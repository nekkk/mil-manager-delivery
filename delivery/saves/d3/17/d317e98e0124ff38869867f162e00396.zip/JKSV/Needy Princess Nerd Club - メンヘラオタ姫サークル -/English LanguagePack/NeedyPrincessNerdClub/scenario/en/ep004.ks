
*start|My relationship with the princess was exposed.

;#################################################
*Ep004|They found out about my relationship with Hime.
;#################################################

[SCENE id=4]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


Then in the morning, I woke up with Kaoruko.
[cpg]

[OnName num="natsuki"]
She said, "......After all, I'll go to the club room alone. Because even Kaoruko won't be blamed."
[cpg cn=true]

[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Kaoruko340"]
[OnName num="kaoruko"]
Sonnya...... then, I'll go with you.
[cpg cn=true]

The two of us agonized over whether I should go to the clubroom alone or together.
[cpg]

In the end, it was decided that I would go alone, but it took me a long time to get there.
[cpg]

I couldn't ...... tell whether her strange persistence was a desire to show off her boyfriend, me, or not.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

Then Kaoruko went back towards her house and I walked towards the university.
[cpg]

I felt heavy. I was going to lose the otaku friend I had found.
[cpg]

I had a little bit of hope that he might forgive me, but that didn't make me feel any better.
[cpg]

I wonder if I will be able to choose my words well enough to avoid him.
[cpg]

I'm a nerd, too, and I'm really bad at that kind of thing, what you might call a communicator. ......
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]

Then I got to the university.
[cpg]

I went to the circle building and they were already waiting for me.
[cpg]

I don't need to ask them what's going on with their morning lectures, they're probably skipping them, but I have to skip them too.
[cpg]

If I'm going to explain myself to everyone, the sooner the better.
[cpg]

I was wondering whether I should open the door or not around the entrance, but I gave it a push and entered the room.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア開く』


[window target=false]
[free time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（朝）******************************************************

[OnName num="kimoto"]
I went into the room and said, "You've come to ......, haven't you?
[cpg cn=true]

[OnName num="tokuzawa"]
I mean, I'm surprised you came. I'm not sure if I should open the door or not.
[cpg cn=true]

[OnName num="shinjo"]
......
[cpg cn=true]

I'm scared. Very scary. Insidiously scary. I know it's wrong of me to do what I did, but there's so much pressure on me to walk away right now.
[cpg]

[OnName num="tokuzawa"]
I'm like, "Well, sit down. I'm going to ask you one question at a time."
[cpg cn=true]

[OnName num="natsuki"]
Ha, yes. ......
[cpg cn=true]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



And so began the interrogation from the three of them.
[cpg]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（朝）******************************************************

[OnName num="shinjo"]
I saw you two talking in that restaurant, right?
[cpg cn=true]

[OnName num="natsuki"]
Yes, .......
[cpg cn=true]

[OnName num="tokuzawa"]
I'll tell you plainly. Are you dating the princess?"
[cpg cn=true]

[OnName num="natsuki"]
"That's ...... just because we happened to be out together at the time, not because we're dating. ......
[cpg cn=true]

[OnName num="kimoto"]
But Shinjo-dono seems to be asking a little more than that, that he should not.
[cpg cn=true]

I'm sure that's true. I just didn't have the face to hear the two of them talking.
[cpg]

[OnName num="tokuzawa"]
I'm sure he didn't look like he heard the two of them talking.
[cpg cn=true]

[OnName num="natsuki"]
That's a false accusation!　Even Kaoruko must think it's too tight.
[cpg cn=true]

[OnName num="shinjo"]
......, here's the main point.
[cpg cn=true]

Shinjo-senpai leans forward over the desk with a "Yui". He is very intimidating.
[cpg]

[OnName num="shinjo"]
I'm good at memorizing lines in anime and other programs. That's why I remember what Sugiura said.
[cpg cn=true]

[OnName num="kimoto"]
I would like to hear it again, that I would like to hear it again, that I would like to hear it again. What did he say, that he did?
[cpg cn=true]

[OnName num="shinjo"]
"Let's go our separate ways for once, because if we act apart, they won't think we're dating. ......
[cpg cn=true]

Oh. I'm sure you've already heard the part where you can't completely get away with it.
[cpg]

[OnName num="tokuzawa"]
"What do you think?　Any objections?
[cpg cn=true]

[OnName num="natsuki"]
"You heard wrong. We're not dating."
[cpg cn=true]

My voice trembles. It's easy to tell that he's lying.
[cpg]

[OnName num="kimoto"]
"I'll take my jokes in my stride, that I will!"
[cpg cn=true]

[OnName num="tokuzawa"]
Yes, where's the benefit of Shinjo's lie here?　We thought we could get along with you, you know!
[cpg cn=true]

[OnName num="natsuki"]
...... That's because Shinjo-senpai has some kind of grudge against me and is trying to trick me, or something.
[cpg cn=true]

[OnName num="shinjo"]
I'm almost sure you're right. He has a grudge against me because I'm dating a princess.
[cpg cn=true]

No, I can't do that. There is no way to get away with it. Can't we go back to the way things were with the three of them? ......
[cpg]

[OnName num="tokuzawa"]
How does it feel to run away without telling us?
[cpg cn=true]

[OnName num="kimoto"]
How do you feel, Mr. Sugiura, about where you are in ABC, that you are?
[cpg cn=true]

There is no need to answer. If I answered, it would only strengthen the resentment between the three of us.
[cpg]

[OnName num="natsuki"]
I understand," he said, "....... I know I made the atmosphere in the circle worse, didn't I?
[cpg cn=true]

[OnName num="kimoto"]
It's not a matter that can be solved with an apology!
[cpg cn=true]

[OnName num="tokuzawa"]
Yes, our princess is not to be defiled by such a man. ......
[cpg cn=true]

[OnName num="shinjo"]
I don't want to hear about it. I don't want to hear about it.
[cpg cn=true]

That's right. It's not a matter of apologizing. Then I had no choice but to go to the last resort.
[cpg]

[OnName num="natsuki"]
I don't think it's enough to apologize, either. I'm leaving the circle.
[cpg cn=true]

[OnName num="tokuzawa"]
"Oh, yeah, get out, get out. You're not coming to Nidoko's clubroom anymore.
[cpg cn=true]

[OnName num="kimoto"]
"No, no!　That is not good, that it is not, Mr. Tokuzawa!
[cpg cn=true]

However, the wind has changed a little. I see, on the contrary, I have become an important person for them.
[cpg]

[OnName num="tokuzawa"]
Why, it would be better for the circle if this guy didn't exist.
[cpg cn=true]

[OnName num="shinjo"]
"But if ...... Sugiura leaves, Hime will also leave the circle with him.
[cpg cn=true]

[OnName num="tokuzawa"]
Oh, ......
[cpg cn=true]

Yes, that's what I mean. It's a chain that holds their precious princess together.
[cpg]

[OnName num="tokuzawa"]
Then there's nothing you can do about it. ......
[cpg cn=true]

[OnName num="kimoto"]
"Not really, that I can think of some other way to sanction them, that I can think of now.
[cpg cn=true]

[OnName num="natsuki"]
"......"
[cpg cn=true]

Sanctions, huh? But I didn't have to leave the circle.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]

From there, everyone started to think about what the sanctions against me would be.
[cpg]

;//【ＢＧ】『サークル部室』（昼）******************************************************

[OnName num="tokuzawa"]
......Yes, Sugiura. You should dump the princess little by little.
[cpg cn=true]

[OnName num="natsuki"]
......I think she'd probably leave the circle in shock if I did that.
[cpg cn=true]

[OnName num="shinjo"]
"Oh, so you're that friendly with her?
[cpg cn=true]

[OnName num="kimoto"]
"No, if you dump the princess or something before that, the atmosphere will be even worse, that it ...... will be.
[cpg cn=true]

No answer. It's almost noon and I'm getting hungry.
[cpg]

I don't think there's any point in having any more unanswerable discussions, but...
[cpg]

[OnName num="natsuki"]
Can I go to the cafeteria now, ......?
[cpg cn=true]

[OnName num="tokuzawa"]
I'm hungry!　Be patient!
[cpg cn=true]

[OnName num="shinjo"]
That's right!　I'm putting up with it too.
[cpg cn=true]

But they still won't let me go, that's how guilty I am.
[cpg]

[OnName num="tokuzawa"]
For example, Sugiura might do something to make the princess hate me. ......
[cpg cn=true]

[OnName num="kimoto"]
That it is, that it is!　For example, putting down her favorite anime."
[cpg cn=true]

[OnName num="natsuki"]
Is that okay?　I think Kaoruko will be disappointed.
[cpg cn=true]

[OnName num="shinjo"]
"Well, I don't like that. ...... I don't want to see Princess Kaoruko depressed.
[cpg cn=true]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]

I'm not getting anywhere. I think we can all go to the cafeteria now and talk about it there.
[cpg]

And then ...... the savior appeared.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア強く開く』
[free time=1000]
[WAIT time=1000]



[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kaoruko341"]
[OnName num="kaoruko"]
He said, "Excuse me!　Let's see, that ......."
[cpg cn=true]

[OnName num="tokuzawa"]
"......, Kaoruko-chan?"
[cpg cn=true]

I said I would go alone first, but since he didn't come out of the club room, I guess he got worried.
[cpg]

Whatever it was, Kaoruko was there. She was dressed back in her usual Lolita outfit.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko342"]
[OnName num="kaoruko"]
I'm sorry, I, um, ...... how far am I getting this?
[cpg cn=true]

[OnName num="natsuki"]
Everyone seems to know we're dating. ......
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko343"]
[OnName num="kaoruko"]
I see, I knew it. ......
[cpg cn=true]

Kaoruko turns her head and almost starts to cry. Seeing this, the seniors panic.
[cpg]

[OnName num="shinjo"]
Don't cry!　I don't blame you.
[cpg cn=true]

[OnName num="tokuzawa"]
That's right, we weren't interrogating Sugiura.
[cpg cn=true]

I see, I wasn't interrogated. I think I was interrogated enough.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko344"]
[OnName num="kaoruko"]
"I understand ....... I won't cry. I will tell you the truth."
[cpg cn=true]

I held back my tears, and my eyes became sharp and strong.
[cpg]

[OnName num="natsuki"]
......"
[cpg cn=true]

The boys, including me, held their breath. Then Kaoruko began to speak little by little.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko345"]
[OnName num="kaoruko"]
I'm sorry. I'm dating Natsuki-kun, I admit it. ......
[cpg cn=true]

I heard small screams from the other boys.
[cpg]

But Kaoruko continued her follow-up words.
[cpg]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Kaoruko346"]
[OnName num="kaoruko"]
She said, "So, but!　But, I love you all just as much as you love me.
[cpg cn=true]

[OnName num="tokuzawa"]
'......Oh, as much as ......?"
[cpg cn=true]

[OnName num="kimoto"]
"That's a lie, that I don't go out with anyone in particular, that I don't."
[cpg cn=true]

A plausible counter-argument emerges. In response to that,
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko347"]
[OnName num="kaoruko"]
I'm telling you the truth!　That's why I want to stay in this circle.
[cpg cn=true]

I want to stay in this circle forever.
[cpg]

[OnName num="natsuki"]
Kaoruko ......
[cpg cn=true]

The reason I muttered this was because I was caught in the "I love you as much as you love me" part.
[cpg]

Perhaps it was a lie to calm the situation, but still, I was a bit miffed.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko348"]
[OnName num="kaoruko"]
I love Tokusawa-senpai, Shinjo-senpai, and Kimoto-san as much as ...... I love them.
[cpg cn=true]

We are weak when girls say they love us. In fact, I was weak.
[cpg]

And everyone else was weak too. The mood that had been so bad earlier had gone away, and they were now looking at Kaoruko with sparkling eyes.
[cpg]

And then, the final word.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko349"]
[OnName num="kaoruko"]
I don't want everyone to hate me, even though I met such wonderful people.
[cpg cn=true]

It's a bit dangerous if you ask me. If you focus on the "I don't want to be disliked," it sounds like a very selfish thing to say.
[cpg]

But everyone was completely taken with it. And then, without anyone's saying anything about it, the topic of conversation turned to something like this.
[cpg]

[OnName num="kimoto"]
I am also in love with Kaoruko-dono, that I am. I like Kaoruko-dono, that I do.
[cpg cn=true]

[OnName num="shinjo"]
"Oh, me too, ...... I'm glad to be told that I like you too, buh, buh.
[cpg cn=true]

[OnName num="tokuzawa"]
That's right, actually we always thought Kaoruko-chan was cute.
[cpg cn=true]

There's something fishy in the air. I couldn't stop him, I just stared at him.
[cpg]

[OnName num="tokuzawa"]
I even called her a princess behind her back. ......
[cpg cn=true]

[OnName num="kimoto"]
Yes, that's right, that's why I was jealous of Sugiura-dono.
[cpg cn=true]

[OnName num="shinjo"]
I was jealous of Sugiura-dono, that I was. It is natural for a healthy girl to date a boy.
[cpg cn=true]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Kaoruko350"]
[OnName num="kaoruko"]
I'm not a fan of that!　I've done terrible things to all of you. Please don't say that.
[cpg cn=true]

[OnName num="shinjo"]
"Bwah!
[cpg cn=true]

Kaoruko took Shinjo-senpai's hand. She then burst into tears.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko351"]
[OnName num="kaoruko"]
I've made a mess of everyone's place,......, and I really think I've done something bad.
[cpg cn=true]

[OnName num="kimoto"]
I don't think I've done anything wrong!　You're overreacting just because I went out with a boy, that you are.
[cpg cn=true]

He approached Kimoto, who said, "I'm sorry," and this time took Kimoto's hand.
[cpg]

[OnName num="kimoto"]
"You're so close, that you are, Kaoruko-dono.
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Kaoruko352"]
[OnName num="kaoruko"]
I'm so happy,...... that you forgive me, Kimoto-kun.
[cpg cn=true]

[OnName num="kimoto"]
"......Of course, that I do,......."
[cpg cn=true]

There was a short pause, but for the time being, Kimoto was subdued. And one after another,
[cpg]

[OnName num="shinjo"]
I don't have a problem with you dating Sugiura, either!　It's true!"
[cpg cn=true]

[OnName num="tokuzawa"]
Oh, I don't either. ......
[cpg cn=true]

Even the senior members began to act as if the issue itself had never happened.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko353"]
[OnName num="kaoruko"]
I'm so happy. I'm too happy,...... to be cherished so much by everyone.
[cpg cn=true]

And Kaoruko, who had regained the faith of the three boys, was overcome with emotion.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Kaoruko354"]
[OnName num="kaoruko"]
'......I love you all too!'
[cpg cn=true]

I had a feeling that things were about to get even more complicated. I felt it, but decided not to say anything at that moment.
[cpg]

If this would solve the problem for now, fine. ......
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


From there, we who were hungry headed to the school cafeteria. Naturally, with Kaoruko, the five of us.
[cpg]

[OnName num="shinjo"]
From now on, you won't call Kaoruko-chan "Hime" in secret, will you?
[cpg cn=true]

[OnName num="tokuzawa"]
That's right. She's our princess, so it's only natural that we call her "Hime.
[cpg cn=true]

I was silent the whole time. In a way, I think I was the star of the day, but I was pretending I wasn't there.
[cpg]

I was also silent because of my absence.
[cpg]

If I approached her and acted like a lover, things would get complicated again.
[cpg]

Then, it was better to keep quiet here. ......
[cpg]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（昼）******************************************************

The next lecture was the same as Kaoruko's.
[cpg]

Of course, we sat next to each other. So I decided to ask her in a whisper.
[cpg]

[OnName num="natsuki"]
'......You said earlier that everyone likes you as much as I do.'
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko355"]
[OnName num="kaoruko"]
Oh, ah,...... that was,......."
[cpg cn=true]

Kaoruko looks awkward. And then,
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kaoruko356"]
[OnName num="kaoruko"]
I'm not sure if it's true. Natsuki-kun is the best.
[cpg cn=true]

She said, "Natsuki-kun is the best. Well, it's probably true.
[cpg]

[OnName num="natsuki"]
If that's the case, I feel sorry for my senpai and Kimoto. They don't know that."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
He became even more awkward. Kaoruko desperately searched for words,
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kaoruko357"]
[OnName num="kaoruko"]
"At ......, though. This worked out well, so why not?　It's enough to give me a compliment, isn't it?"
[cpg cn=true]

She reopened her mouth. Surely, I could say ...... that I got the result I wanted, too?
[cpg]

Because all I wanted was the same geekery I've always wanted, and I didn't expect it to transform like this......
[cpg]

...... No, it hasn't transformed yet. I might transform more in the future.
[cpg]

[OnName num="natsuki"]
I'm sorry, that was weird. I'm sorry, that was a weird thing to say."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kaoruko358"]
[OnName num="kaoruko"]
"Uh, yeah. ......
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（夕方）******************************************************

The lecture was over. I walked alongside Kaoruko.
[cpg]

Then Kimoto came from the other side. He seemed to notice me by raising his hand.
[cpg]

[OnName num="kimoto"]
Sugiura-dono," said Hime ......, "are you going to the club room now, that you are?
[cpg cn=true]

[OnName num="natsuki"]
No, I was going back to ...... because I wanted to check some programs.
[cpg cn=true]

[OnName num="kimoto"]
"What about you, Princess?　I don't have such plans, do you?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kaoruko359"]
[OnName num="kaoruko"]
"Uh, well, ...... um, yes."
[cpg cn=true]

Kaoruko, pushed by Kimoto's swordplay, replies.
[cpg]

[OnName num="kimoto"]
The actuality of the particulars is that it's a good idea, that it's a good idea. That's good, that it is.
[cpg cn=true]

Kaoruko looked at Kimoto and me alternately, waiting for my reply.
[cpg]

[OnName num="natsuki"]
She looks at me alternately, waiting for my reply. Then, why don't you go?"
[cpg cn=true]

I could have watched that program in the club room, but I wanted to watch it alone and in peace and quiet if possible.
[cpg]

So I decided to leave Kaoruko behind. ......
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko360"]
[OnName num="kaoruko"]
I said, "Well then, see you later. Natsuki-kun.
[cpg cn=true]

[OnName num="natsuki"]
Natsuki-kun. I'll see you tomorrow.
[cpg cn=true]

I didn't really feel like we were growing apart or anything at this point.
[cpg]

I could at least imagine being treated like a princess by everyone in the circle, and being elated. ......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

I think I'll stop shopping today. That's how much I definitely want to check out this program.
[cpg]

There's a show, or rather a PR for a certain game company. I definitely want to check that out.
[cpg]

I could have shared that with everyone in the club room, but it was too important an event for me and I wanted to watch it alone.
[cpg]

So I decided to stop shopping and just cook a meal with whatever was left in the fridge.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

Then, I watched the PR in real time.
[cpg]

It may sound strange to say that I was watching a PR movie, but I'm sure there are many people out there who feel the same way I did.
[cpg]

It was such a moving movie that ...... I was watching it with tears in my eyes from the middle.
[cpg]

I couldn't expose myself like this in the clubroom. It was the right decision to watch it alone.
[cpg]

I'm sure Kaoruko is probably being pampered right now,......, I thought.
[cpg]

I wonder if she might have gone out for a drink without me.
[cpg]

Then I wonder if she would do to someone else what she does to me: ......
[cpg]

I don't consider myself to be that possessive. I'm not afraid to be goofy with other boys. ......
[cpg]

Well, it's okay. It's not likely to go any further than that.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


Then I tried to go to sleep, excited by the publicity of the example.
[cpg]

It was hard to sleep because my eyes were so bright, but I managed to sleep.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

Then I woke up somewhat late, hurriedly changed my clothes and brushed my teeth.
[cpg]

No breakfast today. With that in mind, I hurried out of the house.
[cpg]



[SE f="se037"]
;//【ＳＥ】『ドア閉まる』


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se016"]
;//【ＳＥ】『走る』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


Exercise is tough for an otaku. I was too late last night, I knew.
[cpg]

Regretting that I had stayed up too late last night, I headed for the station as fast as I could.
[cpg]

I run, walk, and then run again.
[cpg]

I hated my irregular life, thinking ...... that such a dull man could be such an abomination.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（朝）******************************************************

In the end, I was a little late for the lecture. It was a good thing I was late because I managed to stay within the tardy limit.
[cpg]

[OnName num="kimoto"]
Is everything all right, that it is?　Sugiura-dono?
[cpg cn=true]

Kimoto, sitting next to me, was worried about me.
[cpg]

The teacher of this lecture today was rather lax and allowed me to sneak around during the lecture. So I answered.
[cpg]

[OnName num="natsuki"]
It's nothing. ......
[cpg cn=true]

[OnName num="kimoto"]
Could it be the announcement?　Sugiura-dono is very enthusiastic, that he is.
[cpg cn=true]

[OnName num="natsuki"]
"No, it's fine, I don't care why ...... you stayed up so late," he said.
[cpg cn=true]

[OnName num="natsuki"]
"Kimoto is the one who forced Kaoruko to go with you yesterday, didn't you go out for a drink or something after that?
[cpg cn=true]

[OnName num="kimoto"]
"...... that's not true, but..."
[cpg cn=true]

I'm not sure what you mean by that," he said, looking somewhat uncomfortable. What do you mean?
[cpg]

[OnName num="kimoto"]
I am surprised, that I am not surprised. I am surprised, that I am not.
[cpg cn=true]

[OnName num="natsuki"]
What do you mean by "she has such and such a part"?
[cpg cn=true]

But he didn't answer me. I wondered what it was, but I did not pursue it deeply at that time.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************
;//♪私服（パンツスタイル）


Then, around the end of the lecture, I went to the club room. And there was a strange scene.
[cpg]

Or rather, a strange Kaoruko. She looked like she was in ecstasy and was sticking to Shinjo-senpai.
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Kaoruko361"]
[OnName num="kaoruko"]
'Shinjo-senpai's tummy, it's so plump......... I'm touching it, it's so nice...'
[cpg cn=true]

[OnName num="shinjo"]
'Buh, I don't know, I don't think so myself, but buh buh buh.'
[cpg cn=true]

The first time I saw her, I was so excited.
[cpg]

Now, they are sitting next to each other so closely that they are touching Shinjo-senpai.
[cpg]

[OnName num="tokuzawa"]
"......Hime, do you still like the bigger-built one ......?"
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kaoruko362"]
[OnName num="kaoruko"]
She was so close to me that I had to touch her. Tokusawa-senpai is also nice, oh, and his dark eyes are wonderful."
[cpg cn=true]

And on the opposite side is Tokusawa senpai. This one is also closely packed on this side, like a reverse harem.
[cpg]

I was stunned for a while, but then I decided to respect Kaoruko's wishes, thinking that if this is what Kaoruko wanted, then it's fine.
[cpg]

[OnName num="natsuki"]
I was stunned for a while, but then I decided that if this was what Kaoruko wanted, it was fine. Am I interrupting something?
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kaoruko363"]
[OnName num="kaoruko"]
No, it's okay. Natsuki-kun, come over here too.
[cpg cn=true]

She looked enraptured and intoxicated by the environment in which she was pampered.
[cpg]

[OnName num="natsuki"]
I understand ......, but the left and right sides of the room are occupied, okay?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko364"]
[OnName num="kaoruko"]
Then, Tokusawa-senpai, can I switch seats?"
[cpg cn=true]

[OnName num="tokuzawa"]
I'm not sure if it's a good idea or not, but I'm sure it's a good idea. I'll be right back.
[cpg cn=true]

Tokusawa-senpai, who quickly moves out of the way, saying, "I'm sorry. She is at her mercy.
[cpg]

And then Kaoruko puts her hand on the open chair with a clunk. It seems that she wants me to sit here.
[cpg]

[free time=300]
[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]

I had no reason not to follow her there, so I sat down. ......
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kaoruko365"]
[OnName num="kaoruko"]
I was thirsty. Senior." "Oh, I'll go and buy some.
[cpg cn=true]

[OnName num="shinjo"]
Oh, I'll go get some.
[cpg cn=true]

Shinjo-senpai dashed off, shaking his huge body. He then took an empty seat,
[cpg]

[OnName num="kimoto"]
"May I sit down, princess ......?
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Kaoruko366"]
[OnName num="kaoruko"]
Of course. Of course, it's fine, Kimoto-kun.
[cpg cn=true]

He said so in a bright voice. Dangerous. This situation is dangerous.
[cpg]

Kaoruko's needs are being satisfied in a very dangerous balance.
[cpg]

If something collapses somewhere, it would fall apart in an instant, such a dangerous happiness.
[cpg]

Kaoruko, do you think she is aware of that?　It's impossible for things to stay like this forever. ......
[cpg]

[OnName num="shinjo"]
I got you something.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko367"]
[OnName num="kaoruko"]
Thank you very much."
[cpg cn=true]

It is Shinjo-senpai's job to even open the lid of the PET bottle.
[cpg]

Then Kaoruko drinks the juice. After a few sips, she let go of her mouth.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko368"]
[OnName num="kaoruko"]
"Phew. You can all drink the rest.
[cpg cn=true]

[OnName num="kimoto"]
"Eh, ......?　Is it true?
[cpg cn=true]

[OnName num="shinjo"]
This is mine, I won't let anyone have it!
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
Kaoruko giggles. She has completely become a princess herself.
[cpg]

I thought one day we would be like a princess and a commoner, but now we are a princess and a slave.
[cpg]

[OnName num="natsuki"]
"...... You know, Kaoruko, ...... don't do this kind of thing too ...... much."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko369"]
[OnName num="kaoruko"]
What?　What's wrong, Natsuki-kun?
[cpg cn=true]

[OnName num="natsuki"]
"...... nothing. It's nothing.
[cpg cn=true]

No, I think it's better if I don't tell you. If Kaoruko is satisfied, that's fine.
[cpg]

I'm Kaoruko's boyfriend. Protecting her happiness is the first thing I have to do ......, I think.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kaoruko370"]
[OnName num="kaoruko"]
Are you maybe jealous?　Fine, let's get out of here for a minute."
[cpg cn=true]

[OnName num="natsuki"]
"No, no, I'm not jealous, but ...... hey, Kaoruko?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko371"]
[OnName num="kaoruko"]
I'm sorry everyone, I have something to do with Natsuki-kun, so I'm leaving the room.
[cpg cn=true]

The three of them looked like they were sorry to see us go.
[cpg]

No one would chase after her. It was impossible for the three of them to stop the noble princess now.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_03_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（夕方）******************************************************

And then we were brought to an empty classroom at the university.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Kaoruko372"]
[OnName num="kaoruko"]
'...... Hey, have you noticed anything different about us than we've been doing?
[cpg cn=true]

[OnName num="natsuki"]
No, I don't know, what?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
Kaoruko sighed and shook her head. The gesture seems to be somewhat buoyant.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="sKaoruko010"]
[OnName num="kaoruko"]
I'm not sure if it's a good idea to keep it a secret from anyone. We can make out anywhere.
[cpg cn=true]

Is that why you brought me to this empty, unpopular classroom?
[cpg]

[OnName num="natsuki"]
It's not like you don't care who sees us, right?"
[cpg cn=true]

Kaoruko is troubled, saying, "Hmmm. No, this is a pretense of being troubled. She has already decided on her answer.
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="sKaoruko011"]
[OnName num="kaoruko"]
"Natsuki-kun, don't you want to hug me ......?"
[cpg cn=true]


......I can't run away if she asks me like that.
[cpg]


;//移植のためシーンをカットしています

;//●ＣＧエロ（ヒロイン・カーテンを開けたまま後背位。窓に胸を押し当てる：大学教室）ev_15

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_15_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]


I move closer to her. I can't imagine spontaneously flirting in a place like this.
[cpg]

But if Kaoruko is asking for it, I can't refuse her. ......
[cpg]

[VOICE f="sKaoruko012"]
[OnName num="kaoruko"]
'Heh. I'm so happy...... I can smell Natsuki-kun's scent."
[cpg cn=true]


She looked happy, but I was in a cold sweat.
[cpg]

If this kind of behavior escalates, it's a big problem.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_03_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（夕方）******************************************************

After that, we left the room holding hands, or rather Kaoruko snuggled up to me.
[cpg]

The students hardly walked. I was relieved, but thought that this might be a little frustrating for Kaoruko.
[cpg]

Kaoruko probably wants to do it in a more public place.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Kaoruko410"]
[OnName num="kaoruko"]
"...... Hey, Natsuki-kun.
[cpg cn=true]

[OnName num="natsuki"]
What?"
[cpg cn=true]

[free time=300]
[FG f="CHA01_p5_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Kaoruko411"]
[OnName num="kaoruko"]
"I love ......."
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

After that, Kaoruko dropped by the club room and was treated like a princess.
[cpg]

Seeing Kaoruko getting so pleased with herself, I had mixed feelings.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


And while I was doing that, it was nighttime.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

[OnName num="natsuki"]
Then, I'll see you later.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko412"]
[OnName num="kaoruko"]
"Okay, bye. Let's do many things tomorrow.
[cpg cn=true]

Various things, various things. ......
[cpg]



[SE f="se020"]
;//【ＳＥ】『電車に揺られる』

;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


As I was riding the train home, I imagined that if I repeated this kind of thing every day from now on, it would be bad.
[cpg]

If I repeated this kind of thing every day from now on, I would attract attention in a bad way.
[cpg]

But if that's what she wants, I may not be able to keep up.
[cpg]

But I don't have the guts to break up with her.
[cpg]

The guts of it all include whether I'll ever be courted by a pretty girl like that in the future, but it's more than that.
[cpg]

I didn't feel like he would just let me go without saying goodbye.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

I took the train to my house and headed home.
[cpg]

I was more concerned about Kaoruko tomorrow than I was about today's dinner.
[cpg]

Would I be able to continue going out with her?
[cpg]

Not only about her exhibitionistic nature, but also about her attitude toward the other members of the group.
[cpg]

Both of them are in a precarious balance that could all fall apart at the slightest touch.
[cpg]

When it comes to Kaoruko's boyfriend, my mood becomes a little heavy. ......
[cpg]



;//ＢＫ


[SE f="se037"]
;//【ＳＥ】『ドア閉まる』

[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

It took me a while to come to the conclusion that it was not worth thinking about.
[cpg]

Specifically, it took me until I finished dinner, took a bath, surfed the Internet, and tried to go to bed.
[cpg]

I can't sleep if I'm thinking about dark things.
[cpg]

Yes, surely, by taking some time, Kaoruko might become more normal or ...... less inclined to do strange things.
[cpg]

With this thought in mind, I went to sleep.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

As it turned out, I realized that I was naive in my thinking.
[cpg]

That day, she came on to me in the middle of a lecture.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学教室』（昼）******************************************************

[OnName num="natsuki"]
She said, "...... What's the matter, Kaoruko? How dare you sit so far back?
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Kaoruko413"]
[OnName num="kaoruko"]
It's fine. I'm in the mood.
[cpg cn=true]

Kaoruko sat at the very back of the class, in the corner.
[cpg]

I thought it was hard to see the writing on the board, but I followed her lead.
[cpg]

And I was the one who failed to notice Kaoruko's intention at that stage.
[cpg]

[free time=300]
[FG f="CHA01_p5_03_a.ui" method="change_6"  pos="2/3" time=800]

[OnName num="natsuki"]
"...... n, huh?
[cpg cn=true]

First, Kaoruko kissed me during the lecture.
[cpg]


[OnName num="natsuki"]
"Puhah ...... what are you doing, Kaoruko?"
[cpg cn=true]

I protest in a whisper, a whisper as loud as I can. Then she started doing something else this time.
[cpg]

;//●ＣＧエロ（ヒロイン・講義中にこっそり隠れて手コキ。手の中に出す：大学教室）ev_16

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]


[VOICE f="sKaoruko013"]
[OnName num="kaoruko"]
'Hey, I think we ...... are a good match in everyone's eyes.
[cpg cn=true]


[OnName num="natsuki"]
'Maybe so, but that's no reason to kiss me anywhere.'
[cpg cn=true]


I protested in a quiet voice.
[cpg]

[VOICE f="sKaoruko014"]
[OnName num="kaoruko"]
'Really?　I think I'm trying to show off."
[cpg cn=true]


I already know that without being told that. That's why I'm in trouble. ......
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************



[OnName num="natsuki"]
'This sort of thing has to stop. Let's just get this over with."
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kaoruko431"]
[OnName num="kaoruko"]
Why not?　I'm pretty, aren't I?"
[cpg cn=true]

And my protests struck me as oddly empty.
[cpg]

In response to my suggestion that we should stop doing this, he said, "I'm cute, aren't I?
[cpg]

There was no connection. I was getting a headache.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kaoruko432"]
[OnName num="kaoruko"]
She said, "If a pretty girl does it to you, no matter what she does to you or where she does it, doesn't that make you happy?"
[cpg cn=true]

[OnName num="natsuki"]
I was like, "...... No, that's right, Kaoruko is cute, right?　But, but, but... ......"
[cpg cn=true]

This is probably because she's getting pampered by everyone at Otasa, and she's losing her grip.
[cpg]


I wonder if I can keep going out with them. I can't keep up with such thoughts. ......
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


After that, we finished all the lectures and headed for the Otasa club room.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア開く』

[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************

[OnName num="kimoto"]
Oh, Sugiura-dono and Hime. We've come to the right place, haven't we?
[cpg cn=true]

[OnName num="natsuki"]
"Just the right place?"
[cpg cn=true]

[OnName num="tokuzawa"]
We were talking about going out for a drink when she gets back.
[cpg cn=true]

She was already calling him the princess in a natural way. I could see Kaoruko's mood getting better each time.
[cpg]

[OnName num="shinjo"]
She was in a good mood.　Of course you're going, right?
[cpg cn=true]

[OnName num="natsuki"]
Oh, yeah, yes. ......
[cpg cn=true]

That's not good. I wonder what happens when alcohol is consumed in this situation.
[cpg]

The previous Ota-Sa drinking session was unusual to begin with, but I think it's going to become even more unusual.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

But since there was no way for me to stop them, we decided to go to the pub.
[cpg]

The five of us used to walk in a line, but now it looks like I'm the only one in the back and the four of us are walking in front of me.
[cpg]

Senpai and Kimoto's infatuation with Hime is tremendous. I guess it's partly because they don't know Kaoruko's true nature.
[cpg]




[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

;//ＢＫ



Then, a few dozen minutes have passed since we entered the izakaya.
[cpg]

In short, by the time everyone was ready, this is what happened.
[cpg]



[window target=false]
[free time=1000]
[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居酒屋』（夜）******************************************************


[VOICE f="Kaoruko434"]
[OnName num="kaoruko"]
'Hmm, Kimoto-kun, you have rice grains on you. ......
[cpg cn=true]

[OnName num="kimoto"]
"Oh, is that so?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kaoruko435"]
[OnName num="kaoruko"]
"I'll take it off for you. ......
[cpg cn=true]

I took a grain of rice from his lips and ate it as it was.
[cpg]

Kimoto's face is already bright red, and since this has happened more than once, everyone is bright red.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Kaoruko436"]
[OnName num="kaoruko"]
He was really comfortable sitting on Shinjo-senpai's lap, by the way.
[cpg cn=true]

[OnName num="shinjo"]
Buh, huh, you can sit on it forever.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
There's nothing stopping me now. I thought this over and over again, like an excuse to myself.
[cpg]

As we drank more, the customers at the next table started making noise.
[cpg]

High-pitched voices, a group of girls. They were making a lot of noise and I don't know what it was, but they were laughing a lot.
[cpg]

[OnName num="tokuzawa"]
'...... next door, it's too noisy.'
[cpg cn=true]

[OnName num="natsuki"]
"Is that so? ...... I think that's what taverns are like, though."
[cpg cn=true]

[OnName num="shinjo"]
I know that group. It's a group of gals led by a girl named Yui.
[cpg cn=true]

Yui. I've heard of her, I don't know her last name, but that probably means she's the kind of person who, when asked her name, answers with her first name.
[cpg]

In other words, I'm biased, but it's called a gyaru.
[cpg]

[OnName num="kimoto"]
Compared to a woman with no modesty like that, the princess is a billion times prettier.
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]

[OnName num="tokuzawa"]
Billions of times prettier." "Billions of times prettier?" That's rude. Zero times zero is zero.
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kaoruko437"]
[OnName num="kaoruko"]
Oh, please don't compliment me so much.
[cpg cn=true]

[OnName num="shinjo"]
But yes, it is not good to have no modesty.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
I was thinking ...... that if you think about it, Kaoruko doesn't have modesty either,.......
[cpg]

If you know the name Yui, then you must be a group of gals at the same college. How about saying something too shady: ......
[cpg]

[OnName num="natsuki"]
"That kind of backbiting is not good. ......
[cpg cn=true]

[OnName num="shinjo"]
'Buf, it's okay, it's okay, I can't hear you.'
[cpg cn=true]

[OnName num="natsuki"]
It's not a matter of whether you can hear me or not. ......
[cpg cn=true]

[OnName num="tokuzawa"]
It's not about whether you can hear me or not!　She's still our princess, and we're so glad we're nerds.
[cpg cn=true]

[OnName num="kimoto"]
I'm not prejudiced against nerds, that I'm not.
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kaoruko438"]
[OnName num="kaoruko"]
I'm sure you're right. I don't know, I am certainly an otaku myself, so I have no prejudice against you.
[cpg cn=true]

If you look closely, you will see that Kaoruko's face is also red. And she has a big smile on her face.
[cpg]

I guess she is elated because of the alcohol, but ......
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Kaoruko439"]
[OnName num="kaoruko"]
I think this is where I belong. Anywhere else, I'd be a bit out of place.
[cpg cn=true]

[OnName num="kimoto"]
I don't float, that I don't float!　The princess is a princess no matter where she is, that she is.
[cpg cn=true]

[OnName num="shinjo"]
"But that doesn't mean that I don't belong in this circle. Right, Kimoto?
[cpg cn=true]

[OnName num="kimoto"]
And of course!　A princess is a princess wherever she is, that she is, but she is a princess only when she is in this circle, or how should I say it ......"
[cpg cn=true]

Kaoruko keeps getting praised and smiles ehehehe. I wonder how she feels about it.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kaoruko440"]
[OnName num="kaoruko"]
I'm sure you can find a place for me in this circle after all. Natsuki-kun, you think so too, don't you?
[cpg cn=true]

I thought about it for a moment and then answered.
[cpg]


[switch]
[case "I think you are right."]
	[swap]
	[jump target="*select01_1"]
[case "I don't think so."]
	[swap]
	[jump target="*select01_2"]
[endswitch]

;//■選択肢
;//
;//１、その通りだと思う
;//２、そうでもないと思う
;//
;//==============================
;//１、その通りだと思う
*select01_1|He found out about my relationship with Hime.

[stflag boolean1 = 1]

[OnName num="natsuki"]
'...... yes, I think it's the perfect place for Kaoruko.'
[cpg cn=true]

It might be a little thoughtless statement.
[cpg]

But I thought there's no need to say something that could upset her mood here.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko441"]
[OnName num="kaoruko"]
I think so, Natsuki-kun, don't you think so too?
[cpg cn=true]

[OnName num="tokuzawa"]
"Oh, I think so too, don't I?　Sugiura is not the only one who thinks so.
[cpg cn=true]

[OnName num="kimoto"]
'Yes, yes, that I do. Everyone thinks she is a princess, that she is.
[cpg cn=true]

[OnName num="shinjo"]
Me too, me too.
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


After that, Kaoruko was turned on and no one could stop her.
[cpg]

She was so sticky on everyone that she might actually kiss them, not just kiss them indirectly, and things got out of hand.
[cpg]

The three of them are happy to be pampered. Kaoruko, who was pampered by them, took the skinship more and more.
[cpg]

I don't know whether it was a vicious cycle or a virtuous cycle, but the frenzied party continued.
[cpg]

It was hard for me to watch the party sober, so I think I drank a lot of sake.
[cpg]

I'm not a very strong person, but I drank. ......
[cpg]

I regretted it later, but I probably would have regretted it more if I had stayed sober, so I'll take it.
[cpg]

[jump target=*junction01]
;//==============================
;//２、そうでもないと思う
*select01_2|I got caught up with the princess.

[OnName num="natsuki"]
'...... not so much, I guess.'
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Kaoruko442"]
[OnName num="kaoruko"]
'Eh, why ......?"
[cpg cn=true]

[OnName num="natsuki"]
"If it's Kaoruko, she's with you everywhere you go, surprisingly, isn't she?"
[cpg cn=true]


[OnName num="kimoto"]
"What are you saying, that you are? We need the princess to stay in this circle, that we do.
[cpg cn=true]

[OnName num="natsuki"]
No, I'm not saying that she shouldn't be here, that I'm not saying that she shouldn't be here. ......
[cpg cn=true]

I'm not saying that I don't want to be here. I can imagine what it is.
[cpg]

[OnName num="natsuki"]
Maybe I can do something like that no matter where I go.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko443"]
[OnName num="kaoruko"]
Giggle. What do you mean, like that? You say funny things, Natsuki-kun.
[cpg cn=true]

I didn't want to say everything I was thinking because it would have been rude.
[cpg]

It's too rude to say that I'm probably going to move to be pampered ...... wherever I go.
[cpg]

But I'm the one who thought it was rude. Let's reflect on that.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


After that, Kaoruko continued to go skin-to-skin with everyone in order to be pampered.
[cpg]

In a normal boyfriend-girlfriend relationship, it would have been a little painful to watch.
[cpg]

But we are not normal anymore. Kaoruko has a strong need for approval.
[cpg]

It was hard for me to stand by and watch, so I decided to escape by drinking.
[cpg]

I'm not a strong drinker to begin with, so I had to drive myself into a corner. ......
[cpg]

But it was better than staying sober. I'm glad I did this.
[cpg]


;//==============================
*junction01|My relationship with the princess was exposed.


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居酒屋』（夜）******************************************************

[OnName num="kimoto"]
Sugiura-dono. Sugiura-dono."
[cpg cn=true]

[OnName num="natsuki"]
"N......?　Was I out of my mind?
[cpg cn=true]

[OnName num="tokuzawa"]
You were completely asleep. You're so sloppy, just like this.
[cpg cn=true]

[OnName num="natsuki"]
I'm sorry ......, I don't feel so good .......
[cpg cn=true]

[FG f="CHA01_p1_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Kaoruko444"]
[OnName num="kaoruko"]
Are you okay?　Do you want me to take care of you?
[cpg cn=true]

The moment Kaoruko said,
[cpg]

[OnName num="kimoto"]
"I don't feel so good myself, that I do.
[cpg cn=true]

[OnName num="shinjo"]
I might have had too much to drink, too.
[cpg cn=true]

They're fighting over it. Enough of that, I thought ...... and I walked towards the bathroom.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



Oh, I drank too much. I drank too much. I could say it's Kaoruko's fault, but in the end it's my fault.
[cpg]

It was my fault for just being there without really thinking about what we were going to do.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

And then, when the party was about to end, Kaoruko finally stuck with me.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Kaoruko445"]
[OnName num="kaoruko"]
Then, I'm going home. ...... Good night.
[cpg cn=true]

[OnName num="tokuzawa"]
Oh, yeah. Good night."
[cpg cn=true]

[free time=1000]

They could not just stand by and watch. Waving their hands,
[cpg]

[OnName num="tokuzawa"]
What's with the ......, it's Sugiura after all?
[cpg cn=true]

[OnName num="kimoto"]
I can't help it, he's my boyfriend, that he is.
[cpg cn=true]

[OnName num="shinjo"]
But I envy you, don't I?
[cpg cn=true]

But I envy you, don't I? Kaoruko may or may not have heard them.
[cpg]

Probably, the three of them are having a good time with Kaoruko.
[cpg]

But if they go back to the same person every time, it's natural that it's not fun.
[cpg]

I wonder if Kaoruko is aware of this. That someone could lose patience and explode.
[cpg]

Or I wonder if she realizes that she might suddenly lose faith in herself: ......
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="CHA01_p3_03_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[SE f="se001"]
;//【ＳＥ】『歩く』

[VOICE f="Kaoruko446"]
[OnName num="kaoruko"]
Heh heh. Natsuki-kun, you look cool today."
[cpg cn=true]

[OnName num="natsuki"]
"...... You're drunk, Kaoruko. You smell like alcohol.
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kaoruko447"]
[OnName num="kaoruko"]
I'm not drunk,...... not that much.
[cpg cn=true]

But Kaoruko certainly doesn't drink enough to change her personality.
[cpg]

Maybe she's afraid of getting drunk and ruining her character.
[cpg]

I don't know what happens when she gets drunk to the limit, but maybe something changes.
[cpg]

[OnName num="natsuki"]
What happens to Kaoruko when she gets drunk to the limit?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kaoruko448"]
[OnName num="kaoruko"]
She said, "Well, I don't think it changes much. I don't think it changes much. ......
[cpg cn=true]

Does that mean that this is the state after her personality changes?　I don't know.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]



And then, as a matter of course, they followed me home.
[cpg]

I thought maybe the other three were following me, but there was no sign of them.
[cpg]



;//移植のためシーンをカットしています


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています




[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[FG f="CHA01_p3_03_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sKaoruko015"]
[OnName num="kaoruko"]
"Ugh, n......."
[cpg cn=true]


By the time I got home, she was pretty exhausted.
[cpg]

I managed to get her into the bath, but she seemed to fall asleep after she got in.
[cpg]

[OnName num="natsuki"]
"......"
[cpg cn=true]


Let's just go to sleep today. Neither of us said anything, but that's how we got into the futon.
[cpg]

Our bed is a little small for two people. However, Kaoruko sticks to me without complaining.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


Somehow, we manage to stay together as lovers.
[cpg]

The adoration of everyone in the circle is also protected.
[cpg]

I have a feeling that one day it will fall apart, but we are managing somehow.
[cpg]

Surprisingly, I went to sleep, thinking that the days would continue to be similar for a long time.
[cpg]



[jump storage="ep005.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

