;//==============================
;//ルート５
*route5|I just wanted to be bothered more.

*start|I just wanted to be bothered more.

;#################################################
*Ep011|I just wanted to be bothered more.
;#################################################

[SCENE id=11]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************

One day, an incident occurred.
[cpg]

The first signs of an incident are not great.
[cpg]

Kaoruko just took a day off from college. That much is fine.
[cpg]

[OnName num="natsuki"]
......Why did you say you took the day off?"
[cpg cn=true]

[OnName num="kimoto"]
It says that he will take a leave of absence from the university because he doesn't want to run into Yui-dono and the others, that it does."
[cpg cn=true]

They post such things in the group chat of the circle.
[cpg]

For a while, it was filled with nothing but Kaoruko's statements. It was also quite long-winded.
[cpg]

And the wind direction was getting more and more doubtful.
[cpg]

[OnName num="natsuki"]
"This ...... isn't good. ......
[cpg cn=true]

[OnName num="shinjo"]
He said, "...... that if I continue to be obsessed with Yui and the others, if they don't leave me alone, I'll kill myself. ......"
[cpg cn=true]

Then the word suicide comes up again and again.
[cpg]

The text goes on and on as if to threaten us, even clearly stating how to commit suicide.
[cpg]

[OnName num="natsuki"]
...... seriously, Kaoruko?"
[cpg cn=true]

Tokusawa-senpai shook his head.
[cpg]

[OnName num="tokuzawa"]
He said, "Just leave it alone. All you do is talk."
[cpg cn=true]

Yes, just a mouthful. From what I've seen of her so far, that's entirely possible.
[cpg]

We indulged ourselves and played games and talked about anime as we usually do.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


But we underestimated Kaoruko.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************

[OnName num="shinjo"]
So, you know, that voice actor got married. ......
[cpg cn=true]

[OnName num="tokuzawa"]
I guess so." What's it like to be a fan?"
[cpg cn=true]

[OnName num="shinjo"]
'That's just such a buh-huh, buh-huh, I can only congratulate you...ah ......'
[cpg cn=true]

As usual, we were having a good time talking about geeky topics. Then, we were suddenly interrupted.
[cpg]


[SE f="se036"]
;//【ＳＥ】『グループチャット通知』
[WAIT time=1000]

[OnName num="kimoto"]
"Ko, this! Everyone ... is it sent to the place?"
[cpg cn=true]

I don't know what it was, but a picture of a pill was pasted into the chat room and we were in a quandary.
[cpg]

[OnName num="tokuzawa"]
...... seriously, damn it."
[cpg cn=true]

[OnName num="shinjo"]
This is Kaoruko-chan's house, right?
[cpg cn=true]

Shinjo Senpai is breathing hard. He seems to be quite worried.
[cpg]

But I'm probably the one who worries the most. After all, it's her.
[cpg]

If he dies like this, it's more than just a bad aftertaste.
[cpg]

I might regret it for the rest of my life. Then, of course, I can't leave it alone.
[cpg]

[OnName num="tokuzawa"]
"Does anyone know Kaoruko-chan's house? ......!
[cpg cn=true]

[OnName num="natsuki"]
"I know! Well, I'm going ...!"
[cpg cn=true]

[SE f="se012"]
;//【ＳＥ】『走る』
[WAIT time=1000]

[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

I ran selflessly. I had to get to Kaoruko's house as quickly as possible. She might commit suicide.
[cpg]

I shudder at the thought of Kaoruko as a mute corpse. I don't want to be like that.
[cpg]



;//ＢＫ

[SE f="se025"]
;//【ＳＥ】『乱暴なノック』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

Kaoruko's house, I knocked roughly on its door and received a reply.
[cpg]


[VOICE f="Kaoruko1185"]
[OnName num="kaoruko"]
Oh, you finally came ...... late, Natsuki-kun."
[cpg cn=true]

It's Kaoruko's voice. She says, "You're late," and for a moment I'm thrilled.
[cpg]



[SE f="se019"]
;//【ＳＥ】『ドア開く』

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[WAIT time=1000]

Then the door was opened ...... and a smiling Kaoruko greeted me.
[cpg]

What the heck, you said it was late, so I was in a hurry.
[cpg]

[OnName num="natsuki"]
......Just kidding, don't be like that."
[cpg cn=true]

I said this with a serious expression on my face, intending to lecture Kaoruko. However,
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kaoruko1186"]
[OnName num="kaoruko"]
Then you can make me prettier."
[cpg cn=true]

I get a response back. I've been told I'm supposed to be cute, but I've been doing that for a while now. ......
[cpg]

[OnName num="natsuki"]
But what more can I do ......?"
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Kaoruko1187"]
[OnName num="kaoruko"]
Tell me I'm pretty. Tell me you like me. I want you to tell me over and over again that I'm all you've got."
[cpg cn=true]

It's the same as before, isn't it? I don't know if it's okay, that's just the way it is.
[cpg]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


That day, I adored him all night. Or rather, they made me do so.
[cpg]

;//彼女の要望だったのだ。私のことがかわいいなら、一晩中でも抱けるだろうと。
It was her request. She said if I was cute, she would stay up all night.
[cpg]

;//途中から萎え気味になったのは、体力が尽きたというので誤魔化したけど、誤魔化せたかな……
I faked an empty reply halfway through because I said I was running out of energy, but I guess I could have faked it: ......
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Kaoruko1226"]
[OnName num="kaoruko"]
"I'm cute? Beautiful? Princess? Hey, which is it?"
[cpg cn=true]

I think. There should be no mistakes in these details.
[cpg]

[OnName num="natsuki"]
I guess all of ......."
[cpg cn=true]

Maybe this is the right answer. I don't know, I don't want to be too careful about this kind of thing, though.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko1227"]
[OnName num="kaoruko"]
Ufufu. That's right, Natsuki-kun sees it that way."
[cpg cn=true]

But this is an opportunity. Kaoruko is in a good mood.
[cpg]

[OnName num="natsuki"]
So don't ever threaten everyone again. ......
[cpg cn=true]

I took that chance and I said yes. However,
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Kaoruko1228"]
[OnName num="kaoruko"]
"Yeah, ......, I wouldn't if they were all cute and cuddly."
[cpg cn=true]

The terms were returned. Do I need to be adored by everyone, not just me?
[cpg]

[OnName num="natsuki"]
Don't say that, ......, you don't give a damn about anyone else."
[cpg cn=true]

While pretending to be possessive, do not let them look at other boys.
[cpg]

Because if I don't, depending on the attitude of the other boys, I might do something else.
[cpg]

No matter how much I do, I can't make even other boys do what Kaoruko wants.
[cpg]

I have a feeling that Tokusawa-senpai is going to get fed up with Kaoruko's mood swings.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Kaoruko1229"]
[OnName num="kaoruko"]
"Hmmm... Natsuki-kun, are you the type of guy who wants to monopolize girls? Natsuki-kun, are you the type who wants to monopolize girls?"
[cpg cn=true]

It's not, it's not. ...... Well, as long as you're wrong.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]

From then on, I was stuck on Kaoruko's ass.
[cpg]

If they said they wanted to buy something, they bought it, and that's about it.
[cpg]

But it is indeed disheartening to be demanded to use your own life as a shield.
[cpg]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

Today, that is, I was in the park.
[cpg]


;//移植のためシーンをカットしています

;//●ＣＧ（ヒロイン・公園でいちゃつく二人。ヒロインは乗り気：公園の茂み）ev_53

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_53_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]

;//移植のためシーンをカットしています

She often asks for this kind of flirting to show off.
[cpg]

[VOICE f="sKaoruko032"]
[OnName num="kaoruko"]
Tell me you like ......."
[cpg cn=true]


And make them say they love it. I felt like it all came down to that.
[cpg]

I guess she should ...... me to protect her.
[cpg]

But I also felt like I couldn't protect them.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************

[OnName num="natsuki"]
Wow, ...... is putting it up again."
[cpg cn=true]

On a completely separate matter, Kaoruko continued to threaten everyone.
[cpg]

Every time Kaoruko wanted to be pampered, she would post an image in the group chat that hinted at suicide.
[cpg]

[OnName num="natsuki"]
"...... how many times do you have to do this?"
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************

[OnName num="kimoto"]
"......, um, can you do something about the image ......, that you can?"
[cpg cn=true]

[OnName num="tokuzawa"]
You're her boyfriend. Do something to make it stop, please."
[cpg cn=true]

[OnName num="natsuki"]
No, no, I'm asking you to stop too."
[cpg cn=true]

Circle members were honestly becoming less and less concerned.
[cpg]

It is impossible not to worry at all, but still, when the same thing is repeated, human beings become accustomed to it.
[cpg]

I don't know if Kaoruko is aware of this or not, but either way, the current situation wasn't very good.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[OnName num="gal_A"]
"What? Your princess, what are you doing?"
[cpg cn=true]

Then Yui and the others arrived. We explain the situation.
[cpg]

[OnName num="tokuzawa"]
No, it's just that they want ...... to be pampered, so they start threatening us."
[cpg cn=true]

[FACE method="shake_4" pos="4/5"]
[OnName num="gal_B"]
"Seriously? Hand -cut, such a child"
[cpg cn=true]

[OnName num="shinjo"]
I'm told to cut off my hand. ...... In case you're wondering, I'm a member of The Circle."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[OnName num="gal_A"]
I mean, isn't it kind of gagging to cut off your hand in this situation?"
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[OnName num="natsuki"]
Don't make fun of me, I'm serious."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[FACE method="change_1" pos="4/5"]
From there, it became a consultation between us and a group of gals.
[cpg]

[FACE method="shake_3" pos="2/5"]
[OnName num="gal_A"]
I'd be willing to take a gamble and go cold turkey if I were you.
[cpg cn=true]

[OnName num="natsuki"]
"......It's a real gamble. You never know what will happen."
[cpg cn=true]

[FACE method="bow_7" pos="2/5"]
[OnName num="gal_A"]
"But the actual problem, isn't it so worried, isn't it natural?"
[cpg cn=true]

[OnName num="tokuzawa"]
"...... well, sure ...... I'm not too worried about it anymore."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
No, no, no, it's not good. With Kaoruko's personality, what will she do if she is cold?
[cpg]

As long as we don't know that, I think we should stop, but.
[cpg]

I understand that Tokusawa-senpai is finally fed up. I can't stop him either.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

[OnName num="natsuki"]
I'm in trouble with ......."
[cpg cn=true]

;//俺以外の男子は、リスカに対して危機感を覚えてない。もうそれはしょうがないことでもあるけど、でも……
Boys other than me don't feel threatened by Kaoruko. I can't help it anymore, but ......
[cpg]

I still think Kaoruko should be worried about her now. I would do that.
[cpg]

Maybe there's a difference between being her or not.
[cpg]

Senpai and Kimoto, no matter how much they worry about Kaoruko, they get nothing in return. ......
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

And again about the house, images are posted in the group chat.
[cpg]

I hope ...... Kaoruko realizes that this is not a good place to be, though.
[cpg]

But there's nothing you can do from me.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（昼）******************************************************

Then another day. Also, the club room of the circle.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kaoruko1272"]
[OnName num="kaoruko"]
I don't know, isn't everyone at ...... being kind of cold to me lately?"
[cpg cn=true]

[OnName num="kimoto"]
"Is that so?
[cpg cn=true]

[OnName num="shinjo"]
"That's right ...?
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Kaoruko1273"]
[OnName num="kaoruko"]
"I was about to die? Can you worry more?"
[cpg cn=true]

Kaoruko is angry. The boys don't feel that much danger about that either.
[cpg]

[OnName num="tokuzawa"]
Yeah, well, ...... in moderation."
[cpg cn=true]

Too many times and the suicide attempt will not be taken as serious.
[cpg]

Kaoruko is in a state of wolf-boy. If this happens, there is no other way to get her to seriously commit suicide.
[cpg]

That's bad. Very bad. You know that and you know it. ......
[cpg]

I couldn't do anything about it. There was a limit to what I could say to my seniors and to Kimoto, telling them to be more concerned about me.
[cpg]

In the first place, Yui and the others are kind of losing their minds. There is no reason for Kaoruko to worry that much.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko1274"]
[OnName num="kaoruko"]
"I'm really dead? I'm dead, so is it okay?"
[cpg cn=true]

[OnName num="tokuzawa"]
If you're ......, try dying for real once."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[OnName num="natsuki"]
Pssst!"
[cpg cn=true]

[OnName num="tokuzawa"]
You don't want to anyway, do you?"
[cpg cn=true]

I shuddered. Oh no. I don't know what would happen if I said that to Kaoruko.
[cpg]



[OnName num="natsuki"]
Well, well, well. Tokusawa-senpai, you don't have to say that much."
[cpg cn=true]

I tried to placate the situation somehow, but it didn't work very well.
[cpg]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Kaoruko1275"]
[OnName num="kaoruko"]
'Terrible. ...... If I die, won't anyone be sad, even though I'm a princess, me, me...'
[cpg cn=true]



[SE f="se004"]
;//【ＳＥ】『椅子から乱暴に立ち上がる』

Tokusawa-senpai stood up and got angry. Then, he broke out in a loud voice.
[cpg]

[OnName num="tokuzawa"]
You are no princess!"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

Tokusawa-senpai's stress exploded. He stepped on a land mine for Kaoruko.
[cpg]

That's what Kaoruko has done and is doing now, it could happen anytime, but ......
[cpg]

That is not a good reaction for Kaoruko right now.
[cpg]

[OnName num="natsuki"]
He said, "Let's not fight like this. This kind of fighting is not good.
[cpg cn=true]

[OnName num="tokuzawa"]
I'm not fighting. I'm just complaining one way or the other."
[cpg cn=true]

Kimoto and Shinjo senpai did not try to calm this situation down. Everyone must have been very stressed out.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="sKaoruko033"]
[OnName num="kaoruko"]
Okay, then I guess I'm dead."
[cpg cn=true]

[OnName num="tokuzawa"]
I'll say, "All right, all right, all right. Suit yourself."
[cpg cn=true]

Kaoruko takes a step back after the terrible words.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko1277"]
[OnName num="kaoruko"]
I'm at ......."
[cpg cn=true]


[SE f="se012"]
;//【ＳＥ】『走る』
[free time=1000]

And just like that, Kaoruko ran out of the room.
[cpg]

[OnName num="natsuki"]
Wait, Kaoruko ......!
[cpg cn=true]

I tried to chase after him, but Tokusawa-senpai stopped me.
[cpg]

[OnName num="tokuzawa"]
He said, "There's no need to go after him. He needs to wake up for once."
[cpg cn=true]

Indeed, I understand very much what you mean. I also very much understand that it is not good to keep it this way.
[cpg]

[OnName num="natsuki"]
"At ......, but ......"
[cpg cn=true]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************

My bad premonition was right on target.
[cpg]

I should have gone after Kaoruko after all. No matter what I think now, it's too late.
[cpg]

The final moment has arrived. The final phase, the sum total of what we did and what Kaoruko did.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


;//[SE f="se016"]
;//【ＳＥ】『走る』

The next day, Kaoruko didn't show up at the university and I was heading home, worried.
[cpg]

It was unlocked, and I opened it, thinking it was careless. ......
[cpg]



;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


There was Kaoruko, who had turned blue and collapsed.
[cpg]

Strangely, I was not that upset, and I was surprised at myself for that.
[cpg]

I guess I myself thought this would happen someday.
[cpg]

I decided to call an ambulance and the guys in my circle.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

[OnName num="shinjo"]
We, I don't know if it's our fault. ......
[cpg cn=true]

[OnName num="tokuzawa"]
He doesn't know about ......."
[cpg cn=true]

[OnName num="kimoto"]
But, Kaoruko-dono, I wanted to be bothered until the end. ......
[cpg cn=true]

[OnName num="tokuzawa"]
Don't say that!"
[cpg cn=true]

We watched in silence as Kaoruko was taken away in an ambulance.
[cpg]

Is it my fault? Is it because of Kimoto and seniors? Or Yui -san?
[cpg]

...... maybe it's Kaoruko's fault ......
[cpg]

To remain unaware of it may indeed be a blessing.
[cpg]

[SCENE id=17]

[jump storage="epend.ks" target="*start"]
;//【ルート５】エンド

