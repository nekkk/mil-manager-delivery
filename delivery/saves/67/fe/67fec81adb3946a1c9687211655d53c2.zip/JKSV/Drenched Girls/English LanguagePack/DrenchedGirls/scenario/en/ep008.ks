
;//==============================
;//「合意」ルートの場合

*start|Serious Confession to Asuka

;#################################################
*Ep008|Serious Confession to Asuka
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************

*root2_2|Serious Confession to Asuka

[SCENE id=8]

After all, it's Asuka. I don't want to do it forcibly.
[cpg]

On the other hand, I don't want to continue this prank. I've made up my mind.
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

I'm going to confess to Asuka once more. This time, the meaning will be different.
[cpg]

It's different from when I used to confess to anyone and everyone.
[cpg]

That alone would make my confession a little more meaningful.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************

With such determination, the next morning.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Yukiho086"]
[OnName num="yukiho"]
Good morning. Got a girlfriend?"
[cpg cn=true]

[OnName num="ryo"]
"......What makes you think that?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Yukiho087"]
[OnName num="yukiho"]
I don't know, but you seem to have gotten over your doubts. It's my imagination.
[cpg cn=true]

It's still too early to ...... know. She's not ready yet. I'm just getting started.
[cpg]

[OnName num="ryo"]
Not yet. Not yet, not yet.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Yukiho088"]
[OnName num="yukiho"]
"Yeah. So you've found someone?
[cpg cn=true]

[OnName num="ryo"]
......, that's about it.
[cpg cn=true]

;//直下のセリフは小声でお願いします

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=800]
[FACE method="shake_4" pos="2/3"]
[VOICE f="Yukiho089"]
[OnName num="yukiho"]
Not me. I might have been a little disappointed.
[cpg cn=true]

Yukiho said something as if mumbling. But I couldn't catch it.
[cpg]

[FO pos="4/7" time=800]

[OnName num="ryo"]
What?
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Yukiho090"]
[OnName num="yukiho"]
It's nothing. Have a good day.
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************

And then the classroom. I'm thinking about where I'm going to play the game of my life.
[cpg]

;//勝負も、かけると言うな。精液と同じだ。なんてくだらないことを考えながら。
;//[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="ryo"]
"Asuka. Do you have time after school today?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Asuka239"]
[OnName num="asuka"]
What?　What is it?　It's fine.
[cpg cn=true]

At any rate, I got the appointment.
[cpg]

Even if my confession doesn't go well here, it's one of the many times I've failed ......
[cpg]

What a bad idea. I'm going to play the game that I can't fail.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

And then the time passes, the time that I can't wait for.
[cpg]

Slowly, slowly time passes. After school is approaching.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

And the classroom is empty. We were looking outside, not facing each other.
[cpg]

[OnName num="ryo"]
......The guys who are involved in club activities are in good spirits today too.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Asuka240"]
[OnName num="asuka"]
I'm sure they are. It is the policy of the nerds to go home.
[cpg cn=true]

Policy. It sounds strange coming from an English-speaking person like Aska.
[cpg]

I can't afford to be complacent.
[cpg]

[OnName num="ryo"]
I can't wait to hear what he has to say. Will you go out with me?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Asuka241"]
[OnName num="asuka"]
"Oh, you're going to say that again?
[cpg cn=true]

[OnName num="ryo"]
This is the last time. This is probably the last confession in my life.
[cpg cn=true]

I'm going to go out on a limb. I don't know if I will meet a new love in the future, but for now, I'm going out on a limb.
[cpg]

But for now. I'm going to confess for the last time.
[cpg]


[OnName num="ryo"]
"Go out with me. I like you, Asuka."
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[WAIT time=2000]
[FACE method="shake_6" pos="2/3"]
[WAIT time=2000]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Asuka242"]
[OnName num="asuka"]
"......hehehe. I wish it had been like that from the beginning."
[cpg cn=true]

I don't know whether it's OK or not.
[cpg]

Then silence for a while, and my feelings were left hanging in the air.
[cpg]

[OnName num="ryo"]
Which way is it ......?"
[cpg cn=true]

I ask without thinking. And,
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Asuka243"]
[OnName num="asuka"]
'Me too, I want to go out with you, desu ...... heh.
[cpg cn=true]


;//ブラックアウト
;//========================================
;//●ＣＧ（しゃがんで、主人公を見上げるヒロイン）ev_32
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_32_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[OnName num="ryo"]
"Oh, hey. What's wrong?"
[cpg cn=true]

[VOICE f="sAsuka005"]
[OnName num="asuka"]
"Hehehe ...... I feel so relieved.
[cpg cn=true]

[VOICE f="sAsuka006"]
[OnName num="asuka"]
"I'm so relieved. I'm so ...... relieved."
[cpg cn=true]

[OnName num="ryo"]
"......, get a hold of yourself."
[cpg cn=true]

;//移植のためシーンをカットしています


;//ブラックアウト
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

And we became lovers. We didn't try to hide the fact that we were Americans.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************


[FACE method="shake_7" pos="2/5"]
[VOICE f="Mikoto414"]
[OnName num="mikoto"]
"......Why are you two holding hands?"
[cpg cn=true]

[FACE method="bow_2" pos="4/5"]
[VOICE f="Asuka263"]
[OnName num="asuka"]
"Hmmm, we're dating. We're dating.
[cpg cn=true]

[FACE method="shock_5" pos="2/5"]
Mikoto looked a little shocked. Why?
[cpg]

You don't think he had a thing for me, do you?
[cpg]

[FACE method="bow_6" pos="2/5"]
[VOICE f="Mikoto415"]
[OnName num="mikoto"]
...... I see. I wish you all the best.
[cpg cn=true]

[OnName num="ryo"]
Wait, why are you crying?
[cpg cn=true]

[FACE method="shock_4" pos="2/5"]
[VOICE f="Mikoto416"]
[OnName num="mikoto"]
"Nothing, nothing!"
[cpg cn=true]

I don't think so, I don't think so, but was that what happened?
[cpg]

I did a bad thing ...... but it doesn't change how I feel.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

And on the way home. On my way home, I was called to Asuka's house.
[cpg]

I pulled my arm back so much that it was hitting my chest.
[cpg]

;//ブラックアウト
;//移植のためシーンをカットしています

In every sense of the word, there is no turning back now.
[cpg]

No, I was in a place where there was no turning back long before that. From the time we started playing pranks.
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

And so we spent a long time together.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（朝）******************************************************

A while later, on a weekday. Everyone knew that Asuka and I had started dating.
[cpg]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Mikoto417"]
[OnName num="mikoto"]
I thought we were a good match.
[cpg cn=true]

[OnName num="ryo"]
"Really?　You were a little shocked.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
Mikoto turned his head. Should I not have said anything?
[cpg]

[FACE method="shake_3" pos="4/5"]
[VOICE f="Asuka285"]
[OnName num="asuka"]
Oh, my God. Ryo, you're so delicately rude.
[cpg cn=true]

[OnName num="ryo"]
Maybe. ...... I'm apparently not related to that kind of thing.
[cpg cn=true]

;//========================================
;//●ＣＧ（主人公に不安そうな表情を向けるヒロイン）ev_35
;//人物１：ヒロイン２
;//服装１：制服
;//場所　：学園教室
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//移植のためシーンをカットしています

...... Then again, Asuka is always cute.
[cpg]

[VOICE f="sAsuka007"]
[OnName num="asuka"]
?　What's wrong, Death?"
[cpg cn=true]

She kind of makes you want to do things you don't want to ......
[cpg]

I think there is something about it that stirs up the desire for indulgence.
[cpg]

[OnName num="ryo"]
;//「いや。なんでもないよ」
No." "No, I just... I just thought Asuka was cute."
[cpg cn=true]

;@===============

[VOICE f="Asuka286"]
[OnName num="asuka"]
'...... are you serious, Des?'
[cpg cn=true]

I said it to make him embarrassed, but he seemed to think I was joking. ......
[cpg]

;@===============

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

;//アスカと一緒に帰る。途中、アスカの家に呼ばれることになった。
On the way home with Asuka, I told her I wanted to do something that was more like a girlfriend.
[cpg]

As a result, I was invited to Asuka's house.
[cpg]


;//========================================
;//●ＣＧ（ベッドに座ってゲームをするヒロイン）ev_34
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//移植のためシーンをカットしています

;@=============

[VOICE f="Asuka287"]
[OnName num="asuka"]
"Ryo is a ...... pushy desu, isn't he?"
[cpg cn=true]

[OnName num="ryo"]
'...... not as much as you say.'
[cpg cn=true]

;@=============

I think I am spending quality time with Asuka today.
[cpg]

But how long will this happiness last?
[cpg]

It's useless to think about it. I can only believe that it will last forever.
[cpg]

For that matter, ...... I wish I hadn't done the prank before I started dating Asuka.
[cpg]

If they pursued that, it might cause a crack in our relationship. I was worried about that.
[cpg]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************

A somewhat sleepless night passed, and morning came.
[cpg]

I thought, "I'll stop by Asuka's house on my way home again today. I was getting ready to go to the school with this thought in my mind.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（朝）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Mikoto418"]
[OnName num="mikoto"]
Is everything going well with Asuka?"
[cpg cn=true]

[OnName num="ryo"]
What's with you, suddenly,......?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto419"]
[OnName num="mikoto"]
'......I hope my fears are unfounded. There has been someone who has been playing a strange prank on me.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Mikoto420"]
[OnName num="mikoto"]
But lately, there hasn't been any. Why is that?
[cpg cn=true]

[OnName num="ryo"]
"It's good if there are no ...... pranks. Besides, what kind of prank?
[cpg cn=true]

Mikoto did not answer. But it is certainly a serious matter.
[cpg]

What if Asuka finds out that the culprit is me?
[cpg]

I thought that no matter how I tried, I wouldn't be able to defend myself.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************



Then, after school. I went home with Asuka.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="sAsuka008"]
[OnName num="asuka"]
I asked her, "Can I hold your hand?"
[cpg cn=true]


...... I'm in a relationship where I never know when a crack will appear. When I think about it, I love the present even more.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ブラックアウト
;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

Friday night I remembered that Asuka and I had agreed to meet tomorrow.
[cpg]

Is this the first time you've brought her up to my house?　First time.
[cpg]

Naturally, a smile breaks out on my face. But I have to make sure I don't make a mess of things here.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

And the next morning. Asuka came over.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Asuka350"]
[OnName num="asuka"]
"I'm sorry to bother you at ......."
[cpg cn=true]

She had a strangely unhappy expression on her face. I wondered what was wrong.
[cpg]

[OnName num="ryo"]
What's wrong, Asuka?
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="sAsuka009"]
[OnName num="asuka"]
I've been quiet until now, but..."
[cpg cn=true]

Aska finally opened her mouth. I mean, about what I've been doing.
[cpg]

I've been pranked by someone in the past, and it's been going away lately.
[cpg]

And that it was a prank that I would do. All of these pranks were within my capabilities.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Asuka352"]
[OnName num="asuka"]
"If I'm wrong, that's okay desu...... but ......."
[cpg cn=true]

My conscience was chafing. Can I just go through with the lie?
[cpg]

...... good, I don't think. No it can't be good.
[cpg]

But I can't admit to it, either.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Asuka353"]
[OnName num="asuka"]
"Why are you so silent?　Did you do this to me?"
[cpg cn=true]

[OnName num="ryo"]
"......That's ......."
[cpg cn=true]

It was as if he had already answered the question.
[cpg]

I don't think they have any hard evidence either. But I'm not so brazen as to deny it.
[cpg]

I admitted it. It was something I had done.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

After that, the relationship became a little awkward.
[cpg]

Asuka said, "I'll forget about it, Desu," but we disagreed on the smallest of things.
[cpg]

[OnName num="ryo"]
"...... can I still hold your hand?　I've done terrible things to you."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Asuka354"]
[OnName num="asuka"]
"Why do you say that Desu,......?　Do you hate me now?"
[cpg cn=true]

It's not true. No, on the contrary. I think she hates me.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

I went back to my room and fell asleep.
[cpg]

I had no face to show to Asuka.
[cpg]

I mean, how could I have ever gone out with Aska?
[cpg]

I feel as if it was a miracle that I had been able to go out with her until now.
[cpg]

I've been playing pranks on her secretly, without being noticed. We just went back to the way we were before.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************

Maybe it's just a common misunderstanding.
[cpg]

But I thought my case was quite special.
[cpg]

Or rather, perhaps it was unique.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Asuka355"]
[OnName num="asuka"]
"......"
[cpg cn=true]

[OnName num="ryo"]
"......"
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『道歩く』

The two of us headed toward the school in silence.
[cpg]

We were so close, but the distance felt distant.
[cpg]

I wonder if we will be separated from each other like this. I don't want to do that.
[cpg]

I still love Asuka. That feeling will never change. ......
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

And then, on the way back home after class.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Asuka356"]
[OnName num="asuka"]
"Ryo. Do you want to make up?
[cpg cn=true]

[OnName num="ryo"]
"I don't know if I can ....... Asuka, you despise me.
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Asuka357"]
[OnName num="asuka"]
I don't think so. I'm sure we can start over even now.
[cpg cn=true]

I wonder if that is so. If Aska says so, it may be so.
[cpg]

But maybe not.
[cpg]

I was afraid of giving her further disappointment.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

On the day off, I was still anxious. We were out on the town.
[cpg]

[OnName num="ryo"]
"Where should we go?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Asuka375"]
[OnName num="asuka"]
"Have you thought of a date plan with ......?　It's not good to leave things to someone else.
[cpg cn=true]

Sure thing. Then let's go where I think we should go.
[cpg]

[OnName num="ryo"]
There's a big bookstore near the station. It has a good selection of comic books, so let's go there."
[cpg cn=true]

Asuka sighed and shook her head.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Asuka376"]
[OnName num="asuka"]
"I'm already a regular there, I know a deeper place than that."
[cpg cn=true]


;//ブラックアウト
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

She then took me to a rather deep bookstore.
[cpg]

I thought it was more for men, but I wondered if Asuka would be okay with that.
[cpg]

Thinking from the opposite perspective, it is quite awkward for a man to mix with a woman in a women's section, but ......
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

After that, Aska browsed and browsed and eventually came out without buying anything.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Asuka377"]
[OnName num="asuka"]
"Whew. I had a good time."
[cpg cn=true]

[OnName num="ryo"]
"That's the best of all......"
[cpg cn=true]

Asuka's smile is pure and innocent. It makes me want to get wet again.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Asuka378"]
[OnName num="asuka"]
Oh yeah, I'm going to take a picture to commemorate the event.
[cpg cn=true]

[OnName num="ryo"]
What memorial? A commemoration for stopping by this bookstore?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
Asuka shakes her head. And then,
[cpg]

[free time=300]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Asuka379"]
[OnName num="asuka"]
"It's the anniversary of our reconciliation.
[cpg cn=true]

;//========================================
;//●ＣＧ（スマホで写真を撮る二人。ヒロインがスマホを持っていて、自分達の方にかざしている。二人笑っている感じ）ev_38
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：街
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_38_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[SE f="se017"]
;//【ＳＥ】『カメラのシャッター音』

So we took a picture.
[cpg]

[OnName num="ryo"]
What are you going to do with a picture like this?
[cpg cn=true]

[VOICE f="Asuka380"]
[OnName num="asuka"]
It's important to commemorate the day. I'll send the data to Ling later.
[cpg cn=true]

[OnName num="ryo"]
Thank you very much. I'll take good care of it."
[cpg cn=true]

[VOICE f="Asuka381"]
[OnName num="asuka"]
Don't use ...... for anything strange.
[cpg cn=true]

;//まだ引きずるか。それはもういいだろ……
What is that? Is it a copy of some anime?
[cpg]

;//と思いつつも、ギャグにしてくれるんなら多少心が落ち着く。
I was thinking, "What's that?" But a picture of me with a girl I like is comforting.
[cpg]

;//ただただ黙って、忘れられないというよりはずっとましだ。
;//[cpg]

[VOICE f="Asuka382"]
[OnName num="asuka"]
"Ryo, I'll always be with you. I'll always be with you.
[cpg cn=true]

[OnName num="ryo"]
Ah, we'll always be together. We will always be together.
[cpg cn=true]


;//ブラックアウト
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I am sure that nothing will be able to tear us apart from now on.
[cpg]

;//ＥＮＤ：ヒロイン２ルート２「合意」

[SCENE id=13]

[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
