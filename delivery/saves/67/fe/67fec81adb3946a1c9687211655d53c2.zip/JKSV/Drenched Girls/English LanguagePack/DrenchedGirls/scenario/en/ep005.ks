
;//==============================
;//１、みこと
*select06_1|I want to play a prank on Mikoto

[if exp={getFlagValue("flg_goui") == 2 }]
[jump storage="ep006.ks" target="*root1_2"]
[jump target="*root1_2"]
[endif]

[jump target="*root1_1"]

;//==============================
;//「こっそり」ルートの場合

*start|I want to play a prank on Mikoto

;#################################################
*Ep005|I want to play a prank on Mikoto
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************

*root1_1|I want to play a prank on Mikoto

[SCENE id=5]

...... It's Mikoto. I'm not looking to become a lover anytime soon.
[cpg]

I just want to be able to do it secretly. There is no need to change the way we have been doing things like pranks.
[cpg]

;//彼女の場合、睡眠薬を使って近づくというのをあまりしてないよな。
In her case, she hasn't been able to do the wetting while she's asleep, has she?
[cpg]

I have attempted it with Yukiho, but Mikoto wouldn't be able to do it with me.
[cpg]

Thinking this, I decided to go back to my house.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

I felt as if the fog in front of my eyes had lifted by clarifying my target.
[cpg]

I love Mikoto the most. I love Mikoto more than Asuka or Yukiho.
[cpg]

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=3000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************

[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Asuka095"]
[OnName num="asuka"]
You look like you're up to something.
[cpg cn=true]

[OnName num="ryo"]
I'm not on .......
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Asuka096"]
[OnName num="asuka"]
No?　You look like an evil criminal.
[cpg cn=true]

[OnName num="ryo"]
Asuka, do you know what a scoundrel is?
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Asuka097"]
[OnName num="asuka"]
"Echigoya ...... death?"
[cpg cn=true]

If you think about it, it doesn't fit. It can't be the same person.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（朝）******************************************************

[FACE method="bow_1" pos="2/5"]
[VOICE f="Mikoto115"]
[OnName num="mikoto"]
Good morning, you two. Both of you.
[cpg cn=true]

[OnName num="ryo"]
Good morning. Can I have some time after school today?"
[cpg cn=true]

I asked Mikoto. Mikoto said yes.
[cpg]

[FACE method="bow_7" pos="2/5"]
[VOICE f="Mikoto116"]
[OnName num="mikoto"]
Mikoto replied, "Yes, that's fine. What do you want?　Please don't tell me you're going to confess again.
[cpg cn=true]

[OnName num="ryo"]
I won't do that. I'm not the same person I was before.
[cpg cn=true]

[FACE method="bow_2" pos="4/5"]
[VOICE f="Asuka098"]
[OnName num="asuka"]
I'm not the same person I was before. I was confessing whenever I had a chance.
[cpg cn=true]

I don't think you're a bad listener,....... It's totally true.
[cpg]

;//ブラックアウト
;//========================================
;//●ＣＧ（授業を受けているヒロイン）ev_17
;//人物１：ヒロイン１
;//服装１：制服
;//場所　：学園教室
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

After making the appointment, I'm in class.
[cpg]

She's cute today too. I can say that just looking at her profile is fine.
[cpg]

But as someone who ...... once started a prank, it's not enough.
[cpg]

I want to see a different side of her.
[cpg]

I was even willing to go out with them if it would make it possible.
[cpg]


;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

Then I called Mikoto and we talked.
[cpg]

[OnName num="ryo"]
I called Mikoto and we talked. Is there anything strange going on with you?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto132"]
[OnName num="mikoto"]
I don't know if you can call it anything strange, but Mikoto's attitude toward ...... Ryo is just a little strange.
[cpg cn=true]

[OnName num="ryo"]
Don't say that. I'm just trying to get to know you."
[cpg cn=true]

;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

From there, we continued to talk about nothing else.
[cpg]

Mikoto began to doze off, perhaps because she was tired from her normal student life, or perhaps because I was boring her to talk to.
[cpg]

;//========================================
;//●ＣＧエロ（眠っているヒロインの顔にむかってしごく主人公。途中で目を開け、口を開くヒロイン。最後は口の中にかける）ev_13
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_13_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

...... now, you can do anything you want.
[cpg]

For example, not only can you make them wet and see through, but you might be able to take pictures of them.
[cpg]

[VOICE f="sMikoto007"]
[OnName num="mikoto"]
Soooo, soooo ......."
[cpg cn=true]


I'm getting a little sick of myself for even thinking about it.
[cpg]

Am I really going to stay like this?
[cpg]

;@=================

Even though I was thinking this, my feet went to fetch water to fulfill my desire.
[cpg]

;@=================

;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


And when I return, she is awake.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sMikoto008"]
[OnName num="mikoto"]
......"
[cpg cn=true]


Mikoto looks as if she has guessed everything. I was speechless.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sMikoto009"]
[OnName num="mikoto"]
The truth is, I was aware of it. I had overlooked it because it was you.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="sMikoto010"]
[OnName num="mikoto"]
But I've been holding back for a long time.
[cpg cn=true]


[OnName num="ryo"]
How could you forgive me for doing this? Besides, it was only because it was you. ......
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="sMikoto011"]
[OnName num="mikoto"]
"What reason would you give me?"
[cpg cn=true]

[OnName num="ryo"]
Let me ...... hear it. You're the one who ...... me.
[cpg cn=true]

No. I'm not allowed to say anything from here on out.
[cpg]

I mean, do you like me or not? I felt like this would be the end of it.
[cpg]

I'm not trying to be your girlfriend. It was a prank, so part of it was fun.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Mikoto150"]
[OnName num="mikoto"]
'What is it ......?'
[cpg cn=true]

[OnName num="ryo"]
No, it's nothing. ...... Never mind."
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

One day, Mikoto invited me to go to her house.
[cpg]

On the way, I called my parents. I was supposed to be at a friend's house.
[cpg]

...... I don't have any male friends. My parents must have found out by now.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mikoto151"]
[OnName num="mikoto"]
They'll say, "...... here. My house."
[cpg cn=true]

The front door was marked "Nishigawara". I was to go up to her room.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************

It was a neat and tidy room. I was impressed by the neatly arranged books.
[cpg]

I was wondering if it would be like this if I became the class chairman when ......
[cpg]

[SE f="se029"]
;//【ＳＥ】『衣擦れ』

[free time=300]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

[OnName num="ryo"]
I was thinking, "Wait a minute, Mikoto!　It's close."
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="sMikoto012"]
[OnName num="mikoto"]
Why ...... didn't you want to do something like this?
[cpg cn=true]

It's funny. I can't believe how quickly we've grown apart.
[cpg]

Perhaps I should have asked the question earlier?
[cpg]

In other words, do you like me or not? Maybe Mikoto likes me. ......
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト

[free time=300]
[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sMikoto013"]
[OnName num="mikoto"]
I'm always waiting for you.
[cpg cn=true]

I can't stand what Mikoto is saying to me.
[cpg]

I'm half-hearted to no end. He's almost confessing to me.
[cpg]

I couldn't nod my head to that. It was a strange feeling, as if that was frustrating, as if this was the right thing to do.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夜）******************************************************

The sun was setting as I walked with this feeling of helplessness in my heart.
[cpg]

What do I want to do with Mikoto? I needed to think about it a little more.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア閉まる』

;//ブラックアウト
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


When I returned home a little late, my mother was cold to me.
[cpg]

I don't have any boyfriends. She asked me who I went to, but I was adamant and didn't answer.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I'm in no mood to think of this as love, though I'm not in the ...... mood to be in love.
[cpg]

But that doesn't mean I don't have any expectations.
[cpg]

I had some expectations for the future, but there was still something bothering me.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

It was a little difficult to sleep that night.
[cpg]

I wonder if I will have a date with Mikoto someday.
[cpg]

I don't really want that. But Mikoto might.
[cpg]

How should I react then?
[cpg]

Should I give Mikoto what she wants?　Or should I go to ......
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（朝）******************************************************

[FACE method="shake_7" pos="2/3"]
[VOICE f="Yukiho076"]
[OnName num="yukiho"]
"It's ...... dark, Ryo-kun.
[cpg cn=true]

[OnName num="ryo"]
Is it so ......?"
[cpg cn=true]

Well, it would be dark. I have to admit that I was usually a brainiac.
[cpg]

I've been thinking out of character. I know that much.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Yukiho077"]
[OnName num="yukiho"]
I'll take you up on your relationship advice. Have you been with someone yet?
[cpg cn=true]

You are very perceptive, Yukiho. That's almost right.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（朝）******************************************************

[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]

As I approached the school, Asuka followed close behind.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Asuka099"]
[OnName num="asuka"]
"...... dark desu?　Ryo.
[cpg cn=true]

[OnName num="ryo"]
"No, you didn't. Even you say so."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Asuka100"]
[OnName num="asuka"]
"Did someone tell you that even you?
[cpg cn=true]

[OnName num="ryo"]
"Yes, I was told. I think everyone will probably say so.
[cpg cn=true]

I am not really in the mood to be depressed.
[cpg]

I have confessed my feelings to countless people. No matter how many times I've been rejected, I've never been so depressed.
[cpg]

In fact, my love is about to come true, so why should I be depressed?
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]

[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************


And after school,......, Mikoto asked me to go home again today.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto171"]
[OnName num="mikoto"]
I was so excited to see her."......Why do you have such a gloomy look on your face?"
[cpg cn=true]

Even Mikoto told me. How many more have I heard of this?
[cpg]

[OnName num="ryo"]
I'm trying not to look so gloomy in front of you. I know you understand.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Mikoto172"]
[OnName num="mikoto"]
I do understand. We've known each other for a while.
[cpg cn=true]

That's right. The actuality that you can't get a lot of these types of things, you'll be able to't get a lot of these types of things.
[cpg]

I've confessed to Mikoto many times, right? How did that one get passed over?
[cpg]

I think it's because I was ...... doing it to anyone and everyone. I can't think of anything else.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

So you are saying that if I had been less aggressive and confessed only once, we might have gone out.
[cpg]

Actually, that wasn't the case. I had confessed my feelings to everyone, so I didn't go through with Mikoto.
[cpg]

But in reality, I can only interpret it as a favor and .......
[cpg]

No girl would be happy to be pranked by someone she doesn't like. On the other hand, if I thought he was doing me a favor, it all made sense.
[cpg]

I had a complicated feeling. I was having fun because I was playing a prank on her in secret.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Mikoto173"]
[OnName num="mikoto"]
"You can stay over tonight if you want.
[cpg cn=true]

[OnName num="ryo"]
"......, it's not a good idea. What would your parents think?"
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Mikoto174"]
[OnName num="mikoto"]
'My parents aren't that strict. I'll be fine.
[cpg cn=true]

[OnName num="ryo"]
I don't care what you say, but I have my own reasons.
[cpg cn=true]

;//移植のためシーンをカットしています

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto193"]
[OnName num="mikoto"]
Why don't you just have dinner with us ......?　We're not just friends anymore, are we?
[cpg cn=true]

If they are not just friends, then what?
[cpg]

I didn't pursue it. I was afraid to pursue it.
[cpg]

If this was a girlfriend, I had gotten off on the wrong foot.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夜）******************************************************

Again, a similar view. I was walking at a leisurely pace when the sun was setting.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Yukiho078"]
[OnName num="yukiho"]
Oh, Ryo-kun. You're quite late today, aren't you?
[cpg cn=true]

[OnName num="ryo"]
"......"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Yukiho079"]
[OnName num="yukiho"]
"...... Ryo-kun?　Ryo-kun?
[cpg cn=true]

I couldn't keep myself from responding to Yukiho.
[cpg]

I made a terrible mistake. I couldn't help but feel like I had made a terrible mistake.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************

The next morning. I headed to the school. It was a little hard for me to go on as usual.
[cpg]

If I go to the school, Mikoto will be there. Probably, she must have a look of expectation for the future.
[cpg]

It is hard for me to see her face. I don't want to be a lover with Mikoto.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Asuka101"]
[OnName num="asuka"]
Really, what's wrong desu ......?　It's not like Ling.
[cpg cn=true]

[OnName num="ryo"]
What is it, ......?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Asuka102"]
[OnName num="asuka"]
Don't you realize it?　If so, you're in serious trouble.
[cpg cn=true]

I'm aware of it. I'm in an abnormal situation, I know that much.
[cpg]

What if Mikoto formally confesses to me now?
[cpg]

I don't have an answer. I don't know how to respond.
[cpg]

I was so anxious and hopeful that I couldn't help it.
[cpg]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Asuka103"]
[OnName num="asuka"]
I was helpless to do anything about it!　Are you even listening to me?
[cpg cn=true]

[OnName num="ryo"]
"Oh, I'm sorry, ...... what was that?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Asuka104"]
[OnName num="asuka"]
I don't say sorry!　It's not the Ryo I know, it's the one I'm ...... sorry.
[cpg cn=true]

[OnName num="ryo"]
I'm sorry ......
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

And then, in the classroom during lunch break.
[cpg]

Aska is having lunch while talking with another friend.
[cpg]

It's not just me and Mikoto, but ...... face to face and have a meal.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sMikoto014"]
[OnName num="mikoto"]
......"
[cpg cn=true]


We don't have much conversation. I thought it was going to be the way I wanted it to go.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************


[VOICE f="Asuka107"]
[OnName num="asuka"]
I was sure this was the way I wanted things to go.　Why not?
[cpg cn=true]

[OnName num="ryo"]
I've got some business with Mikoto.
[cpg cn=true]

There's no need to hide it anymore. I'll just tell Asuka.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Asuka108"]
[OnName num="asuka"]
Well,......, that's a good thing.
[cpg cn=true]

[OnName num="ryo"]
I'm just an old lady. Auntie?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Asuka109"]
[OnName num="asuka"]
But it's not right. That doesn't explain why Lung is so dark.
[cpg cn=true]

[OnName num="ryo"]
Never mind. Asuka, go home first.
[cpg cn=true]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]

After such an exchange, I was alone with Mikoto.
[cpg]

[OnName num="ryo"]
"...... Mikoto."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sMikoto015"]
[OnName num="mikoto"]
What is it?
[cpg cn=true]

I have a feeling she's waiting for me to say something. Then I approached her.
[cpg]

;//@
[OnName num="ryo"]
I have something important to tell you. ......
[cpg cn=true]

[SE f="se031"]
;//【ＳＥ】『衝撃音』

;//========================================
;//●ＣＧエロ（※※※01.bmpのシーンです※※※）ev_16
;//人物１：ヒロイン１
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：学園教室
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//@
I was so nervous that my legs got tangled up and I fell toward Mikoto.
[cpg]

;//@
;//みことが姿勢を崩して、おかしな格好になる。
Both Mikoto and I lose our posture and get into funny outfits.
[cpg]

;//@
;//ここまで来て、何も言わないわけにはいかない。
I was not ...... dressed well, but I couldn't just come up here and not say anything.
[cpg]

;//移植のためシーンをカットしています

[OnName num="ryo"]
I've got something important to tell you. Can I?"
[cpg cn=true]

[VOICE f="Mikoto213"]
[OnName num="mikoto"]
......Yes."
[cpg cn=true]

I started to speak up, letting the momentum carry me away.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

[OnName num="ryo"]
I don't think it's right. It was a prank, and it was fun."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sMikoto016"]
[OnName num="mikoto"]
'Well, ...... what are you talking about?"
[cpg cn=true]

[OnName num="ryo"]
I don't want to be your girlfriend.
[cpg cn=true]

[OnName num="ryo"]
I'm just happy ...... that Mikoto didn't notice anything and was in a state of mischief."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Mikoto215"]
[OnName num="mikoto"]
"Even ...... such a ...... relationship is good, isn't it?"
[cpg cn=true]

I didn't say it was good. I thought it was something I'd rather refuse to do.
[cpg]

[OnName num="ryo"]
I can't. I can't be in a relationship with you if I can't reciprocate your love. We can't be together as long as I can't reciprocate Mikoto's love."
[cpg cn=true]

It was almost at the same time that I said that. Mikoto got up from his chair.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Mikoto216"]
[OnName num="mikoto"]
"......That's exactly what's impossible. What should I do about my feelings?"
[cpg cn=true]

[OnName num="ryo"]
I'm sorry, I shouldn't have done anything I shouldn't have done, right?
[cpg cn=true]

I feel guilty. I feel sorry when I see Mikoto start to cry.
[cpg]

But there was nothing I could do about it.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Mikoto217"]
[OnName num="mikoto"]
I can't help it. "Well, ...... then, why don't you just play the same prank on me again?"
[cpg cn=true]

[OnName num="ryo"]
'A prank you're aware of isn't really a prank, is it?
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Mikoto218"]
[OnName num="mikoto"]
I'm fine with that. I don't want this to be the end of my relationship with Ryo.
[cpg cn=true]

I'm sure that if I accept these words, Mikoto and I will no longer be lovers. ......
[cpg]

It's not a good idea to be a stranger. It may be a good compromise.
[cpg]

But is this the right thing to do?
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

And then, we will be...
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************

[OnName num="ryo"]
Good morning, Mikoto. ......
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mikoto219"]
[OnName num="mikoto"]
Good morning. You have a sleeping habit.
[cpg cn=true]

[OnName num="ryo"]
Really?　Where are you?
[cpg cn=true]

In this way, we had a relationship in which we continued to prank each other with conversations that were neither lovers nor mere friends.
[cpg]


;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

Thus, our relationship continued. A relationship that was neither lover nor friend. ......
[cpg]


;//ＥＮＤ：ヒロイン１ルート１

[SCENE id=10]

[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
