
*start|The Beginning of Discomfort

;#################################################
*Ep002|The Beginning of Discomfort
;#################################################

[SCENE id=2]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

And then morning comes.
[cpg]

All today I wished the morning would never come.
[cpg]

I don't know what to say to Mikoto. Or rather, what should I talk about?
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（朝）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Asuka021"]
[OnName num="asuka"]
I don't know what to say to him. What's wrong with you?　Are you sleepy?
[cpg cn=true]

[OnName num="ryo"]
No, I'm not sleepy. ......
[cpg cn=true]

I wonder if my eyes were half open. It's okay.
[cpg]

It's okay, I can have that look on my face. I'm nervous inside. I wondered when I would meet Mikoto ......
[cpg]

I was wondering when I would meet Mikoto, when I saw his back on the way to school.
[cpg]

I wondered if I should talk to him. While I was hesitating, Asuka spoke to him.
[cpg]

[free time=300]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Asuka022"]
[OnName num="asuka"]
"Mikoto, good morning,"
[cpg cn=true]

[VOICE f="Mikoto038"]
[OnName num="mikoto"]
Good morning, and good morning to you too, Ryou.
[cpg cn=true]

[OnName num="ryo"]
Ah, ah, .......
[cpg cn=true]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Mikoto039"]
[OnName num="mikoto"]
"......, what's wrong?　Are you sleepy?"
[cpg cn=true]

He says the same thing as Asuka. But this reaction is ......
[cpg]

[OnName num="ryo"]
"Well, you know... Has anything changed with Mikoto since then?
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[VOICE f="Mikoto040"]
[OnName num="mikoto"]
"What's changed ......?　What are you talking about?
[cpg cn=true]

;//ちょっと突っ込んで聞きすぎたかな。これじゃ、俺が犯人だと名乗ってるようなものか。
I guess I asked a little too penetratingly. This is like saying I was going to do something.
[cpg]

[FACE method="shake_2" pos="2/5"]
[VOICE f="Mikoto041"]
[OnName num="mikoto"]
"Oh, about how sleepy you looked yesterday?　Then don't worry about it.
[cpg cn=true]

[OnName num="ryo"]
Oh, okay. That's all right then."
[cpg cn=true]

If this is how he feels, he doesn't even know I was trying to do it. Besides, I wouldn't have told anyone about it.
[cpg]

It's only natural. It was an attempt.
[cpg]

But that fact ignited my desire.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（朝）******************************************************


What? They didn't know. As Mikoto, Asuka, and I walked together, my anxiety turned to relief and confidence.
[cpg]

My mind started to expand. Various ways of wet pranks.
[cpg]

I wondered if I could use what I did yesterday in a variety of ways.
[cpg]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Mikoto042"]
[OnName num="mikoto"]
"...... what's wrong?　Ryo, something is wrong."
[cpg cn=true]

[OnName num="ryo"]
"No, it's not that. It's all right.
[cpg cn=true]

I have become so relieved that I can reply, "I'm not relieved. Rather than feeling relieved, I am now in a state of mind that is closer to pride.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************

I am taking classes with Mikoto and Asuka.
[cpg]

Various imaginations are expanding. For example, how about sneaking into the locker room during gym class and getting your clothes wet?
[cpg]

Or, maybe I should bring along a small water pistol or something.
[cpg]

Then, I could spray them with it at any moment. Then they might not notice.
[cpg]

My imagination is growing. A plan to get the girl wet, so to speak.
[cpg]

I really think I must be a terrible villain. I should have regretted it so much at one time.
[cpg]

[OnName num="ryo"]
"Hmmm, hmmm... ......"
[cpg cn=true]

[OnName num="male_student_A"]
Hey, that Shirai guy, are you okay?"
[cpg cn=true]

[OnName num="male_student_B"]
I'm sure he's thinking about a girl anyway. Leave him alone.
[cpg cn=true]

Yes, he is. He is thinking about women. But he's in a different, more advanced place than before.
[cpg]

Now, who should I start with? I'm considering Asuka, but ......
[cpg]

I'm afraid of all kinds of things if it's not someone I've already done well with once.
[cpg]

So, I decided to focus on Mikoto.
[cpg]

;//========================================
;//●ＣＧ（昼休み、読書をするヒロイン）ev_06
;//人物１：ヒロイン１
;//服装１：制服
;//場所　：学園教室
;//時間　：昼
;//========================================
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;**【ＣＧ】 ev_06_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[OnName num="ryo"]
"Hey, Mikoto.
[cpg cn=true]

[VOICE f="sMikoto003"]
[OnName num="mikoto"]
What is it?"
[cpg cn=true]

He didn't look back at me. I assumed he was absorbed in reading.
[cpg]

For example, what can I do now ......?
[cpg]

As expected, you can't do anything while you're awake, can you?
[cpg]

[OnName num="ryo"]
I'll just wait for a few more chances.
[cpg cn=true]

I'll wait for a few more chances.
[cpg]

;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

The next day. It was around lunchtime. Even though I could narrow down the target, I couldn't immediately think of what to do.
[cpg]

I had so many ideas that I didn't know which one was the best.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Asuka023"]
[OnName num="asuka"]
"You seem to be in a better mood this time.
[cpg cn=true]

[OnName num="ryo"]
"A complete change, huh? You know some difficult Japanese.
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Asuka024"]
[OnName num="asuka"]
"Hehe. I've learned it.
[cpg cn=true]

Seeing her childish smile, I felt like getting her wet.
[cpg]

I want to distort that expression. But why would I do it?
[cpg]


;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Mikoto046"]
[OnName num="mikoto"]
"...... something looks fun, Ryo."
[cpg cn=true]

[OnName num="ryo"]
No?　What do you think is fun?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Mikoto047"]
[OnName num="mikoto"]
'Is it my imagination? It looks like you're up to something devious."
[cpg cn=true]

[OnName num="ryo"]
"That's outrageous. ...... You have no basis for it."
[cpg cn=true]

But I'm somewhat impatient because I think he's on the outside, saying, "Well, it's okay.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Mikoto048"]
[OnName num="mikoto"]
Well, that's okay. It wouldn't be a big deal anyway."
[cpg cn=true]

It's a pretty big deal. They didn't see that far.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Mikoto049"]
[OnName num="mikoto"]
So what are you up to?　What are you up to?
[cpg cn=true]

[OnName num="ryo"]
"It's not a big deal, is it?　So what's the big deal?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sMikoto004"]
[OnName num="mikoto"]
I'm curious. I'm just curious.
[cpg cn=true]


...... means you haven't noticed anything, right?
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

On the way home. I left Mikoto and met Yukiho.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Yukiho015"]
[OnName num="yukiho"]
Ryo-kun. Good evening.
[cpg cn=true]

[OnName num="ryo"]
"Oh, good evening. ...... You seem to be bored."
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Yukiho016"]
[OnName num="yukiho"]
I'm not bored. I'm studying a lot of things.
[cpg cn=true]

You said that before. I wonder what he is studying.
[cpg]

[OnName num="ryo"]
What are you studying?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Yukiho017"]
[OnName num="yukiho"]
I'm thinking of converting this apartment into a condominium.
[cpg cn=true]

Ah, that kind of thing. Well, you can't do that with half knowledge.
[cpg]

If you are not good at it, you will lose a lot of money, so of course you will study.
[cpg]

[OnName num="ryo"]
By the way, about going out with me..."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Yukiho018"]
[OnName num="yukiho"]
"Hmm. You keep asking me, do you like me that much?
[cpg cn=true]

[OnName num="ryo"]
Yes, I like you. Yes, I love you.
[cpg cn=true]

Words around here come out without hesitation. I'm a womanizer.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Yukiho019"]
[OnName num="yukiho"]
I'm a womanizer. Shall I invite you to my room specially?
[cpg cn=true]

[OnName num="ryo"]
"Oh, ......."
[cpg cn=true]

Oh, my God. This was an unexpected opportunity.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Yukiho's room was simple but tidy.
[cpg]

She must be meticulous. There was a cute piggy bank in her room.
[cpg]

[OnName num="ryo"]
It would take a lot of courage to break it open, wouldn't it?
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Yukiho020"]
[OnName num="yukiho"]
Yes. Yes, that's why it's a perfect piggy bank.
[cpg cn=true]

The conversation we had there was of a trivial nature. I think Yukiho took it as "advice on love.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Yukiho021"]
[OnName num="yukiho"]
Ryo-kun likes all kinds of people, doesn't he? You are so cute.
[cpg cn=true]

[OnName num="ryo"]
"I don't think he's that cute.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Yukiho022"]
[OnName num="yukiho"]
It's cute. You can only be cute while you're still young.
[cpg cn=true]

I wondered if that's how it was. I left when it was time to go home.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『道歩く』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************

[OnName num="ryo"]
I was so happy to see him. Mikoto.
[cpg cn=true]

I waved to Asuka and Mikoto, who had joined us earlier.
[cpg]

[FACE method="bow_1" pos="2/5"]
[VOICE f="Mikoto052"]
[OnName num="mikoto"]
I waved to Asuka and Mikoto, who had joined us earlier. Asuka.
[cpg cn=true]

[FACE method="bow_1" pos="4/5"]
[VOICE f="Asuka032"]
[OnName num="asuka"]
Good morning, Mikoto. Mikoto, how's your lack of sleep?
[cpg cn=true]

Come to think of it, there was a story about that. I wonder what happened to it.
[cpg]

[FACE method="shake_2" pos="2/5"]
[VOICE f="Mikoto053"]
[OnName num="mikoto"]
I've been trying not to doze off since then, so there's nothing to worry about.
[cpg cn=true]

;//そうだろうな。あんなことあったら、居眠りなんてとてもできなくなるだろう。
I'm sure that's true. I'm sure Mikoto, who is such a serious person, will take measures to avoid dozing off.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]

Then I decided to do a prank I had been wanting to do for a long time.
[cpg]

In short, it was like putting a blackboard eraser in the door.
[cpg]

I kept a small plastic bucket filled with water ......
[cpg]

and put it into words, it's too vicious ...... but my desire is unstoppable.
[cpg]

I read what Mikoto was going to do and I did it.
[cpg]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

I was so excited that I didn't want to go back to the classroom.
[cpg]

I thought I had gone too far, but I felt a strange sense of fulfillment.
[cpg]

I wondered if she was around the infirmary right now.　Okay, I'll go check on him.
[cpg]


;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_08_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園保健室』（昼）

During recess, I went to the infirmary where Mikoto was.
[cpg]

[OnName num="ryo"]
"Mikoto, are you all right? Are you all right?
[cpg cn=true]

[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mikoto055"]
[OnName num="mikoto"]
"Oh ...... Ryo. I'm fine, I'm fine. ......
[cpg cn=true]

Mikoto was quite downcast. She looked like she was at the end of the world.
[cpg]

It was unmistakably me who made her look that way. I felt a delicate feeling of both happiness and pain.
[cpg]

[OnName num="ryo"]
I think it's good that you don't have to force yourself to go to class. You don't have to force yourself to go to class, you're usually an honor student."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Mikoto056"]
[OnName num="mikoto"]
'I will. It's okay, really. ......"
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

Then class went on and it was lunchtime.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Asuka034"]
[OnName num="asuka"]
Mikoto, what's going on?　I don't know much.
[cpg cn=true]

[OnName num="ryo"]
I don't know much about it either. Why don't you ask someone?
[cpg cn=true]

[OnName num="ryo"]
Or maybe you should ask him.
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Asuka035"]
[OnName num="asuka"]
I can't be that insensitive, Desu .......
[cpg cn=true]

I'm sure you're right. Asuka is not a person who is incapable of caring.
[cpg]

[OnName num="ryo"]
I'm just curious. Asuka watches anime, right?　What kind of things do you watch?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Asuka036"]
[OnName num="asuka"]
What kind of anime do you watch?　It's, you know, robot stuff. ......?　I wonder if it's Death.
[cpg cn=true]

I see. I feel like I'm here to be left behind or something.
[cpg]

I would have been satisfied if they had told me about a female-oriented animation here.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

And in the evening. In the end, it took about half a day for Mikoto to get back to work.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Mikoto057"]
[OnName num="mikoto"]
"......, I'm sorry I made you worry. I'm fine now."
[cpg cn=true]

[OnName num="ryo"]
You mean you weren't fine until now?
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Mikoto058"]
[OnName num="mikoto"]
That's, well. I'm sure you were. I don't know who ...... did that to you after what happened.
[cpg cn=true]

Mikoto says he doesn't know who did it. If it was me, I'd have a good idea who it was.
[cpg]

[OnName num="ryo"]
Well, don't take it too hard."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Mikoto059"]
[OnName num="mikoto"]
I will do so even if Ryo doesn't tell me to."
[cpg cn=true]

Mikoto seems to be a little out of her usual groove.
[cpg]

It's hard to say what's wrong, but it's something.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（夕方）******************************************************

[FACE method="change_4" pos="2/3"]
[VOICE f="sMikoto005"]
[OnName num="mikoto"]
"Don't you know anything about it?　About the murderer?"
[cpg cn=true]

[OnName num="ryo"]
No?　What are you talking about?
[cpg cn=true]

[FACE method="shake_5" pos="2/3"]
[VOICE f="Mikoto061"]
[OnName num="mikoto"]
'...... that's right, nothing.'
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

Mikoto looks awkward. But I can't do anything to help him.
[cpg]

Because the culprit is me. It's natural.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mikoto062"]
[OnName num="mikoto"]
I'll leave it here then. Bye.
[cpg cn=true]

[OnName num="ryo"]
"Oh, well, I'll see you tomorrow."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto063"]
[OnName num="mikoto"]
Tomorrow is a holiday. See you Monday.
[cpg cn=true]

Oh, that's right. I was so excited that I had lost track of the days of the week.
[cpg]

[free time=1000]
[SE f="se001"]
;//【ＳＥ】『歩く』
[WAIT time=1000]

[OnName num="ryo"]
"Well, and ......."
[cpg cn=true]

The next target would be Ms.Yukiho.
[cpg]

I didn't run into her today, but I'll head to her apartment tomorrow.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[OnName num="ryo"]
"...... hmmm."
[cpg cn=true]

I wonder what I'll do to her. There are some things you can do because it's one-on-one, but there are some things you can't.
[cpg]



[jump storage="ep003.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
