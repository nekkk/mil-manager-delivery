
*start|Maybe they can see right through us.

;#################################################
*Ep003|Maybe he sees through my true feelings.
;#################################################

[SCENE id=3]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

The next morning. I was on my way to Yukiho's place.
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（朝）******************************************************

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

On my way to the apartment, I met Yukiho.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sYukiho001"]
[OnName num="yukiho"]
"Ah, Ryo-kun. Good morning."
[cpg cn=true]


However, the prank was not finished in my mind. I was not confident that I could do it without being discovered.
[cpg]

In the end, I couldn't say anything that day.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（昼）******************************************************

Since nothing seemed to come of it that day, we decided to go out for fun.
[cpg]

I'm not a man of hobbies, but I don't mind wandering around town at random.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

I went out to the city. After cruising through bookstores, game stores, and various other places, I met Asuka.
[cpg]

She came out of a pretty core otaku store. I was surprised.
[cpg]

[FACE method="shake_5" pos="2/3"]
[VOICE f="Asuka037"]
[OnName num="asuka"]
"Oh ......, this is Death. ...... No, I mean..."
[cpg cn=true]

[OnName num="ryo"]
What's the matter, you're acting suspiciously. Did you buy something you're not supposed to?
[cpg cn=true]

I looked inside the bag I bought. But there was nothing in particular, just a figure.
[cpg]

[OnName num="ryo"]
"...... It's just a figure, isn't it? Why are you trying to hide it?"
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Asuka038"]
[OnName num="asuka"]
Because in the U.S., they don't sell ...... things like this.
[cpg cn=true]

[OnName num="ryo"]
Are you ashamed?
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Asuka039"]
[OnName num="asuka"]
"Hai. I'm a little bit.
[cpg cn=true]

I feel like a child. But maybe that's just the way otaku culture is in Japan.
[cpg]

[OnName num="ryo"]
You know, dressing up as a costume for Halloween is also strange in other countries, right?
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Asuka040"]
[OnName num="asuka"]
Yes, because it's something children do.
[cpg cn=true]

They say that overseas is a culture of sin and Japan is a culture of shame, but ...... it seems to me that the opposite is true.
[cpg]

Is it because Aska and I are a little bit dyed-in-the-wool underground? Oh well.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Asuka041"]
[OnName num="asuka"]
Well then, ...... see you tomorrow.
[cpg cn=true]

[OnName num="ryo"]
Tomorrow is Sunday.
[cpg cn=true]

I say something like I've heard someone else say. Asuka blushed and waved her hand.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

After that, we hung around for a while. I sometimes go to the arcade, but I don't spend a lot of money.
[cpg]

I'm good at UFO catcher, but it's a dangerous thing, a piggy bank.
[cpg]

It starts with choosing a machine that I think I can get as much as possible, and by extension, a store. ......
[cpg]

I knew that Asuka and I were both geeks, I thought.
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

Then I went back to my room and planned my next plan.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************

[FACE method="change_2" pos="2/3"]
[VOICE f="Yukiho026"]
[OnName num="yukiho"]
'We've met again. I wonder if Ryo-kun is coming to see me.
[cpg cn=true]

[OnName num="ryo"]
'Something like that. Please go out with me, Yukiho-san.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Yukiho027"]
[OnName num="yukiho"]
I'll listen to your advice on love. I'll listen to your advice on love.
[cpg cn=true]

What the heck, it's going to be a piece of cake. I decided to ask him to take me to his room.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yukiho028"]
[OnName num="yukiho"]
I asked her to take me up to her room.
[cpg cn=true]

He prepared a cup of tea for me.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sYukiho002"]
[OnName num="yukiho"]
It's a beautiful day, isn't it? It's making me sleepy.
[cpg cn=true]


She said something like that, so I suggested, "Why don't you take a nap?
[cpg]

[OnName num="ryo"]
"Would you like to take a nap?"
[cpg cn=true]


It was too forced a strategy, but she nodded.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sYukiho003"]
[OnName num="yukiho"]
She nodded. I'll do that.
[cpg cn=true]

;//========================================
;//●ＣＧ（うとうとするヒロイン）ev_07
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="Yukiho051"]
[OnName num="yukiho"]
"Soooo, soooo ...... mmmm."
[cpg cn=true]

Somehow I ...... thought she knew what I was going to do.
[cpg]

I've always liked soggy girls, and maybe she's figured out that I like soggy girls.
[cpg]

Maybe she knows that and is pretending to sleep with me.
[cpg]

I couldn't take any action because I was thinking that much.
[cpg]

;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（昼）******************************************************

In the end, I ended the meeting without taking any action.
[cpg]

It was noon. I should go home soon, I didn't say I would be out for too long.
[cpg]

With that in mind, I headed home. When I get back home, I'll have another one-man strategy meeting. ......
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]

I ate lunch in the dining room of the house. While eating, I think about a lot of things.
[cpg]

My parents were worried about me because I seemed to have been quiet during that time.
[cpg]

[free time=1000]
[WAIT time=1000]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************

I was not worried. I am enjoying my youth.
[cpg]

It's a complicated youth, but it's also a form of youth.
[cpg]

Next time, I might target Asuka again.
[cpg]

Then, I had an idea. It's high risk, but it's worth a try.
[cpg]

I started preparing for it.
[cpg]

While I was preparing, I couldn't help but imagine what it would be like, and my desire for it increased.
[cpg]

And then I thought to myself.
[cpg]

;//■選択肢
[switch]
[case "I'll put up with a minor prank."]
	[swap]
	[jump target="*select03_1"]
[case "I want to force myself to perform it."]
	[swap]
	[jump target="*select03_2"]
[endswitch]

One, I'll put up with it as a minor prank.
2. I want to do it, even if it's forced.

;//==============================
;//１、些細なイタズラで我慢しよう
*select03_1|Maybe they can see through my true intentions.

Let's just do it in secret. What I do is a prank no matter how far I go.
[cpg]

I had a feeling that this current situation was the best.
[cpg]

[jump target="*select03_3"]

;//==============================
;//２、無理矢理でも実行したい
*select03_2|Maybe they know our true intentions.

;//「無理矢理」変数+1
[stflag flg_muri = 1]

Of course, I think I need to be prepared for that.
[cpg]

But I can't stop now that I've come this far.
[cpg]

;//==============================
*select03_3|Maybe they know what I really want to do.

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_ni"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

And the arrangements for tomorrow are ready.
[cpg]

All we have to do is wait for tomorrow. It's a weekday, Asuka will be at the school.
[cpg]

But this strategy is difficult because we can't pinpoint Asuka. ......
[cpg]

Well, that's okay. Let's just give it a try.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

And the next morning. I headed to the school with everything ready to go.
[cpg]

I felt fine. Let's give it a try.
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（朝）******************************************************

[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Asuka042"]
[OnName num="asuka"]
"Good morning, Death. ......
[cpg cn=true]

[OnName num="ryo"]
You look sleepy. Late night cartoons?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Asuka043"]
[OnName num="asuka"]
"Hi ......, why is that one on late night?"
[cpg cn=true]

Surely, that's a question no one can answer.
[cpg]

I understand that daytime or evening is bad, but I don't understand why late night is OK.
[cpg]

[OnName num="ryo"]
I don't know why late at night is OK. "Well, isn't it best to record it ......?　Ah."
[cpg cn=true]

[free time=300]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Mikoto064"]
[OnName num="mikoto"]
Good morning, you two. You two.
[cpg cn=true]

[FACE method="bow_1" pos="4/5"]
Me and Asuka greet each other. And then,
[cpg]

[FACE method="shake_4" pos="2/5"]
[VOICE f="Mikoto065"]
[OnName num="mikoto"]
'...... Asuka, has anything strange happened to you lately?'
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
Strange things ......?　Asuka nods her head.
[cpg]

[FACE method="shake_1" pos="2/5"]
[VOICE f="Mikoto066"]
[OnName num="mikoto"]
She nods her head and says, "No, it's nothing. Don't worry about it.
[cpg cn=true]

Mikoto is becoming aware of it. Or is it natural?
[cpg]

I'm sure you don't have a clear idea of who the culprit is.
[cpg]

If they had an idea, they wouldn't have said such a thing in front of me.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（朝）******************************************************

On the way to the school, I listened to the conversation between Asuka and Mikoto.
[cpg]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Mikoto067"]
[OnName num="mikoto"]
'I don't read manga,...... I don't really like them.
[cpg cn=true]

[FACE method="shake_2" pos="4/5"]
[VOICE f="Asuka044"]
[OnName num="asuka"]
But Mikoto reads novels, doesn't he?　There are many anime based on novels."
[cpg cn=true]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Mikoto068"]
[OnName num="mikoto"]
"I don't really read novels that are ...... aimed at students either.
[cpg cn=true]

They are fairly close. But there is a gap between them in these areas.
[cpg]

Mikoto is always the chairman of the committee, and Asuka is a geek. Or, to put it another way, a geek or a nerd.
[cpg]

[OnName num="ryo"]
"Hey, do you call them geeks and nerds in general?
[cpg cn=true]

[FACE method="bow_1" pos="4/5"]
[VOICE f="Asuka045"]
[OnName num="asuka"]
"Yes, I do.　It has a slightly different meaning.
[cpg cn=true]

I asked for more details, but then more English words started popping up, and I couldn't keep up with them.
[cpg]

I knew that Asuka was a geek or a nerd.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************

Classroom. Class as usual.
[cpg]

[OnName num="ryo"]
Where are you going, Aska?　Next class will be in this room.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Asuka046"]
[OnName num="asuka"]
Toilet ...... is the Japanese way of saying lavatory.
[cpg cn=true]


[SE f="se001"]
;//【ＳＥ】『歩く』

[free time=1000]
[WAIT time=2000]


[FADEOUTBGM]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

Hmmm. It seems the time has come. I sent him off once and followed him stealthily.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]

The restrooms on this floor have one door before separating the men's and women's rooms.
[cpg]

I decided to play the same prank there as before.
[cpg]


;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Mikoto069"]
[OnName num="mikoto"]
I asked, "......, what's going on?"
[cpg cn=true]

[OnName num="ryo"]
What's wrong?　Ha, ha."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto070"]
[OnName num="mikoto"]
"You're breathing so hard, it's like you've been running ...... as fast as you can."
[cpg cn=true]

[OnName num="ryo"]
"It's just your imagination,...... haha."
[cpg cn=true]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

And at another time, I met Asuka once more.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Asuka059"]
[OnName num="asuka"]
'Dudes, desu...... Ling, Mikoto.'
[cpg cn=true]

Asuka was a little gaunt as she greeted Mikoto and me.
[cpg]

I think that's the kind of expression you get. Considering what I did.
[cpg]

[free time=300]
[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Mikoto071"]
[OnName num="mikoto"]
You seem very depressed. What's wrong?"
[cpg cn=true]

Asuka bit her lip and said nothing. That's the kind of attitude you can expect when you think about what I've done. ......
[cpg]

I wonder if it's a little too much. But the desire is unquenchable.
[cpg]

This whole thing has given me another idea. I can't back down now.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（夕方）******************************************************

Asuka went home first. It's not often that I get to do something like that.
[cpg]

The damage must have been that great. It is easy to imagine.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Mikoto072"]
[OnName num="mikoto"]
Really, I don't know what's wrong with you. ...... I hope you're not in as bad a spot as I was."
[cpg cn=true]

[OnName num="ryo"]
What do you mean, like ...... me?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Mikoto073"]
[OnName num="mikoto"]
"...... well, you might want to talk to Ryo about it."
[cpg cn=true]

Oops. Did I go too far?　If I keep asking for advice like this, I might end up in trouble.
[cpg]

[OnName num="ryo"]
No, no, no. It's a little out of my control.
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Mikoto074"]
[OnName num="mikoto"]
Please at least listen to me. I've been getting a lot of strange pranks lately.
[cpg cn=true]

[OnName num="ryo"]
"I see."
[cpg cn=true]

I said, but I brushed it off.
[cpg]

[OnName num="ryo"]
I don't know about you, but don't get down about it. You don't look good looking depressed."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Mikoto076"]
[OnName num="mikoto"]
'...... I guess you're right. I guess you're right.
[cpg cn=true]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『通学路』（夕方）******************************************************

I think it was a close call. But I managed to pull it off.
[cpg]

I think the next one will be Yukiho-san. Mikoto would be fine, too. ......
[cpg]

I have a lot of things I want to try with Yukiho. Let's give it a try.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yukiho042"]
[OnName num="yukiho"]
"Oh, welcome back, Ryo-kun. Ryo-kun.
[cpg cn=true]

[OnName num="ryo"]
Good evening, Yukiho-san. Are you shopping?
[cpg cn=true]

In his hand was a shopping bag from the supermarket.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Yukiho043"]
[OnName num="yukiho"]
I see. I'm a landlord, but it's just like living alone.
[cpg cn=true]

It was indeed like that.
[cpg]

[OnName num="ryo"]
Please take me home again. I'm continuing with the relationship advice.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Yukiho044"]
[OnName num="yukiho"]
I'll see you next time. I'll see you next time.
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

We went back to my place and had dinner.
[cpg]

[window target=false]
[BG f="b_06_4.ui" time=1000]
[WAIT time=3000]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

What should I do tomorrow? I have to make time to go to Yukiho's house.
[cpg]

I should skip the school on the way there. Let's do that.
[cpg]

I'm becoming quite a delinquent, but I'm not a high achiever to begin with.
[cpg]

I'll just have to convince the teachers that I was always predisposed to be like this.
[cpg]



[jump storage="ep004.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
