
*start|Chance to fulfill your desires

;#################################################
*Ep001|Chance to fulfill your desires
;#################################################

[SCENE id=1]


;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


After finishing dinner, I took a bath and ...... morning comes again.
[cpg]

I feel like I'm spending my time in idleness and I'm in a hurry, but in fact, I'm spending my time in idleness.
[cpg]

I didn't feel like I was filling up my precious youth with fruitless confessions.
[cpg]

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=3000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************

So, the next morning. I went out to school, rubbing my sleepy eyes.
[cpg]

Then I met Yukiho.
[cpg]

;//========================================
;//●ＣＧ非エロ（柔らかい笑顔で主人公と話すヒロイン。アパートの前）ev_03
;//人物１：ヒロイン３
;//服装１：私服
;//場所　：通学路
;//時間　：朝
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="Yukiho009"]
[OnName num="yukiho"]
Oh, good morning. You're already at school, right?
[cpg cn=true]

[OnName num="ryo"]
Yes, it is. Where's Yukiho-san?
[cpg cn=true]

[VOICE f="Yukiho010"]
[OnName num="yukiho"]
I'm telling you, being a landlord, I have quite a bit of free time, don't I?"
[cpg cn=true]

He laughs. But you said you were studying, didn't you?
[cpg]

[OnName num="ryo"]
What did you mean when you said you were studying?
[cpg cn=true]

[VOICE f="Yukiho011"]
[OnName num="yukiho"]
Oh, that's ......, I'm trying to get another certification.
[cpg cn=true]

Qualifications. I wonder if it's something I need as a landlord.
[cpg]

Or is he still planning to expand his business?
[cpg]

The age of the two is not that far apart, but he is a landlord, right?
[cpg]

He must be very rich. If he could get together with her, he might be a ball of reverse psychology.
[cpg]

;//ブラックアウト

[VOICE f="Yukiho012"]
[OnName num="yukiho"]
I'll see you later, Ryo-kun. Ryo-kun.
[cpg cn=true]

[OnName num="ryo"]
Yes, Sachiho. See you later.
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（朝）******************************************************

I headed to the school, thinking of something devious.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mikoto014"]
[OnName num="mikoto"]
I'm sure you're just in time for the morning today as well. Ryo is ...... ah.
[cpg cn=true]

[OnName num="ryo"]
That means you're on the edge too. What were you doing?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Mikoto015"]
[OnName num="mikoto"]
"I had to do some class committee work,......, so I'm a little sleepy.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

Do you usually make class committee members work until they get sleepy?
[cpg]

I walk with Mikoto, wondering if our school is okay.
[cpg]

[SE f="se001"]
;//【ＳＥ】『道歩く』

Of course, Asuka and I walk to school together, but we meet up with Mikoto on the way.
[cpg]

So we have a chance to talk to each other.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Mikoto016"]
[OnName num="mikoto"]
Why were you late?
[cpg cn=true]

[OnName num="ryo"]
I'm in the neighborhood. I've been talking to a goddess in the neighborhood.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto017"]
[OnName num="mikoto"]
......She's a goddess, so is she a beautiful married woman or a female office worker or something like that?
[cpg cn=true]

[OnName num="ryo"]
Maybe you won't get it by guesswork. It's the landlord."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Mikoto018"]
[OnName num="mikoto"]
"Hmm ...... sure, that won't hit the spot, huh."
[cpg cn=true]

Is my story boring? I yawn frequently.
[cpg]

[OnName num="ryo"]
I'm sure you're fine, Mikoto.　Are you sleeping okay?
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Mikoto019"]
[OnName num="mikoto"]
I've been reading novels and stuff after I get home,......, so I'm not sleeping well.
[cpg cn=true]

[OnName num="ryo"]
I'm not good for you. It's bad for your beauty.
[cpg cn=true]

I'm going to say something unmanly.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto020"]
[OnName num="mikoto"]
"You don't look like a man. ......
[cpg cn=true]

[OnName num="ryo"]
I'm aware of that, so don't say it. Let's go."
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（朝）******************************************************

And then we come close to the school.
[cpg]

Once you get here, all you have to do is head to the classroom. But ......
[cpg]

[OnName num="ryo"]
"We're pretty close, should we run?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Mikoto021"]
[OnName num="mikoto"]
"...... can you go ahead of me?　I might not be able to run for a bit......."
[cpg cn=true]

He looks really sleepy. I have no choice, so I just start running.
[cpg]

If you are a serious honor student and also the class president, you may be forgiven for being tardy once or twice.
[cpg]

But I'm an underclassman. If I don't show up for class, I'm in real trouble.
[cpg]


[SE f="se012"]
;//【ＳＥ】『廊下走る』

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************

[OnName num="teacher"]
Shirai, you are ...... just in time for tardiness.
[cpg cn=true]

[OnName num="ryo"]
I'm sorry. ......
[cpg cn=true]

I don't pronounce "mi" or "i" and apologize with "n".
[cpg]

I was just in time for the meeting. I took my seat with this thought in mind.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

Mikoto didn't come easily. I was so sleepy that I didn't think she would have collapsed on the spot.
[cpg]

I wondered if he went to the infirmary. As my imagination was passing, Mikoto came to me. It was already lunchtime.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]

[OnName num="ryo"]
Is you sure you're all right?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Mikoto022"]
[OnName num="mikoto"]
...... staying up late is not so good, is it?
[cpg cn=true]

[OnName num="ryo"]
I'll help you with that. Let me help you.
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Mikoto023"]
[OnName num="mikoto"]
"I can't help you if you're Ryo. ......
[cpg cn=true]

He says something sober and harsh. Then Asuka came in.
[cpg]

[free time=300]
[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Asuka012"]
[OnName num="asuka"]
Mikoto, do you look sleepy?　What's wrong?
[cpg cn=true]

The actuality is that you can find a lot of people who are not able to get the same kind of information.
[cpg]

[OnName num="ryo"]
"She was so sleepy from all the class committee work and reading hobbies and stuff."
[cpg cn=true]

[FACE method="bow_2" pos="4/5"]
[VOICE f="Asuka013"]
[OnName num="asuka"]
I understand. I understand. I stay up late for late-night anime too.
[cpg cn=true]

Don't stay up late for Japanese anime, Americans.
[cpg]

[OnName num="ryo"]
"......, you're pretty much a Japanophile, aren't you?"
[cpg cn=true]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Asuka014"]
[OnName num="asuka"]
Not really. Japanese food tastes bad.
[cpg cn=true]

You don't have to say anything. I think it's a good balance.
[cpg]

I'm not talking about the fact that you look sleepy .......
[cpg]

[OnName num="ryo"]
"Mikoto, if you are too sleepy, you should skip the afternoon class and go home.
[cpg cn=true]

[FACE method="shake_4" pos="2/5"]
[VOICE f="Mikoto024"]
[OnName num="mikoto"]
I'll take the class at my discretion, so ...... don't worry about it."
[cpg cn=true]

Even though he said so, I felt uneasy.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

Then came the afternoon class. Mikoto's eyes were barely open.
[cpg]

Even so, I thought it was Mikoto's persistence to desperately try to take notes.
[cpg]

More time passed, and finally, ......
[cpg]

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』
[WAIT time=1000]

[OnName num="ryo"]
"Finally, the class is over. Let's go home, Mikoto."
[cpg cn=true]

[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mikoto025"]
[OnName num="mikoto"]
No,...... I still have some work to do as chairperson."
[cpg cn=true]

[OnName num="ryo"]
I'm still working as the chair of the committee.　I don't know if I'm going to die from too much sleep.
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Mikoto026"]
[OnName num="mikoto"]
"I'm sure I won't die because I'm too sleepy.
[cpg cn=true]

[OnName num="ryo"]
"I don't know. If we were on a snowy mountain.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Mikoto027"]
[OnName num="mikoto"]
"This is not a snowy mountain. ...... Then, Ryo, please go home first.
[cpg cn=true]

I wondered if he would be okay. With a somewhat bad feeling, I decided to go home first.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（夕方）******************************************************


[FACE method="change_4" pos="2/3"]
[VOICE f="Asuka015"]
[OnName num="asuka"]
"Mikoto, are you all right desu ......?　I feel sorry for him.
[cpg cn=true]

[OnName num="ryo"]
I'm not going to stop him when he's in the mood for it.
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Asuka016"]
[OnName num="asuka"]
That's right, but ...... hmmm, does that mean the Japanese are diligent?
[cpg cn=true]

[OnName num="ryo"]
Asuka certainly doesn't strike me as a hard worker.
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Asuka017"]
[OnName num="asuka"]
I don't want Ryo to tell me that.
[cpg cn=true]

I don't want Ryo to tell me that. I thought about it a bit after I said it too.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

;//[FACE method="change_1" pos="2/3"]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

And then we went back to the house while talking with Asuka about unimportant things.
[cpg]

Then I noticed one thing. My bag was lighter than usual.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Asuka018"]
[OnName num="asuka"]
I noticed that Ryo's bag was not as bulky as usual.
[cpg cn=true]

I have a habit of making my bag bulky, but today it was strangely light.
[cpg]

[OnName num="ryo"]
"Oh, I forgot my ...... textbooks and notebooks.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Asuka019"]
[OnName num="asuka"]
Will you pick them up tomorrow?"
[cpg cn=true]

I'm sure that's what I would do if I were a less diligent person.
[cpg]

Today, however, I had a strange premonition, or rather, a feeling of coming together.
[cpg]

Mikoto looked so sleepy. I knew that, and I forgot something.
[cpg]

This must be some kind of fate. Thinking this, I decided to go back to the school.
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Asuka020"]
[OnName num="asuka"]
"Hey, are you sure you want to go?
[cpg cn=true]

[OnName num="ryo"]
I'm going to go back to the school. Asuka can go home first.
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************

I'm going back to the academy again. I wonder if that classroom is still open.
[cpg]

It should be open, because Mikoto should still be there.
[cpg]

[SE f="se002"]
;//【ＳＥ】『学園のドア開く』

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


The classroom I was headed to, my textbooks and notebooks were there. And one more ......, or rather one person.
[cpg]

[OnName num="ryo"]
"...... Mikoto. Wake up, wake up."
[cpg cn=true]

There was Mikoto who was sleeping on his cheekbones.
[cpg]

How can you sleep in this position? I can't.
[cpg]

Still, he looks happy. Is he dreaming?
[cpg]

As I thought about this, I had a desire in my mind.
[cpg]

;//移植のためシーンをカットしています

;//【ＢＧ】『学園外観』（夕方）

I think that even if I do something to her now, she won't even notice what happened.
[cpg]

I think. I wonder what I want to ......
[cpg]

;//■選択肢
[switch]
[case "I shouldn't do that."]
	[swap]
	[jump target="*select02_1"]
[case "I can't control myself."]
	[swap]
	[jump target="*select02_2"]
[endswitch]

One, I shouldn't do that.
2. I can't control myself


;//==============================
;//１、そんなことしちゃいけない
*select02_1|A chance to fulfill my desires

I mustn't do such a thing. Of course I have the desire to do it.
[cpg]

But if you can't control it, you are no good as a human being.
[cpg]

I thought I was going to ......, but in the end I couldn't stop myself.
[cpg]

[jump target="*select02_3"]

;//==============================
;//２、自分が抑えられない
*select02_2|Chance to fulfill your desire

;//「こっそり」変数+1

[stflag flg_koso = 1]

......After all, I can't stop myself.
[cpg]

If I miss it now, I may never have another chance......
[cpg]

;//==============================
*select02_3|Chance to fulfill your desires


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Just a little bit. I thought it would be just a little bit, so I filled a bucket with water.
[cpg]

If it's just enough to wet my hair, I'm fine. I thought as I approached.
[cpg]

[FG f="CHA01_p3_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sMikoto001"]
[OnName num="mikoto"]
I thought, "...... nn...... good morning."
[cpg cn=true]

Mikoto woke up.
[cpg]

I was wondering if I was lucky or unlucky.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sMikoto002"]
[OnName num="mikoto"]
"...... that bucket, what were you going to do with it?"
[cpg cn=true]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

;//というのも、俺はイタズラを実行する直前だったのだ。今更、言い訳はできない。
I was just about to perform the prank. Somehow I made an excuse and left the place.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『通学路』（夕方）******************************************************

[FACE method="change_2" pos="2/3"]
[VOICE f="Yukiho013"]
[OnName num="yukiho"]
Oh, Ryo-kun. How often do you see me?
[cpg cn=true]

Even though my apartment is on the way to school, it is true that I see him often these days.
[cpg]

I thought about telling him how I felt, but I couldn't. There was no way I could tell him.
[cpg]

There was no way I could. There was no way I could tell him. I didn't know where he would find out.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Yukiho014"]
[OnName num="yukiho"]
What's wrong?　You look a little pale.
[cpg cn=true]

[OnName num="ryo"]
"It's nothing. ...... I'm fine."
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

I went out to the city and wandered around.
[cpg]

I didn't feel like going home right away. I felt strangely elated.
[cpg]

;//こんなことしちゃいけない。もっとしたい。いずれの感情もある。
I shouldn't be doing this. I want to get wet. Both of these feelings exist.
[cpg]

But I don't need to have those feelings, because tomorrow everything might be said and done.
[cpg]

;//そしたら、俺があの教室に向かっていくのを誰かが見ていたりもするかも……
Maybe someone will be watching me as I walk to that classroom. ......
[cpg]

;//俺のしたことは全て明るみになりかねない。
Everything I did could come to light.
[cpg]

No. I'm being negative. I thought to myself, "I'm being negative," as I passed the time by going to the arcades and other random places in town.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

When I came home a little late, my parents were worried about me.
[cpg]

It's fine for them to worry about me, but that's not what I want them to worry about.
[cpg]

My life may already be over. But I can't tell anyone that.
[cpg]

I was in agony. ......
[cpg]


[jump storage="ep002.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
