
;//==============================
;//「合意」ルートの場合

*start|I want to be a lover with Mikoto

;#################################################
*Ep006|I want to be a lover with you
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************

*root1_2|I want to be a lover with you

[SCENE id=6]

......I want to be in love with Mikoto if possible.
[cpg]

I'd like to be in love with Mikoto if I could. But it is not possible to continue this relationship indefinitely.
[cpg]

I thought so, and I began to think of a plan, a strategy, to become a lover with Mikoto.
[cpg]

;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************

I thought I had a clear goal and a clear path to follow.
[cpg]

I want to be in love with Mikoto. I thought about it a lot, but I couldn't come up with anything that could be called a ruse.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Mikoto222"]
[OnName num="mikoto"]
Good morning, Ryo. Ryo.
[cpg cn=true]

[OnName num="ryo"]
Good morning. Come along with me.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto223"]
[OnName num="mikoto"]
'It's started again,...... which is surprising since I haven't heard that lately.
[cpg cn=true]

[OnName num="ryo"]
No, this time I really mean it. And I'll only tell Mikoto to prove it."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
Mikoto looks at me with a puzzled look on his face. Is that the kind of face you want to make?
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

I was so surprised.
[cpg]

[OnName num="ryo"]
"Do you want to have lunch with me?
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mikoto224"]
[OnName num="mikoto"]
"...... is fine.
[cpg cn=true]

[OnName num="ryo"]
"Okay, I'll go out with you.
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Mikoto225"]
[OnName num="mikoto"]
"Oh my God, ......!　Please stop it, if you're going to say something like that, say it to everyone like you did before or ......
[cpg cn=true]

[OnName num="ryo"]
I'm not. I like you, Mikoto. I've finally realized it.
[cpg cn=true]

I'm going to say it straight to the point. Mikoto was puzzled.
[cpg]

[free time=1000]

The people around him were also puzzled. I guess it was unusual for me to attack a single woman.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Asuka110"]
[OnName num="asuka"]
I think he's serious about this. ......
[cpg cn=true]

[OnName num="female_student"]
I never knew Ryo was so single-minded. ......
[cpg cn=true]

The Asuka's are gossiping at a bit of a distance.
[cpg]


;//ブラックアウト
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


Over the next three days, I continued my attack.
[cpg]


Yes, only three days. Surprisingly, it was short until Mikoto broke down.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

[OnName num="ryo"]
"What are you doing calling me all the way out here?　Confession?"
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Mikoto226"]
[OnName num="mikoto"]
Yes, that's right. You're the one who drove him to this point.
[cpg cn=true]

[OnName num="ryo"]
"......?
[cpg cn=true]

I had done what I did in order for this to happen someday. But I was surprised.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Mikoto227"]
[OnName num="mikoto"]
I'll go out with you. Just for a trial, you know. If you become disillusioned, I'll break up with you right away.
[cpg cn=true]

[OnName num="ryo"]
"......Ah, this isn't a dream, is it? This isn't a dream, is it?
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Mikoto228"]
[OnName num="mikoto"]
"Shall I pinch your cheeks?"
[cpg cn=true]

He made a joke that was out of character for Mikoto. It seems that it is not a dream.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]

So, as you can see, there was no progress on the next day off. On the next day off, there was progress.
[cpg]

;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************

[free time=1000]
[WAIT time=1000]

Mikoto's room was tidy. It was very girly, but the novels were sorted by publisher.
[cpg]

I was wondering if she was being a little too meticulous,
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mikoto229"]
[OnName num="mikoto"]
Then I asked her, "So, ......, you'll take full responsibility, won't you?"
[cpg cn=true]

[OnName num="ryo"]
Responsibility for what?
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Mikoto230"]
[OnName num="mikoto"]
I want to have a baby. I've always dreamed of having a baby. I want to have a baby as soon as I graduate from school.
[cpg cn=true]

[OnName num="ryo"]
"...... That's a lot of work, isn't it? I have to get a job too.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mikoto231"]
[OnName num="mikoto"]
I'll work as much as I can, but if I get pregnant, I won't be able to. Please think about that.
[cpg cn=true]


;//ブラックアウト
[free time=300]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[WAIT time=1000]

We kissed. Maybe Miko and I had liked each other to begin with.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************

[OnName num="ryo"]
I'm at ......, Mikoto. Can I talk to you for a minute?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Mikoto249"]
[OnName num="mikoto"]
What is it?"
[cpg cn=true]

[OnName num="ryo"]
"Are you ...... aware of it?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Mikoto250"]
[OnName num="mikoto"]
"Aware of what?　About the series of pranks?
[cpg cn=true]

Oh, yeah. I knew you were aware of it. I kind of didn't need to ask. ......
[cpg]

Somewhere along the way, I had an inkling that you might be right.
[cpg]

[OnName num="ryo"]
I mean, I'm sorry. I've been horrible to you.
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Mikoto251"]
[OnName num="mikoto"]
I don't mind. I don't care. Let's go have lunch.
[cpg cn=true]

I don't care. ...... is that simple.
[cpg]

Is it really that big of a deal to be passed over for the word "more"? I think it's a pretty big deal.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Mikoto252"]
[OnName num="mikoto"]
I'm sure you're hungry.　You must be hungry."
[cpg cn=true]

[OnName num="ryo"]
What?　Oh, ah, .......
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mikoto253"]
[OnName num="mikoto"]
"My family will be home late today. Come on, let's go."
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

So, arm in arm, we went on a date. We went into a casual restaurant, typical of students, and had lunch.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto254"]
[OnName num="mikoto"]
'Phew. ...... I wish I could cook.
[cpg cn=true]

[OnName num="ryo"]
"You can't?　I'm surprised.
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Mikoto255"]
[OnName num="mikoto"]
I'm not confident enough to let Ryo eat. I'm not afraid of it, but I'm not afraid of it.
[cpg cn=true]

I felt her pride a little. I knew it was something I knew.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************

We went back to her room. It was still noon.
[cpg]

There are so many things I want to talk about that there is never enough time.
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************

And the sun is about to set. If I stay too long, there will be a problem.
[cpg]

[OnName num="ryo"]
Well, I guess I'd better get back.
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Mikoto275"]
[OnName num="mikoto"]
Why?　You can stay a little longer.
[cpg cn=true]

[OnName num="ryo"]
No, that's not good. I can't stay for dinner.
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Mikoto276"]
[OnName num="mikoto"]
I see. ...... I wanted to introduce you to my parents.
[cpg cn=true]

That's absurd. It's too soon.
[cpg]

But he also said he wants kids soon. Maybe I should make up my mind too.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[SE f="se029"]
;//【ＳＥ】『衣擦れ』

I went back to my room and fell a little bit lazy.
[cpg]

I can't wait to see what the future holds for me. ......Miko and I are both pretty predatory, even though she looks like she's not.
[cpg]

But that's to my advantage.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************

The next weekday, I was thinking about how devious I was being.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Asuka111"]
[OnName num="asuka"]
I was in a good mood.
[cpg cn=true]

[OnName num="ryo"]
"Do I?　What did you see that made you think that?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Asuka112"]
[OnName num="asuka"]
"Well, ......, it's a bit of a roundabout way of putting it. Mikoto told me what happened.
[cpg cn=true]

I don't know. I know what you mean, but I understand what you want to say.
[cpg]

[OnName num="ryo"]
Well, that's the way it is. I'm sorry I can't hang out with Asuka anymore."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Asuka113"]
[OnName num="asuka"]
I'm sorry I couldn't go out with you. I'm just trying to be smart.
[cpg cn=true]

[OnName num="ryo"]
The last one isn't exactly subtle. ......
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

And then I went to my morning classes at the school.
[cpg]

Soon it's lunchtime. And then Mikoto took me by the hand.
[cpg]

[free time=300]
[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="4/5" time=800]
[VOICE f="Asuka114"]
[OnName num="asuka"]
"Hew hew, hot desu."
[cpg cn=true]

I was taken by Mikoto with words on my back that were almost entirely in katakana, except for one letter.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

I spend more and more time alone with her. And ......
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

After school. I was invited to Mikoto's room again.
[cpg]

;//ブラックアウト
[window target=false]
;//[free time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=2000]

;//【ＢＧ】『通学路』（夕方）

;//ブラックアウト
[free time=1000]
[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************

We will be graduating soon. If that's the case, then I should be able to get ......
[cpg]

I heard that she wants to have a baby after graduation, and the time we are lovers may be surprisingly short for us.
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

We have to cherish the time we have now, but the days are flying by.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************

We have come to the point where we will graduate this school year.
[cpg]

Mikoto says she's going to have a baby, and I say I'm going to work.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Asuka115"]
[OnName num="asuka"]
I'm graduating soon, aren't I? Mikoto and the boys are getting married soon?"
[cpg cn=true]

[OnName num="ryo"]
Well, that's the way it's going to be. That's what Mikoto wanted."
[cpg cn=true]

Asuka smiles. I think she's looking at us with a devious eye rather than genuinely congratulating us.
[cpg]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

Youth goes by. Really, it went by in the blink of an eye.
[cpg]

We graduated from the school, I started working, and so did she.
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[OnName num="ryo"]
What are you going to do with that?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto314"]
[OnName num="mikoto"]
What do you mean, what are you going to do?
[cpg cn=true]

[OnName num="ryo"]
What do you mean, what do you mean? You're going back and forth between my room and Mikoto's room.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mikoto315"]
[OnName num="mikoto"]
Then, do you want to live together in an apartment somewhere?
[cpg cn=true]

Cohabitation. That sounds like a dream come true. It's hard to imagine. But that's a problem, too, isn't it?
[cpg]

[OnName num="ryo"]
I've been thinking about it for a while, and I'm thinking, "...... that would be nice. But my parents want me to stay.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Mikoto316"]
[OnName num="mikoto"]
'It's okay. My parents won't miss me because my sister is there too.
[cpg cn=true]

[OnName num="ryo"]
I'll think about that later. It's nothing you can't handle. ......
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

The days passed by.
[cpg]

;//========================================
;//●ＣＧ非エロ（二人で手を繋いで歩く。ヒロインは妊娠中、買い物袋を持つ主人公）ev_25
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：街
;//時間　：昼
;//備考２：ヒロインは妊娠四ヶ月くらいです
;//========================================
[window target=false]
;**【ＣＧ】 ev_25_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

It was Sunday afternoon. We were out shopping.
[cpg]

She is pregnant with my child, just as I had hoped.
[cpg]

[OnName num="ryo"]
"I love you, Mikoto.
[cpg cn=true]


[VOICE f="sMikoto017"]
[OnName num="mikoto"]
"I love you, too. I love you too.
[cpg cn=true]


There is no hesitation in saying love to each other.
[cpg]

I feel like this situation is what I have always wanted.
[cpg]


;//ＥＮＤ：ヒロイン１ルート２

[SCENE id=11]

[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
