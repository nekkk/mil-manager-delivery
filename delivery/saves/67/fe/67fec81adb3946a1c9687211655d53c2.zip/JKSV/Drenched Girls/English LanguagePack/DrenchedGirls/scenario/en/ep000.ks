
*start|I like girls who get wet and see through

;//液体娘　シナリオ

;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり

;//みこと　私服　制服
;//アスカ　私服　制服
;//幸穂　　私服

;//以下音声なし
;//凌 女子学生 教師 女子学生Ａ 女子学生Ｂ 女子学生Ｃ
;//男子学生Ａ 男子学生Ｂ 男子学生 凌の母

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//みこと　一人称「私」　凌呼び「凌」　アスカ呼び「アスカ」　幸穂呼び「幸穂さん」
;//アスカ　一人称「私」　凌呼び「凌」　みこと呼び「みこと」　幸穂呼び「幸穂」
;//幸穂　一人称「私」　凌呼び「凌くん」　みこと呼び「みことちゃん」　アスカ呼び「アスカちゃん」
;//凌　一人称「俺」　みこと呼び「みこと」　アスカ呼び「アスカ」　幸穂呼び「幸穂さん」

;//以下、残したCGを列挙します

;//みこと　01 06 10 13 16 17 25
;//アスカ　02 11 29 32 34 35 38
;//幸穂　　03 07 09 39 40 41
;///////////////////////////ここからが本編です///////////////////////////

;#################################################
*Ep000|wet and transparent girl lover
;#################################################

[SCENE id=0]

[stflag flg_koso = 0]
[stflag flg_muri = 0]
[stflag flg_goui = 0]
[stflag Cha1flg = 0]
[stflag Cha2flg = 0]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=1000]
[WAIT time=2000]
[window target=true]

[BGM f="bg_me"]
[WAIT time=100]

Why is a girl covered in liquid so cute?
[cpg]

Why tangerines for kotatsu, why salt instead of sugar for watermelon?
[cpg]

I think they are connected by fate.
[cpg]

It is no exaggeration to say that all girls are destined to be covered in liquid.
[cpg]

But why is this not the case in reality?
[cpg]

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

[OnName num="ryo"]
Please go out with me!
[cpg cn=true]

I bow my head. I don't call her by name because I don't know her name.
[cpg]

[OnName num="female_student"]
'Oh no, creepy ...... Ryo, you don't know me.
[cpg cn=true]

Yes, I do. I don't even know your name.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（夕方）******************************************************

;//下記セリフのみ名前を？？？と隠してください

[FACE method="change_7" pos="2/3"]
[VOICE f="Mikoto001"]
[OnName num="unknown"]
You were dumped again, weren't you?"
[cpg cn=true]

[OnName num="ryo"]
'Yeah, I got dumped ...... so go out with me.'
[cpg cn=true]

[free time=300]
[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
The one who sighs at my light talk is Mikoto Nishigaki, the chairperson of my class. He is the chairperson of my class.
[cpg]

[free time=300]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mikoto002"]
[OnName num="mikoto"]
"Huh,......, you're trying to hit on every single one of them, aren't you?"
[cpg cn=true]

[OnName num="ryo"]
I don't feel bad about it. It's up to me.
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Mikoto003"]
[OnName num="mikoto"]
It's bad. It's bad for public morals.
[cpg cn=true]

Whenever I see a pretty and beautiful girl like Mikoto, I think to myself.
[cpg]

He wants to get her wet with my pranks. I go up to his throat to ask him to go out with me first for that.
[cpg]

Or rather, it comes out from my throat. I said it before.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto004"]
[OnName num="mikoto"]
'I'm confessing without moderation, so isn't one confession worth less?
[cpg cn=true]

[OnName num="ryo"]
If that's the case, then it's odd that your first confession didn't go so well."
[cpg cn=true]

You have a point, I said and sighed again. You don't think I have a point.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

I'm Ryo Shirai, walking leisurely down the street to school.
[cpg]

I'm a womanizer, or rather, I'm trying to pass through womanizing and become something else.
[cpg]

In reality, however, I can never become something else, and I am always told that "he is a womanizer.
[cpg]

For example, his grades are bad. Because he is a womanizer.
[cpg]

He is not popular. Because he is a womanizer. In other words, I cannot be excluded from the factor of being a womanizer in their evaluation of me.
[cpg]

I am aware of it. But strictly speaking, it is a little different.
[cpg]

In fact, I like "women covered in liquid. If you make a mistake here, the meaning will change completely.
[cpg]

For example, if I like women who are "covered in liquid," I would be covered in liquid. I don't want that.
[cpg]

I have such distorted desires.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mikoto005"]
[OnName num="mikoto"]
I'll see you tomorrow. Bye.
[cpg cn=true]

[OnName num="ryo"]
Yeah. Come along.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto006"]
[OnName num="mikoto"]
That's why ...... no, goodbye.
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

I went further on my way to school. Then I saw my girl friend, or rather neighbor.
[cpg]

Aska-Dinoise. That's her real name. An assassin from America, the so-called half.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Asuka001"]
[OnName num="asuka"]
"Ah, Ryo?　Is Ryo on his way home too?
[cpg cn=true]

[OnName num="ryo"]
"Yes, I am. I mean, he's your neighbor, right?
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Asuka002"]
[OnName num="asuka"]
"Neighbor, yes, that's right. I forgot about you.
[cpg cn=true]

How could I have forgotten? We see each other almost every day.
[cpg]

[OnName num="ryo"]
Don't tell me you've forgotten my name, too.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Asuka003"]
[OnName num="asuka"]
"......well, who are you?"
[cpg cn=true]

[OnName num="ryo"]
That's funny. I told you when we first met that Ryo was on his way home, too.
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Asuka004"]
[OnName num="asuka"]
"Excuse me. I'm sorry, I forgot.
[cpg cn=true]

Which did I forget, the conversation or the name? It doesn't matter. I'm sure I didn't forget either.
[cpg]

[OnName num="ryo"]
"You're the same as ever. By the way, are you going out with me?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Asuka005"]
[OnName num="asuka"]
"HAHAHA, we're both the same as ever."
[cpg cn=true]

She laughs, not hahaha, but HAHAHA. She laughs so crisply that it takes up twice as much space.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Asuka006"]
[OnName num="asuka"]
She laughs so crisply that it takes up twice as much space as it should. Do you like anyone?
[cpg cn=true]

[OnName num="ryo"]
I'm saying this because it's Asuka. I'm saying this because it's Asuka.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]

Asuka laughs again, "HAHAHA. You don't take me seriously.
[cpg]

The Dinoars are next door neighbors. We naturally walk on the same road until we get back to the house.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Asuka007"]
[OnName num="asuka"]
'Well then, see you tomorrow Desu. Ryo.
[cpg cn=true]

[OnName num="ryo"]
Yes, see you tomorrow."
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

After that, I went home, ate dinner, brushed my teeth, took a bath, and it was nighttime.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

From the outside, I am not inconvenienced in any way.
[cpg]

However, inconvenience is not always apparent to others.
[cpg]

Today, too, I was filled with a desire that had no place to go.
[cpg]

I want to get a girl covered in liquid. But in order to do that, I need to go out with a girl.
[cpg]

What should I do to get together with a girl ......?
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

Morning comes in agony.
[cpg]

In the morning, I first go to the sink to wash my face and brush my teeth.
[cpg]


;//ブラックアウト
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

It is not that I see a dull face in the reflection. On the contrary, he is quite handsome.
[cpg]

I wonder if men are all about character after all. Is it the law of providence that if a man is too aggressive, everyone else will be turned off by him?
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（朝）******************************************************

On the way to school, I see Yukiho Shimamura.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Yukiho001"]
[OnName num="yukiho"]
Oh my, Ryo-kun, are you just leaving? Ryo-kun, are you just leaving?"
[cpg cn=true]

She is the landlord of a nearby apartment building. It is rare to see her.
[cpg]

[OnName num="ryo"]
Yes, well, something like that. Sachiho-san is at .......
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Yukiho002"]
[OnName num="yukiho"]
Yes, I was a little bored, so I went for a walk.
[cpg cn=true]

Bored? But I have the impression that apartment landlords don't know what they are doing.
[cpg]

I have the image of them doing something concurrently or something.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Yukiho003"]
[OnName num="yukiho"]
Is it okay if I stop Ryo-kun?　You're going to school now, right?"
[cpg cn=true]

[OnName num="ryo"]
Yes, it is. Then, will you go out with me?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Yukiho004"]
[OnName num="yukiho"]
"Will you go out with me?　You mean, to the school?
[cpg cn=true]

[OnName num="ryo"]
No, I mean, will you go out with me as a heterosexual ...... lover?
[cpg cn=true]

My love for women is age-neutral. I think Yukiho is quite old.
[cpg]

But I don't care about that.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Yukiho005"]
[OnName num="yukiho"]
I'm glad you're joking. Even if you're joking, I'm glad, thank you.
[cpg cn=true]

This is not the first time I confessed my love to Yukiho-san.
[cpg]

I felt like I deserved to be passed over already.
[cpg]

But she still couldn't give up on him. She is an adult woman, but she is somewhat of a maiden.
[cpg]

I thought she might not even have a boyfriend.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（朝）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Asuka008"]
[OnName num="asuka"]
What's wrong, Death?　You're going to be late. You're going to be late.
[cpg cn=true]

[OnName num="ryo"]
What?　Oh, Asuka or ......."
[cpg cn=true]

I was lost. If I didn't do something, I would never have a girlfriend.
[cpg]

I am beginning to think that I have to think about such a calculation, playing pranks on girls without being able to get a girlfriend.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Asuka009"]
[OnName num="asuka"]
You have a difficult face, don't you ......?"
[cpg cn=true]

[OnName num="ryo"]
I guess so. I also think about difficult things.
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Asuka010"]
[OnName num="asuka"]
I'm surprised.
[cpg cn=true]

The actual "I'm not a fan of the way you do it," he said, "but I'm not a fan of the way you do it either.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************

As soon as I arrived at the school, I had to go to class. I don't have time to rest.
[cpg]

Because I was late because I was thinking about something. ......
[cpg]

;//========================================
;//●ＣＧ非エロ（黒板にチョークを走らせる。真面目な顔のヒロイン）ev_01
;//人物１：ヒロイン１
;//服装１：制服
;//場所　：学園教室
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[SE f="se042"]
;//【ＳＥ】『チョークで書く』

The teacher nominated me for a job, and I chalked it up on the blackboard.
[cpg]

The actuality that you can find a lot more than one of the most popular types of shoes and boots.
[cpg]

She wrote a long equation. I, with my poor grades, had no idea what was being written.
[cpg]

[VOICE f="Mikoto007"]
[OnName num="mikoto"]
......"
[cpg cn=true]

Mikoto's expression is serious. I think she is serious about everything.
[cpg]

Especially when it comes to class chairpersons, it could be that way.
[cpg]

[OnName num="teacher"]
"Very well, go back to your seat, Nishigaki. Go back to your seat, Nishigami.
[cpg cn=true]

[VOICE f="Mikoto008"]
[OnName num="mikoto"]
Yes, sir.
[cpg cn=true]

[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************

Mikoto and Asuka are in the same class as me.
[cpg]

Mikoto is what you might call a high achiever, able to do everything without a hitch.
[cpg]

Rumor has it that she has a photographic memory.
[cpg]

Incidentally, Asuka is strong in math and other subjects but weak in classes involving Japanese.
[cpg]

I guess the language barrier is thick or high.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

By the time lunchtime came, Mikoto had opened his lunch box.
[cpg]

[OnName num="ryo"]
Is it okay if I join you?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mikoto009"]
[OnName num="mikoto"]
Yes, I don't mind.
[cpg cn=true]

[OnName num="ryo"]
I'm glad to hear that. By the way, will you be my lover?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto010"]
[OnName num="mikoto"]
You can't just change the way you say it. ......
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The two of us eat our lunch together. There are no strange rumors.
[cpg]

It seems that the opinion of those around me is that me and Mikoto are not compatible from the start.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Mikoto011"]
[OnName num="mikoto"]
Phew......... when I'm full, I feel sleepy.
[cpg cn=true]

[OnName num="ryo"]
I'm sure you're sleepy, aren't you? Do you have that kind of disease?"
[cpg cn=true]

Mikoto bites back a yawn as he says, "I don't know.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto012"]
[OnName num="mikoto"]
"I can't sleep at all, The next class is physical education."
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Physical education is not a motivation. If they were all boys and girls together, they would be separate.
[cpg]

The girls are in the gym and the boys are on the playground ...... and this doesn't motivate me.
[cpg]

I sat down near the gym and looked toward the gym.
[cpg]

;//========================================
;//●ＣＧ非エロ（バスケットボールをするヒロイン。汗が飛び散る感じ）ev_02
;//人物１：ヒロイン２
;//服装１：体操着
;//場所　：学園体育館
;//時間　：昼
;//========================================

[SE f="se047" loop=true]
;//【ＳＥ】『バスケ』

[window target=false]
[free time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

Asuka was active there. That guy is not only smart, he's also athletic.
[cpg]

He can do everything from track and field, soccer, tennis, and archery.
[cpg]

Because he can do all of them and has a strong visual impact, it seems that he is sought after by many clubs.
[cpg]

I can't picture girls playing basketball seriously, but ......
[cpg]

[OnName num="female_student_A"]
"Asuka, pass the ball!
[cpg cn=true]

[OnName num="female_student_B"]
I won't let you!"
[cpg cn=true]

I felt that the presence of Asuka was tightening up the surroundings.
[cpg]

Asuka, her own personality is like that.
[cpg]

She is full of energy and friendly. She is no exception.
[cpg]

She's childlike in some ways, but she's also unrivaled in athletics.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************

Toward the end of the day, I think I spent most of my time just admiring Asuka.
[cpg]

And then I realized it was after school.
[cpg]

[FACE method="bow_1" pos="2/5"]
[VOICE f="Mikoto013"]
[OnName num="mikoto"]
Asuka is a good basketball player, isn't she?
[cpg cn=true]

[FACE method="bow_2" pos="4/5"]
[VOICE f="Asuka011"]
[OnName num="asuka"]
It's okay. It's about normal over there.
[cpg cn=true]

The two of them are good friends. I don't have the courage ...... to break in on them when they are home together.
[cpg]

But now is not the time to use that kind of courage.
[cpg]

I felt bad to break up the two girls' friendly relationship.
[cpg]

I decided to go home as soon as possible.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

[FACE method="bow_2" pos="2/3"]
[VOICE f="Yukiho006"]
[OnName num="yukiho"]
"Ah, welcome home, Ryo-kun. Ryo-kun.
[cpg cn=true]

[OnName num="ryo"]
Hi, Sachiho. Is your job as a landlord good?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Yukiho007"]
[OnName num="yukiho"]
I don't know what you call landlord work. ...... It's like Sundays almost every day.
[cpg cn=true]

I see. If he has so much time on his hands, how does he spend it?
[cpg]

[OnName num="ryo"]
I'm like, "Do you have that much time on your hands?　Would you like to go out with me?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Yukiho008"]
[OnName num="yukiho"]
"Hmmm. Even if I'm not busy, I still have a lot of studying to do.
[cpg cn=true]

Studying. Is it studying to be a landlord, or does he intend to eventually handle real estate on a larger scale?
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se019"]
;//【ＳＥ】『ドア閉まる』

Whatever the case may be. My day is about to end.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

I consider myself a pervert among perverts. But no matter what anyone says, I will never change my nature.
[cpg]

I think about it further. If I were to get a girl covered in liquid, what would be the best situation?
[cpg]

;//■選択肢
[switch]
[case "Sneakily"]
	[swap]
	[jump target="*select01_1"]
[case "Forcibly"]
	[swap]
	[jump target="*select01_2"]
[case "Consensually"]
	[swap]
	[jump target="*select01_3"]
[endswitch]

1. secretly
2. forcibly
3. consensually

;//==============================
;//１、こっそり
*select01_1|I like wet and transparent girls.

;//「こっそり」変数+1

[stflag flg_koso = 1]

It may be impossible, but if I can do it secretly, that's the best I can do.
[cpg]

After all, I'm not popular. Then I feel it's better to sneak it than to force it or do it consensually: ......
[cpg]

But is that possible?　Would it be a form of prank?
[cpg]

While I was thinking about this and that, my parents called me over for dinner.
[cpg]

[jump target="*select01_4"]

;//==============================
;//２、無理矢理
*select01_2|I like wet and transparent girls

;//「無理矢理」変数+1

[stflag flg_muri = 1]

I want to fulfill my long-cherished wish even if it is forced.
[cpg]

What I say is a bit of an exaggeration, but I had the feeling that one day this desire would crush me.
[cpg]

There would be no way to do that, to sneak away.
[cpg]

Meanwhile, it's time for dinner. My parents call me to the dining room.
[cpg]

[jump target="*select01_4"]

;//==============================
;//３、合意の上で
*select01_3|I love wet and transparent girls!

;//「合意」変数+1

[stflag flg_goui = 1]

I think it's best if the confession is fulfilled after all. With that in mind, I went to ......
[cpg]

I thought I was getting a little hungry, so I headed to the dining room.
[cpg]

;//==============================

*select01_4|I like girls who get wet and see through




[jump storage="ep001.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
