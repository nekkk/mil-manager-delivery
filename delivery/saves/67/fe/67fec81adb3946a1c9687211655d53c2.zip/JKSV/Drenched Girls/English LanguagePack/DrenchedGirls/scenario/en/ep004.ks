
*start|Prank Execution

;#################################################
*Ep004|Execution of a prank
;#################################################

[SCENE id=4]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Mikoto077"]
[OnName num="mikoto"]
"...... you seem to be in a good mood, Ling."
[cpg cn=true]

[OnName num="ryo"]
"Really?　I've been like this for a while.
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Mikoto078"]
[OnName num="mikoto"]
'Was I right? ...... When I think of Ryo, I think he was more impatient with love.
[cpg cn=true]

That's for sure. I haven't been confessing to anyone recently.
[cpg]

I wonder if it means that the form of desire is changing to some extent.
[cpg]

Well, whatever the case may be, has it become healthier ...... than before?
[cpg]

I haven't done anything that's unnecessarily damaging to my impression.
[cpg]

After all, they don't know.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

And then, when I still had afternoon classes.
[cpg]

I complained that I wasn't feeling well and applied to leave early.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Asuka060"]
[OnName num="asuka"]
"Are you all right?　Do you have a cold?"
[cpg cn=true]

[OnName num="ryo"]
"Sounds like it. ...... Goho, goho."
[cpg cn=true]

I wonder if it smells a little like an act. It's okay.
[cpg]

I'm sure they won't know why when they find out I'm faking it.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Asuka061"]
[OnName num="asuka"]
"Have a nice ...... death."
[cpg cn=true]

[OnName num="ryo"]
"Oh, thank you. Well then.
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=3000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（昼）******************************************************

A short time after leaving the campus. I stopped walking tentatively.
[cpg]

Now, I have to go to Sachiho-san's place.
[cpg]

She's probably studying today to convert the apartment into the one I mentioned.
[cpg]

[SE f="se010"]
;//【ＳＥ】『玄関チャイム』

With that in mind, I pressed the chime of her room.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア開く』

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

[VOICE f="Yukiho045"]
[OnName num="yukiho"]
'Yes, yes, ...... Ah, Ryo-kun.
[cpg cn=true]

[OnName num="ryo"]
Hello. I'm here for a relationship consultation.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Yukiho046"]
[OnName num="yukiho"]
'Well, ...... today is not a holiday or anything, is it?　Where's the school?
[cpg cn=true]

[OnName num="ryo"]
It was the anniversary of the founding of the school.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Yukiho047"]
[OnName num="yukiho"]
But you're wearing a uniform.
[cpg cn=true]

Sure, I'm sure. How shall I cover it up?
[cpg]

[OnName num="ryo"]
I went to the wrong school. So we were chatting for a while.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Yukiho048"]
[OnName num="yukiho"]
Giggle. I didn't know you were doing that. Okay, come on.
[cpg cn=true]

;//ブラックアウト
;//========================================
;//●ＣＧイタズラ（寝ているヒロインの髪をちんぽに巻き付け、そのままオナニーする主人公。髪に射精する）ev_09
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：制服
;//場所　：ヒロイン３の部屋
;//時間　：昼
;//========================================
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
[WAIT time=100]
;**【ＣＧ】 ev_09_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="Yukiho030"]
[OnName num="yukiho"]
"Soooo...soooo..."
[cpg cn=true]

While we were talking, Yukiho fell asleep again. This is the second time.
[cpg]

It is different again from the first time. I can't do nothing again, also.
[cpg]

While she is sleeping, I try to head to the washroom to prepare for the prank.
[cpg]

[VOICE f="Yukiho056"]
[OnName num="yukiho"]
'Nn...... Ryo, kun......
[cpg cn=true]

Sachiho-san seems to be having a dream. I'm so happy to see me in my dreams.
[cpg]

Thinking so, I replied to her sleepy voice.
[cpg]

[OnName num="ryo"]
I'm here, Yukiho-san. I'm here, Yukiho-san.
[cpg cn=true]

[VOICE f="Yukiho057"]
[OnName num="yukiho"]
"Ryo, kun ......?"
[cpg cn=true]

Oh, no. As I talked to him, I felt like he wasn't talking in his sleep.
[cpg]

[VOICE f="Yukiho058"]
[OnName num="yukiho"]
"What are you doing, ...... Ryo-kun?"
[cpg cn=true]

[OnName num="ryo"]
I was just going to the bathroom. I was going to the bathroom.
[cpg cn=true]

[VOICE f="Yukiho059"]
[OnName num="yukiho"]
"So ......?　I was sleeping, right?"
[cpg cn=true]

;//移植のためシーンをカットしています

After that, we continue to talk appropriately and watch for the right moment to prank him.
[cpg]

However, it is still hard to find a squeaky clean one-on-one. ......
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『通学路』（昼）******************************************************

I leave the house, but it's still noon outside.
[cpg]

I wander around at random, thinking, "Yes, I skipped class, didn't I? ......
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

Skipping school is a leisurely thing if you don't have a clear purpose for it.
[cpg]

Shall I go back again?　No, that would be pointless.
[cpg]

Thinking about that, I walked around town at random.
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

Meanwhile, it was getting late in the evening. I should get back soon.
[cpg]

If I go any later, Mikoto and Asuka might find me.
[cpg]

I was supposed to be in bad shape, so it would be bad for them to find me like that.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

And when I got home, I was pissed off a lot.
[cpg]

My mother was the only one at home, but she said she had been informed that I had to leave early.
[cpg]

She said she was worried because I didn't come home.
[cpg]

I lied and said I had gone to the hospital alone, but they soon found out. I was not in any physical condition.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Asuka062"]
[OnName num="asuka"]
"Good morning, how are you? How are you?"
[cpg cn=true]

[OnName num="ryo"]
"Fine. I'm okay, I guess.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Asuka063"]
[OnName num="asuka"]
You don't look so-so. You look ...... happy.
[cpg cn=true]

[OnName num="ryo"]
I'm always in a good mood. I'm sure you were.
[cpg cn=true]

Aska nods her head. And,
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Asuka064"]
[OnName num="asuka"]
Compared to when I wanted her, it's much different, Desu. There is a difference.
[cpg cn=true]

[OnName num="ryo"]
Difference between the two. You know a difficult word.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Asuka065"]
[OnName num="asuka"]
"Hmmm. It's like the difference between the moon and the turtle.
[cpg cn=true]

That's not quite right, I thought, and decided to let it pass.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（朝）******************************************************

[VOICE f="Mikoto081"]
[OnName num="mikoto"]
'Oh, good morning. Asuka is with you, isn't she?
[cpg cn=true]

[FACE method="bow_2" pos="4/5"]
[VOICE f="Asuka066"]
[OnName num="asuka"]
Asuka is with you, isn't she? I'm a good friend of hers.
[cpg cn=true]

I think it's amazing that Asuka can unabashedly say we are good friends to someone who has confessed and rejected her.
[cpg]

She is friendly or childish.
[cpg]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Mikoto082"]
[OnName num="mikoto"]
"...... Aska. You better watch out."
[cpg cn=true]

Mikoto said in a slightly low tone of voice.
[cpg]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Asuka067"]
[OnName num="asuka"]
"What?　What des?"
[cpg cn=true]

Asuka reacted like this, but I gasped. You're aware of it?
[cpg]

And how do you know he's even doing it to Asuka ......?
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************

[OnName num="ryo"]
'Hey, Mikoto,......, what did you mean by that in the morning?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto083"]
[OnName num="mikoto"]
If you don't know, it's okay if you don't know. If you don't know, it's okay if you don't. It might be my imagination.
[cpg cn=true]

[OnName num="ryo"]
I'm curious. What are you talking about?
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Mikoto084"]
[OnName num="mikoto"]
I've been asked to consult with ...... Asuka.
[cpg cn=true]

I knew it. I knew it would be something like that.
[cpg]

I found out that the same problems, or rather the same things, were happening.
[cpg]

I suspect that Mikoto and Asuka have a common acquaintance, a boy, that is, me .......
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Mikoto085"]
[OnName num="mikoto"]
I'm just saying, "It's a silly story. Really, if you don't know, I don't care if you don't know.
[cpg cn=true]

[OnName num="ryo"]
"......, I see."
[cpg cn=true]

I couldn't react badly either. I decided to pull back.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

Instead, I decided to play a trick on Mikoto.
[cpg]

I set up a little trick in an empty classroom where no one would come.
[cpg]

[OnName num="ryo"]
"Here you go, ......."
[cpg cn=true]

A bucket filled with water. When you open the door, it falls down.
[cpg]

It's not a sideways-opening door, or something crude like that.
[cpg]

It's a broom or something, and it's balanced perfectly.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And I put it in Mikoto's desk.
[cpg]

A letter that calls out to her. I made it sound like a call for a confession from a guy.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Mikoto086"]
[OnName num="mikoto"]
"Is it ......, this ......?"
[cpg cn=true]

[OnName num="ryo"]
What is it?　A love letter.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto087"]
[OnName num="mikoto"]
"It can't be ......."
[cpg cn=true]

[WAIT time=1000]
[FACE method="shock_5" pos="2/3"]

I opened the envelope. Mikoto looks at the contents and starts to wriggle around.
[cpg]

[OnName num="ryo"]
What's wrong?　Is it really a love letter?
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Mikoto088"]
[OnName num="mikoto"]
No, it's nothing, nothing at all. ......
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Then, at lunchtime, I saw Mikoto heading to the empty classroom.
[cpg]

Everything is falling into place. All that remains is to see.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Mikoto089"]
[OnName num="mikoto"]
"......Gokkoku."
[cpg cn=true]

Mikoto tries to open the door. And then he opens ......!
[cpg]

;//========================================
;//●ＣＧ（頭から水を被って、尻餅をつくヒロイン）ev_10
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[SE f="se044"]
;//【ＳＥ】『バケツ落ちる』

;**【ＣＧ】 ev_10_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sMikoto006"]
[OnName num="mikoto"]
"Kyaaaah!"
[cpg cn=true]

I watched that moment from a distance.
[cpg]

Water does not dry quickly. I didn't want to see that moment.
[cpg]

I just want to see the girl soaking wet.
[cpg]

;@===================

[VOICE f="Mikoto091"]
[OnName num="mikoto"]
What is this ......?　What the hell is ......?"
[cpg cn=true]


I wanted to see what was going on right away, but I could resist.
[cpg]

If I did that, it might make me look suspicious.
[cpg]

For the time being, I was watching what was going on from a little distance, hiding.
[cpg]

Mikoto was slumped on the spot and seemed to be unable to move.
[cpg]

There was a possibility that he might run away right away, but that seemed to be lost.
[cpg]

[VOICE f="Mikoto9092"]
[OnName num="mikoto"]
'Really, what the ...... gusu.'
[cpg cn=true]

I can hear her voice almost crying out.
[cpg]

I felt sorry for him, but I still didn't approach him.
[cpg]

I had to approach it as if I was just passing by.
[cpg]

I kept hiding, thinking that it would be difficult to find the right moment.
[cpg]

I wanted to jump out right now, but I was patient.
[cpg]

If they find out I did this, I'll get away with it. They'll find out that all the pranks I've been up to are mine.
[cpg]

As I was thinking that, I heard Mikoto's voice.
[cpg]

[VOICE f="Mikoto093"]
[OnName num="mikoto"]
"Gusu, hiku, gusu!
[cpg cn=true]

Mikoto seems to be crying. Did I overdo it a little?
[cpg]

No, I couldn't think about whether I had gone too far or not.
[cpg]

If you think like that, you will never be able to do anything.
[cpg]

;@====================

[OnName num="ryo"]
Mikoto, are you okay?
[cpg cn=true]

;//移植のためシーンをカットしています

;//ブラックアウト
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

And then I ran up to her, and instead of asking me for help, she ran away.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Asuka068"]
[OnName num="asuka"]
I ran up to her and ran away without asking for my help.　You didn't show up for class.
[cpg cn=true]

[OnName num="ryo"]
I've been having a bit of ...... trouble."
[cpg cn=true]

Here, if I reacted that I didn't know anything, there would be another contradiction.
[cpg]

It's hard to make things add up. But it's what I did, so I have to take responsibility.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（夕方）******************************************************

In the end, Mikoto and I were not together on the way home.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Asuka069"]
[OnName num="asuka"]
"Mikoto, are you feeling down?
[cpg cn=true]

[OnName num="ryo"]
I heard you were involved in some ...... prank.
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Asuka070"]
[OnName num="asuka"]
I wonder if there are strange boys in the ...... school.
[cpg cn=true]

[OnName num="ryo"]
"Maybe."
[cpg cn=true]

I can't deny it. The actuality that you can't deny it, you can't deny it.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Asuka071"]
[OnName num="asuka"]
I'm sorry for Mikoto, whatever the case may be,.......
[cpg cn=true]

[OnName num="ryo"]
I'll go visit him sometime. Maybe I'll pay you a visit sometime."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]

Asuka nodded. And then,
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Asuka072"]
[OnName num="asuka"]
I'm going to go with you then.
[cpg cn=true]

I'll go with you. That would complicate things. ...... Well, that's okay.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************


And then Asuka and I walk back to the house together.
[cpg]

We're next door neighbors, so I'm going to have to follow her around here.
[cpg]

[OnName num="ryo"]
"See you later, Aska."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Asuka073"]
[OnName num="asuka"]
"Hi. Take care, Des.
[cpg cn=true]

[free time=1000]
[WAIT time=1000]
;//ブラックアウト

Mikoto, then Asuka. How many pranks have we played in total?
[cpg]

I remembered now that it was not a good idea to act too flamboyantly.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

I thought I would be careful about my behavior for a while.
[cpg]

I think it would be bad if they don't live a normal school life and occasionally play pranks on each other.
[cpg]

Mikoto was blatantly wary of me. And after what happened.
[cpg]

After what had happened, it was natural for him to be more cautious than necessary. If that's the case, I'm thinking that I should hold off a little longer with Yukiho-san.
[cpg]

I think Sachiho-san might be suspicious of Sachiho-san. ......
[cpg]

Somewhere along the line, something may have to change. Maybe I'll target one person.
[cpg]

With that thought in mind, I spent my days maturely for a while.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

The holidays come. I spend my days off appropriately.
[cpg]

Days where I don't do anything in particular, but lurk around with the goal of doing wet pranks.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

Then the holiday passes, and Monday ......
[cpg]

It's the day to meet Mikoto and Asuka. I was about to make my move.
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=3000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（朝）******************************************************

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mikoto105"]
[OnName num="mikoto"]
Good morning. Ryo.
[cpg cn=true]

[OnName num="ryo"]
Hey. Are you okay since then?
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Mikoto106"]
[OnName num="mikoto"]
I'm fine. You don't have to worry about me.
[cpg cn=true]

[OnName num="ryo"]
Are you sure about ......?　It was such a big deal.
[cpg cn=true]

Mikoto frowned in frustration.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Mikoto107"]
[OnName num="mikoto"]
The actuality is that you can't just go to the internet and get a new one. I'm sorry.
[cpg cn=true]

[OnName num="ryo"]
I'm sorry about ....... It's nothing.
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（朝）******************************************************


[FACE method="bow_1" pos="4/5"]
[VOICE f="Asuka074"]
[OnName num="asuka"]
Good morning, Death, you two.
[cpg cn=true]

[OnName num="ryo"]
Good morning.
[cpg cn=true]

Mikoto still has a difficult look on her face. I guess she is still in shock about what I did.
[cpg]

[FACE method="shake_1" pos="2/5"]
[VOICE f="Mikoto108"]
[OnName num="mikoto"]
Let's go to ......, we're going to be late.
[cpg cn=true]

[FACE method="bow_2" pos="4/5"]
[VOICE f="Asuka075"]
[OnName num="asuka"]
I'll be late. Shall we go?
[cpg cn=true]


;//ブラックアウト
;//========================================
;//●ＣＧ（機嫌良くお弁当を食べるヒロイン）ev_11
;//人物１：ヒロイン２
;//服装１：制服
;//場所　：学園教室
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_11_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


I ate lunch with Asuka.
[cpg]

;@=====================

[OnName num="ryo"]
"Itadakimasu."
[cpg cn=true]

I spread out the lunch box that my mother had made for me. Asuka does the same.
[cpg]

I looked into Asuka's lunch box and saw that it was a rather ordinary Japanese-style lunch box.
[cpg]

[VOICE f="Asuka076"]
[OnName num="asuka"]
Itadakimasu, desu.
[cpg cn=true]

[OnName num="ryo"]
I see you say both "itadakimasu" and "desu".
[cpg cn=true]

[VOICE f="Asuka077"]
[OnName num="asuka"]
That happens sometimes.
[cpg cn=true]

I ate lunch with Asuka, who seemed to be in a good mood.
[cpg]

The topic of conversation turned to the culprit of the recent prank.
[cpg]

;@=====================

[VOICE f="sAsuka001"]
[OnName num="asuka"]
But who is the culprit?
[cpg cn=true]


Innocent and unguarded. But I do care who the culprit is.
[cpg]

Which means I should probably be a little more careful.
[cpg]

Even with her personality, she's doing enough to make me care.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

Then after school. Me, Mikoto, and Asuka get ready to go home.
[cpg]


[FACE method="change_7" pos="2/5"]
[VOICE f="Mikoto054"]
[OnName num="mikoto"]
......"
[cpg cn=true]

Mikoto looks at me with a strange expression on her face.
[cpg]

[OnName num="ryo"]
"Hey, what's up ......?"
[cpg cn=true]

[FACE method="shake_3" pos="2/5"]
[VOICE f="Mikoto110"]
[OnName num="mikoto"]
No. If Ryo is doing it, it must be heartbreaking for you."
[cpg cn=true]

[OnName num="ryo"]
Are you doubting me?"
[cpg cn=true]

No, but it's a very honest guess.
[cpg]

Mikoto and Asuka play pranks on me, and every time they do, it's me who is nearby.
[cpg]

I think it would be weird not to be suspicious.
[cpg]

I think it's time to target one person or something.
[cpg]

[FACE method="bow_7" pos="2/5"]
[VOICE f="Mikoto111"]
[OnName num="mikoto"]
'Sorry if I offended you. You're right, ...... I don't have any proof, and I don't know anything about it."
[cpg cn=true]

[OnName num="ryo"]
'...... what?'
[cpg cn=true]

I'm trying to put on a bit of a mood, but I'm worried that I'm not putting on the right facade.
[cpg]

I wonder if they can see through this kind of act?　I knew I should have acted a little more carefully. ......
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="4/5" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（夕方）******************************************************


[FACE method="change_4" pos="4/5"]
[VOICE f="Asuka092"]
[OnName num="asuka"]
Mikomo and ...... that's what happened to you, Des?
[cpg cn=true]

Mikoto tells Asuka about the bucket incident sometime ago.
[cpg]

He tells her I was there.
[cpg]

[FACE method="bow_3" pos="2/5"]
[VOICE f="Mikoto112"]
[OnName num="mikoto"]
I think it's probably the same person who's been doing things to me and Asuka all this time.
[cpg cn=true]

[OnName num="ryo"]
Do you enjoy telling me such stories ......?"
[cpg cn=true]

I guess it's risky to have several people doing things at the same time.
[cpg]

They can narrow down the culprit from the common denominator. ......
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

From there, everyone was silent on the way home.
[cpg]

Both Miko and Asuka are probably beginning to suspect that I'm the culprit. I don't think they have any proof yet.
[cpg]

And as for me, I had no choice but to pretend to be grumpy.
[cpg]

This too would not last forever. I may have to do nothing from now on.
[cpg]

......No. It's impossible to do nothing when there's such a cute girl.
[cpg]

Just one of them. I want to see a wet and transparent girl.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************

But that plan is not going so well.
[cpg]

I can no longer move as boldly as before.
[cpg]

If I had to say so, I would say that I could still manage to do it with Yukiho.
[cpg]

On my way to school, I met Yukiho.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yukiho062"]
[OnName num="yukiho"]
"Good morning, Ryo-kun. Are you going to school now?"
[cpg cn=true]

[OnName num="ryo"]
No, the school starts at noon today. The school starts at noon today.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Yukiho063"]
[OnName num="yukiho"]
What?　Is there such a thing as noon school?
[cpg cn=true]

[OnName num="ryo"]
"There is ....... Recently.
[cpg cn=true]

It's a bit of a painful lie, I guess. But Sachio-san understood.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Yukiho064"]
[OnName num="yukiho"]
I understand. You want to talk to me today, don't you?"
[cpg cn=true]

I felt sorry that she understood me so well.
[cpg]


[OnName num="ryo"]
I'm sorry. May I ask you for a favor then?
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[OnName num="ryo"]
"So this is a continuation of our conversation about your love life the other day. Where were we?
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Yukiho065"]
[OnName num="yukiho"]
I don't care how far.　You're here to see me.
[cpg cn=true]

[OnName num="ryo"]
"You're here to see me." "......, after all, do you understand?"
[cpg cn=true]

;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（昼）******************************************************

Sachiho may be able to see through all of this. This is not a very good situation.
[cpg]

We really need to target one person and think about our actions.
[cpg]

If the situation continues as it is, I have a feeling that one day someone will report me.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]

By the time I got to the school, it was almost evening.
[cpg]

Classes were almost over and Mikoto and Asuka were worried about what I was doing.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="4/5" time=800]
[VOICE f="Mikoto114"]
[OnName num="mikoto"]
Did you catch a cold?　I can't believe you're coming to school so late.
[cpg cn=true]

[FACE method="bow_4" pos="4/5"]
[VOICE f="Asuka094"]
[OnName num="asuka"]
Yes, I'm worried about you.
[cpg cn=true]

[OnName num="ryo"]
'Oh ...... sorry. It's nothing.
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（夕方）******************************************************

The two were going to leave with me, but I asked them to leave first.
[cpg]

Somehow, I didn't feel like going home with those two.
[cpg]

I had to make my feelings clear.
[cpg]

I think. First, how to pull a wet prank on them.
[cpg]

;//■選択肢
[switch]
[case "Sneaking around behind my back."]
	[swap]
	[jump target="*select05_1"]
[case "Forcefully"]
	[swap]
	[jump target="*select05_2"]
[case "After we become lovers"]
	[swap]
	[jump target="*select05_3"]
[endswitch]

1, secretly and stealthily
2. forcefully
3. after becoming lovers

;//==============================
;//１、隠れてこっそり
*select05_1|Performing a prank

;//「こっそり」変数+1

[stflag flg_koso = 1]

After all, it is best to continue as before.
[cpg]

I don't have the mentality or the courage to do anything more than this.
[cpg]

If so, who should I target? ......
[cpg]

[jump target="*select05_4"]

;//==============================
;//２、強引に
*select05_2|Performing a prank

;//「無理矢理」変数+1

[stflag flg_muri = 1]

I want to do it, even if it's a bit forced.
[cpg]

I felt like I could clarify what was bothering me a little when I thought about it.
[cpg]

[jump target="*select05_4"]

;//==============================
;//３、恋人になってから
*select05_3|Performing a prank

;//「合意」変数+1

[stflag flg_goui = 1]

It's always best to do things consensually.
[cpg]

That is to say, a lover. That would accomplish all my goals.
[cpg]

And then I thought about who to set as my target.
[cpg]

;//==============================
*select05_4|Performing a prank

;//※ここまでの「こっそり」「無理矢理」「合意」変数で最も多いルートに分岐
;//※同値のものがある場合「こっそり」「無理矢理」「合意」の順で左にある物の方が優先される

;//※「こっそり」「無理矢理」「合意」のうち二種類と、ヒロイン三人の２×３で六種類に分岐
;//※「無理矢理」ルートになっている場合選択肢好捕にヒロイン１が現れない
;//※「こっそり」ルートになっている場合選択肢好捕にヒロイン２が現れない
;//※「合意」ルートになっている場合選択肢好捕にヒロイン３が現れない

[if exp={getFlagValue("flg_goui") >= 2 }]
[jump target="*select_goui"]
[endif]

[if exp={getFlagValue("flg_koso") >= 2 }]
[jump target="*select_koso"]
[endif]

[jump target="*select_muri"]

*select_goui|Performing a prank

[switch]
[case "Mikoto"]
	[swap]
	[jump target="*select06_1"]
[case "Asuka"]
	[swap]
	[jump target="*select06_2"]
[endswitch]


*select_koso|Performing a prank
[switch]
[case "Mikoto"]
	[swap]
	[jump target="*select06_1"]
[case "Koho"]
	[swap]
	[jump target="*select06_3"]
[endswitch]

*select_muri|Performing a prank
[switch]
[case "Asuka"]
	[swap]
	[jump target="*select06_2"]
[endswitch]

;//■選択肢
;//[switch]
;//[case "みこと"]
;//	[swap]
;//	[jump target="*select06_1"]
;//[case "アスカ"]
;//	[swap]
;//	[jump target="*select06_2"]
;//[case "幸穂"]
;//	[swap]
;//	[jump target="*select06_3"]
;//[endswitch]

1, Mikoto "secretly" "agreed
2, Asuka "forcibly" "agreement
3. Sachiho "secretly

*select06_1|Performing a prank
[jump storage="ep005.ks" target="*select06_1"]
*select06_2|Performing a prank
[jump storage="ep007.ks" target="*select06_2"]
*select06_3|Performing a prank
[jump storage="ep009.ks" target="*select06_3"]


[stflag flg_koso = 0]
[stflag flg_muri = 0]
[stflag flg_goui = 0]
