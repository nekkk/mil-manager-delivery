
;//以上、分岐後の選択肢で「３、合意」を選んでいた場合のみ進行　それ以外の場合はスキップ
;//==============================

;//==============================
;//３、幸穂
;//*select06_3|幸穂とは似た者同士

;//[if exp={getFlagValue("flg_koso") == 3 }]
;//[jump target="*root3_1"]
;//[endif]
;//[if exp={getFlagValue("flg_koso") == 2 }]
;//[jump target="*root3_1"]
;//[endif]

;//else それ以外なら
;//[jump target="*root3_2"]

;//==============================
;//「こっそり」ルートの場合

*start|Yukiho and I are like each other

;#################################################
*Ep009|Yukiho and I are like each other
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************

*select06_3|Yukiho and I are like each other

*root3_1|Yukiho and I are like each other

[SCENE id=9]

I've decided. I will focus on Sachiho-san as my target.
[cpg]

I thought I would do it secretly as before.
[cpg]

But I was not satisfied with that. I wanted to do something more drastic.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（昼）******************************************************

Then, on a holiday. I went to Yukiho's apartment.
[cpg]

;//========================================
;//●ＣＧ（洗濯物を干すヒロイン）ev_39
;//人物１：ヒロイン３
;//服装１：私服
;//場所　：アパート＿ベランダ
;//時間　：夕方
;//備考　：主人公の姿は映りません
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_39_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

She is beautiful today.
[cpg]

She has a smile on her face that makes me want to make her mine.
[cpg]

;//移植のためシーンをカットしています

From now on, let's target Yukiho-san and do a lot of things.
[cpg]

...... But even so, you're hanging your laundry out to dry very carefully.
[cpg]

He probably lives alone, so he must not have that much laundry.
[cpg]

However, she takes a long time to hang the laundry. I wonder if he is stretching out the wrinkles or something.
[cpg]

[VOICE f="Yukiho091"]
[OnName num="yukiho"]
I wonder if it's something like this: "....... The weather forecast says it's going to be fine.
[cpg cn=true]

Finally, I finished drying them. I waited for another chance.
[cpg]

But the chance of her going to sleep never came.
[cpg]

I gave up for today and decided to think about my next plan.
[cpg]

Next time I'm going to ....... I had been thinking about it for a while.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

The next day. Sunday. I was stalking Yukiho-san as she went out in the morning.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

It's hard to get a chance to see her everywhere I go on foot.
[cpg]

I was wondering if she was going through a public place.
[cpg]

He went into some restaurant for lunch, and I decided to watch him at the entrance.
[cpg]

[SE f="se046"]
;//【ＳＥ】『空腹でお腹が鳴る』
[WAIT time=1000]

My stomach is growling. Thinking I'm hungry ......, I wait for her.
[cpg]

Finally, Yukiho-san came out.
[cpg]

;//========================================
;//●ＣＧ（本屋で立ち読みしているヒロイン）ev_40
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：本屋
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_40_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//@
[VOICE f="Yukiho095"]
[OnName num="yukiho"]
"......"
[cpg cn=true]

There aren't that many pranks you can do in front of ...... people.
[cpg]

But there was a part of me that was intoxicated by the strangeness of what I was doing.
[cpg]

On second thought, I didn't need to prank her.
[cpg]

I just needed to be by her side, and that's all I ...... needed to do.
[cpg]

;@================

[VOICE f="Yukiho096"]
[OnName num="yukiho"]
......?"
[cpg cn=true]

She looked around. Did she notice me by any chance?
[cpg]

I'm in a place where ...... it's hard to see from the other side, so I guess that's too much to think about.
[cpg]

;@================

;//移植のためシーンをカットしています
;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（朝）******************************************************

The next day, the school day begins normally. I was smirking, wasn't I?
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto421"]
[OnName num="mikoto"]
"......What's wrong?　You look funny.
[cpg cn=true]

[OnName num="ryo"]
'A funny face is a greeting, .......'
[cpg cn=true]

But I must have looked weird. It couldn't be helped.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

On the way home from school. By coincidence or not, I ran into Yukiho again.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sYukiho004"]
[OnName num="yukiho"]
"Hello. Ryo-kun. Can I talk to you for a minute?"
[cpg cn=true]


[OnName num="ryo"]
......Yes, what is it?"
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]

What she said to me was something like this.
[cpg]

I went to a room in the apartment as I was told. And I was to hear the truth.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sYukiho005"]
[OnName num="yukiho"]
"You ...... were following me the other day, weren't you?"
[cpg cn=true]


[OnName num="ryo"]
"......, no."
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="sYukiho006"]
[OnName num="yukiho"]
"You don't have to hide it. I was happy."
[cpg cn=true]

She comes closer to me and says, "I've always been like you.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="sYukiho007"]
[OnName num="yukiho"]
I've always thought boys like you were cute.
[cpg cn=true]

As I listened to her story, it seemed that Ms. Yukiho had extraordinary feelings for me, if not a stalker.
[cpg]

[free time=300]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sYukiho008"]
[OnName num="yukiho"]
So, it's a double love."
[cpg cn=true]

Saying that, she forcefully took my lips.
[cpg]

;//========================================
;//●ＣＧ非エロ（キスをする二人。舌を絡め合う、互いに座っている状態）ev_41
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_41_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

We were not tied together.
[cpg]

I don't want to be your girlfriend.
[cpg]

If that's the case, I wonder what she thinks of me. Does Yukiho-san like me?
[cpg]

I don't know the answer to that question. Without knowing, we continued kissing.
[cpg]

;//ブラックアウト

Our relationship had become quite complicated. I'm more of a weirdo than a lover. ......
[cpg]

Love and weird are very similar as Chinese characters. They may be things that exist side by side.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

I went to Yukiho's place again today, wondering if we were on the "weird" side of the spectrum.
[cpg]

;//ＥＮＤ：ヒロイン３

[SCENE id=14]

[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
