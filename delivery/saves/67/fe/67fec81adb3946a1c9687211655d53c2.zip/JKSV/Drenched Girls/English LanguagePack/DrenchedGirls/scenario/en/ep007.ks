

;//以上、分岐後の選択肢で「３、合意の上で」を選んでいた場合のみ進行　それ以外の場合はスキップ

;//==============================

;//==============================
;//２、アスカ
*select06_2|Aska, the Torturer

[if exp={getFlagValue("flg_goui") == 2 }]
[jump storage="ep008.ks" target="*root2_2"]
[jump target="*root2_2"]
[endif]

;//==============================
;//「無理矢理」ルートの場合

*start|Asuka, the titillating Asuka

;#################################################
*Ep007|Asuka, the one who encourages cruelty
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************

*root2_1|Asuka, who incites lethargy

[SCENE id=7]

Asuka. Even if she becomes a little rough, I want to get close to her.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

I think about this as I make my way home. I've confessed to Asuka several times, it's hard to go out with her head-on.
[cpg]

If that's the case, it's better for me not to hit her head-on.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************

I was thinking about this on my way to school the next morning.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="ryo"]
Asuka, you know. I think she's a pushy one.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto385"]
[OnName num="mikoto"]
...... You're asking me something strange out of the blue. What is it?
[cpg cn=true]

Mikoto and I headed to the school. While there, I asked for some advice.
[cpg]

[OnName num="ryo"]
I wonder if that type of energetic person would break down if I pushed him.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Mikoto386"]
[OnName num="mikoto"]
Are you saying that you care about ...... Aska?　If so, please say so."
[cpg cn=true]

Then she said, "Yes, I guess so," and Mikoto thought about it.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Mikoto387"]
[OnName num="mikoto"]
I think he might be a little less susceptible to force than you might think. It's just my gut feeling.
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

Then at noon. I called out to Asuka.
[cpg]

I called her into an empty classroom.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Asuka119"]
[OnName num="asuka"]
"Uh, ......, what is it?　Why did you call me out of the blue?
[cpg cn=true]

[OnName num="ryo"]
"Oh, it's nothing. I have some other business to attend to.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Asuka120"]
[OnName num="asuka"]
"Another confession?　I already answered you before.
[cpg cn=true]

[OnName num="ryo"]
No, I'm not going to do that. No, I don't do such a complicated thing.
[cpg cn=true]

[free time=300]
[FG f="CHA02_p3_02_a.ui" method="change_5"  pos="2/3" time=800]

Saying this, I nipped at Asuka and cornered her against the wall.
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Asuka121"]
[OnName num="asuka"]
I'm close, I'm close, I'm close.
[cpg cn=true]

She didn't seem to mind.
[cpg]

I was so happy to see her.
[cpg]

I thought about it, but I couldn't muster up the courage to do so.
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通学路』（夕方）******************************************************

On the way home, I met Yukiho.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Yukiho080"]
[OnName num="yukiho"]
"Oh, Ryo-kun. Have you become a little more manly?"
[cpg cn=true]

That's how Yukiho sees me. I don't care what it is.
[cpg]

[OnName num="ryo"]
I'm not manly at all. I'm a coward.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Yukiho081"]
[OnName num="yukiho"]
What's wrong?　If you want to talk about it, I'm here to help.
[cpg cn=true]

Sachiho-san laughs like that, unaware of the horror of what I've done.
[cpg]

I was ...... wondering if I could continue doing this. I wondered if I could keep doing this.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥のさえずり』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************

But even after one night, I still can't come to a conclusion.
[cpg]

I think I should have at least tried to confess to him again, head-on.
[cpg]


;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************

But I can't back down now. I can't have a normal relationship with Asuka.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mikoto388"]
[OnName num="mikoto"]
"Good morning, I'm not with Asuka today. You're not with Asuka today, are you?
[cpg cn=true]

[OnName num="ryo"]
Yeah, well ......
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto389"]
[OnName num="mikoto"]
Did you get into a fight with ......?　Your face clouded over the moment I asked you, Asuka.
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

Classroom at noon. Asuka had come to the school, but her complexion was not good.
[cpg]

The last class of the morning was over and it was lunchtime.
[cpg]

[OnName num="ryo"]
Asuka. You're looking away from me, you're not very friendly.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="sAsuka002"]
[OnName num="asuka"]
"......"
[cpg cn=true]

He has a frightened look in his eyes. Being frightened like this makes my titillation grow.
[cpg]

;//移植のためシーンをカットしています

[FACE method="shake_4" pos="2/3"]
[VOICE f="Asuka161"]
[OnName num="asuka"]
Did I do something desu ...... to make Ling hate me?"
[cpg cn=true]

The conversation is not engaging. Well, I understand what Aska is trying to say.
[cpg]

[OnName num="ryo"]
"I'm not a changed man, I'm not a changed man."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

Asuka was aghast. After that, she seemed to understand the situation.
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Asuka162"]
[OnName num="asuka"]
"...... all was done by Ryo?"
[cpg cn=true]

[OnName num="ryo"]
Yes, that's right. The actuality is that the time has come for me to come. It's just that the time has come.
[cpg cn=true]



;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『通学路』（夕方）******************************************************

After all the classes, he was on his way home.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yukiho082"]
[OnName num="yukiho"]
"Oh, ...... Ryo-kun. We meet often.
[cpg cn=true]

[OnName num="ryo"]
I see you often. Are you on your way home from shopping?
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Yukiho083"]
[OnName num="yukiho"]
"Yes. Ryo-kun, you're on your way home from school, right?
[cpg cn=true]

[OnName num="ryo"]
Yes, well. Yes, well, students don't have anything else to do.
[cpg cn=true]

Sachiho laughs, saying, "I envy you. But ......
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Yukiho084"]
[OnName num="yukiho"]
'...... your face has changed. Ryo-kun,...... something, even a little scary."
[cpg cn=true]

[OnName num="ryo"]
Scary?　What?
[cpg cn=true]

Yukiho shook her head.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Yukiho085"]
[OnName num="yukiho"]
I can't say it well. No, it's nothing, don't worry about it."
[cpg cn=true]

I wonder if I've changed that much. ......
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『ドア開け』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]

The next day off. I was visiting Asuka's house.
[cpg]

;//【ＢＧ】『通学路』（朝）******************************************************

[FACE method="change_4" pos="2/3"]
[VOICE f="Asuka184"]
[OnName num="asuka"]
"Hey, what's up desu......?"
[cpg cn=true]

[OnName num="ryo"]
I'm not at my house today. Wanna come?
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Asuka185"]
[OnName num="asuka"]
Why do you have no reason to go to ......?
[cpg cn=true]

[OnName num="ryo"]
I don't need a reason to come."
[cpg cn=true]

Even if I push her a little, she doesn't mind.
[cpg]

She is rather scared and obeys me. I didn't think she was this type of person.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

And then she went to my room.
[cpg]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[OnName num="ryo"]
"You like comic books, don't you? If you ever come back, you can read whatever you want.
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Asuka187"]
[OnName num="asuka"]
...... Yes."
[cpg cn=true]

Asuka is depressed with a troubled look on her face.
[cpg]

Well, you can't try to get along now, can you?
[cpg]


;//ブラックアウト
;//========================================
;//●ＣＧ（嫌がるヒロインに近づく主人公）ev_29
;//人物１：ヒロイン２
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：主人公の家＿風呂場
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_29_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sAsuka003"]
[OnName num="asuka"]
Kya ......."
[cpg cn=true]

When you get up close, she is really beautiful.
[cpg]

And it's honest, I can say it's my favorite in every way.
[cpg]

I don't want to be pranked any more, so I'm obeying me. ......
[cpg]

;@=================

[OnName num="ryo"]
I'm surprised you don't mind me coming this close.
[cpg cn=true]

[VOICE f="Asuka160"]
[OnName num="asuka"]
'Well, that's ......
[cpg cn=true]


;@=================

;//移植のためシーンをカットしています

;//ブラックアウト
;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
;//[BG f="b_05_3.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

;//上の空のアスカが、ここまでになって、俺に抵抗したり誰かに相談したりしないというのは……
The fact that Asuka, after getting this far, doesn't resist me or talk to anyone about it is ......
[cpg]

Is he afraid of me? Or is it because he likes me?
[cpg]

I can only imagine. I have no control over that.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『通学路』（夕方）******************************************************

[OnName num="ryo"]
I'll see you later. See you at school.
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Asuka207"]
[OnName num="asuka"]
...... then.
[cpg cn=true]

Asuka returned to her house without making eye contact with me.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『通学路』（朝）******************************************************

Then the next weekday. I headed to the school with Mikoto.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Mikoto390"]
[OnName num="mikoto"]
I went to the school with Mikoto. "......Asuka has been acting strange lately, hasn't she?
[cpg cn=true]

[OnName num="ryo"]
"Really?　Same as usual."
[cpg cn=true]

I tried to make things right by saying that, but it had the opposite effect.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Mikoto391"]
[OnName num="mikoto"]
Does that look normal to you?　It's obviously weakened."
[cpg cn=true]

Yes, it is. I don't know why, but I can tell it's getting weaker, or at least that's what I should have replied.
[cpg]

[OnName num="ryo"]
Speaking of which, it certainly ...... seems like that might be the case.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mikoto392"]
[OnName num="mikoto"]
'You and Asuka seem to be together a lot. And yet you don't notice it?"
[cpg cn=true]

Mikoto is blatantly suspicious. I was at a loss for a response.
[cpg]

[OnName num="ryo"]
I was at a loss for an answer. "I don't notice ...... the more time we spend together.
[cpg cn=true]

Mikoto is staring at me. Mikoto and Asuka are good friends.
[cpg]

I think she might be in a position to not allow anything to happen to her.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（昼）******************************************************

Asuka came to the school quite late.
[cpg]

The morning classes were about to end.
[cpg]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p3_02_a.ui" method="change_4"  pos="2/3" time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（夕方）******************************************************

;//ブラックアウト

I called her to the back of the school and let her stay by my side as usual.
[cpg]

I have already proven that I can be a little pushy ......
[cpg]

But there was something a little unexpected.
[cpg]


;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

;//昼休み、おれはみことに話しかけられた。
On another day at lunchtime, Mikoto spoke to me.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Mikoto393"]
[OnName num="mikoto"]
"Excuse me, can I ask you something?　I have a question.
[cpg cn=true]

Mikoto held her phone in her hand and showed me the image.
[cpg]

Obviously, Asuka's expression of disapproval was on the screen.
[cpg]

[OnName num="ryo"]
'Oh, you .......'
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Mikoto394"]
[OnName num="mikoto"]
'With so many people around, you can't even threaten me, can you?
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Mikoto395"]
[OnName num="mikoto"]
'Besides, I have this video on my computer at home. You know what will happen if you don't obey me.
[cpg cn=true]

I understood that I was in the position to be threatened.
[cpg]

[OnName num="ryo"]
'Wait ...... what's the use of doing this, you have nothing to gain.
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Mikoto396"]
[OnName num="mikoto"]
Asuka is my friend. Besides, I don't usually see the benefit in helping a girl in trouble."
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="4/5" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園外観』（夕方）******************************************************

And then, after school. We were going home, me, Mikoto, and Asuka, a strange combination.
[cpg]

[FACE method="shake_4" pos="4/5"]
[VOICE f="sAsuka004"]
[OnName num="asuka"]
The actual "Death ......?　The proof, the pictures.
[cpg cn=true]

[FACE method="bow_2" pos="2/5"]
[VOICE f="Mikoto397"]
[OnName num="mikoto"]
Yes, to help Asuka. I did it to save Asuka.
[cpg cn=true]

The two of us were having such a conversation. I couldn't disobey Mikoto's instruction.
[cpg]

[SE f="se019"]
;//【ＳＥ】『ドア開け』

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[VOICE f="Mikoto398"]
[OnName num="mikoto"]
I'm home.
[cpg cn=true]

[VOICE f="Asuka227"]
[OnName num="asuka"]
Ojamashimasu desu ......"
[cpg cn=true]

And for some reason, I was sent to Mikoto's room.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="4/5" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************

[FACE method="shake_7" pos="2/5"]
[VOICE f="Mikoto399"]
[OnName num="mikoto"]
I was so excited to see him, but I didn't know what to expect.
[cpg cn=true]

[OnName num="ryo"]
Why, you don't ...... know that much.
[cpg cn=true]

[FACE method="shake_3" pos="2/5"]
[VOICE f="Mikoto400"]
[OnName num="mikoto"]
What do you mean by "that far"?　What do you mean by "that far"?
[cpg cn=true]

Oh no. I slipped up. It's like I'm saying I did it.
[cpg]

I should have acted like I didn't know about the prank.
[cpg]

[FACE method="change_3" pos="2/5"]
[VOICE f="Mikoto401"]
[OnName num="mikoto"]
You can't get away with it now, Ryo.
[cpg cn=true]

;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト

[free time=300]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p3_02_a.ui" method="change_4"  pos="4/5" time=800]
[WAIT time=1000]

Thus, my love ended.
[cpg]

I could have had a different relationship with Asuka, too: ......
[cpg]

;//ＥＮＤ：ヒロイン２ルート１

[SCENE id=12]

[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
