;//２回目　日常イベント
;//日常イベントはキャラ共通です。どのヒロインのＨシーンに行くかはフラグにより変化します
*start|Socializing as much as humanly possible

;#################################################
*Ep005|Socializing as much as humanly possible
;#################################################

*day01_after|Socializing as much as humanly possible
*day02|Socializing as much as humanly possible

[SCENE id=5]

[stflag DAY_2 = 1]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

Even if you just stand around in a daze, you can still see the girls just by being in the classroom.
[cpg]

[OnName num="norio"]
I'll go to ...... and say, "Oh."
[cpg cn=true]

Would I be able to have a social life like other people?
[cpg]

[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*day02_1"]
[endif]


[switch]
[case "Airi"]
	[swap]
	[jump target="*day02_1"]
[case "Tsugumi"]
	[swap]
	[jump target="*day02_2"]
[case "Minami"]
	[swap]
	[jump target="*day02_3"]
[endswitch]

;//■選択肢
Airi
Tsugumi
3, Minami

;//※２，３は参戦していたら
;//選択が発生しない場合はそのヒロインの方へ

;//*day02_1|人並みのお付き合い
;//[jump target="*airi_date"]
;//*day02_2|人並みのお付き合い
;//[jump target="*tugumi_date"]
;//*day02_3|人並みのお付き合い
;//[jump target="*minami_date"]



;//ＢＫ

;//////////////////////////////////////////////////////////////////////
;//愛莉パターン
*day02_1|Socializing as much as humanly possible

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Airi129"]
[OnName num="airi"]
"Hey!
[cpg cn=true]


[OnName num="norio"]
"Whoa! Sasamiya?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sAiri007"]
[OnName num="airi"]
I was chasing another girl with my eyes.
[cpg cn=true]


[OnName num="norio"]
I'm sorry.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sAiri008"]
[OnName num="airi"]
You can only look at me now.
[cpg cn=true]

;//ＢＫ
[jump target="*airi_date"]
;//////////////////////////////////////////////////////////////////////
;//つぐみパターン
*day02_2|Socializing as much as humanly possible

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[FACE method="change_3" pos="2/3"]
[VOICE f="Tugumi070"]
[OnName num="tugumi"]
Hey, Butabara-kun.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi071"]
[OnName num="tugumi"]
What are you sneaking around for? You're not exactly a stranger to the world.
[cpg cn=true]


[OnName num="norio"]
Oh, really?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sTugumi005"]
[OnName num="tugumi"]
I wish you'd be more confident. That's what I'm trying to do.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sTugumi006"]
[OnName num="tugumi"]
So, you'd better build up your confidence.
[cpg cn=true]


[jump target="*tugumi_date"]
;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//サブヒロイン、デート前の部分　分岐以後
;///////////////////////////////////////
;//シナリオ調整で２日目の選択肢の直後に移動
*day02_3|Socializing as much as humanly possible

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

After signing the contract. I started to care about her all the time.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sMinami010"]
[OnName num="minami"]
What's wrong?　Do you care that much?"
[cpg cn=true]

Minami calls out to me. I can't answer that I am.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Minami040"]
[OnName num="minami"]
She was staring at me in class, wasn't she? Your gaze is really hot.
[cpg cn=true]

[OnName num="norio"]
I can't deny it.
[cpg cn=true]

I can't deny it. I can't answer. I can't help it.
[cpg]

I couldn't say anything, and when I froze, I ......
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sMinami011"]
[OnName num="minami"]
He laughed and said, "You're really cute!"
[cpg cn=true]

He laughed at me.
[cpg]

[jump target="*minami_date"]

;//ヒロイン１へ
;//ヒロイン２へ


*airi_date|Socializing as much as humanly possible
[jump storage="ep008.ks" target="*airi_date"]
*tugumi_date|Socializing as much as humanly possible
[jump storage="ep010.ks" target="*tugumi_date"]
*minami_date|Socializing as much as humanly possible
[jump storage="ep012.ks" target="*minami_date"]


;//////////////////////////////////////////////////////////////////////
;//サブヒロイン参戦
;//日常イベントの２回目と３回目の間に入ります
;//※※調整の関係上１日目から参戦するために上に移動※※

;//////////////////////////////////////////////////////////////////////
;//デートシーン　愛莉
;//日常イベントの２回目と三回目の間に入ります
;//※※シナリオの調整の関係でデートシーンの差分に使用※※

;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
