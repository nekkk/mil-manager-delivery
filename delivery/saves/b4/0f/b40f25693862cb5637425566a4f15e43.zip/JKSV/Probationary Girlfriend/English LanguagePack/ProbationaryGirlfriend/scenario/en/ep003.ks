;//サブヒロイン参戦
;//日常イベントの２回目と３回目の間に入ります
;//調整の関係上１日目から参戦

;//※サブは言葉遣いとかたまに崩したりするがあくまで普通。イマドキっぽい喋り方はする。
;//ギャルなので主導権はだいたいサブ。サブが手を引いて主人公を引っ張っていく
*start|Minami says hello

;#################################################
*Ep003|Minami says hello
;#################################################

[SCENE id=3]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************

;//@
It was the day after that thing happened.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Minami002"]
[OnName num="minami"]
Oh, Boo-chan. Hi."
[cpg cn=true]

;//@
Her name is Minami Akazawa.
[cpg]

;//@
She was one of the gals who teased me by calling me Boo-chan.
[cpg]

;//@
Boo-chan ...... I honestly don't like this nickname.
[cpg]

[OnName num="norio"]
......"
[cpg cn=true]

[free time=300]
[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Minami003"]
[OnName num="minami"]
Good morning.
[cpg cn=true]

[OnName num="norio"]
......, "Oh, hey."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

;//@
I don't know why, but she greets me.
[cpg]

;//※たまにだが朝挨拶される。主人公は無言か、少し反応。
;//ブーちゃんは愛称だが主人公は馬鹿にされてると思ってる。
;//サブ達ギャルは友好的なものとしての行為。悪気はまったくない。
;//豚で不細工とか合わせてると周りのモブが言ってるので。


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（夕方）******************************************************
;//【ＢＧ】『学園教室』（夕方）

[OnName num="norio"]
"Oh..."
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Minami004"]
[OnName num="minami"]
Hmm? Oh, it's Boo. Are you home?"
[cpg cn=true]

[OnName num="norio"]
"Uh, yeah..."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Minami005"]
[OnName num="minami"]
See you tomorrow.
[cpg cn=true]

[OnName num="norio"]
Bye.
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

Another day.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Minami006"]
[OnName num="minami"]
"Do you know much about anime, Boo?"
[cpg cn=true]

[OnName num="norio"]
Why?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Minami007"]
[OnName num="minami"]
"What? Because you're an otaku, right, Boo?
[cpg cn=true]

[OnName num="norio"]
"Yeah, but... no, I was just wondering how you know so much."
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Minami008"]
[OnName num="minami"]
I was studying for an exam the other day, and I was surprised to see a cartoon on.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Minami009"]
[OnName num="minami"]
I didn't know they were showing cartoons that late at night.
[cpg cn=true]

[OnName num="norio"]
I was surprised to see anime on at that time of the night. There are a lot of late-night cartoons.
[cpg cn=true]

[OnName num="norio"]
I'm going to study for my exams..."
[cpg cn=true]

You're serious even though you're a gal?
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Minami010"]
[OnName num="minami"]
What? Even gals study. I don't think you're prejudiced.
[cpg cn=true]

That wasn't prejudice against nerds...no, it wasn't prejudice.
[cpg]

[FACE method="change_1" pos="2/3"]

She is the one who can talk to me without prejudice, and she is a valuable person.
[cpg]


;//ヒロイン２と仮恋契約をしていない場合はそのまま次の日常パートへ
;//////////////////////////////////////////////////////////////////////
[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*day01"]
[endif]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

I've made a temporary love contract with both of them.
[cpg]

;//@
;//もう後には引けない……そんな気分でいると……
I can't back out now. ......
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMinami001"]
[OnName num="minami"]
I heard that you signed a temporary love contract. I heard you signed a temporary love contract?"
[cpg cn=true]

[OnName num="norio"]
I reacted more than I should have, and I was surprised to hear from whom. ......
[cpg cn=true]

I reacted more than I should have and became suspicious.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="sMinami002"]
[OnName num="minami"]
It doesn't matter who you start with. More importantly, you mean you like the girl?
[cpg cn=true]

When you ask me that, the truth is that I'm not really feeling it either,.......
[cpg]

[OnName num="norio"]
......"
[cpg cn=true]

When I was at a loss for an answer, she said, "I see.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Minami013"]
[OnName num="minami"]
I see. I'm going to miss you.
[cpg cn=true]

Miss me?　What do you mean?
[cpg]

She didn't want to sign a temporary love contract with me, did she?
[cpg]

[OnName num="norio"]
What do you mean ......?"
[cpg cn=true]

Minami says, "It's nothing. What does it really mean?
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Minami014"]
[OnName num="minami"]
You know what, Boo. Aren't you going to do it with me too?
[cpg cn=true]

[OnName num="norio"]
What do you mean, "do" ......?
[cpg cn=true]

I don't think so. I don't think she's going to say anything about it.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sMinami003"]
[OnName num="minami"]
I don't know.　I don't know. It's a temporary love contract."
[cpg cn=true]

No way. What was this all about?
[cpg]

What is it about me that makes me so attractive?
[cpg]

[OnName num="norio"]
I'm not kidding. ......?　You're teasing me like that again. ......
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Minami016"]
[OnName num="minami"]
"Yeah, I'm kidding. I'm kidding.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I knew it. I knew it was something like that.
[cpg]

Don't be fooled, it's not that easy to be liked by girls.
[cpg]

And they say there are a few periods in your life when you're popular, but I'm not one of them.
[cpg]

I'm not fooled. I am not that flirtatious.
[cpg]

In fact, I'm not so flirtatious as to be sneaky. ......
[cpg]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

;//@
I didn't realize it at the time, but I think she added this at the end of her words
[cpg]

;//@
Now I'm .......
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

But then I try to take a class, and I somehow find myself thinking about Minami.
[cpg]

I can't help but stare at the back of her head.
[cpg]

I can't help but look at her like that. ...... I wonder why.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

Otaku and gyaru. Two of the most distant beings in the world.
[cpg]

It's no surprise, but Minami and I weren't always close.
[cpg]

But she talked to me once in a while. I don't have a bad impression of her.
[cpg]

Rather, I have a good impression of her, or rather, I don't feel scared of her among the gals. ......
[cpg]

Anyway, I was becoming strangely interested in her.
[cpg]

;//[SE f="se001"]
;//【ＳＥ】『学園のチャイム』
;//[WAIT time=1000]

In the meantime, the time was after school.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

Among the group of gals talking, Minami was there.
[cpg]

She is different from me. I felt that she was glancing at me.
[cpg]

I hurriedly look away. Then, I get ready to go home.
[cpg]

[FACE method="change_7" pos="2/3"]

The group of gals leaves, and for some reason, Minami is the only one left looking at me.
[cpg]

I'm stumped. I don't know how to react when they do this to me.
[cpg]

Is she telling me to talk to her? If I make a wrong decision here, I will be made fun of again.
[cpg]

I have many scars in my memory of being made fun of by girls like that.
[cpg]

But the other day's talk about signing a contract was a good opportunity to talk to her, wasn't it?
[cpg]

In the end she said it was just a joke, but I could check to see if she was really joking.
[cpg]

[OnName num="norio"]
'Oh, um, um, ...... Minami-san.'
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Minami017"]
[OnName num="minami"]
You said, "Um," twice. Don't be so nervous.
[cpg cn=true]

[OnName num="norio"]
Yes, yes!
[cpg cn=true]

I replied in a strangely cheerful way.
[cpg]


;//ＢＫ
[FACE method="change_1" pos="2/3"]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I talked with her for a while.
[cpg]

Then I got the impression that she was a good girl.
[cpg]

It might be rude to say that she is a good girl ...... even though she is a gal, but she is a good girl.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Minami018"]
[OnName num="minami"]
She said, "I don't know much about anime at all. I mean, I don't know much about it.
[cpg cn=true]

[OnName num="norio"]
It's a waste of time. Many girls watch anime nowadays.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Minami019"]
[OnName num="minami"]
"Oh, yes, there are. "Oh, yes, they do.　They are enjoying their lives in their own way.
[cpg cn=true]

At times like this, I don't make fun of otaku girls.
[cpg]


It's the little things that show her kindness.
[cpg]

[OnName num="norio"]
There is an anime that I also watch that has a one-to-one male-to-female character ratio, so why don't you watch it, too?
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Minami020"]
[OnName num="minami"]
She laughs and says, "Hahaha, you're talking so fast all of a sudden, creepy!"
[cpg cn=true]

I was a bit embarrassed. I was a little shaken,
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sMinami004"]
[OnName num="minami"]
But your enthusiasm is amazing, isn't it? I'm only passionate about love.
[cpg cn=true]

He follows up with a smile.
[cpg]

I can tell she doesn't despise me. She is just cheerful and honest with herself.
[cpg]

The complete opposite of me. If I am a deep-sea fish at the bottom of the ocean, she is like a bird flying in the sky.
[cpg]

That's why I envy her. I am attracted to her because I envy her.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]

And this happened another day. It happened during my lunch break.
[cpg]

;//【ＢＧ】『学園教室』（昼）******************************************************

[FO pos="4/7" time=1000]

[FACE method="change_7" pos="2/3"]
[VOICE f="Minami022"]
[OnName num="minami"]
She was lying on her back. You're going to get hunched over if you keep doing that when there's nothing to do."
[cpg cn=true]

During lunch break, I had nothing to do, so I just sat there.
[cpg]

[OnName num="norio"]
I was bored at lunchtime and had nothing to do, so I just sat there. I'm ......
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Minami023"]
[OnName num="minami"]
Don't say, "I'm nothing. Aren't you sure of yourself?
[cpg cn=true]

I think she said it casually. I think she said it casually, but it stuck deeply in my mind.
[cpg]

[OnName num="norio"]
She said, "I don't have ...... confidence. Really, I have none at all.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
Then I turn over once more. Minami says to me, "That's not a good idea.
[cpg]


[free time=300]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Minami024"]
[OnName num="minami"]
All right. Okay, here's what we'll do. Follow me.
[cpg cn=true]

And then she tries to take me out somewhere.
[cpg]

I didn't have to go along with her, but I was attracted to her, so I went along.
[cpg]

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

She took me to an empty classroom. And then she said something outrageous.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sMinami005"]
[OnName num="minami"]
Hey, will you go on a date with me, too?
[cpg cn=true]


[OnName num="norio"]
What do you mean by a date?
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="sMinami006"]
[OnName num="minami"]
She said, "I don't mean it as a metaphor or anything. I mean it as it is.
[cpg cn=true]


I mean it as it is. If that's the case, I think it's a problem.
[cpg]

Does she say this to everyone?
[cpg]

If not, I can't help but be attracted to her. ......
[cpg]

;//@
[OnName num="norio"]
I'm looking forward to working with you...please.........
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

Thus, I have also made a tentative love contract with Minami: ......
[cpg]

;//１日目へ
;//ヒロイン１へ
;//ヒロイン２へ

*day01|Minami says hello
[jump storage="ep004.ks" target="*day01"]

;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
