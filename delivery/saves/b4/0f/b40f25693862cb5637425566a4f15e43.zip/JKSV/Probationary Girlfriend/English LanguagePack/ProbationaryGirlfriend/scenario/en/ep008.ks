;//愛莉　デートシーン
*airi_date|Date with Airi

[stflag Cha1cnt = 1]

[if exp={getFlagValue("Cha1cnt") == 4 }]
[jump target="*airi_date04"]
[endif]
[if exp={getFlagValue("Cha1cnt") == 3 }]
[jump target="*airi_date03"]
[endif]
[if exp={getFlagValue("Cha1cnt") == 2 }]
[jump target="*airi_date02"]
[endif]

;//[if exp={getFlagValue("Cha1cnt") == 1 }]
;//[jump target="*airi_date01"]
;//[endif]


;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//デートパターン１（ヒロイン１）
;///////////////////////////////////////

*airi_date01|Date with Airi

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）

[FACE method="change_2" pos="2/3"]
[VOICE f="Airi173"]
[OnName num="airi"]
I'm sorry to bother you. This is Norio-kun's room.
[cpg cn=true]

[FACE method="shock_6" pos="2/3"]
[VOICE f="sAiri014"]
[OnName num="airi"]
Oh, I'm sorry. It's rare to see a boy's room. ......"
[cpg cn=true]

She approached me, saying, "I'm sorry.
[cpg]

;//========================================
;//●ＣＧ（主人公に密着するヒロイン）ev_04
;//人物１：ヒロイン１
;//服装１：制服
;//人物３：主人公
;//服装３：制服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_04_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[OnName num="norio"]
I said, "Chi, you're so close.
[cpg cn=true]

But she didn't move away from me.
[cpg]

[VOICE f="sAiri015"]
[OnName num="airi"]
No, you can't look away.
[cpg cn=true]


[VOICE f="sAiri016"]
[OnName num="airi"]
I'm doing this so I can be a girl."
[cpg cn=true]


But I couldn't look directly at her.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）

;//@
[FACE method="change_2" pos="2/3"]
[VOICE f="Airi9416"]
[OnName num="airi"]
"Hmmm... she was cute. She was cute.
[cpg cn=true]

;//@
[OnName num="norio"]
Don't say that. ......
[cpg cn=true]

;//@
I wonder if I can get used to girls at this rate. ......
[cpg]


[jump target="*date_after"]
;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//デートパターン２（ヒロイン１）
;///////////////////////////////////////
*airi_date02|Date with Airi

;//[stflag Cha1cnt = 1]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）

I was in an unused classroom with Sasamiya-san.
[cpg]

[free time=300]
;//@
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Airi9195"]
[OnName num="airi"]
What do you want to do today?"
[cpg cn=true]

;//@
Sasamiya-san approached me and tried to hold my hand.
[cpg]

;//@
I reflexively tried to move away, but she came even closer.
[cpg]

;//========================================
;//●ＣＧ（前のめりで主人公に近づく）ev_05
;//人物１：ヒロイン１
;//服装１：制服
;//人物３：主人公
;//服装３：制服
;//場所　：学園教室
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_05_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

[VOICE f="sAiri017"]
[OnName num="airi"]
Or maybe you wouldn't mind if I got closer to you either?"
[cpg cn=true]


She said this and came so close to me that our chests were almost touching.
[cpg]

[OnName num="norio"]
I don't mind," she said.
[cpg cn=true]


I was finally able to say something like that.
[cpg]

I guess this at least is a little progress.
[cpg]


;//ＢＫ

[jump target="*date_after"]
;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//デートパターン３（ヒロイン１）
;///////////////////////////////////////
*airi_date03|The reason why Airi signed the contract.

;//デートシーン　愛莉　の理由
;//日常イベントの２回目と三回目の間に入ります
;//シナリオの調整の関係でデートシーンの差分に使用


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="bg_ed"]
[WAIT time=1000]
;//【ＢＧ】『街』（昼）******************************************************

;//========================================
;//●ＣＧ（女の子に慣れる為にデート。手を繋いで街を歩く姿）ev_13
;//人物１：ヒロイン１
;//服装１：私服
;//人物３：主人公
;//服装３：私服
;//場所　：街
;//時間　：昼
;//========================================

[window target=false]
;**【ＣＧ】 ev_13_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="Airi138"]
[OnName num="airi"]
I'm not averse to it. I'm nervous? Are you nervous?
[cpg cn=true]

[VOICE f="Airi139"]
[OnName num="airi"]
"It's a date, you have to have fun.
[cpg cn=true]

[OnName num="norio"]
"Uh-huh."
[cpg cn=true]

[VOICE f="Airi140"]
[OnName num="airi"]
Norio, do you have a place you want to go?
[cpg cn=true]

[OnName num="norio"]
Well...
[cpg cn=true]

[VOICE f="Airi141"]
[OnName num="airi"]
How about the arcade?
[cpg cn=true]

[OnName num="norio"]
Yeah, sure.
[cpg cn=true]

[VOICE f="Airi142"]
[OnName num="airi"]
Okay. Okay, let's go.
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

;//【ＢＧ】『街』（昼）******************************************************

;//CG再び表示
;**【ＣＧ】 ev_13_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[OnName num="norio"]
Are you having fun doing this with me?
[cpg cn=true]

[VOICE f="Airi143"]
[OnName num="airi"]
"Yes, it's fun. Why do you say that?
[cpg cn=true]

[OnName num="norio"]
"Because you're so unattractive and ...... ugly."
[cpg cn=true]

I think it's even more so when I see couples and such around me.
[cpg]

[VOICE f="Airi144"]
[OnName num="airi"]
Norio-kun, you worry too much about such things. A man is not his face.
[cpg cn=true]

[OnName num="norio"]
Is that so?
[cpg cn=true]

[VOICE f="Airi145"]
[OnName num="airi"]
â Money ♪
[cpg cn=true]

[OnName num="norio"]
What?
[cpg cn=true]

[VOICE f="Airi146"]
[OnName num="airi"]
Just kidding. Well, from a practical point of view, money is important...
[cpg cn=true]

[VOICE f="sAiri009"]
[OnName num="airi"]
Well...for me, I guess. Personality.
[cpg cn=true]

[OnName num="norio"]
Personality?
[cpg cn=true]

[VOICE f="sAiri010"]
[OnName num="airi"]
Yeah, I know. I've seen faces every day, and they're all the same.
[cpg cn=true]

[VOICE f="sAiri011"]
[OnName num="airi"]
But personality, you never get tired of it or get used to it.
[cpg cn=true]

......You may have a point.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi152"]
[OnName num="airi"]
Oh, it's already this late. Shall we go home soon?
[cpg cn=true]

[OnName num="norio"]
Yes.
[cpg cn=true]

But why does she do this?
[cpg]

I wanted to ask her why she was doing this to me.
[cpg]

[OnName num="norio"]
Can I ask you something?
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Airi153"]
[OnName num="airi"]
Anything.
[cpg cn=true]

[OnName num="norio"]
Why would you make a temporary love contract with me? Me.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi154"]
[OnName num="airi"]
That's a tough question. Well...to put it simply, because I felt something for Norio-kun.
[cpg cn=true]

[OnName num="norio"]
Norio-kun?
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Airi155"]
[OnName num="airi"]
I thought he was just like me. I think that's why I couldn't leave it alone.
[cpg cn=true]

Me and her? There is no similarity between us.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Airi156"]
[OnName num="airi"]
I wasn't always like her, you know.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi157"]
[OnName num="airi"]
I was shy, always alone. I thought the world would die.
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Airi158"]
[OnName num="airi"]
But I was afraid to stay that way, so I had to change.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sAiri012"]
[OnName num="airi"]
"I'm sorry, ....... It's not what you think it is, is it?
[cpg cn=true]

[OnName num="norio"]
I don't think so.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Airi162"]
[OnName num="airi"]
I'm not. I'm sure Norio-kun is very kind.
[cpg cn=true]

You are definitely kinder than me.
[cpg]

[jump target="*date_after"]
;//[jump target="*day03"]

;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//デートパターン４（ヒロイン１）
;///////////////////////////////////////
*airi_date04|Date with Airi
;//[stflag Cha1cnt = 1]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;//【ＢＧ】『学園教室』（夕方）

;//========================================
;//●ＣＧ（主人公が、ヒロインに近づく）ev_17
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================

[BGM f="bg_h2"]
[WAIT time=100]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sAiri018"]
[OnName num="airi"]
"Ah..."
[cpg cn=true]

I was so excited during the date that I couldn't help but press her.
[cpg]

However, there is nothing more that can be done.
[cpg]

[VOICE f="sAiri019"]
[OnName num="airi"]
I'm glad you're being so aggressive. I'm glad you're being so aggressive.
[cpg cn=true]


[VOICE f="sAiri020"]
[OnName num="airi"]
What shall we do now, ......?"
[cpg cn=true]


...I wish I could at least kiss you here.
[cpg]


;//移植のためシーンをカットしています

[jump target="*date_after"]
;//////////////////////////////////////////////////////////////////////
*date_after


[stflag DAY_1 = 0]
[stflag DAY_2 = 0]
[stflag DAY_3 = 0]
[stflag DAY_4 = 0]
[stflag DAY_5 = 0]
[stflag DAY_6 = 0]

;//[if exp={getFlagValue("DAY_6") == 1 }]
;//[jump target="*rast_sel"]
;//[endif]
;//[if exp={getFlagValue("DAY_5") == 1 }]
;//[jump target="*day05_after"]
;//[endif]

;//シナリオ調整で４日目が終わるとどのヒロインを選ぶかの選択肢へ
[if exp={getFlagValue("DAY_4") == 1 }]
;//[jump target="*rast_sel"]
;//[jump target="*day04_after"]
[jump storage="ep007.ks" target="*rast_sel"]
[endif]

[if exp={getFlagValue("DAY_3") == 1 }]
;//[jump target="*day03_after"]
[jump storage="ep006.ks" target="*day03_after"]
[endif]

[if exp={getFlagValue("DAY_2") == 1 }]
;//[jump target="*day02_after"]
[jump storage="ep006.ks" target="*day02_after"]
[endif]

;//[jump target="*day01_after"]
[jump storage="ep005.ks" target="*day01_after"]

;//[if exp={getFlagValue("DAY_1") == 1 }]
;//[jump target="*day01_after"]
;//[endif]


;////////////////////////////////////////////////////////////////////////////////////////
;////////////////////////////////////////////////////////////////////////////////////////
;////////////////////////////////////////////////////////////////////////////////////////
;//最後のデートへの分岐条件『愛莉』
;//愛莉との最後のデートになった場合、最終分岐の選択肢の後に表示
*root_1|My last date with Airi

;#################################################
*EpRoot001|My last date with Airi
;#################################################


;//ＢＫ
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

Well, the last date of the contract is already approaching.
[cpg]

What kind of date shall we make?
[cpg]


[switch]
[case "I want to have the same date as before."]
	[swap]
	[stflag Last_root = 1]
[case "I want to make memories at the school."]
	[swap]
	[stflag Last_root = 2]
[endswitch]


;//++++++++++++++++++++++++++++++++++++++
;//■選択肢
;//１、今まで通りのデートがしたい
;//２、学園で思い出を作りたい
;//++++++++++++++++++++++++++++++++++++++


;//選択後の文章。共通

[OnName num="norio"]
Yes, I want to make memories. Okay, let's do that."
[cpg cn=true]


I think this is what we want to do.
[cpg]

I'm suddenly looking forward to it.
[cpg]


[if exp={getFlagValue("Last_root") == 1 }]
[jump target="*airi_last_date1"]
[endif]

[jump target="*airi_last_date2"]

;//[if exp={getFlagValue("Last_root") == 2 }]
;//[jump target="*airi_last_date2"]
;//[endif]

;//*airi_last_date1|愛莉との最後のデート
;//[jump storage="ep000.ks" target="*airi_last_date1"]
;//*airi_last_date2|愛莉との最後のデート
;//[jump storage="ep000.ks" target="*airi_last_date2"]




;//各筆下ろしのシーンへ
;////////////////////////////////////////////////////////////////////////////////////////
;////////////////////////////////////////////////////////////////////////////////////////


;////////////////////////////////////////////////////////////////////////////////////////
;////////////////////////////////////////////////////////////////////////////////////////
;//愛莉　契約最後のデート
*airi_last_date1|My last date with Airi


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="bg_h1"]
[WAIT time=100]


[free time=1000]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1500]
[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

And so it was the day of .......
[cpg]


;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

This is my room, and if nothing happens here, it will be my last date with Airi.
[cpg]

If nothing happens here, it will be my last date with Airi.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi092"]
[OnName num="airi"]
Are you nervous?"
[cpg cn=true]

Sasamiya-san asks me while tilting her head. She's cute in that way, too.
[cpg]

[OnName num="norio"]
Yes, I'm a little..."
[cpg cn=true]

I'm not really a little nervous, but....
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Airi093"]
[OnName num="airi"]
"Your gaze is so disgusting.
[cpg cn=true]

[OnName num="norio"]
I'm sorry..."
[cpg cn=true]

Despite my nervousness, my eyes were drawn to her breasts, buttocks, thighs, and other parts of her body.
[cpg]

;//移植のためシーンをカットしています

[FACE method="change_6" pos="2/3"]
[VOICE f="sAiri021"]
[OnName num="airi"]
I'm sorry," she said.
[cpg cn=true]

;//========================================
;//●ＣＧ（ヒロインに迫られる主人公）ev_18
;//人物１：ヒロイン１
;//服装１：制服
;//人物３：主人公
;//服装３：制服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[VOICE f="sAiri022"]
[OnName num="airi"]
Hey, you're not going to do anything?
[cpg cn=true]

[OnName num="norio"]
"..."
[cpg cn=true]

She leans her body toward me.
[cpg]

And just like that...our lips touch each other.
[cpg]

I will never forget this moment in my life.
[cpg]

;//移植のためシーンをカットしています

[jump target="*airi_last_date_after"]


;////////////////////////////////////////////////////////////////////////////////////////
;//契約最後のデート　パターン２
*airi_last_date2|My last date with Airi

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]

We decided to have our last date at a place like this.
[cpg]

A certain place in the school.
[cpg]

;//========================================
;//●ＣＧ（マットの上で正常位）ev_12
;//人物１：ヒロイン１
;//服装１：体操服
;//人物３：主人公
;//服装３：制服
;//場所　：体育倉庫
;//時間　：夕方
;//========================================
[window target=false]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//移植のためシーンをカットしています

[VOICE f="sAiri023"]
[OnName num="airi"]
"...You're a little perverted, aren't you?
[cpg cn=true]

[OnName num="norio"]
"Yeah, I guess so."
[cpg cn=true]

But I can't deny it.
[cpg]

It's been a dream of mine for a long time. Being alone with him, in a situation like this...
[cpg]

[VOICE f="sAiri024"]
[OnName num="airi"]
I can't just do nothing, can I?
[cpg cn=true]

She looked at me and closed her eyes.
[cpg]


;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I put my lips to hers.
[cpg]


[jump target="*airi_last_date_after"]

;////////////////////////////////////////////////////////////////////////////////////////
;////////////////////////////////////////////////////////////////////////////////////////
;//愛莉　契約終了後のデート
;//分岐条件
;//愛莉ルート（愛莉との契約最後のデート）に到達した時、通常は契約後デートを経由してノーマルエンドへ
;//日常イベントの選択肢を全て愛莉にし、愛莉ルートに行った場合は
;//契約後デートは発生せずに恋人エンドへ
*airi_last_date_after|My last date with Airi


[if exp={getFlagValue("Cha1cnt") >= 4 }]
[jump target="*airi_nomal_end"]
[endif]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）

;//@
After the last date of our contract, when we were walking together to drop Mr. Sasamiya off.
[cpg]

;//@
[FACE method="change_1" pos="2/3"]
She said to me, "You can go out with me from now on.
[cpg]

[OnName num="norio"]
'Um...are you sure?
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
;//[VOICE f="Airi348"]
[VOICE f="sAiri025"]
[OnName num="airi"]
She said, "Yes, it's fine. It's special because it's Norio-kun, right?
[cpg cn=true]

;//@
[OnName num="norio"]
Well, then...well...I'll be counting on you from now on..."
[cpg cn=true]

;//@
[FACE method="change_2" pos="2/3"]
[VOICE f="Airi061"]
[OnName num="airi"]
I'm looking forward to working with you. I'm looking forward to working with you.
[cpg cn=true]

;//移植のためシーンをカットしています


;////////////////////////////////////////////////////////////////////////////////////////
;////////////////////////////////////////////////////////////////////////////////////////
;//分岐条件
;//愛莉ルート（愛莉との契約最後のデート）に到達した時、通常は契約後のデートを経由してノーマルエンドへ
;//日常イベントの選択肢を全て愛莉にし、愛莉ルート（愛莉との契約最後のデート）に行った場合は
;//契約後のデートは発生せずに恋人エンドへ

;//『愛莉エンディング１』ノーマルエンド
;//契約最後のデートを終えた翌日

*start|Prepared to be crushed

;#################################################
*Ep008|Prepared to be crushed
;#################################################


*airi_nomal_end|Prepared to be crushed

[SCENE id=8]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

I woke up. I feel refreshed.
[cpg]

I always feel depressed when I wake up in the morning because I have to go to the school.
[cpg]

[OnName num="norio"]
It's strange.
[cpg cn=true]

I feel calm.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[FACE method="change_2" pos="2/3"]
[VOICE f="Airi362"]
[OnName num="airi"]
Good morning, Norio. Norio.
[cpg cn=true]

[OnName num="norio"]
'...... Good morning.'
[cpg cn=true]

I meet and greet her at the school. We don't go to school together anymore.
[cpg]

I was able to reply calmly and firmly.
[cpg]

[FACE method="change_1" pos="2/3"]
This is surely thanks to her.
[cpg]

That's why ......
[cpg]

[OnName num="norio"]
Um, Sasamiya-san.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi363"]
[OnName num="airi"]
Hm? What is it?"
[cpg cn=true]

[OnName num="norio"]
Thank you.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi364"]
[OnName num="airi"]
......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Airi365"]
[OnName num="airi"]
"Hmm. You're welcome!"
[cpg cn=true]

After a scowling look, she gave me a big smile.
[cpg]

With a little something hidden in my mind, I went to my seat.
[cpg]

It's okay. I don't have to tell her how I feel.
[cpg]

Not now...not yet.
[cpg]

When I have a little more confidence in myself and become a man I can rely on, I'll be able to .......
[cpg]

At that time...I'll say it clearly and without hesitation.
[cpg]

I'm going to say it head-on.
[cpg]

I'm ready to be crushed.
[cpg]



[if exp={getFlagValue("Cha1cnt") >= 4 }]
[jump target="*airi_true_end"]
[endif]

;//END１　終わり


[jump storage="epend.ks" target="*start"]


;////////////////////////////////////////////////////////////////////////////////////////
;////////////////////////////////////////////////////////////////////////////////////////
;//END２の場合はこのまま進行して下記シナリオが付属する形になります
;//『愛莉エンディング２』恋人エンド


*start|And one year......

;#################################################
*Ep009|And one year......
;#################################################

*airi_true_end|And one year......

[SCENE id=9]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

Then, the months passed and .......
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』

I realized that one year had passed.
[cpg]

[OnName num="norio"]
No, too much time has passed!"
[cpg cn=true]

[FG f="CHA01_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Airi366"]
[OnName num="airi"]
Wow! What's wrong all of a sudden?"
[cpg cn=true]

[OnName num="norio"]
Oh, no...nothing."
[cpg cn=true]

I startled Sasamiya-san, who was walking next to me, with my sudden soliloquy.
[cpg]

It's been such a long time that even I want to make such a tsk tsk myself.
[cpg]

[OnName num="norio"]
I wonder what I've been doing for the past year..."
[cpg cn=true]

Still, I think I've made a lot of progress.
[cpg]

I've been able to invite myself to go out and have fun with them on weekends.
[cpg]

I'm able to talk with girls rather normally now.
[cpg]

I'm only talking to Sasamiya-san.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi367"]
[OnName num="airi"]
What's wrong? What's troubling you?
[cpg cn=true]

[OnName num="norio"]
"Uh...no..."
[cpg cn=true]

I was going to try to be vague for the time being, but the seriousness in her eyes as she looked at me made me change my mind.
[cpg]

[OnName num="norio"]
I was going to say, "Well...from your point of view, do you think I've changed?
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Airi368"]
[OnName num="airi"]
Yes, of course. Yes, of course. You have become very beautiful.
[cpg cn=true]

[OnName num="norio"]
......
[cpg cn=true]

Wow, I am so embarrassed.
[cpg]

I'm embarrassed to be praised with such a pure reaction.
[cpg]

[OnName num="norio"]
Me, too. I think I have changed a lot compared to the past.
[cpg cn=true]

[OnName num="norio"]
When the day comes when I feel like I've changed, there's something I've been thinking about doing.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi369"]
[OnName num="airi"]
What was that?
[cpg cn=true]

What is it?
[cpg]

[OnName num="norio"]
I've been thinking about you, Sasamiya-san. I like you, Sasamiya-san.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Airi370"]
[OnName num="airi"]
"......
[cpg cn=true]

[OnName num="norio"]
Yes?
[cpg cn=true]

Did he just laugh at me?
[cpg]

No, the way he said "I like you" was funny!
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Airi371"]
[OnName num="airi"]
"Oh, I'm sorry. It was just funny.
[cpg cn=true]

[OnName num="norio"]
I wasn't sure which way to say it.
[cpg cn=true]

If it was the same as before, I would say I like you.
[cpg]

But I also thought that I would like it if it made me feel that I had changed, that I had become more like a man.
[cpg]

I was confused and got mixed up.
[cpg]

I'm the kind of guy who can't get it right the first time.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi372"]
[OnName num="airi"]
I don't think you have to change it. I think it's better if you do it in your own way.
[cpg cn=true]

[OnName num="norio"]
I see.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Airi373"]
[OnName num="airi"]
"Ummm...this is a confession, right?
[cpg cn=true]

[OnName num="norio"]
"Of course, of course!
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Airi374"]
[OnName num="airi"]
"Of course! Norio, you've become really cool.
[cpg cn=true]

I am glad. It's simply nice to hear that from someone you like.
[cpg]

In the past, if the other person's reaction was not good, I would have given some reason to cover it up.
[cpg]

If I got the feeling that I was going to get it, I would have said yes.
[cpg]

It was so cowardly. There was no will of my own.
[cpg]

But...it's different now. I don't want to lie about this feeling, no matter which way it turns out.
[cpg]

So I say yes.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi375"]
[OnName num="airi"]
"Ummm...well, I'll answer."
[cpg cn=true]

[OnName num="norio"]
Yes!
[cpg cn=true]

[free time=300]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Airi376"]
[OnName num="airi"]
"...... is fine."
[cpg cn=true]

[OnName num="norio"]
Yes?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Airi377"]
[OnName num="airi"]
Shall we go out?
[cpg cn=true]

[OnName num="norio"]
Really?
[cpg cn=true]

[free time=300]
[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Airi378"]
[OnName num="airi"]
But there's a condition.
[cpg cn=true]

[OnName num="norio"]
Norio-kun?
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Airi379"]
[OnName num="airi"]
"Norio-kun. "Norio-kun, make a new contract with me."
[cpg cn=true]

[OnName num="norio"]
"Contract...?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Airi380"]
[OnName num="airi"]
Yes. A lover's contract.
[cpg cn=true]

[OnName num="norio"]
"Lover..."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Airi381"]
[OnName num="airi"]
This is a tough contract to sign. If you try to break the contract in the middle of the contract, you may get into trouble with the other party. You may even be charged alimony.
[cpg cn=true]

[OnName num="norio"]
"Oh, I see..."
[cpg cn=true]

What a horrible contract.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Airi382"]
[OnName num="airi"]
"In my case, well, ...... I'd probably cry a lot, a lot."
[cpg cn=true]

[OnName num="norio"]
I would never ...... do that."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Airi383"]
[OnName num="airi"]
I'm glad. Thank you. So... will you sign a contract with me?
[cpg cn=true]

[OnName num="norio"]
Yeah, sure.
[cpg cn=true]

[free time=300]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Airi384"]
[OnName num="airi"]
Then give me your hand.
[cpg cn=true]

[OnName num="norio"]
Like this?
[cpg cn=true]

;//========================================
;//●ＣＧ（恋人契約を結ぶ二人。恋人繋ぎで手を握りながらキス）ev_21
;//人物１：ヒロイン１
;//服装１：私服
;//人物３：主人公
;//服装３：私服
;//場所　：街
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_21_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="Airi385"]
[OnName num="airi"]
N......
[cpg cn=true]

[OnName num="norio"]
Ah.
[cpg cn=true]

[VOICE f="Airi386"]
[OnName num="airi"]
Okay. The contract is done! I can't speak for myself, but I think it's a great place... and I hope you'll take good care of it."
[cpg cn=true]

[OnName num="norio"]
"Yes, I do, I do!"
[cpg cn=true]

I know. This is, in essence, being told it's OK.
[cpg]

But I was much, much happier than if he had just nodded at me.
[cpg]

[SCENE id=15]

;//END２　終わり

[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
