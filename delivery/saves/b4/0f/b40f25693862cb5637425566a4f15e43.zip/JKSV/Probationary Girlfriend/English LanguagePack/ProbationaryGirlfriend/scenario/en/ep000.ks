
*start|I hate myself.

;//筆下ろし姫と仮恋契約　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//愛莉　　私服　制服
;//つぐみ　私服　制服
;//未奈美　私服　制服
;//以下音声なし
;//典雄
;//男性教師
;//女子学生

;#################################################
*Ep000|I hate myself.
;#################################################

[SCENE id=0]

[stflag Cha2flg = 0]

[stflag Cha1cnt = 0]
[stflag Cha2cnt = 0]
[stflag Cha3cnt = 0]
[stflag set_zengi = 0]
[stflag DAY_1 = 0]
[stflag DAY_2 = 0]
[stflag DAY_3 = 0]
[stflag DAY_4 = 0]
[stflag DAY_5 = 0]
[stflag DAY_6 = 0]
[stflag Select_root = 0]
[stflag Last_root = 0]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]


I hate myself.
[cpg]

I think there are few people who are confident that they love themselves,
[cpg]

But I am sure that I am at least more confident than those who answer "normal" or "not really"...
[cpg]

I hate myself.
[cpg]

It's not that I hated myself from the beginning.
[cpg]

It started from a trivial thing. But the mark I left on my life was huge.
[cpg]

[SE f="se000"]
;//【ＳＥ】『笑い声』

I hear laughter.
[cpg]

Oh, it's this dream again.
[cpg]

I sometimes see it, and I hate dreaming about it.
[cpg]

;//回想なので出来たらセピア調に

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_moya.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[OnName num="norio"]
I'm Norio Butabara. Yo, yo, nice to meet you...please."
[cpg cn=true]

.......
[cpg]

.............
[cpg]

...................
[cpg]

When I said that, for some reason, the classroom became quiet.
[cpg]

But it was only for a moment.
[cpg]

A moment of silence. After that.
[cpg]

[SE f="se039"]
;//【ＳＥ】『爆笑』

[WAIT time=1500]

[OnName num="norio"]
What? What...what...what...what...？？？？
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Airi001"]
[OnName num="airi"]
"......"
[cpg cn=true]

[free time=300]
[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Tugumi001"]
[OnName num="tugumi"]
I'm sure you're right.
[cpg cn=true]

[free time=300]
[FG f="CHA03_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Minami001"]
[OnName num="minami"]
"......"
[cpg cn=true]

;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


When I first joined this academy. I remember introducing myself in the first year.
[cpg]

Something I didn't really want to remember.
[cpg]

I didn't know why they were laughing at me.
[cpg]

I finally understood when I went home and looked at my appearance.
[cpg]

The way I looked, my name, and the way I looked.
[cpg]

They laughed at me because I matched them too well.
[cpg]

I had never been laughed at like that before. I must have been blessed with friends and acquaintances.
[cpg]

I failed the entrance exam and ended up going to a different school than my good friends,
[cpg]

Since then, I've been alone.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se029"]
;//【ＳＥ】『衣擦れ』

[BG f="b_01_2.ui" time=100]
[WAIT time=200]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************

[OnName num="norio"]
"Uh-uh-uh-uh-uh, ...... ha!
[cpg cn=true]

[OnName num="norio"]
I'm awake, I'm awake, I'm awake.
[cpg cn=true]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『家のドアを開ける』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』

[OnName num="norio"]
I'm off.
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』
[WAIT time=1500]

[OnName num="norio"]
"Huh..."
[cpg cn=true]

I'm depressed. My steps to go to the school are heavy.
[cpg]

Part of it is because it's Monday and I'm feeling blue.
[cpg]

Apart from that, I just want to ......
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se002"]
;//【ＳＥ】『教室の扉を開ける』

[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************


[SE f="se040"]
;//【ＳＥ】『学園の喧騒』

[OnName num="norio"]
I'm sure you're right.
[cpg cn=true]

[OnName num="male_student"]
I'm sure you're right.
[cpg cn=true]

[OnName num="female_student"]
I'm sure you're right.
[cpg cn=true]

I hate this atmosphere.
[cpg]

[OnName num="male_student"]
"Whispering."
[cpg cn=true]

[OnName num="female_student"]
"Whispering."
[cpg cn=true]

It's obvious I'm the only one who doesn't fit in. I feel foreign.
[cpg]

Oh, come to think of it, I'm also depressed about ...... class today.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="b_sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="b_sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="b_sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="b_sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[OnName num="teacher"]
"Well, since..."
[cpg cn=true]

[OnName num="teacher"]
"Well, let's look at the problem here, um...the lid belly. Solve it."
[cpg cn=true]

[OnName num="norio"]
"Eh, ah...ha, hahi..."
[cpg cn=true]

Nominations are made by matching the date of the month with the attendance number, which is often the case.
[cpg]

The most common reason for this is because it is easy to stand out in a good or bad way.
[cpg]

Names I don't want to be called.
[cpg]

[OnName num="female_student"]
"Pork belly...kkkk..."
[cpg cn=true]

[OnName num="female_student"]
Pfft.
[cpg cn=true]

[OnName num="female_student"]
"Stop it, I'm holding back...pfft."
[cpg cn=true]

It's easy.
[cpg]

The name is Butabara. It's written "belly" on the lid and "butabara. But when I hear "butabara," I easily associate it with pork belly.
[cpg]

Butabara. Pork belly. And my appearance, which fits perfectly, makes people laugh.
[cpg]

That's all there is to it, and I've made many people laugh like it's my signature story.
[cpg]

It's not that I'm being bullied.
[cpg]

I am not being maliciously harassed.
[cpg]

I am being played with, is probably the most correct way to put it.
[cpg]

If I had the ability to talk to people using my name as a topic of conversation, I am sure I would not be where I am today,
[cpg]

I would not be in the situation I am in now. I think so.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se028"]
;//【ＳＥ】『チャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

[OnName num="norio"]
"Well...it's finally over.
[cpg cn=true]

I finish all my classes and the day is over. It's finally over.
[cpg]

Every day, I feel like I'm getting a stronger and stronger sense that I've made it through.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Airi002"]
[OnName num="airi"]
"Really?
[cpg cn=true]

[OnName num="female_student"]
Really, really.
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Airi003"]
[OnName num="airi"]
"Ha-ha-ha. That's funny.
[cpg cn=true]

[OnName num="female_student"]
"Really funny."
[cpg cn=true]

[OnName num="norio"]
"......"
[cpg cn=true]

There are many ways for students to spend their time after school.
[cpg]

[free time=1000]

Club activities and part-time jobs. They go out with friends or have a chat like the girls do.
[cpg]

In my case, I don't fall into any of those categories.
[cpg]

I don't participate in club activities, and I don't have any good friends.
[cpg]

I have to go home and watch late-night anime I recorded.
[cpg]

[SE f="se002"]
;//【ＳＥ】『ガタガタ』

;//========================================
;//●ＣＧ（ヒロイン１登場シーン）ev_43
;//人物１：ヒロイン１
;//服装１：制服
;//人物３：主人公
;//服装３：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_43_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="Airi004"]
[OnName num="airi"]
"Ah, Norio-kun.
[cpg cn=true]

[OnName num="norio"]
Eh?"
[cpg cn=true]

I was about to grab my bag from my seat and quickly leave, thinking I would go home quickly.
[cpg]

At that time, a girl called out to me.
[cpg]

[VOICE f="Airi005"]
[OnName num="airi"]
Are you going home?"
[cpg cn=true]

[OnName num="norio"]
Uh...yeah."
[cpg cn=true]

I couldn't say, "Of course I'm getting ready to go home.
[cpg]

I was too busy just responding to her, so I gave a slurred reply.
[cpg]

[VOICE f="Airi006"]
[OnName num="airi"]
I was too busy trying to respond, so I gave a terse reply. I said, "Okay, bye. See you tomorrow.
[cpg cn=true]

[OnName num="norio"]
I said, "I'll see you tomorrow. I'll see you tomorrow.
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』

[OnName num="female_student"]
"Is Airi good friends with pork belly?"
[cpg cn=true]

[VOICE f="Airi007"]
[OnName num="airi"]
"Well, sometimes... I guess. We haven't talked much.
[cpg cn=true]

[OnName num="female_student"]
I've never talked to her much. That's so nice of you.
[cpg cn=true]

[VOICE f="Airi008"]
[OnName num="airi"]
"Well, I at least say hello. We're classmates.
[cpg cn=true]

[OnName num="female_student"]
Airi is an angel.
[cpg cn=true]

[OnName num="female_student"]
"Ha-ha-ha."
[cpg cn=true]


[SE f="se001"]
;//【ＳＥ】『歩く』
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I left the classroom to escape from their conversation.
[cpg]

The first thing to do is to get a good look at the pictures.
[cpg]

Her name is Airi Sasamiya.
[cpg]

She is bright, friendly, and has many friends. In my opinion, she is at the top of the school caste.
[cpg]

I have no idea why she would talk to me.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I don't know the reason.
[cpg]

But just by being approached by her...it made me a little bit happy.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[SE f="se040"]
;//【ＳＥ】『学園の喧騒』

[FACE method="bow_2" pos="2/3"]
[VOICE f="Airi009"]
[OnName num="airi"]
Ah, Norio-kun. Good morning.
[cpg cn=true]

[OnName num="norio"]
"Eh, ah, yeah. ...... Good morning, hello."
[cpg cn=true]

I am relieved and relieved.
[cpg]

I could have responded a little better today, I think.
[cpg]

Mr. Sasamiya greets me in the morning and on my way home.
[cpg]

[free time=1000]
[WAIT time=1000]

Nothing more than that, though.
[cpg]

Compared to my classmates who make fun of me and laugh at me, she is like an angel.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[SE f="se000"]
;//【ＳＥ】『ペン音』

During class. Naturally, most students are not chatting, but rather running their pens.
[cpg]

For me, this is more relaxing than recess.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Airi010"]
[OnName num="airi"]
I'm sure you're right.
[cpg cn=true]

[OnName num="norio"]
Ah..."
[cpg cn=true]

Oh no. My eraser.
[cpg]

I was erasing the wrong part and the eraser fell to the floor.
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Airi011"]
[OnName num="airi"]
"Oops!"
[cpg cn=true]

The eraser bounced off the floor with so much force that it landed on the floor.
[cpg]

The eraser bounced so much that it landed between the legs of Sasamiya-san, who was sitting next to me.
[cpg]

Oh no. I instantly broke out in a cold sweat.
[cpg]

[OnName num="norio"]
"Sorry..."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Airi012"]
[OnName num="airi"]
Coussin. It's okay. I was just a little surprised. You're such a cheerful eraser."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi013"]
[OnName num="airi"]
Here, go back to Norio-kun's place.
[cpg cn=true]

[OnName num="norio"]
Thank you."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

Instead of getting angry, she handed me the eraser with a unique reply.
[cpg]

It was nothing special.
[cpg]

The eraser I dropped happened to be on the seat next to me. Sorry, thanks, I just said so and got it back.
[cpg]

But even so... my heart was beating so fast I felt like it was going to explode.
[cpg]

I felt like I saw a side of Sasamiya-san that was a little different than usual.
[cpg]

[OnName num="norio"]
I'm going to keep this eraser.
[cpg cn=true]

[free time=1000]
[WAIT time=1500]

This is a common story.
[cpg]

When someone is kind to you, before you know it, you fall in love with them.
[cpg]

The other person's actions are just good intentions or a whim.
[cpg]

This tendency is stronger among men who have no relationship with girls.
[cpg]

In other words, it's me.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（夕方）******************************************************
;//【ＢＧ】『学園教室』（夕方）

[OnName num="norio"]
"Phew, it's getting late..."
[cpg cn=true]

The teacher asked me to carry his baggage, so it was getting late when I left.
[cpg]

As I return to the front of the classroom, I can hear them talking from inside.
[cpg]

[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）

[OnName num="female_student"]
I bet you love Airi, Rib!
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi014"]
[OnName num="airi"]
"Oh, really?"
[cpg cn=true]

[OnName num="female_student"]
"You bet."
[cpg cn=true]

It's a topic that makes me nervous. I don't know if I like it or not.
[cpg]

But it seems that people around me seem to think so.
[cpg]

Either way, I can't go inside if they are talking like this.
[cpg]

[OnName num="female_student"]
What would you do if someone told you?
[cpg cn=true]

[OnName num="female_student"]
"No, I don't think so.
[cpg cn=true]

[OnName num="female_student"]
"What if?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Airi015"]
[OnName num="airi"]
"Well..."
[cpg cn=true]

I was unknowingly sharpening my nerves.
[cpg]

I was unconsciously trying not to miss what she was saying.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi016"]
[OnName num="airi"]
I don't know much about Norio-kun yet.
[cpg cn=true]

[OnName num="female_student"]
No, you should immediately say no.
[cpg cn=true]

[OnName num="female_student"]
No matter how much it costs, there is no pork belly.
[cpg cn=true]

[OnName num="norio"]
I'm sure you're right.
[cpg cn=true]

I know, right? Of course.
[cpg]

What if?
[cpg]

She is kind. I was hoping for a "just in case.
[cpg]

[OnName num="norio"]
"Ha-ha...idiot."
[cpg cn=true]

The reality should have been clearer than fire.
[cpg]

The bag...no matter.
[cpg]

Let's go home today.
[cpg]

I can't even enter the classroom with a nonchalant look on my face right now.
[cpg]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=2000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi017"]
[OnName num="airi"]
But Norio-kun is a good person.
[cpg cn=true]

[OnName num="female_student"]
I know, I know, I know.
[cpg cn=true]

[OnName num="female_student"]
Airi is kind. Are you a saint?
[cpg cn=true]

[OnName num="female_student"]
But I think it's better to be moderate because more boys will misunderstand you.
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Airi018"]
[OnName num="airi"]
I don't mean that.
[cpg cn=true]

[OnName num="female_student"]
Oh, let's go home now. Let's go home.
[cpg cn=true]

[OnName num="female_student"]
I had a drama I wanted to watch.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi019"]
[OnName num="airi"]
I'm sure you're right.
[cpg cn=true]

[OnName num="female_student"]
Airi, let's go home.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Airi020"]
[OnName num="airi"]
"Okay."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi021"]
[OnName num="airi"]
"Norio didn't come back."
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[OnName num="norio"]
"......"
[cpg cn=true]

I went under the covers because I didn't have an appetite, even though my parents said it was dinner.
[cpg]

Anyway, let's sleep. Let's sleep and forget about it. That's the best.
[cpg]

It's better for my mental health to forget about the things I don't like.
[cpg]

That's what I've always done.
[cpg]

[OnName num="norio"]
......sniffle
[cpg cn=true]



[jump storage="ep001.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
