;//３回目　日常イベント
;//日常イベントはキャラ共通です。どのヒロインのＨシーンに行くかはフラグにより変化します
*start|A little change

;#################################################
*Ep006|A little change
;#################################################

*day02_after|A little change
*day03|A little change

[SCENE id=6]

[stflag DAY_3 = 1]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

;//;//@
;//仮恋契約……正直、未だに実感がわかない。ダメな僕にこんなことが起きていいのだろうか。
;//[cpg]
;//
;//;//@
;//そんなことを考えながらも、僕の足はあの人のもとへと向かっていた。
;//[cpg]

;//@
I had a feeling that my temporary love contract was changing me.
[cpg]

;//@
I still can't get used to girls though .......
[cpg]


[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*day03_1"]
[endif]


[switch]
[case "Airi"]
	[swap]
	[jump target="*day03_1"]
[case "Tsugumi"]
	[swap]
	[jump target="*day03_2"]
[case "Minami"]
	[swap]
	[jump target="*day03_3"]
[endswitch]

;//■選択肢
1, Airi
2, Tsugumi
3, Minami

;//※３は参戦してから
;//選択が発生しない場合はそのヒロインの方へ


;//*day03_1|少しの変化
;//[jump target="*airi_date"]
;//*day03_2|少しの変化
;//[jump target="*tugumi_date"]
;//*day03_3|少しの変化
;//[jump target="*minami_date"]

;//※以降、日常イベントの時には毎回同じ選択肢が発生します
;//////////////////////////////////////////////////////////////////////
;//ＢＫ
;//愛莉パターン
*day03_1|A little change

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[OnName num="norio"]
Um, Mr. Sasamiya. I'd like to talk to you..."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Airi163"]
[OnName num="airi"]
I'm fine. What's wrong?"
[cpg cn=true]

[OnName num="norio"]
"......, I don't know if we have time after this or not."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="sAiri013"]
[OnName num="airi"]
"Yes, I'm fine. You're getting a little more aggressive.
[cpg cn=true]


She laughed at that. I'm starting to look cuter and cuter...
[cpg]

At the same time, I thought that I might not be so bad after all.
[cpg]

[jump target="*airi_date"]

;//ＢＫ
;//////////////////////////////////////////////////////////////////////
;//つぐみパターン

*day03_2|A little change

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[FACE method="bow_1" pos="2/3"]
[VOICE f="sTugumi009"]
[OnName num="tugumi"]
She said, "Hello. What's wrong?"
[cpg cn=true]

[OnName num="norio"]
"..."
[cpg cn=true]

I was going to ask her out on a date, but...I still couldn't muster up the courage.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sTugumi010"]
[OnName num="tugumi"]
I won't know if you don't tell me...
[cpg cn=true]

;//@
[OnName num="norio"]
I'm sorry...
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="sTugumi011"]
[OnName num="tugumi"]
I don't know. I know. You've been braver than usual, and I can't let you down.
[cpg cn=true]


I was embarrassed, but I felt like I was being pushed.
[cpg]


[jump target="*tugumi_date"]

;//////////////////////////////////////////////////////////////////////
;//未奈美パターン
;//ここは新規パターンは未奈美のみ
;//シナリオの調整で５日目にあった未奈美パターンを３日目に
*day03_3|A little change


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************


[OnName num="norio"]
"Um, Minami-san."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Minami036"]
[OnName num="minami"]
"Hmm? What's up, Boo-chan?
[cpg cn=true]

[OnName num="norio"]
It's, uh..."
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="sMinami008"]
[OnName num="minami"]
I know. You don't have to tell me everything.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="sMinami009"]
[OnName num="minami"]
I'm glad you're looking forward to it.
[cpg cn=true]


[jump target="*minami_date"]

;//ヒロイン１へ
;//ヒロイン２へ
;//サブヒロインへ



*airi_date|Date with Airi
[jump storage="ep008.ks" target="*airi_date"]
*tugumi_date|Date with Tsugumi
[jump storage="ep010.ks" target="*tugumi_date"]
*minami_date|Date with Minami
[jump storage="ep012.ks" target="*minami_date"]


;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//デートシーン　つぐみ　の理由
;//日常イベントの３回目と４回目の間に入ります
;//見づらいので３回目と４回目の間に移動
*day03_after|Why did Tsugumi sign up?

[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*day04"]
[endif]

;//ヒロイン２が選択肢に入ってはいるが一度も選んでいなければ
[if exp={getFlagValue("Cha2cnt") == 0 }]
[jump target="*day03_after_2"]
[endif]

*day03_after_1|Why did Tsugumi sign up?

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="bg_ed"]
[WAIT time=1000]
;//【ＢＧ】『街』（昼）******************************************************

;//========================================
;//●ＣＧ（女の子に慣れる為にデート）ev_14
;//人物１：ヒロイン２
;//服装１：私服
;//人物３：主人公
;//服装３：私服
;//場所　：街
;//時間　：昼
;//========================================

[window target=false]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="Tugumi081"]
[OnName num="tugumi"]
Hey," she said, "today is a date. I thought I told you today was a date.
[cpg cn=true]

[OnName num="norio"]
Yes, I did.
[cpg cn=true]

[VOICE f="Tugumi082"]
[OnName num="tugumi"]
Why are you so scared? Are you scared of me?
[cpg cn=true]

[OnName num="norio"]
No, it's not because of you, Kiriya-san. It's because I'm not used to it.
[cpg cn=true]

[VOICE f="Tugumi083"]
[OnName num="tugumi"]
Calm down. I'm on your side.
[cpg cn=true]

[OnName num="norio"]
"Uh, yeah..."
[cpg cn=true]

[VOICE f="Tugumi084"]
[OnName num="tugumi"]
I'm dating you, so I'm like a pseudo girlfriend. But... are you scared of her?
[cpg cn=true]

[OnName num="norio"]
No, I'm not scared.
[cpg cn=true]

[VOICE f="Tugumi085"]
[OnName num="tugumi"]
Besides... a date is a waste of time if you don't enjoy it.
[cpg cn=true]

[VOICE f="Tugumi086"]
[OnName num="tugumi"]
Time is finite. You have to make the most of it.
[cpg cn=true]

[OnName num="norio"]
Yeah, that's right.
[cpg cn=true]

That's just like her.
[cpg]

[OnName num="norio"]
But what should I do on a date?
[cpg cn=true]

[VOICE f="Tugumi087"]
[OnName num="tugumi"]
You can do whatever you want.
[cpg cn=true]

[OnName num="norio"]
Anything.
[cpg cn=true]

I imagine the worst when she says, "Anything.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



We had dinner together. To be honest, I didn't taste it.
[cpg]

I failed, so I acted.
[cpg]

[OnName num="norio"]
I'll pay for this.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi091"]
[OnName num="tugumi"]
What are you dressed up for? You're a student, how can you have that kind of money? Do you have a part-time job?
[cpg cn=true]

[OnName num="norio"]
No...
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Tugumi092"]
[OnName num="tugumi"]
Then we'll split the bill. That's the way it's supposed to be.
[cpg cn=true]

[OnName num="norio"]
Am I wrong?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Tugumi093"]
[OnName num="tugumi"]
No, it's not wrong. In some cases, it's the right thing to do.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi094"]
[OnName num="tugumi"]
If you think the man should pay, then do it.
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Tugumi095"]
[OnName num="tugumi"]
Girls are difficult. Not everyone wants you to do it.
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Tugumi096"]
[OnName num="tugumi"]
Of course it's different for everyone. I'm more upset that you think I'm like that because I'm lumped in with you.
[cpg cn=true]

[OnName num="norio"]
I'm sorry.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi097"]
[OnName num="tugumi"]
Is what I'm saying difficult?
[cpg cn=true]

Yeah, it's...
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Tugumi098"]
[OnName num="tugumi"]
There's no right answer for every girl. I'm just trying to help them grow as people. That's all I can tell you."
[cpg cn=true]

[OnName num="norio"]
"......"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Tugumi099"]
[OnName num="tugumi"]
I'm sorry. I was out of line.
[cpg cn=true]

She consoled me by saying so.
[cpg]

She is really kind, even though she sometimes says harsh things.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=1000]
;//【ＢＧ】『街』（夜）******************************************************


But why does she do this?
[cpg]

;//どうして僕なんかにしてくれるのか…その理由が聞きたかった。
I wanted to ask her why she cared about me.
[cpg]

[OnName num="norio"]
I wanted to ask her why she was doing this to me.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi100"]
[OnName num="tugumi"]
Do I have to answer that question?
[cpg cn=true]

[OnName num="norio"]
No, if you don't want to..."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi101"]
[OnName num="tugumi"]
I told you before. Because I don't like you.
[cpg cn=true]

[OnName num="norio"]
Ugh..."
[cpg cn=true]

That's not so clear. But I don't think that's a reason.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Tugumi102"]
[OnName num="tugumi"]
They are always influenced by other people's opinions and have no will of their own. They are so nay-nay and irritating to watch.
[cpg cn=true]

[OnName num="norio"]
"I'm sorry..."
[cpg cn=true]

I was told in a very straightforward manner.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Tugumi103"]
[OnName num="tugumi"]
I'm sorry..." "Then you can't live your own life. It's a very sad thing.
[cpg cn=true]

That's why he was talking to me like that.
[cpg]

[OnName num="norio"]
I was so sad that I couldn't live my own life.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Tugumi104"]
[OnName num="tugumi"]
Sasamiya-san told me there was a way to do that.
[cpg cn=true]

I don't believe it was her who was the source of the message.
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="sTugumi008"]
[OnName num="tugumi"]
I don't just dislike you. I've changed my mind a little while I've been in contact with you. Maybe you're not so bad..."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Tugumi109"]
[OnName num="tugumi"]
I wonder if it's because I'm tickled by your motherly feelings.
[cpg cn=true]

I don't really think I have that kind of charm.
[cpg]


;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//未奈美　の理由
;//３回目と４回目の間に入ります
;//見づらいので３回目と４回目の間に移動
*day03_after_2|Minami's reason for signing the contract.


;//サブヒロインが選択肢に入ってはいるが一度も選んでいなければ
[if exp={getFlagValue("Cha3cnt") == 0 }]
[jump target="*day04"]
[endif]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

;//@
Another day after school. When I was talking with Minami.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


Why is she doing this to me?
[cpg]

Why would she do this to me...I wanted to ask her why.
[cpg]

[OnName num="norio"]
I wanted to ask her why she would do this to me.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Minami032"]
[OnName num="minami"]
What? Why...of course.
[cpg cn=true]

[OnName num="norio"]
What?"
[cpg cn=true]

[free time=300]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sMinami007"]
[OnName num="minami"]
Because it's fun to make fun of you."
[cpg cn=true]

Gasp. But if that's the charm, I guess I'll just have to accept it. ......
[cpg]

;//[jump target="*day04"]


*day04|Almost a month has passed since the tentative love contract
[jump storage="ep007.ks" target="*day04"]


;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
