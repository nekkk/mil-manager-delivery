;//最後のデートへの分岐条件『未奈美』
;//未奈美との最後のデートになった場合、最終分岐の選択肢の後に表示
*root_3|Last date with Minami

;#################################################
*EpRoot003|Last date with Minami
;#################################################

;//ＢＫ
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

Well, we are already approaching the last date of our contract.
[cpg]

What kind of date shall we make?
[cpg]



[switch]
[case "I want to meet in my room."]
	[swap]
	[stflag Last_root = 1]
[case "I want to go to her room"]
	[swap]
	[stflag Last_root = 2]
[case "A date at the school."]
	[swap]
	[stflag Last_root = 3]
[endswitch]


;//++++++++++++++++++++++++++++++++++++++
;//■選択肢
;//１、自分の部屋で会いたい
;//２、彼女の部屋に行ってみたい
;//３、学園でデート
;//++++++++++++++++++++++++++++++++++++++

;//選択後の文章。共通

[OnName num="norio"]
Yeah. Okay, let's do that."
[cpg cn=true]


I hope this is how we want to do it.
[cpg]

Yeah...I'm suddenly looking forward to it.
[cpg]

*minami_last_date|Last date with Minami

[if exp={getFlagValue("Last_root") == 1 }]
[jump target="*minami_last_date1"]
[endif]

[if exp={getFlagValue("Last_root") == 2 }]
[jump target="*minami_last_date2"]
[endif]

[if exp={getFlagValue("Last_root") == 3 }]
[jump target="*minami_last_date3"]
[endif]

;//*minami_last_date1|未奈美との最後のデート
;//[jump storage="ep000.ks" target="*minami_last_date1"]
;//*minami_last_date2|未奈美との最後のデート
;//[jump storage="ep000.ks" target="*minami_last_date2"]
;//*minami_last_date3|未奈美との最後のデート
;//[jump storage="ep000.ks" target="*minami_last_date3"]


;//契約最後のデートシーンへ
;////////////////////////////////////////////////////////////////////////////////////////
;////////////////////////////////////////////////////////////////////////////////////////
;////////////////////////////////////////////////////////////////////////////////////////
;////////////////////////////////////////////////////////////////////////////////////////
;////////////////////////////////////////////////////////////////////////////////////////


;////////////////////////////////////////////////////////////////////////////////////////
;////////////////////////////////////////////////////////////////////////////////////////
;//未奈美　デート
;///////////////////////////////////////
;//サブヒロイン、デート前の部分　分岐以後
;///////////////////////////////////////
;//シナリオ調整で２日目の選択肢の直後に移動
*minami_date|Date with Minami

[stflag Cha3cnt = 1]

[if exp={getFlagValue("Cha3cnt") == 4 }]
[jump target="*minami_date04"]
[endif]
[if exp={getFlagValue("Cha3cnt") == 3 }]
[jump target="*minami_date03"]
[endif]
[if exp={getFlagValue("Cha3cnt") == 2 }]
[jump target="*minami_date02"]
[endif]

;//[if exp={getFlagValue("Cha3cnt") == 1 }]
;//[jump target="*minami_date01"]
;//[endif]


;//ＢＫ

;///////////////////////////////////////
;//デートパターン１（サブヒロイン）
;///////////////////////////////////////
*minami_date01|Date with Minami


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

I was summoned to an empty classroom. I thought she was going to do something for me, but apparently not.
[cpg]

Apparently, she had called me in to see how I am as a person. She talked to me about all sorts of trivial things.
[cpg]

However, after I made a temporary love contract with Minami, I started to look at her body unconsciously.
[cpg]

Or rather, I have been looking at it until now. I guess you could say I'm looking at it in a different place than I used to.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Minami042"]
[OnName num="minami"]
"So, my parents tell me not to play with my phone while I'm eating. ......
[cpg cn=true]

[OnName num="norio"]
Heh ......."
[cpg cn=true]

Minami has large breasts. They are also quite large, about an F cup.
[cpg]

Right now I'm trying to phase in the topic, but honestly, that's not enough.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Minami043"]
[OnName num="minami"]
Isn't it ridiculous to talk about the parent-child bond over something like that?
[cpg cn=true]

[OnName num="norio"]
"Yes, I can see that."
[cpg cn=true]

I make conversation looking at her breasts instead of her eyes. And that was apparently discovered by Minami.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Minami044"]
[OnName num="minami"]
I look at her face.
[cpg cn=true]

I looked at her face.
[cpg]

[OnName num="norio"]
I looked at her face. I'm fine.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
She pursed her lips and said, "Hmmm. Then she said, "Well, what was I talking about?
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Minami045"]
[OnName num="minami"]
Then tell me what I was talking about.
[cpg cn=true]

[OnName num="norio"]
Oh, that. I was talking about the phone at ......, uh, ......."
[cpg cn=true]

I tried desperately to remember what she was talking about, going through my fragmented memory.
[cpg]

[OnName num="norio"]
I tried to remember what she was talking about. "...... what was it ......?"
[cpg cn=true]

And then I revealed to myself that I couldn't remember.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="sMinami012"]
[OnName num="minami"]
I said to myself, "......, well, that's okay. If you're that interested, I'm happy.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
Minami is very forgiving. Most girls would have gotten angry.
[cpg]

And I was quite rude to her. I had to listen to what Minami had to say. ......
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Minami047"]
[OnName num="minami"]
I'm not a big fan of the "I'm so happy you're interested in my work.　So even if you're having dinner, you'll still get texts and stuff.
[cpg cn=true]

[OnName num="norio"]
Yeah, that's true. ......
[cpg cn=true]

My gaze naturally goes down. Whenever she makes a gesture, my eyes are drawn to her swaying breasts.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Minami048"]
[OnName num="minami"]
And you're too ...... to reply to that, boo?
[cpg cn=true]

[OnName num="norio"]
What?
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
Huh," sighs Minami. This time it's not good.
[cpg]

The first time you do this, you'll be able to get a better idea of what you're getting into. I wanted to scold me, but it was already too late.
[cpg]

I wanted to scold her, but it was too late.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="sMinami013"]
[OnName num="minami"]
I was going to go on a date with you today, but I decided not to. Maybe next time.
[cpg cn=true]

I bit down in a hurry. I don't want to do that, I want Minami to do it.
[cpg]

[OnName num="norio"]
I said, "I'm sorry!　I'll never look at it again.
[cpg cn=true]

Minami scratches her head and says, "That's not the right place to apologize.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Minami050"]
[OnName num="minami"]
I don't care if you watch it. But if you can't hear what I'm saying, you're looking too much.
[cpg cn=true]

I had nothing to say in reply. I think I was a little bit crazy.
[cpg]

;//移植のためシーンをカットしています

[jump target="*date_after"]
;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//デートパターン２（サブヒロイン）
;///////////////////////////////////////
*minami_date02|Date with Minami

;//[stflag Cha3cnt = 1]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[SE f="se000"]
;//【ＳＥ】『チョークの音』

In the middle of class. I was having a crisis.
[cpg]

;//男ならきっと誰でも経験あると思う、意味もなく理由もなく勃起が止まらなくなるという現象。
I'm sure everyone has experienced this. It's a phenomenon where you can't concentrate on the class and you get distracted by something else.
[cpg]

I don't know the name. But I'm sure there must be a name for it, because it happens to everyone.
[cpg]

In addition, I made a contract with Minami.
[cpg]

She is in the seat diagonally in front of me. Looking at her rear view, I kind of...
[cpg]

I'm tempted to anticipate our future date.
[cpg]

[OnName num="male_teacher"]
'Well then, lid belly. Try to translate."
[cpg cn=true]

[OnName num="norio"]
Yes!"
[cpg cn=true]

I was so surprised that my voice was turned inside out. Not only the girls but even the boys are laughing at me.
[cpg]

[OnName num="norio"]
Oh, um, ...... I'm sorry, I don't understand.
[cpg cn=true]

I mean, was it an English class now?　I'm thinking to myself.
[cpg]

Noticing my unusual behavior, Minami also turns around and teases me.
[cpg]

She flips up her skirt so that only I can see it, or something like that. ......
[cpg]

No, I can't help but think, what if someone finds out about that, but that's really what I've been doing.
[cpg]

I am being teased. I know, but I can't take my eyes off Minami.
[cpg]

[SE f="se004"]
;//【ＳＥ】『椅子から立ち上がる』

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Minami072"]
[OnName num="minami"]
I can't take my eyes off of Minami.
[cpg cn=true]

Minami stopped the class. What is she going to do this time?
[cpg]

[OnName num="male_teacher"]
What is it?　What's wrong?
[cpg cn=true]

Is she going to push me further here? Would she give me a helping hand?
[cpg]

As I listened with trepidation, I heard the following message: ......
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Minami073"]
[OnName num="minami"]
I was listening to her, and she said, "I think your lid stomach is a little bit bad, so I'm going to take you to the infirmary.
[cpg cn=true]

It seemed to be the latter.
[cpg]

;//ＢＫ
;//========================================
;//●ＣＧ（保健室で主人公に説教。主人公の姿は消してください）ev_31
;//人物１：サブヒロイン
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：保健室
;//時間　：昼
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_31_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sMinami014"]
[OnName num="minami"]
I was so worried about him.
[cpg cn=true]


[VOICE f="sMinami015"]
[OnName num="minami"]
Or should I say, you shouldn't be looking at me so much?
[cpg cn=true]


[OnName num="norio"]
I'm sorry.
[cpg cn=true]


[VOICE f="sMinami016"]
[OnName num="minami"]
I'm sorry. You should go back to your classes as you see fit.
[cpg cn=true]


Having said that, she seemed to have no hesitation in this action.
[cpg]


;//移植のためシーンをカットしています
;//ＢＫ
[jump target="*date_after"]
;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//デートパターン３（サブヒロイン）
;///////////////////////////////////////
*minami_date03|Date with Minami

;//[stflag Cha3cnt = 1]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



After school. I was saying goodbye to Minami.
[cpg]

[OnName num="norio"]
I said, "Well then, I'll see you at ......."
[cpg cn=true]

and was about to leave. Then Minami stopped me.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Minami098"]
[OnName num="minami"]
She said, "Wait a minute. I have something I want to tell Boo-chan.
[cpg cn=true]

She sat me down in a chair across the desk from her. She looked very serious.
[cpg]

[OnName num="norio"]
What do you want to talk about?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sMinami017"]
[OnName num="minami"]
You get nervous on every date, don't you? So I'm going to teach you a spell to make you less nervous.
[cpg cn=true]

I thought she was going to teach me something standard, so I wasn't prepared for it.
[cpg]

[free time=300]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[WAIT time=1000]

She suddenly approached me and stretched out her arms.
[cpg]

I had no time to refuse and she kissed me.
[cpg]

[free time=300]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMinami018"]
[OnName num="minami"]
I was not nervous, it's all about confidence. It's the accumulation of things like this.
[cpg cn=true]


I was taken aback and watched her walk away as if nothing had happened.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ
[jump target="*date_after"]
;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//デートパターン４（サブヒロイン）
;///////////////////////////////////////
*minami_date04|Date with Minami

;//[stflag Cha3cnt = 1]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

[OnName num="norio"]
"Today's date...do you have any requests?
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sMinami019"]
[OnName num="minami"]
She said, "You've started to tell me. You're growing up.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sMinami020"]
[OnName num="minami"]
I personally might like to see Boo's room.
[cpg cn=true]

I've never brought him up to the house if you ask me, still, I guess.
[cpg]

I think my parents are there. If they were out, I'd have to get everything done before they got back.
[cpg]

[free time=300]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Minami158"]
[OnName num="minami"]
I don't know where they are. I don't know the place, so you can lead the way today.
[cpg cn=true]

[OnName num="norio"]
"Well, even if you say that, ......
[cpg cn=true]


;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


In the end, I was still worried about my parents, so I asked them to wait until the next holiday.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Minami159"]
[OnName num="minami"]
That's right. We don't see much of each other's clothes.
[cpg cn=true]

The first thing to do is to make sure that your parents are out of the house when you come in.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Minami160"]
[OnName num="minami"]
I asked her to come when her parents were sure to be out of the house. Did you wait long?
[cpg cn=true]

[OnName num="norio"]
"No, no. Not at all.
[cpg cn=true]

We met in the city. Minami doesn't know where I live.
[cpg]

In the end, I'm glad I did this. I've been taken by her to places, but I don't get to experience the opposite very often.
[cpg]

You're right, Minami. Boo can lead.
[cpg]

[OnName num="norio"]
Let's go then. ......
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Minami161"]
[OnName num="minami"]
"Yes. Don't make me walk on the side of the road.
[cpg cn=true]

[OnName num="norio"]
"Oh, you're worried about that?"
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
I'm just kidding," said Minami, laughing. I can't pay attention to all of that.
[cpg]

I was so busy with that that I might not be able to have a conversation with her.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

I thought, "I'm not going to be able to concentrate on the conversation," but it was hard enough to concentrate on the conversation.
[cpg]

[OnName num="norio"]
I thought, "Oh, oh, have you eaten lunch?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Minami162"]
[OnName num="minami"]
What are you talking about? I said we'd meet up after lunch, didn't I?
[cpg cn=true]

[OnName num="norio"]
I know, right?
[cpg cn=true]

Words become more clenched than usual. My voice becomes quieter.
[cpg]

I wonder if they are going to go up to my house. Or rather, are they going up to my room?
[cpg]

I felt like I couldn't stand still. Or maybe I'm standing now.
[cpg]

I'm not standing, but I'm ...... Oh God, I can feel the unimportant thoughts spinning around and around in my head at a high speed.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Minami163"]
[OnName num="minami"]
"Hey, you're walking too fast,...... too nervous."
[cpg cn=true]

[OnName num="norio"]
Oh, I'm sorry. Sorry."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
For some reason, I say it twice. Then I slow down my walk.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


And then I arrived. In front of my house. I had arrived.
[cpg]

[OnName num="norio"]
"Come in. ......"
[cpg cn=true]

I open the door, but I wonder if this is the right order.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Minami164"]
[OnName num="minami"]
"Yes. Good evening.
[cpg cn=true]

There is no correct way to do this. Who decided that a man should walk on the side of the road in the first place?
[cpg]

I don't have to care, I don't have to care, the more I think ......, the more I care.
[cpg]

Am I doing something weird now?　Am I doing the right thing in getting the girl up to my room?
[cpg]

[window target=false]
[free time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************

[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Minami165"]
[OnName num="minami"]
"Heh. I wonder if it's like this in Boo-chan's room. It's pretty normal. But a little nerdy?
[cpg cn=true]

[OnName num="norio"]
"Yeah, I guess so. ......
[cpg cn=true]

In truth, it was a bit more cluttered. I cleaned it up for today.
[cpg]

That was one of the reasons why I asked him to wait until the holiday.
[cpg]

;//ＢＫ
;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

Then we had a good time. It could be said that it was a time of triviality.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[OnName num="norio"]
I said to myself, "Oh, ...... it's late. Well then, my parents will be back soon.
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Minami193"]
[OnName num="minami"]
I'd like to meet them if it's true. If it's true, I'd like to meet them.
[cpg cn=true]

[OnName num="norio"]
I don't know how to introduce them. I don't know how to introduce you."
[cpg cn=true]


Well, it can't be helped. ...... and looked a little sad.
[cpg]

I made a sad face. I'm sure I didn't make that up.
[cpg]

[OnName num="norio"]
I said, "...... Umm, yes. Then, I'll walk you to Minami's house.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Minami194"]
[OnName num="minami"]
I'm sure it's not my imagination.　Then we can talk some more.
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

So we walked to Minami's house.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Minami195"]
[OnName num="minami"]
I'm sure you're happy, Boo. You look good.
[cpg cn=true]

I wonder if that's true. But I didn't feel bad about it.
[cpg]

[OnName num="norio"]
I guess so, thank you.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Minami196"]
[OnName num="minami"]
I think it's good to have confidence little by little. I'm happy with that.
[cpg cn=true]

She even called me happy. If I had the guts, I would be able to hug her right now.
[cpg]

In public. It's not very likely, but it's not possible.
[cpg]

[OnName num="norio"]
...... Oh, oh, thank you."
[cpg cn=true]

The first thing to do is to make sure that you have a good time with your friends and family.
[cpg]

[jump target="*date_after"]
;//////////////////////////////////////////////////////////////////////
*date_after


[stflag DAY_1 = 0]
[stflag DAY_2 = 0]
[stflag DAY_3 = 0]
[stflag DAY_4 = 0]
[stflag DAY_5 = 0]
[stflag DAY_6 = 0]

;//[if exp={getFlagValue("DAY_6") == 1 }]
;//[jump target="*rast_sel"]
;//[endif]
;//[if exp={getFlagValue("DAY_5") == 1 }]
;//[jump target="*day05_after"]
;//[endif]

;//シナリオ調整で４日目が終わるとどのヒロインを選ぶかの選択肢へ
[if exp={getFlagValue("DAY_4") == 1 }]
;//[jump target="*rast_sel"]
;//[jump target="*day04_after"]
[jump storage="ep007.ks" target="*rast_sel"]
[endif]

[if exp={getFlagValue("DAY_3") == 1 }]
;//[jump target="*day03_after"]
[jump storage="ep006.ks" target="*day03_after"]
[endif]

[if exp={getFlagValue("DAY_2") == 1 }]
;//[jump target="*day02_after"]
[jump storage="ep006.ks" target="*day02_after"]
[endif]

;//[jump target="*day01_after"]
[jump storage="ep005.ks" target="*day01_after"]

;//[if exp={getFlagValue("DAY_1") == 1 }]
;//[jump target="*day01_after"]
;//[endif]


;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//未奈美　契約最後のデート

;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//最後のデート　途中のシーン（サブヒロイン）
;///////////////////////////////////////
*minami_last_date_common|Last date with Minami

;//========================================
;//●ＣＧ（主人公に密着するヒロイン）ev_34
;//人物１：サブヒロイン
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：室内　特定の場所ではないです
;//時間　：昼くらい　特定の時間ではないです
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sMinami021"]
[OnName num="minami"]
'Hey, have you gotten used to girls a little?
[cpg cn=true]


[OnName num="norio"]
"......, you're close.
[cpg cn=true]


[VOICE f="sMinami022"]
[OnName num="minami"]
"Well, you're not used to them, are you?"
[cpg cn=true]


[VOICE f="sMinami023"]
[OnName num="minami"]
I guess that's because I'm too attractive.
[cpg cn=true]


I laughed as I said this.
[cpg]


;//移植のためシーンをカットしています

[if exp={getFlagValue("Last_root") == 1 }]
[jump target="*return_minami_last_date1"]
[endif]

[if exp={getFlagValue("Last_root") == 2 }]
[jump target="*return_minami_last_date2"]
[endif]

[jump target="*return_minami_last_date3"]
;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//契約最後のデート　パターン１（サブヒロイン）
;///////////////////////////////////////

*minami_last_date1|Last date with Minami

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

Finally, the last day of the contract.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Minami214"]
[OnName num="minami"]
I said, "Okay, bye. Are you ready for tomorrow?
[cpg cn=true]

[OnName num="norio"]
"..."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Minami215"]
[OnName num="minami"]
"...... for a minute. You'll answer me, won't you?
[cpg cn=true]

[OnName num="norio"]
No, I'm not. I'm ready. I'm fine.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Minami216"]
[OnName num="minami"]
I hope so. Then, I'll see you tomorrow.
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


I felt a little nervous as I walked.
[cpg]

I don't feel like I'm walking. What is wrong with me?
[cpg]

I'm pretty sure I'm not in a normal state of mind anymore. But I think I'll confess when I get here.
[cpg]

I wonder if I'll remember it later and end up going to ......, which I can't remember very well.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

With this worry in mind, on the day of the meeting, I said, "Ojamashimasu!
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

[FACE method="change_2" pos="2/3"]
[VOICE f="Minami217"]
[OnName num="minami"]
excuse me for disturbing you
[cpg cn=true]

Minami looked as usual. But she looked cuter than usual.
[cpg]

I wondered what I was going to do from here. I'm not going to do it suddenly.
[cpg]

I've done a lot of image training, but in the end I don't really know what to do.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sMinami024"]
[OnName num="minami"]
What do you want me to do?　Don't you have anything you want to talk about?
[cpg cn=true]

[OnName num="norio"]
No, no. I have a lot.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

Minami is kind. She is too kind to be too kind.
[cpg]

I might not have thought so at first.
[cpg]

But she understands my feelings very well.
[cpg]


;//ＢＫ

[jump target="*minami_last_date_common"]

;//
;//シーン「最後のデート　途中のシーン」をここに挿入
;//

*return_minami_last_date1|Last date with Minami

;//========================================
;//●ＣＧ（主人公にのしかかるヒロイン）ev_35
;//人物１：サブヒロイン
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

And she came even closer.
[cpg]

So close that I have no choice but to kiss her now.
[cpg]

[VOICE f="sMinami025"]
[OnName num="minami"]
She said, "You didn't forget the spell to keep you from getting nervous, did you?"
[cpg cn=true]


And as she says this, we get even closer.
[cpg]

The moment their lips touched was an unspeakable feeling.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

But then night came, and my parents were about to return home.
[cpg]

We had no choice but to part ways. If my parents found out what we were doing, it would be a disaster.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Minami244"]
[OnName num="minami"]
I said, "Well, I'd better go home. I'll be sorry to see you go.
[cpg cn=true]

[OnName num="norio"]
"......, Minami."
[cpg cn=true]

Oh. It's hard. It's not like it's goodbye for life.
[cpg]

In the end, I didn't have the courage to confess.
[cpg]

But Minami really gave me confidence.
[cpg]

I can say that she changed my life. The only words that came out of my mouth were, "Thank you.
[cpg]

[OnName num="norio"]
Thank you.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Minami245"]
[OnName num="minami"]
You're welcome. I'll see you at the school from Monday.
[cpg cn=true]

That's right. I'll see her again.
[cpg]

And yet, ...... I can't help but have mixed feelings.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

After Minami left, I was alone in the room. It seemed as if I was being left behind.
[cpg]

The loneliness of the room is more apparent even though it should be a familiar room.
[cpg]

I think to myself, "Oh well, the contract is over. That's what I think.
[cpg]

Minami and I are back to our old relationship, or even more so.
[cpg]

I think we can be closer than before the contract. And yet ......
[cpg]

I had a helpless feeling of emptiness.
[cpg]

I wonder if I am a small person after all. Or was Minami too big for me?
[cpg]

I'm not sure anymore: ......
[cpg]

[jump target="*minami_nomal_end"]
;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//契約最後のデート　パターン２（サブヒロイン）
;///////////////////////////////////////

*minami_last_date2|Last date with Minami

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


After school. I was very nervous.
[cpg]

I can't help but be nervous. Today is the day.
[cpg]

It's the day of the battle. When I say "battle," you might be asking if I'm going to fight. ......
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Minami246"]
[OnName num="minami"]
I'm not going to have much time now, so let's go to my place. We don't have much time now, so let's hurry.
[cpg cn=true]

Minami pulled me by the hand. I was pulled along by Minami's hand and followed her.
[cpg]

[OnName num="norio"]
I followed her as she pulled me along.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="sMinami026"]
[OnName num="minami"]
I can't wait. I'm not just talking about you, Boo.
[cpg cn=true]

They say things that make you gulp. But it's true, I'm not ready.
[cpg]

Will I really be able to confess my feelings today?
[cpg]

I don't really feel like it, and I'm starting to think that all the time I've spent with him up until now was just a dream.
[cpg]

Of course, I know it's not true, and I know it won't be a dream from now on.
[cpg]

That is why I am not prepared for this. Since I met her, the passage of time has been like a roller coaster.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sMinami027"]
[OnName num="minami"]
Look, I'll walk quickly."
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

While we were talking like that, we reached Minami's house.
[cpg]



[jump target="*minami_last_date_common"]

;//
;//シーン「最後のデート　途中のシーン」をここに挿入
;//

;//移植のためシーンをカットしています

*return_minami_last_date2|Last date with Minami

;//ＢＫ

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

For a while, I was unable to confess.
[cpg]

Or rather...I was unable to confess. Still, she did not pressure me.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

Then, I left her house and went to her front door.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Minami273"]
[OnName num="minami"]
I said, "I don't know. Will it be a good memory?"
[cpg cn=true]

[OnName num="norio"]
"Well, of course, I don't have to tell you ......."
[cpg cn=true]

That's great," she says and smiles. I am really, really disturbed when I see this girl's smile.
[cpg]

It's not beautiful, it's not cute, it's disturbing.
[cpg]

In fact, it's probably disturbed because it's beautiful or cute. ......
[cpg]

My smile wouldn't move anyone's heart. Really, Minami, you are sneaky.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Minami274"]
[OnName num="minami"]
What's wrong with your face? You did it so why don't you smile?
[cpg cn=true]

I smiled unnaturally.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Minami275"]
[OnName num="minami"]
Yeah, that face. Norio is so charming there when he smiles, so don't forget to smile.
[cpg cn=true]

Minami says this to me even though it should have been an unnatural smile. I am overcome by her kindness.
[cpg]

[OnName num="norio"]
Thank you," she said. I feel like a new person.
[cpg cn=true]

"You say that much?　I'm like a new person," Minami says, smiling again.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Minami276"]
[OnName num="minami"]
Thank you, too. It was fun to see so many different Boo-chan.
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

I wave to Minami and walk home alone.
[cpg]

The heat gradually cools and the wave of happiness recedes.
[cpg]

I felt overly sentimental, and I was puzzled.
[cpg]

Is this the end? The contract, everything.
[cpg]

Of course, this is not the end of my relationship with Minami. I understand that much.
[cpg]

But I feel as if the connection between me and her has been severed here.
[cpg]

I wonder if it's just my imagination. I wonder if I will be able to get along with her again.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I couldn't sleep last night. But I think I can sleep well today.
[cpg]

Even though I am in such tremendous loneliness, somehow the most difficult part of the day has passed.
[cpg]

I can feel my body relaxing. That's why I'm afraid of loneliness.
[cpg]

My relaxed and calm head feels loneliness. I didn't like that.
[cpg]

The loneliness I feel in the middle of the chaos, when the chaos goes away, that's the end of it. ......
[cpg]

The loneliness I feel in the calm now is going to last forever.
[cpg]

Minami. I can't help but remember her smile.
[cpg]

...... Minami.
[cpg]

[jump target="*minami_nomal_end"]
;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//契約最後のデート　パターン３（サブヒロイン）
;///////////////////////////////////////
*minami_last_date3|Last date with Minami

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


Our last date under our contract was to be in the classroom.
[cpg]

I can't have a proper date on campus. So...
[cpg]

This is a prelude to a confession.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="sMinami028"]
[OnName num="minami"]
"Wait a minute. Aren't you going to say anything?"
[cpg cn=true]


But I was too nervous to say anything.
[cpg]


;//☆
;//========================================
;//●ＣＧ（主人公にのしかかるヒロイン）ev_49
;//人物１：サブヒロイン
;//服装１：制服
;//人物３：主人公
;//服装３：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_49_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//移植のためシーンをカットしています

[VOICE f="sMinami029"]
[OnName num="minami"]
If you don't have anything to say, I'll do it myself.
[cpg cn=true]


She moved closer to me.
[cpg]

She was leaning over me. There was no escape.
[cpg]

And then her lips came close to mine...
[cpg]

Even in this situation, I couldn't take the first step of confession.
[cpg]


;//ＢＫ


;//移植のためシーンをカットしています

[jump target="*minami_nomal_end"]

;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//未奈美エンディング
*start|If you don't enjoy life, it's a loss.

;#################################################
*Ep012|If you don't enjoy life, it's a loss.
;#################################################

*minami_nomal_end|If you don't enjoy life, it's a loss.

[SCENE id=12]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************

A few days after that dreamy day with Minami.
[cpg]

I was like a shell. Or perhaps a shell itself.
[cpg]

It was as if I had no spirit in my body. I tend to be in a daze a lot, and I can't even take my classes properly. ......
[cpg]

I never thought that the days with Minami, no matter how much fun I had with her, would bring such a backlash.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Minami317"]
[OnName num="minami"]
Good morning, Boo.
[cpg cn=true]

[OnName num="norio"]
Good morning. You're looking good today.
[cpg cn=true]

But I no longer behave suspiciously when I talk with Minami.
[cpg]

I think it's a sign that I've gained confidence.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Minami318"]
[OnName num="minami"]
Of course. Norio's face has changed a bit. He looks good.
[cpg cn=true]

That may be so. I wonder if it is also a change due to his self-confidence.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



But I still think back to those dreamy days.
[cpg]

My relationship with Minami is good. We greet each other and talk.
[cpg]

But the contract is over. The dreamy time is over.
[cpg]

[OnName num="norio"]
Huh......
[cpg cn=true]

I sigh naturally. This is not a matter of confidence.
[cpg]

It's just a feeling that it has passed.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

After school. I was in a kind of daze in the empty classroom.
[cpg]

It was a sentimental feeling. I look at the town dyed in the evening glow.
[cpg]

[OnName num="norio"]
Huh......
[cpg cn=true]

I sighed for the first time today. And then ......
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Minami319"]
[OnName num="minami"]
What are you sighing about? What's wrong?
[cpg cn=true]

I can't tell you what's wrong.
[cpg]

[OnName num="norio"]
"I can't ...... tell you.
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Minami320"]
[OnName num="minami"]
"Go ahead, talk to her. I'm here to help you with anything, okay?
[cpg cn=true]

[OnName num="norio"]
"......"
[cpg cn=true]

He goes so far as to say. I wondered if it was okay to talk a little.
[cpg]

After thinking about it, I decided to open up a little.
[cpg]

[OnName num="norio"]
I can't forget those days. I can't forget those days.
[cpg cn=true]

[OnName num="norio"]
I think I've changed in the time I've spent with Minami.
[cpg cn=true]


The days that seemed like a dream had passed. I told her how I felt.
[cpg]

I was thinking that even if I talked about it, there was nothing I could do about it.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sMinami030"]
[OnName num="minami"]
"Pfft...... ahaha!"
[cpg cn=true]

[OnName num="norio"]
Eh......?"
[cpg cn=true]

Minami was laughing. I thought for sure that the mood would be like, I can't do anything for you.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="sMinami031"]
[OnName num="minami"]
You think so much of me?
[cpg cn=true]

You don't have to laugh this much, do you? I was embarrassed and put my face down.
[cpg]

But what he said after that was something I couldn't believe my ears.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sMinami032"]
[OnName num="minami"]
It's okay, do you want to go on another date?"
[cpg cn=true]

[OnName num="norio"]
Why?
[cpg cn=true]

Minami says, "By all means, you don't have anything.
[cpg]

I told her I couldn't forget those days, but there was no more contract or anything.
[cpg]

[OnName num="norio"]
I said I couldn't forget those days, but there's no contract or anything.　There's no reason for you to do it with me.
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="sMinami033"]
[OnName num="minami"]
Why not just because I like you?"
[cpg cn=true]

...... is not a waste of time. It's good.
[cpg]

;//移植のためシーンをカットしています

[OnName num="norio"]
I'm sure it's ...... good.　I feel like I'm dreaming.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Minami344"]
[OnName num="minami"]
"No, it's not a dream. I told you it's not a dream, it's not all a dream.
[cpg cn=true]

I've been saying that a lot, come to think of it.
[cpg]

No wonder Minami is laughing at me. When will we learn to accept reality as reality?
[cpg]

I wonder when I will be able to accept reality as it is. I'm sure I can be more proud.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Minami345"]
[OnName num="minami"]
I'm sure I'll be able to be more proud. Let's go home together on the way.
[cpg cn=true]

[OnName num="norio"]
I'll go with you on the way back. Let's go.
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

I think I've been intimidated by something I don't understand all this time.
[cpg]

I thought it was because of my appearance, but I am sure it is not true.
[cpg]

It's all in the mind. The way we look at others, and even the way we look at ourselves, changes depending on how we look at ourselves.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Minami346"]
[OnName num="minami"]
You look happy. If you miss me that much, I'm embarrassed.
[cpg cn=true]

[OnName num="norio"]
I'm happy. I'm really happy.
[cpg cn=true]

It doesn't rise to the point that I am the happiest person in the world, but it really is just a little bit, just a little bit more.
[cpg]

But I'm really going to be a little bit, a little bit more proud of myself.
[cpg]

I think I can still admit that I am who I am.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Minami347"]
[OnName num="minami"]
I am happy. You have to enjoy your life.
[cpg cn=true]


;//ＢＫ


[if exp={getFlagValue("Cha2cnt") >= 4 }]
[jump target="*tugumi_true_end"]
[endif]


;/サブヒロインノーマルＥＮＤ
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//『未奈美エンディング』
*start|Best friend contract?

;#################################################
*Ep013|Best friend contract?
;#################################################

*minami_true_end|Best friend contract?

[SCENE id=13]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

;//========================================
;//●ＣＧ（腕を組んで歩く）ev_39
;//人物１：サブヒロイン
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：街
;//時間　：昼
;//========================================

;**【ＣＧ】 ev_39_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="Minami348"]
[OnName num="minami"]
Here you go. Boo-chan.
[cpg cn=true]

[OnName num="norio"]
Minami. I just got here.
[cpg cn=true]

[VOICE f="Minami349"]
[OnName num="minami"]
"Hey, how long are you going to call me that?"
[cpg cn=true]

[OnName num="norio"]
But...
[cpg cn=true]

[VOICE f="Minami350"]
[OnName num="minami"]
You can call me Minami.
[cpg cn=true]

[OnName num="norio"]
I'm still a little embarrassed.
[cpg cn=true]

[VOICE f="sMinami034"]
[OnName num="minami"]
What? It's a little too late for that."
[cpg cn=true]

In fact, I'm still in a relationship with her even after the contract is over.
[cpg]

It's not that we became lovers. It's kind of like, it's not like Minami's personality...best friend?
[cpg]

In other words, it's like a new best friend contract.
[cpg]

[VOICE f="Minami354"]
[OnName num="minami"]
Here we go!
[cpg cn=true]

[OnName num="norio"]
Whoa, hey."
[cpg cn=true]

In a few hours, I'll be calling her Minami.
[cpg]

But...this relationship isn't so bad. It's great.
[cpg]

Every day is fun.
[cpg]

I've been able to change because of her.
[cpg]

Thank you, Minami.
[cpg]


[SCENE id=17]

;/サブヒロイントゥルーＥＮＤ
;//未奈美END　終わり

[jump storage="epend.ks" target="*start"]
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//通常END
;//フラグの都合上通ることはない
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************
The hectic days are over, and the usual routine has returned.
[cpg]
After the contract was over, I never saw her again.
[cpg]
The way she treats me is the same as before.
[cpg]
I wonder if it might have really been a dream.
[cpg]
But I can't forget the shock of that first time.
[cpg]
It's engraved in my memory for sure.
[cpg]
I wonder if I could have changed a little. ......
[cpg]
;//通常END　終わり
[jump storage="epend.ks" target="*backtitle"]
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
