;//１回目　日常イベント
;//日常イベントはキャラ共通です。どのヒロインのＨシーンに行くかはフラグにより変化します

*start|The Beginning of a Temporary Love Contract


;#################################################
*Ep004|The Beginning of a Temporary Love Contract
;#################################################


*day01|The Beginning of a Temporary Love Contract

[SCENE id=4]

[stflag DAY_1 = 1]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[OnName num="norio"]
Ugh...oh no, I'm not sleeping well.
[cpg cn=true]

I can't sleep well these days. Maybe I am expecting too much for the future.
[cpg]

My feet naturally went to a certain person.
[cpg]

[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*day01_1"]
[endif]

[switch]
[case "Airi"]
	[swap]
	[jump target="*day01_1"]
[case "Tsugumi"]
	[swap]
	[jump target="*day01_2"]
[case "Minami"]
	[swap]
	[jump target="*day01_3"]
[endswitch]


;//■選択肢
1, Airi
2, Tsugumi
3, Minami

;//※２，３は参戦してから
;//選択が発生しない場合はそのヒロインの方へ

;//※以降、日常イベントの時には毎回同じ選択肢が発生します

;//*day01_1|仮恋契約の始まり
;//[jump target="*airi_date"]
;//*day01_2|仮恋契約の始まり
;//[jump target="*tugumi_date"]
;//*day01_3|仮恋契約の始まり
;//[jump target="*minami_date"]

;//////////////////////////////////////////////////////////////////////
*day01_1|The Beginning of a Temporary Love Contract

;//ＢＫ
;//愛莉パターン
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi124"]
[OnName num="airi"]
"Norio, are you okay?"
[cpg cn=true]

[OnName num="norio"]
"What?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sAiri005"]
[OnName num="airi"]
You look a little red.
[cpg cn=true]

[OnName num="norio"]
That's...
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="sAiri006"]
[OnName num="airi"]
"Are you expecting to see me?"
[cpg cn=true]

It seems that he saw my condition and guessed it.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Airi128"]
[OnName num="airi"]
I'm fine. I'll take care of it.
[cpg cn=true]

[OnName num="norio"]
I'll take care of it.
[cpg cn=true]


;//ＢＫ
[jump target="*airi_date"]
;//////////////////////////////////////////////////////////////////////
;//つぐみパターン
*day01_2|The Beginning of a Temporary Love Contract

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi064"]
[OnName num="tugumi"]
"Hey, Mr. Futabara. Are you okay?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
;//[VOICE f="Tugumi065"]
[VOICE f="sTugumi003"]
[OnName num="tugumi"]
;//「いえ、何だか顔色が優れないみたいだから…」
You seem a little pale.
[cpg cn=true]

[OnName num="norio"]
That's...
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Tugumi066"]
[OnName num="tugumi"]
...... Oh, that's what I mean."
[cpg cn=true]

It seems that he saw my condition and guessed it.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="sTugumi004"]
[OnName num="tugumi"]
I guess I can take that as a sign of anticipation.
[cpg cn=true]

[OnName num="norio"]
I'm sorry...
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Tugumi069"]
[OnName num="tugumi"]
"Don't be sorry. I'll take care of it.
[cpg cn=true]

[jump target="*tugumi_date"]

;//////////////////////////////////////////////////////////////////////
;//未奈美パターン　シナリオ追加
;//@
*day01_3|The Beginning of a Temporary Love Contract

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Minami097"]
[OnName num="minami"]
"......, what's up?　Just spaced out.
[cpg cn=true]

[OnName num="norio"]
"No...well..."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Minami037"]
[OnName num="minami"]
"Pfft. I'm sorry for being so fidgety.
[cpg cn=true]

It seems that he saw my condition and guessed it.
[cpg]

[OnName num="norio"]
I'm sorry...
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Minami9067"]
[OnName num="minami"]
It's okay, it's okay.
[cpg cn=true]

[OnName num="norio"]
I'm looking forward to working with you..."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Minami038"]
[OnName num="minami"]
Hmm. Okay. I got it.
[cpg cn=true]


[jump target="*minami_date"]


;//ヒロイン１へ
;//ヒロイン２へ



*airi_date|The Beginning of a Temporary Love Contract
[jump storage="ep008.ks" target="*airi_date"]
*tugumi_date|The Beginning of a Temporary Love Contract
[jump storage="ep010.ks" target="*tugumi_date"]
*minami_date|The Beginning of a Temporary Love Contract
[jump storage="ep012.ks" target="*minami_date"]


;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
