;//ハーレム
;//三重契約をした場合に発生
;//※４を選んだ場合
*start|Temporary Love Triple Contract

;#################################################
*Ep014|Temporary Love Triple Contract
;#################################################

*root_4|Temporary Love Triple Contract

[SCENE id=14]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[FACE method="bow_7" pos="2/3"]
[VOICE f="Tugumi380"]
[OnName num="tugumi"]
"Mr. Futabara, may I have a word with you?"
[cpg cn=true]

[OnName num="norio"]
"Yes, Mr. Kiritani. What's wrong?
[cpg cn=true]

[FACE method="shake_3" pos="1/3"]
[VOICE f="Airi397"]
[OnName num="airi"]
What's wrong? I'm in trouble, Tsugumi.
[cpg cn=true]

[FACE method="bow_2" pos="3/3"]
[VOICE f="Minami355"]
[OnName num="minami"]
Really, really.
[cpg cn=true]

[OnName num="norio"]
Why are you all here?
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Tugumi381"]
[OnName num="tugumi"]
You know why we're all here, don't you?
[cpg cn=true]

[OnName num="norio"]
Yes.
[cpg cn=true]

It seems to me that this means that they already know.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[FACE method="bow_7" pos="3/3"]
[VOICE f="sMinami035"]
[OnName num="minami"]
"......, what are we going to do about this no-nonsense?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi382"]
[OnName num="tugumi"]
"What do you mean, what do you mean?"
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[VOICE f="Airi398"]
[OnName num="airi"]
"I didn't see anything in the contract about this, did I?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sTugumi022"]
[OnName num="tugumi"]
I didn't expect a three-timing.
[cpg cn=true]

I don't think it's three-timing, because we're not dating.
[cpg]

[FACE method="shake_1" pos="3/3"]
[VOICE f="Minami357"]
[OnName num="minami"]
Are we all out of contract?
[cpg cn=true]

[OnName num="norio"]
Oh no!
[cpg cn=true]

I can't say anything because it's my fault.
[cpg]

[FACE method="shake_7" pos="1/3"]
[VOICE f="Airi399"]
[OnName num="airi"]
What do you think about Tsugumi and Minami?
[cpg cn=true]

[FACE method="bow_7" pos="3/3"]
[VOICE f="Minami358"]
[OnName num="minami"]
"I don't mind the three of us together."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Tugumi384"]
[OnName num="tugumi"]
What? Well, that's... that's a little...
[cpg cn=true]

[FACE method="shake_2" pos="3/3"]
[VOICE f="sMinami036"]
[OnName num="minami"]
Because, Boo, you've been so hungry, haven't you?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi385"]
[OnName num="tugumi"]
Well, that's... but there's a fine line.
[cpg cn=true]

[FACE method="bow_2" pos="1/3"]
[VOICE f="Airiex001"]
[OnName num="airi"]
I agree with Minami. I agree with Minami. I think we should all be together now.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi386"]
[OnName num="tugumi"]
Even you. ......
[cpg cn=true]

;//ＢＫ
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

And then I was like, ......
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="3/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************



[FACE method="bow_2" pos="3/3"]
[VOICE f="sMinami037"]
[OnName num="minami"]
good morning
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]

There is a saying, "Two rabbits chase one another..." and we were getting close to that.
[cpg]

I had three more female friends, but no girlfriend.
[cpg]

But this was also the result I wanted.
[cpg]

It would be rude to say that I wasn't happy.
[cpg]

Rather, I was happy even without that.
[cpg]

[SCENE id=18]

;//ハーレムEND
;//ＥＮＤ

[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////

