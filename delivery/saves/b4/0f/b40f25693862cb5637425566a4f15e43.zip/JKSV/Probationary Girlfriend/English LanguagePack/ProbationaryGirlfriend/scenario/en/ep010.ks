;//最後のデートへの分岐条件『つぐみ』
;//つぐみとの最後のデートになった場合、最終分岐の選択肢の後に表示
*root_2|Last Date with Tsugumi


;#################################################
*EpRoot002|Last Date with Tsugumi
;#################################################

;//ＢＫ
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

Come on, we are already approaching the last date of our contract.
[cpg]

What kind of date shall we make?
[cpg]

;//選択は発生しません

Oh, my God. There's no use in trying to play tricks on me.
[cpg]

[OnName num="norio"]
I'll just say, "Yes, I'll do that. Okay, let's do that."
[cpg cn=true]


Yeah...I'm suddenly looking forward to it.
[cpg]

[jump target="*tugumi_last_date"]

;//*airi_last_date|つぐみとの最後のデート
;//[jump storage="ep000.ks" target="*tugumi_last_date"]


;//各筆下ろしのシーンへ
;////////////////////////////////////////////////////////////////////////////////////////
;////////////////////////////////////////////////////////////////////////////////////////



;////////////////////////////////////////////////////////////////////////////////////////
;////////////////////////////////////////////////////////////////////////////////////////
;//つぐみ
*tugumi_date|Date with Tsugumi

[stflag Cha2cnt = 1]

[if exp={getFlagValue("Cha2cnt") == 4 }]
[jump target="*tugumi_date04"]
[endif]
[if exp={getFlagValue("Cha2cnt") == 3 }]
[jump target="*tugumi_date03"]
[endif]
[if exp={getFlagValue("Cha2cnt") == 2 }]
[jump target="*tugumi_date02"]
[endif]

;//[if exp={getFlagValue("Cha2cnt") == 1 }]
;//[jump target="*tugumi_date01"]
;//[endif]

;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//デートパターン１（ヒロイン２）
;///////////////////////////////////////
*tugumi_date01|Date with Tsugumi

;//ＢＫ
;//☆

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）

;//@
After school. Me and Kiritani-san had come to a little-used classroom.
[cpg]

;//@
[OnName num="norio"]
She said it was to help me get used to being a girl. ...... is that okay?"
[cpg cn=true]

;//@
[FACE method="bow_2" pos="2/3"]
[VOICE f="Tugumi9154"]
[OnName num="tugumi"]
If you can help me with that, that's fine. ......
[cpg cn=true]


;//========================================
;//●ＣＧ（主人公に接近しているヒロイン）ev_06
;//人物１：ヒロイン２
;//服装１：制服
;//人物３：主人公
;//服装３：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_06_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

Ms. Kiritani approaches me.
[cpg]

I'm not even a girlfriend yet, but this distance makes me hesitant...
[cpg]

[VOICE f="sTugumi012"]
[OnName num="tugumi"]
What's wrong?"
[cpg cn=true]


[OnName num="norio"]
I look away, but I can't help but notice that he's very close to me.
[cpg cn=true]


I averted my gaze, but didn't say I was too close.
[cpg]

I guess I've grown up a little bit with this one.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ
[jump target="*date_after"]
;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//デートパターン２（ヒロイン２）
;///////////////////////////////////////
*tugumi_date02|Date with Tsugumi

;//[stflag Cha2cnt = 1]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

After signing a tentative love contract with Ms. Kiritani. I was not in a good mood.
[cpg]

I pay too much attention to her. Even though I know I shouldn't be excessive.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Tugumi120"]
[OnName num="tugumi"]
I was like, "......Tabefatu-kun. Can I talk to you for a minute?"
[cpg cn=true]

She calls out to me on her way home after school.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sTugumi013"]
[OnName num="tugumi"]
You're looking at me too much.
[cpg cn=true]

[OnName num="norio"]
"I'm sorry, I'm sorry. ......
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Tugumi122"]
[OnName num="tugumi"]
Follow me. I'm going to have problems with this from now on."
[cpg cn=true]

;//========================================
;//●ＣＧ（ヒロインはしゃがんでいて、主人公をまじまじと見ている）ev_02
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園廊下
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

And then, in the hallway of the school...
[cpg]

[OnName num="norio"]
Why are you staring at me like that?
[cpg cn=true]


[VOICE f="sTugumi014"]
[OnName num="tugumi"]
I'm just trying to make you understand how I feel.
[cpg cn=true]


No, I understand...but I'm so nervous in this situation.
[cpg]

I looked away, unable to say anything back.
[cpg]



;//移植のためシーンをカットしています

;//ＢＫ
[jump target="*date_after"]
;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//デートパターン３（ヒロイン２）
;///////////////////////////////////////
*tugumi_date03|Date with Tsugumi

;//[stflag Cha2cnt = 1]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

On the way home. Today, Kiriya-san is following behind me. Why is that? ......
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi142"]
[OnName num="tugumi"]
'It's not safe to walk if you're so nervous.
[cpg cn=true]

She was supposed to come to my house.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

I had almost forced Ms. Kiritani to come to my room because I needed to get used to girls.
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Tugumi143"]
[OnName num="tugumi"]
She said, "...... breasts, do they bother you that much?"
[cpg cn=true]

[OnName num="norio"]
I said, "No, it's not!　I didn't see them, I really ...... didn't see them.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi144"]
[OnName num="tugumi"]
I didn't see them. What does that lie mean?
[cpg cn=true]


They assume it's a lie. No, it's a lie.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Tugumi164"]
[OnName num="tugumi"]
Well, it's time for me to go home. Bye."
[cpg cn=true]

[OnName num="norio"]
"Uh-huh. See you later. ......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Tugumi165"]
[OnName num="tugumi"]
Yeah. I'm sure we'll meet here again, so be prepared.
[cpg cn=true]

I was told to be prepared.
[cpg]

But getting used to girls is still not something you can do overnight. ......
[cpg]

;//ＢＫ
[jump target="*date_after"]
;//////////////////////////////////////////////////////////////////////
;///////////////////////////////////////
;//デートパターン４（ヒロイン２）
;///////////////////////////////////////

*tugumi_date04|Date with Tsugumi
;//[stflag Cha2cnt = 1]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



Today, Kiriya-san comes to my house again.
[cpg]

I'm sure he comes often for me ......, but there was something I wanted him to clarify today.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi166"]
[OnName num="tugumi"]
What's wrong, Niyatsuki?　What's wrong, you're smiling.
[cpg cn=true]

[OnName num="norio"]
"What, I'm smirking ......?"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Tugumi167"]
[OnName num="tugumi"]
Yeah. I think it's a good trend, but it was just a little creepy.
[cpg cn=true]

I'm relentless...but I'd like to act natural someday.
[cpg]


;//========================================
;//●ＣＧ（主人公の部屋でくつろぐヒロイン。手を下ろしている形に変えられたら変えてください）ev_11
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================
;//[window target=false]
;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//;**【ＣＧ】 ev_11_0 ***********************
;//[CG id=13 index=0 time=1000]
;//;***************************************
;//[WAIT time=1000]
;//[window target=true]
;//移植のためシーンをカットしています


[FACE method="shake_4" pos="2/3"]
[VOICE f="sTugumi015"]
[OnName num="tugumi"]
I'm sorry. About earlier.
[cpg cn=true]


[OnName num="norio"]
What?　What are you talking about?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sTugumi016"]
[OnName num="tugumi"]
I said you were smiling. I thought it was creepy.
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="sTugumi017"]
[OnName num="tugumi"]
When I look closer, it's much nicer when you smile."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
He blushes a little when he says that.
[cpg]

[OnName num="norio"]
Thank you.
[cpg cn=true]


It seemed more natural for him to call me creepy. I was embarrassed.
[cpg]


;//移植のためシーンをカットしています
;//ＢＫ
;//移植のためシーンをカットしています


[jump target="*date_after"]
;//////////////////////////////////////////////////////////////////////
*date_after


[stflag DAY_1 = 0]
[stflag DAY_2 = 0]
[stflag DAY_3 = 0]
[stflag DAY_4 = 0]
[stflag DAY_5 = 0]
[stflag DAY_6 = 0]

;//[if exp={getFlagValue("DAY_6") == 1 }]
;//[jump target="*rast_sel"]
;//[endif]
;//[if exp={getFlagValue("DAY_5") == 1 }]
;//[jump target="*day05_after"]
;//[endif]

;//シナリオ調整で４日目が終わるとどのヒロインを選ぶかの選択肢へ
[if exp={getFlagValue("DAY_4") == 1 }]
;//[jump target="*rast_sel"]
;//[jump target="*day04_after"]
[jump storage="ep007.ks" target="*rast_sel"]
[endif]

[if exp={getFlagValue("DAY_3") == 1 }]
;//[jump target="*day03_after"]
[jump storage="ep006.ks" target="*day03_after"]
[endif]

[if exp={getFlagValue("DAY_2") == 1 }]
;//[jump target="*day02_after"]
[jump storage="ep006.ks" target="*day02_after"]
[endif]

;//[jump target="*day01_after"]
[jump storage="ep005.ks" target="*day01_after"]

;//[if exp={getFlagValue("DAY_1") == 1 }]
;//[jump target="*day01_after"]
;//[endif]


;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//つぐみ　契約最後のデート
*tugumi_last_date|Last Date with Tsugumi


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

And so, finally, the last day of the contract.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

Kiriya-san and I were alone in my room.
[cpg]

Silence...it would be cool to say, but just silence flows.
[cpg]

[OnName num="norio"]
"......"
[cpg cn=true]


Maybe today is the end of our relationship.
[cpg]

Or maybe there will be progress...
[cpg]

And it was she who broke the ice.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Tugumi003"]
[OnName num="tugumi"]
"Hey, Mr. Liddy."
[cpg cn=true]

[OnName num="norio"]
Ha, yes!"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi239"]
[OnName num="tugumi"]
...... this day has finally come. Are you ready for it?"
[cpg cn=true]

[OnName num="norio"]
"...... yes."
[cpg cn=true]

To be honest, I'm not ready. But...time will only fly by if you stay timid here.
[cpg]

The first thing you need to do is to be courageous and take the first step.
[cpg]

[OnName  num="norio"]
I don't know about you..."
[cpg cn=true]

I couldn't say "you," a word I was not used to saying.
[cpg]

I couldn't say anything after that.
[cpg]

;//ＢＫ
;//移植のためシーンをカットしています

;//========================================
;//●ＣＧ（あきれているヒロイン）ev_07
;//人物１：ヒロイン２
;//服装１：制服
;//人物３：主人公
;//服装３：制服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sTugumi018"]
[OnName num="tugumi"]
You really are a coward, aren't you?
[cpg cn=true]


[OnName num="norio"]
I'm sorry.
[cpg cn=true]


[VOICE f="sTugumi019"]
[OnName num="tugumi"]
You don't really have to apologize there, either."
[cpg cn=true]


Even though it is said. It's a reflex.
[cpg]

And today, even at a time like this, she was lovely.
[cpg]


;//移植のためシーンをカットしています
;//ＢＫ
;//移植のためシーンをカットしています
;//ＢＫ
;//ＢＫ
;//移植のためシーンをカットしています

[jump target="*tugumi_last_date_after"]

;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//つぐみ　契約後
;//分岐条件
;//つぐみルート（契約最後のデート）に到達した時、通常は契約後を経由してノーマルエンドへ
;//日常イベントの選択肢を全てつぐみにしてつぐみルートに行った場合は
;//契約後は発生せずに恋人エンドへ
*tugumi_last_date_after

[if exp={getFlagValue("Cha2cnt") >= 4 }]
[jump target="*tugumi_nomal_end"]
[endif]


;///////////////////////////////////////
;//本番後（ヒロイン２）
;///////////////////////////////////////

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[VOICE f="Tugumi316"]
[OnName num="tugumi"]
She said, "What's wrong?　I can't believe you called me."
[cpg cn=true]

We had already gone home. So we were both wearing casual clothes.
[cpg]

[OnName num="norio"]
I was wondering if this is the last time we're going to see each other.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi317"]
[OnName num="tugumi"]
...... a roundabout way of putting it. The actuality that you can't get a lot of these things done. You're able to say that.
[cpg cn=true]

What is this?　I wonder if it's OK, maybe it's like OK?
[cpg]

[OnName num="norio"]
Well, then, ......."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="sTugumi020"]
[OnName num="tugumi"]
I'm good, what do you want?"
[cpg cn=true]

;//移植のためシーンをカットしています

I just nod. But Kiritani-san gives me a little smile.
[cpg]

When I think about it this way, our relationship has changed a lot.
[cpg]

I have changed, and maybe Kiritani-san has changed, too.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Tugumi336"]
[OnName num="tugumi"]
When the time comes, I may mention you, so please let me know.
[cpg cn=true]

[OnName num="norio"]
What do you mean?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Tugumi337"]
[OnName num="tugumi"]
'Well, I'll see you later. See you at the school.
[cpg cn=true]

The truth was still in the dark. The truth is that I am in the dark.
[cpg]

[OnName num="norio"]
Well, then, ......."
[cpg cn=true]

I was also carried away and said so. I've not changed at this point either.
[cpg]

;//ＢＫ
;//移植のためシーンをカットしています

;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//『つぐみエンディング１』ノーマルエンド
;//分岐条件
;//つぐみルート（契約最後のデート）に到達した時、通常は契約後を経由してノーマルエンドへ
;//日常イベントの選択肢を全てつぐみにしてつぐみルートに行った場合は
;//契約後は発生せずに恋人エンドへ
*start|A Sense of Change

;#################################################
*Ep010|A Sense of Change
;#################################################

*tugumi_nomal_end|A Sense of Change

[SCENE id=10]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

The contract with Mr. Kiritani was successfully completed.
[cpg]

It may or may not be realistic.
[cpg]

I'm not sure about that.
[cpg]

But...I think I have changed a little. I would like to think so.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Tugumi355"]
[OnName num="tugumi"]
"Hey, Mr. Liddy."
[cpg cn=true]

[OnName num="norio"]
Kiritani-san.
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Tugumi356"]
[OnName num="tugumi"]
I'm supposed to collect your notes by after school today, but... you haven't turned them in yet, have you? Can you turn them in?"
[cpg cn=true]

[OnName num="norio"]
Oh, that's right. Here you go.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Tugumi357"]
[OnName num="tugumi"]
Thank you.
[cpg cn=true]

After what happened, I was nervous even if she talked to me.
[cpg]

But she was the same as usual. As if nothing had happened.
[cpg]

I was so excited to talk to her, but she was the same as usual.
[cpg]

[SE f="se002"]
;//【ＳＥ】『ガラガラ』

[WAIT time=1000]

[OnName num="teacher"]
"Hey, haven't you finished collecting the notebooks yet?"
[cpg cn=true]

Then that teacher came in.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Tugumi358"]
[OnName num="tugumi"]
I'm sorry. I've already finished collecting them.
[cpg cn=true]

[OnName num="teacher"]
"Oh, Kiriya. It's not your fault. It's because the others around you didn't turn in theirs in time.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi359"]
[OnName num="tugumi"]
No, it's not that.
[cpg cn=true]

[OnName num="teacher"]
You're a good guy.
[cpg cn=true]

;//[free time=1000]

[OnName num="norio"]
I'm sorry. It's not your fault, Kiritani-san.
[cpg cn=true]

I didn't want her to get angry because of me, so I started to tell her myself.
[cpg]

[OnName num="teacher"]
I thought it was you after all. I thought you might be.
[cpg cn=true]

[OnName num="teacher"]
'Okay, carry her to the staff room as punishment.
[cpg cn=true]

I somehow knew she was going to say that.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Tugumi360"]
[OnName num="tugumi"]
I knew he was going to say something like that. I'll be responsible for carrying it to the teacher's lounge.
[cpg cn=true]

[OnName num="teacher"]
You don't have to do that. You don't have to do that. Right?
[cpg cn=true]

;//[free time=1000]

[OnName num="norio"]
Huh?
[cpg cn=true]

[OnName num="teacher"]
All right, then, get your ass out of here. It's not manly of you to let a woman carry it.
[cpg cn=true]

I was the one who gave that order in the first place.
[cpg]

The actual fault is also mine. So I decided to listen to her and tried to take the bundle of notebooks from her.
[cpg]

[free time=300]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Tugumi361"]
[OnName num="tugumi"]
......"
[cpg cn=true]

I met her eyes as she stared at me.
[cpg]

His eyes were trying to say something. I know what he is trying to say.
[cpg]

[OnName num="norio"]
......"
[cpg cn=true]

That's right. Thanks to her, I must have changed.
[cpg]

No, it's not enough to want to think I've changed.
[cpg]

You have to want to change by yourself...by your own will.
[cpg]

I have to show that I have changed.
[cpg]

[free time=300]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[WAIT time=1000]

[OnName num="norio"]
"Sensei."
[cpg cn=true]

[OnName num="teacher"]
Hmm? What is it?
[cpg cn=true]

[OnName num="norio"]
Yes, sir. Here, this is for you.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=1000]

[OnName num="teacher"]
What?"
[cpg cn=true]

With that, the teacher was given half of the notebook bundle to hold.
[cpg]

The teacher took the notebook as if reflexively taking a thrown ball.
[cpg]

[OnName num="teacher"]
What are you talking about, you carry all these.
[cpg cn=true]

[OnName num="norio"]
Yes...but the teacher said that it's disgusting to let a woman carry it.
[cpg cn=true]

[OnName num="teacher"]
"That's why you're supposed to carry them."
[cpg cn=true]

[OnName num="norio"]
So you're a woman?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[OnName num="teacher"]
What?
[cpg cn=true]

[OnName num="norio"]
No, according to you, a man should carry it... but I thought there was no other girl here but you, Kiritani-san.
[cpg cn=true]

[OnName num="teacher"]
You...
[cpg cn=true]

[OnName num="norio"]
Are you saying you're the teacher?
[cpg cn=true]

[OnName num="teacher"]
Of course not! Are you kidding me?
[cpg cn=true]

[OnName num="norio"]
"Oh, so you're a guy. Then I'll take half.
[cpg cn=true]

[OnName num="teacher"]
I'm just saying...
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[OnName num="norio"]
"Sensei. By the way, Kiritani-san said you are a reliable and wonderful teacher.
[cpg cn=true]

[OnName num="teacher"]
......"
[cpg cn=true]

[OnName num="norio"]
"He said he's powerful and manly, and that he's very good."
[cpg cn=true]

[OnName num="teacher"]
"....... He said that he's a very kind man.
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Tugumi362"]
[OnName num="tugumi"]
The doctor is very kind. Even though he says harsh things with his mouth, at the end of the day, he helps us in this way. He really is a teacher's guru.
[cpg cn=true]

[OnName num="teacher"]
"......... Ohon. Well, you know.
[cpg cn=true]

[OnName num="teacher"]
"Okay, lid belly. We'll both carry you.
[cpg cn=true]

[OnName num="norio"]
Thank you.
[cpg cn=true]

[OnName num="teacher"]
"Mm."
[cpg cn=true]

As I followed the teacher walking in front of me, I turned around and gave her a small peace.
[cpg]

;//[FACE method="change_2" pos="2/3"]

;//========================================
;//●ＣＧエロ（笑顔でピースサインを返してくれるつぐみ）ev_30
;//人物１：ヒロイン２
;//服装１：制服
;//人物３：主人公
;//服装３：制服
;//場所　：学園廊下
;//時間　：夕方
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

She returned the piece with a smile I had never seen before.
[cpg]


[if exp={getFlagValue("Cha2cnt") >= 4 }]
[jump target="*tugumi_true_end"]
[endif]

;//ヒロイン２ノーマルＥＮＤ
;//END１　終わり
;//条件を満たしていた場合、エンド２へ続く

[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//『つぐみエンディング２』恋人エンド
*start|What I decided by my own will

;#################################################
*Ep011|What I decided by my own will
;#################################################

*tugumi_true_end|What I decided by my own will

[SCENE id=11]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

A little time passed.
[cpg]

My life changed little by little.
[cpg]

[OnName num="norio"]
"The movie was interesting, wasn't it?
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Tugumi363"]
[OnName num="tugumi"]
"Yes, it was."
[cpg cn=true]

I started to invite her out for fun. I started to invite her out to play with me, and I did it on my own.
[cpg]

I think I was less nervous in front of girls and was able to have normal conversations with them.
[cpg]

[OnName num="norio"]
Kiriya-san.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Tugumi364"]
[OnName num="tugumi"]
What?
[cpg cn=true]

[OnName num="norio"]
I'm really grateful to you, Kiriya-san. Thank you.
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Tugumi365"]
[OnName num="tugumi"]
Thank you is not necessary. I only approached you out of selfishness.
[cpg cn=true]

[OnName num="norio"]
But you still gave me a chance.
[cpg cn=true]

[OnName num="norio"]
I'll decide things on my own.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Tugumi366"]
[OnName num="tugumi"]
I'll make my own decisions. Yes, you're right. That's the best.
[cpg cn=true]

She smiles at me like that. I love her like that.
[cpg]

That's why I decided. I decided to have a firm will of my own.
[cpg]

[OnName num="norio"]
"Tsugumi Kiriya."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Tugumi367"]
[OnName num="tugumi"]
Yes, yes...?
[cpg cn=true]

[OnName num="norio"]
Will you go out with me?
[cpg cn=true]

[OnName num="norio"]
I like you.
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Tugumi368"]
[OnName num="tugumi"]
......"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Tugumi369"]
[OnName num="tugumi"]
Is that what you want?
[cpg cn=true]

[OnName num="norio"]
Of course.
[cpg cn=true]

[WAIT time=1000]

[FACE method="change_2" pos="2/3"]
[VOICE f="Tugumi370"]
[OnName num="tugumi"]
......
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Tugumi371"]
[OnName num="tugumi"]
You know, I'm a pain in the ass.
[cpg cn=true]

[OnName num="norio"]
You're less of a pain in the ass than I am, so that's okay."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Tugumi372"]
[OnName num="tugumi"]
"Pfft. Ha-ha-ha.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Tugumi373"]
[OnName num="tugumi"]
Then let's make a new contract.
[cpg cn=true]

[OnName num="norio"]
A contract?
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sTugumi021"]
[OnName num="tugumi"]
Yeah. A real sweetheart deal.
[cpg cn=true]

[OnName num="norio"]
...... yes.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Tugumi375"]
[OnName num="tugumi"]
"Well, I need you to sign here."
[cpg cn=true]

He says, and he puts his index finger to his lips.
[cpg]

[OnName num="norio"]
"Thumbprint?"
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Tugumi376"]
[OnName num="tugumi"]
"Mm-hm." "Okay."
[cpg cn=true]

[free time=300]
[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[OnName num="norio"]
"Hmm..."
[cpg cn=true]

[VOICE f="Tugumi377"]
[OnName num="tugumi"]
"Hmm. ......."
[cpg cn=true]

[free time=300]
[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Tugumi378"]
[OnName num="tugumi"]
"....... Yes, this concludes the contract.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Tugumi379"]
[OnName num="tugumi"]
I look forward to working with you... for a long time.
[cpg cn=true]

[OnName num="norio"]
"Yeah, that goes for me, too."
[cpg cn=true]

[SCENE id=16]

;//ヒロイン２トゥルーＥＮＤ
;//END２　終わり

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
