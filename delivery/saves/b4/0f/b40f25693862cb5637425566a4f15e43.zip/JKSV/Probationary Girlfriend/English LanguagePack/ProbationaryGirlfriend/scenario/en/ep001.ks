
*start|Airi remembers your name

;#################################################
*Ep001|Airi remembers your name
;#################################################

[SCENE id=1]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

[SE f="se027"]
;//【ＳＥ】『喧騒』

The next day at school was full of discomfort.
[cpg]

I didn't have my bag with me. I didn't bring it home with me.
[cpg]

I was the only one who went to school empty-handed.
[cpg]

[OnName num="norio"]
I felt like I was being watched.
[cpg cn=true]

I felt like I was being watched. The first thing you need to do is to make sure that you have the right tools to do the job.
[cpg]

I didn't like that and was on my way to the academy at a quick pace.
[cpg]

[VOICE f="Tugumi002"]
[OnName num="tugumi"]
......Butabara-kun.
[cpg cn=true]

;//[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Tugumi003"]
[OnName num="tugumi"]
"Butabara-kun."
[cpg cn=true]

[OnName num="norio"]
"Eh, ah...yes?"
[cpg cn=true]

He called me a name. A name I don't want to be called. I think I heard a laugh somewhere.
[cpg]

But that's not important now.
[cpg]

;//ＢＫ

;//========================================
;//●ＣＧ（ヒロイン２登場）ev_44
;//人物１：ヒロイン２
;//服装１：制服
;//人物３：主人公
;//服装３：制服
;//場所　：街　※通学中
;//時間　：昼
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="Tugumi004"]
[OnName num="tugumi"]
Good morning.
[cpg cn=true]

[OnName num="norio"]
"Uh...oh, good morning, yo."
[cpg cn=true]

I turned around and saw a girl.
[cpg]

She was not a stranger...but I remembered her from a corner of my memory.
[cpg]

[OnName num="norio"]
"Um, I think..."
[cpg cn=true]

[VOICE f="Tugumi005"]
[OnName num="tugumi"]
Tsugumi. Tsugumi Kiriya.
[cpg cn=true]

[OnName num="norio"]
Oh, yes. Yes, Mr. Kiriya. Your classmate...
[cpg cn=true]

[VOICE f="Tugumi006"]
[OnName num="tugumi"]
Yes. Yes, that's right.
[cpg cn=true]

I believe she was a member of the class committee.
[cpg]

[VOICE f="Tugumi007"]
[OnName num="tugumi"]
I wish I could at least remember her name.
[cpg cn=true]

[OnName num="norio"]
I'm sorry.
[cpg cn=true]

[VOICE f="Tugumi008"]
[OnName num="tugumi"]
That's okay. I'm not accusing you of anything.
[cpg cn=true]

It's certainly rude not to remember the names of your classmates, isn't it?
[cpg]

I always didn't remember them because I didn't have contact with most of them and I didn't need to.
[cpg]

I'll reflect on that in a moment.
[cpg]

[OnName num="norio"]
Oh, good morning.
[cpg cn=true]

[VOICE f="Tugumi009"]
[OnName num="tugumi"]
?　If you wanted to say hello, you would have done so earlier.
[cpg cn=true]

[OnName num="norio"]
I know, I know! I'm sorry.
[cpg cn=true]

I was wondering what to say, and it just came out of my mouth.
[cpg]

I am aware that I am a communicator, but it's a terrible thing.
[cpg]

I mean, why did she bother to talk to me?
[cpg]

[OnName num="norio"]
Um...what is it?"
[cpg cn=true]

[VOICE f="Tugumi010"]
[OnName num="tugumi"]
I didn't say "something..." I said, "I'm here because I need to talk to you. I asked her because I had something to do.
[cpg cn=true]

Oh, I see.
[cpg]

I know I'm probably talking nonsense, but, you know, it's hard to feel a little cold.
[cpg]

[VOICE f="Tugumi011"]
[OnName num="tugumi"]
Here you go.
[cpg cn=true]

[OnName num="norio"]
"Is this my bag?"
[cpg cn=true]

The one she held out to me was definitely mine.
[cpg]

I left my bag in the classroom yesterday.
[cpg]

[VOICE f="Tugumi012"]
[OnName num="tugumi"]
I checked the classroom after school yesterday and found it there.
[cpg cn=true]

[VOICE f="Tugumi013"]
[OnName num="tugumi"]
I'm sorry for invading your privacy, but I had to take a look inside.
[cpg cn=true]

[VOICE f="Tugumi014"]
[OnName num="tugumi"]
There were some valuables in there, and it wasn't safe to leave them there, so I took them.
[cpg cn=true]

[OnName num="norio"]
I see.
[cpg cn=true]

I was not able to do that yesterday and left it there... but it was still there with my wallet and all sorts of other things.
[cpg]

It seems I've inconvenienced her to the fullest extent.
[cpg]

[OnName num="norio"]
"Oh, thank you..."
[cpg cn=true]

[VOICE f="Tugumi015"]
[OnName num="tugumi"]
"No problem. I'm on the class committee.
[cpg cn=true]

I'm a member of the class committee.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

;//[window target=false]
;//[free time=1000]
;//[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
;//[BG f="b_03_2.ui" time=1000]
;//[WAIT time=2000]
;//[window target=true]
;//[WAIT time=100]

;//[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi016"]
[OnName num="tugumi"]
She said, "......, what's wrong?"
[cpg cn=true]

[OnName num="norio"]
What?"
[cpg cn=true]

;//[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi017"]
[OnName num="tugumi"]
"I'm not going to the school."
[cpg cn=true]

Does that imply that I should go with her?
[cpg]

[OnName num="norio"]
I'm going. I'll go, but... you're going to have to walk away.
[cpg cn=true]

;//[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi018"]
[OnName num="tugumi"]
Why?
[cpg cn=true]

[OnName num="norio"]
Because... if you stay with me, you'll...
[cpg cn=true]

;//[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi019"]
[OnName num="tugumi"]
We're going to the same school, same classroom, so there's nothing wrong with us going together.
[cpg cn=true]

[OnName num="norio"]
Ah."
[cpg cn=true]

;//[free time=1000]

With that said, he walks away without looking back this time.
[cpg]

After a little hesitation, I decided to walk a little behind her.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』


[window target=false]
[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=3000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi020"]
[OnName num="tugumi"]
I was going to give it to you in the classroom... but I thought it would be better somewhere else because of the publicity.
[cpg cn=true]

[OnName num="norio"]
I see...thanks."
[cpg cn=true]

Naturally, no conversation ensued. Not a word.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi021"]
[OnName num="tugumi"]
I often forget.
[cpg cn=true]

[OnName num="norio"]
What?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi022"]
[OnName num="tugumi"]
My bag.
[cpg cn=true]

[OnName num="norio"]
No, I've never forgotten.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Tugumi023"]
[OnName num="tugumi"]
Of course it is. It's something you carry around with you.
[cpg cn=true]

[OnName num="norio"]
What?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi024"]
[OnName num="tugumi"]
Did you forget your ......?
[cpg cn=true]

[OnName num="norio"]
"......."
[cpg cn=true]

Even I, a slow learner, knew what she was going to say.
[cpg]

First of all, it's not every day that you leave something in the classroom and then go home.
[cpg]

I wondered if there wasn't some reason why he left it there.
[cpg]

[OnName num="norio"]
I just, you know, accidentally left it there.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Tugumi025"]
[OnName num="tugumi"]
I was just...well...careful. Be careful.
[cpg cn=true]

[OnName num="norio"]
"...... yeah."
[cpg cn=true]

The conversation never happened again. It remained downcast.
[cpg]

No, it bounced tensely in a negative direction.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

After school that day.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

[OnName num="norio"]
'Huh...two days in a row, what a disaster.'
[cpg cn=true]

I was asked by the teacher to help out again today, so I was late getting home.
[cpg]

I've got to make sure I take my bag home with me today.
[cpg]

I'm going to get Ms. Kiritani in trouble again.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Airi022"]
[OnName num="airi"]
Oh, she's back.
[cpg cn=true]

[OnName num="norio"]
"Eh...ah, Sasamiya-san."
[cpg cn=true]

Somehow she was in the classroom.
[cpg]

Or rather, it sounded like he was waiting for me from what he said. Maybe it was an auditory hallucination.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Airi023"]
[OnName num="airi"]
"Welcome back.
[cpg cn=true]

[OnName num="norio"]
"He...ah...yes. I'm home.
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Airi024"]
[OnName num="airi"]
"I'm back. Kusu-kusu.
[cpg cn=true]

[OnName num="norio"]
Was that funny?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi025"]
[OnName num="airi"]
"Yes. Norio, you are funny.
[cpg cn=true]

I was laughed at. But it's a laugh that I don't dislike.
[cpg]

I don't like to be laughed at.
[cpg]

I am not a fan of being laughed at, but I feel comfortable being laughed at by her.
[cpg]

If I could see Sasamiya-san's smile, I would be more than happy to be laughed at.
[cpg]

[OnName num="norio"]
Sasamiya-san, why are you...alone?
[cpg cn=true]

I'm sure she usually goes home with her good friends.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Airi026"]
[OnName num="airi"]
I heard from Tsugumi. She said she forgot her bag yesterday.
[cpg cn=true]

[OnName num="norio"]
Oh, yeah... she told me.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Airi027"]
[OnName num="airi"]
"Yeah. So I thought I'd check it today so you won't forget it.
[cpg cn=true]

[OnName num="norio"]
Oh, thank you.
[cpg cn=true]

I thanked her with mixed feelings.
[cpg]

It's not her fault. It's like there is no relationship between them.
[cpg]

And yet, there was a part of me that wanted to justify the reason.
[cpg]

No...I wanted her to know that you had something to do with it, a despicable feeling.
[cpg]

[OnName num="norio"]
She said, "Don't worry. I won't forget today.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Airi028"]
[OnName num="airi"]
"Yeah."
[cpg cn=true]

I turn my back and get ready to leave. As I did so, he spoke to me behind my back.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi029"]
[OnName num="airi"]
Why did you forget?"
[cpg cn=true]

The same question as Kiritani-san asked me this morning. But I couldn't answer clearly.
[cpg]

[OnName num="norio"]
I was just in a daze."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi030"]
[OnName num="airi"]
I see.
[cpg cn=true]

[OnName num="norio"]
Yeah.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi031"]
[OnName num="airi"]
I thought maybe you were listening to what I said yesterday.
[cpg cn=true]

[OnName num="norio"]
"......."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Airi032"]
[OnName num="airi"]
"......."
[cpg cn=true]

I tried to blurt out, "What did you mean yesterday?
[cpg]

But the silence was a little too long for that response.
[cpg]

[OnName num="norio"]
No, I mean...
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Airi033"]
[OnName num="airi"]
I knew it. I knew it.
[cpg cn=true]

[OnName num="norio"]
"......."
[cpg cn=true]

I can't shut up. I would have affirmed it. But I couldn't come up with a witty excuse.
[cpg]

[OnName num="norio"]
I'm sorry.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Airi034"]
[OnName num="airi"]
Why are you apologizing, Norio?
[cpg cn=true]

[OnName num="norio"]
I don't know either.
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Airi035"]
[OnName num="airi"]
I'm the one who should apologize. I am sorry."
[cpg cn=true]

He bowed his head saying so. I don't want that.
[cpg]

[OnName num="norio"]
I don't want that." "Okay, stop it.
[cpg cn=true]

I don't want that. What did she think when she found out I was listening to her?
[cpg]

That's what I want to know.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Airi036"]
[OnName num="airi"]
I'll tell them.
[cpg cn=true]

[OnName num="norio"]
"Uh-huh..."
[cpg cn=true]

A moment of silence.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi037"]
[OnName num="airi"]
"......."
[cpg cn=true]

[OnName num="norio"]
"......."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi038"]
[OnName num="airi"]
Norio-kun...
[cpg cn=true]

[OnName num="norio"]
"........."
[cpg cn=true]

[FADEOUTBGM]
[FACE method="change_6" pos="2/3"]
[VOICE f="Airi039"]
[OnName num="airi"]
"Do you like me?"
[cpg cn=true]

I was touched by conviction. I didn't think, I didn't think. I never thought it would turn out like this.
[cpg]

But this...could it be?
[cpg]

[OnName num="norio"]
"What if I like you?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi040"]
[OnName num="airi"]
"Hmmm, I guess so..."
[cpg cn=true]


[BGM f="bg_h1"]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Airi041"]
[OnName num="airi"]
"Socializing. I don't think I want to.
[cpg cn=true]

[OnName num="norio"]
"......."
[cpg cn=true]

Something ended.
[cpg]

Something is gone, quietly, making a sound inside me.
[cpg]

No, it didn't even start, and there's no end to it, no shit.
[cpg]

Oh, but, oh no. I feel dizzy.
[cpg]

[OnName num="norio"]
"...... By the way, why?"
[cpg cn=true]

That's the worst. Such a question.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Airi042"]
[OnName num="airi"]
"You know what? You don't expect me to do it from the beginning.
[cpg cn=true]

[OnName num="norio"]
What?
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Airi043"]
[OnName num="airi"]
They give up from the beginning. They assume it's not going to work, and they have insurance. That kind of love will never work.
[cpg cn=true]

I didn't really understand what she meant.
[cpg]

But I thought she had a point.
[cpg]

[FACE method="change_3" pos="2/3"]
;//[VOICE f="Airi044"]
[VOICE f="Airi044_1"]
[OnName num="airi"]
;//「私が好きって言ったら、君は私の事が好きになるんだよ。まるで最初から好きだったみたいに、心の中で書き換わるの。嫌いって言われたら、元々好きじゃ無かった、ってなる」
If I say I love you, you'll love me. It's like your mind rewrites itself, as if you've liked me from the beginning."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Airi044_2"]
[OnName num="airi"]
If you say you don't like me, it's like you never liked me in the first place.
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Airi045"]
[OnName num="airi"]
I think that's very unfair.
[cpg cn=true]

[OnName num="norio"]
I don't think that..."
[cpg cn=true]

The actuality is that you can't just say you don't like it.
[cpg]

The actuality that you can't deny it, you have to have a clear intention of either liking or disliking it.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi046"]
[OnName num="airi"]
Then, do you like me?
[cpg cn=true]

[OnName num="norio"]
Uh, ah, ......."
[cpg cn=true]

I searched for a clear answer to that question, but could not find one.
[cpg]

I was surprised at the fact that it didn't come up.
[cpg]

[OnName num="norio"]
I don't know..."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Airi047"]
[OnName num="airi"]
I don't know..." "Huh. I thought it was. I thought so.
[cpg cn=true]

Was the feeling I had for her just a longing or...?
[cpg]

Or maybe it was just as Sasamiya-san had said.
[cpg]

I'm afraid of saying I love her now and getting a clear rejection saying I'm sorry.
[cpg]

That's why you're watching...to see how the other person will react.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi048"]
[OnName num="airi"]
I think Norio-kun is good. Really."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Airi049"]
[OnName num="airi"]
But I hate it. Now you are sneaky, bigoted, and cowardly. I don't think I want to associate with you.
[cpg cn=true]

It was a gentle voice. A gentle voice, an obvious rejection. Enough is enough.
[cpg]

But I had to get by just this once.
[cpg]

[OnName num="norio"]
Haha, yeah...you're right. It's natural for them to hate me...right?
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Airi050"]
[OnName num="airi"]
"That's the thing about ......."
[cpg cn=true]

The reason I didn't say it out loud was because I wanted him to deny it.
[cpg]

They see through it all.
[cpg]

[OnName num="norio"]
The name is weird.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi051"]
[OnName num="airi"]
It's a good name.
[cpg cn=true]

[OnName num="norio"]
And you're fat.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Airi052"]
[OnName num="airi"]
I think it's good that he's strong. You can count on it.
[cpg cn=true]

[OnName num="norio"]
No.
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Airi053"]
[OnName num="airi"]
Really, really.
[cpg cn=true]

[OnName num="norio"]
Stop it! I've had enough of your lies!
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Airi054"]
[OnName num="airi"]
I'm telling the truth.
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Airi055"]
[OnName num="airi"]
Norio is the only one who doesn't believe me.
[cpg cn=true]

[OnName num="norio"]
That's enough, stop it!
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Airi056"]
[OnName num="airi"]
That kind of thing is not good. I don't think it's good to feel bad about yourself.
[cpg cn=true]

I don't understand what she is saying. I don't care anymore.
[cpg]

I don't want to be miserable anymore.
[cpg]

[OnName num="norio"]
Why did you have to be so nice to me?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi057"]
[OnName num="airi"]
I didn't mean to be especially nice to you..."
[cpg cn=true]

Then, after a long pause.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Airi058"]
[OnName num="airi"]
After a few moments of silence, he said, "......Yes, I'm going to be nice to you. Then, I'm going to be nice to you.
[cpg cn=true]

[OnName num="norio"]
What?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Airi059"]
[OnName num="airi"]
Norio Butabara-kun. Won't you make a contract with me?
[cpg cn=true]

[OnName num="norio"]
? Contract?
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Airi060"]
[VOICE f="sAiri001"]
[OnName num="airi"]
Yes. I don't know what that is.
[cpg cn=true]

I don't know what that means.
[cpg]

Because there was no explanation at all. But she smiled and held out her hand.
[cpg]

I was so taken in by her compassionate expression that I found myself holding her hand.
[cpg]

[OnName num="norio"]
I was so taken in by her compassionate expression that I found myself holding her hand.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Airi061"]
[OnName num="airi"]
I was so happy to meet you. It's nice to meet you.
[cpg cn=true]

She laughed again.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

[FACE method="change_2" pos="2/3"]
[VOICE f="Airi062"]
[OnName num="airi"]
She laughed again and said, "So, ....... That's all I have to say.
[cpg cn=true]

[OnName num="norio"]
"......."
[cpg cn=true]

I was truly astonished. I couldn't keep my mouth shut.
[cpg]

It's a different place, the date has changed, and I'm in my room.
[cpg]

After school that day. I was just now being briefed on the "temporary love contract" that I had signed with her, but...
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Airi063"]
[OnName num="airi"]
I asked her, "Are you okay? Do you want me to explain it to you one more time?"
[cpg cn=true]

[OnName num="norio"]
No, no...it's okay, it's fine, it wasn't that difficult.
[cpg cn=true]

I'm in trouble because there was nothing difficult.
[cpg]

[OnName num="norio"]
Let's see, let's see, I mean, I'm going to date Sasamiya-san for a month..."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sAiri002"]
[OnName num="airi"]
"Yes, I'm going on a date."
[cpg cn=true]

How did this happen? I don't understand.
[cpg]

At that time, I was sure that I was like...dumped...by her, I believe.
[cpg]

[OnName num="norio"]
Why did you do this?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi065"]
[OnName num="airi"]
Because we had a contract.
[cpg cn=true]

[OnName num="norio"]
That's not what I meant!
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi066"]
[OnName num="airi"]
Well, I guess... because I couldn't leave her alone.
[cpg cn=true]

[OnName num="norio"]
What?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Airi067"]
[OnName num="airi"]
I know I said terrible things, but I know how Norio feels.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi068"]
[OnName num="airi"]
I'm not confident in myself...I can't have self-confidence...that's why I'm worried about what people say about me. I try to give importance to other people's opinions.
[cpg cn=true]

[OnName num="norio"]
What?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi069"]
[OnName num="airi"]
I used to be like that.
[cpg cn=true]

[OnName num="norio"]
"...... Sasamiya-san?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Airi070"]
[OnName num="airi"]
Well, anyway. I mean to have self-confidence. If you gain confidence, you will change that rotten way of thinking and so on.
[cpg cn=true]

That's a terrible thing to say.
[cpg]

But if I accept this...can I change too?
[cpg]

[OnName num="norio"]
"Okay, I understand..."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi072"]
[OnName num="airi"]
"Oh, that's right. I brought the contract with me. Sign here.
[cpg cn=true]

[OnName num="norio"]
You're going to do that?
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Airi073"]
[OnName num="airi"]
Of course I do. I have to make sure that this is done properly. You can put your thumbprint on it.
[cpg cn=true]

She gave me a piece of paper on which she wrote various things in detail.
[cpg]

The contents were explained to me by her, so I think it's all right.
[cpg]

[FACE method="change_2" pos="2/3"]
Then I signed the tentative love contract with Ms. Sasamiya.
[cpg]

Since I had already signed it, there was no turning back now.
[cpg]

I'll just do what I have to do.
[cpg]

Thus began the days of the ...... temporary love contract.
[cpg]


[jump storage="ep002.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
