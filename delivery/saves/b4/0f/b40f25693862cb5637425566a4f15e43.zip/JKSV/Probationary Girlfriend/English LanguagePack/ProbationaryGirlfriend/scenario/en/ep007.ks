;//４回目　日常イベント　日常パート最終日
*start|Almost a month has passed since the tentative love contract

;#################################################
*Ep007|Almost a month has passed since the tentative love contract
;#################################################

*day04|Almost a month has passed since the tentative love contract

[SCENE id=7]

[stflag DAY_4 = 1]


;//日常イベントはキャラ共通です。どのヒロインのＨシーンに行くかはフラグにより変化します

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

;//さあ、今日誰のところに行くかなんて決まってる。
;//[cpg]

;//日数の短縮のため６日目の地の文を４日目に

It's been almost a month since we signed the tentative love contract.
[cpg]

I've been soawing lately. If I don't do anything, these days might be over.
[cpg]


[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*day04_1"]
[endif]

;//@
Thinking about that, I decided who I'm going to go to.
[cpg]


[switch]
[case "Airi"]
	[swap]
	[jump target="*day04_1"]
[case "Tsugumi"]
	[swap]
	[jump target="*day04_2"]
[case "Minami"]
	[swap]
	[jump target="*day04_3"]
[endswitch]



*day04_1|Almost a month has passed since the tentative love contract
[jump target="*airi_date"]
*day04_2|Almost a month has passed since the tentative love contract
[jump target="*tugumi_date"]
*day04_3|Almost a month has passed since the tentative love contract
[jump target="*minami_date"]



;//ヒロイン１へ
;//ヒロイン２へ
;//サブヒロインへ


;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//※※※※以下の５，６日目の日常パートは、※※※※
;//※※※※シナリオ調整のためありません。※※※※
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//５回目　日常イベント
*start|Almost a month has passed since the tentative love contract
;//*day04_after|仮恋契約からもうすぐ一ヶ月
;//*day05|仮恋契約からもうすぐ一ヶ月
[stflag DAY_5 = 1]
;//日常イベントはキャラ共通です。どのヒロインのＨシーンに行くかはフラグにより変化します
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************
;//@
I had a feeling that I am changing after signing a tentative love contract.
[cpg]
;//@
I still can't get used to girls, though.
[cpg]
[if exp={getFlagValue("Cha2flg") == 0 }]
The first time I went to the beach, I was in the middle of the night, and I was in the middle of the night, and I was in the middle of the night.
[cpg]
[jump target="*day05_1"]
[endif]
;//@
......Who shall we go to today?
[cpg]
[switch]
[case "Airi"]
	[swap]
	[jump target="*day05_1"]
[case "Tsugumi"]
	[swap]
	[jump target="*day05_2"]
[case "Minami"]
	[swap]
	[jump target="*day05_3"]
[endswitch]
*day05_1|Almost a month has passed since the tentative love contract
[jump target="*airi_date"]
*day05_2|Almost a month has passed since the tentative love contract
[jump target="*tugumi_date"]
;//*day05_3|仮恋契約からもうすぐ一ヶ月
;//[jump target="*minami_date"]

;//////////////////////////////////////////////////////////////////////
*day05_3|Almost a month has passed since the tentative love contract
;//未奈美パターン
;//ここは新規パターンは未奈美のみ
;//シナリオの調整で５日目にあった未奈美パターンを３日目に
[OnName num="norio"]
Um, Minami.
[cpg cn=true]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Minami036"]
[OnName num="minami"]
"Hmm? What's up, Boo?
[cpg cn=true]
[OnName num="norio"]
It's, uh...
[cpg cn=true]
[FACE method="shake_2" pos="2/3"]
[VOICE f="sMinami008"]
[OnName num="minami"]
I know. You don't have to tell me everything.
[cpg cn=true]
[FACE method="change_6" pos="2/3"]
[VOICE f="sMinami009"]
[OnName num="minami"]
I'm glad you're looking forward to it.
[cpg cn=true]
[jump target="*minami_date"]
;//ヒロイン１へ
;//ヒロイン２へ
;//サブヒロインへ
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//６回目　日常イベント
;//日常イベントはキャラ共通です。どのヒロインのＨシーンに行くかはフラグにより変化します
*start|Almost a month has passed since the tentative love contract
*day05_after|Almost a month has passed since the tentative love contract
*day06|Almost a month has passed since the tentative love contract
[stflag DAY_6 = 1]
;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************
It's been almost a month since we signed the tentative love contract.
[cpg]
I've been soawing lately. If I don't do anything, these days might be over.
[cpg]
;//選択肢へ
[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*day06_1"]
[endif]
;//@
Thinking about that, I decided who I'm going to go to.
[cpg]
[switch]
[case "Airi"]
	[swap]
	[jump target="*day06_1"]
[case "Tsugumi"]
	[swap]
	[jump target="*day06_2"]
[case "Minami"]
	[swap]
	[jump target="*day06_3"]
[endswitch]

*day06_1|Almost a month has passed since the tentative love contract
[jump target="*airi_date"]
*day06_2|Almost a month has passed since the tentative love contract
[jump target="*tugumi_date"]
*day06_3|Almost a month has passed since the tentative love contract
[jump target="*minami_date"]
;//ヒロイン１へ
;//ヒロイン２へ
;//サブヒロインへ

*airi_date|Date with Airi
[jump storage="ep008.ks" target="*airi_date"]
*tugumi_date|Date with Tsugumi
[jump storage="ep010.ks" target="*tugumi_date"]
*minami_date|Date with Minami
[jump storage="ep012.ks" target="*minami_date"]



;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//※※※※以下の５，６日目の日常パートは、※※※※
;//※※※※シナリオ調整のためありません。※※※※
;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//最終分岐
*rast_sel|Who do I like?

;#################################################
*EpRoot000|Who do I like?
;#################################################

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="bg_op"]
[WAIT time=1100]


And so time passed quickly.

[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

Finally...the one month deadline was just around the corner.
[cpg]

Looking back, it seems like it was long and short.
[cpg]

But I can't let these days end here.
[cpg]

;//※ヒロインが一人の場合はこのままそのヒロインルートへ
;//複数居る場合は下記の文章が追加されて選択したヒロインの所へ

;//■選択肢
[if exp={getFlagValue("Cha2flg") == 0 }]

Anyway, I'm going to bed for today.
[cpg]

[stflag Select_root = 1]
[jump target="*root_1"]
[endif]

;//ヒロイン２と契約を結んでいる場合

Oh, by the way, there was a problem with .......
[cpg]

I'm not the only one who signed the contract.
[cpg]

I had a bad feeling...I didn't have the courage to say no, and I signed more than one contract.
[cpg]

What should I do? ......Who do I love after all?
[cpg]

;//■選択肢
;//愛莉を選んでいない=つぐみは選んだ
[if exp={getFlagValue("Cha1cnt") == 0 }]
[jump target="*last_sel_23"]
[endif]

;//愛莉は選んだがつぐみを選んでいない
[if exp={getFlagValue("Cha2cnt") == 0 }]
[jump target="*last_sel_13"]
[endif]

;//愛莉とつぐみは選んだが未奈美を選んでいない
[if exp={getFlagValue("Cha3cnt") == 0 }]
[jump target="*last_sel_12"]
[endif]


;//=================================
;//全員１回は選んでいる場合
[switch]
[case "Airi"]
	[swap]
	[stflag Select_root = 1]
	[jump target="*select_root"]
[case "Tsugumi"]
	[swap]
	[stflag Select_root = 2]
	[jump target="*select_root"]
[case "Minami"]
	[swap]
	[stflag Select_root = 3]
	[jump target="*select_root"]
[case "I can't choose"]
	[swap]
	[jump target="*select_root_4"]
[endswitch]
;//=================================

;//=================================
*last_sel_23|Who do I like?
;//愛莉を選んでいない=つぐみは選んだ
;//未奈美を選んでいない＝つぐみのみ
[if exp={getFlagValue("Cha3cnt") == 0 }]
[stflag Select_root = 2]
......You thought so, but you always thought about her.
[cpg]
[jump target="*select_root"]
[endif]

;//つぐみを選んでいない＝未奈美のみ
[if exp={getFlagValue("Cha2cnt") == 0 }]
[stflag Select_root = 3]
......You thought so, but you always thought about her.
[cpg]
[jump target="*select_root"]
[endif]

[switch]
[case "Tsugumi"]
	[swap]
	[stflag Select_root = 2]
	[jump target="*select_root"]
[case "Minami"]
	[swap]
	[stflag Select_root = 3]
	[jump target="*select_root"]
[endswitch]
;//=================================
;//=================================
*last_sel_13|Who do I like?
;//愛莉は選んだがつぐみを選んでいない
;//未奈美も選んでいない＝愛莉のみ
[if exp={getFlagValue("Cha3cnt") == 0 }]
[stflag Select_root = 1]
......You thought so, but you always thought about her.
[cpg]
[jump target="*select_root"]
[endif]
[if exp={getFlagValue("Cha1cnt") == 0 }]
[stflag Select_root = 3]
......You thought so, but you always thought about her.
[cpg]
[jump target="*select_root"]
[endif]


[switch]
[case "Airi"]
	[swap]
	[stflag Select_root = 1]
	[jump target="*select_root"]
[case "Minami"]
	[swap]
	[stflag Select_root = 3]
	[jump target="*select_root"]
[endswitch]
;//=================================
;//=================================
;//愛莉とつぐみは選んだ=未奈美はいない
*last_sel_12|Who do I like?
;//愛莉とつぐみは選んだが未奈美を選んでいない
;//愛莉を選んでいない＝つぐみのみ
[if exp={getFlagValue("Cha1cnt") == 0 }]
[stflag Select_root = 2]
......You thought so, but you always thought about her.
[cpg]
[jump target="*select_root"]
[endif]
[if exp={getFlagValue("Cha2cnt") == 0 }]
[stflag Select_root = 1]
......You thought so, but you always thought about her.
[cpg]
[jump target="*select_root"]
[endif]

[switch]
[case "Airi"]
	[swap]
	[stflag Select_root = 1]
	[jump target="*select_root"]
[case "Tsugumi"]
	[swap]
	[stflag Select_root = 2]
	[jump target="*select_root"]
[endswitch]

[stflag Cha1cnt = 0]
[stflag Cha2cnt = 0]
[stflag Cha3cnt = 0]

1, Airi
Tsugumi
3, Minami
4, I can't choose
;//=================================
;//=================================
;//※どのヒロインを選んでも共通
*select_root|Who do I like?

Okay, I've decided. After all, there is no one else I like except her.
[cpg]

I don't know how to explain this to the other girls...
[cpg]

I'll just have to be honest and apologize.
[cpg]

Anyway, I'm going to bed for today.
[cpg]

;//愛莉ルート
*root_1|Last date with Airi
[if exp={getFlagValue("Select_root") == 1 }]
;//[jump target="*root_1"]
[jump storage="ep008.ks" target="*root_1"]
[endif]

;//つぐみルート
[if exp={getFlagValue("Select_root") == 2 }]
;//[jump target="*root_2"]
[jump storage="ep010.ks" target="*root_2"]
[endif]

;//未奈美ルート
[if exp={getFlagValue("Select_root") == 3 }]
;//[jump target="*root_3"]
[jump storage="ep012.ks" target="*root_3"]
[endif]
;//=================================
;//=================================
;//※４を選んだ場合
*select_root_4|Who do I like?

I can't pick just one person.
[cpg]

They are all so attractive and cute.
[cpg]

I haven't fixed my indecisiveness after all.
[cpg]

I must apologize to all three of them honestly.
[cpg]

Anyway, I'm going to bed today. ......
[cpg]

;//ハーレムへ
;//[jump target="*root_4"]
[jump storage="ep014.ks" target="*root_4"]
;//=================================

;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
