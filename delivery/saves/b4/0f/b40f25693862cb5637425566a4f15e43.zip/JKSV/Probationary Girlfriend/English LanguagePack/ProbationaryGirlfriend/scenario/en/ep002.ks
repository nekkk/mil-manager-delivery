
*start|Tsugumi says clearly

;#################################################
*Ep002|Tsugumi clearly says
;#################################################

[SCENE id=2]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

[OnName num="norio"]
"Umm...in the morning, huh?"
[cpg cn=true]

A little time has passed since then.
[cpg]

I still think it's a dream or an illusion that I'm with her.
[cpg]

But this is reality.
[cpg]

As proof of this, ......
[cpg]

[OnName num="mother"]
Norio, your friend is here!
[cpg cn=true]

[OnName num="norio"]
"Oh, yes!
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[FACE method="bow_1" pos="2/3"]
[VOICE f="Airi074"]
[OnName num="airi"]
Good morning, Norio.
[cpg cn=true]

[OnName num="norio"]
"Good morning. Sasamiya-san..."
[cpg cn=true]

There she was in front of the house.
[cpg]

It's been a few days since this started, and I'm still not used to it.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Airi075"]
[OnName num="airi"]
Then, let's go.
[cpg cn=true]

[OnName num="norio"]
Yes.
[cpg cn=true]

She suggested that I go to school with Sasamiya-san every day.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Airi076"]
[OnName num="airi"]
She said, "Norio-kun, you don't seem to be used to girls, so let's practice for the future.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Airi077"]
[OnName num="airi"]
"Start small and work your way up," she said.
[cpg cn=true]

That's what he said.
[cpg]

Being together, it looks easy but it's very difficult. But at first you have to get used to it.
[cpg]

Next is conversation. Next is how to date...and so on.
[cpg]

We usually don't hold hands. I don't want people around me to gossip about it.
[cpg]

But on a date, he will hold hands with me.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi078"]
[OnName num="airi"]
"Let's have lunch together today.
[cpg cn=true]

[OnName num="norio"]
"Oh, my God!
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi079"]
[OnName num="airi"]
You're too surprised.
[cpg cn=true]

Because it's a high-stakes event. I can't have enough hearts.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi080"]
[OnName num="airi"]
I'll do my best. Norio-kun.
[cpg cn=true]

[OnName num="norio"]
"Ha, hahi..."
[cpg cn=true]

Yeah, but...I'm feeling a bit good about it. I'm having fun.
[cpg]

I don't think I used to be able to enjoy my days like this.
[cpg]

The gray days are beginning to take on color.
[cpg]

Sasamiya-san is trying to build my confidence in various ways.
[cpg]

[OnName num="norio"]
I'll give it a shot at .......
[cpg cn=true]

Let's give it our best shot.
[cpg]

I'll make a mumble into a resolution.
[cpg]

I hate myself, but I might be able to change that.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************


She talks to me even in ordinary life, not on a date.
[cpg]

[OnName num="norio"]
What's wrong?
[cpg cn=true]

;//[free time=300]
;//[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FACE method="change_7" pos="2/3"]
[VOICE f="sAiri003"]
[OnName num="airi"]
What's wrong?
[cpg cn=true]

;//ＢＫ

;//========================================
;//●ＣＧ（主人公を見上げるヒロイン）ev_45
;//人物１：ヒロイン１
;//服装１：制服
;//人物３：主人公
;//服装３：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_45_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

No, she's not talking to me today. She's staring at me.
[cpg]

Or rather, she is looking up at me. I wonder why she is squatting.
[cpg]

[VOICE f="sAiri004"]
[OnName num="airi"]
Maybe she's quite muscular, if you look closely?
[cpg cn=true]


[OnName num="norio"]
What?
[cpg cn=true]


No, I can tell. It's a confidence-building comment. Don't be fooled.
[cpg]

[OnName num="norio"]
"Huh, I'm just fat."
[cpg cn=true]


;//移植のためシーンをカットしています
;//ＢＫ

And so the days of being strangely tossed around continued.
[cpg]


[window target=false]
[transition target={true} rule="burainndo1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="burainndo1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="burainndo1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="burainndo1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


[VOICE f="Airi118"]
[OnName num="airi"]
So, you know, that drama that was on yesterday was really interesting.
[cpg cn=true]

[OnName num="norio"]
"Oh..."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Airi119"]
[OnName num="airi"]
Norio, you don't watch many dramas, do you?
[cpg cn=true]

[OnName num="norio"]
Yes, I do. I don't watch TV anymore. I used to watch it when I was a kid.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Airi120"]
[OnName num="airi"]
What kind of things do you watch?
[cpg cn=true]

[OnName num="norio"]
I watch a lot of different kinds of movies. I watch cartoons on TV.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Airi121"]
[OnName num="airi"]
I see. Tell me your recommendation, Norio-kun. I want to watch them too.
[cpg cn=true]

[OnName num="norio"]
I'd like to watch it too. Okay..." "Okay..."
[cpg cn=true]

Commuting to school with her has become a daily routine. After about a week has passed, I'm getting used to it.
[cpg]

Though I was puzzled at first. It's amazing how adaptable people are.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

Just as I was thinking that.
[cpg]

[OnName num="norio"]
"Ah...I'm all alone today.
[cpg cn=true]

Sasamiya-san has something to do, so it seems he can't go home with me today.
[cpg]

Well, it can't be helped. When I was thinking of going home after getting ready to go home, I saw a message on ......
[cpg]

[OnName num="teacher"]
Oh. Lid belly. Just in time."
[cpg cn=true]

[OnName num="norio"]
Ah...sir."
[cpg cn=true]

Gikkuri.
[cpg]

I have a very bad feeling about this. Yes...
[cpg]

[OnName num="teacher"]
I'm sorry, but will you help me again?
[cpg cn=true]

[OnName num="norio"]
No...no...
[cpg cn=true]

[OnName num="teacher"]
What, you don't like it?
[cpg cn=true]

[OnName num="norio"]
No, it's not that...it's not that. But...
[cpg cn=true]

[OnName num="teacher"]
You're not even in the club. You're not in a club, so you're probably not busy.
[cpg cn=true]

[OnName num="norio"]
No, but I have plans.
[cpg cn=true]

[OnName num="teacher"]
What do you have?
[cpg cn=true]

[OnName num="norio"]
I don't have anything at .......
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

[OnName num="norio"]
I'm tired.
[cpg cn=true]

In the end, I was made to help the teacher again. I'm not really helping him, I'm just being used for his convenience. I know that.
[cpg]

I don't feel bad about simply being asked to do something.
[cpg]

I'm not afraid to help those in need.
[cpg]

But... I can feel the malice in the teacher's words such as, "You're not busy anyway.
[cpg]

When they say "thank you," it's just for appearances.
[cpg]

He just says it because he has to.
[cpg]

There is no sense of gratitude from the teacher.
[cpg]

He is just a convenient labor force. And I am the one who accepts it.
[cpg]

;//[SE f="se002"]
;//【ＳＥ】『ガサガサ』

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Tugumi026"]
[OnName num="tugumi"]
"Liddy-belly-kun."
[cpg cn=true]

[OnName num="norio"]
Ah...Kiritani-san. Ah...Kiritani-san.
[cpg cn=true]

Just as I was about to leave, I was approached again.
[cpg]

But this time it was an unexpected person. It was Ms. Kiritani, a member of the class committee.
[cpg]

I hadn't talked to her since last time. It was the second time.
[cpg]

[OnName num="norio"]
What's wrong, Ms. Kiritani?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi027"]
[OnName num="tugumi"]
"You're home late today, aren't you? Isn't Sasamiya-san with you?
[cpg cn=true]

[OnName num="norio"]
Oh, yes. He said he had something to do.
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Tugumi028"]
[OnName num="tugumi"]
I know."
[cpg cn=true]

I know," he said coldly.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi029"]
[OnName num="tugumi"]
You've been helping him a lot, haven't you?
[cpg cn=true]

[OnName num="norio"]
Uh, yeah...
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi030"]
[OnName num="tugumi"]
Why?
[cpg cn=true]

[OnName num="norio"]
Because... you asked me to help you.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi031"]
[OnName num="tugumi"]
And you didn't?
[cpg cn=true]

[OnName num="norio"]
No, I didn't have a reason to say no.
[cpg cn=true]

I lied.
[cpg]

[FADEOUTBGM]
[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi032"]
[OnName num="tugumi"]
I lied. I know.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi033"]
[OnName num="tugumi"]
I saw you. Just now.
[cpg cn=true]

[OnName num="norio"]
Just now.
[cpg cn=true]


[BGM f="bg_se"]

I was immediately exposed. Or rather, he was watching my exchange with the teacher.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Tugumi034"]
[OnName num="tugumi"]
"Soft-heartedness. It sounds good to say, but in other words, it means you have no will.
[cpg cn=true]

[OnName num="norio"]
"No, because..."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Tugumi035"]
[OnName num="tugumi"]
If you don't like it, you have to say so. There are limits to what you can do that will twist your will.
[cpg cn=true]

[OnName num="norio"]
Well... that may be true, but...
[cpg cn=true]

Even I, as a quintessential person, am annoyed at being told what to do.
[cpg]

[OnName num="norio"]
I also refuse to do anything if I don't want to...
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi036"]
[OnName num="tugumi"]
Really? If Mr. Sasamiya had been there today, would you have refused?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Tugumi037"]
[OnName num="tugumi"]
We've been going home together a lot lately, haven't we?
[cpg cn=true]

I wondered why her name came up, but it seems she was aware of it.
[cpg]

I was wondering why Sasamiya's name was mentioned, but she seemed to have noticed.
[cpg]

[OnName num="norio"]
Of course she said no..."
[cpg cn=true]

I think she did.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi038"]
[OnName num="tugumi"]
I am sure she would have refused instead of you.
[cpg cn=true]

I couldn't say that she wouldn't have. I could not deny that.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_02_5.ui" time=1000]
[WAIT time=2000]

If she had been next to me, I would have looked first at Ms. Sasamiya when the teacher told me to do so.
[cpg]

I asked myself, "So, what should I do? Then she said,
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Airi122"]
[OnName num="airi"]
"That's fine. I'll help you.
[cpg cn=true]

If she said, "Okay, I'll help you," then I'd help her, too. If not,
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Airi123"]
[OnName num="airi"]
"I'm sorry, we have something to do..."
[cpg cn=true]

I'm sorry, we have other things to do..." and if he said no.
[cpg]

I was surprised to see such a scene in my mind.
[cpg]

[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]

I was surprised at myself.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tugumi039"]
[OnName num="tugumi"]
"How about it? Was there your will there?
[cpg cn=true]

[OnName num="norio"]
"No..."
[cpg cn=true]

No. It was not my will. It was not my will, I was just asking people.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Tugumi040"]
[OnName num="tugumi"]
I don't think that's a good idea.
[cpg cn=true]

I don't like what you're saying.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Tugumi041"]
[OnName num="tugumi"]
I...don't like you, do I?
[cpg cn=true]

I've never been told that before.
[cpg]

I don't know if I've ever been told I hate you.
[cpg]

[OnName num="norio"]
I see...I see.
[cpg cn=true]

I'm used to hearing words like "I hate you" and "you're disgusting. I'm used to hearing those words.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Tugumi042"]
[OnName num="tugumi"]
I hate people who are so shy and don't show their own will.
[cpg cn=true]

[OnName num="norio"]
Ugh..."
[cpg cn=true]

It is true that Kiritani is a cool person who can do anything. He is smart and athletic.
[cpg]

As you can see from this conversation, he thinks logically and is seamless. You could say she is perfect.
[cpg]

She probably gets annoyed when she sees me.
[cpg]

That's why she hates me.
[cpg]

It is difficult for me to express myself in front of her.
[cpg]

To be honest, I envy her.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi043"]
[OnName num="tugumi"]
So..."
[cpg cn=true]

[OnName num="norio"]
?"
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Tugumi044"]
[OnName num="tugumi"]
"Norio, you have a lid on your stomach."
[cpg cn=true]

[OnName num="norio"]
What?
[cpg cn=true]

Suddenly he called me by my full name, and I straightened my back.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Tugumi045"]
[OnName num="tugumi"]
Let's make a contract with me.
[cpg cn=true]

[OnName num="norio"]
What about ......?"
[cpg cn=true]

I had heard that line again sometime ago.
[cpg]

No, I had heard it only recently.
[cpg]

[OnName num="norio"]
"Contract..."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Tugumi046"]
[OnName num="tugumi"]
"...... If you're not happy with who you are, I can help you change. This is the deal."
[cpg cn=true]

[OnName num="norio"]
I see...
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Tugumi047"]
[OnName num="tugumi"]
"This is a contract, but I don't ask you for money. In fact, I'd say it's a win-win situation for you.
[cpg cn=true]

[OnName num="norio"]
What does the contract do?
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="sTugumi001"]
[OnName num="tugumi"]
"It's a contract that will make ...... you a man," she says, her cheeks reddening.
[cpg cn=true]

She says, her cheeks reddening.
[cpg]

It's not a neat explanation, but I get what you're trying to say.
[cpg]

I am sure of it.
[cpg]

[OnName num="norio"]
The name of the contract, by the way, is..."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi049"]
[OnName num="tugumi"]
The name? Oh, um... um..."
[cpg cn=true]

She was a little hesitant to say.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="sTugumi002"]
[OnName num="tugumi"]
It's called a provisional lover's agreement.
[cpg cn=true]

Temporary lover contract...what Mr. Sasamiya was talking about was a temporary love contract.
[cpg]

The name is a little different, but I think it's the same thing.
[cpg]

It seems that people call it a little differently.
[cpg]

[OnName num="norio"]
........."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tugumi051"]
[OnName num="tugumi"]
Is something wrong?
[cpg cn=true]

[OnName num="norio"]
No..."
[cpg cn=true]

No way.
[cpg]

I didn't expect Kiritani-san to offer me the same thing that Sasamiya-san offered me.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Tugumi052"]
[OnName num="tugumi"]
If you don't want to do it, just say no."
[cpg cn=true]

Serious eyes. Moreover, he just told me that he will show his will.
[cpg]

I guess you could say she's testing me.
[cpg]

No, apart from that, is it OK to say yes?
[cpg]

Even though I have a contract with Sasamiya-san... doubly? Out? Safe? Which is it?
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Tugumi053"]
[OnName num="tugumi"]
What are you going to do? I'd appreciate it if you could decide quickly.
[cpg cn=true]

[OnName num="norio"]
Now?
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Tugumi054"]
[OnName num="tugumi"]
Of course. Decide immediately. You can't say you'll decide later.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[OnName num="norio"]
Uh-uh...
[cpg cn=true]

I, I, I ......
[cpg]

;//■選択肢　つぐみと契約するか選択
[switch]
[case "I'll sign the contract."]
	[swap]
	[jump target="*select01_1"]
[case "Do not sign a contract"]
	[swap]
	[jump target="*select01_2"]
[endswitch]

1, I will sign a contract.
2. no contract

;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//１、契約する　の場合
;//日常パートの選択肢にヒロイン２とサブヒロインが追加される
*select01_1|Tsugumi clearly says

[stflag Cha2flg = 1]

[OnName num="norio"]
"I will sign the contract at ......."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Tugumi055"]
[OnName num="tugumi"]
I understand. I understand.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Tugumi056"]
[OnName num="tugumi"]
Then, Norio Futabara-kun. I'm looking forward to working with you again.
[cpg cn=true]

[OnName num="norio"]
"Well, well, it's...nice to meet you."
[cpg cn=true]

He bowed politely to me. It seemed as if he was trying to hide his embarrassment.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Tugumi057"]
[OnName num="tugumi"]
I will explain the details of the contract later.
[cpg cn=true]

[OnName num="norio"]
Yes.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Tugumi058"]
[OnName num="tugumi"]
Well, that's it for today.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Tugumi059"]
[OnName num="tugumi"]
See you tomorrow.
[cpg cn=true]

[OnName num="norio"]
See you..."
[cpg cn=true]

[free time=1000]
[WAIT time=1000]

I could only reply with a listless response.
[cpg]

No, I mean, maybe...maybe I've done something terrible.
[cpg]

;//合流１へ
[jump target="*select01_3"]

;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//２、契約しない　の場合
*select01_2|Tsugumi says clearly

[stflag Cha2flg = 0]

[OnName num="norio"]
I'm sorry, I'll stop..."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Tugumi060"]
[OnName num="tugumi"]
I'm sorry, I shouldn't..." "...... right. I understand.
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Tugumi061"]
[OnName num="tugumi"]
"It's invalid if I say I changed my mind later.
[cpg cn=true]

[OnName num="norio"]
Yes.
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Tugumi062"]
[OnName num="tugumi"]
And please don't tell anyone about this. Absolutely.
[cpg cn=true]

[OnName num="norio"]
Okay. I understand.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Tugumi063"]
[OnName num="tugumi"]
Okay. Thank you.
[cpg cn=true]


[free time=1000]
[WAIT time=1000]

With these words, she left the classroom.
[cpg]

I was torn between feeling that this was a good thing
[cpg]

I was torn between feeling glad about this and feeling like it was a waste of time.
[cpg]

What am I getting myself into?
[cpg]

;//合流１へ

;//////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////
;//合流１
*select01_3|Tsugumi clearly says

;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I was in agony in my room after signing the contract and experiencing it for myself.
[cpg]

I never imagined that I would feel like this.
[cpg]

I never imagined that I would be so...thrilled.
[cpg]


[jump storage="ep003.ks" target="*start"]

;//日常イベントへ
;//ここからは共通の日常イベントを経て、その先のヒロインへとシーンが切り替わります

;//////////////////////////////////////////////////////////////////////
