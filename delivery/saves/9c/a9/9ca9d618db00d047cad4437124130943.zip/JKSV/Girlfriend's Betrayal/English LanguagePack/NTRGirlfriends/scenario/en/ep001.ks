

*start|



;#################################################
*Ep001|Senpai and Kōhai
;#################################################

[SCENE id=1]

;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・廊下』（夕方）******************************************************

I had finished my afternoon classes and was about to go home when Takafumi called out to me.
[cpg]

[OnName num="takafumi"]
Hey, are you going home too?
[cpg cn=true]

[OnName num="keita"]
Yeah, I'm going home. Class is over.
[cpg cn=true]

[OnName num="takafumi"]
Yeah, but..…Why do you always go straight home? Aren't you in a club?
[cpg cn=true]

[OnName num="keita"]
Ugh.
[cpg cn=true]

He hits a sore spot. Since I was technically part of a club, Takafumi must be worried about that.
[cpg]

[OnName num="takafumi"]
I get that the art club isn't something you have to attend every day, but if you skip too often won't you lose your skills?
[cpg cn=true]

[OnName num="keita"]
You're probably right, it might be time to get back there again.
[cpg cn=true]

I sighed and Takafumi frowned. I feel like this is happening a lot today.
[cpg]

[OnName num="takafumi"]
Club activities that you do out of obligation are no fun, right? There are people like that sometimes, but if you're going to do it, you should be more committed.
[cpg cn=true]

[OnName num="keita"]
I'm not sure about that ……
[cpg cn=true]

[OnName num="takafumi"]
What do you mean?
[cpg cn=true]

The first time I went, I didn't even intend to take it seriously, but when I tried to quit, people around me kept stopping me. So I guess I feel a little obligated.
[cpg]





[SE f=se018]
;//【ＳＥ】『ドア横開け』

[window target=false]
[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・美術室』（夕方）******************************************************

[OnName num="keita"]
Excuse me ……
[cpg cn=true]

I hesitantly entered the club room.
[cpg]

[OnName num="sawabe"]
......Oh, Keita, is that you? How unusual, are you finally ready to participate in club activities?
[cpg cn=true]

Mr. Sawabe calls me Keita. He is the advisor of the art club, but I have yet to see any of his paintings in person. He must be good if he was serving as the advisor.
[cpg]

He was cool, popular with the girls, and a talented artist. It was hard not to feel a little jealous.
[cpg]

[OnName num="keita"]
No, I have something to do today, so I was going to head home.
[cpg cn=true]

[OnName num="sawabe"]
You came all the way her to tell me that? Well, it's better than not saying anything, but I'd prefer it if you'd participate…….
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Yuuri001"]
[OnName num="yuuri"]
That's right, senpai!
[cpg cn=true]

A bright, high-pitched voice interrupts Mr. Sawabe. It was a familiar voice, I knew she'd show up eventually.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Yuuri002"]
[OnName num="yuuri"]
Come on, you're always skipping!
[cpg cn=true]

It was Yuri, an underclassman, who had come up to me. There are girls who could be likened to small animals, but Yuri was particularly energetic even amongst them.
[cpg]

If I had to choose between a dog or a cat, I would say she was more like a dog. A small dog that was very attached to me.
[cpg]

As my kōhai, she had only just entered the school. It seems she'd instantly decided to join the club and likewise, instantly became attached to me.
[cpg]

It seemed similar to the imprinting instincts of a newborn animal thinking the first thing they see was their parent.
[cpg]

[OnName num="keita"]
Sorry, I've got errands to run to do today.
[cpg cn=true]



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Yuuri003"]
[OnName num="yuuri"]
Really? Did you make up these errand so that you could skip your club today?
[cpg cn=true]


[OnName num="keita"]
Uhhhh..…
[cpg cn=true]

She hit a sore spot. My conscience ached because it was true.
[cpg]

And if Yuri says all this ...... Then, what should I do?
[cpg]


[switch]
[case "Attend club activities"]
	[swap]
	[jump target="*select01_1"]
[case "Skip club activities"]
	[swap]
	[jump target="*select01_2"]
[endswitch]

1. Attend club activities
2. Skip club activities

;//-----------------------------------------------------------------------
;//１、部活に出る　の場合
;//選択肢に　悠里が出現

*select01_1|Senpai and Kōhai

[stflag CHA03flg = 1]


[OnName num="keita"]
Alright, fine. I'll attend club activities today.
[cpg cn=true]

;//悠里「ほんとですかっ！？」

[FACE method="bow_2" pos="2/3"]

Yuri's persistence paid off and I decided to participate in club activities today.
[cpg]

[OnName num="sawabe"]
What happened to your errands?
[cpg cn=true]



[OnName num="keita"]
Haha......well, they weren't that important, I guess.
[cpg cn=true]

Of course he knew I didn't have anything important to do. I'm sure he realized that I was trying to slack off.
[cpg]

Seeing Yuri's smile as soon as I said I was going to participate in club activities made me feel good about my choice.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//背景再び表示

Time passes, we finish our club activities and headed home.
[cpg]

[jump target="*select01_3"]

;//合流１へ
;//-----------------------------------------------------------------------
;//２、部活を休む　の場合
;//選択肢に　遥が出現

*select01_2|Senpai and Kōhai
[stflag CHA02flg = 1]


[OnName num="keita"]
I really am busy, don't bug me too much about it.
[cpg cn=true]

Of course she was right, I was just glad she didn't ask me what my errands were.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuuri004"]
[OnName num="yuuri"]
Awww, I thought we could paint together today.
[cpg cn=true]

[OnName num="keita"]
......Sorry.
[cpg cn=true]

I enjoy club activities, and I had originally joined of my own volition, but the people around me put me on a pedestal.
[cpg]

Painting was a fun hobby, but I didn't like feeling pressured to paint for a club activity......It wasn't really a priority for me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Yuuri005"]
[OnName num="yuuri"]
You're so talented, why don't you take your activities seriously? I don't have any talent, but I like drawing pictures every day.
[cpg cn=true]

[OnName num="keita"]
I wouldn't say that, you seem plenty talented to me. It's not like I every thought of myself as particularly skilled, either.
[cpg cn=true]

[OnName num="sawabe"]
Come now, don't try to force him.
[cpg cn=true]

Mr. Sawabe to the rescue.
[cpg]

[OnName num="keita"]
You don't need talent to paint. Anyone can paint well enough if they put in the effort.
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Yuuri006"]
[OnName num="yuuri"]
That only applies to people with talent! I've put in plenty of effort and I'm still not very good.
[cpg cn=true]

[OnName num="sawabe"]
Yuri, calm down for a moment. It's up to him to decide whether he wants to put in the effort or not.
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Yuuri007"]
[OnName num="yuuri"]
Are you taking his side? It's a waste if someone as talented as him doesn't try harder! Senpai, I'm really worried about you.
[cpg cn=true]

[OnName num="keita"]
Is that a joke?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Yuuri008"]
[OnName num="yuuri"]
Don't change the subject!
[cpg cn=true]

But it's a little surprising to see Mr. Sawabe on my side. Maybe he's the type of teacher who respects the free will of his students.......
[cpg]

[OnName num="keita"]
I'll leave you to it, then. Excuse me.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Yuuri009"]
[OnName num="yuuri"]
And now you're just going to leave? Am I that annoying to you?
[cpg cn=true]

[OnName num="keita"]
I didn't say that……you're thinking too much.
[cpg cn=true]

At first, it felt good. People looked up to me. But I think it's up to the genius to decide if they want to be a genius or not.
[cpg]

I don't think I'm a genius, but I'd rather choose whether or not I want to be looked up to.
[cpg]

[OnName num="keita"]
Why do you care about my talent anyways? What's in it for you?
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuuri010"]
[OnName num="yuuri"]
That's ……
[cpg cn=true]

[OnName num="keita"]
Tell me why you are so obsessed with me. I don't really understand it and it's getting a little scary.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Yuuri011"]
[OnName num="yuuri"]
It's because I want to draw pictures with you. I mean, I'm sure to improve if I can paint with you.
[cpg cn=true]

[OnName num="keita"]
So, you want me to participate for your benefit. There are plenty of other good artists around. You could even take lessons somewhere.
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Yuuri012"]
[OnName num="yuuri"]
Yes, it's for my own sake. Is that so bad? If anybody's in the wrong, it's you for slacking off all the time!
[cpg cn=true]

There was desperation in her voice. I feel like she was trying to hide her true intentions.
[cpg]

I think she really does want to paint with me. If that's the case, she must really admire me.
[cpg]

I feel sorry for her, but I can only say that she picked the wrong person to look up to.
[cpg]

[OnName num="keita"]
Anyway, goodbye. I really have something to do.
[cpg cn=true]

[OnName num="sawabe"]
Okay. Get home safe.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Yuuri013"]
[OnName num="yuuri"]
Grr......
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『学園・入り口』（夕方）******************************************************

I managed to shake Yuri and leave school. Now that I'd reached the entrance, there was no one to stop me.
[cpg]

[OnName num="keita"]
……
[cpg cn=true]

;//会話はありませんが、恵太の見たヤンキーは英次です。立ち絵があれば表示してください
For a moment, my eyes met those of a delinquent in the distance. I guess there are people like that in every school.
[cpg]

I think he was responsible for some incidents around the school. I've only heard rumors about him, so I don't know the specifics.
[cpg]

The entrance exams for this school weren't easy so I had no idea how he made it in. Maybe he went wild after he got in?
[cpg]

[OnName num="keita"]
……Maybe it's just my imagination.
[cpg cn=true]

I thought I recognized the girl he was with......What was her name?
[cpg]

I'd looked away too quickly to see who she was.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

I headed down the road, basking in the peaceful weather of spring. I had a lot of things to think about.
[cpg]

I guess I was a senpai now. After the conversation with Takafumi, I've been thinking about how I can't be an unreliable guy forever .......
[cpg]

Spring is the time of year when you have to get yourself motivated after the start of a new semester.
[cpg]

But there are more dependable people around me than unreliable people ......Not that it was a good reason for me to be an unreliable guy myself.
[cpg]

Chiho is a caring person, I couldn't imagine myself becoming like Takafumi, and even my dad was the picture of manliness.
[cpg]

Then there was my senpai. I wouldn't describe her as dependable, though.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Haruka001"]
[OnName num="haruka"]
Hey! Are you on your way home?
[cpg cn=true]

[OnName num="keita"]
Aaaagh!
[cpg cn=true]

[SE f="se010"]
A slap lands solidly in the middle of my back.
[cpg]

[OnName num="keita"]
Owwww......what was that for?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Haruka002"]
[OnName num="haruka"]
You look as cute as ever. That kind of troubled face suits you best.
[cpg cn=true]

[OnName num="keita"]
That's not a great reason…….
[cpg cn=true]

This was the senpai I was talking about. Haruka teased me constantly and was one of the reasons I found it hard to act more like a manly guy.
[cpg]

[OnName num="keita"]
You know, this face didn't start today. You can't change it.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Haruka003"]
[OnName num="haruka"]
I didn't tell you to change it. I'm giving you a compliment, be thankful.
[cpg cn=true]

[OnName num="keita"]
Yeah but it hurts a lot. Keep it up and you're going to break me someday.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Haruka004"]
[OnName num="haruka"]
Haha! You're cute that way.
[cpg cn=true]

It wasn't bullying, but she did tease me a lot. I honestly wasn't sure how to deal with her.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se013]
;//【ＳＥ】『歩く』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

[FACE method="bow_1" pos="2/3"]
[VOICE f="Haruka005"]
[OnName num="haruka"]
So, you skipped art club again?
[cpg cn=true]

[OnName num="keita"]
I didn't skip art club, I just didn't go …….
[cpg cn=true]

[OnName num="keita"]
Unlike an athletic club, you don't have to go every day to keep up. It's not the same as skipping workouts.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Haruka006"]
[OnName num="haruka"]
Oh, come on, that's not true. Can you say the same thing about studying?
[cpg cn=true]

[OnName num="keita"]
You may have a point……
[cpg cn=true]

Even if you don't do it every day, you won't decline, but you won't make any progress either. Maybe I should attend club activities more often.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Haruka007"]
[OnName num="haruka"]
You just lack diligence.
[cpg cn=true]

[OnName num="keita"]
If you say that, then you lack modesty.
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Haruka008"]
[OnName num="haruka"]
What? Did you just say something?
[cpg cn=true]

[OnName num="keita"]
Nope. You're hearing things.
[cpg cn=true]

I'd whispered it, how could she possibly hear me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Haruka009"]
[OnName num="haruka"]
Well, hearing that from someone as rowdy as me might not be that convincing.
[cpg cn=true]

[OnName num="keita"]
So you heard me ……
[cpg cn=true]

But it was true that I lacked diligence. I didn't feel great being put in the same group as Haruka.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Haruka010"]
[OnName num="haruka"]
Did you just think something rude about me?
[cpg cn=true]

[OnName num="keita"]
What, are you a mind-reader now?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Haruka011"]
[OnName num="haruka"]
So you were, huh?
[cpg cn=true]

[OnName num="keita"]
You tricked me...
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
The two of us were chatting and laughing as we headed home ...... She was doing all of the laughing.
[cpg]

[OnName num="keita"]
An underclassman told me that I need to be more involved in club activities. I mean, she only just started attending, what's her deal?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Haruka012"]
[OnName num="haruka"]
I see. You've got a kōhai now, huh?
[cpg cn=true]

[OnName num="keita"]
Sure. I mean, even you were someone's kōhai at one point, right?
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Haruka013"]
[OnName num="haruka"]
Oh ...... well, yeah.
[cpg cn=true]

And then Haruka's expression suddenly turned dark. What is it?
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Haruka014"]
[OnName num="haruka"]
I went through a lot of things in the past. Things that I can't even tell you.
[cpg cn=true]

[OnName num="keita"]
What? .....That makes me even more curious.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Haruka015"]
[OnName num="haruka"]
It's none of your business. If you found out, you'd probably be disappointed in me.
[cpg cn=true]

[OnName num="keita"]
Now I want to know even more...... And don't worry, I don't respect you enough to feel disappointed in you.
[cpg cn=true]


[free time=500]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Haruka016"]
[OnName num="haruka"]
Ahh, you little punk.
[cpg cn=true]

[OnName num="keita"]
Ow!
[cpg cn=true]

Haruka's back to her usual self as she grinds her knuckles into my scalp. It was unusual to see her looking serious.
[cpg]

This was for the best. I'd realized that Haruka had become something of an important person in my life.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//ＢＫ

[FACE method="bow_1" pos="2/3"]
[VOICE f="Haruka017"]
[OnName num="haruka"]
Then, I'll see you tomorrow.
[cpg cn=true]

[OnName num="keita"]
See you.
[cpg cn=true]


Then Haruka and I parted ways and I headed home.
[cpg]


;//合流１へ
;//-----------------------------------------------------------------------
;//合流１

*select01_3|Senpai and Kōhai


[jump storage="ep002.ks" target="*start"]


;////////////////////////////////////////////////////////////////////////


