
;//２、遥が好き

*start|Haruka, my Senpai

;#################################################
*Ep006|Haruka, my Senpai
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_02_a.ui" method="change_1"  pos="2/5" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（夜）******************************************************


*Route02|Haruka, my Senpai

[SCENE id=6]

[OnName num="keita"]
I like Haruka.
[cpg cn=true]


[FACE method="shock_5" pos="2/5"]
Huh? she replied. Nanako must not know her, I thought ......
[cpg]

[OnName num="junichi"]
Haruka! Who's that, that's a name I've never heard of.
[cpg cn=true]

Everyone seemed shocked it was someone they didn't know.
[cpg]

[OnName num="junichi"]
Is she a classmate? How long have you known her?
[cpg cn=true]

[OnName num="keita"]
You're close. Dad, don't get so close.
[cpg cn=true]

[OnName num="keita's_mother"]
What kind of girl is she? Is she sweet, or a little bossy?
[cpg cn=true]

[OnName num="keita"]
I can't answer all your questions at once!
[cpg cn=true]

I explain to my family little by little. I wonder why I have to explain to my family about the person I liked who I wasn't even dating.
[cpg]

[OnName num="keita"]
So she's a senpai at school ……
[cpg cn=true]

[OnName num="keita's_mother"]
Oh, she's older? I guess that's intriguing.
[cpg cn=true]

[OnName num="keita"]
Yeah. She tends to pick on me though.
[cpg cn=true]

[OnName num="keita"]
I'm not saying that she's picking on me because she wants to …… but rather she's messing with me, or how can I put it ...... she's really a kind person.
[cpg cn=true]

The more I put it into words, the more I understand why I like Haruka. I guess I really do really like her ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]
;//ＢＫ

I'm not going to confess right away, but now that I know how much I like her, I can't sit around and do nothing.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園・入り口』（夕方）******************************************************

[OnName num="keita"]
Wait up. Haruka!
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Haruka033"]
[OnName num="haruka"]
Hm?
[cpg cn=true]

After class, I catch up with her as she's leaving. She doesn't participate in any club activities and I often skip mine, so we end up going home at the same time.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Haruka034"]
[OnName num="haruka"]
It's rare for you to chase after me. What do you want?
[cpg cn=true]

[OnName num="keita"]
Nothing much, I just saw you ……so I just thought I'd talk to you.
[cpg cn=true]

She looks a little flustered. Unconsciously, I must have said something bold.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Haruka035"]
[OnName num="haruka"]
Well, do you want to hang out?
[cpg cn=true]

[OnName num="keita"]
Okay.
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

Walking side by side, we didn't have much conversation, which was a little awkward.
[cpg]

I think she somehow sensed that I was looking at her in a different way.
[cpg]

I thought maybe she was trying to set the mood or something …… but that doesn't seem to be the case.
[cpg]

;xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;//非表示
;//遥「この川もさぁ、昔はこんなに汚れなかったよなぁ」
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxx

She's not that type of person to begin with. She just seems to have a lot of time on her hands.
[cpg]



[FACE method="change_3" pos="2/3"]
[VOICE f="Haruka036"]
[OnName num="haruka"]
Oops...that looks like it hurt.
[cpg cn=true]

[free time=1000]
[WAIT time=1000]

[OnName num="keita"]
What?
[cpg cn=true]

I didn't know what she meant until I followed her gaze.
[cpg]

The kids were playing a little far away, and one of them was crying, clutching her knees. I wonder if she fell down.
[cpg]

Haruka is heading toward the child, probably to help her.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//ＢＫ

;//背景再び表示


[OnName num="child"]
Thank you!
[cpg cn=true]



[FACE method="bow_2" pos="2/3"]
[VOICE f="Haruka037"]
[OnName num="haruka"]
Sure thing, kiddo.
[cpg cn=true]

She's not the caregiver type ...... But she just seems like a kind person at times like these.
[cpg]

[OnName num="keita"]
You're a kind person. I could never do that.
[cpg cn=true]

Haruka waves as she watches the children run by. But for a moment, her expression turned somber.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Haruka038"]
[OnName num="haruka"]
I'm not a nice person. I used to be bad.
[cpg cn=true]

[OnName num="keita"]
I don't know much about the old you, come to think of it.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Haruka039"]
[OnName num="haruka"]
Do you want to know?
[cpg cn=true]

[OnName num="keita"]
I might want to. I'm not forcing you to tell me, but I want to get to know you.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Haruka040"]
[OnName num="haruka"]
I see ..…
[cpg cn=true]

According to her she had a bad friend with whom she used to hang out. They even shoplifted for fun.
[cpg]

I can't imagine her doing that now. She may be a bit crass, but I can't imagine her as a delinquent.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Haruka041"]
[OnName num="haruka"]
But ...... My friend was the only one who got caught. I got so scared that I ran away.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Haruka042"]
[OnName num="haruka"]
After that, I changed. I'm trying to be proper.
[cpg cn=true]

[OnName num="keita"]
I'm surprised. You seem like a kind person. I even admire you. ......
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Haruka043"]
[OnName num="haruka"]
Haha! You're the only kōhai that would say that.
[cpg cn=true]

Perhaps it was the sunset, but Haruka's face looked a little red.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Haruka044"]
[OnName num="haruka"]
Also you can ask me anything in the future.
[cpg cn=true]
[BGM f="bg_tl"]

I feel like we are choosing words to get closer to each other.
[cpg]

Although we were not physically close to each other, our hearts were getting closer. The surface of the river glistened as the sun set.
[cpg]

[OnName num="keita"]
I …. Umm …..
[cpg cn=true]

[OnName num="keita"]
I like you Haruka.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Haruka045"]
[OnName num="haruka"]
……
[cpg cn=true]

Maybe I jumped the gun, but the mood seemed right.
[cpg]

I don't have many manly qualities, and I still don't know what she thinks of me.
[cpg]

[FACE method="change_8" pos="2/3"]
[WAIT time=500]
[OnName num="keita"]
Huh? Why are you crying?
[cpg cn=true]


[FACE method="shake_8" pos="2/3"]
[VOICE f="Haruka046"]
[OnName num="haruka"]
I'm not crying.
[cpg cn=true]

[OnName num="keita"]
I'm sorry! I should have picked a better time.
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Haruka047"]
[OnName num="haruka"]
I don't mind......I'm just scared that if we go out, you start to think less of me.
[cpg cn=true]

[OnName num="keita"]
I don't see why......
[cpg cn=true]


[FACE method="shake_8" pos="2/3"]
[VOICE f="Haruka048"]
[OnName num="haruka"]
Really? I'm not attractive as a woman, am I?
[cpg cn=true]

[OnName num="keita"]
……
[cpg cn=true]

It seems we had similar worries.
[cpg]

I'm as shy as a girl and she was as crass as a man ….. maybe that was a bit too harsh.
[cpg]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Haruka049"]
[OnName num="haruka"]
Why are you laughing?
[cpg cn=true]

[OnName num="keita"]
I'm sorry. It's nothing.
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="kosuri5.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kosuri5.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園・入り口』（朝）******************************************************

The next day. It was very early in the morning. I thought Haruka wouldn't be at the school at this time of the day, but ......
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=2000]

[OnName num="keita"]
Oh.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Haruka050"]
[OnName num="haruka"]
Hey.
[cpg cn=true]

It seems that both of us wanted to see each other as soon as possible ...... I can't believe we both reached school so early.
[cpg]

[OnName num="keita"]
...... We're a couple, aren't we?
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Haruka051"]
[OnName num="haruka"]
Haha, it's kind of ...... embarrassing. Even though nothing has changed.
[cpg cn=true]

[OnName num="keita"]
You've changed. Haruka, you don't come to school this early.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Haruka052"]
[OnName num="haruka"]
I guess. If you put it that way.
[cpg cn=true]

[OnName num="keita"]
Haha, yes.
[cpg cn=true]

We haven't even kissed yet. That's how new we are to the situation. But I'm happy to call her my girlfriend and have a laugh with her.
[cpg]



[window target=false]
[transition target={true} rule="hiraki.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hiraki.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・教室』（昼）******************************************************

It had already become a topic of conversation that we had started dating. I feel like most of the whispering is directed at me.
[cpg]

And as if to confirm the buzz and rumors, Haruka came to my class.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Haruka053"]
[OnName num="haruka"]
Hey. Keita.
[cpg cn=true]

[OnName num="keita"]
I didn't think you'd come to my classroom.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Haruka054"]
[OnName num="haruka"]
I want to have lunch with you. What do you think, pretty girly, right?
[cpg cn=true]

[OnName num="keita"]
You don't seem to be nervous ..... Did you change your personality? You seem very excited, Haruka.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Haruka055"]
[OnName num="haruka"]
Well, you're acting all grown-up now, so fair's fair.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[WAIT time=1000]

[OnName num="keita"]
Owch, quit poking me.
[cpg cn=true]

We have both changed. With that exchange, people around us are looking at us thinking, "Here we go again" .......
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
;//ＢＫ

Things haven't changed much from before. But there is a happiness that wells up from my heart.
[cpg]

When Haruka introduces me to someone, she'll probably introduce me as her boyfriend. I'd have to do the same, in kind.
[cpg]

Even daydreaming about our future together gave me butterflies. I guess when you are too happy, your heart becomes a little sensitive ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『学園・教室』（夕方）******************************************************

It was after school, and this time I went to Haruka's classroom. Someone was talking with her.
[cpg]

He was big and tall. On top of that, he looked like a delinquent.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Haruka056"]
[OnName num="haruka"]
Oh, Keita …… you came to my classroom.
[cpg cn=true]

[OnName num="keita"]
Uh, yeah. Um, who is this guy?
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Haruka057"]
[OnName num="haruka"]
Well, he's a childhood friend of mine and his name is ...... Eiji.
[cpg cn=true]

[OnName num="eiji"]
.......
[cpg cn=true]

Eiji. This guy was the guy hanging out with her and getting her into trouble. He certainly looked the part.
[cpg]

And that kind of impression makes me feel that this guy was forcing her to do bad things, rather than Haruka doing it on her own, which makes me feel somewhat wary.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Haruka058"]
[OnName num="haruka"]
I'll go get my bag, so just give me a minute.
[cpg cn=true]

[free time=1000]

She left Eiji and I alone for a moment.
[cpg]

[OnName num="eiji"]
Hey, you.
[cpg cn=true]

[OnName num="keita"]
Yes.
[cpg cn=true]

I replied "yes" without thinking although it was rude to talk to me that way.
[cpg]

[OnName num="eiji"]
You're her boyfriend?
[cpg cn=true]

[OnName num="keita"]
Yes, I ……. am.
[cpg cn=true]

I stuttered a little. He had the kind of aura that seemed angry and that would make people scared.
[cpg]

I don't know what he was angry about, but after my reply, he clicked his tongue. What got him so riled up?
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Haruka059"]
[OnName num="haruka"]
Sorry to keep you waiting, Keita. Let's go then.
[cpg cn=true]


;//ＢＫ
[free time=1000]
[BG f="b_16_3.ui" time=1000]
[WAIT time=2000]



In the end, I went home with Haruka that day, and Eiji didn't seem to follow us.
[cpg]

But I was left with an unspeakable feeling of uneasiness ...... I had the impression that he was not a good person to be around.
[cpg]

......And from there, a few days passed.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『遊園地』（昼）******************************************************

[SE f=se015 loop=true]
;//【ＳＥ】『街の喧噪』

[FACE method="change_1" pos="2/3"]
[VOICE f="Haruka060"]
[OnName num="haruka"]
Let's have fun. Time is limited.
[cpg cn=true]

[OnName num="keita"]
Yeah.
[cpg cn=true]

I was a little late for our meet up, but Haruka seemed positive.
[cpg]

Today had planned something what is called an amusement park date. I never dreamed that the day would come when I would experience such a thing, but it's not a dream.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Haruka061"]
[OnName num="haruka"]
You've got a date plan, don't you? I'll leave it to you.
[cpg cn=true]

[OnName num="keita"]
What? It was you who suggested this.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Haruka062"]
[OnName num="haruka"]
Be a man, take the lead.
[cpg cn=true]

[OnName num="keita"]
Uh, umm.
[cpg cn=true]

She still teases me like this. But I take it differently than before. I already know that it is her way of expressing her affection.
[cpg]


[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『遊園地』（夕方）******************************************************

[OnName num="keita"]
I guess you don't like roller coasters ……?
[cpg cn=true]



[FACE method="bow_4" pos="2/3"]
[VOICE f="Haruka063"]
[OnName num="haruka"]
I had no idea, either......
[cpg cn=true]

There are times like this that make me laugh. Haruka, who is always so bossy with me and teasing me, is showing her girly side.
[cpg]

[OnName num="keita"]
It's getting dark already.
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Haruka064"]
[OnName num="haruka"]
I blame you for taking so long to pick the rides.
[cpg cn=true]

[OnName num="keita"]
That's fair.
[cpg cn=true]

I was being myself too much. I have to be careful ……
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
;//ＢＫ

Today, we went as far as holding hands. We haven't kissed yet, but the day after that ......
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（昼）******************************************************


[FACE method="bow_1" pos="2/3"]
[VOICE f="Haruka065"]
[OnName num="haruka"]
Nice to meet you. I'm Keita's girlfriend.
[cpg cn=true]

[OnName num="keita"]
And I'm ...... her boyfriend.
[cpg cn=true]

[OnName num="junichi"]
Haha, he can be pathetic at times, but he's still my son. Please take good care of him!
[cpg cn=true]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
The next day, I introduced her to my family. And since the family was very supportive of us going out, they even asked her to stay over.
[cpg]

Stay the night. It was a simple act, something that maybe even happens between friends. But.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

We hadn't even had our first kiss yet......
[cpg]

[OnName num="keita"]
……
[cpg cn=true]

I sat upright on the bed. We'd finished bathing, separately.
[cpg]

[OnName num="keita"]
I thought we were staying in different rooms.
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Haruka066"]
[OnName num="haruka"]
Really? Your parents didn't say anything about that.
[cpg cn=true]

[OnName num="keita"]
I think they probably have a room somewhere prepared …… for you.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Haruka067"]
[OnName num="haruka"]
Then take me there.
[cpg cn=true]

I was feeling pretty cornered. I wouldn't put it past my parents to not prepare her room.
[cpg]

I know what my dad and mom might be thinking. They're making us cross the line today ......
[cpg]



[OnName num="keita"]
You know what, Haruka?
[cpg cn=true]

[FO pos="2/3" time=500]
[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=1]
[VOICE f="Haruka068"]
[OnName num="haruka"]
Mm ……!
[cpg cn=true]

Haruka covered my lips. Of course, it wasn't with her hand, but a kiss ......
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Haruka069"]
[OnName num="haruka"]
Huh....... Is this your first kiss, Keita?
[cpg cn=true]

[OnName num="keita"]
Umm, yes.......
[cpg cn=true]

I can't help but answer honestly. It's just lips touching each other, but it was so sudden, I don't know how it happened.
[cpg]




;//ＢＫ


;//●ＣＧエロ（遥・ベッドに横たわる。着衣にしてください：恵太の部屋）ev_14
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Haruka070"]
[OnName num="haruka"]
I'm ...... so nervous I don't know what to do.
[cpg cn=true]


[OnName num="keita"]
Me too.
[cpg cn=true]


But maybe she is still more relaxed than I am.
[cpg]

Maybe in my life, there will never be a day like this.
[cpg]

With that in mind, I thought about kissing her again ….. but I couldn't do it.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『学園・入り口』（朝）******************************************************

Another day after that incident. It was a weekday and I was on my way to school.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Haruka071"]
[OnName num="haruka"]
Good morning, Keita.
[cpg cn=true]

[OnName num="keita"]
Oh, good morning .......
[cpg cn=true]

I kind begin to remember ...... just by looking at Haruka.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Haruka072"]
[OnName num="haruka"]
......You look like you're remembering the other night.
[cpg cn=true]

[OnName num="keita"]
I do!?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Haruka073"]
[OnName num="haruka"]
It's cute.
[cpg cn=true]

She'd make fun of me, but I'd say that overall, our relationship was going well.
[cpg]



;//ＢＫ

;//遥に視点切り替わり
;//[ChangeWindow num="1"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『学園・教室』（昼）******************************************************


As I was in a daze in the classroom during lunch break, I see someone waving at me from far away.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Haruka074"]
[OnName num="haruka"]
Oh …… Keita.
[cpg cn=true]

[OnName num="keita"]
Wow, I thought you'd be more excited to see your boyfriend..
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Haruka075"]
[OnName num="haruka"]
You can say that after you do something boyfriend-like.
[cpg cn=true]

I make a joke out of it, again. I can't tell him what I really want.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Haruka076"]
[OnName num="haruka"]
So, what do you want?
[cpg cn=true]

[OnName num="keita"]
I was wondering if I could go on a date with you on the weekend.
[cpg cn=true]

I know. I know that the dates he asks me out on don't include kissing or anything like that.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//背景再び表示

[OnName num="keita"]
I'll see you on the date ......I mean tomorrow at school.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Haruka077"]
[OnName num="haruka"]
Yeah. See you tomorrow.
[cpg cn=true]


[SE f=se013]
;//【ＳＥ】『歩く』
[WAIT time=1000]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Haruka078"]
[OnName num="haruka"]
......Phew.
[cpg cn=true]

I just set up a date with my boyfriend, why am I sighing?
[cpg]

I looked at the photos I took at the amusement park.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・入り口』（夕方）******************************************************

I grabbed Eiji as he was leaving the school and asked him for advice. He was clearly unhappy.
[cpg]



[OnName num="eiji"]
Why are you asking me?
[cpg cn=true]

In the end, he's still an important male friend of mine. And since this consultation is about boys, I thought it was better than talking to a girl about it.
[cpg]

[OnName num="eiji"]
Why don't you just break up with him? Go out with someone more daring.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Haruka079"]
[OnName num="haruka"]
I can't do that.
[cpg cn=true]

[OnName num="eiji"]
Huh, whatever.
[cpg cn=true]

He's probably grumpy because I look like I'm showing off my relationship. I felt a little bad, but I needed his advice.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haruka080"]
[OnName num="haruka"]
I don't know what to do with myself……
[cpg cn=true]


[OnName num="eiji"]
Get over it. And stop telling me stuff like that.
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Haruka081"]
[OnName num="haruka"]
......I figured.
[cpg cn=true]

For some reason, he smiled wryly at my words.
[cpg]

[OnName num="eiji"]
Well, you certainly look like you're not getting enough.
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Haruka082"]
[OnName num="haruka"]
You can't tell that just by looking at me.
[cpg cn=true]

[OnName num="eiji"]
But you do, don't you? You should have gone out with me.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Haruka083"]
[OnName num="haruka"]
...... What?
[cpg cn=true]

It was so sudden that I almost missed it. I couldn't believe my ears.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Haruka084"]
[OnName num="haruka"]
Didn't you hear? I like Keita.
[cpg cn=true]

[OnName num="eiji"]
Yeah, I heard you. So?
[cpg cn=true]

Just because Keita wasn't enough for me doesn't mean that I could...no, if I did that...…
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Haruka085"]
[OnName num="haruka"]
I'm not going to cheat on him.
[cpg cn=true]

[OnName num="eiji"]
It's not cheating. It's only cheating when your feelings are involved. You said you like Keita.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Haruka086"]
[OnName num="haruka"]
……
[cpg cn=true]

I was taken aback. I knew he was this kind of guy.
[cpg]

[OnName num="eiji"]
With me, you don't gotta worry about wanting more. I'll give you everything you want and more.
[cpg cn=true]

;//一瞬だけ、本当に一瞬、たしかにこいつならあたしの疼きを静めてくれるかもしれない、と思った。
For a moment, just a moment, I thought that he might be able to satisfy me.
[cpg]

However, I was so angry that the feeling disappeared. I felt like he was making fun of me and Keita, and that made me angry.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Haruka087"]
[OnName num="haruka"]
You're the worst.
[cpg cn=true]

[OnName num="eiji"]
Maybe. But I understand your feelings better than anyone else, don't I?
[cpg cn=true]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


Furious, I turned around and left. But that didn't make my frustration go away.
[cpg]


I am happy and enjoy my dates with Keita. Keita is a cute guy, and I think I can love him forever.
[cpg]

;//●ＣＧエロ（遥・ベッドに横たわる。欲求不満な感じ。場所が変わっています：遥の部屋）ev_15

[BGM f="bg_h3"]
;**【ＣＧ】 ev_15_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]

Still, that day, when Eiji made that suggestion ……
[cpg]

I had a certain feeling for a moment. The feeling that he could ...... I'd hidden it with anger.
[cpg]

But with time, the anger gradually faded. Then I would suddenly remember his proposal.
[cpg]

I felt sorry to Keita for having this desire, so I decided to put a lid on it. I didn't want to betray him.
[cpg]

It doesn't look like I'll be sleeping anytime soon today …..
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="enn2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


I was lost.
[cpg]


The other day, Keita said, "I can endure anything". I wondered if he would be able to bear it if I cheated on him.
[cpg]


If he would forgive me for that too, then we'd be fine. And if he can't stand it, maybe he'd take it to the next level this time.
[cpg]


......No, that was selfish of me.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

[OnName num="eiji"]
So what's it gonna be? You called me up, because of what I suggested right?
[cpg cn=true]

I can still go back. I can tell him that I just needed to talk and that would be the end of it.
[cpg]

Or I could just say, "I'm sorry I got angry with you the other day," and that would be the end of it. But instead ……
[cpg]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Haruka088"]
[OnName num="haruka"]
...... Yeah.
[cpg cn=true]

I nodded my head in response to his question. Eiji chuckled.
[cpg]

[OnName num="eiji"]
I knew it. I knew it since you first started dating that guy.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Haruka089"]
[OnName num="haruka"]
What?
[cpg cn=true]

[OnName num="eiji"]
You're just not that type who can be in a committed relationship like that. I'm not saying it doesn't suit you, it's just that it's impossible.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Haruka090"]
[OnName num="haruka"]
I'm not...I'm not like that......
[cpg cn=true]

I couldn't deny what he said. If I were satisfied with my current relationship, I wouldn't have called Eiji here.
[cpg]

[OnName num="eiji"]
A girl like you acts all tough and strong. What you really want is for someone to tell you what to do.
[cpg cn=true]

[OnName num="eiji"]
I guess it's inevitable when you're with such a wuss. I understand how you feel.
[cpg cn=true]

He saw through me. Is it because he's been with me for so long? Or does he really care about me?
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Haruka091"]
[OnName num="haruka"]
Don't say it .......
[cpg cn=true]

Everything he said was true. I couldn't help myself from feeling excited.
[cpg]

The fact that he sees through my pattern of failures makes me think that he might lead me to the right answer.
[cpg]

;//移植のためシーンをカットしています

;//[ChangeWindow num="1"]

;//ＢＫ

;//恵太に視点切り替わり
;//[ChangeWindow num="0"]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_du"]
[WAIT time=100]
;//【ＢＧ】『学園・教室』（昼）******************************************************

One day at school. Haruka had been absent due to a cold or something......She'd changed a lot since I'd last seen her.
[cpg]

[OnName num="keita"]
What's wrong? I'll be all ears if you need someone to talk to.
[cpg cn=true]

I went to Haruka's classroom, but I couldn't even greet her properly. I was that depressed.
[cpg]

[OnName num="keita"]
I thought you were absent because of a cold ……? Or was it another illness or something.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Haruka092"]
[OnName num="haruka"]
No ...... but …
[cpg cn=true]

[OnName num="keita"]
What do you mean? ...... Then, why were you absent?
[cpg cn=true]

Haruka doesn't answer. Is it really that hard to say? Is it something that even I, her boyfriend, can't hear?
[cpg]

I tried to go to visit her, but Haruka refused to let me do so over the phone.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Haruka093"]
[OnName num="haruka"]
Keita, you like me, right?
[cpg cn=true]

[OnName num="keita"]
Yeah, of course!
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Haruka094"]
[OnName num="haruka"]
You said you wouldn't hate me no matter what, right ......?	“你说你不会恨我，对……对吗？
I wonder what happened. Did she take a break from school because of something about me? Did her parents disapprove of us going out? I don't think that's the case.	我不知道发生了什么。她是否因为我的一件事就休息了吗？她的父母不赞成我们出去吗？我认为情况并非如此。
Yeah, of course."
[cpg cn=true]

I answered while being skeptical about it. Then Haruka smiled a little.
[cpg]

[OnName num="keita"]
Let's go somewhere...we'll make it a date.
[cpg cn=true]

Okay, let's go. I don't know what happened, but I'll follow you anywhere.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Haruka095"]
[OnName num="haruka"]
Follow me, huh. You don't want to lead...?
[cpg cn=true]

[OnName num="keita"]
Ugh. These are the times when I can't be manly enough ...... But since Haruka seemed happy, it should be all right.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Haruka096"]
[OnName num="haruka"]
With that, we were talking about our next date together.
[cpg cn=true]

Hey, Haruka.
[cpg]

Huh!
[cpg]

[OnName num="eiji"]
Although it was just someone calling her name, Haruka seemed tense. It was ...... Eiji.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Haruka097"]
[OnName num="haruka"]
...... Do you need anything?
[cpg cn=true]

Well, I've got to talk to you.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Haruka098"]
[OnName num="haruka"]
......?
[cpg cn=true]

[OnName num="eiji"]
Haruka walks out into the hallway with him. Just a minute ago she was talking about our date with me.
[cpg cn=true]

[OnName num="keita"]
It kind of looked like she was intimidated by him. Maybe he has some leverage over her.
[cpg cn=true]

No, I was thinking too much ...... If she has a weakness, it would be something she can't even talk to me about.
[cpg]

Hey, you think he's gonna be enough for you?
[cpg]

....
[cpg]



;//ＢＫ

;//遥に視点切り替わり
;//[ChangeWindow num="1"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『学園・廊下』（昼）******************************************************
;//[lbox on]

[OnName num="eiji"]
Eiji asks me. I can't help but check to see if there are any other people around.
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Haruka099"]
[OnName num="haruka"]
You should really go out with me. You know that.
[cpg cn=true]


I won't reject you and you know I can satisfy you.
[cpg]


[OnName num="eiji"]
Earlier, Keita said he would never hate me. I can't betray him ......
[cpg cn=true]


[FACE method="change_4" pos="2/3"]


[OnName num="eiji"]
But at the same time, I had a nasty thought; If he won't betray me, I can do whatever I want ......
[cpg cn=true]

I returned to the classroom where Keita was waiting for me. Keita looked surprised to see me.
[cpg]

Did something happen?…… What were you talking about?
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・教室』（昼）******************************************************

Nothing. He forgot his ...... textbook or something.
[cpg]

[OnName num="keita"]
A delinquent was talking about textbooks? Really?
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Haruka100"]
[OnName num="haruka"]
Yeah, really.
[cpg cn=true]

[OnName num="keita"]
Well, that's fine then ...... but I'm a little worried.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Haruka101"]
[OnName num="haruka"]
I wondered if it had anything to do with the fact that you were absent. Are you being threatened by that guy or something?
[cpg cn=true]

[OnName num="keita"]
That's how it seemed from Keita's point of view. Maybe I looked frightened to him.
[cpg cn=true]

[OnName num="keita"]
I'm fine. It's not like that.
[cpg cn=true]

It's disgusting. I was betraying him even though he was worried about me ......
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Haruka102"]
[OnName num="haruka"]
On a different day. We'd promised to meet.
[cpg cn=true]

That day, my house was empty.
[cpg]

Thanks for inviting me. No one is home right?
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//ＢＫ

;//♪その日は、あたしの家はからっぽだった。学園の休日だったから、両親の仕事とは関係なかった。

......
[cpg]

[OnName num="eiji"]
You're so nervous. Normally it's the other way around.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Haruka103"]
[OnName num="haruka"]
I can't believe I've gone this far……
[cpg cn=true]

[OnName num="eiji"]
If I didn't stop now, I thought I wouldnt' be able to hold back anymore.
[cpg cn=true]

;//移植のためシーンをカットしています

The long-awaited date with Haruka. Today's date was a little different and special.
[cpg]

It was where we had our first date. We were back at the amusement park.
[cpg]


;//恵太に視点切り替わり
;//[ChangeWindow num="0"]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『遊園地』（昼）******************************************************

[SE f=se015 loop=true]
;//【ＳＥ】『街の喧噪』

Where shall we go? I want to go to the places we couldn't get to last time.
[cpg]

I don't want to go on a roller coaster again.
[cpg]

[OnName num="keita"]
I guess you've been through a traumatic experience ……
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Haruka104"]
[OnName num="haruka"]
Haruka, who is next to me, is usually smiling. Which is also the source of my worry.
[cpg cn=true]

[OnName num="keita"]
Are you okay with the haunted house ……? Is it better than the roller coaster?
[cpg cn=true]

Are you afraid Keita? I'm totally fine with it.
[cpg]


[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『遊園地』（昼）******************************************************

[OnName num="keita"]
If you're totally fine, then I guess we don't have to go in there.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Haruka105"]
[OnName num="haruka"]
Oh, so you're bad with scary stuff? Are you sure you're not a girl?
[cpg cn=true]

[OnName num="keita"]
She's almost always cheerful, and she's positive in what she says. I also think we have a conversation like a normal couple.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Haruka106"]
[OnName num="haruka"]
Sometimes, when we're waiting for an attraction, she seems depressed.
[cpg cn=true]

...... Still having any troubles?
[cpg]

Huh? Oh......no.
[cpg]

[OnName num="keita"]
As usual, Haruka sometimes looks gloomy. It should be an occasion, but she seems absent-minded.
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Haruka107"]
[OnName num="haruka"]
What should we do? Shall we still skip the haunted house and go on a roller coaster?
[cpg cn=true]

I tried joking around, but Haruka didn't really respond.
[cpg]

[OnName num="keita"]
Dates with me aren't that fun, huh?
[cpg cn=true]

I tried to go a little further this time. Haruka's face was not gloomy, but rather pained.
[cpg]

[OnName num="keita"]
No. It's fun, but that's why……
[cpg cn=true]

It's fun, that's the problem. She didn't have to finish her sentence, I could tell what she meant to say.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Haruka108"]
[OnName num="haruka"]
I see .…
[cpg cn=true]

I don't pursue it too deeply. She hasn't complained about anything in particular.
[cpg]

[OnName num="keita"]
It was a date. If she didn't like me, she wouldn't have stayed with me. Even at this moment, she told me she was having fun.
[cpg cn=true]

No matter how much fun she was having, whatever she was worried about was so much bigger......
[cpg]

I'm sorry. Did I look gloomy?
[cpg]

Yes, you did. It's what you're troubled about, isn't it?
[cpg]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Haruka109"]
[OnName num="haruka"]
I'm sorry. We're on a date. I'm going to forget about it and enjoy it as much as I can.
[cpg cn=true]

[OnName num="keita"]
She said, laughing. I guess it's something she really wants to hide ...... Then it's better if I don't ask her about it.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Haruka110"]
[OnName num="haruka"]
Coming back for more already?
[cpg cn=true]

......
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
;//遥に視点切り替わり
;//[ChangeWindow num="1"]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************
;//[lbox on]

[OnName num="eiji"]
I know I shouldn't keep doing this. My mind says no, but my body says otherwise and I can't help it.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Haruka111"]
[OnName num="haruka"]
I was the one who decided to go to Eiji's house …… but I feel like crying.
[cpg cn=true]

What's going on? You're the one who came here. Don't look so gloomy.
[cpg]

.....Yeah, you're right. But you know, if I keep doing this ...... I'm going to have to break up with Keita.
[cpg]

[OnName num="eiji"]
When I said so seriously, Eiji seemed puzzled. Didn't he hear what I had just said?
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Haruka112"]
[OnName num="haruka"]
Why? You don't have to break up.
[cpg cn=true]

What do you mean …..?
[cpg]

[OnName num="eiji"]
I meant what I said.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Haruka113"]
[OnName num="haruka"]
I guess, he really didn't think that this was cheating.
[cpg cn=true]

[OnName num="eiji"]
I thought he might like me, even a little bit. I started to feel foolish.
[cpg cn=true]

You ain't the only girl in my life.
[cpg]

……
[cpg]

[OnName num="eiji"]
He adds on those words. He has already seen through my feelings.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Haruka114"]
[OnName num="haruka"]
Good luck with Keita. I'm just doing what you ask me to do.
[cpg cn=true]

......So, you don't think anything of me?
[cpg]

[OnName num="eiji"]
Hey, don't get so upset now. You started this, didn't you?
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Haruka115"]
[OnName num="haruka"]
I'm not going to ask Haruka for the truth about her problems. That's what I had thought at first, but this was going on for too long.
[cpg cn=true]

[OnName num="eiji"]
Just when I think she's calmed down, she starts to look more and more distressed, and when that passes, she just looks sad.
[cpg cn=true]



;//移植のためシーンをカットしています


;//ＢＫ
;//恵太に視点切り替わり
;//[ChangeWindow num="0"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="amamori1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h3"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

I wonder what that cycle was about.
[cpg]

I guess I have to wait for her to talk to me about it.
[cpg]

I don't want to ask her. But I called her to see if she could tell me something.
[cpg]

Hey, Haruka. Can I talk to you for a minute?
[cpg]


;//移植のためシーンをカットしています

What I had to say was nothing out of the ordinary. It wouldn't change the current situation.
[cpg]

[OnName num="keita"]
Do you want to go on a date somewhere? You don't seem to feeling so well lately, so I thought we could do something to take your mind off of things.
[cpg cn=true]


......Sure.

[OnName num="keita"]
Where should we go this time?
[cpg cn=true]


[VOICE f="Haruka116"]
[OnName num="haruka"]
We talked, and I suggested a lot of things, such as a shopping mall that had just been renovated.
[cpg cn=true]

[OnName num="keita"]
But Haruka just seemed depressed. I don't know why, and it's frustrating.
[cpg cn=true]

I've been aware of it for some time, but I don't need to find out the truth about it. It's all going to be solved if I become more attractive.
[cpg]

Even if it's a different problem, she won't be depressed if I'm enough of a lover to keep her by my side.
[cpg]

Sorry for making you wait.
[cpg]

Oh, Keita ...... I just got here.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_du"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

[OnName num="keita"]
The next time I saw Haruka, she was acting strangely again, different from before.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Haruka117"]
[OnName num="haruka"]
It's not the troubled or dark vibe I've been getting. She's more fidgety and ...... somewhat suspicious.
[cpg cn=true]

I can kind of imagine this kind of feeling. She's hiding the fact that she's expecting something.
[cpg]

......You look pretty today too, Haruka.
[cpg]

You think? I'm the same as usual.
[cpg]

[OnName num="keita"]
;//♪「……今日もお洒落だね、遥は」
See, this is where Haruka, before we started dating, would have picked on me.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Haruka118"]
[OnName num="haruka"]
Now she just looks down and checks her appearance. Is that how much she was expecting something from this date?
[cpg cn=true]

I feel like there's another factor ……
[cpg]

From there, we went to the shopping mall and finished lunch ...... it was getting crowded.
[cpg]

That's funny …… we were holding hands.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="enn2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I got separated from Haruka. It's not like either of us went to the bathroom or anything.
[cpg]

[OnName num="keita"]
......What were you gonna do if I had plans? Besides, how are you gonna explain this to him?
[cpg cn=true]

It's not that weird when it's this crowded.
[cpg]



;//遥に視点切り替わり
;//[ChangeWindow num="1"]
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

[BGM f="bg_h3"]
;//●ＣＧエロ（遥・無理矢理迫られるヒロイン。拒めない感じ：ショッピングモール・狭い廊下）ev_19
;**【ＣＧ】 ev_19_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

[VOICE f="Haruka119"]
[OnName num="haruka"]
Whatever. You couldn't get me outta your head, huh?
[cpg cn=true]


[OnName num="eiji"]
That's …….
[cpg cn=true]


[OnName num="eiji"]
Don't hide it. I know what you're thinking.
[cpg cn=true]

;**【ＣＧ】 ev_19_a ***********************
[CG id=7 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Haruka120"]
[OnName num="haruka"]
I was searching from one end of the mall to the other. Then, I found myself outside of the mall again.
[cpg cn=true]


[OnName num="eiji"]
Where did she go? She wasn't picking up when I called. What if something happened that made it impossible for her to pick up the phone?
[cpg cn=true]

;//ＢＫ

;//恵太に視点切り替わり
;//[ChangeWindow num="0"]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

She might be in some kind of accident or something. I didn't think that it could actually happen, but I can't stop worrying.
[cpg]

I head back as I feel the anxiety rushing over me, but then ……
[cpg]

Yo. Keita, right ? Long time no see.
[cpg]

......
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/5" time=800]

[OnName num="eiji"]
Haruka was there. Behind her was the delinquent childhood friend who she introduced to me sometime ago.
[cpg cn=true]

[OnName num="keita"]
We just ran into each other over there. She said she was on a date, so we were looking for you.
[cpg cn=true]



Oh. Thank you ......
[cpg]

[OnName num="eiji"]
.......
[cpg cn=true]

[OnName num="keita"]
I thanked him, but as I did so, a lot of things started connecting in my head.
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Haruka121"]
[OnName num="haruka"]
Why didn't you pick up the phone? If you had, we wouldn't have been separated ……
[cpg cn=true]

I'm sorry about that. I thought I lost it.
[cpg]

[OnName num="keita"]
Is that possible ……?
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Haruka122"]
[OnName num="haruka"]
I don't hide my doubts anymore. Maybe I can clarify everything here. I think so and continue to speak.
[cpg cn=true]

[OnName num="keita"]
So you're on a date, was it? Have fun.
[cpg cn=true]

But ......
[cpg]

[OnName num="eiji"]
The person I wanted to question left. My beloved girlfriend remains by my side.
[cpg cn=true]

[OnName num="keita"]
I'm sorry, I'm really ...... sorry.
[cpg cn=true]

…… It's okay.
[cpg]

[SE f=se013]
;//【ＳＥ】『歩く』

[FO pos="2/5" time=500]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=1000]

[VOICE f="Haruka123"]
[OnName num="haruka"]
During the date, I had been collecting my thoughts. It didn't feel like I was going to have a good time with her. Once ignited, the doubts burn like a fire in the pit of my stomach.
[cpg cn=true]

[OnName num="keita"]
The next day. Haruka came to school, but there was still something strange about her. She was blushing rather than seeming depressed today. I watch her from outside the classroom.
[cpg cn=true]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
;//ＢＫ

Maybe I should have a talk with her after all.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『学園・廊下』（昼）******************************************************

I will go and talk to her.
[cpg]


I won't talk to her.
[cpg]


;//@

;//■選択肢
[switch]
[case "1. I will go and talk to her."]
	[swap]
	[jump target="*select04_1"]
[case "2. I won't talk to her."]
	[swap]
	[jump target="*select04_2"]
[endswitch]

Haruka, my senpai
… But it's not important that she's acting strange, she might just be having troubles.

;//--------------------------------------------------------------------
;//２、話をしない　の場合
*select04_2|Rather, it would be better to trust her.


I should find the right timing and ask, in a casual way, "What's troubling you?'" or something like that.
[cpg]

As a boyfriend, it would be cooler to care about her in a more casual way ......
[cpg]

Haruka, my senpai
[cpg]

There is no doubt anymore that something is happening to her. And I have a few things to back up my theory.
[cpg]

[jump target="*select04_3"]

;//合流４へ
;//--------------------------------------------------------------------
;//１、話をする　の場合
*select04_1|The first of these is that I haven't heard her talk about her childhood friend recently. She had only quickly introduced him to me.

[stflag hiroin2sl = 1]

And yet, Haruka and him are often together. That means that the topic about him should be increasing in the conversation.
[cpg]

The other day was a masterpiece. Even Keita must have figured it out.
[cpg]

……
[cpg]

[OnName num="eiji"]
She's still in the classroom, talking with him about something. I can't hear what they're talking about, but ......
[cpg cn=true]


[VOICE f="Haruka124"]
[OnName num="haruka"]
Hey. It's Eiji, right?
[cpg cn=true]

Yeah? What?
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『学園・教室』（昼）******************************************************

[OnName num="keita"]
.......
[cpg cn=true]

[OnName num="eiji"]
I talk in front of him, or rather, I involve him in the conversation.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Haruka125"]
[OnName num="haruka"]
When I looked at Haruka up close, she was still acting strange. Her face is red and it looks like she has a cold.
[cpg cn=true]

You've known each other since childhood right? Then you two must be close.
[cpg]

Yeah. We're good friends, aren't we?
[cpg]

[OnName num="keita"]
Maybe .......
[cpg cn=true]

[OnName num="eiji"]
Haruka reacted in way that seemed to give those words a deeper meaning. And there was a part of him that was amused by the situation.
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Haruka126"]
[OnName num="haruka"]
Then you might know, but Haruka seems to feel sick often lately .......
[cpg cn=true]

Really? I can't say I've noticed.
[cpg]

[OnName num="keita"]
Well, that's ….
[cpg cn=true]

[OnName num="eiji"]
Well, your face is red, isn't it? And you seem nervous, so I wonder what's wrong.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Haruka127"]
[OnName num="haruka"]
......
[cpg cn=true]

[OnName num="eiji"]
I was going to find out if something had happened between them today. But ...... today she seemed the most strange.
[cpg cn=true]

[OnName num="keita"]
Do you want me to take you to the nurse's office?
[cpg cn=true]

No, I'll take her. It's fine, right Haruka?
[cpg]

[OnName num="keita"]
When I suggested it, Eiji quickly ignored it and got up from his seat. Naturally, he grabbed Haruka's hand.
[cpg cn=true]

[OnName num="eiji"]
……Yes.
[cpg cn=true]

Why are you nodding your head, Haruka? I'm your boyfriend.
[cpg]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Haruka128"]
[OnName num="haruka"]
Haruka, my senpai
[cpg cn=true]

We had another date at home. A lot had happened and I talk to her about something that's been bothering me a little.
[cpg]


;//ＢＫ

;//移植のためシーンをカットしています

;//合流４へ
;//--------------------------------------------------------------------
;//合流４
*select04_3|Lately, you don't seem depressed anymore.

;//恵太に視点切り替わり
;//[ChangeWindow num="0"]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

...... Really? Did I seem that depressed.
[cpg]

[OnName num="keita"]
Yeah......You seem better now, but there was a while where you were acting differently.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Haruka129"]
[OnName num="haruka"]
I don't know. I've always been me.
[cpg cn=true]

[OnName num="keita"]
Even though I had cemented my suspicions, Haruka was back to normal.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Haruka130"]
[OnName num="haruka"]
Are you sure? You don't have any complaints about me or anything?
[cpg cn=true]

;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;//上記の選択１を選んでいた場合のみ文章を表示
[if exp={getFlagValue("hiroin2sl") == 1 }]

I don't. You worry too much.
[cpg]

[endif]
;xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

[OnName num="keita"]
I see ...... That's good to know, then.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Haruka131"]
[OnName num="haruka"]
.......
[cpg cn=true]


[OnName num="keita"]
(I have to say this ...... I can see you've been suspicious of me lately ......)
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Haruka132"]
[OnName num="haruka"]
I still don't think it's possible that she was cheating on me. If she was cheating, there's no way she could suddenly go back to normal.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Haruka133"]
[OnName num="haruka"]
I go for a walk in the city on my day off, alone, doing nothing.
[cpg cn=true]

I don't want to go back to my house. Somehow I feel pressure when I stay in a place where I'm used to worrying.
[cpg]


;//ＢＫ
;//遥に視点切り替わり
;//[ChangeWindow num="1"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="slant2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="slant2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="slant2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="slant2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

I pull out my cell phone again and again, try to make a call, and then stop.
[cpg]

Maybe Eiji will call me. Or maybe my feelings will subside if I can just hold on a little longer.
[cpg]

I can't .......
[cpg]

In the end, I always call him …….
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Haruka134"]
[OnName num="haruka"]
Hello, Eiji ……?
[cpg cn=true]

What? I'm trying to get some sleep here...
[cpg]

[SE f="se003"]
;//【ＳＥ】『携帯電話の発信音』プルルル
[WAIT time=2000]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Haruka135"]
[OnName num="haruka"]
I'm sorry.
[cpg cn=true]

[OnName num="eiji"]
I ain't a convenience store, you don't get to call me up whenever you want.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Haruka136"]
[OnName num="haruka"]
I'm sorry.
[cpg cn=true]

[OnName num="eiji"]
I don't know what's going on, but he's not interested. When I called him in the past, he'd tell me where to meet me ......
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Haruka137"]
[OnName num="haruka"]
I want to see you again.
[cpg cn=true]

Hmm ……
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Haruka138"]
[OnName num="haruka"]
Oh ...... please, I can't go on without you.
[cpg cn=true]

[OnName num="eiji"]
Fine. I'll head over, just wait.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Haruka139"]
[OnName num="haruka"]
From there, I waited for him at home.
[cpg cn=true]

[OnName num="eiji"]
I had finished cleaning my room and all I had to do was for him to visit my house. But it was taking him a while.
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_16_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

I couldn't wait any longer and went outside of the house to look for him.
[cpg]

Oh, Haruka. What's the matter, why don't you just wait inside?
[cpg]

It's just a coincidence.
[cpg]


[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

[OnName num="eiji"]
When I finally saw Eiji, I couldn't help but smile. I don't want him to leave me.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Haruka140"]
[OnName num="haruka"]
Come on in Eiji.
[cpg cn=true]

No, not today. I just came here to apologize.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Haruka141"]
[OnName num="haruka"]
What?
[cpg cn=true]

[OnName num="eiji"]
I'm sorry I toyed with you. I truly am.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Haruka142"]
[OnName num="haruka"]
I got goosebumps. He got bored of me, I thought.
[cpg cn=true]

[OnName num="eiji"]
Let's end this relationship. I feel bad for Keita, and most importantly, I feel bad for you.
[cpg cn=true]

What ….
[cpg]

[OnName num="eiji"]
I was at a loss for words. What was there to feel bad about? Is that what Eiji really thinks?
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haruka143"]
[OnName num="haruka"]
Had he ever apologized to me for anything before......?
[cpg cn=true]

That's why I came to your house. Just apologizing over the phone would be irresponsible.
[cpg]

I think he's testing me. He's seeing if I'll hold myself back here ......
[cpg]

[OnName num="eiji"]
He wants to see if he has a complete advantage over Keita.
[cpg cn=true]


……
[cpg]

I'll see you later. I wish you and Keita all the best.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Haruka144"]
[OnName num="haruka"]
I like Keita. There is no doubt about that. When I think about who I will go out with, there is no doubt in my mind.
[cpg cn=true]

[OnName num="eiji"]
Wait.
[cpg cn=true]

What? What, do you still want something?
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Haruka145"]
[OnName num="haruka"]
But even so, I had no choice but to hold him back.
[cpg cn=true]

[OnName num="eiji"]
I've already apologized to you, haven't I? Is that not enough?
[cpg cn=true]

No, it's not that. I want you ……
[cpg]

[OnName num="eiji"]
But I can't do that. I feel bad for Keita, see?
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Haruka146"]
[OnName num="haruka"]
What am I supposed to do then?
[cpg cn=true]

[OnName num="eiji"]
It's easy. I feel bad because you're already going out with someone.
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Haruka147"]
[OnName num="haruka"]
So all you have to do is say that I'm your real boyfriend and he's just some toy you got bored of.
[cpg cn=true]

[OnName num="eiji"]
What a horrible person. Every word was a lie, he really just wants to see me dump Keita.
[cpg cn=true]

[OnName num="eiji"]
If you can't tell me, well, so be it. I'm sure you'll call me again though.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]

...... Fine.
[cpg]

[OnName num="eiji"]
Oh? What is it?
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Haruka148"]
[OnName num="haruka"]
I'll admit that you're my boyfriend ..…
[cpg cn=true]

[OnName num="eiji"]
Haha! Okay. I guess if you say so.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Haruka149"]
[OnName num="haruka"]
……
[cpg cn=true]

[OnName num="eiji"]
I said it. I said it.
[cpg cn=true]




;//ＢＫ

;//[ChangeWindow num="1"]

;//●ＣＧエロ（遥・後悔してる感じのヒロイン：遥の部屋）ev_21

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h3"]
;**【ＣＧ】 ev_21_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Haruka150"]
[OnName num="haruka"]
I could have regretted it, but I couldn't bring myself to feel that way.
[cpg cn=true]


I wonder why. I'm even excited about our future.
[cpg]

I had already changed long ago.
[cpg]

It was all about when I was going to admit it ......
[cpg]

Okay. Come on, I'll give you what you've been wanting all along.
[cpg]

…..Okay.
[cpg]


;//移植のためシーンをカットしています
;//ＢＫ

;//[ChangeWindow num="1"]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]
;//ＢＫ

;//●ＣＧエロ（遥・浮気相手とキスをするヒロイン。背景が変わっています：遥の部屋）ev_22
;**【ＣＧ】 ev_22_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


[OnName num="eiji"]
I responded like a naive girl.
[cpg cn=true]


[VOICE f="Haruka151"]
[OnName num="haruka"]
I felt whole again, but I hated myself for it.
[cpg cn=true]


How did I get into this mess? How could this happen ……
[cpg]

It is also sinful to think of it as if it were someone else's problem.
[cpg]


;**【ＣＧ】 ev_22_a ***********************
[CG id=9 index=1 time=1]
;***************************************
[WAIT time=1]

One day, I received a phone call from Eiji.
[cpg]

I could also hear Haruka's voice, and I guessed everything.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//恵太に視点切り替わり
;//[ChangeWindow num="0"]

You know why I'm calling you, don't you?
[cpg]

I know. I know now.
[cpg]

[OnName num="eiji"]
Eiji had seduced my girlfriend.
[cpg cn=true]


The sleepless night quickly turns into morning, and I realize that I can see Eiji if I go to school.
[cpg]

Sadly, I didn't think I would see Haruka. Rather than Haruka, my attention turns to Eiji, the man who took everything from me.
[cpg]


[BG f="b_00_1.ui" time=1000]
[WAIT time=2000]
;//ＢＫ


Hey, why did you call me out. Is there something you ……?
[cpg]

I interrupted Eiji and slammed my fist into his cheek.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『学園・教室』（朝）******************************************************

[OnName num="eiji"]
Eiji, however, does not flinch. He chuckled and acted as if I hadn't hit him.
[cpg cn=true]

[SE f="se008"]
;//【ＳＥ】『打撃音』ドカッ

What is this, a fight? Don't you understand that you're inferior to me on all fronts?
[cpg]

It's not over....... Haruka still likes me.
[cpg]

[OnName num="eiji"]
What a masterpiece. You really think she ever resisted? You think she's still holding out, just waiting for you to save her?
[cpg cn=true]

[OnName num="keita"]
I can't stand any of that wishy-washy halfassed stuff. It makes me want to slap some sense into you.
[cpg cn=true]

[OnName num="eiji"]
Don't you dare justify what you did ……!
[cpg cn=true]

[OnName num="eiji"]
You want a fight? Fine, I'm down. Follow me.
[cpg cn=true]

[OnName num="keita"]
The two of us do a face off in the back of the school. I don't have any allies, but neither does he.
[cpg cn=true]

[OnName num="eiji"]
Still, it wasn't a fight. I just got beat up, one-sidedly.
[cpg cn=true]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//ＢＫ

Is that all it takes? Are you a girl? ......Nah, even a girl could fight more than you.
[cpg]

You've hit a woman before, haven't you? The hatred is growing, but I can't do anything.
[cpg]

[OnName num="eiji"]
Do you really want Haruka back?
[cpg cn=true]

...... I do. I think I do, but I can't stand ......
[cpg]

[OnName num="eiji"]
A few days have passed since then.
[cpg cn=true]

Naturally, I don't see Haruka. I don't even speak to her when we pass each other at school.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]
;//ＢＫ

Instead of being depressed, Haruka was back to her normal cheerful self. I often see her smiling.
[cpg]

I realize that she has become a person with whom I have no contact at all.
[cpg]

......
[cpg]

......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（夕方）******************************************************


[VOICE f="Haruka152"]
[OnName num="haruka"]
So it was really surprising that she came to visit me. After serving tea and seeing her face to face, there was nothing more for me to talk about.
[cpg cn=true]

[OnName num="keita"]
Hey, Keita.
[cpg cn=true]

What ……?
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Haruka153"]
[OnName num="haruka"]
I'm sorry about the other day. I was out of control. Please forgive me.
[cpg cn=true]

[OnName num="keita"]
...... Haruka apologizes. Smiling and in a very light tone.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Haruka154"]
[OnName num="haruka"]
She makes it sound like she hadn't been in control. Like it wasn't a big deal.
[cpg cn=true]

I still love you the most.
[cpg]

I guess Eiji doesn't consider Haruka as his girlfriend.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Haruka155"]
[OnName num="haruka"]
If that's the case, I wonder why she came to me.
[cpg cn=true]

;//察するに、彼らのうち誰もが、遥を恋人だと思ってないんだ。
I'm pregnant. But don't worry, it's your baby.
[cpg]

;//だと、したら……俺の元に来たのは、子供を妊娠したことが原因だろう。
I don't believe you!
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Haruka156"]
[OnName num="haruka"]
I stood up and started to ramble on. All the while, Haruka doesn't even look surprised. She just smiles.
[cpg cn=true]

[OnName num="keita"]
I get it! You say you're having a baby, but he doesn't want to raise it.
[cpg cn=true]

That's why you came to me! Just to make me raise the child.
[cpg]

[OnName num="keita"]
;//「だいたい分かるよ！　子供ができたけど、誰も育てる気が無いって言うんだろ」
No, Keita, I'm thinking of marrying you.
[cpg cn=true]

[OnName num="keita"]
How much of the girl I'd fallen for was still there? I couldn't tell anymore.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Haruka157"]
[OnName num="haruka"]
If she says that, I would think that she might still love me ......
[cpg cn=true]

What about a DNA test? I can't marry you unless I have something to believe that it's mine.
[cpg]

I already did. Here, look.
[cpg]

[OnName num="keita"]
She took out a stack of papers from her bag. I looked through it and although I didn't understand it, it said that it was my child.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Haruka158"]
[OnName num="haruka"]
How? Did you take my hair or something?
[cpg cn=true]

I'm sorry I didn't tell you.
[cpg]

[OnName num="keita"]
.......
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Haruka159"]
[OnName num="haruka"]
I was troubled. Our relationship was already fractured. If I didn't keep her by my side, it would shatter and I'd never see her again.
[cpg cn=true]

[OnName num="keita"]
All right …..
[cpg cn=true]

Let's start over. This time, I won't let go.
[cpg]

[OnName num="keita"]
Really? I'm so happy. If I can be with you, I'll always be happy.
[cpg cn=true]

[OnName num="keita"]
The smile that seems to be stuck on her face scares me. I'm afraid she's going to have a relationship with someone else without my knowledge.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Haruka160"]
[OnName num="haruka"]
She probably won't cheat on me for the sake of the child ......
[cpg cn=true]

I keep telling myself that. We started over as lovers.
[cpg]

Sometimes I cannot contact her without knowing why. Still, I carry on.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1100]
;//ＢＫ

The other day, I felt like she was making eye contact with the OB/GYN, and I wondered how much I could trust the DNA test. Still, I carry on.
[cpg]

Eiji also told me that he knew someone at the OB/GYN. Maybe, the results of that test were ......
[cpg]

I carry on and pretend that nothing was wrong. Haruka and I are still lovers as before, without any problems.
[cpg]

On the way home from the hospital, Haruka and I walk side by side. It's not that she's in a bad mood or that I'm in a bad mood, but we don't talk.
[cpg]

Then, Haruka starts to speak.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

Hey, Keita.
[cpg]

...... What?
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Haruka161"]
[OnName num="haruka"]
You won't hate me no matter what?
[cpg cn=true]

[OnName num="keita"]
...... She still asks me that. The answer was a given.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Haruka162"]
[OnName num="haruka"]
I won't ……
[cpg cn=true]

We ended up this way because I didn't question her. Knowing that ……
[cpg]

[OnName num="keita"]
I still carry on pretending nothing was wrong.
[cpg cn=true]

We got this way because we didn't pursue everything. Knowing that, ......
[cpg]

I'm still going to cheat.
[cpg]

[SCENE id=11]

[jump storage="epend.ks" target="*start"]

;//【遥ルート】エンド

;//==============================
