
;//５、奈々子の心配をする

*start|The irreplaceable Nanako

;#################################################
*Ep009|The irreplaceable Nanako
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_02_a.ui" method="change_1"  pos="2/5" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（夜）******************************************************


*Route05|The irreplaceable Nanako

[SCENE id=9]

[OnName num="keita"]
What about you Nanako?
[cpg cn=true]

[OnName num="keita's_mother"]
We're talking about you right now.
[cpg cn=true]

[OnName num="junichi"]
If you're changing the topic to Nanako then that means that there is no one, right?
[cpg cn=true]

Ugh. There are a few people I can think of right now, but no one I can name here.
[cpg]

[OnName num="keita"]
There is! But first, I want to ask how things are going with Nanako.
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Nanako020"]
[OnName num="nanako"]
I don't have a boyfriend.
[cpg cn=true]

[OnName num="keita's_mother"]
Well, Nanako…..
[cpg cn=true]

[OnName num="junichi"]
I'm worried about you two. At your age, you should have a special someone or three.
[cpg cn=true]

......I think it would be bad if you had more than one if you didn't want to get in a lot of trouble.
[cpg]

[OnName num="keita"]
I see, Nanako doesn't have anyone she likes either.
[cpg cn=true]

[OnName num="junichi"]
So she's like you Keita.
[cpg cn=true]

[OnName num="keita"]
There is someone I like though.
[cpg cn=true]

I was relieved to hear that Nanako didn't have a boyfriend.
[cpg]

My parents talk about how this isn't right, but my sister is irreplaceable to me.
[cpg]

I'm not sure what I'm going to do if one day she introduces her boyfriend...... I might have a stroke.
[cpg]

What if the person she brought home were a punk? I might yell and tell him to stay away from her.
[cpg]

[OnName num="junichi"]
Well, if there was a guy who would become Nanako's boyfriend, I would punch him first, ha ha ha.
[cpg cn=true]

I guess my dad would get first dibs......
[cpg]


;//ＢＫ

Nanako and I are siblings. We're past the age where we're always together, and we go to different schools.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園・入り口』（朝）******************************************************

So I don't see her when I go to school. But sometimes I wish Nanako attended the same school.......
[cpg]

Maybe I'm being overprotective, but I feel like I could keep her safe.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・教室』（昼）******************************************************

[SE f=se016 loop=true]
;//【ＳＥ】『学園の喧噪』


[OnName num="takafumi"]
You're not going to try to get a girlfriend?
[cpg cn=true]

Takafumi brought up a familiar topic.
[cpg]

[OnName num="keita"]
My family asked me the same thing …..
[cpg cn=true]

[OnName num="takafumi"]
There's a rumor going around that you might be...you know…..
[cpg cn=true]

[OnName num="keita"]
Why are they talking about me……?
[cpg cn=true]

[OnName num="takafumi"]
Well, it's unusual for a guy our age to not fall in love.
[cpg cn=true]

[OnName num="takafumi"]
Just think about it. Close your eyes for a second and you will see the smile of the girl you like.
[cpg cn=true]

[OnName num="keita"]
What are you talking about, Takafumi ……?
[cpg cn=true]

I try to picture it. A girl, a girl, huh?
[cpg]

As I was thinking about it, a certain person's smile did indeed come to mind. That person was Nanako ......
[cpg]

[OnName num="keita"]
I guess my little sister is enough for me.
[cpg cn=true]

[OnName num="takafumi"]
What's that supposed to mean?
[cpg cn=true]

I know it's not true even though I so. If you ask me if I wanted to kiss Nanako, the answer would be a resounding no.
[cpg]

On the other hand, if Nanako were to come on to me, I still wouldn't like it.
[cpg]

[OnName num="keita"]
I'm sorry, there is no one in particular that I like. There is someone I care about though, but...
[cpg cn=true]

[OnName num="takafumi"]
So, tell me who it is!
[cpg cn=true]

[OnName num="keita"]
Nanako. My sister.
[cpg cn=true]

[OnName num="takafumi"]
...... Isn't that answer a little unfair?
[cpg cn=true]

I don't know if it's unfair. What's wrong with caring about my sister?
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="amamori1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

Even on the way home, I remembered what Takafumi had said to me.
[cpg]

Why did Takafumi ask me that? Maybe Chiho was using him to get information out of me.
[cpg]

However, I could not see Chiho as more than a childhood friend. When compared to Nanako, I would say that Nanako is more important to me.
[cpg]

When I think about whether I would be shocked if one of them got a boyfriend, it would be Nanako by far......
[cpg]

…… Wow, I'm getting more and more worried. I thought about this yesterday, what if Nanako gets a boyfriend?
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[SE f="se007"]
;//【ＳＥ】『ドアをノック』コンコン

I head back home and knock on Nanako's door.
[cpg]




[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・奈々子の部屋』（夕方）******************************************************

[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=800]

Nanako seems bored and ignores my worried look. She is always like this, never getting excited about anything.
[cpg]

[OnName num="keita"]
About what we were talking earlier …..Do you really not have a boyfriend? And am I prying?
[cpg cn=true]

Nanako gives me an exasperated look.
[cpg]

[OnName num="keita"]
I don't even have a favorite celebrity or anything. Or a cartoon character. ……
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Nanako021"]
[OnName num="nanako"]
If I were to have a boyfriend, you'd probably be the first to know. Especially since you keep asking.
[cpg cn=true]

She says this angrily, but in a joking way. It's cute.
[cpg]

[OnName num="keita"]
I see. You're right.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

I'm relieved. I really feel overprotective, but that doesn't make Nanako any less cute.
[cpg]

[OnName num="keita"]
I've been thinking about it for a long time. If you were to get married I'd definitely cry.
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Later, we sat around the table for dinner. It was a time of rest and relaxation for all four family members.
[cpg]

[OnName num="junichi"]
...... What's the matter, Keita? You seem unusually giddy.
[cpg cn=true]

[OnName num="keita"]
Oh, am I?
[cpg cn=true]

I might have been smiling. The first time in a long time, I felt that the distance between us siblings had been closing.
[cpg]

[OnName num="keita's_mother"]
And Nanako, you seem a little happier, too.
[cpg cn=true]

My mother is also a master at detecting changes in Nanako's facial expression …… even though Nanako almost always seems a little dark.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夕方）******************************************************

The following evening, after returning from school. I had nothing special to do and no particular place I wanted to go, so I decided to just relax at home ......
[cpg]


[SE f="se007"]
;//【ＳＥ】『ドアをノック』コンコン
[WAIT time=1000]

[OnName num="keita"]
Umm, hold on a second .......
[cpg cn=true]

I get out of the chair I was sitting in and open the door. It's very unusual for Nanako to come to my room.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・奈々子の部屋』（夕方）******************************************************

Nanako invited me to her room. I don't know why she did that.
[cpg]

I think she just wants to talk to me. If so, it might be another chance to strengthen our bond.
[cpg]

[OnName num="keita"]
Nanako, is there anyone that you like?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Nanako022"]
[OnName num="nanako"]
I like manly men, but there aren't any in my class.
[cpg cn=true]

[OnName num="keita"]
You've been saying that for a while. You often tell me I'm too feminine and that I should be more manly.
[cpg cn=true]

My father is a manly man. If she has some kind of admiration for him, it's possible.
[cpg]

[OnName num="keita"]
I see.
[cpg cn=true]

She seemed calm but that's a strange story, if you think about it.
[cpg]

[OnName num="keita"]
Wait a minute. If you like a manly man, and you want me to be manly, then that's ...
[cpg cn=true]

[OnName num="keita"]
Then that means you like me or something, right? Haha.
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Nanako023"]
[OnName num="nanako"]
I do like you.
[cpg cn=true]

[OnName num="keita"]
......Oh.
[cpg cn=true]

I meant it as a joke. Just to nudge her a little. But the reply that came back was serious.
[cpg]

[OnName num="keita"]
All this time you've been telling me to man up. What does it mean ...... when you say you like me?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
I thought Nanako smiled a little. It's a smile you rarely see from your younger sister.
[cpg]

[OnName num="keita"]
What did you mean by that? As family? As your brother, right?
[cpg cn=true]

I was shocked, I couldn't tell what was going on. Does she like me as a man, rather than a brother?
[cpg]

[FADEOUTBGM]

[OnName num="keita"]
Wha-…..
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


She smothers me with kisses.
[cpg]

[BGM f="bg_t2"]
[WAIT time=100]

[OnName num="keita"]
We can't!
[cpg cn=true]


I pushed her off of me. I knew it was impossible, this is not right.
[cpg]

;//●ＣＧエロ（奈々子・主人公に迫るヒロイン。服を着せてください：奈々子の部屋）ev_43
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_43_0 ***********************
[CG id=20 index=0 time=1000]
;***************************************
[WAIT time=1000]

For a moment, Nanako looked like a girl instead of my sister.
[cpg]

What was wrong with me? I had to calm down.
[cpg]

[OnName num="keita"]
I can't.....we're siblings, this isn't right!
[cpg cn=true]


[VOICE f="Nanako024"]
[OnName num="nanako"]
…….
[cpg cn=true]


Nanako just stares at me in silence.
[cpg]


;//移植のためシーンをカットしています

Then I heard another person's presence. I hurriedly looked at the door.
[cpg]



[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=1000]
;//【ＢＧ】『恵太の家・奈々子の部屋』（夕方）******************************************************

[OnName num="junichi"]
…… What's wrong? You both look so weird.
[cpg cn=true]

[OnName num="keita"]
No, no, it's just …
[cpg cn=true]

[OnName num="junichi"]
Haha, I see, I see…..
[cpg cn=true]

Dad crosses his arms. Did he know!? Was there a mark or something!?
[cpg]

[OnName num="junichi"]
I'm glad you guys get along so well. You don't have to hide it! Ha ha ha!
[cpg cn=true]

Ah ...... This means he didn't notice ......
[cpg]


;//ＢＫ

I wasn't sure whether to feel relieved or not.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（朝）******************************************************

I couldn't see Nanako as just my sister anymore. And yet, Nanako acted as if nothing had happened.
[cpg]

The only awkwardness was on my part. I feel as if everything that happened yesterday was a mistake.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・教室』（昼）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chiho214"]
[OnName num="chiho"]
...... Keita?
[cpg cn=true]

I was so confused that I spent the whole day thinking about Nanako.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Chiho215"]
[OnName num="chiho"]
Keita, Keita!
[cpg cn=true]

[OnName num="keita"]
Oh …… Chiho, what's up?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Chiho216"]
[OnName num="chiho"]
You seem out of it today, Keita. Are you okay?
[cpg cn=true]

[OnName num="keita"]
Yeah, I'm fine ……
[cpg cn=true]

I felt that if I didn't say I was okay, it would be like I was acknowledging that my life had changed forever. I kept my mouth shut.
[cpg]

[FO pos="2/3" time=500]
[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chiho217"]
[OnName num="chiho"]
So, how is Nanako doing?
[cpg cn=true]

[OnName num="keita"]
What ….?
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Chiho218"]
[OnName num="chiho"]
What's wrong? I was thinking about going to your house to hang out ……
[cpg cn=true]

It's okay, it's okay. There's no need to rush. Chiho said she wanted to come to my house.
[cpg]

That was convenient, if Chiho was with us, Nanako wouldn't do anything.
[cpg]

[OnName num="keita"]
Uhh, what were we talking about? Nanako? Yeah, she's fine.
[cpg cn=true]

[FO pos="2/3" time=500]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chiho219"]
[OnName num="chiho"]
So...... can I come over today?
[cpg cn=true]

[OnName num="keita"]
Of course.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
There's nothing else to say. Because there is no way I can say that I kissed my sister.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・恵太の部屋』（夕方）******************************************************

After class, I left school with Chiho.
[cpg]

[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Chiho220"]
[OnName num="chiho"]
Thank you for having me over.
[cpg cn=true]

[OnName num="keita"]
You don't have to say that every time you enter my room.
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Chiho221"]
[OnName num="chiho"]
But I haven't been to your room in a while. I got a little nervous.
[cpg cn=true]



[FACE method="change_1" pos="4/5"]
;//ＢＫ

The three of us talked about trivial things. The atmosphere was cheerful throughout, but Nanako was the only one who seemed a little down.
[cpg]

But that was normal for her. Everything was normal. Nothing has changed since the last time the three of us were together.
[cpg]

Therefore, nothing has changed for Nanako, and nothing has changed for me......
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夕方）******************************************************

[FACE method="bow_1" pos="4/5"]
[VOICE f="Chiho222"]
[OnName num="chiho"]
School? Well, aside from Keita ignoring me all of the time, it's pretty normal.
[cpg cn=true]

[OnName num="keita"]
I was just thinking about something...
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Chiho223"]
[OnName num="chiho"]
I know you don't have anybody you like right now, but you could stand to be a little more proactive about finding a girlfriend.
[cpg cn=true]

[OnName num="keita"]
Huh? I don't think I told that to anybody but Takafumi?
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]
[VOICE f="Chiho224"]
[OnName num="chiho"]
Oh…….
[cpg cn=true]

So it was Chiho behind him. Oh well……
[cpg]


[FACE method="shake_4" pos="4/5"]
[VOICE f="Chiho225"]
[OnName num="chiho"]
No, it's not like that! Takafumi told me, uh, uhhh, so you know......
[cpg cn=true]

It was somewhat awkward, and I got up from my seat.
[cpg]

[OnName num="keita"]
I'm going to go to the restroom.
[cpg cn=true]


[FACE method="bow_6" pos="4/5"]
[VOICE f="Chiho226"]
[OnName num="chiho"]
Oh, haha ...... go on.
[cpg cn=true]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


I had nothing to do in the bathroom, so after some time I went back to the same room.
[cpg]

Something unexpected had happened.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・恵太の部屋』（夕方）******************************************************

[FACE method="shake_7" pos="4/5"]
[VOICE f="Chiho227"]
[OnName num="chiho"]
Oh, Keita ……
[cpg cn=true]

It felt like something strange had happened while I was away. Their expressions were hard, like they'd just been arguing.
[cpg]

We were just chatting lightly before I left, what happened while I was gone?
[cpg]

[OnName num="keita"]
What were you talking about while I was gone? You look mad......
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]
[VOICE f="Chiho228"]
[OnName num="chiho"]
What? Do we? It's nothing, really.
[cpg cn=true]

[OnName num="keita"]
......If you say so.
[cpg cn=true]

I didn't believe her and wanted to pursue it further, but even I could tell that it would be pointless so I let it go.
[cpg]



[window target=false]
[transition target={true} rule="amamori1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

After Chiho left, we had dinner as a family as usual. There doesn't seem to be anything unusual.
[cpg]

Mom is smiling, dad is smiling. Nanako is not, but that's the way it always is.
[cpg]

If anything has changed, it's me and Nanako ......but wait a minute.
[cpg]

Maybe Nanako told her about me. Maybe she told Chiho that she kissed me.
[cpg]

If so, it would not make sense that Nanako had a more serious face ...... but it explains Chiho's expression.
[cpg]

If Nanako had just told Chiho about her feelings for me, and I came back in that moment, it would explain a lot.
[cpg]

I'm going to have to make up my mind, too. I can't cross the line with Nanako. I don't want to cross the line with Nanako.
[cpg]

I don't like how I'm starting to see Nanako as a woman.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_00_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（朝）******************************************************

When I wake up in the morning, nothing has changed.
[cpg]

I think I feel the same way about Nanako as well. I don't want things to change.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

Nanako and I go to different schools, so we will have to part along the way. But until then, we can walk together.
[cpg]

She doesn't look any different than usual, but the events of the other day flash through my mind.
[cpg]

Nanako said she liked me. If asked whether I like her or not, I'd say yes, but it's not the same kind of like.
[cpg]

If she only liked me as a sibling, she wouldn't have done that. But if she's serious about her feelings......
[cpg]

I'd have to find a way to turn her down.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]
;//ＢＫ


That day, I had a strange dream.
[cpg]


;//●ＣＧエロ（奈々子・拘束されているヒロイン。顔のモザイクを外せたら外してください：地下室のような場所）ev_44
[BGM f="bg_h3"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=21 index=0 time=1000]
;***************************************
[WAIT time=1000]

I dreamt that Nanako was alone, tied up somewhere.
[cpg]

I wonder if my subconscious was implying that I see her as a girl instead of family.
[cpg]

She seemed like she was suffering......was this a warning?
[cpg]

I was thinking about Nanako so much that she appeared in my dream.
[cpg]

......She's an important person to me.
[cpg]


;//このシーン中、奈々子の名前を？？？と隠してください

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『学園・教室』（夕方）******************************************************

[OnName num="takafumi"]
You seem dark lately? Is something wrong?
[cpg cn=true]

[OnName num="keita"]
What? What do you mean by dark? You mean my facial expression?
[cpg cn=true]

[OnName num="takafumi"]
The way you asked that pretty much confirms it. Usually you'd just say that nothing was going on with you.
[cpg cn=true]

Maybe he was right, I certainly wasn't feeling at peace.
[cpg]

[OnName num="keita"]
It's nothing ……
[cpg cn=true]

[OnName num="takafumi"]
You know, Keita. I don't know what's bothering you, but if you say it's nothing and don't do anything about it, you'll be stuck at where you are.
[cpg cn=true]

...... He might be right. I think I'm going to have to talk to Nanako soon.
[cpg]


[OnName num="takafumi"]
I'll be happy to talk to you about it.
[cpg cn=true]

[OnName num="keita"]
Yeah. Thanks.
[cpg cn=true]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・リビング』（夕方）******************************************************

[OnName num="keita"]
I'm home.
[cpg cn=true]

[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=800]

When I returned home, Nanako was there. When I saw her face, I felt relieved.
[cpg]

But if I don't do anything, I might not even have this feeling anymore. So, I mustered up the courage.
[cpg]

[OnName num="keita"]
...... Hey, I need to talk to you. Nanako.
[cpg cn=true]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夕方）******************************************************

In my room, we talked about various things. Just casual stuff that we could bond over.
[cpg]

I was not going to suddenly start talking about whether or not she liked me or not.
[cpg]

Or rather, I feel Nanako is trying to avoid a dark topic.
[cpg]

I couldn't bring it up in any way, and time just kept passing ......
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

But there was something strange in the air.
[cpg]

If felt like she was purposefully making me not talk about it.
[cpg]

I felt as if Nanako was asking me for help. I don't know why, but that's how I felt.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="amamori1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（朝）******************************************************

[OnName num="keita's_mother"]
Oh my, you're up early this morning. Keita.
[cpg cn=true]

[OnName num="keita"]
Oh, good morning ...... I couldn't sleep.
[cpg cn=true]

I think and think, trying to figure out what was going on with her. If it was a boy, who could it be? She'd never introduced anybody to me.
[cpg]

If it was somebody I'd introduced to her, then it was somebody I trusted. I wouldn't let anybody I wasn't sure about near her.
[cpg]

[OnName num="junichi"]
I'm sure you can get a part time job if you're up this early in the morning.
[cpg cn=true]


[OnName num="keita"]
I don't want a part-time job. I have my hands full with my schoolwork.
[cpg cn=true]


[OnName num="keita's_mother"]
I hope your grades are good enough to prove that.
[cpg cn=true]

[OnName num="junichi"]
Haha, that's so right!
[cpg cn=true]

[OnName num="keita"]
Oh come on, guys.
[cpg cn=true]

My parents laugh a lot. They never quarrel and we are a happy family.
[cpg]

The pillar of our family would never allow his daughter to do......that kind of work.
[cpg]

[OnName num="keita"]
Hey…… Dad?
[cpg cn=true]

[OnName num="junichi"]
Yeah. What is it?
[cpg cn=true]

[OnName num="keita"]
What do you think of Nanako?
[cpg cn=true]

It's a vague question. Depending on his answer, I felt like I could trust him.
[cpg]

[OnName num="junichi"]
I think she's a nice girl! She must have five or six boyfriends by now.
[cpg cn=true]

[OnName num="keita"]
I don't like that idea.
[cpg cn=true]

I knew he wouldn't do that. I think he's a bright and open-minded person, I'm sure of it.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

The middle of the night. I couldn't sleep because of the uneasiness in my chest, so I took a walk around the area.
[cpg]

As I walked, I became more and more anxious. One thought filled my mind.
[cpg]

Something was off with Nanako. At least, that's how it seemed to me.
[cpg]

Something must have gone wrong a long time ago ……
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

There have been signs for a long time.
[cpg]

This was probably the reason why he seemed to know about my relationship with Nanako.
[cpg]


;//●ＣＧエロ（奈々子・父と抱き合うヒロイン：奈々子の部屋）ev_45
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_45_0 ***********************
[CG id=22 index=0 time=1000]
;***************************************
[WAIT time=1000]

The door to Nanako's room was slightly open, and there was my father.
[cpg]

I didn't wonder why. It made sense to me.
[cpg]

This is what Nanako was asking for help for, right?
[cpg]

I wondered why I hadn't noticed it before.
[cpg]

Wasn't she suffering from being forced to be with my father all this time?
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

No ...... it was all a dream. It's all been a dream, ever since that day when Nanako came on to me.
[cpg]


I curled up under the covers, but I felt so anxious that I realized that it was not a dream. All of it was real.
[cpg]

Nightmares don't make me anxious. Some part of you knows it's all a dream. This was worse.
[cpg]

I'd never be able to dream of something this horrible.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（朝）******************************************************

If it was all a dream, everything would be back to normal when morning came. And sure enough, my father and Nanako were back to normal.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・リビング』（朝）******************************************************

[OnName num="junichi"]
What's wrong, Keita? You look pale.
[cpg cn=true]

[OnName num="keita"]
……
[cpg cn=true]

The two people involved pretend as if nothing has changed at all.
[cpg]

I wasn't dreaming. I almost went back to the thoughts I once denied.
[cpg]

[OnName num="keita's_mother"]
When you clam up like that, it makes you look like you're going to be ill.
[cpg cn=true]

[OnName num="keita"]
Oh, no......Do I really look that pale? I might have a cold.
[cpg cn=true]

I make an excuse for my behaviour and try to act normal. To an outsider, we must look like a perfectly normal family.
[cpg]

There was nothing normal about us.
[cpg]

[OnName num="keita"]
Hey Nanako, about yesterday…
[cpg cn=true]

Nanako didn't panic. My father didn't either. And my mother doesn't seem to know anything about it.
[cpg]



;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


I couldn't ask her as we were headed towards school. I was too scared to ask.
[cpg]

She didn't seem any different than usual. That means it's happened before and I just didn't notice it.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・廊下』（昼）******************************************************

I go to school but I can't concentrate on my studies. I was too preoccupied with trying to act normal.
[cpg]

Something about the school felt off. Then again, nothing seemed normal anymore.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Haruka163"]
[OnName num="haruka"]
...... Are you alright, Keita?
[cpg cn=true]

Haruka was only passing by and even she could tell something was wrong.
[cpg]

[OnName num="keita"]
.......I don't think so……
[cpg cn=true]

I wondered if this was a situation where I should ask someone for help.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Haruka164"]
[OnName num="haruka"]
What's wrong? If it's okay with me, I'll listen to what you have to say.
[cpg cn=true]

[OnName num="keita"]
.......Yeah, thanks.
[cpg cn=true]

[free time=1000]
[WAIT time=1000]

Chiho also came from far away. She waved her hand and came toward us.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Chiho229"]
[OnName num="chiho"]
What were you talking about, Keita?
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Haruka165"]
[OnName num="haruka"]
Well, he said he wasn't doing too hot so I was trying to find out what was going on.
[cpg cn=true]


[FACE method="bow_3" pos="2/5"]
[VOICE f="Chiho230"]
[OnName num="chiho"]
If that's the case, I'm here for you too, Keita. I know you've been feeling down lately.
[cpg cn=true]

It's a little pathetic that I'm asking two girls for advice.
[cpg]

I am depressed from Chiho's point of view, and I look like I'm not doing okay from Haruka's point of view.
[cpg]

Then I don't have to pretend. They might say something that will change the situation ......
[cpg]

[OnName num="keita"]
...... So, let's see. It's about my sister.
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Haruka166"]
[OnName num="haruka"]
Oh yeah, I almost forgot you had a sister......I don't think I've ever met her.
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Chiho231"]
[OnName num="chiho"]
You mean Nanako, right? What's going on?
[cpg cn=true]

I wasn't sure how to explain the situation.
[cpg]

[OnName num="keita"]
I found something out about my sister...and, as her brother, I'm not sure what to do......
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Haruka167"]
[OnName num="haruka"]
That's very abstract. It doesn't sound like you can do anything, really.
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Chiho232"]
[OnName num="chiho"]
.......
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Haruka168"]
[OnName num="haruka"]
Well, cheer up. If you're her brother, you can help her by keeping her secret, right?
[cpg cn=true]

Haruka offers empty advice. Chiho, on the other hand...
[cpg]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Chiho233"]
[OnName num="chiho"]
Did Nanako tell you everything?
[cpg cn=true]

[OnName num="keita"]
Everything...?
[cpg cn=true]


[FACE method="bow_3" pos="2/5"]
[VOICE f="Chiho234"]
[OnName num="chiho"]
You should probably ask her directly.
[cpg cn=true]

What's that? Chiho says something that makes me feel even more uneasy.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

After the class, I was on my way home. My heart felt like it was about to burst.
[cpg]

After yesterday, I was sure she was having a relationship with my father. But I didn't know the whole story.
[cpg]

Was Nanako the instigator? That would change a lot......
[cpg]

If it was initiated by Nanako, I'd have to accept it. If it's something Nanako wants and Dad accepts then it wasn't my place to interfere.....even if it was wrong.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se007"]
;//【ＳＥ】『ドアをノック』コンコン
[WAIT time=1000]

[transition target={true} rule="hiraki.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hiraki.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・奈々子の部屋』（夜）******************************************************

After dinner. I went to Nanako's room and told her about yesterday.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Nanako025"]
[OnName num="nanako"]
Yes, it's about father, isn't it?
[cpg cn=true]

The more I listened to her, the more my father's vile nature became apparent. My body trembles as I seethe with anger.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Nanako026"]
[OnName num="nanako"]
I didn't like it at first, as you might expect, but even if I refused......I'm only a child.
[cpg cn=true]

[OnName num="keita"]
...... You really believe that?
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Nanako027"]
[OnName num="nanako"]
The truth is, I may not want to upset father. If I go against what he says …….
[cpg cn=true]

Nanako seemed to laugh a little. Self-loathing, I was sure.
[cpg]

I was so angry that my eyes had turned bloodshot and red. But at the same time, I was becoming afraid of my father.
[cpg]

How can Nanako be saved from someone who can do such a terrible thing without hesitation?
[cpg]

[OnName num="keita"]
The reason she approached me......probably wasn't out of love.
[cpg cn=true]

It couldn't be what she really wanted. She was trying to ask me for help.
[cpg]

Maybe she wanted me to be masculine because she wanted me to be stronger than my dad. Or maybe she wants my presence to override the pain she suffered from my father.
[cpg]

[OnName num="keita"]
Why didn't you tell mother?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nanako028"]
[OnName num="nanako"]
...... Father told me not to. He said that if she found out, it wouldn't end with just a fight.
[cpg cn=true]

The implications were damning. A parent should never say something like this to a child.
[cpg]

Nanako probably wanted a happy family more than anyone else. She endured all this pain alone.
[cpg]

[OnName num="keita"]
I can't believe it ......
[cpg cn=true]

What was I saying? I didn't know the truth, I was happy to believe in the facade I'd lived with all these years.
[cpg]

;//●ＣＧエロ（奈々子・主人公に襲いかかるヒロイン：奈々子の部屋）ev_46
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h3"]
;**【ＣＧ】 ev_46_0 ***********************
[CG id=23 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Nanako029"]
[OnName num="nanako"]
Unbelievable? What will it take for you to believe me?
[cpg cn=true]


[OnName num="keita"]
Nanako......
[cpg cn=true]


;**【ＣＧ】 ev_46_a ***********************
[CG id=23 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Nanako030"]
[OnName num="nanako"]
.......But you already know.
[cpg cn=true]


[VOICE f="Nanako031"]
[OnName num="nanako"]
Everything I say is true.
[cpg cn=true]


She's been driven crazy long ago. There is no longer any doubt about that.
[cpg]


;//移植のためシーンをカットしています

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

I should have just taken action immediately......But here I was, trying to think of ways to rescue Nanako from our father.
[cpg]

I couldn't help but think of the pain Nanako was going through.
[cpg]



[window target=false]
[transition target={true} rule="hiraki.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hiraki.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

I'd have to confront my father. The only way to help Nanako is to stop the person responsible for her pain.
[cpg]

But would I be able to persuade him? What Nanako says is probably true, which would mean he has a cruel side.
[cpg]

What would happen if I told him that I knew everything?
[cpg]

What would he do to me? It felt like it was hard for me to take the first step.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

Later that night, I took that first step.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（夜）******************************************************

[OnName num="junichi"]
What's the matter? I'm sleepy.
[cpg cn=true]

[OnName num="keita"]
......Yeah, it's not going to take long.
[cpg cn=true]

I've always been scared of my father to some extent. But tonight, he seemed terrifying.
[cpg]

Ever since I found out what he was doing to Nanako, he even seemed somehow alien. I couldn't see a trace of remorse on his face.
[cpg]

[OnName num="keita"]
I want you to tell me what you've been doing to Nanako.
[cpg cn=true]

[OnName num="junichi"]
…….
[cpg cn=true]

For a moment, Dad's face turns serious. I almost didn't recognize him.
[cpg]

[OnName num="junichi"]
Hahahaha! I was wondering when you would find out.
[cpg cn=true]

He talked about it as if it was entertainment. My father, whom I thought I knew so well, continued to speak in his familiar voice.
[cpg]

[OnName num="junichi"]
So what do you want to do about it?
[cpg cn=true]

[OnName num="keita"]
I don't want Nanako to go through that again.
[cpg cn=true]

My voice is hoarse and my throat is dry. But I have to tell him to stop. I have to save Nanako.
[cpg]

[OnName num="keita"]
I need you to leave her alone.
[cpg cn=true]

[OnName num="junichi"]
I see. I'm glad you've grown up to be such a good brother, Keita.
[cpg cn=true]

[OnName num="junichi"]
But I can't do that. She's a fine woman and I'm not about to let her go.
[cpg cn=true]

He says horrible things with a smile on his face. He wasn't about to back down.
[cpg]

[OnName num="keita"]
If you don't stop......I'm going to make you.
[cpg cn=true]

[OnName num="junichi"]
What? You're going to tell her mother or something, right?
[cpg cn=true]

I faltered, he'd hit the nail on the head. He's probably already thought of a way out.
[cpg]

[OnName num="junichi"]
Suppose you tell your mother about this. Nanako would be the one who would be heartbroken, no?
[cpg cn=true]

[OnName num="keita"]
That's …….
[cpg cn=true]

[OnName num="junichi"]
Nanako is the one who has kept quiet to Mom no matter what I've done to her. And you're going to do it?
[cpg cn=true]

[OnName num="junichi"]
Hahaha, do you want to be the one to break her precious family apart? You'll undo everything she's tried so hard to keep together.
[cpg cn=true]

I was terrified. He looked like he was laughing, but his voice could barely conceal his anger.
[cpg]

I wasn't sure if he was even trying to hide it, honestly. He might be smiling, but he looked down upon me with fury in his eyes.
[cpg]

I can't stand up to this person. I can't say anything. The more I think about it, the more frightened I am.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

What am I going to do? Is everything going to stay the same?
[cpg]

I don't want to do that, but I feel like it's the only thing I can do. My father must have thought of everything already.
[cpg]

He must have been thinking about what he would do if I found out. That's how much his words were holding me back.
[cpg]

Maybe he was respecting her wishes. Maybe this wasn't my fight.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="amamori1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

In the morning, I walked alone to school. I didn't want to walk with Nanako, even if it was only to the halfway point.
[cpg]

I had no one. I have nothing. I have no one to help me, not even my sister, who was supposed to be the most important person in my life.
[cpg]

I don't even have anyone I can talk to about this.......
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・廊下』（昼）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chiho235"]
[OnName num="chiho"]
Keita. Is this a good time?
[cpg cn=true]

[OnName num="keita"]
...... yeah.
[cpg cn=true]

But it seems that there was someone who was concerned about me.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Chiho236"]
[OnName num="chiho"]
Is it about Nanako?
[cpg cn=true]

I can't even say a word. I just nodded my head. I felt a little saved by Chiho, not that there was anything she could do to help.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・教室』（昼）******************************************************


[VOICE f="Chiho237"]
[OnName num="chiho"]
So, you know now, right? Nanako also asked me for advice.
[cpg cn=true]

[OnName num="keita"]
I figured……
[cpg cn=true]

It was the last time we'd gathered together. Nanako had looked a little down that day.
[cpg]

[OnName num="keita"]
I don't know what to do now. Hey Chiho, what do you think ......?
[cpg cn=true]

Chiho's face fell. But then she looked at me and smiled.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Chiho238"]
[OnName num="chiho"]
It's okay. You're a hero to Nanako.
[cpg cn=true]

[OnName num="keita"]
What?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Chiho239"]
[OnName num="chiho"]
Nanako told me. I'm sure it's rare for a brother and sister to adore each other so much.
[cpg cn=true]

[OnName num="keita"]
......
[cpg cn=true]

I didn't know she said that. But it could be possible. Maybe she's even looking at me like I'm a hero because she said she liked me.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Chiho240"]
[OnName num="chiho"]
I'm sure, if I say there's nothing you can do about it, then there might be nothing you can do about it. I think Nanako will suffer if you do something reckless.
[cpg cn=true]

[OnName num="keita"]
Yes, that's right.
[cpg cn=true]

Nanako didn't want our family to fall apart. If that's the case, what should I do...?
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Chiho241"]
[OnName num="chiho"]
But if you take good care of Nanako, I think that will be enough to support her.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Chiho242"]
[OnName num="chiho"]
I've been saved many times just by having you around.
[cpg cn=true]

[OnName num="keita"]
Thank you …….
[cpg cn=true]

These words from Chiho may be close to a confession. But I can't respond to anything now. I am sure Chiho is not looking for a response either.
[cpg]


[FACE method="shake_5" pos="2/3"]
[VOICE f="Chiho243"]
[OnName num="chiho"]
I'm sorry for talking about this.
[cpg cn=true]

I smiled. I am liked by more people than I thought.
[cpg]

So, I mustn't break down here. If I break down, Nanako will break down with me.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hikari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hikari.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

I felt a little more inspired. My mother would be home late today due to her work schedule.
[cpg]

That means it's just me, my dad, and Nanako. Maybe we could settle the matter today.
[cpg]

With that in mind, I headed home.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・リビング』（夕方）******************************************************

I waited for my father to come home. It would have been fine if I had talked to Nanako one-on-one, but I wanted to get everything done at once.
[cpg]

[OnName num="junichi"]
I'm home, Keita. What's wrong?
[cpg cn=true]

[OnName num="keita"]
I'm sorry, Dad. I wonder if the three of us could talk alone.
[cpg cn=true]

I'd thought he'd flinch or react in some way.
[cpg]

[FADEOUTBGM]

[OnName num="junichi"]
Not right now.
[cpg cn=true]

[OnName num="keita"]
......What?
[cpg cn=true]

[BGM f="bg_h3"]
[WAIT time=100]

[OnName num="junichi"]
Your mother isn't here today and since you already know everything, there's no reason for me to keep pretending.
[cpg cn=true]

He heads to Nanako's room.
[cpg]

[OnName num="keita"]
.......
[cpg cn=true]

I just stood there, stunned. I couldn't even stop him.
[cpg]

He just walked into Nanako's room ......
[cpg]


;//ＢＫ

;//●ＣＧエロ（奈々子・父に迫られるヒロイン：奈々子の部屋）ev_47
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;**【ＣＧ】 ev_47_0 ***********************
[CG id=24 index=0 time=1000]
;***************************************
[WAIT time=1000]

What is happening in her room?
[cpg]

How could I not know? I'm not an idiot either.
[cpg]

But ...... the current situation is also something Nanako has created.
[cpg]

It's something she has tried to protect. I don't know if it's okay for me to destroy it.
[cpg]

I don't know ...... I don't know anything anymore.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています




They say time heals everything. I'm sure we will be healed too.
[cpg]

Nothing changes in a day. But after a month or a year, something will change.
[cpg]

So, I should pretend that I don't know. I can't be the hero who saves Nanako.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（朝）******************************************************

[OnName num="keita"]
……
[cpg cn=true]

I can't even say hello to her any more. Nanako's face, which looks as if she doesn't care, pierces my heart.
[cpg]

[OnName num="junichi"]
Did you eat breakfast? If you don't eat quickly, you'll be late for school.
[cpg cn=true]

[OnName num="keita"]
……
[cpg cn=true]

[OnName num="keita's_mother"]
I'm not sure what's going on with you lately, Keita. What's troubling you?
[cpg cn=true]

[OnName num="keita"]
No, it's nothing, Mom.
[cpg cn=true]

It's nothing. It's got to be nothing or I'm going to go crazy.
[cpg]

[OnName num="keita"]
.... Hey, Mom. Don't leave the house too often, or I'll miss you.
[cpg cn=true]

[OnName num="keita's_mother"]
Aww. Thank you for saying that.
[cpg cn=true]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

If only Mom didn't leave the house, Dad wouldn't be so reckless.
[cpg]

Please stay at home. That would stop him from doing things.
[cpg]

My hopes were crushed when my mother left the house for work again. It was the weekend.
[cpg]


[OnName num="keita"]
……
[cpg cn=true]


[OnName num="junichi"]
Hey, hey, Keita, your sister and I are going out. Why don't you at least say goodbye?
[cpg cn=true]


[OnName num="keita"]
……
[cpg cn=true]

I can't say anything. There was no way I could support that.
[cpg]

The last thing I saw was a slightly angry face. I'm sure she's still looking for me to help her.
[cpg]

I am sure she is still asking for my help. Nanako is probably looking to me for some miraculous salvation. But there is nothing I can do……
[cpg]


[window target=false]
[transition target={true} rule="kosuri5.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kosuri5.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="kosuri5.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kosuri5.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

I wandered around the city with no particular purpose. I walked where my feet took me, heading nowhere.
[cpg]

I can't stay at home. I didn't want to be at home without Nanako, my father, or my mother, because it seemed to symbolize ...... my current family.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chiho244"]
[OnName num="chiho"]
Oh Keita, what a coincidence.
[cpg cn=true]

As I was walking in town, I bumped into Chiho. She seemed to be returning from some kind of shopping and had a cute bag in her hand.
[cpg]

[OnName num="keita"]
...... Chiho.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Chiho245"]
[OnName num="chiho"]
What's wrong? Why are you crying?
[cpg cn=true]

Most girls could live normal lives. Why couldn't Nanako?
[cpg]

Why couldn't Nanako go outside with her friends on the weekend? She had every right to.
[cpg]

I am the worst. Chiho hadn't done anything wrong and yet I felt resentment towards her.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Chiho246"]
[OnName num="chiho"]
Hey, Keita. Don't cry ……
[cpg cn=true]

[OnName num="keita"]
I'm sorry …… sorry, Chiho.
[cpg cn=true]

Nanako was taken to a photo shoot, according to my father. But I can't talk about it with Chiho.
[cpg]

I wonder what Nanako will have to go through. Just imagining it makes my tears well up again.
[cpg]


;//ＢＫ

;//奈々子に視点切り替わり
;//[ChangeWindow num="1"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA05_p2_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h3"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


I wonder what kind of terrible things he will do to me.
[cpg]

[OnName num="junichi"]
What, are you having second thoughts?
[cpg cn=true]

My brother didn't do anything to stop him. Of course, it's not like I wanted him to.
[cpg]

I didn't want my mother to know about this. I never want to see them fighting again.
[cpg]

I think they call it trauma. When I was a child, my parents used to fight in front of me, instead of my brother.
[cpg]

When my brother was around, he would immediately try to stop them from fighting. But I didn't. So my parents naturally started fighting in front of me instead.
[cpg]

I endured it for a long time. By the time I reached my limit, it had become a deep psychological scar.
[cpg]

I hate it when my parents fight. I don't even want to think of how I'd feel if they got divorced.
[cpg]

The thought that I might be separated from my brother was so painful that I felt as if I would die.
[cpg]

[OnName num="junichi"]
It's at the end of this alley. Come on, Nanako.
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]

I can't disobey my father. I covered up my fear and pain by clinging to pleasure.
[cpg]

I knew what would happen if I refused to do what he wanted. That's why I've started to take pleasure in it myself.
[cpg]

Help me, brother. I'm sure you don't have the means or the will to help me. But I still cry out for help.
[cpg]


;//ＢＫ
;//移植のためシーンをカットしています

;//恵太に視点切り替わり
;//[ChangeWindow num="0"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（夕方）******************************************************

[OnName num="junichi"]
Today's supper was amazing. What's the occasion?
[cpg cn=true]

[OnName num="keita's_mother"]
Oh it's nothing, I wasn't able to cook for you the other night, so I wanted to make sure I was still at the top of my game.
[cpg cn=true]


[FG f="CHA05_p2_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanako032"]
[OnName num="nanako"]
I want to be able to cook like you.
[cpg cn=true]

[OnName num="junichi"]
I can't imagine Nanako cooking, can you Keita?
[cpg cn=true]

[OnName num="keita"]
......I guess.
[cpg cn=true]

Mom came home and the days returned as if nothing had happened.
[cpg]

I know what's happening behind closed doors. I know it's all a lie. I'm losing my senses.
[cpg]

If this is what a happy family looks like, why not leave it alone? Sometimes, a lie is preferable to the truth.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

Nanako and I commute to school together until the halfway point. Nanako acts normal.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Nanako033"]
[OnName num="nanako"]
How have things been going with Chiho since then? I want you two to be happy.
[cpg cn=true]

[OnName num="keita"]
……
[cpg cn=true]

A normal topic. But it's not what the person who came on to me and even kissed me would say.
[cpg]

[OnName num="keita"]
Does that mean you don't care anymore ……?
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]

I took a step forward. Nanako nodded in agreement.
[cpg]

......The situation makes me want to cry. What am I supposed to do?
[cpg]

I want to help Nanako, but I'm also ready to give up. Nanako should want me to help her. But she looks like she's given up.
[cpg]

Things couldn't stay like this, but I didn't know what to do. What could I do?
[cpg]

Where did I go wrong? Am I still making mistakes?
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//移植のためシーンをカットしています

I can't stay at home anymore.
[cpg]

I knew it would hurt Nanako, but the stress outweighed it.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

......Where should I go? Where could I stay?
[cpg]

[OnName num="keita"]
Who would shelter me as I am now?
[cpg cn=true]

Shelter. I wasn't sure where the words had come from, but it was precisely what I wanted at the moment.
[cpg]

I'm not at the stage where I need someone to comfort me or listen to my problems. I need to get out of that house.
[cpg]

Unlike the other two who had slowly been breaking down, I'd had my entire world shattered overnight. I can't stay in that place.
[cpg]

[OnName num="keita"]
...... Takafumi, Takafumi would ……
[cpg cn=true]

Takafumi would shelter me. I don't want him to comfort me or listen to my problems.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[OnName num="takafumi"]
What's going on, man? Do you know how late it-.........Are you doing alright?
[cpg cn=true]

I must have looked awful.
[cpg]

[OnName num="keita"]
I thought about going to Chiho's place, but she's a girl so I don't think I could stay the night.
[cpg cn=true]

[OnName num="takafumi"]
Hold up man, I think you're skipping the part where you explain what's going on.
[cpg cn=true]



[window target=false]
[transition target={true} rule="kosuri5.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kosuri5.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="kosuri5.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_15_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kosuri5.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『隆文の部屋』（夕方）******************************************************

[OnName num="takafumi"]
......That's rough.
[cpg cn=true]
[OnName num="keita"]
And I didn't notice a thing.
[cpg cn=true]

[OnName num="takafumi"]
...... Are you okay, Keita? I mean, I guess you're not.
[cpg cn=true]

[OnName num="takafumi"]
But it's probably hardest for your sister. She's still stuck at home, right?
[cpg cn=true]

[OnName num="keita"]
Yes.
[cpg cn=true]

[OnName num="takafumi"]
Stop playing it cool. If you break down, there's going to be nobody left to fix things.
[cpg cn=true]

Am I going crazy? I thought I'd already passed that point.
[cpg]

[OnName num="takafumi"]
Look, it doesn't have to be right now. But you really should be at home.
[cpg cn=true]

[OnName num="takafumi"]
You can't leave your sister alone. If what you're saying is true, you're probably the only one she has for emotional support.
[cpg cn=true]

[OnName num="keita"]
....... I don't want to be in that house.
[cpg cn=true]

[OnName num="takafumi"]
Then I won't even try to stop you. It all depends on whether you still want to save your sister.
[cpg cn=true]

I don't know what to do......I was struggling to keep myself sane and listen to what Takafumi had to say.
[cpg]

[OnName num="takafumi"]
I think the best thing to do is to talk to your mother. I mean, that's the only way.
[cpg cn=true]

[OnName num="keita"]
….. Nanako doesn't want her mother to know.
[cpg cn=true]

[OnName num="takafumi"]
That's part of the reason you have to talk to her about it. She's an adult, she should be able to handle it.
[cpg cn=true]

[OnName num="takafumi"]
Maybe your sister won't even notice it and your father will back off. That would be the best case scenario.
[cpg cn=true]

He was right ...... For the life of me, though, I can't find the courage to do it.
[cpg]

But I'll do it. It was coming from Takafumi, who was still sane. I trusted him.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_16_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


I stayed at Takafumi's house that day. Even if I went home right now, my mom wouldn't be there.
[cpg]

But tomorrow, I will tell ...... my mother everything. There is no other way to help Nanako.
[cpg]



[window target=false]
[BG f="b_16_4.ui" time=1500]
[WAIT time=3000]
[BG f="b_16_1.ui" time=1500]
[WAIT time=3000]

[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]

;//【ＢＧ】『恵太の家・リビング』（朝）******************************************************

Before going to school, I went back home to get my stuff in the morning. Mom was there.
[cpg]

[OnName num="keita's_mother"]
Oh, welcome home. I was worried. I heard you stayed at a friend's house.
[cpg cn=true]

[OnName num="keita"]
Yes, I did. Why are you home at this hour? Don't you have to be working?
[cpg cn=true]

[OnName num="keita's_mother"]
What are you talking about? It's my day off. I'm not working.
[cpg cn=true]

[OnName num="keita"]
Oh, right……
[cpg cn=true]

I had already lost track of the days of the week. So, that means dad and Nanako are up to something again.
[cpg]

No, don't get distracted by that. I have to tell mom everything to prevent that from happening in the future.
[cpg]

[OnName num="keita"]
Mom, I need to talk to you. Can I talk to you for a second?
[cpg cn=true]

[OnName num="keita's_mother"]
Sure, what is it?
[cpg cn=true]



;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


I told her everything. I told her everything about Nanako and my father's relationship.
[cpg]

The content was the same as what I had told Takafumi. But my mother's reaction was quite different.
[cpg]

Takafumi's face was getting darker and darker, but my mother looked kind of worried about me.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（朝）******************************************************


[OnName num="keita's_mother"]
Oh .......
[cpg cn=true]

Silence. I had nothing more to say to her, but she doesn't reply.
[cpg]

[OnName num="keita"]
So. What do I do, what should we do?
[cpg cn=true]

[OnName num="keita's_mother"]
I'm sorry.
[cpg cn=true]

She just smiled. The look on her face almost sent a chill down my spine. No way, maybe ......
[cpg]


[OnName num="keita's_mother"]
You know, I knew about it ...... from a long time ago.
[cpg cn=true]

[OnName num="keita"]
You're, you're lying .......
[cpg cn=true]

It's a lie, it's a lie, it's a lie. ...... What the hell is this? Then it was really just me. I'm the only one who didn't know.
[cpg]

[OnName num="keita"]
I'm going to tell Nanako ...... that you know about this.
[cpg cn=true]

[OnName num="keita's_mother"]
Why?
[cpg cn=true]

[OnName num="keita"]
Nanako was afraid you and dad would fight. ...... You should have told her earlier.
[cpg cn=true]

[OnName num="keita's_mother"]
That's a strange thing to say. I disagree.
[cpg cn=true]

[OnName num="keita"]
You mean to tell me that you're going to pretend you don't know about it, too ……!
[cpg cn=true]

[OnName num="keita's_mother"]
Junichi's mood is a lot better after he...spends time with Nanako. This family needs to keep up appearances.
[cpg cn=true]

[OnName num="keita's_mother"]
I am grateful to Nanako. Still, if you want to tell Nanako the truth, then ……
[cpg cn=true]

[OnName num="keita's_mother"]
Junichi's stress will build up again and he might get into a big fight with me. I'm sure Nanako will be saddened by that.
[cpg cn=true]

This is crazy. No, it's always been crazy. I didn't see a way out.
[cpg]

Nanako wants a happy family. If Nanako doesn't keep Dad happy, everything's going to come down around us.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="mozaiku.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mozaiku.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


What kind of fights did they have before things got this complicated? Why didn't I notice it?
[cpg]

Nanako wanted a happy family. She's doing all of this to keep it that way. This is crazy, it should be ......
[cpg]


I can't do this anymore. When I graduate from school, I'll leave this house and go live far, far away......
[cpg]

I'm leaving this place.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・リビング』（朝）******************************************************

[OnName num="keita"]
...... Hey, Nanako. Do you still see me as a hero?
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Nanako034"]
[OnName num="nanako"]
...... Of course I do. Please, please stay with me forever.
[cpg cn=true]


[SCENE id=14]

[jump storage="epend.ks" target="*start"]
;//【奈々子ルート】エンド
