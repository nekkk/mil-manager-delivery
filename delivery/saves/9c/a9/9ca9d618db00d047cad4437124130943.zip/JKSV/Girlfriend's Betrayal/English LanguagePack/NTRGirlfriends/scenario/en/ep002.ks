
*start|


;#################################################
*Ep002|Adult Attraction
;#################################################

[SCENE id=2]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

;//背景再び表示


As I approached my house, I saw my mother and someone else ……
[cpg]

It was Yōko. She was strikingly beautiful and rather well-known for it in the neighborhood.
[cpg]

[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="4/5" time=800]

[OnName num="keita"]
I'm home.
[cpg cn=true]

[OnName num="keita's_mother"]
Oh, you're back. You're home early today.
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Youko001"]
[OnName num="youko"]
Hi, Keita.
[cpg cn=true]

[OnName num="keita"]
Hello.
[cpg cn=true]

It wasn't just our little neighborhood. No matter where she went, her looks would turn heads.
[cpg]

I'd heard she'd been scouted by a talent agency when she was younger. She is so dazzlingly beautiful that I think she could still make it as a model.
[cpg]

She was standing in front of my house, talking with my mother about something.
[cpg]

[OnName num="keita"]
What were you two talking about?
[cpg cn=true]

[OnName num="keita's_mother"]
It's just about you Keita. I hear you're not sure about your career path?
[cpg cn=true]

[OnName num="keita"]
Did you hear that from Ms. Yōko?
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]
[VOICE f="Youko002"]
[OnName num="youko"]
I'm sorry, were you keeping it a secret from your mother? You mentioned it the other day.
[cpg cn=true]

Oh, yeah. I was surprised because it's not like I was worrying or anything......I just felt like things would fall into place like they usually did.
[cpg]

[OnName num="keita"]
Right, uhh...yeah, it was bothering me a little bit.
[cpg cn=true]

I had no real worries, but I had made up some problems because I wanted an excuse to talk to Yōko. I had forgotten all about it.
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Youko003"]
[OnName num="youko"]
So, have you decided on a career path?
[cpg cn=true]

[OnName num="keita"]
Yes, I have. Thanks to you Ms. Yōko, I've made up my mind.
[cpg cn=true]

At this point I was quite casual with her. We often talk about our problems, but we also make small talk whenever we bump into each other.
[cpg]

Of course, I did all of this in an attempt to try to get closer to her. I'm always hoping to see if these steady efforts will somehow bear fruit.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Youko004"]
[OnName num="youko"]
I'm glad I could be of help.
[cpg cn=true]

[OnName num="keita's_mother"]
If you have any questions about your future, feel free to talk to me. If you want to go on to higher education, you'll need to talk to someone.
[cpg cn=true]

[OnName num="keita"]
I'm sorry, you're right……
[cpg cn=true]

I don't want people to ask me where I want to go to school. The truth is, I haven't decided on anything.
[cpg]

In fact, I haven't even decided if I'm going to go on to higher education or not. I just didn't really want to work, so I figured I'd go to school ......
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Youko005"]
[OnName num="youko"]
Oh, by the way, how is your cold?
[cpg cn=true]

[OnName num="keita"]
Oh ….. umm I'm already feeling pretty good.
[cpg cn=true]

I remember Takafumi was worried about me. Not only was he worried, but he also copied his notes for me.
[cpg]

I feel bad for Takafumi, but I'm much happier when Yōko worries about me. Some friend I was.
[cpg]

[OnName num="keita"]
I always feel weak during the change of seasons ….. sorry to worry you.
[cpg cn=true]


[FACE method="change_2" pos="4/5"]
[VOICE f="Youko006"]
[OnName num="youko"]
Nanako was worried about you too. She's a good younger sister.
[cpg cn=true]

[OnName num="keita"]
Nanako?
[cpg cn=true]

It wasn't surprising to hear that they were in contact. It was surprising to hear that Nanako was worried about me, though.
[cpg]

[OnName num="keita's_mother"]
I remember Nanako seemed angry when I saw her last. Do you know anything about that?"
[cpg cn=true]

[OnName num="keita"]
No, I'm not sure...
[cpg cn=true]

Nanako is my younger sister. To be precise, she is my current mother's child.
[cpg]

My parents remarried, so we're not blood related ......
[cpg]

But I don't think I'd ever seen her angry, even if we didn't get along.
[cpg]

I walked into the house, wondering what it was all about.
[cpg]


[jump storage="ep003.ks" target="*start"]


;////////////////////////////////////////////////////////////////////////

