
;//４、好きな人は秘密

*start|The Mature Charm of Yōko

;#################################################
*Ep008|The Mature Charm of Yōko
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_02_a.ui" method="change_1"  pos="2/5" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（夜）******************************************************


*Route04|The Mature Charm of Yōko

[SCENE id=8]

[OnName num="keita"]
......It's a secret.
[cpg cn=true]

[OnName num="junichi"]
Huh? Well that sounds like a load of bull.
[cpg cn=true]

[OnName num="keita"]
No, it's just a secret.
[cpg cn=true]

[OnName num="keita's_mother"]
I'm curious. What's she like? Is she younger or much older?
[cpg cn=true]

Mom lands close to the truth. The ladies in our family are quite perceptive.
[cpg]

I guess I'm just easy to read if two out of three of them seem to be able to figure it out.
[cpg]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Nanako012"]
[OnName num="nanako"]
Why are you so coy? Do you want to keep it a secret so badly?
[cpg cn=true]

[OnName num="keita"]
Well ….
[cpg cn=true]

I can imagine the consequences if I told them that I am in love with a divorced woman.
[cpg]

I can't even tell my family, this has to be my secret.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]
;//ＢＫ

Of course, the more you try to hide a secret, the more it stands out without fading.
[cpg]


[window target=false]
[transition target={true} rule="hikari.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hikari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

Each time I walk to school in the morning, I pass by the apartment where Yōko lives, hoping to catch a glimpse of her.
[cpg]

By not talking about it, my feelings were getting stronger day by day.
[cpg]

I am confident enough that I won't change my mind no matter who opposes me, but I dare not discuss it with anyone.
[cpg]

I know that people will judge me. I didn't want this pure feeling to be ridiculed.
[cpg]

Of course, Yōko had a husband. When I think about that ......
[cpg]

[OnName num="keita"]
.....Sigh
[cpg cn=true]

It makes my heart ache. If she marries someone else again, what would I do with these feelings?
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・教室』（昼）******************************************************


I have to make a decision. What society thinks shouldn't matter to us.
[cpg]

I was inspired by seeing other student couples flirting with each other during the lunch break at the school, and I felt strongly that the age difference didn't matter to me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chiho208"]
[OnName num="chiho"]
...... Keita.
[cpg cn=true]

[OnName num="keita"]
Hey, Chiho ...... What's up?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Chiho209"]
[OnName num="chiho"]
No, it's not like I have anything special to say. It's just…
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Chiho210"]
[OnName num="chiho"]
You look more grim than usual, so ...... You just look like you made a decision.
[cpg cn=true]

[OnName num="keita"]
Well, you're probably right.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Chiho211"]
[OnName num="chiho"]
.......?
[cpg cn=true]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

On the way home, I bumped into Yōko. She had a grocery bag in her hand, I guess she was on her way back from shopping.
[cpg]

[OnName num="keita"]
Hi. Good evening.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Youko011"]
[OnName num="youko"]
Yes, good evening. What's the matter, you seem so nervous.
[cpg cn=true]

I spoke to her which was bold of me. I always could talk to her naturally, but today I had to be bold to talk to her.
[cpg]

The only thing different than usual is me, and Yōko gave me a soft smile.
[cpg]

[OnName num="keita"]
So ......were you out shopping?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Youko012"]
[OnName num="youko"]
Yes, I was. What about it?
[cpg cn=true]

[OnName num="keita"]
You work ...... and do housework too, don't you? It must be hard.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Youko013"]
[OnName num="youko"]
Well, I only work part-time. But thank you for your concern.
[cpg cn=true]

[OnName num="keita"]
I wonder if there is anything I can do to help ……
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Youko014"]
[OnName num="youko"]
Just saying hello like this is good enough for me.
[cpg cn=true]

No. This is not the way to say it. I have to go further.
[cpg]

[OnName num="keita"]
I guess, I don't know if I'm the right ...... person to talk to.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Youko015"]
[OnName num="youko"]
If you're offering, perhaps I'll take you up on that offer sometime.
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="hiraki.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hiraki.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

It's hard. It is more difficult for me to take the first step with her than girls my own age.
[cpg]

Would a kid like me say "I love you" to a divorced woman in front of her apartment? But, I have to say it.
[cpg]

She would probably think that I am joking, but I can't give up. I could have taken the first step.
[cpg]

I cannot succeed overnight. I have to do it slowly and deliberately ……
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]

From that day, my struggle with my confidence began. A few days passed with nothing to show for it.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

[FACE method="bow_1" pos="2/3"]
[VOICE f="Youko016"]
[OnName num="youko"]
Welcome back, Keita.
[cpg cn=true]

[OnName num="keita"]
...... Good evening, Ms. Yōko.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Youko017"]
[OnName num="youko"]
Oh my, your eyes are serious again.
[cpg cn=true]

She couldn't help but say, "Oh" when I grabbed her hand.
[cpg]

[OnName num="keita"]
I've always loved you, Ms. Yōko.
[cpg cn=true]

Slowly but surely. That was definitely true, and as a result I'm saying these things to her.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Youko018"]
[OnName num="youko"]
Really? Thank you. You're too good for this old lady.
[cpg cn=true]

[OnName num="keita"]
...... I mean it.
[cpg cn=true]

I wonder how many times I've told her, but she dodges me every time.
[cpg]

I wonder if this effort will really bear fruit someday? I've confessed to her so many times that I'm starting to doubt myself.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

I'm not giving up yet. I'm not going to give up yet. I'm going to say that I like Yōko as much as I can and in every way that I can.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

[OnName num="keita"]
Good morning, Yōko.
[cpg cn=true]


[FG f="CHA04_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Youko019"]
[OnName num="youko"]
Good morning. I suppose you're going to confess your feelings for me again today?
[cpg cn=true]

She beat me to it. But I'm not giving up. I'm thinking of a different approach today.
[cpg]

[OnName num="keita"]
You live in this apartment, don't you?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Youko020"]
[OnName num="youko"]
Yes, I do. Why don't you come visit me?
[cpg cn=true]

[OnName num="keita"]
...... What?
[cpg cn=true]

She keeps moving ahead of me. I mean, what is this? Is she the one who's asking me out?
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Youko021"]
[OnName num="youko"]
It's difficult to keep saying no when you keep coming back, day after day.
[cpg cn=true]

[OnName num="keita"]
Then...
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Youko022"]
[OnName num="youko"]
But you have to go to school. You'll be late.
[cpg cn=true]

[OnName num="keita"]
Yes! I'm off then!
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

I don't remember exactly what happened at school. The usual classes, the usual breaks have disappeared from my memory.
[cpg]

I was so focused on the fact that Yōko had invited me to her place today.
[cpg]


[OnName num="keita"]
I swallow.
[cpg cn=true]

[SE f="se006"]
;//【ＳＥ】『玄関のチャイム』ピンポーン
[WAIT time=1000]

I rang the doorbell at the apartment door and waited for a while.
[cpg]

[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

[OnName num="keita"]
Good evening ……
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Youko023"]
[OnName num="youko"]
Yes, good evening. 
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="hiraki.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_14_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hiraki.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『葉子の部屋』（夕方）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Youko024"]
[OnName num="youko"]
What did you tell your family? Did you tell them you were going to visit someone you like?
[cpg cn=true]

[OnName num="keita"]
I told them I was going to ...... to visit a friend.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Youko025"]
[OnName num="youko"]
So, I'm your friend then.
[cpg cn=true]

She laughs at me. It's a funny situation.
[cpg]

I tell my family that it's a friend's house and pretty far away. In reality, I'm in the same neighborhood at Yōko's place.
[cpg]

In front of me is a small desk. Across it there is Yōko facing me …… and on the desk, there are dishes prepared by her.
[cpg]

Dinner is over before I know it. I put my hands together and thank her for the food.
[cpg]

[OnName num="keita"]
It was so, so delicious ...... You're a terrific cook, Yōko.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Youko026"]
[OnName num="youko"]
Thank you. Keita, you're so cute.
[cpg cn=true]

Saying so, Yōko pats my head ...... This is not good. She still treats me like a child.
[cpg]
[BGM f="bg_tl"]
[OnName num="keita"]
I'm serious. I really like you.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Youko027"]
[OnName num="youko"]
Yes, yes. You've said it that way a few times now.
[cpg cn=true]

[OnName num="keita"]
I really mean it!
[cpg cn=true]

I said it in a tone not so much as to raise my voice, but a little loud. Not so as to startle Yōko, but to let her know how I feel.
[cpg]

[OnName num="keita"]
It's not just a longing, I'll make you happy.
[cpg cn=true]

[OnName num="keita"]
You're not just my ideal woman, but you're someone who I want to love. So, umm ……
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Youko028"]
[OnName num="youko"]
...... It's fine. I already know that.
[cpg cn=true]

[OnName num="keita"]
What does that mean ......?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Youko029"]
[OnName num="youko"]
I already know that you like me. I invited you today to give you a response.
[cpg cn=true]

...... I can't rush. But I can't back down either. What should I say? Umm.
[cpg]

[OnName num="keita"]
Well, then, kiss me.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Youko030"]
[OnName num="youko"]
Okay. Don't move.
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

That sounded like I was in a hurry, I thought. But my words were answered with a kiss.
[cpg]

[OnName num="keita"]
.......
[cpg cn=true]

[free time=1000]
[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_14_3.ui" time=1000]
[WAIT time=2000]


[VOICE f="Youko031"]
[OnName num="youko"]
You're blushing. You were the one who asked me to kiss you., she chuckled.
[cpg cn=true]

Did she actually like me more than I thought?
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『葉子の部屋』（夜）******************************************************

The dishes have been put away and it's nighttime. I had to go home, but I felt like it wasn't the right timing.
[cpg]

I could go further, I thought. If there was a chance, I knew I couldn't pass it up.
[cpg]


[FG f="CHA04_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Youko032"]
[OnName num="youko"]
Oh, I didn't know that happened.
[cpg cn=true]

[OnName num="keita"]
Yes. Chiho is very nosy ……
[cpg cn=true]

We're about to run out of other small talk. Every now and then there would be a silence, and when it lasted long enough, I started talking again.
[cpg]

[OnName num="keita"]
When you kissed me just now. Was that a joke?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Youko033"]
[OnName num="youko"]
Why do you ask that? Did you tell me you like me as a joke?
[cpg cn=true]

[OnName num="keita"]
No, I didn't! It's not that, because I really like you ……
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Youko034"]
[OnName num="youko"]
Thank you. You did say that I am not just a woman you admire.
[cpg cn=true]

Yōko smiles. Then, with a slightly serious look on her face, she continues.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Youko035"]
[OnName num="youko"]
I was a married woman, you know. Knowing that, will you still love me?
[cpg cn=true]

For a moment, I had trouble understanding the meaning of those words. But ......
[cpg]

This means that she might choose me. In that case, I had no choice but to accept.
[cpg]


;//●ＣＧエロ（葉子・主人公を待つヒロイン。もう一度キスをする：葉子家、寝室）ev_34
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Youko036"]
[OnName num="youko"]
I never dreamed that at my age this would happen ......
[cpg cn=true]


Her words seemed too good to be true.
[cpg]

[VOICE f="Youko037"]
[OnName num="youko"]
Keita, will you kiss me?
[cpg cn=true]


Who was I to refuse? I approached her.
[cpg]

I couldn't believe that such a happiness existed.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

The morning of the day after that. On my way to the school, Yōko came up to me.
[cpg]


[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Youko038"]
[OnName num="youko"]
Good morning, Keita. I have a little present for you today.
[cpg cn=true]

She put something in my hand. I opened my hand and looked at it ……. Was it …….
[cpg]

[OnName num="keita"]
......What's this?
[cpg cn=true]

It's a key. I know that, but I have to ask. Was this what I thought it was?
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Youko039"]
[OnName num="youko"]
It's a duplicate key. Come back anytime.
[cpg cn=true]

[OnName num="keita"]
......!
[cpg cn=true]

I think I blushed up to my ears as she told me this.
[cpg]



[window target=false]
[transition target={true} rule="kosuri5.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kosuri5.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

Such days continued like a dream. Since Yōko gave me a key, we don't have the kind of relationship where we talk only when we accidentally see each other.
[cpg]

It's a relationship where I can talk to her whenever I want to. So, whenever I had free time, I would go to Yōko's place.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_14_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『葉子の部屋』（夕方）******************************************************

[OnName num="keita"]
Good evening, Ms. Yōko.
[cpg cn=true]


[FG f="CHA04_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Youko040"]
[OnName num="youko"]
Are you okay with coming here so often?
[cpg cn=true]

[OnName num="keita"]
Don't worry, I told my family that I'm going to visit a friend.
[cpg cn=true]

[OnName num="keita"]
If it's possible, I'd like to take you out on a date but ……
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Youko041"]
[OnName num="youko"]
Oh my.
[cpg cn=true]

Yōko giggles.
[cpg]

I felt like she still sees me as a kid. But at the same time, she sees me as her lover since I could see her face was slightly flushed.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Youko042"]
[OnName num="youko"]
Thank you. What were you going to say after the but" ...... Is something bothering you?"
[cpg cn=true]

[OnName num="keita"]
I don't know how I would explain it to my family and the others if they saw ...... us.
[cpg cn=true]

This time, Yōko looks a bit angry. It's more like the face of someone scolding a child.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Youko043"]
[OnName num="youko"]
Don't, Keita. That's not something you say to your girlfriend.
[cpg cn=true]

[OnName num="keita"]
You're right. I should explain to my family that you're my girlfriend, right?
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Youko044"]
[OnName num="youko"]
Yes. I'm treating you like ...... a lover, so I expect the same from you.
[cpg cn=true]

[OnName num="keita"]
.......
[cpg cn=true]

I realized once again that Yōko was incredibly sexy. When she says something like this, I can't say no. There is something about her that makes me feel that way.
[cpg]

[OnName num="keita"]
I understand. Then let's go out on a date this weekend.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Youko045"]
[OnName num="youko"]
Alright.
[cpg cn=true]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[BGM f="bg_d1"]
[WAIT time=100]

The day of our date. She was the first one to arrive. I jogged towards Yōko.
[cpg]

[OnName num="keita"]
I'm sorry. Did I make you wait?
[cpg cn=true]


[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Youko046"]
[OnName num="youko"]
No, I just arrived.
[cpg cn=true]

It's fun to have this kind of conversation like normal lovers. I wonder how other people see us as we are laughing like this.
[cpg]

[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[FG f="CHA03_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Yuuri142"]
[OnName num="yuuri"]
Oh.
[cpg cn=true]

[OnName num="keita"]
Oh.
[cpg cn=true]

[free time=500]
[FG f="CHA03_p1_02_a.ui" method="change_5"  pos="2/5" time=800]
[FG f="CHA04_p2_01_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Youko047"]
[OnName num="youko"]
……? What's wrong, Keita?
[cpg cn=true]

Yōko is my girlfriend, and I don't feel guilty about it.
[cpg]

But I didn't want my family or anyone I know to see us.
[cpg]

If Chiho sees us, she will be a bit surprised. Haruka might just giggle.
[cpg]

But I was thinking that Yuri, who worships me, would be shocked the most.
[cpg]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Yuuri143"]
[OnName num="yuuri"]
What are you doing, Keita ……?
[cpg cn=true]

I'm dating someone years older than me, and she might tell the whole school about it ……
[cpg]

Or they might be extremely jealous. I was prepared for that.
[cpg]


[FACE method="shock_3" pos="2/5"]
[VOICE f="Yuuri144"]
[OnName num="yuuri"]
Are you so in love with your mother that you would hold hands with her?
[cpg cn=true]

[OnName num="keita"]
Huh?
[cpg cn=true]

Ah …… yes, it does seem that way. It's kind of a relief and a disappointment at the same time.
[cpg]


[FACE method="shake_4" pos="2/5"]
[VOICE f="Yuuri145"]
[OnName num="yuuri"]
Wow, how can I ...... I guess I have to accept you as someone who has mommy issues.
[cpg cn=true]

[OnName num="keita"]
I'm in a hurry. See you later.
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//背景再び表示


[FACE method="change_1" pos="2/3"]
[VOICE f="Youko048"]
[OnName num="youko"]
Is she a student at your school? A kōhai perhaps?
[cpg cn=true]

[OnName num="keita"]
...... Yes.
[cpg cn=true]

I was momentarily relieved when she mistook her for my mother. I guess she didn't look like my girlfriend to those around me.
[cpg]

[OnName num="keita"]
I might not a good match for you Ms. Yōko.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Youko049"]
[OnName num="youko"]
It's a little early to give up, Keita.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Youko050"]
[OnName num="youko"]
If you think you're not a good match for me, then become a man who will be.
[cpg cn=true]

She was right. All I have to do is become the kind of guy who seems like he can get the attention of older women.
[cpg]

[OnName num="keita"]
…… Yeah.
[cpg cn=true]

After our date, I was determined to improve myself.
[cpg]



[window target=false]
[transition target={true} rule="hiraki.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hiraki.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（昼）******************************************************

Yesterday was Saturday, so I had bought a barbell ...... or rather a dumbbell and was opening it.
[cpg]

[OnName num="keita"]
Wow, these ...... are heavy.
[cpg cn=true]

It didn't feel that heavy when I was carrying it. It just felt like a little extra luggage. It felt heavier and heavier as I repeated a lifting exercise.
[cpg]

[OnName num="keita"]
Huh …… Phew.
[cpg cn=true]

I'd started weight training, but I wondered if this kind of thing would help me polish myself as a man.
[cpg]

What is manliness, anyway? How can one become a man who can match up to older women? No matter how much I try, a child may just be a child.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


With this in mind, I began to pay attention to my appearance and fashion, and as I tried various things, I was told something that made me a little happy.
[cpg]

It was from someone other than Yōko.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・教室』（昼）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chiho212"]
[OnName num="chiho"]
I feel like you're getting more confident these days, Keita.
[cpg cn=true]

[OnName num="keita"]
What?
[cpg cn=true]

The effort had borne fruit in an unexpected way. Or rather this was one of the results.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Chiho213"]
[OnName num="chiho"]
We're the same age, but somehow you feel more like an adult. Just a little while ago, you seemed younger than me ……
[cpg cn=true]

[OnName num="keita"]
...... Do you think so?
[cpg cn=true]

I haven't actually gained any muscle. I haven't done any muscle training lately and my dumbbell was more of an ornament at this point.
[cpg]

But I guess it's the fact that I'm dating Yōko, an adult woman. I seemed to have attained a confident personality.
[cpg]

Or maybe it's just because I'm spending my days happily. When you're happy, you naturally become more confident.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_14_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『葉子の部屋』（夕方）******************************************************

[FACE method="shake_1" pos="2/3"]
[VOICE f="Youko051"]
[OnName num="youko"]
Oh. You're here again?
[cpg cn=true]

Lately, I've been going to Yōko's more often than just going to a friend's house.
[cpg]

My family is getting suspicious of me, so I'll have to tell them the truth sooner or later ......
[cpg]

[OnName num="keita"]
Umm, yeah …… Is it annoying?
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Youko052"]
[OnName num="youko"]
It's not annoying. I feel like I'm wanted.
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_14_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[OnName num="keita"]
I'm getting muscular these days, aren't I?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Youko053"]
[OnName num="youko"]
Yeah. You look cool.
[cpg cn=true]


[OnName num="keita"]
I'm not just cool. If you're tired, I can give you a massage.
[cpg cn=true]


I just let my mouth do the talking. Then ......
[cpg]

;//●ＣＧエロ（葉子・主人公に背中を向けるヒロイン。マッサージをする主人公：葉子家、寝室）ev_35
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

She ended up accepting it.
[cpg]

I was getting nervous because I thought she was just going to ignore it.
[cpg]

[VOICE f="Youko054"]
[OnName num="youko"]
What's wrong? You won't do it?
[cpg cn=true]


[OnName num="keita"]
Uh, no. I'm fine.
[cpg cn=true]


I thought it was strange to reply, "I'm fine." ......
[cpg]

I decided to give her a massage.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="kosuri5.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kosuri5.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『葉子の部屋』（夜）******************************************************

Then, after a while …… she and I talked about trivial topics.
[cpg]

[OnName num="keita"]
I've never felt so happy.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Youko055"]
[OnName num="youko"]
Thank you. I get nervous when you look at me like that.
[cpg cn=true]

[OnName num="keita"]
But I really feel like I'm learning all the fun stuff from you.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Youko056"]
[OnName num="youko"]
Yes, I'd be happy to teach you all sorts of things.
[cpg cn=true]

I feel excited and happy when I am with Yōko.
[cpg]

The age difference between the two of us will never be bridged even if we continue to be lovers. That is a given.
[cpg]

But just as the age gap will never be closed, I feel as if this happiness will last forever. I felt as if I could always follow her wherever she goes.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_du"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・恵太の部屋』（昼）******************************************************

[FACE method="shake_7" pos="2/3"]
[VOICE f="Nanako013"]
[OnName num="nanako"]
So, where are you really going, brother? I know you're not at your friend's house all the time.
[cpg cn=true]

[OnName num="keita"]
......What's this all of a sudden?
[cpg cn=true]

Nanako entered my room without knocking. She looked even gloomier than usual.
[cpg]

[OnName num="keita"]
You're asking me if I'm seeing a girlfriend or something?
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Nanako014"]
[OnName num="nanako"]
Yes. Father and mother are worried about you.
[cpg cn=true]

[OnName num="keita"]
Oh, really?
[cpg cn=true]

What unkind parents. If they thought I had found a girlfriend, they should have just congratulated me.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Nanako015"]
[OnName num="nanako"]
It's easy to imagine you getting too involved, too quickly. I'm concerned about your character.
[cpg cn=true]

[OnName num="keita"]
......That seems kind of mean.
[cpg cn=true]

Basically, she's worried about me coming home late.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Nanako016"]
[OnName num="nanako"]
I don't know what kind of person you're dating, but love can make people go crazy.
[cpg cn=true]

The way she said it was strangely persuasive. It sounded as if he was speaking from actual experience ......
[cpg]

[OnName num="keita"]
I'll be fine. You're such a worrier.
[cpg cn=true]

I'm sure Yōko is crazy about me too. If we are crazy about each other, I think it's okay to stay like this a little longer.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_16_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

I wonder when I'll visit Yōko again. I'm looking forward to it ......
[cpg]



;//葉子に視点切り替わり
;//[ChangeWindow num="1"]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『葉子の部屋』（夜）******************************************************


When will he come? I had been looking forward to it.
[cpg]

Since my divorce, the days were as dry as a dessert. No matter what I did, I could not satisfy that thirst.
[cpg]

I always knew that the boy named Keita was looking at me with adoration ...... and not just adoration.
[cpg]

The way men look at you doesn't change much, whether they're a child or an adult.
[cpg]

I had become attached to the young and hungry look in his eyes. It had been a long time since I had felt that.
[cpg]

So I thought it was fate that Keita came on to me.
[cpg]

Of course I seriously consider him as my boyfriend, and he is genuinely in love me.
[cpg]

[SE f="se006"]
;//【ＳＥ】『玄関のチャイム』ピンポーン
[WAIT time=1000]

Even the sound of the doorbell sounded like a symbol for ...... Keita.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="slant1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="slant1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//背景再び表示

But today's visitor was not Keita.
[cpg]

[OnName num="kotaro"]
It's been a while. You look as beautiful as ever.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Youko057"]
[OnName num="youko"]
...... Kōtarō.
[cpg cn=true]

My, ex-husband...... It was a face I didn't want to see the most.
[cpg]

[OnName num="kotaro"]
It seems like the economy's bad no matter where I go. It's getting harder and harder to make ends meet.
[cpg cn=true]

That was the reason for our divorce. He was a leech......when it came to money or anything else.
[cpg]

I couldn't see his true nature until I married him. He almost made me become a night worker for money.
[cpg]

Of course I refused and we were divorced not long after. I didn't want to have anything to do with him anymore.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Youko058"]
[OnName num="youko"]
Please leave. There is already someone I love.
[cpg cn=true]

[OnName num="kotaro"]
Are you talking about Keita? I didn't peg you for the cradle-robbing type. No wonder you lost interest in me.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Youko059"]
[OnName num="youko"]
!
[cpg cn=true]

How did he know about Keita? Why would he want to know?
[cpg]

[OnName num="kotaro"]
I want money, you know. I think for Keita's sake, you should do what I tell you, right?
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Youko060"]
[OnName num="youko"]
What are you talking about ......?
[cpg cn=true]

[OnName num="kotaro"]
I don't mean to threaten you. But I don't want to see Keita suffer any misfortune either.
[cpg cn=true]

This was getting ridiculous. Would he go as far as to commit a crime?
[cpg]

Even the current situation is already strange. He has got nerve to ask his ex-wife for money after separating.
[cpg]


[FACE method="change_7" pos="2/3"]
[WAIT time=1000]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Youko061"]
[OnName num="youko"]
Fine......
[cpg cn=true]


;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


I was feeling various emotions all together.
[cpg]

For Keita's sake, I had to do what Kōtarō says.
[cpg]

I have a feeling that maybe Keita and I will never be together.
[cpg]



;//恵太に視点切り替わり
;//[ChangeWindow num="0"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

After school, I head to Yōko's place as quickly as I can.
[cpg]

It has become almost a daily routine for me. It's normal to want to see your girlfriend every day.
[cpg]

[SE f="se006"]
;//【ＳＥ】『玄関のチャイム』ピンポーン
[OnName num="keita"]
Ms. Yōko, I'm here!
[cpg cn=true]

I hear a slightly distant voice say, "Hold on a second". The tone of her voice sounded somewhat nervous, and I knew something was wrong.
[cpg]

;//●ＣＧエロ（葉子・玄関で扉を少しだけ開ける状態。後ろに元旦那がいる：葉子家、玄関）ev_36
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h3"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Youko062"]
[OnName num="youko"]
I'm sorry, I have some business to take care of right now.
[cpg cn=true]


Business? What could it be? Was it a phone call from someone?
[cpg]

[OnName num="keita"]
I understand. I'll come back later.
[cpg cn=true]


[VOICE f="Youko063"]
[OnName num="youko"]
Yeah, yeah. I'm really sorry.
[cpg cn=true]


She looked like she wasn't just in a hurry.
[cpg]

She looked like …… there was something she wanted to hide from me.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="kosuri5.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kosuri5.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（夕方）******************************************************

[OnName num="keita"]
I'm home. I went to my friend's house today, but she said she was busy with some urgent business or something.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Nanako017"]
[OnName num="nanako"]
Really. I thought it would take you longer to get back.
[cpg cn=true]

I slipped up. It seemed suspicious. I should have been tactful and said I'd called ahead.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Nanako018"]
[OnName num="nanako"]
I thought it might be Chiho, but apparently not. The person you are dating is probably Ms. Yōko, isn't it?
[cpg cn=true]

That was a little too accurate to be a guess. It was as if she had seen us together.
[cpg]

[OnName num="keita"]
It has nothing to do with you Nanako. Let me do whatever I want.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Nanako019"]
[OnName num="nanako"]
I won't interfere. But I saw a man visiting her apartment.
[cpg cn=true]

[OnName num="keita"]
What ……?
[cpg cn=true]



[window target=false]
[transition target={true} rule="giin1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="giin1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

I was shocked, but kept faith. Still, the seeds of doubt had been sown.
[cpg]

A man, at Yōko's place……? Was she seeing someone else on the side?
[cpg]

It couldn't be...... I knew it, Nanako was lying when she said she wouldn't interfere. She's trying to make me feel insecure.
[cpg]

It could be a delivery guy or something.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

Then the night passed. I saw Yōko on my way to school and called out to her.
[cpg]

[OnName num="keita"]
Good morning, Ms. Yōko.
[cpg cn=true]


[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Youko064"]
[OnName num="youko"]
Oh, good morning. You're going to school now, right?
[cpg cn=true]

She didn't seem any different. There was nothing to be worried about......
[cpg]

[OnName num="keita"]
Can I go to your place today?
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Youko065"]
[OnName num="youko"]
Yes, you can. We couldn't talk properly yesterday, right?
[cpg cn=true]

I think I was too concerned about the fact that her expression seemed to get dark for a moment.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

When I thought about Yōko, the boring classes would be over in a second.
[cpg]

Our happiness can no longer be stopped by anyone. Another guy had been at Yōko's place. So what?
[cpg]

Yōko told me that she likes me ......
[cpg]


[window target=false]
[transition target={true} rule="hiraki.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hiraki.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『葉子の部屋』（夜）******************************************************

[OnName num="keita"]
Sorry I'm late, Yōko.
[cpg cn=true]


[FG f="CHA04_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Youko066"]
[OnName num="youko"]
It's rather late...have you eaten dinner yet?
[cpg cn=true]

[OnName num="keita"]
My family complained that I was going out too much.
[cpg cn=true]

It was Nanako, mainly.
[cpg]

[OnName num="keita"]
So I snuck out …….
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Youko067"]
[OnName num="youko"]
You're going to worry your family even more though.
[cpg cn=true]

[OnName num="keita"]
Don't worry, they probably think I'm already asleep ……
[cpg cn=true]

I've changed my shoes. I've also turned off the lights in my room, so I'm probably fine.
[cpg]

;//移植のためシーンをカットしています

;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


……It wasn't often that Yōko invited me in.
[cpg]

Lately, it seemed that she was even more hesitant than usual to let me in.
[cpg]

[OnName num="keita"]
Hey,  Ms.Yōko …… you know, today is Sunday.
[cpg cn=true]


[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Youko068"]
[OnName num="youko"]
Yes, it is.
[cpg cn=true]

[OnName num="keita"]
I'm free you know.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Youko069"]
[OnName num="youko"]
I'm sorry ....... I have something to do.
[cpg cn=true]

It had gotten to the point that she'd refuse even if I tried to set things up in advance.
[cpg]

[OnName num="keita"]
Oh...alright then.
[cpg cn=true]

Was it because she was busy with work? Or maybe she had other things to do outside of her home. Probably not.
[cpg]

Because whenever I went to Yōko's place, she was still there, even if she didn't let me into her house.
[cpg]

That means that she might have other things to do while she is at home ...... or she might have sudden errands to run.
[cpg]

Nanako's words pass my mind. A man had entered her house.
[cpg]

[OnName num="keita"]
Hey, Ms. Yōko. Do you not like me anymore?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Youko070"]
[OnName num="youko"]
What's the matter, Keita? Having second thoughts?
[cpg cn=true]

[OnName num="keita"]
I'm asking you seriously. That's why I want you to answer me seriously.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Youko071"]
[OnName num="youko"]
You don't have to worry ....... I still love you. I really do.
[cpg cn=true]

The word "still" stuck out. Something is changing, and it's in a place I don't know about.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="amamori1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

I was getting anxious at home and at school.
[cpg]

There might be a man coming in and out of her room. There are only two ways to find out.
[cpg]

The first way is to keep an eye on Yōko's house at all times. That way, I would definitely be able to see if someone enters the house.
[cpg]

But as a student, I can't do that …… so I decided to take the other way.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
;//ＢＫ

Apartments usually have a main entrance. If she were in her room, I could open the front door without having to face her right away.
[cpg]

So, it's not impossible to sneak in. I could at least eavesdrop at her door.
[cpg]

I underestimated everything. I had not a clue what Yōko would think if I did that.
[cpg]




[OnName num="keita"]
…..Whose shoes are these?
[cpg cn=true]

Without telling Yōko, I opened the front door with a duplicate key. I found a pair of men's shoes. There was another man inside the room with her ……
[cpg]

That alone makes me so jealous that it makes my head spin.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

What I saw when I snuck in was Yōko with another man kissing her.
[cpg]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

I wander around the residential area outside, with no one there. I had no particular destination, but I couldn't stay home doing nothing.
[cpg]

[OnName num="keita"]
Aaaaaarrrgh!
[cpg cn=true]

I was breathing heavily in anger. My head hurt. The person she called Kōtarō must have wanted this situation.
[cpg]

Somehow, I had a feeling that this nightmare would repeat itself.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_16_4.ui" time=1500]
[WAIT time=3000]
[BG f="b_16_1.ui" time=1500]
[WAIT time=3000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

In the end, I did not sleep a wink that day. I walked around town and fell into bed, but I didn't get any rest.
[cpg]

[OnName num="keita"]
Good morning …… Ms. Yōko.
[cpg cn=true]


[FG f="CHA04_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Youko072"]
[OnName num="youko"]
Good morning. What's the matter, your face looks so worn out.
[cpg cn=true]

Yōko acts as if last night had never happened. I'm sure she's acting that way on purpose.
[cpg]

[OnName num="keita"]
I haven't been able to sleep since yesterday. I was thinking about you.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Youko073"]
[OnName num="youko"]
What?
[cpg cn=true]

[OnName num="keita"]
Hey, Ms. Yōko. What kind of a person was your ex-husband ……?
[cpg cn=true]

I'm dating a divorced woman, so having this level of anxiety is normal. So I don't think this question is unnatural.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Youko074"]
[OnName num="youko"]
Someday, we'll talk about it properly.
[cpg cn=true]

[OnName num="keita"]
When will that be? ...... I couldn't sleep because I was so anxious.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Youko075"]
[OnName num="youko"]
Then come by when you get back from school today.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Youko076"]
[OnName num="youko"]
I'll tell you everything. You're right. We are a couple.
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


The classes at the school felt like an eternity. What would Yōko say to me?
[cpg]

She might come up with some elaborate lie. She might tell me the truth. Either way, it was hard for me.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_14_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『葉子の部屋』（夕方）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Youko077"]
[OnName num="youko"]
My former husband's name is ...... Kōtarō.
[cpg cn=true]

[OnName num="keita"]
......Yes. I want to ask you about him.
[cpg cn=true]

There was no doubt in my mind. It was her ex-husband who was going in and out of her place. I couldn't believe that he was still in her life after the divorce ......
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Youko078"]
[OnName num="youko"]
He's a terrible person. He's the kind of person who only thinks about money.
[cpg cn=true]

The stories I heard about him were indeed terrible.
[cpg]

He forced his wife to work for him and after all this time, he was back and asking for more money.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Youko079"]
[OnName num="youko"]
I don't want to get back together with him. You are all I want.
[cpg cn=true]

[OnName num="keita"]
......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Youko080"]
[OnName num="youko"]
......
[cpg cn=true]

Then, suddenly, the words stopped. Is this the end of the story for her? There must be some things she still hasn't told me yet.
[cpg]

[OnName num="keita"]
I mean, there is nothing between us any more .......
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Youko081"]
[OnName num="youko"]
As in, you know ..…
[cpg cn=true]

She pivots and tries to save the situation. But she soon realizes that it is useless. She's right, you can't go back once you react like that.
[cpg]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Youko082"]
[OnName num="youko"]
You have very good instincts, Keita.
[cpg cn=true]


The despair of the truth I was confronted with and the hope that she would tell me the truth. The mixture of the two fills my heart.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Youko083"]
[OnName num="youko"]
But let me say it one more time. I love you.
[cpg cn=true]

[OnName num="keita"]
I see ......Yeah.
[cpg cn=true]

All I can do is nod. I'm on the verge of tears, but I hold it in. I can't run away from this fact.
[cpg]

If she says that I'm the only one for her, I'll have to tell her that she's the only one for me.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

Even if I force to convince myself, once the feelings start to grow, they will become uncontrollable.
[cpg]

I'm scared. What if he takes Yōko away from me? And I hate this Kōtarō person.
[cpg]

;//移植のためシーンをカットしています


It was living hell. I wanted him to go away and I hoped Yōko felt the same way.
[cpg]

I'm still not calm enough to think about it. I am sure that I still love Yōko.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

[OnName num="keita"]
...... Good evening, Ms. Yōko.
[cpg cn=true]


[FG f="CHA04_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Youko084"]
[OnName num="youko"]
Hi, come on in.
[cpg cn=true]

Yōko is acting as if nothing has happened. She's already told me that her ex-husband is still pressuring her.
[cpg]

But then again, doesn't she feel any guilt towards me? Doesn't she feel sorry for me? Is it all an act?
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Youko085"]
[OnName num="youko"]
...... Keita? What's wrong?
[cpg cn=true]

[OnName num="keita"]
Oh, umm. Nothing.
[cpg cn=true]

When I'm in front of Yōko, sometimes my mind goes blank.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_16_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//葉子さんの所に行く気にはならない。今更どんな気持ちで、彼女を抱けばいいのか分からない。
I don't feel like going to Yōko's place. I don't know how I should feel about seeing her now.
[cpg]

On the other hand, if I stay in my own house, I feel crushed by loneliness. Unable to sleep, I head to the park at night.
[cpg]

;//●ＣＧエロ（葉子・ヒロイン、元夫と偶然出会う主人公。コートは透けてない形にしてください：公園）ev_39
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h3"]
;**【ＣＧ】 ev_39_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="kotaro"]
Oh, is that you Keita?
[cpg cn=true]


I immediately recognized the person who called my name.
[cpg]

It was the same person I had seen on the day I had snuck into Yōko's apartment.
[cpg]

[VOICE f="Youko086"]
[OnName num="youko"]
……
[cpg cn=true]
She looked distressed. I probably did too.
[cpg]

I don't think he wanted to talk to me, but I guess he wanted to show me the difference between our positions.
[cpg]

I was already aware of it ......
[cpg]


;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

;//ＢＫ
;//恵太に視点切り替わり
;//[ChangeWindow num="0"]


[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************


I desperately tried to forget about Yōko. I have to forget about this.
[cpg]

When I'm alone in my room, I'm tormented by my thoughts. Were all those happy days just a dream? Was it all an illusion?
[cpg]

I tried to accept that. Yes, it was all an illusion. The Yōko I saw was not the real Yōko.
[cpg]

I have to forget this love ......
[cpg]

It was all a lie. She doesn't care about me, so I have to stop caring about her too.
[cpg]

Yōko......what was I to you? Were all those days a lie?
[cpg]

......I hate how weak I am. It's small wonder she'd get sick of me.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

It was hard to accept.
[cpg]

The next day, a morning on a weekend. I visited Yōko at a time when I thought he wouldn't be there.
[cpg]

[OnName num="keita"]
Ms. Yōko …… Ms. Yōko.
[cpg cn=true]

I can't give up. I don't want her to tell me that it's over yet ......!
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_14_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『葉子の部屋』（昼）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Youko087"]
[OnName num="youko"]
......
[cpg cn=true]

[OnName num="keita"]
Thanks for having me over …..
[cpg cn=true]

Yōko didn't talk much. She looked apologetic, but more than that, she seemed to want to ask why I was here again.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Youko088"]
[OnName num="youko"]
So, what can I do for you?
[cpg cn=true]

[OnName num="keita"]
Oh, I ……
[cpg cn=true]

I couldn't answer the question. In this case though, I had to answer the question.
[cpg]

[OnName num="keita"]
I still love you,  Ms.Yōko …… I just can't forget you.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Youko089"]
[OnName num="youko"]
I'm glad you're trying to forget me. Thank you.
[cpg cn=true]

No, don't say that! I don't want to forget you, Ms. Yōko, so please tell me you don't want to forget me either!
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Youko090"]
[OnName num="youko"]
;//「でも、ごめんなさい。やっぱり私、貴方とは一緒になれないわ」
I'm sorry. I can't be with you after all.!	“对不起。毕竟我不能和你在一起。
No! You told me you really love me!"
[cpg cn=true]

[OnName num="keita"]
I couldn't help but raise my voice. But Yōko looked tired. Naturally, I panicked.
[cpg cn=true]

(Was he the kind of guy who would be so idealistic? ……)
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Youko091"]
[OnName num="youko"]
Please, please, let me stay with you Ms. Yōko.
[cpg cn=true]

[OnName num="keita"]
I cling on to her as I try to get her attention.
[cpg cn=true]

There's nothing else I can do right now. I can't show her how manly I am at this point, and I never was in the first place ......
[cpg]

......Do you really want to be by my side?
[cpg]


;//●ＣＧエロ（葉子・哀れむような表情のヒロイン：葉子家、寝室）ev_41
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h3"]
;**【ＣＧ】 ev_41_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Youko092"]
[OnName num="youko"]
What?
[cpg cn=true]


[OnName num="keita"]
Then why did you run away?
[cpg cn=true]


[VOICE f="Youko093"]
[OnName num="youko"]
I was shook by that one phrase.
[cpg cn=true]


Yōko knew that I had snuck into her apartment.
[cpg]

I'm sorry. Please leave me alone.
[cpg]

[VOICE f="Youko094"]
[OnName num="youko"]
In my mind, my impression of Keita-kun had changed.
[cpg cn=true]



;//移植のためシーンをカットしています

;//ＢＫ
;//葉子に視点切り替わり
;//[ChangeWindow num="1"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA04_p2_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_14_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]


I think Kōtarō was a really careful person. I wonder how much of it was calculated.
[cpg]

Him divorcing me once was probably on purpose. But perhaps he foresaw that I would accept Keita.
[cpg]

And then he made Keita taste defeat......I wouldn't put it past him.
[cpg]

At night, I invited Kōtarō to my place. I have something important to discuss.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA04_p2_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『葉子の部屋』（夜）******************************************************


......Remarriage? I didn't expect to hear that from you. What should I do?
[cpg]

[OnName num="kotaro"]
...... Yes. I may have said some terrible things to you in the past, but ……
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Youko095"]
[OnName num="youko"]
Water under the bridge. I've got no reason to refuse.
[cpg cn=true]

[OnName num="kotaro"]
I felt like I could laugh again. I no longer felt any guilt towards Keita.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

On the way home after school, I passed by the apartment.
[cpg]

;//移植のためシーンをカットしています

;//恵太に視点切り替わり
;//[ChangeWindow num="0"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

I still had the duplicate key, but I no longer wanted to head over to her place.
[cpg]

Neighborhood rumors say that she was getting remarried or had remarried.
[cpg]

I remember Nanako warning me. She was taking about love making people crazy.
[cpg]

I was caught up in it, and maybe Yōko was too. It was too late for everything.
[cpg]

I don't need her. I never did. I had to think this way or something would break.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_00_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夕方）******************************************************

The feelings don't disappear, they just grow and grow.
[cpg]

Time passes slowly. Every waking moment is pain.
[cpg]

Months and days have passed. I'd graduated school some time ago.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_16_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]

When will Santa Claus come? When will we get a present?
[cpg]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『街』（朝）******************************************************

[OnName num="child"]
Hmmm. Maybe next year.
[cpg cn=true]


[VOICE f="Youko096"]
[OnName num="youko"]
But, I want it tomorrow! Moooom!
[cpg cn=true]

[OnName num="child"]
I think Santa is busy right now, dear.
[cpg cn=true]


[VOICE f="Youko097"]
[OnName num="youko"]
In the distance, I saw Yōko holding hands with her child.
[cpg cn=true]

Yōko had become a mother. It was growing quickly over the years.
[cpg]

Although many years have passed since I spent the days with Yōko, the curse has not been lifted; on the contrary, it is getting stronger.
[cpg]


;//ＢＫ


What I remember is the Yōko of those days. I recall the day when I snuck into her house......
[cpg]


[window target=false]
[transition target={true} rule="kosuri5.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kosuri5.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

Looking back, there may not be a more important moment in my life than that one.
[cpg]

I have recalled it many times. It never fades. I seemed to be able to vividly recall her voice, her silhouette, and even her smell.
[cpg]

I have recalled it many times. It never fades. I seemed to be able to vividly recall her voice, her figure, even her smell.
[cpg]

[SCENE id=13]

[jump storage="epend.ks" target="*start"]
;//【葉子ルート】エンド

;//==============================
