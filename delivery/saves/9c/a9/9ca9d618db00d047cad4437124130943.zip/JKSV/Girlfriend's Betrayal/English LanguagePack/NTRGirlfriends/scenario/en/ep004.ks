
*start

;#################################################
*Ep004|Dreams of dating someone.
;#################################################

[SCENE id=4]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『鳥のさえずり』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（朝）******************************************************


;//まどろみがやってきて、目が覚める。服の上からじゃ俺の物は勃起しているかどうかよく分からないけど、昨日考えたことの影響か、いやらしい夢を見た。だから勃ってるとは思う。
As I was dozing away I end  up waking up. I had a dream that I was going out with someone, probably because of what I thought yesterday.
[cpg]

;//その、いやらしい夢っていうのが、また……相手の女の子、その顔が思い出せないんだよな。
The dream is about ...... a girl I'm dating, and I can't remember what she looks like.
[cpg]

I guess she is a girl I am in love with deep doen. But I can't help it because I can't remember her face.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

[FG f="CHA04_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Youko007"]
[OnName num="youko"]
Good morning, Keita.
[cpg cn=true]

[OnName num="keita"]
“Oh, hi."
[cpg cn=true]

In the morning, I passed Yoko before going to school. So we talked for a little while.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Youko008"]
[OnName num="youko"]
“What's the matter, you've been staring at me. Is there something on my face?”
[cpg cn=true]

[OnName num="keita"]
Uh, no. It’s nothing.”
[cpg cn=true]

Was it Yoko that I saw in my dream? It's not impossible, since she's someone I admire, and I wonder who it was ......
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Youko009"]
[OnName num="youko"]
“If you have any problems, you can talk to me about anything, okay?”
[cpg cn=true]

Even if she says so, I can’t tell her that I was worried about love, and I had a sex dream where she appeared .......
[cpg]

[OnName num="keita"]
“I might talk to you sometime. Thanks.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Youko010"]
[OnName num="youko"]
“You look red. Did you catch another cold?”
[cpg cn=true]

[OnName num="keita"]
“No, no. I'm fine, really.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

I like Yoko. I may like her so much that it may go beyond being someone I admire.
[cpg]

But if, hypothetically, we were to go beyond the point where she is someone I admire, it might be pretty hard to maintain a relationship ...... She's a divorced woman.
[cpg]

She’s a decade older than me, and if I confess to her, she might think I'm a child.
[cpg]

And there's also the fact that I can't imagine what would happen after a successful confession ......
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・入り口』（朝）******************************************************

If I set my love interest at the same age, there are a lot of girls in the school. But most of them I don't know, and they probably don't know me either.
[cpg]

And I'm sure these things are on the minds of other boys besides me. Maybe the girls are thinking like that as well.
[cpg]

There must be almost the same number of men and women in this world, but it's a difficult thing, isn't it? ......
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se017]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・教室』（昼）******************************************************

[SE f=se016 loop=true]
;//【ＳＥ】『学園の喧噪』

When I see people after class like this, they are usually hanging out in groups of guys or girls.
[cpg]

Couples are rare compared to those who are not in couples.
[cpg]

;//こないだ俺達くらいの年代の非童貞、非処女の割合みたいなのをどこかで読んだけど……本当にそんなに居るのかなってくらいに、目に見えるカップルが少ない。
I read somewhere the other day about the percentage of people our age who have been in a relationship, but there are so few couples that I wonder if there really are that many .......
[cpg]

That's why I get nervous. I'm starting to feel like I'm being left behind if people are dating someone even in secret.
[cpg]

If the guys are pretending to be hanging out and the girls are pretending to be having fun, then I wonder if they are actually all in a relationship ......
[cpg]

[OnName num="takafumi"]
“What's going on? You look like the earth is dying.”
[cpg cn=true]

[OnName num="keita"]
“Really ....... Do I look that depressed?"
[cpg cn=true]

[OnName num="takafumi"]
You don't even realize it ...... That’s even worse.
[cpg cn=true]

[OnName num="keita"]
“Hey, Takafumi, do you have a girlfriend?”
[cpg cn=true]

[OnName num="takafumi"]
That's a bit sudden again. Why are you asking me that?
[cpg cn=true]

It's only him who I can ask. I don't have a lot of trusted friends ...... and most of them are girls.
[cpg]

If I asked the girls they would go crazy.
[cpg]

[OnName num="takafumi"]
“No, I don't have a girlfriend right now.”
[cpg cn=true]

[OnName num="keita"]
“I see. How many times have you been confessed to?”
[cpg cn=true]

[OnName num="takafumi"]
“About twice.”
[cpg cn=true]

[OnName num="keita"]
“What? You didn't tell me that.”
[cpg cn=true]

[OnName num="takafumi"]
Well, that's because I haven't told you. It's not something to be proud of, and it's not something to be self-deprecated about so ..…”
[cpg cn=true]

I thought for a minute and I couldn’t believe it, that there are guys who don't go out with a girl after being confessed to twice ...... but I might do that if a girl I didn't know at all confessed to me out of the blue.
[cpg]

But that’s because I’m just shy, so. It was surprising that Takafumi did that.
[cpg]

[OnName num="keita"]
“I didn't expect you to be so passive.”
[cpg cn=true]

[OnName num="takafumi"]
“You don't get to say that. I told you I’m not dating anyone.”
[cpg cn=true]

[OnName num="keita"]
“I can’t believe you are ahead of me.”
[cpg cn=true]

[OnName num="takafumi"]
“It's not about being ahead or anything like that. Just because you have more experience earlier doesn’t mean that it’s a good thing.”
[cpg cn=true]

[OnName num="keita"]
“It just means you have that much mental capacity if you ask me. I’m jealous.”
[cpg cn=true]

[OnName num="takafumi"]
“Don't look at me like that. ...... You really are feminine.”
[cpg cn=true]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se013]
;//【ＳＥ】『歩く』

[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

After hearing the shocking news, I went off to the art room. I wasn't too keen on working today either, but I was skipping too often ......
[cpg]

Yuri will get mad at me if I keep skipping club activities too much. The other day, she even came to my class and got mad at me.
[cpg]



[window target=false]
[transition target={true} rule="kaya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kaya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="kaya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kaya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『学園・美術室』（夕方）******************************************************


[VOICE f="Yuuri014"]
[OnName num="yuuri"]
...... Senior.
[cpg cn=true]

[OnName num="keita"]
“What?"
[cpg cn=true]

I work on art next to Yuri in the midst of many members of the club. I just draw pictures as I'm told.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuuri015"]
[OnName num="yuuri"]
The other day, I met someone that is just like you.”
[cpg cn=true]

[OnName num="keita"]
“Just like me? Like in a comic book or something?”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuuri016"]
[OnName num="yuuri"]
“Yes. It's not just the way you look, you also have a similar personality. The title of the comic is ......."
[cpg cn=true]

It was a great coincidence. It was the title of a comic book I had read the other day.
[cpg]

[OnName num="keita"]
“It's an old comic book. Right?”
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuuri017"]
[OnName num="yuuri"]
Is it really that old? Am I old-fashioned?”
[cpg cn=true]

[OnName num="keita"]
“I didn't say that ……"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuuri018"]
[OnName num="yuuri"]
“There's a character who comes to console a girl who's had her heart broken, and she reminds me a little of you.”
[cpg cn=true]

[OnName num="keita"]
......
[cpg cn=true]

I was about to burst into laughter. It was the character who I thought was too kitsch.
[cpg]

[OnName num="keita"]
“I think you're over-glamorizing it ...... I look like that?”
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Yuuri019"]
[OnName num="yuuri"]
“What? You’ve read the comic before? It's a girls manga ……."
[cpg cn=true]

She cringed. What the heck, she is the one saying something that make me cringe.
[cpg]

[OnName num="keita"]
“That's a terrible thing to say after recommending it! What's wrong with a guy reading girls manga?”
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Yuuri020"]
[OnName num="yuuri"]
“I didn't say it was wrong!”
[cpg cn=true]

The rest of the club members giggle at us arguing. It was a little embarrassing ......
[cpg]

I wonder what kind of admiration Yuri has for me. I've heard that admiration and love are distant.
[cpg]

But if she saw me as a male character from a girl's manga then ……  I shouldn't have high hopes.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・廊下』（夕方）******************************************************

After finishing club activities, I saw two people I knew in the hallway on my way to the school entrance. They were an unusual pair.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]

[OnName num="keita"]
“What's the matter, you two? Talking in a place like this.”
[cpg cn=true]


[FACE method="shake_5" pos="2/5"]
[VOICE f="Chiho013"]
[OnName num="chiho"]
“Oh! No, no, it's nothing. It's nothing.”
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Haruka018"]
[OnName num="haruka"]
“Hey Keita. Well, we were talking about the fact that neither of us has a boyfriend.”
[cpg cn=true]

What, they're talking about love too? ...... There's a lot of that kind of talk going on today.
[cpg]

[OnName num="keita"]
“You don't have a boyfriend? With Chiho it makes sense, but Haruka too? That's surprising.”
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Haruka019"]
[OnName num="haruka"]
“Surprising? I you mean that it’s surprising because I’m too beautiful than I’m happy.”
[cpg cn=true]


[FACE method="shake_2" pos="2/5"]
[VOICE f="Chiho014"]
[OnName num="chiho"]
What do you mean by ‘it makes sense'?
[cpg cn=true]

[OnName num="keita"]
“Look. Don't get me wrong, I know you don't have a boyfriend.”
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Chiho015"]
[OnName num="chiho"]
“Hmm? I see.”
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Haruka020"]
[OnName num="haruka"]
So, we were talking earlier about what we would do if we had to fight over the same person. Right?"
[cpg cn=true]


[FACE method="shock_5" pos="2/5"]
[VOICE f="Chiho016"]
[OnName num="chiho"]
“Uh huh. Right.
[cpg cn=true]

[OnName num="keita"]
“What, that scenario ...... is very limited.”
[cpg cn=true]

Besides, Chiho seems to be stuck on something. It's like she's just going along with Haruka's lies.
[cpg]

If so, were they talking about a totally different topic? What kind of a topic would they have to lie about?
[cpg]

[FACE method="change_2" pos="2/5"]
[FACE method="shake_2" pos="4/5"]
[VOICE f="Haruka021"]
[OnName num="haruka"]
“I'm older than you. What would you do if we had to fight over the same person?"
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Chiho017"]
[OnName num="chiho"]
“Well ...... I don't think I'd be in a relationship where I'd give up because I'd have to worry about someone else."
[cpg cn=true]

[OnName num="keita"]
“What? Did you two fall in love with the same person?”
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Haruka022"]
[OnName num="haruka"]
“No, no. I said, ‘What if?’”
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[FACE method="change_7" pos="4/5"]

[switch]
[case "I am interested."]
	[swap]
	[jump target="*select02_1"]
[case "I don't care."]
	[swap]
	[jump target="*select02_2"]
[endswitch]

1. I am interested.
2. I don't care.

;//---------------------------------------------------------------------------
;//１、気になる
;//千穂の選択肢が出現
*select02_1|Dreams of dating someone.

[stflag CHA01flg = 1]


[OnName num="keita"]
......
[cpg cn=true]

I'm awfully curious about what they were talking about. Especially Chiho.
[cpg]

It's a normal thing for her to fall in love with someone, but I'm surprised because I hadn't really thought about it.
[cpg]

Who exactly is the person that Chiho will fell in love with?
[cpg]

[OnName num="keita"]
I'm bothered by it.
[cpg cn=true]

I thought we were just childhood friends.
[cpg]

Could it be that deep down I have feelings for her?
[cpg]

[jump target="*select02_3"]

;//合流２へ
;//---------------------------------------------------------------------------
;//２、気にならない　場合
;//葉子の選択肢が出現
*select02_2|Dreams of dating someone.

[stflag CHA04flg = 1]


[OnName num="keita"]
“…… Yeah."
[cpg cn=true]

It's kind of weird. It's like there's a battle between the two of them. Normally, I would just think, "Oh, well, maybe there's a conversation topic like that.”, but ….
[cpg]

Suddenly, for some reason, that topic reminded me of Yoko.
[cpg]

She smiled at me gently this morning, her smile. I wonder if she is now directing that to someone in particular.
[cpg]

Yoko is divorced and alone now. Or maybe not ……
[cpg]


[OnName num="keita"]
“By the way, you two have nothing in common. Why were you two talking?”
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Haruka023"]
[OnName num="haruka"]
“We do have something in common, don't we? We both know you.”
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Chiho018"]
[OnName num="chiho"]
“In fact, I'm your childhood friend.”
[cpg cn=true]

Chiho is trying to control me. And she was right about what we had in common.
[cpg]

If that's the case, could it be me that the two of them are after? No way, right?
[cpg]


;//合流２へ
;//---------------------------------------------------------------------------
;//合流２
*select02_3|Dreams of dating someone.


[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・入り口』（夕方）******************************************************

[OnName num="keita"]
“Okay, I'll see you later ……"
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Chiho019"]
[OnName num="chiho"]
“See you later, Keita.”
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Haruka024"]
[OnName num="haruka"]
“See you."
[cpg cn=true]

[free time=1000]
[WAIT time=1000]

I parted from the two of them and headed back home.
[cpg]

Earlier, my mind was occupied with who I wanted to go out with, but now my mind was occupied with who I was going to go out with.
[cpg]

Even Chiho and Haruka, I don’t know who to prioritize right now.
[cpg]

To begin with, I can't compare my senior with my childhood friend. I can’t do something as rude as ranking them.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


After I parted from them, Takafumi chased after me from behind.
[cpg]

[OnName num="takafumi"]
Hey, Keita. Let's go home together.
[cpg cn=true]

[OnName num="keita"]
...... yeah.
[cpg cn=true]


;//ＢＫ
;//背景再び表示

[SE f=se013]
;//【ＳＥ】『歩く』
[WAIT time=1000]


[OnName num="takafumi"]
“It's pretty lonely walking home from school just us two guys.”
[cpg cn=true]

[OnName num="keita"]
“Yeah."
[cpg cn=true]

[OnName num="takafumi"]
“Assuming from the talk before, I'm sure you want to be in love, too. That's a relief."
[cpg cn=true]

[OnName num="keita"]
“…… That's true."
[cpg cn=true]

[OnName num="takafumi"]
“I thought that you wouldn't have any desire for love since you are so feminine.”
[cpg cn=true]

[OnName num="keita"]
“Yeah.”
[cpg cn=true]

[OnName num="takafumi"]
“Was that a yes or a no?”
[cpg cn=true]

[OnName num="keita"]
“Umm …. What were we talking about?”
[cpg cn=true]

[OnName num="takafumi"]
“Hey .........."
[cpg cn=true]

Takafumi didn't say anything to me, and ruffled my hair. He knew I wasn't listening to him.
[cpg]

[OnName num="keita"]
“Oww! That hurts.”
[cpg cn=true]

[OnName num="takafumi"]
“Well, never mind. You'll get a girlfriend soon enough. You don't need to worry about it.”
[cpg cn=true]

[OnName num="keita"]
“What makes you say that?”
[cpg cn=true]

[OnName num="takafumi"]
“Because you’re hanging out with a lot of girls where you look like a married couple. I'm so jealous of you.”
[cpg cn=true]

What? I guess he was just exaggerating. ......
[cpg]

Even if that's the case, I'm curious as with whom I look like a married couple. Chiho? Haruka? Or maybe Yuri?
[cpg]

[OnName num="keita"]
“From your point of view, who do you see as the most suited to me?”
[cpg cn=true]

[OnName num="takafumi"]
“A guy and a girl in our class who look good together? Then, me and ……."
[cpg cn=true]

[OnName num="keita"]
“Not you! Who do you see with me as a married couple?”
[cpg cn=true]

[OnName num="takafumi"]
“Well.”
[cpg cn=true]

Takafumi smirks at me, as if it's unusual for me to talk about this kind of thing. I was being serious.
[cpg]

[OnName num="takafumi"]
“I'll tell you, but then you'll go out with her, right?”
[cpg cn=true]

[OnName num="keita"]
“What?”
[cpg cn=true]

[OnName num="takafumi"]
“It means you don't have any initiative. That's why people say you're feminine. Whether you're a good fit with someone or not is someone else's problem, not yours."
[cpg cn=true]

...... That's certainly true. I might have been approaching this in a wrong way.
[cpg]

[OnName num="takafumi"]
All right, let's stop somewhere. Let's go to the arcade or something.”
[cpg cn=true]

[OnName num="keita"]
“Why are you suddenly changing the subject?”
[cpg cn=true]

[OnName num="takafumi"]
“I'm just thinking if us guys hang out together we would want to invite a girl at some point.”
[cpg cn=true]

[OnName num="keita"]
“I don't think so, I just think it would be fun to play with you Takafumi. I wouldn’t want to hang out with a girl.”
[cpg cn=true]

[OnName num="takafumi"]
“It's so like you to say that.”
[cpg cn=true]

[OnName num="keita"]
“What do you mean ……?"
[cpg cn=true]

[OnName num="takafumi"]
“You know, in a time like this, you just lie and say you want to hang out with girls. Or, play with a girl.”
[cpg cn=true]

[OnName num="keita"]
“But that’s too dirty.”
[cpg cn=true]

As we were talking about this nonsense, my mind somehow began to calm down.
[cpg]

And as I got calmer, one girl who was really important to me came to my mind.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・リビング』（夕方）******************************************************

[OnName num="keita"]
“I'm home."
[cpg cn=true]

In the living room, Nanako was studying while watching TV. The program was a serious news program.
[cpg]


[FG f="CHA05_p2_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanako006"]
[OnName num="nanako"]
What's wrong brother? You seem to be in a better mood than usual.”
[cpg cn=true]


[OnName num="keita"]
I wonder.”
[cpg cn=true]

Well, I'm not in a bad mood. It may indeed be good.
[cpg]

...... Either way I didn’t think it was goo for her to study while watching the news at this time of the day? Mom and dad are not here.
[cpg]

[OnName num="caster"]
“Next, we'll look at the exchange rates and stock market movements.”
[cpg cn=true]

[OnName num="keita"]
You know what, Nanako? How can you study with this turned on?”
[cpg cn=true]

It's not so much dark as it is creepy.
[cpg]

[OnName num="keita"]
Don't you watch dramas? Or anime?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nanako007"]
[OnName num="nanako"]
“If you do that, you will lose your efficiency. It's not the same as manga.”
[cpg cn=true]

She’s so serious ...... I can't believe she’s my sister. She doesn't seem interested in girlish romance at her age.
[cpg]

But wait. It's true that she’s been reading manga about romance, so I guess she has an inner longing for it.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hiraki.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hiraki.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夕方）******************************************************

I went back to my room and put down my luggage. As I sat down on my bed, I noticed that comic book I had been reading when I went to bed.
[cpg]

I think back on the day I spent today, which was so much more focused on romance than I had ever imagined.
[cpg]

Everyone is in love in some kind of way. Not only being lovers or being in love, but also being in love with love and longing for it. In my case, I guess I fall into the last category ......
[cpg]

But I'm slowly shifting to just being in love. I've already made up my mind of who I like.
[cpg]

If someone asked me who I liked, I could answer them.
[cpg]

[OnName num="keita"]
“But this isn't the goal, it's the start ……"
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（夜）******************************************************

With that determination in my heart, I finished dinner and washed the dishes. My parents both work, so I have to do some of the housework.
[cpg]

[OnName num="junichi"]
“They’re losing again.”
[cpg cn=true]

That said, I'm not sure about my dad who watches TV as soon as he finishes eating ...... I think when he says “they’re losing”, he's probably talking about baseball.
[cpg]

[OnName num="keita's_mother"]
“I'm sorry, Keita. I left the dishes to you.”
[cpg cn=true]

[OnName num="keita"]
“I'm not really in charge of the dishes. Half of it mom is doing.”
[cpg cn=true]

Usually, my mother washes the dishes with detergent, and I rinse them. Oh, come to think of it ......
[cpg]

[OnName num="keita"]
“Nanako doesn't do any housework, does she?”
[cpg cn=true]

[OnName num="junichi"]
“Nanako does the cleaning. She does a lot of other things that you doesn't see.”
[cpg cn=true]

[OnName num="keita"]
“?”
[cpg cn=true]

Something seemed wrong in the air for a moment just now. Nanako looked down ...... Is it just my imagination?
[cpg]

[OnName num="junichi"]
“By the way, Keita! I haven't heard any updates about you lately."
[cpg cn=true]

[OnName num="keita"]
“Um......"
[cpg cn=true]

My father said so to me. Even my mother was curious about it, waiting for a reaction.
[cpg]

[OnName num="junichi"]
“Look at this guy, he's in big trouble because he's been caught having an affair.”
[cpg cn=true]

He was talking about a baseball player on TV. Poor guy for being talked about in public.
[cpg]

[OnName num="keita"]
“Do you think adultery is a status thing, Dad?”
[cpg cn=true]

[OnName num="junichi"]
“I didn't say that. But there are people in this world who have more than one woman of their own, you know. Right Nanako?”
[cpg cn=true]


[FG f="CHA05_p2_02_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Nanako008"]
[OnName num="nanako"]
...... I'm sure there are people like that.
[cpg cn=true]

[OnName num="keita"]
“Don't affirm that Nanako."
[cpg cn=true]

I tried to let it slide, but it was still weird. Mom is smiling, but there's something strange about it ……
[cpg]

[OnName num="keita"]
“But I'm sure I could ...... get a girlfriend in no time if I wanted to."
[cpg cn=true]

[OnName num="keita's_mother"]
Well, really? Then, you'll have to introduce me to her sometime.
[cpg cn=true]

[OnName num="keita"]
“Ugh ..... I'm just saying I can. I don't have one right now.”
[cpg cn=true]

[OnName num="keita"]
“I'm not saying I can't have a girlfriend, I'm just saying I won't have one. There are even younger girls who have a crush on me.”
[cpg cn=true]

I feel like I'm getting blank stares. By all three of them.
[cpg]

[OnName num="junichi"]
“Don't be so tough. I know you're a unsuccessful son who is passive, ha ha ha ha.”
[cpg cn=true]

[OnName num="keita"]
“It's true! There's a girl named Yuri who's in love with me.”
[cpg cn=true]

[OnName num="keita's_mother"]
“Just because someone has a crush on you doesn't mean she's your girlfriend, right?”
[cpg cn=true]

What was all of this? They’re all trying to get me to get a girlfriend, no matter what.
[cpg]

[OnName num="keita"]
“I've got someone I'm interested in, too.”
[cpg cn=true]

It's quiet for a moment and everyone is waiting for me to say something. Yes, I'm graduating from being a passive guy. I have to be able to tell my family who I like.
[cpg]


[if exp={getFlagValue("CHA01flg") == 1 }]
[jump target="*CHA01sel"]
[endif]

[if exp={getFlagValue("CHA02flg") == 1 }]
[switch]
[case "I like Haruka"]
	[swap]
	[jump target="*Route02"]
[case "The person I like is a secret"]
	[swap]
	[jump target="*Route04"]
[case "I worry about Nanako"]
	[swap]
	[jump target="*Route05"]
[endswitch]
[endif]

[switch]
[case "I like Yuri"]
	[swap]
	[jump target="*Route03"]
[case "The person I like is a secret"]
	[swap]
	[jump target="*Route04"]
[case "I worry about Nanako"]
	[swap]
	[jump target="*Route05"]
[endswitch]

*CHA01sel|Dreams of dating someone.

[if exp={getFlagValue("CHA02flg") == 1 }]
[switch]
[case "I like Chiho"]
	[swap]
	[jump target="*Route01"]
[case "I like Haruka"]
	[swap]
	[jump target="*Route02"]
[case "I worry about Nanako"]
	[swap]
	[jump target="*Route05"]
[endswitch]
[endif]

[switch]
[case "I like Chiho"]
	[swap]
	[jump target="*Route01"]
[case "I like Yuri"]
	[swap]
	[jump target="*Route03"]
[case "I worry about Nanako"]
	[swap]
	[jump target="*Route05"]
[endswitch]


;//■選択肢
1. I like Chiho
2. I like Haruka
3. I like Yuri
4. The person I like is a secret
5. I worry about Nanako

;//それぞれ、番号ごとのヒロインへと分岐します。なお５番は奈々子へと分岐します


*Route01|
[jump storage="ep005.ks" target="*Route01"]

*Route02|
[jump storage="ep006.ks" target="*Route02"]

*Route03|
[jump storage="ep007.ks" target="*Route03"]

*Route04|
[jump storage="ep008.ks" target="*Route04"]

*Route05|
[jump storage="ep009.ks" target="*Route05"]

;//==============================

;////////////////////////////////////////////////////////////////////////

