
;//３、悠里が好き

*start|Yuri, my kōhai

;#################################################
*Ep007|Yuri, my kōhai
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_02_a.ui" method="change_1"  pos="2/5" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（夜）******************************************************


*Route03|Yuri, my kōhai

[SCENE id=7]

[OnName num="keita"]
I like Yuri.
[cpg cn=true]

[OnName num="junichi"]
Yuri ……? Who is that? I've never heard of her.
[cpg cn=true]

[OnName num="keita's_mother"]
Neither have I, is she from another school?
[cpg cn=true]

[OnName num="keita"]
She's a kōhai from the art club.
[cpg cn=true]

[OnName num="junichi"]
Oh, I remember now! I think you told us that she has a crush on you or something.
[cpg cn=true]

[OnName num="keita"]
Yeah. I don't think she has a crush on me, but she looks up to me. It was hard for me to get used to it at first.
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Nanako011"]
[OnName num="nanako"]
There is someone who looks up to you ……?
[cpg cn=true]

[OnName num="keita"]
She's younger, but different from a downer like you Nanako.
[cpg cn=true]

They have something in common. Nanako and Yuri are somewhat similar. But,
[cpg]

[OnName num="keita"]
Yuri is a more positive person. Almost too passionate.
[cpg cn=true]

[OnName num="keita's_mother"]
But you skip most of the club activities, right?
[cpg cn=true]

[OnName num="keita"]
Uh…
[cpg cn=true]

Indeed, she was right. If I wanted to get closer to Yuri, I should try not to miss club activities too often ......
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園・美術室』（夕方）******************************************************

So, I went to the club activities right the next day.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yuuri028"]
[OnName num="yuuri"]
...... Keita. You won't be absent today, will you?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuuri029"]
[OnName num="yuuri"]
Since you came to the club room, you won't say you're taking the day off and leave, will you?
[cpg cn=true]

She is a handful. I can imagine how she would react after I tell her that I won't take a break.
[cpg]

[OnName num="keita"]
Yeah, I thought I'd do some painting today.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuuri030"]
[OnName num="yuuri"]
Really?
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

She perks up in excitement.
[cpg]



[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//ＢＫ
;//背景再び表示

[OnName num="keita"]
I guess that's about it.
[cpg cn=true]

I was bored and half asleep, but I managed to create something. The amount of time I took to work on it was about half of that compared to the others.
[cpg]



[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuuri031"]
[OnName num="yuuri"]
I think you're a genius after all.
[cpg cn=true]

We are in the middle of club activities, so we can't talk too openly. Yuri calls out to me in a whisper.
[cpg]

[OnName num="keita"]
What? Why?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Yuuri032"]
[OnName num="yuuri"]
Because you were barely moving your hands and you were almost falling asleep meanwhile …….
[cpg cn=true]

[OnName num="keita"]
I thought everyone else was taking too much time ……
[cpg cn=true]

When I say that, I get a lot of angry looks. Most of them are girls.
[cpg]

The art club is mostly consisted of girls and there are only a few boys. And there are not a lot of boys who want to take painting seriously.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Yuuri033"]
[OnName num="yuuri"]
How can you say that? I'm trying my best to paint.
[cpg cn=true]

[OnName num="keita"]
Well ...... I think it would be better if you just drew what you see.	“好吧……我认为，如果您只是绘制了自己的所见，那会更好。
That's not advice!"
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Yuuri034"]
[OnName num="yuuri"]
I don't have a logic, it seems. That's because I didn't even listen to the teacher seriously.
[cpg cn=true]

I'm tired of hearing from Yuri that I'm great because I can still draw despite that.
[cpg]

There was somebody even better than I was. He was the head of the club and continued to work, despite the fuss.
[cpg]

He is tall and has a good face, and he is the type of person who draws with hard work and knowledge. He is way more popular than me.
[cpg]

I think he's better looking than I am. Why are you always focused on me?
[cpg]

[OnName num="keita"]
What?
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuuri035"]
[OnName num="yuuri"]
Everyone looks up and turns their head towards us. I'm not that good at reading the room.
[cpg cn=true]

Are you gonna make me say it? Is that your thing?
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuuri036"]
[OnName num="yuuri"]
Hey, keep it down.
[cpg cn=true]

[OnName num="manager"]
I'm sorry.
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Yuuri037"]
[OnName num="yuuri"]
Her face turns red as she panics. She can't hide her affection for me at all anymore.
[cpg cn=true]

I'll tell you more about it when ...... we're alone.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Yuuri038"]
[OnName num="yuuri"]
After the club activities were over, I headed home.
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

I told my family that I liked Yuri, and I was starting to feel that way too, so I asked her if she wanted to head back home with me.
[cpg]

I'll walk on the side of the road. Keita, um, you know…
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuuri039"]
[OnName num="yuuri"]
She was acting even more spastic than usual. She must be very happy to go home with me.
[cpg cn=true]

She kept mumbling something, but even after she said something, she was still acting strange.
[cpg]

Keita, do you have a girlfriend?
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Yuuri040"]
[OnName num="yuuri"]
That's a very intrusive question.
[cpg cn=true]

[OnName num="keita"]
I'm sorry, you're right. You must have a girlfriend, sorry ......
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuuri041"]
[OnName num="yuuri"]
She doesn't just respect me, she worships me. She's making assumptions and giving up before even trying to make a move.
[cpg cn=true]

Thank you ...... for coming to our club activities today.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuuri042"]
[OnName num="yuuri"]
Why are you thanking me? I didn't go because you asked me to.
[cpg cn=true]

[OnName num="keita"]
Right. You wouldn't come for me, obviously.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuuri043"]
[OnName num="yuuri"]
That's not what I meant. I just meant that she didn't need to thank me.
[cpg cn=true]

[FADEOUTBGM]

But still ...... I like you, Keita!
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Yuuri044"]
[OnName num="yuuri"]
What can I say, I guess she's not the type of person who enjoys the idea of a push and pull … she's already confessed now. I just asked her to go home with me.
[cpg cn=true]

[BGM f="bg_tl"]

Well, I guess it saved me the trouble of confessing myself ......
[cpg]

Uweeeh......
[cpg]


[FACE method="shock_8" pos="2/3"]
[VOICE f="Yuuri045"]
[OnName num="yuuri"]
Huh, wait...
[cpg cn=true]

[OnName num="keita"]
I was took a moment to reply, when she had burst into tears!
[cpg cn=true]

Why are you crying? I like you too Yuri. I like you too, so don't cry  …….
[cpg]

[OnName num="keita"]
When I said that, she looked at me like a surprised cat.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

Really? Am I allowed to like you, Keita?
[cpg]


[FACE method="bow_5" pos="2/3"]
[VOICE f="Yuuri046"]
[OnName num="yuuri"]
Yes, ouch!
[cpg cn=true]

[FO pos="2/3" time=500]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]


[OnName num="keita"]
Yuri hugged me without caring whether there were people around us. It was so forceful that it hurt.
[cpg cn=true]

Hold on, you're gonna break something......
[cpg]

[OnName num="keita"]
I love you, Keita. I loved you so much the whole time, I thought I was going to go crazy.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuuri047"]
[OnName num="yuuri"]
...... She's a handful and over the top, but she's a very sweet girl.
[cpg cn=true]

Her tears soaked through my clothes. I stroked Yuri's head.
[cpg]

She's really cute. That's why I like her too, but ......
[cpg]

I wonder if I can be the perfect person she wants me to be?
[cpg]

The next day. There was no one to stop the overexcited Yuri anymore. Naturally, I couldn't stop her either.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


...... Yuri.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園・廊下』（夕方）******************************************************

[OnName num="keita"]
What is it?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuuri048"]
[OnName num="yuuri"]
All the time, you were waiting for the class to end, weren't you? I saw you glancing at me.
[cpg cn=true]

[OnName num="keita"]
So what? Let's go to the club activities now.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Yuuri049"]
[OnName num="yuuri"]
Our classes end at the same time, she must have skipped class ……
[cpg cn=true]

Yuri steps into the club activity room with a smiling face, forcing me to hold her hand. I'm being dragged along.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・美術室』（夕方）******************************************************

She was humming.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yuuri050"]
[OnName num="yuuri"]
Yuri looks around the room, or rather, shows off to the other club members. She seemed prouder than anyone would could be.
[cpg cn=true]

This is not so different from shouting out loud, "We're dating!" At this point, I wouldn't be surprised if she did.
[cpg]

...... Let's get to our seats quickly. We're here to paint, right?
[cpg]

[OnName num="keita"]
Yes, that's right. We can show off again later, right?
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuuri051"]
[OnName num="yuuri"]
I feel scared for Yuri, who is getting excited like this, rather than feeling like I should respond or do my best to support her …….
[cpg cn=true]

From that point on, Yuri began to drag me along or tag along with me...everywhere.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="hiraki.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_16_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hiraki.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

What's a little strange is that, in spite of her high energy, she never asked me to go on a date with her or come over to her house.
[cpg]

It seems she had a modicum of modesty......
[cpg]

She had a modicum modesty. Or so I had thought...
[cpg]


[window target=false]
[BG f="b_16_4.ui" time=1500]
[WAIT time=3000]
[BG f="b_16_1.ui" time=1500]
[WAIT time=3000]

[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園・入り口』（朝）******************************************************

Good morning! Keita!
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yuuri052"]
[OnName num="yuuri"]
......So you're always here before me?
[cpg cn=true]

[OnName num="keita"]
Yes.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuuri053"]
[OnName num="yuuri"]
And you wait at the entrance until I come and greet me loudly when I arrive.
[cpg cn=true]

[OnName num="keita"]
It's a routine now.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Yuuri054"]
[OnName num="yuuri"]
What a routine. Her love burns with passion.
[cpg cn=true]

...... Um, Keita.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Yuuri055"]
[OnName num="yuuri"]
What? Don't come to my classroom and tell me you're taking classes with me.
[cpg cn=true]

[OnName num="keita"]
I won't do that. But, you know …
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuuri056"]
[OnName num="yuuri"]
Aren't you going to take me on a date or something ......?
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Yuuri057"]
[OnName num="yuuri"]
Oh. That was a bit of a surprising turn of events. I had wondered about the modesty, but I guess she had her limits.
[cpg cn=true]

...... If you suggest something, I'll go with you anywhere.
[cpg]

[OnName num="keita"]
What .......
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuuri058"]
[OnName num="yuuri"]
Oh. I guess I should not answer this way, since she was asking me if I would take her somewhere.
[cpg cn=true]

I'll take you anywhere you want to go. Where do you want to go?
[cpg]

[OnName num="keita"]
Yes, yes! There's going to be an exhibition of my favorite painter.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuuri059"]
[OnName num="yuuri"]
The little things don't seem to go well. I think I love Yuri too, but if our love for each other were to be weighed on a scale, mine would be lighter than hers.
[cpg cn=true]

We went right after school at Yuri's request, but I don't really feel like going on a date after a long day of class ......
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Phew!
[cpg]

[OnName num="keita"]
Unintentionally, I yawned in the museum. Yuri did not miss that.
[cpg cn=true]

Gosh, I'm sorry! I know it's boring. Would you have preferred to go to a movie theater or something?
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuuri060"]
[OnName num="yuuri"]
Oh ...... no, I'm fine.
[cpg cn=true]

[OnName num="keita"]
Yuri keeps smiling and acting in a good mood the whole time so that I won't come to dislike her. It didn't feel like we could keep going on like this……
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

Then one day.
[cpg]


[window target=false]
[transition target={true} rule="amamori1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・美術室』（夕方）******************************************************

Well, that's quite a feat. Congratulations, Keita.
[cpg]

[OnName num="sawabe"]
Huh ......?
[cpg cn=true]

[OnName num="keita"]
I came to the art room a little late and was praised by my advisor, Mr. Sawabe. The other members of the club are also applauding.
[cpg cn=true]

Congratulations, Keita!
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yuuri061"]
[OnName num="yuuri"]
What's this? It's like a dubious self-help seminar. Why were they congratulating me?
[cpg cn=true]

Keita, your painting won an award.
[cpg]

[OnName num="sawabe"]
An award? What award ……?
[cpg cn=true]

[OnName num="keita"]
I remember there was some kind of competition, or open call, or something, that I was forced to participate in ......
[cpg cn=true]

That won a prize?
[cpg]

[OnName num="keita"]
That's not a good way to be modest. It's disrespectful to the other works.
[cpg cn=true]

[OnName num="sawabe"]
Well, if I got an award, that's fine. Yuri is looking at me with sparkles in her eyes, so I figured I'd consider myself lucky.
[cpg cn=true]

Finally, I thought. Finally, Keita's talent was recognized.
[cpg]



;//ＢＫ
;//[lbox on]
;//悠里に視点切り替わり
;//[ChangeWindow num="1"]
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_16_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]


I couldn't be happier, I want everyone to see more of my boyfriend, Keita.
[cpg]

He's charming, cool, and has amazing talent!
[cpg]

...... Um, what is it? Why do you want to see me?
[cpg]


[window target=false]
[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『学園・美術室』（夕方）******************************************************

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yuuri062"]
[OnName num="yuuri"]
That's what I thought, but about the day after he won the award, I was called to the art room.
[cpg cn=true]

There was Mr. Sawabe and the head of the club. They looked serious.
[cpg]

Thanks for coming in, there's been a bit of a problem..
[cpg]

[OnName num="sawabe"]
What's going on?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuuri063"]
[OnName num="yuuri"]
......You know, Yuri. Actually, it's about Keita's work …….
[cpg cn=true]

[OnName num="manager"]
No, let me be the one to say it. Yuri, you need to steel yourself, it isn't a pleasant topic.
[cpg cn=true]

[OnName num="sawabe"]
What were they talking about? What was going on with Keita's work?
[cpg cn=true]

First of all, I want you to take a look at this.
[cpg]

[OnName num="sawabe"]
That's ...... Keita's painting, isn't it?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuuri064"]
[OnName num="yuuri"]
No, it's not. If you look closely, the fine touches seem to be different.
[cpg cn=true]

Yes, other people would think this is a picture he painted.
[cpg]

[OnName num="sawabe"]
No way ……
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuuri065"]
[OnName num="yuuri"]
Yes, he is suspected of plagiarism. You were close to him, weren't you?
[cpg cn=true]

[OnName num="sawabe"]
This can't be happening. I don't think Keita is the type to plagiarize because ...... he doesn't seem like the type of person who would want to cheat to get a prize.
[cpg cn=true]

I've always thought that what he painted was wonderful.
[cpg]

Has he told you anything about this? Does he have a favorite painter.
[cpg]

[OnName num="sawabe"]
I've never heard about that ...... He just yawns when we go to museums.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuuri066"]
[OnName num="yuuri"]
Well, alright ...... there's too much evidence already.
[cpg cn=true]

[OnName num="sawabe"]
Mr, Sawabe, if this comes to light, will Keita be ...... okay?
[cpg cn=true]

[OnName num="manager"]
I don't think so. He may have to leave the school in the worst case.
[cpg cn=true]

[OnName num="sawabe"]
That's ...... impossible!
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuuri067"]
[OnName num="yuuri"]
Was that even possible? I think it's common for students to plagiarize at least one painting or two ......
[cpg cn=true]

Is it such a crime to have entered a competition? I don't know.
[cpg]

Please wait! I'll do anything. Please don't expel Keita.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuuri068"]
[OnName num="yuuri"]
I'm afraid it's out of my hands. As you can see, even the head of the club is aware of the situation.
[cpg cn=true]

[OnName num="sawabe"]
Was there nothing I could do? I didn't want to see him get into trouble......!
[cpg cn=true]

......But if you're this insistent, I think we can come to an agreement.
[cpg]

[OnName num="sawabe"]
......What?
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Yuuri069"]
[OnName num="yuuri"]
The teacher takes a look at the head of the art club. Then he said,
[cpg cn=true]

If you'll excuse us I need to have a one-on-one talk with Yuri.
[cpg]

[OnName num="sawabe"]
I don't think so, this concerns me as well.
[cpg cn=true]

[OnName num="manager"]
......Very well, will the two of you follow me?
[cpg cn=true]

[OnName num="sawabe"]
What was happening? How did it come to this? This is......
[cpg cn=true]

Come along, Yuri.
[cpg]

[OnName num="sawabe"]
The teacher grabbed my arm. I couldn't refuse him, thinking that if I shook him off, Keita would be expelled from school.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

I was taken to the student guidance office. I knew what was going to happen then …..
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
[window target=true]

[BGM f="bg_vs"]

You said I had to satisfy you. What'd you mean by that …..?
[cpg]


[VOICE f="Yuuri070"]
[OnName num="yuuri"]
Suddenly, I was being kissed. I can't breathe.
[cpg cn=true]

;//●ＣＧ非エロ（悠里・教師とねちっこくキス。悔しさと申し訳なさで涙を流すヒロイン：学生指導室）ev_25

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_25_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]

Nnnn, mhhh.
[cpg]


[VOICE f="Yuuri071"]
[OnName num="yuuri"]
My mind was occupied with feeling sorry for Keita, not with the embarrassment of breathing through my nose or anything like that.
[cpg cn=true]

Even though I was trying to protect Keita, my first kiss was taken away from me.
[cpg]

(This is awful……. I wanted my first kiss to be with Keita.)
[cpg]

[VOICE f="Yuuri072"]
[OnName num="yuuri"]
While the teacher and I were kissing, the head of the art club calmly locked the doors. Were these two in on it together?
[cpg cn=true]

I am sure that they were lying about Keita being expelled from school ...... They were lying, so ......
[cpg]

No. If there is even the slightest chance that it is true, I can't resist.
[cpg]

The kiss tastes like a stranger. I don't know what kissing Keita would taste like, but it was so frustrated that ......
[cpg]

Huh.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_8"  pos="2/3" time=800]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



[VOICE f="Yuuri073"]
[OnName num="yuuri"]
I pulled my mouth away. Mr. Sawabe looked at me with cold eyes. The head of the art club on the contrary, is looking at me, as if he were licking my entire body ……
[cpg cn=true]

I feel like crying. What will happen to me now? I might not be able to get Keita to love me anymore.
[cpg]

I start crying.
[cpg]


[VOICE f="Yuuri074"]
[OnName num="yuuri"]
I was filled with anxiety about what would happen to me in the future.
[cpg cn=true]


;//移植のためシーンをカットしています

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


A few days passed, and many times, I was pressured by the teacher.
[cpg]

Then, one day.
[cpg]

I didn't see Keita during my lunch break, and I was sobbing by myself.
[cpg]

;//[ChangeWindow num="1"]

;//●ＣＧエロ（悠里・保健室で泣きじゃくるヒロイン。男の体は消してください：保健室）ev_27

[BGM f="bg_h3"]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

Are you alright? Yuri, I heard you weren't feeling well.
[cpg]

[OnName num="keita"]
I'm fine. Don't worry about it ……
[cpg cn=true]


[VOICE f="Yuuri075"]
[OnName num="yuuri"]
Are you sure? Please take it easy.
[cpg cn=true]


[OnName num="keita"]
Keita tries to reassure me.
[cpg cn=true]


But I have no other choice.
[cpg]

Wait, Keita!
[cpg]

;//恵太に視点切り替わり
;//[ChangeWindow num="0"]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『学園・入り口』（夕方）******************************************************

;//恵太に視点切り替わり


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Yuuri076"]
[OnName num="yuuri"]
Yeah ...... Yuri.
[cpg cn=true]

[OnName num="keita"]
She looked so ill during the day, but by the time we left school, she was back to normal.
[cpg cn=true]

Let's go home together. We are a couple after all.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuuri077"]
[OnName num="yuuri"]
……
[cpg cn=true]

[OnName num="keita"]
As I look closely I see that she's forcing a smile.
[cpg cn=true]

Oh, um. Keita.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuuri078"]
[OnName num="yuuri"]
What?
[cpg cn=true]

[OnName num="keita"]
About the head of the art club ..... what do you think of him?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Yuuri079"]
[OnName num="yuuri"]
What do you mean? I think he's cool and everyone's favorite member.
[cpg cn=true]

[OnName num="keita"]
I think you're much cooler than him.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuuri080"]
[OnName num="yuuri"]
Yeah, I know. Why are you saying that?
[cpg cn=true]

[OnName num="keita"]
I, I love you, Keita.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuuri081"]
[OnName num="yuuri"]
I've heard her say that so many times. I really don't know what's going on with her.
[cpg cn=true]

I didn't tell Keita anything about what the teacher or club head were doing to me.
[cpg]


[FADEOUTBGM]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

;//ＢＫ

;//悠里に視点切り替わり
;//[ChangeWindow num="1"]


[FACE method="change_4" pos="2/3"]
If he finds out, he'd try to protect me even if he gets expelled. If that happened, it would be useless for me to stop him.
[cpg]

I didn't want that to happen……If I'm the only one who has to suffer, then it's a small price to pay.
[cpg]

The art room on a weekend. His behavior was beginning to escalate.
[cpg]


[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『学園・美術室』（昼）******************************************************


Let's go with a typical art club activity today.
[cpg]


[OnName num="manager"]
What ...... does that mean?
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuuri082"]
[OnName num="yuuri"]
He suggested that I become a model for his drawings.
[cpg cn=true]


;//[ChangeWindow num="1"]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

I accepted it if that was all, but ......
[cpg]

It was difficult to stay still as he stared at me, capturing every detail and putting it onto paper.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1100]
[BGM f="bg_h3"]
;//●ＣＧエロ（悠里・デッサンのモデルになるヒロイン：美術室）ev_28
;**【ＣＧ】 ev_28_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]

[window target=true]

That's the expression I wanted to see.
[cpg]

[OnName num="manager"]
He tried to capture my frustrated face on paper.
[cpg cn=true]


It was unspeakably humiliating. I couldn't take this anymore.
[cpg]

How much weaker could I become?
[cpg]

Then, during the summer vacation, I was invited to the teacher's house.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_16_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


This is my house, or rather, my flat. Welcome.
[cpg]


[window target=false]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

[OnName num="sawabe"]
……
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Yuuri083"]
[OnName num="yuuri"]
Are you all right, Yuri? You look so gloomy. I thought you'd be more cheerful.	“你好吗，悠里？你看起来很沮丧。我以为你会更开朗。
You called me to your place on a weekend. If someone sees us, it'll be the end for you too."
[cpg cn=true]

[OnName num="sawabe"]
That's good. If I stop being a teacher, then it's easier to take Keita down with me.
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Yuuri084"]
[OnName num="yuuri"]
.......
[cpg cn=true]

[OnName num="sawabe"]
He would drag Keita into this. Of course he would. He demanded my body to keep Keita from being expelled from school, and now he thinks he has grasped my weakness.
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Yuuri085"]
[OnName num="yuuri"]
But I see no other options......he took Keita, the most important thing in my life, hostage.
[cpg cn=true]

What ......it's already noon!?
[cpg]

Oh shoot, I slept too much again. Summer vacation makes you lose your sense of time, doesn't it?
[cpg]
;//移植のためシーンをカットしています




;//ＢＫ
;//恵太に視点切り替わり
;//[ChangeWindow num="0"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se002"]
;//【ＳＥ】『携帯電話の震動音』ブーン

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・恵太の部屋』（昼）******************************************************


[OnName num="keita"]
I rub my sleepy eyes and pick up the cause that woke me up, or rather the thing that what woke me up.
[cpg cn=true]

Hello, is this Keita?
[cpg]

Yeah, what's up?
[cpg]


[VOICE f="Yuuri086"]
[OnName num="yuuri"]
I haven't seen you since ...... summer vacation started.
[cpg cn=true]

[OnName num="keita"]
Was that true? I could have sworn we talked on the phone a few times...but that sounds like an excuse and I probably shouldn't mention it.
[cpg cn=true]


[VOICE f="Yuuri087"]
[OnName num="yuuri"]
Okay, let's go on a date somewhere then, shall we?
[cpg cn=true]

Yes, yes. Let's go!
[cpg]

[OnName num="keita"]
I hear her happy voice on the other end of the phone.
[cpg cn=true]


[VOICE f="Yuuri088"]
[OnName num="yuuri"]
Yuri doesn't seem to be feeling unwell these days. I didn't know if it was even her physical condition that was making her feel off ......
[cpg cn=true]

Wow, it's beautiful. I remember this amusement park differently from when I was a kid.
[cpg]

Yes, it's like a dream to be in an amusement park with you Keita.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『遊園地』（昼）******************************************************

[SE f=se015 loop=true]
;//【ＳＥ】『街の喧噪』

[OnName num="keita"]
I kept thinking. If she wasn't feeling sick, then what was it? And then I came up with one answer that seemed to make sense.
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yuuri089"]
[OnName num="yuuri"]
The brightness of the girl is somewhat like an act. It was as if she was trying to remember who she had been like before.
[cpg cn=true]

It's not a dream, Yuri. We're really together.
[cpg]

Yes, we are. Yes, we are.
[cpg]

[OnName num="keita"]
So I want to be with you not only through the fun times, but also through the hard times.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Yuuri090"]
[OnName num="yuuri"]
What are you talking about?
[cpg cn=true]

[OnName num="keita"]
She tries to play dumb, but there was no way she could pretend to have forgotten how she looked before. Even I noticed, and that's saying something.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Yuuri091"]
[OnName num="yuuri"]
If it's something that bothers you, you can tell me. I'm your favorite senpai, right?
[cpg cn=true]

I know I'm still not there yet, but I'll do my best to be your ideal.
[cpg]

[OnName num="keita"]
No, really, it's nothing.
[cpg cn=true]

[OnName num="keita"]
She started to cry. She was still hyperactive, but something was shifting her into a strange, foreign direction.
[cpg cn=true]

[FADEOUTBGM]

[FACE method="shock_8" pos="2/3"]
[VOICE f="Yuuri092"]
[OnName num="yuuri"]
It was something serious. I don't think I said anything to make her cry ……
[cpg cn=true]

[BGM f="bg_t1"]
[WAIT time=100]

I also don't think I said anything to move her. I just said something normal, yet she started weeping.
[cpg]

Hey, are you okay? What's wrong, Yuri? ......You don't have an incurable disease or something, do you?
[cpg]

It's not like that. I'm not crying.
[cpg]

[OnName num="keita"]
I love you, Keita. I love you so much but ……
[cpg cn=true]


[FACE method="shake_8" pos="2/3"]
[VOICE f="Yuuri093"]
[OnName num="yuuri"]
But?
[cpg cn=true]


[FACE method="bow_8" pos="2/3"]
[VOICE f="Yuuri094"]
[OnName num="yuuri"]
Yuri's words faltered. She looked down and cried for a moment, then looked up and smiled.
[cpg cn=true]

[OnName num="keita"]
I'm so happy. I'm so happy, that I cried.
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_8"  pos="2/3" time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


...... Don't strain yourself. I'll say it one more time, if you have a problem, just tell me.
[cpg]



[FACE method="shake_6" pos="2/3"]
[VOICE f="Yuuri095"]
[OnName num="yuuri"]
It's true ...... I'm too happy.
[cpg cn=true]

[OnName num="keita"]
Tears are still spilling from the corner of her eyes. She is completely emotionally unstable.
[cpg cn=true]


[FACE method="shock_8" pos="2/3"]
[VOICE f="Yuuri096"]
[OnName num="yuuri"]
I wonder what is happening to her.
[cpg cn=true]

For a while, she continued to smile again, this time in an almost acting-like manner. And then ……
[cpg]

At the top of the Ferris wheel, she started crying, even though I hadn't said anything this time.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『遊園地』（夕方）******************************************************

She was bawling her eyes out.
[cpg]

…….
[cpg]

[free time=500]
[FG f="CHA03_p1_02_a.ui" method="change_8"  pos="2/3" time=800]
[VOICE f="Yuuri097"]
[OnName num="yuuri"]
By the time we got off the Ferris wheel, she still hadn't stopped crying. We probably looked like a couple that broke up on a Ferris wheel.
[cpg cn=true]

[OnName num="keita"]
Keita ...... what should I do?
[cpg cn=true]

I can't tell you. I just can't tell you.
[cpg]

[FACE method="change_8" pos="2/3"]
[VOICE f="Yuuri098"]
[OnName num="yuuri"]
I'm not going to say anything. If it's something you can't say, then just cry.
[cpg cn=true]


[FACE method="shock_8" pos="2/3"]
[VOICE f="Yuuri099"]
[OnName num="yuuri"]
I can't help her with this situation ...... I'm not going to try to stop her from crying by making her reveal her secrets.
[cpg cn=true]

Seeing Yuri's face swell up due to her tears, I can see that my love for her is becoming more certain.
[cpg]

At first, her love was rather too strong for me and I couldn't balance it, but it's gradually changing .......
[cpg]

Maybe someday it will be reversed. That's how loving I want to be.
[cpg]

I don't even know what it is going on anymore. I love Keita so much, almost too much.
[cpg]

If only Keita wasn't here, I find myself thinking.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_16_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]


;//悠里に視点切り替わり
;//[ChangeWindow num="1"]
;//[lbox on]

Another day.
[cpg]

Today, as usual, the teacher forces a kiss on me.
[cpg]


[window target=false]
[BG f="b_16_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

He leaves the room first, saying something about an appointment......
[cpg]

;//移植のためシーンをカットしています
;//ＢＫ
[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・美術室』（昼）******************************************************


......What am I doing?
[cpg]

Thinking so, I headed toward the school entrance and ......
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Yuuri100"]
[OnName num="yuuri"]
What?
[cpg cn=true]

The headmaster was there. Could it be that I was being watched all the time? I felt my blood turn into ice.
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuuri101"]
[OnName num="yuuri"]
Yuri, was it? Do you have some time?
[cpg cn=true]

Yes, sir.
[cpg]

[OnName num="principal"]
The school principal opens the door and comes into the room. I thought this would be the end of everything.
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Yuuri102"]
[OnName num="yuuri"]
If he saw what the teacher and I were doing, he wouldn't keep quiet. Then the teacher would be finished.
[cpg cn=true]

Of course, he would take Keita down with him, but ...... finally. Finally, I would be able to ...... What?
[cpg]

What is going on? Mr. Sawabe just left that room.
[cpg]

Oh, I pretended I didn't know, it's all right.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Yuuri103"]
[OnName num="yuuri"]
Pretended not to know? He saw what we did and pretended he didn't? What for?
[cpg cn=true]

[OnName num="principal"]
You're a bad girl, playing with the teacher in a place like this.
[cpg cn=true]

If you want me to keep my mouth shut, you understand what you have to do right?
[cpg]

[OnName num="principal"]
Oh ……
[cpg cn=true]

[OnName num="principal"]
He was just like Mr. Sawabe. This person also wants the same thing.
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuuri104"]
[OnName num="yuuri"]
Why are all these people like this?
[cpg cn=true]

Is it because the teacher and the principal are both men? Is it because I am a woman?
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


After he left, I was overcome by my emotions and broke down crying.
[cpg]

I think the two of them must have been in on it since the beginning.
[cpg]

;//●ＣＧエロ（悠里・打ちひしがれるヒロイン：美術室）ev_31
;**【ＣＧ】 ev_31_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


More to the point, the head of the art club, too.
[cpg]

I don't know what to do. Can I get out of this?
[cpg]

Is it because I'm weak? ...... When I thought so, I couldn't stop crying.
[cpg]

Yuri doesn't see me much anymore.
[cpg]

If I ask her out on a date, she comes along, but she doesn't ask me out.
[cpg]


;//移植のためシーンをカットしています


;//恵太に視点切り替わり
;//[ChangeWindow num="0"]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

On top of that, for some reason, she's been taking more and more time off from the art club, so we've been seeing each other less.
[cpg]

I think there's an imbalance in our relationship. I'm the one who's starting to miss Yuri.
[cpg]

At first, she was the kōhai who was attached to her senpai, but now it's kind of frustrating to see the situation reversed.
[cpg]

I was walking around wondering if I'll meet Yuri by chance somewhere .......
[cpg]

Yuri doesn't call me much these days.
[cpg]

Even if she does, the conversation doesn't last long. I was getting used to the new Yuri.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

The person on the other end of the phone talking to me in a good mood is not Yuri.
[cpg]

Hey, do you know what day it is tomorrow?
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

I know you'll kill me if I tell you I don't know .......
[cpg]

[VOICE f="Chiho205"]
[OnName num="chiho"]
A rare phone call with Chiho. My childhood friend's birthday was coming up tomorrow.
[cpg cn=true]

[OnName num="keita"]
Heh. If you know, you'll celebrate it, right? I'm looking forward to it.
[cpg cn=true]

I have a girlfriend. But ...... sure.
[cpg]


[VOICE f="Chiho206"]
[OnName num="chiho"]
Yuri would never suddenly say, "Let's go on a date tomorrow."
[cpg cn=true]

[OnName num="keita"]
So, it's fine ...... It's not really that I'm cheating or anything.
[cpg cn=true]

The next morning, I received another phone call. This time it was Yuri.
[cpg]

Hello?
[cpg]




[window target=false]
[transition target={true} rule="hiraki.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hiraki.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se002"]
;//【ＳＥ】『携帯電話の震動音』ブーン

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（朝）******************************************************


...... Yuri, what's wrong? It's so early in the morning.
[cpg]


[VOICE f="Yuuri105"]
[OnName num="yuuri"]
No, it's nothing.
[cpg cn=true]

[OnName num="keita"]
You called me for nothing ......?
[cpg cn=true]


[VOICE f="Yuuri106"]
[OnName num="yuuri"]
It's something I can't tell you ...... Keita. But I'm going through something very painful.
[cpg cn=true]

[OnName num="keita"]
Can you help me to forget my troubles? I want to see you, Keita.
[cpg cn=true]


[VOICE f="Yuuri107"]
[OnName num="yuuri"]
...... I was torn. Chiho's birthday is today, but, I guess it was okay to see Yuri any time to forget her troubles.
[cpg cn=true]


[VOICE f="Yuuri108"]
[OnName num="yuuri"]
That said, I was weighing Chiho, who is just a childhood friend, with Yuri, my girlfriend ......
[cpg cn=true]

Why do you hesitate? Why are you going quiet?
[cpg]

......Oh, it's nothing, sorry.
[cpg]


[VOICE f="Yuuri109"]
[OnName num="yuuri"]
By the way, today is Chiho's birthday, isn't it?
[cpg cn=true]

[OnName num="keita"]
......
[cpg cn=true]


[VOICE f="Yuuri110"]
[OnName num="yuuri"]
What the hell. Was she testing me, making up a false story about her troubles. I felt sick.
[cpg cn=true]

[OnName num="keita"]
I'm sorry. I've got some things to do. I'll see you another day.
[cpg cn=true]

I see.
[cpg]

[OnName num="keita"]
She said one word, and immediately after that, she hung up the phone.
[cpg cn=true]


[VOICE f="Yuuri111"]
[OnName num="yuuri"]
Keita had gone to Chiho's place. It was not a hunch, but a definite fact.
[cpg cn=true]

Happy birthday, Chiho …… You've grown a little taller.
[cpg]



;//ＢＫ

;//悠里に視点切り替わり
;//[ChangeWindow num="1"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************
;//[lbox on]

Thanks. But I don't think I've grown taller.
[cpg]

[OnName num="keita"]
I was secretly following him as he left the house. I saw them talking happily in front of her house.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chiho207"]
[OnName num="chiho"]
I did all of this for Keita.
[cpg cn=true]

I felt as if all the frustration I had been building up was about to explode. I had been abandoned. I had been betrayed.
[cpg]

Yuri, you seem to be more obedient than usual today.
[cpg]

Is that so? You might be right.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

[OnName num="sawabe"]
I guess he already saw that my feelings for Keita were changing inside me.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Yuuri112"]
[OnName num="yuuri"]
That makes him a much nicer man than Keita, who hasn't noticed anything yet. Why didn't I notice it?
[cpg cn=true]

The day after Chiho's birthday. I regretted that I hadn't been calmer that day.
[cpg]

It is a common thing to be tested by one's lover. I've probably done something similar before. I shouldn't have pushed her away......
[cpg]




;//ＢＫ

;//恵太に視点切り替わり
;//[ChangeWindow num="0"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

With that in mind, I had brought Yuri on a date today.
[cpg]

Oh, let's go to that store. It's cute.
[cpg]

Cute...? That?
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yuuri113"]
[OnName num="yuuri"]
It's cute. Why don't you see that?
[cpg cn=true]

[OnName num="keita"]
For me, it seemed like a general store painted in shocking pink and black.
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Yuuri114"]
[OnName num="yuuri"]
Fine, I'll go. Wait here.
[cpg cn=true]

Yuri's smile was back to natural. It didn't seem like she was acting.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuuri115"]
[OnName num="yuuri"]
Instead of "Let's go in together, Keita" she said, "Wait here."
[cpg cn=true]


I think she has come to grasp a good sense of distance. I guess it takes time for couples to reach a period of stability.
[cpg]

Or is it rather weird that we haven't kissed yet? At this point we should already be at second base.
[cpg]

[free time=1000]
[WAIT time=1000]


….. No, no.
[cpg]

What was I thinking. This is really reversing our positions. I'm starting to want Yuri.
[cpg]

[OnName num="keita"]
From there, the days went by. Summer vacation passed in the blink of an eye, and the season is about to turn into autumn.
[cpg cn=true]

After the summer vacation, there was a slight change in Yuri's atmosphere.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_16_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Probably, because it's autumn, but I feel also like she's a become a bit of a gal.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『学園・廊下』（昼）******************************************************

;//★夏休み明け、悠里の服装は若干の変化があった。
It seemed like she were changing to the liking of someone who isn't me. Or wanting to get the attention of someone who isn't me ......
[cpg]

.....I'm going to ask you again, what's going on?
[cpg]

Nothing really. Don't worry.
[cpg]

[OnName num="keita"]
She smiles. It looks like a natural smile, not like he's hiding some hardship.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yuuri116"]
[OnName num="yuuri"]
I finally noticed. It seems that Yuri is trying to get away from me.
[cpg cn=true]

Let's go out on a date again. We haven't been able to spend time alone lately.
[cpg]

In my haste, these words came out of my mouth.
[cpg]

[OnName num="keita"]
I'm sorry, I've been busy lately. Can we go on a date some other time?
[cpg cn=true]

What are you busy with these days ……?
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuuri117"]
[OnName num="yuuri"]
It's none of your business, so really don't worry about it.
[cpg cn=true]

[OnName num="keita"]
Even after school, she heads somewhere else before showing up for club activities.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Yuuri118"]
[OnName num="yuuri"]
I followed her ......
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『学園・廊下』（夕方）******************************************************

Isn't this the principal's office here ......?
[cpg]

Oh, Yuri. I've been waiting for you.
[cpg]

[OnName num="keita"]
What ……? Keita, you've been waiting for me all this time?
[cpg cn=true]



;//ＢＫ
;//悠里に視点切り替わり
;//移植のためシーンをカットしています
;//ＢＫ
;//[lbox on]

[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・入り口』（夕方）******************************************************

[OnName num="keita"]
Yes, I have. Do you wanna come over to my house today?
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Yuuri119"]
[OnName num="yuuri"]
…… I know that since I've distanced myself from him, Keita had become more attracted to me.
[cpg cn=true]

[OnName num="keita"]
But the way he asked me out wasn't very polite either. I can see through his impatience.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

Still, I accepted his offer to go to his house...... We talked about having dinner, too, as the sun was going down.
[cpg]

...... I should go home soon.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

Wait. I'm sorry, I know I've made you feel lonely.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Yuuri120"]
[OnName num="yuuri"]
What are you talking about, Keita? Hey!
[cpg cn=true]

[OnName num="keita"]
He almost forced a kiss on me. I wriggled away and refused, but he pushed me down.
[cpg cn=true]


[FACE method="shake_5" pos="2/3"]
[VOICE f="Yuuri121"]
[OnName num="yuuri"]
……
[cpg cn=true]

[free time=1000]
[WAIT time=1000]

Huh. Yuri...... I'm going crazy. I've been feeling really anxious lately.
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Yuuri122"]
[OnName num="yuuri"]
I don't know why …… but I feel like someone is going to take you away from me.
[cpg cn=true]

[OnName num="keita"]
Oh, I see.
[cpg cn=true]

[OnName num="keita"]
......He was never looking at me.
[cpg cn=true]

Please move aside.
[cpg]

......Why do you refuse?
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuuri123"]
[OnName num="yuuri"]
You neglected me for so long, and now this? Did you really think you understood the first thing about me?
[cpg cn=true]

[OnName num="keita"]
The stunned expression on Keita's face was memorable. I will probably never forget it.
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Yuuri124"]
[OnName num="yuuri"]
I have no hesitation anymore.
[cpg cn=true]

The next day in the art room.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="amamori1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori1.webp" color={0x000000ff} time=1]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


...... Something has changed about you.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『学園・美術室』（夕方）******************************************************

Really?
[cpg]

[OnName num="manager"]
I called some friends, so......
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuuri125"]
[OnName num="yuuri"]
So, you want me to be a model right?
[cpg cn=true]

[OnName num="manager"]
.......
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuuri126"]
[OnName num="yuuri"]
...... She's absent again.
[cpg cn=true]

[OnName num="manager"]
I go to peek into Yuri's classroom. Yuri is not there.
[cpg cn=true]

;//[lbox off]
;//移植のためシーンをカットしています

;//恵太に視点切り替わり
;//[ChangeWindow num="0"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『学園・教室』（昼）******************************************************

[OnName num="keita"]
Often I go there right after class and she is not there. Is she feeling bad?
[cpg cn=true]

Excuse me, sir.
[cpg]

Hmm? You are not in this class, are you? What do you want?
[cpg]

[OnName num="keita"]
Yuri is in this class right? Do you know why she's absent?
[cpg cn=true]

[OnName num="teacher"]
...... That's concerns her privacy. I can't tell you.
[cpg cn=true]

[OnName num="keita"]
No matter who I ask, I end up being told that. Of course, some of them don't know at all.
[cpg cn=true]

[OnName num="teacher"]
And the other act like they know but can't tell you.
[cpg cn=true]

It's not good as her boyfriend to not to do something. I should visit Yuri at home if she's feeling unwell……
[cpg]

As a surprise, I head to Yuri's house without making a phone call.
[cpg]

On the way, I also found a suitable gift for her. The reason I chose fruit was so I could eat it myself if she wasn't sick.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

When I rang the doorbell, Yuri answered.
[cpg]

...... Keita? I wasn't expecting you.
[cpg]

[SE f="se006"]
;//【ＳＥ】『玄関のチャイム』ピンポーン
[WAIT time=1000]

Are you all right?
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Yuuri127"]
[OnName num="yuuri"]
I'm fine. I'm just a little under the weather.
[cpg cn=true]

[OnName num="keita"]
Again, a natural smile. But I felt as if she was telling me that I should not be involved with her.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuuri128"]
[OnName num="yuuri"]
Can I come in?
[cpg cn=true]

……Why?
[cpg]

[OnName num="keita"]
You're just a little under the weather, right? Then let's talk a little. We haven't seen each other recently.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuuri129"]
[OnName num="yuuri"]
Who do you think it is that's keeping us from seeing each other?
[cpg cn=true]

[OnName num="keita"]
The smile remained on her face. I was horrified to hear the cold, low tone of her voice.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuuri130"]
[OnName num="yuuri"]
What do you mean ……?
[cpg cn=true]

Until now, I was lost. But in the end, I think it's all your fault.
[cpg]

[OnName num="keita"]
I'll tell you everything. Even the things you don't want to hear.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Yuuri131"]
[OnName num="yuuri"]
Remember the award you got for the artwork you submitted? Mr. Sawabe found out that it was plagiarized.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuuri132"]
[OnName num="yuuri"]
At first, I defended you in order to protect you ...... but I'm done with that.
[cpg cn=true]




;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuuri133"]
[OnName num="yuuri"]
Because no matter how much pain and suffering I went through, you didn't help me.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuuri134"]
[OnName num="yuuri"]
I think I told Yuri, who kept talking to me, that it was stupid or a lie. But I couldn't hear my own voice anymore.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Yuuri135"]
[OnName num="yuuri"]
Hey!
[cpg cn=true]

I found myself pushing her down.
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuuri136"]
[OnName num="yuuri"]
What's going on? Are you going to do something?
[cpg cn=true]

;//●ＣＧエロ（悠里・ヒロインに迫る主人公。しかし何も出来ない：悠里の部屋）ev_33
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h3"]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]
;//移植のためシーンをカットしています

I couldn't say anything, so I moved closer to her.
[cpg]

[VOICE f="Yuuri137"]
[OnName num="yuuri"]
I know. You're not going to do anything.
[cpg cn=true]


By that, she doesn't mean "don't do anything". Rather, the opposite.
[cpg]

;**【ＣＧ】 ev_33_a ***********************
[CG id=14 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Yuuri138"]
[OnName num="yuuri"]
And yet, she's right......
[cpg cn=true]


I couldn't put even a finger on her body.
[cpg]

Time passes.
[cpg]

The empty time passes like sand in a breeze.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_16_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


She no longer had to obey the teachers, but she still seemed to be having relations with them.
[cpg]

I thought about taking revenge on the teachers who had wronged her, but I could not.
[cpg]

I think she would be rather angry if I did.
[cpg]

More time passed, and Yuri came to my house for the first time in a long time.
[cpg]

What's wrong, Yuri. ...... I've been worried about you for a long time.
[cpg]

[window target=false]
[BG f="b_16_4.ui" time=1500]
[WAIT time=3000]
[BG f="b_16_1.ui" time=1500]
[WAIT time=3000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

Really? I don't need you to worry about me.
[cpg]

[OnName num="keita"]
Let's not talk while standing. Do you want to come in?
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Yuuri139"]
[OnName num="yuuri"]
My mind was filled with a sense of urgency, trying to keep Yuri connected to me somehow. But it was only for a ...... short amount of time.
[cpg cn=true]

[OnName num="keita"]
I think I'm going to be a mother soon so we'll probably be seeing more of each other then.
[cpg cn=true]

I saw a car of someone different from the teacher, and I was at a loss for words.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Yuuri140"]
[OnName num="yuuri"]
Bye Keita.
[cpg cn=true]

Surely this atonement would never end. But I thought it was okay.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuuri141"]
[OnName num="yuuri"]
I couldn't save Yuri. So I don't need to be saved either.
[cpg cn=true]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
;//ＢＫ

Surely this atonement would never end. But I thought it was okay.
[cpg]

I couldn't save Yuri. So I don't need to be saved either.
[cpg]

[SCENE id=12]

[jump storage="epend.ks" target="*start"]
;//【悠里ルート】エンド

;//==============================
