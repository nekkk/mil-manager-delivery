

;//１、千穂が好き

*start|

;#################################################
*Ep005|Chiho, my childhood friend
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_02_a.ui" method="change_1"  pos="2/5" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（夜）******************************************************


*Route01|Chiho, my childhood friend

[SCENE id=5]

[OnName num="keita"]
I love Chiho.
[cpg cn=true]

The silence continued. My father was the first to laugh.
[cpg]

[OnName num="junichi"]
Haha, I see, I see! I wish I'd heard that three years earlier.
[cpg cn=true]

[OnName num="keita"]
Huh?
[cpg cn=true]

[OnName num="keita's_mother"]
Yes, I've been wondering when you were going to introduce her to us as your girlfriend.
[cpg cn=true]

Now even my mother started laughing. Was it that obvious that I liked Chiho?
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Nanako009"]
[OnName num="nanako"]
You took too many detours, brother. Have you ever told anyone that you like Chiho?
[cpg cn=true]

[OnName num="keita"]
…… You guys are the first people to know, but so what?
[cpg cn=true]

Mom and Dad are laughing, but Nanako was flabbergasted. Was it really that obvious?
[cpg]

[OnName num="keita"]
Am I that easy to read? You mean you knew before I told you?
[cpg cn=true]

[OnName num="junichi"]
I wouldn't say that, but I mean...
[cpg cn=true]

[OnName num="keita's_mother"]
Yes, you two have always been so close.
[cpg cn=true]

[OnName num="keita"]
Is that all ……?
[cpg cn=true]

[OnName num="junichi"]
You say that's all, but, for example, who is your closest female friend?
[cpg cn=true]

[OnName num="keita"]
...... Chiho. The second closest one is a bit hard to think of right away.
[cpg cn=true]

We were originally good friends to begin with. But then again, I can't believe my family thought would be so accepting……
[cpg]


;//ＢＫ

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I was surprised and embarrassed, but I felt a certain determination underneath it all.
[cpg]

Tomorrow, I will do my best to close the distance between me and Chiho ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f=se013]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園・入り口』（朝）******************************************************

I went to bed, enthusiastic about the next day.
[cpg]

From then on, it was a matter of probability whether I would see Chiho on the way to the school. That was not something I could control.
[cpg]

[OnName num="takafumi"]
What's wrong, you look so gloomy.
[cpg cn=true]

[OnName num="keita"]
Do I?…… I think it's because I haven't slept enough.
[cpg cn=true]

[OnName num="takafumi"]
What, you didn't get enough sleep? Did something happen?
[cpg cn=true]

Actually, she was right about me having dark circles under my eyes because of the lack of sleep.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・教室』（昼）******************************************************

In between classes, Takafumi was worried again. This time he looked a little more serious.
[cpg]

[OnName num="takafumi"]
You're acting strange. You've been absent-minded in class all day.
[cpg cn=true]

[OnName num="keita"]
Was I…?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chiho020"]
[OnName num="chiho"]
Really? Keita, are you all right?
[cpg cn=true]

The truth of the matter is that I was thinking too much about Chiho, but I can't tell her. I wanted to tell her as soon as I saw her, but I couldn't.
[cpg]

[OnName num="takafumi"]
This guy. He's dazed all the time, but today he looks so gloomy on top of that.
[cpg cn=true]

Somehow, even when I tried to concentrate on other things, like my classes, I kept thinking about Chiho.
[cpg]

I remembered I'd talked about it with my family last night. They seemed supportive.
[cpg]

Close the distance? How? I'm so hyperaware of her presence that I feel like I'm too close to her.
[cpg]

[OnName num="keita"]
Oh .......
[cpg cn=true]

[OnName num="takafumi"]
.....Really, what's wrong with you, Keita? You're even sighing.
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『学園・入り口』（夕方）******************************************************

I don't know if we will see each other on the way to school. But I'm sure we'll head home together.
[cpg]

Why? Because we go to the same school. It's obvious.
[cpg]

[OnName num="keita"]
Let's go home together...... let's go home together......
[cpg cn=true]

I mumble the words, but it doesn't feel right. I was able to say it without a second thought before. How did I end up like this?
[cpg]

I really like Chiho. I said it in front of my family yesterday, and it seems to have made my love for her grow even more.
[cpg]

[OnName num="keita"]
Let's go home together ...... No, that's not it.
[cpg cn=true]

Chiho is a member of the tennis club and is still on the court. But it club activities were almost over.
[cpg]

I hid in the shadows the whole time, but I had to talk to her somehow before she went home.
[cpg]

Time passes slowly but surely. Chiho was walking toward me, and my heart was starting to race.
[cpg]

Let's go home together, Chiho. This one phrase would be enough. It's alright, it's all right. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chiho021"]
[OnName num="chiho"]
You've been here the whole time. Did you need something?
[cpg cn=true]

[OnName num="keita"]
What?
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

She talked to me before I had the chance to talk to her.
[cpg]

[OnName num="keita"]
Why ......?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chiho022"]
[OnName num="chiho"]
Were you hiding? I could see you pretty well.
[cpg cn=true]

Oh no. I guess if I could see her, she could see me too…….
[cpg]

I have to say it, I've come this far. Besides, "Let's go home together" is no good because it's the same as usual.
[cpg]

There has to be some better way to take the next step. How long am I going to be so passive?
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Chiho023"]
[OnName num="chiho"]
Is it something important? If you want to talk about it, I'm here for you.
[cpg cn=true]

[OnName num="keita"]
Yes, it's important.
[cpg cn=true]

I said it. I had to say something important, or else I'd be falling back into my usual pattern."
[cpg]

[OnName num="keita"]
Yeah, ...... So, I, uh …
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Chiho024"]
[OnName num="chiho"]
It's fine. Don't be so nervous, maybe they're the words I've been waiting for …..
[cpg cn=true]

Sensing my unusual mood, Chiho tries to calm me down.
[cpg]

She was waiting for me to say something all this time. My wavering heart finally tips entirely towards her.
[cpg]

[OnName num="keita"]
I like you Chiho. ...... So, please go out with me.
[cpg cn=true]

It took a while, but I was finally able to say it.
[cpg]

I panicked. Originally, I wasn't intending on confessing to her today.
[cpg]

Was it because she noticed me when I was supposed to be hiding? Because she asked me if it was important? Or was it because she said, "They're words I've been waiting for."
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Chiho025"]
[OnName num="chiho"]
......You dummy, how long were you going to keep me waiting?
[cpg cn=true]

We weren't alone and it seemed clear that we were attracting attention.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
Still, she didn't seem to care. I felt bad that I'd kept her waiting for so long.
[cpg]


;//●ＣＧ非エロ（千穂・ヒロインとキス：）ev_02

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]

Her lips touched my lips softly.
[cpg]


[VOICE f="Chiho026"]
[OnName num="chiho"]
We kissed.
[cpg cn=true]

I know, this is a kiss, right? It was a sensation I'd never experienced before.
[cpg]

But my brain, my thoughts, haven't caught up with the happiness. I was so surprised, and I didn't know what was going on.
[cpg]


[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・入り口』（夕方）******************************************************

The kiss was instantaneous. There were people around so our lips parted quickly. We had been childhood friends until yesterday, but we kissed each other.
[cpg]

It didn't feel real. My thoughts had not yet caught up with the happiness I was feeling.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Chiho027"]
[OnName num="chiho"]
I've been waiting for this for a long time. I hope you're ready for this.
[cpg cn=true]

What did she mean by that? But I didn't ask. The dreaminess slowly faded away, and I realized that I now had a girlfriend.
[cpg]


[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//ＢＫ

I couldn't very well tell my family, they'd make a big deal out of it.
[cpg]

On the other hand, I couldn't tell Haruka or Yuri either. I wonder if I could tell Takafumi …… maybe.
[cpg]

Happy times pass in an instant. It felt like as soon as my head hit the pillow, it was already time to get up.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園・教室』（昼）******************************************************

The next day at the school, there were rumors about us. That's the kind of attention we're getting.
[cpg]

I haven't told anyone, I thought. But if someone chatty had seen the kiss, it's possible ......
[cpg]

[OnName num="takafumi"]
You guys are kind of the talk of the school today.
[cpg cn=true]

[OnName num="keita"]
I don't think so. It's just in your imagination. Haha.
[cpg cn=true]

As usual, the three of us had dinner together. I glanced at Chiho.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chiho028"]
[OnName num="chiho"]
...... It's fine with me if you want to hide it, Keita.
[cpg cn=true]

She said. Yes, it's better to let these things unfold itself slowly, because it's the quietest way.
[cpg]

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/5" time=800]

[OnName num="takafumi"]
By the way, is it true you guys are dating?
[cpg cn=true]


[FACE method="change_5" pos="2/3"]

[OnName num="keita"]
What?
[cpg cn=true]

I unintentionally sent a grain of rice flying out of my mouth. It was too direct, too sudden.
[cpg]
[FG f="CHA01_p2_01_a.ui" method="change_6"  pos="2/5" time=800]
[OnName num="keita"]
Well, yeah. We're dating ......
[cpg cn=true]

I can't deny it here, because I'm standing right next to the person.
[cpg]

I wonder what Takafumi will think ...... I wonder if he will make fun of me or tell me that it won't last.
[cpg]

[OnName num="takafumi"]
Congrats ……! It's real, right?
[cpg cn=true]

[OnName num="keita"]
Yes ...... don't make me say it over and over again.
[cpg cn=true]

[OnName num="takafumi"]
Yo, Chiho! He may be unreliable in some ways, but he's a good guy, so take good care of him.
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Chiho029"]
[OnName num="chiho"]
You don't have to tell me twice.
[cpg cn=true]

[OnName num="takafumi"]
Well aren't you two lovey dovey!
[cpg cn=true]

From there, both of us were bombarded with questions. When we started liking each other, if we had kissed or not, or if we had gone beyond that or not.
[cpg]


[FACE method="bow_6" pos="2/5"]
[VOICE f="Chiho030"]
[OnName num="chiho"]
I don't really know when it started......
[cpg cn=true]

[OnName num="takafumi"]
I bet you did. It sure took a while for you to get there.
[cpg cn=true]

I was overwhelmed, but Chiho answered with a happy smile. She seems happy to be able to say clearly that she likes me.
[cpg]

She must have been waiting for a really long time ......
[cpg]

[OnName num="takafumi"]
You've only kissed once? Well this is a good enough time for your second!
[cpg cn=true]

[OnName num="keita"]
Cut it out, Chiho doesn't want to do it either right ……?
[cpg cn=true]

Her face was red and she didn't reply. Could it be …..?
[cpg]

[window target=false]
[transition target={true} rule="enn2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]
[BGM f="bg_tl"]
;//ＢＫ


[VOICE f="Chiho031"]
[OnName num="chiho"]
She kissed me.
[cpg cn=true]

On the cheek. But it was in a room full of students. Neither Takafumi nor I could conceal the look of shock on our faces.
[cpg]

;//背景再び表示
[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p4_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Chiho032"]
[OnName num="chiho"]
...... Just the cheek for now.
[cpg cn=true]

She was still a little bolder than the girl I knew so well. She's probably so happy right now if she's going this far …….
[cpg]

[OnName num="takafumi"]
Bro, you better hold on to her.
[cpg cn=true]

I nodded silently. I knew I made her wait too long, Chiho must have been through a hard time until now ...... I had to be aware of that.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『学園・入り口』（昼）
;//【ＢＧ】『学園・入り口』（夕方）******************************************************

From there, it was a roller coaster ride. Everything happened so fast that I couldn't keep up with it.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chiho033"]
[OnName num="chiho"]
Sorry to keep you waiting, Keita.
[cpg cn=true]


Chiho suggested that we have a date after school.
[cpg]

We had our first kiss and our second kiss in public, and while I was thinking about what would come next, she told me.
[cpg]

[OnName num="keita"]
Oh, I wasn't waiting long.......
[cpg cn=true]

I wasn't waiting long. If anything, I'd kept her waiting until now.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="heart2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
;//ＢＫ

We'd decided to see a movie. The things I had never imagined were happening to me.
[cpg]

I was so nervous that. Hopefully I'd chosen a good movie, one that was not too romantic.
[cpg]

[OnName num="keita"]
I gasped.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Chiho034"]
[OnName num="chiho"]
Are you all right, Keita?
[cpg cn=true]

I heard a worried whisper coming from beside me. I had mistakenly entered a horror movie. It did seem odd how long we'd been waiting for it to begin. That means we are not in the right room. I can't believe I didn't notice.
[cpg]

Chiho took my hand and I tightened her grip on it, trembling. The fear towards the screen is stronger than the happiness of having her next to me.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Chiho035"]
[OnName num="chiho"]
Oww ……. It's too tight,
[cpg cn=true]

[OnName num="keita"]
I'm sorry.
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]

But Chiho looks at me being scared in an endearing way. And more than that she looked happy ...... If that were the case, I didn't mind ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

[OnName num="keita"]
......I don't want to see a saw ever again.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Chiho036"]
[OnName num="chiho"]
When was the last time you saw one in real life, anyway?
[cpg cn=true]


The sun was setting when we left the cinema.
[cpg]

[OnName num="keita"]
It's getting pretty late, what should we do about dinner ……?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Chiho037"]
[OnName num="chiho"]
Let's eat somewhere. I've already told my parents so it's fine.
[cpg cn=true]

[OnName num="keita"]
What?
[cpg cn=true]

What did she tell them? She must have a curfew or something.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="heart2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


We had dinner and talked a lot. I'm happy and Chiho seems happy too.
[cpg]

I wish this blissful time would last forever, but if it really lasts forever, it will worry her parents.
[cpg]

[window target=false]
[FO pos="4/7" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

[FACE method="bow_6" pos="2/3"]
[VOICE f="Chiho038"]
[OnName num="chiho"]
I had a lot of fun today ...... I don't think I've ever been so happy in my life.
[cpg cn=true]

[OnName num="keita"]
Yeah. Me too ……!
[cpg cn=true]

;//冒頭のキスシーンのCGをもう一度表示
[free time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//公園のベンチに座りながら、

Our third kiss. I think I'm getting a little used to this enough to enjoy it.
[cpg]

Then she came close to me so that her chest was pressing against my body.
[cpg]

;//背景再び表示
;//[free time=1000]
;//[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
;//[BG f="b_03_4.ui" time=1000]
;//[WAIT time=1000]


[OnName num="keita"]
Wait a minute. Wait a minute.
[cpg cn=true]

I backed away a little. I know that Chiho made an effort to do this kind of thing, but I can't handle it so suddenly.
[cpg]



[VOICE f="Chiho039"]
[OnName num="chiho"]
I told you to be prepared.
[cpg cn=true]

But Chiho is a little too pushy too. I feel bad for making her wait for me all this time, but in a place like this …….
[cpg]

[OnName num="keita"]
Wait!
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]

I ended up shaking her off. There was an awkward silence.
[cpg]

[OnName num="keita"]
Let's take it step-by-step. There's no need to rush.
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Chiho040"]
[OnName num="chiho"]
You're right. I'm sorry.
[cpg cn=true]

Maybe I am quite feminine. If I were a man, I could have said no in a different way, but it's difficult ......
[cpg]

[OnName num="keita"]
I'm sorry, too. Are you disappointed?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Chiho041"]
[OnName num="chiho"]
I'm not disappointed at all. I had a lot of fun today and it made me happy.
[cpg cn=true]

[OnName num="keita"]
I see ......If I were more manly, I would be able to meet your expectations.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Chiho042"]
[OnName num="chiho"]
No, you already do.
[cpg cn=true]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]
;//ＢＫ

After that, I sent Chiho home and went back to my house. I came back late at night and my parents were giving me a lecture, but I couldn't take that in right now.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

[OnName num="keita"]
I wonder if she had fun with me ……
[cpg cn=true]

I knew I should have responded differently. Maybe I was too much of a wimp ......
[cpg]

No matter how much I agonize over it, I can't find an answer.
[cpg]



[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

And without an answer, I saw her on the way to school the next day.
[cpg]

[OnName num="keita"]
Good morning. Chiho.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chiho043"]
[OnName num="chiho"]
Good morning. I'm sorry about the other day, I don't know what I was thinking ……
[cpg cn=true]

Oh. Chiho was thinking the opposite of what I was worried about.
[cpg]

[OnName num="keita"]
It's okay, you don't have to apologize.
[cpg cn=true]

But the words don't continue from there. We have a conversation, but after a little while ……
[cpg]

[OnName num="keita"]
The movie we saw had great ratings. I don't understand it, it scared me to death.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Chiho044"]
[OnName num="chiho"]
Yeah ...... I had the impression that it was scary, too.
[cpg cn=true]

[OnName num="keita"]
......
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Chiho045"]
[OnName num="chiho"]
......
[cpg cn=true]

The silence returns after a little while, after all. Are couples who just got together really like this?
[cpg]



[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・廊下』（昼）******************************************************

[OnName num="takafumi"]
Hey, what's going on?
[cpg cn=true]

[OnName num="keita"]
What?
[cpg cn=true]

Between classes, Takafumi calls me out to the hallway. His words hit a sore spot.
[cpg]

[OnName num="takafumi"]
For someone who just started dating, you don't talk much, do you? I didn't think you'd stumble at the beginning.
[cpg cn=true]

[OnName num="keita"]
...... No way. I think Chiho might not like me ……
[cpg cn=true]

[OnName num="takafumi"]
What ……? You think she hates you?
[cpg cn=true]

[OnName num="takafumi"]
Are you kidding me? Why would she kiss someone she doesn't like in the classroom.
[cpg cn=true]

[OnName num="keita"]
I don't mean that. I just think she might dislike me for my inadequacies.
[cpg cn=true]

From there, we talk a little bit. First of all, I might not be too familiar with sexual matters.
[cpg]

Then, I was amazed at the way Chiho had changed, or rather, the way she started to approach me……
[cpg]

If Chiho hears me talking like this, I'm in trouble. I'm talk to Takafumi about it while I look around. Then.
[cpg]

[OnName num="takafumi"]
Man, you gotta get it together. Chiho's going to have a hard time if you don't hash it out a little more.
[cpg cn=true]

[OnName num="keita"]
What, it's my fault?
[cpg cn=true]

I thought he would agree with me. She came on to me. I thought Chiho would be in trouble if I didn't stop her.
[cpg]

[OnName num="takafumi"]
You know that Chiho has been thinking about you for years, right?
[cpg cn=true]

[OnName num="keita"]
Of course. So have I.
[cpg cn=true]

[OnName num="takafumi"]
Then, it's not that surprising, is it? She's doing a great job holding back if you ask me.
[cpg cn=true]

[OnName num="keita"]
Oh.......
[cpg cn=true]

What should I do? Is that how it is? I enjoy just being with Chiho, and she says she does too.
[cpg]

[OnName num="takafumi"]
I guess there's a lot of shy guys like you nowadays.
[cpg cn=true]

[OnName num="takafumi"]
......Hmm. Maybe it's not unusual for girls to take the lead?
[cpg cn=true]

From what Takafumi is saying, I gather that Chiho was trying to lead, but I was refusing.
[cpg]

[OnName num="takafumi"]
If she's doing the leading then you shouldn't fight her at every turn. Unless you're willing to switch positions with her or something.
[cpg cn=true]

[OnName num="keita"]
Alright, I get that it's my fault. It's just hard to change right away.......
[cpg cn=true]

I couldn't find it in me to aggressively approach Chiho. It wasn't part of my personality.
[cpg]

Feeling sorry for myself, I get depressed.
[cpg]

[OnName num="takafumi"]
Sorry man, I'm not trying to pin it all on you. It's your relationship, you gotta figure out where you stand.
[cpg cn=true]

[OnName num="keita"]
Yeah ……
[cpg cn=true]

[OnName num="takafumi"]
But since you're dating, something has to change. If you're really thinking about your partner, you'll try a little harder.
[cpg cn=true]

He was right. If we weren't going to change, why were we even dating?
[cpg]

[OnName num="takafumi"]
Otherwise, someone will take Chiho away from you.
[cpg cn=true]

[OnName num="keita"]
I don't want that!
[cpg cn=true]

[OnName num="takafumi"]
That's a good answer. You said it clearly, so that's a good first step.
[cpg cn=true]

...... I can't beat Takafumi in this argument. I feel like he supports me despite all my bad parts.
[cpg]

[OnName num="keita"]
I'll ...... try my best. Okay.
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="amamori1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『学園・教室』（夕方）******************************************************

After school. I went to Chiho's classroom and talked to her, remembering Takafumi's words.
[cpg]

[OnName num="keita"]
Hey, Chiho.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chiho046"]
[OnName num="chiho"]
Oh ...... Keita. What is it?
[cpg cn=true]

[OnName num="keita"]
It's been a long time, do you want to come over to my house?
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Chiho047"]
[OnName num="chiho"]
What?
[cpg cn=true]

Was I too bold all of a sudden? When we were friends, we hung out a few times, so I think it's okay, but now it's a date ......
[cpg]

[OnName num="keita"]
It's okay if you don't want to, but I do.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Chiho048"]
[OnName num="chiho"]
No, I do! I'm happy.
[cpg cn=true]

I got a cheery reply ...... Okay, it's settled. This time, from the family's point of view, Chiho isn't just a friend.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/5" time=1]
[FG f="CHA05_p2_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（夕方）******************************************************

[OnName num="keita"]
So, this is my girlfriend.
[cpg cn=true]


[FACE method="bow_6" pos="2/5"]
[VOICE f="Chiho049"]
[OnName num="chiho"]
Oh, hi ...... It's me Chiho.
[cpg cn=true]

For some reason, we both stiffened. We became polite. My parents are laughing when they see her and hear her words, but Nanako still has a cold expression on her face.
[cpg]

[OnName num="junichi"]
Well, it's been a long time! I'm so overwhelmed.
[cpg cn=true]

[OnName num="keita's_mother"]
It's getting late, why don't you have dinner with us? It's a good chance to show off my cooking skills.
[cpg cn=true]


[FACE method="shake_3" pos="4/5"]
[VOICE f="Nanako010"]
[OnName num="nanako"]
I bet it must be very hard to be my brother's girlfriend, huh? You'll be let down a hundred times along the way.
[cpg cn=true]


[FACE method="shake_4" pos="2/5"]
[VOICE f="Chiho050"]
[OnName num="chiho"]
That's a terrible thing to say …….
[cpg cn=true]

Nanako seemed a little aggressive towards Chiho.
[cpg]

I guess she feels as if her brother is being taken away. But my will remains the same, Nanako.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p2_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（夜）******************************************************

After that, we had dinner, and as we were talking ......
[cpg]

[OnName num="keita's_mother"]
Oh yeah, why don't you stay over?
[cpg cn=true]


[FACE method="shake_5" pos="2/5"]
[VOICE f="Chiho051"]
[OnName num="chiho"]
What, is that okay?
[cpg cn=true]

[OnName num="junichi"]
Well, you've stayed over before, haven't you? Although it was a long time ago, haha.
[cpg cn=true]

At that time, I naturally thought we'd be sleeping in separate rooms. I was sure that my mother would prepare Chiho's bedding.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="amamori1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

[FACE method="change_6" pos="2/3"]
[VOICE f="Chiho052"]
[OnName num="chiho"]
...... There is only one mattress.
[cpg cn=true]

[OnName num="keita"]
I'm sorry...... there's another room, so how could this happen?
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Chiho053"]
[OnName num="chiho"]
I don't mind.
[cpg cn=true]

If Chiho had refused, I would have gladly slept in the living room. If anything, she seemed happy about it.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]
;//ＢＫ

I turned off the light and got into bed with her. We turn our backs to each other, but ......
[cpg]

I wonder if I really want this to happen, even if it's just an accident. Did I just blow an entire lifetime of luck on this moment?
[cpg]

I can't stop my heart from pounding. My heart beats even faster when I think that Chiho can feel it.
[cpg]

[OnName num="keita"]
It's kind of cramped, huh?
[cpg cn=true]


[VOICE f="Chiho054"]
[OnName num="chiho"]
No, it's fine ...... you can come over here a bit.
[cpg cn=true]

If I do that our bodies will touch. Chiho moves closer to me.
[cpg]


[VOICE f="Chiho055"]
[OnName num="chiho"]
Won't you turn around?
[cpg cn=true]

A sweet whisper reaches my ears. I turn to find her looking at me.
[cpg]

;//●ＣＧエロ（千穂・恵太のベッドで一緒に寝る：恵太の部屋）ev_03

;**【ＣＧ】 ev_03_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Chiho056"]
[OnName num="chiho"]
She chuckled.
[cpg cn=true]


She looked as if she had indeed been waiting for me for a long time.
[cpg]

I guess I have to respond to her. I don't have time to be freaked out anymore.
[cpg]

[OnName num="keita"]
……
[cpg cn=true]

Still, I couldn't say a single word about how beautiful she was, so I kept quiet.
[cpg]

I cursed my cowardice......
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="quake_b_06_2.ui" method="stop" layer=20 pos="5/9" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園・教室』（昼）******************************************************

[OnName num="keita"]
So that happened. I was nervous the whole time.
[cpg cn=true]

[OnName num="takafumi"]
Okay ...... So, what happened next?
[cpg cn=true]

[OnName num="keita"]
What do you mean?
[cpg cn=true]

In the classroom, I reported the results of the battle to Takafumi. I thought I had moved beyond the realm of being timid and shy by now.
[cpg]


[OnName num="takafumi"]
You are so dumb!
[cpg cn=true]

[FACE method="quake" pos="5/9"]

[SE f="se001"]
;//【ＳＥ】『叩く』
[WAIT time=1000]

There was a light slap. I was the one who was hit, and Takafumi was the one who hit me.
[cpg]

I didn't know what was going on and couldn't speak. People around us looked at us for a moment, but didn't say anything.
[cpg]

[OnName num="keita"]
Why are you getting mad at me? Did you just hit me?
[cpg cn=true]

It's not like I wanted to brag or anything. I was simply trying to report last night's incident to my best friend.
[cpg]

Chiho and I had slept in the same bed. We'd embraced each other. We kissed a bit, and I'd gotten to cop a feel here and there......
[cpg]

I said all of these things in a voice that only Takafumi could hear. I thought he'd be proud of me.
[cpg]

[OnName num="takafumi"]
How can you still be so timid there?
[cpg cn=true]


[OnName num="keita"]
It's not that I didn't ...... do anything ……
[cpg cn=true]


[OnName num="takafumi"]
It's as if you didn't do anything!
[cpg cn=true]

[OnName num="keita"]
But ...... I didn't have a choice. My parents were there.
[cpg cn=true]

[OnName num="takafumi"]
Would it be any different if your parents weren't there?
[cpg cn=true]


[OnName num="keita"]
I'm sorry …….
[cpg cn=true]

[OnName num="takafumi"]
If you're going to apologize, apologize to Chiho.
[cpg cn=true]

Apparently, Takafumi is quite angry. Finally, I'm beginning to understand the gravity of the situation.
[cpg]

[OnName num="takafumi"]
You know she wants to be with the person she's in love with. You know that, right?
[cpg cn=true]

[OnName num="keita"]
I know that much.
[cpg cn=true]

[OnName num="takafumi"]
And you're too scared to do anything about it, right?
[cpg cn=true]

[OnName num="keita"]
......Yeah.
[cpg cn=true]

[OnName num="takafumi"]
I'm amazed you're willing to admit it. I'm starting to think you're doing it for laughs.
[cpg cn=true]

[OnName num="keita"]
Why? You know I have very little pride.
[cpg cn=true]

[OnName num="takafumi"]
It's a matter of impression. And it's the worst thing of all to look like you value your pride, when you don't.
[cpg cn=true]

[OnName num="takafumi"]
You have to be willing to do whatever it takes to get things done, right? I know you have your ideas of what failure and success look like.
[cpg cn=true]

I noticed that Takafumi was no longer angry with me. He looked serious, as if he was trying to convince me.
[cpg]

It's not like he's joking around and talking about vulgar things.
[cpg]

[OnName num="keita"]
Even you can't know everything I'm feeling.
[cpg cn=true]

[OnName num="takafumi"]
So what? If you think there's a reason why you can't take the next step, explain it to me.
[cpg cn=true]

I didn't think he would go this far ....... I know he is thinking seriously about me and Chiho.
[cpg]

But this tied into my inferiority complex. It wasn't something I could tell him about so casually.
[cpg]


[OnName num="keita"]
Hey. Will you see me the same way no matter what I say?
[cpg cn=true]

[OnName num="takafumi"]
I'm already feeling let down about you given what I heard today.
[cpg cn=true]

I see ...... Well, that's okay then.
[cpg]

[OnName num="keita"]
I have a problem. I'm afraid I'm going to fail, and this is why.
[cpg cn=true]

[OnName num="takafumi"]
What's the matter, you suddenly look so serious.
[cpg cn=true]

Takafumi looks flustered. He seems to have misunderstood something.
[cpg]

[OnName num="takafumi"]
Buddy…? Do you bat for the other team?
[cpg cn=true]

[OnName num="keita"]
No, I'm not! I'm straight! But …
[cpg cn=true]

[OnName num="takafumi"]
But what?
[cpg cn=true]

[OnName num="keita"]
I can't talk about it here. Come with me, I need to show you something.
[cpg cn=true]

I pull Takafumi's arm and take him to a certain place.
[cpg]

[OnName num="takafumi"]
What? You want me to go into a stall with you? Dude...
[cpg cn=true]

[OnName num="keita"]
......
[cpg cn=true]

As awkward as it was for the both of us, I brought him here for a reason.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_du"]
[WAIT time=100]
;//ＢＫ

[OnName num="takafumi"]
Seriously, a restroom …… what the hell are you going to tell me in a place like this?
[cpg cn=true]

Takafumi is sweating, his face like a Noh mask.
[cpg]

I'm not talking about doing something weird. I couldn't show him in the classroom.
[cpg]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』
[WAIT time=1000]

I silently took off my clothes. Takafumi was naturally surprised.
[cpg]

[OnName num="takafumi"]
Oh, come on, are you serious? What's that?
[cpg cn=true]


But he understood immediately.
[cpg]

I guess he saw the big bruise under my clothes.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・廊下』（昼）******************************************************

[OnName num="takafumi"]
So that's what this is all about.
[cpg cn=true]


[OnName num="keita"]
Yeah ...... She's my girlfriend, so she'll see me naked if something happens.
[cpg cn=true]


This is the reason why I still don't have the courage to do it.
[cpg]

It was just a childhood accident, but it was still a complex.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・教室』（昼）******************************************************

When we returned to the classroom, some of the boys saw us and started talking to us.
[cpg]

[OnName num="male_student"]
You guys were in the bathroom together, weren't you? What were you doing?
[cpg cn=true]

[OnName num="male_student"]
Don't ask, you idiot. You know what we were doing.
[cpg cn=true]

[OnName num="keita"]
… !
[cpg cn=true]

People saw us ......I thought I was being careful. Feeling sorry for dragging Takafumi into this, I turned red and stared at my feet.
[cpg]

[OnName num="male_student"]
For real? To think Keita would start cheating already. I envy him for being able to go both ways.
[cpg cn=true]

[OnName num="male_student"]
No, no, no, he's got a girlfriend so it's just two friends having fun. His true love is still Chiho ……
[cpg cn=true]

[OnName num="takafumi"]
Brooooooo! You're taking it too far.
[cpg cn=true]

The way that Takafumi could change everything into a joke was amazing. Sometimes I feel like we were two different species.
[cpg]

He has a good face and he is smart. He's also very tactful at times like this, and his personality is so much more sociable than mine ......
[cpg]

[OnName num="male_student"]
I know you guys wouldn't do that.
[cpg cn=true]

[OnName num="male_student"]
I mean, even you I did, I wouldn't look at you in a funny way.
[cpg cn=true]

It's safe to say he is the most popular person in the class. There is no way anyone would seriously think badly of him at a time like this.
[cpg]

It's just a joke, and everyone takes it as a joke …… except for one person.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chiho057"]
[OnName num="chiho"]
Hmm……so you two were like that.
[cpg cn=true]

[OnName num="keita"]
What ...... Chiho!?
[cpg cn=true]

We're supposed to be in different classes, why is Chiho here? If she was just passing by, then what bad timing ......
[cpg]

[free time=1000]

Chiho ran away with teary eyes.
[cpg]

[OnName num="keita"]
I should go after her right?
[cpg cn=true]

[OnName num="takafumi"]
You'll only add fuel to the fire if you do. I'd better explain it to you.
[cpg cn=true]

Indeed, that's right …… since Chiho and I are lovers, it is better for Takafumi, who is just a friend, to explain this.
[cpg]


;//ＢＫ

;//千穂に視点切り替わり
;//[ChangeWindow num="1"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『学園・入り口』（夕方）******************************************************


[VOICE f="Chiho058"]
[OnName num="chiho"]
Keita-kun, you idiot …… I'm going to stress-eat all day today.
[cpg cn=true]

After school, I decided to leave the school, and took a day off from club activities.
[cpg]

He should have told me that he liked men. I'm sure that's why he's not interested in me.
[cpg]

If that's the case, I wonder if he was forcing himself to confess his feelings to me. He must have felt sorry for me because I looked like I was waiting for him ......
[cpg]

Thinking about it makes me sad. In times like this, I need to escape to something sweet.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//ＢＫ



At a convenience store, I fill my basket with a large amount of candy. An amount that I will never be able to eat, and may be left over till tomorrow, which would make me even more depressed, but I don't care about that anymore.
[cpg]

The sweets I eat while crying will surely comfort me ......
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[OnName num="takafumi"]
Is this a new flavored ice cream?
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Chiho059"]
[OnName num="chiho"]
Huh?
[cpg cn=true]

I was sitting on a bench in the city, trying to reach for my favorite ice cream, when someone peeked out from next to me in a strange manner.
[cpg]

Before I knew it, Takafumi was there. I didn't notice him at all, I guess he was following me ......
[cpg]

[OnName num="takafumi"]
I'm sure it's delicious, but I'm definitely a vanilla guy.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chiho060"]
[OnName num="chiho"]
Okay ……
[cpg cn=true]

[OnName num="takafumi"]
Vanilla also tastes different depending on the manufacturer. Do you wanna compare the tastes?
[cpg cn=true]






[OnName num="takafumi"]
Still you bought so much. Chiho, are you going to eat all of them by yourself?
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Chiho061"]
[OnName num="chiho"]
What does it matter to you? Leave me alone.
[cpg cn=true]

He took Keita away from me. And yet there he is, opening his ice cream.
[cpg]

[OnName num="takafumi"]
What, are you just going to sit here watching? Your ice cream's gonna melt.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Chiho062"]
[OnName num="chiho"]
Yeah.
[cpg cn=true]

I took the opened cup of ice cream that he handed to me. The ice cream was Takafumi's treat.
[cpg]

[OnName num="takafumi"]
I'd buy you more, but it looks like you're set for a while…….
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Chiho063"]
[OnName num="chiho"]
I told you to leave me alone.
[cpg cn=true]

I know I'm in a bad mood. But when I take a bite of ice cream, I can't help it .......
[cpg]

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

[OnName num="takafumi"]
You're back to your usual smile.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Chiho064"]
[OnName num="chiho"]
I can't help it ....... It's delicious.
[cpg cn=true]

[OnName num="takafumi"]
Yeah, that brand is pretty good. This one isn't half-bad either.
[cpg cn=true]

Takafumi was forcing me to do all this. I wanted to go home and eat it in my room ......
[cpg]

[OnName num="takafumi"]
Give me some of yours too. I told you we're going to compare.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Chiho065"]
[OnName num="chiho"]
Fine…… oh.
[cpg cn=true]

He thrusts the tiny spoon into the cup. It was forceful ……. I didn't know he could be like that.
[cpg]

He understands how I feel. That's why he's acting so cheerful.
[cpg]

[OnName num="takafumi"]
Ah, I knew this tasted better! Is it the price difference? I guess vanilla beans can be expensive or cheap.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Chiho066"]
[OnName num="chiho"]
...... Can I taste yours, too, Takafumi?
[cpg cn=true]

[OnName num="takafumi"]
Of course. I bought it with that intention.
[cpg cn=true]

A sweet taste spreads in my mouth. It's like all the bad things that happened are melting in my mouth.
[cpg]

If it weren't for Takafumi, I would have eaten this alone in silence. Now, I feel at peace.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Chiho067"]
[OnName num="chiho"]
Takafumi, you're amazing.
[cpg cn=true]

[OnName num="takafumi"]
Really? Why?
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Chiho068"]
[OnName num="chiho"]
But you're a little unfair.
[cpg cn=true]

[OnName num="takafumi"]
Which is it ……?
[cpg cn=true]

No matter how depressed the other person is, you can talk about ice cream and other silly things, and before you know it, you're comfortable with each other.
[cpg]

That's why Keita is also his best friend. And now I'm also calming down a little bit.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Chiho069"]
[OnName num="chiho"]
You have something to tell me, don't you?
[cpg cn=true]

[OnName num="takafumi"]
Oh, how did you know?
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Chiho070"]
[OnName num="chiho"]
Because it would be weird if you bought me an ice cream for no reason.
[cpg cn=true]

[OnName num="takafumi"]
What the hell, I must look cheap. So, are you ready to talk about it?
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Chiho071"]
[OnName num="chiho"]
...... Only a little.
[cpg cn=true]

[OnName num="takafumi"]
Haha. Well then, just listen to me for a little.
[cpg cn=true]

The story, as I had imagined, happened in the classroom.
[cpg]

[OnName num="takafumi"]
It was a misunderstanding. I can't say what it was about, but Keita needed to talk in private.
[cpg cn=true]

[free time=500]
[FG f="CHA01_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Chiho072"]
[OnName num="chiho"]
Oh……I'm sorry I made such a fuss.
[cpg cn=true]

[OnName num="takafumi"]
Don’t worry about me. I just wanted you to know that Keita is straight.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Chiho073"]
[OnName num="chiho"]
I see. That's right ……
[cpg cn=true]

The truth is, I was aware of it. If he liked Takafumi, he wouldn't have confessed to me in the first place.
[cpg]


[FACE method="change_4" pos="2/3"]
But then...... why won't he touch me? Why doesn't he want me?
[cpg]

[OnName num="takafumi"]
You're looking down again.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Chiho074"]
[OnName num="chiho"]
No, I was just remembering something...... Can you tell me what you talked about?
[cpg cn=true]

[OnName num="takafumi"]
Uhhh. It's kind of a sensitive topic, I'm not sure if it's okay to tell you.
[cpg cn=true]

[OnName num="takafumi"]
Keita probably only told me because he trusted me ……
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Chiho075"]
[OnName num="chiho"]
I'm sorry, you're right. It's something he wanted to keep secret.
[cpg cn=true]

I suppose there are things he wanted to keep from his own girlfriend. It makes me feel kind of sad.
[cpg]

[OnName num="takafumi"]
Yeah, I get you're feeling out of the loop. Maybe you even feel like he's being distant.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Chiho076"]
[OnName num="chiho"]
Takafumi, you really are amazing. It's like you understand how I feel.
[cpg cn=true]

[OnName num="takafumi"]
......? I'm not sure about that.
[cpg cn=true]

He looks like he really doesn't realize it. I wonder if he really doesn't realize it, or if he's doing it on purpose. Either way, I know he's trying to comfort me right now.
[cpg]

[OnName num="takafumi"]
It's a pretty private matter. Are you sure you want to hear it?
[cpg cn=true]


[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chiho077"]
[OnName num="chiho"]
Yes, it's something he opened up to you by himself right?
[cpg cn=true]

[OnName num="takafumi"]
I guess so. Well, it was about his confidence as a man.
[cpg cn=true]

Takafumi is still choosing his words. Was it that difficult to say? ......
[cpg]

[OnName num="takafumi"]
He's shy. There's a reason for that, or to put it simply, he has a complex.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
Takafumi looks like he's having a hard time saying it, but his face isn't red in the slightest. He chose his words carefully because he was concerned that I would be embarrassed.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Chiho078"]
[OnName num="chiho"]
You don't have to say it if you don't want to.
[cpg cn=true]


[OnName num="takafumi"]
Oh, don't get me wrong. It's not that I'm embarrassed, it's just that I don't know if it's okay to say it without permission.
[cpg cn=true]


[OnName num="takafumi"]
Basically, he told me why he couldn't get closer to you. That's how he feels.
[cpg cn=true]

[free time=500]
[FG f="CHA01_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Chiho079"]
[OnName num="chiho"]
I wish Keita had told me ……
[cpg cn=true]

[OnName num="takafumi"]
He couldn't and that's why we're in this situation. Try to understand how he feels.
[cpg cn=true]

Of course, I went out with him with the intention of doing so, and I knew that if I went out with Keita, these things might happen. But.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Chiho080"]
[OnName num="chiho"]
I wish he'd understand a girl's feelings too.
[cpg cn=true]

If I said this to Keita, it would only make him feel depressed. But Takafumi was different.
[cpg]

[OnName num="takafumi"]
I'm sorry. I'll tell him that, so don't lose hope just yet.
[cpg cn=true]


[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chiho081"]
[OnName num="chiho"]
I feel like you're a guardian or an older brother to him.
[cpg cn=true]

[OnName num="takafumi"]
I often think about that. I sometimes feel like Keita is my little brother.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Chiho082"]
[OnName num="chiho"]
But Takafumi, you seem to have the personality of a second child.
[cpg cn=true]

[OnName num="takafumi"]
Is that so? I don't know about that, but I'm an only child …….
[cpg cn=true]

[OnName num="takafumi"]
But, well, I'm like Keita's older brother.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Chiho083"]
[OnName num="chiho"]
Then I guess I'm his big sister.
[cpg cn=true]

[OnName num="takafumi"]
You might be right. Haha.
[cpg cn=true]

I was no longer in a bad mood. Takafumi and I have a normal conversation. In fact, it seems like we have become a lot closer than before.
[cpg]

[free time=500]
[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chiho084"]
[OnName num="chiho"]
And here I thought I had finally gotten past acting like siblings.
[cpg cn=true]

[OnName num="takafumi"]
…… Chiho ......Well, I know how you feel.
[cpg cn=true]

I understand and agree with Keita's feelings. But even so, I still want Keita to want me. Am I being too greedy to think this way?
[cpg]


[OnName num="takafumi"]
(I have to do something about these two love birds.)
[cpg cn=true]

[OnName num="takafumi"]
(But even if I explain and try to persuade her, it's only Keita who benefits.)
[cpg cn=true]

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chiho085"]
[OnName num="chiho"]
What's wrong? Takafumi, you looked a little mischievous.
[cpg cn=true]

[OnName num="takafumi"]
What? Really? Haha.
[cpg cn=true]

[OnName num="takafumi"]
(...... I wish I had a girlfriend like her.)
[cpg cn=true]



;//ＢＫ
;//[lbox off]
;//恵太に視点切り替わり

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・リビング』（昼）******************************************************

[OnName num="takafumi"]
I don't remember the scope of the exams being this wide-ranging……? Are we going to be okay?
[cpg cn=true]

It all started when Takafumi suggested we have a study session. Yet everyone came to my house.
[cpg]

My small room couldn't fit them all, so we decided to have the study group in the living room. There were seven of us.
[cpg]

[OnName num="keita"]
Don't say that, you're the host.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[VOICE f="Chiho086"]
[OnName num="chiho"]
The test is coming whether you like it or not.
[cpg cn=true]

So far, so good. We are classmates, so they will be able to study well. The problem starts here.

[cpg]


[free time=500]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Yuuri021"]
[OnName num="yuuri"]
...... It's quite difficult. Why are there so many symbols? I thought this was math……
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Haruka025"]
[OnName num="haruka"]
Oh yeah, I didn't even know they existed until last year.
[cpg cn=true]

Haruka and Yuri were in different grades than us. From Haruka's point of view, it was old material, and from Yuri's point of view, it's too advanced.
[cpg]

And there are two more. Two of my classmates, a couple, are here for some reason.
[cpg]

[OnName num="couple_woman"]
I can't remember this, it's too hard.
[cpg cn=true]

[OnName num="couple_man"]
Don't slack off now. You said we would play hard after the test.
[cpg cn=true]

[OnName num="couple_woman"]
I can play as hard as I want even if I slack off.
[cpg cn=true]

These two are a complete mystery to me. They seem to be acquainted with Takafumi, but they have no relationship with me or the other girls.
[cpg]

Furthermore, the couples have an aura that seems to keep everyone away from each other, so it doesn't feel like a study group anymore.
[cpg]

Furthermore, Haruka and Yuri are in different grades, so there are practically only three of us who can exchange knowledge.
[cpg]


[FACE method="bow_7" pos="1/3"]
[VOICE f="Chiho087"]
[OnName num="chiho"]
Takafumi, why did you chose this group?
[cpg cn=true]

[OnName num="takafumi"]
I was actually going to do it with just people from my class ……
[cpg cn=true]

[OnName num="keita"]
Oh right. Then, Yuri just barged in?
[cpg cn=true]


[FACE method="shake_3" pos="3/3"]
[VOICE f="Yuuri022"]
[OnName num="yuuri"]
That's rude. I'm earnestly trying to learn something.
[cpg cn=true]

I'm pretty sure she forced her way into the group. Since I've been going out with Chiho, Yuri's gaze has been kind of uncomfortable.
[cpg]

[OnName num="keita"]
Haruka. Why are you here?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Haruka026"]
[OnName num="haruka"]
I'm not busy either. I'm the only one who can help the younger students with their studies. Right Chiho?
[cpg cn=true]


[FACE method="shock_5" pos="1/3"]
[VOICE f="Chiho088"]
[OnName num="chiho"]
Yes.
[cpg cn=true]

In the case of Haruka, her gaze is cold towards Chiho, not me.
[cpg]

[OnName num="couple_woman"]
I'm tired. I want to release stress.
[cpg cn=true]

[OnName num="couple_man"]
I'm always willing to go out with you if you want to relieve stress. What kind of stress relief do you want?
[cpg cn=true]

[OnName num="couple_woman"]
Oh no, I can't tell you here.
[cpg cn=true]

Furthermore, these two are flirting a bit outside of the group circle ...... There's no way they're going to make any progress in their studies like this.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_4"  pos="4/5" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//背景再び表示


[FACE method="shake_7" pos="2/5"]
[VOICE f="Haruka027"]
[OnName num="haruka"]
This is what we did last year. I don't remember it being this difficult.
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]
[VOICE f="Yuuri023"]
[OnName num="yuuri"]
I thought we'd be able to count on you, Haruka.
[cpg cn=true]


[FACE method="bow_4" pos="2/5"]
[VOICE f="Haruka028"]
[OnName num="haruka"]
Honestly, I don't think any of us have grades good enough to teach others.
[cpg cn=true]

[OnName num="takafumi"]
I can't deny that ……
[cpg cn=true]

[free time=1000]
[WAIT time=1000]


Chiho and I did not enter into a conversation, but just silently solved the problems. Perhaps we were feeling the same thing.
[cpg]

[OnName num="couple_woman"]
I'm tired, hey, hang out with me.
[cpg cn=true]

[OnName num="couple_man"]
It tickles. You're a bad girl, I'll tickle you too.
[cpg cn=true]

[OnName num="couple_woman"]
Yeah, you can touch me, okay? Maybe I'll study better.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chiho089"]
[OnName num="chiho"]
......
[cpg cn=true]

[OnName num="keita"]
......
[cpg cn=true]

These two are trying to flirt, and are close in contact all the time.
[cpg]

Maybe Takafumi set this up for me, but it seemed a hard act to follow......
[cpg]

[free time=500]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chiho090"]
[OnName num="chiho"]
......Keita.
[cpg cn=true]

[OnName num="keita"]
What?
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Chiho091"]
[OnName num="chiho"]
We can't lose to them, can we?
[cpg cn=true]

[OnName num="keita"]
Well, yeah ……
[cpg cn=true]

I felt weird for being able to answer like that.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Chiho092"]
[OnName num="chiho"]
Shall we sit closer together ……?
[cpg cn=true]

[OnName num="keita"]
Yeah.
[cpg cn=true]

[free time=500]
[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=800]

Their displays of affection awaked something inside of me. I sat next to Chiho much closer than I'd normally do.
[cpg]

[OnName num="keita"]
......This might make it hard for Chiho to write anything down……?
[cpg cn=true]

Chiho is looking at me. We're so close together, we could kiss. Or rather, she is making a face as if she were waiting for a kiss.
[cpg]

And Haruka and Yuri are glancing at us. Takafumi just sits and stares.
[cpg]

[window target=false]
[transition target={true} rule="heart2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]
;//ＢＫ


So I ended up kissing her on the cheek, but I don't really remember what happened after that.
[cpg]

;//背景再び表示
[window target=false]
[transition target={true} rule="heart2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_5"  pos="4/5" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



[FACE method="shock_5" pos="4/5"]
[VOICE f="Yuuri024"]
[OnName num="yuuri"]
No, Senpai! She's a succubus, stay away from her!
[cpg cn=true]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Haruka029"]
[OnName num="haruka"]
Tch.......
[cpg cn=true]

[OnName num="takafumi"]
You guys don't even try to hide it……
[cpg cn=true]

I'm wondering what Haruka's irritation was aimed at. If it was for our flirting, then I felt sorry ......
[cpg]


[window target=false]
[transition target={true} rule="amamori1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・リビング』（夕方）******************************************************

[OnName num="takafumi"]
Alright, enough of this! We need to take a breather!
[cpg cn=true]

They started rifling through my video games and study time quickly turned into play time.
[cpg]

At first it was Takafumi and Haruka playing the games, but gradually the rest of us joined in.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/5" time=800]
[VOICE f="Haruka030"]
[OnName num="haruka"]
Go easy on me, Takafumi! Have some respect for your elders!
[cpg cn=true]


[FACE method="change_1" pos="2/5"]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Yuuri025"]
[OnName num="yuuri"]
...... Um, can I join you?
[cpg cn=true]

[OnName num="takafumi"]
Sure. You play any fighters?
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]
[VOICE f="Yuuri026"]
[OnName num="yuuri"]
Not really, it's just difficult to keep up with upperclassman material.
[cpg cn=true]

[OnName num="takafumi"]
Well, pick a character, I'll lend you my controller.
[cpg cn=true]

[OnName num="keita"]
Those are my controllers……
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Yuuri027"]
[OnName num="yuuri"]
Oh, this character is cool. It looks like Keita.
[cpg cn=true]

[free time=1000]
[WAIT time=2000]

After a while, we were getting tired of studying.
[cpg]

[OnName num="keita"]
We should take a break, too.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chiho093"]
[OnName num="chiho"]
……Yeah, I guess so.
[cpg cn=true]

But in spite of our laziness, I think it was a good atmosphere. Maybe that's why our concentration lasted longer than those three.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

Then night fell and it was time to finish up. I was on my way to see Takafumi off.
[cpg]

[OnName num="keita"]
Thank you, Takafumi.
[cpg cn=true]

[OnName num="takafumi"]
Hmm? What? I'm glad you lent me the place for the study group.
[cpg cn=true]

[OnName num="keita"]
You brought that couple over for a reason, right?
[cpg cn=true]

I felt sorry to call them "that couple", but I can't remember their names. I think they said each other's name a lot, but I wasn't paying attention.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Chiho094"]
[OnName num="chiho"]
I'd like to thank you as well. Thank you, Takafumi.
[cpg cn=true]

[OnName num="takafumi"]
…….
[cpg cn=true]

At that moment, he looked embarrassed and thrilled at the same time. I guess he felt embarrassed to be thanked for his efforts.
[cpg]

[OnName num="takafumi"]
It's no big deal. Just take it slow. I'll be rooting for you from the shadows.
[cpg cn=true]

[OnName num="keita"]
Yeah. Thank you so much.
[cpg cn=true]

I really enjoyed today. Chiho and I became closer. But I felt a strange sense of discomfort.
[cpg]

While I was thanking him, Takafumi seemed to be looking at Chiho.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="4/5" time=800]
[BG f="b_11_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//ＢＫ

In the meantime, the test we had been preparing for was over, and we entered the summer vacation.
[cpg]

It was summer, so Takafumi set us up to go to the beach and the pool.
[cpg]


[OnName num="keita"]
It's the ocean.
[cpg cn=true]

[FACE method="bow_1" pos="4/5"]
[VOICE f="Chiho095"]
[OnName num="chiho"]
It sure is.
[cpg cn=true]

[OnName num="keita"]
Takafumi is getting desperate these days, isn't he? It's like he's trying to hide his feelings …….
[cpg cn=true]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Chiho096"]
[OnName num="chiho"]
You think so?
[cpg cn=true]

Takafumi set us up on a double date today. But these two seemed more interested in each other than the scenery.
[cpg]

[OnName num="couple_woman"]
It's the ocean, the ocean! We're able to come to the beach together again this year, weren't we?
[cpg cn=true]

[OnName num="couple_man"]
Yes, we did. This is our third summer together.
[cpg cn=true]

The third time ……? How could they stay so into each other?
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_16_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


The ocean is basically a place to swim and have fun, but at this unintentional double date, we only learned that the grass is rather greener on the other side.
[cpg]

What might be perceived as normal skinship seemed strangely risque since we were all wearing swimsuits.
[cpg]

They went off into the ocean, using a big ball as a float.
[cpg]

I'm jealous of them, or maybe they don't care about us ...... or maybe they're doing this at Takafumi's request too?
[cpg]


[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_11_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『海』（昼）******************************************************

We didn't see them again for the rest of the day. I guess they moved things somewhere a little more private.
[cpg]


[VOICE f="Chiho097"]
[OnName num="chiho"]
......We should go too.
[cpg cn=true]


[OnName num="keita"]
What?
[cpg cn=true]

She was silently took me by the hand ......
[cpg]


;//●ＣＧエロ（千穂・主人公を誘うようなヒロイン：茂みの中）ev_04
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_04_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]


She sits down in a secluded spot. She looks up at me.
[cpg]

[VOICE f="Chiho098"]
[OnName num="chiho"]
This is the first time you've seen me in a bathing suit. Don't you feel anything?
[cpg cn=true]


[OnName num="keita"]
Yes ...... Well, I do.
[cpg cn=true]

;**【ＣＧ】 ev_04_a ***********************
[CG id=2 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Chiho099"]
[OnName num="chiho"]
Don't you want to do anything?
[cpg cn=true]


I didn't know what she meant.
[cpg]

I chickened out again.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ

[OnName num="keita"]
Come on. Let's go to the beach. They're waiting for us.
[cpg cn=true]


[VOICE f="Chiho100"]
[OnName num="chiho"]
......Yeah. You're right.
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[free time=1000]
[BG f="b_00_2.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・恵太の部屋』（昼）******************************************************

[OnName num="keita"]
So that happened.
[cpg cn=true]

[OnName num="takafumi"]
Yeah, yeah. You're making progress, so we'll see.
[cpg cn=true]

His response was a lot more half-hearted compared to before. I wasn't really in any position to complain.
[cpg]

But Takafumi's expression seemed a little cold.
[cpg]

[OnName num="takafumi"]
(Does this guy ...... even like Chiho? Or is he not listening to me?)
[cpg cn=true]

[OnName num="takafumi"]
(Besides, I also wonder about her side of the story.)
[cpg cn=true]


;//ＢＫ
;//千穂に視点切り替わり
;//[ChangeWindow num="1"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『飲食店』（昼）******************************************************

;//[lbox on]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chiho101"]
[OnName num="chiho"]
Ah, Takafumi. Over here.
[cpg cn=true]

[OnName num="takafumi"]
Sorry, I made you wait.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Chiho102"]
[OnName num="chiho"]
No, I'm sorry for calling out to you.
[cpg cn=true]

Maybe I've been talking to Takafumi too much. It's just that he really listens to me, so it's okay for me to rely on him a bit……
[cpg]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Chiho103"]
[OnName num="chiho"]
So, Keita is ……
[cpg cn=true]

The things I talk about don't change much from before. It was about Keita.
[cpg]

Since then, we've made progress little by little ......, but in the end, we hit wall when it comes to sex.
[cpg]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Chiho104"]
[OnName num="chiho"]
I feel love from Keita. But sometimes I wonder if he is actually serious about me.
[cpg cn=true]

[OnName num="takafumi"]
I guess ......."
[cpg cn=true]

[OnName num="takafumi"]
(I don't know how serious that guy is either.)
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Chiho105"]
[OnName num="chiho"]
Did you say something?
[cpg cn=true]

[OnName num="takafumi"]
No, nothing.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Chiho106"]
[OnName num="chiho"]
I was just wondering what I should do. I'm always asking you for advice, it's annoying, isn't it?
[cpg cn=true]


[OnName num="takafumi"]
No, no, no. I don't think so. Don't worry.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Chiho107"]
[OnName num="chiho"]
Thank you. You are so kind.
[cpg cn=true]

Takafumi looks a little startled. Then he turns his face away from me.
[cpg]

[OnName num="takafumi"]
(Oh no...... It's not enough to just cheer her up. Now I want her to be grateful to me ……)
[cpg cn=true]

[OnName num="takafumi"]
I'm sorry. I can't think of anything I can do about it right now.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Chiho108"]
[OnName num="chiho"]
I'm sorry for asking too much of you.
[cpg cn=true]

Takafumi stood up and patted me on the shoulder as I was still seated.
[cpg]

[OnName num="takafumi"]
But I know how to make you feel better.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Chiho109"]
[OnName num="chiho"]
What?
[cpg cn=true]

Takafumi took my hand.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Chiho110"]
[OnName num="chiho"]
Where are we going?
[cpg cn=true]

[OnName num="takafumi"]
It's going to be a fun place. I don't mean in a weird way.
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


We were headed for the arcade.
[cpg]

[OnName num="takafumi"]
You don't mind arcades, right?
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Chiho111"]
[OnName num="chiho"]
Not really……
[cpg cn=true]

[OnName num="takafumi"]
It's not too loud here, so I thought it'd be easier to acclimate.
[cpg cn=true]

At first I was a little nervous because I knew he was paying attention to how I felt.
[cpg]

But then we went to karaoke, window-shopped a bit, and ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="slant2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="slant2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

Eventually, I began to forget my worries and enjoyed myself to the fullest. By the end of the evening, I was feeling completely fine.
[cpg]

[OnName num="takafumi"]
How are you feeling? You feel a little better?
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Chiho112"]
[OnName num="chiho"]
Yeah!
[cpg cn=true]

Takafumi didn't solve any of my problems, but he did make me feel like I didn't have to worry about them.
[cpg]

[FACE method="change_1" pos="2/3"]

And it's clearing my mind. That was a fact, but is this ......
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Chiho113"]
[OnName num="chiho"]
Somehow, it feels like we're on a date.
[cpg cn=true]

[OnName num="takafumi"]
Huh?
[cpg cn=true]

I shouldn't have said that. I'm dating Keita-kun, and even though we have our problems, we're in love with each other!
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Chiho114"]
[OnName num="chiho"]
Oh no, I didn't mean for things to get weird……
[cpg cn=true]

[OnName num="takafumi"]
…….
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

Takafumi stares at me. I'm sure he's disappointed in me, and it's embarrassing.
[cpg]

[OnName num="takafumi"]
(Maybe I have a chance.)
[cpg cn=true]

[OnName num="takafumi"]
Haha. You're funny, Chiho.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Chiho115"]
[OnName num="chiho"]
Ugh, don't laugh.
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//ＢＫ

We were about to leave the store as we decided to go home.
[cpg]

[FACE method="shock_5" pos="2/3"]
Without saying a word, Takafumi tried to pay first, and I hurried to stop him.
[cpg]

[OnName num="takafumi"]
Come on, dummy. Let a guy pay for you in this kind of situation.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Chiho116"]
[OnName num="chiho"]
But ……
[cpg cn=true]

[OnName num="takafumi"]
You can use your money on a date with Keita, okay?
[cpg cn=true]

I usually split the bill since we were students, but Takafumi paid more.
[cpg]

[OnName num="takafumi"]
I'm fine with it as long as you're having fun.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Chiho117"]
[OnName num="chiho"]
……Yeah, really, thank you.
[cpg cn=true]

[OnName num="takafumi"]
If you can keep smiling for even one second longer ..... Then that's all that matters.
[cpg cn=true]

After saying that much, Takafumi seemed stuck. I wondered why.
[cpg]

[OnName num="takafumi"]
(What was I thinking? That was going too far.)
[cpg cn=true]

;//[lbox off]


;//ＢＫ

;//恵太に視点切り替わり
;//[ChangeWindow num="0"]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

I woke up in my usual room and went to school as usual. The days went by without any problems, or so I thought.
[cpg]

The problem happened on this day today. It's the one day during the summer vacation that I have to go to school.
[cpg]

[OnName num="keita"]
Oh, good morning. Takafumi ……
[cpg cn=true]

[OnName num="takafumi"]
What's wrong? You're walking funny.
[cpg cn=true]

[OnName num="keita"]
No…just…my butt hurts.
[cpg cn=true]

[OnName num="takafumi"]
Did you finally cross the line? Who were you with last night?
[cpg cn=true]

[OnName num="keita"]
Nooo. Come on, man.
[cpg cn=true]

The usual jokes, but when he sees the wounds on my face, he looked concerned.
[cpg]

[OnName num="takafumi"]
What's happened with your face?
[cpg cn=true]

[OnName num="keita"]
Well, actually ……
[cpg cn=true]

I was on my way to school when I bumped into a student who had a bad attitude. I apologized, but he hit me, and instead of getting into a fight, I let him...... That was typical of me.
[cpg]

[OnName num="takafumi"]
Oh ...... are you okay?
[cpg cn=true]

[OnName num="keita"]
Yeah. I'm used to losing fights.
[cpg cn=true]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

Generally speaking, a one-day commute to school will feel fresh and short. It should be more memorable than the usual school day.
[cpg]

But I don't remember much of what happened at the school that day. I remember more about what happened after I got out of the school.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="4/5" time=800]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

[OnName num="eiji"]
You, from this morning ……
[cpg cn=true]

[OnName num="keita"]
Uh oh
[cpg cn=true]

[OnName num="eiji"]
What? You got something to say?
[cpg cn=true]

On my way home, I got tangled up with that delinquent student again. Somehow, Haruka was there too.
[cpg]

[FACE method="shake_4" pos="2/5"]
[VOICE f="Haruka031"]
[OnName num="haruka"]
Stop, please. I know this guy so just leave him alone.
[cpg cn=true]

[FO pos="4/5" time=1000]

[FG f="quake_b_03_3.ui" method="stop" pos="5/9" time=1]

[OnName num="eiji"]
I don't give a damn. Get outta my way.
[cpg cn=true]

[FACE method="quake" pos="5/9"]

He grabs me by the chest again. Well, I guess I'm getting beat up again……Takafumi's going to worry about me.
[cpg]

[FO pos="5/9" time=1]

Chiho runs away. That was the right choice, I'd hate for her to get involved……
[cpg]

[OnName num="eiji"]
Looks like I dropped my wallet when you bumped into me. Now I can't find it.
[cpg cn=true]

[OnName num="keita"]
You didn't say anything about that at the time.
[cpg cn=true]

[OnName num="eiji"]
Yeah, well I just remembered.
[cpg cn=true]

It was ridiculous, he just wanted someone to vent his frustrations on. He doesn't care who he hits as long as he hits someone ......
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


I struggled, trying to keep him from hitting me again when I see Chiho come running from afar.
[cpg]


[transition target={true} rule="bakuhatu2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/5" time=800]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_t1"]
;//背景を再び表示

[OnName num="keita"]
Chiho!? No, don't come back ......
[cpg cn=true]

I soon found out why. Takafumi was running alongside with her. Apparently she'd gone to ask Takafumi for help.
[cpg]

I feel pathetic.
[cpg]

[OnName num="takafumi"]
Let's keep things civil. Fighting here isn't going to solve anything.
[cpg cn=true]

[OnName num="eiji"]
Who the hell are you supposed to be?
[cpg cn=true]

[OnName num="takafumi"]
Keita said he apologized. That should be enough.
[cpg cn=true]

[OnName num="eiji"]
This is none of your business!
[cpg cn=true]

[OnName num="keita"]
Whoa!
[cpg cn=true]

The target changed from me to Takafumi. They sized each other up.
[cpg]

[OnName num="takafumi"]
Tch.
[cpg cn=true]

[SE f="se008"]
;//【ＳＥ】『打撃音』ドカッ

They gradually closed the distance and fists began to fly.
[cpg]


[FACE method="shake_4" pos="2/5"]
[VOICE f="Chiho118"]
[OnName num="chiho"]
What should we do?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="4/5" time=800]
[VOICE f="Haruka032"]
[OnName num="haruka"]
Should I call the police ......?
[cpg cn=true]

[OnName num="keita"]
No, I'll handle it.
[cpg cn=true]

[free time=1000]

I'm already bruised all over. My small pride was stimulated by that ......No, that wasn't it.
[cpg]

It was the way Chiho looked at Takafumi fighting. Unable to stand by doing nothing, I found a branch nearby and swung it at the delinquent.
[cpg]

[OnName num="eiji"]
Argh!......you little-
[cpg cn=true]

As weak as I was, I couldn't do much damage. But that's okay, at least he turned changed his target to me.
[cpg]

He pulls out a metal stick…where was he hiding it? It looked like a police officer's baton. One good hit from that and I'd end up in the hospital.
[cpg]

[OnName num="takafumi"]
Watch out!
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『強い打撃音』バキッ


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]
;//ＢＫ


I was prepared for that too. Maybe I wasn't, but it should have been me.
[cpg]


;//千穂に視点切り替わり
;//[ChangeWindow num="1"]

;//[lbox on]

Here's what happened a few days later.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_12_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『病室』（昼）******************************************************

[FACE method="shake_7" pos="2/3"]
[VOICE f="Chiho119"]
[OnName num="chiho"]
Are you sure you're doing alright?
[cpg cn=true]

[OnName num="takafumi"]
I'm fine, just bored outta my skull. I can't do anything.
[cpg cn=true]

Takafumi and I were chatting as I swapped out the flowers I had brought to his hospital room.
[cpg]

Takafumi had been hospitalized, having taken multiple hits to his arm and leg.
[cpg]

[OnName num="takafumi"]
Man, they're making a big deal out of nothing. I can't believe I'm being hospitalized over a fracture.
[cpg cn=true]

[free time=500]
[FG f="CHA01_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Chiho120"]
[OnName num="chiho"]
A fracture sounds like a big deal to me...
[cpg cn=true]

[OnName num="takafumi"]
They said it would only take a month to heal. That's not that bad, I don't think I should be stuck in here.
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Chiho121"]
[OnName num="chiho"]
…… Please, just rest.
[cpg cn=true]

[OnName num="takafumi"]
By the way ……
[cpg cn=true]

Takafumi is looking around. He is probably looking for Keita.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Chiho122"]
[OnName num="chiho"]
Keita went to get a drink.
[cpg cn=true]

[OnName num="takafumi"]
He didn't have to do that. You too, Chiho.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Chiho123"]
[OnName num="chiho"]
I do, of course I do ……
[cpg cn=true]


[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Chiho124"]
[OnName num="chiho"]
I'm sorry …… I panicked and the first thing that came to mind was you.
[cpg cn=true]

[OnName num="takafumi"]
Don't look at me like that. Hey, look at me.
[cpg cn=true]


[FACE method="shock_8" pos="2/3"]
[VOICE f="Chiho125"]
[OnName num="chiho"]
I'm sorry I hurt you again by relying on you.
[cpg cn=true]

I should have asked a nearby adult for help. If I had time to call Takafumi, I could have gone to the police station.
[cpg]

I'm getting to the point where I'm constantly relying on him ......
[cpg]

[OnName num="takafumi"]
I'm glad. I'm glad you thought of me when you were in trouble.
[cpg cn=true]


[FACE method="shake_8" pos="2/3"]
[VOICE f="Chiho126"]
[OnName num="chiho"]
But ……
[cpg cn=true]

[OnName num="takafumi"]
This doesn't even count as injured, else they'd be giving me a medal.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Chiho127"]
[OnName num="chiho"]
You're too good-natured.
[cpg cn=true]

[OnName num="takafumi"]
Well, I'll take those words instead of a medal then. My injury will be a sign of good-nature.
[cpg cn=true]

Every time, he tries so hard to make me feel better. But that makes me feel like thanking him even more.
[cpg]

[free time=500]
[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chiho128"]
[OnName num="chiho"]
I'll be back again. I'll come every day.
[cpg cn=true]

[OnName num="takafumi"]
Well, I guess I won't be bored.
[cpg cn=true]

[OnName num="takafumi"]
But I don't need any more gifts. It's too much of a burden on you.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Chiho129"]
[OnName num="chiho"]
No, it's not. I want to thank you more, Takafumi.
[cpg cn=true]

There was silence for a moment. I didn't just come to visit him today.
[cpg]

Seeing my gloomy expression, Takafumi looked concerned. And then, for the hundredth time, I asked him for advice.
[cpg]


[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Chiho130"]
[OnName num="chiho"]
Actually......the other day, Keita told me that he ...... couldn't do it.
[cpg cn=true]



;//ＢＫ

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]

Takafumi listened to me without saying a word. I told him everything.
[cpg]

I wanted to cry. I knew it would bother Takafumi, but I had to tell someone.
[cpg]


;//ここから回想

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_vs"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

The other day, at Keita's house. We've had many house dates together, but that day the atmosphere was great.
[cpg]

The kiss was the best I've ever had. But it wouldn't develop from there.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[OnName num="keita"]
I'm sorry ...... I can't do it. I can't ……
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Chiho131"]
[OnName num="chiho"]
......I see. You can't do it.
[cpg cn=true]

It was the clearest rejection I had ever received. It was just decorated with "I'm sorry".
[cpg]

[OnName num="keita"]
I'm sure we are having the most fun with our current distance. I think we'll enjoy being around each other.
[cpg cn=true]


He won't do anything to me. He won't respond to me.
[cpg]

But still, I kept trying. It took a lot of courage but I was afraid that if I missed this opportunity, we might not be able to be together forever.
[cpg]


[FO pos="2/3" time=500]
[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chiho132"]
[OnName num="chiho"]
I don't want to wait any longer.
[cpg cn=true]

But his next words pierced into my heart deeply …..
[cpg]

[OnName num="keita"]
Chiho, are you that frustrated?
[cpg cn=true]


[FO pos="2/3" time=500]
[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Chiho133"]
[OnName num="chiho"]
…!
[cpg cn=true]

I was having a hard time holding back my tears at that point. Is that how Keita saw me?
[cpg]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Chiho134"]
[OnName num="chiho"]
I'm sorry. I guess we can take it slow. I don't know what came over me.
[cpg cn=true]


[FACE method="shock_1" pos="2/3"]
[VOICE f="Chiho135"]
[OnName num="chiho"]
I feel like an idiot ...... for coming on to you like this, I'm so sorry.
[cpg cn=true]

I couldn't stop myself anymore. The words kept pouring out.
[cpg]

This affection that I had nurtured for so long crumbled away with every word. Try as I might to hold on, the pieces slipped away.
[cpg]

[OnName num="keita"]
Let's go at our own pace ......I don't want you to rush into anything.
[cpg cn=true]

Rushing? Who was rushing into anything?
[cpg]

I guess our pace is his pace.
[cpg]

I didn't feel anger, just bitterness. And yet, I still felt that I could hold on.
[cpg]


;//ここまで回想
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_8"  pos="2/3" time=1]
[BG f="b_12_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『病室』（昼）******************************************************

[OnName num="takafumi"]
.....That's rough.
[cpg cn=true]


[FACE method="shake_8" pos="2/3"]
[VOICE f="Chiho136"]
[OnName num="chiho"]
I'm sorry, I didn't mean to talk so much.
[cpg cn=true]

I couldn't cry in front of Keita, but it's strange. I can cry in front of Takafumi ......
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Chiho137"]
[OnName num="chiho"]
I'm sure it's because I'm a bad girl.
[cpg cn=true]

[OnName num="takafumi"]
...... Why would you say that? No matter how you think about it, it's Keita's fault …….
[cpg cn=true]

Takafumi was silently angry. I don't think I've ever seen a face like this before.
[cpg]


[FACE method="shock_8" pos="2/3"]
[VOICE f="Chiho138"]
[OnName num="chiho"]
I'm a terrible woman, aren't I? Am I trying to get sympathy by talking like this?
[cpg cn=true]

[OnName num="takafumi"]
Don't be silly. Calm down, I know your intentions are pure.
[cpg cn=true]

[OnName num="takafumi"]
I know it's hard to trust anybody right now, but believe me. It's not your fault.
[cpg cn=true]

Tears began to trickle down. Takafumi didn't tell me not to cry.
[cpg]

[FACE method="change_8" pos="2/3"]
[VOICE f="Chiho139"]
[OnName num="chiho"]
I don't know what to do anymore.
[cpg cn=true]

[OnName num="takafumi"]
…… I bet it's even sadder because you've loved him for so long.
[cpg cn=true]


[FACE method="bow_8" pos="2/3"]
[VOICE f="Chiho140"]
[OnName num="chiho"]
Yeah, that's why I don't want to let it go ..... Not like this.
[cpg cn=true]

[OnName num="takafumi"]
Let it go, look at yourself......He's the one making you cry.
[cpg cn=true]

[FACE method="shake_8" pos="2/3"]
[VOICE f="Chiho141"]
[OnName num="chiho"]
I'm sorry. I'm sorry. I'm no good. I can't do this ……
[cpg cn=true]

I cried and cried. Takafumi was silent and looked at me.
[cpg]

[OnName num="takafumi"]
I wish I could comfort you, but I can't……
[cpg cn=true]

Is it because he's injured? Or is it because he is respecting Keita?
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="enn2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



By the time I stopped crying, Takafumi looked like he had made up his mind about something. It wasn't a gaze of pity.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Chiho142"]
[OnName num="chiho"]
I'm really sorry. I'm…...horrible.
[cpg cn=true]

[OnName num="takafumi"]
Don't say that. ...... Don't beat yourself up like that. You didn't do anything wrong.
[cpg cn=true]


[FO pos="2/3" time=500]
[FG f="CHA01_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Chiho143"]
[OnName num="chiho"]
If I didn't do anything wrong, you wouldn't be in this situation.
[cpg cn=true]

[OnName num="takafumi"]
It's not your fault! Who's blaming you? Certainly not me.
[cpg cn=true]

He looked like he was about to cry a little too.
[cpg]


;//移植のためシーンをカットしています

;//恵太に視点切り替わり
;//[ChangeWindow num="0"]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_du"]
[WAIT time=100]
;//【ＢＧ】『病室』（昼）******************************************************

[OnName num="keita"]
I'm sorry I'm late ……
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Chiho144"]
[OnName num="chiho"]
Oh, welcome back.
[cpg cn=true]

Bad things happen in succession. Takafumi was hospitalized because of me, and even the visit didn't end up being a happy event.
[cpg]

I'd left to get Takafumi a drink, but the vending machine was broken, and because of that the kiosk was also sold out, so I had to go to a convenience store a little farther away.
[cpg]

[OnName num="keita"]
The vending machine at the kiosk is broken. I can't believe how far I had to go just to get a drink.
[cpg cn=true]

[OnName num="takafumi"]
Sorry about that, buddy.
[cpg cn=true]

For a moment, Takafumi looked panicked. Maybe it was my imagination.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//ＢＫ

;//千穂に視点切り替わり
;//[ChangeWindow num="1"]
;//[lbox on]
A few more days passed.
[cpg]


[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_12_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『病室』（夕方）******************************************************

My mind was occupied with what had happened the other day. I didn't know what kind of feelings to have.
[cpg]

I wanted to talk to Takafumi again, alone. It wasn't because I was expecting something.
[cpg]

[OnName num="takafumi"]
Do you think that was okay?
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Chiho145"]
[OnName num="chiho"]
Yeah ...... I don't think he suspects anything.
[cpg cn=true]

I told Keita that I wanted him to buy me cream puffs ….. and we were alone together again.
[cpg]

[OnName num="takafumi"]
I'm sorry about ...... the other day.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Chiho146"]
[OnName num="chiho"]
I'm sorry too.
[cpg cn=true]

Let's not go any further. That should be the conclusion. I wanted to be alone with him just to say that.
[cpg]

[FO pos="2/3" time=500]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Chiho147"]
[OnName num="chiho"]
Since that day, I've been feeling strange.
[cpg cn=true]


I shouldn't say anything. I know.
[cpg]


Takafumi already knows what's going on. He can see that I'm still dragging that day around and can't put an end to it once and for all.
[cpg]

I wonder if Takafumi feels the same as me?
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//ＢＫ

We kissed. I didn't feel as guilty as I thought, and that made me a different sense of guilt.
[cpg]

Rather than feeling guilty for Keita, I feel that the guilt towards myself is deepening, and I can't help but stay stuck in this feeling.
[cpg]


;//視点切り替わり
;//[ChangeWindow num="0"]
;//[lbox off]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

I had come to buy cream puffs for Takafumi ……
[cpg]


[OnName num="keita"]
Wow, it's so crowded.
[cpg cn=true]


I had heard that the store is not far from the hospital. It has a good reputation and is always crowded. But, I didn't expect this.
[cpg]

If I had to stand in line for this, it would take more than an hour.
[cpg]

Takafumi said he wanted to eat cream puffs, but what should I do …
[cpg]


;//■選択肢

[switch]
[case "I'll stand in line and buy some."]
	[swap]
	[jump target="*select03_1"]
[case "I'll get something else."]
	[swap]
	[jump target="*select03_2"]
[endswitch]

;//■選択肢
1. I'll stand in line and buy some.
2. I'll get something else.

;//-------------------------------------------------------------------------
;//２、他の物にする　の場合

*select03_2|Chiho, my childhood friend

[stflag hiroin1sl = 1]

I felt a bit bad for Takafumi, but I'll get something else. I wouldn't want to take too long.
[cpg]


;//ＢＫ

I buy a fruit basket at a nearby supermarket and head back to the hospital.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『病室』（夕方）******************************************************



[OnName num="keita"]
I'm back.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/5" time=800]

[VOICE f="Chiho148"]
[OnName num="chiho"]
…!!
[cpg cn=true]


[OnName num="takafumi"]
...... Oh, hey. Welcome back.
[cpg cn=true]

I returned to the hospital room and Takafumi and Chiho turned their heads in surprise.
[cpg]

The distance between the two of them seems strangely close. On top of that, they seemed slightly panicked.
[cpg]

[OnName num="keita"]
What's wrong? Did something happen.
[cpg cn=true]


[OnName num="takafumi"]
No, nothing.
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
I looked at Chiho and she smiled as usual and said, "Welcome back."
[cpg]

It seems like it was all in my head.
[cpg]

I'm glad to hear that. As I'd hoped, they were pretty friendly with each other, so they don't seem to have any trouble finding something to talk about.
[cpg]

[OnName num="keita"]
Oh, that's right. I'm sorry ….. the store was really crowded. I couldn't buy cream puffs.
[cpg cn=true]


[OnName num="takafumi"]
No, it's okay. Don't worry about it. Sorry for the trouble.
[cpg cn=true]


[OnName num="keita"]
No, not at all!
[cpg cn=true]

After that, the three of us chatted for a little while. We told him we would come back to visit again, and we left the hospital.
[cpg]

;//[ChangeWindow num="1"]
;//[lbox on]

[jump target="*select03_3"]

;//合流３へ
;//-------------------------------------------------------------------------
;//１、並んで買う　の場合

*select03_1|Chiho, my childhood friend

[OnName num="keita"]
I guess I'll get in line.
[cpg cn=true]

Takafumi is in the hospital because of me, so I'll buy him something he wants to eat.
[cpg]

Considering that it's for my best friend, this is nothing.
[cpg]

They're there without me, but I'm sure those two will be fine and have topics to talk about, so it won't be a problem.
[cpg]



;//ＢＫ

;//背景再び表示
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_12_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『病室』（夕方）******************************************************


[OnName num="takafumi"]
Hey ...... Chiho.
[cpg cn=true]



After giving him a kiss, Takafumi stopped me.
[cpg]

[OnName num="takafumi"]
The only way to get him in the mood is to do it this way …….
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Chiho149"]
[OnName num="chiho"]
What way?
[cpg cn=true]

[OnName num="takafumi"]
Why don't you use me as a test subject, like you're doing now ….. and hone your techniques to make him fall in love with you?
[cpg cn=true]


[OnName num="takafumi"]
Then, you know, even if he's shy, you can maybe ……
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Chiho150"]
[OnName num="chiho"]
Yeah, you're right.
[cpg cn=true]

It might work, but I don't believe it's the only way.
[cpg]

This reason is just a front. He's trying to get rid of my guilt.
[cpg]

[FO pos="2/3" time=500]
[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chiho151"]
[OnName num="chiho"]
If I get better at kissing, I wonder if Keita will want me.
[cpg cn=true]

[OnName num="takafumi"]
Oh, I bet he will …….
[cpg cn=true]


I nodded. I take another step forward, feeling that I can no longer pull back.
[cpg]

;//移植のためシーンをカットしています

;//ＢＫ

;//恵太に視点切り替わり
;//[ChangeWindow num="0"]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_12_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『病室』（夕方）******************************************************

[OnName num="keita"]
Hey ...... you two, what are you doing?
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Chiho152"]
[OnName num="chiho"]
!
[cpg cn=true]

When I returned to the hospital room, the two of them were strangely close to each other. It was so close that I wondered if they were going to kiss ……
[cpg]

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/5" time=800]

But as soon as they noticed me, they immediately moved away from each other. It seemed like they were doing something inappropriate.
[cpg]


[FACE method="shake_4" pos="2/5"]
[VOICE f="Chiho153"]
[OnName num="chiho"]
It's nothing ……
[cpg cn=true]

[OnName num="keita"]
What were you doing? What were you doing that you wanted to hide from me?
[cpg cn=true]

[OnName num="takafumi"]
…….
[cpg cn=true]

Chiho tries to steer away from the topic, but Takafumi doesn't say anything. My anxiety is growing and growing.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="kosuri5.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kosuri5.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

The atmosphere on the way home after leaving the hospital was heavy.
[cpg]

[OnName num="keita"]
Look. This is the second time we've visited Takafumi, right?
[cpg cn=true]

[OnName num="keita"]
Let's go somewhere else together next time.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Chiho154"]
[OnName num="chiho"]
……
[cpg cn=true]

[OnName num="keita"]
We're a couple.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Chiho155"]
[OnName num="chiho"]
(We're a couple, huh? When I came on to you, you refused …… I also thought of you as my lover, but …….)
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Chiho156"]
[OnName num="chiho"]
(But ...... that's terrible, Keita.)
[cpg cn=true]



[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
;//ＢＫ

;//千穂に視点切り替わり
;//[ChangeWindow num="1"]
;//[lbox on]

The moment when Keita was manly was really for a short time.
[cpg]

Since then, he hasn't really expressed a want for me. So, I don't press him as much anymore.
[cpg]

I wonder if it is really Keita who would soothe my lust.
[cpg]

There is no doubt that there is a gaping hole in my heart, but who is going to fill it?
[cpg]



;//合流３へ
;//-------------------------------------------------------------------------
;//合流３
*select03_3|Chiho, my childhood friend


;//[ChangeWindow num="1"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya4.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya4.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

A few days later.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p2_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_12_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h3"]
[WAIT time=100]
;//【ＢＧ】『病室』（夕方）******************************************************



[FACE method="shake_4" pos="2/3"]
[VOICE f="Chiho157"]
[OnName num="chiho"]
This vase has a crack at the bottom ……
[cpg cn=true]

Water is leaking out. No matter how much water you pour into a cracked vase, it will never fill.
[cpg]

Then the flower will wither. Sometimes it is not enough to be just loved.
[cpg]

[OnName num="takafumi"]
Is that right ……? Then we'll have to replace it……
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Chiho158"]
[OnName num="chiho"]
You're right.
[cpg cn=true]

I was becoming interested in Takafumi. Somehow, he had become more than just friends.
[cpg]



[OnName num="takafumi"]
Chiho, I thought you were going somewhere today.
[cpg cn=true]


[FO pos="2/3" time=500]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Chiho159"]
[OnName num="chiho"]
Yes, it's fine ……
[cpg cn=true]

By training with Takafumi, Keita might seriously love me ......
[cpg]

I still believe that. I still believe it will be the best ending.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ


;//恵太に視点切り替わり
;//[ChangeWindow num="0"]



[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

…… Somehow, Chiho's behavior has changed. Specifically, she stopped coming on to me so much.
[cpg]

I don't know what might have happened, but I'm not going to pursue it. For me, I thought it was good that this distance was maintained.
[cpg]

I guess she has calmed down since then and is respecting my wishes. Things are better than before.
[cpg]

We can continue to slowly close the distance between us. If we both settle down at this distance, that's fine as well.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_16_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_t2"]
[WAIT time=100]
;//ＢＫ

;//千穂に視点切り替わり
;//[ChangeWindow num="1"]


[VOICE f="Chiho160"]
[OnName num="chiho"]
Wow ...... Your house is huge.
[cpg cn=true]

[OnName num="takafumi"]
It's got lots of rooms as well. Come in.
[cpg cn=true]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_15_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『隆文の部屋』（夕方）******************************************************
;//[lbox on]


The day before the last day of summer vacation. Takafumi's injury had finally healed, and I was invited to his house.
[cpg]

[OnName num="takafumi"]
This is my room.
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Chiho161"]
[OnName num="chiho"]
Okay.
[cpg cn=true]

Without hesitation, I stepped into his room. So this is Takafumi's room ......
[cpg]

I didn't come here with half-hearted intentions either. And Takafumi is no different.
[cpg]


[window target=false]
[transition target={true} rule="hiraki.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hiraki.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_15_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//ＢＫ

;//背景再び表示


Somehow, he is different from usual today.
[cpg]

The kind Takafumi is here as usual. Today's smile is also a familiar one.
[cpg]

[OnName num="takafumi"]
I'm sorry. Let me apologize first.
[cpg cn=true]


But ...... I could see a different kind of emotion than usual.
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="Chiho162"]
[OnName num="chiho"]
What?
[cpg cn=true]

[OnName num="takafumi"]
You know me, I'm not my usual self.
[cpg cn=true]


[VOICE f="Chiho163"]
[OnName num="chiho"]
……Yeah.
[cpg cn=true]

[OnName num="takafumi"]
If we do this, I'm not stopping. Not with you.
[cpg cn=true]

[OnName num="takafumi"]
I'm going to make you mine...
[cpg cn=true]

I didn't know how to reply. But Takafumi knows that.
[cpg]

He kisses me to keep me from saying anything.
[cpg]

[FO pos="2/3" time=500]
[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Chiho164"]
[OnName num="chiho"]
…..
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
;//ＢＫ

I spent the night at his house.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_15_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_tl"]
[WAIT time=100]
;//【ＢＧ】『隆文の部屋』（昼）******************************************************

;//[lbox on]

[VOICE f="Chiho165"]
[OnName num="chiho"]
It wasn't a ...... dream.
[cpg cn=true]

Waking up in the morning, I put it into words as if to make sure it was reality. Maybe it would have been better if it had been a dream. If only I could go back to that day when Takafumi was injured. I sometimes wish I could go back.
[cpg]

It feels like the things that have happened lately are overwriting the emotions I had in the past.
[cpg]

Today is the best day of my life. The fact that I can say that bothers me even more.
[cpg]

Takafumi is kind and dependable. I thought I knew that already, but yesterday made me realize it all over again.
[cpg]

……My heart aches, terribly.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_15_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//ＢＫ

;//背景再び表示


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chiho166"]
[OnName num="chiho"]
Oh. Are you awake?
[cpg cn=true]

[OnName num="takafumi"]
I thought I ...... smelled something nice.
[cpg cn=true]

I was making a slightly late lunch. He woke up just when it was ready.
[cpg]

[OnName num="takafumi"]
You even made me lunch ...... I'm so hungry.
[cpg cn=true]


Over a late lunch, he told me about what was to come. I hadn't imagined it either. The future.
[cpg]

[OnName num="takafumi"]
Hey, you want to stay over again?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Chiho167"]
[OnName num="chiho"]
We agreed on one night……
[cpg cn=true]

[OnName num="takafumi"]
Yeah, but it seems like my parents are coming home a little later than expected.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Chiho168"]
[OnName num="chiho"]
But I have plans ……
[cpg cn=true]

[OnName num="takafumi"]
Do you?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Chiho169"]
[OnName num="chiho"]
…… Hold on a second.
[cpg cn=true]

I check my cell phone. I had received a call from Keita, saying that he wanted to see me, even if it was only for a little while.
[cpg]

But that was yesterday, and of course I couldn't respond. He had written in his e-mail, "See you in the new semester."
[cpg]

It seems I didn't have plans after all. I didn't know what to do.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Chiho170"]
[OnName num="chiho"]
But it's a new semester tomorrow ……
[cpg cn=true]

[OnName num="takafumi"]
I'm sure you won't be too late. You just gotta get home by then. You brought your uniform, right?
[cpg cn=true]


It's true that I brought my school uniform just in case. But I didn't bring it with that intention ......
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Chiho171"]
[OnName num="chiho"]
……
[cpg cn=true]

[OnName num="takafumi"]
Are you having regrets?
[cpg cn=true]


I tried to think of other reasons in my head, but they didn't come together. I couldn't even convince Takafumi with that.
[cpg]


Keita has also asked me to meet him. If I accept his invitation here, it will be like I am ranking them.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Chiho172"]
[OnName num="chiho"]
Okay ...... just one more day ……
[cpg cn=true]

Takafumi created the opportunity. If I told him I didn't have any plans tomorrow, he might not even let me go.
[cpg]

So, it's me who is to blame. I'm with Takafumi of my own will.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

;//移植のためシーンをカットしています

The balance in my mind is completely tilted.
[cpg]

I love Takafumi. I want to dote on him more than Keita.
[cpg]

Of course, I also love Keita, not just as a friend …… so there is no way I would ever break up with him. But....
[cpg]

I have found someone more important than my boyfriend.
[cpg]


;//恵太に視点切り替わり
;//[ChangeWindow num="0"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_du"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

The long-awaited new semester. I haven't been able to see Chiho much lately, but it's going to be different from today.
[cpg]

I can see her every weekday ….. I was going to go to school with her, so I drop by her house and ring the doorbell.
[cpg]

[OnName num="chiho's_mother"]
Yes, yes, who is it? ...... Ah, Keita.'	“是的，是的？……啊，惠太。”
Um, is Chiho there?"
[cpg cn=true]

[OnName num="keita"]
Well, she stayed at a friend's house and went straight to school from there.
[cpg cn=true]

[OnName num="chiho's_mother"]
What?
[cpg cn=true]

[OnName num="keita"]
What was that? Who is this friend? I don't think so, but what if it was a male friend …… no, no, it can't be.
[cpg cn=true]

She would never normally do something like this.
[cpg]

[OnName num="chiho's_mother"]
Oh, I see …… Excuse me.
[cpg cn=true]

[OnName num="keita"]
I gave up and headed to school alone. On the way, I bumped into Takafumi.
[cpg cn=true]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

Keita. Long time no see.
[cpg]

[OnName num="takafumi"]
Ah, Takafumi ……
[cpg cn=true]

[OnName num="keita"]
What's wrong, you seem depressed. Is something wrong?
[cpg cn=true]

[OnName num="takafumi"]
No, it's nothing serious. It's about Chiho.
[cpg cn=true]

[OnName num="keita"]
I see.
[cpg cn=true]

[OnName num="takafumi"]
I don't know why, but even Takafumi looked a little gloomy. Normally he would cheer me up.
[cpg cn=true]

Well, more importantly, the celebrity I used to like got married. Here, take a look.
[cpg]

[OnName num="takafumi"]
He pulls up an article on his phone and shows it to me.
[cpg cn=true]

You do have a thing for gals don't you. I don't at all.
[cpg]

[OnName num="keita"]
Yeah totally. I told Chiho the other day and she laughed at me.
[cpg cn=true]

[OnName num="takafumi"]
...... the other day? When was that? I wonder if he had a chance to meet Chiho over summer vacation.
[cpg cn=true]

When was that? ……
[cpg]

[OnName num="keita"]
Oh!
[cpg cn=true]

[OnName num="takafumi"]
What's the matter? Why are you shouting?
[cpg cn=true]

[OnName num="keita"]
Damn, I forgot something! Sorry, Keita, you go ahead.
[cpg cn=true]

[OnName num="takafumi"]
Saying that Takafumi went back the way he came. His hair was kind of in a mess, and it's unusual for him to forget something. Did he stay up late last night ......?
[cpg cn=true]

Oh.
[cpg]

;//★

;//●ＣＧ非エロ（千穂・徐々に変わっていくヒロインの姿：通学路）ev_11
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[BGM f="bg_vs"]
[WAIT time=100]
;**【ＣＧ】 ev_11_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="keita"]
I saw Chiho on the way to school. She was talking with two schoolgirls about something.
[cpg cn=true]

You got your ears pierced! How was it? Did it hurt?
[cpg]

[OnName num="female_student"]
It looks really good. You really have changed your image since summer vacation.
[cpg cn=true]

[OnName num="female_student"]
Haha ..... Oh, Keita.
[cpg cn=true]


[VOICE f="Chiho173"]
[OnName num="chiho"]
Chiho noticed me and turned around. There is something unfamiliar on her smiling face ...... or rather her ears.
[cpg cn=true]

She had gotten her ears pierced. It looked very strange ......
[cpg]

You got your ears pierced......?
[cpg]

[OnName num="keita"]
Yeah? What do you think ......?
[cpg cn=true]


[VOICE f="Chiho174"]
[OnName num="chiho"]
If someone asks me with a face like that whether it suits her or not, I can't deny it. I just smiled and nodded.
[cpg cn=true]

...... Yeah, it looks good on you. You look so pretty.
[cpg]

[OnName num="keita"]
I see. I'm glad.
[cpg cn=true]


[VOICE f="Chiho175"]
[OnName num="chiho"]
Why did you get her ears pierced? I don't remember saying I liked that kind of thing, and in fact it's not my type.
[cpg cn=true]

I feel like I'm out of the loop.
[cpg]

After school, I was on my way home. I saw Chiho at the entrance and followed her.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・入り口』（夕方）******************************************************

Chiho, are you headed back?
[cpg]

[OnName num="keita"]
Yes, I am. What do you want?
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chiho176"]
[OnName num="chiho"]
She seemed distant. "What do you want?" It wasn't something she'd normally say. We were dating, right?
[cpg cn=true]

Well…… Do you want to go on a date with me sometime?
[cpg]

[OnName num="keita"]
Sure. When is good for you?
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Chiho177"]
[OnName num="chiho"]
But it also looks like Chiho being her usual self as well. If I ask her out on a date like this, she doesn't even refuse.
[cpg cn=true]

......You look very daring in those clothes.
[cpg]



;//ＢＫ
;//★
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_06_a.ui" method="change_1"  pos="2/3" time=800]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]

;//移植のためシーンをカットしています

[WAIT time=800]
[OnName num="keita"]
She was showing a lot of skin so I had no other option but to tell her. She then gave me an unexpected answer.
[cpg cn=true]

I think so too.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Chiho178"]
[OnName num="chiho"]
What?
[cpg cn=true]

[OnName num="keita"]
I don't know what she meant. Why would she dress like that if she thinks she is being too bold?
[cpg cn=true]

I guess I gave her too many compliments when she got her earrings ...... If she did it for me, then she didn't really get my tastes right.
[cpg]

From there, we went to the mall for a date, but I wasn't feeling it.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_06_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


Chiho is next to me, wearing more revealing clothes than usual. I feel that people on the street are looking at her more than usual.
[cpg]

I think you might be showing a little too much skin …… and I don't want people to look at you in a strange way.
[cpg]

[OnName num="keita"]
With these few words, I try to get back on track from the point where I praised her earrings. However.
[cpg cn=true]

I know ……
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Chiho179"]
[OnName num="chiho"]
While affirming my opinion, she doesn't seem to want to change her attire.
[cpg cn=true]

Even up until this holiday, I had been worried about her. The accessories she carries, not just her earrings, are changing little by little.
[cpg]

The ladylike quality that used to be there is gradually changing to a different kind of girlishness.
[cpg]

I don't think it's my taste, or even Chiho's taste. I get that she's dressing up for me ......
[cpg]

The date didn't go very well, and it was getting late in the evening.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_06_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

I've made a decision, but I don't know if it's going to work ......
[cpg]

Hey, Chiho.
[cpg]

[OnName num="keita"]
Wait a minute ......
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Chiho180"]
[OnName num="chiho"]
Chiho looked at her cell phone. I had made the decision of a lifetime.
[cpg cn=true]

I'm sorry. I have to go somewhere after this.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Chiho181"]
[OnName num="chiho"]
Oh ...... is that so?
[cpg cn=true]

[OnName num="keita"]
Something came up.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Chiho182"]
[OnName num="chiho"]
Hold up a second...
[cpg cn=true]

[OnName num="keita"]
I stepped in with the courage of a lifetime and stumbled. The second time is not so easy.
[cpg cn=true]

......Never mind, I don't want to keep you if you have plans.
[cpg]

[OnName num="keita"]
I'm really sorry ...... See you.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Chiho183"]
[OnName num="chiho"]
So the date was over after this. After parting with Chiho, I felt disappointment.
[cpg cn=true]

I sighed.
[cpg]



[window target=false]
[transition target={true} rule="kosuri5.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kosuri5.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

[OnName num="keita"]
Alone and lonely, I returned home, collapsed with my back on the bed, and looked up at the ceiling.
[cpg cn=true]

Today wasn't such a good atmosphere to begin with.
[cpg]

I cut off my date with Keita in the middle and …… I went to the meeting place.
[cpg]

;//ＢＫ

;//千穂に視点切り替わり
;//[ChangeWindow num="1"]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_06_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

;//[lbox on]

...... Sorry for inviting you out so suddenly.
[cpg]

[OnName num="takafumi"]
No, it's okay.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Chiho184"]
[OnName num="chiho"]
Chiho. You've been wearing different clothes lately.
[cpg cn=true]

[OnName num="takafumi"]
Don't they look good on me?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Chiho185"]
[OnName num="chiho"]
It looks terrific on you. I mean, it's very attractive, but...you know.
[cpg cn=true]


[OnName num="takafumi"]
It seems like you're trying to change......for me. Am I right?
[cpg cn=true]

[OnName num="takafumi"]
I nodded timidly. Even today, I sacrificed my date with Keita to come here.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
Is that the only reason you wanted to see me? I can't leave with just that.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Chiho186"]
[OnName num="chiho"]
...... You're right. I'll do whatever you want. I'll take you anywhere you want to go.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[OnName num="takafumi"]
About a month had passed since the start of the new school semester. I was getting impatient.
[cpg cn=true]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;//恵太に視点切り替わり
;//[ChangeWindow num="0"]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『学園・廊下』（朝）******************************************************
;//★

Chiho is acting strange lately. I was not seeing her anymore, even though she was my girlfriend.
[cpg]

Hey. Did you wear those earrings before?
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="keita"]
Umm …… yeah. Do you think it suits me?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Chiho187"]
[OnName num="chiho"]
She had added more piercings. Her skin also seems to be a little tanned, and ......
[cpg cn=true]

I got my bellybutton pierced too. Do you want to see?
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Chiho188"]
[OnName num="chiho"]
No, don't you think it's a little too much?
[cpg cn=true]

[OnName num="keita"]
This is how fashionable people look nowadays. Don't you like it, Keita?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Chiho189"]
[OnName num="chiho"]
No, it's not like that. It suits you very well, you look cute.
[cpg cn=true]

[OnName num="keita"]
I hastily deny it as best I can. It's a special day, and I don't want the mood to turn sour this morning.
[cpg cn=true]

Hey, do you want to come over ...... today?
[cpg]

[OnName num="keita"]
...... Oh, sorry. I'm sorry, I've got some things to do today too.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Chiho190"]
[OnName num="chiho"]
…… I guess not. I was thinking of having a party for the six-month anniversary of our relationship, but she turned me down.
[cpg cn=true]

This kind of thing has been happening a lot lately. She has something to do, and we can't find time for each other.
[cpg]

I'm going to go to class. Bye.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Chiho191"]
[OnName num="chiho"]
I'll see you then …….
[cpg cn=true]

[OnName num="keita"]
I had no choice but to smile and cover up what I felt. But the shiny earrings, they weren't her style......I felt a sense of unease…….
[cpg cn=true]

I was crushed with anxiety. I couldn't get rid of the fear that someone might be changing her.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

I miss Chiho. I especially miss her at night. However, if I call her too often, she might get annoyed.
[cpg]

Oh, Keita is calling. ...... what should I do?
[cpg]

;//ＢＫ
;//千穂に視点切り替わり
;//[ChangeWindow num="1"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_06_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_15_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h3"]
[WAIT time=800]
;//【ＢＧ】『隆文の部屋』（昼）******************************************************

[SE f="se002"]
;//【ＳＥ】『携帯電話の震動音』ブーン

[FACE method="change_7" pos="2/3"]
[VOICE f="Chiho192"]
[OnName num="chiho"]
Are you going to pick up?
[cpg cn=true]

[OnName num="takafumi"]
...... I'll get it.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Chiho193"]
[OnName num="chiho"]
Hey, hey!
[cpg cn=true]

[OnName num="takafumi"]
Hello? Sorry, I'm busy right now ……
[cpg cn=true]


;//●ＣＧエロ（千穂・主人公と電話をするヒロイン。できれば普通に座ってる感じにしてください：親友の部屋）ev_12

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[VOICE f="Chiho194"]
[OnName num="chiho"]
Yeah. Yeah …… you're right.
[cpg cn=true]


[VOICE f="Chiho195"]
[OnName num="chiho"]
It's been six months since we've been together. I haven't forgotten.
[cpg cn=true]


[VOICE f="Chiho196"]
[OnName num="chiho"]
Let's go out to eat together again. Yeah ……
[cpg cn=true]


[VOICE f="Chiho197"]
[OnName num="chiho"]
Okay, bye.
[cpg cn=true]


[VOICE f="Chiho198"]
[OnName num="chiho"]
I was changing more and more. I wanted to be the kind of girl that Takafumi likes.
[cpg cn=true]



;//移植のためシーンをカットしています



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//ＢＫ


;//●ＣＧ非エロ（千穂・徐々に変わっていくヒロインの姿：通学路）ev_11_差分
;**【ＣＧ】 ev_11_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1000]

This was who I really was, and I wanted people to know.
[cpg]

;//そして、自分の本性どおり、誰から見てもえっちな子に見えるように。
...... Good morning, Chiho.
[cpg]

[OnName num="keita"]
Good morning.
[cpg cn=true]


[VOICE f="Chiho199"]
[OnName num="chiho"]
His expression is often dark or a bit worrisome.
[cpg cn=true]

That's not surprising, I had even dyed my hair. He must be worried about what was going on.
[cpg]

Do you think this color looks good on me?
[cpg]


[VOICE f="Chiho200"]
[OnName num="chiho"]
......Yes, it looks good on you.
[cpg cn=true]

[OnName num="keita"]
Even so, Keita did not ask for the truth. I was somewhat discouraged by him.
[cpg cn=true]

My disappointment in Keita has also made me lose my grip.
[cpg]



[window target=false]
[transition target={true} rule="amamori1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_04_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_15_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『隆文の部屋』（夕方）******************************************************

;//[lbox on]



I wonder how Takafumi feels. I can't read everything going on in his mind.
[cpg]


But he seems to feel more guilty than I do. Surprisingly, I've come to think he's cute in that way, too.
[cpg]

......
[cpg]



;//ＢＫ
;//[lbox off]

;//恵太に視点切り替わり
;//[ChangeWindow num="0"]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hosya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hosya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_04_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_du"]
[WAIT time=100]
;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************


[VOICE f="Chiho201"]
[OnName num="chiho"]
...... Our kiss feels different.
[cpg cn=true]

[OnName num="keita"]
There had been times where I felt like something was not right, but then the decisive moment came.
[cpg cn=true]


Really? I tried to keep it the same as usual.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Chiho202"]
[OnName num="chiho"]
After hearing that, even I realized what was going on.
[cpg cn=true]


But I don't have the courage to confront her. If I do, I might not be able to love her anymore.
[cpg]

I had to pretend like I didn't know.
[cpg]

From there, it did not take long for Chiho's stomach to grow. I pretended not to notice, even though I felt that the timing was strange.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_04_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//ＢＫ

Hey, Keita. Let's get married.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Chiho203"]
[OnName num="chiho"]
……
[cpg cn=true]

[OnName num="keita"]
It was just a facade. I was forced to get married with those words.
[cpg cn=true]

Chiho is still cute. I can say that I like her. She also tells me that she is happy to be with me.
[cpg]

There is no reason for me to refuse. But…but...Chiho......
[cpg]

Is there anything you're not telling me?
[cpg]

[OnName num="keita"]
No. What do you mean?
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Chiho204"]
[OnName num="chiho"]
I am sure that Takafumi will not leave me. He says he will stay by my side forever.
[cpg cn=true]



;//千穂に視点切り替わり
;//移植のためシーンをカットしています


;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


Maybe he won't make another girlfriend anytime soon. I don't need him to go that far though ……
[cpg]

With no way out, the only person still here is Keita. Then it can't be helped that he gets left behind …… right?
[cpg]


With no way out, the only one standing still is Keita-kun. Then he can't help but be left behind. ...... right?
[cpg]

[SCENE id=10]

[jump storage="epend.ks" target="*start"]
;//【千穂ルート】エンド

;//==============================
