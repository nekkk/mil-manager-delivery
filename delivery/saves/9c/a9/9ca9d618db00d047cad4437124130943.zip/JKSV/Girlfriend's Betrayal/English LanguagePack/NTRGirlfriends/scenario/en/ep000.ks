
*start|

;//寝取られビッチ　シナリオ
;---------------------------

;#################################################
*Ep000|Daily life of going to school with a childhood friend.
;#################################################

[SCENE id=0]



[stflag CHA01flg = 0]
[stflag CHA02flg = 0]
[stflag CHA03flg = 0]
[stflag CHA04flg = 0]
[stflag hiroin1sl = 0]
[stflag hiroin2sl = 0]



;//[ChangeWindow num="0"]
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[window target=true]
[BGM f="bg_vs"]
;//ＢＫ


The scene in front of me is unbelievable, and my head stops thinking.
[cpg]

[FACE method="quake" pos="5/9"]

My immobile head is unable to contain the reality that is too painful, and it slowly creeps into consciousness. Suffering invades my head.
[cpg]

How easy it is to deny reality. To erase the bad parts as if they'd never existed in the first place. Or perhaps, to confuscate it in such a way that I could no longer make heads nor tails of it.
[cpg]


;//移植のためシーンをカットしています

If it were a dream, I'd eventually wake up. But you can't wake up from reality.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

[SE f=se015 loop=true]
;//【ＳＥ】『街の喧噪』

[OnName num="keita"]
I'm still sleepy …… I feel like I've been in a dream this whole time.
[cpg cn=true]

The road to the school was littered with cherry blossoms, scattered by the breeze. The season is spring, and some time has passed since the entrance ceremony.
[cpg]

It's a season that invites a sense of pervading lethargy. Early-onset May blues, if you will. I yawn widely.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chiho001"]
[OnName num="unknown"]
You always oversleep. Nothing has changed since you were a child.
[cpg cn=true]

Walking next to me is Chiho, a childhood friend. She likes to take care of people and sometimes comes to wake me up in the mornings.
[cpg]

;//ここから千穂の名前を隠さないでください
[FACE method="shake_2" pos="2/3"]
[VOICE f="Chiho002"]
[OnName num="chiho"]
They say a child who sleeps grows tall, but I don't think you're at that age anymore.
[cpg cn=true]

[OnName num="keita"]
...... I can't help it, I'm sleepy.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chiho003"]
[OnName num="chiho"]
I wish you could see what it feels like to wake you up every morning. Why is it that although morning comes every day, you can't get up by yourself?
[cpg cn=true]

[OnName num="keita"]
That's because ...... You come to wake me up.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Chiho004"]
[OnName num="chiho"]
I wake you up believing that someday, you'll learn to get up by yourself.
[cpg cn=true]

[OnName num="keita"]
Well ...... I'm trying.
[cpg cn=true]

As usual, Chiho has to pull me by the hand as I trod along slowly. She's a childhood friend, and we're same age, and even though we are in the same class …… Chiho usually walks in front of me.
[cpg]

This wouldn't happen if she was just a caring person. I still think it's the relationship I've had with her since we were young that's led to this.
[cpg]

Chiho would call me "mellow", others have called me "timid" or "lazy".
[cpg]

Because I was like that, Chiho had somehow found herself in a position as my guardian.
[cpg]

I wondered if she would stay with me for the rest of my life like this. A different word flitted through my consciousness.....
[cpg]

[OnName num="keita"]
......
[cpg cn=true]

Maybe...a lover? No, stop. It would be terrible if she found out what I'd just thought.
[cpg]



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chiho005"]
[OnName num="chiho"]
What's the matter? Why are you grinning?
[cpg cn=true]

[OnName num="keita"]
Was I?
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Chiho006"]
[OnName num="chiho"]
Yeah. It's not the kind of face you'd normally make when someone is dragging you along.
[cpg cn=true]

[OnName num="keita"]
I'm sorry. It's nothing, really.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Chiho007"]
[OnName num="chiho"]
You're weird, Keita.
[cpg cn=true]

Chiho smiles. Seeing her face like that makes me smile too, but I was already grinning right?
[cpg]

It's not just when she's smiling. If she cried, I would cry too. If she had someone to be angry with, I bet I would hate them too. It was that sort of a relationship.
[cpg]

When it comes down to it, the word "childhood friend" doesn't seem right. We are closer than that, but it's not as if we are lovers, so it's a subtle distance.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・入り口』（朝）******************************************************

The entrance to the school during school hours is, of course, full of students. We are all in the same uniform, and all about the same age.
[cpg]

If I were a new student, I would think, "Wow, so the start of my school life starts now.", but that wasn't the case for me.
[cpg]

To me, I'd simply moved up to the next grade, so I knew many of the faces around us. One of them stands out in the crowd.
[cpg]

[OnName num="takafumi"]
Hey. You going to school with Chiho again?
[cpg cn=true]

Takafumi. He's more than just my friend, he is my best friend and someone I can rely on.
[cpg]

He is always so well groomed. I wonder what he puts on his hair? I couldn't look like that if I tried. Because I'm not a morning person or something. Yeah, that's it.
[cpg]

Whenever I see him, I think he's a cool guy, and not in a weird way.
[cpg]

[OnName num="keita"]
Yep. What's the biggie?
[cpg cn=true]

[OnName num="takafumi"]
Nothing, if anything I'm happy for you, buddy. I just think you should get out there and meet other people for a change of pace.
[cpg cn=true]

[OnName num="keita"]
What do you mean?
[cpg cn=true]


[FACE method="shake_6" pos="2/5"]
[VOICE f="Chiho008"]
[OnName num="chiho"]
Ahahahaha!
[cpg cn=true]

Now, Chiho looks troubled, too. Or rather, does she look like she is embarrassed?
[cpg]

[OnName num="takafumi"]
I wish we were in the same class.
[cpg cn=true]

[OnName num="keita"]
Yeah …… I'm sad about it too.
[cpg cn=true]


[FACE method="bow_6" pos="2/5"]
[VOICE f="Chiho009"]
[OnName num="chiho"]
I'm sad, too.  As a childhood friend, I'm worried when I can't be near you. As a childhood friend of course.
[cpg cn=true]

She was really emphasizing the fact that she was only my childhood friend. Of course we are. What else would we be?
[cpg]

[OnName num="keita"]
I'm sorry …… am I so unreliable that you worry about me?
[cpg cn=true]


[FACE method="bow_3" pos="2/5"]
[VOICE f="Chiho010"]
[OnName num="chiho"]
Yeah of course. When we're not together, I just get worried about you. That's all.
[cpg cn=true]


[OnName num="takafumi"]
It's so frustrating to watch you guys.
[cpg cn=true]


[FACE method="shock_5" pos="2/5"]
[OnName num="keita"]
What do you mean?
[cpg cn=true]

Chiho seems flustered. Seeing this, Takafumi lets out a small sigh of exasperation.
[cpg]


[FACE method="change_4" pos="2/5"]
[VOICE f="Chiho011"]
[OnName num="chiho"]
I'm in another class, so I'm going to go now.
[cpg cn=true]

[free time=1000]

[OnName num="keita"]
Oh, wait!
[cpg cn=true]

Even though we were in different classes, our path to school was the same. I wonder what happened? I think her face was red.
[cpg]

[OnName num="takafumi"]
I'm not talking about the two of you. I get frustrated when I look at you.
[cpg cn=true]

[OnName num="keita"]
Again, what do you mean?
[cpg cn=true]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="kaya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kaya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・教室』（朝）******************************************************

[SE f=se016 loop=true]
;//【ＳＥ】『学園の喧噪』

[OnName num="takafumi"]
So, what are you going to do? In the next lesson.
[cpg cn=true]

[OnName num="keita"]
What are you saying? Of course I'm gonna go.
[cpg cn=true]

[OnName num="takafumi"]
Idiot. That's normal. That's not what I'm talking about. I'm talking about the notes.
[cpg cn=true]

[OnName num="keita"]
Oh!
[cpg cn=true]

I had caught a cold the other day and had to take the day off. That's not good ...... But the fact that Takafumi told me about it probably means …..
[cpg]

[OnName num="keita"]
Did you take a copy for me?
[cpg cn=true]

[OnName num="takafumi"]
You gotta learn how to ask for things or you'll never be able to stand on your own feet.
[cpg cn=true]

While saying that, he put the copied notes from the classes I missed on my desk …..
[cpg]

[OnName num="keita"]
Thank you! That's a big help.
[cpg cn=true]

[OnName num="takafumi"]
If you were a girl, you might be the type guys would want to protect. Hell, they might even think you were cute. But as a guy, you're too unreliable.
[cpg cn=true]

[OnName num="keita"]
What do you mean? Is that how you see me, Takafumi?
[cpg cn=true]

[OnName num="takafumi"]
No. I'm not interested in men.
[cpg cn=true]

But it's true that he's the opposite of me, since he's masculine and dependable.
[cpg]

On the other hand, the fact that he said that I was better at being dependant than I was dependable. It might be a fatal flaw as a guy......
[cpg]

[OnName num="keita"]
Takafumi, we've known each other for a long time. We were together since our last school, so...how many years is that?
[cpg cn=true]

[OnName num="takafumi"]
It's been about five years since we became friends. If you count our first conversation, it's a little longer.
[cpg cn=true]

[OnName num="keita"]
That sounds about right. Now we're more like best friends.
[cpg cn=true]

I smiled at him, and for some reason, Takafumi made a disgusted face. Did I do something wrong?
[cpg]

[OnName num="takafumi"]
You have a nice smile. I think you could knock a woman off her feet like that.
[cpg cn=true]

[OnName num="keita"]
Really? Thanks.
[cpg cn=true]

[OnName num="takafumi"]
......Why can't you act like that for Chiho?
[cpg cn=true]

[OnName num="keita"]
What do you mean……?
[cpg cn=true]

I don't know if I made such a weird face. No, if I made a weird face, he wouldn't have told me to show it to Chiho, would he?
[cpg]

[OnName num="takafumi"]
Whatever. Chiho's probably fine with it. Everyone has their own type …….
[cpg cn=true]

[OnName num="keita"]
I don't get it, you have to be more clear.
[cpg cn=true]

[OnName num="takafumi"]
If I said it any clearer than that, Haruka or Yuri will get angry with me.
[cpg cn=true]

[OnName num="keita"]
What? Why?
[cpg cn=true]

Why did he mention their names? Haruka is in a grade above us and Yuri is a grade below us.
[cpg]

Although we knew each other, I don't think they had that much contact with Takafumi.
[cpg]

[SE f=se012]
;//【ＳＥ】『ドア横開け』
[WAIT time=500]

[OnName num="sawabe"]
Let's start the class. Take your seats.
[cpg cn=true]

[OnName num="takafumi"]
Anyway, see you later.
[cpg cn=true]

[OnName num="keita"]
Wait, really? But I still don't understand!
[cpg cn=true]

Mr. Sawabe entered the room. At the teacher's signal, everyone instantly took their seats. The female students, in particular, were happy to do as he said.
[cpg]

Takafumi is cool and popular, but Mr. Sawabe is probably even more popular than him.
[cpg]

In truth, multiple girls had confessed their feelings to him already. I wonder if that's a good thing for a teacher, but it makes sense.
[cpg]

Takafumi is a cool student, but Mr. Sawabe is a cool teacher. He is an adult, but at the same time he is young for a teacher.
[cpg]

In addition, it seems that the profession of a teacher easily attracts admirers in the first place.
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]

[OnName num="schoolgirl"]
He is really cool ...... I think I'll make a move on him.
[cpg cn=true]

[OnName num="schoolgirl"]
What if he's married with kids?
[cpg cn=true]

[OnName num="schoolgirl"]
No, he's single. Even though he is that good-looking.
[cpg cn=true]

[OnName num="schoolgirl"]
Really? Then I have a chance, don't I?	“真的吗？那我有机会，不是吗？
Hey, there. Be quiet."
[cpg cn=true]

[OnName num="sawabe"]
Excuse me.
[cpg cn=true]

[OnName num="schoolgirl"]
He had enough admirers that it was common to see students whispering to each other before class began. Of course, popular as he was, once lessons began, they naturally quieted down.
[cpg cn=true]

In this school, it is rare to have a class with as little noise as his class. Even female students, who have bad manners, take the class seriously, with only a little whispering before class.
[cpg]

Maybe it spoke to his teaching skills that the students in his class become quiet, but I don't know ……
[cpg]

I was sleeping.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・教室』（朝）******************************************************

[OnName num="keita"]
When I woke up, about 30 minutes had passed. The class is almost over.
[cpg cn=true]

His classes are not very interesting, probably because he is still young. I'm not a diligent person by nature, and I get sleepy easily.
[cpg]

I wasn't exactly studious, so I couldn't say anything for certain, but it looked and sounded like he was simply following the textbook. Maybe I was mistaken ……?
[cpg]

Somehow, I wonder if Mr. Sawabe became a teacher for another purpose than just wanting to be a teacher? It was a bit of a rude thought, but it goes through my head.
[cpg]

For example, maybe his parents were teachers and he had to follow in their footsteps. I don't feel much enthusiasm from him as a teacher. Maybe he likes schoolgirls or girls in uniforms? No way.
[cpg]

Generally speaking, even if he doesn't seem to be very enthusiastic about teaching, from the eyes of a girl, he seems to be cool and carefree......  That was frustrating.
[cpg]

What a snoozefest. I mean, I fell asleep in the middle of it.
[cpg]

[SE f=se017]
;//【ＳＥ】『学園のチャイム』


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園・教室』（昼）******************************************************

[OnName num="takafumi"]
You have to keep your eyes open at least, Takafumi. You'll only get in trouble on the exam.
[cpg cn=true]

[OnName num="keita"]
You were sleeping too.
[cpg cn=true]

[OnName num="takafumi"]
Haha ...... Well, yeah.
[cpg cn=true]

[OnName num="keita"]
Takafumi talks to me while munching on his lunch. I feel a little inferior to him at lunchtime because of the difference in size between his and my lunch box.
[cpg cn=true]

I'm a little embarrassed that I eat so little, even though I'm a guy who should eat a lot. Am I too concerned about it?
[cpg]

But, you know, that teacher's classes are not well prepared don't you think?
[cpg]

[OnName num="takafumi"]
You think so too? I know, right?
[cpg cn=true]

[OnName num="keita"]
Well, I don't know about that.
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Chiho012"]
[OnName num="chiho"]
Oh, Chiho, are you also a fan of Mr. Sawabe? If so, I'm sorry.
[cpg cn=true]

[OnName num="takafumi"]
Takafumi takes notice of Chiho. Yes, Chiho is in a different class, but she sometimes comes over here and shares a desk with us during lunch break.
[cpg cn=true]

The three of us usually eat lunch together. Occasionally, a girl named Haruka …… an upperclassman, would join us.
[cpg]

I don't really want to see her during lunch ….. It's not that I don't like her, but she seems to be the type to make fun of me.
[cpg]

I don't really want to see her during lunch,......, but she seems to make fun of me for something.
[cpg]


[jump storage="ep001.ks" target="*start"]

;////////////////////////////////////////////////////////////////////////


