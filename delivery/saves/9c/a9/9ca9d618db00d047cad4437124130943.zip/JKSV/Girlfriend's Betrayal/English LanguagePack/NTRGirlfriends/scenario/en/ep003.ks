
*start|


;#################################################
*Ep003|Step sister
;#################################################

[SCENE id=3]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・リビング』（夕方）******************************************************

[SE f="se012"]
;//【ＳＥ】『家の玄関ドア開け』

[OnName num="keita"]
I'm home …..
[cpg cn=true]

Nanako never shown aggression before. I couldn't imagine such a thing, it wasn't in her nature.
[cpg]

If it was true, the only time she'd have an opportunity to get angry would be when we saw each other at dinner.
[cpg]

I can't imagine her looking for me or coming into my room just to get mad at me.
[cpg]

It's not that she lacks emotions or anything, she's just that kind of person. She's always been calm, to the point where she can seem dark.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
;//ＢＫ

[SE f="se007"]
;//【ＳＥ】『ノック』
[WAIT time=1000]

[OnName num="keita"]
Nanako, I'm coming in, okay?
[cpg cn=true]


Knocking on the door of her room, I open it before I can hear her reply.
[cpg]

[SE f="se011"]
;//【ＳＥ】『ドア開け』

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・奈々子の部屋』（夕方）******************************************************


[FACE method="shake_1" pos="2/3"]
[VOICE f="Nanako001"]
[OnName num="nanako"]
.... Please open the door after you hear a reply.
[cpg cn=true]

I have a tendency to be reserved towards others. But I am not particularly reserved with Nanako.
[cpg]

[OnName num="keita"]
I'm sorry. But I came here because I heard you were mad at me for something.
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Nanako002"]
[OnName num="nanako"]
You took my comic books again. But that's not the only reason I'm angry.
[cpg cn=true]

There was something else? Her angry face looked pouty, if anything.
[cpg]

Generally speaking, she was cute. That said, I was numb to such sensations.
[cpg]

Cute or not, she was an important person to me. She was family.
[cpg]

[OnName num="keita"]
So? If it's not the comics, what are you unhappy about?
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Nanako003"]
[OnName num="nanako"]
I just want you to be more like a man.
[cpg cn=true]

I don't understand. If I borrow a comic book from someone, does that make me less of a man and more of a woman?
[cpg]

[OnName num="keita"]
I get it. Next time I'll buy them myself.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Nanako004"]
[OnName num="nanako"]
No, it's not that. Your face and your personality is feminine enough. I don't want you reading girl's manga on top of that.
[cpg cn=true]

[OnName num="keita"]
Oh come on……
[cpg cn=true]

That's what she was talking about. I don't care what I read, as long as it's interesting.
[cpg]

[OnName num="keita"]
Are guys not allowed to read girls manga?
[cpg cn=true]

[OnName num="keita"]
That's not the point……You know guys like you show up in those comics?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

She's still pouty-faced, it must be serious. Even still, Nanako never raises her voice.
[cpg]

I don't think my sister hates me that much, if anything, she likes me. That's why she's in a bad mood.
[cpg]

I guess she doesn't like my weak side.
[cpg]

[free time=1000]

[OnName num="keita"]
Oh, Dad.
[cpg cn=true]

I had left the door open, and as our dad passed by in the hallway, he stopped.
[cpg]

[OnName num="junichi"]
What's this? You two fighting about something?
[cpg cn=true]

[OnName num="keita"]
Nanako got mad at me for borrowing one of her comic books.
[cpg cn=true]

[OnName num="junichi"]
Well that's no good, Keita! You're clearly in the wrong.
[cpg cn=true]

[OnName num="keita"]
Why?
[cpg cn=true]

I didn't think he would be on her side. He always said that in a quarrel, both sides were to blame.
[cpg]

[OnName num="junichi"]
Comic books are for children.
[cpg cn=true]

[OnName num="keita"]
Seriously......?
[cpg cn=true]

I didn't expect him to pick a fight with the comic book industry. It was an outdated way of thinking, but then again, it was in line with his way of thinking.
[cpg]

Dad's name was Junichi. As his name implied, there wasn't a crooked bone in his body.
[cpg]

He has a loud voice and a firm personality. He was well-built and could be overbearing so it was difficult to contradict him.
[cpg]

For example, I could argue with him saying, "So is it okay for Nanako to read this?", but I don't have the energy for a drawn out debate.
[cpg]

[OnName num="junichi"]
If you have time to read manga, it would be more meaningful to devote yourself to club activities. Instead of staying in your room, why not go outside and work up a sweat?
[cpg cn=true]

[OnName num="keita"]
You can't sweat in the art club ……
[cpg cn=true]

I'm sure he is a good father and what he said was fair. I know he cares about me, and not just in the athletic sense.
[cpg]

An older brother who is not very masculine and a younger sister who is a little dark but cute. My parents warmly watch over us both.
[cpg]

The family as a whole is happy. There was a time, however, when the atmosphere in the house was bad ......
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]

;//【ＢＧ】『恵太の家・リビング』（夕方）******************************************************

;//ここから回想。セピア調にしてください

At that time, I didn't really understand what was going on.
[cpg]

I could tell that my father and mother were somewhat on bad terms, but there were no big fights or people taking out knives or anything like that.
[cpg]

When I was a kid, I really didn't like it when my parents fought. They respected that, and they stopped fighting in front of me.
[cpg]

I remember them smiling, but it was strained......There wasn't anything I could do so I figured it was normal......
[cpg]


;//【ＢＧ】『恵太の家・奈々子の部屋』（夕方）******************************************************

But it must have been hard on Nanako. I could imagine that much.
[cpg]

[OnName num="keita"]
Are you okay? Nanako……
[cpg cn=true]


[VOICE f="Nanako005"]
[OnName num="nanako"]
..... You don't notice anything? Even when you look at our parents …….
[cpg cn=true]

[OnName num="keita"]
You'll be fine, no matter what happens. I'll protect you, Nanako.
[cpg cn=true]

;//回想終了。色調を戻してください
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=800]



[OnName num="junichi"]
I'm not in favor of you joining the art club. If you want to paint, then that's your choice, but I still think baseball is a better choice……
[cpg cn=true]

But now everyone is friendly and smiling, as if those times had never happened. It's not that people are awkward with each other, especially now.
[cpg]

[OnName num="keita"]
I don't know what you're talking about. What's the fun in watching me play a sport I don't like?
[cpg cn=true]

[OnName num="junichi"]
Haha, now you get it! If you like the art club, then go for it. Just don't give up halfway.
[cpg cn=true]

[OnName num="keita"]
Y-yeah……got it.
[cpg cn=true]

It feels like everybody's picking on me these days. Weak boys like me must have a weaker position than I'd thought.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=100]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/5" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//ＢＫ

At dinner, the four of us are all together. It was a normal family dinner, nothing out of the ordinary.
[cpg]

There is nothing to be depressed about, but there wasn't anything be overly happy about. The atmosphere is just right, and time passes at its own pace.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

My room at night. There was a lot of stuff in it, but I thought it was fairly tidy.
[cpg]

The shelves are lined with comic books, which I liked to read before bed. But not today.
[cpg]

[OnName num="keita"]
I don't think people this corny really exist......do they?
[cpg cn=true]

I was trying to sleep while reading a comic book I borrowed from Nanako.
[cpg]

It was a classic girl's comic with a story that romanticized romance itself.
[cpg]

You don't see many stories like this nowadays...Looking at the publishing date, I found that it was serialized 15 years ago. No wonder it seemed dated.
[cpg]

I wondered if this might be a manga that my mother had bought ...... When I finished reading one of them, I thought that I would be bored.
[cpg]



[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
;//ＢＫ


But by the time I finished reading the whole thing, all I could think of was falling in love. I had underestimated it ......
[cpg]

I'm kind of having trouble sleeping now. This is what I get for reading a comic before going to bed.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se013"]
;//【ＳＥ】『歩き』

[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

I couldn't sleep much, so I went out for a walk in the middle of the night. I thought maybe I'd head to the bookstore to see if the author had penned any other series.
[cpg]

[OnName num="keita"]
I'm spending too much money this month ...... What should I do?
[cpg cn=true]

But soon my thoughts would return to love again. I don't think I could have such a beautiful love life, but that doesn't mean I don't yearn for it.
[cpg]

Why can't I have that kind of love in the first place? I don't want to think that it's my personality, or that I have a specific taste, or something like that .......
[cpg]

Because if I admit that, I would be admitting that I am not popular. Then, I would make an excuse that I am not meeting enough people.
[cpg]

With this in mind, I counted my female friends one by one and found out that ……
[cpg]

[OnName num="keita"]
There are quite a few ……
[cpg cn=true]

Among them, there is one in my class, one senpai, and one kōhai that I was familiar with.
[cpg]

I've had contact with a lot of girls, but it hasn't led to romance. I guess I'm the one with the unattractive personality ......
[cpg]


;//＠
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//ＢＫ

;//結局本屋まで歩く前に眠くなってきて、家までＵターン。途中でちょっともよおしてきたので、適当なコンビニのトイレに入る。
Eventually, I got sleepy before walking to the bookstore and headed back home. On the way there, I passed a couple holding hands.
[cpg]

[OnName num="keita"]
Huh ……
[cpg cn=true]

;//こう、男が小をするとき、どうしても自分のものの大きさが見えちゃうんだけど、俺の場合はそのたび憂鬱になる。
Whenever I see the male side of a couple like this, I can't help but compare them to myself, and I get depressed every time I do.
[cpg]

;//他の人と比べたわけじゃないけど、色々調べてみると人より小さいのは間違いない。勃起したときでも、かなり小さい。
I didn't seem particularly masculine or reliable.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵太の家・恵太の部屋』（夜）******************************************************

I go back to my own house and lie in bed.
[cpg]

;//恋愛についての悩みは、性的な悩みを含んでいる。俺のものは、いわゆる短小。
My concerns about love include physical concerns. One of them is weakness.
[cpg]

;//性欲がないわけじゃないから、本棚の奥の方にそういうものも色々あるけど……例えば、ＡＶとかなら全部観ることはない。
It's not that I didn't try to make an effort, there are books in the back of my bookshelf ...... for example, muscle training books that I haven't read at all.
[cpg]

;//早漏ってやつで、やろうと思ったら一瞬で終わらせることもできてしまうくらい、早い。
At first, I tried to work out, but I was so weak that I got tired after less than 5 minutes.
[cpg]

;//もし誰かと付き合って、その……そういう行為に及んだとき、がっかりされてしまうんじゃないだろうか？
If I were to go out with someone, they would probably dump me right away because I'm so unreliable.
[cpg]

I flip through the comic I just read again. It says something like, "Love is something you do with your heart," which gives me some confidence, but I still feel uneasy.
[cpg]


[jump storage="ep004.ks" target="*start"]


;////////////////////////////////////////////////////////////////////////
