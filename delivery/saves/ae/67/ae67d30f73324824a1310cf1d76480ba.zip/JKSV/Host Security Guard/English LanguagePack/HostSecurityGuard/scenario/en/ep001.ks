
;+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
;//１、早苗の隣に座る　の場合
;//(Y):早苗ルートへ

*start|I'll Sit Next to Sanae

;#################################################
*Ep001|I'll Sit Next to Sanae
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『居間』（夜電気ON）******************************************************


*select01_1|I'll Sit Next to Sanae

[SCENE id=1]

[free time=300]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

I sit down next to Sanae.
[cpg]

She smiles back at me and puts some of the vegetable stir-fry on my plate.
[cpg]

[OnName num="masato"]
“Umm ..... I don't really like bitter melon ……"
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

Sanae scooped up the bitter melon one after the other.
[cpg]

[OnName num="masato"]
“Ahhhh!”
[cpg cn=true]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『寝室』（夜電気OFF）******************************************************

I wanted to maintain this life. The shared house was comfortable.
[cpg]

People don't like change. That's not a bad thing. Who would give up their happiness
[cpg]

[OnName num="masato"]
“I guess I'm somewhat satisfied with this life.”
[cpg cn=true]

Old men dislike change. In the spiritual sense, not physical. Based on that, I was an old man.
[cpg]

A bag of lemon custard pie was lying on the desk.
[cpg]

[OnName num="masato"]
“I can’t eat that.”
[cpg cn=true]

[OnName num="masato"]
“What will I become if I do?”
[cpg cn=true]

It's a gateway to misery. I put my hand behind my neck and tapped the microchip embedded in my neck.
[cpg]

In the old days, they used to implant them in pets. I am a dog tamed by the state and corporations.
[cpg]

[OnName num="masato"]
“I want to stay the way I am.”
[cpg cn=true]

[FADEOUTBGM]

;//(Y):一瞬の白フラッシュ

[BG f="white.ui" time=500]
[WAIT time=500]
[BG f="b_02_5.ui" time=500]
[WAIT time=500]

Something glowed outside the window.
[cpg]

[OnName num="masato"]
“What was that?”
[cpg cn=true]

;//[SE f="se072"]
;//【ＳＥ】『銃声』

[SE f="se045"]
;//【ＳＥ】『窓が割れる』

[BGM f="bg_d2"]

The window was smashed. I grabbed my bed sheets and used it as a shield.
[cpg]

[OnName num="masato"]
"Damn!"
[cpg cn=true]

I was shot above my left collarbone. But it only cut through my skin!
[cpg]

Change comes uninvited.
[cpg]

[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/5" time=1000]
[FG f="CHA02_p2_01_a.ui" method="change_4"  pos="4/5" time=1000]
[BG f="b_09_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（朝）******************************************************

[OnName num="policeman_A"]
“Gunshots ...... in this day and age in Japan.”
[cpg cn=true]

The three residents in our shared house were surrounded by police and being questioned.
[cpg]

Both Sanae and Hazuki were frightened. No wonder. It seems like I was the only one who was shot.
[cpg]

[OnName num="policeman_B"]
“Can you tell us more about the situation?”
[cpg cn=true]

[OnName num="masato"]
“It was from outside the window. It looks like someone got on the branch of that tree and shot at me.”
[cpg cn=true]

I saw a tree on the neighbor's property. The branch was broken and someone climbed it to shoot me.
[cpg]

[OnName num="masato"]
“Ugh ……."
[cpg cn=true]

I got the shivers when I imagined it - I am human at the end of the day.
[cpg]

I'm in a profession where I do my job hoping nothing happens to me. No one wants to go into a fight.
[cpg]

But I was pissed.
[cpg]

[OnName num="masato"]
“Why was I the one to get shot ...... ?”
[cpg cn=true]

[OnName num="policeman_A"]
“Are you sure you're okay ……? You look calm.”
[cpg cn=true]

I see ……
[cpg]

[OnName num="masato"]
“Well, the criminal mindset is to just stay away from here for a while and see what happens.”
[cpg cn=true]

[OnName num="masato"]
“Nobody's afraid of a coward.”
[cpg cn=true]

[SE f="se075"]
;//【ＳＥ】『葉　がさごぞ』
[WAIT time=1000]

[FACE method="change_7" pos="2/5"]

I said provocatively. I heard a rustle in the grass.
[cpg]

— He was here.
[cpg]

Maybe it was someone else, someone who was just trying to get a reaction out of me.
[cpg]

[OnName num="masato"]
“The branch over there is broken, isn't it? Can you find any footprints or anything?”
[cpg cn=true]

[OnName num="policeman_B"]
“We're looking right now. We haven't had a shooting like this in a long time, but ..…”
[cpg cn=true]

[OnName num="masato"]
“The shooter's an idiot.”
[cpg cn=true]

[FACE method="bow_3" pos="2/5"]
[VOICE f="Sanae025"]
[OnName num="sanae"]
“There seems to be a lot of evidence. Should we not step foot in this area”
[cpg cn=true]


Sanae was acting strange! Was she aware of the criminal by any chance?
[cpg]

[FACE method="change_3" pos="2/5"]
[FACE method="shake_3" pos="4/5"]
[VOICE f="Haduki029"]
[OnName num="haduki"]
“I can't believe that person used a gun.”
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[VOICE f="Haduki030"]
[OnName num="haduki"]
“I guess one can kill because they don't have the imagination to think of pain as their own.”
[cpg cn=true]

Hazuki’s reaction was more aggressive! Stop it!
[cpg]

[FACE method="bow_3" pos="4/5"]
[VOICE f="Haduki031"]
[OnName num="haduki"]
“They have no respect for people. Every person is a stranger to them. That's the type of person who doesn’t know how to communicate with people.”
[cpg cn=true]

Whoa!
[cpg]

[FACE method="bow_7" pos="2/5"]
[VOICE f="Sanae026"]
[OnName num="sanae"]
“It sounds like they’ve been blocked for writing offensive things on social media.”
[cpg cn=true]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Haduki032"]
[OnName num="haduki"]
“In a world where everything around them is an enemy, they've probably fallen to the point where all they can do is attack good intentions.”
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[FACE method="change_1" pos="4/5"]
[VOICE f="Haduki033"]
[OnName num="haduki"]
“Even the evil ones are usually sensitive and vulnerable.”
[cpg cn=true]

[SE f="se075"]
;//【ＳＥ】『葉　がさごぞ』

There was a rustling sound behind the bushes. I looked back and saw a man holding a gun, trembling and shaking.
[cpg]

[FACE method="change_3" pos="2/5"]
[FACE method="change_3" pos="4/5"]

;//俺も警察も姉妹もものすごい勢いで動いた。犯人は銃を撃ち、何にも当たらなかった。
The police, the sisters, and I all moved with stealthy speed. The gunman fired his gun but didn't hit anything.
[cpg]

[OnName num="policeman_A"]
“Get him! Secure him!”
[cpg cn=true]

[OnName num="policeman_B"]
“You fools! Strike him down with the baton!”
[cpg cn=true]

[OnName num="shooter"]
“Aaaaaaaahhh!”
[cpg cn=true]

[OnName num="masato"]
“You bastard! You! Who sent you? Why are you here?”
[cpg cn=true]

Both Sanae and Hazuki started kicking the culprit together.
[cpg]

;//●ＣＧ非エロ（服を着せて、怒りをもって、強い意思で見る時の表情にしてください。口は閉じている想定です）ev_09
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_09_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[VOICE f="Sanae027"]
[OnName num="sanae"]
“You damaged our windowpanes and our walls! You won't get away with this!”
[cpg cn=true]

[SE f="se031"]
;//【ＳＥ】『蹴る』
[WAIT time=1000]

[VOICE f="Haduki034"]
[OnName num="haduki"]
“Violence! I can’t believe you showed yourself! This is really fun!”
[cpg cn=true]

[SE f="se031"]
;//【ＳＥ】『蹴る』
[WAIT time=1000]

[OnName num="shooter"]
“Ahhhhhhhhh!”
[cpg cn=true]

[VOICE f="Sanae028"]
[OnName num="sanae"]
“Of course, you're afraid of being shot!”
[cpg cn=true]

[SE f="se031"]
;//【ＳＥ】『蹴る』
[WAIT time=1000]

;//差分：口を開く。決定的なことを言うときの表情

;//;**【ＣＧ】 ev_09_a ***********************
;//[CG id=6 index=1 time=1]
;//;***************************************
;//[WAIT time=1]

[VOICE f="Sanae029"]
[OnName num="sanae"]
“You hurt Masato and you won’t get away with it!”
[cpg cn=true]

[VOICE f="Sanae030"]
[OnName num="sanae"]
“If you're going to shoot, then shoot me!”
[cpg cn=true]

;//(Y):流用
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『会社』（昼）******************************************************
;//【ＢＧ】『会社』（夜電気ON）

I came to work without being able to call in sick. I think I'm going to apply for a paid vacation tomorrow ......
[cpg]

[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki024"]
[OnName num="misaki"]
“Oh, Mr. Fujita. I heard you were attacked. There are more competitors in this business than you might think.”
[cpg cn=true]

[OnName num="masato"]
“Where did you get that information from ……?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Misaki025"]
[OnName num="misaki"]
“I'm sure you don't underestimate my network, but I can see everything.”
[cpg cn=true]

...... Hmmm. Misaki thinks that they are competitors, but I don't think they are.
[cpg]

[OnName num="masato"]
“I'm really overwhelmed ……"
[cpg cn=true]

;//(Y):流用

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************

Tomorrow is paid vacation. The temperature has dropped at night and it is more comfortable now to be outside.
[cpg]

After work, I was sitting alone on the swing with a can of alcohol. I want get drunk in the park at night.
[cpg]

[OnName num="masato"]
“I can't wait to find out the background of this guy.”
[cpg cn=true]

This is Tokyo, after all. This place used to be called the Shinjuku Gyoen. I'm not worried about getting shot because there are nighttime guards, who are not me.
[cpg]

;//【ＳＥ】『ブランコの音』

[OnName num="masato"]
“But at my age, playing on a swing sucks. It's for kids, so the seats are narrow, and the equipment creaks.
[cpg cn=true]

;//(Y):セピア色。早苗が撃たれることへの恐怖を伏線として撒いておく

[window target=false]
[free time=1000]
[BG f="b_ev_09.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（朝）******************************************************


[VOICE f="Sanae031"]
[OnName num="sanae"]
“If you're going to shoot, then shoot me!”
[cpg cn=true]

;//(Y):回想終わり

[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[OnName num="masato"]
“Sanae ……”
[cpg cn=true]

[OnName num="masato"]
“I wish she hadn't said that.”
[cpg cn=true]

She got angry. Even Hazuki got angry. — For me.
[cpg]

This was bad. Why was I thinking like this? Maybe the shock of being shot is deeper than I realize.
[cpg]


[jump storage="ep002.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
