
;//触手もの　シナリオ　全年齢版

;//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
;//キャラクター・背景素材などの要望は別途グラフィック要望リストにて送信いたします。
;//CGについての改変要望などはこのシナリオ中、当該CGの使用箇所にて表記します。
;//今回は他ゲームにて要望を出させていただいた背景素材を流用する想定です。※現在は、元『童貞喰い』の一本にしか関わっていないのでそちらからになります。
;//今回も、全年齢版への書き換えをしたライターからの注釈は;//(Y):をつけたコメントアウトを用います。
;//主人公はまるっきり変えます。ボイス新録なので、女の子の台詞も変えていいのでは……と思いますのでそちらも変えます。
;//美咲ルートはない予定ですが、2ルートだけだとCGのノルマが達成できなそう！　美咲ルートを増やさねば！　とか思ったら増やすかもしれません
;//※美咲のボイスは必ずしも必要ないかな？　という感触です
;//xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


*start|A Strange Company

;#################################################
*Ep000|A Strange Company
;#################################################

[SCENE id=0]


[stflag sanaecount = 0]
[stflag hadukicount = 0]
[stflag countfive = 0]
[stflag misakipoint = 0]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『生物研究所内部』（夕方）******************************************************

I was working as a member of a private security company when I was headhunted by a strange company.
[cpg]

;//(Y):背景の異様な雰囲気に意識を向かせたい引き込み

[OnName num="masato"]
“What is this place ……?”
[cpg cn=true]

[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki001"]
[OnName num="misaki"]
"It's better if you don't know too much about it."
[cpg cn=true]

My new boss replied. The less I know about it, the better. I wondered for whom it was “better”.
[cpg]

It was visible in the security system. I had never seen such a level of security.
[cpg]

Almost like the department of state secrets.
[cpg]

A security guard passed us. Something dripped down. It was his tears.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Misaki002"]
[OnName num="misaki"]
“He's been crying for a long time. A parasite ...... I mean, something is wrong with his eyes.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki003"]
[OnName num="misaki"]
“……. Please be careful, Mr. Fujita. Do not remove your dust visor glasses while you’re on duty.”
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Misaki004"]
[OnName num="misaki"]
“You will die.”
[cpg cn=true]

[OnName num="masato"]
“Yes, sir.”
[cpg cn=true]

I won't ask too much ababout it.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所前』（夕方）******************************************************

[OnName num="masato"]
“I want a drink. ……"
[cpg cn=true]

From the outside, this new workplace does not stand out that much compared to the surrounding buildings.
[cpg]

But considering the strangeness of the inside, you can tell that this inconspicuous appearance is just camouflage.
[cpg]

[OnName num="masato"]
“I may have chosen the wrong job. ...... I need a drink.”
[cpg cn=true]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（夕方）******************************************************

This is the eastern part of Tokyo. It is a new ward called “Kayamichi”, which was newly created due to the rezoning after the great fire.
[cpg]

The good thing about this place: the ward provides generous support for housing costs because the people with security-related occupations make it safer to live here. Yay.
[cpg]

The bad thing about this place: the alcohol is too cheap and too good. It is very harmful to my health.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『寝室』（夜）******************************************************

I started living in a shared house when I moved here for a new job. Rent starts at 67,000 yen, minus the Kayado ward and security housing assistance.
[cpg]

I chose a shared house with just men. Because ...... when there are women around, it's kind of ...... uncomfortable ……
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

— After two years, I was settled in my new job.
[cpg]

There is only one secret. “Don't think about anything”.
[cpg]

;//(Y):流用
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『寝室』（朝）******************************************************

;//雅人：寝間着
;//早苗：制服＋エプロン
;//葉月：制服

[OnName num="masato"]
“Hmmm ..…”
[cpg cn=true]

[SE f="se029"]
;//【ＳＥ】『ゆさゆさ』

Bop bop.
[cpg]

I feel like my bed is vibrating slightly.
[cpg]

No, no, this is my body being shaken.
[cpg]

[VOICE f="Sanae001"]
[OnName num="sanae"]
“Masato, it's morning, please wake up.”
[cpg cn=true]

;//●ＣＧ非エロ（雅人：寝間着・早苗：制服＋エプロン・寝ている雅人を起こす早苗・寝室：朝）ev_01
;//_0　天井を背に早苗が覆いかぶさる感じで起こしている　笑顔
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[SE f="se029"]
;//【ＳＥ】『ゆさゆさ』

[VOICE f="Sanae002"]
[OnName num="sanae"]
“Look! It's time for breakfast! I’m going to make it for you.”
[cpg cn=true]

[OnName num="masato"]
“Hey, let me sleep ……!"
[cpg cn=true]

The atmosphere of the shared house, which had been full of men changed since two men left and two new women came to live here.
[cpg]

;//(Y):シェアハウスの同居人という設定につき別苗字にしました
;//(Y):20230802さらに変更。輝月　だと葉月と、月の字が被るため

So, my restful sleep is being interrupted by this nosy school student, Sanae Kouno, who loves to cook.
[cpg]

[VOICE f="Sanae003"]
[OnName num="sanae"]
“You said you liked pancakes and bacon and eggs, didn't you? I'm going to make them so you can eat it while it’s still hot.”
[cpg cn=true]

[VOICE f="Sanae004"]
[OnName num="sanae"]
“Look! Wake up!”
[cpg cn=true]

[SE f="se000"]
;//【ＳＥ】『目覚し』

[OnName num="masato"]
“Ugh! The morning light ...... It’s hard on a vampire’s eyes.”
[cpg cn=true]

[VOICE f="Sanae005"]
[OnName num="sanae"]
“How can you joke like that when you’re still half asleep?”
[cpg cn=true]

[OnName num="masato"]
“I had a lot to drink last night, so I'm surprised by how articulate I am when I’m still hungover."
[cpg cn=true]

[OnName num="masato"]
“...... But I feel light-headed.”
[cpg cn=true]

;//_a　寝ぼけておっぱい掴む、揉む　感じる顔

[SE f="se029"]
;//【ＳＥ】『ふにん　おっぱい触る』

;//;**【ＣＧ】 ev_01_a ***********************
;//[CG id=0 index=0 time=1]
;//;***************************************
;//[WAIT time=1]

[VOICE f="Sanae006"]
[OnName num="sanae"]
“Ahhh!”
[cpg cn=true]

[OnName num="masato"]
“Ugh …. The alarm clock feels …… soft?”
[cpg cn=true]

The feeling in my hand feels like something is not right. It felt like pudding.
[cpg]

[VOICE f="Sanae007"]
[OnName num="sanae"]
“That's not the alarm, it's ……! Hey ……!"
[cpg cn=true]

[VOICE f="Sanae008"]
[OnName num="sanae"]
Ahhh, ughhhh.
[cpg cn=true]

I'm still a little hungover. I can’t see what’s right in front of me.
[cpg]

When I grab the alarm, my fingers slip into something soft.
[cpg]

And no matter how hard I push and push, the sound never stops. That’s strange.
[cpg]

[VOICE f="Sanae009"]
[OnName num="sanae"]
“Kun-nun…ah...ah...ah..."
[cpg cn=true]

[SE f="se026"]
;//【ＳＥ】『バンバン　畳たたく』

[VOICE f="Sanae010"]
[OnName num="sanae"]
“No …… enough!”
[cpg cn=true]

;//ＢＫ
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


[SE f="se049"]
;//【ＳＥ】『ビンタ』

;//　画面　揺れる

[VOICE f="Sanae011"]
[OnName num="sanae"]
“Hmph!”
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=1000]

;//【ＢＧ】『空』（朝）******************************************************

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声　雀？』

[WAIT time=2000]


[window target=false]
[free time=1000]
[BG f="b_00_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『居間』（朝）******************************************************

;//【ＳＥ】『ふすま』

I went to the living room, rubbing my battered and bruised arms and face. Sanae seemed to be cooking in the kitchen.
[cpg]

[OnName num="masato"]
“Speaking of which, Sanae?”
[cpg cn=true]

[OnName num="masato"]
“You used the self-defense I taught you.”
[cpg cn=true]

[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Haduki001"]
[OnName num="haduki"]
“What's with your face?”
[cpg cn=true]

[OnName num="masato"]
“Oh, Hazuki. Good morning.”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Haduki002"]
[OnName num="haduki"]
“What did you do to make my big sister hit you so hard?”
[cpg cn=true]

[OnName num="masato"]
“I …… mistook her for my alarm clock and grabbed her breasts.”
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Haduki003"]
[OnName num="haduki"]
“I started living here because I heard this shared house had a security guard. But I guess it has the opposite effect.”
[cpg cn=true]

[OnName num="masato"]
“I have nothing to say in return.”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

Sanae and Hazuki are sisters. They have opposite personalities from each other.
[cpg]

Sanae is the one who comes to wake me up in the morning and is so kind, diligent, and capable that she is still in the kitchen preparing breakfast for me.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Haduki004"]
[OnName num="haduki"]
“If it were me, I'd put you in charge of cleaning toilets and baths for the next four weeks as a punishment.”
[cpg cn=true]

Hazuki was well …… as you could see. She’s a good girl at heart, but lately, she's been particularly foul-mouthed.
[cpg]

[OnName num="masato"]
“Well ……, you'll just have to tolerate me.”
[cpg cn=true]

;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sanae012"]
[OnName num="sanae"]
“Please give me two cat cafe coupons! Then I'll forgive you!”
[cpg cn=true]

[OnName num="masato"]
“Not the cat cafe coupons!!!!!”
[cpg cn=true]

[OnName num="masato"]
"Forgive me! I'll clean the toilet and the bathtub!”
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Haduki005"]
[OnName num="haduki"]
“That seems like a better deal to me too.”
[cpg cn=true]

In our shared house, the dominant currency is a coupon for the neighborhood cat cafe.
[cpg]

The rough and tumble of the yen and the dollar has no place on this rural feline island.
[cpg]

The rent is deducted from the account. In this warring age of points and credit cards, no one has bulky cash.
[cpg]

[SE f="se036"]
;//【ＳＥ】『着信』

;//●ＣＧ非エロ（雅人：スーツ・葉月：制服・腹這いで携帯いじってる・居間）ev_02
;//ev_02_0　携帯に夢中　真顔　朝

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[VOICE f="Haduki006"]
[OnName num="haduki"]
“Oh, the professor is sending me a reminder. I have to reply to this.”
[cpg cn=true]

Hazuki lies down and starts playing on her phone.
[cpg]

[VOICE f="Sanae013"]
[OnName num="sanae"]
“Breakfast is ready. Please help me carry the food.”
[cpg cn=true]

[OnName num="masato"]
“I'm on my way. Come on, Hazuki, help us out.”
[cpg cn=true]

[VOICE f="Haduki007"]
[OnName num="haduki"]
“I'll go get it after I hand in the assignment.”
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[SE f="se007"]
;//【ＳＥ】『カチャカチャ　食器』
;//[SE f="se001"]
;//【ＳＥ】『足音』

The breakfast laid out was freshly made and it looked delicious. ......That's a cinnamon apple Dutch baby pancake!
[cpg]

[OnName num="masato"]
“Bon appétit! Bacon and eggs look good too.”
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Sanae014"]
[OnName num="sanae"]
“Bon appétit!”
[cpg cn=true]

I thank Sanae and the ingredients for making it and put my hands together.
[cpg]

As for the rent, I pay more. That is because Sanae cooks for me. That made me happy.
[cpg]

;//_0　携帯に夢中　真顔
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[VOICE f="Haduki008"]
[OnName num="haduki"]
"...... Mmhh ......"
[cpg cn=true]

Only one person was on their phone.
[cpg]

[OnName num="masato"]
"Your food is getting cold! Today we're having a Hawaiian-style breakfast! There are even acai bowls!”
[cpg cn=true]

[VOICE f="Haduki009"]
[OnName num="haduki"]
“Hold on! I’m emailing my professor.”
[cpg cn=true]

[SE f="se007"]
;//【ＳＥ】『カチャカチャ　食器』

;//_a　叱咤にご機嫌斜め　ジト目で睨む
;**【ＣＧ】 ev_02_a ***********************
[CG id=1 index=1 time=1]
;***************************************
[WAIT time=1]

[SE f="se000"]
;//【ＳＥ】『携帯ポチポチ』

[VOICE f="Haduki010"]
[OnName num="haduki"]
"....... Masato."
[cpg cn=true]

[VOICE f="Haduki011"]
[OnName num="haduki"]
“How do I email a superior? Can you help me?”
[cpg cn=true]

[OnName num="masato"]
“It's your professor, right? It's okay to keep it short. It's better than a long e-mail.”
[cpg cn=true]

[VOICE f="Haduki012"]
[OnName num="haduki"]
“It's the professor of urban design in medieval Germany I was talking about the other day. He's in charge of creating problems. Professor Rogela.”
[cpg cn=true]

[OnName num="masato"]
“......, I was late for a test and got a fail ……”
[cpg cn=true]

[VOICE f="Haduki013"]
[OnName num="haduki"]
“He is a former Vtuber, the grandpa professor-type. He is still active at the age of 84 due to recent medical developments. He is also very particular about manners.”
[cpg cn=true]

That's certainly a nerve-wracking person to send an e-mail to ......
[cpg]

I'm just a lowly security guard. I'm not sure I can do it, but I'll help.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_00_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（朝）******************************************************

;//[SE f="se000"]
;//【ＳＥ】『テレビ音』

;//@
;//[OnName num="caster"]
“{Now, the news.}”
[cpg]

I was intrigued by the TV news that was suddenly playing in the back.
[cpg]

;//●ＣＧ非エロ（キャスター：スーツ・ニュース番組　キャスターと逮捕された研究者の映像・テレビ）ev_03
;//●ＣＧ非エロ（START細胞は時事ネタなので変えます。「光原-坂田NPQ細胞」という適当な名前をでっちあげました。が「文字数が長くて画像に直しにくい！」とかあったらシナリオでも合わせます）ev_03
;//ev_03_0　研究者逮捕のニュース
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

;//_0　研究者逮捕のニュース

;//@
;//[OnName num="caster"]
“{An employee of Marsali Brothers Laboratories was arrested early this morning for conducting illegal experiments.}”
[cpg]

[OnName num="masato"]
“Gee, it's a rival company!”
[cpg cn=true]

The screen showed a person in a white lab coat being taken by the police and put into a police car.
[cpg]

The scene is so common in both TV dramas and in real life that you can't help but say, “Oh, no, not this again.”
[cpg]

;//(Y):ここ時事ネタなので変えます

[OnName num="employee"]
“{‘The Kohara-Sakata NPQ cell is not illegal! I just wanted to save my wife!’, the criminal protested. }”
[cpg cn=true]

;//@
;//[OnName num="caster"]
“{The truth is still under investigation.}”
[cpg]

...... Isn't this the result of the research of that company that I'm guarding?
[cpg]

;//(Y):セピア色とか、シネマスコープ（上下に黒画像を表示するあれ）にして回想だとわかるようにしてください。この主人公が研究所のガチめの内部を見た回数は少ない設定です

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所内部』（回想）******************************************************

We are a company, but in reality, we are a secret government-controlled research institute. After working for the company for two years, I know what's going on.
[cpg]

The government is involved behind the scenes. Ostensibly, it is a private company.
[cpg]

So, other companies are trying to outdo this company in every way possible.
[cpg]

There is too much of a difference in the financial strength that supports the company. So it seems like the ants are trying to topple the gigantic metal statue.
[cpg]

I kind of pity the rival companies …….
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（朝）******************************************************

[OnName num="masato"]
“Thanks for the food, I'm off to work.”
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Sanae015"]
[OnName num="sanae"]
“Have a good day, Masato.”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sanae016"]
[OnName num="sanae"]
“I’m so glad you liked my food. It showed in the way you were eating it, which I thought was cute.”
[cpg cn=true]

[OnName num="masato"]
“What?”
[cpg cn=true]

[free time=300]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Haduki014"]
[OnName num="haduki"]
“Good luck at work ….. munch, munch.”
[cpg cn=true]

It was not a relaxed commute .......
[cpg]

I hope it's not my security skills that caused the research samples to leak ……
[cpg]

;//(Y):新規

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（朝）******************************************************

[OnName num="masato"]
“No one in this town has noticed what is actually going on.”
[cpg cn=true]

…… My company is studying a new organism brought back from an exoplanet expedition.
[cpg]

[OnName num="masato"]
“Since about 2019, extraterrestrial life forms have been discovered.”
[cpg cn=true]

[OnName num="masato"]
“The state is hiding its existence from the people and secretly letting us study it.”
[cpg cn=true]

There are flashy advertisements on street monitors. That's the front. The truth is always stirring behind the scenes.
[cpg]

[OnName num="masato"]
“It's a world of conspiracy theories. Damn ……"
[cpg cn=true]

;//(Y):以下は流用

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社』（昼）******************************************************

;//雅人：スーツ
;//美咲：スーツ

[SE f="se057"]
;//【ＳＥ】『キーボード』

[OnName num="masato"]
“Well ... I finished filling out the paperwork for the security plan.”
[cpg cn=true]

[OnName num="masato"]
“Oh no, there’s a typo. Watch out, watch out.”
[cpg cn=true]

[OnName num="masato"]
“I’ll just fix it and submit it.”
[cpg cn=true]

;//[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki005"]
[OnName num="misaki"]
“Thanks for your hard work, Mr. Fujita. Here's your coffee.”
[cpg cn=true]

;//●ＣＧ非エロ（R18版と同じ）ev_04
;//●ＣＧ非エロ（雅人：スーツ・美咲：スーツ・差し出すような格好・会社：昼）ev_04
;//ev_04_0　コーヒー差し出す　笑顔　昼
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_04_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[OnName num="masato"]
“Thanks, Misaki.”
[cpg cn=true]

[VOICE f="Misaki006"]
[OnName num="misaki"]
“I didn't expect to be promoted in two years. ...... I was just a junior until recently.”
[cpg cn=true]

[OnName num="masato"]
“You know, the former head of security at East Wing 2 was caught trying to go into hiding in an old boat in Okinawa."
[cpg cn=true]

[OnName num="masato"]
“I was just lucky.”
[cpg cn=true]

This "Misaki" person, somehow moves from place to place.
[cpg]

She moves from one position to the other. I thought it was weird.
[cpg]

She used to be a boss and then she became the head of some other department, and the next day she was doing office work ......
[cpg]

Perhaps - she was an internal spy hunter.
[cpg]

That was quite terrifying. I have no problem with it, though, because I’m not causing any trouble.
[cpg]

[VOICE f="Misaki007"]
[OnName num="misaki"]
“You seem like you’re dealing with something. What's troubling you?”
[cpg cn=true]

[OnName num="masato"]
“This morning I accidentally ...... touched my roommate's breasts by mistake. I thought it was my alarm clock.”
[cpg cn=true]

[VOICE f="Misaki008"]
[OnName num="misaki"]
"Oh, that's very like you. You are a very naughty man.”
[cpg cn=true]

[VOICE f="Misaki009"]
[OnName num="misaki"]
“The other day, you got drunk and touched my body as well.”
[cpg cn=true]

[OnName num="masato"]
“I didn't do it! I didn't do it. Please don't make up a story.”
[cpg cn=true]

[VOICE f="Misaki010"]
[OnName num="misaki"]
“Well, I wouldn't mind if you just came on to me.”
[cpg cn=true]

[OnName num="masato"]
“That's enough of your jokes ……"
[cpg cn=true]

She was scary ....... Everything she said seemed like a trap.
[cpg]

;//_a　コーヒー差し出す　にやけ顔
;//ev_04_a　コーヒー差し出す　にやけ顔　昼
;**【ＣＧ】 ev_04_a ***********************
[CG id=3 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Misaki011"]
[OnName num="misaki"]
“Did you hear the news this morning? It’s a former employee of ours.”
[cpg cn=true]

[OnName num="masato"]
"......"
[cpg cn=true]

[OnName num="masato"]
"...... What's going to happen to him ......?"
[cpg cn=true]

I was curious.
[cpg]


[VOICE f="Misaki012"]
[OnName num="misaki"]
“Well, if the world finds out about it, …… it's not going to be good for him.”
[cpg cn=true]

Was the guy who was arrested actually ‘hunted down’?
[cpg]

[VOICE f="Misaki013"]
[OnName num="misaki"]
“It’s nothing compared to What I know about this company.”
[cpg cn=true]

[OnName num="masato"]
“Hmm …… Maybe you should have gone into the news.”
[cpg cn=true]

[VOICE f="Misaki014"]
[OnName num="misaki"]
“I don’t know. I think it’s more of a hobby. I’m just the kind of person who can't help looking things up when I'm curious.”
[cpg cn=true]

I guess I’ll just leave the conversation as that.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社』（昼）******************************************************


I looked over at Misaki returning to work, and I took a seat.
[cpg]

[SE f="se057"]
;//【ＳＥ】『キーボード』

[OnName num="masato"]
"Hmmm ....... I can’t concentrate like this ……"
[cpg cn=true]

[OnName num="masato"]
“…… I’ll just quickly correct the typos in the paperwork and submit it.”
[cpg cn=true]

;//(Y):以下は新規シーン。仕事のディテールを彫りこんで主人公の解像度を上げたい

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所前』（夕方）******************************************************

[OnName num="masato"]
“Please take care of the security behind the building.”
[cpg cn=true]

[OnName num="security_guard"]
"Yes, sir."
[cpg cn=true]

[OnName num="masato"]
“The news will probably bring the press here. Get the name of the broadcaster and the person in charge and report it back to me.”
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（夕方）******************************************************

The news was being broadcast on a large monitor on the wall of the building.
[cpg]

;//@
;//[OnName num="caster"]
“{Next, the news.}”
[cpg]

;//@
;//[OnName num="caster"]
“{The condition of the arrested Marsali Brothers Laboratories employee has suddenly changed and he is unconscious and in critical condition.}”
[cpg]

[OnName num="masato"]
“Oh no.”
[cpg cn=true]

;//[OnName num="caster"]
“{According to the police, he took some kind of pill that was hidden in his pocket.}”
[cpg]

[OnName num="man_walking"]
“What? There's no way the police would overlook something like that ……”
[cpg cn=true]

[OnName num="woman_walking"]
“I wonder if the police made him take it. This is scary.”
[cpg cn=true]

He said in the news that he just wanted to save his wife.
[cpg]

A man who is perceived as one of the bad guys on TV. He may have been a really bad person, but he was a human.
[cpg]

He will die this way and eventually be forgotten.
[cpg]

[OnName num="masato"]
“Ugh, ugh ……!!!"
[cpg cn=true]

I felt nauseous. I thought it was toward other people, but after a while, I realized it was toward me.
[cpg]

I might be saved if I screamed out loud my company’s secret within this crowd.
[cpg]

— It was this country that killed him! The very country you are walking in right now!
[cpg]

;//(Y):新規。株を上げたり下げたりしたい

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（夕方）<『童貞喰い』流用>******************************************************


[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki015"]
[OnName num="haduki"]
“If it isn’t Masato. Going home?”
[cpg cn=true]

[OnName num="masato"]
“Yeah. ...... I guess you are too, Hazuki.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki016"]
[OnName num="haduki"]
“Wait. You are blue in the face. Go sit on that bench over there, you look sick.”
[cpg cn=true]

I didn't have enough energy to talk back. I sat down on the bench.
[cpg]

[free time=800]

She ran to a vending machine and held up her phone against the payment screen.
[cpg]

;//【ＳＥ】自動販売機でモノを買う時のがごん！　という音

[SE f="se001"]
;//【ＳＥ】『歩く』

[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Haduki017"]
[OnName num="haduki"]
“Here you go, marron cinnamon tea.”
[cpg cn=true]

[OnName num="masato"]
“Thank you. Sorry about that. I'll give you a coupon for the public bath later.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki018"]
[OnName num="haduki"]
“A hungover Masato would look really good on social media, but I guess today is not the day.”
[cpg cn=true]

[OnName num="masato"]
"Hazuki, you really have a bad hobby.”
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Haduki019"]
[OnName num="haduki"]
“Just drink this for now and go to bed. I'll take care of the grocery shopping today.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki020"]
[OnName num="haduki"]
“All right I’ll head home then.”
[cpg cn=true]

[free time=800]
[SE f="se001"]
;//【ＳＥ】『歩く』

Hazuki left.
[cpg]

[OnName num="masato"]
I don’t know whether she is a good person or not.
[cpg cn=true]

;//ＢＫ

;//(Y):流用
;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（夕）******************************************************

;//雅人：スーツ
;//早苗：制服＋エプロン
;//葉月：制服

;//[SE f="se002"]
;//【ＳＥ】『玄関　引き戸』

[OnName num="masato"]
“I'm home.”
[cpg cn=true]


;//●ＣＧ非エロ（改変無し）ev_05
;//●ＣＧ非エロ（雅人：スーツ・早苗：制服＋エプロン・家につくと早苗が出迎えてくれた・玄関：）ev_05
;//ev_05_0　エプロンで手を拭きながら　小走り　笑顔　夕方
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_05_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

;//【ＳＥ】『小走り　スリッパ』

[VOICE f="Sanae017"]
[OnName num="sanae"]
“Welcome back. You were home early today.”
[cpg cn=true]

[OnName num="masato"]
“Yeah, I had some business to take care of.”
[cpg cn=true]

[VOICE f="Sanae018"]
[OnName num="sanae"]
“I'll carry your bag.”
[cpg cn=true]

[OnName num="masato"]
“Oh, I might have brought home some notes from the meeting. They are confidential, so that’s okay. But thanks.”
[cpg cn=true]

[VOICE f="Sanae019"]
[OnName num="sanae"]
“Oh, wow! Please be careful.”
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（夕）******************************************************

[SE f="se029"]
;//【ＳＥ】『座る』

[OnName num="masato"]
“Hmm, it's nice to be home after all.”
[cpg cn=true]

The great thing about living in a shared house is that there is a reasonable distance between people. You are not as close as a family member which is better. The two of us are sisters, though.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sanae020"]
[OnName num="sanae"]
“Please wait for me, I'll prepare dinner.”
[cpg cn=true]

[OnName num="masato"]
“Well, I guess I’ll have a drink until then.”
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sanae021"]
[OnName num="sanae"]
"Oh, please, moderate your drinking."
[cpg cn=true]

[OnName num="masato"]
“I know, I know.”
[cpg cn=true]

[free time=800]

By the way, Hazuki should have come home first. I wonder if she went grocery shopping.
[cpg]

;//[SE f="se002"]
;//【ＳＥ】『玄関　引き戸』
;//　葉月が無言で帰宅。早苗玄関に向かうため立ち絵消して下さい
[WAIT time=1000]

As I thought about that she came back. It smells like hot spring water.
[cpg]

I said I'd give her a coupon, so she probably stopped by the bathhouse.
[cpg]

[VOICE f="Sanae022"]
[OnName num="sanae"]
“Hazuki, welcome back.”
[cpg cn=true]

[VOICE f="Haduki021"]
[OnName num="haduki"]
“I told you you don’t have to greet me each time.”
[cpg cn=true]

[VOICE f="Sanae023"]
[OnName num="sanae"]
“So? I like doing it.”
[cpg cn=true]

[SE f="se010"]
;//【ＳＥ】玄関チャイム
[WAIT time=1000]

“Anyway, I have a delivery for you.”
[cpg]

[OnName num="masato"]
“Please leave it here.”
[cpg cn=true]

;//(Y):この椅子が後に姉妹のどちらのルートへ行くかの選択肢に。

I had ordered a chair. I'll bring it inside later.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//(Y):この場面に葉月はいません。風呂に行ってます

[OnName num="masato"]
“You have to assemble the chair on your own. I guess I could do it later.”
[cpg cn=true]

Sanae was cleaning up the dining table. She is preparing to take the chef's exam at the school. She seems to have no trouble washing the dishes.
[cpg]

I'd like to help, but she always rejects it. I've heard that they teach her not to neglect cleaning up.
[cpg]

And then, I managed to carry the chair, but I realized that I was more tired than I had expected. It was after work so ……
[cpg]

[OnName num="masato"]
“Let’s draw the bath.”
[cpg cn=true]

I headed for the shower room. I wonder where Hazuki is. She smelled like she had already been to the bathhouse. Was she in her room?
[cpg]


[SE f="se019"]
;//【ＳＥ】『ガチャ　脱衣所のドア』

;//ＢＫ
;//●ＣＧ非エロ（湯けむりで全年齢相当にしてください）ev_06
;//●ＣＧエロ（雅人：スーツ・葉月：裸・夜中のハプニング・脱衣所：夜電気ON）ev_06
;//ev_06_0　脱衣中の葉月　きょとんとした顔
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_06_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[VOICE f="Haduki022"]
[OnName num="haduki"]
“What?”
[cpg cn=true]

[OnName num="masato"]
“Huh?”
[cpg cn=true]

Hazuki was in the middle of changing her clothes.
[cpg]

[OnName num="masato"]
“Oh, umm ……”
[cpg cn=true]

[OnName num="masato"]
“I thought you had gone to the public bath. Um …… Are you gonna take a second bath?”
[cpg cn=true]

[VOICE f="Haduki023"]
[OnName num="haduki"]
“That was sis …..”
[cpg cn=true]

I realize that I shouldn't have judged by smell.
[cpg]

It was Sanae who went to the public bath ......
[cpg]

[OnName num="masato"]
“Oh, oh ……”
[cpg cn=true]

[VOICE f="Haduki024"]
[OnName num="haduki"]
“So ...... get out of here!”
[cpg cn=true]


[OnName num="masato"]
“Sorry!”
[cpg cn=true]

[SE f="se019"]
;//【ＳＥ】『ガチャ　脱衣所のドア』

;//ＢＫ
;//(Y):そろそろ生活の厚みを出したと思うので本題へ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[BG f="b_10_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************

;//@
;//[OnName num="caster"]
“{Four members of the fraudulent criminal group ‘Ikkaku’ escaped from prison in Kayamichi District.}”
[cpg]

I listened to the news on the street monitor as usual, still thinking about what had happened with Hazuki yesterday.
[cpg]

;//@
;//[OnName num="caster"]
“{About the remote examinations of the New Fujika Culture University, using a method of creating a fake account and having a 34-year-old man send money …….}”
[cpg]

[OnName num="masato"]
“Aren’t those the guys that I arrested: ……?"
[cpg cn=true]

The district had been developed and there is only a limited number of places where no one cares or where people are inconspicuous. So ......
[cpg]

;//(Y):主人公の通勤で移動するのにともない、場所についての言及もそちらで

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[BG f="b_13_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所前』（朝）******************************************************

The building used by this shady company and the "Ikkaku" group were right next door to each other.
[cpg]

[OnName num="masato"]
“Wow. ...... I can see it from here. It was that building over there. I'm sure.”
[cpg cn=true]

So, as a lowly security guard, I looked around and thought their comings and goings looked suspicious, so I stopped them.
[cpg]

It turned out to be a real scam group, and the police had to be called in to deal with them.
[cpg]

[OnName num="masato"]
“I was afraid my company was going to release me.”
[cpg cn=true]

;//(Y):流用

[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se057"]
;//【ＳＥ】『キーボード』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社』（夜電気ON）******************************************************

;//雅人：スーツ
;//美咲：スーツ

[OnName num="masato"]
“Damn ….. it's not going to be easy.”
[cpg cn=true]

There had been a mistake about the division of security, and they were recreating it as they went along.
[cpg]

[OnName num="masato"]
"...... but even so …"
[cpg cn=true]

[OnName num="masato"]
“They have a security system where the lowly don't know about the whole system ……"
[cpg cn=true]

“I'm a reasonably good worker, but even so, they don't give out all the maps of this building.”
[cpg]

The map I have has mysterious blank spaces on the first and second basement floors that I don't need to know about. Even on the second and third floors, there were a lot of secret spaces.
[cpg]

;//(Y):回想。またセピアとかシネマスコープとかでそれっぽく

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所内部』******************************************************

The back of the building, where I was once taken, seems to have recently become a secret room.
[cpg]

The section in question was also a blank space.
[cpg]

What was it that I saw? It seemed to be called simply “the central basement floor”.
[cpg]

;//(Y):回想おわり。
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;//ＣＧ非エロ（R18版と同じ）ev_04
;//(Y):原文に指示があったので同じように書いてますが、二回目のCG表示のよう？　実際のゲーム内でどう演出されているかを確認してないですがCGの扱いはおまかせします
;//●ＣＧ非エロ（雅人：スーツ・美咲：スーツ・差し出すような格好・会社）ev_04
;//ev_04_b　お酒差し出す　笑顔　夜電気ON
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_04_b ***********************
[CG id=3 index=2 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[VOICE f="Misaki015"]
[OnName num="misaki"]
“Hello, Mr. Fujita. Here's your drink.”
[cpg cn=true]

[OnName num="masato"]
“Alcohol on duty? I'll have some, but maybe later.”
[cpg cn=true]

[VOICE f="Misaki016"]
[OnName num="misaki"]
“I'll put it in the fridge. You’re working so late today.”
[cpg cn=true]

[OnName num="masato"]
“Haha ….”
[cpg cn=true]

;//_c　お酒差し出す　にやけ顔　夜電気ON
;**【ＣＧ】 ev_04_c ***********************
[CG id=3 index=3 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Misaki017"]
[OnName num="misaki"]
“By the way, I've got a little proposition for you.”
[cpg cn=true]

[OnName num="masato"]
“What?”
[cpg cn=true]

[VOICE f="Misaki018"]
[OnName num="misaki"]
“Mr. Fujita, you saw ‘that room’ a long time ago.”
[cpg cn=true]

That room. …… I knew what she was talking about. It was the "central basement floor”.
[cpg]

[OnName num="masato"]
“I have a bad feeling about this …….”
[cpg cn=true]

[VOICE f="Misaki019"]
[OnName num="misaki"]
“No way. This involves a raise.”
[cpg cn=true]

[OnName num="masato"]
“You mean ...... a promotion?”
[cpg cn=true]

[VOICE f="Misaki020"]
[OnName num="misaki"]
“No. The researchers over there are asking if you would like to be a test subject for their experiments.”
[cpg cn=true]

[VOICE f="Misaki021"]
[OnName num="misaki"]
“You will get the explanation after you sign the form …… It sounds like an easy way to earn money.”
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

Misaki left the documents behind and gave me time to think.
[cpg]

The area was empty. This is a desk, but there is no confidential information here ...... except for the documents right in front of me.
[cpg]

[OnName num="masato"]
“Why does it feel like a crucial moment in my life?”
[cpg cn=true]

I had an early promotion, but even then I didn't feel this way.
[cpg]

;//(Y):普通にアホっぽい話をして緊張をときほぐす試みです

There were elitist-looking people around me, but they were just people. They were usually late for work or arrested.
[cpg]

So when I came to my senses, I felt like the people around me were dropping out on their own and I was moving up in the ranks — but this was different.
[cpg]

[OnName num="masato"]
“You want some of that booze I left you ……?"
[cpg cn=true]

;//【ＳＥ】『冷蔵庫』

;//【ＳＥ】『足音　リノリウム　ヒール』

;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I thought about it - I groaned and thought about it. And then - I signed the papers.
[cpg]

It seemed sketchy. But I wanted the money.
[cpg]

What am I being used as a test subject for?
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥のさえずり』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[BG f="b_13_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『生物研究所前』（朝）******************************************************

;//(Y):坂田はモブ。いちおう「光原-坂田NPQ細胞」の共同名付け親の一人という裏設定

[OnName num="sakata"]
“Thank you for signing the papers. I'm Sakata from the central building.”
[cpg cn=true]

[OnName num="masato"]
“Is it your day off today since you are meeting me at this hour of the day.”
[cpg cn=true]

[OnName num="sakata"]
“No, we’re about to start the experiment right now.”
[cpg cn=true]

Already? I was not prepared for this.
[cpg]

We headed to the central basement floor.
[cpg]

;//(Y):ちょっとこのあたりは重々しい演出でお願いできたら

;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=2000]

[SE f="se024"]
;//【ＳＥ】重々しい、扉の開く音をなにか

[BG f="b_12_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所内部』******************************************************

[OnName num="masato"]
“What?”
[cpg cn=true]

It was two years ago when I first entered this place.
[cpg]

New things had been added. I saw a sign that said, “Level 1 Security”. Level 1?
[cpg]

[OnName num="masato"]
“This place is a light security area ……?"
[cpg cn=true]

...... I realized that the security standards are completely different from the "East Wing 2" where I work.
[cpg]

It's a different world with its own security rules, and even the lowest level is beyond the maximum security area at East Wing 2.
[cpg]

[OnName num="masato"]
“Excuse me, is that a real gun?”
[cpg cn=true]

[OnName num="sakata"]
“It's just a model.”
[cpg cn=true]

No, it's not. But I guess that’s how it's supposed to be perceived among the researchers.
[cpg]

[OnName num="sakata"]
“I'm sure any intruder will be scared off by that.”
[cpg cn=true]

I'm not sure if that’s the case.
[cpg]

[OnName num="sakata"]
“I almost cried the other day when I was chased by a dog. That's how it is."
[cpg cn=true]

The scale of the example is too small!
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[SE f="se001"]
;//【ＳＥ】『歩く』

;//——。俺は目隠しをされたままで、部屋へと案内された。
— I was blindfolded from there and led to another room.
[cpg]

;//●ＣＧ非エロ（触手生物が公園の草むらでは無く、生物研究所のガラスの中に閉じ込められている。照明の故障のため全貌は見えない……という状態にしてください）ev_07
;//●ＣＧ非エロ（雅人：スーツ・蟲：蜘蛛のような蛸のような長くしなる足。長い触覚よくかわらない生物：公園）ev_07
;//ev_07_0　変な生物を見つける

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[SE f="se029"]
;//【ＳＥ】『衣擦れ』

;**【ＣＧ】 ev_07_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

;//@
The blindfold was removed, but the room was dark and I could not see much. I saw something moving on the other side of the glass.
[cpg]

[OnName num="masato"]
“What is that?”
[cpg cn=true]

[OnName num="mitsuhara"]
“Let me explain to you about this experiment. Byt the way, my name is Mitsuhara.”
[cpg cn=true]

[OnName num="masato"]
“It's nice to meet you.”
[cpg cn=true]

[OnName num="mitsuhara"]
“I want you to swallow the tiny somatic cells of this organism, Mr. Fujita.”
[cpg cn=true]

[OnName num="masato"]
“What ……?"
[cpg cn=true]

[OnName num="mitsuhara"]
“It’s a disgusting creature, isn't it? But I am required to explain this to you.”
[cpg cn=true]

;//(Y):流用


At first glance, it looks like a spider, but its legs are like those of an octopus, and its body is constricted like that of an ant.
[cpg]

Its long antennae are constantly twitching as it seems to be searching for something.
[cpg]

It seems to be watching us. Perhaps it was on alert.
[cpg]

[OnName num="sakata"]
“Hey, Mitsuhara, the light is still broken. You can't see much with this light.”
[cpg cn=true]

[OnName num="mitsuhara"]
“I'm sorry, but there are only a limited number of contractors who can enter here ……"
[cpg cn=true]

Mitsuhara walked over to the wall and turned on another light.
[cpg]

;//●ＣＧ非エロ（触手生物の全貌。やはり生物研究所のガラスの中に変えてください）ev_08
[window target=false]
[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=2000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

It was bizarre.
[cpg]

[OnName num="masato"]
“What …..?”
[cpg cn=true]

[OnName num="masato"]
“Ahhh …..”
[cpg cn=true]

I regretted signing the papers to be a subject of the experiment.
[cpg]

[OnName num="mitsuhara"]
“Now, back to the description of the experiment.”
[cpg cn=true]

[OnName num="mitsuhara"]
“I want you to be the host of this organism, Mr. Fujita. That means you will be parasitized.”
[cpg cn=true]

[OnName num="masato"]
“No …… no! Not a parasite! I won't do it! I will erase the signature on the document.”
[cpg cn=true]

[OnName num="masato"]
“First of all, there were no details in the document! I didn’t get an explanation. I thought it was just a clinical trial!”
[cpg cn=true]

[OnName num="mitsuhara"]
"Well, it pains me to say this, but ... due to confidentiality reasons I cannot do that ……"
[cpg cn=true]

[OnName num="mitsuhara"]
“This new plant-based organism has been proven to enhance the physical capabilities of the human body.”
[cpg cn=true]

[OnName num="mitsuhara"]
“Your body won’t have a negative reaction.”
[cpg cn=true]

[OnName num="mitsuhara"]
“It produces microfibers that can replace muscles and blood vessels inside the body.”
[cpg cn=true]

At once, I thought I was in a dream. This was a dream. The company I had worked for for two years did not exist.
[cpg]

I'll wake up from this dream soon. When I wake up, I will be on a soft bed bathing in sweat ……
[cpg]

[OnName num="mitsuhara"]
“The effectiveness of the drug has already been demonstrated with mice.”
[cpg cn=true]

[OnName num="mitsuhara"]
“It has also been proven safe in humans to a certain extent, though not 100%.”
[cpg cn=true]

[OnName num="masato"]
“No ……"
[cpg cn=true]

[OnName num="mitsuhara"]
“If it does any harm to your body, please contact the legal office as it states in the text of the signed document ……."
[cpg cn=true]

[OnName num="masato"]
“Uh …… aaaahhhh!"
[cpg cn=true]

I ran. I kicked down the chair and ran to the door.
[cpg]

[SE f="se019"]
;//【ＳＥ】『ドア開け』

[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所内部』******************************************************

Someone was waiting for me and locked me in. Many guards rushed to the door.
[cpg]

[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misaki022"]
[OnName num="misaki"]
“I guess it was too much after all.”
[cpg cn=true]

[OnName num="masato"]
“Hey ...... let go of me!”
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Misaki023"]
[OnName num="misaki"]
“No, I won't say it's not too much to ask of someone. I understand how you feel.”
[cpg cn=true]

[OnName num="security_guard_A"]
“Do you want to detain him?”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[OnName num="security_guard_B"]
“As long as the secret is not leaked, there will be no problem. Just be ready for anything.”
[cpg cn=true]

Misaki, who was holding me down, shook her head. What power. I didn't know she had this much power ......
[cpg]

[OnName num="mitsuhara"]
“I didn't know he was going to run away. What are we going to do?”
[cpg cn=true]

[OnName num="sakata"]
“I didn’t know he would resist this much ……”
[cpg cn=true]

[OnName num="sakata"]
“At least the papers are signed.”
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=2000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=3000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『会社』（夕方）******************************************************

After that, my sense of reality recovered.
[cpg]

[OnName num="employee"]
“Mr. Fujita. Where have you been?”
[cpg cn=true]

[OnName num="masato"]
“Oh, uh, ....... I was on a business trip ……"
[cpg cn=true]

[OnName num="employee"]
“I see. You were talking about installing new surveillance cameras.”
[cpg cn=true]

[OnName num="masato"]
“……."
[cpg cn=true]

In front of lay a copy of the document. A large "Confidential" mark was stamped on it as if to threaten me.
[cpg]

And beside it was a plastic bag. Inside was another paper bag containing a lemon custard pie.
[cpg]

Naturally, this was a disguise.
[cpg]

There is indeed a pie inside. However, there is a small case inside the dough.
[cpg]

A small piece of "the creature" was in there.
[cpg]

[OnName num="masato"]
“Don’t they have a manual ...... What if someone mistook this as a gift for the company?”
[cpg cn=true]

[OnName num="employee"]
“Mr. Fujita, is that a souvenir?”
[cpg cn=true]

[OnName num="masato"]
“…….!"
[cpg cn=true]

[OnName num="masato"]
“Well, my roommate loves this pie.”
[cpg cn=true]

I don't like it though ……
[cpg]

[OnName num="employee"]
“Wow! Shopping for someone special on a business trip!"
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所前』（夕方）******************************************************

Given the turn of events, I called a cab today. I didn't want to walk home.
[cpg]

;//【ＳＥ】自動車の音。なにか

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（夕方）<『童貞喰い』流用>******************************************************

I'm restless, thinking I might run into Hazuki on the way back.
[cpg]

[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_10_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（夕方）******************************************************

;//@
;//[OnName num="caster"]
“{The employee who was in critical condition passed away just a few minutes ago.}”
[cpg]

The sound is fading away. If I don't swallow that creature like this - will I be next?
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//@===================================

I quietly open the front door and tip-toe inside so that no one will notice.
[cpg]

It seemed like no one was home.
[cpg]


[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
;//【ＢＧ】『居間』（夜電気ON）

I was about to head to my room when I saw a chair that had been assembled.
[cpg]

There was a note saying, “I went out to buy a screwdriver.”
[cpg]

Sanae had tried to assemble it for me. I was very grateful.
[cpg]

;//@===================================

[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『寝室』（夜電気OFF）******************************************************

;//雅人：寝間着


I went into my room, changed my clothes, and lay down.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I was extremely tired. The bag of pie was on the desk.
[cpg]

Since this is my room, the girls would not eat it.
[cpg]

I didn't see Sanae or Hazuki. It was a good thing. Today I could .......
[cpg]

[free time=1000]
[WAIT time=1000]

;//[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Haduki025"]
[OnName num="haduki"]
“Hey! The chair is in the way! Can someone hurry up and assemble it?”
[cpg cn=true]

;//あっ。
Oh no. I forgot to move the chair.
[cpg]

;//(Y):途中まで流用


;//【ＳＥ】『家の中歩く』

[window target=false]
[free time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（夜電気ON）******************************************************

;//[SE f="se002"]
;//【ＳＥ】『玄関開ける　引き戸』

[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Haduki026"]
[OnName num="haduki"]
“Is anyone here? Sis?”
[cpg cn=true]

;//普段は帰ってくると出迎えてくれるはずの早苗が出てこない。何かあったのか出かけているのか。

[OnName num="masato"]
“Sanae is out shopping.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki027"]
[OnName num="haduki"]
“I always just let it slide because it's such a pain in the ass. Anyway, I’ve got to reply to an e-mail.”
[cpg cn=true]

;//ポチポチと携帯を弄りながら自室に向かおうと歩いていこうとして……。
Hazuki headed to her room, typing on her phone, when …….
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki028"]
[OnName num="haduki"]
“What is this?”
[cpg cn=true]

;//@
[OnName num="masato"]
“What? What's wrong?”
[cpg cn=true]

;//@
She stopped at the back of the room, so I looked to see if something was wrong. There was a tool box with its contents scattered all over the place.
[cpg]

;//工具箱の中身が散乱している。早苗はどうやら椅子を組み立てようとしたようだ。ありがたいが大惨事である。
Sanae had left it there after looking for a screwdriver. I was grateful that she was trying to assemble the chair, but this was a disaster.
[cpg]

It was a mess.
[cpg]

[OnName num="masato"]
;//「途中まで組み立てが進んでるな。後でお礼言っておこう」
“I’ll clean it up.”
[cpg cn=true]

;//俺は椅子を組み立てはじめる。
I cleaned out the scattered toolbox and assembled the chair as far as I could proceed.
[cpg]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（夜電気ON）******************************************************

;//@
[OnName num="masato"]
“...... Okay, that's done.”
[cpg cn=true]

;//早苗が帰ってきた。足りないドライバーを買ってきてくれたので、これで完成させることができた。
After that, Sanae came home and gave me the missing screwdriver so I could finish it.
[cpg]

;//@
;//[OnName num="caster"]
“{According to the police, the building where two members of the fraudulent crime group "Ikkaku" were arrested is located here ……}”
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sanae024"]
[OnName num="sanae"]
“Huh? Isn't that near your workplace?”
[cpg cn=true]

[OnName num="masato"]
“Yeah. I hope they don’t have any grudge against me.”
[cpg cn=true]

[OnName num="masato"]
“Either way, they must be dumb. I can't believe they were arrested after returning to their original base for the first time in two years.”
[cpg cn=true]

;//@
;//[OnName num="caster"]
“{The other two are currently on the run.}”
[cpg]

Sanae finished preparing the food. My chair was completed as well.
[cpg]

The two sisters were digging into the vegetable stir-fry. …… Where should I put this chair?
[cpg]

;//■選択肢
[switch]
[case "I'll sit next to Sanae."]
	[swap]
	[jump target="*select01_1"]
[case "I'll sit next to Hazuki."]
	[swap]
	[jump target="*select01_2"]
[endswitch]

*select01_1|A Strange Company
[jump storage="ep001.ks" target="*select01_1"]

*select01_2|A Strange Company
[jump storage="ep006.ks" target="*select01_2"]

;//■システム選択肢１　ルート分岐
1. I'll sit next to Sanae.
2. I'll sit next to Hazuki.
