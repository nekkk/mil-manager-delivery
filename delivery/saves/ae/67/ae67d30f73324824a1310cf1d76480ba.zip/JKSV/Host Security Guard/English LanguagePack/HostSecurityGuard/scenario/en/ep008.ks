
*start|Tracking

;#################################################
*Ep008|Tracking
;#################################################

[SCENE id=8]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Over the next few days.
[cpg]

In between jobs, I hired a detective online, had him set up cameras, and gathered information.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（朝）******************************************************

In front of Professor Rogera's house. I came here, not dressed in my usual clothes so as not to look suspicious.
[cpg]

I have the key to the house. I made a duplicate.
[cpg]

The professor is out. Probably filming a video class.
[cpg]

He won't be back for a while - the time has come for the real hunt for information.
[cpg]

[OnName num="masato"]
“What’s your motive?”
[cpg cn=true]

[OnName num="masato"]
“I'm going to find out. I came all this way.”
[cpg cn=true]

[OnName num="masato"]
“There's no other family member living here.”
[cpg cn=true]

I'm about to cross a line.
[cpg]

I have night vision goggles. They are the best out there, but to the outside world, they look like nothing more than glasses.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[BGM f="bg_t2"]
[WAIT time=100]

I enter the total darkness.
[cpg]

I am in a hallway. There is a sofa and a desk under my feet, and I feel like I am going to fall.
[cpg]

[OnName num="masato"]
“(Flower pots ...... bookshelves in the hallway? If you get your foot caught and fall, it'll make a lot of noise.)”
[cpg]

[OnName num="masato"]
"(The end ......)"
[cpg cn=true]

The temperature has begun to drop since the day of the tailgating. The house made a creaking sound. I smelled incense.
[cpg]

[OnName num="masato"]
“(Find his room.)”
[cpg cn=true]

After preliminary investigation, I could tell where the light was often on at night from outside. It was on the second floor.
[cpg]

I found a staircase. A dog barked in the neighborhood. I climbed up.
[cpg]

Finally upstairs, I open the door. It seemed to be a library. Mobile bookshelves were lined up.
[cpg]

[OnName num="masato"]
“(I’m sure it's not here. I'm sure it's full of books even if I open it ...... I'm afraid it will make noise, so I'd better not touch it.)”
[cpg cn=true]

I moved to the next room. It was a private room.
[cpg]

This is the place I was looking for. I checked my surroundings and went inside.
[cpg]

[SE f="se034"]
;//【ＳＥ】ピッ

[OnName num="masato"]
“What?”
[cpg cn=true]

Something started to move. A damp, lukewarm wind was blowing.
[cpg]

[OnName num="masato"]
“(Oh, a fan! That scared me!)”
[cpg cn=true]

I stopped the fan. I was about to curse ...... but I can't afford to do that right now.
[cpg]

This time I went to the desk, paying even more attention to my footing.
[cpg]

;//●ＣＧ非エロ（完全新規。開いたノートに文字が書かれている）ev_51
;//▼暗視メガネのフィルターがかかっている。※フィルターとノートとを分けておくと使い回しがしやすそうな気がします
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

There was a notebook. Something was written on it.
[cpg]

<This is my will.>
[cpg]

<I should not normally leave something like this behind. If I get caught, this note will get burned.>
[cpg]

<If it gets to where it's supposed to go, you can put it away in the secret shed. I am tired of secrets.>
[cpg]

[OnName num="masato"]
"......."
[cpg cn=true]

<The intellectual anarchism of the young is disgusting>.
[cpg]

<Those who deny, cynically and repeatedly say ‘at least it's not you’. Those who deny existing authority and values>.
[cpg]

<But if you ask them what they want to affirm, they cannot answer.>
[cpg]

<But once ‘found’, they see the old intellectual as lazy.>
[cpg]

<I feel no respect for professors who, once they find values to affirm, refuse to leave their isolated island.>
[cpg]

<I hate them both.>
[cpg]

<Don’t become one of them.>
[cpg]

<I write this because I do not want you to be.>
[cpg]

[OnName num="masato"]
"To whom is it addressed ......?"
[cpg cn=true]

— It said ‘my will’. It was addressed to someone close to him.
[cpg]

[OnName num="masato"]
“Perhaps to a child ……?"
[cpg cn=true]

<At first, desolation is fine. But once you find a safe place to live, don't stay there.>
[cpg]

<There are many places to live in peace.>
[cpg]

It was a private message. But it doesn't mention a secret nuclear weapon.
[cpg]

I flip the pages back to the front ......There are pages upon pages written in a foreign language, and I don't understand anything. It was not even a foreign language.
[cpg]

It was a made-up language.
[cpg]

He had developed his own language.
[cpg]

[OnName num="masato"]
"Damn ......."
[cpg cn=true]

[SE f="se019"]
;//【ＳＥ】玄関の音。
[WAIT time=1000]

[OnName num="masato"]
“……!"
[cpg cn=true]

I tried to go down the stairs. But someone had already come in the front door. — He's back!
[cpg]

Damn, I even checked the time. Why on earth did he come home so early?
[cpg]

Damn it, what do I do?
[cpg]

[OnName num="rogera"]
“Hey ……! Gah!”
[cpg cn=true]

[OnName num="masato"]
“(What the hell?)”
[cpg cn=true]

[OnName num="masato"]
“(What?)”
[cpg]

[OnName num="rogera"]
“Geeeeeeee!?”
[cpg cn=true]

[OnName num="masato"]
“(!? What? ……?)”
[cpg cn=true]

[OnName num="rogera"]
“Gaaaahhhhhh!”
[cpg cn=true]

;//[SE f="se000"]
;//【ＳＥ】音

Something is making a sound.
[cpg]

The sound of something breaking. A thumping sound like hitting the wall. The sound of bubbles leaking.
[cpg]

The sound of a package being dropped with a thud. I gasp for air.
[cpg]

[OnName num="masato"]
“(What’s going on? Should I go down and out the front door?)”
[cpg cn=true]

[OnName num="unknown"]
“Hey!”
[cpg cn=true]

It was a voice other than Professor Rogela's. A man. A voice that made me uncomfortable just listening to it. He seemed young.
[cpg]

[OnName num="unknown"]
“You're up there, aren't you? Help me out ……"
[cpg cn=true]

[OnName num="masato"]
“(! There's another person downstairs! They know that someone is upstairs.)”
[cpg cn=true]

I didn't know what was going on, so I looked around. There was a window. There seemed to be curtains hanging.
[cpg]

Someone was coming up the stairs.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（朝）******************************************************

I opened the curtains. I tried to open the window. It was rusty, and it was hard to open.
[cpg]

[OnName num="unknown"]
“Who are you? Who are you?”
[cpg cn=true]

A voice called out from behind me. I couldn't wait.
[cpg]

I ran into the half-opened window.
[cpg]

The window was shattered, and I was flying into the air.
[cpg]

[SE f="se051"]
;//【ＳＥ】『ぶつかる』

[OnName num="masato"]
"Gugg!!!!"
[cpg cn=true]

I was about to hit the ground - I caught myself. I'm trained in the company's program.
[cpg]

It was soft dirt underneath. No damage.
[cpg]

[OnName num="unknown"]
“Who the hell are you? Were you lurking ahead of us?”
[cpg cn=true]

[OnName num="unknown"]
“— !”
[cpg cn=true]

[SE f="se012"]
;//【ＳＥ】『走る』

I ran away. My legs wobbled. But I kept running.
[cpg]

I looked behind me and saw— someone leaning out the window. I saw Rogela's head drooping out the window.
[cpg]

Something - a tentacle - was holding it up.
[cpg]

As I ran, I became aware of what was happening. He was dead.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_10_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[OnName num="masato"]
“Ah, ah!”
[cpg cn=true]

[OnName num="masato"]
“Damn, damn, damn ...... My heart is still racing ……!"
[cpg cn=true]

My clothes were torn by the glass and my body was bleeding. I got in my car and drove back to town, but I didn't want people to see me.
[cpg]

[SE f="se013"]
;//【ＳＥ】『携帯電話の着信音』

Then the phone rang.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[OnName num="detective"]
“Mr. Fujii! It’s me!”
[cpg cn=true]

It was a detective. He is helping me with the preliminary stakeout and tailgating. He is a specialist in affairs and other investigations, but he has a good reputation.
[cpg]

[OnName num="detective"]
“I've been working on a case that was a bit odd for a professor, so I was curious to see if he'd still be running his designated camera, and I came to collect it.”
[cpg cn=true]

[OnName num="masato"]
“What? Are you around his place?”
[cpg cn=true]

[OnName num="detective"]
“What is that?”
[cpg cn=true]

[OnName num="detective"]
“It’s a tentacle ……"
[cpg cn=true]

[OnName num="detective"]
“Oh, no, no, no, no, no”
[cpg cn=true]

[OnName num="masato"]
“!”
[cpg cn=true]

[OnName num="unknown"]
“Mr. Fujii? Hello?”
[cpg cn=true]

[OnName num="unknown"]
“I thought you were one of us. I thought you were here first, lurking to help me out.”
[cpg cn=true]

[OnName num="masato"]
“What ……!"
[cpg cn=true]

I heard something snap. I think he was killed, at this moment, on the other end of the phone.
[cpg]

I don't even know this guy. But he was killed.
[cpg]

[OnName num="unknown"]
“Why are you scared? This is probably not even your real phone number.”
[cpg cn=true]

[OnName num="unknown"]
“I know you’re not one of us, but that doesn't mean you’re one of them.”
[cpg cn=true]

[OnName num="unknown"]
“You are the guy who was upstairs, right? You were the first one to sneak in.”
[cpg cn=true]

My fingers trembled.
[cpg]

[OnName num="masato"]
“Why did you kill ……?"
[cpg cn=true]

[OnName num="unknown"]
“Why should I answer that? I'm not going to tell you.”
[cpg cn=true]

[OnName num="unknown"]
“What do you want? The notebook?”
[cpg cn=true]

[OnName num="unknown"]
“I'm interested in you. I'm so interested in you, I could send you a heart emoji.”
[cpg cn=true]

[OnName num="unknown"]
“I guess I could tell you something.”
[cpg cn=true]

[OnName num="unknown"]
“He was a foreign spy.”
[cpg cn=true]

;//(Y):ここは間違いを言っている。葉月を捕まえさせるのがロジェラの目的

[OnName num="unknown"]
“He was probably trying to steal some research.”
[cpg cn=true]

I checked my surroundings. What's the benefit for him of giving me this information?
[cpg]

[OnName num="masato"]
“(He is trying to buy time.)”
[cpg cn=true]

There is a car coming up behind me. Chrome red with a black streamlined design.
[cpg]

It's the car of the dead Professor Rogera.
[cpg]

[OnName num="masato"]
“Damn!”
[cpg cn=true]

I started the car.
[cpg]

I don't have time to hang up the phone. Besides, I feel like I need to keep talking.
[cpg]

[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（昼）******************************************************

I drive away. There was a busy road around the perimeter of the park.
[cpg]

I had to avoid many cars.
[cpg]

[OnName num="unknown"]
“My men call me ‘one wing’.”
[cpg cn=true]

[OnName num="one_wing"]
“My man made a mistake in administering first aid to my lung, because of this plastic umbrella.”
[cpg cn=true]

[OnName num="masato"]
“What? What's the point of giving me that information?”
[cpg cn=true]

[OnName num="one_wing"]
“Nothing. Do you think people are that profit-oriented?”
[cpg cn=true]

[OnName num="one_wing"]
“Anyway, Mr. Fujii, I know about you. I know who you are.”
[cpg cn=true]

[OnName num="one_wing"]
“It's not Fujii, it's Fujita!”
[cpg cn=true]

[OnName num="masato"]
“What?”
[cpg cn=true]


[SE f="se048"]
;//【ＳＥ】『急ブレーキ』

I almost hit a car. A white family car with a family inside.
[cpg]

[SE f="se052"]
;//【ＳＥ】『クラクション』

The sound of a horn. In the side-view mirror, I can see what's going on behind me - a woman who was the driver did not look happy.
[cpg]

[OnName num="one_wing"]
“The other day, all four members of the ‘Ikkaku’ group were arrested.”
[cpg cn=true]

[OnName num="masato"]
“What's that got to do with anything? It's a con group ……!”
[cpg cn=true]

[OnName num="one_wing"]
“I'm a man of principle.”
[cpg cn=true]

[OnName num="one_wing"]
They all broke out of jail to get to you.
[cpg cn=true]

[FADEOUTBGM]

I saw something strange again. The white family car from earlier was headed toward us.
[cpg]

[OnName num="masato"]
“What?”
[cpg cn=true]

[SE f="se071"]
;//【ＳＥ】『爆発』
;//赤フラッシュ

Suddenly, it was smashed and an explosion occurred.
[cpg]

[BGM f="bg_hp"]
[WAIT time=100]

[OnName num="masato"]
“What did you ...... do?”
[cpg cn=true]

[OnName num="one_wing"]
“I took their job because I wanted to kill you!”
[cpg cn=true]

[OnName num="one_wing"]
“They found you sooner than I thought!”
[cpg cn=true]

There were screams all around. Cars sped off one after another, making U-turns, creating chaos.
[cpg]

[SE f="se071"]
;//【ＳＥ】『爆発』
;//赤フラッシュ

A car was thrown at them again.
[cpg]

[OnName num="masato"]
“(What’s going on? Why is the car ……. Aaaaah!)”
[cpg]

In the side-view mirror, that tentacle that killed Professor Rogela was spread out in the driver's seat of the car behind him.
[cpg]

;//セピア色で一瞬だけ表示

;//●ＣＧ非エロ（再利用）ev_08
[window target=false]
[free time=1000]
[BG f="b_ev_08.ui" time=1000]
[WAIT time=1000]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（昼）******************************************************

[OnName num="masato"]
“!!”
[cpg cn=true]

[OnName num="masato"]
“You're not working for that company, are you?”
[cpg cn=true]

[OnName num="one_wing"]
“You mean the tentacles? It’s just a leaked research.”
[cpg cn=true]

[OnName num="masato"]
“No! You think you can lie about that after what you did to Rogela?”
[cpg cn=true]

[OnName num="masato"]
“That piece of shit company hired you! You killed Rogela— This was all just work for you.”
[cpg cn=true]

[OnName num="masato"]
“Now you're coming after me on a personal vendetta!”
[cpg cn=true]

[OnName num="one_wing"]
“Hmm.”
[cpg cn=true]

[OnName num="one_wing"]
“Well, I will admit it. I don't give a shit about that company.”
[cpg cn=true]

[OnName num="masato"]
“Fuck you!”
[cpg cn=true]

Hazuki's in danger.
[cpg]

Sanae is in danger, too.
[cpg]

If they were able to get rid of Rogela this quickly, they would be on to the next mission……
[cpg]

;//(Y):視点変更トランジション

;//(Y):グラフィック要望リストをご確認ください。
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_15_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『空港ロビー』（昼）******************************************************

We took the train, then the bus, and arrived at the airport.
[cpg]

The lobby had a strange atmosphere. The air was tense.
[cpg]

It was hard to believe that these people were excited about their trip.
[cpg]

[FACE method="change_7" pos="2/5"]
[VOICE f="Sanae150"]
[OnName num="sanae"]
“What is this ……? What is this atmosphere?”
[cpg cn=true]

[OnName num="man"]
“Excuse me, ladies.”
[cpg cn=true]

[OnName num="man"]
“The flight to New York is …….”
[cpg cn=true]

Several men and women sitting on the benches get up and come toward us. A lot of men are coming from behind as well.
[cpg]

[FACE method="change_5" pos="4/5"]
[VOICE f="Haduki192"]
[OnName num="haduki"]
“Hey ...... sis!”
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[VOICE f="Haduki193"]
[OnName num="haduki"]
“We should run! Something's wrong!”
[cpg cn=true]

People began to jump at us.
[cpg]

[free time=1000]

I got seized. I struggle, but I can't get out.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sanae151"]
[OnName num="sanae"]
“Hazuki! Hazu ……!"
[cpg cn=true]

[VOICE f="Haduki194"]
[OnName num="haduki"]
“Sis!”
[cpg cn=true]

[VOICE f="Haduki195"]
[OnName num="haduki"]
“No! Let go of me!”
[cpg cn=true]

[VOICE f="Haduki196"]
[OnName num="haduki"]
“Who is it? Help!”
[cpg cn=true]

The suitcase I had brought with me fell to the floor with a thud. My hairdo became a mess.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

This was what Masato had warned us about.
[cpg]

;//(Y):視点変更トランジション
[window target=false]
[WAIT time=1000]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_hp"]
[WAIT time=100]
;//【ＢＧ】『路地裏』（昼）******************************************************

The number of ordinary vehicles increased. The traffic was visibly blocked. I had no choice but to drive into a narrow alley.
[cpg]

[OnName num="masato"]
“Damn! Those guys from work are here.”
[cpg cn=true]

Many vehicles were parked blocking the road, and there were people inside, waiting.
[cpg]

They were here to stop both ‘one wing’ and me. But if I stop, he will kill me with his tentacles.
[cpg]

[OnName num="masato"]
“Is there a reason you refused the tentacle experiment?”
[cpg cn=true]

[OnName num="masato"]
“I don't know! You insidious bastards!”
[cpg cn=true]

Cars were no longer being thrown at me from behind. Probably because I was in an alleyway.
[cpg]

But the tentacles were coming at me from behind. It looked like a jellyfish with its tentacles inverted.
[cpg]

[OnName num="masato"]
“What the hell is that? Throwing cars and killing Rogela ……”
[cpg cn=true]

[OnName num="masato"]
“I don't wanna get caught ……!"
[cpg cn=true]

The police car finally started chasing after his car due to the cries that were spreading through the surrounding area.
[cpg]

[OnName num="masato"]
“...... The police are on our side!”
[cpg cn=true]

[OnName num="police_officer"]
“What's the situation with that car?”
[cpg cn=true]

He speaks in an amplified voice. I shouted.
[cpg]

[OnName num="masato"]
“I'm being chased! I don’t understand why I’m being chased by that thing— I don't know!”
[cpg cn=true]

The roar drowned out my voice.
[cpg]

[OnName num="police_officer"]
“I can't hear you!”
[cpg cn=true]

[OnName num="masato"]
“Please help me! Help me ……!"
[cpg cn=true]

A giant statue of the cartoon character comes into view. It was on the other side of the station.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_10_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

One wing comes after me. More cars pass by, and the vehicle tossing resumes.
[cpg]

[OnName num="masato"]
“Damn, oh, no!”
[cpg cn=true]

Behind us, we could see a huge truck car being lifted.
[cpg]

[OnName num="masato"]
“What the heck is going on? …… That’s a crazy power!”
[cpg cn=true]

I turned a corner on the street. Before I knew it, I was in front of the station.
[cpg]

The truck vehicle that was thrown at me hit the right leg of the nearly completed 147 meter statue of Yukirin, destroying it.
[cpg]

[OnName num="operator"]
“Ahhhhhhhh! Watch out!!!”
[cpg cn=true]

[OnName num="operator"]
“!? The statue is not stable yet! The inside is not done as well ……”
[cpg cn=true]

I heard someone say so. Then, a large shadow came from above.
[cpg]

A second car bomb was thrown at me, and hit her left leg.
[cpg]

— It will collapse!
[cpg]

[OnName num="masato"]
“I should have taken it more seriously. The cloudburst disaster.”
[cpg cn=true]

I remembered a class I once took. I had read the textbook data on an electronic tablet— It said that technology had been lost.
[cpg]

[OnName num="masato"]
“Damage to construction machinery ...... An earthquake caused by a hollow underground due to groundwater erosion ……."
[cpg cn=true]

Damage to machinery and equipment assets. A decrease in population. Major employment upheaval. Loss of skill. After-effects. Curfew orders.
[cpg]

The result of all this is now coming in the form of the collapse of the statue.
[cpg]

[OnName num="man"]
“Ahhhhhhhh!!!! Run!”
[cpg cn=true]

[OnName num="woman"]
“Aaaaaaaaaaaaa!”
[cpg cn=true]

The theme song had begun to play due to a malfunction in the audio equipment.
[cpg]

[OnName num="yukirin"]
“Hope for tomorrow ……. The world is my treasure—"
[cpg cn=true]

[OnName num="masato"]
“Aaaaahhhh!”
[cpg cn=true]

[OnName num="one_wing"]
“Aa……aahhhh! Oh, shit!”
[cpg cn=true]

The tentacle was crushing the building. One wing’s car was speeding past under it.
[cpg]

The statue of Yukirin waved her arms in that direction and announced to the audience that she was completed after two years.
[cpg]

[OnName num="yukirin"]
“Everybody, everybody, I'll save you, I'll save you, I'll save you, with the power of song♪”
[cpg cn=true]

Three more buildings collapsed during the motion of waving arms. Her arm then blew off.
[cpg]

The love for the audience radiating from her dynamic giant body was now a disaster.
[cpg]

[OnName num="operator"]
“Ohhhhhh! It’s a 360-degree live!”
[cpg cn=true]

[OnName num="operator"]
“Twist and turn your body in a sexy way, oh! Run, run, run, run, run!”
[cpg cn=true]

The statue of Yukirin, with its broken arm, began to spin and roll around.
[cpg]

It rolled through the rubble-strewn town and plunged into the station, bringing the train to an abrupt stop on the tracks.
[cpg]

Then multiple mechanisms malfunctioned, causing it to change directions — it was now coming toward us— !
[cpg]

[OnName num="police_officer"]
“Evacuate!!!!!! Residents, Aaaaaaaaaahhhhhh!”
[cpg cn=true]

[OnName num="police_officer"]
“We have to leave!”
[cpg cn=true]

[OnName num="yukirin"]
“It’s all great! Tomorrow's great! The day after tomorrow will be even better! Yay!♪”
[cpg cn=true]

[OnName num="one_wing"]
“It's coming toward us at a great speed!”
[cpg cn=true]

The car that one wing was driving was crushed.
[cpg]

[OnName num="masato"]
“Damn, ahhhhhhh!”
[cpg cn=true]

[OnName num="masato"]
“I don't want to die here!”
[cpg cn=true]

[OnName num="yukirin"]
“To be strong, close your eyes and dream.♪”
[cpg cn=true]

[OnName num="yukirin"]
“I am a legend... a smiling, young idol in Tokyo…♪"
[cpg cn=true]

I try to turn the corner on the road. But, I ran into the guardrail.
[cpg]

[window target=false]
[free time=500]
[BG f="b_03_2.ui" time=500]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（昼）******************************************************

[OnName num="masato"]
"Ah!"
[cpg cn=true]

My vision spins. My car blew up, flying in the direction of the day after tomorrow.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[window target=true]

— My body ached.
[cpg]

I heard sirens in the distance, but they were headed away from where I was. There must be a lot of victims.
[cpg]

[OnName num="masato"]
“I will be abandoned ……"
[cpg cn=true]

I wanted to be saved.
[cpg]

I'm also worried about Hazuki and Sanae. What are Misaki and the others doing right now? Nothing was done yet.
[cpg]

To fight with them, we need weapons.
[cpg]

[OnName num="masato"]
“I can't be unconscious……!”
[cpg cn=true]

[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『空』（昼）******************************************************

I crawled away. My goal was to get to one wing’s body.
[cpg]

His body was messed up in the wrecked car. He will die if left alone.
[cpg]

;//(Y):回想。セピア色にしてください

;//●ＣＧ非エロ（回想。本来台詞の場面はev07ですが、触手の全体像が見えるCGを再利用）ev_08
[window target=false]
[free time=1000]
[BG f="b_ev_08.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[OnName num="mitsuhara"]
“I want you to swallow the tiny body cells of this creature, Mr. Fujita.”
[cpg cn=true]

;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[OnName num="masato"]
“It's tiny, right ……?"
[cpg cn=true]

I bit into the tentacle that had emerged from the burning car.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I didn’t even want to think about the taste, but fortunately, there was only the taste of blood in my mouth.
[cpg]

When I touched the tip of the tentacle with my finger, I felt a twinge of pain.
[cpg]

[OnName num="masato"]
“(Poison ……!)”
[cpg cn=true]

[OnName num="masato"]
“(Tsk.)”
[cpg cn=true]

I tore off the tentacle, squeezed out the venom, and let it drip onto the floor. I almost lost consciousness.
[cpg]

I rinse the torn tentacles with water coming from the red fire hydrant that had been knocked over.
[cpg]

[OnName num="masato"]
“(I can’t get rid of all the poison. I don't want to eat it ……)”
[cpg cn=true]

I end up eating it. I don't want to chew it too much if possible, but .......
[cpg]

[OnName num="masato"]
“(It’s moving, ugh ....... It's fresh. It's still alive.)”
[cpg cn=true]

[OnName num="masato"]
“(How the hell is this thing still alive?)”
[cpg cn=true]

[OnName num="masato"]
“(Hazuki, Sanae ……!)”
[cpg cn=true]

[SE f="se073"]
;//【ＳＥ】『心音』
;//赤フラッシュ

[FADEOUTBGM]
[free time=500]
[BG f="red.ui" time=500]
[WAIT time=1000]

[OnName num="masato"]
“……."
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I became unconscious.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『生物研究所前』（昼）******************************************************

The car with the two girls on board entered the premises.
[cpg]

The guards - or rather, mostly soldiers - with assault rifles greeted us in a horizontal formation.
[cpg]

[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki101"]
[OnName num="misaki"]
“Thank you very much for your help.”
[cpg cn=true]

[OnName num="security_guard_A"]
“Take them to the central building!”
[cpg cn=true]

[OnName num="security_guard_B"]
“What? Wait a minute! Why did you bring two people?”
[cpg cn=true]

[OnName num="vehicle_driver"]
“They're sisters.”
[cpg cn=true]

[OnName num="vehicle_driver"]
“After all, we can't just let one of them go home.”
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Misaki102"]
[OnName num="misaki"]
“I'll allow it.”
[cpg cn=true]

[OnName num="vehicle_driver"]
“Huh!”
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所内部』******************************************************

Hazuki was restrained in the room and sat on a chair.
[cpg]

[FG f="CHA02_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Haduki197"]
[OnName num="haduki"]
“Sis ……”
[cpg cn=true]

[OnName num="sakata"]
“She is conscious now.”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Haduki198"]
[OnName num="haduki"]
“?!”
[cpg cn=true]

[OnName num="mitsuhara"]
“We are Sakata and Mitsuhara ……”
[cpg cn=true]

[OnName num="sakata"]
“You idiot. You don't have to introduce yourself to your experimental subjects.”
[cpg cn=true]

[OnName num="mitsuhara"]
“!! Don’t we have to pay our respects to those who are rare and valuable?”
[cpg cn=true]

[OnName num="sakata"]
“Well …….”
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Haduki199"]
[OnName num="haduki"]
“What are you talking about? Where's Sanae?”
[cpg cn=true]

[OnName num="mitsuhara"]
“She's sleeping in the other room.”
[cpg cn=true]

[OnName num="sakata"]
“Don't answer! Ugh.”
[cpg cn=true]

[OnName num="security_guard"]
“Um, Misaki told me to get on with it.”
[cpg cn=true]

[OnName num="sakata"]
“Whatever. Make her go to sleep again.”
[cpg cn=true]

Mitsuhara pushed a button on the wall. Hazuki's body trembled - she fell unconscious as if she were to asleep.
[cpg]

[OnName num="sakata"]
“Is that guy called Rogela dead?”
[cpg cn=true]

[OnName num="security_guard"]
“Yes. One wing too.!
[cpg cn=true]

[OnName num="sakata"]
“Our tentacled creature. It only had level one security, but I was attached to it.”
[cpg cn=true]

[OnName num="mitsuhara"]
“Hey, let me double-check.”
[cpg cn=true]

Mitsuhara went to a desk with numerous monitors. There are various numbers, from the temperature and humidity of the room to the heart rate of the creature.
[cpg]

[OnName num="mitsuhara"]
“This Hazuki girl is the one who passed the Kirichi test 82% of the time, is that right?”
[cpg cn=true]

[OnName num="sakata"]
“Yeah.”
[cpg cn=true]

[OnName num="mitsuhara"]
“This Rogela guy is a foreign spy. He wanted Hazuki to find out about our tentacle creature.”
[cpg cn=true]

[OnName num="mitsuhara"]
“Perhaps Rogela's goal was to bring the tentacle creature back to the country of its origin.”
[cpg cn=true]

[OnName num="mitsuhara"]
“It seems too good to be true ……"
[cpg cn=true]

Sakata did not listen to these words but continued to prepare for the experiment.
[cpg]

;//●ＣＧ非エロ（触手生物の全貌再利用）ev_08
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[OnName num="sakata"]
“That Fujita bastard ...... He seemed pretty weak.”
[cpg cn=true]

[OnName num="sakata"]
“His muscle mass was in the ideal range, but this woman sniffed around and that's why he killed the tentacle.”
[cpg cn=true]

[OnName num="sakata"]
“You should maintain your courage. A good coincidence happens when you have luck on your side.”
[cpg cn=true]

[OnName num="mitsuhara"]
"......"
[cpg cn=true]

[OnName num="mitsuhara"]
“Yeah, I'd like to see what an 82% would look like ……”
[cpg cn=true]

[OnName num="sakata"]
“There's still too much we don't know about life on exoplanets. And this thing as well!”
[cpg cn=true]

[OnName num="sakata"]
“I've parasitized a thousand, maybe two thousand of them, and if anything ……”
[cpg cn=true]

[OnName num="mitsuhara"]
“……"
[cpg cn=true]

[OnName num="mitsuhara"]
“I want to kill more.”
[cpg cn=true]

[OnName num="sakata"]
“Me, too. I want to see what's possible.”
[cpg cn=true]

[OnName num="sakata"]
“I wonder what kind of creature this Hazuki will become if we get it inside her.”
[cpg cn=true]

Mitsuhara glanced at Hazuki. The guard puts a collar with an explosive function around her neck.
[cpg]

With this, there will be no problem if something should happen —
[cpg]

;//(Y):のちの展開でこの首輪は爆発しましたが葉月は首がもげても再生した裏設定があります。首輪なしで立ち絵もCGも出して大丈夫です



[jump storage="ep009.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
