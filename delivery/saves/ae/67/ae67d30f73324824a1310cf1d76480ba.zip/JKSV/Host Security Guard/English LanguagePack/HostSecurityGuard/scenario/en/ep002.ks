
*start|Happy Life

;#################################################
*Ep002|Happy Life
;#################################################

[SCENE id=2]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[BG f="b_09_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『踏み切り前』（朝）******************************************************

The three of us went out today. Since it was after the shooting, we decided to look for a new place to live.
[cpg]

[FACE method="change_7" pos="4/5"]
[VOICE f="Haduki035"]
[OnName num="haduki"]
“We should find a place that’s cheap and where noise and stray cats are allowed.”
[cpg cn=true]

[OnName num="masato"]
“I don’t think that exists.”
[cpg cn=true]

[OnName num="masato"]
“Well, I guess we don't need a sunroom anymore ……"
[cpg cn=true]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Sanae032"]
[OnName num="sanae"]
“It's convenient for teatime and laundry, but I don't feel comfortable with having big windows.”
[cpg cn=true]

Will security be the main criterion for choosing a room?
[cpg]

We did have security to a certain extent up until now. So, if we want stronger security then …..
[cpg]

;//(Y):戦争忌避はほぼイコールで普通の生活が欲しいという欲求

[FACE method="change_7" pos="4/5"]
[VOICE f="Haduki036"]
[OnName num="haduki"]
“I guess people didn't want war or anything like that since the time of the ancient settlements.”
[cpg cn=true]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Haduki037"]
[OnName num="haduki"]
“Why fight when you can just pick berries and go fishing and live normally?”
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（朝）******************************************************

;//@
;//[OnName num="caster"]
“{According to the police, the shooter has been arrested ……}”
[cpg]

Oh, they’re talking about us.
[cpg]

;//@
;//[OnName num="caster"]
“{We found out that he is a member of the fraud crime group ‘Ikkaku’.}"
[cpg]

;//(Y):ヒロイン二名同行してます。驚くような表情にここで変わる

[FACE method="change_5" pos="2/5"]
[FACE method="change_5" pos="4/5"]

What?
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（朝）******************************************************

I called them and they gave me the details.
[cpg]

[OnName num="police_officer(call)"]
“Yes. He confessed pretty quickly. It seems that the culprit was a member of the fraud group.”
[cpg cn=true]

[OnName num="police_officer(call)"]
“I can’t believe it. Three of the escapees have now been arrested, so there is only one left.”
[cpg cn=true]

I see. I’m the reason that they got arrested ......
[cpg]

[OnName num="police_officer(call)"]
“The motive for the crime seems to be a personal vendetta ……"
[cpg cn=true]

[OnName num="masato"]
“Do you think you'll find the other one?”
[cpg cn=true]

[OnName num="police_officer(call)"]
“They'll find him soon. He's an escaped convict. The Tokyo police are all on the lookout for him.”
[cpg cn=true]

[OnName num="masato"]
“Thank you very much. I feel relieved.”
[cpg cn=true]

I hung up the phone. I see ......
[cpg]

[OnName num="masato"]
“If they find the last one, we might be able to live in peace.”
[cpg cn=true]

[OnName num="masato"]
“....... I guess I won't have to move, then.”
[cpg cn=true]

[FACE method="bow_1" pos="2/5"]
[VOICE f="Sanae033"]
[OnName num="sanae"]
“I'd love to cook again without worrying.”
[cpg cn=true]

[FACE method="shake_2" pos="4/5"]
[VOICE f="Haduki038"]
[OnName num="haduki"]
“I want to eat noodles!”
[cpg cn=true]

I kind of like the current place. It's close to a public bath and a cat cafe.
[cpg]

[FACE method="change_1" pos="2/5"]
[FACE method="change_2" pos="4/5"]

[OnName num="masato"]
“Once everything is back to normal, I want to take a nap while listening to the sound of the train. I haven't slept well recently.”
[cpg cn=true]

Trains— even though the noise doesn’t bother me anymore, I still have to get used to it before I can take a nap.
[cpg]

In that sense, I'm a pro at napping. I don't want to leave this place ......
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（昼）******************************************************

I went bowling, to the karaoke shop, and then to the arcade. I was completely fulfilled.
[cpg]

[SE f="se013"]
;//【ＳＥ】『携帯電話の着信音』
[WAIT time=1000]

;//@
Just as I was talking to them about leaving soon, the phone started ringing. It was the police.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[OnName num="police_officer(call)"]
“We have arrested the last one!”
[cpg cn=true]

[OnName num="masato"]
“Wow! Thank you for your hard work! Thank you!”
[cpg cn=true]

[OnName num="police_officer(call)"]
“This is how it is with scam groups! They caught him trying to catch the bullet train.”
[cpg cn=true]

After talking for a while I hung up the phone.
[cpg]

;//(Y):ここから不穏な展開（いったんの山場にはタメも必要なので）

[FADEOUTBGM]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]

[OnName num="masato"]
“There is no reason whatsoever to eat ‘that thing’.”
[cpg cn=true]

[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『洗面所』（昼）<『童貞喰い』流用>******************************************************

I took a shower and was wiping my body when the gauze towel ripped.
[cpg]

It ripped in a straight line horizontally, and although it was not ripped all the way through, it look horrible.
[cpg]

;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sanae034"]
[OnName num="sanae"]
“We don't have any bread for tomorrow morning, so I'll go buy some!”
[cpg cn=true]

[OnName num="masato"]
“Yeah, all right!”
[cpg cn=true]

“I have to work tomorrow. I'd like to think that they'd give me a day off after the shooting incident, but ……."
[cpg]

I felt a twinge, a pain in my left collarbone.
[cpg]

[OnName num="masato"]
“Agh ......."
[cpg cn=true]

I had just been shot. I touched it fearfully. It was cut.
[cpg]

[OnName num="masato"]
“Ouch ……"
[cpg cn=true]

[OnName num="masato"]
“Are you sure there's nothing there? This is the end of the scam group ……?"
[cpg cn=true]

I was feeling inexpressible anxiety.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（夕方）******************************************************

Sanae did not return.
[cpg]

The wound was aching. I had a feeling that it might be swollen. Should I disinfect it? …… I don't have any medicine.
[cpg]

If only there was a convenient treatment for such a situation.
[cpg]

;//(Y):セピア色。回想。

;//●ＣＧ非エロ（前と同じです）ev_08
[window target=false]
[free time=1000]
[BG f="b_ev_08.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[OnName num="mitsuhara"]
“Just look at this vegetative neoplasm. It has been proven to increase the human body's physical capabilities.”
[cpg cn=true]

[OnName num="mitsuhara"]
“There will be no physical rejection.”
[cpg cn=true]

[OnName num="mitsuhara"]
“It will produce ultra-fine filamentous fibers that can function in place of muscles and blood vessels inside the body.”
[cpg cn=true]

[window target=false]
[free time=1000]
[BG f="b_00_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（夕方）******************************************************

[SE f="se036"]
;//【ＳＥ】『携帯電話の通知音』
[WAIT time=1000]

I received a message from Hazuki.
[cpg]

<Where's your sister? Is she out shopping?>
[cpg]

She was hiding in her bedroom. She could come here and talk to me ...... I reply,
[cpg]

[SE f="se034"]
;//【ＳＥ】『携帯電話のシステム音』

<Yes. She said he was going to buy some bread.>
[cpg]

[SE f="se034"]
;//【ＳＥ】『携帯電話のシステム音』

<I bought bread on my way home from school …..>
[cpg]

I looked in the kitchen. Two bags of 6 slices of bread were there unsealed. The expiration date was 11 days from now.
[cpg]

[OnName num="masato"]
“……."
[cpg cn=true]

I went to the kitchen and opened the refrigerator. Fruit sandwiches. Yogurt. Bananas.
[cpg]

It's hard to believe that there won't be enough food for tomorrow morning.
[cpg]

Why did Sanae go out?
[cpg]

[OnName num="masato"]
“Hazuki! Come downstairs! Was there anything unusual with Sanae?”
[cpg cn=true]

[SE f="se034"]
;//【ＳＥ】『携帯電話のシステム音』

<Uhh, no. But she was also not normal.>
[cpg]

[OnName num="masato"]
“Not normal?”
[cpg cn=true]

[SE f="se034"]
;//【ＳＥ】『携帯電話のシステム音』

<She was getting dressed to go out and she was fidgeting around.>
[cpg]

I left the house in a hurry.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se012"]
;//【ＳＥ】『走る』

[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『路地裏』（夕方）******************************************************

Sanae's small bag was on the ground. I turned the corner, and darkness was hanging in the air.
[cpg]

[OnName num="masato"]
"Sa ...... Sanae!"
[cpg cn=true]

;//(Y):流用台詞の切り貼り＋編集です

I entered the alleyway and found Sanae covered in wounds.
[cpg]

;//●ＣＧ非エロ（傷だらけの早苗。触手で拘束。血がなければ全年齢範囲になる？）ev_12
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[VOICE f="Sanae035"]
[OnName num="sanae"]
“Arghh ……”
[cpg cn=true]

[VOICE f="Sanae036"]
[OnName num="sanae"]
“MMmm ……. Ahhh …..”
[cpg cn=true]

She was tied up. But not with a rope. What is this? .......
[cpg]

— Tentacles?
[cpg]

Sanae's body was swollen and was covered in bruises. There are even marks on her body, as if she was beaten ......
[cpg]

[VOICE f="Sanae037"]
[OnName num="sanae"]
“Please put me down. There’s ... blood on my head. ……"
[cpg cn=true]

[VOICE f="Sanae038"]
[OnName num="sanae"]
“I won't run away, please forgive me.”
[cpg cn=true]

[OnName num="man"]
“No. I will not stop until he comes.”
[cpg cn=true]

A man was standing in the shadows by the side.
[cpg]

[VOICE f="Sanae039"]
[OnName num="sanae"]
“No, no, no!”
[cpg cn=true]

[SE f="se058"]
;//【ＳＥ】『ぎりりり　縄』

[VOICE f="Sanae040"]
[OnName num="sanae"]
“The tentacles that are wrapped around me are biting into my body ...... I can’t breathe.”
[cpg cn=true]

[OnName num="masato"]
“Hey ..... who are you, you bastard? You did this?”
[cpg cn=true]

[OnName num="man"]
“Fujita!”
[cpg cn=true]

[OnName num="man"]
“You destroyed my people.”
[cpg cn=true]

[VOICE f="Sanae041"]
[OnName num="sanae"]
"Why ...... Masato! What is going on?”
[cpg cn=true]

;//(Y):流用おわり

[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『路地裏』（夕方）******************************************************

A man crawls out of the shadows. At first glance, I knew he was a jerk.
[cpg]

I hate this guy fundamentally. Maybe it's physiological.
[cpg]

[OnName num="man"]
“I've been waiting for you. Fujita ....... I even want to have a heart-to-heart chat with you, huh?”
[cpg cn=true]

[OnName num="masato"]
“What are you talking about? I don't know you ....... Is this related to that shooting?”
[cpg cn=true]

No, but that ... The case of the fraud group "Ikkaku" was supposed to be over. They should have all been arrested.
[cpg]

[OnName num="man"]
“Did you forget about the boss of the group, Fujita?”
[cpg cn=true]

[OnName num="masato"]
“!!”
[cpg cn=true]

[OnName num="man"]
“It's a small group, but they were one of our sources of funding. Our boss is pissed, you know?”
[cpg cn=true]

[OnName num="man"]
“Although, I’m the boss.”
[cpg cn=true]

[OnName num="masato"]
“Who the fuck are you?”
[cpg cn=true]

[OnName num="man"]
"It doesn't have a name, but it's called 'one wing.' My men made a mistake in first aid for a lung and it got adhered, because of this plastic umbrella."
[cpg cn=true]

The man was unmoved. Sanae's screams rose as the mysterious tentacles tightened their grip on her.
[cpg]

[OnName num="one_wing"]
“I called this woman because I wanted to talk to you.”
[cpg cn=true]

[OnName num="one_wing"]
“She was a fishing bait and if you run away, she will die.”
[cpg cn=true]

[OnName num="masato"]
“I won't run away even if you don't tell me to!”
[cpg cn=true]

I hit him. I felt those mysterious tentacles coming at me.
[cpg]

The tentacles hit me all over my body. The wall caved in, and pieces of stone flew around like shotgun pellets.
[cpg]

[OnName num="one_wing"]
“This is 'dirt' over here. The filth of society, the stuff of which the well-behaved little Fujita despises.”
[cpg cn=true]

[OnName num="one_wing"]
“I've got a gun.”
[cpg cn=true]

[OnName num="masato"]
“!!”
[cpg cn=true]

I've already been shot twice, once in the bedroom and once under those bushes. This time his aim was accurate - but I dodged.
[cpg]

I flanked the ‘one wing’ and slammed my fist into its face.
[cpg]

But - nothing happened. It was as if there was a hollow space inside of him.
[cpg]

[OnName num="masato"]
“What?”
[cpg cn=true]

[OnName num="one_wing"]
“Huh!”
[cpg cn=true]

A strange thing popped out from inside his face. It was that tentacle.
[cpg]

[OnName num="one_wing"]
“I've already stopped being a human!”
[cpg cn=true]

[OnName num="masato"]
“What the hell is going on? Damn it!”
[cpg cn=true]

Something picked up my feet. It was that tentacle.
[cpg]

[OnName num="masato"]
“Hey!”
[cpg cn=true]

Everything was spinning.
[cpg]

A moment later, I quickly pulled a screwdriver out of my pocket. I had brought it from home because I felt uneasy.
[cpg]

It was the one Sanae had bought when she assembled the chair.
[cpg]

That thick tentacle was waiting for me on the ground in front of me. I swung at it and stabbed it!
[cpg]

[OnName num="one_wing"]
“Nah— gaaaaaaaaaaaaaah!"
[cpg cn=true]

[OnName num="masato"]
“Ugh!”
[cpg cn=true]

The tentacle on the ground, writhing in pain, was damaging him.
[cpg]

I don't know why, let me down on the ground softly.
[cpg]

[OnName num="masato"]
“Thanks for this creepy new weapon. ...... You don't seem to know how to use it, do you?”
[cpg cn=true]

[OnName num="one_wing"]
“Hey, you!!!”
[cpg cn=true]

I leap onto his body and get his attention.
[cpg]

[OnName num="one_wing"]
“It will always end up like this. You can’t hurt me!”
[cpg cn=true]

[OnName num="masato"]
“I know because I hit you before!”
[cpg cn=true]

I flicked the gun with the screwdriver I was holding, pretending to go for his body.
[cpg]

;//銃はくるくると路地を滑っていき——縛られた早苗がそれを拾った。
The gun glided down the alleyway and I ran over to pick it up.
[cpg]

[OnName num="masato"]
“I’ll get you!!! Ahhhhh!”
[cpg cn=true]

[OnName num="one_wing"]
“Huh …..?”
[cpg cn=true]

[SE f="se072"]
;//【ＳＥ】『銃声』

;//(Y):未成年の銃使用になっちゃう？　あぶない・規制されそうなら主人公が使うことにします

;//早苗が銃を撃ち放った。
I picked up the gun and fired it.
[cpg]

Two shots. Three shots. Four shots. — ‘One wing’ trembled and collapsed, exposing those tentacles from all over his body instead of blood.
[cpg]

[OnName num="one_wing"]
“Geez ...... gah!”
[cpg cn=true]

[OnName num="masato"]
“He's not dead ……! What the hell is going on here?”
[cpg cn=true]

;//あたりの住宅から、悲鳴が上がる。早苗の銃がかちかちと鳴る。もう弾がない。
Screams erupt from the houses in the area. I clicked the gun. There are no more bullets.
[cpg]

[OnName num="one_wing"]
“Arghhh ......!"
[cpg cn=true]

[SE f="se012"]
;//【ＳＥ】『走る』

The damage seems to have been done. ‘One wing’ ran away. I try to chase after it, but then - the pain hits me.
[cpg]

[FADEOUTBGM]

[OnName num="masato"]
“Ahhhh! I can’t!”
[cpg cn=true]

[BGM f="bg_t2"]
[WAIT time=100]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sanae042"]
[OnName num="sanae"]
“Masato ....... I'm sorry.”
[cpg cn=true]

Sanae crawls towards me.
[cpg]

[OnName num="masato"]
“You ...... were threatened by that guy? Sanae ……?"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Sanae043"]
[OnName num="sanae"]
“…….. I’m sorry! I'm so sorry! He tried to threaten Hazuki and my mom!”
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Sanae044"]
[OnName num="sanae"]
“Huhhhh ……”
[cpg cn=true]

[free time=800]
[SE f="se031"]
;//【ＳＥ】『倒れる』

Sanae collapsed. — She was in more pain than I was …….
[cpg]

[SE f="se012"]
;//【ＳＥ】『走る』

People are rushing to the scene. They are gathering in this small little alley .......
[cpg]

[FG f="CHA03_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Misaki026"]
[OnName num="misaki"]
“Ms. Fujita!”
[cpg cn=true]

[OnName num="masato"]
“What?”
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Misaki027"]
[OnName num="misaki"]
“Are you all right? Oh no, oh no!”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Misaki028"]
[OnName num="misaki"]
“I was ….. looking out for that ‘thing'! But, but, but!”
[cpg cn=true]

She apparently was looking out for me because of that pie.
[cpg]

Yes, that's right. Come to think of it, how could there not be a lookout? I was being followed ……
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Misaki029"]
[OnName num="misaki"]
“I don't want you to die.”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[OnName num="masato"]
“What ……? Are you talking to me?”
[cpg cn=true]

[OnName num="masato"]
“No, no, no. I'm fine. ……"
[cpg cn=true]

I looked down. The blood vessels in my legs are pale ……!"
[cpg]

[OnName num="man_A"]
“It’s poison ……."
[cpg cn=true]

[OnName num="masato"]
“Are you ……?"
[cpg cn=true]

[OnName num="man_A"]
“I'm disguised as a civilian, but I'm a researcher for the company. I am an errand boy for Mr. Mitsuhara and Mr. Sakata ……"
[cpg cn=true]

I suddenly realized what was going on. I'm dying right now.
[cpg]

— If so, Sanae who had been hit by tentacles earlier, must be in a worse condition.
[cpg]

[OnName num="masato"]
“Sanae.”
[cpg cn=true]

I looked at her. Her whole body was pale. She was trembling.
[cpg]

[OnName num="masato"]
“No!"
[cpg cn=true]

[OnName num="masato"]
“No! No!”
[cpg cn=true]

[OnName num="man_C"]
“What the hell is this?”
[cpg cn=true]

[OnName num="man_A"]
“It's the Mitsuhara-Sakata NPQ cell! That's the leak, isn't it?”
[cpg cn=true]

At the time - when I saw his attack, I recognized it as a tentacle.
[cpg]

They were like jellyfish tentacles. Sanae and I were poisoned.
[cpg]

[OnName num="man_A"]
“Get medical treatment! Can you call Mr. Mitsuhara and Mr. Sakata? Who knows about the results of the hostile organization's research?”
[cpg cn=true]

[OnName num="man_B"]
“I'm contacting them now! Transmitting emergency code now!”
[cpg cn=true]

[OnName num="man_B"]
“Download of response database complete! There are currently 17 poison types! Final identification coming in!”
[cpg cn=true]

[OnName num="man_C"]
“Put the Kerche BCO 33 on her! Left side forward, sideways!”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Misaki030"]
[OnName num="misaki"]
“Uh-uh! Uh-uh!”
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Misaki031"]
[OnName num="misaki"]
“Oh …… the four criminals broke out of jail. ....... I think there might be someone who helped them escape.”
[cpg cn=true]

It didn’t seem like she was acting. I wanted to believe what she was saying.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Misaki032"]
[OnName num="misaki"]
“No …… no!”
[cpg cn=true]

[OnName num="masato"]
“There's ...... at home ……”
[cpg cn=true]

[OnName num="masato"]
I” have some of that pie at home ……”
[cpg cn=true]

[OnName num="man_A"]
“You didn’t eat it.”
[cpg cn=true]

She said something about it boosting physical performance and acting as a substitute for muscles and blood vessels ……
[cpg]

Will it work on the poison? It might only fasten the death of Sanae and me.
[cpg]

If we continue like this, we will die!
[cpg]

[OnName num="man_A"]
“...... It could potentially move the internal organs. You might be able to live longer ……”
[cpg cn=true]

[OnName num="masato"]
“I want to help him.”
[cpg cn=true]

[OnName num="masato"]
“I want to live, too ……!"
[cpg cn=true]

[OnName num="masato"]
“I want to live with you three forever!”
[cpg cn=true]

[OnName num="masato"]
“I was so happy. I want it to stay that way!”
[cpg cn=true]

[OnName num="masato"]
“As long as I'm the only one parasitized by that creature and as long as she stays alive then …..”
[cpg cn=true]

I began to crawl toward my home.
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="Misaki033"]
[OnName num="misaki"]
“…….! It’s bad to keep circulate your blood flow when you have poison inside.”
[cpg cn=true]

[OnName num="masato"]
“Oops!”
[cpg cn=true]

[FACE method="bow_5" pos="2/3"]
[VOICE f="Misaki034"]
[OnName num="misaki"]
“Oh, I'm sorry! Ms. Fujita!”
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Her back was warm. I lay down in the backseat of the car she was using.
[cpg]

I chose to get my hands on the pie.
[cpg]

I am skeptical, even thinking that Misaki and her friends may have sent for me …… but I want to believe that her scream was real.
[cpg]

I'll decide what I believe.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（夕方）******************************************************

[FG f="CHA03_p4_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Misaki035"]
[OnName num="misaki"]
“Huh ...... huh ...... You are heavy ……."
[cpg cn=true]

[OnName num="masato"]
“Argh …… I can’t believe that you are so strong!”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki036"]
[OnName num="misaki"]
“I try to hide it, but I've been working out a lot ……."
[cpg cn=true]

[free time=800]

Hazuki came from across the street.
[cpg]

[FG f="CHA02_p2_01_a.ui" method="change_5"  pos="2/5" time=800]
[FG f="CHA03_p4_01_a.ui" method="change_4"  pos="4/5" time=800]
[VOICE f="Haduki039"]
[OnName num="haduki"]
“What ……?”
[cpg cn=true]

[OnName num="masato"]
“I'm okay. I'm still alive ……”
[cpg cn=true]

[OnName num="masato"]
“I'm going to go save Sanae now ……"
[cpg cn=true]

[FACE method="shock_5" pos="2/5"]
[VOICE f="Haduki040"]
[OnName num="haduki"]
“What are you talking about? You’re going to die ...... Masato! No!”
[cpg cn=true]

I'm dying. It may be unconvincing for me to go and save Sanae.
[cpg]

[FG f="CHA03_p4_01_a.ui" method="shake_3"  pos="4/5" time=800]
[VOICE f="Misaki037"]
[OnName num="misaki"]
“I'm sorry! Please let me in!”
[cpg cn=true]

[SE f="se019"]
;//【ＳＥ】『ドア開け』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p4_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（夕方）******************************************************


[VOICE f="Misaki038"]
[OnName num="misaki"]
“I'll let you down now ……"
[cpg cn=true]

Thank you ...... Misaki. I knew she was telling the truth. I can't even say thank her because I'm having a hard time breathing.
[cpg]

[OnName num="masato"]
“Huh ….. huh.”
[cpg cn=true]

I walk up the stairs.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_02_5.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『寝室』（夜電気OFF）******************************************************

On the desk is a plastic bag of the lemon custard pie.
[cpg]

I rummage through the bag and open the paper bag. The delicious smell of lemon custard pie spreads.
[cpg]

[OnName num="masato"]
“Haaah ...... haaah! Ugh ...... ugh ……!"
[cpg cn=true]

I probed the layer of gooey lemon custard with my fingers.
[cpg]

It was hard.
[cpg]

When I took it out, I found a small case made of glass.
[cpg]

In the darkness, which seemed even darker than the night, I tried to look closely. I saw that something was stirring inside.
[cpg]

It was waiting for me.
[cpg]

[OnName num="masato"]
“……"
[cpg cn=true]

[FADEOUTBGM]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I open the case ….. and then …..
[cpg]

In one gulp, I swallowed the contents.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

...... I went unconscious.
[cpg]

;//(Y):長めのウェイトをとってください

;//(Y):セピア色回想

[window target=false]
[WAIT time=2000]
[BG f="b_03_5.ui" time=1500]
[WAIT time=3000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『空』（回想）******************************************************

The more I love something, the more easily I tend to lose it.
[cpg]

I was born as a twin brother of Venetian glass, blue and shiny.
[cpg]

I was born on the day of the polluted downpour of 2028, called the "cloudburst disaster". To celebrate, my father had a distant Italian friend make me a glass figure.
[cpg]

[FACE method="change_1" pos="2/3"]

A lovely cup of beautiful blue glass. He jokingly told me, “That's your twin brother.”
[cpg]

Four years later, my brother broke. I dropped it and broke it.
[cpg]

It was a stupid thing to do. Glass is breakable. My father was an elementary school arts and crafts teacher, but he was not that smart.
[cpg]

I feel like all my misfortunes came pouring out at that moment.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_04_5.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜・回想）******************************************************

Due to the pollution from the cloudburst disaster, both my father and mother died of illness, one after the other.
[cpg]

They went into the crematorium in their sleep. Now buried in the dark earth. The Gyoen, where I often go to is the place where they met.
[cpg]

If only I didn’t break my brother - there would have been a “happy life”.
[cpg]

;//(Y):セピア色回想おわり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『寝室』（夜電気OFF・回想）******************************************************

[OnName num="masato"]
“I wonder if I am capable of taking care of the people I love now.”
[cpg cn=true]

I moved my hand, and my fingertip snapped open. A disgusting worm-like tentacle sprang out.
[cpg]

This is an extension of my hand.
[cpg]

I’ll use this hand to help Sanae.
[cpg]

;//(Y):画面シェイクなどはげしめの演出で飛び出す。

;//【ＳＥ】風を切る音

[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=800]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=800]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（夕方）******************************************************

I "flew" to her.
[cpg]

I release my tentacles and grasp on the wall of the building. I jump across from roof to roof and accelerate.
[cpg]

[OnName num="masato"]
“No— this is too slow ...... Like this!”
[cpg cn=true]

I weave my tentacles and turn them into wings.
[cpg]

The blazing sunset-colored wind pushes me and gives me speed.
[cpg]

[OnName num="masato"]
“Sanae!”
[cpg cn=true]

[OnName num="masato"]
“I'll save you!”
[cpg cn=true]


[jump storage="ep003.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
