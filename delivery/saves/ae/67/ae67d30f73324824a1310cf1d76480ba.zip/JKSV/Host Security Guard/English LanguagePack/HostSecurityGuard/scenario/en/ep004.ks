


*start|Retirement

;#################################################
*Ep004|Retirement
;#################################################

[SCENE id=4]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『生物研究所前』（朝）******************************************************

I had decided to retire.
[cpg]

But, well, it doesn't matter yet. I'll still be using this building.
[cpg]

[OnName num="security_guard"]
“Ah, Mr. Fujita, long time no see. Are you working?”
[cpg cn=true]

[OnName num="masato"]
“You saw me the other day. I'm here to work.”
[cpg cn=true]

;//(Y):流用

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2500]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社』（夜電気ON）******************************************************

;//雅人：スーツ
;//美咲：スーツ

I didn't mind, but I guess I wasn’t really working lately.
[cpg]

I noticed that it was getting dark outside.
[cpg]

[FG f="CHA03_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Misaki039"]
[OnName num="misaki"]
“I brought your favorite kind of alcohol.”
[cpg cn=true]

[OnName num="masato"]
“Oh, thank you!”
[cpg cn=true]

;//@文章前後入れ替え
[FACE method="bow_7" pos="2/3"]
[VOICE f="Misaki040"]
[OnName num="misaki"]
“Mr. Fujita …… Have you been all right since then?”
[cpg cn=true]

There's no way that I was all right. What am I going to tell Sanae? I want to show them how her body looked inside.
[cpg]

Will Sanae be able to go to a doctor from now on? How will she find someone to marry?
[cpg]

That poisonous tentacle ‘one wing’ is the result of this shitty company's research leak.
[cpg]

[OnName num="masato"]
;//「ははは。大丈夫ですよ。酒はいただきます」
“Ha-ha-ha. It's all right ...... By the way, are you going to drink here too, Misaki?”
[cpg cn=true]

;//@文章前後入れ替え
[FACE method="shake_1" pos="2/3"]
[VOICE f="Misaki041"]
[OnName num="misaki"]
“Would that be bad? It's after working hours.”
[cpg cn=true]

[OnName num="masato"]
;//「んじゃ今日は俺も飲むか」
“Then I guess I'll be drinking with you today.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

I downed the alcohol all in one gulp. The alcohol burns my throat and I feel refreshed.
[cpg]

;//[SE f="se000"]
;//【ＳＥ】『ごくっごくっ』
;/[WAIT time=1000]

But I can't seem to get drunk.
[cpg]

I think that Misaki likes me. She even gave up her duties to save me.
[cpg]

But it's as if these guys gave the tentacles to ‘one wing’. That's what I can't forgive.
[cpg]

[OnName num="masato"]
“(Why was my personal information leaked in the first place? They are too loose with information leaks)”
[cpg cn=true]

[OnName num="masato"]
“(I was about to be killed by the underlings of a fraud group and 'one wing'.)”
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Misaki042"]
[OnName num="misaki"]
“You are drinking a lot today. Let me join you.”
[cpg cn=true]

Misaki also started to drink.
[cpg]

The secret research institute of the country. They think they are the elite, but they are just human beings who are lazy and unorganized.
[cpg]

They want the illusion that they are extraordinary, and they know that they will keep their jobs even if they kill people.
[cpg]


;//[SE f="se011"]
;//【ＳＥ】『ごくっごくっ』

[FACE method="change_2" pos="2/3"]
[VOICE f="Misaki043"]
[OnName num="misaki"]
“This is great!”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki044"]
[OnName num="misaki"]
“Here you go, Fujita.”
[cpg cn=true]

[OnName num="masato"]
“Hahaha. The drinks are amazing.”
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Misaki045"]
[OnName num="misaki"]
“Yes, that's right. I think you have been feeling a bit depressed lately, Fujita.”
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Misaki046"]
[OnName num="misaki"]
“It's so hot, by the way. Is the air conditioner even working?”
[cpg cn=true]

The alcohol was starting to kick in. Misaki put her hair in a bun and opened a few buttons of her shirt.
[cpg]

[OnName num="masato"]
“...... Misaki. I can see your breasts.”
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Misaki047"]
[OnName num="misaki"]
“Oh? It doesn't matter if you see them or not, it doesn't make them less attractive.”
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

I was not happy. She was just flirting. She was looking down at me thinking that it would make me happy.
[cpg]

This must be her way of apologizing.
[cpg]

[OnName num="masato"]
;//「トイレ行ってきます。酒ですぐ小のほう行きたくなるんですよね」
“I'm going to the bathroom. It’s the alcohol.”
[cpg cn=true]

After all, there is no value here.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=2500]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[BG f="b_13_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『生物研究所前』（夕方）******************************************************

[OnName num="masato"]
“I finished planting them ……”
[cpg cn=true]

I focused my attention on the tentacles that had been spreading around the city.
[cpg]

I planted them here and there, but they seem to have begun to connect underground. Originally it was a single organism, so they are tring to connect on their own.
[cpg]

It was my network to grasp the system of the whole city.
[cpg]

I extend my tentacles from my soles and connect to the underground network.
[cpg]

[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_10_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（夕方）******************************************************

The whole city unfolded before my eyes.
[cpg]

I can look down from tall buildings at all kinds of places. I have the bird’s view.
[cpg]

[OnName num="masato"]
“Where is ‘one wing’?”
[cpg cn=true]

I hear a crackling sound. It seems to be straining the building ......
[cpg]

[OnName num="masato"]
"Ahh!"
[cpg cn=true]

My vision tilted. The tentacles would become useless if the building broke ……
[cpg]

Buildings that have crossed the cloudburst disaster are usually in peril.
[cpg]

[OnName num="masato"]
“It's not a very versatile power.”
[cpg cn=true]

The view shifts to another part of town.
[cpg]

[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_09_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（夕方）******************************************************

[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]

Hazuki is walking along with her friends from school.
[cpg]

They are talking about exams.
[cpg]

The vibrations inside the tentacles were catching the sounds of the whole town.
[cpg]

[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_11_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洗面所』（夕方）<『童貞喰い』流用>******************************************************

Where am I? There's nothing to see - but there seems to be water.
[cpg]

[OnName num="masato"]
"(Do my tentacles need water?)"
[cpg cn=true]

[OnName num="masato"]
“(I’ll drink some just in case.)”
[cpg cn=true]

[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_07_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『路地裏』（夕方）******************************************************

This is where I was attacked. He's not here.
[cpg]

[OnName num="masato"]
“Where is ... where is he?”
[cpg cn=true]

[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_12_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所内部』******************************************************

Suddenly, it was connected to a different place.
[cpg]

— What? It's in there.
[cpg]

[OnName num="mitsuhara"]
“What in the world is going on? Was it two days ago?”
[cpg cn=true]

[OnName num="sakata"]
“You've been drilling holes in me. ……."
[cpg cn=true]

I hear voices. I look behind the tempered glass at the two scientists.
[cpg]

— I was looking through the basement at those two scientists! Am I connected to that creature through the basement?
[cpg]

It made sense. They are my parents, so to speak. No wonder we know each other's location.
[cpg]

[FG f="CHA03_p2_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Misaki048"]
[OnName num="misaki"]
“Good evening …… hehe ……."
[cpg cn=true]

[OnName num="researcher"]
“Good evening, sir. Are you drunk? I have something important to tell you today.”
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Misaki049"]
[OnName num="misaki"]
“I was just dealing with him. I gave him a drink, but he didn’t get that drunk.”
[cpg cn=true]

[OnName num="mitsuhara"]
“Ha-ha-ha!”
[cpg cn=true]

[OnName num="one_wing"]
“Hey.”
[cpg cn=true]

It happened suddenly. The guy I was looking for appeared. He seemed to be under investigation.
[cpg]

[OnName num="one_wing"]
“This is the newest version of the new creature. It's a creepy-looking thing.”
[cpg cn=true]

[OnName num="mitsuhara"]
“That's right! But the performance is - you know, very high.”
[cpg cn=true]

[OnName num="mitsuhara"]
“Fujita swallowed it, and it's, well, very good in combat!”
[cpg cn=true]

[OnName num="sakata"]
“So now, I want you to swallow it, ‘one wing’!”
[cpg cn=true]

I see. — The parent of this tentacle is trying to show me this.
[cpg]

[OnName num="sakata"]
“He - he's got all this power, but he doesn't want to kill me at all.”
[cpg cn=true]

[OnName num="sakata"]
“You could kill and steal all you want with that power. What’s going on in his mind?”
[cpg cn=true]

[OnName num="one_wing"]
"Hey, hey, hey! That sounds like a waste. But I did find out during the fight that he's a nice guy.”
[cpg cn=true]

[OnName num="one_wing"]
“The look in his eyes makes it hard to kill him.”
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Misaki050"]
[OnName num="misaki"]
“I could see the ferociousness in his eyes, though. I felt that he was fierce, but I guess I was wrong.”
[cpg cn=true]

[OnName num="one_wing"]
“You want to sell it to the armies of the developing world, don't you? Do you want to see how it fares in combat?”
[cpg cn=true]

[OnName num="sakata"]
“Yes, that's right! You seem to understand.”
[cpg cn=true]

[OnName num="sakata"]
“That's why I want you to kill a lot of people with it, ‘one wing’!”
[cpg cn=true]

[OnName num="one_wing"]
“I'll do it.”
[cpg cn=true]

[OnName num="mitsuhara"]
“He's going to cut a hole in the breeding room, too. He'll go quiet if you cut one off.”
[cpg cn=true]

;//(Y):助けられた時など、主人公は美咲について信じている時は「信用できそう」ということしか言ってないので、実際の美咲は……ということはありえるよう書いてます。

;//(Y):>毒を飲まされて何も反応しない主人公も鈍くて問題ですが、　とありますが、毒は……そもそも気づかないのではと思います。「ひいひい」の部分がすぐに効く毒のイメージになるのかなと思ったので変えます

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki051"]
[OnName num="misaki"]
“I wonder if the alcohol poison is working now on Fujita? I hope so.”
[cpg cn=true]

I checked to see how my body was feeling.
[cpg]

[OnName num="sakata"]
“I have another one ready for you tomorrow. Will it look suspicious if I do it tomorrow as well?”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Misaki052"]
[OnName num="misaki"]
“It’s entertaining to watch him look so sad. I'd like to come here tomorrow if I can.”
[cpg cn=true]

[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所前』（夕方）******************************************************

— I returned my attention to the "me" that is the main body.
[cpg]

My body ached. It must be the poison of alcohol. I wondered if they were going to experiment with various things on me.
[cpg]

[OnName num="masato"]
“Huh ……”
[cpg cn=true]

[OnName num="masato"]
“I'm not human now.”
[cpg cn=true]

[OnName num="masato"]
“I can handle it. The tentacles are the key.”
[cpg cn=true]

[FADEOUTBGM]

The poison must be circulating in the blood - Then the answer is easy.
[cpg]

[BGM f="bg_hp"]
[WAIT time=100]

[OnName num="masato"]
“Just suck the blood.”
[cpg cn=true]

[OnName num="masato"]
“And dilute the poison in the blood.”
[cpg cn=true]

I don't know my blood type or if my body will reject it. So I'm going to shoot my blood into their bodies, test it directly, and then suck it.
[cpg]

The control of blood pressure will be managed in the tentacle part that lies underground, not in my body. The excess blood will be temporarily stored in the network.
[cpg]

Fortunately, they are very close.
[cpg]

A cool breeze blows. My skin feels fresh. I think about the letter I put in the drawer of the desk, “Letter of Resignation”.
[cpg]

Now I won't have to go to work tomorrow.
[cpg]

I had thought about talking to them, again, but there was no need.
[cpg]

[OnName num="masato"]
“I have no resentment ….. I’m sorry.”
[cpg cn=true]

I let my tentacles, rooted in the basement of the office, suck the nutrients out of the soil.
[cpg]

;//(Y):画面シェイク

[SE f="se069"]
;//【ＳＥ】ゴゴゴゴゴゴゴ……みたいな地響き

In the distance, the office building begins to tremble. The security guards at the end of the line are no longer there. Only those working in the central building are left.
[cpg]

I can do whatever I want.
[cpg]

;//(Y):画面シェイク・つよめ

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_12_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『生物研究所内部』******************************************************

[OnName num="mitsuhara"]
“What is it? An earthquake?”
[cpg cn=true]

[OnName num="sakata"]
“Are the electronic tools working? We're underground so give me a break.”
[cpg cn=true]

[OnName num="one_wing"]
“……"
[cpg cn=true]

[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misaki053"]
[OnName num="misaki"]
“What's going on?”
[cpg cn=true]

[OnName num="one_wing"]
“This tentacled creature seems to be staring at me …… Or am I just imagining it.”
[cpg cn=true]

[OnName num="researcher_A"]
“I'm going to start cutting it off. How many tentacles do you want ……?"
[cpg cn=true]

[OnName num="mitsuhara"]
“Three is fine. The compatibility rate has already been calculated with the previous number. Safety is guaranteed.”
[cpg cn=true]

[OnName num="sakata"]
“Is it dangerous to drink the whole thing? The numbers should be fine.”
[cpg cn=true]

[OnName num="sakata"]
“We checked the numbers, even for the prototype that leaked out.”
[cpg cn=true]

;//(Y):画面シェイク・つよめ
;//(Y):ちかちかと照明も点灯

[free time=500]
[BG f="black.ui" time=500]
[WAIT time=500]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=500]
[BG f="b_12_3.ui" time=500]
[WAIT time=500]
[free time=500]
[BG f="black.ui" time=500]
[WAIT time=500]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=500]
[BG f="b_12_3.ui" time=500]
[WAIT time=500]

[FACE method="change_5" pos="2/3"]
[VOICE f="Misaki054"]
[OnName num="misaki"]
“What the …?”
[cpg cn=true]

[SE f="se054"]
;//【ＳＥ】『アラート』
[WAIT time=1000]

[OnName num="broadcast"]
“Emergency call. Emergency call.”
[cpg cn=true]

[OnName num="broadcast"]
“An unexplained impact has occurred 39 meters underground, centered on East Wing 2, causing it to collapse.”
[cpg cn=true]

[OnName num="researcher_A"]
“Collapse!?”
[cpg cn=true]

[OnName num="researcher_B"]
“Oh, my God ……!"
[cpg cn=true]

[SE f="se070"]
;//【ＳＥ】『崩れる』

Just as I had hoped— the debris crumbles and the room collapses.
[cpg]


[SE f="se045"]
;//【ＳＥ】『ガラスが割れる』

The tempered glass shattered. It was as if a tentacled creature, the master of my shared senses, had taken action.
[cpg]

[OnName num="one_wing"]
“It's in my mouth! Eww …. Ahhhhh!”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Misaki055"]
[OnName num="misaki"]
“Mr. One Wing??? Aaaaah!”
[cpg cn=true]

[OnName num="one_wing"]
“Gahhhhhhhh!”
[cpg cn=true]

[OnName num="one_wing"]
“Rahhhhh …..Huuuuuhhhh!”
[cpg cn=true]

[SE f="se071"]
;//【ＳＥ】『爆発』

;//ＢＫ
;//(Y):崩落中。浸食中。赤フラッシュと肉ぐぶぐぶ音みたいな演出を被せるイメージでいます。ロコツでない（規制をくぐれる）雰囲気グロ程度
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0xff0000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="red.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xff0000ff} time=1]
[WAIT time=2000]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[BG f="black.ui" time=1000]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『町』（夜）******************************************************

The performance was beyond expectation. Amazingly, I didn't even need to be nearby.
[cpg]

[SE f="se006"]
;//【ＳＥ】『入店音』
[WAIT time=1000]

I enter a cafe with terrace seating.
[cpg]

A gorgeous aroma wafted through the air, tickling my nose. I take a seat and open the menu.
[cpg]

[OnName num="masato"]
“Tea and chiffon cake, please.”
[cpg cn=true]

[OnName num="staff"]
“Yes, sir.”
[cpg cn=true]

A glass of water is offered to me. I run my fingers through the water, wetting them.
[cpg]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]

;//【ＢＧ】『空』（夜）******************************************************

[OnName num="one_wing"]
“......."
[cpg cn=true]

[OnName num="one_wing"]
"....... ....... ......."
[cpg cn=true]

;//[FG f="CHA03_p4_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Misaki056"]
[OnName num="misaki"]
“Bwahaha ...... ah! Are you all right? The debris ...... on my legs, my body!”
[cpg cn=true]

;//(Y):？を追加

[OnName num="one_wing?"]
“You said you poisoned me, didn't you, Misaki?”
[cpg cn=true]

;//[FACE method="change_3" pos="2/3"]
[VOICE f="Misaki057"]
[OnName num="misaki"]
“What are you talking about? I don't care about that right now,……! Mitsuhara! Sakata!!”
[cpg cn=true]

;//[FACE method="change_4" pos="2/3"]
[VOICE f="Misaki058"]
[OnName num="misaki"]
“……"
[cpg cn=true]

;//[FACE method="change_5" pos="2/3"]
[VOICE f="Misaki059"]
[OnName num="misaki"]
“What? Fujita?”
[cpg cn=true]

;//(Y):美咲のセリフは（だいたい）流用
;//(Y):遠隔操作については地下を通じて大規模に触手の力を行使した結果なので、秘密の一区画に籠もって秘密裏に実験をしなければいけない制限がある科学者には、把握できるものではないです

;//●ＣＧ非エロ（服が破けているが全年齢範囲。）ev_33
;//▼『片翼』の使っていた毒触手と、雅人の触手とが混ざっている状態で美咲が締めあげられている

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

— I took control of one wing’s body and took ahold of Misaki.
[cpg]

[VOICE f="Misaki060"]
[OnName num="misaki"]
“Arghhhh ……!”
[cpg cn=true]

[VOICE f="Misaki061"]
[OnName num="misaki"]
Cough cough.
[cpg cn=true]

[VOICE f="Misaki062"]
[OnName num="misaki"]
“That's disgusting ...... !”
[cpg cn=true]

[VOICE f="Misaki063"]
[OnName num="misaki"]
“Ahhhhhhhhhh!!!!”
[cpg cn=true]

[VOICE f="Misaki064"]
[OnName num="misaki"]
“You can’t do this to me!”
[cpg cn=true]

[OnName num="one_wing_and_masato"]
“Mitsuhara and Sakata are buried in the rubble.”
[cpg cn=true]

[OnName num="one_wing_and_masato"]
“They’re moving.”
[cpg cn=true]

[VOICE f="Misaki065"]
[OnName num="misaki"]
“Noooooooo!!!!!”
[cpg cn=true]

[OnName num="one_wing_and_masato"]
“We weren't the only ones who suffered.”
[cpg cn=true]

[OnName num="one_wing_and_masato"]
“What about that thing in the basement? That’s an electric crematorium, right?”
[cpg cn=true]

[VOICE f="Misaki066"]
[OnName num="misaki"]
“I'm sorry! Forgive me!”
[cpg cn=true]

[OnName num="one_wing_and_masato"]
“There is a truck in the underground passageway, loaded with five bags of ashes. It is disguised as a shipping company.”
[cpg cn=true]

[OnName num="one_wing_and_masato"]
“Where does that passageway lead?”
[cpg cn=true]

Not that it mattered right now.
[cpg]

We are no longer at the stage of exchanging words, since a while ago.
[cpg]

I enter Misaki's body - and then her brain.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（夜）******************************************************

A sit at a cafe. The tea is at a moderate temperature.
[cpg]

I see an old man with a cane enter the store. There is a step. My tentacles are circling the basement. The man was standing on the ground above it.
[cpg]

It's dangerous. He loses his balance and almost falls.
[cpg]

I support his legs and feet with my tentacles from afar, pull his torso and prop him up.
[cpg]

[OnName num="old_man"]
“What …..?”
[cpg cn=true]

The old man avoided falling but he looked around as if he had no idea what was going on.
[cpg]

[OnName num="staff"]
“I'm sorry to keep you waiting. Here is your chiffon cake.”
[cpg cn=true]

[OnName num="masato"]
“Oh, thank you ……."
[cpg cn=true]

;//(Y):「遠くの感触で彼女を感じながら」は直接翻訳されたらまずい……？ここにメタファー程度のエロっぽさが入ると効果的な気がするのですが

I pretended that nothing was going on. Feeling ‘her’ in the distance, I sip on my tea.
[cpg]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『ドア開け』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『寝室』（電気OFF）******************************************************

[OnName num="masato"]
“I've pulled out that memory.”
[cpg cn=true]

[OnName num="masato"]
“But I guess at some point I’ll have to go to sleep.”
[cpg cn=true]

I went through Misaki's brain and duplicated the information.
[cpg]

It wasn’t a nice thing to do. I know.
[cpg]

But if I miss this opportunity, information about my abilities, about ‘one wing’, and about my work will disappear into the darkness.
[cpg]

And there might even be a cure for Sanae that would make her better. I didn’t have the luxury to be ‘nice’ right now.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I then fell asleep.
[cpg]

It is said that information in the brain is organized when we sleep. I experienced Misaki's memories in the form of a dream.
[cpg]

;//(Y):流用

[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『美咲の部屋』（昼）******************************************************


[SE f="se003"]
;//【ＳＥ】『ノック』

[OnName num="shidehara"]
“Hey, Misaki. It's me, Shidehara. I came to visit you, are you okay?”
[cpg cn=true]

[OnName num="shidehara"]
“Why are you not answering? I’ll just go inside.”
[cpg cn=true]

[SE f="se019"]
;//【ＳＥ】『ガチャ　ドア』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]

[OnName num="shidehara"]
“Sorry to bother you.”
[cpg cn=true]

[FG f="CHA03_p4_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Misaki067"]
[OnName num="misaki"]
“Ah, senior. Welcome.”
[cpg cn=true]

[OnName num="shidehara"]
“What are you doing here dressed like that?”
[cpg cn=true]

[OnName num="shidehara"]
“You're not planning on coming to work in a suit are you ......?”
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]

Misaki nodded back. This job is for the good of the country.
[cpg]

The international community smells fishy. There will be a war waiting for us to fight over the land that was not contaminated by the "cloudburst disaster” ......
[cpg]

[FACE method="change_1" pos="2/3"]

[OnName num="shidehara"]
“You should sleep if you are sick. Is it gonna happen soon ……?"
[cpg cn=true]

He forced Misaki back to bed. Her stomach was big.
[cpg]

[OnName num="shidehara"]
“Are you okay? I heard you weren't feeling well, so I came to visit you.”
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Misaki068"]
[OnName num="misaki"]
“Thank you.”
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

[OnName num="shidehara"]
“It's hard enough just being pregnant, but you have to go to work. You can take time off. You shouldn't be so hard on yourself.”
[cpg cn=true]

This was his child.
[cpg]

He stayed away from mentioning that. I wonder if this is what men are like.
[cpg]

He works in the fourth left wing and is also thinly aware of Misaki’s work.
[cpg]

Misaki had a fleeting hope that he would marry her, but there was distance - because she was involved in the dirty work.
[cpg]

He is kind, but he won't step up to the plate.
[cpg]

All he does is to tell her to rest and not force herself to go to work.
[cpg]

[OnName num="shidehara"]
“I'm so happy for you. So, who's the father?”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Misaki069"]
[OnName num="misaki"]
“It’s you. What? Don't you remember?”
[cpg cn=true]

[OnName num="shidehara"]
“Huh? I'm sorry, I don't remember ...... When was I with you?”
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Misaki070"]
[OnName num="misaki"]
“Haha, I knew it. You were so drunk, so it can't be helped.”
[cpg cn=true]

[OnName num="shidehara"]
“Was it when we had a drink at work the other day and ……?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Misaki071"]
[OnName num="misaki"]
“Yes, I was surprised. I was drinking too, so I don't really remember either but ……”
[cpg cn=true]

[OnName num="shidehara"]
“Wow ……!"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Misaki072"]
[OnName num="misaki"]
“What ……?"
[cpg cn=true]

He ran away.
[cpg]

Misaki loved him. He was so kind.
[cpg]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Misaki073"]
[OnName num="misaki"]
“Ouch …… I think I'm in labor!”
[cpg cn=true]

;//(Y):ここからは新規

[FADEOUTBGM]

[FACE method="change_6" pos="2/3"]
[VOICE f="Misaki074"]
[OnName num="misaki"]
“Huh huh ……"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Misaki075"]
[OnName num="misaki"]
“Can someone ...... help me? I'm not allowed to call the doctor ...... Ugh!”
[cpg cn=true]

“Ouch. Ouch. Ouch ...... Ah!”
[cpg]



[jump storage="ep005.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
