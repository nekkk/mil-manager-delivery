
;+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
;//2、葉月の隣に座る　の場合
;//(Y):葉月ルートへ

*start|Next to Hazuki

;#################################################
*Ep006|Next to Hazuki
;#################################################



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『居間』（夜電気ON）******************************************************


*select01_2|Next to Hazuki

[SCENE id=6]

[free time=300]
[FG f="CHA02_p4_01_a.ui" method="change_1"  pos="2/5" time=800]

I sat down next to Hazuki.
[cpg]

Hazuki is eating a lot of stir-fried bitter melon.
[cpg]

[FACE method="change_1" pos="2/5"]
[VOICE f="Haduki120"]
[OnName num="haduki"]
“It's easier to eat if you put mayonnaise on it, Masato.”
[cpg cn=true]

[OnName num="masato"]
“Oh.”
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Sanae129"]
[OnName num="sanae"]
“I'd like you to eat it as it is if you can, but it's a matter of personal preference, so I don't mind.”
[cpg cn=true]

[OnName num="masato"]
“Sanae, you are also putting a lot of mayonnaise on yours.”
[cpg cn=true]

We don't seem to care about calories. I think it is healthier to eat right and exercise.
[cpg]

Hazuki started playing with her phone on her lap.
[cpg]

She doesn't seem to be hiding it, but if she had been sitting across the table, I might not have noticed.
[cpg]

[OnName num="masato"]
“So, Hazuki, how did the email to Professor Rogela go the other day?”
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[VOICE f="Haduki121"]
[OnName num="haduki"]
“I got caught. He realized that I had gotten help.”
[cpg cn=true]

Aaaaaaaaaaaaah!
[cpg]

[FACE method="change_1" pos="2/5"]
[VOICE f="Haduki122"]
[OnName num="haduki"]
“Ge forgave me though ...... So yeah, thanks.”
[cpg cn=true]

;//(Y):座った場所が違う、ということによる分岐として王道かなと思ってここから話をはじめることに

;//(Y):一瞬の白フラッシュ

[FADEOUTBGM]
[WAIT time=1000]

Hazuki's phone glittered.
[cpg]

[OnName num="masato"]
“What ……?”
[cpg cn=true]

[OnName num="masato"]
“Get down! Hazuki!”
[cpg cn=true]

[SE f="se072"]
;//【ＳＥ】『銃声』

[free time=500]
[BG f="white.ui" time=500]
[WAIT time=500]

The window was destroyed. I threw a cushion and tried to block the intruder’s view.
[cpg]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki123"]
[OnName num="haduki"]
“Aaaaah!”
[cpg cn=true]

;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sanae130"]
[OnName num="sanae"]
“Ugh……aaaah!"
[cpg cn=true]

[free time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_t1"]
[WAIT time=100]

Sanae unintentionally threw the spoon she was using to eat behind us, toward the window.
[cpg]

— Shit! She almost grazed the intruder!
[cpg]

How could she do that in a spur of the moment?
[cpg]

[OnName num="shooter"]
“Ugh!”
[cpg cn=true]

— And it hit the culprit. I heard the sound of something being removed. — Was it a gun?
[cpg]

;//[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Haduki124"]
[OnName num="haduki"]
“Ughhhh... ……! Take it! I don't know who it is, but whoa!”
[cpg cn=true]

Hazuki threw a fork. It flew off in a lurch in the wrong direction. Coincidences do not occur twice.
[cpg]

[OnName num="masato"]
“Hey, you! I'm a security guard!”
[cpg cn=true]

I ran out into the yard to seize the man while I still could.
[cpg]

I held him down on the ground and punched him.
[cpg]

[OnName num="shooter"]
“Aaaaahhhh!”
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『踏み切り前』（朝）******************************************************

The police came over and we talked until morning.
[cpg]

[OnName num="police_officer"]
“With a spoon, I ...... the culprit ..…”
[cpg cn=true]

Whenever Sanae was mentioned, she would slump down in embarrassment. She was being a bit of a tease.
[cpg]

The shooter has already been arrested and is no longer here. It's a big problem because it's one of the very few shootings in Japan ......
[cpg]

[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Haduki125"]
[OnName num="haduki"]
“Phew ……."
[cpg cn=true]

As expected, Hazuki is looking at her sister with respect. This one was a bigger deal than the gun.
[cpg]

[free time=1000]

[OnName num="masato"]
“I can't believe it either.”
[cpg cn=true]

[OnName num="masato"]
“Why was I being targeted?”
[cpg cn=true]

[OnName num="police_officer"]
“I'm looking into that too, so please wait a moment.”
[cpg cn=true]

[OnName num="masato"]
“I'm sorry for being so impatient. ……"
[cpg cn=true]

[OnName num="police_officer"]
“Anyway, we're going to be investigating this house for a while to preserve the scene.”
[cpg cn=true]

[OnName num="police_officer"]
“Please go stay at someone else's house or a hotel today. The police will pay for your stay.”
[cpg cn=true]

[OnName num="masato"]
“I understand. I'll pack my things.”
[cpg cn=true]

The pie was still there.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『寝室』（朝）******************************************************

[OnName num="masato"]
“I can't believe this is happening. I don't know where to put it ……"
[cpg cn=true]

[OnName num="masato"]
“I need to make it smaller.”
[cpg cn=true]

There was a small case of glass or resin or something in the pie. I don't look inside because I feel like I'll lose my appetite.
[cpg]

I ate about three pieces of the pie. It was not very tasty, probably because it was a disguise.
[cpg]

I hide the case inside the leftover pie. I put it in a hard, shockproof case used for selling eggs, just in case.
[cpg]

[OnName num="masato"]
“The pie is heavily guarded ……”
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（昼）******************************************************

I was thrown out on the town with almost no sleep. But after the incident, I couldn't fall sleep either.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki126"]
[OnName num="haduki"]
"Do you want to go to a hotel?"
[cpg cn=true]

[OnName num="masato"]
“That sounds inappropriate!”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki127"]
[OnName num="haduki"]
“Oh, ...... sorry.”
[cpg cn=true]

[SE f="se074"]
;//【ＳＥ】『おなかが鳴る』
[WAIT time=1000]

Sanae's stomach rumbled.
[cpg]

[OnName num="masato"]
"...... You're the cook, so you probably didn't get to eat much.”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sanae131"]
[OnName num="sanae"]
“I'm sorry …….”
[cpg cn=true]

So we decided to head to a diner. There would be coffee, so we could get rid of the fatigue.
[cpg]

;//●ＣＧ非エロ（ファミレスのテーブル席に座っている。左下からパフェとか飲み物とかがちょろっと出てる）ev_43
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_43_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[VOICE f="Haduki128"]
[OnName num="haduki"]
“Your throwing skill was awesome. That’s all I can say now. I can't think straight.”
[cpg cn=true]

[VOICE f="Sanae132"]
[OnName num="sanae"]
“Oh, Hazuki.”
[cpg cn=true]

[OnName num="masato"]
“The police were commenting a lot about that and now you are too ……?”
[cpg cn=true]

[OnName num="masato"]
“Well, it's a saga, isn't it? I'll avoid mentioning it if you're ashamed of it.”
[cpg cn=true]

[VOICE f="Haduki129"]
[OnName num="haduki"]
“I'm sorry, sis.”
[cpg cn=true]

[VOICE f="Sanae133"]
[OnName num="sanae"]
“Now I feel bad.”
[cpg cn=true]

[OnName num="masato"]
“What do you want me to do ……?"
[cpg cn=true]

[VOICE f="Sanae134"]
[OnName num="sanae"]
“A natural fade-out.”
[cpg cn=true]

[OnName num="masato"]
“Okay.”
[cpg cn=true]

Evil is a very small thing when you get to the core of it. You can have a gun, but you are no match for the strongest man with a spoon.
[cpg]

I think there's an important fact hidden here, but right now I can’t think straight.
[cpg]

;//【ＳＥ】ねこの鳴き声

[OnName num="clerk_robot"]
“Sorry to keep you waiting. Meow.”
[cpg cn=true]

The robot was serving the food. It brought me a parfait.
[cpg]

It's not a cat in appearance, but it was the way it talked.
[cpg]

[OnName num="masato"]
“Let's give him a tip.”
[cpg cn=true]

;//【ＳＥ】ねこの鳴き声

[OnName num="clerk_robot"]
“Meowww!”
[cpg cn=true]

[VOICE f="Sanae135"]
[OnName num="sanae"]
“This restaurant is great.”
[cpg cn=true]

[VOICE f="Haduki130"]
[OnName num="haduki"]
“I feel calm here.”
[cpg cn=true]

The cat's meow begins to play as background music.
[cpg]

Yes, the reason why restaurants everywhere have recently started playing cat meows as background music is because of tips.
[cpg]

As the restaurant is getting crowded in the morning, cats, dogs, and other animals are barking in the background.
[cpg]

It was an elegant meal.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（夜）******************************************************

I've already called in sick at work because of the shooting.
[cpg]

On the other side of the station, a 147-meter bronze statue of the “gal game idol" Yuki Mioji, a.k.a. Yukirin, was being built. It is huge.
[cpg]

It is a new landmark, the gal game statue. After the cloudburst disaster, there must have been a movement to stop it .......
[cpg]

[OnName num="masato"]
“I guess updating values never progresses, does it? I can’t they are doing this in such a populous district ......."
[cpg cn=true]

The sisters called the school. We checked into a hotel and went to sleep.
[cpg]


[jump storage="ep007.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
