

*start|Go to Sanae!

;#################################################
*Ep003|Go to Sanae!
;#################################################

[SCENE id=3]


;//(Y):視点変更トランジション。視点変更時はそうとわかる演出がないと一気に没入感が損なわれるので欲しいです
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『路地裏』（夕方）******************************************************

[OnName num="man_A"]
“Are you done with the exorcism? No civilians can come here!”
[cpg cn=true]

[OnName num="man_B"]
“It's already been handled! Ah! Mr.Mitsuhara and Mr.Sakata are on the line!”
[cpg cn=true]

[OnName num="mitsuhara(call)"]
“Hey! The poison tentacle sample you sent us is too small!”
[cpg cn=true]

[OnName num="man_B"]
“Sorry!”
[cpg cn=true]

[OnName num="mitsuhara(call)"]
“Oh well! Anyway, this poison - it's not that bad. We’ve already analyzed it two years ago! We're geniuses, right?”
[cpg cn=true]

[OnName num="sakata(call)"]
“When we found the cells, we rode the merry-go-round a dozen times to celebrate, but then puked our brains out.”
[cpg cn=true]

[OnName num="mitsuhara(call)"]
“Stop it! If he swallows the piece we gave him, he'd be able to detoxify it.”
[cpg cn=true]

[OnName num="mitsuhara(call)"]
“Yes! It's like this thing that sprays poison on its enemies but gives its host the means to detoxify it.”
[cpg cn=true]

[OnName num="man_B"]
“What?”
[cpg cn=true]

[OnName num="sakata(call)"]
“The host is a magnet for people looking for the antidote.”
[cpg cn=true]

;//(Y):触手が解毒手段持ってる説得力のこじつけ

[OnName num="sakata(call)"]
“What's that saying about the guy who's going around injuring people and also being a doctor?”
[cpg cn=true]

[OnName num="sakata(call)"]
“That's how they make the host their ruler as well, so they coexist and co-prosper. As a result, some seek out the tentacles, and it will spread."
[cpg cn=true]

[OnName num="mitsuhara(call)"]
“It's a nasty creature. The details are not the domain of the scientific duo, but I can't believe this is security level 1.”
[cpg cn=true]

;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sanae045"]
[OnName num="sanae"]
“Uhhh ...... Uhhhh.”
[cpg cn=true]

[OnName num="man_C"]
“The form is changing. If it dies, we will be investigated as well ……"
[cpg cn=true]

[OnName num="man_C"]
“I have six children! I can't be suspected!”
[cpg cn=true]

[OnName num="mitsuhara(call)"]
“Unless he's already had a blood transfusion from Le(a-b-), he should be able to produce an antidote ……!"
[cpg cn=true]

[OnName num="man_C"]
“It's a bird.”
[cpg cn=true]

[OnName num="mitsuhara(call)"]
“What?”
[cpg cn=true]

[OnName num="man_A"]
“It's a bird— no? It's a ……."
[cpg cn=true]

[OnName num="man_B"]
“Let me get closer.”
[cpg cn=true]

;//ＢＫ
;//(Y):視点変更トランジション。

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『路地裏』（夕方）******************************************************

[OnName num="masato"]
“Sanae!”
[cpg cn=true]

Sanae seemed to be unconscious. She seemed to be in pain. But she is alive.
[cpg]

[OnName num="man_A"]
“Hey, you! You're back ……?"
[cpg cn=true]

[OnName num="mitsuhara(call)"]
“Hey, what's going on?”
[cpg cn=true]

I'm sorry, but I couldn't care less - I touched Sanae. I'm sorry. I'm sorry, Sanae.
[cpg]

[OnName num="masato"]
“I can help you. My body is fine, I'm sure yours will be too ......."
[cpg cn=true]

;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sanae046"]
[OnName num="sanae"]
“Nggghhhh .…! Aggghhhh!”
[cpg cn=true]

[OnName num="masato"]
“!?”
[cpg cn=true]

Tentacles crawl out of Sanae's body ……..
[cpg]

That guy …… did he do something to her? Come to think of it, the real target should have been me!
[cpg]

;//●ＣＧ非エロ（早苗の中から触手が出てくる。喉からでも腹部からでも問題ないです）ev_22
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_22_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

;//(Y):横たえる台詞（>男C「彼女にはケルチェBCO33だ！　左側を前にして横に！」）を追加したので正面だと違和感があるな、と思ってev22に変更しました、が、どうかな

[VOICE f="Sanae047"]
[OnName num="sanae"]
“Ahhhhhhhhhhhhhhhh!!!!!!”
[cpg cn=true]

[OnName num="masato"]
“Get a grip, get a grip! ...... Ahhh!”
[cpg cn=true]

[OnName num="man_A"]
“What the ...... ohh! Get away from it!”
[cpg cn=true]

The surrounding fake employees fled. Sanae's consciousness seemed to be clouded.
[cpg]

I used my tentacles to pop the tentacles that were coming out of her.
[cpg]

The ground moves. Somewhere a building collapses.
[cpg]

When the tentacle from Sanae grazed my hand, the area swelled up as if it was burning.
[cpg]

[OnName num="masato"]
“Wow ...... The poison …….”
[cpg cn=true]

[OnName num="masato"]
“! It was just on the spur of the moment, but just now, when my tentacle touched yours, it was nothing happened — !”
[cpg cn=true]

My tentacles could counter it?
[cpg]

I burst back the poisonous tentacles that appear from Sanae's body.
[cpg]

The wall around me crumbles again, stone grains becoming scattered bullets, hitting the walls and the ground.
[cpg]

[VOICE f="Sanae048"]
[OnName num="sanae"]
“Aggghh, ggg, ahhhhh!”
[cpg cn=true]

[VOICE f="Haduki041"]
[OnName num="haduki"]
“Sissssss!!!!”
[cpg cn=true]

[OnName num="masato"]
“Hazuki!”
[cpg cn=true]

[VOICE f="Sanae049"]
[OnName num="sanae"]
“Nnnngggghhhhhhh!”
[cpg cn=true]

[VOICE f="Haduki042"]
[OnName num="haduki"]
“Get back to normal!”
[cpg cn=true]

Sanae stopped moving.
[cpg]

I take the opportunity to hold her down. I'm going to slip my tentacles into her.
[cpg]

[OnName num="masato"]
“I'm sorry!”
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I let the tentacles go inside Sanae's body.
[cpg]

The brain is still alive, but almost everything else under the skin had been devoured by his poisonous tentacles.
[cpg]

There was no trace of Sanae as a human.
[cpg]

[OnName num="masato"]
“The brain, at least, is ……!"
[cpg cn=true]

;//(Y):脳までダメージを受けて意識混濁している人が正常な言葉で思考できるのはなんか違うな、壮絶な状況に対して真摯じゃないと思って以下。プレイヤーには説明しない方が効果的なところだと思います

;//●ＣＧ非エロ（R18版と同じ）ev_14
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_d1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=11 index=0 time=1000]
;**************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

It's beautiful, Assumed madness heavy. When sis gave me Kagoshima's famous apples and carrots.
[cpg]

Oh no, help me, don't erase that memory of Hazuki! I don't want to die!
[cpg]

I don't want to die like this! Crown me with flowers.
[cpg]

I'm here to help you by scratching all of your brain ……
[cpg]

Who are you?
[cpg]

A flesh weaver. I will fix you.
[cpg]

I won't be who I am, and you won't be who you are, because we're going to play together again.
[cpg]

Thank you. You're welcome.
[cpg]

I'll make you something to eat, and I'll see you in the morning as usual.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[FG f="CHA02_p2_01_a.ui" method="change_4"  pos="2/3" time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『姉妹の部屋』（昼）******************************************************

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki043"]
[OnName num="haduki"]
“....... You're my sister.”
[cpg cn=true]

[OnName num="masato"]
“I did everything I could.”
[cpg cn=true]

Sanae is lying in bed.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Haduki044"]
[OnName num="haduki"]
“I'd rather not ask any questions, right, Masato?”
[cpg cn=true]

[OnName num="masato"]
“Yeah. I'm sorry.”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki045"]
[OnName num="haduki"]
“……"
[cpg cn=true]

I know. Sanae is no longer the Sanae she used to be.
[cpg]

The useless muscles, blood vessels, or even bones and internal organs have completely turned into my tentacles - I am a tentacle man.
[cpg]

A patchwork existence. A repaired, patchwork human being.
[cpg]

But somehow, I am alive.
[cpg]

;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sanae050"]
[OnName num="sanae"]
“Zzzzzz”
[cpg cn=true]

Hazuki doesn't know what kind of existence Sanae has become now. I can't tell her either.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki046"]
[OnName num="haduki"]
“I — I can't live without my sister.”
[cpg cn=true]

She gently touched Sanae's hand. A face of compassion - her eyes were half-closed, and her eyelashes were glistening with tears.
[cpg]

[OnName num="masato"]
She was worried about losing her sister.”
[cpg cn=true]

I was tormented by self-doubt. Sanae was probably already gone.
[cpg]

Could I have helped her in a better way?
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki047"]
[OnName num="haduki"]
“I have never even fried an egg. She even did the laundry for me.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki048"]
[OnName num="haduki"]
“You know my mom, she divorced my father and worked as an electric car mechanic. My sister always took care of me.”
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Haduki049"]
[OnName num="haduki"]
“She's the strongest sister in the world. Although I hated it when she hung my underwear out to dry in the yard ……”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Haduki050"]
[OnName num="haduki"]
“Sis, who did this to you?”
[cpg cn=true]

Hazuki squeezed Sanae's hand. On her fingertips were decorated with nail art. A design of the bluish glow of the night sky.
[cpg]

Beauty is something that is passed down from mother to child, like the old tale of the wolf living in the forest.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Haduki051"]
[OnName num="haduki"]
“I’m not that strong. I’m just young.”
[cpg cn=true]

[OnName num="masato"]
“It could be both strength and weakness ……"
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『姉妹の部屋』（夜）******************************************************

[VOICE f="Sanae051"]
[OnName num="sanae"]
“Huh ……”
[cpg cn=true]

;//(Y):流用

[SE f="se029"]
;//【ＳＥ】『衣擦れ』

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[WAIT time=1000]

[VOICE f="Sanae052"]
[OnName num="sanae"]
“Is that a ...... dream?”
[cpg cn=true]

Hazuki was cowering in the corner of the room and looked at Sanae with a glare.
[cpg]

[free time=300]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_4"  pos="4/5" time=800]
[VOICE f="Haduki052"]
[OnName num="haduki"]
“Why is it taking so long sis ……"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[VOICE f="Sanae053"]
[OnName num="sanae"]
“Oh ……."
[cpg cn=true]

She seemed very worried. When I looked at her, she looked like she was about to cry.
[cpg]

I brought her a drink. A sports drink in a plastic bottle. It was a salt and citrus mix.
[cpg]

[FACE method="shake_4" pos="2/5"]
[VOICE f="Sanae054"]
[OnName num="sanae"]
“What the hell is going on …….”
[cpg cn=true]

Hazuki glanced at me. She seemed to wonder if she was allowed to know.
[cpg]

[OnName num="masato"]
“Calm down and tell me what happened?”
[cpg cn=true]

Hazuki looked at me with a grimace. She probably decided that it would be good to take care of Sanae right now, so she kept quiet for the time being.
[cpg]

[FACE method="change_4" pos="2/5"]
[VOICE f="Sanae055"]
[OnName num="sanae"]
“She was threatened. The e-mail even threatened your mom, so she took action ......."
[cpg cn=true]

[FACE method="shock_5" pos="4/5"]
[VOICE f="Haduki053"]
[OnName num="haduki"]
“Our mother?”
[cpg cn=true]

[FACE method="shock_4" pos="2/5"]
[VOICE f="Sanae056"]
[OnName num="sanae"]
“That guy out something in my mouth. He tied me up and ……"
[cpg cn=true]

[OnName num="masato"]
“……"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[VOICE f="Sanae057"]
[OnName num="sanae"]
“Oh …… I can't remember ……"
[cpg cn=true]

[OnName num="masato"]
“...... Okay. You don't have to remember. I've got it pretty much figured out.”
[cpg cn=true]

[FACE method="bow_7" pos="4/5"]
[VOICE f="Haduki054"]
[OnName num="haduki"]
“I believe you anyway. Anyway, the result turned out to be this …….”
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p2_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（夜）******************************************************

Sanae fell asleep again.
[cpg]

I was pursued by Hazuki, and I had no other choice but to tell her.
[cpg]

About That company. About the man who calls himself ‘one wing’. The tentacles that he used.
[cpg]

[SE f="se025"]
;//【ＳＥ】『バンっ！　机をたたく』
[FACE method="shock_3" pos="2/3"]
[VOICE f="Haduki055"]
[OnName num="haduki"]
“...... How am I supposed to believe that?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki056"]
[OnName num="haduki"]
“A mysterious creature? Tentacles? So ...... that creepy thing is inside you, too?”
[cpg cn=true]

[OnName num="masato"]
“What?”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Haduki057"]
[OnName num="haduki"]
“How is it different from the thing that hurt my sister?”
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Haduki058"]
[OnName num="haduki"]
“I am just a human! You should have rejected it! You should have changed your job!”
[cpg cn=true]

[OnName num="masato"]
“But I saved Sanae!”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Haduki059"]
[OnName num="haduki"]
“You're disgusting! Stay away from me!”
[cpg cn=true]

[free time=800]

[SE f=se019]
;//【ＳＥ】『開ける　引き戸』

;//【ＳＥ】『走る　板張り』


As soon as she said that, Hazuki ran out of the living room.
[cpg]

;//(Y):ここから新規

— It was not a good idea to talk. She is just a human being. It's not a weight you can carry on your shoulders ......
[cpg]

[OnName num="masato"]
“I should have been more considerate.”
[cpg cn=true]

[OnName num="masato"]
“I'm sorry. Hazuki.”
[cpg cn=true]

Looking back, it was a coincidence during security that I was involved in the arrest of the fraudulent group “Ikkaku”.
[cpg]

;//(Y):セピア
[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_13_5.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所前』（朝）******************************************************

I was just faithfully carrying out my duties. I thought they were suspicious and called the police. They got arrested, which then led to this case.
[cpg]

The more diligent you are in your work, the more you make a fool of yourself.
[cpg]

Now I know for sure. It's ridiculous. If you touch the evil in the world, they will get back at you holding a grudge.
[cpg]

Are you kidding me? Is this world a joke?
[cpg]

[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『寝室』（電気OFF）******************************************************


[SE f="se029"]
;//【ＳＥ】『衣擦れ』

I curled up in bed alone.
[cpg]

I should go to bed. I'm tired today. I've stopped being human, but here I am, a weak man ......
[cpg]

[OnName num="masato"]
“Sanae ……"
[cpg cn=true]

[OnName num="masato"]
“I love you.”
[cpg cn=true]

I mumbled. The words leaked out naturally.
[cpg]

[OnName num="masato"]
“I love you ……."
[cpg cn=true]

[OnName num="masato"]
“If only we could live together ...... that would be enough.”
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2500]
[BG f="b_10_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（昼）******************************************************

I checked my body.
[cpg]

There was a man I had to find.
[cpg]

[OnName num="masato"]
“There are a lot of tall buildings around here.”
[cpg cn=true]

[OnName num="masato"]
“It’s perfect for a lookout.”
[cpg cn=true]

I walked into the grass and took off my socks.
[cpg]

I take out my cutter, stick it in, and start cutting holes in the soles of my shoes.
[cpg]

I put on the shoes with the holes in them, barefoot, and began to walk.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

Half an hour later.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『路地裏』（昼）******************************************************

[OnName num="masato"]
“I thought these tentacles were just an extension of my hands.”
[cpg cn=true]

[OnName num="masato"]
“But there was more.”
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I close my eyes.
[cpg]

I focus on the soles of my feet. The tentacles begin to grow, piercing the ground and little by little finding balance.
[cpg]

The tentacles take root in the ground, wrapping around the exterior of the nearest building like ivy, crawling upward.
[cpg]

[OnName num="masato"]
“They are also an extension of the eye ……."
[cpg cn=true]

[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『路地裏』（昼）******************************************************

I planted the seed. Then I headed to the next spot.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=2500]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************

[OnName num="masato"]
“This place has a great view.”
[cpg cn=true]

;//(Y):裏設定として新宿御苑から見えるこのビルは東京都庁。※行政関係なので書きません。　……普通に歩いて行くと遠いみたいですね。そこは「ちょっと歩く」だけでも触手パワーで身体能力が上がってるという事で。

I looked closer and saw a tall building. It must have been an important building at one time, but now it was something close to a ruin.
[cpg]

I was grateful for that building.
[cpg]

[jump storage="ep004.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
