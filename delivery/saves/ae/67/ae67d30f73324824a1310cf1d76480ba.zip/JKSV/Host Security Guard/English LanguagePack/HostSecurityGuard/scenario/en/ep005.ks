
*start|Spring Breeze

;#################################################
*Ep005|Spring Breeze
;#################################################

[SCENE id=5]


[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『寝室』（朝）******************************************************

;//雅人：スーツ
;//早苗：私服

[OnName num="masato"]
“How could you kill someone so easily when you have a man you love?”
[cpg cn=true]

I love Sanae. I want to be a person who can love rather than kill people.
[cpg]

;//(Y):片翼はプロットでは「死なない」と書きましたが、詐欺グループの元締め＋毒触手を取り入れててどうしようもなかった＋早苗襲ってる＋殺人依頼に同意している　でけっこう真っ黒になったので、死にました。

;//(Y):全体にこのあたりは殺人のロコツさを抑える調整

That's why I didn't kill Misaki either. I didn't kill Mitsuhara and Sakata either. But ‘one wing’ - I took him down.
[cpg]

Misaki, Mitsuhara, and Sakata had their memories burned away. So that they could start over as different people.
[cpg]

[OnName num="masato"]
“It may be crueler than death, but I'd like to think it's better.”
[cpg cn=true]

[OnName num="masato"]
“I don't want to ...... murder.”
[cpg cn=true]

I want to believe that Sanae is still alive. I can't say I would be able to bear it if someone I cared about was killed.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（朝）******************************************************

;//(Y):流用

Sanae made breakfast. Hazuki has not yet come out of her room, perhaps because it is her day off.
[cpg]

After breakfast, we relax.
[cpg]

;//(Y):別シーン流用

[SE f="se019"]
;//【ＳＥ】『ふすま』

[free time=300]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="4/5" time=800]
[WAIT time=1000]

[VOICE f="Sanae058"]
[OnName num="sanae"]
“Good morning.”
[cpg cn=true]

[OnName num="masato"]
“...... Hazuki, good morning.”
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[VOICE f="Haduki060"]
[OnName num="haduki"]
“Good morning sis ……."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]

Hazuki comes into the living room. The wooden floor made a little creaking sound.
[cpg]

[FACE method="bow_4" pos="2/5"]
[VOICE f="Sanae059"]
[OnName num="sanae"]
“Hazuki, are you okay? You don't look so good.”
[cpg cn=true]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Haduki061"]
[OnName num="haduki"]
“..... Oh, it’s nothing. I jus feel like I haven't slept at all.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[VOICE f="Sanae060"]
[OnName num="sanae"]
“You look kind of dazed ...... If you're not feeling well you should rest today.”
[cpg cn=true]

[OnName num="masato"]
“Yeah. I can take care of you.”
[cpg cn=true]

[FACE method="shake_5" pos="4/5"]
[VOICE f="Haduki062"]
[OnName num="haduki"]
“I don’t want that! I’m fine! I can eat ……"
[cpg cn=true]

Sanae was surprisingly the same person as before.
[cpg]

I'm having a hard time grasping if I can continue to be involved with her as I have been. I’m sure it was the same with Hazuki as well ……
[cpg]

[FACE method="change_1" pos="2/5"]
[VOICE f="Sanae061"]
[OnName num="sanae"]
“I've decided to make a Western meal today. What do you think?”
[cpg cn=true]

[OnName num="masato"]
“Is this homemade bread? And pumpkin soup? This looks good.”
[cpg cn=true]

[FACE method="bow_7" pos="4/5"]
[VOICE f="Haduki063"]
[OnName num="haduki"]
“Bon appétit.”
[cpg cn=true]

[OnName num="masato"]
“Bon appétit.”
[cpg cn=true]

[FACE method="bow_1" pos="2/5"]
[VOICE f="Sanae062"]
[OnName num="sanae"]
“Bon appétit.”
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[VOICE f="Haduki064"]
[OnName num="haduki"]
“Crunch crunch .…. It’s delicious.”
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[VOICE f="Sanae063"]
[OnName num="sanae"]
“Really? Thank you. I had a hard time making homemade bread because my body was in pain.”
[cpg cn=true]

[OnName num="masato"]
“I could eat your cooking anytime! It’s delicious!”
[cpg cn=true]

[FACE method="change_6" pos="2/5"]
[VOICE f="Sanae064"]
[OnName num="sanae"]
“Oh, you don't have to be so greedy …..”
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[VOICE f="Haduki065"]
[OnName num="haduki"]
“……..”
[cpg cn=true]

;//(Y):ここからは新規

[FACE method="change_4" pos="4/5"]
[VOICE f="Haduki066"]
[OnName num="haduki"]
“I don't know why, but ...... I'm starting to cry.”
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[VOICE f="Sanae065"]
[OnName num="sanae"]
“What? Why ……?"
[cpg cn=true]

[FACE method="change_6" pos="4/5"]
[VOICE f="Haduki067"]
[OnName num="haduki"]
“Thanks sis ...... for everything.”
[cpg cn=true]

;//@
;//[OnName num="caster"]
“{Breaking news. As a result of the search by the police and fire department, seven new people have been found after yesterday's building collapse.}”
[cpg cn=true]

I turn my ear to the TV while eating my meal.
[cpg]

;//[OnName num="on_site_reporter"]
“{Three of them are said to be seriously injured but are expected to survive. They have lost their memories due to a concussion.”
[cpg cn=true]

;//@
;//[OnName num="caster"]
“{The situation seems puzzling, as the area is littered with what appear to be earthworms ……}”
[cpg cn=true]

;//[OnName num="on_site_reporter"]
“{Yes. Rumors of soil mutation as a result of the experiment have been denied by the institute.}”
[cpg cn=true]

;//[OnName num="on_site_reporter"]
“{According to the results of an on-site survey, the possibility of the former cloudburst cannot be ruled out.}”
[cpg cn=true]

;//@
;//[OnName num="caster"]
“{What about the connection to the fraud group? Well, the ringleader's body was found.}”
[cpg cn=true]

;//[OnName num="on_site_reporter"]
“{Yes. The bodies of the suspects, Zetzelin, Kaginomiya, and Takashi, were found in a horrible state ……}”
[cpg cn=true]

[FACE method="shake_4" pos="2/5"]
[VOICE f="Sanae066"]
[OnName num="sanae"]
“Uh-oh. Shall I change the channel?”
[cpg cn=true]

[FACE method="shock_5" pos="4/5"]

She automatically changed it. Hazuki seemed to be concentrating on the news too, and reacted with a jerk in her body!
[cpg]

[free time=800]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[FG f="CHA02_p4_01_a.ui" method="change_7"  pos="4/3" time=800]
[WAIT time=2500]

Sanae, the person most involved in this incident, didn't seem to realize it. Well, I hope it stays that way.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_02_a.ui" method="change_4"  pos="2/3" time=1000]
[FG f="CHA02_p4_01_a.ui" method="change_7"  pos="4/3" time=1]
[WAIT time=2000]

Suddenly, a tentacle came out of her back.
[cpg]

[OnName num="masato"]
“Huh?”
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sanae067"]
[OnName num="sanae"]
“There aren't any good channels. ...... all they talk about is the collapsed building.”
[cpg cn=true]

The tentacle slouched and crawled on the ground, extending into the kitchen in the blink of an eye.
[cpg]

It drinks the water from the water tap and then begins to shrink again ……
[cpg]

[free time=300]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="4/5" time=800]
[WAIT time=1000]

;//@
;//[OnName num="news_commentator"]
“{Since the cloudburst disaster, standards for high-rise buildings have been revised, but there is still a danger of old buildings collapsing. ……}”
[cpg]

[FACE method="bow_3" pos="4/5"]
[VOICE f="Haduki068"]
[OnName num="haduki"]
“Yeah! Land prices have dropped because central Tokyo is covered with skyscrapers! I wrote a report about this.”
[cpg cn=true]

The tentacles disappeared. Hazuki doesn't seem to have noticed either.
[cpg]

I looked frantically to see if I could find any water that might have smeared the floor …… Nothing.
[cpg]

[OnName num="masato"]
“Sanae, is everything alright with your body?”
[cpg cn=true]

[FACE method="bow_7" pos="2/5"]
[VOICE f="Sanae068"]
[OnName num="sanae"]
“I'm fine.”
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[VOICE f="Haduki069"]
[OnName num="haduki"]
“By the way Masato, isn’t the collapsed building your work place?”
[cpg cn=true]

[OnName num="masato"]
“Yeah. I lost my job. I have to find a new one.”
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[VOICE f="Sanae069"]
[OnName num="sanae"]
“That’s why! I thought it looked familiar.”
[cpg cn=true]

I wonder how much of Sanae's memory is left.
[cpg]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜電気ON）******************************************************

I don’t have to work anyway. I should take a break for a while. It was another night in the park, where I was swaying on the swings and drinking.
[cpg]

;//【ＳＥ】『ごくっごくっ』

[OnName num="masato"]
“It’s made in Switzerland ……”
[cpg cn=true]

And yet the alcohol tasted bad. It can't be helped. I take the tablet out of my luggage, unfold the small easel, and prop it up.
[cpg]

I took out a brush-shaped pen from the back of the tablet and activated the drawing tool. I start sketching something random.
[cpg]

[OnName num="masato"]
“I think I'd rather do this than drink. Although it's too dark outside.”
[cpg cn=true]

The lighting these days is getting dimmer and dimmer due to the international policy of de-globalization. It is not a good time for sketching.
[cpg]

But I am aware of the inside of my body. These guys have strengthened the muscles in my eye's, and I can see at night.
[cpg]

[OnName num="masato"]
“How I wish they had been able to use their abilities like this, instead of using them for military purposes.”
[cpg cn=true]

[OnName num="masato"]
“I guess the fighting of land won’t stop ……”
[cpg cn=true]

Looking at the world, there was still plenty of beauty to be found. Even after the cloudburst disaster, the world was not abandoned.
[cpg]

As I sketched with poor lines, I felt like painting.
[cpg]

I was still beginning to draw ...... Sanae's face with poorvdrwing skills.
[cpg]

[OnName num="masato"]
“…… Ah.”
[cpg cn=true]

[OnName num="masato"]
“I have no choice. I'll just paint it as is.”
[cpg cn=true]

;//(Y):（自分のシナリオ執筆の結果、CGノルマを埋める必要がありそうなら）ここにラフ描きの早苗

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I would I would add shadows in the back and create a pose for her.
[cpg]

[OnName num="masato"]
“Twisting the contra post shouldn't be a bad idea ...... right?”
[cpg cn=true]

I think that was the way to add dynamism. Now it's different. It's for an everyday/natural pose.
[cpg]

I like Sanae in that natural way, just cooking and smiling.
[cpg]

There was no need to do anything unusual.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（夜）******************************************************

On the way home, the lights of the unmanned bookstore were twinkling. It seemed to be breaking.
[cpg]

[OnName num="masato"]
“I'll buy them both a book card ……”
[cpg cn=true]

A book card. Even in the age of credit cards and loyalty points, it seems that library cards still exist. They take up a lot of space though.
[cpg]

I was browsing through a bookstore when Mary Shelley's "Frankenstein" caught my eye.
[cpg]

It is the story of Dr. Frankenstein, who has to face "human beings" because he resurrected a corpse.
[cpg]

[OnName num="masato"]
“…….”
[cpg cn=true]

I proceed to the unattended cash register, purchase and issue a book card, and leave the store.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（夜）******************************************************

[OnName num="masato"]
“I bought you both book cards!”
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[VOICE f="Sanae070"]
[OnName num="sanae"]
“Wow! Thank you!”
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[VOICE f="Haduki070"]
[OnName num="haduki"]
“Yay! Thank you!”
[cpg cn=true]

;//(Y):キャラ対比して厚みを出すパート

[OnName num="masato"]
“What are you guys going to buy? I'd buy comic magazines or camping magazines.”
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[VOICE f="Sanae071"]
[OnName num="sanae"]
“You think I'd say something about cooking right? But I want to buy American comics.
[cpg cn=true]

[OnName num="masato"]
“American comics?”
[cpg cn=true]

[FACE method="shake_1" pos="4/5"]
[VOICE f="Haduki071"]
[OnName num="haduki"]
“It's my sister's hobby. She always occupies the bookshelf.”
[cpg cn=true]

[OnName num="masato"]
“Really?”
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[VOICE f="Sanae072"]
[OnName num="sanae"]
“A sushi chef, dying from his training to make potato porridge, awakens his ability to jump from building to building while ……”
[cpg cn=true]

Wow, that's a lot of calories.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sanae073"]
[OnName num="sanae"]
“The sushi attracts the spirits of Nobunaga Oda and then the chef summons them to fight against the giant demons attacking New York City.”
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[VOICE f="Haduki072"]
[OnName num="haduki"]
“It's a lot of fun.”
[cpg cn=true]

What will Hazuki buy? She seems to be giving it a lot of thought.
[cpg]

[FACE method="change_7" pos="4/5"]
[VOICE f="Haduki073"]
[OnName num="haduki"]
“I think I'll think about it after I go to a big bookstore.”
[cpg cn=true]

[OnName num="masato"]
“That's the safest answer.”
[cpg cn=true]

She is going to be spontaneous ......
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（朝）******************************************************

I planted tentacles around the house using the shoe with the hole in the back.
[cpg]

I want to know if something happens. The possibility of disaster should be gone by now, but just in case.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sanae074"]
[OnName num="sanae"]
“I'm off to school.”
[cpg cn=true]

[OnName num="masato"]
“Oh, have a good day.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sanae075"]
[OnName num="sanae"]
“I'm graduating soon. I have to go and pick out my graduation dress ...... hmm?”
[cpg cn=true]

Sanae looked at my feet and tilted her head. This is not good. I usually wear socks, but not today.
[cpg]

[free time=800]

But she was in a hurry to get going. She seemed to be concerned, but she left the house right away.
[cpg]

[OnName num="masato"]
“Oh, look out ……"
[cpg cn=true]

[OnName num="masato"]
“If I say that I’m just here to check the mail in front of the house then I don't need to wear socks …… right?”
[cpg cn=true]

A train passed in front of my house and the wind blew. The power lines swayed unsteadily. I want to cut out this view and send it to someone.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（昼）******************************************************

There was an "edible plant exhibition hall" next to the park. I bought some shiso, turnip, and radish there.
[cpg]

[OnName num="masato"]
“I was watching Sanae cook, too.”
[cpg cn=true]

[OnName num="masato"]
“I want to make her something good.”
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（夜）******************************************************

I made a simple soup and served it to her.
[cpg]

[FACE method="change_2" pos="2/5"]
[VOICE f="Sanae076"]
[OnName num="sanae"]
“Wow! This is delicious.”
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[VOICE f="Haduki074"]
[OnName num="haduki"]
“Oh, is this ...... Masato's cooking? I'm not saying it's great, but it's better than mine ……"
[cpg cn=true]

[OnName num="masato"]
“Yeah. I had some free time.”
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[VOICE f="Haduki075"]
[OnName num="haduki"]
“The soup has its character ….. didn't it spill?”
[cpg cn=true]

[OnName num="masato"]
“No, it didn't. As for the miso, I ordered some miso from a faraway prefecture.”
[cpg cn=true]

[OnName num="masato"]
“It may be a simple dish, but I'm free for a while, so I'll help you with cooking.”
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[VOICE f="Sanae077"]
[OnName num="sanae"]
;//「ほっほー、言ってくれますね藤田さん。今日、私はお返し兵器があるんです」
“That’s very kind of you Masato. As an addition, I made something as well.”
[cpg cn=true]

“What— what?”
[cpg]

Sanae put something on the desk with a thud.
[cpg]

It was an ice shaving machine!
[cpg]

[OnName num="masato"]
“It's almost winter! …… For some reason, ice cream is good in the winter too ……"
[cpg cn=true]

[FACE method="shock_5" pos="4/5"]
[VOICE f="Haduki076"]
[OnName num="haduki"]
“Whoa!”
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[VOICE f="Haduki077"]
[OnName num="haduki"]
“I'll go buy some strawberry syrup then!”
[cpg cn=true]

[FACE method="bow_1" pos="2/5"]

Sanae put the strawberry syrup on the desk.
[cpg]

[FACE method="change_2" pos="4/5"]
[VOICE f="Haduki078"]
[OnName num="haduki"]
“Wow! Nice infrasturcture! Like a power line coming through!”
[cpg cn=true]

[OnName num="masato"]
“I can’t believe this! Hospitality wise, I'm completely defeated by Sanae ……!”
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[VOICE f="Sanae078"]
[OnName num="sanae"]
Sanae chuckles.
[cpg cn=true]

[OnName num="masato"]
“How much was it? How many public bath coupons and cat cafe tickets should I give you?”
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[VOICE f="Sanae079"]
[OnName num="sanae"]
“It's a free service.”
[cpg cn=true]

[OnName num="masato"]
“Then it’s a total defeat.”
[cpg cn=true]

[FO pos="4/5" time=1000]


Hazuki went to the refrigerator. She checked the ice in the freezer.
[cpg]

She puffed her cheeks and smiled. Sanae saw it and chuckled.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[BG f="b_09_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（朝）******************************************************

I was going to talk to the police for a bit today.
[cpg]

It was not only about the fraudulent group ‘Ikkaku’ but also about the collapse of the building.
[cpg]

[OnName num="masato"]
“They won't find out about the tentacles, I'm sure.”
[cpg cn=true]

[OnName num="masato"]
“But I'm ...... involved in too many strange cases.”
[cpg cn=true]

[OnName num="masato"]
“It's the idiots who attack me to get revenge …… it's their fault!”
[cpg cn=true]

It was gloomy. I was nervous. I left the house and started walking ...... Then I saw a motorcycle stopping at our house.
[cpg]

[OnName num="postal_worker"]
“It’s mail!”
[cpg cn=true]

I heard Sanae's voice …… and the mailman left a package in front of the house.
[cpg]

[OnName num="masato"]
“I can’t do this. I’m worried about every little thing.”
[cpg cn=true]

I don't turn around, sit down, pretend to tie my shoes, and connect to the ground. I 'saw' it with my tentacles around the house.
[cpg]

The neighbors seem to think this is just some kind of ivy. It has a camouflage effect.
[cpg]

[OnName num="postal_worker"]
“Like the morning glory flower.”
[cpg cn=true]

[OnName num="postal_worker"]
“I don't remember the ivy being this overgrown.”
[cpg cn=true]

I can hear their voices. Is this like a string telephone? But that can only happen with a pulled thread .......
[cpg]

[OnName num="masato"]
“I wonder if we can find the research results under that rubble ……”
[cpg cn=true]

;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="kosuri5.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kosuri5.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//[BGM f="bg_t1"]
;//[WAIT time=100]
;//【ＢＧ】『居間』（夜）******************************************************

It was night when I returned home. I didn't think I would be allowed to visit the scene of the crime ......
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki079"]
[OnName num="haduki"]
“What about my sister? Is she still drinking somewhere?”
[cpg cn=true]

Hazuki was eating the shaved ice. The flavor was strawberry with condensed milk.
[cpg]

[OnName num="masato"]
“I guess she hasn’t come back yet. It’s that time of year for a drinking party because graduation is close.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki080"]
[OnName num="haduki"]
“I heard that she picked out her graduation dress today. There is a kimono club, so the American comics club went along with them.”
[cpg cn=true]

[OnName num="masato"]
“They probably decided to have a joint drinking party on the way home ……"
[cpg cn=true]

It's late today. I'm worried because it reminds me of the incident in the past. Hazuki seems to be feeling the same.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki081"]
[OnName num="haduki"]
“Masato ….. I've been trying not to think about it.”
[cpg cn=true]

[OnName num="masato"]
“Yeah.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki082"]
[OnName num="haduki"]
“Is there still that thing in your body that is not human ……?"
[cpg cn=true]

[OnName num="masato"]
“……"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Haduki083"]
[OnName num="haduki"]
“I heard that you cured my sister with that.”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Haduki084"]
[OnName num="haduki"]
“How are you planning to use that power? I'm still afraid of you, Masato.”
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Haduki085"]
[OnName num="haduki"]
“I know you’re kind, but ...... could it be that it was you who caused that building to collapse?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki086"]
[OnName num="haduki"]
“What about that Misaki? What happened to her?”
[cpg cn=true]

I was lost. How should I answer? There are only dark facts in that area of topic.
[cpg]

The Misaki that carried me on her back and that I believed was the enemy. Misaki immediately switched to being on one wing’s side.
[cpg]

[OnName num="masato"]
“I want to use this power to ...... maintain a normal life.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki087"]
[OnName num="haduki"]
“……"
[cpg cn=true]

[OnName num="masato"]
“I've been shot at, I saved Sanae from being attacked, and all kinds of other things.”
[cpg cn=true]

[OnName num="masato"]
“I don't want to go down fighting.”
[cpg cn=true]

[OnName num="masato"]
“I want to use this extraordinary power only for a little bit of happiness ……"
[cpg cn=true]

Hazuki was staring into my eyes.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki088"]
[OnName num="haduki"]
“But, Masato.”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki089"]
[OnName num="haduki"]
“Helping one person means abandoning another.”
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Haduki090"]
[OnName num="haduki"]
“Assuming you want my sister to be happy, how do you feel about others like me?!
[cpg cn=true]

[OnName num="masato"]
“That’s ……"
[cpg cn=true]

;//(Y):「プレイヤー自ら選択した」事実はオチを重くするので選択肢。システム上においては、分岐による変化はありません
;//(Y):こちら分岐にシステム上の変化は存在しない趣旨をそれとなく伝えたい……メタすぎない範囲で

;//■選択肢
[switch]
[case "I want to make everyone happy."]
	[swap]
	[jump target="*select02_1"]
[case "I want to make Sanae happy."]
	[swap]
	[jump target="*select02_2"]
[endswitch]

;//■システム選択肢２
1. I want to make everyone happy.
2. I want to make Sanae happy.

;+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
;//１、みんなを幸せにしたい　の場合

*select02_1|Spring Breeze

[OnName num="masato"]
“I want to make everyone happy!”
[cpg cn=true]

[OnName num="masato"]
“I don't want you to only protect Sanae.”
[cpg cn=true]

[OnName num="masato"]
“I'm greedy you know.”
[cpg cn=true]

;//すぐ合流。合流Ａへ
[jump target="*select02_3"]

;//==============================
;//２、早苗を幸せにしたい

*select02_2|Spring Breeze

[OnName num="masato"]
“I want to make Sanae happy.”
[cpg cn=true]

[OnName num="masato"]
“I'm sorry. I think that's what choice means.”
[cpg cn=true]

[OnName num="masato"]
“I can't say I'll make all of you happy.”
[cpg cn=true]

;//すぐ合流。合流Ａへ
;//==============================
;//合流Ａ

*select02_3|Spring Breeze

Hazuki got up from her chair and began to fill her plate with ice.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki091"]
[OnName num="haduki"]
“You eat shaved ice, right?”
[cpg cn=true]

[OnName num="masato"]
“Yes.”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Haduki092"]
[OnName num="haduki"]
“I bought a Blue Hawaii syrup. Your favorite.”
[cpg cn=true]

Without being told, she used the ice-shaving machine and prepared a plate. She also poured the syrup over it.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『寝室』（夜）******************************************************

I fell asleep.
[cpg]


;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

Sanae still hadn’t come home.
[cpg]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥のさえずり』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『姉妹の部屋』（朝）******************************************************

It was almost 5:00 in the morning when I woke up. Sanae had not returned.
[cpg]

[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Haduki093"]
[OnName num="haduki"]
“Are you awake!?”
[cpg cn=true]

[OnName num="masato"]
“Are you awake!?”
[cpg cn=true]

[OnName num="masato"]
“Where’s Sanae?”
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Haduki094"]
[OnName num="haduki"]
“I'm going to check my sister's tablet. Thank God I know the password ……!”
[cpg cn=true]

Me and Hazuki go to Sanae's tablet. She seems to have left it on her bed.
[cpg]

[OnName num="masato"]
“Ugh …… I know I'm supposed to behave, but …..”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Haduki095"]
[OnName num="haduki"]
“Here! This is an electronic flyer for a neighborhood dress store! This store is the school's contractor for the graduation gowns!!”
[cpg cn=true]

[OnName num="masato"]
“And after that, she was supposed to go out for a drink, right?”
[cpg cn=true]

Hazuki and I opened the map app and explored the area around the dress shop. There are several bars.
[cpg]

[OnName num="masato"]
“Let's see if we can narrow down the taverns around here ……!”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki096"]
[OnName num="haduki"]
“I wonder if there's anything we can find in the text messages ...... Let's take a look.”
[cpg cn=true]

If I'm lucky, there might be a location and meeting time in the text messages - but I can't find it.
[cpg]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Haduki097"]
[OnName num="haduki"]
“Um, Masato!”
[cpg cn=true]

[OnName num="masato"]
“?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki098"]
[OnName num="haduki"]
“Is ...... your power useful for this kind of stuff ……?”
[cpg cn=true]

[OnName num="masato"]
“It’s actually……. I was going to do that.”
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（朝）******************************************************

I connected to the underground network in the garden.
[cpg]

I operated the eye extensions wrapped around the various skyscrapers which I also used to search for "one wing" in the past.
[cpg]

There are only a few kimono stores. First, I began to explore the area around the shop that has a contract with the scchool.
[cpg]

;//(Y):背景をメッセージなしで次々切り替えてください

[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_10_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（朝）******************************************************



[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『公園』（朝）******************************************************

[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[BG f="b_08_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『裏路地』（昼）******************************************************

I found Sanae. Easily.
[cpg]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Sanae080"]
[OnName num="sanae"]
“Huh ……!"
[cpg cn=true]

[OnName num="man_A"]
“We've finally cornered her.”
[cpg cn=true]

[OnName num="man_B"]
“I can’t believe she ran away.”
[cpg cn=true]

— I've seen these men before. They were former employees of the institute. They were the ones who disguised themselves as ordinary people.
[cpg]

Why?
[cpg]

[OnName num="man_C"]
“We have lives, too.”
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Sanae081"]
[OnName num="sanae"]
“I don't know! It has nothing to do with me!”
[cpg cn=true]

[OnName num="man_D"]
“It's a big deal! You're ...... the civilian from that incident! You were successfully revived!”
[cpg cn=true]

[OnName num="man_E"]
“Kouhara and Sakata are in good health and rehabilitated under the protection of the state! The government is protecting the security …… but we're out of a job!”
[cpg cn=true]

[OnName num="man_F"]
“And we're about to be killed! Because we're at the bottom! It's cheaper than protecting us!”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sanae082"]
[OnName num="sanae"]
“!”
[cpg cn=true]

Sanae's eyes flashed with sympathy for a moment. Is she the kind of girl who would feel empathy for an enemy?
[cpg]

She then shook her head and began to walk away from those men.
[cpg]

[OnName num="man_A"]
“If we could submit you to the state ...... then there will be hope. Please understand.”
[cpg cn=true]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Sanae083"]
[OnName num="sanae"]
“I'm just a student at the academy! What value am I to you ……?”
[cpg cn=true]

[OnName num="man_B"]
“……"
[cpg cn=true]

[OnName num="man_B"]
“Don't tell me you don’t know ……?"
[cpg cn=true]

[window target=false]
[free time=500]
[BG f="b_09_1.ui" time=500]
[WAIT time=500]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（朝）******************************************************

I went back to my own body for a moment.
[cpg]

[OnName num="masato"]
“Uh …… Ah!"
[cpg cn=true]

[FG f="CHA02_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Haduki099"]
[OnName num="haduki"]
“What's wrong, Masato?”
[cpg cn=true]

Hazuki supported my body. I wobble.
[cpg]

[OnName num="masato"]
“I don't want this.”
[cpg cn=true]

It is not Sanae who will be tested in the future.
[cpg]

[OnName num="masato"]
“No ……!"
[cpg cn=true]

It's me.
[cpg]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『裏路地』（昼）******************************************************

The men are chasing Sanae down.
[cpg]

Kicking trash, splashing puddles, and soaking their dirty trousers in mud.
[cpg]

The styrofoam bounced, and one of the men snarled and swiped it away with his hand.
[cpg]

[OnName num="man_A"]
“Wait a minute!”
[cpg cn=true]

[OnName num="man_B"]
“There must be a tentacled monster inside you!”
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Sanae084"]
[OnName num="sanae"]
“No! No! Don't come here! Even the main street is blocked ……"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sanae085"]
[OnName num="sanae"]
“What ...... are you talking about!”
[cpg cn=true]

— I tried to intervene by extending a tentacle.
[cpg]

Now, this tentacle is an extension of the eye. There is not enough water and nutrient distribution to use it as an arm - it is like a muscle that lacks blood.
[cpg]

It needs to be fed with nutrients over time to gain strength.
[cpg]

[OnName num="man_C"]
“It means you're a monster who'll never be able to see a doctor again!”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Sanae086"]
[OnName num="sanae"]
“What?”
[cpg cn=true]

[OnName num="man_C"]
“It will be all over once you get an X-ray! And then you'll be all over the news!”
[cpg cn=true]

[OnName num="man_C"]
“That's why we'll protect you before that happens! You're all we need to get accepted from the state.”
[cpg cn=true]

— I make the tentacles absorb water and nutrients and move them around. I have to save Sanae ......
[cpg]

The tentacles swell and bloat taking the figure of an arm - I make the building creak.
[cpg]

;//ＢＫ

[OnName num="masato"]
“(Get away from Sanae!)”
[cpg cn=true]

;//【ＢＧ】『裏路地』（昼）******************************************************

One of the men threw a stone at Sanae. He was probably hoping it would hit her in the leg.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sanae087"]
[OnName num="sanae"]
“Ahhhhhhhhh!!”
[cpg cn=true]

[OnName num="masato"]
“(Sanae!)”
[cpg cn=true]

It hit the back of the head, She staggered and used the wall to support herself.
[cpg]

A man reaches out a hand. She shakes it off and walks further into the narrow alley.
[cpg]

[OnName num="masato"]
“(Don’t touch Sanae!!!!!!)”
[cpg cn=true]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Suddenly, my vision blurs. Everything goes black.
[cpg]

— What is it?
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『踏み切り前』（朝）******************************************************

I was pulled back. I felt intense pain all over my body.
[cpg]

[OnName num="masato"]
“Gghh……aahhhh! What the hell is this ……!”
[cpg cn=true]

[FG f="CHA02_p2_01_a.ui" method="change_4"  pos="2/3" time=800]

Hazuki didn't call out to me. She was looking in the direction of the town.
[cpg]

A broadcast echoed.
[cpg]

;//[OnName num="broadcast"]
“{Kayado ward, emergency broadcast—! Citizens, please be aware of a collapse!}”
[cpg]

;//[OnName num="broadcast"]
“{The former International Glass Pole Chandelier Tower will collapse! Get down now! Get down now ……!}”
[cpg]

[SE f="se070"]
;//【ＳＥ】倒壊音

The dust was running toward us on the ground. Both Hazuki and I got down.
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="Haduki100"]
[OnName num="haduki"]
“Ahhhhhhh!!!!”
[cpg cn=true]

The high-rise building that I used to support my tentacles collapsed. The building had become fragile since the cloudburst disaster.
[cpg]

[OnName num="masato"]
“I was being tested."
[cpg cn=true]

[OnName num="masato"]
“And now I lost.”
[cpg cn=true]

[OnName num="masato"]
“Instead of saving Sanae, I saved the others.”
[cpg cn=true]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se073"]
;//【ＳＥ】『心音』
;//赤フラッシュ

[free time=500]
[BG f="red.ui" time=500]
[WAIT time=500]
[BG f="black.ui" time=500]
[WAIT time=500]

[OnName num="one_wing"]
“Hey there. Hello from the residue of memories.”
[cpg cn=true]

[OnName num="one_wing"]
“You took me in, and now I'm gone. I can't even stand up to you.”
[cpg cn=true]

[OnName num="one_wing"]
“But you heard me.”
[cpg cn=true]

;//(Y):セピア

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『生物研究所内部』******************************************************

[OnName num="sakata"]
“He's got all this power, and he won't even try to kill.”
[cpg cn=true]

[OnName num="sakata"]
“Normally, one would do whatever, whether it be stealing or killing! What's going on in his mind?”
[cpg cn=true]

[SE f="se073"]
;//【ＳＥ】『心音』
;//赤フラッシュ

[free time=500]
[BG f="red.ui" time=500]
[WAIT time=500]
[BG f="b_12_5.ui" time=500]
[WAIT time=500]

[OnName num="one_wing"]
“You tried to save one person, didn't you?”
[cpg cn=true]

[OnName num="one_wing"]
“Just one.”
[cpg cn=true]

[OnName num="one_wing"]
“I'm not here to ...... denounce you. I'm here to ……"
[cpg cn=true]

[OnName num="one_wing"]
“Maybe, just maybe ...... I'm a petty evil. Compared to you.”
[cpg cn=true]

[OnName num="one_wing"]
“That's the last thing I'm going to say.”
[cpg cn=true]

He looked at me with pity. There was kindness in his eyes.
[cpg]

[OnName num="one_wing"]
“Goodbye.”
[cpg cn=true]

[OnName num="one_wing"]
“I think sometimes it's more difficult to live.”
[cpg cn=true]

;//(Y):片翼消える

Yes, it is. I had sinned.
[cpg]

;//(Y):すいません。「町」に差分の要望を追加します。＞その他差分：崩壊した町（昼）　グラフィック要望リストをご確認ください。
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[BG f="b_10_5.ui" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『町』（崩壊）******************************************************

I, through a network of tentacles, heard the vindictive voices of the whole town.
[cpg]

[OnName num="child"]
“Mother!!!!! Mother!!!!!!!!”
[cpg cn=true]

[OnName num="woman"]
“Someone ...... help!”
[cpg cn=true]

[OnName num="man"]
“Cough cough ……gub......aah......!"
[cpg cn=true]

[OnName num="man"]
“I can see ...... the stars.”
[cpg cn=true]

The information is being transmitted through a vibration.
[cpg]

I give an inarticulate cry at the center of the myriad extensions of myself.
[cpg]

I can't even wriggle out of my pain.
[cpg]

Somewhere inside of me, I wondered if this was a useful ability I had been given. Now, it was a curse.
[cpg]

[OnName num="broadcast"]
“Emergency broadcast ……..”
[cpg cn=true]

[OnName num="broadcast"]
“Cough, cough.”
[cpg cn=true]

[OnName num="broadcast"]
“Ahhh ……”
[cpg cn=true]

As far as I could see, more than 3000 people had died.
[cpg]

[OnName num="masato"]
“(I thought this was an extension of my hand.)”
[cpg cn=true]

[OnName num="masato"]
“(Another creature ……)"
[cpg cn=true]

[OnName num="masato"]
“(A beast.)”
[cpg cn=true]

[OnName num="masato"]
“(A monster.)”
[cpg cn=true]

[OnName num="masato"]
“(Why did you think you could dominate it?)”
[cpg cn=true]

I saw a dog crawling out of the rubble. The old man's wrinkled hand was calling for help.
[cpg]

The dog bit the old man's hand, snapping the bones of his fingers. The dog was still biting the hand.
[cpg]

Then the dog leaves.
[cpg]

[OnName num="masato"]
“(〜〜〜〜〜!)”
[cpg cn=true]

I start to retrieve the tentacles that have been spreading around the town.
[cpg]

I don't like it. It's not my arm. It's someone else's. It's not me ......
[cpg]

My mind was giving orders to the tentacles.
[cpg]

[OnName num="masato"]
“(Go wherever you want. I can't carry you.)”
[cpg cn=true]

From somewhere came a voice that said, 'No.'
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（昼）******************************************************

‘I don't want to leave.’ ‘We're connected.’ ‘Where else can I go?’
[cpg]

[OnName num="masato"]
“(Uhhh ……..)”
[cpg cn=true]

[OnName num="masato"]
“(Aaaaahhhhhh!!!)”
[cpg cn=true]

“I shouldn't have been allowed to use this ability. I've got too much power.”
[cpg]

I was the Frankenstein or the Prometheus of our time.
[cpg]

Let's kill people and suck their nutrients.' 'Let's do that.'
[cpg]

[OnName num="masato"]
“(Don't do it!)”
[cpg cn=true]

[OnName num="masato"]
“(Don't kill me! Don't kill me! Don't kill me!”
[cpg cn=true]

The one with the greatest intelligence is the one that's inside of that lab.
[cpg]

“(I won't let you go. I won't let you go, Masato Fujita.)”
[cpg]

The collapse rips off countless tentacles trying to get back to me, some of them escaping and coming back to me.
[cpg]

I just wanted to be a mere human being dreaming of a normal life.
[cpg]

In my spinning vision, I saw the torn tentacles scattered around the town, crawling up to the weakened humans.
[cpg]

So many tentacles were broken off and became new life, then cut into pieces, and died, unable to live.
[cpg]

They died, unable to live, after killing many people.
[cpg]

‘Humans are delicious.’ ‘They’re delicious.’
[cpg]

‘Thank you for giving birth, father.’
[cpg]

[OnName num="masato"]
“(No, no, no! No!)”
[cpg cn=true]

[OnName num="masato"]
“(All I wanted to do was to save Sanae ......, but ……!)”
[cpg cn=true]

I know - the monsters also just want a normal life. They just want to leave behind the fleeting lives where they are born and then die.
[cpg]

Meanwhile, the tentacles coming back to me have brought back a surplus of soil nutrients that they had sucked up.
[cpg]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（朝）******************************************************

My head is clear and my body is full of strength. I feel my height increase by ten to twenty centimeters.
[cpg]

Without any intention, my body has become bigger than the average person.
[cpg]

[FG f="CHA02_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Haduki101"]
[OnName num="haduki"]
“Ahhhh ……"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Haduki102"]
[OnName num="haduki"]
“Ahhhhhhhhhhhhhhhh!!!!!”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Haduki103"]
[OnName num="haduki"]
“Gross! Gross, gross!”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Haduki104"]
[OnName num="haduki"]
“Die, monster!”
[cpg cn=true]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

Hazuki screamed and ran away from me.
[cpg]

I was turning into a giant. My height exceeded 300 centimeters, 310 centimeters, and kept growing.
[cpg]

;//(Y):スパイダーマン（>触手を放ちビルの壁面に捕まる。屋根から屋根へ飛び渡り加速。）→スーパーマン（男A「鳥です——いや、違う？　ありゃ……」）→ハルク

If I were to do anything with that strong muscular body, it would be to cry out loud.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『裏路地』（昼）******************************************************

[OnName num="man_A"]
“Oooohhhhhhhhhh ……! It's collapsing……!"
[cpg cn=true]

[OnName num="man_B"]
“No, not in this direction! Are you okay ……! Cough cough!”
[cpg cn=true]

[OnName num="man_C"]
“Cough! Cough ……!”
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sanae088"]
[OnName num="sanae"]
“Ahhhhhhhhh!!!!!”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Sanae089"]
[OnName num="sanae"]
“Something's coming from inside ……!"
[cpg cn=true]

[OnName num="man_D"]
“Hey, he's falling! Get him while you can!”
[cpg cn=true]

[OnName num="man_E"]
“Isn't he acting weird ……? Oh well!”
[cpg cn=true]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Sanae090"]
[OnName num="sanae"]
“Something's coming ……!"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sanae091"]
[OnName num="sanae"]
“It wants out! What the hell is this?”
[cpg cn=true]

[OnName num="man_F"]
“Oh ......?”
[cpg cn=true]

;//(Y):遡ると　>早苗の目には同情の光が一瞬浮かんだ。そ、そんな……敵に対して入れ込むような子なのか……！？　があるので不自然ではないと思います

[FACE method="change_4" pos="2/3"]
[VOICE f="Sanae092"]
[OnName num="sanae"]
“My, inside ……! I want to escape!”
[cpg cn=true]

;//●ＣＧ非エロ（早苗の鎖骨あたりの箇所から触手が出て飛び出す。周囲の人間がなぎ払われて、画面端に手足などが映る程度。血とかは描かなくてもモーションブラー・衝撃波のような演出で迫力がでるかもしれません）ev_21
;//▼服あり。しかし男たちに追いかけられた後なので服は汚れあり。
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_21_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

The tentacles flew out from Sanae and reaped the surroundings.
[cpg]

[VOICE f="Sanae093"]
[OnName num="sanae"]
“Ahhhhhh!!!!”
[cpg cn=true]

[OnName num="man_A"]
“Help!!!!!!!!!”
[cpg cn=true]

[OnName num="man_B"]
“What the hell?”
[cpg cn=true]

[OnName num="man_C"]
“Aaaaahhhh, run away!!!! What’s going on ……?"
[cpg cn=true]

[OnName num="man_D"]
“Huh, huh!”
[cpg cn=true]

[VOICE f="Sanae094"]
[OnName num="sanae"]
“What the hell is this?”
[cpg cn=true]

[VOICE f="Sanae095"]
[OnName num="sanae"]
“I'm a monster woman ...... !!!!!! Aaaaagh!”
[cpg cn=true]

[OnName num="man_E"]
“Aaagh!”
[cpg cn=true]

[OnName num="man_F"]
“Help! Help! ……Mitsuhara, Sakata …… We’re sorry! Aaahh!”
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『裏路地』（昼）******************************************************

My huge body didn't make it into the alleyway.
[cpg]

I can no longer stay in this country with this body. I would have to get out, even if it meant swimming through the ocean.
[cpg]

[OnName num="masato"]
“Sa ...... na ...... e ……."
[cpg cn=true]

My hearing caught a sob coming from the back of the room.
[cpg]

;//(Y):早苗の立ち絵は出さないイメージです。前に出てきてくれない

[VOICE f="Sanae096"]
[OnName num="sanae"]
;//「藤田さんっ……私に、なにしたの……ッ」
“Masato ...... What did you do to me ……?”
[cpg cn=true]

[OnName num="masato"]
“……..”
[cpg cn=true]

[VOICE f="Sanae097"]
[OnName num="sanae"]
“I saw ...... that the town is a mess.”
[cpg cn=true]

[VOICE f="Sanae098"]
[OnName num="sanae"]
“Is it your fault ……?"
[cpg cn=true]

[OnName num="masato"]
“It's my fault.”
[cpg cn=true]

[VOICE f="Sanae099"]
[OnName num="sanae"]
“Ughhhh ….!”
[cpg cn=true]

[VOICE f="Sanae100"]
[OnName num="sanae"]
“What did you do to me? I'm not human anymore!”
[cpg cn=true]

[OnName num="masato"]
“I brought you back from the ...... brink of death.”
[cpg cn=true]

[VOICE f="Sanae101"]
[OnName num="sanae"]
“I was near you and they wanted me! Why did you do this to ...... me?”
[cpg cn=true]

[OnName num="masato"]
“I'm sorry.”
[cpg cn=true]

[VOICE f="Sanae102"]
[OnName num="sanae"]
“Sorry won't help you now, will it ……?”
[cpg cn=true]

[VOICE f="Sanae103"]
[OnName num="sanae"]
“Look! This thing coming out of my body is sucking nutrients from the soil!”
[cpg cn=true]

[VOICE f="Sanae104"]
[OnName num="sanae"]
“I can't have children with this body!”
[cpg cn=true]

[VOICE f="Sanae105"]
[OnName num="sanae"]
“I can't be with a man with this body!”
[cpg cn=true]

[VOICE f="Sanae106"]
[OnName num="sanae"]
“Nooooooo!!!”
[cpg cn=true]

I was at a loss for words. So I search for the right words.
[cpg]

It was all because of this great power — .
[cpg]

[VOICE f="Sanae107"]
[OnName num="sanae"]
“Ughhhh ...... ughhhh ……."
[cpg cn=true]

[VOICE f="Sanae108"]
[OnName num="sanae"]
;//「あなたも……藤田さんも、苦しいのよね」
“You and ...... Masato are both suffering, aren't you?”
[cpg cn=true]

[OnName num="masato"]
“….."
[cpg cn=true]

I can't even swallow my spit. Even mouthing the words was difficult with a body that was just unnecessarily huge.
[cpg]

I'm not qualified to say anything.
[cpg]

But.
[cpg]

[OnName num="masato"]
“I liked you ...... Sanae.”
[cpg cn=true]

[VOICE f="Sanae109"]
[OnName num="sanae"]
“……"
[cpg cn=true]

Why did it take so long to say that?
[cpg]

[VOICE f="Sanae110"]
[OnName num="sanae"]
“I liked ...... you too ……"
[cpg cn=true]

[OnName num="masato"]
“I just wanted you to be alive.”
[cpg cn=true]

[OnName num="masato"]
“I just wanted to save you.”
[cpg cn=true]

[OnName num="masato"]
“But here we are.”
[cpg cn=true]

[VOICE f="Sanae111"]
[OnName num="sanae"]
“You killed so many people, and now I'm alive? Without anyone catching me.”
[cpg cn=true]

[OnName num="masato"]
“Yes. I'd like to think so.”
[cpg cn=true]

[OnName num="masato"]
“Maybe you shouldn't have met me.”
[cpg cn=true]

[VOICE f="Sanae112"]
[OnName num="sanae"]
“I ……”
[cpg cn=true]

[VOICE f="Sanae113"]
[OnName num="sanae"]
“I don't want to think that ……"
[cpg cn=true]

[VOICE f="Sanae114"]
[OnName num="sanae"]
“Oh no ...... Why am I in so much pain? Help me ..... Hazuki ……!”
[cpg cn=true]

[OnName num="masato"]
“….."
[cpg cn=true]

A normal life. I can never have a normal life. I'm a mass murderer, so it’s something I should no longer be seeking.
[cpg]

[VOICE f="Sanae115"]
[OnName num="sanae"]
“Will you erase my memory ……? You did it already, that dream, that image.”
[cpg cn=true]

[VOICE f="Sanae116"]
[OnName num="sanae"]
“I only want to erase your memory.”
[cpg cn=true]

[OnName num="masato"]
“...... Okay.”
[cpg cn=true]

[VOICE f="Sanae117"]
[OnName num="sanae"]
“The three of us had a good life together. ……"
[cpg cn=true]

;//(Y):早苗の立ち絵はここで出てくる

[FG f="CHA01_p3_02_a.ui" method="change_4"  pos="2/3" time=800]

Sanae emerged from the thin darkness of the alleyway.
[cpg]

The sirens of the fire department and police - and helicopters - are flying overhead.
[cpg]

[OnName num="masato"]
“I still want to protect you, okay?”
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Sanae118"]
[OnName num="sanae"]
“...... Yes.”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sanae119"]
[OnName num="sanae"]
“Thank you. I'm sorry.”
[cpg cn=true]

I touched Sanae's forehead. It was wide, cute, with beautiful skin.
[cpg]

;//(Y):再度

;//●ＣＧ非エロ（R18版と同じ）ev_14
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

How is it? My memories.
[cpg]

Isn't she cute? It's Hazuki.
[cpg]

Shaved ice cream, the cat cafe, the swinging electric wire, the sunset, I wish I could've spent more time with you.
[cpg]

Thank you. Thank you.
[cpg]

I am in love with the beautiful morning.
[cpg]

;//(Y):長めのウェイト。エピローグ入り

;//ＢＫ
;//(Y):視点主が早苗なので立ち絵はなし
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=2000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1000]
[WAIT time=3000]
[BG f="b_10_2.ui" time=100]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（昼）******************************************************

;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sanae120"]
[OnName num="sanae"]
“Ah — the cherry blossoms, they're falling.”
[cpg cn=true]

It’s graduation day.
[cpg]

I chose a long-sleeved kimono for my graduation day. I dressed up beautifully, but my heart was not fine.
[cpg]

The reason is obvious - I lost someone. Someone I can't remember but someone very important to me.
[cpg]

I know that there is such a thing as a forgotten memory. The reason is simple: the memories don't add up.
[cpg]

There was someone who was blank as if a photo had been cropped, yet I cherished that person.
[cpg]

[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Haduki105"]
[OnName num="haduki"]
“Sis, what do you think of the picture? Here.”
[cpg cn=true]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sanae121"]
[OnName num="sanae"]
“Yes, it's beautiful. I'm so happy with the picture. I'll take it one for you when you graduate too.”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki106"]
[OnName num="haduki"]
“……"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki107"]
[OnName num="haduki"]
“Sis, are you okay?”
[cpg cn=true]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sanae122"]
[OnName num="sanae"]
“I'm fine.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki108"]
[OnName num="haduki"]
“You have a special kind of amnesia.”
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Haduki109"]
[OnName num="haduki"]
“The doctors are bad people. Don't go see them okay? Please ……."
[cpg cn=true]

Hazuki looks pained when she cares for me.
[cpg]

[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（昼）******************************************************

I heard that after graduation, many people come to visit this place where beautiful flowers bloom, which is rare after a disaster.
[cpg]

When I look around, I can see my classmates laughing here and there. The monument of reconstruction was standing in the back.
[cpg]

[FG f="CHA02_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Haduki110"]
[OnName num="haduki"]
“…….”
[cpg cn=true]

;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sanae123"]
[OnName num="sanae"]
“Hazuki?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki111"]
[OnName num="haduki"]
“I'm sorry. ...... Sorry.”
[cpg cn=true]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sanae124"]
[OnName num="sanae"]
“Why are you crying? What's wrong with that monument?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki112"]
[OnName num="haduki"]
“Sis.”
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Haduki113"]
[OnName num="haduki"]
“In the end. Even if you're embarrassed, even if you're treated like a cocky character.”
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Haduki114"]
[OnName num="haduki"]
“You have to say what you want to say. Thank you, or ...... that the soup is delicious ……"
[cpg cn=true]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sanae125"]
[OnName num="sanae"]
“Is this about dad?”
[cpg cn=true]

;//(Y):葉月が雅人に言った最後の言葉は「死ね、怪物」です

[FACE method="shake_4" pos="2/3"]
[VOICE f="Haduki115"]
[OnName num="haduki"]
“I'm talking about the fact that I shouldn't be happy anymore.”
[cpg cn=true]

Hazuki just wiped her tears and looked into the distance. She shows this side of her.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki116"]
[OnName num="haduki"]
“Sis, when you took this picture, the sash of your kimono was loose.”
[cpg cn=true]

What? ....... Why didn't she tell me?
[cpg]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sanae126"]
[OnName num="sanae"]
“Should we retake that photo ……?"
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Haduki117"]
[OnName num="haduki"]
“It's all right. You look pretty either way.”
[cpg cn=true]

I looked at the sash. At that moment, I saw a shadow wiggle behind me.
[cpg]

— What is that? I looked and saw that the sash had been fixed perfectly.
[cpg]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sanae127"]
[OnName num="sanae"]
“Hazuki, did you fix it?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki118"]
[OnName num="haduki"]
“......?”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki119"]
[OnName num="haduki"]
“No, I didn't. Someone more skilled might have done it ……"
[cpg cn=true]

— I look back at my kimono again.
[cpg]

I felt protected by someone - someone who wasn't here.
[cpg]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sanae128"]
[OnName num="sanae"]
“Thank you.”
[cpg cn=true]

[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]

If only the spring breeze would carry my gratitude to that someone.
[cpg]


;//end1
;//ＥＮＤ１

[SCENE id=10]

[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

