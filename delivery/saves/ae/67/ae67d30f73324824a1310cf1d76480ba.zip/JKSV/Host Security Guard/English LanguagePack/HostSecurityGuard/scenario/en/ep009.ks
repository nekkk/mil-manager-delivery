
*start|I Hate Myself

;#################################################
*Ep009|I Hate Myself
;#################################################

[SCENE id=9]

;//(Y):視点変更トランジション
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（崩壊）******************************************************

I wake up. The dry winter wind is blowing.
[cpg]

The town is covered in rubble. Like Rogela, there was death all around me. Something I was able to evade.
[cpg]

[OnName num="masato"]
“……”
[cpg cn=true]

My body felt the same as before. I felt light and heavy at the same time.
[cpg]

[OnName num="masato"]
“Did nothing change?”
[cpg cn=true]

I looked at my palms. When I moved it, the fingertip snapped open and a disgusting, poisonous jellyfish-like tentacle sprang out.
[cpg]

— It was the same as the one used by ‘one wing’.
[cpg]

[OnName num="masato"]
“I have changed ……”
[cpg cn=true]

[OnName num="masato"]
“I quit being a human being.”
[cpg cn=true]

[OnName num="masato"]
“I don't have time to think about whether it was good or bad.”
[cpg cn=true]

[OnName num="masato"]
“Someone, make time stop …….”
[cpg cn=true]

I started walking around town. My car was wrecked and I needed a new one. I can't afford to be distracted at this point.
[cpg]

[OnName num="masato"]
“I've got a microchip on the back of my neck. It's tied to my account.”
[cpg cn=true]

[OnName num="masato"]
“I can rent a car ……"
[cpg cn=true]

As I drove down the road, I saw the body of ‘one wing’ being carried by four men and put into some kind of black car.
[cpg]

It had a green license plate. It had the number 8 on it, which is allowed to carry a dead body.
[cpg]

The four men carrying the body looked at me and froze.
[cpg]

[OnName num="masato"]
“(They are people from work. That makes sense. They cannot show the dead body to anyone.)”
[cpg]

They pretended not to see me. Do they know I've got tentacles in me?
[cpg]

After seeing what the one wing can do, I can understand their fear - they don't want to fight.
[cpg]

[OnName num="masato"]
“That works out for me too. I don't have time for a fight either— You're in luck.”
[cpg cn=true]

I decided to get the hell out of here.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（夕方）******************************************************

I return home in the rental car and change out of my tattered, conspicuous clothes.
[cpg]

I call Hazuki and Sanae on my cell phone, but they don't reply.
[cpg]

As long as they are involved, Hazuki's location must be - my workplace. That's where they take most of the action.
[cpg]

[OnName num="masato"]
“It's going to end up in another fight.”
[cpg cn=true]

Just in case, I loaded up several spares of clothes. It was part of the preparation.
[cpg]

[OnName num="masato"]
“If I don't have spares for clothes when I show up, I can't blend in with the public.”
[cpg cn=true]

[OnName num="masato"]
“I've had a drink, I've had a sandwich. I'm ready. If I don't have enough, I go to a drive-through.”
[cpg cn=true]

[OnName num="masato"]
“As long as I can look the part, I should be able to survive as a monster— as long as I am holding a crumpled hamburger paper bag.”
[cpg cn=true]

I got back in my car again and headed out.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所外部』（夕方）******************************************************

At my workplace, I didn't see anyone.
[cpg]

The sun was setting early. The temperature is low. It was winter. I don't know what the unusual heat was the other day.
[cpg]

[OnName num="masato"]
“I think Hazuki might be here, but am I wrong? If only Sanae would be here ……."
[cpg cn=true]

[OnName num="masato"]
“What is this? Is it because it's winter that it's so cold?”
[cpg cn=true]

I get out of the car.
[cpg]

[OnName num="masato"]
“It's too conspicuous if I am around here. No, I work here, why should I be inconspicuous?”
[cpg cn=true]

[OnName num="masato"]
“Damn ...... hmm? There's something scattered on the ground ……"
[cpg cn=true]

There were cartridges and bullets scattered about.
[cpg]

[OnName num="masato"]
“What?”
[cpg cn=true]

[OnName num="masato"]
“What happened here …… The only thing that could have happened is a gunshot.”
[cpg cn=true]

[OnName num="masato"]
“The question to ask is; What were they shooting at?”
[cpg cn=true]

Although I came here with the assumption that Hazuki and Sanae might be here - suddenly I didn’t want that to be the case.
[cpg]

But this bullet. It was not a coincidence.
[cpg]

;//[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki103"]
[OnName num="misaki"]
“Ahhhhhhhh!”
[cpg cn=true]

— I’ve heard that cry before!
[cpg]

I looked up and saw the second east wing in front of me. It was the building where I worked.
[cpg]

Now that one wing had attacked and Hazuki had disappeared, Misaki was an enemy. So I'm not interested. I am no saint.
[cpg]

But - something is going on in the back.
[cpg]

[OnName num="masato"]
“Damn! I have a card key ...... Damn it! It's like I'm a corporate animal!”
[cpg cn=true]

[OnName num="masato"]
“I don't want to have anything to do with this shitty company!”
[cpg cn=true]

I put the card key into the card key reader at the front entrance.
[cpg]

It didn't open. I looked closer and saw that the reader had stopped functioning.
[cpg]

[OnName num="masato"]
“……."
[cpg cn=true]

[OnName num="masato"]
“Shall we go home?”
[cpg cn=true]

[OnName num="masato"]
“In any case, Hazuki and Sanae could be in that disgusting central building ……"
[cpg cn=true]

[window target=false]
[free time=500]
[BG f="b_03_3.ui" time=500]
[WAIT time=500]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（夕方）******************************************************

Suddenly my vision 'went up'. In front of me was the office on the third floor. — What the hell is going on here?
[cpg]

— That tentacle is growing out of my back, supporting me and lifting me up…
[cpg]

[OnName num="masato"]
“This thing has a mind of its own!”
[cpg cn=true]

[OnName num="masato"]
“Ughhhhhhhh!”
[cpg cn=true]

I was swung around and plunged through the windowpane as if I were being thrown in.
[cpg]

[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社』（夕方）******************************************************

The tentacles helped me support my body. On the desk, a cute little beastman character figure, I wonder who it belonged to, was swaying.
[cpg]

It had blue and fluffy fur, but the plastic didn’t suit the figure ......
[cpg]

[OnName num="masato"]
“(Damn. I don’t like this tentacle treating me like this ..…)”
[cpg cn=true]

[OnName num="masato"]
"(Do I have to learn how to control it?)"
[cpg cn=true]

[OnName num="masato"]
“(No, it's more like ...... I have to explore.)”
[cpg cn=true]

I looked around. It was the general affairs department. It looked like the office of any other company.
[cpg]

[OnName num="masato"]
“But what's the point of having a security guard's personal information document labeled as ‘To Central Administration’ if it's in the general affairs department?”
[cpg cn=true]

[OnName num="masato"]
“Maybe it's a department that shouldn't be split up …… I don’t know.”
[cpg cn=true]

[OnName num="masato"]
“It all seems so sketchy.”
[cpg cn=true]

I run through the room and out into the corridor.
[cpg]

I ignore the warning signs that say ‘don't run’ because the floor is slippery.
[cpg]

[OnName num="masato"]
“Why the hell are you wasting time for such a stupid sign? The central research lab is all dangerous anyway!”
[cpg cn=true]

Someone screamed. This time it was a man.
[cpg]

It came from downstairs. I head down.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社』（夕方）******************************************************

Upstairs. Several people were lying on the floor. There was a familiar face.
[cpg]

[OnName num="masato"]
“Murayama! Sakita! Lida Eschenbach! Even, Imai ……"
[cpg cn=true]

[OnName num="masato"]
“Hm? Imai ……"
[cpg cn=true]

Imai - a senior security guard who had worked here two years longer than me. He stood up unsteadily.
[cpg]

[OnName num="imai"]
“……."
[cpg cn=true]

He said he had a hard time for a while as a result of grazing the cafe terrace while driving his car.
[cpg]

[FADEOUTBGM]

He was also complaining to me all the time - the vexed look on his face when he was talking about it was gone now.
[cpg]

Tentacles were coming out of his mouth.
[cpg]

[BGM f="bg_h1"]
[WAIT time=100]

[OnName num="masato"]
“What?”
[cpg cn=true]

[OnName num="imai"]
“Rrrrrrrghhhhh!”
[cpg cn=true]

It attacked me.
[cpg]

[OnName num="masato"]
“Ahh! What the hell are you doing? Stop it!”
[cpg cn=true]

[OnName num="imai"]
“Arghhhhhhh!”
[cpg cn=true]

I try to run up the stairs. A tentacle bites me from behind. My legs are bound and I can't move.
[cpg]

The familiar faces around me stood up one after another.
[cpg]

[OnName num="masato"]
“Damn! At least at a time like this, my tentacles should ……!"
[cpg cn=true]

[OnName num="masato"]
“Move!”
[cpg cn=true]

Tentacles extended from the fingertips of both my hands.
[cpg]

I rip all of the tentacles that were coming for me.
[cpg]

[OnName num="imai_and_the_others"]
“Gahhhhhhh!”
[cpg cn=true]

Imai and the others fall unsteadily. They stop moving.
[cpg]

[OnName num="masato"]
“What the hell is going on with these guys ……!"
[cpg cn=true]

[OnName num="masato"]
“Do they have a parasite like me?”
[cpg cn=true]

[OnName num="masato"]
“No, but they seem to have had their consciousness completely hijacked. They are not like me.”
[cpg cn=true]

[OnName num="masato"]
“They are like a zombie.”
[cpg cn=true]

Whatever it is, I can fight it. I guess I'll just have to keep going.
[cpg]

[OnName num="masato"]
“I'm here to fight ……!"
[cpg cn=true]

[OnName num="masato"]
“Hazuki. Sanae. Where are you guys …..”
[cpg cn=true]

I continued my search.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社』（夕方）******************************************************

On the way, a surprise attack came from behind me. I turned around and saw it was my colleague, Asai. He got married just the other day.
[cpg]

[OnName num="asai"]
“Gaaaahhhhhhhhh ……!”
[cpg cn=true]

[OnName num="masato"]
“Damn ……!"
[cpg cn=true]

Before I could even defend myself, a tentacle attached itself to the tentacle coming from Asai's chest and got entangled.
[cpg]

[OnName num="asai"]
“Gahhhhhh!”
[cpg cn=true]

[OnName num="asai"]
“Aaaaah!”
[cpg cn=true]

My tentacles pulled out the tentacles from Asai's chest.
[cpg]

[OnName num="asai"]
“Gahhhhhhh!!!”
[cpg cn=true]

[OnName num="masato"]
“Ugh, ahhh ...... death ……!”
[cpg cn=true]

Asai twitches as he bleeds from his body. If this continues, he may die.
[cpg]

[OnName num="masato"]
“Damn! This guy ……”
[cpg cn=true]

My tentacles moved with a jerk as I tried to control them.
[cpg]

;//セピア色

;//●ＣＧ非エロ（前と同じです）ev_08
[window target=false]
[free time=1000]
[BG f="b_ev_08.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[OnName num="mitsuhara"]
“I'm sure it's a new plant species. As you can see, this new vegetative organism has been proven to enhance the physical capabilities of the human body.”
[cpg cn=true]

[OnName num="mitsuhara"]
“There will be no physical rejection.”
[cpg cn=true]

[OnName num="mitsuhara"]
“Inside the human body, it produces microfibers that can replace muscles and blood vessels.”
[cpg cn=true]

[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社』（夕方）******************************************************

[OnName num="masato"]
“I will control you.”
[cpg cn=true]

[OnName num="masato"]
“You rampaging horse.”
[cpg cn=true]

My tentacles trembled in resistance.
[cpg]

This is the tentacle I took from "one wing". It's a unique one that specializes in killing.
[cpg]

It is not poisoned at the moment, perhaps because it is not familiar to me. But I have a feeling it will eventually have that ability ......
[cpg]

[OnName num="masato"]
“It's not about killing, but about helping people! Otherwise, it’s not cool to have powers!”
[cpg cn=true]

My tentacles trembled. Then they went quiet.
[cpg]

As a result of the tentacles being pulled out, there was a hole in Asai's chest, which was dripping with blood.
[cpg]

[OnName num="masato"]
“...... Wow!”
[cpg cn=true]

[OnName num="masato"]
“I can feel it, it’s as if the tentacles held on to a microscopic world ...... Ughhh. I want this to stop ......."
[cpg cn=true]

Apparently, my tentacles can heal the human body. Although, I’m not sure how to do it.
[cpg]

I gave Asai a procedure that I was not accustomed to.
[cpg]

[OnName num="masato"]
“Damn it, don't die you guys.”
[cpg cn=true]

I went down the stairs. It led to the first floor.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社』（夕方）******************************************************

The first floor. There was no sign of the tentacle zombies being present.
[cpg]

Misaki was lying on the floor. She seemed to be conscious.
[cpg]

[OnName num="masato"]
“Misaki!”
[cpg cn=true]

;//[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki104"]
[OnName num="misaki"]
“Help me! Ahhhhh!”
[cpg cn=true]

As I tried to approach her, tentacles appeared from all directions, breaking down the doors of the rooms around us.
[cpg]

The tentacles tied up Misaki.
[cpg]

;//●ＣＧ非エロ（美咲。服が破けているが全年齢範囲。触手に拘束され這い回られている）ev_34
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[VOICE f="Misaki105"]
[OnName num="misaki"]
“Noooooooo! It hurts! Forgive me!”
[cpg cn=true]

[OnName num="masato"]
“Damn ……!"
[cpg cn=true]

I tried to get closer. I tried to strike it with my tentacles, but they were stronger than mine.
[cpg]

[OnName num="masato"]
“This tentacle is ...... hard!”
[cpg cn=true]

[VOICE f="Misaki106"]
[OnName num="misaki"]
“Owwwwwww!”
[cpg cn=true]

[OnName num="masato"]
“I have no choice but to ask now! Where is Hazuki? Where’s Sanae?”
[cpg cn=true]

[VOICE f="Misaki107"]
[OnName num="misaki"]
“Ahhhhhhh!!!!!! Will you help me if I answer?”
[cpg cn=true]

[OnName num="masato"]
“It depends on what you did to them!”
[cpg cn=true]

[VOICE f="Misaki108"]
[OnName num="misaki"]
“I don't know about Sanae!”
[cpg cn=true]

[VOICE f="Misaki109"]
[OnName num="misaki"]
“Hazuki is ……! Ahhhhhh! She keeps moving …… Ahhhhhh!!!”
[cpg cn=true]

[OnName num="masato"]
“She keeps moving?”
[cpg cn=true]

The tentacles extending out from the area were coming at me. It has power.
[cpg]

I flicked it, dodged it, and kept on attacking it. The tip is hard. It was probably because it was better that way to attack its prey.
[cpg]

[VOICE f="Misaki110"]
[OnName num="misaki"]
“Help me!”
[cpg cn=true]

[OnName num="masato"]
“Why is this happening?”
[cpg cn=true]

[VOICE f="Misaki111"]
[OnName num="misaki"]
“I made Hazuki gain the tentacles!”
[cpg cn=true]

[VOICE f="Misaki112"]
[OnName num="misaki"]
“She's so fit. This area is being controlled by her!”
[cpg cn=true]

[OnName num="masato"]
“So you got what you deserved! You idiots!”
[cpg cn=true]

[OnName num="masato"]
“You have to bring Hazuki back!”
[cpg cn=true]

[OnName num="masato"]
“After all, I don't have time for you!”
[cpg cn=true]

[VOICE f="Misaki113"]
[OnName num="misaki"]
“Noooooooo!!!!”
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社』（夕方）******************************************************

I discovered a weakness in the tentacles. The tips of the tentacles are strong, but the root was weak.
[cpg]

The root was Hazuki. Why does she 'keep moving' ......?
[cpg]

[OnName num="masato"]
“Damn!”
[cpg cn=true]

I cut through the tentacles coming toward me.
[cpg]

I was dealing with them one by one, and unintentionally Misaki got released as well ...... Damn. I didn't mean to help her, but oh well.
[cpg]

[FG f="CHA03_p4_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Misaki114"]
[OnName num="misaki"]
“Aaaaaaah!”
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Misaki115"]
[OnName num="misaki"]
“Oh, thank you so much! I won't do this again!”
[cpg cn=true]

[OnName num="masato"]
“Get the hell out of here! Don't ever show your face again!”
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Misaki116"]
[OnName num="misaki"]
“Yes, sir!”
[cpg cn=true]

Misaki ran upstairs.
[cpg]

Damn, she's just a little thing after escaping from the monster.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社』（夕方）******************************************************

I continue the search. The area is blocked by tentacles, but I can handle it.
[cpg]

[OnName num="masato"]
“There's a section that even the security map didn't reveal information about.”
[cpg cn=true]

[OnName num="masato"]
“I need a key card, but ...... the building is so distorted that the walls and doors are full of holes. I’ll just force my way inside.”
[cpg cn=true]

I pried open the doors and examined them one by one.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[OnName num="masato"]
“Is this ...... a dark room? There's no electricity to begin with.”
[cpg cn=true]

[OnName num="masato"]
“It looks like something they used to develop photographs a long time ago ……."
[cpg cn=true]

;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sanae152"]
[OnName num="sanae"]
“What?”
[cpg cn=true]

[OnName num="masato"]
“!?”
[cpg cn=true]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『会社』（夕方）******************************************************

Sanae was there. When she came out of the room, I could see her face more clearly. She looked like she had been crying.
[cpg]

[OnName num="masato"]
“Sanae! I knew you were here!”
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sanae153"]
[OnName num="sanae"]
;//「藤田さん！　葉月が！　葉月が！」
“Masato! Hazuki is ……! Hazuki ……”
[cpg cn=true]

[OnName num="masato"]
“I heard about it. She was taken away, wasn't she?”
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Sanae154"]
[OnName num="sanae"]
“That's right!”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sanae155"]
[OnName num="sanae"]
“A lot of these tentacles came out of her.”
[cpg cn=true]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Sanae156"]
[OnName num="sanae"]
“This whole area was eroded!”
[cpg cn=true]

— Sanae was panicking.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sanae157"]
[OnName num="sanae"]
“Huhhhhhh. What should we do ……"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sanae158"]
[OnName num="sanae"]
;//「藤田さん、私、一人だけじゃついていけなくて！」
“Masato, I can't keep up with this!”
[cpg cn=true]

[OnName num="masato"]
“Can't keep up?”
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Sanae159"]
[OnName num="sanae"]
“I can't carry the burden all by myself. I don't know what’s going on ……”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sanae160"]
[OnName num="sanae"]
“Did this happen because I made a mistake somewhere? Or did Hazuki? Why is this happening ……!"
[cpg cn=true]

She was in pain. She looked like a wounded little animal.
[cpg]

[OnName num="masato"]
“Calm down. I'm here. Tell me what you know, in detail.”
[cpg cn=true]

[OnName num="masato"]
“What is this room you came out of? You need a key card, but you came out from the inside.”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sanae161"]
[OnName num="sanae"]
“That room is disguised as a dark room.”
[cpg cn=true]

A black-light flashlight rolled out from behind the door.
[cpg]

When coated with a special paint, it glows under a certain kind of light.
[cpg]

[OnName num="masato"]
“I remember when I was in the blacklight darkroom ...... Weren’t they developing weird products here as well?”
[cpg cn=true]

[OnName num="masato"]
“But that's just camouflage. I'm sure the people at the company didn’t care about this.”
[cpg cn=true]

[OnName num="masato"]
“I'm sure they're just trying to hide something in the dark.”
[cpg cn=true]

[OnName num="masato"]
“What's really in here?”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sanae162"]
[OnName num="sanae"]
“It leads to the basement. From there, there's a secret passageway that leads to the secret central building.”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sanae163"]
[OnName num="sanae"]
“I escaped through there ...... I'm sorry I'm such a coward.”
[cpg cn=true]

[OnName num="masato"]
“No, you’re not. You are giving me useful information.”
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Sanae164"]
[OnName num="sanae"]
“Huh …….”
[cpg cn=true]

[OnName num="masato"]
“I know it must have been scary.”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sanae165"]
[OnName num="sanae"]
“....... I was listening through the door, and I knew the place was covered in tentacles. I couldn’t stop shaking while I was waiting.”
[cpg cn=true]

[OnName num="masato"]
“You made the right call.”
[cpg cn=true]

The place was indeed covered with tentacles. A dark room was the perfect place to hide.
[cpg]

[OnName num="masato"]
“I'm going to go to Hazuki.”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Sanae166"]
[OnName num="sanae"]
“It's supposed to be dangerous ……"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sanae167"]
[OnName num="sanae"]
“..... Don't tell me you have the means to fight the tentacles …….”
[cpg cn=true]

Sanae looked around.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Sanae168"]
[OnName num="sanae"]
;//「どうやってここまであの触手を乗り越えてきたの？　藤田さん」
“How did you get past those other tentacles?”
[cpg cn=true]

Sanae, who had been panicking, now asked calmly. Did she think that someone else fought them off?
[cpg]

[OnName num="masato"]
“I also have tentacles inside my body.”
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Sanae169"]
[OnName num="sanae"]
“!!!”
[cpg cn=true]

[OnName num="masato"]
“I've got it under control for now. I think I can use it when I face Hazuki.”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sanae170"]
[OnName num="sanae"]
“Take me there too ……."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Sanae171"]
[OnName num="sanae"]
“You can't fight. You may just be extra baggage. You might get in the way.”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sanae172"]
[OnName num="sanae"]
“But I have to see her ...... even if I risk my life. I feel like I have to talk to her.”
[cpg cn=true]

[free time=800]
[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki117"]
[OnName num="misaki"]
“Nothing is more important than your life.”
[cpg cn=true]

[OnName num="masato"]
“!? Why did you come back?”
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Misaki118"]
[OnName num="misaki"]
“Here. Please take it with you.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki119"]
[OnName num="misaki"]
“All Level 2 staff in the central building carry these gas grenades. They're not that lethal.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki120"]
[OnName num="misaki"]
“We don't want any trouble either.”
[cpg cn=true]

Misaki handed me a gas grenade, but only one.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Misaki121"]
[OnName num="misaki"]
“It works on those tentacles, but the 'poison type' comes from the same organism, so it will work on you too.”
[cpg cn=true]

[OnName num="masato"]
“Uh! Can I use this?”
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Misaki122"]
[OnName num="misaki"]
“I couldn't prepare a gas mask or anything like that. Please hold your breath when you use it.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki123"]
[OnName num="misaki"]
“I guess that Rogela guy wasn't after the creatures.”
[cpg cn=true]

The shadow of a helicopter covered the window pane. Was there already a commotion?
[cpg]

Somewhere in the distance, a building collapsed. I could see thick tentacles flapping on the ground, attacking the town.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Misaki124"]
[OnName num="misaki"]
“Was the purpose of this economic terrorism ……?”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki125"]
[OnName num="misaki"]
“He deliberately caught that Hazuki in his net …… what a masterful way of thinking.”
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Misaki126"]
[OnName num="misaki"]
“Even the death was staged.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki127"]
[OnName num="misaki"]
“In the end, the goal was to send Hazuki over here to cause this catastrophe.”
[cpg cn=true]

[OnName num="masato"]
“Evil is always stupid when you get right down to it. I can’t believe we fell into his act.”
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Misaki128"]
[OnName num="misaki"]
“You’re right.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki129"]
[OnName num="misaki"]
“Any sane person knows that if you rob the world, the world will retaliate.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki130"]
[OnName num="misaki"]
“Most of the world is good. The top management is stupid to make enemies of them.”
[cpg cn=true]

Misaki stumbled off. I would not see her again.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

We walked through the dark underground passageway.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sanae173"]
[OnName num="sanae"]
“The lights aren't on ……”
[cpg cn=true]

[OnName num="masato"]
“Sanae. I'll leave the gas grenade to you. Use it well.”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sanae174"]
[OnName num="sanae"]
“Yes ….. Yes!”
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_12_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『生物研究所内部』******************************************************

“We came to the lab.”
[cpg]

This is where the story began, and now it's about to end.
[cpg]


[VOICE f="Haduki200"]
[OnName num="haduki"]
“Ha-ha-ha-ha! You came! Sis!”
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sanae175"]
[OnName num="sanae"]
“! Hazuki!”
[cpg cn=true]

A voice echoed from somewhere. The tentacles came towards us to attack. I repel them with my tentacles.
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="Sanae176"]
[OnName num="sanae"]
“Wow, you have tentacles too!”
[cpg cn=true]

[VOICE f="Haduki201"]
[OnName num="haduki"]
“Masato ……”
[cpg cn=true]

[OnName num="masato"]
“Yes, I do.”
[cpg cn=true]

[OnName num="masato"]
“Hazuki, show yourself.”
[cpg cn=true]

[VOICE f="Haduki202"]
[OnName num="haduki"]
“You don't have to shout ...... I don’t want to fight.”
[cpg cn=true]

;//●ＣＧ非エロ（服を着ている。触手が彼女の背中側からいくつか地下へ繋がっている）ev_30
;//▼差分は_0が嘲笑するように笑う（元R18版と同じ表情、手つき）_bが悲しそうな顔、手も下ろしたもの
;//_0　嘲笑するような笑い
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[VOICE f="Haduki203"]
[OnName num="haduki"]
“Haha. What are you so nervous about?”
[cpg cn=true]

She emerged from the cracked ground. The tentacles extend from her. They must be connected to the basement.
[cpg]

[OnName num="masato"]
“Hazuki ……!"
[cpg cn=true]

[VOICE f="Haduki204"]
[OnName num="haduki"]
“It's not my fault, is it?”
[cpg cn=true]

[VOICE f="Haduki205"]
[OnName num="haduki"]
“The professor tricked us into this.”
[cpg cn=true]

[VOICE f="Haduki206"]
[OnName num="haduki"]
I know they say that I'm compatible, but I can't control it. It's just that this body is perfect for tentacles to nest.
[cpg cn=true]

;//_b
;//;**【ＣＧ】 ev_30_a ***********************
;//[CG id=19 index=1 time=1]
;//;***************************************
;//[WAIT time=1]

[VOICE f="Haduki207"]
[OnName num="haduki"]
“...... Help me please.”
[cpg cn=true]

[VOICE f="Haduki208"]
[OnName num="haduki"]
“They turned me into a monster.”
[cpg cn=true]

[OnName num="masato"]
“〜〜〜〜〜!”
[cpg cn=true]

[VOICE f="Sanae177"]
[OnName num="sanae"]
“Hazuki ……!"
[cpg cn=true]

[VOICE f="Haduki209"]
[OnName num="haduki"]
“Sis. What's with the gas grenade?”
[cpg cn=true]

[VOICE f="Sanae178"]
[OnName num="sanae"]
“What?”
[cpg cn=true]

There was an awkward silence.
[cpg]

Hadn't we all been working together to turn Hazuki into a monster?
[cpg]

Professor Rogera spotted her suitability, and the damn workplace took advantage of her.
[cpg]

And now we have these gas grenades because we took their information to heart.
[cpg]

Isn't that sinful—?
[cpg]

[VOICE f="Haduki210"]
[OnName num="haduki"]
“I guess I’m not ….. family anymore.”
[cpg cn=true]

[VOICE f="Haduki211"]
[OnName num="haduki"]
“I can't go back to the way things were ……”
[cpg cn=true]

[VOICE f="Haduki212"]
[OnName num="haduki"]
“No one will help me. They'll just mess me up, and then leave me.”
[cpg cn=true]

[VOICE f="Haduki213"]
[OnName num="haduki"]
“They just think I am their little mascot.”
[cpg cn=true]

[VOICE f="Haduki214"]
[OnName num="haduki"]
“I hate everyone ……!”
[cpg cn=true]

[window target=false]
[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/5" time=1000]
[FG f="CHA02_p2_02_a.ui" method="change_3"  pos="4/5" time=1000]
[BG f="b_12_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所内部』******************************************************

Her tentacles are slithering and attacking something far away.
[cpg]

[FACE method="shake_5" pos="2/5"]
[VOICE f="Sanae179"]
[OnName num="sanae"]
“Hazuki …… You’re not a monster ……!"
[cpg cn=true]

[FACE method="shock_3" pos="4/5"]
[VOICE f="Haduki215"]
[OnName num="haduki"]
“Get out of here!”
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[VOICE f="Haduki216"]
[OnName num="haduki"]
“I don't need cheap words of comfort!”
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

[FACE method="change_4" pos="4/5"]
[VOICE f="Haduki217"]
[OnName num="haduki"]
“You all just use me for your benefit!”
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[VOICE f="Haduki218"]
[OnName num="haduki"]
“Why do I have to go through this when I just wanted to gift my mother a cruising trip?”
[cpg cn=true]

[FACE method="shake_3" pos="4/5"]
[VOICE f="Haduki219"]
[OnName num="haduki"]
“No one sees me as a human being. Even without these tentacles, it’s been that way from the beginning!”
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[VOICE f="Haduki220"]
[OnName num="haduki"]
“I’m the one who gets lectured by older men and women so that they can mold me into the 'right person’!”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki221"]
[OnName num="haduki"]
“Everyone's normal life is made up of people who are not normal, isn't it?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki222"]
[OnName num="haduki"]
“Where am I supposed to go?”
[cpg cn=true]

[OnName num="masato"]
“You can't even accept me into your ‘normal’ group.”
[cpg cn=true]

[OnName num="masato"]
“Don't be a pussy for wanting to be accepted as ‘normal’.”
[cpg cn=true]

[FACE method="shock_5" pos="4/5"]
[VOICE f="Haduki223"]
[OnName num="haduki"]
“Hey!”
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[VOICE f="Sanae180"]
[OnName num="sanae"]
;//「ちょっ、藤田さん！？」
“Masato!”
[cpg cn=true]

[OnName num="masato"]
“I'm gonna give you a lecture!”
[cpg cn=true]

[OnName num="masato"]
“You're a monster right now! There are times when you have to get it together and apologize.”
[cpg cn=true]

[OnName num="masato"]
“I guess it’s a disgusting attitude for someone like you.”
[cpg cn=true]

[OnName num="masato"]
“You don't even consider the people you've hurt in the process of asserting yourself as human!”
[cpg cn=true]

[OnName num="masato"]
“You can claim to be one, but it's your fault for not kicking Rogela's ass!”
[cpg cn=true]

[FACE method="shock_4" pos="2/5"]
[VOICE f="Haduki224"]
[OnName num="haduki"]
“〜〜〜〜〜!”
[cpg cn=true]

[OnName num="masato"]
“You were suspicious of him! He gave you eighty-five thousand yen out of the blue!”
[cpg cn=true]

[OnName num="masato"]
“Don't just blame others when you made the mistake of following the wrong guy!”
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[VOICE f="Haduki225"]
[OnName num="haduki"]
“Ahhhhhhhhh!”
[cpg cn=true]

[OnName num="masato"]
“I'm leaving.”
[cpg cn=true]

[OnName num="masato"]
“Can't control your tentacles? Try controlling them. Even if you have to suffer.”
[cpg cn=true]

[OnName num="masato"]
“I did it ……"
[cpg cn=true]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

This was going to be Hazuki's problem.
[cpg]

I'm out of the picture.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（崩壊）******************************************************

My job was gone. I was staring into the void with nothing to do.
[cpg]

Well, whatever. I could probably get a job if I wandered around.
[cpg]

Fortunately, the town is falling apart. It will need people to rebuild it.
[cpg]

[OnName num="masato"]
“Tentacles ...... what can I use them for?”
[cpg cn=true]

[OnName num="masato"]
“I know now how to create poison.”
[cpg cn=true]

[OnName num="masato"]
“Is there any place that would hire a guy like me?”
[cpg cn=true]

The Great Buddha of a gal game. My eyes met Yukirin's, who had collapsed.
[cpg]

[OnName num="masato"]
“I'm a scum. I've got great abilities, but I can't use them.”
[cpg cn=true]

[OnName num="masato"]
“It must be tough being an idol, Yukirin.”
[cpg cn=true]

[OnName num="masato"]
“You and me as well, we're all in trouble.”
[cpg cn=true]

[BG f="b_10_2.ui" time=1000]
[WAIT time=2000]

[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Haduki226"]
[OnName num="haduki"]
“Here you are, Masato.”
[cpg cn=true]

[OnName num="masato"]
“Oh, Hazuki. “
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Haduki227"]
[OnName num="haduki"]
“I'm sorry.”
[cpg cn=true]

[OnName num="masato"]
“I'm sorry, too.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki228"]
[OnName num="haduki"]
“I got it under control.”
[cpg cn=true]

[OnName num="masato"]
“Good job.”
[cpg cn=true]

[OnName num="masato"]
“Why don't you buy Sanae some cream puffs?”
[cpg cn=true]

[OnName num="masato"]
“She went to the abandoned plaza at the west exit of the old station to help with the reconstructions.”
[cpg cn=true]

I got out a coupon for the cat cafe and for the public bath.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki229"]
[OnName num="haduki"]
"......"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Haduki230"]
[OnName num="haduki"]
“I'll take it.”
[cpg cn=true]

[OnName num="masato"]
“It’s on me.”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Haduki231"]
[OnName num="haduki"]
“I have a feeling, that if I stick with you, everything will be all right.”
[cpg cn=true]

[OnName num="masato"]
“What are you talking about?”
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Haduki232"]
[OnName num="haduki"]
“Don't worry about it. I'll buy some cream puffs for you, too.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki233"]
[OnName num="haduki"]
“See ya.”
[cpg cn=true]

[free time=800]

She stepped over the debris of concrete and headed out. She had gotten her driver's license and so she headed out by car.
[cpg]

[OnName num="masato"]
“I hate myself.”
[cpg cn=true]

[OnName num="masato"]
“But maybe I'll have to stay this way.”
[cpg cn=true]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_15_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空港ロビー』（昼）******************************************************

[OnName num="airport_staff"]
“You're the new airport porter?”
[cpg cn=true]

[OnName num="masato"]
“Yes.”
[cpg cn=true]

[OnName num="masato"]
“I used to work in security. I'll be able to help you with security in case of any incidents, such as sudden violent assaults.”
[cpg cn=true]

[OnName num="airport_staff"]
“Really? That’s a strong statement.”
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_15_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空港ロビー』（昼）******************************************************

[OnName num="masato"]
“Let me help you with your luggage.”
[cpg cn=true]

[OnName num="man"]
“Okay. Yes, please.”
[cpg cn=true]

[OnName num="man"]
“The security is tight lately. I think it's because of the illegal entry of that gang ……"
[cpg cn=true]

I lift the suitcase and put it on the automatic moving belt. It passes the X-ray scanner.
[cpg]

The man looked like a normal guy, but his behavior was suspicious. Maybe it was a sixth sense I'd developed in my previous job.
[cpg]

[OnName num="man"]
“Hey, what are you staring at?”
[cpg cn=true]

[OnName num="masato"]
“Nothing, Sir! I beg your pardon.”
[cpg cn=true]

[OnName num="masato"]
“You look like you're thinking about getting through the gate.”
[cpg cn=true]

[OnName num="man"]
“……”
[cpg cn=true]

The man walks through the inspection gate.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I pulled a tentacle out of my pinky finger.
[cpg]

A very thin one. I let it crawl and examine the man's shoe.
[cpg]

There was a bag of white powder on the sole of his shoe.
[cpg]

[OnName num="masato"]
“……."
[cpg cn=true]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_15_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空港ロビー』（昼）******************************************************

[OnName num="masato"]
“Sir. Let me check your shoes.”
[cpg cn=true]

[OnName num="man"]
“〜〜〜〜〜?”
[cpg cn=true]

[OnName num="airport_staff"]
“Hey, what's going on?”
[cpg cn=true]

[OnName num="masato"]
“There is something suspicious ……"
[cpg cn=true]

I took off the man's shoes. He tried to resist, but he guessed it was a bad idea and just stood there shuddering.
[cpg]

I took the shoes and held them up.
[cpg]

[OnName num="airport_staff"]
“What? No way ...... I guess these shoes seem to be thicker than they should be.”
[cpg cn=true]

[OnName num="man"]
“…….."
[cpg cn=true]

[OnName num="masato"]
“I don't know. Is it the soles?”
[cpg cn=true]

I peeled off the sole of the shoe. The sole had melted.
[cpg]

The acid had dissolved it without leaving any trace.
[cpg]

[OnName num="man"]
“!? What, what ...... what!?”
[cpg cn=true]

[OnName num="airport_staff"]
“Oh, oh! Did you step in a chemical substance?”
[cpg cn=true]

[OnName num="man"]
“What, hey ……!”
[cpg cn=true]

I looked at the man silently. The staff didn't know what to do in such a situation and went to call for a superior.
[cpg]

[OnName num="masato"]
“Hey. Don't do it again, you scum. You got a wife and kids.”
[cpg cn=true]

[OnName num="masato"]
“Judy Smith Murray, 36.”
[cpg cn=true]

[OnName num="man"]
“Ugh. That’s disgusting ……"
[cpg cn=true]

[OnName num="masato"]
“This time you'll get away with it, but we don’t want trouble either.”
[cpg cn=true]

[OnName num="masato"]
“The next time I find you, your body will melt. Maybe you'll find me at a different airport or port.”
[cpg cn=true]

[OnName num="masato"]
“I didn't set up the acid for this.”
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

After a few days of interrogation, the man left the airport.
[cpg]

Will he do the right thing next time? I gave him a good scare. I want to believe he will.
[cpg]

But I felt like the right thing to do was to turn him in to the police.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_15_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空港ロビー』（夕方）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Sanae181"]
[OnName num="sanae"]
;//「藤田さん！　お久しぶりです！」
“Masato! It's been a while!”
[cpg cn=true]

It was Sanae. She had moved to the Aomori Prefecture.
[cpg]

The contaminated soil changes every few months due to the cloudburst disaster.
[cpg]

[OnName num="masato"]
“Oh, you're using this airport? ...... Oops, I'm on duty.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sanae182"]
[OnName num="sanae"]
“Why don't you move to Aomori? I’ll be waiting.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sanae183"]
[OnName num="sanae"]
“Kayado is about to be contaminated, so it's not safe.”
[cpg cn=true]

[OnName num="masato"]
“I guess I have to move soon.”
[cpg cn=true]

I’d have to change jobs again. But, oh well.
[cpg]

I wander and wander, eventually live in a place I like, and then travel again.
[cpg]

Having that kind of life would be nice.
[cpg]


;//ＥＮＤ２


[SCENE id=11]

[jump storage="epend.ks" target="*start"]
