
*start|Work from a Professor

;#################################################
*Ep007|Work from a Professor
;#################################################

[SCENE id=7]

;//(Y):視点変更トランジション
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=2000]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『公園』（昼）******************************************************


[VOICE f="Haduki131"]
[OnName num="haduki"]
“Why did you want to see me here, Professor Rogela?”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Haduki132"]
[OnName num="haduki"]
“Is it about the email?”
[cpg cn=true]

[OnName num="rogera"]
“Don't jump to conclusions. Kano.”
[cpg cn=true]

[OnName num="rogera"]
“You have a roommate, don't you? …… Cough cough.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki133"]
[OnName num="haduki"]
“……? Yes, I have a roommate. So?”
[cpg cn=true]

I'm - oh, no, no! I have no idea why I'm being called to see this professor.
[cpg]

Professor Rogela is a mild and gentle old man. He is a professor of urban design in medieval Germany.
[cpg]

But something felt different now.
[cpg]

[OnName num="rogera"]
“The story is that the man brought back something strange.”
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Haduki134"]
[OnName num="haduki"]
“I don't recognize it.”
[cpg cn=true]

[OnName num="rogera"]
“He's hiding it. It must be some kind of special creature.”
[cpg cn=true]

His eyes are cool. He may have been good-looking when he was young. He is adored by the girls in the school, but .......
[cpg]

I didn't like him much. I don't know why. Now that feeling is getting stronger.
[cpg]

[OnName num="rogera"]
“The spread of the pollution cloud known as the 'cloudburst disaster' was caused by a meteorite impact in Switzerland.”
[cpg cn=true]

[OnName num="rogera"]
“The creatures in the area are forbidden to be taken somewhere, but the man seems to own it.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki135"]
[OnName num="haduki"]
“Really? Why would he have it?”
[cpg cn=true]

[OnName num="rogera"]
”A friend of mine who works on the local decontamination crew said there were traces of it being taken across the border.”
[cpg cn=true]

[OnName num="rogera"]
”Now it seems the man has a stash of the stuff ...... Cough, cough …….”
[cpg cn=true]

[OnName num="rogera"]
“It's illegal stuff, so he has to return it to the country it came from.”
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（昼）******************************************************

The professor and I entered the meeting hall of the city library in front of the station. You can see the outside view through the window.
[cpg]

[OnName num="rogera"]
“……"
[cpg cn=true]

[OnName num="rogera"]
“Are there any strange people following you around?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki136"]
[OnName num="haduki"]
“?”
[cpg cn=true]

[OnName num="rogera"]
“I’m a little blind since I'm old.”
[cpg cn=true]

[FADEOUTBGM]

[OnName num="rogera"]
“Anyway. I want you to bring it to me.”
[cpg cn=true]

[BGM f="bg_d2"]
[WAIT time=100]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Haduki137"]
[OnName num="haduki"]
“You want me to steal it ……?"
[cpg cn=true]

The professor stood up and gently slid a white envelope across the desk.
[cpg]

;//(Y):候補は吉川英治/手塚治虫

[FACE method="change_5" pos="2/3"]

It has a 10,000 yen bill - a rarity nowadays - with Kenzo Tange written on it. There were seventeen of them.
[cpg]

170,000 yen ……! That's an amount of money I’ve never earned.
[cpg]

[OnName num="rogera"]
“Look closely, it was made in 2030.”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Haduki138"]
[OnName num="haduki"]
“So it's actually worth 50,000 yen per piece ……?”
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Haduki139"]
[OnName num="haduki"]
“That's eighty-five thousand yen!”
[cpg cn=true]

[OnName num="rogera"]
“Did they want to recover the banknotes that had been circulating until then for the complete transition to electronic payments ……?"
[cpg cn=true]

[OnName num="rogera"]
“The economic havoc caused by the 2028 cloudburst disaster. Land prices in Tokyo and Osaka have been near zero for 51 straight months.”
[cpg cn=true]

[OnName num="rogera"]
“People flocked to the building demolition jobs, but more people joined the coup.”
[cpg cn=true]

[OnName num="rogera"]
“I'll give you school credit as well. Just promise not to tell anyone.”
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（昼）******************************************************

[OnName num="police_officer"]
“Oh, I see you're back. We've finished our investigation of the house.”
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Haduki140"]
[OnName num="haduki"]
“Right …..”
[cpg cn=true]

[OnName num="police_officer"]
“I'm sure you'll be hearing a formal report later, but we’ve identified the gunmen.”
[cpg cn=true]

[OnName num="police_officer"]
“Please inform Masato Fujita.”
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The police had gone. They simply sent an electronic certificate handover to the citizen's number.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_11_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洗面所』（昼）<『童貞喰い』流用>******************************************************

I wash my hands. The water is cold.
[cpg]

The microchip implanted in the back of my neck transmits a bone-conduction sound signifying reception.
[cpg]

Masato and sis must have been notified. I send a message.
[cpg]

<Masato, you received it right?>
[cpg]

<Yes, it arrived. I have nothing to do after all, so I'm working at my office. Why don’t you head home before me?>
[cpg]

<The gunman arrested was the third person to escape from prison in the "Ikkaku" scam group.>
[cpg]

<That’s surprising ……>
[cpg]

I had no idea ...... He broke out of jail and came here with a gun? I sense a strong sense of revenge.
[cpg]

I'm sure that prison is a fierce place, and you may have to cling to some grudge or something to survive.
[cpg]

<Sanae is in the school kitchen, apparently taking part in a remote class.>
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki141"]
[OnName num="haduki"]
“Eighty-five thousand yen— you mean up front?”
[cpg cn=true]

I don't want anything else. I don't want to get money by stealing because I feel like it was too dirty.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Haduki142"]
[OnName num="haduki"]
“No, I'm already dirty.”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki143"]
[OnName num="haduki"]
“I don't know what it is, but I feel it.”
[cpg cn=true]

I felt that if my sister found out, she would scold me.
[cpg]

Next, I thought of my mother.
[cpg]

She divorced my dad and worked as a train engineer for electric cars. Her body was getting weaker due to the cloudburst disaster.
[cpg]

Every time I go back to see her, I can see that she is getting weaker.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki144"]
[OnName num="haduki"]
“Cruise ship trip ……"
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Haduki145"]
[OnName num="haduki"]
“I wonder if she'll be pleased."
[cpg cn=true]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『寝室』（朝）******************************************************

I snuck into Masato's room. There is the smell of male sweat.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki146"]
[OnName num="haduki"]
“I’m not sure if I should do this king of thing ……”
[cpg cn=true]

I get close to the desk. There is nothing on top. It was clean. There is a drawer filled with a four-digit dial, but it is open.
[cpg]

I open the drawer. Nothing. It's clean and empty.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki147"]
[OnName num="haduki"]
“The dial is extreme security, but isn't it strange that there's nothing in there ……?"
[cpg cn=true]

I couldn't figure out what was going on. But there is a trash can next to the table ...... It has all sorts of stuff in it.
[cpg]

I looked inside and saw what looked like a paper bag of crushed pie at the bottom.
[cpg]

And on top of that, there's a coffee-stained tissue and shredded paper trash stuck in there.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Haduki148"]
[OnName num="haduki"]
“He said it was a creature ...... but there's nothing like it in here.”
[cpg cn=true]

— Also, did he sneak out and buy a pie? Whatever ...... He did treat me at the restaurant though.
[cpg]

I'll check the bookshelf.
[cpg]

Countermeasures Against Terrorism Through Air Conditioning,' 'Cyber Police Individual Casebook 2047,' 'Still Life Drawing for Beginners.’
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki149"]
[OnName num="haduki"]
“Hmmm, I hope I don’t bump into any erotic books ……”
[cpg cn=true]

‘France Photo Collection from 2021,’ ‘Japan's Umaishu, Eastern Japan,’ ‘Security Industry Laws and Regulations, <Since the Cloudburst Disaster>.’
[cpg]

— Oh no - I'm not going to find it.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（昼）******************************************************

I went down to the living room. My sister had come back home.
[cpg]

;//●ＣＧ非エロ（R18版からそのまま使用）ev_16
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[VOICE f="Sanae136"]
[OnName num="sanae"]
“..... Hazuki?”
[cpg cn=true]

[VOICE f="Haduki150"]
[OnName num="haduki"]
“Oh, you’re back.”
[cpg cn=true]

My heart was pounding. I wondered if she was aware of my actions.
[cpg]

[VOICE f="Sanae137"]
[OnName num="sanae"]
;//「……藤田さんの部屋から、扉を締める音がしなかった？」
“...... Did you hear the door close from Masato's room?”
[cpg cn=true]

[VOICE f="Haduki151"]
[OnName num="haduki"]
“……"
[cpg cn=true]

[VOICE f="Haduki152"]
[OnName num="haduki"]
“It's probably just your imagination ……."
[cpg cn=true]

[VOICE f="Sanae138"]
[OnName num="sanae"]
“You're lying, aren't you?”
[cpg cn=true]

— !?
[cpg]

[VOICE f="Sanae139"]
[OnName num="sanae"]
“How many years do you think I've been your sister? I can sense that you’re nervous.”
[cpg cn=true]

[VOICE f="Sanae140"]
[OnName num="sanae"]
“What were you up to?”
[cpg cn=true]

[VOICE f="Haduki153"]
[OnName num="haduki"]
“……”
[cpg cn=true]

[VOICE f="Haduki154"]
[OnName num="haduki"]
“I was just ……looking around the house to see if anyone was messing with us ……"
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_4"  pos="4/4" time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（昼）******************************************************

Lies upon lies upon lies. I have no choice but to go through with it now ......
[cpg]

[FACE method="change_7" pos="2/5"]
[VOICE f="Sanae141"]
[OnName num="sanae"]
“…… Hmmm.”
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[VOICE f="Haduki155"]
[OnName num="haduki"]
“Yeah, because that's what you do when someone comes into your house ……! When you invite people over for a party.”
[cpg cn=true]

[FACE method="bow_7" pos="2/5"]
[VOICE f="Sanae142"]
[OnName num="sanae"]
“I'm sure. It gets pretty dirty. Drinks get spilled all over the place.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[VOICE f="Sanae143"]
[OnName num="sanae"]
“Oh, well.”
[cpg cn=true]

;//(Y):視点変更トランジション
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=2000]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『居間』（夜）******************************************************

[OnName num="masato"]
“Hey, I'm home!”
[cpg cn=true]

Hazuki and Sanae greeted me, waving their hands. But I felt a somewhat awkward atmosphere. Was it just my imagination?
[cpg]

[OnName num="masato"]
“I feel like I haven't been home in a while ……"
[cpg cn=true]

[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『寝室』（夜）******************************************************

Hmm? There is a different smell in the room. Was it Hazuki ......?
[cpg]

No, it also smells like the police.
[cpg]

[OnName num="masato"]
“Oh, shit …… I'm glad I ate the pie and threw away the bag.”
[cpg cn=true]

On top of that, I stuffed coffee-sucking tissues and other paper scraps in the garbage bin. It was just to comfort my thoughts, but maybe it helped.
[cpg]

I put my hand on the four-digit dial; entering 3673.
[cpg]

I open the bottom drawer. It was already open.
[cpg]

[OnName num="masato"]
"Mmm-hmm."
[cpg cn=true]

I pull out baby powder and a fluffy earpick from the bottom of the drawer.
[cpg]

[OnName num="masato"]
“I'm going to check for fingerprints.”
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

There were a couple of fingerprints, including the bookshelf handle .......
[cpg]

[OnName num="masato"]
“……."
[cpg cn=true]

I don't think the police leave fingerprints. It must have been Hazuki.
[cpg]

I pulled out an old-generation feature phone ...... A junk phone with no battery.
[cpg]

It was disguised as one that I had tried to disassemble.
[cpg]

[OnName num="masato"]
“I guess I have to use it.”
[cpg cn=true]

I open the inside of the computer, take out a very small, unfamiliar card from it and insert it.
[cpg]

I insert the battery, and the tiny card, connect it to the charger, and turn on the power.
[cpg]

It says "no signal," but I open the phone and type in the number: 6231.
[cpg]

Suddenly I hear a sound come from somewhere.
[cpg]

I disassembled the top nozzle of the can of insecticide I had left in my room. The can was empty, but there was something at the bottom.
[cpg]

It was a device with a black metal ring. There were red dots on the inside.
[cpg]

[OnName num="masato"]
“It was ‘the black light wire’.”
[cpg cn=true]

[OnName num="masato"]
“I'm sorry, I was given this at work. ...... Sorry.”
[cpg cn=true]

I take out the hard case, where the creepy insect was inside, and put it on the through the round wire.
[cpg]

The creature inside the case sprawled, squirmed, and spun around. Then it stopped moving.
[cpg]

It looks just like an ordinary worm .......
[cpg]

The evidence was destroyed.
[cpg]

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[FG f="CHA03_p4_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社』（昼）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki076"]
[OnName num="misaki"]
“Hmm?”
[cpg cn=true]

I reported it, but she didn't pay much attention to that.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki077"]
[OnName num="misaki"]
“Even if you left them alone, they'd die like mere worms. Anyway.”
[cpg cn=true]

[OnName num="masato"]
“Do I get punished for that?”
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Misaki078"]
[OnName num="misaki"]
“No, sir.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki079"]
[OnName num="misaki"]
“You know, that's security level one.”
[cpg cn=true]

I thought about it. That's level 1, and it was a creature of the other world, but .......
[cpg]

What if there is a level 2 or 3?
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Misaki080"]
[OnName num="misaki"]
“I'd rather say that you've reported me properly, so you've earned a higher level of trust.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki081"]
[OnName num="misaki"]
“But if you continue to volunteer for the experiment, you will asked to come here next time.”
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所前』（朝）******************************************************

[OnName num="masato"]
"...... That short life, that was security in itself."
[cpg cn=true]

It's a fleeting life. When it dies, it looks like an earthworm.
[cpg]

The police can't possibly investigate it as a new organism for exoplanet exploration.
[cpg]

They would have to go to the top, or the research institutes would have to cover it up. How big a power do those agencies have?
[cpg]

[OnName num="masato"]
“I don't want to think about it …… I want a drink ……"
[cpg cn=true]

;//(Y):視点変更トランジション
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『公園』（昼）******************************************************

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki156"]
[OnName num="haduki"]
“Professor Rogera: …… not found.”
[cpg cn=true]

[OnName num="rogera"]
“Well, that's just the way it is.”
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Haduki157"]
[OnName num="haduki"]
“Well, I ...... failed, right? Should I return the money ……?”
[cpg cn=true]

[OnName num="rogera"]
“No, I don't care.”
[cpg cn=true]

I wonder what scale of an investigation he is working on.
[cpg]

I could tell that it was strange that he suddenly handed over that amount of money.
[cpg]

What's behind this ......?
[cpg]

;//(Y):ロジェラ教授は葉月をわざと美咲らの捜査網にひっかけさせて「適合しやすい個体じゃないか」と触手を呑ませるだろうことを予見しています。本当は葉月が暴走する可能性が高い個体であることを知っています。素人の葉月が、プロの警備（主人公）や国が背後にいる美咲を相手に、新生物を盗みだせるとは思っていません。ロジェラ教授は美咲らを騙す縁起の迫真さのために死亡する気でいます。

[OnName num="rogera"]
“As a matter of fact, it's been a success. You've done a great job.”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Haduki158"]
[OnName num="haduki"]
“?”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Haduki159"]
[OnName num="haduki"]
“Oh, um ...... I'm an amateur, aren't I?”
[cpg cn=true]

[OnName num="rogera"]
“What do you mean?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki160"]
[OnName num="haduki"]
“I mean, someone a little more ...... adept at this sort of thing should probably do it ……"
[cpg cn=true]

[OnName num="rogera"]
“You’re his roommate. That’s why I asked for your help.”
[cpg cn=true]

[OnName num="rogera"]
“I may be moving away soon so I won't be able to see you.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki161"]
[OnName num="haduki"]
“What about your classes?”
[cpg cn=true]

[OnName num="rogera"]
“I've already recorded them. You’ll have to take the classes online. It’s something I an do in this day and age.”
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（夕方）******************************************************

I didn't want to go home.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki162"]
[OnName num="haduki"]
“Masato ……"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki163"]
[OnName num="haduki"]
“They don't know, do they? ……"
[cpg cn=true]

Is this really where I stand?
[cpg]

Since the days before urban design, the days of small settlements of people, weak people like me have been leaning on each other.
[cpg]

In truth, it would be best if I could live on my own ......
[cpg]

;//(Y):視点変更トランジション
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『居間』（夜）******************************************************

[FACE method="change_1" pos="2/5"]
[VOICE f="Sanae144"]
[OnName num="sanae"]
“I'm going to take a bath.”
[cpg cn=true]

[OnName num="masato"]
“Go ahead.”
[cpg cn=true]

[free time=1000]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=1000]
[WAIT time=1000]

Sanae headed for the bath. Hazuki and I were now alone. Hazuki seemed nervous and would not make any eye contact.
[cpg]

[OnName num="masato"]
“Hazuki.”
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Haduki164"]
[OnName num="haduki"]
“…..!"
[cpg cn=true]

[OnName num="masato"]
“You went into my room, didn't you?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki165"]
[OnName num="haduki"]
“The police saw us. I wondered if everyone's room was okay.”
[cpg cn=true]

[OnName num="masato"]
“You said that a little too soon.”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Haduki166"]
[OnName num="haduki"]
“What?”
[cpg cn=true]

[OnName num="masato"]
“When you're accused of something, can you reply that fast?”
[cpg cn=true]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Haduki167"]
[OnName num="haduki"]
"〜〜〜〜〜!"
[cpg cn=true]

I have to pursue it. We live together, after all. I want to know what she’s up to.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki168"]
[OnName num="haduki"]
"...... Masato, is it true that you brought back some kind of creature?"
[cpg cn=true]

[OnName num="masato"]
"......"
[cpg cn=true]

[OnName num="masato"]
“……. I don't remember anything in particular.”
[cpg cn=true]

—S uddenly, I was in a tight spot.
[cpg]

Wait a minute. How does she know ......?
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Haduki169"]
[OnName num="haduki"]
“Oh, that's right. Isn't it in your clothes or luggage or something?”
[cpg cn=true]

[OnName num="masato"]
“Wait, who told you what?”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Haduki170"]
[OnName num="haduki"]
"〜〜〜〜!"
[cpg cn=true]

[OnName num="masato"]
“Is that person really on your side?”
[cpg cn=true]

[OnName num="masato"]
“What reason did he give for approaching you?”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Haduki171"]
[OnName num="haduki"]
“Wait, wait! One question at a time! That's the rule in this house ……!"
[cpg cn=true]

[OnName num="masato"]
“So you will tell me?”
[cpg cn=true]

From the bathroom, I could hear Sanae singing. It was an American song at the top of the billboard chart recently.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki172"]
[OnName num="haduki"]
“....... Switzerland. Meteorite ……."
[cpg cn=true]

Hazuki spoke.
[cpg]

;//(Y):セピア色回想の演出。葉月に語らせるとボイスコストかかりそうなので回想シーンによって説明を使い回します

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（昼）******************************************************

[OnName num="rogera"]
“The spread of the pollution cloud known as the ‘cloudburst disaster’ was caused by a meteorite impact in Switzerland.”
[cpg cn=true]

[OnName num="rogera"]
“Creatures in the vicinity of it are forbidden to be taken away, but the man has it.”
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（夜）******************************************************

[OnName num="masato"]
“What?”
[cpg cn=true]

That was a complete lie. The workplace is only studying the organisms brought back from the 'exoplanet' exploration.
[cpg]

I have a feeling they are ostensibly taking advantage of it, hiding the truth with a hoax about biological mutations caused by a cloudburst disaster or something like that.
[cpg]

Could this be the guy who fell for one of those?
[cpg]

[OnName num="masato"]
“Professor Rogela ……."
[cpg cn=true]

[OnName num="masato"]
“The professor who I helped you type the email?"
[cpg cn=true]

Hazuki nodded.
[cpg]

[OnName num="masato"]
“How much money did you get? Was it all cash?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki173"]
[OnName num="haduki"]
“Uh ...... yeah.”
[cpg cn=true]

[OnName num="masato"]
“……"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki174"]
[OnName num="haduki"]
“Eight hundred and fifty thousand yen.”
[cpg cn=true]

[OnName num="masato"]
“Wow!”
[cpg cn=true]

[OnName num="masato"]
“Oh my God!”
[cpg cn=true]

;//(Y):風呂から声をかけてくるだけなので立ち絵なし

[VOICE f="Sanae145"]
[OnName num="sanae"]
“What's going on? Masato!”
[cpg cn=true]

Sanae called out from the bath. How could I stay calm?
[cpg]

——That kind of amount ——I——!
[cpg]

[OnName num="masato"]
“What!!! Eight hundred and fifty thousand???”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki175"]
[OnName num="haduki"]
“Masatooooo!”
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Haduki176"]
[OnName num="haduki"]
“I'm sorry! I'm so sorry!”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Haduki177"]
[OnName num="haduki"]
“Oh, my bag!”
[cpg cn=true]

An envelope fell out. The bills spread out like a fan.
[cpg]

A 10,000 yen bill made in 2030, worth 50,000 yen, spread out in front of me - 17 of them, to be exact.
[cpg]

[OnName num="masato"]
“Woahhhhhhhhhhh!”
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『会社』（夜）******************************************************

The air coming from the air-conditioning room was reported to have a different composition. My boss was upset, wondering if it was bio-terrorism.
[cpg]

Upon investigation, it was nothing of the sort. It was just pigeons pooping in the old rooftop ducts.
[cpg]

Before I had time to catch my breath, Misaki spoke to me.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki082"]
[OnName num="misaki"]
“That thing the other day, that was with your roommate, Hazuki, wasn't it?”
[cpg cn=true]

[OnName num="masato"]
“..... Yes.”
[cpg cn=true]

I can't hide your roommate's status, etc. from the company. The company knows everything.
[cpg]

But I will not lay a hand on Hazuki, a mere school student, to harm her. It's dangerous, but I'm not saying anything unnecessary.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Misaki083"]
[OnName num="misaki"]
“We have an EEG scanner, in case you're wondering. I'd like to ask you a few questions, as required by the Intelligence Leakage Investigation Act.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki084"]
[OnName num="misaki"]
“Let’s go to the other room.”
[cpg cn=true]

Machines like this have been commonplace in the private sector since around 2037. In the case of this place, though, they seem to be of high performance.
[cpg]

;//ＢＫ
[window target=false]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[window target=true]

Misaki approached me and began to attach a black headband around my head.
[cpg]

Finally, I saw Misaki's chest area. She took me to another room.
[cpg]

;//●ＣＧ非エロ（美咲が高圧的な様子で質問してくる。厳しい目）ev_37
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_37_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[VOICE f="Misaki085"]
[OnName num="misaki"]
“Please sit down.”
[cpg cn=true]

I was torn. How should I answer?
[cpg]

[OnName num="masato"]
“Hazuki is ……"
[cpg cn=true]

[VOICE f="Misaki086"]
[OnName num="misaki"]
“I haven't asked any questions yet. Quiet.”
[cpg cn=true]

[OnName num="masato"]
“Yes.”
[cpg cn=true]

I felt a nasty sweat trickle down my forehead. My mouth is dry. I want this to be over soon.
[cpg]

[VOICE f="Misaki087"]
[OnName num="misaki"]
“What is Ms. Hazuki's daily life like?”
[cpg cn=true]

[OnName num="masato"]
“She’s studying European and American history and culture at school.”
[cpg cn=true]

[VOICE f="Misaki088"]
[OnName num="misaki"]
“Have there been any changes recently?”
[cpg cn=true]

[OnName num="masato"]
“……!"
[cpg cn=true]

[SE f="se034"]
;//【ＳＥ】機械が反応する。ビーッ、ビーッ　など

[VOICE f="Misaki089"]
[OnName num="misaki"]
"...... It’s responding.”
[cpg cn=true]

[OnName num="masato"]
"......"
[cpg cn=true]

It's not a lie detection. I didn't even answer the question. It just sensed mt anger.
[cpg]

[VOICE f="Misaki090"]
[OnName num="misaki"]
“The question is. What has changed recently?"
[cpg cn=true]

[OnName num="masato"]
“..... She’s become kinder to her sister.”
[cpg cn=true]

[VOICE f="Misaki091"]
[OnName num="misaki"]
“….."
[cpg cn=true]

No response. Not a lie, but not true either. I answered randomly and tried to get through the situation.
[cpg]

I did all of this to protect Hazuki. At this rate, Misaki will figure out the truth ......
[cpg]

[VOICE f="Misaki092"]
[OnName num="misaki"]
"...... What else?”
[cpg cn=true]

[OnName num="masato"]
“I realized that the restaurant's, cat's meow service calmed me down ……"
[cpg cn=true]

[VOICE f="Misaki093"]
[OnName num="misaki"]
“Damn it ……."
[cpg cn=true]

[OnName num="masato"]
“I felt relaxed enough to love the flowers, the birds, the wind, and the moon, and I thought, something's changed. ……!"
[cpg cn=true]

[SE f="se034"]
;//【ＳＥ】機械が反応する。ビーッ、ビーッ　など

The machine reacted again in response to the growing tension.
[cpg]

[VOICE f="Misaki094"]
[OnName num="misaki"]
"...... What else?”
[cpg cn=true]

[OnName num="masato"]
“What do you mean?”
[cpg cn=true]

;//a　美咲、驚愕の顔に変化
;//;**【ＣＧ】 ev_37_a ***********************
;//[CG id=16 index=1 time=1]
;//;***************************************
;//[WAIT time=1]

[VOICE f="Misaki095"]
[OnName num="misaki"]
“!?”
[cpg cn=true]

[OnName num="masato"]
“I don't know what kind of things are weird.”
[cpg cn=true]

I remember all the bad things that have happened to me in my life up until now. I - I tried to have a mental breakdown on purpose.
[cpg]

It could be when I was drinking alcohol and almost collapsed.
[cpg]

Or the excitement of being beaten up in a fight or getting back at someone! No, wait, that would not be good! I'm still pissed off by that!
[cpg]

[SE f="se034"]
;//【ＳＥ】機械が反応する。

[OnName num="masato"]
“Why is Hazuki suspicious? She's a good girl!”
[cpg cn=true]

[VOICE f="Misaki096"]
[OnName num="misaki"]
“Please stop this!”
[cpg cn=true]

[OnName num="masato"]
“It's dark! Take off this blindfold!”
[cpg cn=true]

[OnName num="masato"]
“Uh-oh! Aah! I'm afraid of ...... dark places ……"
[cpg cn=true]

[OnName num="masato"]
“Huh!”
[cpg cn=true]

[OnName num="masato"]
“Huh ……… Ahhhhhh.”
[cpg cn=true]

[OnName num="masato"]
“I'm calm now.”
[cpg cn=true]

[SE f="se034"]
;//【ＳＥ】機械が反応する。

[VOICE f="Misaki097"]
[OnName num="misaki"]
“....... Uh, um ……."
[cpg cn=true]

[VOICE f="Misaki098"]
[OnName num="misaki"]
“Let me get back to the question. Did Ms. Hazuki see anyone suspicious recently?
[cpg cn=true]

[OnName num="masato"]
“I've never heard of such a thing ……”
[cpg cn=true]

[SE f="se034"]
;//【ＳＥ】機械が反応する。

[VOICE f="Misaki099"]
[OnName num="misaki"]
“……"
[cpg cn=true]

[OnName num="masato"]
“……"
[cpg cn=true]

How about it? I don't know.
[cpg]

[VOICE f="Misaki100"]
[OnName num="misaki"]
“That would be all the questions. We are done now ……”
[cpg cn=true]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『生物研究所前』（夕方）******************************************************

Done.
[cpg]

[OnName num="security_guard"]
“Oh ....... Mr. Fujita, ....... Thank you for dropping by.”
[cpg cn=true]

[OnName num="masato"]
“What's wrong?”
[cpg cn=true]

[OnName num="security_guard"]
“I …. don’t know.”
[cpg cn=true]

[OnName num="security_guard"]
“If it's all right with you, I can help you ……?"
[cpg cn=true]

[OnName num="masato"]
“Oh, ha-ha-ha ...... thank you.”
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『寝室』（夜）******************************************************

I had to find out more about Professor Rogela.
[cpg]

First, I looked up his class schedule. This was easy to find.
[cpg]

[OnName num="masato"]
“Who are you?”
[cpg cn=true]

[OnName num="masato"]
“Where do you live?”
[cpg cn=true]

I was trying to email a school student I found on the Internet. But, wait ……
[cpg]

Wait a minute, I don't want word to get out. What should I do?
[cpg]

Currently, the school offers mostly video and audio classes. If they listen to the lessons and understand them well enough, they come to the campus to take the credit exam.
[cpg]

In a nutshell, the current Japan is centered on the former web-based classes. That is why the students are usually working.
[cpg]

[OnName num="masato"]
“....... So many students don't know much about their professors ……”
[cpg cn=true]

This was a cost-cutting measure on the part of the school, but it also created free time on the part of the students.
[cpg]

The students can intern or work part-time in the private sector. The sense of belonging to the school was quite low.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居間』（夜）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki178"]
[OnName num="haduki"]
“The professor lives in the western part of Kayado Ward.”
[cpg cn=true]

[OnName num="masato"]
“I see ……"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Haduki179"]
[OnName num="haduki"]
“I've been looking into it ever since I thought he was suspicious.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki180"]
[OnName num="haduki"]
“There was a case of a bomb in the mail in 2031, wasn't there? The one addressed to Hibiya International Music University.”
[cpg cn=true]

[OnName num="masato"]
“Yes.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki181"]
[OnName num="haduki"]
“Since then, it's customary to hide one's address and personal information, but since the professor is also a Vtuber, he's not hiding anything.”
[cpg cn=true]

[OnName num="masato"]
“Hmm? Why didn't he hide his address?”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Haduki182"]
[OnName num="haduki"]
“I guess it was common at gift receptions. It would be more suspicious if he hid it.”
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Haduki183"]
[OnName num="haduki"]
“If he received all his earnings in money, he would have to go through the trouble of filing a final tax return.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Haduki184"]
[OnName num="haduki"]
“Masato, what are you going to do? Why are you trying to find out where he lives?”
[cpg cn=true]

[OnName num="masato"]
“I'm going to find out what the professor is up to.”
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Haduki185"]
[OnName num="haduki"]
“……. It's dangerous.”
[cpg cn=true]

[OnName num="masato"]
“I know …… It's probably a trap. And let me tell you something else. It's more dangerous now.”
[cpg cn=true]

[OnName num="masato"]
“Well, you got yourself involved in something dangerous. You and Sanae should get ready to jump.”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Haduki186"]
[OnName num="haduki"]
“What?”
[cpg cn=true]

[OnName num="masato"]
“I cashed in the money that you received. It ended up really being eighty-five thousand yen. There is till some money left.”
[cpg cn=true]

[OnName num="masato"]
“Just make up a reason. Say you’re traveling or visiting your parents, whatever.”
[cpg cn=true]

[OnName num="masato"]
“It all smells fishy. If nothing happens, we'll meet up later.”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki187"]
[OnName num="haduki"]
“Okay, I got it ...... but this money ……”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Haduki188"]
[OnName num="haduki"]
“I wanted to give my mother a cruise ship trip ……"
[cpg cn=true]

[OnName num="masato"]
“Even for your parents, your safety comes first. What are you talking about?”
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（昼）******************************************************

In the end, I decided to use my day off to follow him. I looked for his car in the parking lot behind the school where there were many cars.
[cpg]

[OnName num="masato"]
“It's hot. It's the ...... environmental destruction, you son of a bitch ……"
[cpg cn=true]

In the distance, Yukirin, the main character of a gal game - or rather, an anime - was echoing in the background, singing the theme song. It was annoying.
[cpg]

The few people who could be seen were all dressed in white. An old lady with a parasol gets into a car with an ice cream cone in her hand.
[cpg]

[OnName num="masato"]
“The license plate number of the car is ....... No. That one is different. Let's see, ...... it's that car.”
[cpg cn=true]

The car was chrome red with black streamlines running from the lower front to the rear end.
[cpg]

Even with such an assertive design, it was not shiny and was a rather calm design for this district.
[cpg]

[OnName num="masato"]
“A formidable foe.”
[cpg cn=true]

[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（昼）******************************************************

I got into my car and waited, looking at the sky.
[cpg]

I've never cared about cars or ....... Even more so since the Energy Conservation Act came into effect.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（昼）******************************************************

Just as I was starting to feel a bit depressed - someone got into the chrome red/black car.
[cpg]

It was the professor. His sun visor glowed like a beetle. The car starts slowly.
[cpg]

I drive slowly, trying to stay out of sight.
[cpg]

[OnName num="masato"]
“Don't follow too closely.”
[cpg cn=true]

[OnName num="masato"]
“I'm not a professional tailgater ……"
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（昼）******************************************************

He seemed to have stopped at a supermarket and a frozen food store.
[cpg]

He didn’t spend much time in each of the stores. He was probably a regular customer.
[cpg]

[OnName num="masato"]
“This is enough information ……"
[cpg cn=true]

[OnName num="masato"]
“This should be the limit.”
[cpg cn=true]

The rest should be done by someone professional, like a detective ...... The car slowed down as I thought about it.
[cpg]

The car entered a residential area. There was no sign of any other cars in the area and it was gradually entering a narrow street.
[cpg]

[OnName num="masato"]
“Am I too close?”
[cpg cn=true]

I randomly entered a lonely parking lot and parked my car.
[cpg]

I hurry out of the car and run. I returned to the original road and looked for the car from the corner of the road. It was standing in front of a house.
[cpg]

It was slowly backing the car into the parking space ......
[cpg]

[OnName num="masato"]
“....... I tracked him down.”
[cpg cn=true]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（夕方）******************************************************

I want to be careful approaching the front of the house and checking it out. I took out the camera on my phone and looked at the house.
[cpg]

The house was surrounded by houses of British and Scandinavian design, but this was the only house that had a Japanese design.
[cpg]

There was even a nameplate. It says "Rubio" on it. The font looks like it was written by a Japanese calligrapher.
[cpg]

[OnName num="masato"]
“This should be good enough.”
[cpg cn=true]

I returned to the car. There was a kid in front of me, that seemed to be an elementary school student.
[cpg]

[OnName num="boy"]
“Mister, what are you doing?”
[cpg cn=true]

[OnName num="masato"]
“Uhh ……”
[cpg cn=true]

Was he a resident of the neighborhood? I don't want any rumors to get out. What would happen if that rumor got around to ‘him’ ......?
[cpg]

[OnName num="masato"]
“Hey, I'm a little lost.”
[cpg cn=true]

[OnName num="boy"]
“Was it you who just parked there?”
[cpg cn=true]

[OnName num="boy"]
“A lady in the neighborhood was wondering who it was.”
[cpg cn=true]

[OnName num="boy"]
“She said she didn't recognize the car! She said she was gonna call the cops.”
[cpg cn=true]

[OnName num="masato"]
“…..”
[cpg cn=true]

[OnName num="masato"]
“I’m ...... real estate agent.”
[cpg cn=true]

[OnName num="boy"]
“You don't look like a realtor.”
[cpg cn=true]

[OnName num="masato"]
“My company has its eye on a plot of land around here. We’ve been approached about building a big crepe shop.”
[cpg cn=true]

[OnName num="boy"]
“What? Wow, that's great! That could come in handy.”
[cpg cn=true]

[OnName num="boy"]
“Can we eat crepes in secret from the teacher when we come back from school?”
[cpg cn=true]

[OnName num="masato"]
“Yes, you can! Oh no. I might have talked too much!”
[cpg cn=true]

[OnName num="masato"]
“If word of this gets out, we might not be able to build it anymore ……..”
[cpg cn=true]

[OnName num="boy"]
“!”
[cpg cn=true]

[OnName num="masato"]
“You know, the company is all about secrecy ...... I guess I accidentally told you …..”
[cpg cn=true]

[OnName num="masato"]
“If I tell anyone about this, the big boss will get mad at me and fire me, and the whole crepe shop will go away.”
[cpg cn=true]

[OnName num="boy"]
“That's ...... not good ……”
[cpg cn=true]

[OnName num="boy"]
“I'll keep it a secret.”
[cpg cn=true]

[OnName num="masato"]
“Thank you.”
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『居間』（夜）******************************************************

With that, I went home.
[cpg]

[FACE method="change_7" pos="2/5"]
[VOICE f="Sanae146"]
[OnName num="sanae"]
“...... You're drinking a lot more than ususal today, aren't you?”
[cpg cn=true]

[OnName num="masato"]
“I'm screwed. I've tricked a nice little kid.”
[cpg cn=true]

[OnName num="masato"]
“Ahhhh 〜〜〜〜〜〜……! I'm a sinner ...... and what I did is unforgivable …….”
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[VOICE f="Haduki189"]
[OnName num="haduki"]
“You're drinking in regret!”
[cpg cn=true]

[FACE method="shake_3" pos="4/5"]
[VOICE f="Haduki190"]
[OnName num="haduki"]
“Sis. You can't do this. Drinking is a roundabout way of committing suicide.”
[cpg cn=true]

[FACE method="bow_7" pos="2/5"]
[VOICE f="Sanae147"]
[OnName num="sanae"]
“I'm old enough to drink, but I don't like the taste ..... so I guess I'm not worried about that at the moment.”
[cpg cn=true]

[OnName num="masato"]
“It makes me want to hang on to something else instead …….”
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[VOICE f="Haduki191"]
[OnName num="haduki"]
“I don't want to be that way …… I want to be young forever ……"
[cpg cn=true]

Our current society is a sham given that you have to depend on something to survive. It's best if you can live a healthy life.
[cpg]

I hope that Sanae and Hazuki don't end up like me.
[cpg]

[FACE method="bow_1" pos="2/5"]
[VOICE f="Sanae148"]
[OnName num="sanae"]
“I'm going back to my mother’s tomorrow.”
[cpg cn=true]

[OnName num="masato"]
“Okay.”
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[VOICE f="Sanae149"]
[OnName num="sanae"]
“She said she wanted to see me, which is quite unusual ……"
[cpg cn=true]

It was about what I had told her the other day. I had told Hazuki to run away once because I felt that she was in danger.
[cpg]

[FACE method="bow_1" pos="4/5"]

I looked at Hazuki. She nodded. Her eyes were strong-willed, as usual.
[cpg]


[jump storage="ep008.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
