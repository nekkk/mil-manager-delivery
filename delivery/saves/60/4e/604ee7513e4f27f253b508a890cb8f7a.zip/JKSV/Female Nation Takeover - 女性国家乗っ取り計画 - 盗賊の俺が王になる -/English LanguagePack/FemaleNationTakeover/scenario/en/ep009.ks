

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//『ヒロイン３エンド』（ヒロイン３ポイントが４度増加している場合）
*Ending_hiroin3|Tina's Intentions

*start|Tina's Intentions

;#################################################
*Ep009|Tina's Intentions
;#################################################

[SCENE id=9]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『宿屋寝室』（朝）******************************************************


Tina was completely obedient to me. I had no doubts about that.
[cpg]

But still, I couldn't keep my mind from going to darker places.
[cpg]

Without her help, I wasn't sure we could win.
[cpg]

Maybe there was some part of her that really loved her country......
[cpg]

Maybe it was all a ploy to get me to deploy the rest of my forces so she could take them all out at once.
[cpg]

[OnName num="gil"]
"You're overthinking it, she doesn't look like the type who can hide things well."
[cpg cn=true]

[OnName num="eddie"]
"You're probably right......"
[cpg cn=true]

But I still couldn't explain how quickly she'd placed herself at my mercy.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[OnName num="gil"]
"So where are we heading?"
[cpg cn=true]

[OnName num="eddie"]
"Just in case, we've got to be careful."
[cpg cn=true]

Tina had fought alongside the military in previous engagements.
[cpg]

In that case, Alicia would probably know about Tina.
[cpg]

Or maybe Stella was a better choice? It's not like Alicia would hire mercenaries herself.
[cpg]

Maybe I should just visit both of them.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城内の一室』（昼）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="Stella289"]
[OnName num="stella"]
"Tina...? I'm afraid all I can say is that she's an excellent magician."
[cpg cn=true]

[OnName num="eddie"]
"So how loyal is she to the kingdom?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Stella290"]
[OnName num="stella"]
"Well...it did seem that she was only there for the money. I can't really say that she volunteered for any other reason."
[cpg cn=true]

I already know all that.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Stella291"]
[OnName num="stella"]
"However.....I think she was acting rather strangely when I saw her the other day."
[cpg cn=true]

[OnName num="eddie"]
"What do you mean?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Stella292"]
[OnName num="stella"]
"She seemed dazed."
[cpg cn=true]

I knew about that too. That's how she acted after I trained her. It seems Stella didn't know anything I didn't.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


It was Alicia's turn.
[cpg]

[OnName num="gil"]
"Why are you panicking now? Why don't you trust Tina like before?"
[cpg cn=true]

[OnName num="eddie"]
"You shut your mouth."
[cpg cn=true]


[window target=false]
[free time=1000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『姫の寝室』（昼）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Alicia345"]
[OnName num="alicia"]
"Tina? I'm sorry, I don't really know her all that well."
[cpg cn=true]

[OnName num="eddie"]
"Whatever. Tell me what you know."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Alicia346"]
[OnName num="alicia"]
"Well...I think she's in love with you."
[cpg cn=true]

[OnName num="eddie"]
"What......?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Alicia347"]
[OnName num="alicia"]
"Tina's the reason you were able to sneak into the castle, right?"
[cpg cn=true]

[OnName num="gil"]
"That's right, I think normally you wouldn't go quite that far..."
[cpg cn=true]

[OnName num="gil"]
"I mean the risks are so great, normally you'd hesitate before sticking your neck out like that."
[cpg cn=true]

[OnName num="eddie"]
"You're saying she's helping me because she's in love with me?"
[cpg cn=true]

[OnName num="eddie"]
"That's impossible."
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



Well that was a total waste of time.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[OnName num="gil"]
"So now what? Are you going to go to her directly this time?"
[cpg cn=true]

[OnName num="eddie"]
"Yeah. If she betrays us at the last minute, we're done."
[cpg cn=true]

[OnName num="gil"]
"......Well, I won't stop you if that's what you want to do. But I don't think you'll enjoy it."
[cpg cn=true]

[OnName num="eddie"]
"What do you mean?"
[cpg cn=true]

[OnName num="gil"]
"Well, boss...it seems to me that you've never fallen in love before and you probably never will."
[cpg cn=true]

[OnName num="eddie"]
"Yeah, well that's part of being a bandit."
[cpg cn=true]

[OnName num="gil"]
"Right, so don't you think that you should probably avoid situations like this?"
[cpg cn=true]

[OnName num="eddie"]
"......"
[cpg cn=true]


[SE f="se006"]
;//【ＳＥ】『入店音』

[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『花屋』（昼）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Tina310"]
[OnName num="tina"]
"Hello......"
[cpg cn=true]

[OnName num="eddie"]
"This will be our last meeting before the attack. I need to talk to you."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tina311"]
[OnName num="tina"]
"Okay......? Umm, I've been trying to come up with a plan to help you and your men.
[cpg cn=true]

[OnName num="eddie"]
"Oh, I believe you. I need to know something else..."
[cpg cn=true]

[OnName num="eddie"]
"Why do you obey me to this extent?"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Tina312"]
[OnName num="tina"]
"That's......"
[cpg cn=true]

[OnName num="eddie"]
"What you're about to do is murder, too, in a sense."
[cpg cn=true]

[OnName num="eddie"]
"And you're killing your own people. Why aren't you hesitating?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tina313"]
[OnName num="tina"]
"I can't tell you......"
[cpg cn=true]

She blushes furiously. Was Alicia right?
[cpg]

[OnName num="eddie"]
"I need you to tell me straight. Are you in love with me?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tina314"]
[OnName num="tina"]
"......"
[cpg cn=true]

[OnName num="eddie"]
"If so, I can't reciprocate your feelings. I'm just not capable of love."
[cpg cn=true]

Why am I saying all this? If she's useful to me, then let her stay that way.
[cpg]

She's just a tool to take this kingdom down...I need to treat her like one.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tina315"]
[OnName num="tina"]
"If you're saying this because you care about me, then I'm glad......"
[cpg cn=true]

[OnName num="eddie"]
"Don't say it. Look, just do what I tell you. Don't even think about anything else."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Tina316"]
[OnName num="tina"]
"I know. Don't worry."
[cpg cn=true]



[SE f="se011"]
;//【ＳＥ】『ドア閉まる』


;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


I met up with Gil, who was waiting outside.
[cpg]

[OnName num="gil"]
"So, how'd it go? She's in love with you, right boss?"
[cpg cn=true]

[OnName num="eddie"]
"......It was nothing. It doesn't matter. Let's go."
[cpg cn=true]

[OnName num="gil"]
"I told you......"
[cpg cn=true]


[SE f="se001"]
;//【ＳＥ】『歩く』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『荒野』（夕方）******************************************************


We left the town and walked past the border to the bandit camp.
[cpg]

It was a good distance away, but not so far that we'd need horses.
[cpg]

Otherwise, we'd never be able to take the kingdom overnight.
[cpg]

[OnName num="eddie"]
"It seems I've kept you waiting, men!"
[cpg cn=true]

Morale was higher than ever. My men were ready to press the attack.
[cpg]

Seeing them makes me wonder why I ever felt any hesitation.
[cpg]

[OnName num="gil"]
"We love you too, boss."
[cpg cn=true]

[OnName num="eddie"]
"What? I didn't know you saw me like that."
[cpg cn=true]

[OnName num="gil"]
"You know I didn't mean it like that. We all love how ruthless you can be."
[cpg cn=true]

[OnName num="gil"]
"Just don't let your feelings make you treat a certain florist any differently."
[cpg cn=true]

[OnName num="eddie"]
"I know."
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


Rugalant was going down. We'd attack after nightfall.
[cpg]

It may seem sudden, but I don't think my men would be willing to wait for much longer.
[cpg]

What a bunch of hot-blooded bastards. I knew it, this is where I belong.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="fire1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="fire1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]
;//【ＢＧ】『荒野』（夜）******************************************************



[SE f="se024"]
;//【ＳＥ】『戦闘　剣を交える』


And so the battle began.
[cpg]

[OnName num="female_soldier"]
"My......body, I can't move."
[cpg cn=true]

[OnName num="female_soldier"]
"I......don't know why, but my body doesn't move like it should either!"
[cpg cn=true]

[OnName num="female_soldier"]
"What's going on? Did someone poison us?"
[cpg cn=true]

[OnName num="female_soldier"]
"Damn it, shake it off! We can't let them through!"
[cpg cn=true]

The female soldiers and the bandits clash.
[cpg]

[OnName num="female_soldier"]
"Aaaaah!"
[cpg cn=true]

[OnName num="female_soldier"]
"Get a hold of yourself! Damn it......"
[cpg cn=true]

[OnName num="bandit"]
"They sure seem...weaker than last time?"
[cpg cn=true]

[OnName num="bandit"]
"Yeah. I heard something about a magician betraying them."
[cpg cn=true]

[OnName num="bandit"]
"Hot damn, the boss sure knows how to pick 'em! Victory's on our side!"
[cpg cn=true]

The enemy had been weakened so thoroughly that the battle became entirely one-sided.
[cpg]

Apparently, Tina had cast a weakening magic on Rugalant's soldiers.
[cpg]

Their physical strength had been reduced just enough that they wouldn't notice.
[cpg]

Of course, Stella or Alicia may have realized what was going on, but......
[cpg]

They, too, are under my control.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


And in no time at all, the country was overrun.
[cpg]

The town, castle, tavern...everything in sight was sacked.
[cpg]

My men even went into the flower shop, looking for some coin.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『花屋』（朝）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Tina317"]
[OnName num="tina"]
"......Eddie...Eddie."
[cpg cn=true]

I found my men holding down Tina.
[cpg]

[OnName num="bandit"]
"Huh......? Do you know the boss?"
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Tina318"]
[OnName num="tina"]
"I know your boss...I know Eddie."
[cpg cn=true]

;//移植のためシーンをカットしています

[OnName num="eddie"]
"......Let her go, she's just a florist. There's nothing to steal here."
[cpg cn=true]

I left the flower shop and Tina alone.
[cpg]

I had nothing left to say. I'd already gotten too involved.
[cpg]

I had trained her too much, and it was now out of my hands.
[cpg]

She'll do whatever I say, but if I brought her with us, she'd be the end of me.
[cpg]

[OnName num="eddie"]
"Goodbye Tina. With luck, we'll never meet again."
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Tina340"]
[OnName num="tina"]
"......If you want me to wait, I'll wait. I'll always be here, waiting for you."
[cpg cn=true]

Damn it all......don't say anything more. Just let me be......
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


After taking all that we could, we left Rugalant behind.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『荒野』（夕方）******************************************************


I don't think we'll ever return. At least, not as long as Tina is around.
[cpg]

[OnName num="gil"]
"......Are you okay, boss? You look very gloomy."
[cpg cn=true]

[OnName num="eddie"]
"You're imagining it."
[cpg cn=true]

[OnName num="gil"]
"I hope so."
[cpg cn=true]

[OnName num="eddie"]
"Gil, since when did you get so damned high and mighty?"
[cpg cn=true]

[OnName num="eddie"]
"I'm the boss here, watch your tongue."
[cpg cn=true]

[OnName num="gil"]
"Well boss, when did you develop feelings?"
[cpg cn=true]

[OnName num="gil"]
"The boss I know wouldn't go out of his way to avoid a woman."
[cpg cn=true]

......Is this feeling...is this love?
[cpg]

Probably not. I'm sure it's not. Of course it's not.
[cpg]

Whatever it is, it's left its mark on me......a scar that never fades.
[cpg]

Was this part of Tina's plan ......?
[cpg]

[OnName num="gil"]
"Come on boss. There are plenty of women out there for the taking."
[cpg cn=true]


;//【ヒロイン３エンド】エンド
[SCENE id=14]

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////

