*start|Stella's Secret

;#################################################
*Ep004|Stella's Secret
;#################################################

[SCENE id=4]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]


The next morning ......
[cpg]

[window target=false]
[free time=1000]
[BG f="b_00_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『荒野』（朝）******************************************************


[OnName num="bandit"]
"Oh, boss! Are you back?"
[cpg cn=true]

[OnName num="bandit"]
"The boss is back! It's finally time to attack!"
[cpg cn=true]

[OnName num="eddie"]
"Hold your horses......it's still too early."
[cpg cn=true]

[OnName num="gil"]
"That's right, gentlemen. Keep your pants on."
[cpg cn=true]

I returned to camp to find the men quite restless.
[cpg]

[OnName num="bandit"]
"Then why did you come back!"
[cpg cn=true]

[OnName num="eddie"]
"I just wanted to let you know that the plan is underway."
[cpg cn=true]

[OnName num="bandit"]
"Does that mean that things have developed? What have you two been up to?"
[cpg cn=true]

[OnName num="eddie"]
"Yes, there was a development. I turned two women in the country into pawns."
[cpg cn=true]

[OnName num="bandit"]
"What? Only two ......?"
[cpg cn=true]

[OnName num="bandit"]
"You idiot! You can't talk like that to the boss."
[cpg cn=true]

Well, I can understand why he said that. But...
[cpg]

[OnName num="eddie"]
"Those two women will prove more useful than you lot. With them on our side, we'll be able to take that kingdom in one fell swoop."
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


There's a bit of distance between our hideout and the kingdom
[cpg]

It's tiring to make the trip back and forth, but I make the trek back to Rugalant and talk to Gil.
[cpg]

[OnName num="gil"]
"They sure are a hot-tempered bunch. There's no way we could have possibly set everything up so quickly."
[cpg cn=true]

[OnName num="eddie"]
"Well, as bandits, we're not exactly models of patience."
[cpg cn=true]

[OnName num="gil"]
"You aren't wrong."
[cpg cn=true]


[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

;//[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_se"]
;//[WAIT time=100]
;//【ＢＧ】『酒場』（昼）******************************************************



[FG f="CHA04_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Loose104"]
[OnName num="loose"]
"Oh......so you're......uh..."
[cpg cn=true]

Ruth looks puzzled. The tavern wasn't open yet.
[cpg]

It seems Ruth didn't know my name...now that I think about it, I don't believe we ever introduced ourselves.
[cpg]

[OnName num="eddie"]
"I guess we never introduced ourselves? I'm Eddie. Eddie Hales."
[cpg cn=true]

[OnName num="gil"]
"My name is Gil. Pleased to know you."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Loose105"]
[OnName num="loose"]
"Right......"
[cpg cn=true]

Ruth seems startled by Gil's polite way of introducing himself.
[cpg]

[OnName num="eddie"]
"So, what do you have for me?"
[cpg cn=true]

Ruth seemed puzzled again. I guess she didn't understand what I meant.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Loose106"]
[OnName num="loose"]
"What do you mean?"
[cpg cn=true]

[OnName num="eddie"]
"I want to know about what's going on with the military. You've heard something, I'm sure."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Loose107"]
[OnName num="loose"]
"I don't know anything about that......knights and soldiers might drop by every now and again, but......"
[cpg cn=true]

Ruth pauses, thinking to herself.
[cpg]

[OnName num="eddie"]
"What? Tell me."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Loose108"]
[OnName num="loose"]
"It's a really stupid rumor, but I did hear something..."
[cpg cn=true]

[OnName num="eddie"]
"Good. Tell me."
[cpg cn=true]

As I was getting impatient, Ruth began to talk.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Loose109"]
[OnName num="loose"]
"There's a general named Stella......and apparently she's in love with the princess."
[cpg cn=true]

Stella...a general in Rugalant's military...in love with her own princess?
[cpg]

......Did I mishear that?
[cpg]

[OnName num="eddie"]
"Did I mishear you? Stella is a man, right?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Loose110"]
[OnName num="loose"]
"No, Stella is a woman. The rumor is that she has unrequited feeling for the princess."
[cpg cn=true]

I see. Perhaps lesbians aren't uncommon in this country, but it's still a love affair between people of differing status.
[cpg]

[OnName num="eddie"]
"I can work with that......I just need find a weakness."
[cpg cn=true]

What kind of weakness could I exploit? I stop to think.
[cpg]


;//ＢＫ
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[OnName num="gil"]
"So, what are you going to do now?"
[cpg cn=true]

[OnName num="eddie"]
"I'm going to enlist Tina's help. Right now, she's willing to do whatever it takes."
[cpg cn=true]

[OnName num="gil"]
"But what does that entail?"
[cpg cn=true]

Gil seems worried about our prospects. He's got a lot of nerve to doubt me.
[cpg]

[OnName num="gil"]
"We should probably go after the general next, but there's no way we can get into the castle in the first place."
[cpg cn=true]

[OnName num="eddie"]
"I need to find out what Tina can do and plan our next move from there."
[cpg cn=true]

I headed for the flower shop.
[cpg]

As for Tina, we should rely on her as much as possible. We should use her as much as we can.
[cpg]


[SE f="se006"]
;//【ＳＥ】『入店音』

[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『花屋』（夕方）******************************************************

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

At the flower shop, Tina was tending to the store with a pensive expression on her face.
[cpg]

[OnName num="eddie"]
"We're baaaaack."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Tina168"]
[OnName num="tina"]
"What?"
[cpg cn=true]

Tina noticed our presence and reacted with a startle.
[cpg]

[OnName num="eddie"]
"You don't have to be afraid of us. We're just here to figure out how to get into the castle."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Tina169"]
[OnName num="tina"]
"Oh......right."
[cpg cn=true]

Her face changed to a questioning look as she wondered why we were trying to get into the castle.
[cpg]

I don't think I ever told her what our goals were, but maybe it was time.
[cpg]

It's not like she's going to betray us now. I should tell her. That way, Tina will know what to do.
[cpg]

[OnName num="eddie"]
"I'm going to go into the castle and make allies. I want you to help me with that."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Tina170"]
[OnName num="tina"]
"Are you trying to destroy this country......?"
[cpg cn=true]

[OnName num="eddie"]
"Yeah. I mean, are you actually okay with the kingdom as it is now?"
[cpg cn=true]

[OnName num="eddie"]
"If the kingdom falls, I bet you could find yourself a nice man to love you the way you want."
[cpg cn=true]

Tina blushed and turned her head away.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『住居寝室』（夜）******************************************************


We moved to the back room to discuss our options.
[cpg]

[OnName num="eddie"]
"I see......Invisibility and Transformation magic. That's good, real good."
[cpg cn=true]

Invisibility magic does exactly what it sounds like...it'll make sneaking into the castle a breeze.
[cpg]

I had never heard of such useful magic until she told me about it......
[cpg]

The fact that it's not well-known implies that it's difficult magic to perform.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Tina172"]
[OnName num="tina"]
"Invisibility spells are high-level magic, but I can do it."
[cpg cn=true]

[OnName num="gil"]
"I'm sure we can count on you. That will be great help."
[cpg cn=true]

Transformation magic allows one to take the appearance of another person.
[cpg]

Like Invisibility spells, it sounds like another difficult spell.
[cpg]

I could think of a few things to do with magic like that.
[cpg]

[OnName num="eddie"]
"I'm glad you've come around to cooperating with us. You made the right choice."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

I patted Tina on the head. She blushed and her body shook.
[cpg]

;//移植のためシーンをカットしています
;//ＢＫ


[OnName num="eddie"]
"It all starts here. What to do.....?"
[cpg cn=true]

[OnName num="gil"]
"We don't have a lot of time. Let's start immediately."
[cpg cn=true]

[OnName num="eddie"]
"......Alright."
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『宿屋寝室』（夜）******************************************************


We couldn't risk sleeping in Tina's room so we returned to the usual inn.
[cpg]

[OnName num="eddie"]
"......It's finally time to head behind enemy lines."
[cpg cn=true]

[OnName num="gil"]
"What are you talking about? We've been behind their lines since we entered the country."
[cpg cn=true]

Hm. I guess he had a point.
[cpg]

[OnName num="eddie"]
"You're right, Gil. I guess I'd better get my head in the right place."
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


Once our preparations had finished, I brought Gil and Tina with me to the castle.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Tina193"]
[OnName num="tina"]
"If we're going to use invisibility magic, I think we should do it in a back alley somewhere......"
[cpg cn=true]

[OnName num="eddie"]
"Good idea. Should we start now?"
[cpg cn=true]

After some discussion, we decided to go ahead and do it.
[cpg]



;//ＢＫ

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

A back alley near the castle.
[cpg]

Tina mumbled some sort of spell and our bodies were enveloped with a pale light.
[cpg]

[SE f="se020"]
;//【ＳＥ】『呪文』

[window target=false]
[transition target={true} rule="cube.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0xffffffff} time=1]
[WAIT time=1]
[transition target={true} rule="cube.webp" color={0xffffffff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//小さな丸い光がいくつか舞っているような感じにできたらお願いします

;//【ＢＧ】『街』（朝）******************************************************


;//ここから、ティナの立ち絵を消してください


[OnName num="eddie"]
"......Where are you, Gil?"
[cpg cn=true]

[OnName num="gil"]
"Here, here."
[cpg cn=true]

We couldn't locate each other without speaking out loud. That could be a problem.
[cpg]

[OnName num="eddie"]
"......Alright, we're going to have to hold hands and walk in a line."
[cpg cn=true]

[OnName num="gil"]
"Got it, boss."
[cpg cn=true]

This was more inconvenient than I'd thought it would be......we probably should have tested the effects of the spell beforehand.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]

There were heavily armored sentries posted by the gate, but it was open for the time being.
[cpg]

I guess they thought guards were enough.
[cpg]

Whatever the case, we were able to enter the castle with ease.
[cpg]

I'm sure people heard our footsteps, but nobody seemed to think of it as suspicious.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城内の一室』（昼）******************************************************


[OnName num="eddie"]
"I can't believe we got through the front door. This country must be really peaceful."
[cpg cn=true]

[OnName num="gil"]
"No kidding. So, what's the plan?"
[cpg cn=true]

[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Tina194"]
[OnName num="tina"]
"I have been invited to this castle several times. I know the general layout of the rooms."
[cpg cn=true]

Oh, right, Tina works with the military every now and again.
[cpg]

Hold on, that wasn't the problem. If I'd known that, we could have made a plan before we entered the castle?
[cpg]

[OnName num="eddie"]
"Why didn't you say so from the beginning?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tina195"]
[OnName num="tina"]
"I'm sorry......"
[cpg cn=true]

[OnName num="gil"]
"Well, that's all right. It's not like we're going to be stuck here."
[cpg cn=true]

We discussed the plan in a storage room that didn't seem like it got a lot of use.
[cpg]

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城内の一室』（夕方）******************************************************


General Stella ..... or whatever her name was.
[cpg]

It took us a while to locate where she was, or rather, where she lived.
[cpg]

[OnName num="gil"]
"I think that's her......"
[cpg cn=true]

Gil spoke in a whisper. Even if we could find Stella she was soon gone out of our sight.
[cpg]

She must be a busy person. We frequently lost sight of her.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


Eventually, we finally identified where her quarters were.
[cpg]

I could hear her voice, but I was sure she was alone...
[cpg]

Indeed, she was talking to herself. She laments her unrequited feelings for Princess Alicia.
[cpg]

;//移植のためシーンをカットしています

[SE f="se011"]
;//【ＳＥ】『ドアゆっくり開く』


We slowly opened the door and left.
[cpg]

She might die of embarrassment if she'd known that we'd overheard everything she said.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


[VOICE f="Stella023"]
[OnName num="stella"]
"Oh, Princess Alicia......I can't take my mind off you......"
[cpg cn=true]

[VOICE f="sStella001"]
[OnName num="stella"]
"What am I to do with these feelings?"
[cpg cn=true]

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城内の一室』（夜）******************************************************

[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

We went back to the storage room.
[cpg]

It was difficult to have a conversation while we were invisible.
[cpg]

We can't even talk if somebody was near......
[cpg]

[OnName num="eddie"]
"We can talk freely here. So, about what we're going to do."
[cpg cn=true]

[OnName num="eddie"]
"I suppose I could transform myself into Alicia and hold the cochlea stone hidden in my hand?"
[cpg cn=true]

[OnName num="gil"]
"You're right. Then Stella might slip up."
[cpg cn=true]

[OnName num="eddie"]
"Unlike Ruth, we'll need more than just a recording."
[cpg cn=true]

[OnName num="gil"]
"Why not?"
[cpg cn=true]

[OnName num="eddie"]
"You have to think of her like she's a man. In which case, a recording wouldn't make for much of a threat."
[cpg cn=true]

[OnName num="eddie"]
"And she's patriotic, to boot. She won't go down as easily as Ruth."
[cpg cn=true]

I thought it was a great idea. But Tina has a grim look on her face. I wondered why.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tina196"]
[OnName num="tina"]
"The magic of transformation requires the hair or blood of the person. Otherwise, you can't transform perfectly."
[cpg cn=true]

[OnName num="eddie"]
"Then why don't we go pick it up?"
[cpg cn=true]


;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『姫の寝室』（夜）******************************************************


[VOICE f="Alicia007"]
[OnName num="alicia"]
"Zzzzz......"
[cpg cn=true]

Finding Alicia's chambers was much easier than finding Stella's quarters.
[cpg]

However, it was a little difficult to make it inside because of how many people were around.
[cpg]

We should have looked around after dark, when people had already gone to sleep.
[cpg]

Then they wouldn't be suspicious when we opened the door.
[cpg]


[VOICE f="Alicia008"]
[OnName num="alicia"]
"Hmmm......Mmhh."
[cpg cn=true]

It would be easier to take some hair from her directly rather than look around on the floor.
[cpg]

I cut one strand off halfway. I couldn't risk her waking up if I ripped one out at the root.
[cpg]

[OnName num="eddie"]
"There we go."
[cpg cn=true]

Then I decide to leave. Just wait for me, Princess.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内の一室』（夜）******************************************************

;//ここからエディがアリシアに変身しています。アリシアの立ち絵を表示してください
;//ここからアリシアの名前欄を「アリシア（エディ）」と書き換えてください


[OnName num="gil"]
"......That's impressive. If I didn't know any better, I'd think you were the real deal."
[cpg cn=true]

I felt as if Gil was staring at me. Even though I couldn't see him, I sensed such a presence.
[cpg]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Alicia009"]
[OnName num="alicia(eddie)"]
"If you cop a feel, I'm leaving you for dead."
[cpg cn=true]

Creeped out, I made it clear that I wasn't going to tolerate any fooling around.
[cpg]

[OnName num="gil"]
"I'd never...it's you insider there, right boss?"
[cpg cn=true]

Still invisible, Gil defends himself.
[cpg]

[FACE method="bow_1" pos="2/5"]
[VOICE f="Alicia010"]
[OnName num="alicia(eddie)"]
"Good. Then you two are coming with me."
[cpg cn=true]

[OnName num="gil"]
"What? I'm sure you'll be fine alone."
[cpg cn=true]

Gil was surprised, but I had an idea how this was going to go.
[cpg]

[FACE method="change_2" pos="2/5"]
[VOICE f="Alicia011"]
[OnName num="alicia(eddie)"]
"It's always better to outnumber your opponent."
;//。いざって時に、ティナは絶対必要だしな」後半部分のボイスが足りない
[cpg cn=true]

[FACE method="bow_7" pos="4/5"]
[VOICE f="Tina197"]
[OnName num="tina"]
".....Can't argue with that."
[cpg cn=true]

;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城内の一室』（夜）******************************************************



[VOICE f="sStella002"]
[OnName num="stella"]
"......Princess? What brings you hear at this hour?"
[cpg cn=true]

[FACE method="bow_7" pos="4/5"]
[VOICE f="sAlicia001"]
[OnName num="alicia(eddie)"]
"Yes. I wanted to talk to you about something. I heard a rumor that you harbored feelings for me..."
[cpg cn=true]

[FACE method="shock_5" pos="2/5"]
[VOICE f="sStella003"]
[OnName num="stella"]
"......!"
[cpg cn=true]

Stella looks at me in surprise, but quickly shakes her head.
[cpg]

[FACE method="shake_4" pos="2/5"]
[VOICE f="sStella004"]
[OnName num="stella"]
"That's not true......I ..... well."
[cpg cn=true]

[FACE method="shake_2" pos="4/5"]
[VOICE f="Alicia015"]
[OnName num="alicia(eddie)"]
"You don't have to hide it. I also like you Stella."
[cpg cn=true]

I had to gauge her reaction. It was related to the strategy I'd come up with earlier.
[cpg]

[FACE method="bow_6" pos="4/5"]
[VOICE f="Alicia016"]
[OnName num="alicia(eddie)"]
"I'm glad to hear that you think of me that way."
[cpg cn=true]

[FACE method="shock_5" pos="2/5"]
[VOICE f="Stella044"]
[OnName num="stella"]
"Truly? Then...then......"
[cpg cn=true]

[FACE method="bow_6" pos="4/5"]
[VOICE f="Alicia017"]
[OnName num="alicia(eddie)"]
"Yes. Your desires are coming to fruition, Stella."
[cpg cn=true]


;//========================================
;//●ＣＧエロ（ヒロイン１の姿をしている主人公が、ヒロイン２に近づく）ev_19
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：ヒロイン１（正体は主人公）
;//服装２：ドレス
;//場所　：城寝室
;//時間　：夜
;//========================================
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


;//移植のためシーンをカットしています


[VOICE f="Alicia026"]
[OnName num="alicia(eddie)"]
"But our positions are not so easily overcome."
[cpg cn=true]

[VOICE f="Alicia027"]
[OnName num="alicia(eddie)"]
"We can't be together like this......"
[cpg cn=true]

That's good, one more step and I'll have what I need to put her in a weak position.
[cpg]

Just a little bit more.
[cpg]

[VOICE f="Alicia028"]
[OnName num="alicia(eddie)"]
"Are you willing to throw away everything in order to be with me?"
[cpg cn=true]

[VOICE f="Stella057"]
[OnName num="stella"]
"Yes! Yes, of course."
[cpg cn=true]

[VOICE f="Alicia029"]
[OnName num="alicia(eddie)"]
"I see. So you are willing to give up on Rugalant for my sake?"
[cpg cn=true]

That's good progress, just a little bit more.
[cpg]

[VOICE f="Stella058"]
[OnName num="stella"]
"I have no attachments to the kingdom."
[cpg cn=true]

[VOICE f="Stella059"]
[OnName num="stella"]
"If I have you by my side, I could leave these lands this very night!"
[cpg cn=true]

[VOICE f="Alicia030"]
[OnName num="alicia(eddie)"]
"Hmph......haha...hahahahaha!"
[cpg cn=true]

She's so easily manipulated that I couldn't stop myself from laughing.
[cpg]



;//アリシアの立ち絵を光らせた後、消してください
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="bakuhatu2.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu2.webp" color={0xffffffff} time=1]
[WAIT time=1100]

;//========================================
;//●ＣＧエロ（振り返りながら驚いているヒロイン）ev_20
;//人物１：ヒロイン２
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：城寝室
;//時間　：夜
;//========================================

;//[BGM f="bg_se"]
;**【ＣＧ】 ev_20_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//ここから、アリシアの名前欄を通常通り表記してください



[OnName num="eddie"]
"Me? I'm Eddie. And this is Gil, and Tina......you already know."
[cpg cn=true]

At least I got some good information out of her.
[cpg]

[OnName num="eddie"]
"So, the great general of Rugalant has no attachments to the kingdom she serves. I wonder what would happen if somebody had overheard that little remark."
[cpg cn=true]

[OnName num="eddie"]
"I bet you'd lose everything. You might even get exiled."
[cpg cn=true]

[VOICE f="Stella061"]
[OnName num="stella"]
"Wha- What is this trickery!?"
[cpg cn=true]

[OnName num="gil"]
"Figure it out."
[cpg cn=true]

Gil shows her the cochlea stone.
[cpg]

Stella seems to know what it is. She turns pale.
[cpg]

[OnName num="eddie"]
"Besides, you've told me all about your feelings for Alicia."
[cpg cn=true]

[OnName num="eddie"]
"Seeing as you've approached the princess with ulterior motives, it seems a clear choice to separate the two of you."
[cpg cn=true]

People would worry that she might act upon her...urges.
[cpg]

No one would want to keep such a dangerous person in the same castle as their precious princess.
[cpg]

[VOICE f="Stella062"]
[OnName num="stella"]
"Are you trying to threaten me? For what purpose......"
[cpg cn=true]

;//移植のためシーンをカットしています

Well, what to do? I have enough material to threaten her ......
[cpg]

;//※ヒロイン２選択肢発生、と書いてある部分を通っていなければ選択肢は発生せず
;//　選択肢２を選んだことになる

[if exp={getFlagValue("FirstSelect") == 2 }]
[jump target=*select02_0]
[endif]
[jump target=*select02_2]

*select02_0

;//■選択肢
[switch]
[case "Push her further."]
	[swap]
	[jump target="*select02_1"]
[case "It's time to pull back."]
	[swap]
	[jump target="*select02_2"]
[endswitch]

1. Push her further.
2. It's time to pull back.



;//==============================
;//１、更に追い詰める
*select02_1|Stella's Secret

;//（ヒロイン２ポイント増加）
[stflag Cha2flg = 1]

[OnName num="eddie"]
"I don't have to tell you anything. But you...well, you're going to have to do whatever I say, when I say it."
[cpg cn=true]

[VOICE f="sStella005"]
[OnName num="stella"]
"No......"
[cpg cn=true]

Stella's eyes well up with tears. I've cornered her now.
[cpg]

But it's a good thing she understands her situation quickly.
[cpg]

[OnName num="eddie"]
"You belong to me now. Prepare yourself."
[cpg cn=true]


;//移植のためシーンをカットしています


[jump target=*select02_3]
;//==============================
;//２、やめておく
*select02_2|Stella's Secret.


No, I've done enough for now.
[cpg]

If I overstep, I could lose everything.
[cpg]


;//==============================
*select02_3|Stella's Secret


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『城内の一室』（夜）******************************************************


[OnName num="eddie"]
"Don't go looking for us or do anything stupid. We'll be watching."
[cpg cn=true]

[FACE method="shake_4" pos="2/5"]
[VOICE f="Stella106"]
[OnName num="stella"]
"......Wait a minute. If I don't do anything, do you promise to keep quiet about Princess Alicia?"
[cpg cn=true]

[OnName num="eddie"]
"That depends on how obedient you are. Tina."
[cpg cn=true]

Tina nodded and cast an invisibility spell on us.
[cpg]


;//小さな丸い光がいくつか舞っているような感じにできたらお願いします

[SE f="se020"]
;//【ＳＥ】『呪文』

[window target=false]
[transition target={true} rule="cube.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0xffffffff} time=1]
[WAIT time=1]
[transition target={true} rule="cube.webp" color={0xffffffff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[FACE method="change_5" pos="2/3"]

To Stella, it looked as if we suddenly disappeared.
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Stella107"]
[OnName num="stella"]
"......Teleportation magic? Impossible....."
[cpg cn=true]

Unfortunately, we don't have anything that useful.
[cpg]

Actually, I wouldn't put anything past Tina anymore...I don't understand how a magician of her caliber could run a flower shop.
[cpg]

Maybe she's just trying to make money without using magic.
[cpg]

Perhaps she associates magic with killing people and tries avoid it as much as possible.
[cpg]




[jump storage="ep005.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

