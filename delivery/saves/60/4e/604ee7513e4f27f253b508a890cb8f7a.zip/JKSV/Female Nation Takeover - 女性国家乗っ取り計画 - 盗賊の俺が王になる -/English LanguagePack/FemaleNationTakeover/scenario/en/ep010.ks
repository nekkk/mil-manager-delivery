

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//『ヒロイン４エンド』（ヒロイン４ポイントが４度増加している場合）
*Ending_hiroin4|Ruth's Tavern

*start|Ruth's Tavern

;#################################################
*Ep010|Ruth's Tavern
;#################################################

[SCENE id=10]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『宿屋寝室』（朝）******************************************************


I'd decided to turn Ruth into my pawn and I think I did a good job.
[cpg]

But I wasn't sure it was enough. There's only so much one tavern owner can do.
[cpg]

Tina and Stella were obedient enough, with their cooperation, we'd still hold the upper hand......
[cpg]

[OnName num="gil"]
"Are you still worried Boss?"
[cpg cn=true]

[OnName num="eddie"]
"A little bit. Should we go back and remind her who's in charge?"
[cpg cn=true]

[OnName num="gil"]
"Whatever you think is best, Boss. I'll just follow your lead."
[cpg cn=true]

Then there was only one thing to do. I had to eliminate the source of my worries.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



[SE f="se001"]
;//【ＳＥ】『歩く』


I left the inn and walked into town.
[cpg]

Naturally, the tavern wasn't open. In fact, it seemed like it just closed.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『酒場』（朝）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Loose268"]
[OnName num="loose"]
"......You again. What do you want this time?"
[cpg cn=true]

[OnName num="eddie"]
"When do you sleep? Or are you always up all night?"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Loose269"]
[OnName num="loose"]
"What's it to you? And you still haven't answered my question."
[cpg cn=true]

[OnName num="eddie"]
"I just wanted to make sure you were following my instructions.."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Loose270"]
[OnName num="loose"]
"You're persistent...... Don't worry so much, I will."
[cpg cn=true]

Surely she would obey my orders. But Ruth had a somewhat distant look in her eyes.
[cpg]

[OnName num="eddie"]
"What's wrong? Is there something on your mind?"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Loose271"]
[OnName num="loose"]
"Yes......if bandits attack Rugalant and somehow come out victorious, then......"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Loose272"]
[OnName num="loose"]
"I don't see how I'd be able to keep this tavern in business."
[cpg cn=true]

[OnName num="eddie"]
"You'd still have the same problem if I were to scatter cochineal stones all over the place."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Loose273"]
[OnName num="loose"]
"Yes, you're absolutely right."
[cpg cn=true]

She sits down, a pensive look on her face.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Loose274"]
[OnName num="loose"]
"This place has been in my family for generations. I never thought it would end with me."
[cpg cn=true]

[OnName num="eddie"]
"So it's the same thing anyway, right?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Loose275"]
[OnName num="loose"]
"I know, I know, but it's just......"
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[OnName num="gil"]
"How did it go?"
[cpg cn=true]

Gil had been waiting outside for me.
[cpg]

[OnName num="eddie"]
"I don't think it's going to work out like I planned. We should try to get the others to cooperate."
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


We went around to make sure the others hadn't shown any signs of betraying us.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se006"]
;//【ＳＥ】『入店音』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『花屋』（昼）******************************************************


[OnName num="gil"]
"So, I want you to attack the Rugalant forces from inside if you can."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Tina341"]
[OnName num="tina"]
"......Okay. I should be able to cast a few spells to keep the others from noticing."
[cpg cn=true]

[OnName num="eddie"]
"I'm counting on you, Tina."
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城内の一室』（昼）******************************************************


[OnName num="gil"]
"I'd like to know about the placement of your soldiers ahead of time and the tactics they'll be using."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Stella293"]
[OnName num="stella"]
"Right......I could probably make focus them on a single direction so they don't notice your approach."
[cpg cn=true]

[OnName num="eddie"]
"Whatever, as long as it works."
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


[OnName num="eddie"]
"......That should do it."
[cpg cn=true]

[OnName num="gil"]
"Yeah."
[cpg cn=true]

[OnName num="eddie"]
"Now all we have to do is meet up with the men at the camp."
[cpg cn=true]

[OnName num="gil"]
"Right, let's head out."
[cpg cn=true]

I wonder if Ruth will make the right move.
[cpg]

It would take at least a day to get the false information out there.
[cpg]

I'll have to keep my men from attacking for at least a day.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『荒野』（昼）******************************************************


[OnName num="gil"]
"It's almost time to leave this country."
[cpg cn=true]

[OnName num="eddie"]
"The next time we're there, we'll be sacking the place."
[cpg cn=true]

[OnName num="gil"]
"Yeah, I'm looking forward to it."
[cpg cn=true]

[OnName num="gil"]
"Once we take care of the army, we can have all the women we want."
[cpg cn=true]

[OnName num="eddie"]
"It always comes down to that with you doesn't it?"
[cpg cn=true]

[OnName num="gil"]
"Come on, boss! You know you enjoy it too."
[cpg cn=true]

We walked through the wilderness while joking around.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』


After a while, we can finally see the camp.
[cpg]

We'd lost a lot of men, but there were still quite a few of us left.
[cpg]

[OnName num="eddie"]
"Guess who's back, boys! We attack tomorrow."
[cpg cn=true]

[OnName num="bandit"]
"Boss! Look, the boss is back!"
[cpg cn=true]

[OnName num="bandit"]
"I'm glad you're safe......we were starting to get worried!"
[cpg cn=true]

[OnName num="bandit"]
"Come on guys! Get ready to launch the attack!"
[cpg cn=true]

[OnName num="eddie"]
"I said tomorrow......"
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


It was hard to convince them not to attack immediately.
[cpg]

I'm glad to see their morale was high, but it could be a real problem if they don't listen to me.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『荒野』（夕方）******************************************************


[OnName num="bandit"]
"Why tomorrow? Why not today?"
[cpg cn=true]

[OnName num="bandit"]
"Yeah! Our fallen brothers cry for vengeance......"
[cpg cn=true]

[OnName num="eddie"]
"I told you to hold your damn horses, I've got a plan. We have an ally on the inside, but she needs time to do her job."
[cpg cn=true]

[OnName num="bandit"]
"But......"
[cpg cn=true]

[OnName num="gil"]
"Boys, when has the boss ever led us wrong?"
[cpg cn=true]

[OnName num="gil"]
"Everything will be find, just trust in the boss and his plan."
[cpg cn=true]

[OnName num="bandit"]
"......"
[cpg cn=true]

I think I managed to convince half of them, but a few seem like they're about to go off the rails.
[cpg]

[OnName num="eddie"]
"Listen up, boys. I know how frustrating it is to lose your friends."
[cpg cn=true]

[OnName num="eddie"]
"That's why you can understand why I can't afford to lose the rest of you."
[cpg cn=true]

[OnName num="eddie"]
"Just be patient for a little while longer and I promise that we'll make it out alright."
[cpg cn=true]

[OnName num="bandit"]
"......Yeah...the boss is right."
[cpg cn=true]

[OnName num="bandit"]
"Just because we're bandits doesn't mean we're fools."
[cpg cn=true]

[OnName num="bandit"]
"This time, we're going to bring that country down!"
[cpg cn=true]

All I did was rephrase what I said earlier...I don't know whether I should be glad or pity them for being this dumb.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『荒野』（夜）******************************************************


And so the night passes......
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_00_1.ui" time=1000]
[WAIT time=3000]
[BG f="b_00_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

Morning passes, noon passes.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_00_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『荒野』（夕方）******************************************************


[OnName num="bandit"]
"I can't take it anymore, we're going to run out of food eventually!"
[cpg cn=true]

[OnName num="bandit"]
"Let's go, boss! Now is the time to invade."
[cpg cn=true]

They were at their limit, I couldn't stall any longer.
[cpg]

[OnName num="eddie"]
"Alright, let's head out."
[cpg cn=true]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="fire1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="fire1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="fire1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="fire1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]


A cheer erupts throughout the camp and we set out to invade Rugalant.
[cpg]

Stella and Tina seemed to be doing their jobs.
[cpg]

[OnName num="female_soldier"]
"I thought they weren't going to attack us again!"
[cpg cn=true]

[OnName num="female_soldier"]
"I don't know! I never heard anything about that!"
[cpg cn=true]

[OnName num="female_soldier"]
"Someone betrayed us! Aaagh!"
[cpg cn=true]

[OnName num="bandit"]
"Too easy! How did we lose last time?"
[cpg cn=true]

[OnName num="bandit"]
"They have a lot of traitors on their side! It would be sad if we weren't winning!"
[cpg cn=true]

[OnName num="bandit"]
"No doubt! I bet they're regretting making an enemy out of the boss!"
[cpg cn=true]

[OnName num="female_soldier"]
"Push them back! We can't let them pass!"
[cpg cn=true]

[OnName num="female_soldier"]
"They're cutting us down! We can't hold on for much longer!"
[cpg cn=true]

[OnName num="female_soldier"]
"Damn it, is this the end......?"
[cpg cn=true]

It seems that Ruth had done her job.
[cpg]

We'd taken the army by surprise.
[cpg]

It seems that someone spread a rumor that the bandits had given up on Rugalant.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



[SE f="se024"]
;//【ＳＥ】『戦闘　剣を交える』


[OnName num="woman"]
"No! Nooooo!!"
[cpg cn=true]

[OnName num="woman"]
"Blood! Aaaaaghh!"
[cpg cn=true]

[OnName num="woman"]
"Somebody help me, I don't want to die!"
[cpg cn=true]

As the screams boiled over, I got somewhat curious......
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『酒場』（夜）******************************************************


I poked my head into the tavern to find several women hiding there......
[cpg]

[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Loose276"]
[OnName num="loose"]
"......"
[cpg cn=true]

Ruth looks up at me, blankly.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The sacking of Rugalant continued well into the next morning.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


All through the night, the bandits roamed the streets, stealing anything of value and cutting down anybody who dared resist.
[cpg]

[OnName num="woman"]
"I thought the bandits weren't going to attack......?"
[cpg cn=true]

[OnName num="woman"]
"Someone must have spread false rumors."
[cpg cn=true]

[OnName num="woman"]
"Who in the world would do such a thing......? What would they possibly stand to gain?"
[cpg cn=true]

The country was in turmoil. It seems that Ruth's "false information" was the deciding factor.
[cpg]

I guess I'd have to reward her for her efforts.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『酒場』（朝）******************************************************


[OnName num="eddie"]
"Ruth, are you in there? Good work."
[cpg cn=true]

[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Loose277"]
[OnName num="loose"]
"......I just did what you told me to do."
[cpg cn=true]

[OnName num="eddie"]
"You did good, it was a lot easier to attack than I thought."
[cpg cn=true]

[OnName num="woman"]
"What did he say!?"
[cpg cn=true]

[OnName num="woman"]
"Did Ruth betray us!?"
[cpg cn=true]

[OnName num="woman"]
"I can't believe it......! You destroyed our country!"
[cpg cn=true]

Ruth has a complicated look on her face.
[cpg]

She is not being treated like an animal like the other women.
[cpg]

That said, she is still a traitor. The other women must surely despise her.
[cpg]

;//========================================
;//●ＣＧエロ（崩れ落ちるヒロイン。涙目になっている）ev_49
;//人物１：ヒロイン４
;//服装１：私服
;//場所　：酒場
;//時間　：朝
;//========================================
;//[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_49_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

Ruth falls to her knees and doesn't even look at me.
[cpg]

[VOICE f="sLoose016"]
[OnName num="loose"]
"......Was this the right choice?"
[cpg cn=true]

There was still hesitation in her.
[cpg]

She looks like she's seeing a dream.
[cpg]

It seems like this strategy had been quite the gamble.
[cpg]

;//移植のためシーンをカットしています


;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_se"]
;//[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


Ruth takes me by the hand and leads me out of the tavern. It must have been hard for her to see everything she worked for destroyed.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Loose299"]
[OnName num="loose"]
"......What should I have done? Should I have refused?"
[cpg cn=true]

Ruth looked nostalgic for the past. Although it wasn't that long ago.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Loose300"]
[OnName num="loose"]
"Maybe then I wouldn't have had to suffer through all of that."
[cpg cn=true]

[OnName num="eddie"]
"What other choices did you have?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Loose301"]
[OnName num="loose"]
"I could have told the people of the castle that you were going to invade."
[cpg cn=true]

I see. Well, that would have been a problem. We probably wouldn't have won.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Loose302"]
[OnName num="loose"]
"Maybe then the soldiers could have fought you off."
[cpg cn=true]

[OnName num="eddie"]
"Maybe. But I'd be furious."
[cpg cn=true]

[OnName num="eddie"]
"I know you love this place more than anything else and I'd do everything in my power to destroy it."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Loose303"]
[OnName num="loose"]
"......"
[cpg cn=true]

[OnName num="eddie"]
"You saved your tavern."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Loose304"]
[OnName num="loose"]
"Did I? I'm not sure anymore......"
[cpg cn=true]

Ruth looks up at the sign.
[cpg]

Tina and Stella probably felt something similar to what Ruth was feeling right now.
[cpg]

[OnName num="eddie"]
"Don't worry, I'll keep your mind off things."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="sLoose017"]
[OnName num="loose"]
"Please......make me believe that this is normal......"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="sLoose018"]
[OnName num="loose"]
"That having things broken and lost......is normal."
[cpg cn=true]


;//【ヒロイン４エンド】エンド
[SCENE id=15]

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////

