*start|Down with the Crown

;#################################################
*Ep005|Down with the Crown
;#################################################

[SCENE id=5]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]



We make it back to town.
[cpg]

Gil and I head back to the inn after seeing Tina home.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『宿屋寝室』（夜）******************************************************


We'd spent quite a bit of time in this inn now, but the innkeep didn't seem to suspect us at all.
[cpg]

We've finally made a foothold in the castle...
[cpg]

But there was still more to do.
[cpg]

In the end, we still have to do something about Alicia.
[cpg]

[OnName num="eddie"]
"It's going to be harder to blackmail Alicia compared to the others."
[cpg cn=true]

;//[OnName num="eddie"]「何か方法はないか？　ステラを脅すのはルースを脅すより難しいが」[cpg cn=true]
;//[OnName num="eddie"]「アリシアを脅すのはステラを脅すより難しいぞ」[cpg cn=true]


Gil nods in agreement.
[cpg]

[OnName num="gil"]
"I agree. If she has a weakness, she'd likely discuss it with her advisors."
[cpg cn=true]

The more noble your status is, the less likely you are to be vulnerable to simple blackmail.
[cpg]

With Ruth a lighthearted threat might do enough damage to destroy her business.
[cpg]

On the other hand, if we threatened Alicia and recorded her......
[cpg]

The people would simply pity her and the sentiment towards us would shift to hatred and anger.
[cpg]

I can only see one way to get her to submit.
[cpg]

[OnName num="eddie"]
"We're going to need Stella's cooperation."
[cpg cn=true]

Stella feelings for Alicia were considerable, to say the least. She might have a good idea.
[cpg]

[OnName num="gil"]
"Do you think she'll be of any help? I can't imagine Stella having anything we could use on the princess."
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[OnName num="eddie"]
"Either way. Let's go, Tina."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tina202"]
[OnName num="tina"]
"...Are you going to enter the castle again? How are you planning on threatening Princess Alicia?"
[cpg cn=true]

[OnName num="gil"]
"I'll figure it out after we get in, we don't even know what Stella can do yet."
[cpg cn=true]

Tina seemed a little taken aback. Sorry, even I don't have all the answers...yet.
[cpg]


;//ＢＫ


We used the invisibility magic again to hide our appearance and make our way to the castle.
[cpg]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="4/5" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城内の一室』（昼）******************************************************


I am more familiar with the structure of the castle than before.
[cpg]

During the day, Stella was in her quarters. I suspect this was her room and she was on break.
[cpg]

[OnName num="eddie"]
"Hello, Stella."
[cpg cn=true]

I show myself and call out to her.
[cpg]

[FACE method="shock_5" pos="4/5"]
[VOICE f="Stella108"]
[OnName num="stella"]
"What!? It's you......!"
[cpg cn=true]

She'd scrambled to draw her sword in surprise. Someone was feeling a little jumpy.
[cpg]

[OnName num="eddie"]
"Sheathe that steel if you know what's good for you."
[cpg cn=true]

It's not directly related, but it's in our best interest to make Stella listen to us, since we're going to threaten Alicia.
[cpg]

[FACE method="change_3" pos="4/5"]
[VOICE f="sStella006"]
[OnName num="stella"]
"Ugh......You're doing this......just because you know my weakness."
[cpg cn=true]

;//移植のためシーンをカットしています

I decide to explain part of my plan to Stella.
[cpg]

[OnName num="eddie"]
"I intend to take Alicia down, eventually."
[cpg cn=true]

Stella looked surprised. Then she looked away. What kind of emotion was that in her eyes?
[cpg]

[OnName num="eddie"]
"Do you have any bright ideas? Anything you can think of works, just tell me."
[cpg cn=true]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Stella130"]
[OnName num="stella"]
"What's in it for me if I do that?......"
[cpg cn=true]

She makes a good point. If the kingdom collapses, her position won't matter much.
[cpg]

In other words, her weakness ceases to be a weakness. However...
[cpg]

[OnName num="eddie"]
"Obey us and we'll keep your little secrets......"
[cpg cn=true]

[OnName num="eddie"]
"And once this country falls into our hands, you get to survive unscathed."
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[VOICE f="Stella131"]
[OnName num="stella"]
"......Talk is cheap and I have little reason to trust you."
[cpg cn=true]

I have a few more cards in my deck, or rather, I can say what Stella wants to hear.
[cpg]

[OnName num="eddie"]
"I can make Alicia yours, too. You'd like that, wouldn't you?"
[cpg cn=true]

[FACE method="shock_5" pos="4/5"]
Stella's eyes betray her true feelings.
[cpg]

She stutters as she say "I don't know......".  I knew it.
[cpg]

Stella wants Alicia, no matter what it takes.
[cpg]

Perhaps that pleasure is clouding her judgment.
[cpg]

Finally, Stella spoke up. A method that could be used to bend Alicia to our will.
[cpg]

[FACE method="bow_7" pos="4/5"]
[VOICE f="Stella132"]
[OnName num="stella"]
"There's a poison......the conqueror's poison, as I recall."
[cpg cn=true]

[FACE method="shock_5" pos="2/5"]
Conqueror's poison? Never heard of it, but Tina was surprised.
[cpg]

[FACE method="shake_5" pos="2/5"]
[VOICE f="Tina203"]
[OnName num="tina"]
"Really......! How did you get such a rare thing?"
[cpg cn=true]

[OnName num="eddie"]
"Wait, what is this poison? I've never heard of it."
[cpg cn=true]

[FACE method="bow_3" pos="2/5"]
[VOICE f="Tina204"]
[OnName num="tina"]
"It's a poison made with magic. Once it enters the body, it permanently binds itself to the victim."
[cpg cn=true]

So it's not poison in the literal sense of the word. Was there anything that magic couldn't do?
[cpg]

[FACE method="bow_7" pos="4/5"]
[VOICE f="Stella133"]
[OnName num="stella"]
"Yes...... And if you put magic power into it, you can activate the poison from a distance."
[cpg cn=true]

[FACE method="shake_4" pos="4/5"]
[VOICE f="Stella134"]
[OnName num="stella"]
"A small amount of magic will cause a temporarily paralysis...more than that and it becomes fatal......"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[VOICE f="Tina205"]
[OnName num="tina"]
"Can you use that magic?"
[cpg cn=true]

This was important. Otherwise, why have such a dangerous thing lying around?
[cpg]

[FACE method="bow_7" pos="4/5"]
[VOICE f="Stella135"]
[OnName num="stella"]
"I can't use it. That's why I've been holding on to it for so long."
[cpg cn=true]

It seems that Stella didn't have the capacity to use such an item.
[cpg]

In short, it's a bomb in your body that can be remotely controlled......It's a good way to scare somebody, but...
[cpg]

[OnName num="gil"]
"You're a real piece of work, aren't you?"
[cpg cn=true]

[OnName num="gil"]
"I'd wager you've been thinking about how to make the princess yours for a while now."
[cpg cn=true]

[FACE method="change_6" pos="4/5"]
Stella goes silent. She stares at the ground, blushing slightly.
[cpg]

Her affections for the princess were twisted, at best. I take the bottle from her.
[cpg]

It was a small bottle. Invisibility magic would make it easy to conceal.
[cpg]

We could make the liquid transparent and mix it in with Alicia's food.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I had the poison placed into Alicia's next meal.
[cpg]

The process itself was very smooth. I thought there might be a change in taste, but Stella had done her research properly.
[cpg]

Apparently, it is an odorless and tasteless poison. How terrifying.
[cpg]

Since I had never heard of it, it must be very rare and expensive.
[cpg]

I wonder how Stella got her hands on a bottle, but...she was nothing, if not persistent.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『姫の寝室』（夜）******************************************************



That night, before the princess had gone to sleep.
[cpg]

She was reading in a dress, rather than pajamas.
[cpg]

There was no need to hide anymore. We reveal ourselves in front of Alicia.
[cpg]

[OnName num="eddie"]
"Reading at this hour, princess?"
[cpg cn=true]


[SE f="se020"]
;//【ＳＥ】『呪文』

[window target=false]
[transition target={true} rule="cube.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0xffffffff} time=1]
[WAIT time=1]
[transition target={true} rule="cube.webp" color={0xffffffff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Alicia jolts at our sudden appearance. It was a natural reaction.
[cpg]

[FACE method="shock_5" pos="2/5"]
[VOICE f="Alicia031"]
[OnName num="alicia"]
"What?......Huh?"
[cpg cn=true]

[OnName num="eddie"]
"Don't make a fuss."
[cpg cn=true]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Alicia032"]
[OnName num="alicia"]
"Who are you people......?"
[cpg cn=true]

[OnName num="eddie"]
"My name is Eddie, head of the bandits."
[cpg cn=true]

[OnName num="eddie"]
"You killed a lot of my men. Tina?"
[cpg cn=true]

[FACE method="bow_7" pos="4/5"]
[VOICE f="Tina206"]
[OnName num="tina"]
"I know......I'm sorry, Princess Alicia."
[cpg cn=true]

Tina activates the poison, causing Alicia to writhe in pain.
[cpg]

[FACE method="shock_5" pos="2/5"]
[VOICE f="Alicia033"]
[OnName num="alicia"]
"Aghh..... My body, my body, this is......!"
[cpg cn=true]


[SE f="se004"]
;//【ＳＥ】『本落とす』


She drops her book as she collapses onto the bed without any energy left in her body.
[cpg]

;//========================================
;//●ＣＧエロ（倒れているヒロイン）ev_23
;//人物１：ヒロイン１
;//服装１：ドレス
;//人物２：主人公
;//服装２：裸
;//場所　：城寝室
;//時間　：夜
;//========================================
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_23_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[OnName num="eddie"]
"Don't let out a sound. If you do, I'll kill you."
[cpg cn=true]

Alicia seemed to be unable to comprehend the reality in front of her and what was happening right now.
[cpg]

;//[VOICE f="Alicia034"]
[VOICE f="sAlicia002"]
[OnName num="alicia"]
"Aaaah! Wha-what...why? What is this magic?"
[cpg cn=true]

[OnName num="eddie"]
"I think they call it the Conqueror's Poison? In short, it's a magical poison that can kill you at any time, anywhere."
[cpg cn=true]

[OnName num="eddie"]
"It's already running through your veins. We could end your life in an instant if we wanted to."
[cpg cn=true]

That's a big advantage. Even if Tina is caught, she can retaliate.
[cpg]

The threat of mutual annihilation has always been a powerful deterrent.
[cpg]

;//[VOICE f="Alicia035"]
[VOICE f="sAlicia003"]
[OnName num="alicia"]
"Please! Don't kill me. Nooo!"
[cpg cn=true]

[OnName num="eddie"]
"I told you not to make a fuss. Am I going to have to activate this poison again to get you to be quiet?"
[cpg cn=true]

;//[VOICE f="Alicia036"]
[VOICE f="sAlicia004"]
[OnName num="alicia"]
"Ugh......What do you want from me?"
[cpg cn=true]

[OnName num="eddie"]
"Does it matter? You got the general gist of what's going on now right?"
[cpg cn=true]

[VOICE f="Alicia052"]
[OnName num="alicia"]
"Huh......"
[cpg cn=true]

[OnName num="gil"]
"When you go quiet like that, that makes me nervous. When I get nervous, I might hurt someone."
[cpg cn=true]

Gil pressures her to reply, and Alicia reluctantly obliged.
[cpg]

[VOICE f="Alicia053"]
[OnName num="alicia"]
"I understand...I'll do as you say......"
[cpg cn=true]

;//移植のためシーンをカットしています

Now we had to decide how far we were going to push her.
[cpg]

I don't think there's anything better than scaring her ......
[cpg]



;//※ヒロイン１選択肢発生、と書いてある部分を通っていなければ選択肢は発生せず
;//　選択肢２を選んだことになる

[if exp={getFlagValue("FirstSelect") == 1 }]
[jump target=*select01_0]
[endif]
[jump target=*select01_2]

*select01_0|Down with the Crown

;//■選択肢
[switch]
[case "Instill fear in her"]
	[swap]
	[jump target="*select01_1"]
[case "Leave her for now"]
	[swap]
	[jump target="*select01_2"]
[endswitch]

1. Instill fear in her
2. Leave her for now



;//==============================
;//１、恐怖を植えつける
*select01_1|Down with the Crown


;//（ヒロイン１ポイント増加）
[stflag Cha1flg = 1]


[OnName num="eddie"]
"Turn around."
[cpg cn=true]

I said so and forced her to kiss me.
[cpg]

No matter what I do, Alicia just seems terrified.
[cpg]

;//[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sAlicia005"]
[OnName num="alicia"]
"You beast......you're awful......"
[cpg cn=true]

[OnName num="eddie"]
"Well aren't you the tragic little heroine. It's your fault so many of my men died."
[cpg cn=true]

Well, that's because we are bandits, but I made it seem like it was her fault.
[cpg]


;//（ヒロイン１ポイント増加）

;//移植のためシーンをカットしています

;//[window target=false]
;//[free time=1000]
;//[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/5" time=1000]
;//[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="4/5" time=1000]
;//[BG f="b_07_4.ui" time=1000]
;//[WAIT time=2000]
;//[window target=true]
;//[WAIT time=100]

;//【ＢＧ】『姫の寝室』（夜）******************************************************

;//[FACE method="shake_7" pos="4/5"]
[VOICE f="Tina210"]
[OnName num="tina"]
"......Isn't that enough? I'm starting to feel a little sorry for her......"
[cpg cn=true]

[OnName num="eddie"]
"I didn't expect to hear that from you."
[cpg cn=true]

;//移植のためシーンをカットしています

;//ＢＫ

I decided to leave for now.
[cpg]

I couldn't risk anybody finding us here.
[cpg]



[jump target=*select01_3]
;//==============================
;//２、一旦引き上げる
*select01_2|Down with the Crown


I think I've done enough for tonight, I couldn't risk anybody finding us here.
[cpg]

It wasn't a good idea to go any further.
[cpg]


;//==============================
*select01_3|Down with the Crown


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『姫の寝室』（夜）******************************************************



[OnName num="eddie"]
"Now the head of this country is at our mercy."
[cpg cn=true]

[OnName num="gil"]
"Right. At the very least, we've got 2 central pillars of the kingdom under our control."
[cpg cn=true]

We hold a meeting in front of Alicia.
[cpg]

At this point, things won't change much even if she overheard us.
[cpg]

She probably won't say anything to anyone if she wanted to live to see the next day.
[cpg]

[OnName num="eddie"]
"We could let the others start the attack...what to do, what to do..."
[cpg cn=true]

Should we just regroup with the bandits and start the attack?
[cpg]

No, I'd rather prefer straighten things out more here and make sure we get the results that I want.
[cpg]

There is a good chance that they will betray us if we don't do anything.
[cpg]

I'd have to be careful about the choices I made.
[cpg]

[OnName num="eddie"]
"We'll be back."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[VOICE f="Alicia116"]
[OnName num="alicia"]
"......"
[cpg cn=true]

There was silence. Alicia, does not respond to anything, but it proves that her heart is broken.
[cpg]

But it's not enough to just have her heart broken. She has to be obedient to my orders.
[cpg]

[OnName num="eddie"]
"Also, when I come over, you have to treat me like a guest."
[cpg cn=true]

[OnName num="gil"]
"That's right. It's a lot of work, having to sneak in all the time."
[cpg cn=true]

[FACE method="bow_4" pos="2/5"]
[VOICE f="Alicia117"]
[OnName num="alicia"]
"......Yes. I understand."
[cpg cn=true]

I'm glad she was so understanding. Or perhaps she is too afraid of her situation.
[cpg]

Maybe she's thinking about how to get me in a good mood.
[cpg]

That's good progress, I needed her to be obedient.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

After that, I left the castle and parted ways with Tina.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


I awake the next morning feeling fantastic. I'd slept well.
[cpg]

Things are going smoothly and every step was leading me closer and closer to my revenge.
[cpg]

It's a great feeling.
[cpg]

[OnName num="gil"]
"Now we can enter the castle through the front door."
[cpg cn=true]

[OnName num="eddie"]
"Yes, that alone is a big step forward."
[cpg cn=true]

But I had the general's and the princess's weaknesses in my own hands.
[cpg]

The situation couldn't have been better. A smile forms on my face.
[cpg]

[OnName num="eddie"]
"Alright Gil, let's head to the castle."
[cpg cn=true]

We should get to the castle, I'm sure Alicia has already given the order.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


[OnName num="female_soldier"]
"Stop right there! What business do you have at the castle?"
[cpg cn=true]

When we went to the castle, we were stopped at the gate.
[cpg]

Well, these soldiers don't even know what we look like, so they won't let us through right away.
[cpg]

[OnName num="eddie"]
"Tell the princess that Eddie and Gil are here, I'm sure she'll let us through."
[cpg cn=true]

[OnName num="female_soldier"]
"What nonsense is this? Why would the princess have business with men...especially men as shabby-looking as you?"
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『城内の一室』（昼）******************************************************


When she came back, she let us through, apologizing profusely the entire time. It was almost laughable how quickly her attitude changed.
[cpg]

[OnName num="eddie"]
"Well that was amusing. It's nice to not have to sneak in all the time."
[cpg cn=true]

[OnName num="gil"]
"I agree. And did you see how pale that guard went? What a masterpiece!"
[cpg cn=true]

;//全く、気分のいい日だ。このまま、もう少し国内の女を犯してやりたい気分だ。
It's a good day. I'd like to continue to dominate the women in the country for a little while longer.
[cpg]

And then I caught a glimpse of Stella. How convenient, I thought to myself.
[cpg]

[OnName num="eddie"]
"Hey, Stella, come over here for a minute."
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Stella136"]
[OnName num="stella"]
"......Oh, it's you."
[cpg cn=true]

I called out through the open door of the room.
[cpg]

The look on her face is complicated, as if she was looking at something horrible, but it was not just that.
[cpg]

[OnName num="eddie"]
"You did good work, I think I can get you and Alicia together in the near future."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Stella137"]
[OnName num="stella"]
"Really. Do you promise?...... Please."
[cpg cn=true]

Ha! I didn't expect her to say that to me. I can't help but smile.
[cpg]

Does she love the princess that much? I never thought I'd see a woman act so much like a man. It's almost endearing.
[cpg]

[OnName num="eddie"]
"If you think that you have to show it in your attitude."
[cpg cn=true]

The amusement made me feel even better. She puts her own desires first.
[cpg]

She will do whatever it takes to get what she wants. So I'm going to have a little fun.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Stella138"]
[OnName num="stella"]
"Understood then. I will show you to my room."
[cpg cn=true]

Stella is smart. She seemed to understand the meaning of my words.
[cpg]

She neither resisted nor showed distress, but obeyed me obediently. I appreciated it, but it was a little boring.
[cpg]


;//ＢＫ
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

I touched her hair and asked her,
[cpg]

;//========================================
;//●ＣＧエロ（ヒロインに接近する主人公）ev_27
;//人物１：ヒロイン２
;//服装１：鎧
;//人物２：主人公
;//服装２：私服
;//場所　：城寝室
;//時間　：昼
;//========================================
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[OnName num="eddie"]
"Now, Stella......will you help me destroy this country?"
[cpg cn=true]

I ask her, just to be sure. I don't have to ask though, since I already poisoned Alicia.
[cpg]

;//[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Stella180"]
[OnName num="stella"]
"I'll do whatever it takes......as long as Alicia and I can be together."
[cpg cn=true]

I can't stop laughing. I don't even know what I was worried about.
[cpg]

At her core, she's a lot like us...bound by her own, selfish desires.
[cpg]

She probably meant it when she said that she'd do anything.
[cpg]

[OnName num="eddie"]
"I'm impressed."
[cpg cn=true]

I patted her head and she didn't even blush. Apparently she has no feelings for me.
[cpg]

Maybe she hates men that much. Maybe she is single-minded about Alicia.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『歩く』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]

Then, Gil and I headed out to look for Alicia.
[cpg]

According to the gossip of those walking around the castle, Alicia had shut herself in her room.
[cpg]

[OnName num="gil"]
"Well, that makes sense. She never knows when she might get killed."
[cpg cn=true]

It had not been that long since she was threatened, so it was only natural.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『姫の寝室』（夕方）******************************************************

[FACE method="shock_5" pos="2/3"]
[VOICE f="Alicia118"]
[OnName num="alicia"]
"Eek....."
[cpg cn=true]

Alicia turned pale as she was being examined by a doctor.
[cpg]

She might find out about the poison...not that it mattered much.
[cpg]

It was magic, not actual poison, so there wasn't much of a risk.
[cpg]

[OnName num="eddie"]
"Hey, Alicia. Have your doctor leave the room."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Alicia119"]
[OnName num="alicia"]
"Y-yes, of course."
[cpg cn=true]

[OnName num="doctor"]
"Who are you? The princess isn't feeling well."
[cpg cn=true]

If a grubby man burst into a princess' room, you'd normally tell them to leave, wondering how they got past the guards.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Alicia120"]
[OnName num="alicia"]
"......Oh, um. Doctor, that's enough for now, please leave us for now."
[cpg cn=true]

[OnName num="doctor"]
"......I understand."
[cpg cn=true]

But if the princess herself seems to have business with him, what choice would you have?
[cpg]

I don't know what I expected, but even the doctors in this kingdom are women, too.
[cpg]


[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

[WAIT time=1000]

[OnName num="eddie"]
"You are so obedient now. Are you afraid of me or afraid of poison?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Alicia121"]
[OnName num="alicia"]
"I'm afraid of both......"
[cpg cn=true]

Well, I guess that's a given. How boring.
[cpg]

But at least she's being honest. I like that.
[cpg]

Although I don't care as long as I get things done my way.
[cpg]

[OnName num="eddie"]
"I don't blame you. Don't worry, I won't kill you while you're being obedient."
[cpg cn=true]

[OnName num="eddie"]
"Or maybe I should put that obedience to the test...?"
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="sAlicia006"]
[OnName num="alicia"]
"......You disgust me."
[cpg cn=true]


;//========================================
;//●ＣＧエロ（後ろから迫られるヒロイン）ev_29
;//人物１：ヒロイン１
;//服装１：ドレス
;//人物２：主人公
;//服装２：私服
;//場所　：城寝室
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_29_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sAlicia007"]
[OnName num="alicia"]
"Eek!"
[cpg cn=true]

All it took was me taking a few steps towards her......
[cpg]

She immediately stopped resisting and became quiet.
[cpg]

[OnName num="eddie"]
"I keep my promises, princess. I won't do anything as long as you prove useful."
[cpg cn=true]

[VOICE f="sAlicia008"]
[OnName num="alicia"]
"I don't trust you......"
[cpg cn=true]

;//移植のためシーンをカットしています
;//ＢＫ
;//移植のためシーンをカットしています
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_sl"]
;//[WAIT time=100]
;//【ＢＧ】『姫の寝室』（夕方）******************************************************


Taking down an entire country was a farfetched dream.
[cpg]

It's not something you'd normally be able to do in revenge. But I've succeeded in doing the groundwork.
[cpg]

Little by little, it's starting to become a reality.
[cpg]

[OnName num="eddie"]
"When the time comes, I'm going to have you help me dismantle this whole damned kingdom."
[cpg cn=true]

[OnName num="eddie"]
"If you don't, you'll be dead. Get my drift?"
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Alicia161"]
[OnName num="alicia"]
"......Yes. I know."
[cpg cn=true]

Am I being too hard on her? I feel like I'm asking myself the same thing over and over again.
[cpg]

I can't afford to fail here, you can never be too careful...
[cpg]

[free time=1000]

[OnName num="gil"]
"Well, she won't do anything stupid."
[cpg cn=true]

[OnName num="gil"]
"In the end, everybody puts their own survival first."
[cpg cn=true]

[OnName num="eddie"]
"Wise words, coming from you, Gil."
[cpg cn=true]

No matter how much you care about your people. No matter how blindly you serve your country. No matter how much you worship a person.
[cpg]

When it's your life on the line, most people choose themselves.
[cpg]

I'm no exception. My life is more valuable to me than anybody or anything.
[cpg]

That's what it means to be human. That's why I can finally relax.
[cpg]

We left the castle.
[cpg]

[SE f="se011"]
;//【ＳＥ】『ドア閉まる』


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_07_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Alicia162"]
[OnName num="alicia"]
"Oh no, I......"
[cpg cn=true]


[VOICE f="Alicia163"]
[OnName num="alicia"]
"What am I to do......mother?"
[cpg cn=true]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『宿屋寝室』（夜）******************************************************


[OnName num="eddie"]
"I've got enough women in my hands to take the whole country, don't I?"
[cpg cn=true]

[OnName num="gil"]
"Don't start to question yourself or you'll make the rest of us nervous. It's probably fine."
[cpg cn=true]

I think we're both feeling vulnerable. It can be scary when things go so well.
[cpg]

I felt confident about our chances, but it wasn't absolute.
[cpg]

[OnName num="eddie"]
"Just probably, huh?"
[cpg cn=true]

It's better to be completely sure.
[cpg]

My men waiting outside are already getting tired of the situation. We only have about three days left.
[cpg]

The question was how to use that time. We can dominate one person or try to dominate all of them.
[cpg]

Either way, our actions here are going to decide everything.
[cpg]

[OnName num="eddie"]
"I'm tired of thinking about this...... I'm going to bed."
[cpg cn=true]

[OnName num="gil"]
"Sounds like a plan. I'll see you tomorrow, then."
[cpg cn=true]


;//ＢＫ


[jump storage="ep006.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

