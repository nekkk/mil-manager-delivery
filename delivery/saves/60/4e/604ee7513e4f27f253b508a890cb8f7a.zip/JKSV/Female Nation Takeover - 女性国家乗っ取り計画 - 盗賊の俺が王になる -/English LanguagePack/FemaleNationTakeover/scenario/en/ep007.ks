

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//『ヒロイン１エンド』（ヒロイン１ポイントが４度増加している場合）
*Ending_hiroin1|Dominate Princess Alicia

*start|Dominate Princess Alicia

;#################################################
*Ep007|Dominate Princess Alicia
;#################################################

[SCENE id=7]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[OnName num="eddie"]
"I guess we're really done with that inn, huh?"
[cpg cn=true]

[OnName num="gil"]
"Yeah, but we'll be sleeping in that castle soon......"
[cpg cn=true]

[OnName num="eddie"]
"Either that or we'll be rotting away on the battlefield."
[cpg cn=true]

[OnName num="gil"]
"Don't say that......"
[cpg cn=true]

[OnName num="eddie"]
"Well, don't worry your pretty little head. We've done all that we can."
[cpg cn=true]

[OnName num="gil"]
"You're right, boss."
[cpg cn=true]

But it is better to be fully prepared for anything.
[cpg]

Maybe I should take Tina or somebody with me? They might come in handy.
[cpg]


[SE f="se006"]
;//【ＳＥ】『入店音』

[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『花屋』（昼）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Tina303"]
[OnName num="tina"]
"......What do you need?"
[cpg cn=true]

Tina's expression turns serious upon seeing us.
[cpg]

[OnName num="eddie"]
"There's going to be a battle. I've told my men about you, but you should still find a safe place to go in the meantime."
[cpg cn=true]

[OnName num="eddie"]
"Besides, it might be best if you're with me when I'm making it clear to Alicia that she has no other options."
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Tina304"]
[OnName num="tina"]
"I understand......"
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

We headed for the castle immediately. I felt uncharacteristically nervous.
[cpg]

This wasn't good, I'm supposed to be the leader of a group of bandits.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『姫の寝室』（朝）******************************************************


[FACE method="bow_6" pos="2/3"]
[VOICE f="Alicia276"]
[OnName num="alicia"]
"Ah, Mr. Eddie......"
[cpg cn=true]

Good girl. I don't even know what I was worried, I'd done everything I could to make her as obedient as possible.
[cpg]

[OnName num="eddie"]
"It's about the other night. Remember when I told you to surrender unconditionally?"
[cpg cn=true]


Alicia nodded firmly.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Alicia277"]
[OnName num="alicia"]
"Of course, I understand."
[cpg cn=true]

[OnName num="eddie"]
".......Good."
[cpg cn=true]

She's almost too obedient. I'd feel more at ease if she resisted a little bit or at least looked depressed.
[cpg]

[FACE method="change_7" pos="2/3"]

When she looks me in the eyes like that, I start to feel like she's found the courage to sacrifice herself for her people.
[cpg]

[free time=300]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Tina305"]
[OnName num="tina"]
"......Princess Alicia, are you sure about this? The country that your family has ruled over for generations will be destroyed here."
[cpg cn=true]

[OnName num="gil"]
"Hey, whose side are you on?"
[cpg cn=true]

[FACE method="shake_3" pos="2/5"]
[VOICE f="Tina306"]
[OnName num="tina"]
"I need to know. Princess Alicia's the reason I had to fight..."
[cpg cn=true]

I see. I guess there was some bad blood between them.
[cpg]

She was the reason that Tina had to kill people to make a living.
[cpg]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Alicia278"]
[OnName num="alicia"]
"I could ask the same of you. I thought you didn't want to kill anybody anymore."
[cpg cn=true]

[FACE method="bow_7" pos="2/5"]
[VOICE f="Tina307"]
[OnName num="tina"]
"......That's true, but..."
[cpg cn=true]

[FACE method="bow_3" pos="4/5"]
;//[VOICE f="Alicia279"]
[VOICE f="sAlicia013"]
[OnName num="alicia"]
;//「私、分かりました。この国はおかしいとずっと思ってましたけれど」
"I understand now. This country is bizarre."
[cpg cn=true]

[FACE method="shake_4" pos="4/5"]
;//[VOICE f="Alicia280"]
[VOICE f="sAlicia014"]
[OnName num="alicia"]
;//「男の人に蹂躙されるということを、覚えないといけないんです、きっと」
"It was fine for a while when women first took over the kingdom. But as a people, we became weaker with every passing generation."
[cpg cn=true]

......Well, that's a real surprise. What changed her mind?
[cpg]

[OnName num="eddie"]
"I never thought you'd say something like that. What's with the change of heart?"
[cpg cn=true]

[FACE method="bow_2" pos="4/5"]
[VOICE f="sAlicia015"]
[OnName num="alicia"]
"I finally understand after meeting you, Mr. Eddie."
[cpg cn=true]

[FACE method="change_6" pos="4/5"]
[VOICE f="sAlicia016"]
[OnName num="alicia"]
"I realised the truth...being conquered feels so......good."
[cpg cn=true]

Was this going to be a problem?
[cpg]

I think this works in my favor, right?
[cpg]

Apparently, I've awakened Alicia's true nature.
[cpg]

And she seems to think that everyone else must feel the same way.
[cpg]

[OnName num="eddie"]
"In that case, there's nothing left to worry about. The attack will come tonight, be ready."
[cpg cn=true]

[FACE method="bow_2" pos="4/5"]
[VOICE f="Alicia283"]
[OnName num="alicia"]
"Yes, I'll take care of it."
[cpg cn=true]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I left the castle feeling conflicted.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[OnName num="eddie"]
"......She wasn't acting, right?"
[cpg cn=true]

[OnName num="gil"]
"If that was an act, I'd be impressed."
[cpg cn=true]

Indeed. If she was going to double-cross us, I figured she'd act a little less...unhinged.
[cpg]

Normally you wouldn't want to draw attention to yourself if you were planning a betrayal.
[cpg]

In that case, I don't think there's anything to worry about.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Tina308"]
[OnName num="tina"]
"Well, I'll leave you to it then."
[cpg cn=true]

[OnName num="eddie"]
"Oh, wait a minute. Tina, if the military calls for you, use your magic to assist us in any way that you can."
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Tina309"]
[OnName num="tina"]
"I know."
[cpg cn=true]

Everything's going smoothly. Almost too smoothly.
[cpg]

No sense in getting cold feet now, I had to keep it together.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『荒野』（昼）******************************************************


We crossed the border and headed to the bandit camp.
[cpg]

[OnName num="eddie"]
"Rugalant's going to disappear from the map overnight."
[cpg cn=true]

[OnName num="gil"]
"What's wrong? Don't tell me you've gotten attached."
[cpg cn=true]

[OnName num="eddie"]
"It's not about that. It's just......"
[cpg cn=true]

It was a country where I lived for a while. When I think about it getting destroyed, I get a little sentimental.
[cpg]

I didn't want to have to sneak into a country and destroy from the inside ever again.
[cpg]

It's not that I didn't enjoy it, but I was a lot harder than I thought it would be.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『荒野』（夕方）******************************************************


[OnName num="bandit"]
"Boss, it's good to see you!"
[cpg cn=true]

[OnName num="bandit"]
"Is it time? Are we taking Rugalant!? The men are ready to go, just give the word!"
[cpg cn=true]

[OnName num="bandit"]
"Hey, boys! You polish those weapons?"
[cpg cn=true]

[OnName num="bandit"]
"You bet, boss! Let's go show them women who's boss around these parts!"
[cpg cn=true]

[OnName num="eddie"]
"Hold your horses, men. I put a lot of work into this plan and I don't want one of you lunks messing things up."
[cpg cn=true]

Bloodthirsty bastards, the lot of 'em. Gil and I had to focus that energy somewhere or there wouldn't be any spoils of victory left to enjoy.
[cpg]

[OnName num="eddie"]
"Listen to me. The princess of that country no longer functions as the head of state."
[cpg cn=true]

[OnName num="eddie"]
"I told her to surrender the moment we invade, and that's what she's going to do."
[cpg cn=true]

[OnName num="eddie"]
"Some soldiers may come after us. But they will be confused because their chain of command is in tatters."
[cpg cn=true]

[OnName num="gil"]
"So, gentlemen, there is nothing to fear! Nothing can stop us now!"
[cpg cn=true]

My men let out a hearty cheer.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]
;//【ＢＧ】『荒野』（夜）******************************************************



[SE f="se024"]
;//【ＳＥ】『戦闘　剣を交える』


The decisive battle against the Rugalant.
[cpg]

Everything went smoothly. Alicia surrendered as soon as we reached the castle walls.
[cpg]

And Stella knew my intentions to some extent.
[cpg]

Their top general and princess had shown no intent to fight. On top of that, their most powerful magician betrayed them.
[cpg]

[OnName num="female_soldier"]
"What is going on......?"
[cpg cn=true]

[OnName num="female_soldier"]
"I don't understand, Princess Alicia said she would surrender? What happened!?"
[cpg cn=true]

[OnName num="bandit"]
"Heheh, the battlefield isn't a place for idle chatter!"
[cpg cn=true]

[OnName num="female_soldier"]
"Aaaaahhhh!"
[cpg cn=true]

Rugalant's infantry fall one after the other. Of course, their spirit had already been broken.
[cpg]

[OnName num="female_soldier"]
"Hey! Hold on!"
[cpg cn=true]

[OnName num="bandit"]
"This is almost boring..."
[cpg cn=true]

[OnName num="bandit"]
"Well, it's a nice change from last time."
[cpg cn=true]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="kemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『荒野』（夜）******************************************************


The battle was one-sided and the castle was quickly overrun.
[cpg]

[OnName num="eddie"]
"......That didn't take long, we probably could have just stayed in the tent and waited a bit."
[cpg cn=true]

[OnName num="gil"]
"No kidding. Maybe we could have just sat back with a cask of ale."
[cpg cn=true]


[window target=false]
[transition target={true} rule="kemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


Almost all the soldiers were defeated. The women of the city, unarmed, could do little more than weep in fear.
[cpg]

A single man with a weapon frightens a number of women. Now this was how things should be, I chuckled to myself.
[cpg]

[OnName num="bandit"]
"Move, move, move. The princess is on her way."
[cpg cn=true]

;//[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
;//誰が考えたのか、アリシアは裸のまま磔にされて、街の真ん中に放置された。
I don't know whose idea it was, but the princess was trussed up on a pole and left in the middle of the castle town.
[cpg]

[OnName num="eddie"]
"That's a good look. That's the woman who used to be the head of this country."
[cpg cn=true]

[OnName num="gil"]
"Yeah boss. That's what happens to people who go against you."
[cpg cn=true]

[OnName num="woman"]
"Oh, Princess Alicia......How terrible......"
[cpg cn=true]

[OnName num="woman"]
"Shh. Who knows what they'll do to you..."
[cpg cn=true]

[OnName num="woman"]
"But even so, it's terrible."
[cpg cn=true]

The women are talking. I don't listen to them.
[cpg]

[OnName num="eddie"]
"......How do you feel, Alicia?"
[cpg cn=true]

;//ここまで修正済み

;//========================================
;//●ＣＧエロ（磔にされ、見せしめにされるヒロイン）ev_45
;//人物１：ヒロイン１
;//服装１：ドレス
;//場所　：街
;//時間　：昼
;//========================================
;//[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_00_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

She'd been tied up, but I wasn't going to have her executed. I wanted her alive. A living symbol of how the kingdom was now under my control.
[cpg]

;//[VOICE f="Alicia284"]
[VOICE f="sAlicia017"]
[OnName num="alicia"]
"I feel at peace......"
[cpg cn=true]


;//[VOICE f="Alicia285"]
[VOICE f="sAlicia018"]
[OnName num="alicia"]
"I feel like I'm finally being who I'm supposed to be."
[cpg cn=true]

[OnName num="eddie"]
"I see. Maybe I went a little too far in training you. It's kind of boring when you're this submissive."
[cpg cn=true]

[VOICE f="sAlicia019"]
[OnName num="alicia"]
"It's all your doing Mr. Eddie."
[cpg cn=true]

[OnName num="eddie"]
"Fair enough, Alicia. I'll take real good care of you."
[cpg cn=true]

I touched Alicia's cheek.
[cpg]

;//移植のためシーンをカットしています
;//ＢＫ

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[OnName num="gil"]
"This is what it feels like to conquer an entire country."
[cpg cn=true]

[OnName num="eddie"]
"Yeah, I guess so."
[cpg cn=true]

I've destroyed small countries in other places.
[cpg]

Rugalant wasn't exactly a big country, either.
[cpg]

They had a lot of soldiers and a powerful wizard, so they were able to defend themselves surprisingly well.
[cpg]

;//========================================
;//●ＣＧエロ（拘束されているヒロイン。連れ回されている）ev_46
;//人物１：ヒロイン１
;//服装１：ドレス
;//人物２：主人公
;//服装２：私服
;//場所　：街
;//時間　：夜
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_46_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

I had changed Alicia's restraints and pulled her along around the city.
[cpg]

She even seemed to be happy about that.
[cpg]

[VOICE f="sAlicia020"]
[OnName num="alicia"]
"......"
[cpg cn=true]

She doesn't say anything, but that attracted me to her.
[cpg]

From now on, this country, including her, belong to me.
[cpg]

;//移植のためシーンをカットしています
;//ＢＫ


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


As a bandit, stealing things is normal to me. How many could say that they'd stolen an entire kingdom?
[cpg]

The frenzied feast continues......
[cpg]


;//【ヒロイン１エンド】エンド

[SCENE id=12]

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////

