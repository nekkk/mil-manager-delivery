*start|The Bar and The Flower Shop

;#################################################
*Ep001|The Bar and The Flower Shop
;#################################################

[SCENE id=1]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


The tavern was closed at noon, which was to be expected.
[cpg]

[OnName num="eddie"]
"Oh well......I wanted to ask Ruth about something."
[cpg cn=true]

[OnName num="gil"]
"Why not just go inside? Look, she's cleaning the shop."
[cpg cn=true]

Gil pointed to someone inside.
[cpg]

If there was somebody inside before the tavern was open, it was likely to be the owner. It must be her.
[cpg]

[OnName num="eddie"]
"......I think you're right. Let's go see what we can find out."
[cpg cn=true]

I opened the door to the tavern and went inside.
[cpg]


;//ＢＫ

[SE f="se011"]
;//【ＳＥ】『ドア開く』

[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『酒場』（昼）******************************************************


[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Loose008"]
[OnName num="loose"]
"Hey, you guys......we're not open until the evening."
[cpg cn=true]

Of course. But I wasn't here for a drink.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Loose009"]
[OnName num="loose"]
"Either way, it's not respectable for a man to be drinking alcohol while the sun's still up."
[cpg cn=true]

[OnName num="eddie"]
"......Are you implying that the same couldn't be said for women here?"
[cpg cn=true]

Another instance of culture shock.
[cpg]

I wonder if this was part of the gender norms being reversed.
[cpg]

[OnName num="eddie"]
"Well, whatever. I'd like to know more about the florist down the way."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Loose010"]
[OnName num="loose"]
"The florist......? Oh, are you talking about Tina?"
[cpg cn=true]

As expected, Ruth had a wealth of information that could prove useful to me.
[cpg]


;//ここから、ティナの名前欄をそのまま表示してください


[OnName num="eddie"]
"Yeah, she seemed like a pretty capable magician."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Loose011"]
[OnName num="loose"]
"Oh yeah. I heard that she's one of the most powerful magicians in the kingdom."
[cpg cn=true]

Although she was officially a florist, it seems like there were rumors going around about Tina's magical prowess.
[cpg]

I have to admit, I didn't expect Ruth to talk to readily. Is it just because she doesn't suspect us of anything?
[cpg]

[OnName num="eddie"]
"So it's true, then. I had a feeling that she wasn't just a florist."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Loose012"]
[OnName num="loose"]
"I also heard that she freelances for the military every so often."
[cpg cn=true]

That makes sense. I recall seeing magic being used during our last battle.
[cpg]

So that means Tina was contracted by the military as a mercenary.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Loose013"]
[OnName num="loose"]
"It doesn't look like the flower shop makes much money......I guess she didn't have any other choice."
[cpg cn=true]

[OnName num="eddie"]
"I see."
[cpg cn=true]

Her family must be poor. But if she was working for the military, she should be be making a fortune...
[cpg]

But was she really okay with that?
[cpg]

She didn't seem like an aggressive person. In fact, she seemed to prefer peace and quiet.
[cpg]

What would happen if we offered her another way of earning money?
[cpg]

It's worth checking out. I thanked Ruth and left the bar to inform Gil of my discovery.
[cpg]


[SE f="se011"]
;//【ＳＥ】『ドア開く』

;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[SE f="se001"]
;//【ＳＥ】『歩く』


[OnName num="gil"]
"A magician working as a florist, huh? I've heard stranger tales..."
[cpg cn=true]

[OnName num="eddie"]
"I don't doubt it."
[cpg cn=true]

On the surface, Tina's just a florist. But in reality, she's a magician working for the military. I imagine she isn't the only one with a hidden side to her.
[cpg]

We headed to the flower shop.
[cpg]

[OnName num="gil"]
"Are you going to rope Tina into working with us, boss?"
[cpg cn=true]

[OnName num="eddie"]
"I'm going to try. A magician under our control would really open up our options."
[cpg cn=true]

I already knew she could fight. What I was really interested in was what else she could do with that magic of hers.
[cpg]

If I played my cards right, it might be possible to take over the kingdom in one fell swoop.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se006"]
;//【ＳＥ】『入店音』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『花屋』（昼）******************************************************


[VOICE f="Tina005"]
[OnName num="tina"]
"Welcome......"
[cpg cn=true]

Tina looks unhappy.
[cpg]

The flowers appear to be well cared for, but they didn't look like they were selling.
[cpg]

I realized this because the appearance of the shop has not changed much from the last time I came here.
[cpg]

[OnName num="eddie"]
"I heard you're working with the military. Do you like killing people?"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Tina006"]
[OnName num="tina"]
"!"
[cpg cn=true]

I ask straightforwardly without beating around the bush. At the same time, it was a chance for me to show her that I'd done some research on her.
[cpg]

Tina looks startled. She probably also took part in the battle the other day.
[cpg]

Otherwise, the magic I saw would have been by someone else.
[cpg]

[OnName num="eddie"]
"So what do you really want to do? I can't imagine a florist enjoys burning people alive on the battlefield."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Tina007"]
[OnName num="tina"]
"That's not something I want to discuss with someone I just met......"
[cpg cn=true]

She closes her mouth and averts her eyes. She is wary of us.
[cpg]

But if I can find out what she wants in this moment, then we can have a conversation.
[cpg]

[OnName num="eddie"]
"I'm offering you another job. Come on, tell me what you really want."
[cpg cn=true]

Half of it is just a hunch. I can guess, given the circumstances, that she's probably doing it for the money.
[cpg]

Tina hesitates several times, then she began to speak her mind.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Tina008"]
[OnName num="tina"]
"The truth is, I don't......want to kill people, and I don't want to hurt people either."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Tina009"]
[OnName num="tina"]
"I don't like seeing blood and I really don't want to kill people."
[cpg cn=true]

I knew it. It was simpler than I thought, but that made it easier to get her to work with me.
[cpg]

All I have to do is give her a better offer and she'll take the bait.
[cpg]

[OnName num="eddie"]
"I see. But you still need the money, right?"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Tina010"]
[OnName num="tina"]
"Yes......I have provide for my siblings."
[cpg cn=true]

Just as I thought.
[cpg]

I've seen plenty of people forced into selling their skills due to debt or family.
[cpg]

If it were a personal problem, she would have resolved it long ago. Now I have leverage over her.
[cpg]

[OnName num="eddie"]
"Then I'll be your new patron. The question is what you're willing to offer me in exchange..."
[cpg cn=true]

I looked up and down Tina's body...
[cpg]

[OnName num="eddie"]
"Why don't we have a little chat somewhere quiet. Don't worry, I'm not going to touch you. All you have to do is talk to me."
[cpg cn=true]

[OnName num="gil"]
"What!?"
[cpg cn=true]

That wasn't Tina's voice...Gil had let out a yelp of surprise. He leans in and whispers in my ear.
[cpg]

[OnName num="gil"]
"What are you planning, boss? Why not just tell her that you'll give her money if she helps you overthrow the kingdom?"
[cpg cn=true]

[OnName num="eddie"]
"What? This way, I don't need to pay her money."
[cpg cn=true]

[OnName num="gil"]
"But you run the risk of being rejected."
[cpg cn=true]

[OnName num="eddie"]
"Offering her money doesn't make that risk go away."
[cpg cn=true]

I'm not going to bother explaining my strategy from scratch, so it would be easier if he just agreed with what I say.
[cpg]

While Gil and I were whispering, Tina seemed to struggle with my offer.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sTina001"]
[OnName num="tina"]
"I'm grateful for the offer, but I don't trust you."
[cpg cn=true]

[OnName num="eddie"]
"I see. I'm sorry to hear that."
[cpg cn=true]

[OnName num="gil"]
"What? Are you giving up already?"
[cpg cn=true]

I decided to pull back immediately. Gil must have been surprised, but I don't have the time to explain every little move I make.
[cpg]

I need him to trust me and keep his damn mouth shut.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


It was simple. If I force my way in, I will only alarm her and create distrust.
[cpg]

In that case....it's better to create a situation in which working with me is the better option.
[cpg]

[OnName num="eddie"]
"I've got a burglary job for you, Gil."
[cpg cn=true]

Gil looks convinced now.
[cpg]

[OnName num="gil"]
"Good choice. You're going to rob that flower shop of its money, aren't you?"
[cpg cn=true]

[OnName num="eddie"]
"I'm glad we're on the same page." 
[cpg cn=true]

If she needs money, then let's make that problem even worse.
[cpg]

When she's struggling to put food on the table, she won't be so picky about the jobs she takes.
[cpg]

Once she's reliant on me, I'll have even more leverage over her. I can hardly wait.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


That night, most everything of value disappeared from Tina's house.
[cpg]

It was easier than I'd thought. The only measure of security to be found was a lock on the door. This country must not see a lot of crime.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se006"]
;//【ＳＥ】『入店音』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『花屋』（朝）******************************************************


The next day, we went to the flower shop.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Tina012"]
[OnName num="tina"]
"You......"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

Though shocked at first, her eyes quickly narrowed into a glare.
[cpg]

But she looked more defeated than angry.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Tina013"]
[OnName num="tina"]
"Did you do this to me?"
[cpg cn=true]

[OnName num="eddie"]
"Whatever could you mean?"
[cpg cn=true]

Playing dumb only made her angrier. Not that she could do anything about it.
[cpg]

There was no proof that we did it, but the timing made us the obvious culprits.
[cpg]

It's not like we were trying to hide it, either. It's simply a roundabout way of threatening her.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Tina014"]
[OnName num="tina"]
"Someone broke into my house......and took all of my money."
[cpg cn=true]

[OnName num="eddie"]
"Well, I'm sorry to hear that. So what will you do now?"
[cpg cn=true]

Tina looks down. In this world, you need money to survive.
[cpg]

And if you're not rich to begin with, you're going to want it right away.
[cpg]

She didn't have the luxury of waiting for another job from the military.
[cpg]

Morals go out the window when you're having trouble putting food on the table.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Tina015"]
[OnName num="tina"]
"I understand. I need the money right away."
[cpg cn=true]

[OnName num="eddie"]
"Great. I'm happy you came around."
[cpg cn=true]

I couldn't help but smile.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Tina016"]
[OnName num="tina"]
"......It's better than having to kill people to make money......"
[cpg cn=true]

She must be very kind-hearted. She'd rather sacrifice herself instead of hurting or killing someone else.
[cpg]

She's like a saint. I'll never understand how people like her think.
[cpg]

If it came down to me or somebody else, I choose me every time.
[cpg]

But I guess there are people like this. People who suffer when they hurt other people.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『花屋』（朝）******************************************************


[VOICE f="Tina017"]
[OnName num="tina"]
"......Look, I have to go have an important talk with these people, so......"
[cpg cn=true]

Tina's younger sister and brother gawk at the sight of us.
[cpg]

They are still kids, and she can't tell them the truth, so she covers it up.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sTina002"]
[OnName num="tina"]
"Go outside and play......"
[cpg cn=true]

[OnName num="tina_brother"]
"Okaaay."
[cpg cn=true]

[OnName num="tina_sister"]
"......Are you okay? You look like you're having a hard time......"
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Tina019"]
[OnName num="tina"]
"I'm fine. I'm fine."
[cpg cn=true]

The younger sister may have sensed something. She seemed concerned for her sister.
[cpg]

Tina let her siblings out of the house for the time being. Is it just the three of them living here?
[cpg]

The house itself is pretty big, so maybe they lost their parents in an accident or something.
[cpg]

[OnName num="eddie"]
"Alright, Tina. Are you ready?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
Tina nods reluctantly.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『住居寝室』（朝）******************************************************


Then we faced Tina.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sTina003"]
[OnName num="tina"]
"......I know it's not going to end with just talking."
[cpg cn=true]

"Probably not.", I replied.
[cpg]

She knows her place well.
[cpg]

;//========================================
;//●ＣＧエロ（主人公がヒロインに迫る）ev_04
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：住宅寝室
;//時間　：昼
;//========================================

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_04_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


I walked up to her and whispered in her ear.
[cpg]

[OnName num="eddie"]
"If you spent all your time fighting, I imagine you've never been in love."
[cpg cn=true]

[VOICE f="sTina004"]
[OnName num="tina"]
"......"
[cpg cn=true]

As you can imagine, she didn't answer. But these are the kind of words that seduce women in every time period.
[cpg]

With that thought in mind, I stroked her hair.
[cpg]

;//移植のためシーンをカットしています

;//ＢＫ
;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
;//[BG f="b_05_2.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//
;//[BGM f="bg_se"]
;//[WAIT time=100]
;//【ＢＧ】『住居寝室』（昼）******************************************************


;//[FACE method="change_7" pos="2/3"]
[VOICE f="sTina005"]
[OnName num="tina"]
"......Don't touch me."
[cpg cn=true]

[OnName num="eddie"]
"Isn't this what you wanted? Why must you make me out to be the villain?"
[cpg cn=true]

;//[FACE method="shake_3" pos="2/3"]
[VOICE f="Tina041"]
[OnName num="tina"]
"You stole our money......That's why I'm in this mess."
[cpg cn=true]

She had a good point. I was surely the bad guy.
[cpg]

But I've gotten so used to being the bad guy that it doesn't bother my conscience anymore.
[cpg]

[OnName num="gil"]
"Come on, boss, save some for the rest of us. Like me. Especially me."
[cpg cn=true]

[OnName num="eddie"]
"Yeah, yeah."
[cpg cn=true]

;//移植のためシーンをカットしています
;//ＢＫ
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_se"]
;//[WAIT time=100]
;//【ＢＧ】『住居寝室』（昼）******************************************************


Even after a while...... Tina still wouldn't let her guard down.
[cpg]

I needed her cooperation, but I couldn't move too quickly.
[cpg]

There's no telling how she'd react if I said anything about toppling the kingdom.
[cpg]

I need to dominate her first, otherwise she might reveal our plan.
[cpg]

If that happens, it's straight to the gallows for us.
[cpg]

[OnName num="eddie"]
"Who do I talk to if I want to know the dirty little secrets of powerful people?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tina060"]
[OnName num="tina"]
"......I wouldn't know."
[cpg cn=true]

There she goes again. She doesn't seem to understand her position at all.
[cpg]

I'm trying to be nice to her because of her situation, but she's testing my patience.
[cpg]

[OnName num="eddie"]
"You've been saying that since the beginning. Get it together. You need money, don't you?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tina061"]
[OnName num="tina"]
"I don't understand why you're asking me......"
[cpg cn=true]

It's hard for me to answer when she questions me. I don't know what to say.
[cpg]

I shouldn't tell her the truth.
[cpg]

[OnName num="eddie"]
"We're searching for a person. I can't tell you everything."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Tina062"]
[OnName num="tina"]
"I don't have a lot of acquaintances. I don't really know anyone......"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Tina063"]
[OnName num="tina"]
"But maybe......Ruth from the tavern might know some things......"
[cpg cn=true]

Ruth. So she wasn't just a pretty face.
[cpg]

I guess most tavern owners overhear a lot of things.
[cpg]

Tina was probably telling the truth when she said that she didn't know.
[cpg]

She wouldn't risk lying and getting on my bad side.
[cpg]

[OnName num="eddie"]
"I see. Thank you."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
I patted Tina on the head as I headed out the door.
[cpg]

[OnName num="eddie"]
"I'll be back again soon. I figure you'll be needing more money."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
Tina's face darkens again. This is something that she has to deal with now. 
[cpg]

No hard feelings, I thought to myself.
[cpg]

[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

;//ＢＫ

;//========================================
;//●ＣＧエロ（四つん這いのヒロイン。一人で居る）ev_05
;//人物１：ヒロイン３
;//服装１：私服
;//場所　：住宅寝室
;//時間　：昼
;//========================================

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=2000]
;**【ＣＧ】 ev_05_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sTina006"]
[OnName num="tina"]
"What a weird person......really, I can't believe he didn't do anything."
[cpg cn=true]

[VOICE f="sTina007"]
[OnName num="tina"]
"I wonder what he thinks of me......"
[cpg cn=true]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


I could have headed to Ruth's tavern today......if I wanted to.
[cpg]

Unlike Tina, who is poor to begin with, stealing money from Ruth's place won't make for good leverage since she can earn it back quickly.
[cpg]

If we can't threaten her, we wouldn't be able to get any information out of her. It would be better to carefully plan my approach first.
[cpg]

I wracked my brain, trying to come up with a good scenario.
[cpg]

Do I start with the people around her? I don't know anything about her friends or family.
[cpg]

In the first place, how much time did I even have left?
[cpg]

;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=3000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『宿屋寝室』（夜）******************************************************


[OnName num="gil"]
"The sun's already setting Boss. What's the plan?"　
[cpg cn=true]

Gil's remark reminds me that I didn't have much time.
[cpg]

It was even more irksome because he had a point.
[cpg]

But I didn't have a plan yet, so what could I do?
[cpg]

[OnName num="eddie"]
"We lost a lot of men in that battle, there's plenty of supplies and funds left."
[cpg cn=true]

[OnName num="eddie"]
"Besides, I ordered them to stay battle-ready. They won't disobey my orders so easily."
[cpg cn=true]

[OnName num="gil"]
"Sure, but there's a limit to how long we can keep them waiting."
[cpg cn=true]

Gil was right, of course.
[cpg]

Career bandits took some semblance of pride in their work. They weren't the type to sit around waiting forever.
[cpg]

If they get tired of waiting, there was a good chance that they'd jump the gun.
[cpg]

If that happens, all of my work will have been for nothing.
[cpg]

What a pain...it's like trying to herd cats.
[cpg]

I need to come up with a plan to overthrow the kingdom, and fast.
[cpg]

The key had to be Tina. I need her cooperation no matter what.
[cpg]



[jump storage="ep002.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

