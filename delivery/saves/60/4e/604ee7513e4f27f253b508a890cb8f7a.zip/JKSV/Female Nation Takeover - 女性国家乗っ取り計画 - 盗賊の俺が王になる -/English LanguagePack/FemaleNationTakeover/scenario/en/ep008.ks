

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//『ヒロイン２エンド』（ヒロイン２ポイントが４度増加している場合）
*Ending_hiroin2|The Tragedy of Stella the Blind


*start|The Tragedy of Stella the Blind

;#################################################
*Ep008|The Tragedy of Stella the Blind
;#################################################

[SCENE id=8]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『宿屋寝室』（朝）******************************************************


[OnName num="gil"]
"What's the plan? I'm heading back to the camp."
[cpg cn=true]

[OnName num="eddie"]
"I thought I'd stay here, what do you think?"
[cpg cn=true]

[OnName num="gil"]
"......I think it might affect the men's morale."
[cpg cn=true]

That was a good point. I should join the men in the assault.
[cpg]

But I wanted to have a little chat with Stella first.
[cpg]

[OnName num="eddie"]
"Alright. I'll join up with you later, I need to go to the castle first."
[cpg cn=true]

[OnName num="gil"]
"Understood, I'll head to the camp."
[cpg cn=true]


[window target=false]
[free time=1000]
[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


I headed to the bar where Ruth was before heading to Stella's.
[cpg]

Now that I think about it, Ruth was the one who told me that Stella might be a lesbian.
[cpg]


[SE f="se011"]
;//【ＳＥ】『ドア開く』

[window target=false]
[free time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『酒場』（朝）******************************************************


[OnName num="eddie"]
"Ruth? Are you there?"
[cpg cn=true]

[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Loose263"]
[OnName num="loose"]
"......What? I'm trying to sleep, don't make so much noise."
[cpg cn=true]

[OnName num="eddie"]
"You're the one who told me that Stella was in love with Alicia, right?"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Loose264"]
[OnName num="loose"]
"Yes......what about it?"
[cpg cn=true]

[OnName num="eddie"]
"How did you hear about that in the first place? Did she let it slip one night?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Loose265"]
[OnName num="loose"]
"No, I just overheard a rumor going around the castle is all."
[cpg cn=true]

[OnName num="eddie"]
"I see. I guess she doesn't come to the tavern."
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Loose266"]
[OnName num="loose"]
"General Stella wouldn't come to a tavern like this."
[cpg cn=true]

Hmmm. Does that mean she is not seen as loyal to her desires?
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Loose267"]
[OnName num="loose"]
;//「あんな、お堅くて、アリシア姫に絶対の忠誠を誓うような人が、ここに来るイメージが湧かないわ」
"I can't imagine someone that uptight and unquestioningly loyal coming here."
[cpg cn=true]

I see. So, her allegiance to Alicia was seen as infallible.
[cpg]

At least, on the outside. But in truth, Stella had planned on slipping Alicia a poison, all to bend the princess to her will.
[cpg]

It seems that Stella hides her true self well.
[cpg]


;//ＢＫ
[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


I headed to the castle.
[cpg]

Of course, nobody tries to stop me anymore. I am treated as a guest of the princess.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内の一室』（朝）******************************************************


[OnName num="eddie"]
"Oh, Stella...... There you are."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Stella255"]
[OnName num="stella"]
"......What is it? I'm in the middle of devising a strategy."
[cpg cn=true]

Stella was hunched over a table in what looked like a war room.
[cpg]

[OnName num="eddie"]
"Oh? I'm glad to see you're working hard."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Stella256"]
[OnName num="stella"]
"You were the one who told me to do it."
[cpg cn=true]

[OnName num="eddie"]
"Last time we talked, you seemed hesitant to risk the lives of your soldiers. Has that changed?"
[cpg cn=true]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Stella257"]
[OnName num="stella"]
"......I, I......"
[cpg cn=true]

Stella swallows hard, a bitter expression on her face.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Stella258"]
[OnName num="stella"]
"I've loved Princess Alicia...ever since I first laid eyes on her."
[cpg cn=true]

Stella suddenly began to talk about her past.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Stella259"]
[OnName num="stella"]
"Back then, I wasn't a soldier or anything."
[cpg cn=true]

She looks off into the distance with a pained look in her eyes.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Stella260"]
[OnName num="stella"]
"We were children then......but I knew that this feeling was love."
[cpg cn=true]

[OnName num="eddie"]
"So you enlisted to get closer to Alicia?"
[cpg cn=true]

It sure seemed like a roundabout way of getting close to Alicia. I didn't see how it could possibly lead to them being together.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Stella261"]
[OnName num="stella"]
"Yes. I started out as a mere soldier, but I worked hard. Harder than I'd ever worked before."
[cpg cn=true]

She actually had the talent to become a general. It seems like her efforts paid off, to a point.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Stella262"]
[OnName num="stella"]
"I did everything I could to raise my position. All so that I could get closer to the princess."
[cpg cn=true]

[OnName num="eddie"]
"And you ended up as a general in her army. How'd that work out for you?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Stella263"]
[OnName num="stella"]
"The......distance between us did not get closer. If anything, we seemed to drift apart."
[cpg cn=true]

She looks down in silence for a moment before continuing on, quietly.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Stella264"]
[OnName num="stella"]
"On the day I became general, Princess Alicia something to me."
[cpg cn=true]

I leaned forward, unexpectedly interested to hear the rest of her story.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Stella265"]
[OnName num="stella"]
"General Stella, I leave Rugalant in your capable hands..."
[cpg cn=true]

Well that's...pretty normal.
[cpg]

[OnName num="eddie"]
"I see? That seems pretty standard to me, what was the problem with that?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Stella266"]
[OnName num="stella"]
"Princess Alicia entrusted the fate of Rugalant to me. Not herself."
[cpg cn=true]

You'd usually realize that before you worked your way up to becoming a general.
[cpg]

But not Stella...I felt a little pity for her.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Stella267"]
[OnName num="stella"]
"I've been fighting for Princess Alicia this whole time......"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Stella268"]
[OnName num="stella"]
"And for what, to become the perfect servant? I wanted to become her lover."
[cpg cn=true]

She's nothing if not determined.
[cpg]

Tears well up in her eyes. Her true feelings, kept locked away for years, were finally coming to the surface.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Stella269"]
[OnName num="stella"]
"I love my subordinates. We've been through so much together. I feel terrible knowing that I'm sending so many of them to their deaths."
[cpg cn=true]

[OnName num="eddie"]
"I see. Then do you want to call it off?"
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Stella270"]
[OnName num="stella"]
"I've come too far to turn back now. My wish hasn't changed. I want to be free to love Princess Alicia."
[cpg cn=true]

[OnName num="eddie"]
"Then are you willing to throw away everything and obey me?"
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Stella271"]
[OnName num="stella"]
"......Yes."
[cpg cn=true]



;//ＢＫ


That sounded fine to me. I don't care what Stella felt as long as she was useful to me.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


As I was walking around town I came to realize that I'd never actually been in love before.
[cpg]

But if love could change a person like that......
[cpg]

Then maybe it would be better if love didn't exist.
[cpg]

In the end, love was a convenient tool, but it was far too great a burden for one person to bear alone.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



I walked further. The road became more of a suggestion and quickly faded into the wild.
[cpg]

My men were waiting for me at the camp. It wasn't far now.
[cpg]

[free time=1000]
[WAIT time=1000]


;//【ＢＧ】『荒野』（昼）******************************************************


[OnName num="eddie"]
"Sorry to keep you lads waiting. Did you miss me?"
[cpg cn=true]

[OnName num="bandit"]
"Hey, boss!"
[cpg cn=true]

[OnName num="bandit"]
"The boss is back!"
[cpg cn=true]

[OnName num="bandit"]
"What have you been doing? We've been worried about you!"
[cpg cn=true]

I may not understand love, but I understood how to lead people.
[cpg]

I preferred the simplicity of it. Unlike love, where you have people balancing needs and wants from a position of equality.
[cpg]

[OnName num="eddie"]
"Rugalant's ripe for the picking, boys. Let's go harvest our spoils."
[cpg cn=true]

[OnName num="eddie"]
"Don't worry, I know all about the strategy they're going to take. I heard it from the general herself."
[cpg cn=true]

[OnName num="bandit"]
"How'd you manage that, boss!? Did you make her fall for you or something?"
[cpg cn=true]

[OnName num="eddie"]
"Something like that. It wasn't that hard, honestly."
[cpg cn=true]

[OnName num="gil"]
"We're all set. We've got Tina on our side and Alicia's already our hostage."
[cpg cn=true]

[OnName num="eddie"]
"Yeah, we have nothing to fear anymore. We will attack tonight."
[cpg cn=true]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_00_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『荒野』（夕方）******************************************************


We waited for night to fall.
[cpg]

We lost a lot in the last battle.
[cpg]

Some of us lost friends, some of us lost comrades.
[cpg]

Stella was worried about losing her soldiers, but the scales had been tipped too far. I'd lost a lot of my men and there had to be a reckoning......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]
;//【ＢＧ】『荒野』（夜）******************************************************


The battle began at night.
[cpg]

[OnName num="eddie"]
"Don't give them time to breathe. Ready!?"
[cpg cn=true]


[SE f="se024"]
;//【ＳＥ】『戦闘　剣を交える』


The battle went smoothly. We already knew where Stella was putting her soldiers.
[cpg]

[OnName num="female_soldier"]
"What's going on...!? It's like they know our every move!?"
[cpg cn=true]

[OnName num="female_soldier"]
"I don't know! How...why!?"
[cpg cn=true]

[OnName num="female_soldier"]
"Did someone betray us? But who? Why-aaaagh!"
[cpg cn=true]

[OnName num="bandit"]
"Pathetic! How did we lose to them last time?"
[cpg cn=true]

[OnName num="bandit"]
"So this is what happens when the boss works his magic behind enemy lines."
[cpg cn=true]

[OnName num="bandit"]
"I didn't think it would be this different..."
[cpg cn=true]

It was like putting your sword through someone with their back turned to you.
[cpg]

The battle was one-sided and one-sided it remained......
[cpg]

[OnName num="female_soldier"]
"Sound the retreat! Pull back, pull back!"
[cpg cn=true]

[OnName num="female_soldier"]
"There's nowhere to go! They've surrounded us!"
[cpg cn=true]

[OnName num="female_soldier"]
"Damn it, are we really going to die here!?"
[cpg cn=true]

The battle was almost over.
[cpg]

Most of the Rugalant soldiers had been killed or taken prisoner.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I wonder how Stella feels.
[cpg]

Was her love worth all of this death? How was she going to rationalize what she'd done?
[cpg]

I can't even begin to understand.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="fire1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="fire1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[OnName num="gil"]
"Look at them...terrified at the sight of us. It feels good, doesn't it?"
[cpg cn=true]

We hadn't destroyed everything. There were plenty of women left, but they had no means to fight us anymore.
[cpg]

We may not have the numbers, but we had plenty of weapons and knew how to use them.
[cpg]

But the women didn't resist. They were either too scared or had lost the will to fight.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城内の一室』（朝）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Stella272"]
[OnName num="stella"]
"......I did as you asked."
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Stella273"]
[OnName num="stella"]
"Now......I can finally be with Princess Alicia, right?"
[cpg cn=true]

[OnName num="eddie"]
"Sure, I keep my promises. Gil!"
[cpg cn=true]

[OnName num="gil"]
"Yes, sir?"
[cpg cn=true]

[OnName num="eddie"]
"Bring Alicia here. I'll bed them together."
[cpg cn=true]

[OnName num="gil"]
"Sure thing, boss. Uhh, where is she, anyways..."
[cpg cn=true]


[SE f="se011"]
;//【ＳＥ】『ドア閉まる』


Gil jogs off, looking for Alicia.
[cpg]

[OnName num="eddie"]
"Having regrets yet, Stella?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Stella274"]
[OnName num="stella"]
"......No. If I had, I wouldn't have betrayed Rugalant in the first place."
[cpg cn=true]

[OnName num="eddie"]
"That's true."
[cpg cn=true]

;//移植のためシーンをカットしています


;//ＢＫ
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_se"]
;//[WAIT time=100]

Later...
[cpg]

Stella seemed satisfied, but Alicia had a complicated expression on her face.
[cpg]

Stella sacrificed a lot, but at least her wish had come true.
[cpg]

Although perhaps, not in the way that she wanted......
[cpg]

[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1000]
[WAIT time=1000]

;//【ＢＧ】『城内の一室』（昼）******************************************************


[FACE method="shake_7" pos="4/5"]
[VOICE f="Stella286"]
[OnName num="stella"]
"Princess Alicia, do you love me......?"
[cpg cn=true]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Alicia341"]
[OnName num="alicia"]
"......How could I possibly love you......"
[cpg cn=true]

One day I overheard them having a conversation.
[cpg]

[FACE method="bow_4" pos="2/5"]
[VOICE f="Alicia342"]
[OnName num="alicia"]
"You betrayed the country you sword to protect......you're a traitor."
[cpg cn=true]

Stella, while looking sad, did not look terribly shocked.
[cpg]

I hadn't intended on eavesdropping, it really was just a coincidence.
[cpg]

[FACE method="shake_4" pos="2/5"]
[VOICE f="Alicia343"]
[OnName num="alicia"]
"But it seems that I am not blameless in this. I relied on you too much."
[cpg cn=true]

Alicia also looks sad...maybe even frustrated.
[cpg]

[FACE method="change_7" pos="2/5"]
[VOICE f="Alicia344"]
[OnName num="alicia"]
"Maybe it's my fault for not realizing your true emotions or even the scheming behind it......"
[cpg cn=true]

[FACE method="shake_3" pos="4/5"]
[VOICE f="Stella287"]
[OnName num="stella"]
"......No, no. It's not about whose fault this is."
[cpg cn=true]

Stella shakes her head and embraces Alicia.
[cpg]

[FACE method="bow_6" pos="4/5"]
[VOICE f="Stella288"]
[OnName num="stella"]
"Please love me. I will love you forever until the day you love me back."
[cpg cn=true]

I don't think I'll ever understand love.
[cpg]

In the end, Rugalant was destroyed because of one woman's love.
[cpg]

......A tale of tragic love?
[cpg]

To me it seemed more like a comedy, and Stella...a lonely pierrot.
[cpg]


;//【ヒロイン２エンド】エンド
[SCENE id=13]

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////

