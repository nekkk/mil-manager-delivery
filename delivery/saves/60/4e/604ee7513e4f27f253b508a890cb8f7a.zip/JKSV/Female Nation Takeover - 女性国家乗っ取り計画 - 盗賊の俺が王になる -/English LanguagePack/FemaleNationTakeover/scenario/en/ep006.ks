*start|To Make a Perfect Pawn

;#################################################
*Ep006|To Make a Perfect Pawn
;#################################################

[SCENE id=6]


;//※ここから、ヒロイン１〜４のいずれかを選択します
;//※選択したヒロインは対応したポイントが増加します
;//　（ヒロイン１を選択したらヒロイン１ポイントが増加）
;//※それを三度繰り返し、あるヒロインのポイントが４度増加している場合、そのヒロインのエンディングへ進みます。
;//　全てのヒロインのポイントが１度ずつ増加している場合、ハーレムエンドへと進みます。
;//　それ以外の場合、バッドエンドへと進みます。
;//選択前のシナリオ→一回目
;//↓
;//各ヒロインの選択回数に対応したシナリオ
;//↓
;//選択前のシナリオ→二回目
;//↓
;//各ヒロインの選択回数に対応したシナリオ
;//↓
;//選択前のシナリオ→三回目
;//↓
;//各ヒロインの選択回数に対応したシナリオ
;//↓
;//エンディング
;//という流れになります。

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//選択前のシナリオ→一回目
[stflag LastDay = 1]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


I wake up in the morning and walk around town. I already knew where I was headed.
[cpg]

I had to turn her into the perfect pawn.
[cpg]

[OnName num="eddie"]
"Just wait......"
[cpg cn=true]

Without hesitation, I headed to......
[cpg]


;//■選択肢
[switch]
[case "Alicia"]
	[swap]
	[jump target="*select10_1"]
[case "Stella"]
	[swap]
	[jump target="*select10_2"]
[case "Tina"]
	[swap]
	[jump target="*select10_3"]
[case "Ruth"]
	[swap]
	[jump target="*select10_4"]
[endswitch]

1. Alicia
2. Stella
3. Tina
4. Ruth


;//==============================
;//１、アリシアを調教する
;//==============================
;//２、ステラを調教する
;//==============================
;//３、ティナを調教する
;//==============================
;//４、ルースを調教する
;//==============================

;//それぞれ、対応したポイントが増加した後、対応したシナリオへジャンプ

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//選択前のシナリオ→二回目

*LastSelDay2|To Make a Perfect Pawn

[stflag LastDay = 1]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


I had about two days left. It was just a gut feeling, but I figured this was the limit.
[cpg]

The worst thing that can happen is that my men lose their patience and attack without waiting for my orders.
[cpg]

Timing is everything. The forces from within and from outside must be in sync.
[cpg]

Who was I going to today? The answer was clear.
[cpg]


;//■選択肢
[switch]
[case "Alicia"]
	[swap]
	[jump target="*select10_1"]
[case "Stella"]
	[swap]
	[jump target="*select10_2"]
[case "Tina"]
	[swap]
	[jump target="*select10_3"]
[case "Ruth"]
	[swap]
	[jump target="*select10_4"]
[endswitch]

1. Alicia
2. Stella
3. Tina
4. Ruth



;//==============================
;//１、アリシアを調教する
;//==============================
;//２、ステラを調教する
;//==============================
;//３、ティナを調教する
;//==============================
;//４、ルースを調教する
;//==============================



;//それぞれ、対応したポイントが増加した後、対応したシナリオへジャンプ



;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//選択前のシナリオ→三回目
*LastSelDay3|To Make a Perfect Pawn

[stflag LastDay = 1]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


This was the last day.
[cpg]

Ready or not, we were launching the attack tomorrow.
[cpg]

Had my preparations been enough? Were the women I'd dominated really willing to do as they were told?
[cpg]

And who would I visit today? That was already decided.
[cpg]

I'm going to the person my heart was set on.
[cpg]


;//■選択肢
[switch]
[case "Alicia"]
	[swap]
	[jump target="*select10_1"]
[case "Stella"]
	[swap]
	[jump target="*select10_2"]
[case "Tina"]
	[swap]
	[jump target="*select10_3"]
[case "Ruth"]
	[swap]
	[jump target="*select10_4"]
[endswitch]

1. Alicia
2. Stella
3. Tina
4. Ruth



;//==============================
;//１、アリシア
*select10_1|To Make a Perfect Pawn
[stflag Cha1flg = 1]
[stflag Last1get = 1]

[if exp={getFlagValue("Last1get") == 1 }]
[jump target=*hiroin1_Ep1]
[endif]

[if exp={getFlagValue("Last1get") == 2 }]
[jump target=*hiroin1_Ep2]
[endif]

[jump target=*hiroin1_Ep3]


;//==============================
;//２、ステラ
*select10_2|To Make a Perfect Pawn
[stflag Cha2flg = 1]
[stflag Last2get = 1]

[if exp={getFlagValue("Last2get") == 1 }]
[jump target=*hiroin2_Ep1]
[endif]

[if exp={getFlagValue("Last2get") == 2 }]
[jump target=*hiroin2_Ep2]
[endif]

[jump target=*hiroin2_Ep3]

;//==============================
;//３、ティナ
*select10_3|To Make a Perfect Pawn
[stflag Cha3flg = 1]
[stflag Last3get = 1]

[if exp={getFlagValue("Last3get") == 1 }]
[jump target=*hiroin3_Ep1]
[endif]

[if exp={getFlagValue("Last3get") == 2 }]
[jump target=*hiroin3_Ep2]
[endif]

[jump target=*hiroin3_Ep3]

;//==============================
;//４、ルース
*select10_4|To Make a Perfect Pawn
[stflag Cha4flg = 1]
[stflag Last4get = 1]

[if exp={getFlagValue("Last4get") == 1 }]
[jump target=*hiroin4_Ep1]
[endif]

[if exp={getFlagValue("Last4get") == 2 }]
[jump target=*hiroin4_Ep2]
[endif]

[jump target=*hiroin4_Ep3]

;//==============================

;//それぞれ、対応したポイントが増加した後、対応したシナリオへジャンプ

*BackHome|To Make a Perfect Pawn

[if exp={getFlagValue("LastDay") == 1 }]
[jump target=*LastSelDay2]
[endif]

[if exp={getFlagValue("LastDay") == 2 }]
[jump target=*LastSelDay3]
[endif]

[jump target="*move_Ending"]
;//これより、エンディング分岐

;//////*move _ Ending


;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//ヒロイン１を選択した場合→一回目
*hiroin1_Ep1|To Make a Perfect Pawn



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『城内の一室』（夜）******************************************************


I'd come to Alicia at night, alone.
[cpg]

I had many reasons for doing so. With Gil around, I might go a little too far.
[cpg]

Also, everything was more convenient at night......when everyone was fast asleep.
[cpg]

[OnName num="eddie"]
"Let's see...Alicia's room was this way, right?"
[cpg cn=true]


[window target=false]
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『姫の寝室』（夜）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Alicia164"]
[OnName num="alicia"]
"......What are you doing here?"
[cpg cn=true]

[OnName num="eddie"]
;//「パジャマ姿も麗しいじゃないか、お姫様」
"You look beautiful today, princess."
[cpg cn=true]

I went to Alicia's room and greeted her. She did not respond.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Alicia165"]
[OnName num="alicia"]
"Are you planning on doing something to me again?"
[cpg cn=true]

She seemed terrified of me.
[cpg]

[OnName num="eddie"]
"Of course."
[cpg cn=true]

;//移植のためシーンをカットしています

;//========================================
;//●ＣＧエロ（ベットで横になっているヒロイン。）ev_32
;//人物１：ヒロイン１
;//服装１：ドレス
;//人物２：主人公
;//服装２：私服
;//場所　：城寝室
;//時間　：夜
;//========================================

;//[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_32_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sAlicia009"]
[OnName num="alicia"]
"......Why is it always me?"
[cpg cn=true]

[OnName num="eddie"]
"I do the same to the others, but right now, you're the most important person to me."
[cpg cn=true]

;//[VOICE f="Alicia167"]
[VOICE f="sAlicia010"]
[OnName num="alicia"]
"I'm the most important......"
[cpg cn=true]

Alicia relaxes a little bit. I was surprised.
[cpg]

I think I might have given her the wrong idea. She could have interpreted it the wrong way.
[cpg]

[OnName num="eddie"]
"Oh, by important, I mean important in attacking this country. Don't get me wrong."
[cpg cn=true]

;//移植のためシーンをカットしています

;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_se"]
;//[WAIT time=100]
;//【ＢＧ】『姫の寝室』（夜）******************************************************


[OnName num="eddie"]
"Well then, I'll see you again. Keep the door unlocked for the night."
[cpg cn=true]

Alicia no longer said anything. I'm sure she's very tired of it.
[cpg]

Well, that's okay. I'm going to break her to the point where she has no choice but to obey me.
[cpg]

I'm looking forward to it......
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I went back to the inn.
[cpg]

[jump target="*BackHome"]

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//ヒロイン１を選択した場合→二回目
*hiroin1_Ep2|To Make a Perfect Pawn


;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『城内の一室』（夜）******************************************************


Then again, at night. I made my way to Alicia's room.
[cpg]

I had prepared a lot of stuff today. Hopefully I'll see some interesting reactions.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『姫の寝室』（夜）******************************************************


[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Alicia215"]
[OnName num="alicia"]
"......I was hoping you wouldn't be here today."
[cpg cn=true]

[OnName num="eddie"]
"I'm flattered. I can't wait to change your mind."
[cpg cn=true]

I'm going to make it so that she can't bear to live without me.
[cpg]

;//移植のためシーンをカットしています
;//ＢＫ

;//[free time=300]
;//[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[FACE method="change_4" pos="2/3"]

I stroked her hair and was gentle with her as she was too intimidated to do anything about it.
[cpg]

She wouldn't know why I was doing this.
[cpg]

;//[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

From that point on, Alicia was silent until I left the room.
[cpg]

Maybe this was a good thing. Maybe her mind is wavering.
[cpg]

If so, I'm almost there. I'm really going to take control of this country.
[cpg]


[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


One more push. One more push and this country is going to be mine.
[cpg]

[OnName num="gil"]
"Ah, welcome back, boss. How was it?"
[cpg cn=true]

[OnName num="eddie"]
"Not so bad. Let's go back to the inn, Gil."
[cpg cn=true]

[OnName num="gil"]
"All right, all right. Please take me with you this time."
[cpg cn=true]

That was certainly an option, but I wasn't sure if I should allow it.
[cpg]


;//ＢＫ


[jump target="*BackHome"]

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//ヒロイン１を選択した場合→三回目
*hiroin1_Ep3


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『城内の一室』（夜）******************************************************


I was on my way to Alicia again.
[cpg]

It's not that I like Alicia.
[cpg]

It's just that she's important to my plans, that's all.
[cpg]

Gil wanted to tag alone, but I had him wait outside. There's no telling what he'd do if he got too excited.
[cpg]

Now is the most important time. If I mess up here, everything we've done so far will be for nothing.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『姫の寝室』（夜）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Alicia241"]
[OnName num="alicia"]
"......Mr. Eddie......
[cpg cn=true]

[OnName num="eddie"]
"I'm surprised you remembered my name."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Alicia242"]
[OnName num="alicia"]
"Oh...... no, I mean, it's not that I remembered ....."
[cpg cn=true]

Why deny it? She wouldn't say my name if she didn't remember it.
[cpg]

;//移植のためシーンをカットしています

[OnName num="eddie"]
"I have a favor to ask you, a promise."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Alicia264"]
[OnName num="alicia"]
"A promise......? What promise?"
[cpg cn=true]

[OnName num="eddie"]
"I am going to invade this country. When I do so, I want you to surrender unconditionally."
[cpg cn=true]

Now, how will she react to that? I was nervous.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Alicia265"]
[OnName num="alicia"]
"...... Of course. If you want, Eddie."
[cpg cn=true]

It didn't take her long to reply. That was easy.
[cpg]

But let's take it a step further...
[cpg]

[OnName num="eddie"]
"And don't call me Eddie. It's Mr. Eddie, right?"
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Alicia266"]
[OnName num="alicia"]
"Yes...... Mr. Eddie."
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


Everything is going well. Every woman in Rugalant was going to be under my rule soon.
[cpg]

I left the castle gloating.
[cpg]

[jump target="*BackHome"]

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//ヒロイン２を選択した場合→一回目
*hiroin2_Ep1|To Make a Perfect Pawn


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se006"]
;//【ＳＥ】『入店音』

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『花屋』（昼）******************************************************


I was intent on making Stella mine, but I needed Tina's help to do it.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tina212"]
[OnName num="tina"]
"Summoning magic? It's possible, but...don't expect too much."
[cpg cn=true]

[OnName num="eddie"]
"That's fine. I don't care if the effect is weak."
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


After that conversation, I took Tina to the castle.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城内の一室』（夜）******************************************************


[OnName num="eddie"]
"Yo, Stella. What are you doing, working this late?"
[cpg cn=true]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Stella181"]
[OnName num="stella"]
"......What do you want?"
[cpg cn=true]

Well that's cold of her. She could at least make small talk.
[cpg]

[OnName num="eddie"]
"Hey, Tina. Use it on her."
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[VOICE f="Tina213"]
[OnName num="tina"]
"Okay......Sorry, General."
[cpg cn=true]

Tina apologizes before casting the spell......
[cpg]

She chants words from some language I'd never heard of.
[cpg]


;//小さな丸い光がいくつか舞っているような感じにできたらお願いします


[FACE method="shock_5" pos="4/5"]
[VOICE f="Stella182"]
[OnName num="stella"]
"Ugh! What is this......"
[cpg cn=true]

The effects were immediate. I didn't know summoning magic could be applied like that.
[cpg]

Honestly, I was expecting something on a larger scale, like a big magic circle......
[cpg]

But this was better. It was certainly more useful.
[cpg]


;//========================================
;//●ＣＧエロ（鎧の中に、触手生物を這わせる）ev_35
;//人物１：ヒロイン２
;//服装１：鎧
;//人物２：触手生物
;//服装２：なし
;//場所　：城寝室
;//時間　：夜
;//========================================
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


;//移植のためシーンをカットしています

[VOICE f="sStella007"]
[OnName num="stella"]
"Ugh...get it off of me! Stop!"
[cpg cn=true]

[OnName num="eddie"]
"Hahaha, this is more fun than I expected."
[cpg cn=true]

With some people, kindness goes a long way. But she was different.
[cpg]

I felt that by doing things she didn't like, she would eventually be mine.
[cpg]

;//[VOICE f="Stella202"]
[VOICE f="sStella008"]
[OnName num="stella"]
"Does this...amuse you?"
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『城内の一室』（夜）******************************************************


The tentacles inside her armor turned to ashes and fell out. 
[cpg]

The ashes also scatter and disappear. It was convenient, but I wondered how it functioned.
[cpg]

[OnName num="eddie"]
"It's a lot of fun. Your reactions always excite me. It makes me want to do it again and again."
[cpg cn=true]

[FACE method="shake_3" pos="4/5"]
;//[VOICE f="Stella203"]
[VOICE f="sStella009"]
[OnName num="stella"]
"Tina......Since when have you become an ally of the bandits? You swore an oath of allegiance to our army."
[cpg cn=true]

Stella's words put Tina in a foul mood.
[cpg]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Tina216"]
[OnName num="tina"]
"I didn't pledge allegiance......I just fought for you because I needed money."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

Tina and Stella don't seem to get along. It makes sense, Tina doesn't like violence.
[cpg]

[OnName num="eddie"]
"You don't have any allies here. I sure hope you're ready for more."
[cpg cn=true]

[FACE method="shock_5" pos="4/5"]
[VOICE f="Stella204"]
[OnName num="stella"]
"Wait, wait!"
[cpg cn=true]

Stella stops me as I turned to leave.
[cpg]

[OnName num="eddie"]
"What?"
[cpg cn=true]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Stella205"]
[OnName num="stella"]
"It's about......Princess Alicia......"
[cpg cn=true]

Oh, so that's what this was all about.
[cpg]

Did she think that I was going to lie? Well, I do lie sometimes......
[cpg]

[OnName num="eddie"]
"I'll bring Alicia with me next time. Will that do?"
[cpg cn=true]

[FACE method="bow_6" pos="4/5"]
[VOICE f="Stella206"]
[OnName num="stella"]
"......Yes."
[cpg cn=true]

I thought I saw a brief smile flicker on her face at the very end. Was it my imagination?
[cpg]



[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I parted with Tina and headed to the inn where Gil was waiting for me.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『宿屋寝室』（夜）******************************************************


[OnName num="gil"]
"You sure kept me waiting, boss."
[cpg cn=true]

[OnName num="eddie"]
"Oh, my bad. You could have just gone to sleep."
[cpg cn=true]

[OnName num="gil"]
"I can't do that. You never know when I might be useful."
[cpg cn=true]

[OnName num="eddie"]
"I'm sorry, but I can't take you with me next time I go to Stella's."
[cpg cn=true]

[OnName num="gil"]
"Aww, come on..."
[cpg cn=true]


;//ＢＫ


[jump target="*BackHome"]
;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//ヒロイン２を選択した場合→二回目
*hiroin2_Ep2|To Make a Perfect Pawn



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]

I was determined to make Stella fall for me again. I decided to do something different than usual.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『姫の寝室』（夜）******************************************************


I went to Alicia's room first. I'd said I'd bring Alicia next time, so that's what I was going to do.
[cpg]

[OnName num="eddie"]
"Alicia. Are you still awake?"
[cpg cn=true]

[FG f="CHA01_p3_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Alicia267"]
[OnName num="alicia"]
"Umm......yes. What is it?"
[cpg cn=true]

Of course she's still terrified of me. Well, whatever.
[cpg]

[OnName num="eddie"]
"Come with me. I'm going to visit Stella and I need your help with something."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Alicia268"]
[OnName num="alicia"]
"Help...? But...why me?"
[cpg cn=true]

She doesn't know what I'm talking about. Well, that's all right.
[cpg]

[OnName num="eddie"]
"Don't worry about it. Just go see Stella for me."
[cpg cn=true]


[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p3_02_a.ui" method="change_5"  pos="4/5" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城内の一室』（夜）******************************************************

[FACE method="shock_3" pos="4/5"]
[VOICE f="Stella207"]
[OnName num="stella"]
"What have you done......?"
[cpg cn=true]

And here I thought she would be overjoyed.
[cpg]

This was what she wanted, wasn't it? If not, then I'd just have to change her mind.
[cpg]

[OnName num="eddie"]
"You should be happy. At least you'll finally get the chance to have your beloved Alicia touch you."
[cpg cn=true]

Aren't you happy? You should be happy, Stella. Don't look so nervous.
[cpg]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Alicia269"]
[OnName num="alicia"]
"Beloved...? What's going on here, Stella?"
[cpg cn=true]

[FACE method="shock_5" pos="4/5"]
[VOICE f="Stella208"]
[OnName num="stella"]
"No, no! Don't listen to him......"
[cpg cn=true]

Who was she trying to fool?
[cpg]

If anything, I was more surprised that Alicia hadn't noticed.
[cpg]

[OnName num="eddie"]
"I thought it was pretty obvious that Stella loves you, Alicia."
[cpg cn=true]

Alicia pauses, clearly surprised.
[cpg]

[FACE method="bow_7" pos="2/5"]
[VOICE f="sAlicia011"]
[OnName num="alicia"]
"Is that so, Stella? Do you see me......in a romantic way?"
[cpg cn=true]

[FACE method="shake_4" pos="4/5"]
[VOICE f="Stella209"]
[OnName num="stella"]
"No, no, he's lying......"
[cpg cn=true]

I just realized that this meant I'd lost the leverage I'd had over Stella...
[cpg]

Well, I guess it's alright if Alicia's the only one who knows. The problem would be if other people found out as well.
[cpg]

It should still work as a threat.
[cpg]


;//========================================
;//●ＣＧエロ（背後からヒロイン１がヒロイン２に触れる）ev_36
;//人物１：ヒロイン２
;//服装１：パジャマ
;//人物２：ヒロイン１
;//服装２：パジャマ
;//場所　：城寝室
;//時間　：夜
;//========================================
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sAlicia012"]
[OnName num="alicia"]
"I'm sorry......If I hadn't been threatened, it never would have come to this......"
[cpg cn=true]

Her words might hurt Stella more than anything I could ever do.
[cpg]

But I thought she might actually enjoy the situation she was in.
[cpg]

[VOICE f="sStella010"]
[OnName num="stella"]
"Oh......princess."
[cpg cn=true]

[OnName num="eddie"]
"As long as you obey me, I can make the princess do whatever you want."
[cpg cn=true]

[VOICE f="Stella225"]
[OnName num="stella"]
"......Really? Anything?"
[cpg cn=true]

Of course, Alicia would do anything I said.
[cpg]

[OnName num="eddie"]
"If you want, I can make the two of you switch places."
[cpg cn=true]

Alicia listens awkwardly. Well, she is just a tool to get what I want.
[cpg]

[OnName num="eddie"]
"So, Stella. Are you ready to swear your allegiance to me?"
[cpg cn=true]

I needed her to say it.
[cpg]

[VOICE f="Stella226"]
[OnName num="stella"]
"......Yes. It's not like I could go against you from the beginning."
[cpg cn=true]

;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城内の一室』（夜）******************************************************

I think she is slowly giving up. One more push and she's mine.
[cpg]

[OnName num="eddie"]
"I'll see you later then."
[cpg cn=true]


[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

Then I left the castle. I return to the inn where Gil was waiting for me.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『宿屋寝室』（夜）******************************************************


[OnName num="gil"]
"I'm jealous. Why does it always get to be you......"
[cpg cn=true]

[OnName num="eddie"]
"Don't worry, I've got plans for you."
[cpg cn=true]

I went to sleep after saying so.
[cpg]


;//ＢＫ

[jump target="*BackHome"]

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//ヒロイン２を選択した場合→三回目
*hiroin2_Ep3|To Make a Perfect Pawn


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『城内の一室』（夕方）
;//【ＢＧ】『城内の一室』（夜）******************************************************


[OnName num="gil"]
"It feels like a while since I've gotten to sneak into the castle."
[cpg cn=true]

I'd had Gil wait for me the past few days, so perhaps it was his idea of sarcasm.
[cpg]

[OnName num="eddie"]
"Don't worry, there's no sneaking to be done anymore."
[cpg cn=true]

[OnName num="gil"]
"You're right. We can come and go as we please."
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『城内の一室』（夕方）
;//【ＢＧ】『城内の一室』（夜）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Stella227"]
[OnName num="stella"]
"Again? What is it you want with me?"
[cpg cn=true]

[OnName num="eddie"]
"You've got an important role in my plan."
[cpg cn=true]

;//移植のためシーンをカットしています

;//ＢＫ
;//ＣＧ再び表示
;//[window target=false]
;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//;**【ＣＧ】 ev_36_0 ***********************
;//[CG id=14 index=0 time=1000]
;//;***************************************
;//[WAIT time=1000]
;//[window target=true]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

Then, as I approached Stella, I told her about my strategy.
[cpg]

When you are being threatened by two men who are bigger than you, you may be tempted to give in.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城内の一室』（夜）******************************************************


[OnName num="eddie"]
"I can make Alicia yours. All you have to do is serve me."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sStella011"]
[OnName num="stella"]
"......I understand......"
[cpg cn=true]

[OnName num="eddie"]
"Then do me a favor. I'm going to invade this kingdom."
[cpg cn=true]

[OnName num="eddie"]
"Since you'll be taking the field with your knights, I want you to make a few stupid decisions."
[cpg cn=true]

Stella balked at the idea. Normally, she'd never consider such a thing.
[cpg]

[FACE method="shake_5" pos="2/3"]
[VOICE f="Stella252"]
[OnName num="stella"]
"......If I do that, who knows how many of my subordinates will die......"
[cpg cn=true]

[OnName num="eddie"]
"Sure, but you'll make out alright. Keep your eyes on the prize."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Stella253"]
[OnName num="stella"]
"But......"
[cpg cn=true]

One more push.
[cpg]

[OnName num="eddie"]
"Don't forget that I own you. If you don't do as I say, you'll never see your precious princess again."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Stella254"]
[OnName num="stella"]
"......"
[cpg cn=true]

She was still weighing her options. At the end of the day, it's going to come down to how far I can go to persuade her.
[cpg]

;//[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



She wasn't the only one risking death here.
[cpg]

Choose wisely, Stella.
[cpg]

I left the castle hoping for the best.
[cpg]

[jump target="*BackHome"]

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//ヒロイン３を選択した場合→一回目
*hiroin3_Ep1|To Make a Perfect Pawn


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se006"]
;//【ＳＥ】『入店音』

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『花屋』（昼）******************************************************


Gil and I headed for the flower shop. Of course, we had a specific goal in mind.
[cpg]

[OnName num="eddie"]
"Hey, Tina. How are things?"
[cpg cn=true]


[VOICE f="Tina217"]
[OnName num="tina"]
"......"
[cpg cn=true]

Tina doesn't answer. But...
[cpg]

;//========================================
;//●ＣＧエロ（ヒロインと対面して話す。嫌そうな顔ではない）ev_38
;//人物１：ヒロイン３
;//服装１：私服
;//場所　：住宅寝室
;//時間　：昼
;//========================================
;//[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_38_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

She didn't look unhappy to see us, either. Unlike the others...
[cpg]

I think Tina's the only one I'd been able to dominate entirely.
[cpg]

The fact that she did exactly what I wanted was proof of that.
[cpg]

[OnName num="gil"]
"Why did you choose to head to Tina's? It seems like she's already on your side......"
[cpg cn=true]

Gil had a point, but I wasn't hearing any of it.
[cpg]

[OnName num="eddie"]
"Don't say anything stupid, we're just getting started."
[cpg cn=true]

Honestly, part of it was that I'd grown rather fond of Tina.
[cpg]

[OnName num="eddie"]
"You didn't have any qualms about this country being destroyed in the first place, did you?"
[cpg cn=true]

[VOICE f="Tina218"]
[OnName num="tina"]
"It's hard to respond when you put it that way, but......"
[cpg cn=true]

That was fine, that was a good enough answer.
[cpg]

[OnName num="eddie"]
"Then I'll make it so that you'll be happy just doing what I say."
[cpg cn=true]

Tina blushes and nods.
[cpg]

;//移植のためシーンをカットしています
;//ＢＫ
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_se"]
;//[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[OnName num="gil"]
"What are you planning, boss?"
[cpg cn=true]

[OnName num="eddie"]
"About what? You mean about choosing Tina?"
[cpg cn=true]

[OnName num="gil"]
"Yeah, what more can you do with her? She's already obedient."
[cpg cn=true]

Gil was right. She'd proven herself to be a great help.
[cpg]

In other words, we shared a modicum of trust between us.
[cpg]

Perhaps there wasn't any point in trying to dominate her any further.
[cpg]

But there was a part of me that wanted more. Even if it didn't exist.
[cpg]

No matter what you do, there's a limit to how completely you can control somebody else.
[cpg]

[jump target="*BackHome"]

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//ヒロイン３を選択した場合→二回目
*hiroin3_Ep2|To Make a Perfect Pawn



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]

I was on my way to Tina's again. I left Gil behind, and went alone.
[cpg]

[SE f="se006"]
;//【ＳＥ】『入店音』

[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『花屋』（夕方）******************************************************


[OnName num="eddie"]
"Hey, Tina. How are you feeling today?"
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Tina240"]
[OnName num="tina"]
"......Good evening......"
[cpg cn=true]

When I went to the store, she would even greet me. It's a nice change, honestly.
[cpg]

[OnName num="eddie"]
"Let's go out. Did you feed the kids yet?"
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Tina241"]
[OnName num="tina"]
"......Give me a minute to get ready."
[cpg cn=true]



;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


After that, we went out together.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="sTina009"]
[OnName num="tina"]
"Why did you bring me out here?"
[cpg cn=true]

[OnName num="eddie"]
"Does it matter?"
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


We walked into an alleyway.
[cpg]

;//========================================
;//●ＣＧエロ（路地裏でヒロインに近づく主人公）ev_39
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：路地裏
;//時間　：夕方
;//========================================
;//[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_39_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[OnName num="eddie"]
"Your hair is beautiful. It's a waste that no man has ever touched it before."
[cpg cn=true]

Tina blushed, but she turned her back to me.
[cpg]

[OnName num="eddie"]
"I can give you a much happier future."
[cpg cn=true]

[OnName num="eddie"]
"You won't have to be lonely from now on."
[cpg cn=true]

[VOICE f="sTina010"]
[OnName num="tina"]
"......"
[cpg cn=true]

;//移植のためシーンをカットしています

;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_se"]
;//[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[OnName num="gil"]
"Boss, give me a turn."
[cpg cn=true]

[OnName num="eddie"]
"Why don't you go find someone to dominate?"
[cpg cn=true]

[OnName num="gil"]
"Give me a break, boss......not everyone's as quick thinking as you."
[cpg cn=true]

[OnName num="eddie"]
"Then be patient, this is the fruit of my labor and sharing isn't the bandit way."
[cpg cn=true]

I saw Tina back to her house. It was important to show that I cared.
[cpg]

[OnName num="eddie"]
"See you again, Tina."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sTina011"]
[OnName num="tina"]
"......I'll be waiting."
[cpg cn=true]

It was an odd conversation, but Tina seemed pleased.
[cpg]

This was good, things were going smoothly.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『宿屋寝室』（夜）******************************************************

[SE f="se029"]
;//【ＳＥ】『ベッドきしむ』

[OnName num="eddie"]
"I'm beat......"
[cpg cn=true]

I muttered as I collapsed onto the bed.
[cpg]

[OnName num="gil"]
"All you did was threaten a woman, what's so hard about that?"
[cpg cn=true]

[OnName num="eddie"]
"Ahhh, you don't get it. It's a lot of work to get them to obey you."
[cpg cn=true]

[OnName num="gil"]
"I wouldn't know......"
[cpg cn=true]

Tina was an excellent find. If only I could recruit her into my gang.
[cpg]

If she joined up, she'd make us a real force to be reckoned with.
[cpg]

......But it would be like throwing fresh meat into a pack of wolves. Bandits and women just couldn't coexist.
[cpg]


;//ＢＫ

[jump target="*BackHome"]

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//ヒロイン３を選択した場合→三回目
*hiroin3_Ep3|To Make a Perfect Pawn


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


Gil and I headed to the flower shop rather early.
[cpg]

[OnName num="gil"]
"Do I finally get a turn? I've been looking forward to this."
[cpg cn=true]

I make sure Gil doesn't get the wrong idea.
[cpg]

[OnName num="eddie"]
"Don't get ahead of yourself."
[cpg cn=true]

[OnName num="gil"]
"Huh?"
[cpg cn=true]

He's not a very perceptive guy. But I guess I don't have to explain it all to him.
[cpg]

[SE f="se006"]
;//【ＳＥ】『入店音』


[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『花屋』（昼）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Tina264"]
[OnName num="tina"]
"Hello......"
[cpg cn=true]

[OnName num="eddie"]
"We're going out for a bit. Get ready."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Tina265"]
[OnName num="tina"]
"......Okay, give me a minute."
[cpg cn=true]

I'm glad she's so obedient. She follows my orders unquestioningly.
[cpg]

I haven't even told her where we're going.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『花屋』（昼）******************************************************


[FACE method="shake_6" pos="2/3"]
[VOICE f="Tina266"]
[OnName num="tina"]
"Umm......I told my siblings that I was going out for a bit."
[cpg cn=true]

[OnName num="eddie"]
"Good. We're going somewhere pretty far away, are you good to walk long distances?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Tina267"]
[OnName num="tina"]
"If it comes down to it, I can use recovery magic to push myself a little further......"
[cpg cn=true]

That's convenient.
[cpg]

She's submissive. I think she'll come in real handy when we invade the kingdom.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』


;//[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


We left the city, passing through fields and forest until we reached the border.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『荒野』（夕方）******************************************************


After a few hours, we reached our destination, the bandit camp.
[cpg]

[OnName num="bandit"]
"Oh, boss! We were worried about you!"
[cpg cn=true]

[OnName num="eddie"]
"Sorry to keep you waiting. We're almost ready to invade."
[cpg cn=true]

[OnName num="bandit"]
"Wait...who's the girl you got there? Is she a gift for us or what?"
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Tina268"]
[OnName num="tina"]
"......"
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

Tina swallows hard, faced with such an unruly bunch.
[cpg]

She looked almost excited, rather than terrified.
[cpg]

Tina's cheeks turned red.
[cpg]

[OnName num="eddie"]
"Look at them, Tina. See how they look at you?"
[cpg cn=true]

[OnName num="eddie"]
"It's not something you'd get the chance to experience in Rugalant."
[cpg cn=true]

Tina didn't say anything, but she didn't reject them, either.
[cpg]

;//移植のためシーンをカットしています
;//ＢＫ


[OnName num="eddie"]
"She's on our side. Treat her well."
[cpg cn=true]

And so ended Tina's initiation into the gang.
[cpg]

She looked dazed the whole time.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『荒野』（夜）******************************************************


We parted with the bandits and headed back to the castle town.
[cpg]

[OnName num="eddie"]
"I'm going to invade this country soon. When that day comes, I expect you to lend me a hand."
[cpg cn=true]

[OnName num="eddie"]
"I want you to make sure that Rugalant's soldiers can't fight at their full potential."
[cpg cn=true]

Tina goes quiet for a moment. I didn't think she'd refuse.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tina294"]
[OnName num="tina"]
".....What am I supposed to do?"
[cpg cn=true]

[OnName num="eddie"]
"I'll leave that up to you...I'm not an expert when it comes to magic."
[cpg cn=true]

Tina thinks to herself.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Tina295"]
[OnName num="tina"]
"I understand. Leave it to me."
[cpg cn=true]

She seemed confident. I'd done all that I could.
[cpg]

All that remained was to launch the attack. It would all come down to that.
[cpg]

[jump target="*BackHome"]

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//ヒロイン４を選択した場合→一回目
*hiroin4_Ep1|To Make a Perfect Pawn


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『宿屋寝室』（夜）******************************************************

[OnName num="gil"]
"Come on boss, take me with you."
[cpg cn=true]

[OnName num="eddie"]
"Not this time, I've got plans that requires some finesse."
[cpg cn=true]

I decided to manipulate Ruth.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『酒場』（夜）******************************************************


[SE f="se027"]
;//【ＳＥ】『賑わう店内』


[FACE method="change_5" pos="2/3"]
[VOICE f="Loose156"]
[OnName num="loose"]
"Welcome to...... Oh."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

She swallowed. Well, I guess she is terrified of me.
[cpg]

[OnName num="eddie"]
"What's the matter? You don't have to be so scared."
[cpg cn=true]

Ruth is obviously tense. She looks as if she's trembling.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Loose157"]
[OnName num="loose"]
"......What are you doing here? Things were nicer when you weren't around......"
[cpg cn=true]

[OnName num="eddie"]
"I'm sure. You should take the day off."
[cpg cn=true]

Ruth will know what these words mean.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Loose158"]
[OnName num="loose"]
"Fine......I'll let someone else handle the store today."
[cpg cn=true]

;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『酒場寝室』（夜）******************************************************

;//移植のためシーンをカットしています

[OnName num="eddie"]
"Ruth. You're going to have an important role to play."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="sLoose009"]
[OnName num="loose"]
"......Helping out the bad guys......"
[cpg cn=true]

Even though she says so, I can tell that she's scared of me.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="sLoose010"]
[OnName num="loose"]
"Besides, I'm not in the military and I can't do anything."
[cpg cn=true]

She had a point.
[cpg]

I'd have to figure out how to get her to cooperate.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


[OnName num="eddie"]
"......It never gets old to see a strong woman get frightened."
[cpg cn=true]

I can't help but say my thoughts out loud.
[cpg]

[jump target="*BackHome"]

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//ヒロイン４を選択した場合→二回目
*hiroin4_Ep2|To Make a Perfect Pawn


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]


I head over to Ruth's place, leaving Gil at the inn again.
[cpg]

He threw a fit, but I wasn't about to risk him screwing my plans up.
[cpg]

Gil wasn't the type to betray me, even if I left him on his own for a while.
[cpg]

But Ruth would...
[cpg]

[SE f="se011"]
;//【ＳＥ】『ドア開く』

[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『酒場』（昼）******************************************************


[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Loose204"]
[OnName num="loose"]
"......Oh, you......What are you planning this time?"
[cpg cn=true]

Ruth was cleaning the store by herself. Her expression turns into one of disgust upon seeing me.
[cpg]

[OnName num="eddie"]
"I'm glad you understand me so well."
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『酒場寝室』（昼）******************************************************


I sit next to Ruth and pat her head.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sLoose011"]
[OnName num="loose"]
"Stop it...... I wouldn't be with you if you hadn't threatened me."
[cpg cn=true]

She still has some energy left to resist.
[cpg]

[OnName num="eddie"]
"There's no need to be cruel."
[cpg cn=true]

I'd prepared a new strategy for dealing with her.
[cpg]

[OnName num="eddie"]
"Are you really happy with the way things are? The way this country is set up, with women in control?"
[cpg cn=true]

It was a gamble, but I felt that Ruth might have similar emotions to Tina.
[cpg]

[OnName num="eddie"]
"You don't want to be in control, but you want to be controlled."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="sLoose012"]
[OnName num="loose"]
"Don't assume that."
[cpg cn=true]

She says so coldly, but her body language said otherwise.
[cpg]

She doesn't brush my hand aside, and I don't think it's just because she's afraid of me.
[cpg]

;//移植のためシーンをカットしています

[jump target="*BackHome"]

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//ヒロイン４を選択した場合→三回目
*hiroin4_Ep3|To Make a Perfect Pawn


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『宿屋寝室』（朝）******************************************************


[OnName num="gil"]
"I've brought them over, boss. Two of the nicer ones."
[cpg cn=true]

[OnName num="bandit"]
"......What do you want us to do, boss?"
[cpg cn=true]

[OnName num="eddie"]
"I want you to help me convince a certain woman that working with us is in her best interests."
[cpg cn=true]

[OnName num="gil"]
Then shouldn't we have brought Tina?"
[cpg cn=true]

[OnName num="eddie"]
"What do you mean......?"
[cpg cn=true]

[OnName num="gil"]
"Tina could use transformation magic to turn into a man, right?"
[cpg cn=true]

[OnName num="eddie"]
"Oh, it's not just about numbers."
[cpg cn=true]

The other bandits look thoroughly perplexed. They probably had no idea what we were talking about.
[cpg]

[OnName num="eddie"]
"Sorry......you guys probably have no idea what's going on."
[cpg cn=true]

[OnName num="bandit"]
"Don't worry about us, boss. If you call for us, we're there for you."
[cpg cn=true]

[OnName num="eddie"]
"I appreciate it."
[cpg cn=true]

I had them follow me to the tavern.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『酒場』（昼）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="Loose236"]
[OnName num="loose"]
"......I see you brought friends."
[cpg cn=true]

[OnName num="eddie"]
"That I did....."
[cpg cn=true]

We head up to her room.
[cpg]

;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『酒場寝室』（昼）******************************************************


[OnName num="eddie"]
"Cooperate with me and you'll have your pick of the bunch."
[cpg cn=true]

[OnName num="eddie"]
"Think about it. After we take over, you could even become queen."
[cpg cn=true]

Ruth looked lost.
[cpg]

I am usually not persuasive in these negotiations, but today was a little different.
[cpg]

[OnName num="eddie"]
"Hey, Ruth. I have a favor to ask you."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sLoose013"]
[OnName num="loose"]
"What is it......?"
[cpg cn=true]

[OnName num="eddie"]
"All I need you to do is spread a few rumors..."
[cpg cn=true]

[OnName num="eddie"]
"You're probably the best-informed person in the country. I'm sure people will trust what you say."
[cpg cn=true]

Ruth seemed to be getting the idea. She doesn't reply, but waits for me to finish.
[cpg]

[OnName num="eddie"]
"In the meantime, I'll take this kingdom down. Will you help me?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="sLoose014"]
[OnName num="loose"]
"......"
[cpg cn=true]

[OnName num="eddie"]
"I need a clear answer from you. Will you help me or not?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="sLoose015"]
[OnName num="loose"]
"......I'll help you......"
[cpg cn=true]

Good, that's what I was hoping to hear.
[cpg]

From here on out, there's nothing to be afraid of. It's time for our revenge.
[cpg]

This battle decides everything. If we lose here, at least I'll die knowing I did everything I could.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[OnName num="gil"]
"You two get back to camp. Remember the plan."
[cpg cn=true]

[OnName num="bandit"]
"Got it, boss."
[cpg cn=true]

[OnName num="bandit"]
"See you soon, boss......"
[cpg cn=true]

[OnName num="eddie"]
"I'm counting on you. We're going to succeed this time..."
[cpg cn=true]

And with that, we parted ways.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]
;//【ＢＧ】『宿屋寝室』（夜）******************************************************


[OnName num="eddie"]
"It's almost time, Gil."
[cpg cn=true]

[OnName num="gil"]
"So it seems. I'm going to miss this inn."
[cpg cn=true]

[OnName num="eddie"]
"Yeah, but if all goes well, we'll be sleeping in that castle soon."
[cpg cn=true]

We went to sleep that night with high hopes.
[cpg]


[jump target="*BackHome"]

;//※※※※※※※※※※※※※※※※※※※※※※※※※※
;//※※※※※※※※※※※※※※※※※※※※※※※※※※
;//これより、エンディング分岐

*move_Ending|To Make a Perfect Pawn

[if exp={getFlagValue("Cha1flg") == 4 }]
[jump target=*Ending_hiroin1]
[endif]

[if exp={getFlagValue("Cha2flg") == 4 }]
[jump target=*Ending_hiroin2]
[endif]

[if exp={getFlagValue("Cha3flg") == 4 }]
[jump target=*Ending_hiroin3]
[endif]

[if exp={getFlagValue("Cha4flg") == 4 }]
[jump target=*Ending_hiroin4]
[endif]



[if exp={getFlagValue("Cha1flg") >= 1 }]
[if exp={getFlagValue("Cha2flg") >= 1 }]
[if exp={getFlagValue("Cha3flg") >= 1 }]
[if exp={getFlagValue("Cha4flg") >= 1 }]
[jump target=*Ending_harlem]
[endif]
[endif]
[endif]
[endif]

[jump target=*Ending_BadEnd]


;//各ヒロインのポイントにより分岐します


*Ending_hiroin1|To Make a Perfect Pawn
[jump storage="ep007.ks" target="*Ending_hiroin1"]

*Ending_hiroin2|To Make a Perfect Pawn
[jump storage="ep008.ks" target="*Ending_hiroin2"]

*Ending_hiroin3|To Make a Perfect Pawn
[jump storage="ep009.ks" target="*Ending_hiroin3"]

*Ending_hiroin4|To Make a Perfect Pawn
[jump storage="ep010.ks" target="*Ending_hiroin4"]

*Ending_harlem|To Make a Perfect Pawn
[jump storage="ep011.ks" target="*Ending_harlem"]

*Ending_BadEnd|To Make a Perfect Pawn
[jump storage="ep012.ks" target="*Ending_BadEnd"]


;//ヒロイン１ポイントが４度増加している場合→『ヒロイン１エンド』へ
;//ヒロイン２ポイントが４度増加している場合→『ヒロイン２エンド』へ
;//ヒロイン３ポイントが４度増加している場合→『ヒロイン３エンド』へ
;//ヒロイン４ポイントが４度増加している場合→『ヒロイン４エンド』へ
;//全てのヒロインのポイントが１度増加している場合→『ハーレムエンド』へ
;//それ以外の場合→『バッドエンド』へ
;//各分岐条件はエンディング頭にも表記してあります



;//※※※※※※※※※※※※※※※※※※※※※※※※※※
;//※※※※※※※※※※※※※※※※※※※※※※※※※※


