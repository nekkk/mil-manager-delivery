*start|Turning Ruth into a Pawn

;#################################################
*Ep003|Turning Ruth into a Pawn
;#################################################

[SCENE id=3]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]

I snuck into the tavern in the early hours of the morning.
[cpg]

The tavern was supposed to be open at night, so Ruth was probably still sleeping.
[cpg]

[OnName num="gil"]
"This plan lacks your usual finesse, boss."
[cpg cn=true]

[OnName num="eddie"]
"Shut that big mouth of yours and keep watch."
[cpg cn=true]

The reason why I can't be so choosy is because, unlike Tina, we can't find any obvious weaknesses.
[cpg]

With Gil standing guard, I headed to Ruth's bedroom.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_08_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『酒場寝室』（夜）******************************************************


[VOICE f="Loose014"]
[OnName num="loose"]
"Zzzz ....."
[cpg cn=true]

I sneak beside her and check that I had everything I needed.
[cpg]

She can't know that I'm recording her, but I can't have her clam up and refuse to talk.
[cpg]

On the other hand, I can't have her scream or make a fuss and alert anybody nearby.
[cpg]

In other words, a blade is a must. I keep my steel where she can see it.
[cpg]

[OnName num="eddie"]
"Wake up."
[cpg cn=true]

[FG f="CHA04_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Loose015"]
[OnName num="loose"]
"Mmmhhh......What?"
[cpg cn=true]

Ruth slowly opens her eyes. Though dazed, she quickly begins to understand her situation.
[cpg]

The first thing she saw was cold steel pointed at her. It's enough to make even a grown man cower in fear.
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Loose016"]
[OnName num="loose"]
"Eek!? Wh-what are you doing...what is this?"
[cpg cn=true]

[OnName num="eddie"]
"Don't make a commotion or my hand might slip. Understand?"
[cpg cn=true]

Ruth swallows hard and nods. Yes, that's it.
[cpg]

Of course, the cochlear stone is set. Everything's going according to plan.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sLoose001"]
[OnName num="loose"]
"Do you think you'll get away with this?"
[cpg cn=true]

[OnName num="eddie"]
"Of course I do. That's why I'm here."
[cpg cn=true]

And now, the fun part.
[cpg]

;//移植のためシーンをカットしています
;//ＢＫ

;//========================================
;//●ＣＧエロ（背後から迫られるヒロイン）ev_09
;//人物１：ヒロイン４
;//服装１：パジャマ
;//人物２：主人公
;//服装２：私服
;//場所　：住宅寝室
;//時間　：夜
;//========================================
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_09_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

I intimidate Ruth into talking.
[cpg]

[OnName num="eddie"]
"Are you scared? Are you scared of being threatened by a man?"
[cpg cn=true]

[VOICE f="sLoose002"]
[OnName num="loose"]
"Of course I am! Anyone would act like this if threatened with a knife."
[cpg cn=true]

I see. This question was no good.
[cpg]

[OnName num="eddie"]
"Are you willing to do as I say?"
[cpg cn=true]

[VOICE f="sLoose003"]
[OnName num="loose"]
"What do you want me to do? I don't want to die."
[cpg cn=true]

Yes, those are the words I want to hear. If I were put in the same position, I'd never want anybody to hear me say something like that.
[cpg]

[OnName num="eddie"]
"Then kiss me."
[cpg cn=true]

[VOICE f="sLoose004"]
[OnName num="loose"]
"......Fine."
[cpg cn=true]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

After I was satisfied with what I'd recorded......
[cpg]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『酒場寝室』（夜）******************************************************


[OnName num="eddie"]
"It's called a cochlear stone. It's capable of recording sounds...like everything that just happened."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Loose035"]
[OnName num="loose"]
"Oh......but...but then..."
[cpg cn=true]

[OnName num="eddie"]
"I happen to know magician who'll be happy to duplicate it and distribute it for me. But then what would happen to this wonderful little tavern?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Loose036"]
[OnName num="loose"]
"Don't! This tavern is my dream!"
[cpg cn=true]

It was her dream, huh? Good. All the more reason for her to obey me.
[cpg]

[OnName num="eddie"]
"I told you to keep your voice down. Are you willing to do as I say?"
[cpg cn=true]

Ruth didn't say anything or even nod her head, but that was fine.
[cpg]

I'll take that as an affirmation.
[cpg]

;//移植のためシーンをカットしています

;//ＢＫ
;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[FG f="CHA04_p3_02_a.ui" method="change_7"  pos="2/3" time=1]
;//[BG f="b_08_4.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//
;//[BGM f="bg_sl"]
;//[WAIT time=100]
;//【ＢＧ】『酒場寝室』（夜）******************************************************


[OnName num="eddie"]
"Don't tell anyone about this. Okay?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Loose056"]
[OnName num="loose"]
"......I won't tell anybody."
[cpg cn=true]

She was surprisingly obedient. I hadn't really threatened her with much, yet.
[cpg]

It was like she accepted her situation rather than gave up.
[cpg]

I don't even think she's faking it. Maybe she's a rather calm person. Or maybe she's smart.
[cpg]

Putting the question of her true nature aside, my goals hadn't changed.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


When I the tavern, the sun had already risen.
[cpg]

[OnName num="gil"]
"I'm so jealous......she's still pretty young, eh?"
[cpg cn=true]

[OnName num="eddie"]
"Keep it under control. You'll get your turn later on."
[cpg cn=true]

I reassure Gil that he still had a part to play as we head back to the inn.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

We have a quick nap to refresh ourselves......
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『宿屋寝室』（昼）******************************************************


[OnName num="eddie"]
"Okay one more push. Ruth isn't fully under my control yet."
[cpg cn=true]

[OnName num="gil"]
"I suppose so. Shall we barge in when the tavern opens?"
[cpg cn=true]

[OnName num="eddie"]
"......Let's do that."
[cpg cn=true]

We'd shown her that we could get to her at night, now it was time to make it clear that we could get to her whenever we wanted.
[cpg]

Just like Tina, we needed her to be obedient.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『酒場』（夜）******************************************************


We waited for night to fall and barged into the tavern again. Just like the town, the tavern was full of women.
[cpg]

[FACE method="shock_5" pos="2/3"]

In the middle of it all, Ruth jerked as soon as she saw us.
[cpg]

[OnName num="eddie"]
"Hey there. Thank you for yesterday. You do remember me right?"
[cpg cn=true]

I called out to her with a crude smile on my face.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Loose057"]
[OnName num="loose"]
"If you need something......you can come see me later, after business hours."
[cpg cn=true]

Well I'll be. She's trying to tell me what to do.
[cpg]

[OnName num="eddie"]
"Well what if we don't want to wait?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Loose058"]
[OnName num="loose"]
"I can't......I can't leave the store to someone else when it's this busy."
[cpg cn=true]

I don't think she understands her position. It may be because of her strong personality, but this attitude was not acceptable.
[cpg]

It might be time to teach her a lesson in obedience.
[cpg]

[OnName num="eddie"]
"Well if you can't make time, I might just have to tell everybody about the other day. Is that okay with you?"
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Loose059"]
[OnName num="loose"]
"......You really are cruel......"
[cpg cn=true]

Ruth stopped resisting with a disgusted look on her face.
[cpg]

She'd carved herself a position in the community. I'd made the right choice.
[cpg]

We followed her into the back room as the customers eyed us with suspicion.
[cpg]


;//========================================
;//●ＣＧエロ（ヒロインに背後から迫る主人公）ev_10
;//人物１：ヒロイン４
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：住宅寝室
;//時間　：夜
;//========================================
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[VOICE f="sLoose005"]
[OnName num="loose"]
"What more do you want from me?"
[cpg cn=true]

[OnName num="eddie"]
"What's with the hostility? I'm being a perfect gentleman."
[cpg cn=true]

Ruth wanted to refuse, she obviously couldn't.
[cpg]

;//移植のためシーンをカットしています

;**【ＣＧ】 ev_10_a ***********************
[CG id=5 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sLoose006"]
[OnName num="loose"]
"You can't keep doing this, I have a business to run."
[cpg cn=true]

Ruth looked tired as she says this.
[cpg]

If she really was having as much trouble as she suggests, it might be better to pull back for a bit.
[cpg]

;//※ヒロイン４選択肢発生、と書いてある部分を通っていなければ選択肢は発生せず
;//　選択肢２を選んだことになる

[if exp={getFlagValue("FirstSelect") == 4 }]
[jump target=*select04_0]
[endif]
[jump target=*select04_2]

*select04_0

;//■選択肢
[switch]
[case "I will pressure her further."]
	[swap]
	[jump target="*select04_1"]
[case "I will calm her down."]
	[swap]
	[jump target="*select04_2"]
[endswitch]

1. I will pressure her further.
2. I will calm her down.



;//==============================
;//１、さらに踏み込む
*select04_1|Turning Ruth into a Pawn


;//（ヒロイン４ポイント増加）
[stflag Cha4flg = 1]


Screw that. She need to be taught a lesson in obedience.
[cpg]

So I decided to take it a step further.
[cpg]


[SE f="se029"]
;//【ＳＥ】『衣擦れ』

;//========================================
;//●ＣＧエロ（腕を上げた状態で押さえつけられているヒロイン）ev_11
;//人物１：ヒロイン４
;//服装１：私服
;//人物２：主人公（膣に入れる）
;//服装２：私服
;//人物３：主人公の相棒（ヒロインの腕を押さえつける）
;//服装３：私服
;//場所　：住宅寝室
;//時間　：夜
;//========================================
;//[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_11_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[OnName num="eddie"]
"I don't think you appreciate how nice I've been. Now I'm going to have to show you what happens when you disobey me."
[cpg cn=true]

[VOICE f="sLoose007"]
[OnName num="loose"]
"......"
[cpg cn=true]

Finally, Ruth shut up. While Gil held her down, I forcefully kissed her.
[cpg]

[VOICE f="sLoose008"]
[OnName num="loose"]
"Ahh......"
[cpg cn=true]

I thought I caught a glimpse of her heart breaking the moment our lips parted.
[cpg]

;//移植のためシーンをカットしています


[jump target=*select04_3]
;//==============================
;//２、体を労わってやる
*select04_2|Turning Ruth into a Pawn


Right, there's no guarantee that she wouldn't react poorly. I needed her to work with me, not against me.
[cpg]

;//[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Loose099"]
[OnName num="loose"]
"......Is this your idea of mercy?"
[cpg cn=true]

[OnName num="eddie"]
"Hmm. I just thought it would be a real shame if I broke you."
[cpg cn=true]

Ruth glares at me. And here I was, trying to get on her good side.
[cpg]

;//[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Loose100"]
[OnName num="loose"]
"Even so, I'll never forgive you......"
[cpg cn=true]

She was bold. That was a sign that she was worth it."
[cpg]


;//==============================
*select04_3|Turning Ruth into a Pawn



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『酒場寝室』（夜）******************************************************


[OnName num="eddie"]
"Let's see......you know a lot about this country, don't you?"
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Loose101"]
[OnName num="loose"]
"What makes you think that?"
[cpg cn=true]

[OnName num="eddie"]
"Well, you own a bar, so I figure you've heard more than your fair share of secrets. Tell me about them."
[cpg cn=true]

Ruth looks down and shakes her head a little. I know she knows something...she has to.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Loose102"]
[OnName num="loose"]
"Information......I know a few rumors, but nothing that important. It's not like I have the time to listen in on every conversation."
[cpg cn=true]

[OnName num="eddie"]
"Just tell us what you know. I especially want to know about the people who run this kingdom. Like the military or the nobility."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Loose103"]
[OnName num="loose"]
"I wouldn't know anything about that."
[cpg cn=true]

And then she became quiet.
[cpg]

Maybe she's holding out on me...
[cpg]

I decided to give up for the night. She needed to be disciplined, but this wasn't the time.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『歩く』

[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


Ruth needs another push. As for my other pawn.....
[cpg]


[SE f="se006"]
;//【ＳＥ】『入店音』

[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『花屋』（夜）******************************************************


[OnName num="eddie"]
"You're open awful late."
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Tina121"]
[OnName num="tina"]
"......It's because I don't have enough money......"
[cpg cn=true]

Yeah, I bet. But it's not like anybody was buying flowers at this hour.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sTina008"]
[OnName num="tina"]
"......Are you going to do something to me again today?"
[cpg cn=true]

[OnName num="gil"]
"That's bold of you. I like it."
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Tina123"]
[OnName num="tina"]
"I need money..."
[cpg cn=true]

That said, she was acting differently from when we'd first met.
[cpg]

What I did seems to be having an effect. I decided to make Tina even more obedient.
[cpg]

;//移植のためシーンをカットしています


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

When I talk to Tina, I can tell she is trying to get on my good side.
[cpg]

Is it because she wants even a little of her money back? I have a feeling that's not the only reason.
[cpg]

;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


I gave Tina a little money and then left. I think she's given up trying to fight me anymore.
[cpg]

If I can learn a little more about magical items, I think I can use them to come up with a better plan.
[cpg]

Progress was a little slow, but I was making the foundation I needed in order to topple the kingdom.
[cpg]

[OnName num="eddie"]
"We're making progress. Do you think I'm taking too long?"
[cpg cn=true]

[OnName num="gil"]
"No, I think you're doing it your way and your way usually works."
[cpg cn=true]

From Gil's point of view, maybe I was being too flexible with the time that I had left. Well, I'll do what I want to do regardless of what he thinks.
[cpg]



[jump storage="ep004.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

