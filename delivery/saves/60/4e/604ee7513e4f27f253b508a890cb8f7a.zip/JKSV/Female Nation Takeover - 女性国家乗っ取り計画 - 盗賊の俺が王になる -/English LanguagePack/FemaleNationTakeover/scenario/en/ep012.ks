

;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//『バッドエンド』（それ以外の場合）
*Ending_BadEnd|The Last Day


*start|The Last Day

;#################################################
*Ep012|The Last Day
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『宿屋寝室』（朝）******************************************************


This was the last day we had before launching the attack.
[cpg]

I decided not to talk to any of the women today.
[cpg]

[OnName num="gil"]
"Are you sure, boss?"
[cpg cn=true]

[OnName num="eddie"]
"It's all right. They'll do what I tell them to do."
[cpg cn=true]

[OnName num="gil"]
"......If you say so, boss."
[cpg cn=true]

What was he so worried about? I never thought I'd see Gil get cold feet.
[cpg]

[OnName num="eddie"]
"You don't believe in our men?"
[cpg cn=true]

[OnName num="gil"]
"It's not that......but......"
[cpg cn=true]

He seems unsatisfied. Well, he's never been one for plans that required brainpower.
[cpg]

If we don't win the next battle, we were dead anyway.
[cpg]

But he also can't go against my command.
[cpg]

[OnName num="eddie"]
"......Fine, fine. Let's go threaten Alicia again."
[cpg cn=true]


[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


We head to the castle.
[cpg]

[OnName num="gil"]
"I wonder if this was really the right thing to do."
[cpg cn=true]

[OnName num="eddie"]
"What do you mean?"
[cpg cn=true]

[OnName num="gil"]
"I feel like we haven't completely......gotten everyone on our side."
[cpg cn=true]

[OnName num="gil"]
"And I don't think you really tried to get them all to obey you."
[cpg cn=true]

[OnName num="eddie"]
"I did what I could, don't worry about it."
[cpg cn=true]

[OnName num="gil"]
"......Alright."
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『姫の寝室』（朝）******************************************************


[OnName num="eddie"]
"Alright Alicia, when we invade I want you to surrender unconditionally. Got it?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Alicia357"]
[OnName num="alicia"]
"I don't think the people will obey me......"
[cpg cn=true]

[OnName num="eddie"]
"That's fine, as long as it confuses them a little. I'm relying on you."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Alicia358"]
[OnName num="alicia"]
"......If you insist......"
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城内の一室』（朝）******************************************************


On our way out, I dropped in to see Stella and make sure she was on our side.
[cpg]

I don't think I really had to say anything, but just in case...
[cpg]


[OnName num="eddie"]
"I told Alicia earlier to surrender when we attack."
[cpg cn=true]

[OnName num="eddie"]
"So I want you to go along with it. It'll sow discord among the soldiers."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Stella305"]
[OnName num="stella"]
"......Sure."
[cpg cn=true]

I don't know why, but something felt off about her response.
[cpg]

Alicia was the same way. Maybe Gil had a point. Maybe I didn't do a good job training them to obey me......
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


[OnName num="gil"]
"The men are waiting, let's head back to the camp."
[cpg cn=true]

[OnName num="eddie"]
"Right."
[cpg cn=true]


[SE f="se029"]
;//【ＳＥ】『肩ぶつかる』
[WAIT time=800]

I bumped into another man. How unusual.
[cpg]

[OnName num="man"]
"S...sorry..."
[cpg cn=true]

[OnName num="eddie"]
"......This must be fate. Tell me a bit about the kingdom before I destroy it."
[cpg cn=true]

[OnName num="man"]
"Huh...? What...what are you talking about?"
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I spent a bit of time questioning the man about how Rugalant functioned.
[cpg]

When I thought about it, I had never bothered to learn about men's position in this country.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[OnName num="man"]
"Umm, well...men are like breeding studs I guess. There's a lot of women and not a lot of us."
[cpg cn=true]

[OnName num="gil"]
"So it's like polygamy? But it seems like men have a pretty weak social standing here."
[cpg cn=true]

[OnName num="man"]
"Yes......because most women want to be mothers, but not wives."
[cpg cn=true]

[OnName num="man"]
"So...once they get pregnant, that's the end of the relationship..."
[cpg cn=true]

[OnName num="eddie"]
"That's insane. What do they think men are?"
[cpg cn=true]

[OnName num="gil"]
"I don't know, it doesn't sound entirely terrible to me, but......"
[cpg cn=true]

[OnName num="gil"]
"Isn't the birthrate kind of strange? Normally you'd see more male children being born."
[cpg cn=true]

[OnName num="man"]
"Yes, it seems like there's some divine power at work behind the scenes."
[cpg cn=true]

[OnName num="eddie"]
"I don't care what it is. It means that this country is rotten to the core."
[cpg cn=true]

[OnName num="gil"]
"......Women born to a country like this must be pretty tough."
[cpg cn=true]

[OnName num="gil"]
"Boss, are you really sure you have those women under your thumb?"
[cpg cn=true]

[OnName num="eddie"]
"......I told you it's fine."
[cpg cn=true]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『荒野』（昼）******************************************************


[SE f="se001"]
;//【ＳＥ】『歩く』


We head towards the border, in the direction of our camp.
[cpg]

[OnName num="eddie"]
"I see the tents......almost there."
[cpg cn=true]

[OnName num="gil"]
"Yes, I'm sure everyone is eagerly waiting for you."
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


We return to find morale higher than ever.
[cpg]

They were ready to attack right now, but I managed to hold them off.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_00_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『荒野』（夕方）******************************************************


[OnName num="eddie"]
"......What a bloodthirsty bunch. I haven't even told them the plan."
[cpg cn=true]

[OnName num="gil"]
"We wouldn't have made it this far without you, boss."
[cpg cn=true]

[OnName num="eddie"]
"I don't doubt it. Alright, we move tonight."
[cpg cn=true]

[OnName num="gil"]
"I'm sure they'll have calmed down a bit by then."
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="fire1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="fire1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]
;//【ＢＧ】『荒野』（夜）******************************************************


[SE f="se024"]
;//【ＳＥ】『戦闘　剣を交える』


The battle began at nightfall.
[cpg]

As soon as our forces clashed, I knew something had gone wrong.
[cpg]

What happened? Did those women double-cross me?
[cpg]

Rugalant's soldiers cut through my men with ease. It's just like the other day.
[cpg]

[OnName num="eddie"]
"We have to retreat! Run for your lives!"
[cpg cn=true]

[OnName num="gil"]
"Retreat! Retreat......"
[cpg cn=true]

An arrow finds its mark in Gil and he falls to the ground. Some part of me could tell that this was the end.
[cpg]

[OnName num="eddie"]
"Gil! Gil, keep it together!"
[cpg cn=true]

[OnName num="gil"]
"I had a bad...feeling......about this."
[cpg cn=true]

[OnName num="gil"]
"Run, boss. As long as you're...alive......there'll be another...chance."
[cpg cn=true]

[OnName num="eddie"]
"Don't give up on me now! Damnit all, hold on! I'll get you out of here......"
[cpg cn=true]

[SE f="se034"]
;//【ＳＥ】『刺す』

[BG f="red.ui" time=1000]
[WAIT time=2000]

I felt something hit me. A burning sensation spreads from my chest.
[cpg]

An arrow had hit me in the heart. I guess that was it for me.
[cpg]

Where did I go wrong? We should have been able to win this war.
[cpg]

Who had betrayed me......?
[cpg]

There was no way for me to know.
[cpg]

;//ゲームオーバー
;//【バッドエンド】エンド

[jump storage="epend.ks" target="*badend"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////
