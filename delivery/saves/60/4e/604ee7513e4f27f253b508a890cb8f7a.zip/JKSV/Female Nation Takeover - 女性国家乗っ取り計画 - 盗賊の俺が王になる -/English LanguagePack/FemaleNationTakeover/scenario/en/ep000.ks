
*start

;//【牝狩賊～淫獄に穢れる乙女たち～_シナリオ】

;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています

;//以下音声あり

;//アリシア　：ドレス
;//ステラ　　：鎧　私服
;//ティナ　　：私服
;//ルース　　：私服

;//以下音声なし

;//エディ
;//ギル
;//女
;//ティナの弟
;//ティナの妹
;//盗賊
;//女兵士
;//医者
;//男

;//以下、残したCGを列挙します
;//アリシア　01 23 29 32 45 46
;//ステラ　　19 20 27 35 36
;//ティナ　　02 04 05 38 39
;//ルース　　09 10 11 49


;#################################################
*Ep000|The Fearsome Bandits
;#################################################

[SCENE id=0]


[stflag FirstSelect = 0]

[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[stflag Cha4flg = 0]

[stflag Last1get = 0]
[stflag Last2get = 0]
[stflag Last3get = 0]
[stflag Last4get = 0]

[stflag LastDay = 0]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『荒野』（昼）******************************************************



We walk through the wilderness to the Kingdom of Rugalant.
[cpg]

Rugalant is a blessed land, easily defended due to its terrain.
[cpg]

Several nations have marched their armies against it, but all have failed......
[cpg]

But the most surprising thing about this country was that its rulers have always been women.
[cpg]

The power relations between men and women in Rugalant are reversed. Women hold all positions of power, from ministers to generals.
[cpg]

[OnName num="eddie"]
"It ain't right......"
[cpg cn=true]

I muttered to myself. I couldn't leave such a country alone.
[cpg]

My name is Eddie Hales, I run this group of bandits.
[cpg]

Men should always stand above women. That's just the natural order of things.
[cpg]

[OnName num="gil"]
"The men are ready. Just give the word."
[cpg cn=true]

Gil, my partner in crime and a captain in my gang.
[cpg]

He's well-built and quick with a knife. Let's just say I didn't bring him on for his brains.
[cpg]

That said, he's not completely tactless. He knows how to control himself when the situation requires it.
[cpg]

[OnName num="eddie"]
"I can't wait to get my hands on one of them noble women."
[cpg cn=true]

We are a gang of bandits, but our goal is not only money and food.
[cpg]

Outlaws weren't exactly welcome in most towns, so there was a constant hunger for women.
[cpg]

That's why Rugalant presented a unique opportunity.
[cpg]

[OnName num="eddie"]
"Alright. Get the men together, it's time to take a Kingdom."
[cpg cn=true]

[OnName num="gil"]
"Yes, boss."
[cpg cn=true]

Rugalant had never known defeat...but neither did I.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



[SE f="se024"]
;//【ＳＥ】『戦場　剣を交える音など』


If everything went according to plan, it would be entirely one-sided.
[cpg]

After all, even Rugalant's knights were supposed to be women.
[cpg]

There's an insurmountable difference in physical power between men and women. I couldn't see any way we'd lose.
[cpg]

Strength was everything in our gang. The thought of women fighting seemed laughable.
[cpg]

It was impossible for us to lose......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]
;//【ＢＧ】『荒野』（昼）******************************************************
;//ここからステラのセリフの名前欄は「女将軍」と変えてください


[VOICE f="Stella001"]
[OnName num="female_general"]
"Push them back! Victory is with us!"
[cpg cn=true]

But the women of that country were far stronger and braver than I had expected.
[cpg]

They were well-trained and it seemed to me that they were used to battle.
[cpg]

It was as if the sexes were really reversed. That's how strong they were.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『荒野』（昼）******************************************************


[OnName num="gil"]
"......What do we do, boss? We're losing more men by the minute."
[cpg cn=true]

[OnName num="eddie"]
"You scared, Gil? Since when did you become such a coward?"
[cpg cn=true]

[OnName num="gil"]
"Of course not......but I don't see any way we can turn the tables."
[cpg cn=true]

He was right, of course. If something didn't change, we'd just keep losing men.
[cpg]

[OnName num="eddie"]
"I'm heading to the front lines, it's time to remind these knights who's really in charge."
[cpg cn=true]

I rushed to the front, but......
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『荒野』（夜）******************************************************


The line had collapsed before I knew what had happened.
[cpg]

[OnName num="gil"]
"......Boss! Are you alright?"
[cpg cn=true]

[OnName num="eddie"]
"Yeah......but......"
[cpg cn=true]

Most of my men were either captured or killed.
[cpg]

I can't help but be outraged by this, but what can I do about it?
[cpg]

We could regroup and try to launch another attack, but it would probably be useless. Our forces were severely depleted.
[cpg]

I needed a plan. After some thought, I determined the best course of action.
[cpg]

[OnName num="eddie"]
"I'll sneak in and destroy the country from the inside."
[cpg cn=true]

There might have been other options......but this seemed like a decent plan.
[cpg]

[OnName num="gil"]
"Are, are you serious? What can you do from the inside?"
[cpg cn=true]

[OnName num="eddie"]
"I'll think about that after I get in. In the first place, there is no way a woman could be fit to rule a whole country."
[cpg cn=true]

[OnName num="eddie"]
"Women were made to serve men. It's time to remind them of that fact."
[cpg cn=true]

Gil must be thinking that I am talking nonsense.
[cpg]

But there was no backing down after coming this far.
[cpg]

I wasn't going to end like this. I had to leave my mark on Rugalant.
[cpg]

No, not just a mark. I was going to destroy this damned Kingdom if it was the last thing I did.
[cpg]

[OnName num="gil"]
"I'll go with you. I can't let you do this alone."
[cpg cn=true]

[OnName num="eddie"]
"......Then who will keep the men in line while I'm gone?"
[cpg cn=true]

[OnName num="gil"]
"They'll figure something out. Besides, I can't let you have all the fun."
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


......And so Gil and I snuck into the Kingdom of Rugalant.
[cpg]

I had the men make camp just past the border. They were to lie in wait for our signal.
[cpg]

Though reluctant, they obeyed. I don't think we can keep them waiting for long.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se002"]
;//【ＳＥ】『街の喧騒』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


Upon making it into the Kingdom, we were faced with an incredible sight.
[cpg]

[OnName num="eddie"]
"Wow......it's all women."
[cpg cn=true]

[OnName num="gil"]
"They call Rugalant a blessed Kingdom, but maybe it's not just a rumor. It's hard to explain this gender ratio......"
[cpg cn=true]

If Ruglant had truly received a Blessing, then perhaps the Gods held a strong presence in this lands.
[cpg]

This country consisted mostly of women. There were some men here and there, but they were weak-looking.
[cpg]

I saw a few hanging laundry as if they were mere housewives.
[cpg]

How could men let themselves fall into such a weak position?
[cpg]

There are far too few of them to rile up into a rebellion.
[cpg]

[OnName num="eddie"]
"......Rugalant is supposed to be ruled by a Princess. Let's see if we can get a glimpse of her."
[cpg cn=true]

[OnName num="gil"]
"Alright......It looks like it'll take a lot of time and preparation before they're weak enough for us to launch another attack."
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（城から出て行くヒロイン１。ヒロイン２や他の護衛がついている）ev_01
;//人物１：ヒロイン１
;//服装１：ドレス
;//人物２：ヒロイン２
;//服装２：鎧
;//人物３：モブ女性
;//服装３：鎧
;//場所　：城下町
;//時間　：昼
;//========================================

;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;//[BGM f="bg_op"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


We make our way through town to the castle.
[cpg]

As luck would have it, someone fitting the bill was just walking out.
[cpg]

She had several guards in tow...all women, of course.
[cpg]

It was such an odd sight that I felt a chill run down my spine.
[cpg]

It wasn't natural. Women guarding a woman? This country was......wrong.
[cpg]


[VOICE f="Stella002"]
[OnName num="female_general"]
"Are you sure, Princess Alicia? I'm sure you're busy."
[cpg cn=true]


[VOICE f="Alicia001"]
[OnName num="alicia"]
"Yes, it's fine. The people must be frightened after the bandit attack."
[cpg cn=true]


[VOICE f="Stella003"]
[OnName num="female_general"]
"That may be true, but......"
[cpg cn=true]

I think she's talking about us. She was saying that the people are frightened......
[cpg]

I lost most of my men attacking this country and the people were merely frightened? I've never felt so insulted in my life.
[cpg]


[VOICE f="Alicia002"]
[OnName num="alicia"]
"More than that, I'm worried about you, Stella. You haven't slept since the battle, have you?"
[cpg cn=true]


;//ここから、ステラの名前欄をステラと表示してください



[VOICE f="Stella004"]
[OnName num="stella"]
"Of course......we drove them off, but it's just a matter of time before they return."
[cpg cn=true]


[VOICE f="Alicia003"]
[OnName num="alicia"]
"All the more reason for you to get some rest now, while you still can. You can worry about me after."
[cpg cn=true]


[VOICE f="Stella005"]
[OnName num="stella"]
"......Of course. I can't thank you enough for your kind words."
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


We tailed her from a distance.
[cpg]

[OnName num="woman"]
"Oh, Princess Alicia!"
[cpg cn=true]

[OnName num="woman"]
"Welcome, welcome......what brings you here?"
[cpg cn=true]

We followed the Princess and her escorts as they made their way toward the town.
[cpg]

She was talking to the people. Encouraging them, thanking them for their efforts and other things like that. I guess that's what a princess does.
[cpg]

But if she has time to go out and visit the people like this, it means she's just a figurehead. Someone else is running the actual country.
[cpg]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Alicia004"]
[OnName num="alicia"]
"A barbaric gang of bandits attacked our kingdom the other day, but there is nothing to fear."
[cpg cn=true]

[FACE method="bow_1" pos="2/5"]
[VOICE f="Alicia005"]
[OnName num="alicia"]
"Rugalant is protected by the bravest knights in all the lands. Live freely and without fear."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[VOICE f="Alicia006"]
[OnName num="alicia"]
"Remember that my heart is always with you, my people. Let us do our best for the prosperity of the Kingdom."
[cpg cn=true]

I can't stand it. Someone has to put an end to this ridiculous country.
[cpg]

......The women seemed pleased with the princess's words.
[cpg]

[OnName num="woman"]
"Yes! I'll do my best!"
[cpg cn=true]

The people in town looked nervous, but they were all smiling. The princess must be well-liked.
[cpg]


;//ＢＫ
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_se"]
;//[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


After Alicia and her group left, we thought about how we could drag the princess off her throne.
[cpg]

[OnName num="gil"]
"The first step would be to get into the castle......but I don't see that going well."
[cpg cn=true]

[OnName num="eddie"]
"Yeah. We should start by getting somebody in the town under our control."
[cpg cn=true]

We needed allies if we were going to operate in town.
[cpg]

We need at least one, though two might be better? Even getting a normal citizen on our side would help
[cpg]

We walk through the town trying to hammer out a plan...
[cpg]

[OnName num="gil"]
"There's a lot of lookers in town. The boy'll have a field day after we take this country for ourselves."
[cpg cn=true]

[OnName num="eddie"]
"......Wait."
[cpg cn=true]

I hush Gil to focus on the presence of some magic power nearby.
[cpg]

[OnName num="eddie"]
"I sense something. A strong magical force."
[cpg cn=true]

[OnName num="gil"]
"Really? I don't feel anything......"
[cpg cn=true]

Gil doesn't have the sense. There is definitely a magician or something nearby.
[cpg]

I trace the magic to a nearby florist.
[cpg]

I tell Gil to wait as I head inside.
[cpg]

[SE f="se006"]
;//【ＳＥ】『入店音』

;//========================================
;//●ＣＧ非エロ（花屋で花の手入れをするヒロイン）ev_02
;//人物１：ヒロイン３
;//服装１：私服
;//場所　：花屋
;//時間　：昼
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


;//ここからティナのセリフの名前欄は「花屋の店員」と変えてください



[VOICE f="Tina001"]
[OnName num="flower_shop_clerk"]
"Welcome......"
[cpg cn=true]

There was a woman who looked a little worn out.
[cpg]

Apparently, she is also the source of the magic. Why was such a powerful magician working in such a shabby flower shop?
[cpg]

I pretend to look at the flowers while trying to figure out who I was dealing with.
[cpg]

I really want to know what her story is.
[cpg]

I have a hunch......that she might be a great magician and is running a flower shop to hide her identity.
[cpg]

[OnName num="eddie"]
"What's this flower called?"
[cpg cn=true]


[VOICE f="Tina002"]
[OnName num="flower_shop_clerk"]
"Umm......that's a Gerbera...and that's what it looks like, I guess."
[cpg cn=true]

Yeah, I have eyes. I just wanted to know the name.
[cpg]

She isn't good at interacting with customers. A normal florist would at least tell me what it symbolized or something.
[cpg]

[OnName num="eddie"]
"Are there any magicians around here?"
[cpg cn=true]

She lowers her tone of voice and stares at me.
[cpg]


[VOICE f="Tina003"]
[OnName num="flower_shop_clerk"]
"I wouldn't know......You should look elsewhere."
[cpg cn=true]

That confirms that this was just a cover. Her real job likely had something to do with magic.
[cpg]

[OnName num="eddie"]
"It's strange. I'm sensing a powerful source of magic around here."
[cpg cn=true]

[OnName num="eddie"]
"Perhaps there's a magical item in use around here?"
[cpg cn=true]


[VOICE f="Tina004"]
[OnName num="flower_shop_clerk"]
"......I wouldn't know."
[cpg cn=true]

It seems she isn't receptive to the idea of talking about it.
[cpg]

[OnName num="eddie"]
"I'm Eddie. That guy waiting outside, is Gil."
[cpg cn=true]

The woman looks over at Gil, who waves.
[cpg]

[OnName num="eddie"]
"Remember our names, you'll be working with us soon enough."
[cpg cn=true]

After a moment of confusion, she bowed.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se006"]
;//【ＳＥ】『入店音』

[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


[OnName num="gil"]
"How'd it go?"
[cpg cn=true]

[OnName num="eddie"]
"She's a powerful magician, but she's hiding it for some reason."
[cpg cn=true]

[OnName num="gil"]
"So if we get her on our side, we might be able to use her to get into the castle."
[cpg cn=true]

[OnName num="eddie"]
"Yeah, we don't have any good magicians in the gang......"
[cpg cn=true]

[OnName num="eddie"]
"And even they'd rather split heads with an axe over chanting a spell. Magic would open up a lot of opportunities for us."
[cpg cn=true]

I don't know much about magic, but if it can be used to disguise oneself or something, it could be our key to the castle.
[cpg]

Now the question is how to get her to obey me.
[cpg]

;//女なら、快楽で落としてしまえばいい。これは、さっきの花屋に限った話じゃない。
It shouldn't be hard. Threatening her and dominating her usually works. Of course, this isn't restricted to the florist.
[cpg]

;//この国の女、全員を快楽漬けにしてやる。
I'm going to dominate every woman in this country.
[cpg]

To that end, I had to find some who could prove useful to me.
[cpg]

We walked around, taking note of any women who looked easy to dominate or held positions of power in their communities.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


As we looked around, I was struck by the abnormality of this country.
[cpg]

In every store and inn, the owner was a woman and the men are the helpers.
[cpg]

They all look thin and powerless. I've seen livelier slaves in my day.
[cpg]

All the men act like they'd been castrated. I get the chills just thinking about it.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


It was starting to get dark, I'm starving, and I'm starting to feel like I can't do this sober.
[cpg]

[OnName num="eddie"]
"I need a drink......"
[cpg cn=true]

[OnName num="gil"]
"Sounds good, boss. Fortunately, we have plenty of money."
[cpg cn=true]

[OnName num="eddie"]
"We wouldn't be very good bandits otherwise.."
[cpg cn=true]

There was nothing quite so sweet as the fruits of another's labors.
[cpg]

Of course, if we ran low on funds, we could always get some from the coffers back at camp.
[cpg]

We had money, but I wasn't sure how much time we had......
[cpg]

The men were hot-tempered and itching for revenge. Some hot head might write us off as dead and start the attack.
[cpg]

If they attacked before we were ready, they wouldn't stand a chance. I had to avoid that.
[cpg]

;//ここに元々あったev03は無くなってハーレムのev_50を分割するのに一枚使用

[SE f="se011"]
;//【ＳＥ】『ドア開閉』

[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『酒場』（夜）******************************************************



[OnName num="woman"]
"Ms. Ruth, you're late! Can't you hire somebody?"
[cpg cn=true]

[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Loose001"]
[OnName num="loose"]
"I'm sorry to keep you waiting. Yes, I'll give it some thought."
[cpg cn=true]

[OnName num="woman"]
"Come now, the ale here is well worth the wait."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Loose002"]
[OnName num="loose"]
"Why, thank you."
[cpg cn=true]

[OnName num="eddie"]
"......Nothing but women in here, too."
[cpg cn=true]

[OnName num="gil"]
"Yeah......it's nice to have plenty of options, but it's also kind of creepy."
[cpg cn=true]

Ruth, the proprietor, is also a woman. And almost all of the customers are women too.
[cpg]

Were men not allowed to drink alcohol in this country?
[cpg]

Are they just tools for making children? It wasn't right.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『酒場』（夜）******************************************************


I rubbed my temples for a moment to stave off this headache when Ruth came up to us.
[cpg]

[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Loose003"]
[OnName num="loose"]
"You are a traveler, aren't you? This country must appear awful strange to you."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Loose004"]
[OnName num="loose"]
"That said, I can't recommend you moving here. You'll have a real hard time fitting in."
[cpg cn=true]

She smiles. They probably didn't get many travelers, so we must have seemed quite unusual.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Loose005"]
[OnName num="loose"]
"Well, I'm sure there are men who are into that kind of thing. Who am I to judge?"
[cpg cn=true]

[OnName num="eddie"]
"It's true, I've never seen a country where it's so hard for men to live."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Loose006"]
[OnName num="loose"]
"There aren't many jobs for men here. Most of them are househusbands and have never done much more than housework."
[cpg cn=true]

[OnName num="gil"]
"No kidding? Well, it sounds like a pretty easy life."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Loose007"]
[OnName num="loose"]
"There aren't any decent men in all the kingdom. I hear it's different in other lands."
[cpg cn=true]

Men are stronger than women, so why are there so few jobs available to them?
[cpg]

My head began to ache again, but my desire to overthrow this country from the ground up grew even stronger.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『街』（夜）******************************************************


I was already exhausted, and now I was drunk. I had to find an inn before I collapsed.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『宿屋寝室』（夜）******************************************************


I went to an inn and got a room. I feel strangely tired today......
[cpg]

[OnName num="eddie"]
"We need a plan."
[cpg cn=true]

I can't just go around town randomly and do nothing. I have to make some kind of short-term goal.
[cpg]

[OnName num="gil"]
"You're right. What should we do? I don't have any good ideas."
[cpg cn=true]

I thought about it for a moment.
[cpg]


;//■選択肢


[switch]
[case "I need to take the princess down first."]
	[swap]
	[jump target="*select00_1"]
[case "I need to dominate somebody close to the princess."]
	[swap]
	[jump target="*select00_2"]
[case "I need to make an ally out of a townsperson."]
	[swap]
	[jump target="*select00_3"]
[case "I need to find out something to blackmail the royal family with."]
	[swap]
	[jump target="*select00_4"]
[endswitch]



1. I need to take the princess down first.
2. I need to dominate somebody close to the princess.
3. I need to make an ally out of a townsperson.
4. I need to find out something to blackmail the royal family with.



;//==============================
;//１、早々に姫を襲ってしまう
*select00_1|The Fearsome Bandits


;//（ヒロイン１選択肢発生）
[stflag FirstSelect = 1]


[OnName num="eddie"]
"We just gotta take the princess down, and fast."
[cpg cn=true]

[OnName num="gil"]
"You're joking, right?"
[cpg cn=true]

Gil laughs it off, but it was clear he was serious.
[cpg]

[OnName num="eddie"]
"Yeah. But this country makes me sick, I need something to laugh about or I'll go nuts."
[cpg cn=true]


[jump target="*select00_5"]

;//==============================
;//２、姫の部下から篭絡させていく
*select00_2|The Fearsome Bandits


;//（ヒロイン２選択肢発生）
[stflag FirstSelect = 2]


[OnName num="eddie"]
"We need to turn somebody close to the princess against her."
[cpg cn=true]

[OnName num="gil"]
"Well, that makes sense, but......I can't think of a way to do that."
[cpg cn=true]

[OnName num="eddie"]
"That's why I do all the thinking."
[cpg cn=true]


[jump target="*select00_5"]

;//==============================
;//３、誰か一般市民を味方につける
*select00_3|The Fearsome Bandits


;//（ヒロイン３選択肢発生）
[stflag FirstSelect = 3]


[OnName num="eddie"]
"We have to find somebody......well, anybody, who will become an ally."
[cpg cn=true]

[OnName num="gil"]
"That's a very roundabout strategy. It's unlike you, boss."
[cpg cn=true]

[OnName num="eddie"]
"Maybe, but I'm done playing around. I'm going to topple this kingdom even if it's the last thing I do."
[cpg cn=true]


[jump target="*select00_5"]

;//==============================
;//４、国の裏事情を手に入れる
*select00_4|The Fearsome Bandits


;//（ヒロイン４選択肢発生）
[stflag FirstSelect = 4]


[OnName num="eddie"]
"If we could get some information that could threaten the royal family, it'd be easy."
[cpg cn=true]

[OnName num="gil"]
"Who's got that kind of information?"
[cpg cn=true]

[OnName num="eddie"]
"Well, I have some idea."
[cpg cn=true]


;//==============================
*select00_5|The Fearsome Bandits


Shortly after chatting, we went to sleep.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I had an idea of where to start.
[cpg]

Or rather, I'd decided who I was going to target first.
[cpg]

Exhausted as I was, sleep came quickly to me.
[cpg]


[jump storage="ep001.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

