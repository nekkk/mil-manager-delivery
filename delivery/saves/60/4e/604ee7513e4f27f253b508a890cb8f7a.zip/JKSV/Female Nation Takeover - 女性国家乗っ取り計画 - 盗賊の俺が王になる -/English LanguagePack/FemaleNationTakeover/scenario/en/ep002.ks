*start|Taking Tina

;#################################################
*Ep002|Taking Tina
;#################################################

[SCENE id=2]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se006"]
;//【ＳＥ】『入店音』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『花屋』（昼）******************************************************


The next day we dropped by the flower shop again.
[cpg]

[OnName num="eddie"]
"Do you have enough money, Tina?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Tina064"]
[OnName num="tina"]
"Of course not......You still have most of it."
[cpg cn=true]

That's right, she was starting to understand her position.
[cpg]

I find a small creep across my face. I knew she'd say that.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Tina065"]
[OnName num="tina"]
"The amount you gave me yesterday isn't enough. I want it all back......"
[cpg cn=true]

[OnName num="eddie"]
"If you cooperate with me, I'll pay you even more than I took."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Tina066"]
[OnName num="tina"]
"......Fine."
[cpg cn=true]

Tina accepts my proposition without hesitation. Of course, it's not like she had any other choice.
[cpg]

There's nothing quite like holding leverage over somebody and forcing them to do your bidding.
[cpg]

It's an exhilarating feeling.
[cpg]

[OnName num="tina_brother"]
"Hey, what are you talking about? Did this person steal from you?"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Tina067"]
[OnName num="tina"]
"Uh, well......no, no, go play outside....."
[cpg cn=true]

[OnName num="tina_sister"]
"......"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
She is not good at lying to her siblings. But even if they knew the truth, the situation wouldn't change much.
[cpg]

;//移植のためシーンをカットしています
;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『住居寝室』（昼）******************************************************


[OnName num="gil"]
"Hey boss, shouldn't we be putting her in her place?"
[cpg cn=true]

Just when I was thinking that things were going smoothly, Gil interrupts with a crass suggestion.
[cpg]

The decision I make here could come back to bite me in the ass later......
[cpg]


;//※ヒロイン３選択肢発生、と書いてある部分を通っていなければ選択肢は発生せず
;//　選択肢２を選んだことになる

[if exp={getFlagValue("FirstSelect") == 3 }]
[jump target=*select03_0]
[endif]
[jump target=*select03_2]

*select03_0|Taking Tina

;//■選択肢
[switch]
[case "Reassure her."]
	[swap]
	[jump target="*select03_1"]
[case "Tell her the plan."]
	[swap]
	[jump target="*select03_2"]
[endswitch]

1. Reassure her.
2. Tell her the plan.



;//==============================
1. Reassure her.
*select03_1|Taking Tina


;//（ヒロイン３ポイント増加）
[stflag Cha3flg = 1]



[OnName num="eddie"]
"I'll stay with you a little longer, Tina."
[cpg cn=true]

;//移植のためシーンをカットしています

Tina is scared. But we have to make sure that she lets down her guard.
[cpg]

We are not the enemy. If anything, we're liberators who are here to correct the wrong ways of this country.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And so, for a while, I concentrated on getting Tina to trust me.
[cpg]

After that, I got to business.
[cpg]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『住居寝室』（昼）******************************************************




[jump target=*select03_3]

;//==============================
;//２、本題を話す
*select03_2|Taking Tina


[OnName num="eddie"]
"Why not? It's not like her money problems are going away any time soon."
[cpg cn=true]

[OnName num="gil"]
"Well, I guess......You might have a point."
[cpg cn=true]

Let's get down to business.
[cpg]


;//==============================
*select03_3|Taking Tina



[FACE method="change_4" pos="2/3"]

[OnName num="eddie"]
"Let me put it simply. I'm thinking of threatening someone."
[cpg cn=true]

[OnName num="gil"]
"That might be a little too simple......look, Tina's face looks like she's in shock."
[cpg cn=true]

Indeed, Tina looks blatantly frightened.
[cpg]

Well, blackmail isn't exactly a peaceful topic for conversation.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tina110"]
[OnName num="tina"]
"Wait, you want me to help you blackmail someone?"
[cpg cn=true]

[OnName num="eddie"]
"That's right. Of course, you can refuse and live in poverty if you prefer."
[cpg cn=true]

I went out of my way to tell her because I wanted her to cooperate. Tina seemed to have guessed this and had a bitter expression on her face.
[cpg]

That's why I also told her the consequences of disobeying me. So that she won't be able to say no.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tina111"]
[OnName num="tina"]
"......You mentioned that you were looking for somebody?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Tina112"]
[OnName num="tina"]
"There's magic for tracking people down."
[cpg cn=true]

What a pleasant surprise. I wonder how it works...
[cpg]

But when I said that I was looking for someone, it was more of a figure of speech. I can't explain the entire situation to Tina.
[cpg]

[OnName num="eddie"]
"Don't worry about it. More importantly, is there any other magic that you can threaten someone with?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Tina113"]
[OnName num="tina"]
"Come to think of it, how did you know I was a magician?"
[cpg cn=true]

Oh, right. That, too, might seem strange from Tina's point of view.
[cpg]

[OnName num="eddie"]
"I heard a rumor about you from Ruth and I have the ability to detect magic to some extent."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Tina114"]
[OnName num="tina"]
"......Oh, I see."
[cpg cn=true]

That said, I can't actually use magic, I'm just a bandit.
[cpg]

I've never trained or studied to be a magician.
[cpg]


;//下記セリフの蝸牛は「かたつむり」ではなく「かぎゅう」です
;//以降何度か出てきますが、全て同じ読みです


[FACE method="change_1" pos="2/3"]
[VOICE f="Tina115"]
[OnName num="tina"]
"If you simply want to threaten people, you might be able to use a cochlea stone."
[cpg cn=true]

[OnName num="eddie"]
"......A what? Cochlea?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Tina116"]
[OnName num="tina"]
"A stone that accumulates sound. It's shaped like this."
[cpg cn=true]

Tina said, searching the shelves. She only seems to have a vague recollection of where it was.
[cpg]

I'm still surprised that such a thing exists.
[cpg]

I am reminded once again that magicians aren't playing on the same level as the rest of us.
[cpg]

[OnName num="eddie"]
"So I understand that it can pick up sounds, but how big is it?"
[cpg cn=true]

Tina finally finds the stone that she was looking for.
[cpg]

I see, it is indeed a stone. It looks like an unprocessed gem to me.
[cpg]

It isn't that large, either. I could hide it in the palm of my hand.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Tina117"]
[OnName num="tina"]
"When you place it on a stable surface, it records sound."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Tina118"]
[OnName num="tina"]
"Then, when you put magic power into the stone, the sound will play back backwards."
[cpg cn=true]

So it's some sort of recording device.
[cpg]

Unlike other enchanted items, it's not capable of manifesting powerful magicks.


However, depending on how it's used, it could prove extremely useful.
[cpg]

......My mind races to think of what to do with this new tool. It didn't take long for me to come up with a use for it.
[cpg]

[OnName num="eddie"]
"It's perfect. Who would have thought such handy items existed?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Tina119"]
[OnName num="tina"]
"They're fairly rare. It takes a magician of my caliber to make one."
[cpg cn=true]

I see......it makes sense. If they were easy to get, rogues like myself would do whatever it took to get their hands on one.
[cpg]

But if Tina can make more, we're in business. It seems that I've found myself a really handy woman.
[cpg]

[OnName num="gil"]
"That's pretty cool. I didn't know stuff like this existed....."
[cpg cn=true]

[OnName num="eddie"]
"I'm going to borrow one. Of course, if you want me to buy it I'll pay for it."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Tina120"]
[OnName num="tina"]
"......Yeah."
[cpg cn=true]

If we take it, we'd obviously use it for something bad.
[cpg]

She knows that, but she can't refuse.
[cpg]

Tina nods, a dark expression on her face.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


As we head back, Gil starts to question me.
[cpg]

[OnName num="gil"]
"What are you planning? I can't really see a use for that thing."
[cpg cn=true]

He don't understand. That's not surprising, Gil isn't the brains of this operation.
[cpg]

But that doesn't mean he's stupid. We each had our own circumstances that prevented us from getting an education.....There's a lot of us in the same boat.
[cpg]

[OnName num="eddie"]
"We're going to sneak into Ruth's place now. We're going to record a conversation that she wouldn't want anyone to hear."
[cpg cn=true]

[OnName num="gil"]
"What good would that do? Then she'll know we snuck in and the guard will be on us like flies on carrion."
[cpg cn=true]

This was unusual. Gil seemed almost nervous about our prospects. Although he did have a point......
[cpg]

But it seems he hasn't quite realized what I was planning.
[cpg]

[OnName num="eddie"]
"Think about it for a moment......it's a way to get solid proof that she'd been succumbed to being dominated by a man."
[cpg cn=true]

[OnName num="gil"]
"I see...but evidence works both ways. If it all goes wrong, it's proof that we committed a crime."
[cpg cn=true]

It is true that recording evidence of trespassing is tempting fate.
[cpg]

But if we played our hand right, we'd have something to work with.
[cpg]

[OnName num="eddie"]
"Women have the upper hand in this country, how do you think it would go down?"
[cpg cn=true]

[OnName num="gil"]
"......I see."
[cpg cn=true]

Gil snorted and looked impressed. Yes, this country is unmistakably dominated by women.
[cpg]

They hold all the power and men were looked down upon as lesser beings.
[cpg]

If a woman was threatened by a man, her status in society would take a nosedive. They'd think of her as even less than a man.
[cpg]

It's a good deterrent against her trying to seek help.
[cpg]


[jump storage="ep003.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

