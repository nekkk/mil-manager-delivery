
;//++++++++++++++++++++++++++++++++++++++++++++++++++
;//『ハーレムエンド』（全てのヒロインのポイントが１度増加している場合）
*Ending_harlem|Righting the Wrong


*start|Righting the Wrong

;#################################################
*Ep011|Righting the Wrong
;#################################################

[SCENE id=11]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『宿屋寝室』（朝）******************************************************


It was the last day. I asked for the cooperation of all the women I had under my thumb.
[cpg]

[OnName num="gil"]
"How'd you come up with the idea to blackmail so many women?"
[cpg cn=true]

[OnName num="eddie"]
"What? It's always better to have more allies."
[cpg cn=true]

[OnName num="eddie"]
"That way you don't have to worry if one or two get cold feet."
[cpg cn=true]

[OnName num="gil"]
"I guess that's a good point. Who do you want to see first?"
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


I headed for the castle first. If we were going to war, then that's where it had to start.
[cpg]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城内の一室』（朝）******************************************************


[OnName num="eddie"]
"We'll go to Alicia first. Most people will obey her commands."
[cpg cn=true]

[OnName num="gil"]
"As long as it's nothing too outlandish."
[cpg cn=true]

Outlandish didn't even begin to describe it.
[cpg]

We have to be careful about how we do this. I'll need Stella, Tina, and Ruth's cooperation.
[cpg]


;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_op"]
;//[WAIT time=100]
;//【ＢＧ】『姫の寝室』（朝）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Alicia348"]
[OnName num="alicia"]
"What do you want me to do......?"
[cpg cn=true]

[OnName num="eddie"]
"Once we start the attack, I want you to surrender unconditionally."
[cpg cn=true]

[OnName num="eddie"]
"There will be soldiers who will not obey, but that's not a problem."
[cpg cn=true]

[OnName num="eddie"]
"They'll be disobeying orders and that hesitation will make them easier to take down."
[cpg cn=true]

[OnName num="eddie"]
"Do as I say and you'll live to see the morning."
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Alicia349"]
[OnName num="alicia"]
"......I understand."
[cpg cn=true]

[OnName num="eddie"]
"Good, I'm counting on you the most."
[cpg cn=true]


;//ＢＫ


Next, I went to see Stella. Unlike the princess, I didn't have her life in my hands......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『城内の一室』（朝）******************************************************


[OnName num="eddie"]
"I told Alicia to surrender when we attack. I trust you'll obey her orders."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Stella294"]
[OnName num="stella"]
"......I can't guarantee my soldiers will obey, are you okay with that?"
[cpg cn=true]

[OnName num="eddie"]
"It's not a problem."
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Stella295"]
[OnName num="stella"]
"......I'll obey the princess. Will this be enough to bind the princess and I together?"
[cpg cn=true]

[OnName num="eddie"]
"Of course it is. Don't worry, I'll prioritize my deal with you over everyone else."
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[OnName num="eddie"]
"We're done with the castle......"
[cpg cn=true]

[OnName num="gil"]
"Aye, boss. Are we going to Ruth and Tina?"
[cpg cn=true]

[OnName num="eddie"]
"Yeah. I'll talk to them, too."
[cpg cn=true]


[SE f="se006"]
;//【ＳＥ】『入店音』

[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『花屋』（朝）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Tina342"]
[OnName num="tina"]
"......What do you want?"
[cpg cn=true]

[OnName num="eddie"]
"We launch the attack this evening."
[cpg cn=true]

[OnName num="eddie"]
"Can you stir up trouble from behind their lines?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Tina343"]
[OnName num="tina"]
"......Weakening magic should be hard to detect."
[cpg cn=true]

[OnName num="eddie"]
"That'll do."
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Tina344"]
[OnName num="tina"]
"If this is what you want......I'll do it."
[cpg cn=true]

[OnName num="eddie"]
"I'm glad to see you behaving so obediently."
[cpg cn=true]

[OnName num="eddie"]
"You've been the most help to me out of everybody I've met so far."
[cpg cn=true]

[OnName num="gil"]
"......"
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


[OnName num="gil"]
"It sure sounds like you're giving them all the same pep talk."
[cpg cn=true]

[OnName num="eddie"]
"You noticed that, did you? It's all part of the plan."
[cpg cn=true]

[OnName num="gil"]
"It's not like you, boss."
[cpg cn=true]

[OnName num="eddie"]
"Don't fret your pretty little head. Trust in me and we'll come out of this on top."
[cpg cn=true]

Gil stares questioningly for a moment.
[cpg]


[SE f="se011"]
;//【ＳＥ】『ドア開く』

[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『酒場』（昼）******************************************************


[OnName num="eddie"]
"Hey, Ruth. I need a little favor."
[cpg cn=true]

[FG f="CHA04_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Loose307"]
[OnName num="loose"]
"What? Are you invading already?"
[cpg cn=true]

[OnName num="eddie"]
"No, of course not. I need you to spread a rumor that we're giving up on Rugalant."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Loose308"]
[OnName num="loose"]
"......If I do that, this country will burn."
[cpg cn=true]

[OnName num="eddie"]
"Fine, fine. Just remember, we have leverage, and one way or another, your tavern is done for."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Loose309"]
[OnName num="loose"]
"......"
[cpg cn=true]

[OnName num="eddie"]
"I could really use your help. What do you say?"
[cpg cn=true]

I didn't get an answer out of Ruth. Well, that's all right.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[OnName num="gil"]
"Let's get back to camp. The others are probably sick of waiting."
[cpg cn=true]

[OnName num="eddie"]
"I bet. At least now we can finally go back to being bandits."
[cpg cn=true]

[OnName num="gil"]
"What a strange country. There are so few men that it's hard to imagine what their marriages look like."
[cpg cn=true]

[OnName num="eddie"]
"Somehow I doubt this country even understands the concept of marriage."
[cpg cn=true]

[OnName num="eddie"]
"They probably just see men as tools to breed."
[cpg cn=true]

[OnName num="gil"]
"Makes sense, I guess......most of the men are probably stuck doing chores at home."
[cpg cn=true]

[OnName num="eddie"]
"I don't really want to know. It's wrong for men to be living in the shadows of women."
[cpg cn=true]

Either way, it was time to leave. The next time we visited, it would be to plunder the place.
[cpg]


;//ＢＫ

[SE f="se001"]
;//【ＳＥ】『歩く』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]



We head past the border to the camp.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『荒野』（夕方）******************************************************


[OnName num="bandit"]
"Boss? Are you back?"
[cpg cn=true]

[OnName num="bandit"]
"Hey, guys! The boss is back!"
[cpg cn=true]

[OnName num="bandit"]
"Does that mean we're finally going to attack?"
[cpg cn=true]

[OnName num="eddie"]
"Hold your horses......I'm beat after that bloody hike. Someone get me some ale."
[cpg cn=true]

[OnName num="bandit"]
"Yes, sir!"
[cpg cn=true]

It seems the men were at least energetic.
[cpg]

[OnName num="gil"]
"What's the plan? Do we launch the attack tonight?"
[cpg cn=true]

[OnName num="eddie"]
"Yeah, I don't think we can hold them back for much longer."
[cpg cn=true]

[OnName num="eddie"]
"What do our supplies look like?"
[cpg cn=true]

[OnName num="bandit"]
"A few days of food, no more."
[cpg cn=true]

[OnName num="bandit"]
"More importantly, I'm tired of waiting around and doing nothing."
[cpg cn=true]

[OnName num="bandit"]
"I want to invade that country right now, I hate it so much!"
[cpg cn=true]

That's what I thought. It had to happen tonight.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]
;//【ＢＧ】『荒野』（夜）******************************************************


That night, I led my men across the border.
[cpg]

[OnName num="eddie"]
"Let's go, boys!"
[cpg cn=true]

[SE f="se024"]
;//【ＳＥ】『戦闘　剣を交える』

;//ＢＫ
[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『荒野』（夜）******************************************************


It wasn't much of a battle, honestly.
[cpg]

[OnName num="female_soldier"]
"Why is Princess Alicia saying she's surrendering......?"
[cpg cn=true]

[OnName num="female_soldier"]
"I don't know, but we can't give up now!"
[cpg cn=true]

[OnName num="female_soldier"]
"Of course not! But morale is low..."
[cpg cn=true]

[OnName num="female_soldier"]
"Damn......! What's going on?"
[cpg cn=true]

The soldiers were distracted and confused. They were easy prey for my men.
[cpg]

[OnName num="bandit"]
"Pathetic! How did we lose to this lot?"
[cpg cn=true]

[OnName num="bandit"]
"Yeah, I know it was all part of the plan but this is more than I expected......"
[cpg cn=true]

[OnName num="bandit"]
"I guess they never expected anybody to betray them."
[cpg cn=true]

[OnName num="bandit"]
"Maybe that's the difference between men and women......"
[cpg cn=true]

We had Tina's magic and Ruth's false information.
[cpg]

And with Alicia's and Stella's orders, Rugalant's army had all but ceased to function.
[cpg]


[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


[SE f="se024"]
;//【ＳＥ】『戦闘　剣を交える』


My men head into the city to sack it.
[cpg]

[OnName num="woman"]
"Noooo! Someone help!"
[cpg cn=true]

[OnName num="woman"]
"Why are there bandits here!?"
[cpg cn=true]

[OnName num="woman"]
"I thought the soldiers in this country were strong......!"
[cpg cn=true]

With nobody left to stop them, the bandits sweep through the town, looting and pillaging as they go along.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="fire1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="fire1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Then on the next day.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『姫の寝室』（朝）******************************************************


I was exhausted and spent most of the night asleep. When I awoke, everything was already over.
[cpg]

Or rather, most everything had ended before I went to sleep.
[cpg]

The kingdom had collapsed and the bandits were probably still roaming the streets.
[cpg]

I could check if I wanted to, but I had other business to attend to.
[cpg]

[OnName num="eddie"]
"This bed looks expensive......"
[cpg cn=true]

I was sleeping in Alicia's bed. This is the room of the highest authority in the country.
[cpg]

I wanted to feel what it was like to sleep like a king.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I sat on the throne earlier, but I didn't really feel anything special. I guess there wasn't much to see from up here.
[cpg]

Or maybe it was because the castle had already been ransacked.
[cpg]

[OnName num="bandit"]
"Boss, we stole everything there was to steal. What do we do now?"
[cpg cn=true]

[OnName num="eddie"]
"Alicia, Stella, Tina, Ruth."
[cpg cn=true]

[OnName num="bandit"]
"Yes?"
[cpg cn=true]

[OnName num="eddie"]
"Bring me the four I just mentioned. If they're hiding somewhere, find them."
[cpg cn=true]

They wouldn't have gotten mixed up in the battle, right? They're not stupid enough to fight a war they know they're going to lose.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/4" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/4" time=1]
[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="4/4" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/4" time=1]

[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『姫の寝室』（昼）******************************************************


[OnName num="bandit"]
"I've brought them......"
[cpg cn=true]

[OnName num="eddie"]
"Good. You're excused."
[cpg cn=true]

[OnName num="bandit"]
"Yes, sir."
[cpg cn=true]

Was this the first time all four of them were in the same room? Probably.
[cpg]


[FACE method="shake_7" pos="1/4"]
[VOICE f="Alicia350"]
[OnName num="alicia"]
"......Why did you bring us here?"
[cpg cn=true]

[OnName num="eddie"]
"That's because you four were pivotal in taking the kingdom. Good work, all of you."
[cpg cn=true]

[FACE method="bow_5" pos="2/4"]
[VOICE f="Stella296"]
[OnName num="stella"]
"Ruth......you too?"
[cpg cn=true]

[FACE method="shake_7" pos="2/4"]
[VOICE f="Stella297"]
[OnName num="stella"]
"I knew that Tina was siding with the bandits."
[cpg cn=true]

[FACE method="bow_7" pos="3/4"]
[VOICE f="Tina345"]
[OnName num="tina"]
"I know pretty much everything."
[cpg cn=true]

[FACE method="change_7" pos="4/4"]
[VOICE f="Loose310"]
[OnName num="loose"]
"Even Princess Alicia......You sure are something."
[cpg cn=true]

Their reactions differed, but at that moment, I'm sure they felt the same thing.
[cpg]

;//移植のためシーンをカットしています



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

Some time later.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『姫の寝室』（夕方）******************************************************


Women are creatures that obey men. This country was crazy to begin with.
[cpg]

All I did was set it back on track. I restored some semblance of normalcy to this twisted land.
[cpg]

[OnName num="gil"]
"Once you're done, we'll head to the next country or town, right boss?"
[cpg cn=true]

[OnName num="eddie"]
"That's right. I haven't had my fill yet. I'll make all the women in the world mine."
[cpg cn=true]


;//【ハーレムエンド】エンド

[SCENE id=16]

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////

