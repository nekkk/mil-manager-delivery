
;//１、毬枝

*start

;//==============================
;//催眠術を際限なく使う　を選んでいた場合
*root_11

[jump target="*jump2"]


;#################################################
*Ep002|Even if your senior's heart is broken
;#################################################


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]


*jump2|Even if your senior's heart is broken.

[SCENE id=2]


Marieda. Targeting senpai.
[cpg]


It's late today. I need to do a lot of prep work.
[cpg]


I might be too excited to sleep, but I still decided to go home and sleep.
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Hypnotism has no limits. I don't care if it destroys my mind.
[cpg]

I will do whatever I want to do. If that were the case, there would be no need for any strategy.
[cpg]

I would just have to convince him that I was his girlfriend and it would all be over.
[cpg]

There will be no reason to run away, and no one will call for help. ......
[cpg]

So there is nothing to fear. After thinking about it, I decided to go ahead with the plan.
[cpg]

[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



I know where Marie lives. It's not far from here, in an apartment.
[cpg]


She must still be at her lodgings. If she's not there, I'll just change the target to someone else. ......
[cpg]


I was hoping to target Marie. I couldn't afford to stumble upon her at this point.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

[SE f="se011"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=1100]

I headed over to the place and rang the intercom.
[cpg]


A few moments later, Marie answered.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Marie068"]
[OnName num="marie"]
She said, "E......?　Toma-kun?　How do you know my house ......?"
[cpg cn=true]


Oh, shoot. I had forgotten about that.
[cpg]


I had erased the memory of asking for the address. If that was the case, would I be surprised here first?
[cpg]


After thinking for a moment, Marie tries to close the door. I couldn't refuse her, so I put my foot between the doors.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Marie069"]
[OnName num="marie"]
I'm scared!　Answer me, how did you know my address?
[cpg cn=true]


[OnName num="toma"]
I'm so scared! I can't close the door.
[cpg cn=true]

[FACE method="change_8" pos="2/3"]
Through the smallest crack in the door. But it worked.
[cpg]


Little by little, the strength drained out of me. Seeing this, I hypnotized him again.
[cpg]


[OnName num="toma"]
"I can't get any more strength,......, and I fall down on the spot.
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Marie070"]
[OnName num="marie"]
Oh,......, ah!
[cpg cn=true]



[SE f="se013"]
;//【ＳＥ】『人が倒れる』

[FO pos="2/3" time=1000]

The actual "Marijuana" is a very good way to get a good deal more information about the product or service. The most important thing to remember is that you can't be too careful.
[cpg]


 Or rather, it's pretty bad to see this moment right now.
[cpg]


The actual a lot more the better.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************



It was a tidy room. It was a tidy room, but it also had the feel of a woman living alone.
[cpg]

I have never been in a girl's room before, but I guess it was like this: ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marie071"]
[OnName num="marie"]
"Hmmm,......, what's that,......?"
[cpg cn=true]


[OnName num="toma"]
Good morning, senpai. No, Marije."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Marie072"]
[OnName num="marie"]
"Why is ...... Toma-kun here?　Yes, it's me.
[cpg cn=true]


[OnName num="toma"]
I'm not sure what you're talking about, but I'm sure you'll be able to figure it out. You won't be able to open the front door."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Marie073"]
[OnName num="marie"]
What?　No way, hypnosis ......!
[cpg cn=true]


[OnName num="toma"]
No matter what happens, you won't be able to put any pressure on the doorknob. Okay?"
[cpg cn=true]


The ballerina shows a frightened expression. And then he backs away just like that.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Marie074"]
[OnName num="marie"]
Oh, ...... ah!"
[cpg cn=true]


She opens the door to this room and exits, but not yet at the exit.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[VOICE f="Marie075"]
[OnName num="marie"]
Why?　I can't open it, I can't open it!
[cpg cn=true]


I put my hand on the doorknob again and again, but I can't get the strength to open it.
[cpg]


That's right, that's how hypnosis works.
[cpg]


[OnName num="toma"]
Give it up. Come on, come here.
[cpg cn=true]



[VOICE f="Marie076"]
[OnName num="marie"]
......"
[cpg cn=true]


Marie seemed to have given up and came toward me.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marie077"]
[OnName num="marie"]
What should I do ...... to get her out of this hypnosis?
[cpg cn=true]


[OnName num="toma"]
The first thing to do is to make sure that you have a good idea of what you're doing. I'm not sure if it's up to her or not.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Marie078"]
[OnName num="marie"]
"...... like that ......"
[cpg cn=true]


[OnName num="toma"]
You know what I'm talking about, don't you?　You know why I'm doing this.
[cpg cn=true]


I'm sure you haven't lost your will to resist me.
[cpg]


I just don't want them to do anything more to me. That's the only reason you're listening to me. ......
[cpg]


;//========================================
;//●ＣＧ（主人公のすぐ前に居るヒロイン。催眠にかかっていない）ev_10
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sMarie003"]
[OnName num="marie"]
......Why are you doing this?
[cpg cn=true]


Why. It's obvious, but if you say it, it's not worth it.
[cpg]

[OnName num="toma"]
I'm not going to say that. It doesn't matter. ......"
[cpg cn=true]


 I reached for her body, saying so.
[cpg]

 Marie stiffens her body for a moment, but she doesn't resist.
[cpg]

 It seemed like a conflict in my heart, and I was delighted with it.
[cpg]

;**【ＣＧ】 ev_10_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sMarie004"]
[OnName num="marie"]
......."
[cpg cn=true]


I raised my voice. It was a voice that I almost missed.
[cpg]

She is a lovely person. I was happy to think that she would be by my side for a long time to come.
[cpg]

I thought about hugging her, but I decided to save that for later.
[cpg]

[VOICE f="sMarie005"]
[OnName num="marie"]
What's this going to do for you? ......
[cpg cn=true]


[OnName num="toma"]
I'm going to do it even if it doesn't make a difference. I'm going to do it because I want to.
[cpg cn=true]

;**【ＣＧ】 ev_10_b ***********************
[CG id=6 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMarie006"]
[OnName num="marie"]
......."
[cpg cn=true]


She looked pained, but that was all.
[cpg]

[OnName num="toma"]
'Well, brace yourself. I'm not going to give you your freedom."
[cpg cn=true]


She gives me a look of despair. That alone was enough to make the mission worthwhile.
[cpg]

So what do we do now? We already know that she is easily hypnotized.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Marie098"]
[OnName num="marie"]
I'm going to go to ...... and see if I can find her. Ughhh..."
[cpg cn=true]


Marie was crying. I'm not going to let her go.
[cpg]


[OnName num="toma"]
You know the effect of my hypnotism. From now on, you are stuck in this room.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sMarie007"]
[OnName num="marie"]
Are you trying to lock me in ......?
[cpg cn=true]


[OnName num="toma"]
You swallow fast. That's right.
[cpg cn=true]


[OnName num="toma"]
Of course, I'll get you food and groceries. Don't worry, I've got some money saved up.
[cpg cn=true]


[OnName num="toma"]
In the meantime, I'm going to hypnotize her and make her unconscious. Naturally."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Marie100"]
[OnName num="marie"]
How can you come up with such a terrible ...... idea?
[cpg cn=true]


The most important thing to remember is that you should never be afraid to ask for help. The most important thing to remember is that you should not be afraid to ask for help.
[cpg]


[OnName num="toma"]
I'm not going to do anything about it. If you don't, I'll hypnotize you and force you to do it.
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And so our life together began.
[cpg]

For me and for her, there was no more routine.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************



[OnName num="toma"]
I think I'll go get some lunch then. Turn around, Marie.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marie101"]
[OnName num="marie"]
"......"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
She wouldn't look at me. I'm not sure what to do with it, but I'm sure it will work.
[cpg]


[OnName num="toma"]
You're going to lose consciousness now. You won't wake up until I come back.
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Marie102"]
[OnName num="marie"]
Ah......, hah!
[cpg cn=true]


[free time=1000]




This is good.
[cpg]


[OnName num="toma"]
The actuality is that you can find a lot of people who are not aware of the fact that they are not aware of the fact.
[cpg cn=true]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



 I will buy a bento at a convenience store.
[cpg]


 You can cook a normal meal separately, but that doesn't create an atmosphere.
[cpg]


I'm not going to make him eat a home-cooked meal, and I'm not going to eat his home-cooked meal, either.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se005"]
;//【ＳＥ】『ドア開く』




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



[OnName num="toma"]
I'm not going to make him eat homemade food, and I'm not going to eat his food. Eat."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Marie103"]
[OnName num="marie"]
"I can't ...... eat this. I don't want to eat it.
[cpg cn=true]


Maybe he is under extreme stress and has lost his appetite.
[cpg]


[OnName num="toma"]
"Don't be so picky. I don't care if you hypnotize me to eat. I can hypnotize you to eat.
[cpg cn=true]


Hearing this, she looked as if she had given up.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Marie104"]
[OnName num="marie"]
All right, I'll eat. ......
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]



And after we ate, I decided to hypnotize Marie to get close to me.
[cpg]

[OnName num="toma"]
'Now you're going to feel the cold.
[cpg cn=true]


[OnName num="toma"]
So much so that you will have to be warmed by someone's human skin to make it bearable. ......
[cpg cn=true]


Hearing my words, she paled.
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ（背後から抱きしめられるヒロイン。寒く感じる催眠を受けている）ev_11
;//人物１：ヒロイン１
;//服装１：私服（半脱ぎ）
;//人物２：主人公
;//服装２：私服（半脱ぎ）
;//場所　：ヒロイン１の部屋
;//時間　：夜
;//========================================



[BGM f="bg_h1"]
;**【ＣＧ】 ev_11_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sMarie008"]
[OnName num="marie"]
"Ugh,...... what is this,......?"
[cpg cn=true]


My hypnosis is taking effect and Marie is shivering.
[cpg]

[VOICE f="sMarie009"]
[OnName num="marie"]
It's cold, why, it's in the room.
[cpg cn=true]


That's a good response. I wonder how much longer she will be able to endure this.
[cpg]

I watched her for a while and then she leaned closer to me.
[cpg]

[VOICE f="sMarie010"]
[OnName num="marie"]
Oh ......, it's so warm ......."
[cpg cn=true]


The fact that human skin feels warm is also included in the hypnosis.
[cpg]

It is natural for this to happen. I looked at her and hugged her from behind.
[cpg]

I'm not sure if this is a good idea or not, but I'm sure it's a good idea.
[cpg]

;**【ＣＧ】 ev_11_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sMarie011"]
[OnName num="marie"]
"Phew...... more, warm it up."
[cpg cn=true]


I was thinking about what I was going to do now with a sense of accomplishment.
[cpg]

[VOICE f="sMarie012"]
[OnName num="marie"]
I'm going to freeze if I don't do this, hah......."
[cpg cn=true]


Somewhere I heard a story about a man who was trapped in a refrigerator.
[cpg]

A refrigerator with the power turned off. It was not really cold, but people froze to death in it because they thought they were in a cold place.
[cpg]

She is probably in that situation now.
[cpg]

And I am undoubtedly the one who is creating that situation. I can't stop laughing when I think about that.
[cpg]

;**【ＣＧ】 ev_11_b ***********************
[CG id=7 index=2 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sMarie013"]
[OnName num="marie"]
"Oh, ......, please, hug me."
[cpg cn=true]


She asked me to hug her, and I did.
[cpg]

[OnName num="toma"]
I can't help it if she wants me so much.
[cpg cn=true]


I was in a state of unparalleled pleasure.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



After I was hypnotized, I decided to change things up a bit.
[cpg]

Of course, it was also very pleasurable to have to be with her even though she didn't want to be there.
[cpg]

But I was no longer satisfied with that.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************



The morning would come. I took over the bed and let Marie sleep on the floor. There was no reason for me to be shy here.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marie126"]
[OnName num="marie"]
I'm not going to be able to sleep in the morning ......?　You're not dreaming, are you?"
[cpg cn=true]


I was so excited to see her staggering toward the front door.
[cpg]


I don't need to chase after her. The hypnosis she's under must be persistent, so I can't open the door.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Marie127"]
[OnName num="marie"]
I can't open the door.
[cpg cn=true]


[OnName num="toma"]
I'll put her under a different kind of hypnosis. Marieda.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Marie128"]
[OnName num="marie"]
What are you going to do ......?　What more ......
[cpg cn=true]


[OnName num="toma"]
Listen. You and I are going to be lovers.
[cpg cn=true]


The first thing to do is to make sure that you have a good time. The first thing that you need to do is to make sure that you have a good time.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Marie129"]
[OnName num="marie"]
The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it.　I don't like it!
[cpg cn=true]


[OnName num="toma"]
She thinks that they are lovers, and that they are living together now. ......
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Marie130"]
[OnName num="marie"]
"Oh ...... ahhh!"
[cpg cn=true]

[free time=1000]
[SE f="se013"]
;//【ＳＥ】『人が倒れる』

The most important thing to remember is that you should not be afraid to ask for help. The most important thing to remember is that you should not be afraid to ask for help.
[cpg]


The most important thing to remember is that the best way to get the most out of your time in the world is to be a good person.
[cpg]


[OnName num="toma"]
By the time you wake up, you'll be in love with me.
[cpg cn=true]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************



[OnName num="toma"]
You're awake?　Marije.
[cpg cn=true]


Now you're supposed to think I'm your boyfriend. What do you think?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marie131"]
[OnName num="marie"]
'Oh, oh ...... Toma-kun. Why did I fall asleep?"
[cpg cn=true]


The face showed no sign of alarm. I am relieved.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Marie132"]
[OnName num="marie"]
I was hungry. ...... Shall I make you something to eat?
[cpg cn=true]


[OnName num="toma"]
I'm not sure what to do. I'll do it.
[cpg cn=true]


I think there were ingredients in the fridge. I'm sure there were ingredients in the fridge.
[cpg]


I helped Marije cook while holding back my laughter.
[cpg]




;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************



After lunch, she looked at me with a happy expression on her face.
[cpg]

It's funny to think that just a few minutes ago she was hating me.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sMarie014"]
[OnName num="marie"]
She was looking at me with a happy expression on her face. Do you like me?"
[cpg cn=true]


He seemed to be unable to suppress the feelings that had suddenly sprouted in him, and asked me something like that.
[cpg]

[OnName num="toma"]
I was so happy to think that he had hated me earlier. I like you.
[cpg cn=true]


I can say as much as I want. I really like Marie.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="sMarie015"]
[OnName num="marie"]
I'm sure you'll be able to spend a lot of time with her since it's summer vacation.
[cpg cn=true]


[OnName num="toma"]
"......, that's right."
[cpg cn=true]


The first time I saw him, I thought he was a good guy.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************

This time we decided to cook dinner. ......
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sMarie016"]
[OnName num="marie"]
We are short of ingredients for dinner. ...... Shall we go shopping together?
[cpg cn=true]



[OnName num="toma"]
I said, "...... sure."
[cpg cn=true]


However, this is only confinement.
[cpg]


The most important thing to remember is that you can't just go out and buy a new pair of shoes.
[cpg]


[OnName num="toma"]
Turn around and look at me, Marije.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Marie155"]
[OnName num="marie"]
What?　What is it?
[cpg cn=true]


[OnName num="toma"]
"You're going to faint ...... the next time you wake up, the memory of the two of us going shopping will be imprinted on you."
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Marie156"]
[OnName num="marie"]
You'll be ...... ah, ......."
[cpg cn=true]


[free time=1000]
[SE f="se013"]
;//【ＳＥ】『人が倒れる』




As per my hypnosis, Marie fainted.
[cpg]


I'm not sure what to expect, but I'm sure I'm going to be fine. I'm going to go outside in the meantime.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



I'm going to buy some foodstuffs. I'm going to cook for them today.
[cpg]


So I picked them out with my own sense of taste. I also buy some daily necessities because I don't want to run out of them.
[cpg]


[OnName num="toma"]
I'll just go to .......
[cpg cn=true]


I carry the heavy luggage by myself. I thought that I should have brought Marije with me after all, but that wouldn't have been the best part of locking her up.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



The most important thing to remember is that the best way to get the most out of your home is to be sure that your home is clean and well maintained.
[cpg]


I was still playing lover with her while I locked her up. I'm not sure how much I'm going to be able to do.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Marie157"]
[OnName num="marie"]
I'm sure you're a good cook, Toma.
[cpg cn=true]


[OnName num="toma"]
The most important thing to remember is that you can't just go out and buy a new one. The most important thing to remember is that you should never be afraid to ask for help.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Marie158"]
[OnName num="marie"]
I don't know if that's true,......, but I've got a good boyfriend.
[cpg cn=true]


The most important thing to remember is that you should not be afraid to ask for help.
[cpg]

[OnName num="toma"]
I'm going to go take a bath.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMarie017"]
[OnName num="marie"]
Oh, yeah. Oh, yeah."
[cpg cn=true]


It seems that Marie was expecting something. I'm sorry to betray that, but ......
[cpg]

But I want to save the important stuff for last.
[cpg]


;//移植のためシーンをカットしています


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



And so that night passed.
[cpg]


Our days of cohabitation still go on. I was unaware that Marie was hypnotized into doing this.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Marie178"]
[OnName num="marie"]
She said, "Good morning. You looked so cute sleeping.
[cpg cn=true]


[OnName num="toma"]
......
[cpg cn=true]


I don't feel very good about it. The most important thing to remember is that you can't just go out with your friends and family and expect them to be happy.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Marie179"]
[OnName num="marie"]
I'm not doing this to make out with you.　It's too stuffy being in the house all the time."
[cpg cn=true]


If I did that, it wouldn't be called confinement anymore. But, yes, it is.
[cpg]


[OnName num="toma"]
"All right. Then let's go."
[cpg cn=true]

[FACE method="change_8" pos="2/3"]
And so, I hypnotized her. We decided to go on a date without leaving the house.
[cpg]


That's how I hypnotized her. I could do anything now.
[cpg]


[OnName num="toma"]
I said, "Look, this is a park. You're going to think you're in a park.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Marie180"]
[OnName num="marie"]
"...... yeah."
[cpg cn=true]


And that's boring, so I decide to abuse him a little bit.
[cpg]


[OnName num="toma"]
It feels good to be outside. I'm sure Ballina feels the same way."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Marie181"]
[OnName num="marie"]
"Yes,...... but there's something weird about it,......."
[cpg cn=true]


The most important thing to remember is that you can't go wrong with the way you look.
[cpg]


The most important thing to remember is that the best way to get the most out of your money is to be honest with yourself.
[cpg]


[OnName num="toma"]
I wonder what they think this place is, a bench or something. Why don't we make out here?
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="sMarie018"]
[OnName num="marie"]
"What?　But, but ......
[cpg cn=true]


[OnName num="toma"]
"I'll show you. I don't know.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sMarie019"]
[OnName num="marie"]
I'm embarrassed ...... to do that."
[cpg cn=true]


 I pushed through the shy Marie and leaned over.
[cpg]



;//========================================
;//●ＣＧ（人前であると催眠をかけて、ヒロインといちゃつく）ev_14
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：朝
;//========================================


[free time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]

If that's the case,......
[cpg]

The most important thing to remember is that you can't just kiss a girl and expect her to be embarrassed.
[cpg]

[OnName num="toma"]
I might even try kissing her."
[cpg cn=true]


[VOICE f="sMarie020"]
[OnName num="marie"]
"Are you serious ......?　I'm not ready for that."
[cpg cn=true]


Marie's face is red.
[cpg]

[OnName num="toma"]
I'm not sure if I'm ready to do that.
[cpg cn=true]


She obeyed my words. Then, I moved my lips closer to hers.
[cpg]

I felt her body temperature was higher than usual, as if she really thought we were in the park.
[cpg]

I pulled my face away from hers, thinking, "You're going to show me a face like this. ......
[cpg]

[OnName num="toma"]
You look pretty."
[cpg cn=true]


;**【ＣＧ】 ev_14_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=1000]


Marie looks shy. But that part of her was also attractive.
[cpg]

[VOICE f="sMarie021"]
[OnName num="marie"]
I'm so surprised that you're suddenly doing this. I'm surprised.
[cpg cn=true]


The look on her face when she said that was really the look she would give to her lover.
[cpg]

Rather than wanting to take good care of her, she seemed to want to destroy her. ......
[cpg]

[OnName num="toma"]
I'm sorry, I'm sorry. I just wanted to tease you.
[cpg cn=true]


;**【ＣＧ】 ev_14_b ***********************
[CG id=8 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMarie022"]
[OnName num="marie"]
It's weird. Is that the only reason you would do something like this?"
[cpg cn=true]



;//移植のためシーンをカットしています


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



And before things got out of hand, I decided to break the hypnosis.
[cpg]


[OnName num="toma"]
I'm coming home again,...... and I'll still remember what I did in the park.
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Marie203"]
[OnName num="marie"]
...... you won't do those things again, will you?"
[cpg cn=true]


[OnName num="toma"]
What do you mean, "Oh, no, no, no, no."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Marie204"]
[OnName num="marie"]
"Don't make me say it,...... anymore,......."
[cpg cn=true]


In her mind, it's really what we did outside, isn't it? It's funny.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I'm not sure if it's a good idea to have a new one, but I'm sure it's a good idea to have a new one.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************



Then one day. Marie said something like this.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sMarie023"]
[OnName num="marie"]
"Hey ......, if you were going to have a wedding, what kind of wedding would you like?"
[cpg cn=true]


She seems to be really happy. She seemed to be seriously planning to get married to me.
[cpg]


I thought it was a good opportunity. I thought it would be a good opportunity to break the hypnosis.
[cpg]


I am looking forward to just imagining what she will look like when I break the hypnosis here.
[cpg]


I was excited just by imagining it. I waited for the right moment.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



After hypnotizing her, I went shopping for groceries and other daily necessities.
[cpg]


I couldn't stop laughing. I wondered how she would react if I put her out of her trance.
[cpg]


Just imagining it gives me a sense of joy. And the time limit is approaching.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



And then night. Marie kisses me good night.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sMarie024"]
[OnName num="marie"]
I'm too happy," she says. I can be with the person I love all the time. ......
[cpg cn=true]


[OnName num="toma"]
I'm too happy to be with the person I love all the time. I'm happy too.
[cpg cn=true]


The best time to break the hypnosis is now. That's what I thought.
[cpg]


I looked into her face and said, "I'm going to break the hypnosis that was on you.
[cpg]

[OnName num="toma"]
All the hypnosis on you will be lifted, except for the hypnosis ...... that prevents you from going outside.
[cpg cn=true]


For a moment, Marie's expression froze.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="sMarie025"]
[OnName num="marie"]
She said, "E......, ah, ah......."
[cpg cn=true]


Mariie looks confused by my words.
[cpg]

The actuality of the particulars is that you can find a lot of different types of products and services available. I think I wanted to watch her like this for a long time.
[cpg]

The most important thing to remember is that you can't just take a look at the pictures of the people you love.
[cpg]

But that doesn't mean I'm ready to leave this room.
[cpg]

[OnName num="toma"]
I'm still going to love you, so brace yourself."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="sMarie026"]
[OnName num="marie"]
What do you think I am, you terrible ......?
[cpg cn=true]


I think it's a toy that you can roll and play with.
[cpg]

The actual "I'm not a fan of the way you look at me," he said.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



Then I went to sleep. She can't go out tomorrow.
[cpg]


So she can't call for help. I slept peacefully, but ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************



I was informed that my perception was wrong.
[cpg]



[SE f="se004"]
;//【ＳＥ】『扉強く叩く』



[OnName num="toma"]
I said, "...... what is it?"
[cpg cn=true]


[OnName num="police_officer_A"]
Police!　Open up!
[cpg cn=true]


[OnName num="police_officer_B"]
Neighborhood watch is on the line. Open the door now!
[cpg cn=true]


Oh, right. I should have taken away the phone too, I thought now.
[cpg]


......I might be able to hypnotize even a police officer now.
[cpg]


But I decided not to put up a futile resistance.
[cpg]


I have achieved my goal. There was no point in fighting for nothing.
[cpg]


[OnName num="toma"]
I said, "I'll open ...... now. Please wait."
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



And I was arrested. It wasn't long before I was sentenced.
[cpg]



No probation, and I was going to spend the rest of my life in jail.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



A long, long time passed. But I was not bored.
[cpg]


I could get what I wanted in prison. Hypnosis got me what I wanted.
[cpg]


I couldn't do anything too spectacular, but people were creeped out.
[cpg]


I could break out of prison if I wanted to. That's how out of the ordinary my power was.
[cpg]


Still, I was just waiting to serve my time.
[cpg]


I had achieved my goal and was a shell of a man. ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



Time went on and on. I would have a hard time reintegrating back into society when I got out.
[cpg]


Even if that were the case, I could do anything I wanted, like robbing someone without their knowledge.
[cpg]


Or maybe I could go to someone's house and get fed. As I was thinking that, a thought occurred to me: ......
[cpg]




[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



Time flies. When I had a purpose, it seemed even longer.
[cpg]


Still, the sentence passed.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



I was looking for the whereabouts of Marie. I checked the Internet and soon found out where she was.
[cpg]


Apparently, the method of breaking into her home had made the news at the time.
[cpg]


Then I saw that Marie had already returned to her parents' house.
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BGM f="bg_ky"]



So I went to her parents' house. I rang the doorbell.
[cpg]



[VOICE f="Marie226"]
[OnName num="marie"]
"Yes, yes, I'll get it. ......"
[cpg cn=true]


When she saw me, she froze. That's the kind of reaction I would expect.
[cpg]


There is nothing strange about it. It's a rather natural reaction.
[cpg]



[VOICE f="Marie227"]
[OnName num="marie"]
What are you doing here, ......?
[cpg cn=true]


[OnName num="toma"]
I'm going to make you love me again. I'm going to make you love me again.
[cpg cn=true]


[OnName num="toma"]
You're gonna love me ...... like you used to.
[cpg cn=true]



[VOICE f="Marie228"]
[OnName num="marie"]
No, no, no!　Stop it. Don't come inside me.
[cpg cn=true]


[OnName num="toma"]
You'll fall in love with me. You're gonna love me more and more. ......
[cpg cn=true]



[VOICE f="Marie229"]
[OnName num="marie"]
"Oh, oh ......."
[cpg cn=true]


And then the light goes out of her eyes.
[cpg]

I walked proudly into her room through the front door.
[cpg]

I'm not sure what I'm going to do now, but I'm going to do it.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



And then. Well, it was necessary to fill the outer moat, or rather, to go in order. ......
[cpg]


I started by apologizing to her and her family.
[cpg]

I decided to have Marie tell her parents that we were good friends in ...... college.
[cpg]

By making her act as if she really liked me, I was able to get people to let their guard down a little bit.
[cpg]

After that, Marie and I grew closer. I let her think that I was in love with her.
[cpg]

Eventually we would get married. Of course, that's what she wants.
[cpg]

Of course people are surprised by that, but they don't care.
[cpg]

I just think it's a natural reaction and don't think anything more about it.
[cpg]



For me, it doesn't matter. As long as I can spend time with Marije again.
[cpg]


If I could get close to her again, ...... I would do it again and again as long as I still have my hypnotic power.
[cpg]

Even now, she is waiting impatiently for me. She is waiting for me to come home.
[cpg]

Thinking of that, everything I have done up to now is not in vain.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



With that in mind, I went back to her house again today.
[cpg]


[SCENE id=8]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン１ルート１



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


