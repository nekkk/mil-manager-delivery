
;//３、美沙ルート

*start

;//ここから更にト書きが短くなっています
;//Ｈシーン以外の部分でも追加予定です



;//==============================
;//催眠術を際限なく使う　を選んでいた場合
*root_31

[jump target="*jump6"]

;#################################################
*Ep006|I want to hypnotize my teacher
;#################################################



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]

;//ヒロイン３ルート１

*jump6|I want to hypnotize the teacher.

[SCENE id=6]


;//ブラックアウト


I chose the teacher as my target. I decided to use hypnosis to break in.
[cpg]


It is a hypnotism that I have obtained. I had to use it without limit or it would be meaningless.
[cpg]


Of course, there are ways to avoid using hypnosis as much as possible, but ......
[cpg]


I was not satisfied with that. I wanted to hypnotize him.
[cpg]


It didn't take me long to act on this thought.
[cpg]

I already knew where he lived, that he didn't have a girlfriend, and that he could be hypnotized properly.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misa061"]
[OnName num="misa"]
Yes, which one of you ...... Oh, Suzumura-kun?"
[cpg cn=true]


I nodded. Then he greeted me.
[cpg]


[OnName num="toma"]
'Good evening,...... sorry, I know you're surprised at my sudden appearance.'
[cpg cn=true]


I tried to be as careful as possible not to raise any alarms.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa062"]
[OnName num="misa"]
What's wrong? At this hour."
[cpg cn=true]


But if they are alarmed, all I have to do is hypnotize them.
[cpg]


I approached the teacher, thinking there was no problem.
[cpg]


[OnName num="toma"]
I wanted to have a word with you.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMisa003"]
[OnName num="misa"]
"A talk?　What do you want to talk about?
[cpg cn=true]


I didn't think about that. I hadn't thought that far ahead.
[cpg]


But I had a feeling that I could manage even if it was not appropriate.
[cpg]


He wasn't cautious. He didn't ask me how I knew where he lived.
[cpg]


That's fine. I thought to myself, and said to her, "I need your advice.
[cpg]


[OnName num="toma"]
I need your advice.
[cpg cn=true]


Consulting. Well, a male student of my age has a lot of things to ask for advice.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Misa064"]
[OnName num="misa"]
I said to her, "......, that's fine. It's nice to be depended on.
[cpg cn=true]


[OnName num="toma"]
Thank you very much. Okay, let's see... ......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Misa065"]
[OnName num="misa"]
"Come on up. I'll make you some tea.
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Thanks to my lack of caution, everything went without a hitch.
[cpg]


I went up to the doctor's room. Then comes the moment when I'm about to hypnotize him.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夜）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="toma"]
"Look at me ......, you'll do whatever I tell you to do .......
[cpg cn=true]


[OnName num="toma"]
"See, you won't be able to disobey me. You won't be able to disobey me. ......
[cpg cn=true]



[FACE method="change_8" pos="2/3"]
[VOICE f="Misa066"]
[OnName num="misa"]
What...? I said something, but......."
[cpg cn=true]


The teacher is holding his head and looking at me.
[cpg]


The first thing that comes to mind is that the "I" in "I" is a very good name. The hypnosis seems to have at least some effect.
[cpg]


[OnName num="toma"]
"So much for that. Well, sir..."
[cpg cn=true]


I turned to him. He didn't seem intimidated.
[cpg]


[OnName num="toma"]
All right, then, stand right there. Do as I say.
[cpg cn=true]


From this point on, I didn't have to treat her like a teacher.
[cpg]


I told her in a cold tone.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa067"]
[OnName num="misa"]
I told her coldly, "N...... what? Why did you...?"
[cpg cn=true]


I don't care what you order me to do from here, but let's see what I'll do.
[cpg]


Well, whatever you want. It's true that Sensei can't run away anymore.
[cpg]


[OnName num="toma"]
Sensei can't defy me anymore. Come on, get up."
[cpg cn=true]


Sensei was puzzled. He moved his body as I said.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Misa068"]
[OnName num="misa"]
What do you mean?
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Misa069"]
[OnName num="misa"]
What do you mean? My body just moved on its own..."
[cpg cn=true]


You must have been surprised. She must have been surprised, not knowing why she was doing what I told her to do.
[cpg]

;//========================================
;//●ＣＧ（催眠術で体を操る。意識はそのまま。自由に動けないヒロインにキス）ev_44
;//人物１：ヒロイン３
;//服装１：スーツ
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夜
;//========================================

[free time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]



I put my lips to hers, feeling better.
[cpg]



;//移植のためシーンをカットしています

;//ブラックアウト


[VOICE f="sMisa004"]
[OnName num="misa"]
What are you doing ......?　What are you doing ......?
[cpg cn=true]


She's surprised, but only surprised.
[cpg]

She was surprised, but only surprised, not able to push me away.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夜）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

[OnName num="toma"]
You know what I'm going to do? You know what I'm going to do?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sMisa005"]
[OnName num="misa"]
......."
[cpg cn=true]


The teacher stood there, trembling.
[cpg]

[OnName num="toma"]
It doesn't matter if you don't know. You'll find out soon enough.
[cpg cn=true]


Specifically, you're going to be a hypnotic toy for me to play with, but you don't have to tell me that much.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Misa128"]
[OnName num="misa"]
......... such a thing."
[cpg cn=true]


Ah, the teacher's face is colored with despair.
[cpg]


[OnName num="toma"]
Don't look so gloomy. Sensei."
[cpg cn=true]


While saying that, I was enjoying watching the teacher's despair.
[cpg]


I was in control of her body, so I could do whatever I wanted to her.
[cpg]


A toy to play with when I can. But her thoughts and mind are at her will. The gap between the two.
[cpg]


I think it must be considerable. Normally, the mind that is not being manipulated would collapse.
[cpg]


It would not last long. If it collapses, I don't know what will happen to me in the end.
[cpg]


But if possible, I'd like it to break in such a way that ...... it would fall in love with me.
[cpg]


[OnName num="toma"]
Come on, let's play some more, Doc.
[cpg cn=true]


[OnName num="toma"]
There's plenty of time for that.
[cpg cn=true]


I can only imagine how long I'll be able to keep it up.
[cpg]


I can only imagine, but I'm sure I won't be able to hold out much longer.
[cpg]


I can only imagine, but I don't think she would be able to endure it for too long.
[cpg]


If there was an end in sight, her heart would be healed a little.
[cpg]


This time, there is no end in sight. That is why the teacher is more mentally corroded.
[cpg]


The countdown to the collapse of ...... has already begun.
[cpg]


I wonder how long it will take for the teacher to fall in love with me.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I approached her, acting like a lover.
[cpg]


I tried to manipulate her body as much as possible.
[cpg]


If I manipulated her mind, it would be easy to make her think that she likes me.
[cpg]


But that would be boring. So, I manipulated her body.
[cpg]


She was unable to call for help, let alone leave the room.
[cpg]


Only her mind is free, but the rest of her body is mine.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************



[OnName num="toma"]
I really want to go on a date with you.
[cpg cn=true]


When I said this to him one day, he looked at me with a sparkle in his eyes.
[cpg]


He must have thought this was a good chance. Then he would say.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misa129"]
[OnName num="misa"]
'Yes, that's fine. At least a date. Let's go out, shall we?"
[cpg cn=true]


I might have said something careless, too.
[cpg]


If I hadn't said something unnecessary, the teacher wouldn't have reacted this way.
[cpg]


[OnName num="toma"]
I'm sure he'll try to do something while we're out. I know that much."
[cpg cn=true]


I would have said something like that and decided not to let him out for the time being.
[cpg]


I'd have to wait until I'm a little more brokenhearted. If I do, that is.
[cpg]


[OnName num="toma"]
So, I'm sorry, but I can't let you out of your room.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa130"]
[OnName num="misa"]
'But there's nothing I can do about it. You're the one who said that. Then I think you could at least take a walk.
[cpg cn=true]


[OnName num="toma"]
'...... a walk, a walk?
[cpg cn=true]


You mean you want someone to witness it.
[cpg]


Whatever it was, I could see that he was thinking about all kinds of things to get away from me.
[cpg]


[OnName num="toma"]
I'm not giving up on you, Doc. I hate that sort of thing."
[cpg cn=true]


[OnName num="toma"]
You've got to be more obedient. Can't you?
[cpg cn=true]


I said and pressed closer to him.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Misa131"]
[OnName num="misa"]
I pressed him.
[cpg cn=true]


He bit his lip. It was a good reaction.
[cpg]


[OnName num="toma"]
"Well, anyway, that's the way it is.
[cpg cn=true]


[OnName num="toma"]
I can't let you out of here until you change your mind.
[cpg cn=true]


The teacher muttered, "Oh, no. That's the kind of reaction you'd expect.
[cpg]


At the very least, it's not the way a human being should be treated. I understand that much.
[cpg]

[FACE method="change_7" pos="2/3"]
The patient is locked in a room, and gradually his body is not only damaged, but his mind is also sickened.
[cpg]


It would be easy to destroy the mind with hypnosis.
[cpg]


But it is not. Hypnosis does not manipulate the mind, but only after it has been brought to its knees.
[cpg]


Hypnosis is just a tool for that purpose. That's what I thought.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


It had been a while since I had locked myself in the room with the teacher.
[cpg]


I myself sometimes go outside to buy food.
[cpg]


But he keeps me locked up in the house with hypnosis during that time.
[cpg]


Of course, I couldn't call for help. Such days went on and on.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************



It seems that Sensei is getting a little tired of it.
[cpg]


It must be hard just to stay in the house for a long time and to see the same scenery.
[cpg]


He is on the verge of a mental breakdown. I sense it.
[cpg]


I felt sorry for him, but it was also as I expected.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misa148"]
[OnName num="misa"]
I was thinking, "Hey...can you let me out for a little bit? Can you let me out?"
[cpg cn=true]


The teacher said something like that. Of course, I couldn't do it.
[cpg]


I thought, "I can't do that," but I thought I could do something interesting if I used it as bait.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa149"]
[OnName num="misa"]
I need to get some sunlight...I've been in my room all day..."
[cpg cn=true]


[OnName num="toma"]
I've been in my room all day. What should we do ......?"
[cpg cn=true]


I ponder. I think about what I can do.
[cpg]


[OnName num="toma"]
Then play a game with me.
[cpg cn=true]


The teacher is getting nervous when he hears the word "game".
[cpg]


[OnName num="toma"]
Nothing to be scared of.
[cpg cn=true]


[OnName num="toma"]
A game is a game. Don't be so scared.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Misa150"]
[OnName num="misa"]
What are you going to do?
[cpg cn=true]


[OnName num="toma"]
It's just a game. Don't be afraid.
[cpg cn=true]


I approached her, saying that.
[cpg]



;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

And we were out on the street. I had the teacher with me.
[cpg]


[OnName num="toma"]
It's nice to get out of the house once in a while."
[cpg cn=true]


The teacher didn't say anything. She could have been more pleased.
[cpg]


I guess it's important to grant her wishes in moderation.
[cpg]


Granting her wishes and dropping her. It's called "candy and whip.
[cpg]




Of course, I hypnotize her. Of course, I hypnotize her carefully.
[cpg]


One is that I can't call for help.
[cpg]


The other is that she won't leave me.
[cpg]


In other words, she can't get out of this situation.
[cpg]


[OnName num="toma"]
I ask the doctor, "Would you like to get out in the daylight?"
[cpg cn=true]


I ask the teacher, but she doesn't really answer.
[cpg]


Instead, she's looking around.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa196"]
[OnName num="misa"]
'Ugh......... ugh...'
[cpg cn=true]


She groans. She's trying to tell me she doesn't want to do this.
[cpg]


[OnName num="toma"]
What's wrong? Aren't you happy?"
[cpg cn=true]


The doctor was not happy to be out.
[cpg]


I would never give her a moment's peace. I knew that.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Misa197"]
[OnName num="misa"]
I know you know that..."
[cpg cn=true]


Yes, I know. But I dared to pretend I didn't. I asked the teacher, "Are you worried about your thin clothes?
[cpg]


[OnName num="toma"]
"Are you worried that you're wearing light clothes?"
[cpg cn=true]


The teacher was silent and turned his head down. And then he said, "What do you mean by light clothing?
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Misa198"]
[OnName num="misa"]
What do you mean by "light clothes"?
[cpg cn=true]


I don't know. It's not quite light clothing, because I'm wearing a coat.
[cpg]

It is not that she is completely naked. But I had hypnotized her.
[cpg]

In other words, the hypnosis of not being able to see herself even if she was wearing clothes. ......
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="sMisa006"]
[OnName num="misa"]
Please let me go home.
[cpg cn=true]


[OnName num="toma"]
She was saying something different from a moment ago.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sMisa007"]
[OnName num="misa"]
But ...... I can't take it anymore."
[cpg cn=true]


It's a cute reaction. I'd like to watch it all the time.
[cpg]


The most important thing to remember is that you should never let the teacher get away with anything.
[cpg]


We could go to a less popular park and play with him.
[cpg]



That way, he would be less inclined to disobey me.
[cpg]


Even if there were witnesses, I could hypnotize them to erase their memories.
[cpg]


With these thoughts in mind, I took her around a little longer.
[cpg]


She was gradually losing heart. I could tell.
[cpg]



;//ブラックアウト

;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


It had been almost a month since she had started living with the teacher.
[cpg]


Things were slowly starting to change.
[cpg]


It wasn't so convenient for me.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************



[SE f="se008"]
;//【ＳＥ】『携帯電話の振動音』



The phone rang in the room.
[cpg]


I couldn't hang up, so I left it alone. ......
[cpg]


The phone stops ringing, but then it rings again.
[cpg]


[OnName num="toma"]
"Tsk...it's bothering me."
[cpg cn=true]


I already know who the caller is. It got a little tricky.
[cpg]


I was acting like I wanted to, but gradually I couldn't stay that way.
[cpg]


I was a student, so I had no problem spending my summer vacation in comfort.
[cpg]


I could have gone home for the summer without going home for the Bon Festival.
[cpg]


However, that was not the case with Sensei. I thought she would be on summer vacation, too. ......
[cpg]


The summer vacation was not always a vacation for university lecturers.
[cpg]


I've been getting calls from the university several times recently.
[cpg]


If I let this go, they will know that something is happening to the teacher.
[cpg]


It's only a matter of time before someone comes here.
[cpg]


I'm ignoring it for now, but...this life won't last much longer.
[cpg]


I faced the teacher with that thought in my mind.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ（ベッドに横たわるヒロイン。主人公とキスをする）ev_49
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================



[BGM f="bg_h2"]
;**【ＣＧ】 ev_49_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMisa008"]
[OnName num="misa"]
"Nnghhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh..."
[cpg cn=true]


The teacher was no longer upset by the mere act of kissing me.
[cpg]

The most important thing to remember is that you can't just take a look at the pictures and say, "I've got a great deal to say about this.
[cpg]

I think I have a difficult personality. ......
[cpg]

I was also no longer so interested in what happened after it went well.
[cpg]

[VOICE f="sMisa009"]
[OnName num="misa"]
'Ha, ha,...... we're not going to do anything else.
[cpg cn=true]


[OnName num="toma"]
'Oh. Do you want me to?"
[cpg cn=true]


When I asked, the teacher made an indescribable expression.
[cpg]

Even though she didn't want me to do it, she looked like she was out of sync. ......
[cpg]

I had made a decision with her in the back of my mind.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misa230"]
[OnName num="misa"]
"...... hey. What are you doing?"
[cpg cn=true]


[OnName num="toma"]
What do you mean, you can tell by looking at it?"
[cpg cn=true]


I was packing my bags. I was packing my bags.
[cpg]


[OnName num="toma"]
I'm getting ready to leave.
[cpg cn=true]


I couldn't let the call from the university go unanswered.
[cpg]


I didn't know what would happen if I just let it go like that.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Misa231"]
[OnName num="misa"]
'Eh...ugh, you're lying,...... trying to trick me again by saying that...'
[cpg cn=true]


[OnName num="toma"]
I would never lie at a time like this."
[cpg cn=true]


I said as I turned my back to the teacher.
[cpg]


[OnName num="toma"]
I'm just trying to get out of here before things get messy.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Misa232"]
[OnName num="misa"]
I see..."
[cpg cn=true]


The teacher sounded relieved.
[cpg]


It's still too early to be relieved, though. Well, she can realize that later.
[cpg]


[OnName num="toma"]
'Well then, I'll see you later. See you later, doctor.
[cpg cn=true]


I pack up my stuff and really try to leave.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Misa233"]
[OnName num="misa"]
"Oh, I did it...thank God. I'm finally going to be released. I'm sure he's having second thoughts about ...... it, I'm sure he's tired of it.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Misa234"]
[OnName num="misa"]
But now, finally..."
[cpg cn=true]


When I looked at the teacher, he looked exhausted but still relieved.
[cpg]


I was so tired, but I was still relieved.
[cpg]


I thought so, and said, "I'll be back.
[cpg]


[OnName num="toma"]
I'll be back. Prepare yourself."
[cpg cn=true]


She froze for a moment and reacted as if she had no idea what I was talking about.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Misa235"]
[OnName num="misa"]
She froze for a moment and reacted as if she didn't know what I was talking about.
[cpg cn=true]


She mumbled. Well, this is the kind of reaction I would expect.
[cpg]


But I have hypnosis. I can at least leave her alone temporarily.
[cpg]


I could even find a way to keep her from testifying against me or reporting me to the police.
[cpg]


I wasn't going to let her go yet.
[cpg]


[OnName num="toma"]
"It's just a temporary refuge. I'll be back. Until then, forget everything that has happened. ......
[cpg cn=true]


I looked at the doctor's face as I said this.
[cpg]


[OnName num="toma"]
Now it's time for hypnosis. Look at me."
[cpg cn=true]


The teacher was stunned and looked at me.
[cpg]


[OnName num="toma"]
'I'm going to lose all memory of what I've just been through. All memories of everything that was done to me will be gone, and I won't be able to tell anyone about it."
[cpg cn=true]


[OnName num="toma"]
'Of course, I won't be able to call the police or anything.'
[cpg cn=true]


I think the doctor was hypnotized. I hope he is hypnotized.
[cpg]


But my hypnosis had been working so far, it wouldn't matter.
[cpg]


[FACE method="change_8" pos="2/3"]
[VOICE f="Misa236"]
[OnName num="misa"]
"Uh, ah ......, ah ......."
[cpg cn=true]


Then I hypnotized her out of her memory, and I disappeared.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[OnName num="university_personnel"]
"Oh, doctor. I thought something was wrong.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misa237"]
[OnName num="misa"]
"Oh, is something wrong?"
[cpg cn=true]


[OnName num="university_personnel"]
What do you mean... you haven't heard from me in a long time?
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Misa238"]
[OnName num="misa"]
Is that so? That can't be...
[cpg cn=true]


[OnName num="university_personnel"]
Anyway, I'm glad you're okay. I'm glad you're okay, but I know you're going through a lot..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa239"]
[OnName num="misa"]
I'm going to ...... to the university.
[cpg cn=true]


[OnName num="university_personnel"]
Yes.
[cpg cn=true]


One day, I heard that the university officials came to my house because I had not been able to contact the teacher for too long.
[cpg]


But by then I was gone. And her memory was also erased.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



Summer is over. Summer vacation is over, of course.
[cpg]


Time passed, and a new semester was about to begin.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学講義室』（昼）******************************************************



[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misa240"]
[OnName num="misa"]
"Well, therefore, this problem is ......."
[cpg cn=true]


I smiled as I watched the teacher lecturing with a nonchalant expression on his face.
[cpg]


I'll have to wait a little longer...
[cpg]


It's too early to reveal everything. I've been waiting for the right moment.
[cpg]


It would be best to barge in when I have another big vacation.
[cpg]


Besides, I needed to wait for things to cool down.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（朝）******************************************************



[SE f="se011"]
;//【ＳＥ】『玄関のチャイム』



;//[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Misa241"]
[OnName num="misa"]
I said, "Yes, I'll open it now. I'll open it now.
[cpg cn=true]


Time passed, and it was winter break.
[cpg]


I had come again. To my beloved.
[cpg]


I visited her house again when I had recovered from the cold.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[WAIT time=800]

[OnName num="toma"]
"Good morning. Good morning, sir.
[cpg cn=true]


I said and smiled at her.
[cpg]



[FACE method="change_5" pos="2/3"]
[VOICE f="Misa242"]
[OnName num="misa"]
'Eh...oh, are you ...... Suzumura...kun?
[cpg cn=true]


[OnName num="toma"]
You remember, don't you? The situation. I'm not sure if this is a good idea or not, but it's a good idea.
[cpg cn=true]


The teacher puts his hand over his mouth and backs away.
[cpg]


The first thing to do is to make sure that you have a good idea of what you're doing. He looks at me as an object of so much fear.
[cpg]




And then he sees me and the memories of the doctor come flooding back.
[cpg]


It was probably due to the fact that I had left the hypnosis in place for a while.
[cpg]


I had put him under hypnosis of losing his memory, but it is coming undone.
[cpg]


But if it was completely coming undone, he would have reported me. ......
[cpg]


I guess it would be in the form of a full revival when he saw me visiting his house.
[cpg]


If I had been in the wrong, they would have reported me. Watch out, watch out, watch out.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Misa243"]
[OnName num="misa"]
Why did you come back? Why did you come back now?
[cpg cn=true]


[OnName num="toma"]
I told you I'd be back, didn't I?
[cpg cn=true]


[OnName num="toma"]
"......, it's funny to be polite now, isn't it? I'll hypnotize you again."
[cpg cn=true]


The teacher was trembling. What a cute guy.
[cpg]


[OnName num="toma"]
Don't be so frightened."
[cpg cn=true]


I said that, but I loved her when she was frightened.
[cpg]


She didn't even try to run away. Even if she did, I would hold her back.
[cpg]


I was going to keep her and then hypnotize her.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Misa244"]
[OnName num="misa"]
"Oh no...no...no...no......... ah...I...again..."
[cpg cn=true]


[OnName num="toma"]
I'm going to do it. I'm going to do it."
[cpg cn=true]


I stuffed her up as I said that. I stand close to her.
[cpg]


[OnName num="toma"]
We'll spend time together again. We made a promise, didn't we?"
[cpg cn=true]


I take the teacher's hand as I say this.
[cpg]


I don't have to do this, but it's just a matter of mood.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Misa245"]
[OnName num="misa"]
Stay away from me...please...don't get involved anymore."
[cpg cn=true]


I wonder if she really believes that she should stay away.
[cpg]


She was once overrun. The memory of that time has been erased, but ......
[cpg]


I think it's imprinted in her body.
[cpg]


[OnName num="toma"]
She said, "Say that. You need me, don't you?"
[cpg cn=true]


I thought she must want me, she must want a male.
[cpg]


[FACE method="change_8" pos="2/3"]
[VOICE f="Misa246"]
[OnName num="misa"]
'Oh no, don't do that .......'
[cpg cn=true]


I told her this. To end it all, to begin.
[cpg]


[OnName num="toma"]
What do you really want me to do?　Tell me what you want me to do."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//エンディングＣＧ
;//========================================
;//●ＣＧ（立っているヒロイン。催眠にかかって呆然としていて、壊れた笑顔を浮かべる）ev_50
;//人物１：ヒロイン３
;//服装１：スーツ
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：朝
;//========================================



[BGM f="bg_op"]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMisa010"]
[OnName num="misa"]
I've been ...... really waiting for you for a long time.
[cpg cn=true]


[VOICE f="sMisa011"]
[OnName num="misa"]
I've been waiting for you for as long as I've been ...... bored out of my mind with nothing but peace and quiet.
[cpg cn=true]


[VOICE f="sMisa012"]
[OnName num="misa"]
"It's true that I don't want anything done to me, but ...... I've been wanting you to hypnotize me again just as much as I want you to hypnotize me.
[cpg cn=true]


[OnName num="toma"]
I've been waiting for you for days now. I see."
[cpg cn=true]


Who would have thought she was hiding this kind of true nature under her gentle smile?
[cpg]


No one should be able to imagine that she is such a person.
[cpg]


Normally, she is an ordinary lecturer. Such is her secret face.
[cpg]


I carved it into her heart. In her heart: ......
[cpg]



[OnName num="toma"]
I know how you feel. It's all right now."
[cpg cn=true]


I said and smiled at her.
[cpg]


[OnName num="toma"]
Don't worry, I'll be here for you from now on.
[cpg cn=true]


I'll fill her up. I can hypnotize her as much as I want.
[cpg]


[OnName num="toma"]
So you don't have to worry about anything else.
[cpg cn=true]



[VOICE f="Misa249"]
[OnName num="misa"]
"Oh, oh...really?"
[cpg cn=true]


The doctor was devastated.
[cpg]


I know you've been wanting me for a long time.
[cpg]


My memory was erased, so even though I don't know who is responsible for this ......
[cpg]


The memories have already come back. He must have realized that he wanted me.
[cpg]


[OnName num="toma"]
It's true. I promise.
[cpg cn=true]


I don't need hypnosis anymore. Even if I did, there would be no need to manipulate my mind.
[cpg]


The proof was in her words.
[cpg]


;**【ＣＧ】 ev_50_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="Misa250"]
[OnName num="misa"]
I'm so happy. I'm so happy. I'm so...so happy."
[cpg cn=true]


She is not under hypnosis to manipulate her emotions. This is her true feelings.
[cpg]


[OnName num="toma"]
"Ha-ha-ha!　Well, I guess I'll go back to my hypnotic days."
[cpg cn=true]


From now on, I will be more circumspect. From now on, I would be more careful, so as not to make the same mistakes as before.
[cpg]


With that in mind, I thought about what I needed to do.
[cpg]


I guess I'll need a new hypnosis. I would probably get a call from the university like before.
[cpg]


So I decided to manipulate her.
[cpg]


[OnName num="toma"]
"Well...for now, write me a letter of resignation.
[cpg cn=true]


I'll make her quit her job as a lecturer. So that we can make love forever.
[cpg]



[OnName num="toma"]
You can do that, right?　Don't tell me you can't.
[cpg cn=true]



[VOICE f="Misa251"]
[OnName num="misa"]
"Nn...... hahii♪"
[cpg cn=true]


The teacher had a broken smile on his face. Those days come back to me.
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]


Sensei was broken. I wanted this and everything is fine.
[cpg]

It's what she wants, I'll do whatever hypnotism I can.
[cpg]

I hypnotize her again with the hope of what is to come. ......
[cpg]

The days of hell for the teacher begin.
[cpg]

Or...it will be a happy one for her.
[cpg]


[SCENE id=12]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン３ルート１
;//==============================
