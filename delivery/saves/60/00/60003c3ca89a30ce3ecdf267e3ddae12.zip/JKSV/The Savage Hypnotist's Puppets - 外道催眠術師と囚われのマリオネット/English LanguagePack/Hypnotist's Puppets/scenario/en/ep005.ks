
*start

;//==============================
;//催眠術は近づくための手段として使う　を選んでいた場合
*root_22


[jump target="*jump5"]

;#################################################
*Ep005|I want to destroy Nanako as she is
;#################################################



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]

*jump5|I want to destroy it as it is Nanako

[SCENE id=5]


I'm going to target Nanako. I made up my mind.
[cpg]

I would use hypnosis only as a means to get close to her. I would try to break in without putting her in a hypnotic state as much as possible.
[cpg]


;//ブラックアウト

Nanako seems to be mentally weak.
[cpg]

If so, it would be a waste to destroy her by hypnosis.
[cpg]

We want to destroy Nanako as she is.
[cpg]

If that is the case, we may need some tools.
[cpg]

It would be better to prepare as well as possible. ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



I knew I needed to do a lot of prep work, so I gathered up all the restraints, shackles, and whatnot.
[cpg]

I think I managed to get it all together. There are stores that sell such things in this wide world.
[cpg]


;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



We arrived at Nanako's house.
[cpg]


I pressed the intercom at her house. After waiting for a while, Nanako comes in.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanako250"]
[OnName num="nanako"]
She says, "Oh, is that ......?　Toma, why are you here?
[cpg cn=true]


[OnName num="toma"]
She says, "I don't care what you want. Let me take you home.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
He tries to force his way up to the house. Nanako pulled his arm to stop him.
[cpg]


[OnName num="toma"]
Nanako pulls her arm to stop him, "You're going to think you can't escape from this room from now on.
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[OnName num="toma"]
Furthermore, you won't be able to yell or call for help .......
[cpg cn=true]


I took the initiative and put her under such hypnosis.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（朝）******************************************************



Her room was full of machines. There were several computers.
[cpg]


I thought, "She must be a geek," and I decided to lock her in this room.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanako251"]
[OnName num="nanako"]
I said, "Wow, what are you doing in my room, ......?"
[cpg cn=true]


[OnName num="toma"]
I don't have anything to hide. I just want to be around you.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Nanako252"]
[OnName num="nanako"]
Nah,......."
[cpg cn=true]


But Nanako would not run away. The most important thing to remember is that the best way to get the most out of your car is to make sure that it is a good one.
[cpg]


The person in question is surprised by that. It was amusing to see that.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]

Now, Nanako could no longer leave this room.
[cpg]


I have also stopped her loud voice and phone calls. She can't do anything now.
[cpg]


[OnName num="toma"]
"Well, ......, as you can probably tell by now, I'm here to lock you in here."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako272"]
[OnName num="nanako"]
"Are you serious, ......?　You can't do that.
[cpg cn=true]


[OnName num="toma"]
I'm serious. You just couldn't get out, could you?　That's what my hypnosis is all about.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Nanako273"]
[OnName num="nanako"]
Hypnosis ...... doesn't exist.
[cpg cn=true]


[OnName num="toma"]
If that's what you think, I'll hypnotize you again.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

I thought, "But it's against my principle to hypnotize you again here.
[cpg]


It is only a means to catch them. I can't deviate from that.
[cpg]


Nanako is looking at me with eyes of fear. Just watching her was enough for me.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



After that, I went to buy food.
[cpg]


I didn't have any particular preference, so I decided to get a convenience store bento.
[cpg]


It took me a little time because I didn't know where the convenience store was, but that was OK.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************



[OnName num="toma"]
"Here. Eat."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanako274"]
[OnName num="nanako"]
Nanako said, "I don't care if you say so.
[cpg cn=true]


The first thing to do is to make sure that you have a good time.
[cpg]


The first thing to do is to make sure that you have a good time.
[cpg]


[OnName num="toma"]
She was trying to make him eat with his hands cuffed behind his back. You must be hungry."
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『お腹が鳴る』



Nanako's stomach rumbled. Nanako crawled down and started eating her lunch like a dog.
[cpg]


It was an unbecoming appearance for a girl, but it ignited her desire even more.
[cpg]


[OnName num="toma"]
'......, you really are a cute guy, aren't you?'
[cpg cn=true]



[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Nanako275"]
[OnName num="nanako"]
Hah, hah ...... gulp."
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


In the end, Nanako ate her lunch as it was. I can guess that she was quite hungry.
[cpg]


The first thing I did was to wipe my face with a tissue.
[cpg]


[OnName num="toma"]
You're ruining your beautiful face.
[cpg cn=true]


Nanako was not embarrassed by my words.
[cpg]

I thought it was rather nice that she was just frightened.
[cpg]


;//移植のためシーンをカットしています



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************



And the sun was setting. What about a place to sleep?
[cpg]


I would sleep in the bed, but where should I let Nanako sleep?
[cpg]


I've got handcuffs on her, so I can let her sleep on the ground.
[cpg]


[OnName num="toma"]
I'm not sure if I'll be able to sleep on the ground, but I'm sure I'll be able to sleep on the floor. Are you sure you're ventilating it properly?"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Nanako295"]
[OnName num="nanako"]
Nanako was still crying.
[cpg cn=true]


Nanako was still crying. The most important thing to remember is that you should never be afraid to ask for help.
[cpg]


I opened various drawers. They are full of books and clothes, but ......
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Nanako296"]
[OnName num="nanako"]
No, not in there!
[cpg cn=true]


I tried to open one drawer, but Nanako stopped me. But I can't stop her because I'm handcuffed behind my back.
[cpg]


[OnName num="toma"]
I tried to open one of the drawers, but Nanako stopped me.　A book?"
[cpg cn=true]


Is it something called a doujinshi? I don't know much about it, but I know these things exist.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sNanako020"]
[OnName num="nanako"]
"Don't look at it, don't look at it.
[cpg cn=true]


Nanako's face turned bright red, even though it was nothing that she didn't want to be seen.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************



Then, at night, they ate their meals and went to sleep. We each had a meal and went to sleep.
[cpg]


I put Nanako on the floor and I put myself on the bed.
[cpg]


I could have slept in the bed with Nanako, but I didn't because I had to restrain her.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（朝）******************************************************



In the morning. I woke up before Nanako.
[cpg]


I was very tired. I guess it is more exhausting to be on the receiving end than to be locked up.
[cpg]


Thinking it was only natural, I decided to go out for shopping.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se005"]
;//【ＳＥ】『ドア開く』




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



People were hurriedly walking around. It must have been right around the time they were going to work.
[cpg]


I'm an easy-going person. It's not like I have anything to do.
[cpg]


With hypnosis, I can make any kind of money I want after graduating from college.
[cpg]


Or maybe I don't even need to make money.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（朝）******************************************************



When I returned home, Nanako was awake from the quicksand.
[cpg]


She looked as if she was in pain, only her posture was unnatural because of the handcuffs.
[cpg]


[OnName num="toma"]
Do you want me to take off the handcuffs?"
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
Nanako nodded. Now what shall we do?
[cpg]


Of course, I was not prepared for the danger I would be in if I removed the handcuffs.
[cpg]

[OnName num="toma"]
After the handcuffs are off, you won't be able to harm me.
[cpg cn=true]


[OnName num="toma"]
Of course, you won't be able to get out or call for help."
[cpg cn=true]


I hypnotized him like that and then decided to remove the handcuffs.
[cpg]

I don't want to do this, but if Nanako breaks down, it's not my intention.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************



A few moments after I removed the restraints, I put the handcuffs on again.
[cpg]


Even if I didn't handcuff her, she wouldn't be able to call for help or get out.
[cpg]


I can't say there's anything wrong with it, but ...... well, it's a matter of mood.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanako317"]
[OnName num="nanako"]
"...... hah, hah. Let me out of here,......."
[cpg cn=true]


Nanako is debilitated, but not troubled.
[cpg]


The most important thing to remember is that you can't just go out and get a good meal. The most important thing to remember is that you can't die.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



The first time I saw a woman in the street, I thought to myself, "I'm not going to die. I bought a bento again.
[cpg]


The disadvantage of convenience store bento is that they don't last long.
[cpg]


Besides, if I buy a lot at once, the clerk might get suspicious.
[cpg]


Even now, I wonder if they are suspicious of me, since I am buying for two people.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se005"]
;//【ＳＥ】『ドア開く』




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************



Thinking like that, I returned to Nanako.
[cpg]


She still has the same dead-eyed look in her eyes. I was so excited that I wanted to push her even harder.
[cpg]


[OnName num="toma"]
I said, "Come on, I'm going to make dinner. You should eat too.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanako318"]
[OnName num="nanako"]
"......"
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************



Nanako crawled over to eat. I looked at her with the eyes of something I love.
[cpg]


Meanwhile, it was nighttime.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se002"]
;//【ＳＥ】『シャワー』



I decided to give Nanako a bath.
[cpg]


She would not be able to wash herself properly with handcuffs on.
[cpg]


Nanako must have felt uncomfortable to be washed in that condition.
[cpg]




;//========================================
;//●ＣＧ（泣いているヒロイン。シャワーを浴びせようとする主人公）ev_35
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋＿風呂場
;//時間　：夜
;//備考　：浴槽でのプレイではありません
;//========================================



[BGM f="bg_h2"]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]

However, it would be troublesome to undress her with handcuffs on.
[cpg]

If you tear them, you can't get them back on. ......
[cpg]

[VOICE f="sNanako021"]
[OnName num="nanako"]
Ugh, gusu, gusu......."
[cpg cn=true]


Nanako is still crying, and it's getting kind of tiresome.
[cpg]

[OnName num="toma"]
Don't cry."
[cpg cn=true]


I try saying that as a command, not hypnosis, but nothing changes.
[cpg]

[OnName num="toma"]
I can do anything I want now. If you don't stop crying, I can throw cold water on you.
[cpg cn=true]


Nanako did not stop crying even after I said that much.
[cpg]

I was not a devil to do what I said.
[cpg]

I was not a demon to do what I said, but hypnotizing her would do nothing.
[cpg]

[OnName num="toma"]
I had no choice."
[cpg cn=true]


I decided to let her take a shower by herself.
[cpg]

The most important thing to remember is that you can't get a good deal on a new pair of shoes or boots.
[cpg]

[VOICE f="sNanako022"]
[OnName num="nanako"]
I was so frustrated that I didn't care if I saw Nanako unable to resist.
[cpg cn=true]



;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************



I am never bored because of Nanako.
[cpg]


The most important thing to remember is that you can't tell anyone about it. I can hypnotize her so that she can't tell anyone.
[cpg]


I was doing everything for my own personal greed. Even now, I was occupying the bed and letting Nanako sleep on the hard floor.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（朝）******************************************************



And morning. It was a pleasant morning.
[cpg]


After breaking into Nanako's house, I had felt a sense of lightness in my heart.
[cpg]


Hypnosis, which had been missing its role, now had a clear meaning.
[cpg]


That made me feel relieved.
[cpg]


[OnName num="toma"]
"Nanako?　Hey, Nanako.
[cpg cn=true]


I was still not able to get Nanako to wake up. I was so tired after all.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************



Then, Nanako started to act strangely.
[cpg]


[OnName num="toma"]
She said, "Open your mouth. Eat it even if you have to.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Nanako337"]
[OnName num="nanako"]
I don't want to ...... eat. ......
[cpg cn=true]


Nanako stopped eating. It is possible to hypnotize Nanako to eat, but it is not possible to hypnotize her to eat.
[cpg]


But I wanted to use hypnosis as a means of confinement, so I decided to leave it as it was.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************



Several days and nights passed. Sooner or later, he would become unable to endure his hunger.
[cpg]


I would not do such a reckless thing even if I had no means to kill myself.
[cpg]



;//========================================
;//●ＣＧ（ぐったりして、血の気が失せたヒロイン）ev_36
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//========================================


[free time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="toma"]
Hey, don't be so stubborn," he said. Don't be so stubborn all the time.
[cpg cn=true]


[VOICE f="sNanako023"]
[OnName num="nanako"]
I'm not trying to be tough. ......
[cpg cn=true]


I'm not trying to be tough, I'm just trying to . The actuality that the actuality is that you can't get a lot of these things.
[cpg]

The most important thing to remember is that you can't force-feed yourself by hypnotizing yourself.
[cpg]

So, what should I do?
[cpg]

[OnName num="toma"]
Is ...... not enough for you?　Do you want something to eat?
[cpg cn=true]


I tried to be nice, but Nanako didn't reply.
[cpg]

I was more anxious than irritated.
[cpg]

I wondered if I could just leave her like this, no matter how much it was against my principles.
[cpg]

[VOICE f="sNanako024"]
[OnName num="nanako"]
I don't want to eat anything anymore.
[cpg cn=true]


[OnName num="toma"]
I see. Well, if you feel like eating, eat.
[cpg cn=true]


I just said that and didn't think too much about the situation.
[cpg]

[VOICE f="sNanako025"]
[OnName num="nanako"]
I didn't think much of the situation. ......
[cpg cn=true]


She was limp, and there was a part of me that felt uneasy watching her.
[cpg]

The first time I saw her, I thought she was going to die of starvation, and I left it at that.
[cpg]

I didn't realize that this decision would lead her to an unexpected end. ......
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************



And so, I left them with nothing to eat.
[cpg]


It doesn't matter. I was sure he would ask for food sooner or later.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************



One day, I was thinking.
[cpg]


[OnName num="toma"]
I thought to myself, "I slept a little too much ...... Nanako?
[cpg cn=true]


[OnName num="toma"]
Nanako, what's wrong?　Are you all right?"
[cpg cn=true]


The first thing to do is to make sure you have a good night's sleep. The color of her face was bad. And her pulse was slowing down considerably.
[cpg]


I was horrified. Had I killed her?　I had to kill Nanako at ......
[cpg]


No, it's not too late. I should call an ambulance.
[cpg]


But if I did that, Nanako would tell me everything.
[cpg]


If she were awake now, I could hypnotize her to stop talking, but she's passed out.
[cpg]


Then take her to the doctor ....... No, that's no good either. It's the same thing.
[cpg]


I'll think about it. If we don't do something, it won't be enough to keep her locked up. It's going to be murder.
[cpg]



[SE f="se010" loop=true]
;//【ＳＥ】『携帯電話の発信音』
[WAIT time=2000]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[OnName num="toma"]
There's a man down!　Please go to ...... right away.
[cpg cn=true]


I decided to call an ambulance after all.
[cpg]


I had no choice but to call for an ambulance. But ......
[cpg]


Was this the right thing to do?　My life was going to end here.
[cpg]



[SE f="se007" loop=true]
;//【ＳＥ】『救急車のサイレン』


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



And then... Nanako miraculously survived.
[cpg]


I was asked what happened and lied about being in a relationship.
[cpg]


One day she suddenly collapsed and said it was because of an overdone diet. ......
[cpg]


Really, it was a lie that would be easily discovered.
[cpg]


Once Nanako told the truth, it was all over. That's what it was all about. ......
[cpg]



[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



[OnName num="toma"]
"......"
[cpg cn=true]


The police never came to my place. I didn't understand what was going on.
[cpg]


The summer vacation went by without me understanding.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



My life returned to normal. I went back to my parents' house for the Bon holidays, but I was always afraid that the police would come.
[cpg]


...... Really, why am I doing this?
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大学外観』（昼）******************************************************



Then, a new semester. I headed off to college.
[cpg]


I would meet Nanako. There, I thought that everything would be revealed,......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Nanako358"]
[OnName num="nanako"]
...... Toma-san."
[cpg cn=true]


There was Nanako, with a little blush on her cheeks.
[cpg]


As we walked through the university, Nanako told me her story.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako359"]
[OnName num="nanako"]
I ...... have been thinking about you for a while now, and I've been thinking about you.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Nanako360"]
[OnName num="nanako"]
So, if you're willing to be remorseful,...... I'm willing to live with you one more time,......."
[cpg cn=true]


Extreme fear and pain seemed to have flipped inside Nanako.
[cpg]


Maybe it was the suspension bridge effect. I was in love with her.
[cpg]



It doesn't add up. It doesn't add up, but it's the truth.
[cpg]


This is the result of what I have done. I can't not accept it.
[cpg]


In a way, it's a state of delirium more powerful than any hypnosis. ......
[cpg]



[FACE method="change_6" pos="2/3"]
[VOICE f="sNanako026"]
[OnName num="nanako"]
"...... Toma, will you fall in love with me again?"
[cpg cn=true]


This is crazy. My wish was not supposed to come true this way.
[cpg]


She is not sane right now. She's not decent, but she wants ...... me.
[cpg]


I can't not comply. I decided to love her.
[cpg]


[OnName num="toma"]
I was confused, but Nanako answered me, "Are you sure?
[cpg cn=true]


Nanako replies to my confusion, "Don't be shy.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="sNanako027"]
[OnName num="nanako"]
I'm not afraid of you.
[cpg cn=true]


[OnName num="toma"]
I said to her, "....... I understand.
[cpg cn=true]


I don't know what happened to me that brought me to this point.
[cpg]

;//移植のためシーンをカットしています



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I broke her. It seemed like it was my role to stay with her.
[cpg]


I had done something irrevocable,...... and a person's heart is not something that can be easily played with.
[cpg]


I looked into her broken eyes with regret and realized the sinfulness of what I had done.
[cpg]


I can't leave her anymore,...... I thought.
[cpg]


[SCENE id=11]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[jump storage="epend.ks" target="*start"]
;//ＥＮＤ：ヒロイン２ルート２



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
