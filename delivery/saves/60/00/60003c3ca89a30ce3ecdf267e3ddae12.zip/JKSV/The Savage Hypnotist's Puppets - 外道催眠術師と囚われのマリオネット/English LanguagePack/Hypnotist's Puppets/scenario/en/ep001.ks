
*start


;#################################################
*Ep001|How to Use Hypnosis
;#################################################


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************




[SCENE id=1]

[stflag Jumpflg=0]

[if exp={getFlagValue("Jumpflg") == 1 }]
[jump target="*jump"]
[endif]

[if exp={ isSystemFlagsEnabled( "Cha1sysflg") }]
[stflag Cha1flg = 1]
[else]
[stflag Cha1flg = 0]
[endif]
[if exp={ isSystemFlagsEnabled( "Cha2sysflg") }]
[stflag Cha2flg = 1]
[else]
[stflag Cha2flg = 0]
[endif]
[if exp={ isSystemFlagsEnabled( "Cha3sysflg") }]
[stflag Cha3flg = 1]
[else]
[stflag Cha3flg = 0]
[endif]


*jump|How to use hypnosis


The next day. On my days off, I often have a lot of free time.
[cpg]


I am not a man of many hobbies to begin with. So I tend to wander around the city in a daze. ......
[cpg]


I saw Nanako near my house. I'm not sure if it's a good idea to catch her.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanako014"]
[OnName num="nanako"]
"Ah...... er, Toma-san."
[cpg cn=true]


[OnName num="toma"]
I'm so glad you remember me. I'm glad you remember me.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Nanako015"]
[OnName num="nanako"]
That ...... I have something to do, so here ......
[cpg cn=true]


[OnName num="toma"]
Wait a minute. Look at me, will you?
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Nanako016"]
[OnName num="nanako"]
"Yeah. ......."
[cpg cn=true]


He forced her to look at me. Then he hypnotized me.
[cpg]


[OnName num="toma"]
You follow me. I go up to my room, but I don't feel any different."
[cpg cn=true]

[FACE method="change_8" pos="2/3"]
Nanako's eyes became vacant. It seems to be working.
[cpg]


[OnName num="toma"]
Then let's go, Nanako. Nanako.
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Nanako017"]
[OnName num="nanako"]
"......Yes."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



So I brought her to my house.
[cpg]


It was a room in an apartment. There is nothing special to explain.
[cpg]


I myself think it's just an ordinary man living alone.
[cpg]


;//移植のためシーンをカットしています


[OnName num="toma"]
"Now, you're going to have to answer my questions.
[cpg cn=true]


[OnName num="toma"]
Where is your address?
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Nanako037"]
[OnName num="nanako"]
...... that is."
[cpg cn=true]


Nanako spoke without hesitation. I make a note of what it is.
[cpg]


We can come back later.
[cpg]


[OnName num="toma"]
You live alone, right?
[cpg cn=true]



[VOICE f="Nanako038"]
[OnName num="nanako"]
Yes, I live alone.
[cpg cn=true]


Good. That's all I need to know.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_8"  pos="2/3" time=800]

Then, I carried him and brought him outside the room.
[cpg]


I sat him down with his back to the front door.
[cpg]


[OnName num="toma"]
Okay. Wake up, Nanako.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Nanako039"]
[OnName num="nanako"]
That's ......, and this is .......
[cpg cn=true]


[OnName num="toma"]
Are you awake?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako040"]
[OnName num="nanako"]
"Were you ...... asleep?　I ...... can't remember what I was.
[cpg cn=true]


[OnName num="toma"]
You collapsed on the street. I took care of you.
[cpg cn=true]


He blurts out all kinds of things to Nanako.
[cpg]


[OnName num="toma"]
I don't know what happened, but I don't care. I don't know what happened.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako041"]
[OnName num="nanako"]
I don't know what happened, but it's not right.
[cpg cn=true]


Nanako left, mumbling to herself.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



And then the night comes.
[cpg]


Two nights came and went, and then the holiday was over.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学外観』（朝）******************************************************



Now the next one is the teacher. I had to get there right away.
[cpg]


But she never stays anywhere.
[cpg]


[OnName num="toma"]
"Well, let's see where he is. ......
[cpg cn=true]


There are days when she doesn't come at all, but I'm sure she's here today.
[cpg]


Thinking so, I look for her. I wonder where she is. ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大学外観』（昼）******************************************************



I walked around looking for her without even attending the lecture. Then, I saw the teacher.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misa011"]
[OnName num="misa"]
Oh, Suzumura-kun. We see each other often these days.
[cpg cn=true]


[OnName num="toma"]
Yes, I do. I've got some business to attend to while I'm in the area.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa012"]
[OnName num="misa"]
"Something ...... short, please."
[cpg cn=true]


I don't know if I can make it quick or not. I don't know if I can be brief or not, but that's not important anymore.
[cpg]


Either way, the teacher has no right to reject me.
[cpg]


[OnName num="toma"]
"Look over here,...... you will do whatever I tell you to do,......."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Misa013"]
[OnName num="misa"]
What ......?"
[cpg cn=true]

[FACE method="change_8" pos="2/3"]
[OnName num="toma"]
Come on, let's go. I prefer an unused lecture hall."
[cpg cn=true]


The first thing you need to do is to get a good idea of what you want to do.
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//========================================
;//●ＣＧ（目から光を失ったヒロイン。主人公の質問に答えている）ev_06
;//人物１：ヒロイン３
;//服装１：スーツ
;//人物２：主人公
;//服装２：私服
;//場所　：大学講義室
;//時間　：昼
;//========================================




[BGM f="bg_h1"]
;**【ＣＧ】 ev_06_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


There are some things I want to get out of the teacher.
[cpg]

Of course, questions similar to the questions I asked my seniors. But when you are talking to a teacher, the meaning of the question changes.
[cpg]

[OnName num="toma"]
"Sensei, do you have a girlfriend?
[cpg cn=true]


[VOICE f="sMisa001"]
[OnName num="misa"]
"No, I don't have a girlfriend.
[cpg cn=true]


I see. That's convenient. I thought he might have a girlfriend, so I was surprised.
[cpg]

I could ask him what I wanted to ask him. But it was the same as the other day.
[cpg]

[OnName num="toma"]
I guess so. ......
[cpg cn=true]


I would like to ask some more questions that are more difficult to answer.
[cpg]

I'd like to ask him some more questions that are more difficult to answer, to see if he is really hypnotized.
[cpg]

[OnName num="toma"]
Who was your first love, doctor?"
[cpg cn=true]


;**【ＣＧ】 ev_06_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMisa002"]
[OnName num="misa"]
"...... that is."
[cpg cn=true]


He seems to be having a bit of trouble answering my question.
[cpg]

This is a hypnosis technique in which she listens to my commands rather than answering my questions. It is a hypnotic technique, in which the person listens to commands rather than answering questions.
[cpg]

But the fact that I was about to say something proved that I was hypnotized.
[cpg]

[OnName num="toma"]
Don't you want to answer?"
[cpg cn=true]


She nodded. It's hypnosis that makes you listen to commands, so she asks me if I don't want to answer, and I answer honestly.
[cpg]

Well, there's no need to force me to ask here. It's not that hard to ask. ......
[cpg]

The only thing that matters is that you asked a question that is hard to answer.
[cpg]

[OnName num="toma"]
I said, "Okay. That's enough."
[cpg cn=true]



;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大学外観』（夕方）******************************************************



[FG f="CHA03_p1_02_a.ui" method="change_8"  pos="2/3" time=800]

So, after I left the room, I decided to release the hypnosis I had put the teacher under.
[cpg]


[OnName num="toma"]
"All hypnosis is released, and I forget what happened while I was under hypnosis. ......3, 2, 1."
[cpg cn=true]



[SE f="se012"]
;//【ＳＥ】『指を鳴らす』



I snapped my fingers and released the hypnosis that was on her.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Misa033"]
[OnName num="misa"]
'Hmmm ...... oh, what?　What time is it ......?"
[cpg cn=true]


The teacher looked at the clock and was surprised. I see, there was some kind of lecture.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Misa034"]
[OnName num="misa"]
I'm sorry!　Maybe you had something to do, but I'm going to go to ...... now.
[cpg cn=true]


[OnName num="toma"]
Yes, it's nothing important. It's no big deal.
[cpg cn=true]


Before I could hear everything he said, he was gone.
[cpg]


He is a busy man. Well, it is natural for a lecturer in a university, I guess.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



So I left the university.
[cpg]


Of course, I still have things to do.
[cpg]


I had to get the address from Marie and the teacher. And I may do something for them.
[cpg]


And Nanako hasn't confirmed whether or not she has a girlfriend: ......
[cpg]


I still have a lot of things I want to do.
[cpg]


I'm not sure if I'm going to be able to do it today, but I'm going to take the day off.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



So I bought some ingredients for dinner and went back home.
[cpg]


The day goes by without any problems.
[cpg]


I'm sure it would be the same even if I carried out my ambition.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



And then morning came. I head back to the university.
[cpg]


This time, I go to ...... to see who I can make contact with.
[cpg]


It doesn't matter who it is. Each of them has their own thing to do.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大学外観』（朝）******************************************************



And then, I arrived at the university. Then I saw Nanako before her lecture.
[cpg]


[OnName num="toma"]
She said, "Oh, Nanako, can I talk to you for a minute? Nanako, can I talk to you for a minute?
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanako042"]
[OnName num="nanako"]
"...... what?"
[cpg cn=true]


[OnName num="toma"]
I have something to do. Don't worry, I'll finish before the lecture starts.
[cpg cn=true]


I'll be done before the lecture starts," he said and invited her out.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



Once we left the university, we headed to a little back alley-like place.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanako043"]
[OnName num="nanako"]
I say, "......, what are you doing ...... in a place like this?"
[cpg cn=true]


[OnName num="toma"]
I said, "Whatever you want. Anything, you'll have to do what I say. ......
[cpg cn=true]


[OnName num="toma"]
Look me in the eye. You won't be able to disobey my orders."
[cpg cn=true]

[FACE method="change_8" pos="2/3"]
Nanako's eyes are getting dimmer and dimmer. As it was, I took her into the alleyway.
[cpg]



;//========================================
;//●ＣＧ（催眠をかけられているヒロイン。呆然とした状態）ev_07
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：路地裏
;//時間　：朝
;//========================================

;//移植のためシーンをカットしています

[free time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]

I'm not sure what I'm going to do now, but I'm going to do something about it.
[cpg]

[OnName num="toma"]
"Let's see, ......."
[cpg cn=true]


I suppressed this feeling and decided to ask her some questions.
[cpg]

The first thing I had to ask her was this.
[cpg]

[OnName num="toma"]
Nanako, do you have a girlfriend?
[cpg cn=true]


Nanako is the third person I have asked this question.
[cpg]

I knew I could erase her memory, so I had no hesitation in asking her.
[cpg]

And she did not answer right away. She resisted, even though she was under hypnosis.
[cpg]

It was a pattern I had not expected, and I was a little confused.
[cpg]

[OnName num="toma"]
She looked into my eyes more. See, you'll have no choice but to say what you really feel.
[cpg cn=true]


Nanako's eyes grew vacant. Then she answered.
[cpg]

;**【ＣＧ】 ev_07_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sNanako001"]
[OnName num="nanako"]
'Yes, I'm not here. ......'
[cpg cn=true]


Compared to her teachers and seniors, she hesitated to answer.
[cpg]

I guess it is something she does not want to say so much.
[cpg]

I don't know if she feels more embarrassed ...... than the other two, I don't know about that.
[cpg]

Whatever it is, I don't think it's hard to hypnotize her.
[cpg]

Even if there were, there are no exceptions to my hypnosis.
[cpg]

[OnName num="toma"]
I'll tell you what. You answered well.
[cpg cn=true]


And then I decided to release the hypnosis.
[cpg]



[OnName num="toma"]
"The hypnosis on you will be lifted, and you will no longer remember being hypnotized. ......3, 2, 1."
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[FG f="CHA02_p1_02_a.ui" method="change_8"  pos="2/3" time=800]


I broke the hypnosis that was on Nanako.
[cpg]


And it was a little late for the lecture.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Nanako062"]
[OnName num="nanako"]
"Oh, that ......?　I, until this late, what ......?"
[cpg cn=true]


[OnName num="toma"]
I better hurry up," he said. The lecture is about to start.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Nanako063"]
[OnName num="nanako"]
I know, I know. ......!　I have to hurry.
[cpg cn=true]



[SE f="se015"]
;//【ＳＥ】『走る』
[free time=1000]
[WAIT time=1500]


Nanako is running away. She is a busy person. Well, I'm the one keeping her busy.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学外観』（朝）******************************************************



Then, I went back to the university. There was originally no lecture at this time, so I had free time.
[cpg]


I had no choice but to look for either the teacher or Marie.
[cpg]


But it's not something you can just look for.
[cpg]


Neither of them had given me their addresses yet. I just have to get that out of them. ......
[cpg]


With that in mind, I wandered aimlessly around the university.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大学外観』（昼）******************************************************



While I was wandering around, it was time for me to attend a lecture.
[cpg]


I had no choice but to attend the lecture, and it was already noon.
[cpg]


As I was heading to the cafeteria, I saw Marie there.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="female_student_A"]
She said, "Oh, I'm so hungry. ...... you get hungry in the summer, don't you?
[cpg cn=true]


[OnName num="female_student_B"]
I'm not sure if it's the other way around.　Usually,......, summer fatigue is what people usually call it."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Marie037"]
[OnName num="marie"]
I think it's true. The most important thing to remember is that you can't get a good deal on a good deal on a good deal on a good deal on a bad deal.
[cpg cn=true]


Marie noticed this and waved her hand.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Marie038"]
[OnName num="marie"]
 "If you like, would you like to eat with me?"
[cpg cn=true]


I decided to decline.
[cpg]


[OnName num="toma"]
I said no. "No, that's fine. What do you have for the rest of the lecture?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Marie039"]
[OnName num="marie"]
Nothing in particular. Do you want to train?
[cpg cn=true]


[OnName num="toma"]
I'll take care of it.
[cpg cn=true]


He left the room.
[cpg]


[OnName num="female_student_A"]
What is that?　A younger boyfriend?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Marie040"]
[OnName num="marie"]
No way. It's not like that.
[cpg cn=true]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大学講義室』（昼）******************************************************



Then, after finishing her lunch, Marie comes to me.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="toma"]
I'm sorry, senpai. I'm always with you.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Marie041"]
[OnName num="marie"]
It's okay. I'm sorry for always going out with you, senpai. But please don't do anything dirty.
[cpg cn=true]


[OnName num="toma"]
I won't. I won't.
[cpg cn=true]


She said, "No, I won't." But she was willing to do it. I hypnotized her defenseless body.
[cpg]


[OnName num="toma"]
"From now on, you're going to start following me,...... and you'll never disobey me."
[cpg cn=true]


;//[FACE method="change_8" pos="2/3"]
[FG f="CHA01_p1_01_a.ui" method="change_8"  pos="2/3" time=800]
[VOICE f="Marie042"]
[OnName num="marie"]
'...... yeah.'
[cpg cn=true]


From here on out, there's no need to treat her like a senior. She's just a woman.
[cpg]


[OnName num="toma"]
I'm just a woman. I know a great place.
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Marie043"]
[OnName num="marie"]
Okay. ......
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




And we headed for an unpopular lecture room.
[cpg]

There are probably several places like this in the university. It's such a big place.
[cpg]

I just need to find one place for me. I don't need more than that.
[cpg]

And soon I won't need it, because I'll have my sights set on one person.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[OnName num="nanako"]
[VOICE f="Nanako014"]
"Oh, ......, Toma.
[cpg cn=true]

[OnName num="toma"]
"...... Nanako?"
[cpg cn=true]


While I was thinking like that, I ran into another person.
[cpg]

What was she doing here?　It would be bad if she talked to Marie now.
[cpg]

[OnName num="toma"]
'You ...... stand there and don't want to move. I like that."
[cpg cn=true]

[FACE method="change_8" pos="2/3"]
That's the kind of hypnosis I'm going to put on Marije. "You won't want to move," is not good. It's hard to explain when someone comes over.
[cpg]

The actual "I'm not going to be able to move," is not a good idea.
[cpg]



;//========================================
;//●ＣＧ（しゃがみ込んでいるヒロイン。主人公の指を舐める）ev_08
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：大学講義室
;//時間　：昼
;//========================================


[free time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]

I decided to check something that had been bothering me.
[cpg]

What I wanted to find out was whether or not the so-called "factual error" hypnosis would work.
[cpg]

For example, hypnosis that says you can't move can be considered a misinterpretation, since it is happening when it is not.
[cpg]

But I've never tried this kind of thing, for example .......
[cpg]

[OnName num="toma"]
You mistake my index finger for a popsicle and want to lick it.
[cpg cn=true]


[VOICE f="sNanako002"]
[OnName num="nanako"]
......"
[cpg cn=true]


She was silent, but I had a feeling it was working.
[cpg]

To begin with, the hypnosis has been working quite recklessly so far.
[cpg]

With that in mind, I put my index finger in front of her and ......
[cpg]


;**【ＣＧ】 ev_08_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sNanako003"]
[OnName num="nanako"]
...... flop, flop."
[cpg cn=true]


She started licking my finger. I get a tickling sensation.
[cpg]

The fact that this worked means that ...... I'm going to be able to do a wider range of things again.
[cpg]

[OnName num="toma"]
She said, "Hmmm, that tastes good, doesn't it? Tastes good?"
[cpg cn=true]


[VOICE f="sNanako004"]
[OnName num="nanako"]
"Delicious ...... mmmm, chu."
[cpg cn=true]


Seeing this reaction makes me want to do more hypnosis.
[cpg]

But I'm still patient. The most important thing to remember is that you can't be too careful when it comes to your own personal information.
[cpg]

So I'll save what I want to do ...... for later.
[cpg]

[OnName num="toma"]
You're a cute guy.
[cpg cn=true]


Nanako continued to lick my fingers, as if she didn't hear my voice.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Satisfied, I decided to break the hypnosis there.
[cpg]


[OnName num="toma"]
'Your memory will disappear ...... and you won't be able to remember what you were doing to me.'
[cpg cn=true]

Nanako just erased her memory and sent her home. Marie obediently waited in front of the lecture hall.
[cpg]


And on my way back, I asked her something like this.
[cpg]


[OnName num="toma"]
What's your address?
[cpg cn=true]



[VOICE f="Marie063"]
[OnName num="marie"]
"Well, you have to answer ....... ......?"
[cpg cn=true]


Okay. I didn't do any hypnosis on this one.
[cpg]


[OnName num="toma"]
I can answer truthfully. You can't resist my questions."
[cpg cn=true]


After the hypnosis, I asked him again, "Where is your address, Mariie?
[cpg]


[OnName num="toma"]
"Where do you live, Marije? Tell me.
[cpg cn=true]



[VOICE f="Marie064"]
[OnName num="marie"]
......, that's ......."
[cpg cn=true]


She answered correctly. I wrote it down.
[cpg]


As I expected, she seemed to be living alone. She gave a name and room number that looked like an apartment.
[cpg]




[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大学講義室』（昼）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_8"  pos="2/3" time=800]
Then I went back to the lecture room where I had been before I put her under hypnosis.
[cpg]


It would be a little bit troublesome if I released the hypnosis in a different place.
[cpg]


So I took precautions. And then I wake up.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Marie065"]
[OnName num="marie"]
I said, "Hmmm........., it's been quite a while."
[cpg cn=true]


[OnName num="toma"]
I was surprised. I just fell down and didn't wake up.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Marie066"]
[OnName num="marie"]
Was that so ......?　Did you do anything dirty during that time?
[cpg cn=true]


[OnName num="toma"]
I didn't. I couldn't be that rude to my seniors. I can't be that rude to a senior.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Marie067"]
[OnName num="marie"]
"I don't know,...... if he at least knows what color underwear I'm wearing.
[cpg cn=true]


......No, I really don't know that.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学講義室』（夕方）******************************************************



And then you will also take the afternoon lectures. The most important thing to remember is that the best way to get the most out of your money is to be honest with yourself.
[cpg]


 I wasn't sure what to do, but I decided to take the lecture seriously.
[cpg]


I was thinking of hypnotizing the teacher again to get her address if I had the chance. ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大学外観』（夕方）******************************************************



Just as I was thinking that, I met the teacher.
[cpg]


[OnName num="toma"]
"Oh. Hey, sir."
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misa035"]
[OnName num="misa"]
"What is it, ......?　What is it? I'm in a hurry.
[cpg cn=true]


[OnName num="toma"]
I won't take up too much of your time. Come with me.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa036"]
[OnName num="misa"]
I said I'm in a hurry.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
The teacher was about to leave when I grabbed him by the shoulders and forced him to turn toward me.
[cpg]


[OnName num="toma"]
You will have no choice but to listen to me. From now on, you'll have to answer my questions honestly. ......"
[cpg cn=true]

[FACE method="change_8" pos="2/3"]
The teacher's eyes lost their light. Then I asked him, "Where is your address?
[cpg]


[OnName num="toma"]
Where is your address?　Tell me.
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Misa037"]
[OnName num="misa"]
He says, "My address is ......."
[cpg cn=true]


He gives me the address and I write it down.
[cpg]


That's perfect. I can head to anyone's place, but what do I do ......
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

Once at ...... I decide to erase her memory.
[cpg]

I'm in a position to do whatever I want, but it's not a good idea to do it in a public place like a university.
[cpg]



[OnName num="toma"]
The teacher's memory will be gone. I'll forget where I was hypnotized."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa059"]
[OnName num="misa"]
"Nn......, oh, that ......?　I'm .......
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Misa060"]
[OnName num="misa"]
It's late!　I'm going to be late again.
[cpg cn=true]

[free time=1000]

The lecture was over, but he said he had something to do. It was like this before.
[cpg]


It's none of my business. But they might notice that I'm the cause of the problem.
[cpg]


I may have reached the limit of hypnotizing someone at the university.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



Some days and nights repeat themselves.
[cpg]


I confirm my ambition. I confirm my ambition: to force my way into someone's home and possibly misidentify them as my lover.
[cpg]

It might work without much strategy.
[cpg]


My hypnosis had reached the point where I could do anything.
[cpg]


But that did not mean that I could not imagine anything.
[cpg]


If there was any chance of failure, I would have to destroy it.
[cpg]


It was summer vacation from now on. If I were dealing with students, there would be no problem.
[cpg]


But what about teachers?　He must have a job.
[cpg]


No, how would you use hypnosis in the first place?　For example, there is the question of whether or not to use it just to get closer.
[cpg]


That also needs to be decided. I thought about it.
[cpg]



;//■選択肢
[switch]
[case "Use hypnosis without limit"]
	[swap]
	[jump target="*select03_1"]
[case "Use hypnosis as a means to get closer"]
	[swap]
	[jump target="*select03_2"]
[endswitch]


1. Use hypnosis without limit
2. Use hypnosis as a means to get closer.



;//==============================
;//１、催眠術を際限なく使う

*select03_1|How to use hypnosis

[stflag Rootflg = 1]



After all, I want to use hypnosis as much as I can.
[cpg]


I thought so again. Since I have this power, it would be a shame not to use it.
[cpg]


[jump target="*select03_3"]
;//後の分岐に影響
;//==============================
;//２、催眠術は監禁の手段として使う

*select03_2|How to use hypnosis

[stflag Rootflg = 0]

Let's use hypnotism only to get closer.
[cpg]


It would be boring not to be able to see the true reaction. That's what I thought.
[cpg]


;//後の分岐に影響
;//==============================

*select03_3|How to use hypnosis

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大学外観』（夕方）******************************************************



Several days and nights passed. And I was finally going to fulfill my ambition.
[cpg]


Needless to say, what triggered it all went without saying. Summer vacation starts today.
[cpg]


This means that no one will suspect me if I don't come to the university from tomorrow.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



As I returned home, I thought to myself. Tomorrow is the best time to take action.
[cpg]


Even summer vacation is limited. More importantly, some students will probably go back to their parents' homes during the Obon holidays.
[cpg]


We must decide on a course of action as soon as possible. With this in mind, I made up my mind.
[cpg]


I chose ...... as the person I would barge into my home.
[cpg]



;//■選択肢
[if exp={getFlagValue("Cha2flg") == 1}]
[jump target="*Get_Nanako"]
[endif]



;//奈々子がいないので選択肢無し
;//毬枝フラグ。無ければ美沙
[if exp={getFlagValue("Cha1flg") == 1}]
[jump target="*select04_1"]
[endif]

[jump target="*select04_3"]


;//毬枝フラグ。無ければ美沙
*Get_Nanako

[if exp={getFlagValue("Cha1flg") == 1}]
[switch]
[case "Marie"]
	[swap]
	[jump target="*select04_1"]
[case "Nanako"]
	[swap]
	[jump target="*select04_2"]
[endswitch]
[endif]


[switch]
[case "Nanako"]
	[swap]
	[jump target="*select04_2"]
[case "Misa"]
	[swap]
	[jump target="*select04_3"]
[endswitch]




;//■選択肢
[switch]
[case "Marie"]
	[swap]
	[jump target="*select04_1"]
[case "Nanako"]
	[swap]
	[jump target="*select04_2"]
[case "Misa"]
	[swap]
	[jump target="*select04_3"]
[endswitch]



1, Marie
*select04_1

[if exp={getFlagValue("Rootflg") == 1}]
[jump target=*root_11]
[endif]

[jump target=*root_12]

2, Nanako
*select04_2

[if exp={getFlagValue("Rootflg") == 1}]
[jump target=*root_21]
[endif]

[jump target=*root_22]

Misa
*select04_3

[if exp={getFlagValue("Rootflg") == 1}]
[jump target=*root_31]
[endif]


[jump target=*root_32]


1, MARIE
2, Nanako
3, Misa
;//※ここまでの候補になっているヒロインから選択
;//※一人しか候補が居ない場合固定されそのまま進む



;//==============================


*root_11
[jump storage="ep002.ks" target="*start"]

*root_12
[jump storage="ep003.ks" target="*start"]

*root_21
[jump storage="ep004.ks" target="*start"]

*root_22
[jump storage="ep005.ks" target="*start"]

*root_31
[jump storage="ep006.ks" target="*start"]

*root_32
[jump storage="ep007.ks" target="*start"]

