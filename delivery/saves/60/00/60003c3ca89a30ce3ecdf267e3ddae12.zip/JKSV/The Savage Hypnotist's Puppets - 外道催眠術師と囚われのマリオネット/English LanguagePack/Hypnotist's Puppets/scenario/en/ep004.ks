

*start

;//==============================
;//２、奈々子

;//qwe

;//==============================
;//催眠術を際限なく使う　を選んでいた場合
*root_21


[jump target="*jump4"]

;#################################################
*Ep004|Nanako is not strong at heart
;#################################################



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]


*jump4|Nanako is not strong at heart

[SCENE id=4]

Nanako. I know where she lives, of course. And I have already confirmed that she has no boyfriend.
[cpg]

I decided to target her. She is a mystery in many ways. ......
[cpg]

She doesn't seem to have a strong heart. If so, it would be most interesting to see her reaction.
[cpg]


;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

If she doesn't have a strong mind, I guess I'd better spare her the hypnosis.
[cpg]

You might enjoy the fun of breaking in more than someone else.
[cpg]

I would rather use it to play with things than just as a means to break in.
[cpg]

And if I use hypnosis without limit, I don't have to think about the strategy to lock myself in anymore.
[cpg]

Just do what you want to do, and it will be impossible to escape.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



And I decided to do it as soon as I thought of it.
[cpg]


I don't need handcuffs or shackles. I have hypnosis.
[cpg]


With that as my guide, I decided to go to Nanako's place.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanako064"]
[OnName num="nanako"]
I went to the apartment where Nanako lived, and I saw a sign that said, "Yes, ......, that's ......."
[cpg cn=true]


I went to Nanako's apartment and rang the intercom.
[cpg]


Nanako was surprised. I guess she was wondering why I was here.
[cpg]


It was not the first time I had contact with Nanako. But she must be feeling something close to that.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako065"]
[OnName num="nanako"]
What do you want, ......?　Toma.
[cpg cn=true]


[OnName num="toma"]
I just wanted to see Nanako's face. I just wanted to see Nanako's face.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Nanako066"]
[OnName num="nanako"]
What are you talking about?　If you don't need me, I'm at .......
[cpg cn=true]


[OnName num="toma"]
You're going to lose consciousness. You're going to lose consciousness right now.
[cpg cn=true]

[FACE method="change_8" pos="2/3"]
The eyes of Nanako become blank. And then, the power is drained from her body.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（朝）******************************************************



 It's a daytime crime, but no one notices it.
[cpg]


I went into Nanako's room with this thought in mind.
[cpg]


[OnName num="toma"]
I went to ...... and saw that the room was like this.
[cpg cn=true]


It's a pretty nerdy room. There's a computer in there, and not just one.
[cpg]


[OnName num="toma"]
"Hey, wake up, Nanako. Nanako.
[cpg cn=true]


I lightly tap Nanako on the cheek to wake her up.
[cpg]


Hypnotism doesn't work on a sleeping person. I'm not a magician, you see.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanako067"]
[OnName num="nanako"]
I'm not sure if this is the right place for me to be.
[cpg cn=true]


[OnName num="toma"]
You will not be able to leave the front door. You will not be able to open the front door.
[cpg cn=true]


[OnName num="toma"]
You won't be able to scream. You won't be able to call for help,...... okay?"
[cpg cn=true]


Imprinting, where the consciousness is dazed. Now Nanako can't do anything.
[cpg]


At least, there is no problem at all for me to confine her here.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Nanako068"]
[OnName num="nanako"]
Oh, my God!"
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



Nanako wakes up properly and, perhaps terrified, runs toward the front door, collapsing into it.
[cpg]


But the door cannot be opened. I've already experimented with the fact that she can't escape my hypnosis.
[cpg]



[VOICE f="Nanako069"]
[OnName num="nanako"]
I can't open the door. ......!　My hand, I can't get it open.
[cpg cn=true]


I push her to the edge of the room. Then I pull her arm back to the room.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（朝）******************************************************



[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Nanako070"]
[OnName num="nanako"]
"No, don't ...... what are you going to do ......?"
[cpg cn=true]


[OnName num="toma"]
Don't you remember?　I just wanted to see your face."
[cpg cn=true]


Nanako looks at me with a frightened face.
[cpg]

She gives me a look that is quite tantalizing.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

[OnName num="toma"]
'Well, and ...... how much do you know about my hypnotism?
[cpg cn=true]


Well, that's okay. I can explain it all.
[cpg]


[OnName num="toma"]
I can hypnotize you. That's why I couldn't get out of here right now.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako088"]
[OnName num="nanako"]
That ...... can't be true.
[cpg cn=true]


[OnName num="toma"]
If you think it's impossible, why don't you call for help?　You shouldn't be able to."
[cpg cn=true]


Nanako tried to shout something, but made a gesture as if she couldn't speak.
[cpg]


I'm sure she would have been convinced. It would be faster to practice than to explain any more.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************



Now, she can't leave her room, but ...... she still gets hungry.
[cpg]


There are things in the refrigerator. But there are only ingredients.
[cpg]


I'm not sure if it would be right to cook something for her or have Nanako cook it for me.
[cpg]


So I decided to go out to buy a lunch box.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



It was a strange situation to have her locked up in my house.
[cpg]


If I wanted to get out, I could have done so, but hypnosis prevented me from doing so.
[cpg]


This would never have been possible without hypnosis. With this in mind, I headed for the convenience store.
[cpg]


I was lost for a while because I did not know where the nearest convenience store was, but I could get used to it.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************



[OnName num="toma"]
Here. Eat.
[cpg cn=true]


Nanako was frightened. I guess she is afraid that she won't be able to call out for help.
[cpg]


[OnName num="toma"]
Don't worry, it's not poisoned.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Nanako089"]
[OnName num="nanako"]
That's not ...... what are you ......?"
[cpg cn=true]


[OnName num="toma"]
Who are you, ?" "I'm nothing. I'm just a student.
[cpg cn=true]


I answered in reply to the unanswerable and decided to eat my lunch.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako090"]
[OnName num="nanako"]
'...... psychic powers, you mean?'
[cpg cn=true]


Nanako asks me another question. It's a pain in the ass.
[cpg]


[OnName num="toma"]
You could say that.
[cpg cn=true]


I didn't have to answer her question properly.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************



Nanako did not eat immediately. But in the evening, she had a bite, perhaps because she couldn't stand it any longer.
[cpg]

;//移植のためシーンをカットしています

[OnName num="toma"]
She was a good eater.
[cpg cn=true]


I looked at her as she ate. She, on the other hand, seemed to have no time to be shy.
[cpg]

After she finished eating, she looked at me and looked away.
[cpg]

[OnName num="toma"]
She looks at me after she finishes eating and then looks away. We haven't done anything yet.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sNanako005"]
[OnName num="nanako"]
She says, "Not yet. ......
[cpg cn=true]


[OnName num="toma"]
You know what I'm talking about.
[cpg cn=true]


I just need to make her a little scared and she'll go pale.
[cpg]

She is the type of person that tickles your appetite for all kinds of things. I like the fact that she is unaware of it.
[cpg]


;//ブラックアウト


Then night falls and she goes to sleep. Since I could use hypnosis, I tried to sleep with Nanako on the same futon.
[cpg]


Nanako didn't want to, but I couldn't refuse even if she didn't want to. I have hypnotism.
[cpg]


So we slept together.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（朝）******************************************************



When I woke up, Nanako was not next to me.
[cpg]


But I should not be able to get out. No, wait, ......
[cpg]


Come to think of it, there was a cell phone. I should make sure I can't use that one either.
[cpg]


When I got up, Nanako was in the kitchen.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_8"  pos="2/3" time=800]
I'll go get her right away. Then, I put her under a new hypnosis.
[cpg]


[OnName num="toma"]
"You won't be able to call for help on the Internet, call the police, or call for help in any way.
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Nanako114"]
[OnName num="nanako"]
Oh, ......, ugh."
[cpg cn=true]


Nanako held her head. The first thing you need to do is to get a good night's sleep. No matter what happens, no one will come to his rescue.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************



I'm going to get some food. Nanako is now eating without any resistance.
[cpg]


That's all right. I don't feel like doing anything with someone who is hungry and weak.
[cpg]


;//移植のためシーンをカットしています

[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sNanako006"]
[OnName num="nanako"]
......Thanks for the food."
[cpg cn=true]


One time she said that to me.
[cpg]

I wondered if she said it simply out of habit,......
[cpg]

I shook my head when I noticed her looking me up and down.
[cpg]

[OnName num="toma"]
'I admire your obedience,' she said. But you can't be tampered with."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sNanako007"]
[OnName num="nanako"]
I know that. ......
[cpg cn=true]


I'm sure you've seen this before, but I'm sure you've never heard of it.
[cpg]

 I can't even flirt with me.
[cpg]

 But in this position, people may show an unexpected side.
[cpg]

I was enjoying being there.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************

[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]

Then the evening came and the sun was setting.
[cpg]


I could have spent all day with Nanako, but I also wanted to enjoy myself for a long time.
[cpg]

In that respect, Nanako's room had a computer, so I would not be bored.
[cpg]


I was surfing the Internet thinking that way.
[cpg]


At first Nanako refused to let me use her computer, but I had no problem with that.
[cpg]


If she really refused, I was going to hypnotize her.
[cpg]


[OnName num="toma"]
She said, "...... You're quite the geek, aren't you? I never noticed."
[cpg cn=true]


I traced her history and found a variety of sites for women.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako134"]
[OnName num="nanako"]
"Oh, don't look at ...... too much."
[cpg cn=true]


Nanako's face turned bright red. It's nice to be shamed in these places.
[cpg]


And when surfing was getting boring, I turned to Nanako and said, "How's it going?
[cpg]

[OnName num="toma"]
How are you doing? Are you getting used to this life?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="sNanako008"]
[OnName num="nanako"]
......, you'll never get used to it."
[cpg cn=true]


Nanako gave me a resentful look.
[cpg]

[OnName num="toma"]
I'd better get used to it. I'm not going to hypnotize you.
[cpg cn=true]


Nanako didn't argue with that.
[cpg]

The first thing to do is to get a good look at the picture.
[cpg]

Somehow, I don't think she would have been so straightforward if she had locked up Marie.
[cpg]

In a sense, Nanako has a strong heart.
[cpg]

I thought so, and I wanted to break her down, so I approached her.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sNanako009"]
[OnName num="nanako"]
......"
[cpg cn=true]


She looked at me and didn't say a word or make a slight movement. I'm not sure what I'm supposed to be doing.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="sNanako010"]
[OnName num="nanako"]
What are you going to do?
[cpg cn=true]


[OnName num="toma"]
I said, "....... I'm not going to do anything.
[cpg cn=true]


I'll break it up in a different way. I'm not sure what I'm going to do.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************



The most important thing to remember is that you can't be too careful with what you do.
[cpg]


But I don't feel like giving her that much attention. I don't think anything of her suffering.
[cpg]


On the contrary, I am thinking about how I can make her suffer more.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se005"]
;//【ＳＥ】『ドア開く』




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



I already know the way to the convenience store. I don't get lost anymore.
[cpg]


Every time, I buy a lunch box for two. The clerk might sneeze at me, but I'm sure ...... it won't lead to a call to the police.
[cpg]


So, what's next?　I can't wait to get home so I can do whatever I want with Nanako.
[cpg]


With my hypnotism, I could even bring someone else over.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************



And then we'll eat dinner. Nanako was horrified, but I did nothing.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sNanako011"]
[OnName num="nanako"]
'You don't do ...... anything anymore.
[cpg cn=true]


[OnName num="toma"]
'What do you want me to do?'
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Nanako160"]
[OnName num="nanako"]
'Nah, nothing. It's okay.
[cpg cn=true]


It's okay, I'm told. I wonder what's okay.
[cpg]


[OnName num="toma"]
I can do whatever I want to you. I can do anything you want.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako161"]
[OnName num="nanako"]
Really, I'm fine. ...... Don't do anything."
[cpg cn=true]


I'm tired of being told to do nothing, and I want to do something, but I don't.
[cpg]

 I was tired of my unfamiliar life, so I decided to sleep as it was.
[cpg]

I slept with Nanako again today. It was warm and smelled good.
[cpg]


I wonder if this is what a lover's life is like. I wonder if it's not this awkward. ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（朝）******************************************************


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
And morning. I eat the lunch I bought again.
[cpg]



[SE f="se009"]
;//【ＳＥ】『携帯電話の着信音』

[FACE method="change_5" pos="2/3"]

That day, there was a little trouble. Nanako received a call on her cell phone.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako162"]
[OnName num="nanako"]
It was from her mother. ...... what should I do?"
[cpg cn=true]


She looked at me. I can't call for help. It's hypnotically restricted.
[cpg]


[OnName num="toma"]
You don't have to answer it. Leave it alone."
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】『携帯電話の着信音』



But the calls kept coming in. If I let this go on and on, they might call the police.
[cpg]


I had no choice, so I told them to cover it up.
[cpg]


I could just order them to do so. I hypnotized him into thinking I couldn't call for help.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako163"]
[OnName num="nanako"]
I said, "Hello, hello. I'm ......."
[cpg cn=true]


My voice is shaking. I wonder if she's okay. I know it's nothing for me to worry about. ......
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Nanako164"]
[OnName num="nanako"]
I'll be fine ......, I think I'll be able to go home for Obon."
[cpg cn=true]


The first thing to do is to make sure that you have a good idea of what you're getting into. I was tempted to interject, "Don't be selfish," but I held back.
[cpg]

After hanging up the phone, he said.
[cpg]


[OnName num="toma"]
I was tempted to interject, "Don't be so selfish," but I held my tongue. I didn't promise to take you home.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako165"]
[OnName num="nanako"]
I'm sorry ...... but ......
[cpg cn=true]


Well, okay, I don't have to send you home. I didn't have to send her home.
[cpg]


I thought, and decided to touch Nanako again.
[cpg]


[OnName num="toma"]
I'm not going to tell you what to do, but I'm going to tell you what to do. This is the courtyard of the university. There are a lot of people around."
[cpg cn=true]


I told her that, but she reacted strangely.
[cpg]


[FACE method="change_8" pos="2/3"]
[VOICE f="Nanako166"]
[OnName num="nanako"]
I tell her, "I ...... ugh, my head hurts ......."
[cpg cn=true]


Am I hypnotizing her too many times?　Her reaction is getting a little strange.
[cpg]


Have I hypnotized you too many times?　I was going to play a little prank on her, but I thought it was a bad idea.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************



Then, I revealed the truth, or rather, I restored Nanako's perception.
[cpg]


[OnName num="toma"]
The only thing that will be released is the hypnosis of being in front of people. You can see the original scenery at ......."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanako186"]
[OnName num="nanako"]
"Oh, is that ......?　This is my room .......
[cpg cn=true]


[OnName num="toma"]
I was so excited that I could not believe my eyes. This has always been your room.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Nanako187"]
[OnName num="nanako"]
"That's ...... mmm, my head hurts."
[cpg cn=true]


My memory is quite mixed up. I should avoid too much hypnosis.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************



Then several days and nights passed.
[cpg]


Nanako's mother called frequently.
[cpg]


Each time, Nanako says she will return for the Bon Festival. ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************



[OnName num="toma"]
'You say you're coming home for Bon, but ...... you're not coming home.'
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanako188"]
[OnName num="nanako"]
I ...... know."
[cpg cn=true]


Do you really understand?　You say you're coming home for Bon, but if you don't, they'll worry a lot.
[cpg]


They might come to this house. If he does, it's a big deal.
[cpg]


[OnName num="toma"]
Call him now. Tell him I won't be home for Bon too."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Nanako189"]
[OnName num="nanako"]
"...... yes."
[cpg cn=true]


Nanako then made a phone call. She dialed her own mother's cell phone.
[cpg]


It seemed like she was quite busy on the phone.
[cpg]


She was trying to somehow explain why she couldn't come home, but she called without thinking that far ahead.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Nanako190"]
[OnName num="nanako"]
She said, "A good friend of mine and I have an event that I really need to go to: ......."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Nanako191"]
[OnName num="nanako"]
Yes, the one they have on Obon, it's ......, so..."
[cpg cn=true]


Is that a good response?　It is not hard to explain to her that she is a nerdy girl.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako192"]
[OnName num="nanako"]
I'm sorry ......, I'll see you later ......, I'll be home soon.
[cpg cn=true]


I don't know. I don't think I could have fooled her.
[cpg]


If it wasn't, it would have really put a damper on my plans.
[cpg]


[OnName num="toma"]
What are you going to do if ...... your family comes to this house?"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Nanako193"]
[OnName num="nanako"]
No, there is no ...... way to do anything."
[cpg cn=true]


...... sure you do. The only thing that I can think of is that it's a situation that Nanako would never wish for.
[cpg]


I'm not sure what to do about it. I didn't realize it.
[cpg]


I'm not sure how much I'm going to be able to do with it, but I'm not going to be optimistic.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************



Then night comes again. Nanako was getting tired of being confined for a long time.
[cpg]


It is not that she is restrained stiffly, but it must be extremely stressful that she is still not allowed to go outside.
[cpg]


On top of that, the person who put her under hypnosis is right next to her. It would be difficult to maintain one's sanity.
[cpg]

[OnName num="toma"]
......Now...
[cpg cn=true]


How shall we play today? I thought about it for a while and came up with an idea.
[cpg]

[OnName num="toma"]
"Stand up for a minute, Nanako. Nanako."
[cpg cn=true]


This one word is not a hypnotic word, so there is no reason to obey it. But ......
[cpg]


;//========================================
;//●ＣＧ（立っているヒロイン。動けない催眠術にかかっている）ev_29
;//人物１：ヒロイン２
;//服装１：私服
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//========================================


[free time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_29_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="toma"]
"You ...... stand up, and you'll be stuck like that."
[cpg cn=true]


[VOICE f="sNanako012"]
[OnName num="nanako"]
Ahh,...... ahhh."
[cpg cn=true]


The first thing to do is to make sure that you have a good understanding of what you're doing.
[cpg]

The actuality of the actuality that you can't move. I am a great potency.
[cpg]

[OnName num="toma"]
I'm good. Keep going.
[cpg cn=true]


And I stared at her figure intently.
[cpg]


;**【ＣＧ】 ev_29_a ***********************
[CG id=11 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNanako013"]
[OnName num="nanako"]
"Oh, my God."
[cpg cn=true]


I traced her skin over her clothes a little, as she stood still, unable to move.
[cpg]

She was ticklish, but she couldn't move.
[cpg]

[OnName num="toma"]
I ask, "Are you ticklish?"
[cpg cn=true]


I asked, but she didn't answer. I might as well give it a try.
[cpg]

[VOICE f="sNanako014"]
[OnName num="nanako"]
No, don't ...... it, ah!"
[cpg cn=true]


I trace my fingers down her back. It tickles and makes her laugh, more like she wants to twist around but can't.
[cpg]

I came up with an interesting play. I kept playing tricks on her for a while.
[cpg]


;**【ＣＧ】 ev_29_b ***********************
[CG id=11 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNanako015"]
[OnName num="nanako"]
I said, "Don't touch me anymore. ......, hah, ah."
[cpg cn=true]


But this is not what I really wanted to do.
[cpg]

I want to make her heart mine. That's what I really want.
[cpg]

So this is like playing around ......
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************



When she finally couldn't stand up anymore, I broke the hypnosis.
[cpg]

I saw some pretty interesting things, but Nanako seemed to be more tired than I thought.
[cpg]

She fell asleep right after I put her out of her trance, so I decided to go to bed too.
[cpg]


I went to bed and went back to sleep. ...... But still, the Bon Festival is approaching soon.
[cpg]


I wonder if I was able to fool Nanako's parents.
[cpg]


I'm not sure if I'm going to be able to do that, but I've got a plan in case I have to.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



The next day, I woke up before Nanako and went shopping.
[cpg]


It is not only food that we need. This is necessary.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（朝）******************************************************



[OnName num="toma"]
...... what are you doing?"
[cpg cn=true]


When I returned home, Nanako was there with a knife.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Nanako214"]
[OnName num="nanako"]
She said, "Don't come here,...... if you don't want to get stabbed, you have to get out of the hypnosis."
[cpg cn=true]


[OnName num="toma"]
I'm not going to come over here and stab you," she said. Put the knife down.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako215"]
[OnName num="nanako"]
I'm not putting it down. ...... I should have done this from the beginning.
[cpg cn=true]


[OnName num="toma"]
You have to put it down. Here, put the knife back where you found it.
[cpg cn=true]


[OnName num="toma"]
"Your body moves on its own ...... and you can't fight me."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Nanako216"]
[OnName num="nanako"]
"Ughhhh,...... why,huh?"
[cpg cn=true]


Nanako put the knife back with a frustrated look on her face.
[cpg]


[OnName num="toma"]
I'm not going to go against you. Then let's play again today."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sNanako016"]
[OnName num="nanako"]
No more, no ...... more, nothing more."
[cpg cn=true]


[OnName num="toma"]
I'm sure it's worthwhile if you don't want to do anything more. Nanako.
[cpg cn=true]


;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

This kind of exchange is somewhat familiar to me, but I still don't cut corners.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************



In the meantime, it's getting to be noon.
[cpg]


I was a little nervous when he brought out a kitchen knife at ...... a while ago.
[cpg]


The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it.
[cpg]


I doubt if Nanako would have been able to defend herself, but at the very least, this would have been the end of her days.
[cpg]


I almost avoided it. But I can't say for sure that I won't be in danger from now on.
[cpg]


[OnName num="toma"]
Let's have dinner. Nanako.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sNanako017"]
[OnName num="nanako"]
"Oh, I can't ...... take it anymore. ......
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************

[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]

And the sun was setting. I decided to approach Nanako once more.
[cpg]

I'm not sure if "getting close" is the right word. I was going to hypnotize her.
[cpg]


[OnName num="toma"]
I said, "Turn around, Nanako. I'll play with you again.
[cpg cn=true]



[VOICE f="Nanako219"]
[OnName num="nanako"]
"Oh, no. ......, don't get inside my head any more.
[cpg cn=true]


Nanako, who did not want to play with me, refused to look at me.
[cpg]



;//========================================
;//●ＣＧ（倒れ込んでいるヒロイン。主人公に背を向けて逃げようとしている）ev_30
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]

The most important thing to remember is that you can't be in the same place at the same time.
[cpg]

I wonder what would happen if I covered her ears?　But Nanako didn't seem to have thought that far ahead.
[cpg]

[OnName num="toma"]
Listen to my voice, Nanako.
[cpg cn=true]


[VOICE f="sNanako018"]
[OnName num="nanako"]
No, no, no. ......
[cpg cn=true]


She would have no more strength left to resist.
[cpg]

I was about to hypnotize her again, amused by that fact.
[cpg]

What kind of hypnotism would be best?　Should I make her immobile like before?
[cpg]

[OnName num="toma"]
What do you want me to do?　How do you want me to take away your freedom?
[cpg cn=true]


Or would you prefer something that would make me believe the truth?
[cpg]


;**【ＣＧ】 ev_30_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNanako019"]
[OnName num="nanako"]
"Don't do anything to me. You're driving me crazy.
[cpg cn=true]


I want to drive you crazy. Such rejection would be counterproductive.
[cpg]

I wanted to do anything I could to Nanako, who was so frightened.
[cpg]

Just as I was thinking that.
[cpg]

[OnName num="toma"]
I heard a sound in the distance.
[cpg cn=true]



[SE f=se004]
;//【ＳＥ】『ドアを叩く』

I heard a sound in the distance. It sounded like something tapping, and it was getting louder and louder.
[cpg]

[OnName num="female_voice"]
"Hey!　I know you're in there!"
[cpg cn=true]


Then I hear someone's voice I've never heard before.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************



[SE f="se004"]
;//【ＳＥ】『ドアを叩く』



[OnName num="nanako_mother"]
Nanako!　If you're here, answer me.
[cpg cn=true]


I knew instantly that something was wrong. It seems that my parents are here.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Nanako240"]
[OnName num="nanako"]
"Oh, Mom, ......."
[cpg cn=true]


I couldn't ask them to help me. But I don't know what will happen to the hypnosis if I leave this room.
[cpg]


What should I do? I had to make Nanako go to her parents.
[cpg]


But in the meantime, how can I get her to stop talking about me?
[cpg]


I'm not sure how to get her to talk about me in the meantime. ...... I guess hypnosis would be the most effective way. I mean, there is nothing else.
[cpg]


[OnName num="toma"]
"Nanako. Turn around.
[cpg cn=true]


I decided to hypnotize Nanako.
[cpg]


I don't know how long it will work, but I have to do it.
[cpg]


[OnName num="toma"]
You won't be able to tell anyone what I did to you. Is that clear?
[cpg cn=true]


[OnName num="toma"]
And you come back here as soon as the bon festival is over.
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Nanako241"]
[OnName num="nanako"]
...... yeah."
[cpg cn=true]


And I decided to walk out the front door, being Nanako's friend.
[cpg]


;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[OnName num="nanako_mother"]
"...... Nanako, not you. Who are you?"
[cpg cn=true]


[OnName num="toma"]
I'm Suzumura. I'm a friend of Nanako's and I was just visiting.
[cpg cn=true]


Nanako said nothing. I'm sure I'm going to give you a strange misunderstanding. ......
[cpg]


I guess it's only natural, since I can't call for help or explain what was done to me.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



So I was left with no time to do anything.
[cpg]


It's a strange situation that once I'm out of the apartment, she'll do as I say.
[cpg]


But if this happens, I'll just have to wait for Nanako.
[cpg]


I should either go back to my parents' house or ...... act like I'm not doing anything suspicious.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



I took it easy for a while.
[cpg]


There was nothing to worry about. There was no doubt about my hypnotism.
[cpg]


The effect would last for a long time. At least, it would not be broken in the middle of the hypnotism.
[cpg]


The hypnosis I had put on Nanako, that she could not leave the room, did not break in the middle.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



Then, after the Bon holidays,...... I went back to my apartment again.
[cpg]


After that, I was about to head back to the apartment where Nanako lived.
[cpg]




;//ブラックアウト




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


The door was unlocked. I thought Nanako might have given up.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************



[OnName num="toma"]
I thought, "You're back, aren't you?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanako242"]
[OnName num="nanako"]
She said, "I'm back ....... She said she was back at .......
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Nanako243"]
[OnName num="nanako"]
I can hand you over to the police.
[cpg cn=true]


[OnName num="toma"]
...... what?"
[cpg cn=true]


I was about to hypnotize her again, not understanding the meaning of Nanako's words, when she said, "The police!
[cpg]


[SE f="se004"]
;//【ＳＥ】『ドアを叩く』


[WAIT time=2000]


[OnName num="police_officer"]
Police!　Open the door!
[cpg cn=true]


I heard such a voice. No way, I thought.
[cpg]


[OnName num="toma"]
I thought to myself, "......, how did you do that?　You couldn't have called for help."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Nanako244"]
[OnName num="nanako"]
"Hi, I told your mother in writing,...... and she told the police that you can use hypnosis.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako245"]
[OnName num="nanako"]
I think there's no way ...... out of this, so I'm going to ......
[cpg cn=true]


You want me to give up. I can't give up.
[cpg]


I opened the door. One policeman can be hypnotized.
[cpg]


I thought so, but ......
[cpg]



[SE f="se005"]
;//【ＳＥ】『ドア開く』



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


There were five cops, as far as I could see. I guess they conquered my power.
[cpg]


This means nothing if I stop one of them. ......
[cpg]


While I was thinking this, my hands were handcuffed.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



From there, there was nothing much to write home about.
[cpg]


The usual things happened. Everything I did came to light.
[cpg]


And somewhere along the way, I thought about using hypnosis to escape, but I couldn't.
[cpg]


At every turn, there were multiple cops and whatnot.
[cpg]


They would probably find me even if I escaped somewhere.
[cpg]


My power has gone beyond human knowledge. I might not be able to do more than just get caught.
[cpg]


Will they use me as a test subject for something?　I wonder. ......
[cpg]


But after it was all over, it didn't matter to me.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


Yes, everything was about to end.
[cpg]

From here, a fact that I don't need to know. But still, I was privy to Nanako's complicated feelings.
[cpg]

;//========================================
;//●ＣＧ（法廷に証人として立つヒロイン。被告人として立つ主人公。主人公が手前、ヒロインが奥にいるようなアングル）ev_31
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：法廷
;//時間　：昼
;//========================================


[BGM f="bg_h1"]
;**【ＣＧ】 ev_31_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


Me and Nanako stood in the courtroom. Nanako was answering questions as a witness.
[cpg]


I am the defendant. There was no way I could hypnotize everyone in this room.
[cpg]


Even if I could, I don't think I could get away with it.
[cpg]


[VOICE f="Nanako246"]
[OnName num="nanako"]
I want to ask ...... and Toma-san ...... something.
[cpg cn=true]


[OnName num="toma"]
......"
[cpg cn=true]


And from here, it is not my role as a witness. It was something I really wanted to tell you as a victim, or something like that.
[cpg]



[VOICE f="Nanako247"]
[OnName num="nanako"]
"Mr. Toma, why did you choose to ...... about me?"
[cpg cn=true]



[VOICE f="Nanako248"]
[OnName num="nanako"]
"Perhaps you chose to ...... about me?"
[cpg cn=true]


It was a question I didn't have to answer. I said nothing.
[cpg]


I just said that Nanako was just a matter of various conditions.
[cpg]


It's not like I chose her because I liked her or anything.
[cpg]



[VOICE f="Nanako249"]
[OnName num="nanako"]
He said, "Answer ...... Toma. Did you like me,......?"
[cpg cn=true]


[OnName num="toma"]
"...... nothing."
[cpg cn=true]


I just answered yes, and decided not to answer anything from there.
[cpg]


It was a story that I didn't care about my feelings.
[cpg]

The most important thing to remember is that the best way to get the most out of your money is to be honest with yourself.
[cpg]


The fact that I have been in the same situation as you is not going to make me feel any less guilty.
[cpg]


Still, should I have told her ......? I don't know.
[cpg]


Everything is too late now.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



And now my future is closed.
[cpg]


I will never see Nanako again. ......
[cpg]


[SCENE id=10]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン２ルート１



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


