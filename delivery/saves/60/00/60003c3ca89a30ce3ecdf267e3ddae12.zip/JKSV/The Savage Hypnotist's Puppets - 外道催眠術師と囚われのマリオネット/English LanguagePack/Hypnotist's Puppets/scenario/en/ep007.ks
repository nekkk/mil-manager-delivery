

*start

;//催眠術は近づくための手段として使う　を選んでいた場合
*root_32

[jump target="*jump7"]

;#################################################
*Ep007|Leaving the Shape of the Heart
;#################################################



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]


*jump7|Leaving the shape of the heart

[SCENE id=7]

I'm going to target the teacher. I made up my mind.
[cpg]

Hypnosis is just a means to push my way in. I would not use it as much as possible.
[cpg]


Because if I use hypnosis, I can do anything.
[cpg]


I wanted to make him my own, but I decided to use hypnosis only to keep him from escaping.
[cpg]


For example, it would be possible to make him my lover in an instant by using hypnosis.
[cpg]


But that would be boring.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



I want to make him mine while keeping the shape of his heart.
[cpg]

I wanted to do so because of the power of hypnosis, which is beyond human knowledge.
[cpg]

Then, I came to the teacher's house and confirmed the plan again.
[cpg]

I didn't need any sleeping pills, even if I called it a strategy. All I needed was hypnosis. Then, I press the intercom.
[cpg]


I already knew where she lived. I already know where she lives.
[cpg]



[SE f="se005"]
;//【ＳＥ】『ドア開く』
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]


[OnName num="toma"]
"Good morning, sir. Teacher ......."
[cpg cn=true]


I couldn't hold back my laughter.
[cpg]


The doctor wouldn't know why I was laughing.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Misa252"]
[OnName num="misa"]
"Is that ......?　Suzumura-kun, what's wrong?"
[cpg cn=true]


In fact, he probably doesn't remember the moment I asked him for his address, so he probably doesn't even know how I got here.
[cpg]


[OnName num="toma"]
I'm not really asking about anything. I'm just on a personal errand.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa253"]
[OnName num="misa"]
No, how do you know where I live, ......?
[cpg cn=true]


What the hell does it matter? So I broke into her house.
[cpg]


The teacher grabbed my arm to hold me back.
[cpg]


It was a natural reaction. With that in mind, I decided to hypnotize the teacher.
[cpg]


I tried to avoid using hypnosis as much as possible, but I couldn't not use it here.
[cpg]


[OnName num="toma"]
I said, "Okay, doctor, look at me. Look at me, doctor.
[cpg cn=true]


[OnName num="toma"]
"Your body will relax, ...... and you won't be able to stand."
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Misa254"]
[OnName num="misa"]
Oh ......, ah!"
[cpg cn=true]


The teacher wobbles and falls over here.
[cpg]


The most important thing to remember is that you should never be afraid to take a look at your own personal information. Now, you can do anything you want from here.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（朝）******************************************************



The room of the teacher was rather tidy. It was well cleaned.
[cpg]


There was even a houseplant in the room, so perhaps he has a surprisingly diligent personality.
[cpg]


He must be the type of person who takes care of such things. It's a little different from what I imagined.
[cpg]


Aside from that, ...... I was in a situation where I could do whatever I wanted to the teacher.
[cpg]


I could suddenly give away my virginity. But that would be tasteless.
[cpg]


Now ...... what should I do?
[cpg]


;//移植のためシーンをカットしています



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************



I needed to let the teacher know where I stood. First, I put on the shackles.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misa272"]
[OnName num="misa"]
"Mgghh......muguuhhhh."
[cpg cn=true]


I had prepared the manacles in advance. I could have used hypnosis to take the words away, but ......
[cpg]


The first thing to do is to make sure that you have a good time with your friend.
[cpg]


[OnName num="toma"]
I don't think I'll get away with it for free. I'll do whatever I want for now.
[cpg cn=true]


At least the muzzle will have an effect.
[cpg]


Now I can't waste any more words. In an apartment like this, if he screamed, it would be the end of him.
[cpg]


[OnName num="toma"]
"Come on over here," he said, "and don't resist. Don't resist.
[cpg cn=true]


I took him to the bed and handcuffed his arms.
[cpg]


Now he could not escape. I would use hypnosis when I needed it.
[cpg]


[OnName num="toma"]
"Well," he said, "let's go to ......."
[cpg cn=true]


Once this was done, the doctor could do nothing.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************



The afternoon turned into evening, and the sun was going down.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Misa273"]
[OnName num="misa"]
"Whew, whew, ugh. ......
[cpg cn=true]


Sensei is getting weaker and weaker. Just looking at him was enough to fill my heart.
[cpg]


But still, it's boring not to talk. What should I do?
[cpg]


Is there a point where it's good that he doesn't talk?
[cpg]


[OnName num="toma"]
I think, "...... heh."
[cpg cn=true]


I chuckled, imagining what I was about to do.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

It was almost time to feed him.
[cpg]


Hunger can kill you if you go too far, and it's boring to be with someone who is too weak.
[cpg]


I bought a lunch box, but to feed him, I had to remove his shackles.
[cpg]


The teacher might call for help the moment I removed the shackles.
[cpg]


I thought about what to do. As a result, I settled on a common conclusion.
[cpg]


Just to be safe, I decided to threaten him with a knife.
[cpg]


Just the presence of a sharp metal object like this makes it impossible for people to disobey.
[cpg]


It's a strange thing, I thought to myself. ......
[cpg]


[OnName num="toma"]
I said, "If you yell, I won't hold back. Understood?"
[cpg cn=true]


I pronounced it so. I lied about not hesitating.
[cpg]


I don't have the guts to commit murder.
[cpg]


If push came to shove, I would use hypnosis, not a knife, to keep him quiet.
[cpg]


[OnName num="toma"]
Nod your head if you understand."
[cpg cn=true]


The doctor groaned and shook his head.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Misa291"]
[OnName num="misa"]
I nodded my head, "...... ugh."
[cpg cn=true]


He seems to understand. I remove the shackles.
[cpg]


This situation must be hell for her right now.
[cpg]


But I don't care. If she feels it's hell, that's fine.
[cpg]


[OnName num="toma"]
"Well," she said, "you must be hungry. Why don't you eat?"
[cpg cn=true]




;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

For a while, the doctor ate his food without saying anything. But ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************



the muzzle was gone, and he began to ask me questions.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misa292"]
[OnName num="misa"]
"What are you going to do about this ......?"
[cpg cn=true]


[OnName num="toma"]
What do you mean, what are you going to do?　I'm just doing it because I want to."
[cpg cn=true]


There was no other way to put it. I can assure you that there is no other purpose at all.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Misa293"]
[OnName num="misa"]
Even if it's good now, the police will find me soon. And that will be the end of you.
[cpg cn=true]


What is this, a sermon? I'm not going to listen to that.
[cpg]


[OnName num="toma"]
If you say anything else, I'll have to muzzle you again.
[cpg cn=true]


The teacher was silent for a while after my words.
[cpg]


But then he said again, "You seem to be getting weaker. He seems to be getting weaker.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa294"]
[OnName num="misa"]
He seems to be weak. "Hey, on second thought,......, let me out."
[cpg cn=true]


[OnName num="toma"]
"......, are you serious?"
[cpg cn=true]


If you say whether you are serious or not, you are, but ......
[cpg]


I'm not sure if you can understand that it's useless to say such a thing to the people who incarcerate you.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Misa295"]
[OnName num="misa"]
'Please, please oh ...... gusu, gusu.'
[cpg cn=true]


He doesn't seem to understand. This time, the teacher tries to make him cry.
[cpg]


In truth, I may just be crying. But still.
[cpg]


I was too dumbfounded to say anything.
[cpg]


[OnName num="toma"]
I was so stunned that I couldn't say a word.　How much of a softy can you really be, doctor?
[cpg cn=true]


[OnName num="toma"]
I'm sorry, but give it up.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Misa296"]
[OnName num="misa"]
"Ughhh ......, what should I do then?"
[cpg cn=true]


[OnName num="toma"]
I can't help you. No matter what they do to me, I will not change my mind.
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（朝）******************************************************



Then, the days with her continued.
[cpg]

She was getting weaker and weaker. However, it was rather cute to see her weakening.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています


;//========================================
;//●ＣＧ（ベッドに横たわるヒロイン。無理矢理近づいてキスをする主人公）ev_48
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夜
;//========================================


[free time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_48_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sMisa013"]
[OnName num="misa"]
She said, "Please forgive me, too, ......."
[cpg cn=true]


After returning to my room, I acted as if we were lovers.
[cpg]

[OnName num="toma"]
I said, "Forgive me?　I just want to kiss you.
[cpg cn=true]


[VOICE f="sMisa014"]
[OnName num="misa"]
I can't respond to your feelings.
[cpg cn=true]


[OnName num="toma"]
I'm not giving up on you. I'm not going to give up on you.
[cpg cn=true]


The most important thing to remember is that you can't just give up.
[cpg]

The teacher is tired of being frightened and just refuses.
[cpg]

He almost breaks completely. I had hoped for that.
[cpg]

You don't need hypnosis to do this kind of thing ......
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（朝）******************************************************



Just to be able to be with her. But over time, the doctor became weaker and weaker.
[cpg]

She was refusing to eat, and it wasn't looking good for her.
[cpg]


[OnName num="toma"]
She said, "Eat. If you don't want it, I'll put it on my lunch."
[cpg cn=true]


But she would not eat.
[cpg]


She must be very hungry, but she was trying to push herself.
[cpg]


I don't think she's going to be able to scream out loud. She would not run away, so I removed her shackles and handcuffs.
[cpg]


He probably can't even run as fast as he can now. If that were the case, there would be no point in restraining him.
[cpg]


With that thought in mind, I released his restraints.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************



[OnName num="toma"]
I asked him if he really didn't need them. How many meals have you not eaten?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misa313"]
[OnName num="misa"]
I don't want ...... to eat any more food.
[cpg cn=true]


The teacher seems to be getting desperate.
[cpg]


The most important thing to remember is that you should not be afraid to ask for help.
[cpg]


I don't want her to die. I told her, "If you don't eat, you're really going to die.
[cpg]


[OnName num="toma"]
If you don't eat, you will really die.
[cpg cn=true]


It was easy to force her to eat. But I wanted her to eat by her own will.
[cpg]


I didn't want to hypnotize her if I could help it.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Misa314"]
[OnName num="misa"]
I didn't care if she died. "I don't care if I die, as long as I'm released from this hell.
[cpg cn=true]


[OnName num="toma"]
...... I see."
[cpg cn=true]


I watched the doctor weaken. What would happen to him?
[cpg]


I don't think I'm really going to die.
[cpg]


I don't think I'm really going to die.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa315"]
[OnName num="misa"]
I'm fine with dying now...I've been a screw-up ever since I became a ...... teacher."
[cpg cn=true]


The teacher seemed to be remembering everything that had happened. I don't really know if I was a screw-up or not.
[cpg]


[OnName num="toma"]
I don't know if I was a screw-up or not. I don't know if I was a screw-up or not.
[cpg cn=true]


It's funny that I, the one who is locking him up, would say such a thing, but I still followed up with him.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Misa316"]
[OnName num="misa"]
I'm sure no one needs me. ......
[cpg cn=true]


That's the idea. That's why you're saying you're willing to die.
[cpg]


But I don't like that. I don't want him to die, and I don't want him to be too weak.
[cpg]


If push comes to shove, you really have to use hypnosis.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Misa317"]
[OnName num="misa"]
That's why you're going through all this, isn't it?"
[cpg cn=true]


The doctor continued speaking. It was as if he was repenting to me.
[cpg]


He was getting very desperate. That's cute.
[cpg]


[OnName num="toma"]
So you're ready to give up?"
[cpg cn=true]


I asked him. He didn't respond.
[cpg]


[OnName num="toma"]
I need you," I said.
[cpg cn=true]



I said, but his mood didn't seem to change.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="sMisa015"]
[OnName num="misa"]
I don't want to hear any more of that ...... stuff."
[cpg cn=true]


;//移植のためシーンをカットしています

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

Misa-san seemed to be getting really weak. I thought I would force her to eat.
[cpg]


[OnName num="toma"]
She said, "Eat. Open your mouth."
[cpg cn=true]


I tried to force it into her mouth, but she wouldn't ...... accept it.
[cpg]


The doctor did not even try to open his mouth.
[cpg]


It was possible that he would just wither away and die.
[cpg]


If that happened, my goal would not be achieved.
[cpg]



I had no choice but to hypnotize him into eating.
[cpg]


[OnName num="toma"]
Look at me. Look at me, doctor.
[cpg cn=true]


I looked at the teacher. In that state, I commanded him.
[cpg]


[OnName num="toma"]
"Now, I'm going to eat. You will have to eat food regardless of your will.
[cpg cn=true]


Hearing this, or rather the effect of hypnosis, the doctor was surprised.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Misa337"]
[OnName num="misa"]
He said, "I don't want to eat, but my ...... body will move on its own.
[cpg cn=true]




;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Then, she made the doctor eat the food.
[cpg]


She didn't seem to understand what she was doing, but ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************



Soon, she realized that I was doing something.
[cpg]


Even if she didn't understand what I was doing, she was doing something.
[cpg]


She must have thought so, because she asked me, "Who are you?
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misa338"]
[OnName num="misa"]
What are you, ......?　Do you have psychic powers?
[cpg cn=true]


[OnName num="toma"]
I said, "I'm ......."
[cpg cn=true]


That's about it. But I don't have to answer.
[cpg]


It won't change anything. I have no plans to use hypnosis in the future.
[cpg]


I will use it again when I stop eating. ......
[cpg]


But I don't intend to use it in any other situation.
[cpg]


At least, I won't use it on my teachers.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Misa339"]
[OnName num="misa"]
Come to think of it, I've had some strange ...... memory lapses lately."
[cpg cn=true]


The teacher seemed to be going back to his memory.
[cpg]


I've done a lot of things in my life. You might even think it was all my doing.
[cpg]


And that is correct. I had somehow tampered with the parts of her memory that were missing.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa340"]
[OnName num="misa"]
Was it all Suzumura-kun's doing?"
[cpg cn=true]


She asks. I didn't have to answer her.
[cpg]


Even if I did, she wouldn't believe me.
[cpg]


My abilities were beyond human knowledge. I was at least aware of that.
[cpg]


[OnName num="toma"]
"I don't know. I don't know."
[cpg cn=true]


I was vague. What did the teacher want to say?
[cpg]


[OnName num="toma"]
I was just saying, "Well, I don't care about that, sir. I'll give you a bath.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Misa341"]
[OnName num="misa"]
I said, "Well, why don't you answer me at ......?
[cpg cn=true]


The reason is that there's nothing you can do about it. It doesn't change the past.
[cpg]


[OnName num="toma"]
I threatened him, "If you keep talking too much, I'm going to put a fetter on you again.
[cpg cn=true]


I threatened. The teacher became silent.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夜）******************************************************



Then night falls. I hypnotized him so he couldn't call for help, and I decided to let him take a shower.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misa342"]
[OnName num="misa"]
I said, "You don't have to let me ...... take a bath."
[cpg cn=true]


[OnName num="toma"]
I don't need you to bathe me," he said. I'm a human being, I have to wash my body.
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I was starting to feel a little like I wanted to take good care of them.
[cpg]

The most important thing to remember is that you can't just take a bath in a bathtub.
[cpg]

It was a difficult character, but both of them might come true.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夜）******************************************************



The teacher took a shower. In addition, she had just eaten dinner, so she was no longer hungry.
[cpg]


If she wanted to escape, she could. But she wouldn't.
[cpg]


I guess I don't have to restrain her any longer.
[cpg]


[OnName num="toma"]
You've become more honest, doctor. That's good."
[cpg cn=true]


I said, and put the handcuffs on.
[cpg]


I'm going to have a lot of fun keeping her locked up.
[cpg]


I'm going to keep doing it. That's what I thought.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（朝）******************************************************



And then morning came. I decided to go buy breakfast in my sleep.
[cpg]


Leaving the teacher here is no problem at all. He's probably already lost the will to run away.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************


[SE f="se008"]
;//【ＳＥ】『携帯電話の振動音』

As I went about my day, his cell phone rang.
[cpg]


[OnName num="toma"]
I'm not going to let you leave. I think you know that."
[cpg cn=true]


On the screen was a name I didn't recognize.
[cpg]


[OnName num="toma"]
"...... who is this guy?"
[cpg cn=true]


I just showed it to the teacher.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misa359"]
[OnName num="misa"]
'It's from college. ......I say I'm a lecturer, but I don't have the whole summer off.'
[cpg cn=true]


[OnName num="toma"]
'...... I see.'
[cpg cn=true]


Well, that's probably true. I'm sure professors and such do the same.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Misa360"]
[OnName num="misa"]
Someday you'll realize I'm not here,......, and that will be the end of Suzumura-kun.
[cpg cn=true]


Well, that could certainly happen.
[cpg]


But it's not a threat that will happen right now.
[cpg]


And even if it did happen, I felt like I could do anything about it.
[cpg]


[OnName num="toma"]
I doubt it," he said. Even if the police come, I'll do something about it with hypnosis.
[cpg cn=true]


I assured him. The doctor bit his lip.
[cpg]


[OnName num="toma"]
My hypnotism is absolute. I can do whatever I want to the part of a person's consciousness.
[cpg cn=true]


I assured him, but he countered, "Well, you see, hypnosis is a kind of hypnotism.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa361"]
[OnName num="misa"]
I don't know how much hypnosis you're talking about, but ......
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Misa362"]
[OnName num="misa"]
It's going to come back to haunt you someday. You'll never get away with it.
[cpg cn=true]


[OnName num="toma"]
"......funny."
[cpg cn=true]


You're trying to scare me with words like that? That's shallow.
[cpg]


I wouldn't have locked him up in the first place if I was frightened by such words.
[cpg]


[OnName num="toma"]
I'll get away with it. My hypnotism is more powerful than you think.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misa363"]
[OnName num="misa"]
I won't say anything now. Please reconsider.
[cpg cn=true]


The doctor tries to cut me off like that.
[cpg]


Of course, I don't comply. Of course I wouldn't comply, and there was no guarantee that he wouldn't say anything.
[cpg]


[OnName num="toma"]
Don't be ridiculous. I'm not going to say anything.
[cpg cn=true]


He said it was true, but I knew it was just a promise.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************



I continued to lock him up.
[cpg]


Night comes again and again. Day comes. Over and over again.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夜）******************************************************



[SE f="se008"]
;//【ＳＥ】『携帯電話の振動音』



The phone rang again and again. But I never answered it.
[cpg]


Or rather, I couldn't answer it. I would be strangling myself.
[cpg]


I could hypnotize the teacher and make her answer the phone. ......
[cpg]


Would I be able to get out of it with a temporary illness? I don't think so.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************



While I was thinking about this, the situation changed.
[cpg]


Before long, someone from the university came to my house.
[cpg]



[SE f="se004"]
;//【ＳＥ】『ドアを叩く』



They knocked on my door several times. I used the answering machine.
[cpg]


[OnName num="university_personnel"]
"Sir!　You're not there?
[cpg cn=true]


[OnName num="university_personnel"]
That's funny, ......, you don't answer your phone. ......."
[cpg cn=true]


I hear something being said on the other side of the door, but I ignore it.
[cpg]


 The teacher looked a little relieved, probably because he thought it would be over soon.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夜）******************************************************



Is it about to be bad? If the teacher wasn't here, the police would be here.
[cpg]


I had to think of my next move.
[cpg]


If push came to shove, I might be able to hypnotize him to .......
[cpg]


I came up with a plan. I'll get through this. With that thought, I drifted off to sleep.
[cpg]


The teacher repeatedly mumbled something like, "It's finally over," but I didn't care.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************



[SE f="se004"]
;//【ＳＥ】『ドアを叩く』



Again, there is a knock at the door.
[cpg]



[SE f="se006" loop=true]
;//【ＳＥ】『パトカーのサイレン』



I try to fool around with my residence, but soon I hear the siren of a police car.
[cpg]


[OnName num="toma"]
'Oh no. ......'
[cpg cn=true]


It was only a matter of time now. I hear something like a door being pried open.
[cpg]


The door is about to be forced open. And it's going to be opened. ......!
[cpg]


I thought. My mind is going full throttle like never before.
[cpg]


With my hypnosis, I should be able to do something.
[cpg]


There is no such thing as a hopeless situation for me.
[cpg]


[OnName num="police_officer"]
"Is anyone here, ......?"
[cpg cn=true]


I stayed at the far end of the room and tried to be as interactive as possible.
[cpg]


I had to hypnotize him.
[cpg]


The cops would find the fallen doctor first.
[cpg]


I decided to hypnotize the cop while he was there.
[cpg]


In the meantime, the policeman would find the teacher.
[cpg]


[OnName num="police_officer"]
The policeman said to me, "You're a ...... murderer or ......?"
[cpg cn=true]


I look at the policeman who is saying this, and I make eye contact with him.
[cpg]


[OnName num="toma"]
I look at him and say, "You're going to fall asleep. You're going to fall asleep.
[cpg cn=true]


[OnName num="toma"]
You're going to lose your strength and you're going to fall ...... down and you're not going to be able to move."
[cpg cn=true]


[OnName num="police_officer"]
"Oh, ...... ugh, ugh."
[cpg cn=true]


Well. What are we going to do from here?
[cpg]


I couldn't just get through this situation and be done with it.
[cpg]


Because the teacher would tell him everything.
[cpg]



;//ブラックアウト
[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



I decided to escape.
[cpg]


It doesn't mean I wasn't there. There must have been some kind of trace left behind.
[cpg]


I'm not sure about fingerprints or anything, but they might have some kind of evidence and ......
[cpg]


The teacher would have talked about me in the first place. He was bound to mention my name.
[cpg]


[OnName num="toma"]
'Oh dear, we're going to have a tough time now.
[cpg cn=true]


Oh my God, it's going to be tough. I said, "But I'm not in trouble.
[cpg]


I was already thinking about my next move. I couldn't say that I didn't want to use hypnosis anymore.
[cpg]


On the contrary, as long as I use hypnosis, I can disappear.
[cpg]


This was the beginning of my days on the run, but I didn't have much trouble.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


The means to catch people are designed on the assumption that they do not have supernatural powers.
[cpg]

That's right, because there is no one like that except me.
[cpg]

Then ...... there's no way they can catch me.
[cpg]

It reminds me of a comic book I read a long time ago. It was about ordinary people hunting down thugs with super powers by sheer numbers.
[cpg]

But that kind of thing only happens in comic books, and I had more power than the thugs in the comic book.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



[OnName num="toma"]
That's why the police are after me."
[cpg cn=true]


I was headed for my senior's house.
[cpg]


I was headed to my senior's house, where I already knew she lived alone too.
[cpg]


I could have targeted her instead of the teacher.
[cpg]


I was glad I got her address, I thought now.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Marie373"]
[OnName num="marie"]
I'm sorry you're going through such a hard time. Toma-kun is also ......"
[cpg cn=true]


The police were chasing me, and they were hiding me from the police.
[cpg]


The reason why you are not surprised is because I had hypnotized her.
[cpg]


I hypnotized her into hiding me.
[cpg]


This was enough to solve most of my problems.
[cpg]


You would never guess that a criminal on the run would be staying at the home of a completely unrelated student.
[cpg]


There was no reason to hide him. And yet, I had managed to create a reason to hide him.
[cpg]


My power was too perfect. As long as I am beyond human knowledge, ordinary guesses cannot reach me.
[cpg]


Even if the doctor had told me about my hypnotism, it would be the same.
[cpg]


The search will be extremely difficult. And ......
[cpg]


If I keep moving from one house to another, I'll have no trouble finding food and a place to sleep. ......
[cpg]


[OnName num="toma"]
'More importantly, senpai. Could you turn around for a moment?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
What?　I'm going to hypnotize you," he said.
[cpg]


[OnName num="toma"]
I hypnotized him into believing that he was my lover.
[cpg cn=true]


[FACE method="change_8" pos="2/3"]

You'll think you're my lover. I don't even have to worry about a girlfriend.
[cpg]


It's more comfortable than my normal, conventional life.
[cpg]


I thought I would stay like this for a while.
[cpg]


[OnName num="toma"]
I thought to myself, "...... You have a nice face. You look like you're in love with me.
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="sMarie039"]
[OnName num="marie"]
Well, that's ......
[cpg cn=true]


She didn't say she liked me, but she was blushing.
[cpg]

I can get whatever I want.
[cpg]



This time I can go to Nanako. I'm going to plan a lot of things.
[cpg]


I could follow not only my college acquaintances, but any woman I meet on the street.
[cpg]


I can't stop laughing when I think about it. No one can catch me.
[cpg]


I'm a criminal and live a comfortable life. This kind of life is not bad. ......
[cpg]


[SCENE id=13]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[jump storage="epend.ks" target="*start"]
;//ＥＮＤ：ヒロイン３ルート２



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


