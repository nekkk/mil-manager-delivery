
*start


;//O・SHI・KA・KE 催眠術師　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//毬枝　　裸　私服
;//奈々子　裸　私服
;//美沙　　裸　私服　スーツ
;//台本用で仕上げるため、主にＨシーンを短く書いておりました
;//現在は追加済です
;//以下音声なし
;//斗真
;//女子学生Ａ
;//女子学生Ｂ
;//警察官Ａ
;//警察官Ｂ
;//奈々子の母
;//警察官
;//大学関係者
;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//毬枝　一人称「私」　奈々子呼び「奈々子ちゃん」　美沙呼び「細田先生」　斗真呼び「斗真くん」
;//奈々子　一人称「私」　毬枝呼び「毬枝さん」　美沙呼び「細田先生」　斗真呼び「斗真さん」
;//美沙　一人称「私」　毬枝呼び「瀬能さん」　奈々子呼び「桜井さん」　斗真呼び「鈴村くん」
;//斗真　一人称「俺」　毬枝呼び「先輩or毬枝」　奈々子呼び「奈々子」　美沙呼び「先生」


;//以下、残したＣＧを列挙いたします
;//毬枝   ev_01 ev_04 ev_10 ev_11 ev_14 ev_18 ev_22
;//奈々子 ev_07 ev_08 ev_29 ev_30 ev_31 ev_35 ev_36
;//美沙   ev_03 ev_06 ev_44 ev_48 ev_49 ev_50

;//ev_48はルートごとのＣＧを確保するために場所が移動しています
;//また、Ｈシーンのテキストを削る代わりに新たな文章を追加しています
;//それに伴い追加される新しいセリフは、100未満くらいになっています




;///////////////////////////ここからが本編です///////////////////////////




;#################################################
*Ep000|The Power of Hypnosis
;#################################################

[SCENE id=0]

[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[stflag Rootflg = 0]
[stflag Jumpflg = 1]



[BGM f="bg_d1"]
;//ブラックアウト

[window target=false]
[BG f="black.ui" time=1000]
[WAIT time=2000]


[window target=true]
Toma Suzumura. Neither bright nor dark, he is a college student who could be anywhere.
[cpg]


I am the one who plays the role of ......, a college student who could be anywhere. The truth is that I am a little more extraordinary.
[cpg]



;//画面の色調をセピア調にしてください




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



At first, I imitated a hypnotist I saw on TV.
[cpg]


It was really something I did as a kid out of complete curiosity.
[cpg]


I tried it on a girl I went to school with and was good friends with. It was a girl, and I still remember the moment well.
[cpg]


Your strength drained from your body. You suddenly lost all strength.
[cpg]


Really, it was just like I was watching you do it. I even tied a string to a five-yen coin and shook it.
[cpg]


But the boy ...... really lost his strength and fell down.
[cpg]


There was a bit of a commotion, but in the end people didn't understand what had happened.
[cpg]


Except me, the person involved, ......
[cpg]



;//画面の色調を元に戻してください
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]


From there, growing up, I tried hypnosis in hiding.
[cpg]


I used some of them in my experiments while nailing them not to tell anyone.
[cpg]


I didn't do anything terrible to those kids.
[cpg]


I wasn't ready for that kind of thing yet. My hypnosis could not manipulate memories.
[cpg]


If I can't manipulate memories, my power is still too weak to do anything.
[cpg]





;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Summer. It was the hottest time of the year, almost summer vacation.
[cpg]


No matter how much I can use hypnosis, I can't handle this heat.
[cpg]


If I had to say, could I ease the heat by self-hypnosis?　Would it be possible?
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学講義室』（朝）******************************************************



While I was thinking about such things, I arrived at the university. I was planning to try hypnosis with someone today.
[cpg]


But that will come a little later. I am just an ordinary college student.
[cpg]


I have to attend all my lectures first. If I want to do something, I'll do it after that.
[cpg]


;//ブラックアウト
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[WAIT time=1000]


I could have lived a normal life if I wanted to.
[cpg]


But I couldn't stop there.
[cpg]


Once you know you can do something superhuman, you want to master it.
[cpg]


Without anyone knowing about it. At least, that was my nature.
[cpg]


I think anyone would feel the same way if they had this kind of power.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大学講義室』（昼）******************************************************



Then, during lunch break. I met up with the person I was after.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="toma"]
"Senior. Hello.
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
Senpai. Marie Senou.
[cpg]


One year older than me. She is the only person in this university who knows that I can use hypnosis.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Marie001"]
[OnName num="marie"]
Hello. You are going to do it again today, right?　Training?
[cpg cn=true]


[OnName num="toma"]
"Yes, I do. I'm looking forward to it.
[cpg cn=true]


Training. That is, literally, hypnosis training.
[cpg]




;//ブラックアウト


;//========================================
;//●ＣＧ（机の上で手を握るヒロイン。開けなくて驚く。その後微笑む。目に光はともっている）ev_01
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：大学講義室
;//時間　：昼
;//========================================



[free time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="toma"]
You will not be able to open your hand ...... completely anymore.
[cpg cn=true]


[OnName num="toma"]
"Little by little, your muscles will stiffen. Your muscles will gradually harden, rejecting signals from your head.
[cpg cn=true]


I try to get him to open his hand after that, telling him something like that.
[cpg]


[OnName num="toma"]
How do you like it?　Can you open it?"
[cpg cn=true]



[VOICE f="Marie002"]
[OnName num="marie"]
"Great, ...... it doesn't move at all. It's stuck.
[cpg cn=true]


I'm good friends with my seniors. I'm a good friend of my seniors, and this is partly to make sure they keep their promise not to tell anyone.
[cpg]


But more than that, I don't want them to be afraid of this hypnosis.
[cpg]


I'm trying to do something about it. I made sure that I was not going to do anything to my senpai.
[cpg]


Thanks to that, they are not afraid of my hypnosis, but are amused by it.
[cpg]


[OnName num="toma"]
I hope ...... my hypnosis will have a stronger effect."
[cpg cn=true]



[VOICE f="Marie003"]
[OnName num="marie"]
"Hmmm, what's that?　You're up to something, aren't you?
[cpg cn=true]


[OnName num="toma"]
No, I'm not trying to take over the world. I'm not planning to take over the world.
[cpg cn=true]



[VOICE f="Marie004"]
[OnName num="marie"]
You already said it. World domination.
[cpg cn=true]


While we were having this conversation, I was testing the effectiveness of my hypnotism.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学講義室』（昼）******************************************************



[OnName num="toma"]
I wish I could do something more like manipulating ...... memories.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marie005"]
[OnName num="marie"]
"Oh no, don't try it on me.　I'm afraid of it.
[cpg cn=true]


[OnName num="toma"]
I'm afraid to try it on me." "And then I'll be able to eat the foods I don't like.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Marie006"]
[OnName num="marie"]
"That would be great.
[cpg cn=true]


The most important thing to remember is that the hypnosis is growing in power on its own.
[cpg]


I didn't know how I could make it more powerful.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Marie007"]
[OnName num="marie"]
I was so excited to see her. See you later.
[cpg cn=true]


[OnName num="toma"]
Yes, I'll see you later. See you later.
[cpg cn=true]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大学講義室』（夕方）******************************************************



I finished the afternoon lecture and was about to walk out of the lecture room.
[cpg]



;//ここから暫く奈々子の名前欄を「？？？」と隠してください



[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Nanako001"]
[OnName num="unknown"]
"......, ......, ah..."
[cpg cn=true]


[OnName num="toma"]
Oops. ......."
[cpg cn=true]


On my way out, I almost bumped into a girl.
[cpg]


I think she was a junior. I hadn't seen her until last year.
[cpg]


[OnName num="toma"]
I'm sorry. I'm sorry.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako002"]
[OnName num="unknown"]
I bowed to her without saying anything.
[cpg cn=true]


She bowed her head without saying anything. And then he just walked away.
[cpg]


What can I say, she had a mysterious atmosphere.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大学外観』（夕方）******************************************************



And today, college is over.
[cpg]


Someday I'd like to try using a senior to see if I can erase my memory. ......
[cpg]


But I couldn't do it because I felt it was somehow too risky.
[cpg]


If the hypnosis doesn't work, the fact that I tried to erase the memory will be revealed.
[cpg]


That would be a big deal that could destroy my relationship with my senpai. I knew I could not make a rash move.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]

As I was thinking this, I met Ms. Hosoda. Misa Hosoda-sensei.
[cpg]


;//[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misa001"]
[OnName num="misa"]
......
[cpg cn=true]


She was sighing again today, probably tired from her unfamiliar work.
[cpg]


She is a new teacher. She is not that much older than us.
[cpg]


The most important thing to remember is that you can't just take a look at the pictures and say, "I'm sorry. She's a bit of a klutz, but that's part of her charm.
[cpg]


She's beautiful, too. If the hypnosis to erase her memory works, I would like to target her.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



I walked home.
[cpg]


I could walk to the university from my house. That's why I chose this lodgings.
[cpg]


That's right. I live in a boarding house. That was very important for me.
[cpg]


In other words, my parents would not notice if I did not go home.
[cpg]


This was essential to the fulfillment of my ambitions.
[cpg]




[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//[BGM f="bg_d2"]
;//[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



Before the evening turned into night, I headed to the supermarket to cook for myself.
[cpg]


But by the time I left the supermarket, it was night.
[cpg]


I'm not such a serious student. I was thinking, "......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="toma"]
Ah ......"
[cpg cn=true]


I met her whom I saw during the daytime. I wonder if she has a boarding house nearby.
[cpg]


She was passing by, but we were going in the same direction and I spotted her.
[cpg]


[OnName num="toma"]
Good evening.
[cpg cn=true]



;//ここから暫く奈々子の名前欄を「？？？」と隠してください



[FACE method="change_5" pos="2/3"]
[VOICE f="Nanako003"]
[OnName num="unknown"]
Oh, .......
[cpg cn=true]


[OnName num="toma"]
I wonder if she lives near her lodgings. She's probably younger than me, right?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako004"]
[OnName num="unknown"]
Uh, yes.
[cpg cn=true]


There is no reason to be friendly with him. I was just a little curious about her.
[cpg]


She's a pretty cute girl. I'm sure she won't be popular because she looks dark.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Nanako005"]
[OnName num="unknown"]
"Oh, um, ...... I'm going the wrong way, so ...... here."
[cpg cn=true]


[OnName num="toma"]
"Oh, yeah. ......?"
[cpg cn=true]


And then he went into a very narrow street.
[cpg]


I think he was actually going in the same direction as me. I think she might have forced herself to move away from me.
[cpg]


She didn't seem to be good at socializing. I wouldn't be surprised if she came up with that idea.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I went home and took a shower after filling my stomach with a simple meal.
[cpg]


I'm not a hobbyless person, but I don't have a lot of hobbies either. In addition, I am not the type to stay up too late.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



So, I have naturally developed a healthy lifestyle rhythm. I don't mean to imply that I do so intentionally.
[cpg]


It's just that there is nothing better than being healthy. It may have an effect on hypnosis.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学外観』（朝）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Marie008"]
[OnName num="marie"]
Good morning, Toma. Toma.
[cpg cn=true]


[OnName num="toma"]
Good morning. It's early in the morning, isn't it?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Marie009"]
[OnName num="marie"]
Isn't it the same with you, Toma?
[cpg cn=true]


I guess so. I wonder if you are in some kind of a club, Marie.
[cpg]


[OnName num="toma"]
"Marie, are you in a circle or something?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Marie010"]
[OnName num="marie"]
I'm not. I just came early because I was in the mood.
[cpg cn=true]


The first thing to do is to get a good idea of what you want to do. This was a good thing. She was the one who suggested it.
[cpg]


[OnName num="toma"]
I'll take care of it.
[cpg cn=true]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『大学講義室』（朝）******************************************************



An empty lecture room. We were both face to face, experimenting with hypnosis.
[cpg]


[OnName num="toma"]
"As it is, I can't stay awake any longer, I feel so sleepy.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marie011"]
[OnName num="marie"]
"Nnnn...... phew, hah, ah."
[cpg cn=true]


[OnName num="toma"]
"I fall asleep ...... and the power completely leaves my body."
[cpg cn=true]


I don't need any tools for my hypnosis. The most important thing to do is to keep your eyes on the road.
[cpg]


It's a power that's quite remote from human knowledge, but that's how useful it is.
[cpg]


[free time=800]
And then, I see ......
[cpg]



;//ここから暫く奈々子の名前欄を「？？？」と隠してください



[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Nanako006"]
[OnName num="unknown"]
"......!"
[cpg cn=true]


When I turned around, my eyes met another girl's.
[cpg]


She looked at me. That I was a senior and had tried it.
[cpg]


I wondered how far they had seen me. If they had seen everything, it would have been very bad.
[cpg]


My hypnotism is something I have to hide.
[cpg]



[SE f="se015"]
;//【ＳＥ】『走る』


[free time=1000]
[WAIT time=1100]

[OnName num="toma"]
Oh, wait, ......!
[cpg cn=true]


The girl ran away. I might have been watched for a long time.
[cpg]


I was seen in a bad way. This is pretty really bad. ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marie012"]
[OnName num="marie"]
"What's wrong, Toma?
[cpg cn=true]


[OnName num="toma"]
Oh, no, nothing. ......
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学講義室』（昼）******************************************************




I had an ambition.
[cpg]

The most important thing to remember is that the best way to get the most out of your home is to make the most of your time and money.
[cpg]


But if word got out about this, my ambition might be thwarted.
[cpg]


I was in a hurry. I couldn't believe that my ambition would be cut short by something so trivial.
[cpg]


No. ......If this happens, I'll do whatever I can to catch the girl who just came in.
[cpg]


And yes. I need to try that hypnotism.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大学外観』（昼）******************************************************



So I looked for her.
[cpg]


[OnName num="toma"]
"Oh, there she is. ......, excuse me."
[cpg cn=true]



;//ここから暫く奈々子の名前欄を「？？？」と隠してください



[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Nanako007"]
[OnName num="unknown"]
"...... what?"
[cpg cn=true]


[OnName num="toma"]
"My name is Suzumura. My name is Toma Suzumura, and you?
[cpg cn=true]



;//ここから名前を隠さず表示してください



[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako008"]
[OnName num="nanako"]
I'm ...... Nanako Sakurai.
[cpg cn=true]


Nanako. I don't really need to know her name, but it would be bad if she didn't cooperate to some extent.
[cpg]


I decided to take her to another lecture room.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『大学講義室』（昼）******************************************************



I decided to hypnotize her at the place where I took her.
[cpg]


[OnName num="toma"]
I said to her, "I have nothing else to do. Just look at me for a second.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Nanako009"]
[OnName num="nanako"]
What? ......?"
[cpg cn=true]


[OnName num="toma"]
"Little by little, you'll be sucked into my eyes ...... and my consciousness will take over."
[cpg cn=true]

[FACE method="change_8" pos="2/3"]

I hypnotize Nanako as I say this.
[cpg]


The most important thing to remember is that you can't just take a look at the actual product or service and expect it to work. But I have no choice but to make it succeed.
[cpg]


For that I had to pray. ......
[cpg]


[OnName num="toma"]
You will forget that you were hypnotized and that scene where you hypnotized your senior.
[cpg cn=true]


I wonder if ...... is working. I'm in a daze.
[cpg]



;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『人が倒れる』
[free time=1000]
[WAIT time=1000]


Nanako fell to the floor.
[cpg]


She seemed to have lost the strength to sit on the chair.
[cpg]


[OnName num="toma"]
The first thing that comes to mind is the fact that the first time you see a person, you know that they are not going to be able to get up.　Can you stand up, Nanako?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Nanako010"]
[OnName num="nanako"]
"Oh, ......, is that ......?"
[cpg cn=true]


[OnName num="toma"]
"......, do you remember what happened to you until now?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako011"]
[OnName num="nanako"]
"......, that's, uh, ...... what was it?
[cpg cn=true]


It may or may not be working. It's hard to tell from this.
[cpg]


I reached out my hand and asked, "Do you remember what hypnosis is?
[cpg]


[OnName num="toma"]
Do you remember what hypnosis is?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nanako012"]
[OnName num="nanako"]
Hypnosis is ......?"
[cpg cn=true]


Apparently, it was working. I had finally managed to manipulate people's memories.
[cpg]


I wanted to burst out laughing, but it would look suspicious if I did so at this very moment.
[cpg]



;//ブラックアウト


;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_06_2.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//
;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『大学講義室』（昼）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanako013"]
[OnName num="nanako"]
"Well, ......, I think you took me to ......."
[cpg cn=true]


[OnName num="toma"]
"Oh. I'm not here for anything else. Forget it."
[cpg cn=true]


Nanako has a look of disbelief on her face.
[cpg]


The most important thing to remember is that you can't just go to the store and ask for a refund.
[cpg]


So I decided to leave Nanako like this.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学講義室』（夕方）******************************************************



Then, the afternoon lecture. I remember Nanako's reaction at that time.
[cpg]


She really seemed to have forgotten about it.
[cpg]


I could make her forget no matter what I did.
[cpg]


At least, as far as Nanako was concerned, the hypnosis had worked. I thought to myself.
[cpg]



;//■選択肢
[switch]
[case "I could continue to target Nanako."]
	[swap]
	[jump target="*select01_1"]
[case "I'll stay away from Nanako so that she won't say anything."]
	[swap]
	[jump target="*select01_2"]
[endswitch]


One, I can target Nanako.
2. I'll stay away from Nanako so that she won't say anything.



;//==============================
;//１、このまま奈々子をターゲットにできそうだ

*select01_1|The power of hypnotism


[stflag Cha2flg = 1]

[system Cha2sysflg=true]



I think I can make Nanako the target of my ambition.
[cpg]


But it's too early for that. We have to make sure everything is in order.
[cpg]



;//奈々子が候補に

[jump target="*select01_3"]

;//==============================
;//２、奈々子には何も喋らせないよう、近づかないでおこう


*select01_2|The Power of Hypnosis

[system Cha2sysflg=false]


I don't want to say anything to Nanako so that she won't do anything unnecessary.
[cpg]


It is not a good idea to get any closer.
[cpg]



;//==============================

*select01_3|The Power of Hypnosis

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大学外観』（夕方）******************************************************



Here we go. We need to test the power of hypnosis to see what kind of hypnosis we can now use.
[cpg]


Who should we try it on? If we try it with only Nanako and her seniors, I don't think we have enough samples.
[cpg]


After all, we can make them forget. Then I feel like we should be more daring.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



I stayed at home, plotting something else.
[cpg]


I decided to target the teacher next time.
[cpg]


She's a beautiful woman. If you know you can do something, anything, then a beautiful woman is better.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学外観』（朝）******************************************************



In the morning, I headed back to the university.
[cpg]


This time it was the teacher. This time, I would try a more complicated hypnosis.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misa002"]
[OnName num="misa"]
"Ah, Mr. Suzumura. Can I help you?
[cpg cn=true]


[OnName num="toma"]
Yes, I have something to do. I have some business to attend to. ......
[cpg cn=true]


I make sure no one is around while saying, "Yes, I have some business to attend to.
[cpg]


It would be difficult to call him anywhere. So, I hypnotized him while he was standing here.
[cpg]


[OnName num="toma"]
You will fall into a hypnotic state while still having the strength to stand. ......
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_8"  pos="2/3" time=800]
[VOICE f="Misa003"]
[OnName num="misa"]
......"
[cpg cn=true]



;//========================================
;//●ＣＧ（ぼうっと立ったまま、抱えていた書類を落とすヒロイン。目の光を失っている→目に光がともる）ev_03
;//人物１：ヒロイン３
;//服装１：スーツ
;//場所　：大学外観
;//時間　：朝
;//========================================



[free time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


[SE f="se013"]
;//【ＳＥ】『物を落とす』


She dropped the papers she was carrying.
[cpg]


But she doesn't notice that either. I hypnotize her as it is.
[cpg]


[OnName num="toma"]
"From now on, even if she doesn't see me, she'll think I'm in the lecture.
[cpg cn=true]


[OnName num="toma"]
While I'm in the lecture, it's ...... as usual, but while I'm not there, it looks like I am."
[cpg cn=true]


[OnName num="toma"]
Okay?　Okay, then I'm going to unhypnotize you."
[cpg cn=true]



[SE f="se012"]
;//【ＳＥ】『指を鳴らす』



I snap my fingers. Then Misa woke up.
[cpg]



[VOICE f="Misa004"]
[OnName num="misa"]
'Oh, is that ......?　What was I ...... doing?"
[cpg cn=true]


[OnName num="toma"]
I don't know. You dropped your paperwork.
[cpg cn=true]



[VOICE f="Misa005"]
[OnName num="misa"]
Oh, ......."
[cpg cn=true]


I decided to skip the teacher's lecture.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大学外観』（昼）******************************************************



I wondered if it would work. After the lecture, the teacher came out.
[cpg]


Would he be angry with me and ask why I skipped his lecture?
[cpg]


Or would he pay no attention? I wondered if he would say anything at that point, so I had to talk to him.
[cpg]


[OnName num="toma"]
I need to talk to him. Can I talk to you for a minute?
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misa006"]
[OnName num="misa"]
"What?　What is it?
[cpg cn=true]


[OnName num="toma"]
"Was I in your lecture earlier?"
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misa007"]
[OnName num="misa"]
"......, that's a strange question. You're talking about yourself, aren't you?
[cpg cn=true]


[OnName num="toma"]
Come on, tell me.
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misa008"]
[OnName num="misa"]
You seemed to be taking the lecture seriously.
[cpg cn=true]


......Good. Now the arrangements are finally made.
[cpg]


I've succeeded in misleading them for quite a long time.
[cpg]


This is going to have a lot of applications.
[cpg]


And I thought once again about who to target.
[cpg]



;//■選択肢
[switch]
[case "Maybe I could drop the teacher."]
	[swap]
	[jump target="*select02_1"]
[case "Let's just drop the senior."]
	[swap]
	[jump target="*select02_2"]
[endswitch]


1, I might be able to drop the teacher, too.
2, Let's drop the senior to the end.



;//==============================
;//１、先生も落とせるかも知れない

*select02_1|The Power of Hypnosis

[stflag Cha3flg = 1]

[system Cha1sysflg=false]
[system Cha3sysflg=true]


Hypnosis can be so effective.
[cpg]


By targeting her, things may go more smoothly.
[cpg]


;//美沙が候補に

[jump target="*select02_3"]

;//==============================
;//２、あくまで先輩を落とそう


*select02_2|Power of hypnosis

[stflag Cha1flg = 1]

[system Cha1sysflg=true]
[system Cha3sysflg=false]

Let's target the senior.
[cpg]


She is the one who started the whole thing. After all, we must not make a mistake.
[cpg]



;//毬枝が候補に



;//==============================


*select02_3|The Power of Hypnosis


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misa009"]
[OnName num="misa"]
So?　Any reason why you stopped me?
[cpg cn=true]


[OnName num="toma"]
No, that's all I wanted to ask. That's all I wanted to ask.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Misa010"]
[OnName num="misa"]
'...... You're a weird kid.'
[cpg cn=true]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学講義室』（夕方）******************************************************



Then I finally decided to make my move.
[cpg]


I approach the girls. I want to see who's good for me and if they have a girlfriend in the first place.
[cpg]


After all, I can erase their memories. I can do anything I want.
[cpg]


With this in mind, I waited for the end of the lecture that my seniors were attending.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Marie013"]
[OnName num="marie"]
What is it, Toma? What do you want, Toma?
[cpg cn=true]


[OnName num="toma"]
I have something to do. May I?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Marie014"]
[OnName num="marie"]
I asked, "What do you want?" "Oh, well..."
[cpg cn=true]


I waited for the other students to leave, and then I had one-on-one time with my senpai. Then I hypnotized him.
[cpg]


[OnName num="toma"]
'You're going to start following me. This is something you will never be able to resist. ......"
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
I can switch whether my words are hypnotic or not myself.
[cpg]


I don't know what switches it, but just a slight adjustment of the tone of voice has the effect of hypnosis.
[cpg]


[OnName num="toma"]
I say, "Okay?　Follow me."
[cpg cn=true]



[VOICE f="Marie015"]
[OnName num="marie"]
'...... yeah.'
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



And I brought my senior to an unused lecture room.
[cpg]


I don't think anyone saw me. I wouldn't make such a rudimentary screw-up.
[cpg]


I don't think anyone saw me, but if they did, I could hypnotize them and that would be the end of it.
[cpg]



;//========================================
;//●ＣＧ（うつろな目をしているヒロイン。主人公の質問になんでも答えてしまう）ev_04
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：大学講義室
;//時間　：夕方
;//========================================



[BGM f="bg_h1"]
;**【ＣＧ】 ev_04_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="toma"]
You'll have no choice but to answer the questions they're going to ask you."
[cpg cn=true]


He looked at me with a vacant look in his eyes, as if he was not sure if he was looking at me or not.
[cpg]

I am used to seeing this kind of expression. I'm used to seeing this kind of expression, so I'm not surprised.
[cpg]

[OnName num="toma"]
I asked him, "Do you mind if I ...... ask you a question?　I'll ask you a question then.
[cpg cn=true]


I could ask anything now, because I could erase my memory later.
[cpg]

[OnName num="toma"]
I'm not sure if you have a  girlfriend or not. Do you have a ...... girlfriend?
[cpg cn=true]


There was a slight hesitation to answer, but soon she answered, "I don't have a  girlfriend.
[cpg]

[VOICE f="sMarie001"]
[OnName num="marie"]
I don't have a ...... girlfriend.
[cpg cn=true]


I was glad to hear that. Otherwise, I wouldn't have had the motivation to do it.
[cpg]

Of course, it's one thing to have a woman who has a girlfriend as my ......
[cpg]

But if it's not anyone else's, then it's worthwhile.
[cpg]

I thought about ...... that much, and I came up with another question I wanted to ask in addition.
[cpg]

[OnName num="toma"]
Have you ever had a girlfriend?"
[cpg cn=true]


[VOICE f="sMarie002"]
[OnName num="marie"]
......Never."
[cpg cn=true]


Good. That's enough confirmation.
[cpg]

I could have asked her if she had ever been in love with someone ......, but it would be rare for someone to answer no to that question.
[cpg]

[OnName num="toma"]
I'm glad to hear that. Thank you for answering honestly.
[cpg cn=true]


I would thank them like this, but of course I would erase the memory of being hypnotized.
[cpg]

Satisfied, I decided to let go of the hypnosis.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大学外観』（夕方）******************************************************



[OnName num="toma"]
You're going to forget what ever happened to ...... you see, forget.
[cpg cn=true]


[OnName num="toma"]
You'll forget what I asked you and you'll forget ...... what happened today.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_8"  pos="2/3" time=800]
[VOICE f="Marie034"]
[OnName num="marie"]
"...... hmmm, hmmm......."
[cpg cn=true]


The most important thing to remember is that you can't forget about it.
[cpg]


But they should be able to forget about it cleanly.
[cpg]


The most important thing to remember is that you can't just forget about it.
[cpg]


[OnName num="toma"]
"Now, let's wake up ...... on the count of three."
[cpg cn=true]



[SE f="se012"]
;//【ＳＥ】『指を鳴らす』



And after counting to three, he snapped his fingers.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Marie035"]
[OnName num="marie"]
"Phew ...... huh, that ......?　What was I doing?"
[cpg cn=true]


[OnName num="toma"]
'You don't remember?　No, you don't remember?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Marie036"]
[OnName num="marie"]
'Yeah ...... what was that, something you were doing.'
[cpg cn=true]


You don't remember. If you remember what you were doing, I'll be in trouble.
[cpg]


If I remember anything, I'll just hypnotize her again.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



We parted without further ado. But I realized that I had made a slight mistake.
[cpg]


I should have asked for her address at that time.
[cpg]


Otherwise, I would not have been able to push in.
[cpg]


On the other hand, if I had hypnosis, I could easily get it out of him.
[cpg]


It's so convenient, but I can't believe I let it go unnoticed.
[cpg]


I thought to myself, "I still haven't mastered my own powers yet.
[cpg]







[jump storage="ep001.ks" target="*start"]


