
*start


;//==============================
;//催眠術は近づくための手段として使う　を選んでいた場合
*root_12


[jump target="*jump3"]

;#################################################
*Ep003|The Power to Catch Seniors
;#################################################



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]


*jump3|The Power to Catch a Senior

[SCENE id=3]


Let's target Marie. I thought of breaking into her home.
[cpg]


She was my collaborator to begin with. Hypnosis has proven to be effective.
[cpg]


;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I prepared carefully. I wanted to make sure nothing could go wrong.
[cpg]

However, I didn't need any tools.
[cpg]

As long as I had my hypnosis, everything would work.
[cpg]

But even so, I was still trying to sort out my purpose and what I needed to do.
[cpg]

I would use hypnosis as a means to get closer. I use hypnosis only to break in.
[cpg]

Otherwise, I would not be able to see her true reaction.
[cpg]

I mean, would I need a tool to restrain her?　No. ......
[cpg]

Can we use hypnosis as a substitute for restraints, for example?
[cpg]

If I hypnotize her with something like "I can't get my strength up," I can stop her movement while her mind is still intact.
[cpg]

After making sure of that, I put my plan into action.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



I headed to Marie's house. I had already found out where she was staying.
[cpg]


I don't think about what I would do if I wasn't here.
[cpg]


Wherever she is, I'm going to target her.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



And then, I arrived at her house. I come to her room.
[cpg]


I ring the intercom. Then she came out of nowhere.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Marie247"]
[OnName num="marie"]
She said, "Yes, ......, Toma?　How do you know my house, ......?"
[cpg cn=true]


[OnName num="toma"]
I said, "How do you know my house? How do you know where I live, ?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Marie248"]
[OnName num="marie"]
Why are you talking to me like that?　I don't care. ......
[cpg cn=true]


[OnName num="toma"]
Turn around and look at me. Marije.
[cpg cn=true]


Mariie looked at me. I hypnotized her in that state.
[cpg]


[OnName num="toma"]
You will lose strength from all over your body. You won't be able to stand on your own.
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Marie249"]
[OnName num="marie"]
What are you saying ......, ah!
[cpg cn=true]


I'm going to support her as she's about to fall down.
[cpg]


The first thing to do is to make sure that you have a good understanding of what you're doing. The days of home confinement are about to begin.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************



The first thing you need to do is to make sure that you have a good idea of what you want to do.
[cpg]


The scent of Marie's fragrance is wafting through the air.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marie250"]
[OnName num="marie"]
'Hey, what are you ...... doing?　You're doing this to me ......."
[cpg cn=true]



I laid her down on the bed.
[cpg]


[OnName num="toma"]
You didn't have a boyfriend, did you?
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Marie251"]
[OnName num="marie"]
So how do you know ......?　I didn't know, but I figured it out.
[cpg cn=true]


[OnName num="toma"]
You know what I'm talking about. You guessed right.
[cpg cn=true]


I touched her cheek as I said this.
[cpg]



;//========================================
;//●ＣＧ（ベッドにぐったり眠っているヒロイン。ヒロインの頬に触れる主人公）ev_18
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：朝
;//========================================


[free time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]

She looked prettier than usual, with her strength still intact.
[cpg]

In some ways it was like I was rediscovering my power.
[cpg]

It was as if my long-cherished wish had just taken shape.
[cpg]

I stroked her cheek and she didn't even want to.
[cpg]

[VOICE f="sMarie027"]
[OnName num="marie"]
She was not even able to resist my stroking her cheek. What's really wrong with you?
[cpg cn=true]


If she could, she would only verbally disapprove.
[cpg]

[OnName num="toma"]
Her hair smells so good.
[cpg cn=true]

;**【ＣＧ】 ev_18_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMarie028"]
[OnName num="marie"]
No. ......
[cpg cn=true]


It's so cute that I want to do this all the time.
[cpg]

I'm so excited about what's to come. I couldn't stop laughing.
[cpg]


;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMarie029"]
[OnName num="marie"]
Please,...... Toma, reconsider.
[cpg cn=true]


[OnName num="toma"]
I'm not in a position to say anything to you.
[cpg cn=true]


The first thing to do is to make sure that you have a good time. I'm not sure what to say, but I'm not sure I'm in a position to say anything.
[cpg]

The most important thing to remember is that you can't be afraid of anything.
[cpg]

For me, it was more meaningful than hypnotizing her and forcing her to reveal her true nature.
[cpg]

[OnName num="toma"]
I'm looking forward to the future. You think so too, don't you?"
[cpg cn=true]


Marie didn't answer. That's fine.
[cpg]

I want to look at this face all the time,......, I thought.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************



I'm not sure how much I'm going to be able to do with this.
[cpg]


She won't be able to eat by herself.
[cpg]


So there would be no problem if I went out. There would be no problem even if I left her alone.
[cpg]


After all, she can't walk. She can't crawl.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marie270"]
[OnName num="marie"]
"Ha, ha ......, how long are you going to keep doing this ......?"
[cpg cn=true]


[OnName num="toma"]
Until I get bored.
[cpg cn=true]


But I suppose I could scream out loud. I'll be careful, just in case.
[cpg]


[OnName num="toma"]
Listen," he said. You won't be able to yell for help.
[cpg cn=true]


[OnName num="toma"]
You can yell, but you can't call for help.
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Marie271"]
[OnName num="marie"]
Oh, ah ......, ah, ah.
[cpg cn=true]


Hypnotized, eyes slack. The best way to do this is to get a good look at the site and see what it has to offer.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************



And after a while, Marije said to me: "Please  move your body.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marie272"]
[OnName num="marie"]
Please ...... let me move my body.
[cpg cn=true]


[OnName num="toma"]
What's the matter? I thought you gave up.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sMarie030"]
[OnName num="marie"]
I need to go to the bathroom.
[cpg cn=true]


[OnName num="toma"]
That's good. I'll take you.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Marie274"]
[OnName num="marie"]
No, thanks.　I'll go myself.
[cpg cn=true]


[OnName num="toma"]
How do you mean you'll go by yourself?
[cpg cn=true]


Marie was mumbling. Then, she begged again.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="sMarie031"]
[OnName num="marie"]
Please ...... forgive me already.
[cpg cn=true]


[OnName num="toma"]
I don't forgive you. I said I would take you there.
[cpg cn=true]


The first thing that comes to mind is the fact that the two of them are not even close to the same age. The most important thing to remember is that you can't afford to be lost.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************



The most important thing to remember is that you should never be afraid to ask for help. After waiting for a while, it seems that Marije has reached her limit.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Marie276"]
[OnName num="marie"]
"Please ...... take me to the bathroom. ......
[cpg cn=true]


[OnName num="toma"]
I'll carry you. I'll carry you."
[cpg cn=true]


 I lent my shoulder to Marie and carried it to the bathroom as it was.
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト


The most important thing to remember is that you can't just take a look at your own personal computer and not be able to see what's going on.
[cpg]

On the other hand, for me, just that fact alone seemed to fill my heart with contentment.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
Even with all this going on, Marie's heart was not yet broken.
[cpg]


[FACE method="change_3" pos="2/3"]
Somewhere the light in her eyes had not been taken away. It was as if she was still willing to resist me.
[cpg]


[OnName num="toma"]
The first thing to do is to make sure that you have a good time. I'm going to buy you some food.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Marie295"]
[OnName num="marie"]
"Go to ...... and do whatever you want. ......"
[cpg cn=true]


He replies as if he is still rebellious.
[cpg]


I don't have a problem with this not going away. Rather, it's worthwhile.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



I could have cooked him something, but I'm doing this at the wrong time.
[cpg]


I thought I'd at least make a convenience store bento to create a good atmosphere, so I did.
[cpg]


I thought it would be easier for me, too.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

[OnName num="toma"]
I thought, "Look, I bought some food. I bought it.
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『お腹が鳴る』



I heard a sound from her stomach as she collapsed onto the bed.
[cpg]



[OnName num="toma"]
I'm not going to eat. You must be hungry.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Marie297"]
[OnName num="marie"]
You can't eat. ...... I can't move.
[cpg cn=true]


[OnName num="toma"]
I'll feed you. I'll feed you. That won't be a problem.
[cpg cn=true]


Ballina seemed to be feeling humiliated, but apparently she couldn't overcome her hunger.
[cpg]


She was waiting for me to bring the rice to her mouth as she collapsed.
[cpg]


Ballie just chews. This will highlight the fact that she is deprived of power.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Marie298"]
[OnName num="marie"]
"This ...... is such a terrible ...... thing, I hate it already."
[cpg cn=true]


She can neither eat nor go to the bathroom by her own will.
[cpg]


The most important thing to remember is that you can't just go to the bathroom and eat. She was so adorable.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



Then night came. I approached her again, thinking I would do something to her.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sMarie032"]
[OnName num="marie"]
"......What are you doing ......?"
[cpg cn=true]


I loved her like a doll.
[cpg]

I'm not going to be able to get rid of the problem.
[cpg]

I want to do anything I want to her, but I'll save the ...... important things for later.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



And then I fall asleep. I decided to sleep snuggled up to Marie.
[cpg]


The bed was too small for the two of us, but I didn't mind.
[cpg]


After all, I had Mariie with me. I was lying down next to Mariie, who had lost her strength.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marie320"]
[OnName num="marie"]
I couldn't go on like this for much longer. ......
[cpg cn=true]


[OnName num="toma"]
Even if you can't continue, I will.
[cpg cn=true]


I'm going to keep going even if you can't keep going. With her like that, I went to sleep ......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************



I've been by her side day in and day out.
[cpg]


I took care of her toileting and eating. It was only natural, since she couldn't move.
[cpg]



As I continued to do this, she seemed to be losing a lot of her physical strength.
[cpg]


Was it her physical strength or her mental strength?　I'm losing my mind.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sMarie033"]
[OnName num="marie"]
"......Oh, no more. ......
[cpg cn=true]


It must be the result of having one's dignity as a human being shattered.
[cpg]


But even suicide is not something you can do on your own. That is the state of Marie's life.
[cpg]


[OnName num="toma"]
I'm going to go get some food, but is the bathroom okay?"
[cpg cn=true]


She didn't say anything. That means she must be okay.
[cpg]


So I went shopping.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



I was sure that my repeated trips to the convenience store would not raise any suspicion.
[cpg]


It would not be traced to the point that I was committing a crime. So, I acted with an open mind.
[cpg]


It might be suspicious if only men go in and out of the room where female students used to live. ......
[cpg]


But even so, I don't think it's something that should be reported.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************



[OnName num="toma"]
So, let's have dinner. Open your mouth.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Marie322"]
[OnName num="marie"]
...... ah."
[cpg cn=true]


At this moment, Ballina is no longer resisting. The most important thing to remember is that you should never be afraid to ask for help.
[cpg]


That said, she would still be in the mood to die.
[cpg]


 Starvation can be quite painful, even if you don't choose it yourself.
[cpg]


He must still be thinking of killing himself first.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Marie323"]
[OnName num="marie"]
The body is not moving,......, what should I do,......?
[cpg cn=true]


The most important thing to remember is that you can't just take a chance on a new person.
[cpg]


 It's nice to have them cry separately, but I can't control it.
[cpg]


The most important thing to remember is that you can't just go out and get a good job.
[cpg]




[FACE method="change_4" pos="2/3"]
[VOICE f="Marie324"]
[OnName num="marie"]
Oh ...... God, no."
[cpg cn=true]



;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト


;//移植のためシーンをカットしています

Marie continues to cry as she lies on her back on the bed. Tears are running down her face.
[cpg]


[OnName num="toma"]
'No matter how much you cry, I won't feel sorry for you.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Marie344"]
[OnName num="marie"]
"......I didn't mean it, I'm not crying. ......
[cpg cn=true]


[OnName num="toma"]
I'm not going to do anything about it. Then I won't do anything."
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************



The most important thing to remember is that you can't just go out and buy a new pair of jeans and a new pair of jeans and a new pair of jeans.
[cpg]

The most important thing to remember is that you can't just go out and buy a new pair of shoes.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sMarie034"]
[OnName num="marie"]
I'm so sad.
[cpg cn=true]


[OnName num="toma"]
I still want to have fun. I still want to have fun.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Marie346"]
[OnName num="marie"]
I'm not normal.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



The most important thing to remember is that you can't just go out and buy a new pair of shoes.
[cpg]


 I'll brush my teeth too. I might kiss you.
[cpg]


She looked rather tired all the time.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

But soon, I was getting bored with the fact that I couldn't move a muscle.
[cpg]

In addition, I was also concerned that she was getting weaker.
[cpg]

I thought, "I could hypnotize her for a little while. With that in mind, I turned my head toward her.
[cpg]


[OnName num="toma"]
Listen, you can temporarily be released from the hypnosis of being immobile," she said.
[cpg cn=true]


[OnName num="toma"]
However, you cannot escape from this room or call for help. ......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Marie347"]
[OnName num="marie"]
......, ugh."
[cpg cn=true]


For the first time in a long time, Marie moved her body. The first time in a long time, Marie moved her upper body.
[cpg]


[OnName num="toma"]
The most important thing to remember is that you can't just take a break from your work and go to work. The most important thing to remember is that you can't just go out and get a good meal.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Marie348"]
[OnName num="marie"]
"...... muscles are sore,...... and I can't get my strength right."
[cpg cn=true]


I see. I'm sure that's how it is. But it's better if it's hard to move.
[cpg]


[OnName num="toma"]
"Now that you can move, you feel a little better, don't you?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sMarie035"]
[OnName num="marie"]
"......"
[cpg cn=true]


[OnName num="toma"]
Smile. You should be thanking me.
[cpg cn=true]


I try to say something reckless, but Marije doesn't smile at all.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marie350"]
[OnName num="marie"]
'Toma-kun,......, no, it's nothing.
[cpg cn=true]


What was I going to say?　You looked like you gave up for a moment.
[cpg]


I wonder if he is planning something. That said, you shouldn't be able to go out and yell.
[cpg]


So there's nothing to fear.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ（四つん這いのヒロイン。ふらふらの状態）ev_22
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：夜
;//========================================



[BGM f="bg_h2"]
;**【ＣＧ】 ev_22_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sMarie036"]
[OnName num="marie"]
Oh ...... ah!"
[cpg cn=true]


 It was ridiculous to see her trying to get up and not being able to stand up.
[cpg]

[OnName num="toma"]
The most important thing to remember is that you can't get out of this situation without a lot of help. You can't run away now, can you?
[cpg cn=true]


[VOICE f="sMarie037"]
[OnName num="marie"]
"Haa, haa,......, haa."
[cpg cn=true]


The most important thing to remember is that you can't just take a chance on the market and expect to be able to get a good deal on a product.
[cpg]

Even though I couldn't get up and get out of the front door.
[cpg]

But she still tries to move on all fours, she is healthy and cute.
[cpg]

I thought that maybe I had always wanted to see her like this.
[cpg]

I thought, "Well, she's not showing me her strength, she's not forcing me to do anything, but she's not in a normal situation.
[cpg]

[OnName num="toma"]
Well, it's fun to watch her struggle.
[cpg cn=true]


I was about to cry when she heard what I said.
[cpg]


;**【ＣＧ】 ev_22_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMarie038"]
[OnName num="marie"]
Someone, anyone ...... help me."
[cpg cn=true]


She says so, but she seems to have difficulty even standing up.
[cpg]

 When I think of it like this, I feel indescribable emotions.
[cpg]

[OnName num="toma"]
It's no use running away," he said. You can't go outside.
[cpg cn=true]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Even though she finally got up, her steps were sluggish.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



She walked unsteadily toward the front door.
[cpg]


But as long as my hypnosis is still in effect, she will not be able to get out of here.
[cpg]


I don't doubt the power of my hypnosis now. I had been stuck there for a long time.
[cpg]


That's what I thought, so I didn't chase after her. I decided to let Marie do what she wanted.
[cpg]



[SE f="se013"]
;//【ＳＥ】『人が倒れる』



[OnName num="toma"]
"......?"
[cpg cn=true]


I heard a thud just now. What was it?
[cpg]


I thought so, and headed toward the passageway.
[cpg]



[OnName num="toma"]
"......!"
[cpg cn=true]


There was Marie, who was lying there in an unconscious state.
[cpg]

She was in a wobbly state, so she must have fallen. It was not impossible, it was bypassed.
[cpg]

[OnName num="toma"]
What a thing to ......!"
[cpg cn=true]


I was puzzled. Would I be able to handle the injury?
[cpg]

What if he never woke up?
[cpg]


Would I call an ambulance?　If I did that, I'd tell them everything.
[cpg]


[OnName num="toma"]
"Marie!　Look at me!
[cpg cn=true]


I was going to hypnotize her to forget everything, but she's already passed out.
[cpg]


I was out of luck. I can't hypnotize a sleeping girl.
[cpg]


I can't let her die. I can't even imagine what kind of crime I would be accused of.
[cpg]


I had no choice but to call an ambulance: ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se007" loop=true]
;//【ＳＥ】『救急車のサイレン』



This is a defeat, but it's not over yet.
[cpg]

With that in mind, I was interviewed by the police.
[cpg]

I was told to tell them everything, and I had no reason to refuse.
[cpg]

I was told to tell them everything, and there was no reason for me to refuse.
[cpg]


I didn't want to keep silent, so I told them.
[cpg]


However, I did not tell her about the hypnosis. ......
[cpg]


If I told the truth, I might be used in human experiments.
[cpg]

That's how much power I had gained that was beyond human knowledge.
[cpg]



[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



When Marie was taken to the hospital, everything became clear.
[cpg]


What was imposed on me was a prison sentence. I will be in prison soon.
[cpg]


But I thought it might not be such a hard time for me.
[cpg]


Even now, she must be locked up in fear.
[cpg]


It's not so different from me going to jail.
[cpg]


It seemed like a pleasant time to me.
[cpg]

Even if the hypnosis is broken, even if I am no longer around, she cannot escape from me.
[cpg]

In a sense, she is bound by something more powerful than hypnosis.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



Finally, I had to hear her case in court.
[cpg]


I heard that she had something she really wanted to tell me, not that she was testifying or anything like that.
[cpg]



[VOICE f="Marie370"]
[OnName num="marie"]
...... Toma-kun."
[cpg cn=true]


Her voice was trembling.
[cpg]



[VOICE f="Marie371"]
[OnName num="marie"]
'No more about anyone or ...... me. Swear to me that you will never do anything like this again."
[cpg cn=true]


[OnName num="toma"]
I know."
[cpg cn=true]


I couldn't afford to make my feelings any worse, so I answered.
[cpg]



[VOICE f="Marie372"]
[OnName num="marie"]
I know that's all I have to tell you."
[cpg cn=true]


Marie still sounded horrified. It was pointless to have this exchange.
[cpg]


I'm sure she knew that, but she still wanted to hear one word of my response.
[cpg]


...... Of course, I had no intention of following through.
[cpg]


The first thing to do is to make sure that you have a good idea of what you're getting yourself into.
[cpg]


I had time to plan. I looked forward to the day of my release.
[cpg]


[SCENE id=9]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン１ルート２



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


