
*start

;###################################################################
*Ep002|被管理的痛苦。
;###################################################################

[SCENE id=2]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





看來她姐姐已經在去工作的路上了，或者說是去學院。
[cpg]


她也是個大忙人，所以我不怪她。
[cpg]


我猜她自然要比學生們來的早。
[cpg]


當我想到這一點時，有些事情我是無法理解的。 ......。
[cpg]


與我不同的是，我覺得我仍然是一個工作的人。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************




[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa055"]
[OnName num="sawa"]
'好吧，那就去吧。不要停下來，再回來'。
[cpg cn=true]


我不需要你來告訴我，我不會停下來的，因為晚上我又要受罪了。
[cpg]


考慮到這一點，我回過頭來問候了我的母親。
[cpg]


[OnName num="gorou"]
我走了。 "
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari067"]
[OnName num="himari"]
你走吧！ "
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************


早晨的教室。我已經去上課了，越來越硬。
[cpg]


上課是你應該集中精力學習的時候。
[cpg]


但是當老師是個女人時，我就忍不住了。即使她不是那麼年輕。
[cpg]


而當老師是個男人時，我的注意力就會轉向我的同學們的女孩。
[cpg]


僅僅是想要悸動的感覺就使它變得如此艱難。
[cpg]


我已經很痛苦了，以至於我不得不在很早的時候就給我姐姐幫了一把。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（朝）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune059"]
[OnName num="suzune"]
'...... 等到午餐時間。你是個男孩，你必須有點耐心。 "
[cpg cn=true]


[OnName num="gorou"]
'我有麻煩了，因為我是個男孩......'
[cpg cn=true]


'確實如此，'我姐姐嘟囔道。不，這並不重要。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



從那以後，我設法堅持到了午餐時間，這次我壓住了她。
[cpg]


我不會再懷念它了。如果我錯過這個時機，我就真的會死。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune008"]
[OnName num="suzune"]
'那好吧，我們今天去某個空教室好嗎？
[cpg cn=true]


[OnName num="gorou"]
'什麼，不是...... 學生諮詢室？
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune061"]
[OnName num="suzune"]
'如果你用得太多，它就會很突出。
[cpg cn=true]


這是正確的，但如果你使用一個空教室，有人會找到你。 ......。
[cpg]



;//ブラックアウト


[VOICE f="sSuzune009"]
[OnName num="suzune"]
'好吧，我們該怎麼做？我的意思是，來吧。 "
[cpg cn=true]


我有很多顧慮，但我無法阻止自己。
[cpg]


;//========================================
;//●ＣＧ（ヒロインに背後から抱きつく主人公。衝動を必死にこらえる）ev_10
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]





[OnName num="gorou"]
'姐.......
[cpg cn=true]


她從後面抱住她的妹妹。我聞到她的好味道，感覺我的脈搏加快了。
[cpg]


回想起來，我從小到大即使想做也做不到。
[cpg]


但現在，我可以毫不猶豫地寵愛她。
[cpg]


從這個意義上說，我目前的體質在一定程度上幫助了我。 ......
[cpg]


[VOICE f="sSuzune010"]
[OnName num="suzune"]
'......，這太突然了。你嚇了我一跳。 "
[cpg cn=true]


我覺得她也有點臉紅。
[cpg]


也許她對我所做的事情有想法。
[cpg]


[OnName num="gorou"]
'對不起，我只是不能再忍受了。
[cpg cn=true]


;**【ＣＧ】 ev_10_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune011"]
[OnName num="suzune"]
'你現在是這樣一個...... 無助的小女孩。
[cpg cn=true]


她似乎既感到震驚又感到尷尬。
[cpg]


[VOICE f="sSuzune012"]
[OnName num="suzune"]
'嗯，她在那方面也很可愛。
[cpg cn=true]


我很漂亮，你說，我的心再次向你走去。
[cpg]


這也是一種來自我的體質的感覺，我想...... 悸動。
[cpg]


但不管怎樣，我也想有一個暗戀對象。
[cpg]


我想被我妹妹誤導。我想被迷惑，所有的時間。 ......
[cpg]


[VOICE f="sSuzune013"]
[OnName num="suzune"]
五郎的體溫，感覺是越來越高了。 "
[cpg cn=true]


[OnName num="gorou"]
'是的，我不認為如此。
[cpg cn=true]


如果有人告訴我並且我意識到了這一點，我很可能會格外害羞。
[cpg]


[VOICE f="sSuzune014"]
[OnName num="suzune"]
'是的，我是。我不認為這只是我的想像'。
[cpg cn=true]


但即使是這樣說的姐姐也覺得有點熱。
[cpg]


;**【ＣＧ】 ev_10_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune015"]
[OnName num="suzune"]
'我現在該走了嗎？你平靜下來了嗎？ "
[cpg cn=true]


我搖搖頭。這還不夠。
[cpg]


我感到一陣慾望，想把她抱得更緊，我努力壓制著它。
[cpg]


[VOICE f="sSuzune016"]
[OnName num="suzune"]
'真的，你不能幫助它，孩子。
[cpg cn=true]


這不是一個冷冰冰的說法，而是一個親切的話語，直奔主題。
[cpg]


我從母親那裡感受到了一種不同的母愛，或類似的東西。
[cpg]


[VOICE f="sSuzune017"]
[OnName num="suzune"]
'溺愛...... 好，讓我們再保持這樣的狀態。
[cpg cn=true]


她這樣說，並允許我做我所做的。
[cpg]


我覺得如果她對我這麼好，我就不能再忍下去了。 ......
[cpg]


但我還是忍住了，沒有再做什麼。
[cpg]


[OnName num="gorou"]
'謝謝你......'
[cpg cn=true]


[VOICE f="sSuzune018"]
[OnName num="suzune"]
'不客氣。看到我的兄弟陷入困境，我不能置身事外'。
[cpg cn=true]


說這話的姐姐是我的妹妹，似乎在隱瞞什麼。
[cpg]


我想知道她是否會對我有所想法，或者.......。
[cpg]


[OnName num="gorou"]
'你聞起來很香.......'
[cpg cn=true]


;**【ＣＧ】 ev_10_b ***********************
[CG id=4 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune019"]
[OnName num="suzune"]
'不要聞。而且不要說任何令人尷尬的話。
[cpg cn=true]


她沒有感到羞愧，而是以一種更像是嘲弄的方式說道。
[cpg]


但我想知道她是否也能聞到我。
[cpg]


我希望她在想些什麼。 ...... 很快，午休就會結束。
[cpg]



;//ブラックアウト

快樂的時光不可避免地很快過去。
[cpg]


你越想讓它永遠持續下去，它就越早結束，從物理上講。
[cpg]


而我越是希望它結束，越是痛苦的時間就要重新開始。
[cpg]


我想感到興奮。我可以說上一整天。 ......
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



事後。謠言傳播得很快，還是那個人在第一時間看到了？
[cpg]


[OnName num="male_student_A"]
'我看到了。你和小坂老師一起進了教室，儘管那是午餐時間。 "
[cpg cn=true]


[OnName num="male_student_B"]
'你在做什麼。你在做什麼？
[cpg cn=true]


啊哈，我想，但我回答。
[cpg]


[OnName num="gorou"]
'不，是......，你知道我和我的老師是同姓的嗎？
[cpg cn=true]


[OnName num="male_student_A"]
'哦，你是小坂五郎，對嗎？你有相同的漢字嗎？
[cpg cn=true]


[OnName num="gorou"]
'是的，它是。我和我的老師，我們是姐弟戀'。
[cpg cn=true]


[OnName num="male_student_B"]
'真的嗎？多麼令人羨慕啊！ ......！ "
[cpg cn=true]


[OnName num="gorou"]
這就是為什麼我一直在請教諸如家庭問題之類的事情。 "
[cpg cn=true]


我沒有說謊。我不能很好地說出真相。
[cpg]


[OnName num="male_student_A"]
'話說回來，去一個空的教室是很奇怪的。
[cpg cn=true]


[OnName num="gorou"]
'這是我不希望任何人聽到的建議。
[cpg cn=true]


我不知道，我不能幫助它。 ......，但這不僅僅是我的錯。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園教室』（夕方）******************************************************





然後是下午的課程。在我服用時，這一次我母親的臉開始在我腦海中閃現。
[cpg]


最後，我不能沒有你們三個人。我想起了這一點。
[cpg]


我被打上了印記，我不能再和他們作對了。 ......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





我在回家的路上已經搖搖晃晃了。我的同學們都很擔心我。
[cpg]


[OnName num="female_student_A"]
'你還好嗎？小坂君。 "
[cpg cn=true]


[OnName num="female_student_B"]
'嘿，嘿，你和小坂老師是姐弟戀是真的嗎？
[cpg cn=true]


考慮到謠言傳播得很快，我離開了，當時就回復了。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa056"]
[OnName num="sawa"]
'歡迎回來。你已經在痛苦中了嗎？我不知道。 "
[cpg cn=true]


[OnName num="gorou"]
'Ts，這很難。 ...... 幫助我，媽媽。
[cpg cn=true]


我說了我的想法，但媽媽笑著說
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa057"]
[OnName num="sawa"]
'漂亮的臉蛋。嘿，戈羅，你今天為什麼不試著多一點耐心呢？ "
[cpg cn=true]


他說。我不由自主地脫口而出。
[cpg]


[OnName num="gorou"]
'噓，我要死了......！ '
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





有人告訴我，我不應該太過頻繁地敲打。
[cpg]


但一天三次是目標，這意味著即使一天兩次也不會殺死你。
[cpg]


事實上，他們可能已經說了三次，以設定一個上限。
[cpg]


習慣搗鼓那麼多可能是個問題。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari068"]
[OnName num="himari"]
'兄弟，你似乎過得很辛苦。我希望你的身體迅速痊癒'。
[cpg cn=true]


我吃完飯，從椅子上不穩地站起來。
[cpg]

[free time=1000]

我什麼都做不了。或者說，我不能看有吸引力的女人，如緋紅、我的姐姐和我的母親。
[cpg]


最好是一個人睡。考慮到這一點，我走回了我的房間。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





我不知道我還得等多久。我母親該睡覺了，不是嗎？
[cpg]


當我這樣想時，我開始失去意識。
[cpg]


我可能真的又要得病了。在這一切的中間。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[WAIT time=1100]



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa058"]
[OnName num="sawa"]
'對不起，讓你久等了。到我的房間來。 "
[cpg cn=true]


[OnName num="gorou"]
'......，你確定......？
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa059"]
[OnName num="sawa"]
'你可以說得出口。我應該怎麼做？ "
[cpg cn=true]


[OnName num="gorou"]
呃--呃! 求你了，我已經束手無策了。 "
[cpg cn=true]


甚至我母親也這樣對我說。我已經沒有選擇了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//移植前シーンカット


那天晚上，我在母親撫摸著我的頭入睡。
[cpg]


我沒有逃跑或躲藏，我讓我的心怦怦直跳。
[cpg]


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa016"]
[OnName num="sawa"]
'你太可愛了。你看起來很解氣'。
[cpg cn=true]

我實際上是鬆了一口氣。我很激動，但也鬆了一口氣。
[cpg]


之後，我筋疲力盡，直接和我母親一起睡了。 ......
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





然後第二天，在媽媽醒來之前，我回到了我的房間。
[cpg]


沒過多久，搗蛋的管理層就開始了。這就是我注意到它的地方。
[cpg]


我想，經常給人捶打可能會使我更加依賴它。
[cpg]


另一方面，如果我不這樣做，我將很難呼吸。 ......
[cpg]


我在想該怎麼辦，但也在想，我不能再這樣下去了。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari012"]
[OnName num="himari"]
'Onii-chan。今天我們也和我漂亮的小妹妹親熱一下吧'。
[cpg cn=true]


緋紅說，類似這樣的話。你說自己很可愛。 ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari070"]
[OnName num="himari"]
'爸爸已經走了，所以...... 籲，你可以做任何你想做的事。
[cpg cn=true]


你說的"任何東西"是什麼意思？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Suzune079"]
[OnName num="suzune"]
'別鬧了。趁我不注意的時候做吧'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari071"]
[OnName num="himari"]
'Ew.'不要緊，你沒看到也沒關係，姐姐。
[cpg cn=true]



她姐姐的反應是合理的，但緋紅似乎也預見到了這一點。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





我尷尬地回到我的房間里呆了一會兒，但仔細一想這是個壞主意。
[cpg]


這意味著我不能在早上感到興奮。它可以持續到午餐時間。
[cpg]


我是否應該按照緋紅的要求在這裡做，即使我感到有點尷尬？
[cpg]


不，不，不，不，我畢竟不能在我母親和妹妹面前這樣做。 ......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我的衝突並沒有持續很久。
[cpg]


我知道我不能什麼都不做。我覺得我失去了一些東西給緋紅。 ......
[cpg]


我決定跟隨緋紅。除了她的母親，她的姐姐冷冷地看著我。
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari072"]
[OnName num="himari"]
'為什麼你不從一開始就按我說的做？你太固執了'。
[cpg cn=true]


我決定聽從緋紅的安排。除了她的母親，她的姐姐冷冷地看著我。
[cpg]



;//========================================
;//●ＣＧ（倒れ込んでいる主人公にキスをしようとするヒロイン。寸止めでキスはしない）ev_12
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の家＿リビング
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari013"]
[OnName num="himari"]
'嘿，讓我們接吻吧。這是你能做的最激動人心的事情'。
[cpg cn=true]


然後我們就出現了這種情況。緋紅比我們早了一步。
[cpg]


看來她不僅僅是......，看著我倒下和悸動而感到有趣。
[cpg]


[OnName num="gorou"]
'你說吻的時候是認真的嗎，......？
[cpg cn=true]


緋紅看起來好像不是在開玩笑。而且她也是那種說到做到的人。
[cpg]


;**【ＣＧ】 ev_12_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari014"]
[OnName num="himari"]
'我是認真的。你也想讓我這樣做，是嗎，大哥？
[cpg cn=true]


我認為這當然是最令人興奮的事情。然而。
[cpg]


[OnName num="gorou"]
'如果我這樣做，除了...... 接吻之外，我可能無法對其他事情感到興奮。
[cpg cn=true]


[VOICE f="sHimari015"]
[OnName num="himari"]
'......，你是什麼意思？
[cpg cn=true]


[OnName num="gorou"]
並不是說突然做這樣的事情不好，更像是習慣了就不好了。 "
[cpg cn=true]


;**【ＣＧ】 ev_12_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari016"]
[OnName num="himari"]
'嗯，這就是困擾我的地方。
[cpg cn=true]


緋紅說得好像這是別人的問題，但對我來說這是一個嚴重的問題。
[cpg]


[OnName num="gorou"]
'我確實關心! 如果我的心臟不能再跳動，我就會死。 "
[cpg cn=true]


[VOICE f="sHimari017"]
[OnName num="himari"]
'你需要放棄。我不會再讓你得逞了'。
[cpg cn=true]


緋紅似乎是認真的。如果她不打算讓他逃跑，那麼也許他就不能逃跑。
[cpg]


[OnName num="gorou"]
'等待，等待.......'
[cpg cn=true]


緋紅比我更有力量，而我比緋紅更有女人味。
[cpg]


;**【ＣＧ】 ev_12_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari018"]
[OnName num="himari"]
'我等不及了。來吧，把你的臉轉向這邊。 "
[cpg cn=true]


說著，緋紅將她的臉靠近。
[cpg]


她柔軟的嘴唇也同時靠近。他們幾乎碰在一起。
[cpg]


我可以聞到好聞的味道。緋紅就在身邊，閉著眼睛。
[cpg]


而當我快到時，我就下定決心。
[cpg]


我等待著，等待著，等待著她的嘴唇接觸.......
[cpg]


[OnName num="gorou"]
"...... 什麼？"
[cpg cn=true]


在我等待的過程中，我沒有感覺到有任何...... 嘴唇貼著我。
[cpg]


然後，她及時地把臉拉開。
[cpg]


;**【ＣＧ】 ev_12_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari019"]
[OnName num="himari"]
'呵。你感覺到撲通一聲嗎？
[cpg cn=true]


對，這就是我的意思。我被帶去兜風了。
[cpg]


[OnName num="gorou"]
嗯，嗯。
[cpg cn=true]


她天生就是這樣的人。不要把她說的話看得太重。 ......
[cpg]


[VOICE f="sHimari020"]
[OnName num="himari"]
那麼我想我們的目標已經實現了。 "
[cpg cn=true]


緋紅可能是一個令人驚訝的縱容者。
[cpg]


還是她只是在挑逗我？或者只是做他們想做的事？
[cpg]


我不是什麼都知道，但我剛才的重擊是相當不錯的，所以我不能抱怨: ......
[cpg]


;**【ＣＧ】 ev_12_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari021"]
[OnName num="himari"]
'那好吧，祝你今天好運。因為當我的兄弟受苦時，我也會受苦'。
[cpg cn=true]


[OnName num="gorou"]
'謝謝你......'
[cpg cn=true]


我不知道謝謝你是否是正確的回應，但沒有別的可說。
[cpg]



;//ブラックアウト

但是，我仍然想知道在我妹妹面前這樣做是否合適。
[cpg]


我不知道在我妹妹面前這樣做是否可以，但我真的很好奇。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************


而在與緋紅做了這樣的事情后，姐姐的冷言冷語也在等著我。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="sSuzune020"]
[OnName num="suzune"]
'這真的很不謙虛。我想知道她是否沒有尷尬的感覺'。
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari089"]
[OnName num="himari"]
'嘿嘿。我想我沒有'。
[cpg cn=true]


我有。所以我感到抱歉和尷尬，我覺得我不能說什麼。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune082"]
[OnName num="suzune"]
'哦，好吧。我現在要走了。 "
[cpg cn=true]


[OnName num="gorou"]
'是的，繼續，繼續。 ......'
[cpg cn=true]



我妹妹總是早早離開。我們在這之後。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************





過了一會兒，我和緋紅不得不離開房子。
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa079"]
[OnName num="sawa"]
'再見。回頭見。 "
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari090"]
[OnName num="himari"]
我走了。 "
[cpg cn=true]


緋紅歡快地回答道。我沒有這個心情。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep003.ks" target="*start"]



;/////////////////////////////////////////////////////////////////////
