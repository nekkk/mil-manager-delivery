

*start

;###################################################################
*Ep001|開始搗鼓管理。
;###################################################################

;//ブラックアウト
[SCENE id=1]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]

[SE f="se002"]
;//【ＳＥ】『喧噪』

[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************





[OnName num="female_student_A"]
'你的情緒有些變化，小坂君，......。
[cpg cn=true]


[OnName num="female_student_B"]
是的。他只是一個食草動物，但他也是...... 憂鬱的。 "
[cpg cn=true]


我聽到了，我聽到了。我聽著竊竊私語，想著。
[cpg]


他沒有說我的壞話，這感覺很好。但是。
[cpg]


如果他們是因為我的憲法而這麼說，我不知道該怎麼說。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************




而到了午餐時間，已經很辛苦了。我的腦袋裡滿是想要搗亂的想法。
[cpg]



我無法理解上午的最後部分。
[cpg]


我很難呼吸，我不能再想別的事情了。
[cpg]


這讓我很抓狂，撲面而來的依賴性真的讓我很難受。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************





[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune038"]
[OnName num="suzune"]
'......，是時候了，這很痛苦。我知道它的大部分內容。 "
[cpg cn=true]


[OnName num="gorou"]
'哦，拜託。我不能再這樣做了，我不能。 ......"
[cpg cn=true]


女性化的話語從我口中說出。但我不能幫助它。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune039"]
[OnName num="suzune"]
'好吧。來吧。 "
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植前シーンカット

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_03_2_up.ui" time=1000]
[WAIT time=1000]

我跟著他來到學生指導辦公室。
[cpg]


我進去了，想知道這次他們會對我做什麼。
[cpg]


...... 結果，這和前幾天發生的事情如出一轍。
[cpg]


我可以看到我的姐姐是多麼關心我，試圖不過度刺激我。
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



搗毀管理。每天三次，使心率上升：......
[cpg]


這是一個相當怪異的情況，但這就是我所處的那種情況。
[cpg]


一天三次已經很困難了。我希望它是這個數字的兩倍。
[cpg]


但我們不能無休止地觸摸對方，這可能會越界。
[cpg]


是否有這樣的治療方法？有一些人具有難以置信的吸引力，他們接近我。
[cpg]


我不能做我想做的事。我被管理得無以復加。
[cpg]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（夕方）******************************************************





[OnName num="male_student_A"]
'我聽說了。他和小坂老師一起走進了學生諮詢辦公室。
[cpg cn=true]


[OnName num="male_student_B"]
'發生了什麼事。那你做了什麼？ "
[cpg cn=true]


我認為被這樣質疑是很自然的。
[cpg]


但我無法回答任何問題。
[cpg]


[OnName num="gorou"]
'這是職業建議。 ......，這沒什麼可擔心的。
[cpg cn=true]


[OnName num="male_student_A"]
'有傳言說你從裡面出來的時候躺在......，很慌張。
[cpg cn=true]


這就是他們得到信息的程度。我下次離開時要小心了。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夕方）******************************************************





啊，我離開的時候會小心的。我迫不及待地想回家。
[cpg]


現在輪到我媽媽了。今天我已經可以承受了，如果我可以說我可以承受的話。 ......
[cpg]


不過，這還是讓人相當苦惱的事。
[cpg]


我甚至不能和同學們交談，更不用說認真上課了。
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』


[OnName num="gorou"]
'塔，我回來了。 ......'
[cpg cn=true]




[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa003"]
[OnName num="sawa"]
'歡迎回來。你現在很難受嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'什麼，......？不，嗯，是......"
[cpg cn=true]


我沒有立即回答，壓抑著自己的感覺，我真的希望現在就能做點什麼。
[cpg]


不知為何，我不想說我理解。另一方面，讓我的母親告訴我也不好。 ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa004"]
[OnName num="sawa"]
'你不必如此。你看起來很蒼白'。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSawa005"]
[OnName num="sawa"]
'我們今天該做什麼？你想和我一起洗個澡嗎？ "
[cpg cn=true]


他們看穿了這一切，感到很難堪。
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_04_3_up.ui" time=1000]
[WAIT time=1000]


話雖如此，我還是不能以尷尬為由拒絕。
[cpg]

[VOICE f="sSawa006"]
[OnName num="sawa"]
'是的，一件游泳衣。有了這個，你就不會感到尷尬了'。
[cpg cn=true]

[OnName num="gorou"]
'但是，但是......，我可以嗎？
[cpg cn=true]


[VOICE f="sSawa007"]
[OnName num="sawa"]
'好的。我不想再看到你痛苦的臉。
[cpg cn=true]


我按母親的要求做了，然後去洗澡。
[cpg]


......，希望沒有人發現。
[cpg]


;//========================================
;//●ＣＧエロ（石けんで洗いながら手コキ。ヒロインは背後から片手で主人公の乳首も弄りながらしごく）ev_08
;//人物１：ヒロイン３
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：主人公の家＿風呂
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


這有點像我不能說我沒有問題......，因為我穿著游泳衣。
[cpg]


我不知道要花多少錢，但我不知道和家人這樣做是否可以，即使他們沒有血緣關係。
[cpg]


[VOICE f="sSawa008"]
[OnName num="sawa"]
'當你在洗澡的時候，我也要給你洗身體嗎？
[cpg cn=true]


媽媽表現得好像無動於衷。
[cpg]


[OnName num="gorou"]
'是的，很好。我自己會做的'。
[cpg cn=true]



而我呢，我的聲音都快變了。
[cpg]


;**【ＣＧ】 ev_08_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sawa038"]
[OnName num="sawa"]
'你這麼說，但你真的想把我寵壞，不是嗎？
[cpg cn=true]


我有一種想要被呵護的慾望。但我不能大聲說出來。
[cpg]


我感覺我的母親也知道這一點，並且正在接近我。
[cpg]


[OnName num="gorou"]
這真的很好。 ......
[cpg cn=true]


[VOICE f="sSawa009"]
[OnName num="sawa"]
'別憋著了。我有一個不激動的藉口'。
[cpg cn=true]



[OnName num="gorou"]
'當你稱它為藉口時，就更尷尬了。
[cpg cn=true]


媽媽笑了，用肥皂和海綿給他們擦洗。
[cpg]


;**【ＣＧ】 ev_08_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa010"]
[OnName num="sawa"]
'那好吧，讓我給你洗吧。
[cpg cn=true]

海綿觸動了我。這已經足夠讓我的心跳加速了。 ......
[cpg]


[VOICE f="sSawa011"]
[OnName num="sawa"]
我可以感覺到你的脈搏在加快。籲。
[cpg cn=true]


她的手指在泡沫上滑行。這種癢癢的感覺是騙人的。 ......
[cpg]


漸漸地，呼吸變得不那麼困難了。這本身就是一件令人欣慰的事情。
[cpg]


再加上我與這樣一個美麗的人親密接觸的事實。
[cpg]


那是一段可以說是幸福的時光。這部憲法可能並不全是壞事。
[cpg]


[VOICE f="sSawa012"]
[OnName num="sawa"]
我不知道我是否已經洗了大部分的東西。你還有什麼要我洗的嗎？ "
[cpg cn=true]


你還有什麼意思......，你還打算做什麼？
[cpg]



[OnName num="gorou"]
'你想讓我說什麼？
[cpg cn=true]


我想說這是一種阻力，但媽媽卻拂袖而去。
[cpg]


;**【ＣＧ】 ev_08_b ***********************
[CG id=3 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa013"]
[OnName num="sawa"]
'這是什麼？我想不出來了。 "
[cpg cn=true]


媽媽可能有點刻薄，不是嗎？
[cpg]



[OnName num="gorou"]
'...... 如果你想不出來，就不要說了。
[cpg cn=true]

[VOICE f="sSawa014"]
[OnName num="sawa"]
'嗯。好吧，那我就把你衝下去。
[cpg cn=true]


感受到了溫暖的水。它不僅使你的脈搏加快，而且我認為它也提高了你的體溫。
[cpg]


也許我媽媽也是這樣，......？
[cpg]


[VOICE f="sSawa015"]
[OnName num="sawa"]
'什麼？那張臉。你想讓我多洗洗嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'呃，不。這沒什麼。 "
[cpg cn=true]


熱水會沖走泡沫。的確，這感覺有點像一種提醒。
[cpg]


我已經受夠了敲打......，這不是你可以和你的家人一起做的事情了。
[cpg]






[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


等到跳動減弱時，我意識到我的呼吸不在了。
[cpg]


這提醒了我，如果我不真的搗鼓，就會有生命危險。 ......
[cpg]

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





做完這一切後，我們圍坐在餐桌旁，看起來好像不知道發生了什麼事。
[cpg]


我真的覺得我不應該這樣做。
[cpg]



[SE f="se011"]
;//【ＳＥ】『食器の音』




[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune058"]
[OnName num="suzune"]
'...... 吾郎。你沒有胃口嗎？
[cpg cn=true]


[OnName num="gorou"]
不，思考......。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari039"]
[OnName num="himari"]
'在思考，嗯？我最近也在做大量的思考'。
[cpg cn=true]


主要是在想如何搞亂我。這就是我所想的。
[cpg]


[OnName num="father"]
'怎麼了？你說的是憲法。 "
[cpg cn=true]


嗯，大概就是這樣。爸爸是唯一被排除在這群人之外的人。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





然後我回到我的房間。每當我想起今天發生的事情，我就感到很尷尬。
[cpg]


我不知道該怎麼做。我只需要修復我的體質，不是嗎？
[cpg]


但如果我不知道如何解決它，我就不能做任何事情。 ......
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


[SE f="se004"]
;//【ＳＥ】『衣擦れ』

當我帶著這些想法入睡時，我被一種奇怪的感覺驚醒了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari040"]
[OnName num="himari"]
'早上好，兄弟。
[cpg cn=true]


[OnName num="gorou"]
'...... 不，不是早安。
[cpg cn=true]


緋紅正撫摸著我的頭。這也與我的憲法有關嗎？
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari006"]
[OnName num="himari"]
'大哥的頭太值得撫摸了，不是嗎？
[cpg cn=true]


...... 顯然不是。他只是想挑逗我。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari007"]
[OnName num="himari"]
'進展如何？你很激動嗎？ "
[cpg cn=true]


[OnName num="gorou"]
......，一般般。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari008"]
[OnName num="himari"]
我當時想，"好，好，好。你得說出來。"
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
緋紅這樣說，並把她的臉靠近他。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari009"]
[OnName num="himari"]
'看。我可能會像這樣吻你'。
[cpg cn=true]


[OnName num="gorou"]
'哦，我很抱歉。 ......'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari010"]
[OnName num="himari"]
如果你知道我的意思的話。
[cpg cn=true]


;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************




[OnName num="gorou"]
......緋紅，你很卑鄙。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari011"]
[OnName num="himari"]
'你在說什麼。我沒有這麼好的妹妹，你有嗎？
[cpg cn=true]


...... 當然，如果你問我，那是真的。她一直是個皮實的姐姐，但現在她似乎真的很享受這種感覺。
[cpg]


我想。
[cpg]



;//■選択肢
[switch]
[case "她對我如此投入，我很高興。"]
	[swap]
	[jump target="*select01_1"]
[case "我迫不及待地要修復這部憲法。"]
	[swap]
	[jump target="*select01_2"]
[endswitch]

第一，我很高興你對我如此忠誠。
2、我想盡快修復這個憲法。



;//==============================
;//１、こんなに尽くしてくれて幸せだ
*select01_1|搗毀管理的開始




我很高興緋紅對我如此忠誠。
[cpg]


我相信一定有類似於愛的反面的東西。
[cpg]


當我想到這一點時，緋紅似乎也是一個可愛的人。
[cpg]

[stflag Cha2flg = 1]

;//ヒロイン２が候補に

[jump target="*select01_3"]

;//==============================
;//２、早くこの体質を治したい

*select01_2|搗毀管理的開始



我知道我不想這樣做太久。
[cpg]

如果可能的話，我想現在就解決我的體質問題，重新過上無憂無慮的生活。 ......
[cpg]


但我相信這將是更遠的事情。
[cpg]



;//==============================

*select01_3|搗毀管理的開始

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep002.ks" target="*start"]



;/////////////////////////////////////////////////////////////////////
