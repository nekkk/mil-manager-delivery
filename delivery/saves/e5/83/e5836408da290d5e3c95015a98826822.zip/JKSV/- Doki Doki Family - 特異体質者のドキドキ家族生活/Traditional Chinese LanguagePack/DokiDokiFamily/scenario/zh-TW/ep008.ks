
*start


;###################################################################
*Ep008|快樂優柔寡斷
;###################################################################

;//４、選ぶことができない

*select04_4|快樂優柔寡斷

[SCENE id=8]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


...... 號。我還是無法選擇。
[cpg]


即使有人告訴你需要戀愛，也不是那麼容易做出決定的。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="gorou"]
'對不起，我還是......無法選擇。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[VOICE f="Suzune337"]
[OnName num="suzune"]
五郎......"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari331"]
[OnName num="himari"]
'大哥......'
[cpg cn=true]


我很迷茫，無法選擇任何人。
[cpg]


然後我告訴他們，我不能選擇反對他們三個人。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa273"]
[OnName num="sawa"]
'我知道五郎的想法。那麼你就不必選擇了'。
[cpg cn=true]


[OnName num="gorou"]
嗯？ "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari095"]
[OnName num="himari"]
'換句話說，我還是要和我們三個人一起搗鼓你，兄弟，就像我們一直以來一樣。
[cpg cn=true]


不，但這不是...
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/3" time=800]
[VOICE f="Suzune338"]
[OnName num="suzune"]
'沒關係的。這是我們已經討論過並決定的事情'。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="3/3" time=800]
[VOICE f="sSawa061"]
[OnName num="sawa"]
'如果他們說墜入愛河可以治愈你的體質，那麼人越多越好。
[cpg cn=true]


嗯，這當然是......？它是否能使治癒的機會增加三倍？
[cpg]


[OnName num="gorou"]
'......'
[cpg cn=true]


即使是這樣，我是否可以這樣利用一個對我這麼好的家庭成員？
[cpg]


但我仍然擔心......，我的呼吸會出現問題。
[cpg]


[OnName num="gorou"]
'......，謝謝你，請。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="Suzune339"]
[OnName num="suzune"]
為了五郎的緣故，我會......盡我所能。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari333"]
[OnName num="himari"]
我讓你去吧。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa275"]
[OnName num="sawa"]
'你會把你的母親寵壞的。
[cpg cn=true]


雖然不解，但她還是決定服從，認為如果他們三個人這麼說，那就這麼辦吧。
[cpg]





;//ブラックアウト

[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]


這事發生幾天后。
[cpg]


他們三個人仍然像往常一樣對我來者不拒。當然，他們還沒有吻過我。 ......
[cpg]


但這一天終於到來，他越過了治愈這種疾病的界限。
[cpg]


[window target=false]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





我醒來的時候，我妹妹已經和我一起爬到了床上。
[cpg]


[OnName num="gorou"]
'嗯...'
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari334"]
[OnName num="himari"]
'哦，我起來了。早上好，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'是的......早上好。你為什麼這麼近？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari096"]
[OnName num="himari"]
為什麼，當然是為了吻我。
[cpg cn=true]


[OnName num="gorou"]
轉到.......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari336"]
[OnName num="himari"]
'否則你將永遠無法恢復。你確定你想保持這種方式嗎？ "
[cpg cn=true]


[OnName num="gorou"]
我不......，認為這是個好主意。
[cpg cn=true]


以這種方式被大家激動，是一種福利，也可能是一種美味的環境。
[cpg]


但這種使生活受到更多限制的體質，仍然必須得到治愈。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari097"]
[OnName num="himari"]
'那好吧，讓我們接吻吧。如果是和我哥哥......好吧。 "
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


然後她把她的嘴唇送到他的面前。
[cpg]


我甚至還沒有刷牙，......，想著我現在不應該想的事情。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_h1"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


緋紅拉開她的嘴唇，看起來很高興。當她做出這樣的表情時，敲擊聲就會越來越強。
[cpg]



[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari098"]
[OnName num="himari"]
'這對你來說還不夠，是嗎？我還是會讓你悸動的。 "
[cpg cn=true]


[OnName num="gorou"]
'什麼，你還打算這麼做？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari099"]
[OnName num="himari"]
'我不在乎你做了多少次。我必須通過做愛來治療我的體質'。
[cpg cn=true]


[OnName num="gorou"]
'但是，這是否可以......'
[cpg cn=true]




[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari100"]
[OnName num="himari"]
'好。你關心什麼呢？
[cpg cn=true]


[OnName num="gorou"]
因為我不認為你在單挑我們。 "
[cpg cn=true]


我想當時有一個規則，就是每個人都是平等的。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari363"]
[OnName num="himari"]
'現在是我負責的時間，所以很好。也許你們兩個也會這樣做......'
[cpg cn=true]


她是一個非常有活力的妹妹。我想我妹妹會有所保留，更不用說我母親了。
[cpg]


即使有這樣的想法，我們最終還是在一起度過了整個時間......。
[cpg]



[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[window target=true]


然後就到了交接的時候。
[cpg]


嚴格說來不是從這裡出發，但......，我姐姐來拉我。
[cpg]

[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune077"]
[OnName num="suzune"]
'...... a bit.你要和我堅持多久，緋紅？ "
[cpg cn=true]


姐姐似乎有點生氣，因為希卡里在午餐後留下來陪她。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari101"]
[OnName num="himari"]
'哦...姐姐'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune341"]
[OnName num="suzune"]
'是時候走了。來吧，走吧。 "
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari365"]
[OnName num="himari"]
嘖嘖。 "
[cpg cn=true]

[free time=1000]

緋紅不情願地離開了房間。這不像是緋紅馬上就听我的話，但我猜她覺得我獨占她這麼久很不好。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune342"]
[OnName num="suzune"]
你......你沒事吧？一點也不，緋紅。
[cpg cn=true]


[OnName num="gorou"]
'嗯，是的......有點過於緊張和疲憊，但是......'
[cpg cn=true]


我的妹妹似乎對我說的話有點不以為然。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune343"]
[OnName num="suzune"]
'...... 你想做什麼？我不知道如果我不這樣做是否更好......'
[cpg cn=true]


[OnName num="gorou"]
'不，我很好。我不能讓你和其他人單獨在一起'。
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune344"]
[OnName num="suzune"]
'謝謝你，戈羅。我很高興。但是......不要做一個假正經的人。 "
[cpg cn=true]


[OnName num="gorou"]
我們會好好照顧它。 "
[cpg cn=true]


這次是和你妹妹一起。不無節制可能是很難做到的。
[cpg]


我們不得不轉移到另一個地方，前往我姐姐的房間。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

;//移植前シーンカット

她沒有吻我，但我覺得她很清楚該怎麼做才能讓我緊張。
[cpg]


她能看出我很喜歡她，即使我們沒有緊緊抓住對方。
[cpg]



;//ブラックアウト

[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



而更多的時間過去了，然後......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa276"]
[OnName num="sawa"]
'五郎。現在輪到你母親了！ "
[cpg cn=true]


[OnName num="gorou"]
'嗯...讓我休息一下...'
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa277"]
[OnName num="sawa"]
'嗯，嗯。 Dahme♪''
[cpg cn=true]


[OnName num="gorou"]
"...... 是。"
[cpg cn=true]


我們又搬了房間，這次是和我母親一起。
[cpg]


我認為我的房間對她來說不夠好，但她不願意。
[cpg]


也許有一些本能的東西.......，不，如果不是這樣就太不禮貌了。
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_04_2_up.ui" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[WAIT time=2000]

;//移植前シーンカット

我媽媽可能是我們三個人中最不寬容的。
[cpg]


你可以說她最擔心的是我。如果我不扑騰，我就很難呼吸了。
[cpg]


上午是緋紅，下午是我妹妹，晚上是我母親。他們每個人都有自己的搗蛋時間。
[cpg]


這是那種可以被描述為男人最好的一天。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



當我繼續這樣的粗暴對待時，我的體質就穩定下來了。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="sHimari102"]
[OnName num="himari"]
'這很奇怪!當你墜入愛河時，你真的被治癒了。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSuzune078"]
[OnName num="suzune"]
'......，就我而言，我想知道你愛上的是誰。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]

[VOICE f="sSawa062"]
[OnName num="sawa"]
'他們是誰並不重要。這是每個人的吾郎'。
[cpg cn=true]


我母親說了一句話，有點棘手。不，當你說出來的時候，你也說出來了，姐姐。
[cpg]


我自己也不知道我們三個人都愛上了誰。
[cpg]


但現在真的沒有回頭路了。
[cpg]


我的體質已經穩定下來了，這意味著證明我愛上了他們三個中的一個。
[cpg]



;//ブラックアウト

;//移植前シーンカット

我希望我有足夠的資格在這裡說我愛誰。
[cpg]


不幸的是，我是那個在關鍵時刻無法選人的人。
[cpg]


我相信在......，每個人都覺得這很令人沮喪。但我同樣喜歡他們。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************

;//ブラックアウト

[OnName num="father"]
'不知為什麼，你們這些天相處得非常好。
[cpg cn=true]


而我父親，正如預期的那樣，說了一些話，讓我意識到他已經註意到了。
[cpg]


也許我更早地註意到它。只是他現在說出來了。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="sSuzune079"]
[OnName num="suzune"]
'什麼？不，不，這不是......"
[cpg cn=true]


我妹妹對我爸爸的行為很可疑。儘管他們是家人。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari103"]
[OnName num="himari"]
'這就對了!我們一直都很親密，不是嗎？
[cpg cn=true]


[OnName num="father"]
你有嗎？ "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSawa063"]
[OnName num="sawa"]
'是的，沒錯。他正處於想要被寵愛的年齡，我打賭。
[cpg cn=true]


[OnName num="father"]
'......，我明白了。
[cpg cn=true]


爸爸看起來有點複雜。
[cpg]


當然，我不會在他面前無謂地調情。姐姐。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari104"]
[OnName num="himari"]
'爸爸，你不能吃醋。你只屬於我，大哥哥。
[cpg cn=true]


然而，緋紅並不害怕在爸爸面前堅持下去。
[cpg]


看到我妹妹痛苦的臉，我也很難受。 ......
[cpg]

;//移植前シーンカット


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『街』（昼）******************************************************


最後，我們三個人，每個人都保持同樣的距離。
[cpg]


或者，也許我只是沒有註意到，因為我離他們所有人都那麼近。
[cpg]


週末來了又走，不知道這種關係是否好。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]


[VOICE f="sHimari105"]
[OnName num="himari"]
'我們四個人已經很久沒有一起出去了。
[cpg cn=true]


我們出來的時候，只有爸爸有差事要做。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="sSawa064"]
[OnName num="sawa"]
'是的，我想是的。我想特別是鈴音可能會有點害羞'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune080"]
[OnName num="suzune"]
'......，現在沒有什麼可害羞的了。
[cpg cn=true]


這當然是真的。如果我要害羞，那就應該在更早的時候。 ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="sHimari106"]
[OnName num="himari"]
'那麼，我們應該去哪裡？你有一個約會計劃嗎，媽媽？ "
[cpg cn=true]


向母親要一個約會計劃，聽起來......，但這並沒有錯。
[cpg]


;//背景と違う場所です。上下に黒帯を入れるなどの演出を入れてください

[FACE method="feadin" pos="4/7"]
[BG f="b_01_2_up.ui" time=1000]
[WAIT time=1000]


我們要去商場。我記得小時候經常去那裡。
[cpg]


當然，我現在已經不好意思和他們出去了。
[cpg]


在這種情況下再次外出，對我來說是一種非常感性的體驗。
[cpg]


就像他們三個人認出了我的奇怪體質。 ......
[cpg]


更重要的是，我覺得他們接受了我的感受。
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="sSawa065"]
[OnName num="sawa"]
'你已經改變了很多。所有的服裝店'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSuzune081"]
[OnName num="suzune"]
'嗯，......，也許這就是它的方式。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]

[VOICE f="sHimari107"]
[OnName num="himari"]
'你真的想買那麼多衣服嗎？不過我更想吃一頓好的。 "
[cpg cn=true]


[OnName num="gorou"]
對了，我想我們是時候吃晚飯了。 "
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]

[VOICE f="sSuzune082"]
[OnName num="suzune"]
我很驚訝你能負責。
[cpg cn=true]


[OnName num="gorou"]
不，不，我不認為我是負責人。
[cpg cn=true]


我們進行了多麼精彩的對話，享受我們在一起的時光。
[cpg]


這樣一來，我們仍然覺得自己是家人而不是戀人。
[cpg]


這就像我們仍然是一個家庭，但我們變得更親密了。 ......
[cpg]


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="sHimari108"]
[OnName num="himari"]
這很有趣。我哥哥給我買了衣服。 "
[cpg cn=true]


[OnName num="gorou"]
'你告訴我你想做的就是買衣服。 ......
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari109"]
[OnName num="himari"]
'沒事的，沒事的。不要把我說的話看得那麼嚴重'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSuzune083"]
[OnName num="suzune"]
'它必須是......
[cpg cn=true]


我母親看著我們的談話，微笑著。
[cpg]


回想起來，也許這就是我一直想要的東西。
[cpg]


我在一次事故中失去了父母后，我希望得到家庭的溫暖。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="sSawa066"]
[OnName num="sawa"]
你玩得開心嗎，戈羅？
[cpg cn=true]


[OnName num="gorou"]
是的。當然，這是一個很大的樂趣。 "
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]


...... 我最喜歡這種時間。我相信這比我和我女朋友在一起的時間要多。 ......
[cpg]


我不想為了和任何一個人在一起而拆散家庭關係。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


隨著我們家庭關係的增長，我感到很遺憾，這個人是一隻蚊子。
[cpg]


[OnName num="father"]
'...... 什麼？你想和我談談。 "
[cpg cn=true]


[OnName num="gorou"]
'不。只是我們今天又出去了'。
[cpg cn=true]


[OnName num="father"]
'別擔心。我知道你們兩個相處得很好。 "
[cpg cn=true]


可憐的是，我想，但......，還有一件事我在想。
[cpg]


[OnName num="gorou"]
'謝謝你.......因為接受我進入這個家。 "
[cpg cn=true]


[OnName num="father"]
'什麼？出乎意料。 "
[cpg cn=true]


[OnName num="gorou"]
'不，不。我只是覺得我沒有說太多。 "
[cpg cn=true]


[OnName num="father"]
'這正是你需要擔心的事情。我不能丟下你一個人。
[cpg cn=true]


爸爸看起來很尷尬。
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSawa067"]
[OnName num="sawa"]
怎麼了？你們兩個似乎談了很多。 "
[cpg cn=true]


[OnName num="gorou"]
'是的。我只是很高興能在這個房子裡。 "
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sSawa068"]
[OnName num="sawa"]
'嗯。不尋常。 "
[cpg cn=true]


不尋常的。我確實沒有對你說過這些話。
[cpg]


[OnName num="gorou"]
我為我的不孝感到抱歉。
[cpg cn=true]


[OnName num="father"]
'別擔心。你還沒有大到可以擔心這種事情的地步'。
[cpg cn=true]


爸爸重複著'不要擔心'這句話。我對此表示感謝。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]


我欠我父親一個人情。我的姐姐、緋紅，甚至我的母親都讓我感到緊張。
[cpg]


我知道他沒有告訴我也不要擔心這個問題，......，但這仍然讓我感覺好些。
[cpg]


[window target=false]


[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

吃完晚飯後，在我的房間裡休息，緋紅過來了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari110"]
[OnName num="himari"]
'嘿，你確定你不打算選人嗎？
[cpg cn=true]


[OnName num="gorou"]
是的，從那時起我就一直在思考這個問題。 ......"
[cpg cn=true]


[OnName num="gorou"]
'不是說我同樣喜歡他們，更多的是我不能只選其中一個的原因。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sHimari111"]
[OnName num="himari"]
你是什麼意思？ "
[cpg cn=true]


[OnName num="gorou"]
我......，喜歡這個房子。
[cpg cn=true]


[OnName num="gorou"]
'我現在不想毀掉這段關係。在今天發生的事情之後，我深深感受到了這一點'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari112"]
[OnName num="himari"]
'...... 這對你姐姐來說可能是一件很難說出口的事情，不是嗎？從我們的角度來看，你是孤獨的。 "
[cpg cn=true]


[OnName num="gorou"]
'...... 抱歉。
[cpg cn=true]


緋紅似乎有點生氣，但也很寬容。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari113"]
[OnName num="himari"]
'好吧，這不是我哥哥第一次優柔寡斷了，所以我已經放棄了。
[cpg cn=true]


[OnName num="gorou"]
我非常抱歉。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari114"]
[OnName num="himari"]
'你不需要道歉。你已經下定決心。你那優柔寡斷的弟弟'。
[cpg cn=true]


我有點抱歉，不能說什麼。
[cpg]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]
;//【ＢＧ】『街』（朝）******************************************************

我的體質越來越平和了。我並不是愛上了任何一個人。
[cpg]


一切都在向好的方向發展，儘管就這段關係而言，沒有任何改變。
[cpg]


...... 就在這時，事情發生了。
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『学園教室』（昼）******************************************************

[OnName num="gorou"]
'姐姐，怎麼了？
[cpg cn=true]


我在一個空蕩蕩的教室裡，我姐姐叫我進去。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune084"]
[OnName num="suzune"]
'...... 抱歉。我不是有意這麼突然叫你出來的。
[cpg cn=true]


[OnName num="gorou"]
'這很好，但有些事情是不對的。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune085"]
[OnName num="suzune"]
這並不是說事情剛剛發生，更像是......，一直以來，都有事情發生。 "
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune086"]
[OnName num="suzune"]
'五郎。你喜歡我嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'是的。我喜歡你。 "
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune087"]
[OnName num="suzune"]
'你不是最好的聽眾。你喜歡我這個戀人嗎？
[cpg cn=true]


[OnName num="gorou"]
這是......，已經決定我不會選擇其他人。 "
[cpg cn=true]


我妹妹聽到我的話後，顯得很痛苦。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune088"]
[OnName num="suzune"]
'我非常喜歡你，我想做你的情人。
[cpg cn=true]


...... 我直到剛才才考慮到這種可能性。
[cpg]


這不是由我來選擇其他人。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune089"]
[OnName num="suzune"]
與我們四個人在一起很有趣，但也可能很困難。 "
[cpg cn=true]


顯然，我姐姐很愛我。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune090"]
[OnName num="suzune"]
'我已經準備好成為你唯一的我。
[cpg cn=true]


我想讓你成為我，只做你的妹妹"這句話背後的意圖隱藏在"我想讓你成為我，只做你的妹妹"。
[cpg]


[OnName num="gorou"]
'......'
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune091"]
[OnName num="suzune"]
'我不會對你隱瞞。我想和你結婚'。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune092"]
[OnName num="suzune"]
'如果你說你不會選擇任何人，......，我想與你保持距離。當我們不能在一起時，我在你身邊是很痛苦的。 "
[cpg cn=true]


這是一個令人心痛的想法。我只想和我的家人在一起。
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『学園廊下』（夕方）******************************************************

[OnName num="male_student_A"]
'哦，不。職業道路"。
[cpg cn=true]


[OnName num="male_student_B"]
'你為什麼會迷路呢？你說你想在畢業後馬上找到一份工作'。
[cpg cn=true]


[OnName num="male_student_A"]
我在努力，但我的父母似乎不允許我這樣做。
[cpg cn=true]


[OnName num="male_student_A"]
我和我的兄弟姐妹們也很挑剔。 ......。
[cpg cn=true]


[OnName num="male_student_B"]
'你必須做你自己。家庭，無論你多麼關心他們，他們不可能永遠留在你身邊。
[cpg cn=true]


...... 在稍遠的地方，可以聽到兩個互不相識的人之間的對話。
[cpg]


家庭不可能永遠呆在一起。我想可能確實是這樣的情況。
[cpg]


[window target=false]



[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************


要么你與你的妹妹有一種非家庭的關係，要么你與她這個家庭成員保持距離。它是一個還是另一個？
[cpg]


我想保持我們的關係是這樣的。
[cpg]


[window target=false]

[STOPBGM]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


那天在餐桌上，我和姐姐之間的關係變得很尷尬。
[cpg]


當然，Himaru似乎已經註意到了什麼，並且很擔心。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sSawa069"]
[OnName num="sawa"]
'怎麼了？我不再吃了。 "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSuzune093"]
[OnName num="suzune"]
是的。 ......，我沒有什麼胃口。 "
[cpg cn=true]


如何對待你的妹妹。我覺得我仍有一些事情需要告訴她。
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="gorou"]
'......，我知道這是唯一的辦法。
[cpg cn=true]


思考。經過反复思考，我得出了一個結論。
[cpg]


我不會在我妹妹和緋紅之間做出選擇。我找到了繼續我們目前關係的唯一方法。
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

第二天早上。在我離開之前，我給我姐姐打了電話。
[cpg]


[OnName num="gorou"]
'對不起。我很忙。 "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune094"]
[OnName num="suzune"]
'...... 不'。你想過這個故事嗎？
[cpg cn=true]


[OnName num="gorou"]
'是的。我給出了自己的答案。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sHimari115"]
[OnName num="himari"]
那是關於什麼的故事？ "
[cpg cn=true]


緋春也在這裡。我真的需要她在那裡。
[cpg]


因為如果我和我妹妹結婚，緋紅還是不會說她想留在我身邊。
[cpg]


我甚至不需要再問這個問題了，或者說問這個問題太自私，太不禮貌了。
[cpg]


當然，我母親除外，否則她不會要求這樣做。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="sSuzune095"]
[OnName num="suzune"]
'......，我不能不對緋紅隱瞞。我告訴戈羅。我告訴他，我非常愛他，我想嫁給他。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="sHimari116"]
[OnName num="himari"]
'呵。這很大膽。 "
[cpg cn=true]


緋紅似乎一點也不難過。她可能認為我不能在那裡鼓起勇氣。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune096"]
[OnName num="suzune"]
我......，如果我不能結婚，那麼我就很難在五郎身邊，這是我說的。 "
[cpg cn=true]


[OnName num="gorou"]
是的，我希望你能和我在一起。但我也希望緋紅能和我在一起。 "
[cpg cn=true]


[OnName num="gorou"]
我想知道這樣的方便是否可能。 "
[cpg cn=true]


我妹妹喘著氣，等著我說什麼。
[cpg]


[OnName num="gorou"]
'......，讓他們兩個人結婚怎麼樣？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="sHimari117"]
[OnName num="himari"]
嗯？ "
[cpg cn=true]


[OnName num="gorou"]
'當然，不是現在。因為我喜歡我們這個家庭'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="sSuzune097"]
[OnName num="suzune"]
你知道你在說什麼嗎？日本不承認一夫多妻制"。
[cpg cn=true]


[OnName num="gorou"]
'是的，好吧，......，實際上不會是關於註冊的。
[cpg cn=true]


[OnName num="gorou"]
'但如果他們說他們可以在國外做，如果這就是他們出國的原因，那麼我認為這也很好'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune098"]
[OnName num="suzune"]
'哦，你知道，......，這不是一個法律問題，而是一個心靈問題。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune099"]
[OnName num="suzune"]
'現在你們已經搬到一起住了，或者有了孩子，你會好好考慮嗎？
[cpg cn=true]


[OnName num="gorou"]
'我正在考慮這個問題。我在認真考慮與你們倆結婚。 "
[cpg cn=true]


[OnName num="gorou"]
'因為我決定不做選擇。我不認為走到一半是個好主意。
[cpg cn=true]


一種奇怪的沉默佔了上風。在這種情況下，緋紅開始笑了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari118"]
[OnName num="himari"]
'...... phew, ha ha ha'.
[cpg cn=true]


[OnName num="gorou"]
'緋紅?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari119"]
[OnName num="himari"]
'我沒有意識到你在想這些。你應該告訴我'。
[cpg cn=true]


笑完後，緋紅插話說。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari120"]
[OnName num="himari"]
'我不需要和你們兩個人結婚，也不需要出國，或者任何東西。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari121"]
[OnName num="himari"]
'因為我可以一直呆呆的，即使我的姐姐和弟弟結婚了。
[cpg cn=true]


[OnName num="gorou"]
什麼？ "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune100"]
[OnName num="suzune"]
'但是，但是......，我將擁有五郎一個人。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSuzune101"]
[OnName num="suzune"]
如果緋紅像你一樣喜歡五郎，你將無法原諒他。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="sHimari122"]
[OnName num="himari"]
'你們都想得太多了。你不知道未來會怎樣'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari123"]
[OnName num="himari"]
'你為什麼一開始就想結婚？你從哪裡得到的壟斷？我完全可以做我哥哥的第二。
[cpg cn=true]


緋紅的性格是讓模棱兩可的事情變得模糊不清。
[cpg]


她正試圖把我們從思想中解救出來。
[cpg]


也許她正在努力管理這種情況，即使它有點不堪重負。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune102"]
[OnName num="suzune"]
'緋紅，你不吃醋嗎？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari124"]
[OnName num="himari"]
'我願意。但和我妹妹在一起，我很好。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari125"]
[OnName num="himari"]
'你們倆都太守規矩了。這一天到來時，又不是世界末日，為什麼事情不能按原樣發展？
[cpg cn=true]


我和我妹妹互相看了看。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari126"]
[OnName num="himari"]
'那你確定你是準時的嗎？我已經習慣於遲到了。 "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="sSuzune103"]
[OnName num="suzune"]
啊！ "
[cpg cn=true]


;//ブラックアウト

[window target=false]

[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（朝）******************************************************

我們開始交談。我趕緊準備一下，然後去學院，但我妹妹可能會遲到。
[cpg]


緋紅說的那件事是......，說是最後什麼都沒做，但我的心卻奇怪的很清楚。
[cpg]


我決定做的事情也可能是像緋紅所說的那樣。
[cpg]


我想盡可能長時間地保持相同的距離。
[cpg]


緋紅可能已經看穿了這一點，她可能已經安撫了她的妹妹。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『学園教室』（昼）******************************************************


[OnName num="male_student_A"]
'我已經決定了。我畢竟要去找一份工作了。
[cpg cn=true]


[OnName num="male_student_B"]
'嗯，這很好。為了你的家庭，繼續接受高等教育是很愚蠢的'。
[cpg cn=true]


[OnName num="male_student_A"]
'哦。 '我想如果我要考慮什麼是對我的家庭最好的，那麼我不妨做我想做的事。
[cpg cn=true]


[OnName num="male_student_A"]
'在我焦頭爛額的時候，這對我的家庭是不利的。
[cpg cn=true]


[OnName num="male_student_A"]
'我想有時我為自己做的事也是為我的家人做的事。
[cpg cn=true]


...... 有時間的二人組。看起來我們已經取得了一些進展。
[cpg]


我也不能一直迷路。我不能迷失，不能選擇任何人，我不能迷失。
[cpg]


如果你已經下定決心，就繼續向前推進吧。這就是我的想法。
[cpg]


[window target=false]

[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『学園教室』（夕方）******************************************************

這是一種思維方式，但我也想知道是否所有的事情都要決定。
[cpg]


有時，像向日葵這樣的思維方式可以解決一切問題。
[cpg]


即使它不能解決所有問題，但有些時候，現狀是最幸福的。
[cpg]


似乎不從我姐姐那裡學到，我甚至不能意識到這麼明顯的事情。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune104"]
[OnName num="suzune"]
因此，......，這裡的解決方案是：......
[cpg cn=true]


你的妹妹表現得很平靜，她沒有提醒你她遲到了。
[cpg]


當我在同一個教室裡時也是如此。可能要感謝緋紅的存在，我才能像這樣保持冷靜。
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************



[OnName num="female_student"]
'哦，不。我已經被終止了，嗯？ "
[cpg cn=true]


[OnName num="male_student"]
'審查？漫畫？ "
[cpg cn=true]


[OnName num="female_student"]
'是的，一部卡通片。你想在那裡堅持下去嗎？它就這樣結束了。 "
[cpg cn=true]


[OnName num="male_student"]
'慚愧。我寧願有一個后宮，而不是一些奇怪的聯姻。
[cpg cn=true]


現實不是漫畫書。不要擔心被審查。
[cpg]


我在聽一些夫婦的談話時也這麼想。
[cpg]


[OnName num="female_student"]
'嗯？我不喜歡后宮和通常的東西。你是不是有什麼外遇？ "
[cpg cn=true]


[OnName num="male_student"]
'不，不。 ......，怎麼可能呢？
[cpg cn=true]


...... 好吧，我們說有一些關係在一起沒有問題，比如說這兩個人。
[cpg]


但同樣，現實不是卡通。
[cpg]


我的生活不是為了讓人看到，為了給人看。
[cpg]


如果是這樣的話，追求幸福總是更好的，即使它是模糊的。
[cpg]




;//ブラックアウト


[window target=false]



[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="sSuzune105"]
[OnName num="suzune"]
'緋紅.不要再在你父親面前調情了。
[cpg cn=true]


[VOICE f="sHimari127"]
[OnName num="himari"]
'你為什麼不和你妹妹也調情呢？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune106"]
[OnName num="suzune"]
'不! 這不會耽誤我們的工作。 "
[cpg cn=true]


[OnName num="gorou"]
'當人們說他們不喜歡它時，我很傷心。 ......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune107"]
[OnName num="suzune"]
哦，不，我不是這個意思。 "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]

媽媽笑著說。
[cpg]


起初我覺得很奇怪，沒有人選擇她，但也許這就是日常生活應該有的樣子。
[cpg]


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[window target=true]


然後過了一會兒，......
[cpg]


;//========================================
;//●ＣＧ（ベッドに三人寝転がっている。おなかは膨らんでない）ev_50
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//人物３：ヒロイン３
;//服装３：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================


[STOPBGM]
[WAIT time=1000]
[BGM f="bg_op"]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sHimari128"]
[OnName num="himari"]
'嘿嘿~。我們都在一起，這有點像一次旅行。 "
[cpg cn=true]


[VOICE f="sSawa070"]
[OnName num="sawa"]
'嗯，沒錯。我們已經有一段時間沒有過家庭假期了。
[cpg cn=true]


[VOICE f="sSuzune108"]
[OnName num="suzune"]
......，是的，沒錯。 "
[cpg cn=true]


今天，我們四個人在緋紅的要求下在一起。
[cpg]


這也不適合我，因為我的體質已經穩定下來了。
[cpg]


這是我的命運，因為我沒有選擇其他任何人。
[cpg]


[VOICE f="sHimari129"]
[OnName num="himari"]
'來吧，兄弟。你想要多少刺激，我就給你多少刺激。 "
[cpg cn=true]


[VOICE f="sSuzune109"]
[OnName num="suzune"]
'......，很瘋狂。這就是......'
[cpg cn=true]


[VOICE f="sHimari130"]
[OnName num="himari"]
'嗯，我很開心。我希望我們都能一直在一起'。
[cpg cn=true]


我當時的心情無法形容，但卻很激動。
[cpg]


[VOICE f="sSawa071"]
[OnName num="sawa"]
'呵。緋紅是如此的無辜'。
[cpg cn=true]


還有我的母親，她說，嗯，她也在天真地笑著。
[cpg]


我不知道他們三個人到底是怎麼想的。但他們似乎有點高興。
[cpg]




[VOICE f="Suzune385"]
[OnName num="suzune"]
'如果你對我的愛不夠，我就會生氣，因為我們三個人在一起。
[cpg cn=true]


[VOICE f="sHimari131"]
[OnName num="himari"]
'很高興見到你，大哥哥。 '不，我想我總有一天會成為一個父親。
[cpg cn=true]


[OnName num="gorou"]
'我不知道。
[cpg cn=true]


[VOICE f="Sawa315"]
[OnName num="sawa"]
不要漏掉一個人！ "
[cpg cn=true]




[OnName num="gorou"]
...... 我知道我在做什麼。
[cpg cn=true]


是否有后宮這種東西，或者是否應該有？
[cpg]



;//ブラックアウト

家庭。戀人。不能用這些詞來定義的關係。
[cpg]


我當然很高興，讓模棱兩可的事情保持模棱兩可。
[cpg]


我想我姐姐、緋紅和我母親可能也有同樣的感覺。 ......
[cpg]

[SCENE id=12]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]
;//ＥＮＤ：ハーレムルート






;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





