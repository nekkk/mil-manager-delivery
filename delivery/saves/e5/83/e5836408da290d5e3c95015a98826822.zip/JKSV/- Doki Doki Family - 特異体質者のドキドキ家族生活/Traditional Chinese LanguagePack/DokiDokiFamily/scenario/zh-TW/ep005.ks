
*start

;###################################################################
*Ep005|對Jujuon的看法
;###################################################################


;//１、寿々音
*select04_1|關於鈴音的思考


[SCENE id=5]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


...... 我想這畢竟是我的妹妹。
[cpg]


我認為她是最可靠的人。有一些東西是缺失的，但即便如此，她與緋紅和我的母親完全不同。
[cpg]


緋紅做什麼事都太隨和了，而我母親則有些軟弱和放鬆。
[cpg]


但這並不是愛上她的理由。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我早早起床，只有我和我妹妹。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune107"]
[OnName num="suzune"]
'早上好。你今天起得很早。 "
[cpg cn=true]


[OnName num="gorou"]
'是的。 ...... 嘿，我需要和你談點事。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune108"]
[OnName num="suzune"]
'我想知道。是關於憲法的嗎？
[cpg cn=true]


我點點頭，繼續與我的妹妹交談。
[cpg]


[OnName num="gorou"]
'......，我想如果我要愛上一個人，她會是唯一的一個。 ......'
[cpg cn=true]


[OnName num="gorou"]
'但如果我們那樣做，我們就會在家族中結婚，不是嗎？所以，你知道。 "
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
我一直在說，我不能歸結為什麼。最後。
[cpg]


[OnName num="gorou"]
'......，我應該怎麼做呢？
[cpg cn=true]


他總結說。她沒有給我一個驚愕的眼神。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune109"]
[OnName num="suzune"]
'首先，你必須和你喜歡的人在一起。 '如果是因為你認為我會原諒你，這仍然不是一個好主意。
[cpg cn=true]


[OnName num="gorou"]
我知道。 ......，是的，我可以看到。 "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune110"]
[OnName num="suzune"]
'那麼你最好考慮一下你喜歡誰。然後我們可以談一談。 "
[cpg cn=true]


......，我不能說什麼。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




;//＠
之後，緋紅讓我的心跳加快，我就去了學院。
[cpg]


不知何故，當我和緋紅在一起時，我不能想太多東西。
[cpg]


我不禁想起了我的妹妹。
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************





然後我在學校花了一些時間。現在輪到我去我姐姐那裡了。
[cpg]


在遇到她之前，我是如此緊張，以至於我無法與遇到緋紅時相比。
[cpg]



;//ブラックアウト


[window target=false]



[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『学園教室』（昼）******************************************************





空蕩蕩的教室。我們帶著某種尷尬的心情面對著對方。
[cpg]

;//ブラックアウト

;//========================================
;//●ＣＧ（主人公と密着するヒロイン。胸が当たっている）ev_16
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]





我的姐姐接近我。我們在學校裡，而她卻在做這個。
[cpg]


由於我的體質，這是沒辦法的事，無論我怎麼想......。
[cpg]


並非所有其他看到這一幕的人都會這麼想。
[cpg]


而這一事實正是讓我心跳加速的原因。
[cpg]


[VOICE f="sSuzune022"]
[OnName num="suzune"]
'我不知道.......所有這些東西是否讓你感到緊張？ "
[cpg cn=true]


我只是與她保持密切聯繫。儘管這只是一次親密接觸，但我非常興奮，因為她對我非常重要。
[cpg]


只要能有這樣的感覺，能夠接觸對方就意味著很多。
[cpg]


[OnName num="gorou"]
......"
[cpg cn=true]


我甚至連一個字都說不出來。看到這一點，我妹妹很擔心。
[cpg]


;**【ＣＧ】 ev_16_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune023"]
[OnName num="suzune"]
'如果你不說點什麼，我就會擔心。
[cpg cn=true]


當他走到那一步時，我終於回復了。
[cpg]


[OnName num="gorou"]
'是的。這是非常......。 "
[cpg cn=true]


;**【ＣＧ】 ev_16_b ***********************
[CG id=7 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune024"]
[OnName num="suzune"]
'不要告訴我這很好。你會讓我意識到這一點'。
[cpg cn=true]


她很冷淡，但我可以看出她有點尷尬。
[cpg]


如果她感到尷尬，說明她對我有看法。
[cpg]


這也讓我很高興。除了高興之外，我還想說的是。
[cpg]


[OnName num="gorou"]
你臉紅了。
[cpg cn=true]


;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune025"]
[OnName num="suzune"]
'你這麼說，但你也是如此。
[cpg cn=true]


我一直希望能在她身邊。
[cpg]


如果我說，只要有她在，我就不需要別的東西，我覺得對緋紅很不好.......
[cpg]


即便如此，我的姐姐對我來說是一個不可替代的存在。
[cpg]


我不知道如何將她與其他任何人進行比較。
[cpg]


;**【ＣＧ】 ev_16_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune026"]
[OnName num="suzune"]
'我的身體也開始發熱，我在這裡......，這讓我很尷尬。
[cpg cn=true]


我對我和我妹妹之間這種微妙的距離感念念不忘。
[cpg]


當然，現在我在身體上非常接近，但我的思想卻不是。
[cpg]


[OnName num="gorou"]
'......，你妹妹似乎也很激動。
[cpg cn=true]


我注意到，她的脈搏在加快。
[cpg]


;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune027"]
[OnName num="suzune"]
'真的嗎？不僅僅是你這樣。 "
[cpg cn=true]


[OnName num="gorou"]
'我不這麼認為。 ......，我認為這是我的想像力。
[cpg cn=true]


[VOICE f="sSuzune028"]
[OnName num="suzune"]
'這只是我的想像。
[cpg cn=true]


我所說的一些話是真的嗎？這就是我的想法，我們都在......。
[cpg]


在這個世界上只有我們兩個人，或者說他們是這麼說的，但這是一個學院。
[cpg]


我可以聽到另一個學生的聲音就在外面。我有一部分人感到緊張，因為我們並不孤單。
[cpg]


教會我這些感覺的姐妹是不可替代的。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


我和我妹妹在白天的時候互相觸摸。
[cpg]


晚上，是我的母親。早上是緋紅。那些日子已經持續了很久，現在也不會改變。
[cpg]


[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





第二天早上。向學校走去，我在路上與女孩們會合。
[cpg]


[OnName num="female_student"]
'早上好，小坂君。
[cpg cn=true]


[OnName num="gorou"]
'哦，早上好......'
[cpg cn=true]


[OnName num="female_student"]
'最近，小坂君改變了他的情緒，是嗎？我不知道該怎麼說，這更像是憂鬱。 ......
[cpg cn=true]


[OnName num="gorou"]
'什麼，......？你在說什麼？ "
[cpg cn=true]


[OnName num="female_student"]
'不，這沒什麼! 到時見。 "
[cpg cn=true]


...... 那個迅速離開的女孩可能也對我有好感。
[cpg]


我也沒有一個這樣的女孩。
[cpg]


但當你想到要一起度過你的餘生時，情況就不同了。
[cpg]


回想起來，我跟隨姐姐的腳步已經有很長一段時間了。
[cpg]


我一直很佩服她。我又意識到了這一點。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


然後早晨又變成了中午，是我和我妹妹在一起的時候了。
[cpg]

[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[OnName num="gorou"]
'......Oh，請。這對我來說已經很困難了。 ......"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune130"]
[OnName num="suzune"]
'這對你來說一定很困難。我知道，如果我站在你的立場上，我也會很難過。
[cpg cn=true]


...... 一些奇怪的說法。如果你處於我的位置，你會怎麼做？
[cpg]


[OnName num="gorou"]
你的意思是......？ "
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune029"]
[OnName num="suzune"]
'這沒什麼。更重要的是，你今天在做什麼？
[cpg cn=true]


我是被迫作弊的。而我仍然呼吸困難。
[cpg]



我不能過多地考慮其他事情。對。
[cpg]


[OnName num="gorou"]
那好吧，......."
[cpg cn=true]


;//========================================
;//●ＣＧ（座っているヒロインのことを見つめる主人公）ev_17
;//人物１：ヒロイン１
;//服装１：スーツ（はだけ）
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


我想出了一些和以前不一樣的東西，我決定給它一個機會。
[cpg]


我妹妹看起來有點驚愕，但這很好，包括她臉上的表情。
[cpg]


[VOICE f="Suzune134"]
[OnName num="suzune"]
'......，你想出了最奇怪的事情。
[cpg cn=true]


今天，我將停止要求我的妹妹觸摸我或接近我。
[cpg]


我想看著我妹妹。我曾要求她這樣做。
[cpg]


[OnName num="gorou"]
'這並不奇怪。我認為你想一直看著我。
[cpg cn=true]


她似乎對我的話有些迷惑。
[cpg]


;**【ＣＧ】 ev_17_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune030"]
[OnName num="suzune"]
'你確定你想這樣做，只是看著？
[cpg cn=true]


[VOICE f="sSuzune031"]
[OnName num="suzune"]
'我認為你需要觸摸它或接近它，或......，這樣的東西。
[cpg cn=true]


沒有這些，我就已經很激動了。我現在可能會這樣。
[cpg]


[OnName num="gorou"]
...... 是的。 "
[cpg cn=true]


看著她，她似乎是我需要的一切。
[cpg]


我不好意思這麼說，但我這麼想也沒關係。
[cpg]


;**【ＣＧ】 ev_17_b ***********************
[CG id=8 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune032"]
[OnName num="suzune"]
她看五郎的樣子，有點噁心。 "
[cpg cn=true]


[OnName num="gorou"]
'是的，我不認為如此。
[cpg cn=true]


她看起來很困惑和尷尬。
[cpg]


唯一的一點是，被盯著看是被盯著看的人可能在想的事情。
[cpg]


[OnName num="gorou"]
'姐姐......，真的非常、非常漂亮。
[cpg cn=true]


她剛才在看我，現在又看向別處。
[cpg]


;**【ＣＧ】 ev_17_c ***********************
[CG id=8 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune033"]
[OnName num="suzune"]
'你怎麼敢？
[cpg cn=true]


[OnName num="gorou"]
'我沒有撒謊。我是認真的。
[cpg cn=true]


她對我的話做出了輕微的顫抖姿態。
[cpg]


[VOICE f="sSuzune034"]
[OnName num="suzune"]
我的手指都沒放在她身上，但這太奇怪了。這也讓我很緊張。
[cpg cn=true]


姐姐說這話時臉紅了。
[cpg]


我不能就這樣看著她。
[cpg]


[OnName num="gorou"]
我想繼續盯著她看。姐姐。
[cpg cn=true]


那個更害羞的妹妹開口了。
[cpg]


;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune035"]
[OnName num="suzune"]
'......，就像被五郎的話語所觸動。
[cpg cn=true]


她這樣說並不是在撒謊。
[cpg]


作為證據，她的妹妹甚至臉紅到了耳根。
[cpg]


我想觀察一切，甚至她的樣子。這就是我的感覺。
[cpg]


接受我的目光和話語的姐妹。
[cpg]


我覺得那裡有一些像母親的東西。
[cpg]


[OnName num="gorou"]
'即使我只是看著她，我也很高興。
[cpg cn=true]


;**【ＣＧ】 ev_17_c ***********************
[CG id=8 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune036"]
[OnName num="suzune"]
'不要感到尷尬。不過，我受寵若驚了。
[cpg cn=true]


她當然看起來既尷尬又高興。
[cpg]


我只為這個感到高興。
[cpg]


[FG f="ci_lbox.ui" method="feadin_up"  pos="4/7"]

[WAIT time=1000]
;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】『学園のチャイム』


時間過去了一段時間。我們不可能永遠在一起，我們不可能和對方在一起。
[cpg]


午餐時間過後，我和姐姐都要去上課。
[cpg]


這一次比以往任何時候都更讓人沮喪。
[cpg]





[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


還有下午上課後，放學後。
[cpg]


[window target=false]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



傍晚時分的學校。我們離開教室，試圖回家。
[cpg]


在那裡我有這樣的想法。
[cpg]


一天三次，一天三次，我有時間激動不已。 ......
[cpg]


所有這些，我都是為了想和我妹妹在一起。
[cpg]


首先，我必須和我媽媽談談。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************





當我回到家時，就像這樣，只有我媽媽在那裡。
[cpg]


[OnName num="gorou"]
'哦，你知道，...... 母親。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa101"]
[OnName num="sawa"]
'這是什麼？這對你來說有點早，不是嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'不，不是那個，是那個。這是關於你晚上要為我做什麼，我想讓...... 你的妹妹來代替我。
[cpg cn=true]


我解釋說。只有關於我喜歡我妹妹的部分仍然被隱藏著。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa102"]
[OnName num="sawa"]
'...... 是的。我明白了。
[cpg cn=true]


但我的媽媽似乎把一切都想好了。這是正確的，她是我的母親。 ......
[cpg]




;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[WAIT time=1000]

[SE f="se012"]
;//【ＳＥ】『ノック』


[WAIT time=1500]

[window target=true]


;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune151"]
[OnName num="suzune"]
我進來了，戈羅。
[cpg cn=true]


[OnName num="gorou"]
呃，是的。 ...... 進來吧。 "
[cpg cn=true]


[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune037"]
[OnName num="suzune"]
'我聽說了。你想讓我做你母親的那份？
[cpg cn=true]


[OnName num="gorou"]
我不知道我是否應該......，真的，但這取決於我。 "
[cpg cn=true]


不知怎的，我有種感覺，他們不會說不。
[cpg]


然後姐姐微微嘆了口氣，然後
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune153"]
[OnName num="suzune"]
'你認為如果你告訴我這些，我能說不嗎？真的，他是一個可愛的小兄弟。 "
[cpg cn=true]



;//========================================
;//●ＣＧ（密着する二人。ヒロインが体を前に倒している状態。ヒロインの髪が主人公の体に当たっている）ev_18
;//人物１：ヒロイン１
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：主人公の部屋
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]


[SE f="se004"]
;//【ＳＥ】『衣擦れ』


[BGM f="bg_h1"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune038"]
[OnName num="suzune"]
'也許......，我也已經瘋了。
[cpg cn=true]


他說這話時，表情略顯渾濁，或者說他的眼睛裡有一種憂鬱的神情。
[cpg]


[OnName num="gorou"]
'你這話是什麼意思？
[cpg cn=true]


姐姐在選擇她的話語。她彷彿不知道該說什麼。
[cpg]


[VOICE f="sSuzune039"]
[OnName num="suzune"]
'沒有你，我感覺好像我的心在痛苦。
[cpg cn=true]


...... 我應該如何看待這個問題？
[cpg]


與其說是深思熟慮，不如說是感覺他按捺不住，言之有物。
[cpg]


當然，我的體質讓我很痛苦，但我無法想像我的妹妹會從我這裡得到這些。
[cpg]


[VOICE f="sSuzune040"]
[OnName num="suzune"]
'我覺得我想更接近你。我不知道為什麼'。
[cpg cn=true]


你妹妹的長發貼著我的身體。我感到很沮喪。
[cpg]


[OnName num="gorou"]
'妹子。你的頭髮讓我很癢。 "
[cpg cn=true]


她不是沒有註意到，但我敢於說出來。然後。
[cpg]


;**【ＣＧ】 ev_18_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune041"]
[OnName num="suzune"]
'真的嗎？你不喜歡它？ "
[cpg cn=true]


他說了一句話，讓人分外難受。
[cpg]


[OnName num="gorou"]
'......，我並不討厭它。
[cpg cn=true]


[VOICE f="sSuzune042"]
[OnName num="suzune"]
'很好，那麼。讓我像這樣多呆一會兒吧'。
[cpg cn=true]


姐姐說了一些咄咄逼人的話。我不覺得我這樣做只是為了讓她緊張。
[cpg]


也許這就是它的開始，但它與我的憲法已經沒有關係。
[cpg]


我覺得我們已經到了一個不應該有的地步。
[cpg]


但這是......，即使如此，我也不討厭它。
[cpg]


[OnName num="gorou"]
'是的。這是......，直到它讓你感覺更好。 "
[cpg cn=true]


;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune043"]
[OnName num="suzune"]
'這很古怪。我是為了你的憲法而做的。
[cpg cn=true]


但我覺得那是一個藉口，或者說是我們共同的逃避途徑。
[cpg]


當這種體質被治好後，我們將做什麼？
[cpg]


[VOICE f="sSuzune044"]
[OnName num="suzune"]
'我可以聞到五郎的味道。
[cpg cn=true]


當然，相反的情況也是如此。這就是我們的關係。
[cpg]


彷彿不僅是我們的身體，而且我們的心也變得更加緊密。
[cpg]


;**【ＣＧ】 ev_18_b ***********************
[CG id=9 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune045"]
[OnName num="suzune"]
這很奇怪。我們總是在一起，但你似乎是一個不同的人。
[cpg cn=true]


當她這樣說時，她更加靠近。呼吸打。
[cpg]


我希望時間能像這樣停止。我想這麼想，我覺得撲通撲通的聲音讓我很解氣。 ......
[cpg]


因重擊而感到安心，聽起來好像很矛盾，但對此刻的我來說，這是個正確的詞。
[cpg]


我相信這是一對半路出家的戀人所感受不到的。
[cpg]


;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune046"]
[OnName num="suzune"]
我想多和你在一起。我也很擔心你。
[cpg cn=true]


儘管我和妹妹沒有血緣關係，但我們也是姐妹和兄弟。
[cpg]


我在那裡感到安全一定是有原因的。
[cpg]


[VOICE f="sSuzune047"]
[OnName num="suzune"]
'如果這樣做會讓我感覺更好，我會......，一直這樣做。
[cpg cn=true]


她在說這句話時，把她的皮膚拉到我身上。
[cpg]


[OnName num="gorou"]
'我很高興。姐姐'。
[cpg cn=true]


這對我來說是一種浪費，但這並不意味著我不想把它給別人。
[cpg]


我想讓她成為我的親妹妹。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]



[OnName num="gorou"]
'謝謝你。我現在很好。 "
[cpg cn=true]


呼吸不再有任何疼痛感。但我的心卻有些痛苦。
[cpg]


彷彿我的身體和思想彼此不一致。
[cpg]


[VOICE f="sSuzune048"]
[OnName num="suzune"]
'真的嗎？別緊張。 "
[cpg cn=true]


我真的很想和你睡覺，但如果我這樣做了，我可能會習慣於我所受到的重擊。
[cpg]



[window target=false]


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




我不覺得自己會被那些常見的、奇怪的夢境驚醒。
[cpg]


也許這是對我姐姐為我所做的事情的滿足。
[cpg]


我並不感到孤獨，即使是在一個人的房間裡。 ......
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



還有早晨。現在我必須要和緋紅談談。
[cpg]


我想我應該昨天就做了，因為......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari026"]
[OnName num="himari"]
'早上好。來吧，今天我再給你一個刺激。 "
[cpg cn=true]


真讓人吃驚，因為緋紅走過來對我說。
[cpg]


她還把她漂亮的大奶子推給我，但我雖然不應該被掃地出門。
[cpg]


[OnName num="gorou"]
'哦，你知道，......，我很抱歉你總是這樣對我，但那.........'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari117"]
[OnName num="himari"]
'什麼？你甚至想讓我和你妹妹交換位置嗎？ "
[cpg cn=true]


[OnName num="gorou"]
是的。 ......"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Himari118"]
[OnName num="himari"]
'我主要是從你母親那裡聽說的。你一定是真的那麼喜歡你的妹妹'。
[cpg cn=true]


緋紅看起來有點悲傷。
[cpg]


這就是為什麼，或者說......，我感到有什麼東西把我推到了邊緣。
[cpg]


我不能再這樣下去了。半心半意的態度甚至會傷害到緋紅。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune170"]
[OnName num="suzune"]
'......，我也在早上做？一天三次，不過都是由我來做。 "
[cpg cn=true]


[OnName num="gorou"]
'哦，不？
[cpg cn=true]


她笑了一下。我一定是看起來很傻。
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune049"]
[OnName num="suzune"]
'不，我不知道。然後.......'。
[cpg cn=true]


;//ブラックアウト

;//========================================
;//●ＣＧ（主人公に寄り添うヒロイン。朝出かける前）ev_19
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：朝
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



我不需要任何更多的話，但我不想保持沉默，所以我說。
[cpg]


[OnName num="gorou"]
'這很溫暖。 '姐姐'。
[cpg cn=true]


姐姐看著我。然後她問道。
[cpg]


[VOICE f="sSuzune050"]
[OnName num="suzune"]
'......，難道你光是在我身邊就沒有快感了嗎？
[cpg cn=true]


[OnName num="gorou"]
'不。不，不是的'。
[cpg cn=true]


[VOICE f="sSuzune051"]
[OnName num="suzune"]
你確定你沒有在逼迫它嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'這是真的，我告訴你。你看起來沒有任何痛苦的證據'。
[cpg cn=true]


[VOICE f="sSuzune052"]
[OnName num="suzune"]
'真的嗎？我希望如此。 "
[cpg cn=true]


她在說這句話時向我靠攏。
[cpg]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[VOICE f="sSuzune053"]
[OnName num="suzune"]
'...... 吾郎對我來說比什麼都重要。我很抱歉讓你認為我不是。
[cpg cn=true]


觸感柔軟。就在這時，我的心才停止了跳動。
[cpg]


我想更接近。我的慾望並沒有就此停止。
[cpg]


我想成為你的...... 情人。
[cpg]


[OnName num="gorou"]
姐姐。嗯，嗯......"
[cpg cn=true]


我正準備說些什麼，我妹妹卻不肯閉嘴，看到我說不出話來。
[cpg]


;**【ＣＧ】 ev_19_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune054"]
[OnName num="suzune"]
'我也很緊張，......，你知道嗎？
[cpg cn=true]


[OnName num="gorou"]
是的。我得到了這個消息'。
[cpg cn=true]


就像我越不主動，我妹妹就越親近。
[cpg]


這種關係在某種程度上讓人感到安心，與重擊的方式不同。
[cpg]


;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune055"]
[OnName num="suzune"]
胡胡，這有點尷尬。 "
[cpg cn=true]


他們在一起的時間在談論這些事情時過去了。
[cpg]


[OnName num="gorou"]
'我可能會感到尷尬，但我想留在你的身邊......。
[cpg cn=true]


[VOICE f="sSuzune056"]
[OnName num="suzune"]
是的，我也一樣。 "
[cpg cn=true]


她覺得自己與姐姐的關係比任何人都要密切，但仍然感到很沮喪。
[cpg]


[VOICE f="sSuzune057"]
[OnName num="suzune"]
'吾郎......'
[cpg cn=true]


她撫摸著我的頭，低聲說。
[cpg]


她撫摸著我的頭髮。她的臉也走近了。
[cpg]


而且她的嘴唇越來越近。我趕緊閉上眼睛。
[cpg]


我幾乎失去了距離。我不能以這種緊迫性做任何事情。
[cpg]


;**【ＣＧ】 ev_19_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune058"]
[OnName num="suzune"]
'週週'。
[cpg cn=true]


他們互相撫摸。她向我走了一步。
[cpg]


我太愛她了，以至於我覺得自己要......，失去了控制。言語無法解釋我有多愛她。
[cpg]


我不認識這麼可愛的人。我覺得我現在就想抱抱她。
[cpg]


我不能永遠這樣做，儘管我無法抗拒。
[cpg]


;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune059"]
[OnName num="suzune"]
......，差不多該走了。我得走了。 "
[cpg cn=true]


在我什麼都做不了的時候，我姐姐對我說了這句話。
[cpg]


我咒罵自己的無能，但我很高興她吻了我。
[cpg]


[OnName num="gorou"]
我很高興她吻了我。回頭見。 "
[cpg cn=true]


我不可能在一段時間內忘記她嘴唇的感覺。
[cpg]


我是說一段時間。 ...... 這將是一個我永遠不會忘記的吻。
[cpg]


;//ブラックアウト



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


然後我妹妹比我先離開了家。
[cpg]


這是很平常的事情，但關於它的孤獨感卻與平常不同。
[cpg]


我去學校的時候會看到她，但我會非常想念她。
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa103"]
[OnName num="sawa"]
我待會兒見。要小心。
[cpg cn=true]


[OnName num="gorou"]
'是的，我去了......'。
[cpg cn=true]


我們和緋紅一起離開了房子。我心裡有一些想法。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************



我要向我姐姐坦白。我想和她在一起。
[cpg]


她是我不可替代的妹妹，但我還是想。
[cpg]


我還想親吻她，擁抱她。
[cpg]


這並不是說我想治愈這種體質或什麼。 ......
[cpg]


我意識到，我仍然喜歡我的妹妹。
[cpg]


我可以說，這要歸功於緋紅。如果她不告訴我，我可能永遠不會從心底里意識到這一點。
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

白天，像往常一樣，我讓我的姐姐提高我的心率。但在放學後，......。
[cpg]

[WAIT time=1000]

[STOPBGM]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（夕方）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune190"]
[OnName num="suzune"]
'現在怎麼辦......？你在白天已經做過了。 "
[cpg cn=true]


[OnName num="gorou"]
'...... 姐姐，你說我應該和我喜歡的人在一起。
[cpg cn=true]


姐姐的表情變得有些僵硬。也許她在想像會說什麼。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune191"]
[OnName num="suzune"]
'......，那怎麼辦？
[cpg cn=true]


不過，我還是得說。我不能讓我妹妹猜到。
[cpg]


如果我在這樣的地方被寵壞了，我的餘生就真的被寵壞了。
[cpg]


[OnName num="gorou"]
"哦，我......，我是，你知道，......"。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune192"]
[OnName num="suzune"]
'我知道，我知道。你喜歡我，對嗎？ "
[cpg cn=true]


哦，不。這種趨勢將使我的餘生都受到寵愛。
[cpg]


但我現在不能幫助它。我已經說了我的觀點。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune193"]
[OnName num="suzune"]
'別擔心，我也喜歡你。不是作為一個兄弟，而是作為一個情人。
[cpg cn=true]




;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



我和我妹妹分別回家。我們有不同的工作和學習，有不同的時間投入其中。
[cpg]


但我想了一下，至少今天我想一起回家。
[cpg]


最後，我姐姐讓我先回家，但......，我有點迫不及待地想見到她。
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





那天的飯桌上沒有什麼異常。
[cpg]


我還是和往常一樣。我妹妹和往常一樣。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari119"]
[OnName num="himari"]
'再來一個! 大約百分之七十在碗裡！ "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune194"]
[OnName num="suzune"]
'你會發胖的。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Himari120"]
[OnName num="himari"]
'與我姐姐不同，我並沒有得到多少好處，我。
[cpg cn=true]


我認為我的姐姐是瘦的那個，緋紅說。
[cpg]


但姐姐並沒有露出厭惡的神情。或者說，她在某種程度上高於它。 ......。
[cpg]


...... 我想知道他們是否在想我。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





還有夜晚。我妹妹在我的房間裡。
[cpg]


[OnName num="gorou"]
'呃，呃，......，很高興見到你。
[cpg cn=true]


一天三次，出於三次心跳。然而，我卻非常緊張。
[cpg]


在這一切中，我妹妹對我說。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune060"]
[OnName num="suzune"]
'我必須告訴你，我從來沒有過女朋友。
[cpg cn=true]


[OnName num="gorou"]
'誒......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune061"]
[OnName num="suzune"]
我是說你是第一個。 "
[cpg cn=true]


說著，她向他走近。
[cpg]


;//移植前シーンカット
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]

;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]



[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

當我和姐姐在一起時，我覺得內心深處很充實。
[cpg]


這可能是人們固有的東西，而不是與他們的憲法有關的東西。
[cpg]


我感到很興奮。甚至在她離開後，我也睡不著，因為我太緊張了。
[cpg]


我想讓她永遠留在我身邊。但她離開了房間。
[cpg]


我說這是沒辦法的事，我也沒辦法。如果我父親發現她從我的房間出來，那就糟糕了。
[cpg]


我沒有選擇，只能等待明天。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



然後明天就來了，這有點尷尬。
[cpg]


我從未想過我會有這樣的感覺。她是我一直認識的那個姐姐。
[cpg]


她看起來像一個不同的人，或者也許是我變了。
[cpg]


我目送她離開房子，心想。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune213"]
[OnName num="suzune"]
我第一次見到她時，我想："好吧，那我走了，戈羅。緋紅。
[cpg cn=true]


[OnName num="gorou"]
是的。要小心。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari121"]
[OnName num="himari"]
祝你有個愉快的一天。 "
[cpg cn=true]

[free time=1000]
爸爸也離開了家。我們剩下的三個人是我、緋紅和我母親。
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Sawa104"]
[OnName num="sawa"]
'那麼，你打算怎麼做？我想知道他是否要和鈴音約會。
[cpg cn=true]


[OnName num="gorou"]
'E...... yeah, yeah.這就是計劃'。
[cpg cn=true]


經過片刻的困惑，我能夠給出我的答案。
[cpg]


我再也無法隱藏它了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="Himari122"]
[OnName num="himari"]
'要快樂。我也喜歡你的哥哥'。
[cpg cn=true]


[OnName num="gorou"]
"...... 是的。"
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』





還有學院的一個空教室。
[cpg]


我與我的妹妹面對面，搖搖晃晃，掙扎著要呼吸。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune214"]
[OnName num="suzune"]
'...... 我。我不想這樣做，因為我的體質。
[cpg cn=true]


他一邊走一邊告訴我這些。
[cpg]


我猜他很擔心，因為他在想我。我對此有一定的了解。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune215"]
[OnName num="suzune"]
'此外，當緋紅和你母親在處理五郎時，我不禁感到嫉妒。
[cpg cn=true]


[OnName num="gorou"]
'......，就是這麼回事。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune062"]
[OnName num="suzune"]
'不過，現在很好。我將填補...... 他們所有人。 "
[cpg cn=true]


對。關於我的一切都在我姐姐的手上。
[cpg]


這感覺相當令人欣慰。
[cpg]


;//移植前シーンカット



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

從現在起，我可以永遠呆在你身邊。僅僅是這樣想，我就覺得有點鬆了一口氣。
[cpg]


[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************



在我鬆了一口氣的同時，我對搗蛋的慾望也越來越強烈。
[cpg]


這其實只是一個小小的時間差，但我再也受不了了。
[cpg]


我再也無法忍受了。但我姐姐說那是晚上。
[cpg]


首先，現在她是我的妹妹而不是我的母親，我不能一回家就看到她。
[cpg]


我走了，感覺無法忍受。 ......
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





晚餐。現在的情況是，我爸爸是唯一不知道我和我妹妹之間關係的人。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari123"]
[OnName num="himari"]
'那麼你的姐姐和弟弟去哪裡了？
[cpg cn=true]


在這一切中，緋紅說了這樣一段話。我差點把吃的東西噴出來。
[cpg]


[free time=1000]

[OnName num="father"]
'你在說什麼？
[cpg cn=true]


[OnName num="gorou"]
'不，這沒什麼! 這沒什麼。 "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]

話雖如此，我的妹妹看起來有點暴躁。
[cpg]


是的，有一天我必須向我父親解釋。
[cpg]


他從來沒有像一個嚴格和頑固的父親，但......
[cpg]


不過，有些事情還是讓我緊張。一想到要告訴我爸爸，我就有些焦慮。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





而且夜夜如此。在我達到極限之前，我妹妹來到我的房間。
[cpg]



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune063"]
[OnName num="suzune"]
'你看起來很高興。
[cpg cn=true]


[OnName num="gorou"]
'......，有那麼明顯嗎？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune064"]
[OnName num="suzune"]
'是的。不過，她在這方面也很可愛。
[cpg cn=true]


我很尷尬，但等著看我妹妹會怎麼做。
[cpg]


我不知道，我經常這樣做。不過，我傾向於帶頭。
[cpg]

;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



我看著姐姐再次回到她的房間，我在痛苦中設法睡著了。
[cpg]


明天，我們仍將是戀人。我很高興。 ......
[cpg]


我應該高興得不得了，但我的體質裡有一種緊繃感。
[cpg]


我必須做一些事情。要做到這一點，我想我需要和我的妹妹做一些更有情趣的事情。
[cpg]


這是一種...... 巨大的事情，但首先我必須向我父親解釋。
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


而這一天出乎意料地迅速到來。
[cpg]

[window target=false]

[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************





[OnName num="gorou"]
'嗯，我不能! 我還沒有準備好。 "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune253"]
[OnName num="suzune"]
'爸爸，我今天心情很好。 '不是說他總是心情不好。
[cpg cn=true]


;//＠
一個星期天。有人找我談了這個問題。
[cpg]


我的意思是，我告訴我爸爸。 "把你的女兒給我！"還有。
[cpg]


;//ブラックアウト


[window target=false]

[STOPBGM]

[free time=1000]

[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



沒有緋紅和媽媽。這是我、我爸爸和我妹妹。
[cpg]


[OnName num="father"]
"......"
[cpg cn=true]


[OnName num="gorou"]
"......"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune254"]
[OnName num="suzune"]
'所以這就是為什麼我們......，不，吾郎可以和你說話嗎？
[cpg cn=true]

爸爸沒有嚴厲的面孔，但接近於無表情，有點嚇人。
[cpg]


[OnName num="gorou"]
'嗯，把你的女兒交給...... 我。
[cpg cn=true]


[OnName num="father"]
......"
[cpg cn=true]


在我說這句話的時候，我想我看到了爸爸嘴角的微笑。
[cpg]


[OnName num="gorou"]
'志，不。嗯，我想和我妹妹...... Suzune-san出去，或者說，我們要出去。
[cpg cn=true]


[OnName num="father"]
'噗，哈哈哈! 哦，是的，我知道你有一天會這樣。 "
[cpg cn=true]


[OnName num="gorou"]
什麼？ ......？ "
[cpg cn=true]


爸爸的反應令人驚訝。我原本以為他也會感到困惑。
[cpg]


[OnName num="father"]
'不，在這種情況下，要照顧好鈴音。我相信五郎將能夠幫助你'。
[cpg cn=true]


他寬慰地笑了笑，向我們表示祝賀。
[cpg]


我想，這是一個多麼偉大的父親，當然我也很感激......，所以......
[cpg]


[OnName num="gorou"]
哦，非常感謝你，......."
[cpg cn=true]


我說。我從來沒有對我父親經常使用過禮貌用語。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





[OnName num="gorou"]
'......，很順利。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune255"]
[OnName num="suzune"]
'對。我以為我是有點名氣的'。
[cpg cn=true]


他們在那裡仍然是父子關係嗎？
[cpg]


我不理解我父親的所有感受，但我的姐姐似乎理解。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune256"]
[OnName num="suzune"]
我不知道怎麼做，但我不打算這樣做。這很難，不是嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'是的。 ......，這很難。
[cpg cn=true]


我的體質仍在癒合。我很確定我已經愛上了，但可能還需要一點時間才能治愈我的體質。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune065"]
[OnName num="suzune"]
'來。現在我希望你能讓...... 我激動不已'。
[cpg cn=true]


[OnName num="gorou"]
'......，我會努力的。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune258"]
[OnName num="suzune"]
胡憂，你已經長大了，可以這麼說了。 "
[cpg cn=true]


姐姐拍拍她的頭。我感到很尷尬。
[cpg]

;//移植前シーンカット

;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************




幾天的通行證。暑假已經開始，嗯，沒關係。
[cpg]


校外已經有傳言說我愛上了我的妹妹。
[cpg]


而在到處都是謠言的情況下，暑假仍然是曙光。
[cpg]


這成為全校的大新聞。無數的男孩為此感到震驚，甚至女孩也有一些粉絲或不知道。 ......
[cpg]



[window target=false]

[STOPBGM]

[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]


[window target=true]


;//【ＢＧ】『街』（夜）******************************************************



儘管如此，日子還是一天天過去了。我想毫無顧忌地以我姐姐的情人身份出現。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune066"]
[OnName num="suzune"]
'......，現在，你難道不覺得苦嗎？
[cpg cn=true]


[OnName num="gorou"]
是的。輕鬆多了。 "
[cpg cn=true]


從那時起，我的體質就像一個謊言一樣安定下來。
[cpg]


所以醫生說的都是真的，起初我以為是個笑話。
[cpg]


我想知道我是否可以用'憲法'這個詞把它收起來，但我和我妹妹沒有必要再靠近了。
[cpg]


不過，這並不改變我們想要對方的事實。
[cpg]


[OnName num="gorou"]
我能說什麼呢，那些日子好像是個謊言。 ......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune278"]
[OnName num="suzune"]
'對。那些日子是那些日子，它們很有趣，但是......
[cpg cn=true]


[OnName num="gorou"]
'現在你不能忍受你的妹妹？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune279"]
[OnName num="suzune"]
我真的希望你不要再叫我 "姐姐"。
[cpg cn=true]


[OnName num="gorou"]
Ugh, it's ......"
[cpg cn=true]


當然，現在是時候解決這個問題了。
[cpg]


[OnName num="gorou"]
'但你不能幫助已經變得根深蒂固的東西，是嗎？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune067"]
[OnName num="suzune"]
'比如說，如果你有一個孩子，你還會把我稱為你的妹妹嗎？
[cpg cn=true]


[OnName num="gorou"]
那我就叫你媽媽。 "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune281"]
[OnName num="suzune"]
'......，你越來越善於歸還東西了。
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune068"]
[OnName num="suzune"]
'我希望我可以整天和你在一起。我們不必再對任何人隱瞞了'。
[cpg cn=true]


[OnName num="gorou"]
我說，"對。"...... 嘿。
[cpg cn=true]


她開始撫摸我的頭髮。我扭動著身體，癢癢的。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune069"]
[OnName num="suzune"]
'什麼？
[cpg cn=true]


[OnName num="gorou"]
'那很癢，哈哈哈，哈哈哈'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune070"]
[OnName num="suzune"]
'你認為五郎有被撓的弱點嗎？要我為你做更多嗎？ "
[cpg cn=true]


這是一個多麼適合調情的時代。


[window target=false]

[SE f="se000"]
;//【ＳＥ】『ノック』

[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




在這一切之中，有人敲響了我房間的門。
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari124"]
[OnName num="himari"]
'兄弟，你要用我的漫畫走那條路嗎？
[cpg cn=true]


[OnName num="gorou"]
'哦，緋紅......？嗯，我不知道。 "
[cpg cn=true]


現在已經很晚了。在這個時候，談論漫畫？
[cpg]


我想，我猜測。有人暗示我太吵了。
[cpg]


[OnName num="gorou"]
'......，很吵嗎？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari125"]
[OnName num="himari"]
'什麼？更重要的是，漫畫呢？ "
[cpg cn=true]


[OnName num="gorou"]
'哦，呃，我不認為我借了它。 ......'
[cpg cn=true]


我妹妹已經猜到了，讓我閉嘴。然而。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari126"]
[OnName num="himari"]
'嗯。好吧，那就祝你們倆好運。
[cpg cn=true]

[free time=1000]

緋紅說過這樣的話。我知道你太吵了。
[cpg]


[OnName num="gorou"]
'......，我應該怎麼做，姐姐？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune299"]
[OnName num="suzune"]
'別擔心。我說，'我祝愿你一切順利'。
[cpg cn=true]


這是事實，但我認為這是......，具有諷刺意味。
[cpg]


;//＠なんて思いつつ、俺達はもう一度交わることにした。




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


更多的時間過去了。我的體質已經完全穩定下來，我再也不用去醫院了。
[cpg]


他們要求我解釋發生了什麼，但我只是感到尷尬。
[cpg]


我想知道我是否應該讓我妹妹在我旁邊。我正在考慮這個問題。
[cpg]


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************



然後時間就過去了。有一個假期，我和我的妹妹在散步。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune316"]
[OnName num="suzune"]
她說："我們結婚後可以住在同一個房子裡，這很方便。"
[cpg cn=true]


[OnName num="gorou"]
'哦，那是肯定的。你不會在那裡迷路的'。
[cpg cn=true]


真是一場對話，我們的關係又有點不同了。
[cpg]


我妹妹懷孕了。顯然是個女孩，而且我們已經想好了名字。
[cpg]


[OnName num="gorou"]
'所以......，我不知道我要做什麼。我仍然不確定我是否會繼續接受高等教育'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune317"]
[OnName num="suzune"]
'我們之前已經談過這個問題了。繼續接受高等教育'。
[cpg cn=true]


[OnName num="gorou"]
'但你會讓你的妹妹陷入困境。抓緊時間找工作不是更好嗎？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune318"]
[OnName num="suzune"]
'五郎的優先事項應該是他想做的事情。你又沒有破壞我的生活或什麼，你可以依靠我'。
[cpg cn=true]


......，如果你想說那麼多，我就不說了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_01_2_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune071"]
[OnName num="suzune"]
'總之，你記得今天是什麼日子嗎？
[cpg cn=true]


[OnName num="gorou"]
'讓我看看......，是什麼......'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune072"]
[OnName num="suzune"]
'你不記得了？這是我們開始約會的日子，不是嗎？ "
[cpg cn=true]


[OnName num="gorou"]
我不記得我們開始約會的日子，......，也不記得我們成為戀人的日子。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune073"]
[OnName num="suzune"]
我們想要慶祝，即使這部分有點模糊。 "
[cpg cn=true]


[OnName num="gorou"]
我想知道它是否是這樣的。 "
[cpg cn=true]



[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune074"]
[OnName num="suzune"]
五郎這樣的人太沉悶了。
[cpg cn=true]


[OnName num="gorou"]
'不，不。日期有點模糊，但我也一直想慶祝一下'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune075"]
[OnName num="suzune"]
什麼？ "
[cpg cn=true]


[OnName num="gorou"]
'我有一個禮物給你。我回家後要不要打開它？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune076"]
[OnName num="suzune"]
感謝......."
[cpg cn=true]



[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


孩子出生後，我真的很忙。
[cpg]


我是個學生，但我算是個家庭主夫，我必須撫養孩子。
[cpg]


但我不認為這是艱苦的工作。我真的不認為這是必要的或任何東西。
[cpg]


這就是我和我的妹妹......，鈴音的日子是多麼快節奏和可愛。
[cpg]



時間在迅速流逝。而三年已經過去了。
[cpg]




;//========================================
;//●ＣＧ（街を三人で歩く。幸せそうなヒロインと娘の笑顔が正面から見えるアングル）ev_26
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//人物３：主人公の娘
;//服装３：私服
;//場所　：街
;//時間　：昼
;//備考　：娘の年齢は三歳くらいです。また、本編から三年の時間が経過しています
;//========================================




[BGM f="bg_h1"]
;**【ＣＧ】 ev_26_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]




我想，我們成了一對幸福的夫婦。
[cpg]


我沒有和鈴音打過一次架。我們不吵架，我們沒有那種關係。
[cpg]


我們周圍的人羨慕我們，但這是我們之間的自然距離。
[cpg]


我現在不想打架。我們在一起生活的時間比大多數夫妻都長。
[cpg]


我們甚至比一對兒時的朋友更了解對方。
[cpg]


[VOICE f="Suzune319"]
[OnName num="suzune"]
嘿，戈羅。
[cpg cn=true]


鈴音轉向我，微笑著說。
[cpg]


[OnName num="gorou"]
'怎麼了，鈴音？
[cpg cn=true]


[VOICE f="Suzune320"]
[OnName num="suzune"]
'你很高興。我仍然不相信我可以作為你的妻子而感到幸福。
[cpg cn=true]


...... 那是因為我當姐姐的時間比較長。這也是沒辦法的事。
[cpg]


但最終你們會花更大比例的時間作為夫妻。
[cpg]


我必須盡快擺脫當她小弟的命運。我的某些部分把鈴音當成了我的妹妹。
[cpg]


;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

而當我從鈴音的小弟弟畢業時，她可能會有一個妹妹或弟弟。
[cpg]


想到這裡，我們在一條長長的道路上走了出來。
[cpg]



[SCENE id=9]

[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン１ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

