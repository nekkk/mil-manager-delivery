
*start

;###################################################################
*Ep006|珍惜陽光
;###################################################################

;//==============================
;//２、ひまり
*select04_2|珍惜陽光


[SCENE id=6]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


我認為...... 緋紅。雖然可依賴，但並不討人喜歡。
[cpg]


但如果你問我喜歡誰，我喜歡緋紅。
[cpg]


她就像一個孩子，但也有母性。
[cpg]


她有一部分把我玩弄於股掌之間，我已經越來越喜歡她了。
[cpg]


我不知道我是否有欺負人的氣質，喜歡這樣的人。
[cpg]


但我不介意和緋紅在一起。 ......
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[WAIT time=1000]



[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari127"]
[OnName num="himari"]
'One-chan。這是早晨的樂趣！ "
[cpg cn=true]


當我在思考這個問題時，緋紅來了。
[cpg]


[OnName num="gorou"]
'啊，啊。是的。 .......'
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari128"]
[OnName num="himari"]
'怎麼了？你看起來不舒服。
[cpg cn=true]


[OnName num="gorou"]
'不是我心情不好，是......，我需要和你談點事情。
[cpg cn=true]


他重新轉向向日葵。然後他切入正題。
[cpg]


[OnName num="gorou"]
'...... 你知道他們怎麼說嗎，當你愛上一個人時，你的體質就會安定下來？
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari129"]
[OnName num="himari"]
'我知道。我知道醫生是怎麼說的'。
[cpg cn=true]


[OnName num="gorou"]
'那麼，...... 緋紅呢？
[cpg cn=true]


我很謹慎地問道。但緋紅似乎已經猜到了。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari027"]
[OnName num="himari"]
'嗯，是的。如果是和我哥哥一起，我完全沒問題。我想我也會很高興。 ......"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari028"]
[OnName num="himari"]
'如果我們在一起，病情沒有消失，你打算怎麼做？
[cpg cn=true]


[OnName num="gorou"]
'你打算怎麼做？ ......，這當然是令人不安的。
[cpg cn=true]


而我想的是我自己，但緋紅似乎在想一些不同的事情。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Himari132"]
[OnName num="himari"]
'你可能會和其他人欺騙我。有了這樣的憲法，'。
[cpg cn=true]


嗯，我很擔心這個問題，我想.......
[cpg]


[OnName num="gorou"]
'我不會的。我可以向你保證。 "
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari133"]
[OnName num="himari"]
'我不相信。我相當懷疑和妒忌'。
[cpg cn=true]


緋紅來找我，說它不止於此。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari029"]
[OnName num="himari"]
'現在，我給你一個刺激。我們該怎麼做？ "
[cpg cn=true]


[OnName num="gorou"]
'......Oh, please......'
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin_up"  pos="4/7"]

[BG f="b_06_1_up.ui" time=10]
[WAIT time=200]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari030"]
[OnName num="himari"]
'現在我們該怎麼做？我厭倦了用我的手觸摸你。
[cpg cn=true]


[OnName num="gorou"]
即使你說你很無聊......，那麼你要做什麼呢？ "
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari031"]
[OnName num="himari"]
'嗯，今天......，這樣的事情怎麼樣？
[cpg cn=true]


緋紅做了一些不同的事情，說。
[cpg]


;//========================================
;//●ＣＧ（ヒロインに足蹴にされる主人公。からかうような表情のヒロイン）ev_27
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：朝
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]



所以她把她的腳，而不是她的手，貼近我的身體。
[cpg]


我當時想，'你以為我是什麼人？ '但我不能拒絕，因為如果我不喜歡，就會不計後果地結束它。
[cpg]


[VOICE f="sHimari032"]
[OnName num="himari"]
'我不知道。我不知道，大哥哥，我想你從這種事情中得到了刺激。 "
[cpg cn=true]


你不能在這裡表現得像你很高興。另一方面，我也不能勉為其難。
[cpg]


[OnName num="gorou"]
嗯
[cpg cn=true]


[VOICE f="sHimari033"]
[OnName num="himari"]
'你看起來不開心，但我知道你其實很開心。
[cpg cn=true]


[OnName num="gorou"]
'我不高興......，你認為我有什麼樣的個性？
[cpg cn=true]


但他肯定很激動。
[cpg]


;**【ＣＧ】 ev_27_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari034"]
[OnName num="himari"]
'如果這是一個徵兆，我希望你能這麼說。你這麼固執，很可愛'。
[cpg cn=true]


[OnName num="gorou"]
'我並不是說要直言不諱。
[cpg cn=true]


是嗎？她邊說邊看著我的反應。
[cpg]


[VOICE f="sHimari035"]
[OnName num="himari"]
我認為刺激來自於不尋常的情況。
[cpg cn=true]


對於這個問題，緋紅是如何想出這些東西的？
[cpg]


[OnName num="gorou"]
緋紅一直在考慮...... 這些事情。 "
[cpg cn=true]


;**【ＣＧ】 ev_27_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari036"]
[OnName num="himari"]
'嗯？總是這樣嗎？ "
[cpg cn=true]


[OnName num="gorou"]
所以，即使你沒有看到我。
[cpg cn=true]


[VOICE f="sHimari037"]
[OnName num="himari"]
'我不知道，我不知道...' 這只是我想到的一個想法。 "
[cpg cn=true]


緋紅邊說邊用腳摸索著我的胸甲。
[cpg]


這不是怕癢或什麼。但這感覺很奇怪，是不道德的。
[cpg]


然而，我沒有做任何討厭的事情。 ......。
[cpg]


[VOICE f="sHimari038"]
[OnName num="himari"]
'你更喜歡哪一個，你的手還是你的腳，大哥哥？
[cpg cn=true]


[OnName num="gorou"]
什麼，這個問題？
[cpg cn=true]


他問了我一些很奇怪的問題，我無法保持冷靜。
[cpg]


我無法直視他。緋紅看穿了這一點。
[cpg]


;**【ＣＧ】 ev_27_b ***********************
[CG id=12 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari039"]
[OnName num="himari"]
'別裝傻了，我正在努力決定下一步為你做什麼。
[cpg cn=true]


[OnName num="gorou"]
'......'
[cpg cn=true]


你說了那麼多，我甚至無法回答。
[cpg]


我擔心如果我說腳，他們現在會對我做什麼，如果我說手，他們就會停止現在做的事情。
[cpg]


[VOICE f="sHimari040"]
[OnName num="himari"]
'嗯，好的。從現在開始，我也要讓你在晚上感受到這種刺激。
[cpg cn=true]


當我在思考這個問題時，緋紅說了一句更令人驚訝的話。
[cpg]


她表現得非常積極。這又不是我要求她做的。
[cpg]


[OnName num="gorou"]
'誒，...... 可以嗎？
[cpg cn=true]


[VOICE f="sHimari041"]
[OnName num="himari"]
'不是我不介意，更多的是我想讓它屬於我自己。你媽媽也會給你的。我確定'。
[cpg cn=true]


他們把你當做一個東西，好像你都是自己的，或者你把它送人。
[cpg]


但我也很高興，或者說我覺得我可以感受到緋紅對我的愛。
[cpg]




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


觸摸她之後，痛苦的時間又回來了。
[cpg]


但是，我可以在中午看到我的姐姐，此外，她還說，緋紅會在晚上為我做。 ......
[cpg]


相信這一點，我只得暫時忍耐。
[cpg]


[window target=false]


[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************



[SE f="se000"]
;//【ＳＥ】『歩く』





走在街上。一路走到學院。
[cpg]


同時，它仍然沒有那麼痛苦。但當上午的課程即將結束時，這是最困難的。
[cpg]


到午休前的時間，或者說，那是你必須為......，無論你怎麼想。
[cpg]




[window target=false]


[STOPBGM]

[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************





[OnName num="male_student"]
'嘿，小坂。我聽說你前幾天和一個女孩在一起散步。
[cpg cn=true]


[OnName num="gorou"]
'什麼？嗯，情況並非總是如此。 ......"
[cpg cn=true]


[OnName num="male_student"]
別裝傻了! 你說你和一個女孩手拉手，她都在你身上。 "
[cpg cn=true]


[OnName num="gorou"]
你在說什麼呢？我不認識任何與我關係那麼好的女孩。 ......"
[cpg cn=true]


哦，他來了。緋紅。也許有人在她離開房子時看到了她或其他東西。
[cpg]


但如果是這樣，很明顯，她是我的妹妹。
[cpg]


[OnName num="gorou"]
這是我的妹妹。她的名字叫小坂緋紅。
[cpg cn=true]


[OnName num="male_student"]
'哦，啊......，所以她是你的妹妹。所以她不是你的女朋友或什麼？
[cpg cn=true]


[OnName num="gorou"]
'...... 是的。是的，不是女朋友。 "
[cpg cn=true]


...... 一般來說，妹妹不是愛人。
[cpg]


我瘋了，不是嗎？我必須被提醒這一點。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



;//その後、昼休みになって姉さんに抜いてもらった。
;//＠
後來，在午餐時間，我讓我姐姐提高我的心率。
[cpg]


事後。我姐姐說了這樣的話。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune321"]
[OnName num="suzune"]
'嘿。你喜歡緋紅嗎？也許是某種形式的懺悔？ "
[cpg cn=true]


[OnName num="gorou"]
'......，你知道我的意思嗎？
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune322"]
[OnName num="suzune"]
'我可以看到。緋紅早上離開你的房間時，臉上有一種嚴肅的表情'。
[cpg cn=true]


這就是你在看的東西。我猜她有點像個鑑賞家，或者她很有姐妹情誼。
[cpg]


[OnName num="gorou"]
如果你指的是懺悔，你是否做了......？ "
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune323"]
[OnName num="suzune"]
'我不認為我有，沒有。你需要承擔適當的責任'。
[cpg cn=true]


;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



我姐姐教訓我，我感覺很微妙。
[cpg]


我喜歡緋紅。毋庸置疑。
[cpg]


但當我想到我是否正確面對緋紅時，就很難說了。
[cpg]


她害怕作弊。考慮到我的體質，這很自然。
[cpg]

;//＠妊娠しても体質が治らなかったらと考えるのは、当然かもしれない。
可能會很自然地想到，即使我的愛得到滿足，如果我的體質沒有得到治愈。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************



[OnName num="gorou"]
'我回家了: ......'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari153"]
[OnName num="himari"]
'歡迎回來，兄弟。我們可以嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'做，有點太快了......？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari042"]
[OnName num="himari"]
'你必須適應我的心情。你的兄弟沒有權利選擇。
[cpg cn=true]


就這樣，他們強迫我，把我的手拿走了。
[cpg]


而我被帶到了緋紅的房間。 ......
[cpg]



;//========================================
;//●ＣＧ（主人公に顔を近づけるヒロイン。キスをする）ev_28
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]



她是在近距離。我無法直視她。
[cpg]


但當我把目光移開時，緋紅指出了這一點。
[cpg]


[VOICE f="sHimari043"]
[OnName num="himari"]
'別看了。再仔細看看我。 "
[cpg cn=true]


當你說這樣的話時，它只是讓我緊張。
[cpg]


[OnName num="gorou"]
'...... 是的。
[cpg cn=true]


我現在沒有選擇，只能點頭。我沒有膽量在這裡拒絕。
[cpg]


但我也沒有膽量接受它。
[cpg]


;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari044"]
[OnName num="himari"]
我不知道該怎麼做。你將永遠是一個新手。
[cpg cn=true]


像往常一樣，緋紅的臉皮相當厚。
[cpg]


如果她像她一樣隨和，也許我就不會有這種憲法了。 ......
[cpg]


[OnName num="gorou"]
'你不能幫助它。 ...... 如果你不再激動，那就是一個問題。
[cpg cn=true]



我很害怕，緋紅比平時更接近，說。
[cpg]


[VOICE f="sHimari045"]
[OnName num="himari"]
'從那時起，我就想知道什麼讓你最緊張。
[cpg cn=true]


緋紅看著我，給了我一個計謀性的微笑。
[cpg]


在這麼遠的地方有這麼漂亮的女孩，真讓人激動。
[cpg]


但緋紅仍然看起來想做什麼。
[cpg]


[OnName num="gorou"]
'，你是如此接近。
[cpg cn=true]


;**【ＣＧ】 ev_28_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari046"]
[OnName num="himari"]
'現在說這個有點晚了，不是嗎？你以前做了那麼多事情，你還害怕只是接吻嗎？ "
[cpg cn=true]


我不敢說這件事，但緋紅說了。
[cpg]


我知道她要吻我。
[cpg]


[OnName num="gorou"]
'......，對我好一點。
[cpg cn=true]


[VOICE f="sHimari047"]
[OnName num="himari"]
'我說得像個女孩，漂亮~'
[cpg cn=true]


如果發生這種情況，我想我只能準備好自己。我就是這麼想的，然後閉上了眼睛。 ......
[cpg]


;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari048"]
[OnName num="himari"]
'呵。漂亮的臉蛋。 "
[cpg cn=true]


然後她就沒有再吻我。
[cpg]


我睜開細長的眼睛，看著希瑪莉。
[cpg]


[VOICE f="sHimari049"]
[OnName num="himari"]
'我想我會用我的手機拍下我弟弟的吻臉...'
[cpg cn=true]


[OnName num="gorou"]
'做，你是什麼意思？
[cpg cn=true]


[VOICE f="sHimari050"]
[OnName num="himari"]
'你想讓我吻你嗎？那我希望你能這麼說。
[cpg cn=true]


[OnName num="gorou"]
'...... 有時緋紅看起來像一個惡魔。
[cpg cn=true]


[VOICE f="sHimari051"]
[OnName num="himari"]
'你是說惡魔般的類型？我真為你感到高興。 "
[cpg cn=true]


緋紅笑著說。但對於懸浮在半空中的我來說，它看起來仍然像魔鬼的微笑。
[cpg]


[VOICE f="sHimari052"]
[OnName num="himari"]
'那麼，你是怎麼想的？我想讓你吻我。 "
[cpg cn=true]


[OnName num="gorou"]
這是......."
[cpg cn=true]


在我說這句話的時候，她給了我一個不可抗拒的眼神，並把她的嘴唇送到我的面前。
[cpg]


;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト


;**【ＣＧ】 ev_28_b ***********************
[CG id=13 index=2 time=1000]
;***************************************
[WAIT time=1000]

我們的嘴唇互相接觸。這是一個輕柔的吻，但感覺我們終於越過了界限。
[cpg]



;//ＣＧ再び表示

;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]

然後我們拉開距離。我們不再只是兄弟姐妹。
[cpg]


[VOICE f="sHimari053"]
[OnName num="himari"]
'...... 大哥哥，你真的很可愛。
[cpg cn=true]


當他對我說這句話時，我可以感覺到我的臉越來越熱。
[cpg]


我沒有想到，被告知我很漂亮會讓我如此緊張和......。
[cpg]


我也沒有想到這個吻本身會有這樣的感覺。
[cpg]


[VOICE f="sHimari054"]
[OnName num="himari"]
'那好吧。我會把接吻推遲一段時間，我不想讓你通過正常的皮膚關係失去刺激。 "
[cpg cn=true]


我覺得我的臉都紅了。我認為這更像是因為另一邊的緋紅也在臉紅。
[cpg]


我想知道從現在開始我們會有什麼樣的關係......。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


要記住的最重要的事情是，你不應該害怕尋求幫助。
[cpg]


我感覺我無法入睡，但我比這更高興。
[cpg]


我想知道緋紅是否處於類似的心理狀態......，但我不能確定。
[cpg]


一段時間後，在星期六。
[cpg]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の家＿玄関』（昼）******************************************************



當時我剛從醫院回來。
[cpg]


我和我媽媽去了那裡，我被告知了一些事情，有點......，令人震驚。
[cpg]




;//ブラックアウト


[window target=false]


[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Himari173"]
[OnName num="himari"]
'歡迎回來。情況如何？ "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Sawa105"]
[OnName num="sawa"]
'事情是這樣的--......，這有點，有點大材小用。
[cpg cn=true]


我必須告訴你細節，不是嗎？這不是我要讓我母親告訴我的事情。
[cpg]


[OnName num="gorou"]
'......，他們說有一種藥可以治好我的病。但是。 "
[cpg cn=true]


[OnName num="gorou"]
'他說，他非但沒有治好自己的病，反而會對愛情失去興趣。
[cpg cn=true]


簡而言之，我們談論的是失去了激動人心的願望。
[cpg]


如果你不再想與任何人相愛，這是一個關於...... 人的生命的故事。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
緋玉和她姐姐的表情變得陰晴不定。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune324"]
[OnName num="suzune"]
'醫生也會說可怕的事情，......，如果他們說這樣的話，你只會變得更加焦慮。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

是的，沒錯。但是，希瑪里沉默不語，也許想的是不同的。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

而我和緋紅單獨在一個房間裡。
[cpg]


緋紅闖入我的房間。
[cpg]


她想談點什麼，或者說，我也想和她談點什麼。
[cpg]


[OnName num="gorou"]
'......，你怎麼看。關於如何治療你的體質'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari055"]
[OnName num="himari"]
'這很好。沒什麼，我想如果我這樣做就可以了'。
[cpg cn=true]


[OnName num="gorou"]
'嗬，說真的! 因為......，如果我吃了藥，我相信我也不會對緋紅有什麼想法。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari175"]
[OnName num="himari"]
'如果我哥哥不欺騙我，我還是會喜歡的。但......."
[cpg cn=true]


緋紅在說這句話時顯得有些尷尬。和......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari056"]
[OnName num="himari"]
'如果我可以，我也希望你仍然是你一直以來的兄弟，只是你的體質會被治愈。
[cpg cn=true]


...... 我明白了。緋紅是這樣想的嗎？
[cpg]


正如醫生所說，你和緋紅應該走到一起，你的體質應該穩定下來。
[cpg]


那是最好的狀態。但如果憲法沒有安頓下來，那麼......
[cpg]


也許我將被剝奪愛本身的權利。
[cpg]


即使有這樣的決心，我還是要和緋紅出去。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari057"]
[OnName num="himari"]
'嘿。你也準備好了，不是嗎，大哥哥？
[cpg cn=true]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト



[window target=true]


緋紅走近。她試圖吻我。 ......
[cpg]


我開始有點不耐煩了。我知道我也想和緋紅做愛。
[cpg]


[window target=false]

[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





時間在流逝，再過一會兒就到了吃晚飯的時間。
[cpg]



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari058"]
[OnName num="himari"]
快到吃晚飯的時間了。我們很快就可以走了嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'......'
[cpg cn=true]



我覺得我可以多和緋紅接觸，看看她的體質是否穩定下來。
[cpg]


但是，如果我太倉促，緋紅會不會變得幻滅，而愛情本身也會沒有結果？
[cpg]


經過思考，我想出了一個答案。
[cpg]


;//■選択肢
[switch]
[case "我將會更加接近緋紅，即使我必須要稍微推動一下自己。"]
	[swap]
	[jump target="*select05_1"]
[case "慢慢來，別著急"]
	[swap]
	[jump target="*select05_2"]
[endswitch]

1.更接近Himaru，即使有點不知所措
2，慢慢來，不要著急。



;//==============================
;//１、多少無理してもひまりに近づく
*select05_1|珍惜緋紅。




[OnName num="gorou"]
'再和我們呆一會兒吧。 緋紅"。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sHimari059"]
[OnName num="himari"]
但食物是......"
[cpg cn=true]


[OnName num="gorou"]
'快走吧! 如果你繼續這樣下去，你無法真正治愈你的體質。 "
[cpg cn=true]



[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari060"]
[OnName num="himari"]
'...... 是的。好吧，如果你堅持這麼說的話。
[cpg cn=true]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ブラックアウト


[window target=true]

就這樣，與緋紅的日子繼續著。但在幕後，不適感也在不斷累積。
[cpg]


緋紅怎麼會看到我著急呢？
[cpg]


如果我嚇到她或讓她感到不舒服，哪怕是一點點，那就不好了。
[cpg]


甚至"我不擅長這個"的感覺也再次變成了不耐煩。
[cpg]


;//移植前シーンカット


[window target=false]
[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari061"]
[OnName num="himari"]
'嘿，兄弟。你不應該得到我所說的待遇嗎？ "
[cpg cn=true]


[OnName num="gorou"]
為什麼......，我喜歡緋紅？ "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari062"]
[OnName num="himari"]
'是的，但也許是你的體質使你認為你喜歡我。
[cpg cn=true]


[VOICE f="sHimari063"]
[OnName num="himari"]
'如果你不捶打，你就無法呼吸。我以為你愛上了我，因為你想搗蛋。
[cpg cn=true]


面對我的不耐煩，向日葵開始質疑她是否真的被愛。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（昼）******************************************************





然後，緋紅逐漸開始對我採取冷漠的態度。
[cpg]


但我的體質還很好，所以我和緋紅的關係很苦。
[cpg]


[OnName num="gorou"]
'該死，我很痛苦，...... 緋紅!
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari064"]
[OnName num="himari"]
'我不知道該怎麼做。我沒有心情'。
[cpg cn=true]



[window target=false]

[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『街』（夜）******************************************************



諷刺的是，在我痛苦的時候，緋紅對我產生了興趣。
[cpg]


也許她一直都有這種氣質。
[cpg]



我只能想像，但......，我有一種感覺，她確實如此。
[cpg]


[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト


緋紅不再向我靠近。她不能再做捶打，而我還在痛苦中。
[cpg]


它是如此痛苦，以至於有一天晚上我甚至無法入睡.......。
[cpg]


;//========================================
;//●ＣＧ（寝ている主人公に寄り添うヒロイン。サディスティックな感じ）ev_30
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="gorou"]
'哈，哈......，緋紅？
[cpg cn=true]


她來到了我的房間。我已經等了她很久了，我覺得我現在就想擁抱她。
[cpg]


但我無法呼吸，也無法起身。
[cpg]


無論她是否知道我處於這種情況，她都說。
[cpg]


[VOICE f="sHimari065"]
[OnName num="himari"]
'也許我想一直看著我痛苦的弟弟......。
[cpg cn=true]


他一邊笑著一邊說著殘酷的事情。
[cpg]


我不能呼吸，我一直不能呼吸，呼吸太難了，如果不呼吸，我真的會死。
[cpg]


[OnName num="gorou"]
'緋紅......，請到我身邊來。
[cpg cn=true]


;**【ＣＧ】 ev_30_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari066"]
[OnName num="himari"]
'我想知道我應該怎麼做？我哥哥現在有點太絕望了，也許我不想和他親近。 "
[cpg cn=true]


緋紅以她一貫的語氣平靜而輕蔑地說道。
[cpg]


[OnName num="gorou"]
'桑尼，緋紅並不關心我發生了什麼。
[cpg cn=true]


[VOICE f="sHimari067"]
[OnName num="himari"]
'......，這很難，大哥哥。你已經變得如此依賴搗蛋了'。
[cpg cn=true]


依靠緋紅而不是Dokidoki，我叫她的名字。
[cpg]


[OnName num="gorou"]
'緋紅......，哦，緋紅，緋紅！ '
[cpg cn=true]


[VOICE f="sHimari068"]
[OnName num="himari"]
'怎麼了？你想從我這裡得到什麼，叫我那麼多？ "
[cpg cn=true]


管它呢，這很明顯。
[cpg]


[OnName num="gorou"]
'請...... 搗毀我。如果你不這樣做，這是在你的憲法中。 ......
[cpg cn=true]


[VOICE f="sHimari069"]
[OnName num="himari"]
憲法，嗯？對。 "
[cpg cn=true]


;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari070"]
[OnName num="himari"]
'嘿。實際上，我正在接受一些藥物治療，以治愈我的病情。 "
[cpg cn=true]


[OnName num="gorou"]
什麼？ "
[cpg cn=true]


有一瞬間，我不明白希瑪里在說什麼。
[cpg]


但我昏昏沉沉的腦袋漸漸開始明白了。
[cpg]


[VOICE f="sHimari071"]
[OnName num="himari"]
'我想，也許我的兄弟不會想自己喝酒。但現在你在痛苦中，你確實想喝酒'。
[cpg cn=true]


[OnName num="gorou"]
'哦，不......，只要緋紅能靠近我，那就足以幫助我呼吸了。
[cpg cn=true]


我想我是自私的。但我忍不住說了出來。
[cpg]


這就是它的痛苦之處。不僅是我的呼吸，而且我的心臟也在受苦。
[cpg]


;**【ＣＧ】 ev_30_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari072"]
[OnName num="himari"]
'這只是暫時的，不是嗎？你必須一直讓我在你身邊，這是不健康的。
[cpg cn=true]


[OnName num="gorou"]
但是！ "
[cpg cn=true]


緋紅從頭到尾都顯得有些驚慌失措。
[cpg]


我越是絕望，越是適得其反。儘管我知道，但我還是忍不住不耐煩了。
[cpg]


[VOICE f="sHimari073"]
[OnName num="himari"]
'我想知道這些藥丸裡有什麼？它是否會減少睾丸激素？ "
[cpg cn=true]


[VOICE f="sHimari074"]
[OnName num="himari"]
'那你就可以知道為什麼我對浪漫失去了興趣。我想這也會讓我對沒有心跳的感覺好起來。
[cpg cn=true]


緋紅說著可怕的事情。我真的要放下這份愛嗎？
[cpg]


光是想像我不能愛上緋紅就很難。但呼吸更困難了。
[cpg]


[OnName num="gorou"]
'Kuu...... 痛苦，緋紅，幫助我。
[cpg cn=true]


看到我痛苦的樣子，緋紅似乎並不著急。
[cpg]


[OnName num="gorou"]
'我應該怎麼做......，我做了什麼讓你這麼恨我？
[cpg cn=true]


;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari075"]
[OnName num="himari"]
'沒事的。我不恨你。儘管我的哥哥已經中立了，但我仍然喜歡他。
[cpg cn=true]


她用平靜、溫和的語氣說著可怕的事情。
[cpg]


[VOICE f="sHimari076"]
[OnName num="himari"]
'也許到時候我會把你當做一個裝扮的娃娃來玩？
[cpg cn=true]


[OnName num="gorou"]
'那個，啊，那個.......'
[cpg cn=true]


這種愛，已經嗤之以鼻。緋紅有些樂在其中。
[cpg]


而我，則沒有時間去享受它。
[cpg]


我沒有想到......，最後會變成這樣。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



......，怎麼會變成這樣？
[cpg]


儘管我很後悔，但最後我的呼吸還是很痛苦。
[cpg]


為了逃避痛苦，我吃了藥。
[cpg]


[OnName num="gorou"]
'哈哈，哈哈......，緋紅。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari077"]
[OnName num="himari"]
'這就對了。你太有魄力了，大哥哥，你嚇到我了。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari078"]
[OnName num="himari"]
現在我的兄弟是我的，也是我一個人的。 ......
[cpg cn=true]


說到這裡，緋紅拍了拍我的頭。對此，我不再感到激動。
[cpg]


[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ブラックアウト



我的搗蛋真的是由緋紅管理的。
[cpg]


我的心已經被鎖住了。 ......
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*back_title"]
;//ＥＮＤ：バッドエンドルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================
;//２、ゆっくり慣らしていこう
*select05_2|珍惜緋紅。




[OnName num="gorou"]
'......，我同意。
[cpg cn=true]




緋紅可能是困難的。我不想讓她看到我太著急了。
[cpg]


相反，我想照顧好...... 緋紅。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



之後，在我們吃完晚飯後，緋紅就來到了我的房間。
[cpg]


她說她不希望看到我受苦。
[cpg]


通過不從我這邊要求太多，緋紅從我這邊要求了。 ......
[cpg]



[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari079"]
[OnName num="himari"]
'我希望我可以......，做點什麼。醫生說，如果你墜入愛河，你就會痊癒，對嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'嗯，差不多就是這樣的情況。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari080"]
[OnName num="himari"]
'它是蓬鬆的，不是嗎？愛有什麼關係呢？
[cpg cn=true]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_h1"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



比如說。你不是在談論簡單的結婚或類似的事情。
[cpg]

即使是這樣，我也不想倉促行事。我不想強迫緋紅做任何事情。
[cpg]


[window target=false]


[STOPBGM]

[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



但似乎緋紅在我之前就下定了決心。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari229"]
[OnName num="himari"]
'...... 你知道嗎？如果事情繼續這樣下去，它不會很快結束，對嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'沒有必要急於求成。讓我們慢慢來吧....... 緋紅？ "
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari081"]
[OnName num="himari"]
'更多偉大的事情，我會為你做。即使你哥哥不願意，我也會。
[cpg cn=true]


[OnName num="gorou"]
'......，要溫柔。
[cpg cn=true]



我從來沒有厭惡過它。但我認為如果我要求的話，就不會發生這種情況。
[cpg]


我真的以為愛情是一種奇怪的東西。
[cpg]


;//ブラックアウト

;//移植前シーンカット


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



緋紅和我花了一天時間進行適度的調情。
[cpg]


我們甚至在路上去餐廳吃飯。 ......。
[cpg]




;//ブラックアウト


[window target=false]



[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari247"]
[OnName num="himari"]
'謝謝你的食物。那麼，大哥哥，我們回你的房間去吧。
[cpg cn=true]


[OnName num="gorou"]
'這太明目張膽了，......'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari248"]
[OnName num="himari"]
'時間是有限的，我們不能磨磨蹭蹭。
[cpg cn=true]

[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa106"]
[OnName num="sawa"]
'咯咯笑。你們真的很親密......'
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



然後他們回到自己的房間，進行了一場黏稠的調情。

[cpg]


在做這些的時候，我們甚至談到了一起睡在被褥上。 ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari249"]
[OnName num="himari"]
'嘿，這很好。也許人們已經知道了。 "
[cpg cn=true]


[OnName num="gorou"]
我知道。 ...... 那麼好吧。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari250"]
[OnName num="himari"]
'知道了。和我弟弟睡覺。 "
[cpg cn=true]


看到緋紅這樣，我覺得她仍然是我的小妹妹。
[cpg]


儘管我真的想做她的情人。在那裡，它將不可避免地成為一個中間地帶。
[cpg]


她是我的妹妹，但她是我的愛人。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=1000]

然後我們倆依偎在一起，進入了夢鄉。 ......
[cpg]


激動但鬆了一口氣。這個詞再次出現在我的腦海中，因為我已經想了很多次。
[cpg]


我認為那是一段快樂的時光。這感覺就像是對我和緋紅之間的愛情的確認。
[cpg]


如果當時我很著急，緋紅體內的感情可能會冷卻下來。
[cpg]


當然，會有一個與現在不同的未來。
[cpg]


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari251"]
[OnName num="himari"]
"嗯 ...... 困了 ......"
[cpg cn=true]


緋紅先醒過來，搖晃著我。
[cpg]


現在已經是工作日了嗎？我必須要去學院。 ......
[cpg]


但現在的時間還很早。有什麼計劃？
[cpg]


[OnName num="gorou"]
'現在不是早......嗎？如果你困了，為什麼不回到床上去？ "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari082"]
[OnName num="himari"]
'不'。你在試圖治療你的體質。
[cpg cn=true]


[OnName num="gorou"]
......，你是對的。 "
[cpg cn=true]


如果我不花一點時間和你在一起，我的體質就不會穩定下來。
[cpg]


即使是這樣，我認為也不必在這麼早的時候。 ......
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_06_1_up.ui" time=1000]
[WAIT time=2000]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sHimari083"]
[OnName num="himari"]
'嘿，讓我們接吻吧。我還沒有刷牙。 "
[cpg cn=true]


[OnName num="gorou"]
'這是不衛生的。 ......'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari084"]
[OnName num="himari"]
'如果你想想你的身體，如果你不吻它，你會更痛苦。
[cpg cn=true]


...... 的確如此。
[cpg]



;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



快樂的時光很快就會過去。我必須要去上學。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari085"]
[OnName num="himari"]
嗯。 ......，我希望我的早晨能長一點。 "
[cpg cn=true]


[OnName num="gorou"]
'我想我只能早起了？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari086"]
[OnName num="himari"]
'那會使夜晚變得更短，不是嗎？
[cpg cn=true]



;//ブラックアウト



沒有緋紅的日子越來越難熬了。
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『学園教室』（昼）******************************************************





不出所料，到了中午時分，我已經搖搖晃晃了。
[cpg]


我想過要去我姐姐那裡，但我還是忍住了。
[cpg]


一般來說，如果我不斷地重複這樣的日子，我的體質就會及時地穩定下來。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************





時間過去了。特別是......
[cpg]


足夠的時間過去了，我不需要再扑騰了，也不需要再用力呼吸了。
[cpg]


與緋紅的關係在家裡已經完全暴露。
[cpg]


我向父親解釋了很久，但他終於承認了。
[cpg]



;//ブラックアウト


[window target=false]

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari087"]
[OnName num="himari"]
'你哥哥要做你的丈夫，對嗎？
[cpg cn=true]


[OnName num="gorou"]
如果你這樣說的話，那麼緋春也是你的妻子。 "
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari088"]
[OnName num="himari"]
'嘿嘿。很高興聽到這個消息'。
[cpg cn=true]



直到最近，她還只是一個小妹妹。我暈頭轉向的日子開始......
[cpg]



;//ブラックアウト


[window target=false]

[STOPBGM]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


我已經有了一份工作，我將在春天開始工作。
[cpg]


緋想盡快結婚，所以為了所謂的學校而學習是不夠的。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari272"]
[OnName num="himari"]
'我進來了，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'哦，緋紅......，怎麼了？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari089"]
[OnName num="himari"]
'你哥哥的體質最近已經穩定下來了，是嗎？這就是為什麼......，我想念你。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari090"]
[OnName num="himari"]
'我不知道......，我想靠近我哥哥。
[cpg cn=true]


[OnName num="gorou"]
'是的。我也這麼認為。這與敲打沒有關係'。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari091"]
[OnName num="himari"]
'我喜歡我的...... 弟弟的這一點。你把我當回事。
[cpg cn=true]


[OnName num="gorou"]
'真的嗎？我覺得我很輕浮。 "
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari092"]
[OnName num="himari"]
'但你不像我這麼輕浮，是嗎，大哥？
[cpg cn=true]




...... 緋紅稱我為她的大哥哥。
[cpg]


我希望她現在不要再這樣叫我了，但......，緋紅很難改變。
[cpg]



[OnName num="gorou"]
'你知道嗎？如果你要結婚，你可以改變你對我的稱呼。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari293"]
[OnName num="himari"]
'連你的哥哥都叫你姐姐。
[cpg cn=true]


這完全無關緊要。我和我妹妹沒有任何關係。
[cpg]



[OnName num="gorou"]
這是一派胡言。 ......，這是行不通的。 "
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari294"]
[OnName num="himari"]
'沒關係的。我再不說就不行了，所以現在就說'大哥'吧。
[cpg cn=true]



對，這就是我的意思。那麼我可以理解，為什麼他們不能這樣說呢？
[cpg]

;//ブラックアウト
;//移植前シーンカット
;//移植前シーンカット

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



就這樣，我和緋紅的日子一直在繼續。
[cpg]


這讓人頭暈目眩。然後，當我們終於結婚時：......
[cpg]


;//========================================
;//●ＣＧ（椅子に座って、編み物をするヒロイン。おなかは膨らんでいない形にしてください）ev_35
;//人物１：ヒロイン２
;//服装１：私服
;//場所　：主人公の家＿リビング
;//時間　：朝
;//備考　：元のＣＧと違って、おなかは膨らんでいない形にしてください
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


有人看到緋紅在客廳裡織毛衣。
[cpg]


我不認為她是一個狡猾的人，但我不知道她是否有這樣的愛好。
[cpg]


[OnName num="gorou"]
'......，我不記得她會編織。
[cpg cn=true]



緋紅搖了搖頭。我知道，我從未見過她這樣做。
[cpg]


[OnName num="gorou"]
[OnName num="gorou"]
'我不能做的時候就做。
[cpg cn=true]


[VOICE f="Himari315"]
[OnName num="himari"]
'你將能夠。 '因為我知道會有一些日子，你會感到無聊。
[cpg cn=true]


你和我有這樣的對話。也許他們正在談論生孩子的問題。
[cpg]


我不需要再問了。而在這一天，我聽到了我一直期待的話語。
[cpg]


;//;**【ＣＧ】 ev_35_a ***********************
;//[CG id=15 index=1 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="sHimari093"]
[OnName num="himari"]
'從現在開始留在我身邊，戈羅。
[cpg cn=true]


他叫我戈羅。我感覺自己的胸口被打了一拳。
[cpg]


在這一刻，我已經從一個單純的大哥哥畢業了。
[cpg]


這並不公平。緋紅用她的稱呼迷惑了我，但我對此無能為力。
[cpg]


[OnName num="gorou"]
'...... 是的。 緋紅"。
[cpg cn=true]


我別無選擇，只能叫緋紅為緋紅。但總有一天，我會叫她媽媽。
[cpg]


你叫我五郎的時間會很短。
[cpg]


但這也沒關係。這就是我的快樂。 ......
[cpg]


我哥哥成為父親的日子在我眼前漸漸逼近。
[cpg]


我只是很高興。
[cpg]



;//ブラックアウト

不是作為她的兄弟，而是作為她的情人，就在身邊。
[cpg]


你不是每天都能成為曾經的兄弟和現在的女友。
[cpg]


我有一種感覺，從現在開始我就會很興奮，有一天我也想讓Himaru有同樣的感覺。
[cpg]


她的性格相當強勢，所以我可能很難做點什麼。 ......
[cpg]


我想感到興奮，我想讓他們感到興奮。我有這樣一個共同的愛人的願望。
[cpg]





;//ブラックアウト

[SCENE id=10]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン２ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


