
*start
;//あねいもままの射精管理　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//寿々音　裸　私服　スーツ
;//ひまり　裸　私服　制服
;//砂羽　　裸　私服

;//以下音声なし
;//吾郎 父親 男子学生Ａ 男子学生Ｂ
;//医者 女子学生 女子学生Ａ 女子学生Ｂ 男子学生
;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//寿々音　一人称「私」　ひまり呼び「ひまり」　砂羽呼び「お母さん」　吾郎呼び「吾郎」
;//ひまり　一人称「私」　寿々音呼び「お姉ちゃん」　砂羽呼び「お母さん」　吾郎呼び「お兄ちゃん」
;//砂羽　一人称「私」　寿々音呼び「寿々音」　ひまり呼び「ひまり」　吾郎呼び「吾郎」
;//吾郎　一人称「俺」　寿々音呼び「姉さん」　ひまり呼び「ひまり」　砂羽呼び「母さん」


;###################################################################
*Ep000|神秘的憲法。
;###################################################################

[SCENE id=0]


[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[stflag jump_scene=1]


;///////////////////////////ここからが本編です///////////////////////////



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_me"]
;//ブラックアウト





當我還很年輕的時候。
[cpg]


我的媽媽和爸爸在一次事故中去世。我當時還是個孩子，所以我並不真正知道發生了什麼事。
[cpg]


我記得我也在哭，因為我周圍的人都在哭，這讓我莫名地害怕。
[cpg]


我認為失去父母的真正悲痛是在更遠的地方。
[cpg]


我的一個遠房親戚薩瓦-高坂也參加了葬禮。她現在是我的母親，我的岳母。
[cpg]


我想這也是我第一次見到我的嫂子，鈴音。
[cpg]



;//下記寿々音のセリフは子供の頃の声です






[VOICE f="Suzune001"]
[OnName num="suzune"]
...... 不要哭。你在天堂的母親和父親也會哭泣。
[cpg cn=true]


我想我當時甚至沒有理解他的大部分意思。
[cpg]


我想我姐姐當時是出於好意。
[cpg]


她甚至在忍耐即將到來的淚水。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我的家庭包括我的母親和父親，我的姐姐鈴音和我的妹妹緋紅。而我是被收養的，所以我們有五個人。
[cpg]


沒有一個人與我有血緣關係。我想我與他們有一點關係，但我與緋紅和她的妹妹的關係比我與我的堂兄弟姐妹的關係更遠。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari001"]
[OnName num="himari"]
'哦，我不想去學校。 ......，這是五月的病，不是嗎？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune002"]
[OnName num="suzune"]
'現在已經是六月了。別傻了'。
[cpg cn=true]


緋紅和她的妹妹正在進行這樣的對話。我也有點呆滯。
[cpg]


[OnName num="gorou"]
'我知道這是低氣壓的影響，這......'
[cpg cn=true]

[free time=1000]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa001"]
[OnName num="sawa"]
'咯咯笑。 '但他們說低壓對你有好處！ '
[cpg cn=true]


[OnName num="gorou"]
'真的......？我從來沒有聽說過。 "
[cpg cn=true]


[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune003"]
[OnName num="suzune"]
'我也聽說了。你知道，壽命長的地方氣壓都很低'。
[cpg cn=true]


我不知道。不過我有點懶。
[cpg]


[OnName num="gorou"]
"懶惰會增加你的預期壽命還是......？"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari002"]
[OnName num="himari"]
'那我就會活得更久，因為我每天都很懶惰。嘆氣，我不想去'。
[cpg cn=true]


爸爸已經在工作了，我們卻在進行這種愚蠢的談話。
[cpg]


沒有什麼成果，如果有的話，只是獲得一點瑣事。 ......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************





我姐姐是我所在學校的老師。
[cpg]


所以她當然比我更早離開家。問題是我和緋紅。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Himari003"]
[OnName num="himari"]
'......，我們不是有六月病嗎？我想就是這樣了。 "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa002"]
[OnName num="sawa"]
'我不知道。即使有，我也不認為緋紅會有什麼不同。 "
[cpg cn=true]


[OnName num="gorou"]
'對。它太慢性了，不可能是一種疾病，你知道。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Himari004"]
[OnName num="himari"]
我不知道這是否符合憲法。 ......
[cpg cn=true]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]

[window target=true]


憲法》。是的，這是一個關於憲法的故事。
[cpg]


我過去是，現在仍然是，受到某種體質的影響。
[cpg]




;//ブラックアウト


[window target=false]




[BG f="b_01_1.ui" time=1000]
[WAIT time=1500]


[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





我一邊想，一邊走在與緋紅不同的路上。
[cpg]


有許多方法可以用一個詞來表達憲法。早上難以醒來，對酒精的高度容忍和憤怒也是構成因素。
[cpg]


在這樣的情況下，我已經形成了一種"搗蛋的依賴"。
[cpg]


我最喜歡的漫畫是一部浪漫的喜劇。我最喜歡的動畫片也是一部愛情喜劇。我最喜歡的音樂是偶像們唱的情歌。
[cpg]


這很令人尷尬，但我不能沒有這種東西。 ......
[cpg]


我渴望得到一種叫做"搗蛋"的東西。我甚至不知道我怎麼會變成這樣。
[cpg]


[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[WAIT time=2000]

;//========================================
;//●ＣＧ非エロ（授業をするヒロイン１。黒板に背を向けて本を手に持っている）ev_01
;//人物１：ヒロイン１
;//服装１：スーツ
;//場所　：学園教室
;//時間　：昼
;//========================================


[WAIT time=1000]
[BGM f="bg_d2"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]






[VOICE f="Suzune004"]
[OnName num="suzune"]
'嗯，在這裡很容易出錯......，像這樣......'。
[cpg cn=true]


上午的最後一堂課是我姐姐的。
[cpg]

當她面對黑板時，她很有趣，很聰明。
[cpg]


說實話，她在男孩中相當受歡迎，至少可以這麼說。
[cpg]


[OnName num="male_student_A"]
'...... 小坂老師很漂亮，不是嗎？
[cpg cn=true]


[OnName num="male_student_B"]
'哦......，你太有風格了，那個人。
[cpg cn=true]


但是，儘管她是我的嫂子，當人們這樣稱呼我的家人時，我覺得有點不舒服。
[cpg]


我當然也姓小坂，所以人們問我各種各樣的問題，但我假裝不知道。
[cpg]


如果他們知道我是我妹妹，我就會有大麻煩。
[cpg]


我可以看到，我將受到不必要的嫉妒和奇怪做法的困擾，所以我不告訴他們。 ......。
[cpg]


[OnName num="male_student_A"]
'這些乳房是一種致命的武器。我不知道他們吃什麼才能長成這樣。 ......"
[cpg cn=true]


我也知道，但我沒有說。
[cpg]


;**【ＣＧ】 ev_01_a ***********************
[CG id=0 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Suzune005"]
[OnName num="suzune"]
'嘿，那裡。你應該避免和我說話。 "
[cpg cn=true]


[OnName num="male_student_A"]
'......'
[cpg cn=true]

我的意思是，她說的正是她的妹妹，她可能已經註意到了這一點。


儘管如此，我認為她不動聲色是很好的。
[cpg]


如果你只看她現在的樣子，你會看到她是一個堅實的人。 ......
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[window target=true]


對。她在學校表現得相當穩重，但我知道她有點不在狀態。
[cpg]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『学園教室』（昼）******************************************************





她經常忘記事情。她在當老師時很少犯錯，但在家裡卻相當粗心。
[cpg]


在幫助做飯的時候，她把鹽當成糖是常有的事。
[cpg]


我來到這所學校，因為它是留給我唯一可以滑倒的地方。
[cpg]


對我來說，與我妹妹在同一所學校是很尷尬的。但我再也忍不住了。
[cpg]


我做不起浪人，我在這裡是因為......，我在這裡。
[cpg]


順便說一下，緋紅是一個比較聰明的人。與我相反的是，她是那種看起來不合群但卻能出人意料地做事的人。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************





而與這些情況完全無關的是，我當時遇到了危機。
[cpg]


即使在學校，我對"Doki-Doki "的依賴也沒有減少。
[cpg]


然而，我不能在學校傳播漫畫，所以我用手機聽音樂。
[cpg]


太甜太酸的情歌。儘管這是一首偶像歌曲，但它是現在連學生都不聽的那種東西。
[cpg]


我怎麼會變成這樣？ ......，我是這麼想的，但我對自己是瘋子這一事實無能為力。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************





最重要的是，你不能只是去學校，並期望獲得良好的教育。
[cpg]


我在路上沒有和緋紅碰面。這是與她相反的方向。
[cpg]


[SE f="se003"]
;//【ＳＥ】『ドア開く』

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[OnName num="gorou"]
我回來了。 "
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（主人公に笑顔で抱きつくヒロイン。胸を腕に押し当てている）ev_02
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の家＿玄関
;//時間　：夕方
;//========================================


[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


我一回到家，緋紅就找到我。
[cpg]


[VOICE f="Himari005"]
[OnName num="himari"]
'歡迎回家，大哥哥！
[cpg cn=true]

;//＠
;//彼女は私服に着替えていて、もうとっくに家に戻っていたようだった。


他拍拍屁股走到門口，擁抱了我。
[cpg]


[OnName num="gorou"]
'阿志，你太近了......，都快打到我了。
[cpg cn=true]


;//;**【ＣＧ】 ev_02_a ***********************
;//[CG id=1 index=1 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="Himari006"]
[OnName num="himari"]
你太調皮了。你在用這種方式看我妹妹嗎？ "
[cpg cn=true]


[OnName num="gorou"]
...... 沒什麼。 "
[cpg cn=true]


我很激動，感覺到一些我無法偽造的東西。
[cpg]


[OnName num="gorou"]
我的意思是，緋紅有五月的藍調，對嗎？你看起來已經很好了。 "
[cpg cn=true]


;//;**【ＣＧ】 ev_02_0 ***********************
;//[CG id=1 index=0 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="Himari007"]
[OnName num="himari"]
'我在晚上感覺更好。我想知道為什麼'。
[cpg cn=true]


緋紅假裝不明白，但我認為她只是有一個脆弱的早晨。
[cpg]


這樣的話語幾乎傳入我的喉嚨，但我沒有說出來。
[cpg]


[OnName num="gorou"]
'現在，離我遠點，......，我需要穿上衣服。
[cpg cn=true]



[VOICE f="Himari008"]
[OnName num="himari"]
'Duh.然後我就看著你換衣服'。
[cpg cn=true]


你在說什麼。看我弟弟穿衣服有什麼樂趣？
[cpg]


[OnName num="gorou"]
'我不認為看到我的裸體是件有趣的事，...... 可憐的東西。
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]

我推開試圖進入我房間的Himari，然後穿上衣服。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





我只是在我的房間裡閒逛。他說："我是一個很有耐心的人，我希望我的朋友們都能理解我。"他說："我希望我的朋友們都能理解我。
[cpg]


你需要做的第一件事是確保你對你所做的事情有充分的了解。我對這樣的事情感到緊張。
[cpg]


我想我的心臟正在遭受某種疾病的折磨。或者頭部。
[cpg]



[window target=false]



[BG f="b_06_4.ui" time=1500]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





之後，我在網上查了查這個，那個。被禁止的部分，或者說是我長期以來一直迴避的部分。
[cpg]


是否有愛的依賴這一回事。實際上，我更依賴刺激本身，而不是愛情。 ......
[cpg]


不是說沒有，顯然。但他們說這在已經和別人有關係的女性中更常見。
[cpg]


我沒有女朋友，我是個男人，......，最近甚至感覺我必須要緊張才能呼吸。
[cpg]


也許我應該偷偷溜去醫院。我會這樣做的。
[cpg]


[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ非エロ（ヒロインが料理をしている。手伝う主人公。主人公が横にいてヒロインは味見してる感じ）ev_03
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の家＿ダイニングキッチン
;//時間　：夜
;//========================================

[WAIT time=1000]

[SE f="se006"]
;//【ＳＥ】『料理』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]




當我走到廚房時，我母親正在準備晚餐。
[cpg]

[OnName num="gorou"]
'我也要做什麼嗎？媽媽。 "
[cpg cn=true]


[VOICE f="Sawa003"]
[OnName num="sawa"]
'哦，你要幫我？謝謝你！ "
[cpg cn=true]



有時我姐姐會幫忙做飯，但我沒有看到她。
[cpg]


[OnName num="gorou"]
你妹妹在哪裡？ "
[cpg cn=true]



[VOICE f="Sawa004"]
[OnName num="sawa"]
'你已經在你的房間裡下去了!她一定也很難受。 "
[cpg cn=true]


我相信你是對的。當她鬆懈時，她鬆懈到了極限。
[cpg]


從這個角度來看，他並不是一個完全穩固的人。
[cpg]


;**【ＣＧ】 ev_03_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Himari009"]
[OnName num="himari"]
祝你好運，你們兩個。
[cpg cn=true]


緋紅的聲音從後面傳來。
[cpg]


我認為這傢伙可以幫助做家務，但他沒有。
[cpg]


他是否像他姐姐那樣懶惰？
[cpg]


緋紅是如此懶惰，以至於她無法關閉。
[cpg]


...... 仔細想想，我的母親是最靠譜的一個嗎？真是不費吹灰之力。
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





這就是為什麼我們都在這裡。爸爸當然是在那裡吃飯的。
[cpg]


[OnName num="father"]
'......，這是怎麼回事。五郎，什麼事困擾著你？ "
[cpg cn=true]


[OnName num="gorou"]
'不，謝謝你。我很好。 "
[cpg cn=true]


我看起來很陰沉嗎？好吧，我可以看起來很陰沉嗎？
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Sawa005"]
[OnName num="sawa"]
'我也很擔心。你最近一直表現得很奇怪，很害怕。
[cpg cn=true]


我在努力不讓他們看到我的恐懼。 ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune006"]
[OnName num="suzune"]
'五郎以前受過驚嚇，是嗎？在學院裡更是如此。 "
[cpg cn=true]


你是這樣看的嗎？我有點震驚了。
[cpg]




;//ブラックアウト


[window target=false]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[STOPBGM]
[WAIT time=1000]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************





第二天休息。我正在去醫院的路上。
[cpg]


我仍然有一種想要一直悸動的感覺。我想這只是我的體質。 ......
[cpg]


就這一點而言，我想知道我的身體發生了什麼。
[cpg]


;//ブラックアウト


[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]


[SE f="se003"]
;//【ＳＥ】『ドア開く』

[WAIT time=1000]


所以我在一家小醫院進行了檢查。 ......。
[cpg]


[OnName num="doctor"]
'這是......，發生了什麼事。我不明白。 ......"
[cpg cn=true]


顯然，我的身體正在發生一些奇怪的事情。
[cpg]


他們把我轉到一家更大的醫院，我顯然不得不向家人傾訴。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿玄関』（昼）******************************************************





[OnName num="gorou"]
我回來了。 ......
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa006"]
[OnName num="sawa"]
'歡迎回來。怎麼了，你不是出去購物了嗎？
[cpg cn=true]


[OnName num="gorou"]
我想要的那款產品已經賣完了，.......。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa007"]
[OnName num="sawa"]
'哦，是的。那太糟糕了。 ...... 那是什麼？ "
[cpg cn=true]


[OnName num="gorou"]
啊！ "
[cpg cn=true]


一封介紹信從袋子裡掉了出來。我愣了一下。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[OnName num="father"]
'...... ill?你能單獨去諮詢這個問題，已經很不錯了'。
[cpg cn=true]


[OnName num="gorou"]
'不，我是說，哈哈......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune007"]
[OnName num="suzune"]
'我也很好奇。你有什麼症狀？
[cpg cn=true]


[OnName num="gorou"]
'嘿，我能說什麼呢......，這有點像感冒。
[cpg cn=true]


苦難。我很痛苦。隨著時間的推移，這一切都會變得清晰。
[cpg]


甚至緋紅和她的母親也在做神秘的表情。緋紅的表情是這樣的，我一定讓她擔心了。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夕方）******************************************************





所以我立即前往我被轉診的醫院。我的家人和我一起來到這裡。
[cpg]


從那裡開始就很艱難。他們說我需要進行全面檢查或其他什麼。
[cpg]


據說這是一種罕見的疾病，只影響到數百萬人中的一個，甚至更少。
[cpg]


我很不解，但還是照他們說的做了，解釋說有可能會陷入嚴重的狀況。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





那晚的晚餐很尷尬。
[cpg]


吃飯時還可以，但飯後的家庭會議，或......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa008"]
[OnName num="sawa"]
'......，運氣不好。這就是為什麼你獨自在醫院裡。
[cpg cn=true]


在這一點上，我開始想，我至少可以和我父親談談這個問題。
[cpg]


套用一句話，他的體質使他難以呼吸，除非定期提高心率。這已經隨著年齡的增長而表現出來。
[cpg]


簡而言之，如果你不提高你的心率，最壞的情況是你會誘發其他疾病。
[cpg]


他們威脅我說有可能陷入危急狀態，我就頭疼了。也許我的家人也會。
[cpg]

[free time=800]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sSuzune001"]
[OnName num="suzune"]
'你為什麼不獨自去......，看浪漫漫畫或其他什麼。這可能會有幫助。 "
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="sHimari001"]
[OnName num="himari"]
'不! 如果我不能為此感到興奮，我就會死。
[cpg cn=true]


死亡是一種誇張的說法，但它不是謊言。
[cpg]


畢竟，這是一種未知的疾病，任何事情都可能發生。
[cpg]


[OnName num="father"]
'嗯，這很好。五郎會自己處理好的，太過擔心也不好。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari011"]
[OnName num="himari"]
'我不知道............ 我知道我很焦慮。
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（昼）******************************************************





我們這樣一談，就同意暫時由我來做自我評判。
[cpg]


日子就這樣一天天過去了。我想知道這樣做是否正確，但沒有別的辦法。
[cpg]


......在這一切之中。
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



一個早晨。爸爸去上班後，舉行了一次家庭會議。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune002"]
[OnName num="suzune"]
'我想，你不是對我們有好感嗎？
[cpg cn=true]



[OnName num="gorou"]
'嘿，你在說什麼？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune003"]
[OnName num="suzune"]
'你是什麼意思，你一定很激動？我和五郎甚至沒有血緣關係'。
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSawa001"]
[OnName num="sawa"]
'是的，沒錯。我知道我也是如此。
[cpg cn=true]


甚至我的母親也會加入進來，談論這些話題。不過，這很好。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSuzune004"]
[OnName num="suzune"]
幸運的是，你白天也和我一起去學校。 ......
[cpg cn=true]


[VOICE f="sSuzune005"]
[OnName num="suzune"]
'如果你有一天有了悸動的衝動，而且變得太硬，你可以指望我們。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="3/3" time=800]
[VOICE f="sHimari002"]
[OnName num="himari"]
'你又不能依靠我！ '這是不可能的。你必須積極主動地與他們調情。 "
[cpg cn=true]


緋紅這麼說，但她不是在開玩笑。
[cpg]

[OnName num="gorou"]
'我不想這樣，我拒絕這樣！ '。我絕對討厭它。 "
[cpg cn=true]

[SE f=se010]
;//【ＳＥ】『走る』
[free time=1000]
[WAIT time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Suzune013"]
[OnName num="suzune"]
'哦，緋紅！別讓他跑了，把他按住。 "
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Himari013"]
[OnName num="himari"]
'我知道! 大哥，你想逃跑是沒有意義的。 "
[cpg cn=true]




[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[WAIT time=2000]
;//ブラックアウト



就這樣。
[cpg]


我受到了我的姐姐、妹妹和母親的所謂'搗蛋管理'。 ......
[cpg]



[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（朝）******************************************************



然後，在了解了我的體質後，我感到有一種額外的慾望，想讓自己激動起來。
[cpg]


我想感到興奮。如果我不碾壓，我就會死。這是一部多麼困難的憲法。
[cpg]


但我不能在上課時聽音樂，上午的課程結束後，我感到很暈眩。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************


當我失去意識時，我的姐姐幫助我。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune014"]
[OnName num="suzune"]
她說：'我想知道我應該去哪裡，.......我知道這將是學生指導辦公室。 ......
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune015"]
[OnName num="suzune"]
'但你也不應該過多地使用它。你怎麼看？
[cpg cn=true]


我只能回答說我不知道。但最後，他們把我帶到了學生諮詢室。
[cpg]


我已經在掙扎著呼吸了，我不能再忍受了。
[cpg]


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

;//ブラックアウト


最後，我和我妹妹單獨在一個封閉的房間裡，沒有人可以看到我。
[cpg]


[VOICE f="sSuzune006"]
[OnName num="suzune"]
'別誤會，我不能為你做那麼多。
[cpg cn=true]


說著說著，姐姐就把手放在了我的胸前。
[cpg]


[OnName num="gorou"]
'Ugh. ......'
[cpg cn=true]


這並不是說我從來沒有意識到我妹妹是個女人。
[cpg]


當她離我如此之近時，我無法停止...... 扑騰。
[cpg]


那是一段無法形容的舒適時光。一個奇怪的時期，我感到緊張，但同時又很自在。
[cpg]

;//移植前シーンカット


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



[OnName num="gorou"]
'......，你每天都堅持這樣做嗎？
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune033"]
[OnName num="suzune"]
'這不是我的錯，是嗎？這更是你的錯。 "
[cpg cn=true]


他從學生指導辦公室出來時這樣說。
[cpg]


一般來說，這是一個相當糟糕的場景。
[cpg]


學生們可能不知道，但老師們知道我和我妹妹是姐妹和兄弟。
[cpg]




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（夕方）******************************************************


在這種事情發生時，時間就會流逝。
[cpg]


儘管從中午到現在沒過多少時間，但我已經接近我的極限了。
[cpg]


如果我不被重擊，我就會得另一種病，我明白了，我想是這樣。 ......
[cpg]


我在掙扎著呼吸，好像在這之前我就要瘋掉了。
[cpg]


[OnName num="female_student"]
'怎麼了？小坂君，你的行為很奇怪。 "
[cpg cn=true]


[OnName num="gorou"]
'爸，我很好。這不算什麼'。
[cpg cn=true]


不可能什麼都沒有，但我決定回答這個問題。
[cpg]


我不能再這樣做了。當我看著女孩們的臉時，這就更難了。
[cpg]


這是一種來自我的體質的痛苦，我的體質顯然與正常男孩的體質不同。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





而我正試圖回到家裡。
[cpg]


我不禁發現街上的所有女人都很有吸引力。這是不正常的。
[cpg]


但我無法單獨控制我的感覺。
[cpg]


受控"這個詞太冷淡了。我正在被折磨，而不是被控制。
[cpg]


我回家的感覺是這樣的。 ......
[cpg]


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[SE f="se003"]
;//【ＳＥ】『ドア開く』
[WAIT time=1000]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa010"]
[OnName num="sawa"]
'歡迎回來。你看起來很痛苦，戈羅。 "
[cpg cn=true]


爸爸離開前的時間。
[cpg]


我想做點什麼，我打算跪下來，向我媽媽求助。
[cpg]


這就是我的真實感受。我無法忍受這一點。
[cpg]


我不想忍受它。我緊緊抓住母親。
[cpg]


[OnName num="gorou"]
我很高興見到她，我也很高興見到她。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa011"]
[OnName num="sawa"]
'咯咯笑。 '對--你這樣看著我，我什麼也做不了。
[cpg cn=true]


這是在爸爸回來之前呢。我希望他能做一些事情。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト



[BG f="b_04_3_up.ui" time=1000]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7" time=1000]
[WAIT time=2000]


我被帶到了我媽媽的房間。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa002"]
[OnName num="sawa"]
'好吧，那我要給你一個擁抱了。
[cpg cn=true]


[OnName num="gorou"]
'是的，你確定嗎......？
[cpg cn=true]




[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa013"]
[OnName num="sawa"]
'沒關係的。看到我的兒子處於痛苦之中，我很痛心'。
[cpg cn=true]


這樣的話語引誘我到......
[cpg]

;//移植前シーンカット

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]


在母親的懷抱中，我的眼淚都快流出來了。
[cpg]


這與興奮的感覺有點不同。
[cpg]


但就解脫而言，我可能比和我妹妹在一起時更解脫。
[cpg]


這就是我母親連我的焦慮都籠罩的程度。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[OnName num="father"]
......
[cpg cn=true]


[OnName num="gorou"]
"......"
[cpg cn=true]


晚餐時，我和爸爸都沉默不語。我認為有些事情，男人可以在某種程度上理解對方。
[cpg]


我是個男人，卻愛上了你，這很令人尷尬，但......。
[cpg]


也許他們多少能理解這種尷尬的感覺。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="Himari014"]
[OnName num="himari"]
'媽媽，把醬油遞給我。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa032"]
[OnName num="sawa"]
'好吧--給你。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune034"]
[OnName num="suzune"]
'你就在它旁邊。自己去拿吧，緋紅'。
[cpg cn=true]


女人進行這樣的對話。這是一件非常、非常隨和的事情。
[cpg]


或者說，他們甚至似乎很興奮。明天他們會不會照顧緋紅呢......？
[cpg]


我仍然不知道我的母親和妹妹的情況。但緋紅是我的妹妹。
[cpg]


對你的妹妹感到緊張是不正常的。
[cpg]


我感到那裡有危險的東西，但我不能說什麼。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





我脫下衣服，換上了睡衣。
[cpg]


在我睡覺的時候，我的症狀並沒有惡化，但這並不能緩解，因為.......。
[cpg]


我深深地嘆了口氣，為即將到來的事情感到擔憂。
[cpg]


真的，會發生什麼......？
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』朝チュン


[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



即使你在考慮要發生什麼，早晨也會正常到來。
[cpg]


我以前睡覺的時候都很好，但今天我夢見我有一個可愛的女朋友。
[cpg]


這是連正常男人都很難醒來的那種夢。
[cpg]


我想找人幫忙，所以我還是去找我姐姐。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[BG f="b_04_1_up.ui" time=1000]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[WAIT time=2000]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune007"]
[OnName num="suzune"]
'什麼？早晨我不負責任。 "
[cpg cn=true]


那是什麼，這樣的輪換已經建立了？
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune036"]
[OnName num="suzune"]
'我把早上的事留給了緋紅。所以我希望你去找她。 "
[cpg cn=true]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari015"]
[OnName num="himari"]
'早上好，大哥哥。你看起來不舒服。
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
不好。他說他的體質本來就很奇怪。
[cpg]


[OnName num="gorou"]
'......, 緋紅......，關於我的體質。
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari003"]
[OnName num="himari"]
'我知道--我知道。那麼？你想讓我做什麼？ "
[cpg cn=true]


他在笑，想讓我告訴他。
[cpg]


看來爸爸已經離家了。我想這就是為什麼Himaru要告訴我這些。 ......
[cpg]


而這並不是一種毫無保留的說法。好吧，只有我、緋紅、我姐姐和我母親知道我們在做什麼。
[cpg]


相反，爸爸是唯一不知道的人。只要我爸爸不在這裡，我說什麼又有什麼關係呢？
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari004"]
[OnName num="himari"]
你曾經和一個女孩牽過手嗎？
[cpg cn=true]


[OnName num="gorou"]
不，我不知道。 "
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari005"]
[OnName num="himari"]
'嗯。那麼如果有人這樣對你，你會感到興奮嗎？
[cpg cn=true]

在她說這句話的時候，Himari握住了我的手。
[cpg]


然後，將他們的手指交織在一起，成為一種...... 情人的聯繫，或類似的形式。
[cpg]


我變得很緊張。而苦澀的感覺也消失了。
[cpg]


[OnName num="gorou"]
'謝謝你，.......'
[cpg cn=true]

[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari036"]
[OnName num="himari"]
現在你是我的了，大哥哥......ehehe。 "
[cpg cn=true]


緋紅似乎很高興。
[cpg]


緋紅可能也會有佔有欲。
[cpg]


我不知道，但我有一種感覺，她是。 ......。
[cpg]

;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



然後我們吃早餐。姐姐看著我們手拉手，很是不安。
[cpg]


但我知道為什麼會發生這種情況。
[cpg]


早上是緋紅。在下午，或者說在學校，是我妹妹。晚上，我們又有一次與我母親......，我相信。
[cpg]


我昨天和今天發現了這個問題。也許這就是他們一天三次的計算方法。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari037"]
[OnName num="himari"]
'這很好吃。炒蛋看起來不能做'。
[cpg cn=true]


是否有這樣的事情，即不能做炒蛋？就在我這樣想的時候，我妹妹探出頭來。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune037"]
[OnName num="suzune"]
'你只是不想讓他們，你......'。
[cpg cn=true]


緋紅並不覺得她剛才和我牽手。
[cpg]


好像她切換得很快或什麼的。
[cpg]


但她和我單獨在一起時也是這樣嗎？
[cpg]


我不知道。我不知道，但如果你這樣說，我母親也是如此。 ......。
[cpg]


我的姐姐給了我一些"砰"的一聲，但緋紅和我的母親卻沒有那麼多。
[cpg]




;//ブラックアウト


[window target=false]

[STOPBGM]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



在她離開一段時間後，我們也去了學校。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Himari038"]
[OnName num="himari"]
我現在要走了。再見，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'嗯，嗯。那我就走了。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa033"]
[OnName num="sawa"]
'嗯，有一個好的一天。
[cpg cn=true]


這個微笑是什麼意思？不，你的母親看到了一切。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（朝）******************************************************





[OnName num="gorou"]
'哦，......，現在會發生什麼......'。
[cpg cn=true]


我終於對自己說了我想了好幾遍的話。
[cpg]


我不知道如果我不這樣做會發生什麼。
[cpg]


我繼續過著讓家人激動的生活，即使是婆媳關係。
[cpg]


那麼我就不能把我的媽媽、姐姐和緋紅看成只是家人。
[cpg]


我在痛苦中去了學院。
[cpg]





[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

;//[jump storage="ep001.ks" target="*start"]


;/////////////////////////////////////////////////////////////////////


*start

;###################################################################
*Ep001|悸動管理的開始
;###################################################################

;//ブラックアウト
[SCENE id=1]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]

[SE f="se002"]
;//【ＳＥ】『喧噪』

[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************





[OnName num="female_student_A"]
'你的情緒有些變化，小坂君，......。
[cpg cn=true]


[OnName num="female_student_B"]
是的，"他說。我只是一個食草動物，但我也有...... 憂鬱症。"
[cpg cn=true]


我聽到了，我聽到了。我聽著竊竊私語，想著。
[cpg]


他沒有說我的壞話，這感覺很好。但是。
[cpg]


如果他們是因為我的憲法而這麼說，我不知道該怎麼說。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************




而到了午餐時間，已經很辛苦了。我的腦袋裡滿是想要搗亂的想法。
[cpg]



我無法理解上午的最後部分。
[cpg]


我很難呼吸，我不能再想別的事情了。
[cpg]


這讓我很抓狂，撲面而來的依賴性真的讓我很難受。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************





[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune038"]
[OnName num="suzune"]
'......，是時候了，這很痛苦。我知道它的大部分內容。 "
[cpg cn=true]


[OnName num="gorou"]
'哦，拜託。我不能再這樣做了，我不能。 ......"
[cpg cn=true]


女性化的話語從我口中說出。但我不能幫助它。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune039"]
[OnName num="suzune"]
'好吧。來吧。 "
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植前シーンカット

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_03_2_up.ui" time=1000]
[WAIT time=1000]

我跟著他來到學生指導辦公室。
[cpg]


我進去了，想知道這次他們會對我做什麼。
[cpg]


...... 結果是，這和前幾天的情況一樣，這很好。
[cpg]


我可以看到我的姐姐是多麼關心我，試圖不過度刺激我。
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



搗毀管理。每天三次，使心率上升：......
[cpg]


這是一個相當怪異的情況，但這就是我所處的那種情況。
[cpg]


一天三次已經很困難了。我希望它是這個數字的兩倍。
[cpg]


但我們不能無休止地觸摸對方，這可能會越界。
[cpg]


是否有這樣的治療方法？有一些人具有難以置信的吸引力，他們接近我。
[cpg]


我不能做我想做的事。我被管理得無以復加。
[cpg]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（夕方）******************************************************





[OnName num="male_student_A"]
'我聽說了。他和小坂老師一起走進了學生諮詢辦公室。
[cpg cn=true]


[OnName num="male_student_B"]
'發生了什麼事。那你做了什麼？ "
[cpg cn=true]


我認為被這樣質疑是很自然的。
[cpg]


但我無法回答任何問題。
[cpg]


[OnName num="gorou"]
'這是職業建議。 ......，這沒什麼可擔心的。
[cpg cn=true]


[OnName num="male_student_A"]
'有傳言說你從裡面出來的時候躺在......，很慌張。
[cpg cn=true]


這就是他們得到信息的程度。我下次離開時要小心了。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夕方）******************************************************





啊，我離開的時候會小心的。我迫不及待地想回家。
[cpg]


現在輪到我媽媽了。今天我已經可以承受了，如果我可以說我可以承受的話。 ......
[cpg]


不過，這還是讓人相當苦惱的事。
[cpg]


我甚至不能和同學們交談，更不用說認真上課了。
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』


[OnName num="gorou"]
'塔，我回來了。 ......'
[cpg cn=true]




[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa003"]
[OnName num="sawa"]
'歡迎回來。你現在很難受嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'什麼，......？不，嗯，是......"
[cpg cn=true]


我沒有立即回答，壓抑著自己的感覺，我真的希望現在就能做點什麼。
[cpg]


不知為何，我不想說我理解。另一方面，讓我的母親告訴我也不好。 ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa004"]
[OnName num="sawa"]
'你不必如此。你看起來很蒼白'。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSawa005"]
[OnName num="sawa"]
'我們今天該做什麼？你想和我一起洗個澡嗎？ "
[cpg cn=true]


他們看穿了這一切，感到很難堪。
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_04_3_up.ui" time=1000]
[WAIT time=1000]


話雖如此，我還是不能以尷尬為由拒絕。
[cpg]

[VOICE f="sSawa006"]
[OnName num="sawa"]
'是的，一件游泳衣。有了這個，你就不會感到尷尬了'。
[cpg cn=true]

[OnName num="gorou"]
'但是，但是......，我可以嗎？
[cpg cn=true]


[VOICE f="sSawa007"]
[OnName num="sawa"]
'好的。我不想再看到你痛苦的臉。
[cpg cn=true]


我按母親的要求做了，然後去洗澡。
[cpg]


......，希望沒有人發現。
[cpg]


;//========================================
;//●ＣＧエロ（石けんで洗いながら手コキ。ヒロインは背後から片手で主人公の乳首も弄りながらしごく）ev_08
;//人物１：ヒロイン３
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：主人公の家＿風呂
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


這有點像我不能說我沒有問題......，因為我穿著游泳衣。
[cpg]


我不知道要花多少錢，但我不知道和家人這樣做是否可以，即使他們沒有血緣關係。
[cpg]


[VOICE f="sSawa008"]
[OnName num="sawa"]
'當你在洗澡的時候，我也要給你洗身體嗎？
[cpg cn=true]


媽媽表現得好像無動於衷。
[cpg]


[OnName num="gorou"]
'是的，很好。我自己會做的'。
[cpg cn=true]



而我呢，我的聲音都快變了。
[cpg]


;**【ＣＧ】 ev_08_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sawa038"]
[OnName num="sawa"]
'你這麼說，但你真的想把我寵壞，不是嗎？
[cpg cn=true]


我有一種想要被呵護的慾望。但我不能大聲說出來。
[cpg]


我感覺我的母親也知道這一點，並且正在接近我。
[cpg]


[OnName num="gorou"]
這真的很好。 ......
[cpg cn=true]


[VOICE f="sSawa009"]
[OnName num="sawa"]
'別憋著了。我有一個不激動的藉口'。
[cpg cn=true]



[OnName num="gorou"]
'當你稱它為藉口時，就更尷尬了。
[cpg cn=true]


媽媽笑了，用肥皂和海綿給他們擦洗。
[cpg]


;**【ＣＧ】 ev_08_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa010"]
[OnName num="sawa"]
'那好吧，讓我給你洗吧。
[cpg cn=true]

海綿觸動了我。這已經足夠讓我的心跳加速了。 ......
[cpg]


[VOICE f="sSawa011"]
[OnName num="sawa"]
我可以感覺到你的脈搏在加快。籲。
[cpg cn=true]


她的手指在泡沫上滑行。這種癢癢的感覺是騙人的。 ......
[cpg]


漸漸地，呼吸變得不那麼困難了。這本身就是一件令人欣慰的事情。
[cpg]


再加上我與這樣一個美麗的人親密接觸的事實。
[cpg]


那是一段可以說是幸福的時光。這部憲法可能並不全是壞事。
[cpg]


[VOICE f="sSawa012"]
[OnName num="sawa"]
我不知道我是否已經洗了大部分的東西。你還有什麼要我洗的嗎？ "
[cpg cn=true]


你還有什麼意思......，你還打算做什麼？
[cpg]



[OnName num="gorou"]
'你想讓我說什麼？
[cpg cn=true]


我想說這是一種阻力，但媽媽卻拂袖而去。
[cpg]


;**【ＣＧ】 ev_08_b ***********************
[CG id=3 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa013"]
[OnName num="sawa"]
'這是什麼？我想不出來了。 "
[cpg cn=true]


媽媽可能有點刻薄，不是嗎？
[cpg]



[OnName num="gorou"]
'...... 如果你想不出來，就不要說了。
[cpg cn=true]

[VOICE f="sSawa014"]
[OnName num="sawa"]
'嗯。好吧，那我就把你衝下去。
[cpg cn=true]


感受到了溫暖的水。它不僅使你的脈搏加快，而且我認為它也提高了你的體溫。
[cpg]


也許我媽媽也是這樣，......？
[cpg]


[VOICE f="sSawa015"]
[OnName num="sawa"]
'什麼？那張臉。你想讓我多洗洗嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'呃，不。這沒什麼。 "
[cpg cn=true]


熱水會沖走泡沫。的確，這感覺有點像一種提醒。
[cpg]


我已經受夠了敲打......，這不是你可以和你的家人一起做的事情了。
[cpg]






[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


等到跳動聲減弱時，我意識到我的呼吸不在了。
[cpg]


這提醒了我，如果我不真的搗鼓，就會有生命危險。 ......
[cpg]

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





做完這一切後，我們圍坐在餐桌旁，看起來好像不知道發生了什麼事。
[cpg]


我真的覺得我不應該這樣做。
[cpg]



[SE f="se011"]
;//【ＳＥ】『食器の音』




[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune058"]
[OnName num="suzune"]
'...... 吾郎。你沒有胃口嗎？
[cpg cn=true]


[OnName num="gorou"]
不，思考......。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari039"]
[OnName num="himari"]
'在思考，嗯？我最近也在做大量的思考'。
[cpg cn=true]


主要是在想如何搞亂我。這就是我所想的。
[cpg]


[OnName num="father"]
'怎麼了？你說的是憲法。 "
[cpg cn=true]


嗯，大概就是這樣。爸爸是唯一被排除在這群人之外的人。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





然後我回到我的房間。每當我想起今天發生的事情，我就感到很尷尬。
[cpg]


我不知道該怎麼做。我只需要修復我的體質，不是嗎？
[cpg]


但如果我不知道如何解決它，我就不能做任何事情。 ......
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


[SE f="se004"]
;//【ＳＥ】『衣擦れ』

當我帶著這些想法入睡時，我被一種奇怪的感覺驚醒了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari040"]
[OnName num="himari"]
'早上好，兄弟。
[cpg cn=true]


[OnName num="gorou"]
'...... 不，不是早安。
[cpg cn=true]


緋紅正撫摸著我的頭。這也與我的憲法有關嗎？
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari006"]
[OnName num="himari"]
'大哥的頭太值得撫摸了，不是嗎？
[cpg cn=true]


...... 顯然不是。他只是想挑逗我。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari007"]
[OnName num="himari"]
'進展如何？你很激動嗎？ "
[cpg cn=true]


[OnName num="gorou"]
......，一般般。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari008"]
[OnName num="himari"]
我當時想，"好，好，好。你得說出來。"
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
緋紅這樣說，並把她的臉靠近他。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari009"]
[OnName num="himari"]
'看。我可能會像這樣吻你'。
[cpg cn=true]


[OnName num="gorou"]
'哦，我很抱歉。 ......'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari010"]
[OnName num="himari"]
如果你知道我的意思的話。
[cpg cn=true]


;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************




[OnName num="gorou"]
'......Himari, you're pretty mean.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari011"]
[OnName num="himari"]
'你在說什麼。我沒有這麼好的妹妹，你有嗎？
[cpg cn=true]


...... 當然，如果你問我，那是真的。她一直是個皮實的姐姐，但現在她似乎真的很享受這種感覺。
[cpg]


我想。
[cpg]



;//■選択肢
[switch]
[case "她對我如此投入，我很高興。"]
	[swap]
	[jump target="*select01_1"]
[case "我迫不及待地要修復這部憲法。"]
	[swap]
	[jump target="*select01_2"]
[endswitch]

第一，我很高興你對我如此忠誠。
2、我想盡快修復這個憲法。



;//==============================
;//１、こんなに尽くしてくれて幸せだ
*select01_1|搗毀管理的開始




我很高興緋紅對我如此忠誠。
[cpg]


我相信一定有類似於愛的反面的東西。
[cpg]


當我想到這一點時，緋紅似乎也是一個可愛的人。
[cpg]

[stflag Cha2flg = 1]

;//ヒロイン２が候補に

[jump target="*select01_3"]

;//==============================
;//２、早くこの体質を治したい

*select01_2|搗毀管理的開始



我知道我不想這樣做太久。
[cpg]

如果可能的話，我想現在就解決我的體質問題，重新過上無憂無慮的生活。 ......
[cpg]


但我相信這將是更遠的事情。
[cpg]



;//==============================

*select01_3|搗毀管理的開始

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


;//[jump storage="ep002.ks" target="*start"]



;/////////////////////////////////////////////////////////////////////

*start

;###################################################################
*Ep002|被管理的痛苦
;###################################################################

[SCENE id=2]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





看來她姐姐已經在去工作的路上了，或者說是去學院。
[cpg]


她也是個大忙人，所以我不怪她。
[cpg]


我猜她自然要比學生們來的早。
[cpg]


當我想到這一點時，有些事情我是無法理解的。 ......。
[cpg]


與我不同的是，我覺得我仍然是一個工作的人。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************




[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa055"]
[OnName num="sawa"]
'好吧，那就去吧。不要停下來，再回來'。
[cpg cn=true]


我不需要你來告訴我，我不會停下來的，因為晚上我又要受罪了。
[cpg]


考慮到這一點，我回過頭來問候了我的母親。
[cpg]


[OnName num="gorou"]
我走了。 "
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari067"]
[OnName num="himari"]
你走吧！ "
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************


早晨的教室。我已經去上課了，越來越硬。
[cpg]


上課是你應該集中精力學習的時候。
[cpg]


但是當老師是個女人時，我就忍不住了。即使她不是那麼年輕。
[cpg]


而當老師是個男人時，我的注意力就會轉向我的同學們的女孩。
[cpg]


僅僅是想要悸動的感覺就使它變得如此艱難。
[cpg]


我已經很痛苦了，以至於我不得不在很早的時候就給我姐姐幫了一把。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（朝）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune059"]
[OnName num="suzune"]
'...... 等到午餐時間。你是個男孩，你必須有點耐心。 "
[cpg cn=true]


[OnName num="gorou"]
'我有麻煩了，因為我是個男孩......'
[cpg cn=true]


'確實如此，'我姐姐嘟囔道。不，這並不重要。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



從那以後，我設法堅持到了午餐時間，這次我壓住了她。
[cpg]


我不會再懷念它了。如果我錯過這個時機，我就真的會死。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune008"]
[OnName num="suzune"]
'那好吧，我們今天去某個空教室好嗎？
[cpg cn=true]


[OnName num="gorou"]
'什麼，不是...... 學生諮詢室？
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune061"]
[OnName num="suzune"]
'如果你用得太多，它就會很突出。
[cpg cn=true]


這是正確的，但如果你使用一個空教室，有人會找到你。 ......。
[cpg]



;//ブラックアウト


[VOICE f="sSuzune009"]
[OnName num="suzune"]
'好吧，我們該怎麼做？我的意思是，來吧。 "
[cpg cn=true]


我有很多顧慮，但我無法阻止自己。
[cpg]


;//========================================
;//●ＣＧ（ヒロインに背後から抱きつく主人公。衝動を必死にこらえる）ev_10
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]





[OnName num="gorou"]
'姐.......
[cpg cn=true]


她從後面抱住她的妹妹。我聞到她的好味道，感覺我的脈搏加快了。
[cpg]


回想起來，我從小到大即使想做也做不到。
[cpg]


但現在，我可以毫不猶豫地寵愛她。
[cpg]


從這個意義上說，我目前的體質在一定程度上幫助了我。 ......
[cpg]


[VOICE f="sSuzune010"]
[OnName num="suzune"]
'......，這太突然了。你嚇了我一跳。 "
[cpg cn=true]


我覺得她也有點臉紅。
[cpg]


也許她對我所做的事情有想法。
[cpg]


[OnName num="gorou"]
'對不起，我只是不能再忍受了。
[cpg cn=true]


;**【ＣＧ】 ev_10_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune011"]
[OnName num="suzune"]
'你現在是這樣一個...... 無助的小女孩。
[cpg cn=true]


她似乎既感到震驚又感到尷尬。
[cpg]


[VOICE f="sSuzune012"]
[OnName num="suzune"]
'嗯，她在那方面也很可愛。
[cpg cn=true]


我很漂亮，你說，我的心再次向你走去。
[cpg]


這也是一種來自我的體質的感覺，我想...... 磅。
[cpg]


但不管怎樣，我也想有一個暗戀對象。
[cpg]


我想被我妹妹誤導。我想被迷惑，所有的時間。 ......
[cpg]


[VOICE f="sSuzune013"]
[OnName num="suzune"]
五郎的體溫，感覺是越來越高了。 "
[cpg cn=true]


[OnName num="gorou"]
'是的，我不認為如此。
[cpg cn=true]


如果有人告訴我並且我意識到了這一點，我很可能會格外害羞。
[cpg]


[VOICE f="sSuzune014"]
[OnName num="suzune"]
'是的，我是。我不認為這只是我的想像'。
[cpg cn=true]


但即使是這樣說的姐姐也覺得有點熱。
[cpg]


;**【ＣＧ】 ev_10_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune015"]
[OnName num="suzune"]
'我現在該走了嗎？你平靜下來了嗎？ "
[cpg cn=true]


我搖搖頭。這還不夠。
[cpg]


我感到一陣慾望，想把她抱得更緊，我努力壓制著它。
[cpg]


[VOICE f="sSuzune016"]
[OnName num="suzune"]
'真的，你不能幫助它，孩子。
[cpg cn=true]


這不是一個冷冰冰的說法，而是一個親切的話語，直奔主題。
[cpg]


我從母親那裡感受到了一種不同的母愛，或類似的東西。
[cpg]


[VOICE f="sSuzune017"]
[OnName num="suzune"]
'溺愛...... 好，讓我們再保持這樣的狀態。
[cpg cn=true]


她這樣說，並允許我做我所做的。
[cpg]


我覺得如果她對我這麼好，我就不能再忍下去了。 ......
[cpg]


但我還是忍住了，沒有再做什麼。
[cpg]


[OnName num="gorou"]
'謝謝你......'
[cpg cn=true]


[VOICE f="sSuzune018"]
[OnName num="suzune"]
'不客氣。看到我的兄弟陷入困境，我不能置身事外'。
[cpg cn=true]


說這話的姐姐是我的妹妹，似乎在隱瞞什麼。
[cpg]


我想知道她是否會對我有所想法，或者.......。
[cpg]


[OnName num="gorou"]
'你聞起來很香.......'
[cpg cn=true]


;**【ＣＧ】 ev_10_b ***********************
[CG id=4 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune019"]
[OnName num="suzune"]
'不要聞。而且不要說任何令人尷尬的話。
[cpg cn=true]


她沒有感到羞愧，而是以一種更像是嘲弄的方式說道。
[cpg]


但我想知道她是否也能聞到我。
[cpg]


我希望她在想些什麼。 ...... 很快，午休就會結束。
[cpg]



;//ブラックアウト

快樂的時光不可避免地很快過去。
[cpg]


你越想讓它永遠持續下去，它就越早結束，從身體上來說。
[cpg]


而我越是希望它結束，越是痛苦的時間就要重新開始。
[cpg]


我想感到興奮。我可以說上一整天。 ......
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



事後。謠言傳播得很快，還是那個人在第一時間看到了？
[cpg]


[OnName num="male_student_A"]
'我看到了。你和小坂老師一起進了教室，儘管那是午餐時間。 "
[cpg cn=true]


[OnName num="male_student_B"]
'你在做什麼。你在做什麼？
[cpg cn=true]


啊哈，我想，但我回答。
[cpg]


[OnName num="gorou"]
'不，是......，你知道我和我的老師是同姓的嗎？
[cpg cn=true]


[OnName num="male_student_A"]
'哦，你是小坂五郎，對嗎？你有相同的漢字嗎？
[cpg cn=true]


[OnName num="gorou"]
'是的，它是。我和我的老師，我們是姐弟戀'。
[cpg cn=true]


[OnName num="male_student_B"]
'真的嗎？多麼令人羨慕啊！ ......！ "
[cpg cn=true]


[OnName num="gorou"]
這就是為什麼我一直在請教諸如家庭問題之類的事情。 "
[cpg cn=true]


我沒有說謊。我不能很好地說出真相。
[cpg]


[OnName num="male_student_A"]
'話說回來，去一個空的教室是很奇怪的。
[cpg cn=true]


[OnName num="gorou"]
'這是我不希望任何人聽到的建議。
[cpg cn=true]


我不知道，我不能幫助它。 ......，但這不僅僅是我的錯。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園教室』（夕方）******************************************************





然後是下午的課程。在我服用時，這一次我母親的臉開始在我腦海中閃現。
[cpg]


最後，我不能沒有你們三個人。我想起了這一點。
[cpg]


我被打上了印記，我不能再和他們作對了。 ......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





我在回家的路上已經搖搖晃晃了。我的同學們都很擔心我。
[cpg]


[OnName num="female_student_A"]
'你還好嗎？小坂君。 "
[cpg cn=true]


[OnName num="female_student_B"]
'嘿，嘿，你和小坂老師是姐弟戀是真的嗎？
[cpg cn=true]


考慮到謠言傳播得很快，我離開了，當時就回復了。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa056"]
[OnName num="sawa"]
'歡迎回來。你已經在痛苦中了嗎？我不知道。 "
[cpg cn=true]


[OnName num="gorou"]
'Ts，這很難。 ...... 幫助我，媽媽。
[cpg cn=true]


我說了我的想法，但媽媽笑著說
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa057"]
[OnName num="sawa"]
'漂亮的臉蛋。嘿，戈羅，你今天為什麼不試著多一點耐心呢？ "
[cpg cn=true]


他說。我不由自主地脫口而出。
[cpg]


[OnName num="gorou"]
'噓，我要死了......！ '
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





有人告訴我，我不應該太過頻繁地敲打。
[cpg]


但一天三次是目標，這意味著即使一天兩次也不會殺死你。
[cpg]


事實上，他們可能已經說了三次，以設定一個上限。
[cpg]


習慣搗鼓那麼多可能是個問題。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari068"]
[OnName num="himari"]
'兄弟，你似乎過得很辛苦。我希望你的身體迅速痊癒'。
[cpg cn=true]


我吃完飯，從椅子上不穩地站起來。
[cpg]

[free time=1000]

我什麼都做不了。或者說，我不能看有吸引力的女人，如緋紅、我的姐姐和我的母親。
[cpg]


最好是一個人睡。考慮到這一點，我走回了我的房間。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





我不知道我還得等多久。我母親該睡覺了，不是嗎？
[cpg]


當我這樣想時，我開始失去意識。
[cpg]


我可能真的又要得病了。在這一切的中間。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[WAIT time=1100]



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa058"]
[OnName num="sawa"]
'對不起，讓你久等了。到我的房間來。 "
[cpg cn=true]


[OnName num="gorou"]
'......，你確定......？
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa059"]
[OnName num="sawa"]
'你可以說得出口。我應該怎麼做？ "
[cpg cn=true]


[OnName num="gorou"]
呃--呃! 求你了，我已經束手無策了。 "
[cpg cn=true]


甚至我母親也這樣對我說。我已經沒有選擇了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//移植前シーンカット


那天晚上，我在母親撫摸著我的頭入睡。
[cpg]


我沒有逃跑或躲藏，我讓我的心怦怦直跳。
[cpg]


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa016"]
[OnName num="sawa"]
'你太可愛了。你看起來很解氣'。
[cpg cn=true]

我實際上是鬆了一口氣。我很激動，但也鬆了一口氣。
[cpg]


之後，我筋疲力盡，直接和我母親一起睡了。 ......
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





然後第二天，在媽媽醒來之前，我回到了我的房間。
[cpg]


沒過多久，搗蛋的管理層就開始了。這就是我注意到的地方。
[cpg]


我想，經常給人捶打可能會使我更加依賴它。
[cpg]


另一方面，如果我不這樣做，我將很難呼吸。 ......
[cpg]


我在想該怎麼辦，但也在想，我不能再這樣下去了。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari012"]
[OnName num="himari"]
'Onii-chan。今天我們也和我漂亮的小妹妹親熱一下吧'。
[cpg cn=true]


緋紅說，類似這樣的話。你說自己很可愛。 ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari070"]
[OnName num="himari"]
'爸爸已經走了，所以...... 籲，你可以做任何你想做的事。
[cpg cn=true]


你說的"任何東西"是什麼意思？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Suzune079"]
[OnName num="suzune"]
'別鬧了。趁我不注意的時候做吧'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari071"]
[OnName num="himari"]
'Ew.'不要緊，你沒看到也沒關係，姐姐。
[cpg cn=true]



她姐姐的反應是合理的，但緋紅似乎也預見到了這一點。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





我尷尬地回到我的房間里呆了一會兒，但仔細一想這是個壞主意。
[cpg]


這意味著我不能在早上感到興奮。它可以持續到午餐時間。
[cpg]


我是否應該按照緋紅的要求在這裡做，即使我感到有點尷尬？
[cpg]


不，不，不，不，我畢竟不能在我母親和妹妹面前這樣做。 ......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我的衝突並沒有持續很久。
[cpg]


我知道我不能什麼都不做。我覺得我失去了一些東西給Himari。 ......
[cpg]


我決定跟隨緋紅。除了她的母親，她的姐姐冷冷地看著我。
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari072"]
[OnName num="himari"]
'為什麼你不從一開始就按我說的做？你太固執了'。
[cpg cn=true]


我決定聽從緋紅的安排。除了她的母親，她的姐姐冷冷地看著我。
[cpg]



;//========================================
;//●ＣＧ（倒れ込んでいる主人公にキスをしようとするヒロイン。寸止めでキスはしない）ev_12
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の家＿リビング
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari013"]
[OnName num="himari"]
'嘿，讓我們接吻吧。這是你能做的最激動人心的事情'。
[cpg cn=true]


然後我們就出現了這種情況。緋紅比我們早了一步。
[cpg]


看來她不僅僅是......，看著我倒下和悸動而感到有趣。
[cpg]


[OnName num="gorou"]
'你說吻的時候是認真的嗎，......？
[cpg cn=true]


緋紅看起來好像不是在開玩笑。而且她也是那種說到做到的人。
[cpg]


;**【ＣＧ】 ev_12_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari014"]
[OnName num="himari"]
'我是認真的。你也想讓我這樣做，是嗎，大哥？
[cpg cn=true]


我認為這當然是最令人興奮的事情。然而。
[cpg]


[OnName num="gorou"]
'如果我這樣做，除了...... 接吻之外，我可能無法對其他事情感到興奮。
[cpg cn=true]


[VOICE f="sHimari015"]
[OnName num="himari"]
'......，你是什麼意思？
[cpg cn=true]


[OnName num="gorou"]
並不是說突然做這樣的事情不好，更像是習慣了就不好了。 "
[cpg cn=true]


;**【ＣＧ】 ev_12_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari016"]
[OnName num="himari"]
'嗯，這就是困擾我的地方。
[cpg cn=true]


緋紅說得好像這是別人的問題，但對我來說這是一個嚴重的問題。
[cpg]


[OnName num="gorou"]
'我確實關心! 如果我的心臟不能再跳動，我就會死。 "
[cpg cn=true]


[VOICE f="sHimari017"]
[OnName num="himari"]
'你需要放棄。我不會再讓你得逞了'。
[cpg cn=true]


緋紅似乎是認真的。如果她不打算讓他逃跑，那麼也許他就不能逃跑。
[cpg]


[OnName num="gorou"]
'等待，等待.......'
[cpg cn=true]


緋紅比我更有力量，而我比緋紅更有女人味。
[cpg]


;**【ＣＧ】 ev_12_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari018"]
[OnName num="himari"]
'我等不及了。來吧，把你的臉轉向這邊。 "
[cpg cn=true]


說著，Himari將她的臉靠近。
[cpg]


她柔軟的嘴唇也同時靠近。他們幾乎碰在一起。
[cpg]


我可以聞到好聞的味道。緋紅就在身邊，閉著眼睛。
[cpg]


而當我快到時，我就下定決心。
[cpg]


我等待著，等待著，等待著她的嘴唇接觸.......
[cpg]


[OnName num="gorou"]
"...... 什麼？"
[cpg cn=true]


在我等待的過程中，我沒有感覺到有任何...... 嘴唇貼著我。
[cpg]


然後，她及時地把臉拉開。
[cpg]


;**【ＣＧ】 ev_12_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari019"]
[OnName num="himari"]
'呵。你感覺到撲通一聲嗎？
[cpg cn=true]


對，這就是我的意思。我被帶去兜風了。
[cpg]


[OnName num="gorou"]
嗯，嗯。
[cpg cn=true]


她天生就是這樣的人。不要把她說的話看得太重。 ......
[cpg]


[VOICE f="sHimari020"]
[OnName num="himari"]
那麼我想我們的目標已經實現了。 "
[cpg cn=true]


緋紅可能是一個令人驚訝的縱容者。
[cpg]


還是她只是在挑逗我？或者只是做他們想做的事？
[cpg]


我不是什麼都知道，但我剛才的重擊是相當不錯的，所以我不能抱怨: ......
[cpg]


;**【ＣＧ】 ev_12_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari021"]
[OnName num="himari"]
'那好吧，祝你今天好運。因為當我的兄弟受苦時，我也會受苦'。
[cpg cn=true]


[OnName num="gorou"]
'謝謝你......'
[cpg cn=true]


我不知道謝謝你是否是正確的回應，但沒有別的可說。
[cpg]



;//ブラックアウト

但是，我仍然想知道在我妹妹面前這樣做是否合適。
[cpg]


我不確定在她面前這樣做是否合適，但這是我一直在考慮的事情。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************


而在與緋紅做了這樣的事情后，姐姐的冷言冷語也在等著我。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="sSuzune020"]
[OnName num="suzune"]
'這真的很不謙虛。我想知道她是否沒有尷尬的感覺'。
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari089"]
[OnName num="himari"]
'嘿嘿。我想我沒有'。
[cpg cn=true]


我有。所以我感到抱歉和尷尬，我覺得我不能說什麼。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune082"]
[OnName num="suzune"]
'哦，好吧。我現在要走了。 "
[cpg cn=true]


[OnName num="gorou"]
'是的，繼續，繼續。 ......'
[cpg cn=true]



我妹妹總是早早離開。我們在這之後。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************





過了一會兒，我和緋紅不得不離開房子。
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa079"]
[OnName num="sawa"]
'再見。回頭見。 "
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari090"]
[OnName num="himari"]
我走了。 "
[cpg cn=true]


緋紅歡快地回答道。我沒有這個心情。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


;//[jump storage="ep003.ks" target="*start"]



;/////////////////////////////////////////////////////////////////////

*start

;###################################################################
*Ep003|我的耐心已經接近極限了。
;###################################################################


[SCENE id=3]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（朝）******************************************************





當我在城裡走動時，就不會這樣了。我是說，這一刻也很難說。
[cpg]


但還不足以讓我感到心慌意亂。我也逐漸習慣了這些石頭。
[cpg]


下一次，我姐姐會幫我做。等到這個時候，我走了。
[cpg]


如果我沒有這樣的短期目標，或者沒有路線圖，我也沒辦法。
[cpg]


當我想到它是永遠持續下去的東西時，我感到很無助。 ......。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（朝）******************************************************


[SE f="se002"]
;//【ＳＥ】『喧噪』


然後我們到達了學院。我想我已經從第一天的搗亂管理中多少平靜下來了。
[cpg]


[OnName num="male_student"]
'你前一陣子看起來有點不舒服，但你最近看起來好多了。這是一種解脫。 "
[cpg cn=true]


[OnName num="gorou"]
'是的，...... 是的，我想這些天情況相當好。
[cpg cn=true]


我知道我周圍的人認為這很奇怪。我在思考這個問題。
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************



上課的時候已經很辛苦了，而且是在中午。
[cpg]


我甚至在吃晚飯之前就想去我姐姐那裡，但那樣她可能也吃了。
[cpg]


最終，大約在午休的晚些時候，我終於前往我姐姐的地方。
[cpg]


我沒有太多的時間，但我仍然不能什麼都不做。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune021"]
[OnName num="suzune"]
'......，聽起來你的日子很難過。

[cpg cn=true]


[OnName num="gorou"]
姐姐......，我已經快死了。 "
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune084"]
[OnName num="suzune"]
'對。我被告知有獲得另一種疾病的風險'。
[cpg cn=true]


她一邊平靜地說話，一邊把我的手拉開。
[cpg]


我想如果她看到這一點會很糟糕，但她把我帶到了學生諮詢室。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_03_2_up.ui" time=1000]
[WAIT time=2000]


如果我不斷地重複這樣做，它一定會升級的。
[cpg]


如果是這樣的話，我最終會不會也親吻我的妹妹？
[cpg]


我想知道我的妹妹對我有什麼看法，等等。
[cpg]


我不認為我想做她不希望我做的事。
[cpg]


或者......，她還會為我即將死去而感到悲傷嗎？
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



我走出學生指導辦公室，確定沒有人在看。
[cpg]


如果有人看到我，他們又會對我說三道四。
[cpg]


我不能一直做這種事。
[cpg]


我需要更有創意一些，......，但我不知道怎麼做。
[cpg]


我在校園裡的整個過程中，都無法忍耐。
[cpg]



[window target=false]

[WAIT time=2000]

[BG f="b_03_3.ui" time=1500]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



同時，現在是放學後。
[cpg]


我試圖回家。現在是我還能設法忍受的時候，.......。
[cpg]


[OnName num="male_student_A"]
'嘿，小坂。讓我們回家休息一下，找點樂子。 "
[cpg cn=true]


[OnName num="male_student_B"]
'你最近不善於社交。怎麼了？ "
[cpg cn=true]


[OnName num="gorou"]
'不，有事情發生。所以，請讓我回家。 ......"
[cpg cn=true]


[OnName num="male_student_A"]
沒有。好了，我們去電玩城吧。 "
[cpg cn=true]


他一開始就是一個好朋友。我確實不能忽視他們。
[cpg]


但是你知道。 ......，我越晚回家就越難。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夜）******************************************************



男孩們就在我旁邊。或者說，我和所有男孩一起玩。
[cpg]


而我卻在尋找一個暗戀的對象。
[cpg]


我周圍的人似乎不知道發生了什麼事，他們以為我感冒了或什麼。
[cpg]


所以我被提前釋放了，但......，還是已經是午夜了。
[cpg]


[OnName num="gorou"]
'哦，......，這很糟糕，這是...... 糟糕。
[cpg cn=true]



我不禁想到了我母親的臉。我想知道爸爸是否已經回來了。
[cpg]


如果我想讓他做一些事情，我需要盡快做。 ......，我回去了，思考。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa080"]
[OnName num="sawa"]
'歡迎回來。你回來晚了。 "
[cpg cn=true]


[OnName num="gorou"]
'對不起......，對不起。 ......
[cpg cn=true]


[OnName num="father"]
'你在哪裡停了下來？快到晚飯時間了。 "
[cpg cn=true]


[OnName num="gorou"]
是的，......，那是......."
[cpg cn=true]


它不是為了告訴你在哪裡停過車而建造的。
[cpg]


但這還不是最糟糕的部分。爸爸的家。
[cpg]


會不會是在他吃晚飯的時候，我必須堅持下去？
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


我的猜測是正確的。主要是因為我父親回來後，我母親不可能為我做什麼。
[cpg]


我心裡充滿了苦澀，這讓緋紅覺得很好笑。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari091"]
[OnName num="himari"]
'嗯，嗯。 '現在大哥哥，你真可愛。你的母親真狡猾'。
[cpg cn=true]


[OnName num="father"]
'......?'
[cpg cn=true]


爸爸顯然不知道我在說什麼。
[cpg]


這很好，但我當時的情況很危急，我無法圍繞它做出適當的決定。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



在最後一分鐘，我母親對我說。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa081"]
[OnName num="sawa"]
我在我的房間裡等你。你可以隨時來'。
[cpg cn=true]


他現在想去......。我是這麼想的，但我不能讓爸爸起疑。
[cpg]



;//ブラックアウト


遠遠超過了我的忍耐極限，我逐漸失去了立足之地。
[cpg]


就在那個時候，我去了我母親的地方。
[cpg]


就像我再也無法忍受了。 ......
[cpg]


;//========================================
;//●ＣＧ（主人公に胸を押しつけるヒロイン。主人公の体に少し触れている感じ）ev_14
;//人物１：ヒロイン３
;//服装１：パジャマ
;//人物２：主人公
;//服装２：パジャマ
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa017"]
[OnName num="sawa"]
'你今天一定過得很辛苦。我要給你一個好的依偎'。
[cpg cn=true]


[OnName num="gorou"]
"...... 母親，先生。"
[cpg cn=true]


[VOICE f="sSawa018"]
[OnName num="sawa"]
'這很難。現在一切都好了。 "
[cpg cn=true]


[OnName num="gorou"]
哦，哦，......."
[cpg cn=true]


我感到很欣慰，忍不住要發出有趣的聲音。
[cpg]


[VOICE f="sSawa019"]
[OnName num="sawa"]
'咯咯笑。這對你來說一定很困難。
[cpg cn=true]


僅僅通過觸摸她，我就能感覺到某種大腦化學物質被釋放。
[cpg]


我不禁知道，這一定是我現在需要的東西。
[cpg]


我很激動，但也鬆了一口氣。這是一種奇怪的感覺，我已經失去了表情。
[cpg]


;**【ＣＧ】 ev_14_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa020"]
[OnName num="sawa"]
'我怎麼能讓你激動呢？
[cpg cn=true]


他一邊說一邊輕輕地撫摸著我的身體。我覺得我無法忍受它。
[cpg]


[OnName num="gorou"]
'我已經夠緊張了。
[cpg cn=true]


[VOICE f="sSawa021"]
[OnName num="sawa"]
'是的。很好'。
[cpg cn=true]


我覺得我似乎想擁抱她，但我忍住了。
[cpg]


[VOICE f="sSawa022"]
[OnName num="sawa"]
'你的脈搏變得非常快。我可以感覺到它。
[cpg cn=true]


緊張是很自然的。有些人說，如果你接近這樣一個美麗的人，你.......
[cpg]


還有來自一個地方的重擊，比如說如果我爸爸發現了會發生什麼。
[cpg]


我知道光是有這些感覺就是個問題。
[cpg]


我知道我這樣做是不道德的，我也知道光有這些感覺是有問題的，但我不能壓制它們。
[cpg]


;**【ＣＧ】 ev_14_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa023"]
[OnName num="sawa"]
你想今天再一起睡嗎？
[cpg cn=true]


媽媽說了一句相當大膽的話。
[cpg]


[OnName num="gorou"]
'嗯，那是...... 確實不好。
[cpg cn=true]


[VOICE f="sSawa024"]
[OnName num="sawa"]
'我很好。只要五郎沒問題就好。
[cpg cn=true]


當你說這樣的話時，我很想這麼做，但我......，忍住了。
[cpg]


如果我父親發現了，他會懷疑發生了什麼。
[cpg]


我父親在某些方面可以說是直言不諱，但仍然是一個糟糕的......。
[cpg]


[OnName num="gorou"]
'......，我還是不行。我今天要回去了。 "
[cpg cn=true]


[VOICE f="sSawa025"]
[OnName num="sawa"]
'是嗎？我這里永遠歡迎你。 "
[cpg cn=true]


當你說這樣的話時，我幾乎是在考慮。
[cpg]


不過，與我姐姐和緋紅不同，我知道我不會對我母親犯任何錯誤。
[cpg]



;//ブラックアウト

帶著遺憾的心情，我離開了母親的房間。
[cpg]


儘管這是我的職責，但他對我來說是一個不可替代的人，我不知道這樣做是否正確。
[cpg]


這不可能是好事。 ......我知道，但我無法停止。
[cpg]






;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』



之後，我就癱軟在我的房間裡。
[cpg]


無論我怎麼覺得自己被折騰得太厲害，我都無法以自己的意志......。
[cpg]


這主要是我的體質。但......
[cpg]


我想知道我母親是否也對你有看法。或者，也許她不像我一樣有任何暗戀的對象。
[cpg]


我還想到了這個：......
[cpg]



;//■選択肢
[switch]
[case "我為我的父親感到遺憾。"]
	[swap]
	[jump target="*select02_1"]
[case "如果你對我有想法，我想回應一下。"]
	[swap]
	[jump target="*select02_2"]
[endswitch]

第一，我為我的父親感到遺憾。
二，如果你對我有看法，我想回應。



;//==============================
;//１、父に申し訳ない
*select02_1|我的耐心已經接近極限了。




我為我的父親感到遺憾，不是嗎？我和媽媽是陌生人，但爸爸和媽媽是夫妻。
[cpg]


這並不意味著我們有血緣關係，但......，我仍然認為我做錯了什麼。
[cpg]


我並不是說，如果是向日葵或我的妹妹，我就不會有什麼想法了。
[cpg]

[jump target="*select02_3"]


;//==============================
;//２、何か思ってくれてるなら応えたい

*select02_2|我的耐心已經接近極限了。



如果我媽媽還在想什麼，我覺得我別無選擇，只能做出回應。
[cpg]


即使是尖酸刻薄的關係，你也不能突然斷絕關係。也許這是相互的。 ......
[cpg]



[stflag Cha3flg = 1]

;//ヒロイン３が候補に



;//==============================

*select02_3|我的耐心已經接近極限了。


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]



;//[jump storage="ep004.ks" target="*start"]


;/////////////////////////////////////////////////////////////////////

*start

;###################################################################
*Ep004|我們為每個人著想。
;###################################################################

[SCENE id=4]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[transition target={false} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





早晨。我被一個不怎麼好的夢驚醒。
[cpg]


我夢見我在一個我不知道在哪裡的地方，周圍有我的母親、姐姐和緋紅。
[cpg]


我認為夢到別人是可以的。但我不這樣做，就有點瘋狂了。
[cpg]


想到這裡，我帶著一種無奈的心情走向餐廳。
[cpg]



;//ブラックアウト


[window target=false]



[BG f="b_04_1_up.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="gorou"]
'嘿，緋紅是在......？
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Sawa099"]
[OnName num="sawa"]
'我不知道--我不知道。也許他還在他的房間裡？
[cpg cn=true]


我有麻煩了。 ......，我得往我的方向走？我感覺我正在失去。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Suzune102"]
[OnName num="suzune"]
'好吧，我現在要走了。回頭見。 "
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se000"]
;//【ＳＥ】『ノック』



我敲了敲緋紅的房間，敲了敲它的門。
[cpg]


[VOICE f="Himari092"]
[OnName num="himari"]
'你可以進來了。你是她的哥哥，對嗎？
[cpg cn=true]


[OnName num="gorou"]
"...... 是的。"
[cpg cn=true]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_04_1_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari093"]
[OnName num="himari"]
'我一直想試試那種情況，你哥哥到我房間來，你知道嗎？
[cpg cn=true]


緋紅是無憂無慮的。我們的生命危在旦夕。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari022"]
[OnName num="himari"]
'你看起來很苦惱。你不能沒有我，對嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'你沒有錯。我生病了'。
[cpg cn=true]


緋紅說她病了，她並不高興。
[cpg]


[VOICE f="sHimari023"]
[OnName num="himari"]
'好吧，我不在乎是不是因為我生病了。只要你到我身邊來'。
[cpg cn=true]



說著，緋紅張開雙手。我無法拒絕這個邀請。
[cpg]


;//移植前シーンカット



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（昼）******************************************************





日子就這樣一點點地過去了。
[cpg]


對我來說，這似乎是一個無盡的時間，但顯然只過去了大約一個星期。
[cpg]


而我又去了醫院。然後我發現：......
[cpg]


[window target=false]


[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



這畢竟是一種未知的憲法，是我們已經知道了一段時間的東西，但我已經看到了一個電燈泡的時刻。
[cpg]


這一線生機是我希望我沒有再看到的。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Sawa100"]
[OnName num="sawa"]
'...... 醫生，你說了一些驚人的事情！ '
[cpg cn=true]


[OnName num="gorou"]
'嗯，是的。 ......，我不知道我是否想考慮太多。
[cpg cn=true]


醫生說，這種情況是一種愛上某人的本能過度活躍的狀態。
[cpg]


他解釋說，通過與別人相愛，憲法會平靜下來。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari113"]
[OnName num="himari"]
'這就像你感冒了，它就會消失。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune103"]
[OnName num="suzune"]
'我認為......，這是不同的。
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





回到家裡，回到我的房間，我遇到了麻煩。
[cpg]


愛上某人了嗎？這是個大問題了。
[cpg]


我沒有女朋友。如果我這樣做，就不會發生這種情況。
[cpg]


...... 緋紅和她的妹妹呢？我從來沒有聽說過她有男朋友，也沒有聽說過她有男朋友。
[cpg]


如果我不檢查，這就不好了。這是一個關於未來的故事。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



這就是為什麼我問我姐姐和緋紅。
[cpg]


[OnName num="gorou"]
'...... 你們倆有男朋友嗎？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune104"]
[OnName num="suzune"]
'你突然間怎麼了......，不，想那種事是很誘人的。
[cpg cn=true]


大姐似乎已經猜到了什麼，臉紅了。還有。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune105"]
[OnName num="suzune"]
'不，我不知道。 Himaru也不例外。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari024"]
[OnName num="himari"]
'是的。我也是'。
[cpg cn=true]



緋紅在說這句話時笑了。這看起來是一種歡迎，但這是一種歡迎的態度。 ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune106"]
[OnName num="suzune"]
'我很好。如果是為了五郎'。
[cpg cn=true]


她更進一步。 '好，你是什麼意思？你是什麼意思？
[cpg]


[OnName num="gorou"]
'那是...... 誤聽，聽起來很好？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sHimari025"]
[OnName num="himari"]
'只有你姐姐是偷偷摸摸的。我和你在一起'。
[cpg cn=true]


......，我不得不把我的頭從我的屁股裡拿出來。
[cpg]


姑娘們說，這對我來說很好。甚至愛上了我。 ......
[cpg]



;//■選択肢
[switch]
[case "你不能這樣做。"]
	[swap]
	[jump target="*select03_1"]
[case "我可能不得不這樣做。"]
	[swap]
	[jump target="*select03_2"]
[endswitch]
第一，你不能這樣做。
二，我們可能不得不這樣做。



;//==============================
;//１、そんなことはできない
*select03_1|這個想法在每個人的腦海中都有。




我還是做不到。我不能這樣做......
[cpg]


更不用說你的姐姐和緋紅了，你的母親更糟糕。
[cpg]


我帶著這些想法回到了我的房間。
[cpg]


[jump target="*select03_3"]

;//==============================
;//２、そうするしかないかもしれない

*select03_2|思想是給大家的。



但你不可能一直這樣生活，對嗎？
[cpg]


也許有一天我會和其他人在一起。 ......
[cpg]


帶著這些想法，我離開了這個地方。
[cpg]

[stflag Cha1flg = 1]

;//後の選択肢で選択肢４が候補に



;//==============================

*select03_3|思想與誰同在


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





幾天的通行證。在你知道之前，這又是一個工作日。
[cpg]




[window target=false]

[STOPBGM]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





從那時起，我必須定期提高我的心率。
[cpg]


那段日子是如此痛苦，以至於我終於想到要治好病情本身。
[cpg]


然而，我想不出有誰能與之相愛。
[cpg]


班上有一些女孩和我相處得很好，但當我想到我是否喜歡她們時，我想不出有誰......。
[cpg]


不，更重要的是，讓我們撇開你是否愛上某人不談：......
[cpg]


我必須至少和一個人談起這個問題，才能感到舒服。
[cpg]


我想，如果我要談戀愛，真的，假想一下，會是誰呢？
[cpg]



[if exp={getFlagValue("Cha1flg") == 0 }]
[endif]

[if exp={getFlagValue("Cha2flg") == 0 }]
[endif]

[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*select04_1"]
[endif]
//////////////////////////////////////////

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*C2"]
[endif]

[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*Out2C3"]
[endif]


[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "紀曉嵐"]
	[swap]
	[jump target="*select04_1"]
[case "我無法選擇。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]


[jump target="*select04_1"]
//////////////////////////////////////////
*Out2C3|誰對誰有感情？

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "居順"]
	[swap]
	[jump target="*select04_1"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[case "我無法選擇。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "紀曉嵐"]
	[swap]
	[jump target="*select04_1"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[endswitch]

//////////////////////////////////////////
*C2|你在想誰？
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*C2C3"]
[endif]

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "紀曉嵐"]
	[swap]
	[jump target="*select04_1"]
[case "太陽雨"]
	[swap]
	[jump target="*select04_2"]
[case "我無法選擇。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "壽命說明"]
	[swap]
	[jump target="*select04_1"]
[case "陽光"]
	[swap]
	[jump target="*select04_2"]
[endswitch]

//////////////////////////////////////////
*C2C3|誰在你心中

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "壽命說明"]
	[swap]
	[jump target="*select04_1"]
[case "陽光"]
	[swap]
	[jump target="*select04_2"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[case "我無法選擇。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "紀曉嵐"]
	[swap]
	[jump target="*select04_1"]
[case "太陽雨"]
	[swap]
	[jump target="*select04_2"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[endswitch]








;//■選択肢
[switch]
[case "慶祝長壽"]
	[swap]
	[jump target="*select04_1"]
[case "太陽雨"]
	[swap]
	[jump target="*select04_2"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[case "不能選擇"]
	[swap]
	[jump target="*select04_4"]
[endswitch]

1、鈴音。
2, Himari
3，蘇納
4，我無法選擇。



;//ここまでの選択で候補になっている選択肢から選択
;//ただし、候補がヒロイン１のみの場合選択肢は発生せずそのまま進行


;//*select04_1|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[jump storage="ep005.ks" target="*start"]


;//*select04_2|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[jump storage="ep006.ks" target="*start"]



;//*select04_3|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[jump storage="ep007.ks" target="*start"]


;//*select04_4|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[jump storage="ep008.ks" target="*start"]


;//==============================

*start

;###################################################################
*Ep005|關於鈴音的思考
;###################################################################


;//１、寿々音
*select04_1|對蘇珊的看法


[SCENE id=5]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


...... 我想她畢竟是我的妹妹。
[cpg]


我認為她是最可靠的人。有一些東西是缺失的，但她仍然與緋紅和我的母親非常不同。
[cpg]


緋紅做什麼事都太隨和了，而我母親則有些軟弱和放鬆。
[cpg]


但這並不是愛上她的理由。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我早早起床，只有我和我妹妹。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune107"]
[OnName num="suzune"]
'早上好。你今天起得很早。 "
[cpg cn=true]


[OnName num="gorou"]
'是的。 ...... 嘿，我需要和你談點事。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune108"]
[OnName num="suzune"]
'我想知道。是關於憲法的嗎？
[cpg cn=true]


我點點頭，繼續與我的妹妹交談。
[cpg]


[OnName num="gorou"]
'......，我想如果我要愛上一個人，她會是唯一的一個。 ......'
[cpg cn=true]


[OnName num="gorou"]
'但如果我們那樣做，我們就會在家族中結婚，不是嗎？所以，你知道。 "
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
我一直在說，我不能歸結為什麼。最後。
[cpg]


[OnName num="gorou"]
'......，我應該怎麼做呢？
[cpg cn=true]


他總結說。她沒有給我一個驚愕的眼神。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune109"]
[OnName num="suzune"]
'首先，你必須和你喜歡的人在一起。 '如果是因為你認為我會原諒你，這仍然不是一個好主意。
[cpg cn=true]


[OnName num="gorou"]
我知道。 ......，是的，我可以看到。 "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune110"]
[OnName num="suzune"]
'那麼你最好考慮一下你喜歡誰。然後我們可以談一談。 "
[cpg cn=true]


......，我不能說什麼。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




;//＠
之後，緋紅讓我的心跳加快，我就去了學院。
[cpg]


不知何故，當我和緋紅在一起時，我不能想太多東西。
[cpg]


我不禁想起了我的妹妹。
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************





然後我在學校花了一些時間。現在輪到我去我姐姐那裡了。
[cpg]


在遇到她之前，我是如此緊張，以至於我無法與遇到緋紅時相比。
[cpg]



;//ブラックアウト


[window target=false]



[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『学園教室』（昼）******************************************************





空蕩蕩的教室。我們帶著某種尷尬的心情面對著對方。
[cpg]

;//ブラックアウト

;//========================================
;//●ＣＧ（主人公と密着するヒロイン。胸が当たっている）ev_16
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]





我的姐姐接近我。我們在學校裡，而她卻在做這個。
[cpg]


由於我的體質，這是沒辦法的事，無論我怎麼想......。
[cpg]


並非所有其他看到這一幕的人都會這麼想。
[cpg]


而這一事實正是讓我心跳加速的原因。
[cpg]


[VOICE f="sSuzune022"]
[OnName num="suzune"]
'我不知道.......所有這些東西是否讓你感到緊張？ "
[cpg cn=true]


我只是與她保持密切聯繫。儘管這只是一次親密接觸，但我非常興奮，因為她對我非常重要。
[cpg]


只要能有這樣的感覺，能夠接觸對方就意味著很多。
[cpg]


[OnName num="gorou"]
......"
[cpg cn=true]


我甚至連一個字都說不出來。看到這一點，我妹妹很擔心。
[cpg]


;**【ＣＧ】 ev_16_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune023"]
[OnName num="suzune"]
'如果你不說點什麼，我就會擔心。
[cpg cn=true]


當他走到那一步時，我終於回復了。
[cpg]


[OnName num="gorou"]
'是的。這是非常......。 "
[cpg cn=true]


;**【ＣＧ】 ev_16_b ***********************
[CG id=7 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune024"]
[OnName num="suzune"]
'不要告訴我這很好。你會讓我意識到這一點的。
[cpg cn=true]


她很冷淡，但我可以看出她有點尷尬。
[cpg]


如果她感到尷尬，說明她對我有看法。
[cpg]


這也讓我很高興。除了高興之外，我還想說的是。
[cpg]


[OnName num="gorou"]
你臉紅了。
[cpg cn=true]


;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune025"]
[OnName num="suzune"]
'你這麼說，但你也是如此。
[cpg cn=true]


我一直希望能在她身邊。
[cpg]


如果我說，只要有她在，我就不需要別的東西，我覺得對緋紅很不好.......
[cpg]


即便如此，我的姐姐對我來說是一個不可替代的存在。
[cpg]


我不知道如何將她與其他任何人進行比較。
[cpg]


;**【ＣＧ】 ev_16_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune026"]
[OnName num="suzune"]
'我的身體也開始發熱，我在這裡......，這讓我很尷尬。
[cpg cn=true]


我對我和我妹妹之間這種微妙的距離感念念不忘。
[cpg]


當然，現在我在身體上非常接近，但我的思想卻不是。
[cpg]


[OnName num="gorou"]
'......，你妹妹似乎也很激動。
[cpg cn=true]


我注意到，她的脈搏在加快。
[cpg]


;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune027"]
[OnName num="suzune"]
'真的嗎？不僅僅是你這樣。 "
[cpg cn=true]


[OnName num="gorou"]
'我不這麼認為。 ......，我認為這是我的想像力。
[cpg cn=true]


[VOICE f="sSuzune028"]
[OnName num="suzune"]
'這只是我的想像。
[cpg cn=true]


我所說的一些話是真的嗎？這就是我的想法，我們都在......。
[cpg]


在這個世界上只有我們兩個人，或者說他們是這麼說的，但這是一個學院。
[cpg]


我可以聽到另一個學生的聲音就在外面。我有一部分人感到緊張，因為我們並不孤單。
[cpg]


教會我這些感覺的姐妹是不可替代的。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


我和我妹妹在白天的時候互相觸摸。
[cpg]


晚上，是我的母親。早上是緋紅。那些日子已經持續了很久，現在也不會改變。
[cpg]


[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





第二天早上。向學校走去，我在路上與女孩們會合。
[cpg]


[OnName num="female_student"]
'早上好，小坂君。
[cpg cn=true]


[OnName num="gorou"]
'哦，早上好......'
[cpg cn=true]


[OnName num="female_student"]
'最近，小坂君改變了他的情緒，是嗎？我不知道該怎麼說，這更像是憂鬱。 ......
[cpg cn=true]


[OnName num="gorou"]
'什麼，......？你在說什麼？ "
[cpg cn=true]


[OnName num="female_student"]
'不，這沒什麼! 到時見。 "
[cpg cn=true]


...... 那個迅速離開的女孩可能也對我有好感。
[cpg]


我也沒有一個這樣的女孩。
[cpg]


但當你想到要一起度過你的餘生時，情況就不同了。
[cpg]


回想起來，我跟隨姐姐的腳步已經有很長一段時間了。
[cpg]


我一直很佩服她。我又意識到了這一點。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


然後早晨又變成了中午，是我和我妹妹在一起的時候了。
[cpg]

[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[OnName num="gorou"]
'......Oh，請。這對我來說已經很困難了。 ......"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune130"]
[OnName num="suzune"]
'這對你來說一定很困難。我知道，如果我站在你的立場上，我也會很難過。
[cpg cn=true]


...... 一些奇怪的說法。如果你處於我的位置，你會怎麼做？
[cpg]


[OnName num="gorou"]
你的意思是......？ "
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune029"]
[OnName num="suzune"]
'這沒什麼。更重要的是，你今天在做什麼？
[cpg cn=true]


我是被迫作弊的。而我仍然呼吸困難。
[cpg]



我不能過多地考慮其他事情。對。
[cpg]


[OnName num="gorou"]
那好吧，......."
[cpg cn=true]


;//========================================
;//●ＣＧ（座っているヒロインのことを見つめる主人公）ev_17
;//人物１：ヒロイン１
;//服装１：スーツ（はだけ）
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


我想出了一些和以前不一樣的東西，我決定給它一個機會。
[cpg]


我妹妹看起來有點驚愕，但這很好，包括她臉上的表情。
[cpg]


[VOICE f="Suzune134"]
[OnName num="suzune"]
'......，你想出了最奇怪的事情。
[cpg cn=true]


今天，我將停止要求我的妹妹觸摸我或接近我。
[cpg]


我想看著我妹妹。我曾要求她這樣做。
[cpg]


[OnName num="gorou"]
'這並不奇怪。我認為你想一直看著我。
[cpg cn=true]


她似乎對我的話有些迷惑。
[cpg]


;**【ＣＧ】 ev_17_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune030"]
[OnName num="suzune"]
'你確定你想這樣做，只是看著？
[cpg cn=true]


[VOICE f="sSuzune031"]
[OnName num="suzune"]
'我認為你需要觸摸它或接近它，或......，這樣的東西。
[cpg cn=true]


沒有這些，我就已經很激動了。我現在可能會這樣。
[cpg]


[OnName num="gorou"]
...... 是的。 "
[cpg cn=true]


看著她，她似乎是我需要的一切。
[cpg]


我不好意思這麼說，但我這麼想也沒關係。
[cpg]


;**【ＣＧ】 ev_17_b ***********************
[CG id=8 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune032"]
[OnName num="suzune"]
她看五郎的樣子，有點噁心。 "
[cpg cn=true]


[OnName num="gorou"]
'是的，我不認為如此。
[cpg cn=true]


她看起來很困惑和尷尬。
[cpg]


唯一的一點是，被盯著看是被盯著看的人可能在想的事情。
[cpg]


[OnName num="gorou"]
'姐姐......，真的非常、非常漂亮。
[cpg cn=true]


她剛才在看我，現在又看向別處。
[cpg]


;**【ＣＧ】 ev_17_c ***********************
[CG id=8 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune033"]
[OnName num="suzune"]
'你怎麼敢？
[cpg cn=true]


[OnName num="gorou"]
'我沒有撒謊。我是認真的。
[cpg cn=true]


她對我的話做出了輕微的顫抖姿態。
[cpg]


[VOICE f="sSuzune034"]
[OnName num="suzune"]
我的手指都沒放在她身上，但這太奇怪了。這也讓我很緊張。
[cpg cn=true]


姐姐說這話時臉紅了。
[cpg]


我不能就這樣看著她。
[cpg]


[OnName num="gorou"]
我想繼續盯著她看。姐姐。
[cpg cn=true]


那個更害羞的妹妹開口了。
[cpg]


;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune035"]
[OnName num="suzune"]
'......，就像被五郎的話語所觸動。
[cpg cn=true]


她這樣說並不是在撒謊。
[cpg]


作為證據，她的妹妹甚至臉紅到了耳根。
[cpg]


我想觀察一切，甚至她是如何看起來像那樣的。這就是我的感覺。
[cpg]


接受我的目光和話語的姐妹。
[cpg]


我覺得那裡有一些像母親的東西。
[cpg]


[OnName num="gorou"]
'即使我只是看著她，我也很高興。
[cpg cn=true]


;**【ＣＧ】 ev_17_c ***********************
[CG id=8 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune036"]
[OnName num="suzune"]
'不要感到尷尬。不過，我受寵若驚了。
[cpg cn=true]


她當然看起來既尷尬又高興。
[cpg]


我只為這個感到高興。
[cpg]


[FG f="ci_lbox.ui" method="feadin_up"  pos="4/7"]

[WAIT time=1000]
;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】『学園のチャイム』


時間過去了一段時間。我們不可能永遠在一起，我們不可能和對方在一起。
[cpg]


午餐時間過後，我和姐姐都要去上課。
[cpg]


這一次比以往任何時候都更讓人沮喪。
[cpg]





[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


還有下午上課後，放學後。
[cpg]


[window target=false]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



傍晚時分的學校。我們離開教室，試圖回家。
[cpg]


在那裡我有這樣的想法。
[cpg]


一天三次，一天三次，我有時間激動不已。 ......
[cpg]


所有這些，我都是為了想和我妹妹在一起。
[cpg]


首先，我必須和我媽媽談談。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************





當我回到家時，就像這樣，只有我媽媽在那裡。
[cpg]


[OnName num="gorou"]
'哦，你知道，...... 母親。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa101"]
[OnName num="sawa"]
'這是什麼？這對你來說有點早，不是嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'不，不是那個，是那個。這是關於你晚上要為我做什麼，我想讓...... 你的妹妹來代替我。
[cpg cn=true]


我解釋說。只有關於我喜歡我妹妹的部分仍然被隱藏著。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa102"]
[OnName num="sawa"]
'...... 是的。我明白了。
[cpg cn=true]


但我的媽媽似乎把一切都想好了。這是正確的，她是我的母親。 ......
[cpg]




;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[WAIT time=1000]

[SE f="se012"]
;//【ＳＥ】『ノック』


[WAIT time=1500]

[window target=true]


;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune151"]
[OnName num="suzune"]
我進來了，戈羅。
[cpg cn=true]


[OnName num="gorou"]
呃，是的。 ...... 進來吧。 "
[cpg cn=true]


[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune037"]
[OnName num="suzune"]
'我聽說了。你想讓我做你母親的那份？
[cpg cn=true]


[OnName num="gorou"]
我想不會。 ...... 真的，這取決於我。 "
[cpg cn=true]


不知怎的，我有種感覺，他們不會說不。
[cpg]


然後我的姐姐微微嘆了口氣，說
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune153"]
[OnName num="suzune"]
'你認為如果你告訴我這些，我能說不嗎？真的，他是一個可愛的小兄弟。 "
[cpg cn=true]



;//========================================
;//●ＣＧ（密着する二人。ヒロインが体を前に倒している状態。ヒロインの髪が主人公の体に当たっている）ev_18
;//人物１：ヒロイン１
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：主人公の部屋
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]


[SE f="se004"]
;//【ＳＥ】『衣擦れ』


[BGM f="bg_h1"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune038"]
[OnName num="suzune"]
'也許......，我也已經瘋了。
[cpg cn=true]


他說這話時，表情略顯渾濁，或者說他的眼睛裡有一種憂鬱的神情。
[cpg]


[OnName num="gorou"]
'你這話是什麼意思？
[cpg cn=true]


姐姐在選擇她的話語。她彷彿不知道該說什麼。
[cpg]


[VOICE f="sSuzune039"]
[OnName num="suzune"]
'沒有你，我感覺好像我的心在痛苦。
[cpg cn=true]


...... 我應該如何看待這個問題？
[cpg]


與其說是深思熟慮，不如說是感覺他按捺不住，言之有物。
[cpg]


當然，我的體質讓我很痛苦，但我無法想像我的妹妹會從我這裡得到這些。
[cpg]


[VOICE f="sSuzune040"]
[OnName num="suzune"]
'我覺得我想更接近你。我不知道為什麼'。
[cpg cn=true]


你妹妹的長發貼著我的身體。我感到很沮喪。
[cpg]


[OnName num="gorou"]
'妹子。你的頭髮讓我很癢。 "
[cpg cn=true]


她不是沒有註意到，但我敢於說出來。然後。
[cpg]


;**【ＣＧ】 ev_18_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune041"]
[OnName num="suzune"]
'真的嗎？你不喜歡它？ "
[cpg cn=true]


他說了一句話，讓人分外難受。
[cpg]


[OnName num="gorou"]
'......，我並不討厭它。
[cpg cn=true]


[VOICE f="sSuzune042"]
[OnName num="suzune"]
'很好，那麼。讓我像這樣多呆一會兒吧'。
[cpg cn=true]


姐姐說了一些咄咄逼人的話。我不覺得我這樣做只是為了讓她緊張。
[cpg]


也許這就是它的開始，但它與我的憲法已經沒有關係。
[cpg]


我覺得我們已經到了一個不應該有的地步。
[cpg]


但這是......，即使如此，我也不討厭它。
[cpg]


[OnName num="gorou"]
'是的。這是......，直到它讓你感覺更好。 "
[cpg cn=true]


;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune043"]
[OnName num="suzune"]
'這很古怪。我是為了你的憲法而做的。
[cpg cn=true]


但我覺得那是一個藉口，或者說是我們共同的逃避途徑。
[cpg]


當這種體質被治好後，我們將做什麼？
[cpg]


[VOICE f="sSuzune044"]
[OnName num="suzune"]
'我可以聞到五郎的味道。
[cpg cn=true]


當然，相反的情況也是如此。這就是我們的關係。
[cpg]


彷彿不僅是我們的身體，而且我們的心也變得更加緊密。
[cpg]


;**【ＣＧ】 ev_18_b ***********************
[CG id=9 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune045"]
[OnName num="suzune"]
這很奇怪。我們總是在一起，但你似乎是一個不同的人。
[cpg cn=true]


當她這樣說時，她更加靠近。呼吸打。
[cpg]


我希望時間能像這樣停止。我想這麼想，我覺得撲通撲通的聲音讓我很解氣。 ......
[cpg]


因重擊而感到安心，聽起來像是一個矛盾，但這是此刻對我來說最合適的詞。
[cpg]


我相信這是一對半路出家的戀人所感受不到的。
[cpg]


;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune046"]
[OnName num="suzune"]
我想多和你在一起。我也很擔心你。
[cpg cn=true]


儘管我和妹妹沒有血緣關係，但我們也是姐妹和兄弟。
[cpg]


我在那裡感到安全一定是有原因的。
[cpg]


[VOICE f="sSuzune047"]
[OnName num="suzune"]
'如果這樣做會讓我感覺更好，我會......，一直這樣做。
[cpg cn=true]


她在說這句話時，把她的皮膚拉到我身上。
[cpg]


[OnName num="gorou"]
'我很高興。姐姐'。
[cpg cn=true]


這對我來說是一種浪費，但這並不意味著我不想把它給別人。
[cpg]


我想讓她成為我的親妹妹。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]



[OnName num="gorou"]
'謝謝你。我現在很好。 "
[cpg cn=true]


呼吸不再有任何疼痛感。但我的心卻有些痛苦。
[cpg]


彷彿我的身體和思想彼此不一致。
[cpg]


[VOICE f="sSuzune048"]
[OnName num="suzune"]
'真的嗎？別緊張。 "
[cpg cn=true]


我真的很想和你睡覺，但如果我這樣做了，我可能會習慣於我所受到的重擊。
[cpg]



[window target=false]


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




我不覺得自己會被那些常見的、奇怪的夢境驚醒。
[cpg]


也許這是對我姐姐為我所做的事情的滿足。
[cpg]


我並不感到孤獨，即使是在一個人的房間裡。 ......
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



還有早晨。現在我必須要和緋紅談談。
[cpg]


我想我應該昨天就做了，因為......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari026"]
[OnName num="himari"]
'早上好。來吧，今天我再給你一個刺激。 "
[cpg cn=true]


真讓人吃驚，因為緋紅走過來對我說。
[cpg]


她還把她漂亮的大奶子推給我，但我雖然不應該被掃地出門。
[cpg]


[OnName num="gorou"]
'哦，你知道，......，我很抱歉你總是這樣對我，但那.........'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari117"]
[OnName num="himari"]
'什麼？你甚至想讓我和你妹妹交換位置嗎？ "
[cpg cn=true]


[OnName num="gorou"]
是的。 ......"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Himari118"]
[OnName num="himari"]
'我主要是從你母親那裡聽說的。你一定是真的那麼喜歡你的妹妹'。
[cpg cn=true]


緋紅看起來有點悲傷。
[cpg]


這就是為什麼，或者說......，我感到有什麼東西把我推到了邊緣。
[cpg]


我不能再這樣下去了。半心半意的態度甚至會傷害到緋紅。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune170"]
[OnName num="suzune"]
'......，我也在早上做？一天三次，不過都是由我來做。 "
[cpg cn=true]


[OnName num="gorou"]
'哦，不？
[cpg cn=true]


她笑了一下。我一定是看起來很傻。
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune049"]
[OnName num="suzune"]
'不，我不知道。然後.......'。
[cpg cn=true]


;//ブラックアウト

;//========================================
;//●ＣＧ（主人公に寄り添うヒロイン。朝出かける前）ev_19
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：朝
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



我不需要任何更多的話，但我不想保持沉默，所以我說。
[cpg]


[OnName num="gorou"]
'這很溫暖。 '姐姐'。
[cpg cn=true]


姐姐看著我。然後她問道。
[cpg]


[VOICE f="sSuzune050"]
[OnName num="suzune"]
'......，難道你光是在我身邊就沒有快感了嗎？
[cpg cn=true]


[OnName num="gorou"]
'不。不，不是的'。
[cpg cn=true]


[VOICE f="sSuzune051"]
[OnName num="suzune"]
你確定你沒有在逼迫它嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'這是真的，我告訴你。你看起來沒有任何痛苦的證據'。
[cpg cn=true]


[VOICE f="sSuzune052"]
[OnName num="suzune"]
'真的嗎？我希望如此。 "
[cpg cn=true]


她在說這句話時向我靠攏。
[cpg]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[VOICE f="sSuzune053"]
[OnName num="suzune"]
'...... Goro對我來說比什麼都重要。我很抱歉讓你認為我不是。
[cpg cn=true]


觸感柔軟。就在這時，我的心才停止了跳動。
[cpg]


我想更接近。我的慾望並沒有就此停止。
[cpg]


我想成為你的...... 情人。
[cpg]


[OnName num="gorou"]
姐姐。嗯，嗯......"
[cpg cn=true]


我正準備說些什麼，我妹妹卻不肯閉嘴，看到我說不出話來。
[cpg]


;**【ＣＧ】 ev_19_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune054"]
[OnName num="suzune"]
'我也很緊張，...... 你知道嗎？
[cpg cn=true]


[OnName num="gorou"]
是的。我得到了這個消息'。
[cpg cn=true]


就像我越不主動，我妹妹就越親近。
[cpg]


這種關係在某種程度上讓人感到安心，與重擊的方式不同。
[cpg]


;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune055"]
[OnName num="suzune"]
胡胡，這有點尷尬。 "
[cpg cn=true]


他們在一起的時間在談論這些事情時過去了。
[cpg]


[OnName num="gorou"]
'我可能會感到尷尬，但我想留在你的身邊......。
[cpg cn=true]


[VOICE f="sSuzune056"]
[OnName num="suzune"]
是的，我也一樣。 "
[cpg cn=true]


她覺得自己與姐姐的關係比任何人都要密切，但仍然感到很沮喪。
[cpg]


[VOICE f="sSuzune057"]
[OnName num="suzune"]
'吾郎 ......'
[cpg cn=true]


她撫摸著我的頭，低聲說。
[cpg]


她撫摸著我的頭髮。她的臉也走近了。
[cpg]


而且她的嘴唇越來越近。我趕緊閉上眼睛。
[cpg]


我幾乎失去了距離。我不能以這種緊迫性做任何事情。
[cpg]


;**【ＣＧ】 ev_19_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune058"]
[OnName num="suzune"]
'週週'。
[cpg cn=true]


他們互相撫摸。她向我走了一步。
[cpg]


我太愛她了，以至於我覺得自己要......，失去了控制。言語無法解釋我有多愛她。
[cpg]


我不認識這麼可愛的人。我覺得我現在就想抱抱她。
[cpg]


我不能永遠這樣做，儘管我無法抗拒。
[cpg]


;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune059"]
[OnName num="suzune"]
......，差不多該走了。我得走了。 "
[cpg cn=true]


在我什麼都做不了的時候，我姐姐對我說了這句話。
[cpg]


我咒罵自己的無能，但我很高興她吻了我。
[cpg]


[OnName num="gorou"]
我很高興她吻了我。回頭見。 "
[cpg cn=true]


我不可能在一段時間內忘記她嘴唇的感覺。
[cpg]


我是說一段時間。 ...... 這將是一個我永遠不會忘記的吻。
[cpg]


;//ブラックアウト



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


然後我妹妹比我先離開了家。
[cpg]


這是很平常的事情，但關於它的孤獨感卻與平常不同。
[cpg]


我去學校的時候會看到她，但我會非常想念她。
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa103"]
[OnName num="sawa"]
我待會兒見。要小心。
[cpg cn=true]


[OnName num="gorou"]
'是的，我去了......'。
[cpg cn=true]


我們和緋紅一起離開了房子。我心裡有一些想法。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************



我要向我姐姐坦白。我想和她在一起。
[cpg]


她是我不可替代的妹妹，但我還是想。
[cpg]


我還想親吻她，擁抱她。
[cpg]


這並不是說我想治愈這種體質或什麼。 ......
[cpg]


我意識到，我仍然喜歡我的妹妹。
[cpg]


我可以說，這要歸功於緋紅。如果她不告訴我，我可能永遠不會從心底里意識到這一點。
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

白天，像往常一樣，我讓我的姐姐提高我的心率。但在放學後，......。
[cpg]

[WAIT time=1000]

[STOPBGM]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（夕方）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune190"]
[OnName num="suzune"]
'現在怎麼辦......？你在白天已經做過了。 "
[cpg cn=true]


[OnName num="gorou"]
'...... 姐姐，你說我應該和我喜歡的人在一起。
[cpg cn=true]


姐姐的表情變得有些僵硬。也許她在想像會說什麼。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune191"]
[OnName num="suzune"]
'......，那怎麼辦？
[cpg cn=true]


不過，我還是得說。我不能讓我妹妹猜到。
[cpg]


如果我在這樣的地方被寵壞了，我的餘生就真的被寵壞了。
[cpg]


[OnName num="gorou"]
"哦，我......，我是，你知道，......"。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune192"]
[OnName num="suzune"]
'我知道，我知道。你喜歡我，對嗎？ "
[cpg cn=true]


哦，不。這種趨勢將使我的餘生都受到寵愛。
[cpg]


但我現在不能幫助它。我已經說了我的觀點。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune193"]
[OnName num="suzune"]
'別擔心，我也喜歡你。不是作為一個兄弟，而是作為一個情人。
[cpg cn=true]




;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



我和我妹妹分別回家。我們有不同的工作和學習，有不同的時間投入其中。
[cpg]


但我想了一下，至少今天我想一起回家。
[cpg]


最後，我姐姐讓我先回家，但......，我有點迫不及待地想見到她。
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





那天的飯桌上沒有什麼異常。
[cpg]


我還是和往常一樣。我妹妹和往常一樣。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari119"]
[OnName num="himari"]
'再來一個! 大約百分之七十在碗裡！ "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune194"]
[OnName num="suzune"]
'你會發胖的。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Himari120"]
[OnName num="himari"]
'與我姐姐不同，我並沒有得到多少好處，我。
[cpg cn=true]


我認為我的姐姐是瘦的那個，緋紅說。
[cpg]


但姐姐並沒有露出厭惡的神情。或者說，她在某種程度上高於它。 ......。
[cpg]


...... 我想知道他們是否在想我。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





還有夜晚。我妹妹在我的房間裡。
[cpg]


[OnName num="gorou"]
'呃，呃，......，很高興見到你。
[cpg cn=true]


一天三次，出於三次心跳。然而，我卻非常緊張。
[cpg]


在這一切中，我妹妹對我說。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune060"]
[OnName num="suzune"]
'我必須告訴你，我從來沒有過女朋友。
[cpg cn=true]


[OnName num="gorou"]
'誒......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune061"]
[OnName num="suzune"]
我是說你是第一個。 "
[cpg cn=true]


說著，她向他走近。
[cpg]


;//移植前シーンカット
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]

;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]



[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

當我和姐姐在一起時，我覺得內心深處很充實。
[cpg]


這可能是人們固有的東西，而不是與他們的憲法有關的東西。
[cpg]


我感到很興奮。甚至在她離開後，我也睡不著，因為我太緊張了。
[cpg]


我想讓她永遠留在我身邊。但她離開了房間。
[cpg]


我說這是沒辦法的事，我也沒辦法。如果我父親發現她從我的房間出來，那就糟糕了。
[cpg]


我沒有選擇，只能等待明天。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



然後明天就來了，這有點尷尬。
[cpg]


我從未想過我會有這樣的感覺。她是我一直認識的那個姐姐。
[cpg]


她看起來像一個不同的人，或者也許是我變了。
[cpg]


我目送她離開房子，心想。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune213"]
[OnName num="suzune"]
我第一次見到她時，我想："好吧，那我走了，戈羅。緋紅。
[cpg cn=true]


[OnName num="gorou"]
是的。要小心。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari121"]
[OnName num="himari"]
祝你有個愉快的一天。 "
[cpg cn=true]

[free time=1000]
爸爸也離開了家。我們剩下的三個人是我、緋紅和我母親。
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Sawa104"]
[OnName num="sawa"]
'那麼，你打算怎麼做？我想知道他是否要和鈴音約會。
[cpg cn=true]


[OnName num="gorou"]
'E...... yeah, yeah.這就是計劃'。
[cpg cn=true]


經過片刻的困惑，我能夠給出我的答案。
[cpg]


我再也無法隱藏它了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="Himari122"]
[OnName num="himari"]
'要快樂。我也喜歡你的哥哥'。
[cpg cn=true]


[OnName num="gorou"]
"...... 是的。"
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』





還有學院的一個空教室。
[cpg]


我與我的妹妹面對面，搖搖晃晃，掙扎著要呼吸。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune214"]
[OnName num="suzune"]
'...... 我。我不想這樣做，因為我的體質。
[cpg cn=true]


他一邊走一邊告訴我這些。
[cpg]


我猜他很擔心，因為他在想我。我對此有一定的了解。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune215"]
[OnName num="suzune"]
'此外，當緋紅和你母親在處理五郎時，我不禁感到嫉妒。
[cpg cn=true]


[OnName num="gorou"]
'......，就是這麼回事。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune062"]
[OnName num="suzune"]
'不過，現在很好。我將填補...... 他們所有人。 "
[cpg cn=true]


對。關於我的一切都在我姐姐的手上。
[cpg]


這感覺相當令人欣慰。
[cpg]


;//移植前シーンカット



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

從現在起，我可以永遠呆在你身邊。僅僅是這樣想，我就覺得有點鬆了一口氣。
[cpg]


[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************



在我鬆了一口氣的同時，我對搗蛋的慾望也越來越強烈。
[cpg]


這其實只是一個小小的時間差，但我再也受不了了。
[cpg]


我再也無法忍受了。但我姐姐說那是晚上。
[cpg]


首先，現在她是我的妹妹而不是我的母親，我不能一回家就看到她。
[cpg]


我走了，感覺無法忍受。 ......
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





晚餐。我爸爸是唯一不知道我和我妹妹之間發生了什麼的人。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari123"]
[OnName num="himari"]
'那麼你的姐姐和弟弟去哪裡了？
[cpg cn=true]


在這一切中，緋紅說了這樣一段話。我幾乎把正在吃的食物噴了出來。
[cpg]


[free time=1000]

[OnName num="father"]
'你在說什麼？
[cpg cn=true]


[OnName num="gorou"]
'不，這沒什麼! 這沒什麼。 "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]

話雖如此，我的妹妹看起來有點暴躁。
[cpg]


是的，有一天我必須向我父親解釋。
[cpg]


他從來沒有像一個嚴格和頑固的父親，但......
[cpg]


不過，有些事情還是讓我緊張。一想到要告訴我爸爸，我就有些焦慮。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





而且夜夜如此。在我達到極限之前，我妹妹來到我的房間。
[cpg]



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune063"]
[OnName num="suzune"]
'你看起來很高興。
[cpg cn=true]


[OnName num="gorou"]
'......，有那麼明顯嗎？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune064"]
[OnName num="suzune"]
'是的。不過，她在這方面也很可愛。
[cpg cn=true]


我很尷尬，但等著看我妹妹會怎麼做。
[cpg]


我不知道，我經常這樣做。不過，我傾向於帶頭。
[cpg]

;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



我看著姐姐再次回到她的房間，我在痛苦中設法睡著了。
[cpg]


明天，我們仍將是戀人。我很高興。 ......
[cpg]


我應該高興得不得了，但我的體質中有一種緊繃的感覺。
[cpg]


我必須做一些事情。要做到這一點，我想我需要和我的妹妹做一些更有情趣的事情。
[cpg]


這是一種...... 巨大的事情，但首先我必須向我父親解釋。
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


而這一天出乎意料地迅速到來。
[cpg]

[window target=false]

[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************





[OnName num="gorou"]
'嗯，我不能! 我還沒有準備好。 "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune253"]
[OnName num="suzune"]
'爸爸，我今天心情很好。 '不是說他總是心情不好。
[cpg cn=true]


;//＠
一個星期天。有人找我談了這個問題。
[cpg]


我的意思是，我告訴我爸爸。 "把你的女兒給我！"還有。
[cpg]


;//ブラックアウト


[window target=false]

[STOPBGM]

[free time=1000]

[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



沒有緋紅和媽媽。這是我、我爸爸和我妹妹。
[cpg]


[OnName num="father"]
"......"
[cpg cn=true]


[OnName num="gorou"]
"......"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune254"]
[OnName num="suzune"]
'所以這就是為什麼我們......，不，Goro可以和你說話嗎？
[cpg cn=true]

爸爸沒有嚴厲的面孔，但接近於無表情，有點嚇人。
[cpg]


[OnName num="gorou"]
'嗯，把你的女兒交給...... 我。
[cpg cn=true]


[OnName num="father"]
......"
[cpg cn=true]


在我說這句話的時候，我想我看到了爸爸嘴角的微笑。
[cpg]


[OnName num="gorou"]
'志，不。嗯，我想和我妹妹...... Suzune-san出去，或者說，我們要出去。
[cpg cn=true]


[OnName num="father"]
'噗，哈哈哈! 哦，是的，我知道你有一天會這樣。 "
[cpg cn=true]


[OnName num="gorou"]
什麼？ ......？ "
[cpg cn=true]


爸爸的反應令人驚訝。我原本以為他也會感到困惑。
[cpg]


[OnName num="father"]
'不，在這種情況下，要照顧好鈴音。我相信五郎將能夠幫助你'。
[cpg cn=true]


他寬慰地笑了笑，向我們表示祝賀。
[cpg]


我想，這是一個多麼偉大的父親，當然我也很感激......，所以......
[cpg]


[OnName num="gorou"]
哦，非常感謝你，......."
[cpg cn=true]


我說。我從來沒有對我父親經常使用過禮貌用語。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





[OnName num="gorou"]
'......，很順利。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune255"]
[OnName num="suzune"]
'對。我以為我是有點名氣的'。
[cpg cn=true]


他們在那裡仍然是父子關係嗎？
[cpg]


我不理解我父親的所有感受，但我的姐姐似乎理解。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune256"]
[OnName num="suzune"]
我不知道怎麼做，但我不打算這樣做。這很難，不是嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'是的。 ......，這很難。
[cpg cn=true]


我的體質仍在癒合。我很確定我已經愛上了，但可能還需要一點時間才能治愈我的體質。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune065"]
[OnName num="suzune"]
'來。現在我希望你能讓......，我很激動。
[cpg cn=true]


[OnName num="gorou"]
'......，我會努力的。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune258"]
[OnName num="suzune"]
胡憂，你已經長大了，可以這麼說了。 "
[cpg cn=true]


姐姐拍拍她的頭。我感到很尷尬。
[cpg]

;//移植前シーンカット

;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************




幾天的通行證。暑假已經開始，嗯，沒關係。
[cpg]


校外已經有傳言說我愛上了我的妹妹。
[cpg]


而在到處都是謠言的情況下，暑假仍然是曙光。
[cpg]


這成為全校的大新聞。無數的男孩為此感到震驚，甚至女孩也有一些粉絲或不知道。 ......
[cpg]



[window target=false]

[STOPBGM]

[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]


[window target=true]


;//【ＢＧ】『街』（夜）******************************************************



儘管如此，日子還是一天天過去了。我想毫無顧忌地以我姐姐的情人身份出現。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune066"]
[OnName num="suzune"]
'......，現在，你難道不覺得苦嗎？
[cpg cn=true]


[OnName num="gorou"]
是的。輕鬆多了。 "
[cpg cn=true]


從那時起，我的體質就像一個謊言一樣安定下來。
[cpg]


所以醫生說的都是真的，起初我以為是個笑話。
[cpg]


我想知道我是否可以用'憲法'這個詞把它收起來，但我和我妹妹沒有必要再靠近了。
[cpg]


不過，這並不改變我們想要對方的事實。
[cpg]


[OnName num="gorou"]
我能說什麼呢，那些日子好像是個謊言。 ......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune278"]
[OnName num="suzune"]
'對。那些日子是那些日子，它們很有趣，但是......
[cpg cn=true]


[OnName num="gorou"]
'現在你不能忍受你的妹妹？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune279"]
[OnName num="suzune"]
我真的希望你不要再叫我 "姐姐"。
[cpg cn=true]


[OnName num="gorou"]
Ugh, it's ......"
[cpg cn=true]


當然，現在是時候解決這個問題了。
[cpg]


[OnName num="gorou"]
'但你不能幫助已經變得根深蒂固的東西，是嗎？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune067"]
[OnName num="suzune"]
'比如說，如果你有一個孩子，你還會把我稱為你的妹妹嗎？
[cpg cn=true]


[OnName num="gorou"]
那我就叫你媽媽。 "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune281"]
[OnName num="suzune"]
'......，你越來越善於歸還東西了。
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune068"]
[OnName num="suzune"]
'我希望我可以整天和你在一起。我們不必再對任何人隱瞞了'。
[cpg cn=true]


[OnName num="gorou"]
我說，"對。"...... 嘿。
[cpg cn=true]


她開始撫摸我的頭髮。我扭動著身體，癢癢的。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune069"]
[OnName num="suzune"]
'什麼？
[cpg cn=true]


[OnName num="gorou"]
'那很癢，哈哈哈，哈哈哈'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune070"]
[OnName num="suzune"]
'你認為五郎有被撓的弱點嗎？要我為你做更多嗎？ "
[cpg cn=true]


這是一個多麼適合調情的時代。


[window target=false]

[SE f="se000"]
;//【ＳＥ】『ノック』

[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




在這一切之中，有人敲響了我房間的門。
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari124"]
[OnName num="himari"]
'兄弟，你要用我的漫畫走那條路嗎？
[cpg cn=true]


[OnName num="gorou"]
'哦，緋紅......？嗯，我不知道。 "
[cpg cn=true]


現在已經很晚了。在這個時候，談論漫畫？
[cpg]


我想，我猜測。有人暗示我太吵了。
[cpg]


[OnName num="gorou"]
'......，很吵嗎？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari125"]
[OnName num="himari"]
'什麼？更重要的是，漫畫呢？ "
[cpg cn=true]


[OnName num="gorou"]
'哦，呃，我不認為我借了它。 ......'
[cpg cn=true]


我妹妹已經猜到了，讓我閉嘴。然而。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari126"]
[OnName num="himari"]
'嗯。好吧，那就祝你們倆好運。
[cpg cn=true]

[free time=1000]

緋紅說過這樣的話。我知道你太吵了。
[cpg]


[OnName num="gorou"]
'......，我應該怎麼做，姐姐？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune299"]
[OnName num="suzune"]
'別擔心。我說，'我祝愿你一切順利'。
[cpg cn=true]


這是事實，但我認為這是......，具有諷刺意味。
[cpg]


;//＠なんて思いつつ、俺達はもう一度交わることにした。




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


更多的時間過去了。我的體質已經完全穩定下來，我再也不用去醫院了。
[cpg]


他們要求我解釋發生了什麼，但我只是感到尷尬。
[cpg]


我想知道我是否應該讓我妹妹在我旁邊。我正在考慮這個問題。
[cpg]


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************



然後時間就過去了。有一個假期，我和我的妹妹在散步。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune316"]
[OnName num="suzune"]
她說："我們結婚後可以住在同一個房子裡，這很方便。"
[cpg cn=true]


[OnName num="gorou"]
'哦，那是肯定的。你不會在那裡迷路的'。
[cpg cn=true]


真是一場對話，我們的關係又有點不同了。
[cpg]


我妹妹懷孕了。顯然，這是一個女孩，我們已經想好了名字。
[cpg]


[OnName num="gorou"]
'所以......，我不知道我要做什麼。我仍然不確定我是否會繼續接受高等教育'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune317"]
[OnName num="suzune"]
'我們之前已經談過這個問題了。繼續接受高等教育'。
[cpg cn=true]


[OnName num="gorou"]
'但你會讓你的妹妹陷入困境。抓緊時間找工作不是更好嗎？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune318"]
[OnName num="suzune"]
'五郎的優先事項應該是他想做的事情。 '你又不是給我糟蹋了，或者什麼，你可以依靠我。
[cpg cn=true]


......，如果你想說那麼多，我就不說了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_01_2_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune071"]
[OnName num="suzune"]
'總之，你記得今天是什麼日子嗎？
[cpg cn=true]


[OnName num="gorou"]
'讓我看看......，是什麼......'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune072"]
[OnName num="suzune"]
'你不記得了？這是我們開始約會的日子，不是嗎？ "
[cpg cn=true]


[OnName num="gorou"]
我不記得我們開始約會的日子，......，也不記得我們成為戀人的日子。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune073"]
[OnName num="suzune"]
我們想要慶祝，即使這部分有點模糊。 "
[cpg cn=true]


[OnName num="gorou"]
我想知道它是否是這樣的。 "
[cpg cn=true]



[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune074"]
[OnName num="suzune"]
五郎這樣的人太沉悶了。
[cpg cn=true]


[OnName num="gorou"]
'不，不。日期有點模糊，但我也一直想慶祝一下'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune075"]
[OnName num="suzune"]
什麼？ "
[cpg cn=true]


[OnName num="gorou"]
'我有一個禮物給你。我回家後要不要打開它？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune076"]
[OnName num="suzune"]
感謝......."
[cpg cn=true]



[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


孩子出生後，我真的很忙。
[cpg]


我是個學生，但我算是個家庭主夫，我必須撫養孩子。
[cpg]


但我不認為這是艱苦的工作。我真的不認為這是必要的或任何東西。
[cpg]


這就是我和我的妹妹......，鈴音的日子是多麼快節奏和可愛。
[cpg]



時間在迅速流逝。而三年已經過去了。
[cpg]




;//========================================
;//●ＣＧ（街を三人で歩く。幸せそうなヒロインと娘の笑顔が正面から見えるアングル）ev_26
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//人物３：主人公の娘
;//服装３：私服
;//場所　：街
;//時間　：昼
;//備考　：娘の年齢は三歳くらいです。また、本編から三年の時間が経過しています
;//========================================




[BGM f="bg_h1"]
;**【ＣＧ】 ev_26_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]




我想，我們成了一對幸福的夫婦。
[cpg]


我沒有和鈴音打過一次架。我們不吵架，我們沒有那種關係。
[cpg]


我們周圍的人羨慕我們，但這是我們之間的自然距離。
[cpg]


我現在不想打架。我們在一起生活的時間比大多數夫妻都長。
[cpg]


我們甚至比一對兒時的朋友更了解對方。
[cpg]


[VOICE f="Suzune319"]
[OnName num="suzune"]
嘿，吾郎。
[cpg cn=true]


鈴音轉向我，微笑著說。
[cpg]


[OnName num="gorou"]
怎麼了，鈴音？
[cpg cn=true]


[VOICE f="Suzune320"]
[OnName num="suzune"]
'你很高興。我仍然無法相信我將作為你的妻子而感到幸福'。
[cpg cn=true]


...... 那是因為我當姐姐的時間比較長。這也是沒辦法的事。
[cpg]


但最終你們會花更大比例的時間作為夫妻。
[cpg]


我必須盡快擺脫當她小弟的命運。我的某些部分把鈴音當成了我的妹妹。
[cpg]


;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

而當我從鈴音的小弟弟畢業時，她可能會有一個妹妹或弟弟。
[cpg]


考慮到這些想法，我們已經走了很長的路。
[cpg]



[SCENE id=9]

[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン１ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

*start

;###################################################################
*Ep006|珍惜緋紅。
;###################################################################

;//==============================
;//２、ひまり
*select04_2|珍惜陽光


[SCENE id=6]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


我認為...... 緋紅。雖然可依賴，但並不討人喜歡。
[cpg]


但如果你問我喜歡誰，我喜歡緋紅。
[cpg]


她就像一個孩子，但也有母性。
[cpg]


她有一部分把我玩弄於股掌之間，我已經越來越喜歡她了。
[cpg]


我不知道我是否有欺負人的氣質，喜歡這樣的人。
[cpg]


但我不介意和緋紅在一起。 ......
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[WAIT time=1000]



[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari127"]
[OnName num="himari"]
'One-chan。這是早晨的樂趣！ "
[cpg cn=true]


當我在思考這個問題的時候，緋紅來了。
[cpg]


[OnName num="gorou"]
'啊，啊。是的。 .......'
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari128"]
[OnName num="himari"]
'怎麼了？你看起來不舒服。
[cpg cn=true]


[OnName num="gorou"]
'不是我心情不好，是......，我需要和你談點事情。
[cpg cn=true]


他重新轉向向日葵。然後他切入正題。
[cpg]


[OnName num="gorou"]
'...... 你知道他們怎麼說嗎，當你愛上一個人時，你的體質就會安定下來？
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari129"]
[OnName num="himari"]
'我知道。我知道醫生是怎麼說的'。
[cpg cn=true]


[OnName num="gorou"]
'那麼，...... 緋紅呢？
[cpg cn=true]


我很謹慎地問道。但緋紅似乎已經猜到了。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari027"]
[OnName num="himari"]
'嗯，是的。如果是和我哥哥一起，我完全沒問題。我想我也會很高興。 ......"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari028"]
[OnName num="himari"]
'如果我們在一起，病情沒有消失，你打算怎麼做？
[cpg cn=true]


[OnName num="gorou"]
'你打算怎麼做？ ......，這當然是令人不安的。
[cpg cn=true]


而我想的是我自己，但緋紅似乎在想一些不同的事情。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Himari132"]
[OnName num="himari"]
'你可能會和其他人欺騙我。有了這樣的憲法，'。
[cpg cn=true]


嗯，我很擔心這個問題，我想.......
[cpg]


[OnName num="gorou"]
'我不會的。我可以向你保證。 "
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari133"]
[OnName num="himari"]
'我不相信。我相當懷疑和妒忌'。
[cpg cn=true]


緋紅來找我，說它不止於此。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari029"]
[OnName num="himari"]
'現在，我給你一個刺激。我們該怎麼做？ "
[cpg cn=true]


[OnName num="gorou"]
哦，請......"
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin_up"  pos="4/7"]

[BG f="b_06_1_up.ui" time=10]
[WAIT time=200]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari030"]
[OnName num="himari"]
'現在我們該怎麼做？我厭倦了用我的手觸摸你。
[cpg cn=true]


[OnName num="gorou"]
即使你說你很無聊......，那麼你要做什麼呢？ "
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari031"]
[OnName num="himari"]
'嗯，今天......，這樣的事情怎麼樣？
[cpg cn=true]


緋紅做了一些不同的事情，說。
[cpg]


;//========================================
;//●ＣＧ（ヒロインに足蹴にされる主人公。からかうような表情のヒロイン）ev_27
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：朝
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]



所以她把她的腳，而不是她的手，貼近我的身體。
[cpg]


我當時想，'你以為我是什麼人？ '但我不能拒絕，因為如果我不喜歡，就會不計後果地結束它。
[cpg]


[VOICE f="sHimari032"]
[OnName num="himari"]
'我不知道。我不知道，大哥哥，我想你從這種事情中得到了刺激。 "
[cpg cn=true]


你不能在這裡表現得像你很高興。另一方面，我也不能勉為其難。
[cpg]


[OnName num="gorou"]
嗯
[cpg cn=true]


[VOICE f="sHimari033"]
[OnName num="himari"]
'你看起來不開心，但我知道你其實很開心。
[cpg cn=true]


[OnName num="gorou"]
'我不高興......，你認為我有什麼樣的個性？
[cpg cn=true]


但他肯定很激動。
[cpg]


;**【ＣＧ】 ev_27_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari034"]
[OnName num="himari"]
'如果這是一個徵兆，我希望你能這麼說。你這麼固執，很可愛'。
[cpg cn=true]


[OnName num="gorou"]
'我並不是說要直言不諱。
[cpg cn=true]


是嗎？她邊說邊看著我的反應。
[cpg]


[VOICE f="sHimari035"]
[OnName num="himari"]
我認為刺激來自於不尋常的情況。
[cpg cn=true]


對於這個問題，緋紅是如何想出這些東西的？
[cpg]


[OnName num="gorou"]
緋紅一直在考慮...... 這些事情。 "
[cpg cn=true]


;**【ＣＧ】 ev_27_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari036"]
[OnName num="himari"]
'嗯？總是這樣嗎？ "
[cpg cn=true]


[OnName num="gorou"]
所以，即使你沒有看到我。
[cpg cn=true]


[VOICE f="sHimari037"]
[OnName num="himari"]
'我不知道，我不知道...' 這只是我想到的一個想法。 "
[cpg cn=true]


緋紅邊說邊用腳摸索著我的胸甲。
[cpg]


這不是怕癢或什麼。但這感覺很奇怪，是不道德的。
[cpg]


然而，我沒有做任何討厭的事情。 ......。
[cpg]


[VOICE f="sHimari038"]
[OnName num="himari"]
'你更喜歡哪一個，你的手還是你的腳，大哥哥？
[cpg cn=true]


[OnName num="gorou"]
什麼，這個問題？
[cpg cn=true]


他問了我一些很奇怪的問題，我無法保持冷靜。
[cpg]


我無法直視他。緋紅看穿了這一點。
[cpg]


;**【ＣＧ】 ev_27_b ***********************
[CG id=12 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari039"]
[OnName num="himari"]
'別裝傻了，我正在努力決定下一步為你做什麼。
[cpg cn=true]


[OnName num="gorou"]
'......'
[cpg cn=true]


你說了那麼多，我甚至無法回答。
[cpg]


我擔心如果我說腳，他們現在會對我做什麼，如果我說手，他們就會停止現在做的事情。
[cpg]


[VOICE f="sHimari040"]
[OnName num="himari"]
'嗯，好的。從現在開始，我也會讓你在晚上感受到這種刺激。
[cpg cn=true]


當我在思考這個問題時，Himari說了一句更令人驚訝的話。
[cpg]


她表現得非常積極。這又不是我要求她做的。
[cpg]


[OnName num="gorou"]
'誒，...... 可以嗎？
[cpg cn=true]


[VOICE f="sHimari041"]
[OnName num="himari"]
'不是我不介意，更多的是我想讓它屬於我自己。你媽媽也會給你的。我確定'。
[cpg cn=true]


他們把你當做一個東西，好像你都是自己的，或者你把它送人。
[cpg]


但我也很高興，或者說我覺得我可以感受到緋紅對我的愛。
[cpg]




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


觸摸她之後，痛苦的時間又回來了。
[cpg]


但是，我可以在中午看到我的姐姐，此外，她還說緋紅會在晚上為我做。 ......
[cpg]


相信這一點，我只得暫時忍耐。
[cpg]


[window target=false]


[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************



[SE f="se000"]
;//【ＳＥ】『歩く』





走在街上。一路走到學院。
[cpg]


同時，它仍然沒有那麼痛苦。但當上午的課程即將結束時，這是最困難的。
[cpg]


到午餐時間的時間，或者說，這就是......，不管你怎麼想，你都必須做好準備。
[cpg]




[window target=false]


[STOPBGM]

[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************





[OnName num="male_student"]
'嘿，小坂。我聽說你前幾天和一個女孩在一起散步。
[cpg cn=true]


[OnName num="gorou"]
'什麼？嗯，情況並非總是如此。 ......"
[cpg cn=true]


[OnName num="male_student"]
別裝傻了! 你說你和一個女孩手拉手，她都在你身上。 "
[cpg cn=true]


[OnName num="gorou"]
你在說什麼呢？我不認識任何與我關係那麼好的女孩。 ......"
[cpg cn=true]


哦，他來了。緋紅。也許有人在她離開房子時看到了她或其他東西。
[cpg]


但如果是這樣，很明顯，她是我的妹妹。
[cpg]


[OnName num="gorou"]
這是我的妹妹。她的名字叫小坂緋紅。
[cpg cn=true]


[OnName num="male_student"]
'哦，啊......，所以她是你的妹妹。所以她不是你的女朋友或什麼？
[cpg cn=true]


[OnName num="gorou"]
'...... 是的。是的，不是女朋友。 "
[cpg cn=true]


...... 一般來說，妹妹不是愛人。
[cpg]


我瘋了，不是嗎？我必須被提醒這一點。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



;//その後、昼休みになって姉さんに抜いてもらった。
;//＠
後來，在午餐時間，我讓我姐姐提高我的心率。
[cpg]


事後。我姐姐說了這樣的話。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune321"]
[OnName num="suzune"]
'嘿。你喜歡緋紅嗎？也許是某種形式的懺悔？ "
[cpg cn=true]


[OnName num="gorou"]
'......，你知道我的意思嗎？
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune322"]
[OnName num="suzune"]
'我可以看到。緋紅早上離開你的房間時，臉上有一種嚴肅的表情'。
[cpg cn=true]


這就是你在看的東西。我猜她有點像個鑑賞家，或者她很有姐妹情誼。
[cpg]


[OnName num="gorou"]
如果你指的是懺悔，你是否做了......？ "
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune323"]
[OnName num="suzune"]
'我不認為我有，沒有。你需要承擔適當的責任'。
[cpg cn=true]


;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



我姐姐教訓我，我感覺很微妙。
[cpg]


我喜歡緋紅。毋庸置疑。
[cpg]


但當我想到我是否正確面對緋紅時，就很難說了。
[cpg]


她害怕作弊。考慮到我的體質，這很自然。
[cpg]

;//＠妊娠しても体質が治らなかったらと考えるのは、当然かもしれない。
可能會很自然地想到，即使我的愛得到滿足，如果我的體質沒有得到治愈。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************



[OnName num="gorou"]
'我回家了: ......'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari153"]
[OnName num="himari"]
'歡迎回來，兄弟。我們可以嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'做，有點太快了......？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari042"]
[OnName num="himari"]
'你必須適應我的心情。你的兄弟沒有權利選擇。
[cpg cn=true]


就這樣，他們強迫我，把我的手拿走了。
[cpg]


而我被帶到了Himari的房間。 ......
[cpg]



;//========================================
;//●ＣＧ（主人公に顔を近づけるヒロイン。キスをする）ev_28
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]



她是在近距離。我無法直視她。
[cpg]


但當我把目光移開時，緋紅指出了這一點。
[cpg]


[VOICE f="sHimari043"]
[OnName num="himari"]
'別看了。再仔細看看我。 "
[cpg cn=true]


當你說這樣的話時，它只是讓我緊張。
[cpg]


[OnName num="gorou"]
'...... 是的。
[cpg cn=true]


我現在沒有選擇，只能點頭。我沒有膽量在這裡拒絕。
[cpg]


但我也沒有膽量接受它。
[cpg]


;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari044"]
[OnName num="himari"]
我不知道該怎麼做。你將永遠是一個新手。
[cpg cn=true]


像往常一樣，緋紅的臉皮相當厚。
[cpg]


如果她像她一樣隨和，也許我就不會有這種憲法了。 ......
[cpg]


[OnName num="gorou"]
'你不能幫助它。 ...... 如果你不再激動，那就是一個問題。
[cpg cn=true]



我很害怕，緋紅比平時更接近，說。
[cpg]


[VOICE f="sHimari045"]
[OnName num="himari"]
'從那時起，我就想知道什麼讓你最緊張。
[cpg cn=true]


緋紅看著我，給了我一個計謀性的微笑。
[cpg]


在這麼遠的地方有這麼漂亮的女孩，真讓人激動。
[cpg]


但緋紅仍然看起來想做什麼。
[cpg]


[OnName num="gorou"]
'，你是如此接近。
[cpg cn=true]


;**【ＣＧ】 ev_28_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari046"]
[OnName num="himari"]
'現在說這個有點晚了，不是嗎？你以前做了那麼多事情，你還害怕只是接吻嗎？ "
[cpg cn=true]


我不敢說這件事，但緋紅說了。
[cpg]


我知道她要吻我。
[cpg]


[OnName num="gorou"]
'......，對我好一點。
[cpg cn=true]


[VOICE f="sHimari047"]
[OnName num="himari"]
'我說得像個女孩，漂亮~'
[cpg cn=true]


如果發生這種情況，我想我只能準備好自己。我就是這麼想的，然後閉上了眼睛。 ......
[cpg]


;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari048"]
[OnName num="himari"]
'呵。漂亮的臉蛋。 "
[cpg cn=true]


然後她就沒有再吻我。
[cpg]


我睜開細長的眼睛，看著希瑪莉。
[cpg]


[VOICE f="sHimari049"]
[OnName num="himari"]
'我想我會用我的手機拍下我弟弟的吻臉...'
[cpg cn=true]


[OnName num="gorou"]
'做，你是什麼意思？
[cpg cn=true]


[VOICE f="sHimari050"]
[OnName num="himari"]
'你想讓我吻你嗎？那我希望你能這麼說。
[cpg cn=true]


[OnName num="gorou"]
'...... 有時緋紅看起來像一個惡魔。
[cpg cn=true]


[VOICE f="sHimari051"]
[OnName num="himari"]
'你是說惡魔般的類型？我真為你感到高興。 "
[cpg cn=true]


緋紅笑著說。但對於懸浮在半空中的我來說，它看起來仍然像魔鬼的微笑。
[cpg]


[VOICE f="sHimari052"]
[OnName num="himari"]
'那麼，你是怎麼想的？我想讓你吻我。 "
[cpg cn=true]


[OnName num="gorou"]
這是......."
[cpg cn=true]


在我說這句話的時候，她給了我一個不可抗拒的眼神，並把她的嘴唇送到我的面前。
[cpg]


;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト


;**【ＣＧ】 ev_28_b ***********************
[CG id=13 index=2 time=1000]
;***************************************
[WAIT time=1000]

我們的嘴唇相互接觸。這是一個輕柔的吻，但感覺我們終於越過了界限。
[cpg]



;//ＣＧ再び表示

;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]

然後我們拉開距離。我們不再只是兄弟姐妹。
[cpg]


[VOICE f="sHimari053"]
[OnName num="himari"]
'...... 大哥哥，你真的很可愛。
[cpg cn=true]


當他對我說這句話時，我可以感覺到我的臉越來越熱。
[cpg]


我沒有想到，被告知我很漂亮會讓我如此緊張和......。
[cpg]


我也沒有想到這個吻本身會有這樣的感覺。
[cpg]


[VOICE f="sHimari054"]
[OnName num="himari"]
'那好吧。我會把接吻推遲一段時間，我不想讓你通過正常的皮膚關係失去刺激。 "
[cpg cn=true]


我覺得我的臉都紅了。我認為這更像是因為另一邊的緋紅也在臉紅。
[cpg]


我想知道從現在開始我們會有什麼樣的關係......。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


要記住的最重要的事情是，你不應該害怕尋求幫助。
[cpg]


我感覺我無法入睡，但我比這更高興。
[cpg]


我想知道緋紅是否處於類似的心理狀態......，但我不能確定。
[cpg]


一段時間後，在星期六。
[cpg]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の家＿玄関』（昼）******************************************************



當時我剛從醫院回來。
[cpg]


我和我媽媽去了那裡，我被告知了一些事情，有點......，令人震驚。
[cpg]




;//ブラックアウト


[window target=false]


[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Himari173"]
[OnName num="himari"]
'歡迎回來。情況如何？ "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Sawa105"]
[OnName num="sawa"]
'事情是這樣的--......，這有點，有點大材小用。
[cpg cn=true]


我必須告訴你細節，不是嗎？這不是我要讓我母親告訴我的事情。
[cpg]


[OnName num="gorou"]
'......，他們說有一種藥可以治好我的病。但是。 "
[cpg cn=true]


[OnName num="gorou"]
'他說，他非但沒有治好自己的病，反而會對愛情失去興趣。
[cpg cn=true]


簡而言之，我們談論的是失去了激動人心的願望。
[cpg]


如果你不再想與任何人相愛，這是一個關於...... 人的生命的故事。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
緋玉和她姐姐的表情變得陰晴不定。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune324"]
[OnName num="suzune"]
'醫生也會說可怕的事情，......，如果他們說這樣的話，你只會變得更加焦慮。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

是的，沒錯。但是，希瑪里沉默不語，也許想的是不同的。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

而我和緋紅單獨在一個房間裡。
[cpg]


緋紅闖入我的房間。
[cpg]


她想談點什麼，或者說，我也想和她談點什麼。
[cpg]


[OnName num="gorou"]
'......，你怎麼看。關於如何治療你的體質'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari055"]
[OnName num="himari"]
'這很好。沒什麼，我想如果我這樣做就可以了'。
[cpg cn=true]


[OnName num="gorou"]
'嗬，說真的! 因為......，如果我吃了藥，我相信我也不會對緋紅有什麼想法。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari175"]
[OnName num="himari"]
'如果我哥哥不欺騙我，我還是會喜歡的。但......."
[cpg cn=true]


緋紅在說這句話時顯得有些尷尬。和......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari056"]
[OnName num="himari"]
'如果我可以，我也希望你仍然是你一直以來的兄弟，只是你的體質會被治愈。
[cpg cn=true]


...... 我明白了。緋紅是這樣想的嗎？
[cpg]


正如醫生所說，你和緋紅應該走到一起，你的體質應該穩定下來。
[cpg]


那是最好的狀態。但如果憲法沒有安頓下來，那麼......
[cpg]


也許我將被剝奪愛本身的權利。
[cpg]


即使有這樣的決心，我還是要和緋紅出去。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari057"]
[OnName num="himari"]
'嘿。你也準備好了，不是嗎，大哥哥？
[cpg cn=true]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト



[window target=true]


緋紅走近。她試圖吻我。 ......
[cpg]


我開始有點不耐煩了。我知道我也想和緋紅做愛。
[cpg]


[window target=false]

[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





時間在流逝，再過一會兒就到了吃晚飯的時間。
[cpg]



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari058"]
[OnName num="himari"]
快到吃晚飯的時間了。我們很快就可以走了嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'......'
[cpg cn=true]



我覺得我可以多和緋紅接觸，看看她的體質是否穩定下來。
[cpg]


但是，如果我太倉促，緋紅會不會變得幻滅，而愛情本身也會沒有結果？
[cpg]


經過思考，我想出了一個答案。
[cpg]


;//■選択肢
[switch]
[case "我將會更加接近緋紅，即使我必須要稍微推動一下自己。"]
	[swap]
	[jump target="*select05_1"]
[case "慢慢來，別著急"]
	[swap]
	[jump target="*select05_2"]
[endswitch]

1.更接近Himaru，即使有點不知所措
2，慢慢來，不要著急。



;//==============================
;//１、多少無理してもひまりに近づく
*select05_1|珍惜緋紅。




[OnName num="gorou"]
'再和我們呆一會兒吧。 緋紅"。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sHimari059"]
[OnName num="himari"]
但食物是......"
[cpg cn=true]


[OnName num="gorou"]
'快走吧! 如果你繼續這樣下去，你無法真正治愈你的體質。 "
[cpg cn=true]



[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari060"]
[OnName num="himari"]
'...... 是的。好吧，如果你堅持這麼說的話。
[cpg cn=true]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ブラックアウト


[window target=true]

就這樣，與緋紅的日子繼續著。但在幕後，不適感也在不斷累積。
[cpg]


緋紅怎麼會看到我著急呢？
[cpg]


如果我嚇到她或讓她感到不舒服，哪怕是一點點，那就不好了。
[cpg]


甚至"我不擅長這個"的感覺也再次變成了不耐煩。
[cpg]


;//移植前シーンカット


[window target=false]
[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari061"]
[OnName num="himari"]
'嘿，兄弟。你不應該得到我所說的待遇嗎？ "
[cpg cn=true]


[OnName num="gorou"]
為什麼......，我喜歡緋紅？ "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari062"]
[OnName num="himari"]
'是的，但也許是你的體質使你認為你喜歡我。
[cpg cn=true]


[VOICE f="sHimari063"]
[OnName num="himari"]
'如果你不捶打，你就無法呼吸。我以為你愛上了我，因為你想搗蛋。
[cpg cn=true]


面對我的不耐煩，向日葵開始質疑她是否真的被愛。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（昼）******************************************************





然後，緋紅逐漸開始對我採取冷漠的態度。
[cpg]


但我的體質還很好，所以我和緋紅的關係很苦。
[cpg]


[OnName num="gorou"]
'該死，我很痛苦，...... 緋紅!
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari064"]
[OnName num="himari"]
'我不知道該怎麼做。我沒有心情'。
[cpg cn=true]



[window target=false]

[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『街』（夜）******************************************************



諷刺的是，在我痛苦的時候，緋紅對我產生了興趣。
[cpg]


也許她一直都有這種氣質。
[cpg]



我只能想像，但......，我有一種感覺，她確實如此。
[cpg]


[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト


緋紅不再向我靠近。她不能再做捶打，而我還在痛苦中。
[cpg]


它是如此痛苦，以至於有一天晚上我甚至無法入睡.......。
[cpg]


;//========================================
;//●ＣＧ（寝ている主人公に寄り添うヒロイン。サディスティックな感じ）ev_30
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="gorou"]
'哈，哈......，緋紅？
[cpg cn=true]


她來到了我的房間。我已經等了她很久了，我覺得我現在就想擁抱她。
[cpg]


但我無法呼吸，也無法起身。
[cpg]


無論她是否知道我處於這種情況，她都說。
[cpg]


[VOICE f="sHimari065"]
[OnName num="himari"]
'也許我想一直看著我痛苦的弟弟......。
[cpg cn=true]


他一邊笑著一邊說著殘酷的事情。
[cpg]


我不能呼吸，我一直不能呼吸，呼吸太難了，如果不呼吸，我真的會死。
[cpg]


[OnName num="gorou"]
'緋紅......，請到我身邊來。
[cpg cn=true]


;**【ＣＧ】 ev_30_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari066"]
[OnName num="himari"]
'我想知道我應該怎麼做？我哥哥現在有點太絕望了，也許我不想和他親近。 "
[cpg cn=true]


緋紅以她一貫的語氣平靜而輕蔑地說道。
[cpg]


[OnName num="gorou"]
'桑尼，緋紅並不關心我發生了什麼。
[cpg cn=true]


[VOICE f="sHimari067"]
[OnName num="himari"]
'......，這很難，大哥哥。你已經變得如此依賴搗蛋了'。
[cpg cn=true]


依靠緋紅而不是Dokidoki，我叫她的名字。
[cpg]


[OnName num="gorou"]
'緋紅......，哦，緋紅，緋紅！ '
[cpg cn=true]


[VOICE f="sHimari068"]
[OnName num="himari"]
'怎麼了？你想從我這裡得到什麼，叫我那麼多？ "
[cpg cn=true]


管它呢，這很明顯。
[cpg]


[OnName num="gorou"]
'請...... 搗毀我。如果你不這樣做，這是在你的憲法中。 ......
[cpg cn=true]


[VOICE f="sHimari069"]
[OnName num="himari"]
憲法，嗯？對。 "
[cpg cn=true]


;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari070"]
[OnName num="himari"]
'嘿。實際上，我正在接受一些藥物治療，以治愈我的病情。 "
[cpg cn=true]


[OnName num="gorou"]
什麼？ "
[cpg cn=true]


有一瞬間，我不明白希瑪里在說什麼。
[cpg]


但我昏昏沉沉的腦袋漸漸開始明白了。
[cpg]


[VOICE f="sHimari071"]
[OnName num="himari"]
'我想，也許我的兄弟不會想自己喝酒。但現在你在痛苦中，你確實想喝酒'。
[cpg cn=true]


[OnName num="gorou"]
'哦，不......，只要緋紅能靠近我，那就足以幫助我呼吸了。
[cpg cn=true]


我想我是自私的。但我忍不住說了出來。
[cpg]


這就是它的痛苦之處。不僅是我的呼吸，而且我的心臟也在受苦。
[cpg]


;**【ＣＧ】 ev_30_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari072"]
[OnName num="himari"]
'這只是暫時的，不是嗎？你必須一直讓我在你身邊，這是不健康的。
[cpg cn=true]


[OnName num="gorou"]
但是！ "
[cpg cn=true]


緋紅從頭到尾都顯得有些驚慌失措。
[cpg]


我越是絕望，越是適得其反。儘管我知道，但我還是忍不住不耐煩了。
[cpg]


[VOICE f="sHimari073"]
[OnName num="himari"]
'我想知道這些藥丸裡有什麼？它是否會減少睾丸激素？ "
[cpg cn=true]


[VOICE f="sHimari074"]
[OnName num="himari"]
'那你就可以知道為什麼我對浪漫失去了興趣。我想這也會讓我對沒有心跳的感覺好起來。
[cpg cn=true]


緋紅說的是可怕的事情。我真的要放下這份愛嗎？
[cpg]


光是想像我不能愛上緋紅就很難了。但呼吸更困難了。
[cpg]


[OnName num="gorou"]
'Kuu...... 痛苦，緋紅，幫助我。
[cpg cn=true]


看到我痛苦的樣子，緋紅似乎並不著急。
[cpg]


[OnName num="gorou"]
'我應該怎麼做......，我做了什麼讓你這麼恨我？
[cpg cn=true]


;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari075"]
[OnName num="himari"]
'沒事的。我不恨你。儘管我的哥哥已經中立了，但我仍然喜歡他。
[cpg cn=true]


她用平靜、溫和的語氣說著可怕的事情。
[cpg]


[VOICE f="sHimari076"]
[OnName num="himari"]
'也許到時候我會把你當做一個裝扮的娃娃來玩？
[cpg cn=true]


[OnName num="gorou"]
'那個，啊，那個.......'
[cpg cn=true]


這種愛，已經嗤之以鼻。緋紅有些樂在其中。
[cpg]


而我，則沒有時間去享受它。
[cpg]


我沒有想到......，最後會變成這樣。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



......，怎麼會變成這樣？
[cpg]


儘管我很後悔，但最後我的呼吸還是很痛苦。
[cpg]


為了逃避痛苦，我吃了藥。
[cpg]


[OnName num="gorou"]
'哈哈，哈哈......，緋紅。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari077"]
[OnName num="himari"]
'這就對了。你太有魄力了，大哥哥，你嚇到我了。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari078"]
[OnName num="himari"]
現在我的兄弟是我的，也是我一個人的。 ......
[cpg cn=true]


說到這裡，緋紅拍了拍我的頭。對此，我不再感到激動。
[cpg]


[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ブラックアウト



我的搗蛋真的是由緋紅管理的。
[cpg]


我的心已經被鎖住了。 ......
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*back_title"]
;//ＥＮＤ：バッドエンドルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================
;//２、ゆっくり慣らしていこう
*select05_2|珍惜緋紅。




[OnName num="gorou"]
'......，我同意。
[cpg cn=true]




緋紅可能是困難的。我不想讓她看到我太著急了。
[cpg]


相反，我想照顧好...... 緋紅。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



之後，在我們吃完晚飯後，緋紅就來到了我的房間。
[cpg]


她說她不希望看到我受苦。
[cpg]


通過不從我這邊要求太多，緋紅從我這邊要求了。 ......
[cpg]



[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari079"]
[OnName num="himari"]
'我希望我可以......，做點什麼。醫生說如果你墜入愛河，你就會痊癒，對嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'嗯，差不多就是這樣的情況。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari080"]
[OnName num="himari"]
'它是蓬鬆的，不是嗎？愛有什麼關係呢？
[cpg cn=true]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_h1"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



比如說。你不是在談論簡單的結婚或類似的事情。
[cpg]

即使是這樣，我也不想倉促行事。我不想強迫緋紅做任何事情。
[cpg]


[window target=false]


[STOPBGM]

[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



但似乎緋紅在我之前就下定了決心。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari229"]
[OnName num="himari"]
'...... 你知道嗎？如果事情繼續這樣下去，它不會很快結束，對嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'沒有必要急於求成。讓我們慢慢來吧....... Himari？ "
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari081"]
[OnName num="himari"]
'更多偉大的事情，我會為你做。即使你哥哥不願意，我也會。
[cpg cn=true]


[OnName num="gorou"]
'......，要溫柔。
[cpg cn=true]



我從來沒有厭惡過它。但我認為如果我要求的話，就不會發生這種情況。
[cpg]


我真的以為愛情是一種奇怪的東西。
[cpg]


;//ブラックアウト

;//移植前シーンカット


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



緋紅和我花了一天時間進行適度的調情。
[cpg]


我們甚至在路上去餐廳吃飯。 ......。
[cpg]




;//ブラックアウト


[window target=false]



[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari247"]
[OnName num="himari"]
'謝謝你的食物。那麼，大哥哥，我們回你的房間去吧。
[cpg cn=true]


[OnName num="gorou"]
'這太明目張膽了，......'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari248"]
[OnName num="himari"]
'時間是有限的，我們不能磨磨蹭蹭。
[cpg cn=true]

[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa106"]
[OnName num="sawa"]
'咯咯笑。你們真的很親密......'
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



然後他們回到自己的房間，進行了一場黏稠的調情。

[cpg]


在做這些的時候，我們甚至談到了一起睡在被褥上。 ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari249"]
[OnName num="himari"]
'嘿，這很好。也許人們已經知道了。 "
[cpg cn=true]


[OnName num="gorou"]
我知道。 ...... 那麼好吧。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari250"]
[OnName num="himari"]
'知道了。和我弟弟睡覺。 "
[cpg cn=true]


看到緋紅這樣，我覺得她仍然是我的小妹妹。
[cpg]


儘管我真的想做她的情人。在那裡，它將不可避免地成為一個中間地帶。
[cpg]


她是我的妹妹，但她是我的愛人。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=1000]

然後他們依偎在一起，進入了夢鄉。 ......。
[cpg]


激動但鬆了一口氣。我又想起了這個詞，因為我已經想了很多次。
[cpg]


我認為那是一段快樂的時光。這感覺就像是對我和緋紅之間的愛情的確認。
[cpg]


如果當時我很著急，緋紅體內的感情可能會冷卻下來。
[cpg]


當然，會有一個與現在不同的未來。
[cpg]


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari251"]
[OnName num="himari"]
"嗯 ...... 困了 ......"
[cpg cn=true]


緋紅先醒過來，搖晃著我。
[cpg]


現在已經是工作日了嗎？我必須要去學院。 ......
[cpg]


但現在的時間還很早。有什麼計劃？
[cpg]


[OnName num="gorou"]
'現在不是早......嗎？如果你困了，為什麼不回到床上去？ "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari082"]
[OnName num="himari"]
'不'。你在試圖治療你的體質。
[cpg cn=true]


[OnName num="gorou"]
......，你是對的。 "
[cpg cn=true]


如果我不花一點時間和你在一起，我的體質就不會穩定下來。
[cpg]


即使是這樣，我認為也不必在這麼早的時候。 ......
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_06_1_up.ui" time=1000]
[WAIT time=2000]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sHimari083"]
[OnName num="himari"]
'嘿，讓我們接吻吧。我還沒有刷牙。 "
[cpg cn=true]


[OnName num="gorou"]
這是不衛生的。 ......
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari084"]
[OnName num="himari"]
'如果你想想你的身體，如果你不吻它，你會更痛苦。
[cpg cn=true]


...... 的確如此。
[cpg]



;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



快樂的時光意味著它們很快就會過去。我還得去上學。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari085"]
[OnName num="himari"]
嗯。 ......，我希望我的早晨能長一點。 "
[cpg cn=true]


[OnName num="gorou"]
'我想我只能早起了？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari086"]
[OnName num="himari"]
'那會使夜晚變得更短，不是嗎？
[cpg cn=true]



;//ブラックアウト



沒有緋紅的日子越來越難熬了。
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『学園教室』（昼）******************************************************





不出所料，到了中午時分，我已經搖搖晃晃了。
[cpg]


我想過要去我姐姐那裡，但我還是忍住了。
[cpg]


一般來說，如果我不斷地重複這樣的日子，我的體質就會及時地穩定下來。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************





時間過去了。特別是......
[cpg]


足夠的時間過去了，我不需要搗鼓，也不需要用力呼吸。
[cpg]


與緋紅的關係在家裡已經完全暴露。
[cpg]


我向父親解釋了很久，但他終於承認了。
[cpg]



;//ブラックアウト


[window target=false]

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari087"]
[OnName num="himari"]
'你哥哥要做你的丈夫，對嗎？
[cpg cn=true]


[OnName num="gorou"]
如果你這樣說的話，那麼緋春也是你的妻子。 "
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari088"]
[OnName num="himari"]
'嘿嘿。很高興聽到這個消息'。
[cpg cn=true]



直到最近，她還只是一個小妹妹。我暈頭轉向的日子開始......
[cpg]



;//ブラックアウト


[window target=false]

[STOPBGM]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


我已經有了一份工作，我將在春天開始工作。
[cpg]


緋想馬上結婚，所以為了所謂的學校而學習是不夠的。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari272"]
[OnName num="himari"]
'我進來了，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'哦，緋紅......，怎麼了？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari089"]
[OnName num="himari"]
'你哥哥的體質最近已經穩定下來了，是嗎？這就是為什麼......，我想念你。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari090"]
[OnName num="himari"]
'我不知道......，我想靠近我的兄弟。
[cpg cn=true]


[OnName num="gorou"]
'是的。我也這麼認為。這與敲打沒有關係'。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari091"]
[OnName num="himari"]
'我喜歡我的...... 弟弟的這一點。你把我當回事。
[cpg cn=true]


[OnName num="gorou"]
'真的嗎？我覺得我很輕浮。 "
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari092"]
[OnName num="himari"]
'但你不像我這麼輕浮，是嗎，大哥？
[cpg cn=true]




...... 緋紅稱我為她的大哥哥。
[cpg]


我希望她現在不要再這樣叫我了，但......，緋紅很難改變。
[cpg]



[OnName num="gorou"]
'你知道嗎？如果你要結婚，你可以改變你對我的稱呼。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari293"]
[OnName num="himari"]
'連你的哥哥都叫你姐姐。
[cpg cn=true]


這完全無關緊要。我和我妹妹沒有任何關係。
[cpg]



[OnName num="gorou"]
這是一派胡言。 ......，這是行不通的。 "
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari294"]
[OnName num="himari"]
'沒關係的。我再不說就不行了，所以現在就說'大哥'吧。
[cpg cn=true]



對，這就是我的意思。那麼我可以理解，為什麼他們不能這樣說呢？
[cpg]

;//ブラックアウト
;//移植前シーンカット
;//移植前シーンカット

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



就這樣，我和緋紅的日子一直在繼續。
[cpg]


這讓人頭暈目眩。然後，當我們終於結婚時：......
[cpg]


;//========================================
;//●ＣＧ（椅子に座って、編み物をするヒロイン。おなかは膨らんでいない形にしてください）ev_35
;//人物１：ヒロイン２
;//服装１：私服
;//場所　：主人公の家＿リビング
;//時間　：朝
;//備考　：元のＣＧと違って、おなかは膨らんでいない形にしてください
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


有人看到緋紅在客廳裡織毛衣。
[cpg]


我不認為她是一個狡猾的人，但我不知道她是否有這樣的愛好。
[cpg]


[OnName num="gorou"]
'......，我不記得她會編織。
[cpg cn=true]



緋紅搖了搖頭。我知道，我從未見過她這樣做。
[cpg]


[OnName num="gorou"]
[OnName num="gorou"]
'我不能做的時候就做。
[cpg cn=true]


[VOICE f="Himari315"]
[OnName num="himari"]
'你將能夠。 '因為我知道會有一些日子，你會感到無聊。
[cpg cn=true]


你和我有這樣的對話。也許他們正在談論生孩子的問題。
[cpg]


我不需要再問了。而在這一天，我聽到了我一直期待的話語。
[cpg]


;//;**【ＣＧ】 ev_35_a ***********************
;//[CG id=15 index=1 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="sHimari093"]
[OnName num="himari"]
'從現在開始留在我身邊，戈羅。
[cpg cn=true]


他叫我戈羅。我感覺自己的胸口被打了一拳。
[cpg]


在這一刻，我已經從一個單純的大哥哥畢業了。
[cpg]


這並不公平。緋紅用她的稱呼迷惑了我，但我對此無能為力。
[cpg]


[OnName num="gorou"]
'...... 是的。 緋紅"。
[cpg cn=true]


我別無選擇，只能叫緋紅為緋紅。但有一天，我會叫她媽媽。
[cpg]


你叫我五郎的時間會很短。
[cpg]


但這也沒關係。這就是我的快樂。 ......
[cpg]


我哥哥成為父親的日子在我眼前漸漸逼近。
[cpg]


我只是很高興。
[cpg]



;//ブラックアウト

不是作為她的兄弟，而是作為她的情人，就在身邊。
[cpg]


你不是每天都能成為曾經的兄弟和現在的女友。
[cpg]


我有一種感覺，從現在開始我就會很興奮，有一天我也想讓Himaru有同樣的感覺。
[cpg]


她的性格相當強勢，所以我可能很難做點什麼。 ......
[cpg]


我想感到興奮，我想讓他們感到興奮。這就是一個普通情人的慾望。
[cpg]





;//ブラックアウト

[SCENE id=10]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン２ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================

*start

;###################################################################
*Ep007|對Sunahane的不想要的想法。
;###################################################################


;//３、砂羽
*select04_3|

[SCENE id=7]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


我想到了我母親的臉。不，我知道這不可能發生，但它就這樣出現在我面前。
[cpg]


姐姐和緋紅還是不錯的。她們是妯娌，年齡相仿。
[cpg]


但是和我媽媽在一起，年齡差距相當大。不......
[cpg]


他說他是一個已婚男人。你有一個父親。
[cpg]


而我的父親對我來說仍然是我的父親，......，我越想越覺得不可能。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[window target=true]

是緋紅讓我在早上感到緊張。她來到我的房間，......
[cpg]


而在那之後，我對離開房子感到猶豫不決。
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari317"]
[OnName num="himari"]
'兄弟，你不是已經去了嗎？我們要遲到了。 "
[cpg cn=true]


[OnName num="gorou"]
'是的，我一會兒就到.......，去吧。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari318"]
[OnName num="himari"]
'嗯。我得去看看你媽媽。
[cpg cn=true]


他們看穿了這一點。這就是事情的真相。 ......
[cpg]


[free time=1000]

[SE f="se003"]
;//【ＳＥ】『ドア閉まる』


緋紅離開後，就剩下我和媽媽。
[cpg]


姐姐和爸爸去工作了。緋紅也上了學。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa108"]
[OnName num="sawa"]
'......，你想要見我，對嗎？我想知道......"
[cpg cn=true]


他在輕鬆的氣氛中問我。
[cpg]


我想你已經可以看出，我有一些嚴肅的想法。但我的母親敢於讓我這樣做。
[cpg]


[OnName num="gorou"]
'我，嗯，...... 我母親的...... 母親和...... 嗯...'
[cpg cn=true]


我不知所措了。我不知道該說些什麼。
[cpg]


我覺得如果我說出來，就意味著結束了。在這樣的時候。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa109"]
[OnName num="sawa"]
'我幾乎可以看到它。也許我離得太近了--'
[cpg cn=true]


我幾乎總是能看出來，我母親曾告訴我。還有就是我離得太近了。 ......
[cpg]


[OnName num="gorou"]
'嗯，嗯，......，這是...'
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa026"]
[OnName num="sawa"]
'我不能幫助它。如果你說你喜歡它。
[cpg cn=true]


......，輕鬆通過。不，這不是好事。
[cpg]


[OnName num="gorou"]
'嘿，等一下，等一下! 我是認真的。 "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa027"]
[OnName num="sawa"]
'不管怎樣，今天晚上見。如果我不早點到那裡，我上學就要遲到了。
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





所以我們去了學校。
[cpg]


但我已經在空中了。儘管我在白天會看到我的妹妹，......
[cpg]


即使考慮到這一點，我也無法保持冷靜。想到我的母親會為我這樣做。
[cpg]


這一點就使我痛苦地感到緊張。我以前從來沒有過這樣的暗戀。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************



而在晚上放學的時候。我感到很慌張。
[cpg]


媽媽說："我也沒辦法，是吧？"這是真的嗎？
[cpg]


我有些不講情面。自然，我必須在爸爸回家之前和他談談。
[cpg]


爸爸和媽媽有單獨的房間，所以他們沒有機會撞到一起。
[cpg]




;//ブラックアウト


[window target=false]

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



當我在想這些的時候，我到了家。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Himari319"]
[OnName num="himari"]
歡迎回家。你看起來棒極了。 "
[cpg cn=true]


它是什麼顏色？它是紅色還是藍色？這並不重要。
[cpg]

[free time=1000]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa028"]
[OnName num="sawa"]
'嗯。你看起來很難受的樣子。很好。 "
[cpg cn=true]


拍了拍我的頭，我被帶到了母親的房間。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




只要有她在我身邊，握著我的手，就足以讓我感覺到我要失去它。
[cpg]


我不禁感到，我的思想被控制得那麼厲害。
[cpg]



;//========================================
;//●ＣＧ（ヒロインが寝ている主人公に近づく。穏やかに微笑んでいる→心配そうな表情に）ev_36
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================



[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sSawa029"]
[OnName num="sawa"]
'......，我想知道像這樣在你身邊是否會讓你緊張。
[cpg cn=true]


我很激動。我點了點頭，回答道。
[cpg]


[OnName num="gorou"]
'是的。 ......，它非常、非常平靜。
[cpg cn=true]


媽媽撅了一會兒嘴，然後笑了一下。
[cpg]


[VOICE f="sSawa030"]
[OnName num="sawa"]
'嗯。平靜，是這樣嗎？你不應該感到興奮嗎？ "
[cpg cn=true]


但我只能這麼說。
[cpg]


也許我畢竟不是想悸動，我是想冷靜下來。
[cpg]


也許是我一直有呼吸困難的事實，也許是我不能得到一個暗戀的對象，我就像焦慮的.......。
[cpg]


如果是這樣的話，也許我的體質只要做這個就能治好。
[cpg]


只要在媽媽身邊，我就覺得很有成就感。
[cpg]


;**【ＣＧ】 ev_36_a ***********************
[CG id=16 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa031"]
[OnName num="sawa"]
'哦，好吧。我想做你想讓我做的事。
[cpg cn=true]


[OnName num="gorou"]
'謝謝你。媽媽。 "
[cpg cn=true]


[VOICE f="sSawa032"]
[OnName num="sawa"]
'......，我真的很擔心你。我也把五郎當作我的孩子。
[cpg cn=true]


然後，突然，他看起來很擔心。
[cpg]


;**【ＣＧ】 ev_36_b ***********************
[CG id=16 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa033"]
[OnName num="sawa"]
'我想如果你為我感到興奮，那也很好。
[cpg cn=true]


[VOICE f="sSawa034"]
[OnName num="sawa"]
'如果這意味著他不必受苦，我願意為五郎做任何事。
[cpg cn=true]


我不知道你這麼看重我。她給人的印像是平靜的，所以我有點吃了一驚。
[cpg]


[OnName num="gorou"]
'我很高興.......非常感謝你。 "
[cpg cn=true]


我這樣說，知道這是一個愚蠢的說法，但想讓他知道我很感激。
[cpg]


我努力使自己的臉色盡可能嚴肅，聲音也盡可能嚴肅。我試圖傳達我的感受，但......
[cpg]


但我媽媽看起來特別惱火。
[cpg]


出於某種原因，她看起來更苦惱，這就是她在我看來的樣子。
[cpg]


[VOICE f="sSawa035"]
[OnName num="sawa"]
'如果五郎說他喜歡我，那麼我想這也是可以的。這不是謊言'。
[cpg cn=true]


媽媽小心翼翼地選擇她的語言，並逐漸告訴我她的感受。
[cpg]


;**【ＣＧ】 ev_36_c ***********************
[CG id=16 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa036"]
[OnName num="sawa"]
'我不知道該怎麼做。他絕對是我的孩子，但我也喜歡他'。
[cpg cn=true]


我明白了。 ......，我不知道我讓你這麼想。
[cpg]


[OnName num="gorou"]
......."
[cpg cn=true]


我是不是太不敏感了？我面對的是一個兒子，儘管是一個繼子。
[cpg]


我把我媽媽逼到了絕境。我已經意識到了這一點。
[cpg]


我想我的行為可能太自私了，但我仍然無法停止...... 這種感覺。
[cpg]


[OnName num="gorou"]
我很抱歉。但我不能停下來。 "
[cpg cn=true]


我不知道該怎麼做。但如果我把這種焦慮大聲表達出來，會不會讓我母親更加惱火？
[cpg]


那麼我想最好是說我想做什麼。
[cpg]


[OnName num="gorou"]
我想吻你。
[cpg cn=true]


彷彿是為了掩飾，我說。她點了點頭。
[cpg]


我看到她閉上了眼睛，我走近了一些。 ......
[cpg]


這一步將是任何理智的人都不會採取的措施。但我早已經瘋了。
[cpg]


[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

...... 而且。
[cpg]


我親吻了我母親的嘴。我邁出了顯然不應該邁出的一步。
[cpg]


[OnName num="gorou"]
......"


;//ＣＧ
;**【ＣＧ】 ev_36_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sSawa037"]
[OnName num="sawa"]
'呼。不要做這種表情。
[cpg cn=true]


我本來會是什麼樣子？他看起來很遺憾嗎？
[cpg]


[VOICE f="sSawa038"]
[OnName num="sawa"]
我有沒有好好地敲打你？ "
[cpg cn=true]


你這樣一說，我不激動是假的。然而。
[cpg]


[OnName num="gorou"]
'再來一次......'
[cpg cn=true]


[VOICE f="sSawa039"]
[OnName num="sawa"]
'不，你不能。今天就到此為止。你已經習慣了重擊，這對你沒有好處，是嗎？
[cpg cn=true]


[OnName num="gorou"]
嗯，是的，但是...
[cpg cn=true]


[VOICE f="Sawa132"]
[OnName num="sawa"]
'哦，上帝。不要太執著，否則女孩們會討厭你！ '
[cpg cn=true]


女孩，是否包括我的母親？
[cpg]


這樣問很不禮貌，所以我閉嘴，退了出去。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





我不想讓我的母親討厭我。我不想為此做任何事情。
[cpg]


我很矛盾，不知道它們是否有衝突。
[cpg]

[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[SE f="se009"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





早上，我無法正常看到母親的臉。
[cpg]


看到這一點，我姐姐和緋紅似乎也感覺到了。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Himari320"]
[OnName num="himari"]
'你越過了某種界限，不是嗎？大哥哥。 "
[cpg cn=true]


[OnName num="gorou"]
'...... 那是......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune325"]
[OnName num="suzune"]
'......，我不會說什麼。你們兩個需要在自己之間解決這個問題。
[cpg cn=true]


這就像已經說了。這很令人厭惡。
[cpg]


但我不能幫助它。我喜歡我的母親。
[cpg]


[free time=1000]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa133"]
[OnName num="sawa"]
不要過多地折磨五郎。是我推著你去做的。
[cpg cn=true]


他將與我一起承擔。如果爸爸在這裡，他就會有很多麻煩。
[cpg]


我很高興我爸爸是早早離開家的人。 ......，我完成了我的早餐。
[cpg]


;//ブラックアウト

[window target=false]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************


[OnName num="gorou"]
我走了。 ......
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa134"]
[OnName num="sawa"]
'是的。祝你有個愉快的一天。
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari321"]
[OnName num="himari"]
我走了。 "
[cpg cn=true]


......，我感到無法形容。我想在我母親的身邊。
[cpg]


但這是一個未實現的願望。
[cpg]


我是她的兒子，儘管她是我的繼女，而且我首先要去學院。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[window target=false]

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[window target=true]


我打算去學院，同時有點心事重重。
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="male_student"]
我不知道我的感覺如何，但我不確定。你不覺得今天的我有些不同嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'我不...... 知道，我也不認為，但......'
[cpg cn=true]


[OnName num="male_student"]
'我們出去了! 我的春天也已經來臨了，哈哈。 "
[cpg cn=true]


[OnName num="gorou"]
'是的。對你有好處。 "
[cpg cn=true]


[OnName num="male_student"]
'多麼單薄的回應啊。當然，我們甚至還沒有親吻過'。
[cpg cn=true]


...... 我吻了一個我甚至沒有約會的人。而且是和我的岳母一起。
[cpg]


即使我想說，我也不能這麼說。在此期間，是我妹妹等我的時候了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_03_2_up.ui" time=1000]
[WAIT time=2000]

還有午餐時間。當我們單獨在一起時，我妹妹對我說。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Suzune326"]
[OnName num="suzune"]
'......，你的母親是我們真正的母親。所以......."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Suzune327"]
[OnName num="suzune"]
'不要大意，不要破壞我們的家庭。
[cpg cn=true]


他們說。這是個相當嚴厲的詞。
[cpg]


她說'親生母親'的方式也有點刺耳。但我沒有選擇。
[cpg]


我就像一個異物。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





我的體質如果不與別人相愛，就無法治愈。
[cpg]


我想，我的姐姐和緋紅也是可能的伙伴。
[cpg]


但我並不想這麼做。我愛的人是我的母親。
[cpg]


我想不出別的辦法。我喜歡我的母親。
[cpg]


現在我說出來了，我明白為什麼我姐姐告訴我不要拆散這個家庭。
[cpg]


我姐姐告訴我的話在我腦中迴盪。
[cpg]


;//ブラックアウト


[window target=false]

[STOPBGM]

[BG f="b_04_3_up.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa135"]
[OnName num="sawa"]
'歡迎回來。你怎麼樣，已經很辛苦了嗎？
[cpg cn=true]


這已經很困難了。我當時沒有狀態去撒謊。
[cpg]


[OnName num="gorou"]
'...... 是的。我想和我媽媽在一起。好嗎？ "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa136"]
[OnName num="sawa"]
'當然了。我已經決定我要做晚上的--'
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



然後我被帶到了我媽媽的房間。
[cpg]


只要來到這裡，就覺得是一種解脫.......
[cpg]


;//========================================
;//●ＣＧ（寝ているヒロインに迫る主人公。抱きしめ合う感じ）ev_37
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================


[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h2"]
;**【ＣＧ】 ev_37_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSawa040"]
[OnName num="sawa"]
'來吧，我給你一個擁抱。
[cpg cn=true]


當我看到媽媽張開雙臂時，我都快哭了。
[cpg]


我想告訴她我現在的一切感受。
[cpg]


但我不能說出來，我還是覺得自己要哭了。
[cpg]


我不知道該怎麼做。我甚至不知道我是否應該通過這種愛。
[cpg]


在我看來，我愛我的母親是毫無疑問的。
[cpg]


而且更重要的是，我不想惹惱我的母親。
[cpg]


[OnName num="gorou"]
...... 我仍然愛我的母親。
[cpg cn=true]


這句話的聲音很小，連我都感到驚訝。我知道我不應該說這麼多。
[cpg]


如果我在這裡說，我想做你的女朋友，那就完了。
[cpg]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa041"]
[OnName num="sawa"]
'對。我知道。你不必什麼都說'。
[cpg cn=true]


我不是想讓你說出所有的事情。這將有助於我。
[cpg]


[OnName num="gorou"]
'...... 是的。
[cpg cn=true]


[VOICE f="sSawa042"]
[OnName num="sawa"]
'你今天一定很痛苦。破壞它也沒關係'。
[cpg cn=true]


我認為有些話，如果你說出來，你就不能收回。如果我母親能讓他們閉嘴，那將是相當有幫助的。
[cpg]


我沒有說什麼，就擁抱了她。
[cpg]


[OnName num="gorou"]
'你聞起來像我母親。
[cpg cn=true]


她並不諱言這一點。她肯定與她的姐姐和緋紅不同。
[cpg]


媽媽認為我不會再靠近了。
[cpg]


;**【ＣＧ】 ev_37_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa043"]
[OnName num="sawa"]
'好吧，...... 吾郎將永遠是一個被寵壞的孩子。
[cpg cn=true]


這個溫柔的聲音使我無法壓制我一直在假裝的東西，我一直在忍耐的東西。
[cpg]


我想讓你成為我的全部。說這一個字很容易。
[cpg]


但......，我不知道我是否真的能做到這一點。
[cpg]


不僅我不知道，而且連她也可能不知道。
[cpg]


如果是這樣，我說的話就會無從談起。
[cpg]


[VOICE f="sSawa044"]
[OnName num="sawa"]
'怎麼了？你看起來像要哭了。 "
[cpg cn=true]


她現在不是我唯一的媽媽。我不禁想到了這一點。
[cpg]


她看起來也像是要哭了。我真的喜歡上了我的媽媽。
[cpg]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa045"]
[OnName num="sawa"]
'我想知道她是否有什麼可悲之處，而不僅僅是痛苦。
[cpg cn=true]


這不是悲傷，是難過。目前的這種情況是可悲的。
[cpg]


這不再是好事，我知道，這就是為什麼我不能停止。
[cpg]


[OnName num="gorou"]
'媽媽，......，我已經下定決心了。
[cpg cn=true]


媽媽看起來有點擔心。
[cpg]


也許她以某種方式知道她將被告知什麼。
[cpg]


;**【ＣＧ】 ev_37_b ***********************
[CG id=17 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa046"]
[OnName num="sawa"]
'決定了什麼？
[cpg cn=true]


[OnName num="gorou"]
'你知道他們是怎麼說我的，如果我不談戀愛，我的體質就不會安定下來。
[cpg cn=true]


媽媽顯然知道一切。儘管如此，她只是帶著相貌聽我說話。
[cpg]


[VOICE f="sSawa047"]
[OnName num="sawa"]
'是的。怎麼了？ "
[cpg cn=true]


一旦我說出這句話，就沒有回頭路可走了。這是我經常思考的問題。
[cpg]


[OnName num="gorou"]
'我喜歡......，你的母親。
[cpg cn=true]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa048"]
[OnName num="sawa"]
'是的。我知道。 "
[cpg cn=true]


[OnName num="gorou"]
'不，不。你的母親還不明白'。
[cpg cn=true]


[OnName num="gorou"]
當我說我愛你時，我是指愛。 "
[cpg cn=true]


;//移植前シーンカット

;//ブラックアウト



我終於說出來了。喜歡"這個詞與"愛"這個詞有不同的含義。
[cpg]


短暫的沉默。然後媽媽反問道。
[cpg]


;**【ＣＧ】 ev_37_b ***********************
[CG id=17 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sawa153"]
[OnName num="sawa"]
'你是認真的嗎？你知道這意味著什麼。 "
[cpg cn=true]


我想我知道。我想我知道。 ......
[cpg]


[VOICE f="Sawa154"]
[OnName num="sawa"]
'也許我們會被分開。你準備好了嗎？ "
[cpg cn=true]


對。這是可能摧毀家庭的事情。
[cpg]


你的妹妹會怎麼想？而且，即使緋紅不覺得有什麼，最大的問題是爸爸。
[cpg]


我又得迷路了。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



爸爸通常會回家吃飯。
[cpg]


[OnName num="father"]
'鈴音。這些天的工作怎麼樣？ "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune328"]
[OnName num="suzune"]
嗯，......，還有很多地方我不夠強壯。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari322"]
[OnName num="himari"]
'你作為一個姐妹，力量並不弱。我有點不適應'。
[cpg cn=true]


他們正在談論這個問題。正常的、親子的對話。
[cpg]


但我......，感覺有點被疏遠。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



之後，我邀請緋紅和她的妹妹到我的房間。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari323"]
[OnName num="himari"]
'...... 怎麼了？你的臉上有一種神秘的表情'。
[cpg cn=true]


[OnName num="gorou"]
是的，好的。 ......
[cpg cn=true]


我不知道該如何談及這個話題，這時緋紅說。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Himari324"]
[OnName num="himari"]
'你是在說你的母親嗎？可能，是的。 "
[cpg cn=true]


[OnName num="gorou"]
'......，你完全知道我的意思。你仍然不是緋紅的對手'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune329"]
[OnName num="suzune"]
'你是什麼意思？我對事情的發展不滿意。 "
[cpg cn=true]


[OnName num="gorou"]
我仍然想治愈這種體質。為此，我希望能像我的母親一樣。 "
[cpg cn=true]


這位典型的姐姐退縮了。她就是那個曾經釘死我的人。
[cpg]


但緋紅是個酒鬼。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari325"]
[OnName num="himari"]
'不知怎的，我知道這將會發生。是的，我知道。
[cpg cn=true]


她仍然感到困惑。但我一直在說話。
[cpg]


[OnName num="gorou"]
'我很抱歉，姐姐，......，我為緋紅和你姐姐為我做的事感到高興，但這並不能解決什麼。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune330"]
[OnName num="suzune"]
'...... 是的。原來如此。 ......"
[cpg cn=true]


他們會接受嗎？你仍然覺得你沒有完全理解它。 ......
[cpg]


但這是你必須花時間去了解的事情。
[cpg]


畢竟，她是她姐姐和緋紅的真正母親。
[cpg]


這是一種相當複雜的關係，但我已經愛上了我的媽媽。我再也忍不住了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト








到了晚上，我妹妹被說服了。
[cpg]


最後，她似乎支持我。
[cpg]

[BG f="b_06_4.ui" time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]

[WAIT time=2000]

[VOICE f="Suzune331"]
[OnName num="suzune"]
'不要太魯莽，.......我現在真的很關心我的家人"。
[cpg cn=true]


想了想後，他們各自回到自己的房間睡覺去了。
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[OnName num="gorou"]
'...... 哦，那個？媽媽。 "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa049"]
[OnName num="sawa"]
'緋紅告訴我。她說我應該是早上給你一個刺激的人。
[cpg cn=true]


[OnName num="gorou"]
'嗯，是的，......，我為你感到高興，但是，呃...'
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSawa050"]
[OnName num="sawa"]
我們會想念學校的。
[cpg cn=true]


當我陷入沉思時，我的母親走近了。
[cpg]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト
;//移植前シーンカット

[window target=true]


她只是撫摸著我的頭，擁抱著我。她沒有吻我。
[cpg]


儘管如此，我還是足夠興奮。因為她是我最喜歡的人。
[cpg]



[window target=false]


[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************


然後我不得不馬上離開家，所以我跳過了早餐。
[cpg]


[OnName num="gorou"]
'好吧，那我就走了。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa174"]
[OnName num="sawa"]
'祝你有個愉快的一天。晚上也要向......'打招呼。
[cpg cn=true]


這是我的台詞，不過。考慮到這一點，我離開了家。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_01_1.ui" time=1000]
[WAIT time=1000]


一路走到學院。沒有什麼特別的，只是一個普通的日子。
[cpg]


但我不得不考慮一些事情。
[cpg]


我可能會破壞我的家庭。無論我是否準備這樣做。
[cpg]


也許有辦法可以防止這種情況發生。但也有突發事件。
[cpg]


我得想，這不是好事。我不能呆在這個憲法裡。
[cpg]




[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune332"]
[OnName num="suzune"]
'...... 不可能是我嗎？
[cpg cn=true]

;//＠昼に空き教室で抜いてもらってから、姉さんにそう言われた。


[OnName num="gorou"]
不是說我不能，更像是......，你必須是我的母親。 "
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Suzune333"]
[OnName num="suzune"]
如果我告訴你，我也喜歡你呢？
[cpg cn=true]


[OnName num="gorou"]
......"
[cpg cn=true]


他的臉上帶著嚴肅的表情。他是認真的嗎？或者是......
[cpg]


他是否為了保護他的家人而強迫自己這麼說？我無法決定。
[cpg]


[OnName num="gorou"]
'我還是不行。我愛我的母親.......'
[cpg cn=true]

敢於使用強烈的語言。她看起來很懊惱。
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune334"]
[OnName num="suzune"]
'我看......，我不能阻止你，是嗎？
[cpg cn=true]


她說她會支持我，但我認為她心中仍有一些猶豫。
[cpg]


這並不難理解她的感受。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************


我也仍然迷茫。我經常懷疑我做的事情是否正確。
[cpg]


我們之間存在著明顯的年齡差異，這一點我不必再考慮了。
[cpg]


更重要的是，她是養育我的人。
[cpg]


而且我爸爸也是父母，儘管對我來說是繼父母。 ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_04_3.ui" time=1000]
[WAIT time=1000]


我可能正在犯一個可怕的錯誤。我認為這一點。
[cpg]


但我的母親輕輕地把我包了起來。
[cpg]


;//移植前シーンカット

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa051"]
[OnName num="sawa"]
'歡迎回來，戈羅。你還在痛苦中，是嗎？ "
[cpg cn=true]



[OnName num="gorou"]
是的。 ......
[cpg cn=true]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


我還在向我父親隱瞞。我知道我不能把它永遠藏起來。
[cpg]


我姐姐和緋紅也對此事保持沉默，但我想它不能永遠這樣下去。 ......
[cpg]


[window target=false]


[STOPBGM]

[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


全家一起吃過晚飯後，我回到了自己的房間。
[cpg]


這時我把我的母親帶過來和她談。 ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa052"]
[OnName num="sawa"]
'我想知道。你痛苦是因為你想再搗鼓一下嗎？
[cpg cn=true]


媽媽甚至似乎在淡化它。
[cpg]


我，我覺得我看起來很嚴肅。我想知道它是否已經完成？
[cpg]


[OnName num="gorou"]
'我仍然愛你，媽媽。愛你還不夠'。
[cpg cn=true]


盡可能的直接。就像你不關心你的長相一樣。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sawa193"]
[OnName num="sawa"]
'不要.......如果你的父親發現了怎麼辦？ "
[cpg cn=true]


[OnName num="gorou"]
'我會確保他們不會發現的。我保證。 "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sawa194"]
[OnName num="sawa"]
'是的。 ......，我知道。五郎是認真的，不是嗎？ "
[cpg cn=true]


媽媽的反應是，她好像明白了什麼。
[cpg]


她接著說。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa195"]
[OnName num="sawa"]
'你是認真的，對嗎？我們不能結婚，無論如何都不能。 "
[cpg cn=true]



[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSawa053"]
[OnName num="sawa"]
'我想你，而不是我，會被你的感情所約束。你還是可以接受的，不是嗎？
[cpg cn=true]


我點了點頭。我已經受夠了那方面的衝突。
[cpg]


然後我的母親看起來有點煩惱，說。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSawa054"]
[OnName num="sawa"]
'好吧。
[cpg cn=true]


;//ブラックアウト

我媽媽認為她也喜歡我。我仍然不知道這是否是一種浪漫的感覺。
[cpg]


但我對這一點沒有意見。這不是我應該擔心的事情。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSawa055"]
[OnName num="sawa"]
唯一的另一件事是，我不會以...... Goro而告終。
[cpg cn=true]


對。如果我連這個都接受，那將是一個好故事。
[cpg]


我很早就已經接受了這個事實。我已經知道這是禁忌之愛。
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





第二天早上。早上從緋紅變成了我的母親。
[cpg]


而對於我的母親，我打算做一些與以前不同的事情。
[cpg]


我告訴她，我是說，......，我想吻她。
[cpg]


[OnName num="gorou"]
我是...... 緊張，我就知道。 "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa199"]
[OnName num="sawa"]
'我可能比五郎更緊張。
[cpg cn=true]


母親說這話時笑了。你看起來並不緊張。
[cpg]



;//移植前シーンカット

;//ブラックアウト

[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

我們變得更接近一點。距離消失了。
[cpg]


我們的嘴唇互相接觸。初吻的感覺被不道德所覆蓋。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『街』（昼）******************************************************



時間過去了。所有的時間，只要有可能，我都和我的母親在一起。
[cpg]



[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d2"]

;//【ＢＧ】『街』（夜）******************************************************


而......，這是值得的，我的體質逐漸平靜了下來。
[cpg]


;//ブラックアウト

[window target=false]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


我深信不疑。我不能以任何方式結婚。
[cpg]


我們甚至不能像正常的戀人那樣行事。但這也沒關係。
[cpg]


我們只是秘密地愛著對方，不管我們走多遠。
[cpg]


而對我母親來說，最重要的人必然是我的父親。
[cpg]


當我看到我的母親若無其事地微笑時，我就是這麼想的。
[cpg]


這是一種無論如何都不會有結果的愛。但我認為它已經走到了盡頭。
[cpg]


;//ブラックアウト


[window target=false]


[STOPBGM]

[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


隨著時間的推移，我的情況繼續得到改善。
[cpg]


我不必再去醫院了。
[cpg]


但你可以說，問題是從這裡開始的。
[cpg]


我想我和我母親之間的愛必須繼續下去。否則，我的體質可能會回來。
[cpg]


然後我將永遠這樣，直到我愛上別人。
[cpg]


我也沒有想到我現在會愛上別的人。
[cpg]


換句話說，結果就像我的...... 母親說的那樣，我將把自己綁在自己身上。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』

[WAIT time=1500]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa217"]
[OnName num="sawa"]
'五郎。我可以和你說句話嗎- ......."
[cpg cn=true]


[OnName num="gorou"]
'怎麼了？你想我了嗎？ "
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa056"]
[OnName num="sawa"]
'嗯。你得說出來'。
[cpg cn=true]


儘管我的體質已經平靜下來，不需要再緊張了，但我的母親寧可嘗試觸摸我。
[cpg]


這是我的錯。我無法拒絕，所以我服從了。
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植前シーンカット

當我和母親在一起時，僅這一點就讓我感到安全。
[cpg]


在這個意義上，我也不能說不。
[cpg]


;//ブラックアウト


[window target=false]


[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="gorou"]
我不會對她說不的。 ...... 我們不能明天改天再談這個問題嗎？如果你呆得太晚，人們可能會認為你很奇怪。 "
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa235"]
[OnName num="sawa"]
'是的，但...... 好。我會耐心等待。 "
[cpg cn=true]


媽媽說這話時似乎真的很喜歡我。
[cpg]


我是如此尷尬、高興和...... 歉意，以至於我無法直視她。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



[OnName num="gorou"]
'好吧，那我就走了。
[cpg cn=true]


我和緋紅一起離開家，向母親問好。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari327"]
[OnName num="himari"]
'...... 嘿，大哥哥。我和我哥哥的關係會發生什麼變化？ "
[cpg cn=true]


[OnName num="gorou"]
你說的'會發生什麼'是什麼意思......？ "
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari094"]
[OnName num="himari"]
'你將成為你母親喜歡的人。我應該叫你爸爸嗎？
[cpg cn=true]


我認為他是在開玩笑。這似乎是無辜的緋紅。
[cpg]



[OnName num="gorou"]
'Ze，絕對不要這樣叫我......'。
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『歩く』



在這樣的談話之後，我們在城市中漫步。
[cpg]


我們前往學院。我不必再要求我的姐姐為我做任何事情。
[cpg]




[window target=false]


[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="male_student"]
'哦，不，我前幾天終於吻了她。
[cpg cn=true]


[OnName num="gorou"]
'...... 是的。
[cpg cn=true]


他就是那個很久以前為有女朋友而大驚小怪的人。
[cpg]


我想，我妹妹會叫我爸爸或什麼的，我很不能這麼說。
[cpg]




[window target=false]


[STOPBGM]

[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（夕方）******************************************************


還有一次。我是被一個與我沒有特別關係的女學生叫來的。
[cpg]



[OnName num="female_student"]
'...... 小坂君，你有女朋友嗎？
[cpg cn=true]


[OnName num="gorou"]
'為什麼不呢？她是...... 嗯，......"
[cpg cn=true]


一個可能對我有好感的女孩。當然，我都是為了我的媽媽。
[cpg]


但我甚至不能說我有一個女朋友。而且她不是我的妻子。
[cpg]


[OnName num="gorou"]
我不知道是否有我喜歡的人......."
[cpg cn=true]


[OnName num="female_student"]
'我明白了。對'。
[cpg cn=true]


最後的措辭是這樣的。我不知道，也許我可以和她約會。
[cpg]


但我所擁有的是我的母親。我選擇了她，而不是我姐姐或緋紅。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『歩く』



我們又步行回家，一吃完晚飯，就到了晚上。
[cpg]


我這樣說聽起來很無味，但有一件事已經改變了很多。
[cpg]



[window target=false]


[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


那就是我母親在晚上來找我。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSawa057"]
[OnName num="sawa"]
...... Goro。 "
[cpg cn=true]


他們叫我的方式和以前一樣，但我還是很高興。
[cpg]


我想更多地靠近你。這就是我的想法。
[cpg]


;//＠それから何度か交わった後、俺達は別れた。



然後每個早晨都會到來。
[cpg]


[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我確信，你是唯一能在我身邊的人。我想知道我母親的情況。
[cpg]


我不知道我母親的情況，但我不知道我是否愛上了我父親。
[cpg]


但這是一種無法以任何方式實現的愛。我們不可能成為戀人。 ......
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）

[BG f="b_01_1.ui" time=1000]
[WAIT time=1000]

我吃完早餐，走出前門。向向日葵的相反方向前進。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari329"]
[OnName num="himari"]
'回頭見，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'哦。到時見'。
[cpg cn=true]

[free time=1000]

;//【ＢＧ】『街』（朝）


我在一種昏迷中度過了我的日子。
[cpg]


不是女朋友或情人，但絕對是我愛的人。
[cpg]


這是最幸福但不尋常的幸福。
[cpg]



[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_02_1.ui" time=1000]

[WAIT time=2000]

[BG f="b_02_2.ui" time=1000]

[WAIT time=2000]


[BGM f="bg_d2"]
[BG f="b_02_3.ui" time=1000]

[WAIT time=1000]


然後我去了學院，上課，放學。
[cpg]

;//【ＢＧ】『学園教室』（夕方）


[OnName num="female_student"]
'...... 小坂君。哦，你知道，......."
[cpg cn=true]


[OnName num="gorou"]
...... 什麼？ "
[cpg cn=true]


有一天的女學生。是她問我是否喜歡某人。
[cpg]


[OnName num="female_student"]
'我喜歡小坂君。那......，你想和我出去嗎？
[cpg cn=true]


我遇到了麻煩。也許我可以在這裡轉移到一個體面的生活。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



最後，我帶著待定的答案離開了。
[cpg]


我不能馬上給你一個答案。我不能和她出去，直到我和我媽媽的關係結束。
[cpg]


考慮到這一點，我走回了我的房子。 ......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="gorou"]
'......，這就是所發生的事情。媽媽。 "
[cpg cn=true]


我按照學院的情況講述了這個故事。然後媽媽說。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa252"]
[OnName num="sawa"]
'你可以和他們一起出去，不是嗎？我不會阻止你。 "
[cpg cn=true]


[OnName num="gorou"]
為什麼......，我喜歡你？ "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa253"]
[OnName num="sawa"]
'我很清楚這一點。但你甚至不能讓我在你的餘生中做你的女朋友'。
[cpg cn=true]


...... 這可能確實是事實。
[cpg]


我不知道如果發生這種情況，我爸爸會怎麼樣。
[cpg]


媽媽也可以愛爸爸。
[cpg]


[OnName num="gorou"]
'...... 了解。我會考慮的。 "
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************


然後我忍住不回應那個在學校向我表白的女孩。
[cpg]


我們繼續保持著不太相愛的關係，開始是朋友。
[cpg]


她似乎真的很喜歡我，而且似乎覺得這很令人沮喪。
[cpg]


但我就是我，我從未失去對我母親的愛。
[cpg]


我不覺得我可以適當地愛這個剛剛向我表白的女孩。
[cpg]



;//ブラックアウト



;//========================================
;//●ＣＧ（主人公に膝枕するヒロイン）ev_44
;//人物１：ヒロイン３
;//服装１：私服
;//場所　：主人公の家＿リビング
;//時間　：昼
;//備考　：妊娠していない状態に変えてください
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』


[BGM f="bg_h1"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]



儘管這些曖昧的日子，我還是很開心。
[cpg]


無論我過什麼樣的生活，我的母親都會支持我。
[cpg]


我覺得這就是我需要的一切。我很有成就感。
[cpg]


[VOICE f="sSawa058"]
[OnName num="sawa"]
'...... 你後悔嗎？五郎。 "
[cpg cn=true]


但他看起來肯定只是有點失落。媽媽開始擔心了。
[cpg]


[OnName num="gorou"]
'不可能。不可能的'。
[cpg cn=true]


這些話自然而然就說出來了。我想這是因為我是真心的。
[cpg]


這不僅僅是一個口號。我完全沒有遺憾。
[cpg]


;**【ＣＧ】 ev_44_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa059"]
[OnName num="sawa"]
'我很好，我不在乎我和誰相愛。你喜歡我安撫你的體質，這才是最重要的。
[cpg cn=true]


他說了一句話，讓我有點難過。他說他現在不能回去了。
[cpg]


[OnName num="gorou"]
'那是不可能的事。我真的愛上了你，我的體質已經穩定下來了'。
[cpg cn=true]


相反，我的體質已經穩定下來的事實證明，我喜歡我的母親。
[cpg]


在確定爸爸、姐姐和緋紅已經離開後，我說。
[cpg]


[OnName num="gorou"]
'我愛你，.......蘇納赫恩"。
[cpg cn=true]


我突然叫她的名字，但我母親不會感到沮喪。
[cpg]


;//;**【ＣＧ】 ev_44_b ***********************
;//[CG id=18 index=2 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="sSawa060"]
[OnName num="sawa"]
'是的。我也是'。
[cpg cn=true]


我喜歡這種關係。我想一直呆在她身邊。
[cpg]



;//ブラックアウト

我希望它能永遠繼續下去，但我不知道這是否會發生。
[cpg]


也許我的立場會隨著時間的推移而改變，當我工作的時候，我就會想建立一個家庭。
[cpg]


但......，目前還是不錯的。因為我想繼續做我母親的孩子。
[cpg]


[SCENE id=11]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン３ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================

*start


;###################################################################
*Ep008|快樂的優柔寡斷。
;###################################################################

;//４、選ぶことができない

*select04_4|快樂優柔寡斷

[SCENE id=8]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


...... 號。我還是無法選擇。
[cpg]


這不是一個容易做出的決定，即使有人告訴你需要戀愛。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="gorou"]
'對不起，我還是......無法選擇。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[VOICE f="Suzune337"]
[OnName num="suzune"]
五郎......"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari331"]
[OnName num="himari"]
'大哥......'
[cpg cn=true]


我很迷茫，無法選擇任何人。
[cpg]


然後我告訴他們，我不能選擇反對他們三個人。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa273"]
[OnName num="sawa"]
'我知道五郎的想法。那麼你就不必選擇了'。
[cpg cn=true]


[OnName num="gorou"]
嗯？ "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari095"]
[OnName num="himari"]
'換句話說，我還是要和我們三個人一起搗鼓你，兄弟，就像我們一直以來一樣。
[cpg cn=true]


不，但這不是...
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/3" time=800]
[VOICE f="Suzune338"]
[OnName num="suzune"]
'沒關係的。這是我們已經討論過並決定的事情'。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="3/3" time=800]
[VOICE f="sSawa061"]
[OnName num="sawa"]
'如果他們說墜入愛河可以治愈你的體質，那麼人越多越好。
[cpg cn=true]


嗯，這當然是......？它是否能使治癒的機會增加三倍？
[cpg]


[OnName num="gorou"]
'......'
[cpg cn=true]


即使是這樣，我是否可以這樣利用一個對我這麼好的家庭成員？
[cpg]


但我仍然擔心......，我的呼吸會出現問題。
[cpg]


[OnName num="gorou"]
'......，謝謝你，請。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="Suzune339"]
[OnName num="suzune"]
為了五郎的緣故，我會......盡我所能。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari333"]
[OnName num="himari"]
我讓你去吧。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa275"]
[OnName num="sawa"]
'你會把你的母親寵壞的。
[cpg cn=true]


雖然不解，但她還是決定服從，認為如果他們三個人這麼說，那就這麼辦吧。
[cpg]





;//ブラックアウト

[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]


這事發生幾天后。
[cpg]


他們三個人仍然像往常一樣對我來者不拒。當然，他們還沒有吻過我。 ......
[cpg]


但這一天終於到來，他越過了治愈這種疾病的界限。
[cpg]


[window target=false]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





我醒來的時候，我妹妹已經和我一起爬到了床上。
[cpg]


[OnName num="gorou"]
'嗯...'
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari334"]
[OnName num="himari"]
'哦，我起來了。早上好，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'是的......早上好。你為什麼這麼近？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari096"]
[OnName num="himari"]
為什麼，當然是為了吻我。
[cpg cn=true]


[OnName num="gorou"]
轉到.......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari336"]
[OnName num="himari"]
'否則你將永遠無法恢復。你確定你想保持這種方式嗎？ "
[cpg cn=true]


[OnName num="gorou"]
我不......，認為這是個好主意。
[cpg cn=true]


以這種方式被大家激動，是一種福利，也可能是一種美味的環境。
[cpg]


但這種使生活受到更多限制的體質，仍然必須得到治愈。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari097"]
[OnName num="himari"]
'那好吧，讓我們接吻吧。如果是和我哥哥......好吧。 "
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


然後她把她的嘴唇送到他的面前。
[cpg]


我甚至還沒有刷牙，......，想著我現在不應該想的事情。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_h1"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


緋紅拉開她的嘴唇，看起來很高興。當她做出這樣的表情時，敲擊聲就會越來越強。
[cpg]



[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari098"]
[OnName num="himari"]
'這對你來說還不夠，是嗎？我還是會讓你悸動的。 "
[cpg cn=true]


[OnName num="gorou"]
'什麼，你還打算這麼做？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari099"]
[OnName num="himari"]
'我不在乎你做了多少次。我必須通過做愛來治療我的體質'。
[cpg cn=true]


[OnName num="gorou"]
'但是，這是否可以......'
[cpg cn=true]




[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari100"]
[OnName num="himari"]
'好。你關心什麼呢？
[cpg cn=true]


[OnName num="gorou"]
因為我不認為你在單挑我們。 "
[cpg cn=true]


我想當時有一個規則，就是每個人都是平等的。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari363"]
[OnName num="himari"]
'現在是我負責的時間，所以很好。也許你們兩個也會這樣做......'
[cpg cn=true]


她是一個非常有活力的妹妹。我想我妹妹會有所保留，更不用說我母親了。
[cpg]


即使有這樣的想法，我們最終還是在一起度過了整個時間......。
[cpg]



[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[window target=true]


然後就到了交接的時候。
[cpg]


嚴格說來不是從這裡出發，但......，我姐姐來拉我。
[cpg]

[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune077"]
[OnName num="suzune"]
'...... a bit.你要和我堅持多久，緋紅？ "
[cpg cn=true]


姐姐似乎有點生氣，因為希卡里在午餐後留下來陪她。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari101"]
[OnName num="himari"]
'哦...姐姐'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune341"]
[OnName num="suzune"]
'是時候走了。來吧，走吧。 "
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari365"]
[OnName num="himari"]
嘖嘖。 "
[cpg cn=true]

[free time=1000]

緋紅不情願地離開了房間。這不像緋紅會馬上聽我的話，但我猜她覺得我獨占她這麼久很不好。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune342"]
[OnName num="suzune"]
你......你沒事吧？一點也不，緋紅。
[cpg cn=true]


[OnName num="gorou"]
'嗯，是的......有點過於緊張和疲憊，但是......'
[cpg cn=true]


我的妹妹似乎對我說的話有點不以為然。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune343"]
[OnName num="suzune"]
'...... 你想做什麼？我不知道如果我不這樣做是否更好......'
[cpg cn=true]


[OnName num="gorou"]
'不，我很好。我不能讓你和其他人單獨在一起'。
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune344"]
[OnName num="suzune"]
'謝謝你，戈羅。我很高興。但是......不要做一個假正經的人。 "
[cpg cn=true]


[OnName num="gorou"]
我們會好好照顧它。 "
[cpg cn=true]


這次是和你妹妹一起。不無節制可能是很難做到的。
[cpg]


我們不得不轉移到另一個地方，前往我姐姐的房間。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

;//移植前シーンカット

她沒有吻我，但我覺得她很清楚該怎麼做才能讓我緊張。
[cpg]


她能看出我很喜歡她，即使我們沒有緊緊抓住對方。
[cpg]



;//ブラックアウト

[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



而更多的時間過去了，然後......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa276"]
[OnName num="sawa"]
'五郎。現在輪到你母親了！ "
[cpg cn=true]


[OnName num="gorou"]
'嗯...讓我休息一下...'
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa277"]
[OnName num="sawa"]
'嗯，嗯。 Dahme♪''
[cpg cn=true]


[OnName num="gorou"]
是的，先生。
[cpg cn=true]


我們又搬了房間，這次是和我母親一起。
[cpg]


我認為我的房間對她來說不夠好，但她不願意。
[cpg]


也許有一些本能的東西.......，不，如果不是這樣就太不禮貌了。
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_04_2_up.ui" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[WAIT time=2000]

;//移植前シーンカット

我媽媽可能是我們三個人中最不寬容的。
[cpg]


你可以說她最擔心的是我。如果我不扑騰，我就很難呼吸了。
[cpg]


上午是緋紅，下午是我妹妹，晚上是我母親。他們每個人都有自己的搗蛋時間。
[cpg]


這是那種可以被描述為男人最好的一天。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



當我繼續這樣的粗暴對待時，我的體質就穩定下來了。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="sHimari102"]
[OnName num="himari"]
'這很奇怪!當你墜入愛河時，你真的被治癒了。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSuzune078"]
[OnName num="suzune"]
'......，就我而言，我想知道你愛上的是誰。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]

[VOICE f="sSawa062"]
[OnName num="sawa"]
'他們是誰並不重要。這是每個人的Goro'。
[cpg cn=true]


我母親說了一句話，有點棘手。不，當你說出來的時候，你也說出來了，姐姐。
[cpg]


我自己也不知道我們三個人都愛上了誰。
[cpg]


但現在真的沒有回頭路了。
[cpg]


我的體質已經穩定下來了，這意味著證明我愛上了他們三個中的一個。
[cpg]



;//ブラックアウト

;//移植前シーンカット

我希望我有足夠的資格在這裡說我愛誰。
[cpg]


不幸的是，我是那個在關鍵時刻無法選人的人。
[cpg]


我相信在......，每個人都覺得這很令人沮喪。但我同樣喜歡他們。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************

;//ブラックアウト

[OnName num="father"]
'不知為什麼，你們這些天相處得非常好。
[cpg cn=true]


而我父親，正如預期的那樣，說了一些話，讓我意識到他已經註意到了。
[cpg]


也許我更早地註意到它。只是他現在說出來了。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="sSuzune079"]
[OnName num="suzune"]
'什麼？不，不，這不是......"
[cpg cn=true]


我妹妹對我爸爸的行為很可疑。儘管他們是家人。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari103"]
[OnName num="himari"]
'這就對了!我們一直都很親密，不是嗎？
[cpg cn=true]


[OnName num="father"]
你有嗎？ "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSawa063"]
[OnName num="sawa"]
'是的，沒錯。他正處於想要被寵愛的年齡，我打賭。
[cpg cn=true]


[OnName num="father"]
'......，我明白了。
[cpg cn=true]


爸爸看起來有點複雜。
[cpg]


當然，我不會在他面前無謂地調情。姐姐。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari104"]
[OnName num="himari"]
'爸爸，你不能吃醋。你只屬於我，大哥哥。
[cpg cn=true]


然而，緋紅並不害怕在爸爸面前堅持下去。
[cpg]


看到我妹妹痛苦的臉，我也很難受。 ......
[cpg]

;//移植前シーンカット


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『街』（昼）******************************************************


最後，我們三個人，每個人都保持同樣的距離。
[cpg]


或者也許我只是沒有註意到，因為我離他們所有人都很近。
[cpg]


週末來了又走，不知道這種關係是否好。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]


[VOICE f="sHimari105"]
[OnName num="himari"]
'我們四個人已經很久沒有一起出去了。
[cpg cn=true]


我們出來的時候，只有爸爸有差事要做。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="sSawa064"]
[OnName num="sawa"]
'是的，我想是的。我想特別是鈴音可能會有點害羞'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune080"]
[OnName num="suzune"]
'......，現在沒有什麼可害羞的了。
[cpg cn=true]


這當然是真的。如果我要害羞，那就應該在更早的時候。 ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="sHimari106"]
[OnName num="himari"]
'那麼，我們應該去哪裡？你有一個約會計劃嗎，媽媽？ "
[cpg cn=true]


向母親要一個約會計劃，聽起來......，很奇怪，但這並沒有錯。
[cpg]


;//背景と違う場所です。上下に黒帯を入れるなどの演出を入れてください

[FACE method="feadin" pos="4/7"]
[BG f="b_01_2_up.ui" time=1000]
[WAIT time=1000]


我們要去商場。我記得小時候經常去那裡。
[cpg]


當然，我現在已經不好意思和他們出去了。
[cpg]


在這種情況下再次外出，對我來說是一種非常感性的體驗。
[cpg]


就像他們三個人認出了我的奇怪體質。 ......
[cpg]


更重要的是，我覺得他們接受了我的感受。
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="sSawa065"]
[OnName num="sawa"]
'你已經改變了很多。所有的服裝店'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSuzune081"]
[OnName num="suzune"]
'嗯，......，也許這就是它的方式。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]

[VOICE f="sHimari107"]
[OnName num="himari"]
'你真的想買那麼多衣服嗎？不過我更想吃一頓好的。 "
[cpg cn=true]


[OnName num="gorou"]
對了，我想我們是時候吃晚飯了。 "
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]

[VOICE f="sSuzune082"]
[OnName num="suzune"]
我很驚訝你能負責。
[cpg cn=true]


[OnName num="gorou"]
不，不，我不認為我是負責人。
[cpg cn=true]


我們的談話多麼精彩，我們多麼享受我們在一起的時光。
[cpg]


這樣一來，我們仍然覺得自己是家人而不是戀人。
[cpg]


這就像我們仍然是一個家庭，但我們變得更親密了。 ......
[cpg]


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="sHimari108"]
[OnName num="himari"]
這很有趣。我哥哥給我買了衣服。 "
[cpg cn=true]


[OnName num="gorou"]
'你告訴我你想做的就是買衣服。 ......
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari109"]
[OnName num="himari"]
'沒事的，沒事的。不要把我說的話看得那麼嚴重'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSuzune083"]
[OnName num="suzune"]
'它必須是......
[cpg cn=true]


我母親看著我們的談話，微笑著。
[cpg]


回想起來，也許這就是我一直想要的東西。
[cpg]


我在一次事故中失去了父母后，我希望得到家庭的溫暖。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="sSawa066"]
[OnName num="sawa"]
你玩得開心嗎，戈羅？
[cpg cn=true]


[OnName num="gorou"]
是的。當然，這是一個很大的樂趣。 "
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]


...... 我最喜歡這種時間。我相信這比我和我女朋友在一起的時間要多。 ......
[cpg]


我不想為了和任何一個人在一起而拆散家庭關係。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


隨著我們家庭關係的增長，我感到很遺憾，這個人是一隻蚊子。
[cpg]


[OnName num="father"]
'...... 什麼？你想和我談談。 "
[cpg cn=true]


[OnName num="gorou"]
'不。只是我們今天自己出去了'。
[cpg cn=true]


[OnName num="father"]
'別擔心。我知道你們兩個相處得很好。 "
[cpg cn=true]


可憐的是，我想，但......，還有一件事我在想。
[cpg]


[OnName num="gorou"]
'謝謝你.......因為接受我進入這個家。 "
[cpg cn=true]


[OnName num="father"]
'什麼？出乎意料。 "
[cpg cn=true]


[OnName num="gorou"]
'不，不。我只是覺得我沒有說太多。 "
[cpg cn=true]


[OnName num="father"]
'這正是你需要擔心的事情。我不能丟下你一個人。
[cpg cn=true]


爸爸看起來很尷尬。
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSawa067"]
[OnName num="sawa"]
怎麼了？ " 聽起來你們兩個已經有了很多的對話。"
[cpg cn=true]


[OnName num="gorou"]
'是的。我只是很高興能在這個房子裡。 "
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sSawa068"]
[OnName num="sawa"]
'嗯。不尋常。 "
[cpg cn=true]


不尋常的。我確實沒有對你說過這些話。
[cpg]


[OnName num="gorou"]
我為我的不孝感到抱歉。
[cpg cn=true]


[OnName num="father"]
'別擔心。你還沒有大到可以擔心這種事情的地步'。
[cpg cn=true]


爸爸重複著'不要擔心'這句話。我對此表示感謝。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]


我欠我父親一個人情。我的姐姐、緋紅，甚至我的母親都讓我感到緊張。
[cpg]


我知道他沒有告訴我也不要擔心這個問題，......，但這仍然讓我感覺好些。
[cpg]


[window target=false]


[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

吃完晚飯後，在我的房間裡休息，緋紅過來了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari110"]
[OnName num="himari"]
'嘿，你確定你不打算選人嗎？
[cpg cn=true]


[OnName num="gorou"]
是的，從那時起我就一直在思考這個問題。 ......"
[cpg cn=true]


[OnName num="gorou"]
'不是說我同樣喜歡他們，更多的是我不能只選其中一個的原因。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sHimari111"]
[OnName num="himari"]
你是什麼意思？ "
[cpg cn=true]


[OnName num="gorou"]
我......，喜歡這個房子。
[cpg cn=true]


[OnName num="gorou"]
'我現在不想毀掉這段關係。在今天發生的事情之後，我深深感受到了這一點'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari112"]
[OnName num="himari"]
'...... 這對你姐姐來說可能是一件很難說出口的事情，不是嗎？從我們的角度來看，你是孤獨的。 "
[cpg cn=true]


[OnName num="gorou"]
'...... 抱歉。
[cpg cn=true]


緋紅似乎有點生氣，但也很寬容。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari113"]
[OnName num="himari"]
'好吧，這不是我哥哥第一次優柔寡斷了，所以我已經放棄了。
[cpg cn=true]


[OnName num="gorou"]
我非常抱歉。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari114"]
[OnName num="himari"]
'你不需要道歉。你已經下定決心。你那優柔寡斷的弟弟'。
[cpg cn=true]


我有點抱歉，不能說什麼。
[cpg]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]
;//【ＢＧ】『街』（朝）******************************************************

我的體質越來越平和了。我並不是愛上了任何一個人。
[cpg]


一切都在向好的方向發展，儘管就這段關係而言，沒有任何改變。
[cpg]


...... 就在這時，事情發生了。
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『学園教室』（昼）******************************************************

[OnName num="gorou"]
'姐姐，怎麼了？
[cpg cn=true]


我在一個空蕩蕩的教室裡，我姐姐叫我進去。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune084"]
[OnName num="suzune"]
'...... 抱歉。我不是有意這麼突然叫你出來的。
[cpg cn=true]


[OnName num="gorou"]
'這很好，但有些事情是不對的。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune085"]
[OnName num="suzune"]
這並不是說事情剛剛發生，更像是......，一直以來，都有事情發生。 "
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune086"]
[OnName num="suzune"]
'五郎。你喜歡我嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'是的。我喜歡你。 "
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune087"]
[OnName num="suzune"]
'你不是最好的聽眾。你喜歡我這個戀人嗎？
[cpg cn=true]


[OnName num="gorou"]
這是......，已經決定我不會選擇其他人。 "
[cpg cn=true]


我妹妹聽到我的話後，顯得很痛苦。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune088"]
[OnName num="suzune"]
'我非常喜歡你，我想做你的情人。
[cpg cn=true]


...... 我直到剛才才考慮到這種可能性。
[cpg]


這不是由我來選擇其他人。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune089"]
[OnName num="suzune"]
與我們四個人在一起很有趣，但也可能很辛苦。 "
[cpg cn=true]


顯然，我姐姐很愛我。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune090"]
[OnName num="suzune"]
'我已經準備好成為你唯一的我。
[cpg cn=true]


我想讓你成為我，只做你的妹妹"這句話背後的意圖隱藏在"我想讓你成為我，只做你的妹妹"。
[cpg]


[OnName num="gorou"]
'......'
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune091"]
[OnName num="suzune"]
'我不會對你隱瞞。我想和你結婚'。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune092"]
[OnName num="suzune"]
'如果你說你不會選擇任何人，......，我想與你保持距離。當我們不能在一起時，我在你身邊是很痛苦的。 "
[cpg cn=true]


這是一個令人心痛的想法。我只想和我的家人在一起。
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『学園廊下』（夕方）******************************************************

[OnName num="male_student_A"]
'哦，不。職業道路"。
[cpg cn=true]


[OnName num="male_student_B"]
'你為什麼會迷路呢？你說你想在畢業後馬上找到一份工作'。
[cpg cn=true]


[OnName num="male_student_A"]
我在努力，但我的父母似乎不允許我這樣做。
[cpg cn=true]


[OnName num="male_student_A"]
我和我的兄弟姐妹們也很挑剔。 ......。
[cpg cn=true]


[OnName num="male_student_B"]
'你必須做你自己。家庭，無論你多麼關心他們，他們不可能永遠留在你身邊。
[cpg cn=true]


...... 在稍遠的地方，可以聽到兩個互不相識的人之間的對話。
[cpg]


家庭不可能永遠呆在一起。我想可能確實是這樣的情況。
[cpg]


[window target=false]



[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************


要么你與你的妹妹有一種非家庭的關係，要么你與她這個家庭成員保持距離。它是一個還是另一個？
[cpg]


我想保持我們的關係是這樣的。
[cpg]


[window target=false]

[STOPBGM]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


那天在餐桌上，我和姐姐之間的關係變得很尷尬。
[cpg]


當然，Himaru似乎已經註意到了什麼，並且很擔心。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sSawa069"]
[OnName num="sawa"]
'怎麼了？我不再吃了。 "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSuzune093"]
[OnName num="suzune"]
是的。 ......，我沒有什麼胃口。 "
[cpg cn=true]


如何對待你的妹妹。我覺得我仍有一些事情需要告訴她。
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="gorou"]
'......，我知道這是唯一的辦法。
[cpg cn=true]


思考。經過反复思考，我得出了一個結論。
[cpg]


我不會在我妹妹和緋紅之間做出選擇。我找到了繼續我們目前關係的唯一方法。
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

第二天早上。在我離開之前，我給我姐姐打了電話。
[cpg]


[OnName num="gorou"]
'對不起。我很忙。 "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune094"]
[OnName num="suzune"]
'...... 不'。你想過這個故事嗎？
[cpg cn=true]


[OnName num="gorou"]
'是的。我給出了自己的答案。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sHimari115"]
[OnName num="himari"]
那是關於什麼的故事？ "
[cpg cn=true]


緋春也在這裡。我真的需要她在那裡。
[cpg]


因為如果我和我妹妹結婚，緋紅還是不會說她想留在我身邊。
[cpg]


我甚至不需要再問這個問題了，或者說問這個問題太自私，太不禮貌了。
[cpg]


當然，我母親除外，否則她不會要求這樣做。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="sSuzune095"]
[OnName num="suzune"]
'......，我不能不對緋紅隱瞞。我告訴戈羅。我告訴他，我非常愛他，我想嫁給他。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="sHimari116"]
[OnName num="himari"]
'呵。這很大膽。 "
[cpg cn=true]


緋紅似乎一點也不難過。她可能認為我不能在那裡鼓起勇氣。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune096"]
[OnName num="suzune"]
我......，如果我不能結婚，那麼我就很難在五郎身邊，這是我說的。 "
[cpg cn=true]


[OnName num="gorou"]
是的，我希望你能和我在一起。但我也希望緋紅能和我在一起。 "
[cpg cn=true]


[OnName num="gorou"]
我想知道這樣的方便是否可能。 "
[cpg cn=true]


我妹妹喘著氣，等著我說什麼。
[cpg]


[OnName num="gorou"]
'......，讓他們兩個人結婚怎麼樣？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="sHimari117"]
[OnName num="himari"]
嗯？ "
[cpg cn=true]


[OnName num="gorou"]
'當然，不是現在。因為我喜歡我們這個家庭'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="sSuzune097"]
[OnName num="suzune"]
你知道你在說什麼嗎？日本不承認一夫多妻制"。
[cpg cn=true]


[OnName num="gorou"]
'是的，好吧，......，實際上不會是關於註冊的。
[cpg cn=true]


[OnName num="gorou"]
'但如果他們說他們可以在國外做，如果這就是他們出國的原因，那麼我認為這也很好'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune098"]
[OnName num="suzune"]
'哦，你知道，......，這不是一個法律問題，而是一個心靈問題。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune099"]
[OnName num="suzune"]
'現在你們已經搬到一起住了，或者有了孩子，你會好好考慮嗎？
[cpg cn=true]


[OnName num="gorou"]
'我正在考慮這個問題。我在認真考慮與你們倆結婚。 "
[cpg cn=true]


[OnName num="gorou"]
'因為我決定不做選擇。我不認為走到一半是個好主意。
[cpg cn=true]


一種奇怪的沉默佔了上風。在這種情況下，Himari開始笑了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari118"]
[OnName num="himari"]
'...... phew, ha ha ha'.
[cpg cn=true]


[OnName num="gorou"]
'緋紅?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari119"]
[OnName num="himari"]
'我沒有意識到你在想這些。你應該告訴我'。
[cpg cn=true]


笑完後，緋紅插話說。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari120"]
[OnName num="himari"]
'我不需要和你們兩個人結婚，也不需要出國，或者任何東西。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari121"]
[OnName num="himari"]
'因為我可以一直呆呆的，即使我的姐姐和弟弟結婚了。
[cpg cn=true]


[OnName num="gorou"]
什麼？ "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune100"]
[OnName num="suzune"]
'但是，但是......，我將擁有五郎一個人。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSuzune101"]
[OnName num="suzune"]
如果緋紅像你一樣喜歡五郎，你將無法原諒他。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="sHimari122"]
[OnName num="himari"]
'你們都想得太多了。你不知道未來會怎樣'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari123"]
[OnName num="himari"]
'你為什麼一開始就想結婚？你從哪裡得到的壟斷？我完全可以做我哥哥的第二。
[cpg cn=true]


緋紅的性格是讓模棱兩可的東西模糊不清。
[cpg]


她正試圖把我們從思想中解救出來。
[cpg]


也許她正在努力管理這種情況，即使它有點不堪重負。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune102"]
[OnName num="suzune"]
'緋紅，你不吃醋嗎？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari124"]
[OnName num="himari"]
'我願意。但和我妹妹在一起，我很好。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari125"]
[OnName num="himari"]
'你們倆都太守規矩了。這一天到來時，又不是世界末日，為什麼事情不能按原樣發展？
[cpg cn=true]


我和我妹妹互相看了看。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari126"]
[OnName num="himari"]
'那你確定你是準時的嗎？我已經習慣於遲到了。 "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="sSuzune103"]
[OnName num="suzune"]
啊！ "
[cpg cn=true]


;//ブラックアウト

[window target=false]

[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（朝）******************************************************

我們開始交談。我趕緊準備一下，然後去學院，但我妹妹可能會遲到。
[cpg]


緋紅說的那件事是......，說是最後什麼都沒做，但我的心卻奇怪的很清楚。
[cpg]


我決定做的事情也可能是像緋紅所說的那樣。
[cpg]


我想盡可能長時間地保持相同的距離。
[cpg]


緋紅可能已經看穿了這一點，她可能已經安撫了她的妹妹。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『学園教室』（昼）******************************************************


[OnName num="male_student_A"]
'我已經決定了。我畢竟要去找一份工作。
[cpg cn=true]


[OnName num="male_student_B"]
'嗯，這很好。為了你的家庭，繼續接受高等教育是很愚蠢的'。
[cpg cn=true]


[OnName num="male_student_A"]
'哦。 '我想如果我要考慮什麼是對我的家庭最好的，那麼我不妨做我想做的事。
[cpg cn=true]


[OnName num="male_student_A"]
'在我焦頭爛額的時候，這對我的家庭是不利的。
[cpg cn=true]


[OnName num="male_student_A"]
'我想有時我為自己做的事也是為我的家人做的事。
[cpg cn=true]


...... 有時間的二人組。看起來我們已經取得了一些進展。
[cpg]


我也不能一直迷路。我不能迷失，不能選擇任何人，我不能迷失。
[cpg]


如果你已經下定決心，就繼續向前推進吧。這就是我的想法。
[cpg]


[window target=false]

[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『学園教室』（夕方）******************************************************

這是一種思維方式，但我也想知道是否所有的事情都要決定。
[cpg]


有時，像向日葵這樣的思維方式可以解決一切問題。
[cpg]


即使它不能解決所有問題，但有些時候，現狀是最幸福的。
[cpg]


似乎不從我姐姐那裡學到，我甚至不能意識到這麼明顯的事情。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune104"]
[OnName num="suzune"]
因此，......，這裡的解決方案是：......
[cpg cn=true]


你的妹妹表現得很平靜，她沒有提醒你她遲到了。
[cpg]


當我在同一個教室裡時也是如此。可能要感謝緋紅的存在，我才能像這樣保持冷靜。
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************



[OnName num="female_student"]
'哦，不。我已經被終止了，嗯？ "
[cpg cn=true]


[OnName num="male_student"]
'審查？漫畫？ "
[cpg cn=true]


[OnName num="female_student"]
'是的，一部卡通片。你想在那裡堅持下去嗎？它就這樣結束了。 "
[cpg cn=true]


[OnName num="male_student"]
'太糟糕了。我寧願有一個后宮，而不是一些奇怪的聯姻。
[cpg cn=true]


現實不是漫畫書。不要擔心被審查。
[cpg]


我在聽一些夫婦的談話時也這麼想。
[cpg]


[OnName num="female_student"]
'嗯？我不喜歡后宮和通常的東西。你是不是有什麼外遇？ "
[cpg cn=true]


[OnName num="male_student"]
'不，不。 ......，怎麼可能呢？
[cpg cn=true]


...... 好吧，我們說有一些關係在一起沒有問題，比如說這兩個人。
[cpg]


但同樣，現實不是卡通。
[cpg]


我的生活不是為了讓人看到，為了給人看。
[cpg]


如果是這樣的話，追求幸福總是更好的，即使它是模糊的。
[cpg]




;//ブラックアウト


[window target=false]



[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="sSuzune105"]
[OnName num="suzune"]
'Himari.不要再在你父親面前調情了。
[cpg cn=true]


[VOICE f="sHimari127"]
[OnName num="himari"]
'你為什麼不和你妹妹也調情呢？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune106"]
[OnName num="suzune"]
'不! 這不會耽誤我們的工作。 "
[cpg cn=true]


[OnName num="gorou"]
'當人們說他們不喜歡它時，我很傷心。 ......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune107"]
[OnName num="suzune"]
哦，不，我不是這個意思。 "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]

媽媽笑著說。
[cpg]


起初我覺得很奇怪，沒有人選擇她，但也許這就是日常生活應該有的樣子。
[cpg]


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[window target=true]


然後過了一會兒，......
[cpg]


;//========================================
;//●ＣＧ（ベッドに三人寝転がっている。おなかは膨らんでない）ev_50
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//人物３：ヒロイン３
;//服装３：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================


[STOPBGM]
[WAIT time=1000]
[BGM f="bg_op"]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sHimari128"]
[OnName num="himari"]
'嘿嘿~。我們都在一起，這有點像一次旅行。 "
[cpg cn=true]


[VOICE f="sSawa070"]
[OnName num="sawa"]
'嗯，沒錯。我們已經有一段時間沒有過家庭假期了。
[cpg cn=true]


[VOICE f="sSuzune108"]
[OnName num="suzune"]
......，是的，沒錯。 "
[cpg cn=true]


今天，我們四個人在緋紅的要求下在一起。
[cpg]


這也不適合我，因為我的體質已經穩定下來了。
[cpg]


這是我的命運，因為我沒有選擇其他任何人。
[cpg]


[VOICE f="sHimari129"]
[OnName num="himari"]
'來吧，兄弟。你想要多少刺激，我就給你多少刺激。 "
[cpg cn=true]


[VOICE f="sSuzune109"]
[OnName num="suzune"]
'......，很瘋狂。這就是......'
[cpg cn=true]


[VOICE f="sHimari130"]
[OnName num="himari"]
'嗯，我很開心。我希望我們都能一直在一起'。
[cpg cn=true]


我當時的心情無法形容，但卻很激動。
[cpg]


[VOICE f="sSawa071"]
[OnName num="sawa"]
'呵。緋紅是如此的無辜'。
[cpg cn=true]


還有我的母親，她說，嗯，她也在天真地笑著。
[cpg]


我不知道他們三個人到底在想什麼。但他們似乎很高興。
[cpg]




[VOICE f="Suzune385"]
[OnName num="suzune"]
如果你對我的愛不夠，我就會生氣，因為我們三個人在一起。
[cpg cn=true]


[VOICE f="sHimari131"]
[OnName num="himari"]
'很高興見到你，大哥哥。 '不，我想我總有一天會成為一個父親。
[cpg cn=true]


[OnName num="gorou"]
'我不知道。
[cpg cn=true]


[VOICE f="Sawa315"]
[OnName num="sawa"]
不要漏掉一個人！ "
[cpg cn=true]




[OnName num="gorou"]
...... 我知道我在做什麼。
[cpg cn=true]


是否有后宮這種東西，或者是否應該有？
[cpg]



;//ブラックアウト

家庭。戀人。不能用這些詞來定義的關係。
[cpg]


我當然很高興，讓模棱兩可的事情保持模棱兩可。
[cpg]


我想我姐姐、緋紅和我母親可能也有同樣的感覺。 ......
[cpg]

[SCENE id=12]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]
;//ＥＮＤ：ハーレムルート






;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





