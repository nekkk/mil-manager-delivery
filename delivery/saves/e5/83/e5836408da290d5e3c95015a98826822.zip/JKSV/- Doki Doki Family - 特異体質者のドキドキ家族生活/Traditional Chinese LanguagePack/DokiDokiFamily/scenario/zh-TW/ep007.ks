
*start

;###################################################################
*Ep007|不願看到的沙羽之思
;###################################################################


;//３、砂羽
*select04_3|

[SCENE id=7]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


我想到了我母親的臉。不，我知道這不會發生，但它只是突然出現在我的腦子裡。
[cpg]


姐姐和緋紅還是不錯的。她們是妯娌，年齡相仿。
[cpg]


但是和我媽媽在一起，年齡差距相當大。不......
[cpg]


他說他是一個已婚男人。你有一個父親。
[cpg]


而我的父親對我來說仍然是我的父親，......，我越想越覺得不可能。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[window target=true]

是緋紅讓我在早上感到緊張。她來到我的房間，......
[cpg]


而在那之後，我對離開房子感到猶豫不決。
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari317"]
[OnName num="himari"]
'兄弟，你不是已經去了嗎？我們要遲到了。 "
[cpg cn=true]


[OnName num="gorou"]
'是的，我一會兒就到.......，去吧。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari318"]
[OnName num="himari"]
'嗯。我得去看看你媽媽。
[cpg cn=true]


他們看穿了這一點。這就是事情的真相。 ......
[cpg]


[free time=1000]

[SE f="se003"]
;//【ＳＥ】『ドア閉まる』


緋紅離開後，就剩下我和媽媽。
[cpg]


姐姐和爸爸去工作了。緋紅也上了學。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa108"]
[OnName num="sawa"]
'......，你想要見我，對嗎？我想知道......"
[cpg cn=true]


他在輕鬆的氣氛中問我。
[cpg]


我想你已經可以看出，我有一些嚴肅的想法。但我的母親敢於讓我這樣做。
[cpg]


[OnName num="gorou"]
'我，嗯，...... 我母親的...... 母親和...... 嗯...'
[cpg cn=true]


我不知所措了。我不知道該說些什麼。
[cpg]


我覺得如果我說出來，就意味著結束了。在這樣的時候。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa109"]
[OnName num="sawa"]
'我幾乎可以看到它。也許我離得太近了--'
[cpg cn=true]


我幾乎總是能看出來，我母親曾告訴我。還有就是我離得太近了。 ......
[cpg]


[OnName num="gorou"]
'嗯，嗯，......，這是...'
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa026"]
[OnName num="sawa"]
'我不能幫助它。如果你說你喜歡它。
[cpg cn=true]


......，輕鬆通過。不，這不是好事。
[cpg]


[OnName num="gorou"]
'嘿，等一下，等一下! 我是認真的。 "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa027"]
[OnName num="sawa"]
'不管怎樣，今天晚上見。如果我不早點到那裡，我上學就要遲到了。
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





所以我們去了學校。
[cpg]


但我已經在空中了。儘管我在白天會看到我的妹妹，......
[cpg]


即使考慮到這一點，我也無法保持冷靜。想到我的母親會為我這樣做。
[cpg]


這一點就使我痛苦地感到緊張。我以前從來沒有過這樣的暗戀。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************



而在晚上放學的時候。我感到很慌張。
[cpg]


媽媽說："我也沒辦法，是吧？"這是真的嗎？
[cpg]


我有些不講情面。自然，我必須在爸爸回家之前和他談談。
[cpg]


爸爸和媽媽有單獨的房間，所以他們沒有機會撞到一起。
[cpg]




;//ブラックアウト


[window target=false]

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



當我在想這些的時候，我到了家。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Himari319"]
[OnName num="himari"]
歡迎回家。你看起來棒極了。 "
[cpg cn=true]


它是什麼顏色？它是紅色還是藍色？這並不重要。
[cpg]

[free time=1000]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa028"]
[OnName num="sawa"]
'嗯。你看起來很難受的樣子。很好。 "
[cpg cn=true]


拍了拍我的頭，我被帶到了母親的房間。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




只要有她在我身邊，握著我的手，就足以讓我感覺到我要失去它。
[cpg]


我不禁感到，我的心被控制得那麼厲害。
[cpg]



;//========================================
;//●ＣＧ（ヒロインが寝ている主人公に近づく。穏やかに微笑んでいる→心配そうな表情に）ev_36
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================



[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sSawa029"]
[OnName num="sawa"]
'......，我想知道像這樣在你身邊是否會讓你緊張。
[cpg cn=true]


我很激動。我點了點頭，回答道。
[cpg]


[OnName num="gorou"]
'是的。 ......，它非常、非常平靜。
[cpg cn=true]


媽媽撅了一會兒嘴，然後笑了一下。
[cpg]


[VOICE f="sSawa030"]
[OnName num="sawa"]
'嗯。平靜，是這樣嗎？你不應該感到興奮嗎？ "
[cpg cn=true]


但我只能這麼說。
[cpg]


也許我畢竟不是想悸動，我是想冷靜下來。
[cpg]


也許是我一直有呼吸困難的事實，也許是我不能得到一個暗戀的對象，我就像焦慮的.......。
[cpg]


如果是這樣的話，也許我的體質只要做這個就能治好。
[cpg]


只要在媽媽身邊，我就覺得很有成就感。
[cpg]


;**【ＣＧ】 ev_36_a ***********************
[CG id=16 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa031"]
[OnName num="sawa"]
'哦，好吧。我想做你想讓我做的事。
[cpg cn=true]


[OnName num="gorou"]
'謝謝你。媽媽。 "
[cpg cn=true]


[VOICE f="sSawa032"]
[OnName num="sawa"]
'......，我真的很擔心你。我也把五郎當作我的孩子。
[cpg cn=true]


然後，突然，他看起來很擔心。
[cpg]


;**【ＣＧ】 ev_36_b ***********************
[CG id=16 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa033"]
[OnName num="sawa"]
'我想如果你為我感到興奮，那也很好。
[cpg cn=true]


[VOICE f="sSawa034"]
[OnName num="sawa"]
'如果這意味著他不必受苦，我願意為五郎做任何事。
[cpg cn=true]


我不知道你這麼看重我。她給人的印像是平靜的，所以我有點吃了一驚。
[cpg]


[OnName num="gorou"]
'我很高興.......非常感謝你。 "
[cpg cn=true]


我這樣說，知道這是一個愚蠢的說法，但想讓他知道我很感激。
[cpg]


我努力使自己的臉色盡可能嚴肅，聲音也盡可能嚴肅。我試圖傳達我的感受，但......
[cpg]


但我媽媽看起來特別惱火。
[cpg]


出於某種原因，她看起來更苦惱，這就是她在我看來的樣子。
[cpg]


[VOICE f="sSawa035"]
[OnName num="sawa"]
'如果五郎說他喜歡我，那麼我想這也是可以的。這不是謊言'。
[cpg cn=true]


媽媽小心翼翼地選擇她的語言，並逐漸告訴我她的感受。
[cpg]


;**【ＣＧ】 ev_36_c ***********************
[CG id=16 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa036"]
[OnName num="sawa"]
'我不知道該怎麼做。他絕對是我的孩子，但我也喜歡他'。
[cpg cn=true]


我明白了。 ......，我不知道我讓你這麼想。
[cpg]


[OnName num="gorou"]
......."
[cpg cn=true]


我是不是太不敏感了？我面對的是一個兒子，儘管是一個繼子。
[cpg]


我把我媽媽逼到了絕境。我已經意識到了這一點。
[cpg]


我想我的行為可能太自私了，但我仍然無法停止...... 這種感覺。
[cpg]


[OnName num="gorou"]
我很抱歉。但我不能停下來。 "
[cpg cn=true]


我不知道該怎麼做。但如果我把這種焦慮大聲表達出來，會不會讓我母親更加惱火？
[cpg]


那麼我想最好是說我想做什麼。
[cpg]


[OnName num="gorou"]
我想吻你。
[cpg cn=true]


彷彿是為了掩飾，我說。她點了點頭。
[cpg]


我看到她閉上了眼睛，我走近了一些。 ......
[cpg]


這一步將是任何理智的人都不會採取的措施。但我早已經瘋了。
[cpg]


[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

...... 而且。
[cpg]


我親吻了我母親的嘴。我邁出了明顯不應該邁出的一步。
[cpg]


[OnName num="gorou"]
......"


;//ＣＧ
;**【ＣＧ】 ev_36_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sSawa037"]
[OnName num="sawa"]
'呼。不要做這種表情。
[cpg cn=true]


我本來會是什麼樣子？他看起來很遺憾嗎？
[cpg]


[VOICE f="sSawa038"]
[OnName num="sawa"]
我有沒有好好地敲打你？ "
[cpg cn=true]


你這樣一說，我不激動是假的。然而。
[cpg]


[OnName num="gorou"]
'再來一次......'
[cpg cn=true]


[VOICE f="sSawa039"]
[OnName num="sawa"]
'不，你不能。今天就到此為止。你已經習慣了重擊，這對你沒有好處，是嗎？
[cpg cn=true]


[OnName num="gorou"]
嗯，是的，但是...
[cpg cn=true]


[VOICE f="Sawa132"]
[OnName num="sawa"]
'哦，上帝。不要太執著，否則女孩們會討厭你！ '
[cpg cn=true]


女孩，是否包括我的母親？
[cpg]


這樣問很不禮貌，所以我閉嘴，退了出去。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





我不想讓我的母親討厭我。我不想為此做任何事情。
[cpg]


我很矛盾，不知道它們是否有衝突。
[cpg]

[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[SE f="se009"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





早上，我無法正常看到母親的臉。
[cpg]


看到這一點，我姐姐和緋紅似乎也感覺到了。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Himari320"]
[OnName num="himari"]
'你越過了某種界限，不是嗎？大哥哥。 "
[cpg cn=true]


[OnName num="gorou"]
'...... 那是......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune325"]
[OnName num="suzune"]
'......，我不會說什麼。你們兩個需要在自己之間解決這個問題。
[cpg cn=true]


這就像已經說了。這很令人厭惡。
[cpg]


但我不能幫助它。我喜歡我的母親。
[cpg]


[free time=1000]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa133"]
[OnName num="sawa"]
不要過多地折磨五郎。是我推著你去做的。
[cpg cn=true]


他將與我一起承擔。如果爸爸在這裡，他就會有很多麻煩。
[cpg]


我很高興我爸爸是早早離開家的人。 ......，我完成了我的早餐。
[cpg]


;//ブラックアウト

[window target=false]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************


[OnName num="gorou"]
我走了。 ......
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa134"]
[OnName num="sawa"]
'是的。祝你有個愉快的一天。
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari321"]
[OnName num="himari"]
我走了。 "
[cpg cn=true]


......，我感到無法形容。我想在我母親的身邊。
[cpg]


但這是一個未實現的願望。
[cpg]


我是她的兒子，儘管她是我的繼女，而且我首先要去學院。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[window target=false]

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[window target=true]


我打算去學院，同時有點心事重重。
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="male_student"]
我不知道我的感覺如何，但我不確定。你不覺得今天的我有些不同嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'我不...... 知道，我也不認為，但......'
[cpg cn=true]


[OnName num="male_student"]
'我們出去了! 我的春天也已經來臨了，哈哈。 "
[cpg cn=true]


[OnName num="gorou"]
'是的。對你有好處。 "
[cpg cn=true]


[OnName num="male_student"]
'多麼單薄的回應啊。當然，我們甚至還沒有親吻過'。
[cpg cn=true]


...... 我吻了一個我甚至沒有約會的人。而且是和我的岳母一起。
[cpg]


即使我想說，我也不能這麼說。在此期間，是我妹妹等我的時候了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_03_2_up.ui" time=1000]
[WAIT time=2000]

還有午餐時間。當我們單獨在一起時，我妹妹對我說。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune326"]
[OnName num="suzune"]
'......，你的母親是我們真正的母親。所以......."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune327"]
[OnName num="suzune"]
'不要大意，不要破壞我們的家庭。
[cpg cn=true]


他們說。這是個相當嚴厲的詞。
[cpg]


她說'親生母親'的方式也有點刺耳。但我沒有選擇。
[cpg]


我就像一個異物。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





我的體質如果不與別人相愛，就無法治愈。
[cpg]


我想，我的姐姐和緋紅也是可能的伙伴。
[cpg]


但我並不想這麼做。我愛的人是我的母親。
[cpg]


我想不出別的辦法。我喜歡我的母親。
[cpg]


現在我說出來了，我明白為什麼我姐姐告訴我不要拆散這個家庭。
[cpg]


我姐姐告訴我的話在我腦中迴盪。
[cpg]


;//ブラックアウト


[window target=false]

[STOPBGM]

[BG f="b_04_3_up.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa135"]
[OnName num="sawa"]
'歡迎回來。你怎麼樣，已經很辛苦了嗎？
[cpg cn=true]


這已經很困難了。我當時沒有狀態去撒謊。
[cpg]


[OnName num="gorou"]
'...... 是的。我想和我媽媽在一起。好嗎？ "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa136"]
[OnName num="sawa"]
'當然了。我已經決定我要做晚上的--'
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



然後我被帶到了我媽媽的房間。
[cpg]


只要來到這裡，就覺得是一種解脫.......
[cpg]


;//========================================
;//●ＣＧ（寝ているヒロインに迫る主人公。抱きしめ合う感じ）ev_37
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================


[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h2"]
;**【ＣＧ】 ev_37_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSawa040"]
[OnName num="sawa"]
'來吧，我給你一個擁抱。
[cpg cn=true]


當我看到媽媽張開雙臂時，我都快哭了。
[cpg]


我想告訴她我現在的一切感受。
[cpg]


但我不能說出來，我還是覺得自己要哭了。
[cpg]


我不知道該怎麼做。我甚至不知道我是否應該通過這種愛。
[cpg]


在我看來，我愛我的母親是毫無疑問的。
[cpg]


而且更重要的是，我不想惹惱我的母親。
[cpg]


[OnName num="gorou"]
...... 我仍然愛我的母親。
[cpg cn=true]


這句話的聲音很小，連我都感到驚訝。我知道我不應該說這麼多。
[cpg]


如果我在這裡說，我想做你的女朋友，那就完了。
[cpg]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa041"]
[OnName num="sawa"]
'對。我知道。你不必什麼都說'。
[cpg cn=true]


我不是想讓你說出所有的事情。這將有助於我。
[cpg]


[OnName num="gorou"]
'...... 是的。
[cpg cn=true]


[VOICE f="sSawa042"]
[OnName num="sawa"]
'你今天一定很痛苦。破壞它也沒關係'。
[cpg cn=true]


我認為有些話，如果你說出來，你就不能收回。如果我母親能讓他們閉嘴，那將是相當有幫助的。
[cpg]


我沒有說什麼，就擁抱了她。
[cpg]


[OnName num="gorou"]
'你聞起來像我母親。
[cpg cn=true]


她並不諱言這一點。她肯定與她的姐姐和緋紅不同。
[cpg]


媽媽認為我不會再靠近了。
[cpg]


;**【ＣＧ】 ev_37_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa043"]
[OnName num="sawa"]
'好吧，...... 吾郎將永遠是一個被寵壞的孩子。
[cpg cn=true]


這個溫柔的聲音使我無法壓制我一直在假裝的東西，我一直在忍耐的東西。
[cpg]


我想讓你成為我的全部。說這一個字很容易。
[cpg]


但......，我不知道我是否真的能做到這一點。
[cpg]


不僅我不知道，而且連她也可能不知道。
[cpg]


如果是這樣，我說的話就會無從談起。
[cpg]


[VOICE f="sSawa044"]
[OnName num="sawa"]
'怎麼了？你看起來像要哭了。 "
[cpg cn=true]


她現在不是我唯一的媽媽。我不禁想到了這一點。
[cpg]


她看起來也像是要哭了。我真的喜歡上了我的媽媽。
[cpg]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa045"]
[OnName num="sawa"]
'我想知道她是否有什麼可悲之處，而不僅僅是痛苦。
[cpg cn=true]


這不是悲傷，是難過。目前的這種情況是可悲的。
[cpg]


這不再是好事，我知道，這就是為什麼我不能停止。
[cpg]


[OnName num="gorou"]
'媽媽，......，我已經下定決心了。
[cpg cn=true]


媽媽看起來有點擔心。
[cpg]


也許她以某種方式知道她將被告知什麼。
[cpg]


;**【ＣＧ】 ev_37_b ***********************
[CG id=17 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa046"]
[OnName num="sawa"]
'決定了什麼？
[cpg cn=true]


[OnName num="gorou"]
'你知道他們是怎麼說我的，如果我不談戀愛，我的體質就不會安定下來。
[cpg cn=true]


媽媽顯然知道一切。儘管如此，她只是帶著相貌聽我說話。
[cpg]


[VOICE f="sSawa047"]
[OnName num="sawa"]
'是的。怎麼了？ "
[cpg cn=true]


一旦我說出這句話，就沒有回頭路可走了。這是我經常思考的問題。
[cpg]


[OnName num="gorou"]
'我喜歡......，你的母親。
[cpg cn=true]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa048"]
[OnName num="sawa"]
'是的。我知道。 "
[cpg cn=true]


[OnName num="gorou"]
'不，不。你的母親還不明白'。
[cpg cn=true]


[OnName num="gorou"]
當我說我愛你時，我是指愛。 "
[cpg cn=true]


;//移植前シーンカット

;//ブラックアウト



我終於說出來了。喜歡"這個詞與"愛"這個詞有不同的含義。
[cpg]


短暫的沉默。然後媽媽反問道。
[cpg]


;**【ＣＧ】 ev_37_b ***********************
[CG id=17 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sawa153"]
[OnName num="sawa"]
'你是認真的嗎？你知道這意味著什麼。 "
[cpg cn=true]


我想我知道。我想我知道。 ......
[cpg]


[VOICE f="Sawa154"]
[OnName num="sawa"]
'也許我們會被分開。你準備好了嗎？ "
[cpg cn=true]


對。這是可能摧毀家庭的事情。
[cpg]


你的妹妹會怎麼想？而且，即使緋紅不認為有什麼，最大的問題是爸爸。
[cpg]


我又得迷路了。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



爸爸通常會回家吃飯。
[cpg]


[OnName num="father"]
'鈴音。這些天的工作怎麼樣？ "
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune328"]
[OnName num="suzune"]
嗯，......，還有很多地方我不夠強壯。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari322"]
[OnName num="himari"]
'你作為一個姐妹，力量並不弱。我有點不適應'。
[cpg cn=true]


他們正在談論這個問題。正常的、親子的對話。
[cpg]


但我......，感覺有點被疏遠。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



之後，我邀請緋紅和她的妹妹到我的房間。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari323"]
[OnName num="himari"]
'...... 怎麼了？你的臉上有一種神秘的表情'。
[cpg cn=true]


[OnName num="gorou"]
是的，好的。 ......
[cpg cn=true]


我不知道該如何談及這個話題，這時緋紅說。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Himari324"]
[OnName num="himari"]
'你是在說你的母親嗎？可能，是的。 "
[cpg cn=true]


[OnName num="gorou"]
'......，你完全知道我的意思。你仍然不是緋紅的對手'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune329"]
[OnName num="suzune"]
'你是什麼意思？我對事情的發展不滿意。 "
[cpg cn=true]


[OnName num="gorou"]
我仍然想治愈這種體質。為此，我希望能像我的母親一樣。 "
[cpg cn=true]


這位典型的姐姐退縮了。她就是那個曾經釘死我的人。
[cpg]


但緋紅是個酒鬼。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari325"]
[OnName num="himari"]
'不知怎的，我知道這將會發生。是的，我知道。
[cpg cn=true]


她仍然感到困惑。但我一直在說話。
[cpg]


[OnName num="gorou"]
'我很抱歉，姐姐，......，我為緋紅和你姐姐為我做的事感到高興，但這並不能解決什麼。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune330"]
[OnName num="suzune"]
'...... 是的。原來如此。 ......"
[cpg cn=true]


他們會接受嗎？你仍然覺得你沒有完全理解它。 ......
[cpg]


但這是你必須花時間去了解的事情。
[cpg]


畢竟，她是她姐姐和緋紅的真正母親。
[cpg]


這是一種相當複雜的關係，但我已經愛上了我的媽媽。我再也忍不住了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト








到了晚上，我妹妹被說服了。
[cpg]


最後，她似乎支持我。
[cpg]

[BG f="b_06_4.ui" time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]

[WAIT time=2000]

[VOICE f="Suzune331"]
[OnName num="suzune"]
'不要太魯莽，.......我現在真的很關心我的家人"。
[cpg cn=true]


想了想後，他們各自回到自己的房間睡覺去了。
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[OnName num="gorou"]
'...... 哦，那個？媽媽。 "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa049"]
[OnName num="sawa"]
'緋紅告訴我。她說我應該是早上給你一個刺激的人。
[cpg cn=true]


[OnName num="gorou"]
'嗯，是的，......，我為你感到高興，但是，呃...'
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSawa050"]
[OnName num="sawa"]
我們會想念學校的。
[cpg cn=true]


當我陷入沉思時，我的母親走近了。
[cpg]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト
;//移植前シーンカット

[window target=true]


她只是撫摸著我的頭，擁抱著我。她沒有吻我。
[cpg]


儘管如此，我還是足夠興奮。因為她是我最喜歡的人。
[cpg]



[window target=false]


[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************


然後我不得不馬上離開家，所以我跳過了早餐。
[cpg]


[OnName num="gorou"]
'好吧，那我就走了。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa174"]
[OnName num="sawa"]
'祝你有個愉快的一天。晚上也要向......'打招呼。
[cpg cn=true]


這是我的台詞，不過。考慮到這一點，我離開了家。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_01_1.ui" time=1000]
[WAIT time=1000]


一路走到學院。沒有什麼特別的，只是一個普通的日子。
[cpg]


但我不得不考慮一些事情。
[cpg]


我可能會破壞我的家庭。無論我是否準備這樣做。
[cpg]


也許有辦法可以防止這種情況發生。但也有意外情況。
[cpg]


我得考慮一下。我不能停留在這種憲法中。
[cpg]




[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune332"]
[OnName num="suzune"]
......，就不能是我嗎？ "
[cpg cn=true]

;//＠昼に空き教室で抜いてもらってから、姉さんにそう言われた。


[OnName num="gorou"]
這不像是沒有，更像是......，必須是你。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Suzune333"]
[OnName num="suzune"]
如果我告訴你，我也喜歡你呢？
[cpg cn=true]


[OnName num="gorou"]
......"
[cpg cn=true]


他的臉上帶著嚴肅的表情。他是認真的嗎？或者是......
[cpg]


他是否為了保護他的家人而強迫自己這麼說？我無法決定。
[cpg]


[OnName num="gorou"]
'我還是不行。我愛我的母親.......'
[cpg cn=true]

敢於使用強烈的語言。她看起來很懊惱。
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune334"]
[OnName num="suzune"]
'我看......，我不能阻止你，是嗎？
[cpg cn=true]


她說她會支持我，但我認為她心中仍有一些猶豫。
[cpg]


這並不難理解她的感受。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************


我也仍然迷茫。我經常懷疑我做的事情是否正確。
[cpg]


我們之間存在著明顯的年齡差異，這一點我不必再考慮了。
[cpg]


更重要的是，她是撫養我長大的父母。
[cpg]


而且我爸爸也是父母，儘管對我來說是繼父母。 ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_04_3.ui" time=1000]
[WAIT time=1000]


我可能正在犯一個可怕的錯誤。我認為這一點。
[cpg]


但我的母親輕輕地把我包了起來。
[cpg]


;//移植前シーンカット

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa051"]
[OnName num="sawa"]
'歡迎回來，戈羅。你還在痛苦中，是嗎？ "
[cpg cn=true]



[OnName num="gorou"]
是的。 ......
[cpg cn=true]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


我還在向我父親隱瞞。我知道我不可能永遠隱藏它。
[cpg]


我姐姐和緋紅也對此事保持沉默，但我想它不能永遠這樣下去。 ......
[cpg]


[window target=false]


[STOPBGM]

[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


全家一起吃過晚飯後，我回到了自己的房間。
[cpg]


這時我把我的母親帶過來和她談。 ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa052"]
[OnName num="sawa"]
'我想知道。你痛苦是因為你想再搗鼓一下嗎？
[cpg cn=true]


媽媽甚至似乎在淡化它。
[cpg]


我，我覺得我看起來很嚴肅。我想知道它是否已經完成？
[cpg]


[OnName num="gorou"]
'我仍然愛你，媽媽。愛你還不夠'。
[cpg cn=true]


盡可能的直接。就像你不關心你的長相一樣。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sawa193"]
[OnName num="sawa"]
'不要.......如果你的父親發現了怎麼辦？ "
[cpg cn=true]


[OnName num="gorou"]
'我會確保他們不會發現的。我保證。 "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sawa194"]
[OnName num="sawa"]
'是的。 ......，我知道。五郎是認真的，不是嗎？ "
[cpg cn=true]


媽媽的反應是，她好像明白了什麼。
[cpg]


她接著說。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa195"]
[OnName num="sawa"]
'你是認真的，對嗎？我們不能結婚，無論如何都不能。 "
[cpg cn=true]



[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSawa053"]
[OnName num="sawa"]
'我想你，而不是我，會被你的感情所約束。你還是可以接受的，不是嗎？
[cpg cn=true]


我點了點頭。我已經受夠了那方面的衝突。
[cpg]


然後我的母親看起來有點煩惱，說。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSawa054"]
[OnName num="sawa"]
'好吧。
[cpg cn=true]


;//ブラックアウト

我媽媽認為她也喜歡我。我仍然不知道這是否是一種浪漫的感覺。
[cpg]


但我對這一點沒有意見。這不是我應該擔心的事情。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSawa055"]
[OnName num="sawa"]
唯一的另一件事是，我不會以...... 吾郎而告終。
[cpg cn=true]


對。如果我連這個都接受，那將是一個好故事。
[cpg]


我很早就已經接受了這個事實。我已經知道這是禁忌之愛。
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





第二天早上。早上從緋紅變成了我的母親。
[cpg]


而對於我的母親，我打算做一些與以前不同的事情。
[cpg]


我告訴她，我是說，......，我想吻她。
[cpg]


[OnName num="gorou"]
我是...... 緊張，我就知道。 "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa199"]
[OnName num="sawa"]
'我可能比五郎更緊張。
[cpg cn=true]


母親說這話時笑了。你看起來並不緊張。
[cpg]



;//移植前シーンカット

;//ブラックアウト

[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

我們變得更接近一點。距離消失了。
[cpg]


我們的嘴唇互相接觸。初吻的感覺被不道德所覆蓋。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『街』（昼）******************************************************



時間過去了。所有的時間，只要有可能，我都和我的母親在一起。
[cpg]



[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d2"]

;//【ＢＧ】『街』（夜）******************************************************


而......，這是值得的，我的體質逐漸平靜了下來。
[cpg]


;//ブラックアウト

[window target=false]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


我深信不疑。我不能以任何方式結婚。
[cpg]


我們甚至不能像正常的戀人那樣行事。但這也沒關係。
[cpg]


我們只是秘密地愛著對方，不管我們走多遠。
[cpg]


而對我母親來說，最重要的人必然是我的父親。
[cpg]


當我看到我的母親若無其事地微笑時，我就是這麼想的。
[cpg]


這是一種無論如何都不會有結果的愛。但我認為它已經走到了盡頭。
[cpg]


;//ブラックアウト


[window target=false]


[STOPBGM]

[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


隨著時間的推移，我的情況繼續得到改善。
[cpg]


我不必再去醫院了。
[cpg]


但你可以說，問題是從這裡開始的。
[cpg]


我想我和我母親之間的愛必須繼續下去。否則，我的體質可能會回來。
[cpg]


然後我將永遠這樣，直到我愛上別人。
[cpg]


我也沒有想到我現在會愛上別的人。
[cpg]


換句話說，結果就像我的...... 母親說的那樣，我將把自己綁在自己身上。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』

[WAIT time=1500]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa217"]
[OnName num="sawa"]
'五郎。我可以和你說句話嗎- ......."
[cpg cn=true]


[OnName num="gorou"]
'怎麼了？你想我了嗎？ "
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa056"]
[OnName num="sawa"]
'嗯。你得說出來'。
[cpg cn=true]


儘管我的體質已經平靜下來，不需要再緊張了，但我的母親寧可嘗試觸摸我。
[cpg]


這是我的錯。我無法拒絕，所以我服從了。
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植前シーンカット

當我和母親在一起時，僅這一點就讓我感到安全。
[cpg]


在這個意義上，我也不能說不。
[cpg]


;//ブラックアウト


[window target=false]


[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="gorou"]
我不會對她說不的。 ...... 我們不能明天改天再談這個問題嗎？如果你呆得太晚，人們可能會認為你很奇怪。 "
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa235"]
[OnName num="sawa"]
'是的，但...... 好。我會耐心等待。 "
[cpg cn=true]


媽媽說這話時似乎真的很喜歡我。
[cpg]


我是如此尷尬、高興和...... 歉意，以至於我無法直視她。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



[OnName num="gorou"]
'好吧，那我就走了。
[cpg cn=true]


我和緋紅一起離開家，向母親問好。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari327"]
[OnName num="himari"]
'...... 嘿，大哥哥。我和我哥哥的關係會發生什麼變化？ "
[cpg cn=true]


[OnName num="gorou"]
你說的'會發生什麼'是什麼意思......？ "
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari094"]
[OnName num="himari"]
'你將成為你母親喜歡的人。我應該叫你爸爸嗎？
[cpg cn=true]


我認為他是在開玩笑。這似乎是無辜的緋紅。
[cpg]



[OnName num="gorou"]
'Ze，永遠不要這樣叫我。 ......
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『歩く』



在這樣的談話之後，我們在城市中漫步。
[cpg]


我們前往學院。我沒有再要求我姐姐為我做任何事情。
[cpg]




[window target=false]


[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="male_student"]
'哦，不，我前幾天終於吻了她。
[cpg cn=true]


[OnName num="gorou"]
'...... 是的。
[cpg cn=true]


他就是那個很久以前為有女朋友而大驚小怪的人。
[cpg]


我想，我妹妹會叫我爸爸或什麼的，我很不能這麼說。
[cpg]




[window target=false]


[STOPBGM]

[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（夕方）******************************************************


還有一次。我是被一個與我沒有特別關係的女學生叫來的。
[cpg]



[OnName num="female_student"]
'...... 小坂君，你有女朋友嗎？
[cpg cn=true]


[OnName num="gorou"]
'為什麼不呢？她是...... 嗯，......"
[cpg cn=true]


一個可能對我有好感的女孩。當然，我都是為了我的媽媽。
[cpg]


但我甚至不能說我有一個女朋友。而且她不是我的妻子。
[cpg]


[OnName num="gorou"]
我不知道是否有我喜歡的人......."
[cpg cn=true]


[OnName num="female_student"]
'我明白了。對'。
[cpg cn=true]


最後的措辭是這樣的。我不知道，也許我可以和她約會。
[cpg]


但我所擁有的是我的母親。我選擇了她，而不是我姐姐或緋紅。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『歩く』



我們又步行回家，一吃完晚飯，就到了晚上。
[cpg]


我這樣說聽起來很無味，但有一件事已經改變了很多。
[cpg]



[window target=false]


[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


那就是我母親在晚上來找我。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSawa057"]
[OnName num="sawa"]
...... 吾郎。 "
[cpg cn=true]


他們叫我的方式和以前一樣，但我還是很高興。
[cpg]


我想更多地靠近你。這就是我的想法。
[cpg]


;//＠それから何度か交わった後、俺達は別れた。



然後每個早晨都會到來。
[cpg]


[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我確信，你是唯一能在我身邊的人。我想知道我母親的情況。
[cpg]


我不知道我母親的情況，但我不知道我是否愛上了我父親。
[cpg]


但這是一種無法以任何方式實現的愛。我們不可能成為戀人。 ......
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）

[BG f="b_01_1.ui" time=1000]
[WAIT time=1000]

我吃完早餐，走出前門。向向日葵的相反方向前進。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari329"]
[OnName num="himari"]
'回頭見，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'哦。到時見'。
[cpg cn=true]

[free time=1000]

;//【ＢＧ】『街』（朝）


我在一種昏迷中度過了我的日子。
[cpg]


不是女朋友或情人，但絕對是我愛的人。
[cpg]


這是最幸福但不尋常的幸福。
[cpg]



[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_02_1.ui" time=1000]

[WAIT time=2000]

[BG f="b_02_2.ui" time=1000]

[WAIT time=2000]


[BGM f="bg_d2"]
[BG f="b_02_3.ui" time=1000]

[WAIT time=1000]


然後我去了學院，上課，放學。
[cpg]

;//【ＢＧ】『学園教室』（夕方）


[OnName num="female_student"]
'......Kasaka-kun。哦，你知道，......."
[cpg cn=true]


[OnName num="gorou"]
...... 什麼？ "
[cpg cn=true]


有一天的女學生。是她問我是否喜歡某人。
[cpg]


[OnName num="female_student"]
'我喜歡小坂君。那......，你想和我出去嗎？
[cpg cn=true]


我遇到了麻煩。也許我可以在這裡轉移到一個體面的生活。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



最後，我帶著待定的答案離開了。
[cpg]


我不能馬上給你一個答案。我不能和她出去，直到我和我媽媽的關係結束。
[cpg]


考慮到這一點，我走回了我的房子。 ......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="gorou"]
'......，這就是所發生的事情。媽媽。 "
[cpg cn=true]


我按照學院的情況講述了這個故事。然後媽媽說。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa252"]
[OnName num="sawa"]
'你可以和他們一起出去，不是嗎？我不會阻止你。 "
[cpg cn=true]


[OnName num="gorou"]
為什麼......，我喜歡你？ "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa253"]
[OnName num="sawa"]
'我很清楚這一點。但你甚至不能讓我在你的餘生中做你的女朋友'。
[cpg cn=true]


...... 這可能確實是事實。
[cpg]


我不知道如果發生這種情況，我爸爸會怎麼樣。
[cpg]


媽媽也可以愛爸爸。
[cpg]


[OnName num="gorou"]
'...... 了解。我會考慮的。 "
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************


然後我忍住不回應那個在學校向我表白的女孩。
[cpg]


我們繼續保持著不太相愛的關係，開始是朋友。
[cpg]


她似乎真的很喜歡我，而且似乎覺得這很令人沮喪。
[cpg]


但我就是我，我從未失去對我母親的愛。
[cpg]


我不覺得我可以適當地愛這個剛剛向我表白的女孩。
[cpg]



;//ブラックアウト



;//========================================
;//●ＣＧ（主人公に膝枕するヒロイン）ev_44
;//人物１：ヒロイン３
;//服装１：私服
;//場所　：主人公の家＿リビング
;//時間　：昼
;//備考　：妊娠していない状態に変えてください
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』


[BGM f="bg_h1"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]



儘管這些曖昧的日子，我還是很開心。
[cpg]


無論我過什麼樣的生活，我的母親都會支持我。
[cpg]


我覺得這就是我需要的一切。我很有成就感。
[cpg]


[VOICE f="sSawa058"]
[OnName num="sawa"]
'...... 你後悔嗎？五郎。 "
[cpg cn=true]


但他看起來肯定只是有點失落。媽媽開始擔心了。
[cpg]


[OnName num="gorou"]
'不可能。不可能的'。
[cpg cn=true]


這些話自然而然就說出來了。我想這是因為我是真心的。
[cpg]


這不僅僅是一個口號。我完全沒有遺憾。
[cpg]


;**【ＣＧ】 ev_44_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa059"]
[OnName num="sawa"]
'我很好，我不在乎我和誰相愛。你喜歡我安撫你的體質，這才是最重要的。
[cpg cn=true]


他說了一句話，讓我有點難過。他說他現在不能回去了。
[cpg]


[OnName num="gorou"]
'那是不可能的事。我真的愛上了你，我的體質已經穩定下來了'。
[cpg cn=true]


相反，我的體質已經穩定下來的事實證明，我喜歡我的母親。
[cpg]


在確定爸爸、姐姐和緋紅已經離開後，我說。
[cpg]


[OnName num="gorou"]
'我愛你，.......蘇納赫恩"。
[cpg cn=true]


我突然叫她的名字，但我母親不會感到沮喪。
[cpg]


;//;**【ＣＧ】 ev_44_b ***********************
;//[CG id=18 index=2 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="sSawa060"]
[OnName num="sawa"]
'是的。我也是'。
[cpg cn=true]


我喜歡這種關係。我想一直呆在她身邊。
[cpg]



;//ブラックアウト

我希望它能永遠繼續下去，但我不知道這是否會發生。
[cpg]


也許我的立場會隨著時間的推移而改變，當我工作的時候，我就會想建立一個家庭。
[cpg]


但......，目前還是不錯的。因為我想繼續做我母親的孩子。
[cpg]


[SCENE id=11]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン３ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================
