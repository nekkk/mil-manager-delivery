
*start

;###################################################################
*Ep003|我的耐心已經接近尾聲了。
;###################################################################


[SCENE id=3]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（朝）******************************************************





當你在城裡走動時，它還是不錯的。我是說，這一刻也很難說。
[cpg]


但還不足以讓我感到心慌意亂。我也逐漸習慣了這些石頭。
[cpg]


下一次，我姐姐會幫我做。等到這個時候，我走了。
[cpg]


如果我沒有這樣的短期目標，或者沒有路線圖，我也沒辦法。
[cpg]


當我想到它是永遠持續下去的東西時，我感到很無助。 ......。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（朝）******************************************************


[SE f="se002"]
;//【ＳＥ】『喧噪』


然後我們到達了學院。我想我已經從第一天的搗亂管理中多少平靜下來了。
[cpg]


[OnName num="male_student"]
'你前一陣子看起來有點不舒服，但你最近看起來好多了。這是一種解脫。 "
[cpg cn=true]


[OnName num="gorou"]
'是的，...... 是的，我想這些天情況相當好。
[cpg cn=true]


我知道我周圍的人認為這很奇怪。我在思考這個問題。
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************



上課的時候已經很辛苦了，而且是在中午。
[cpg]


我甚至在吃完飯之前就想去我姐姐那裡，但那樣她可能也吃完飯了。
[cpg]


最後，我終於在午休的後半段去了我姐姐那裡。
[cpg]


我沒有太多的時間，但我還是不能什麼都不做。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune021"]
[OnName num="suzune"]
'......，聽起來很痛苦。

[cpg cn=true]


[OnName num="gorou"]
姐姐......，我已經快死了。 "
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune084"]
[OnName num="suzune"]
'對。我被告知有獲得另一種疾病的風險'。
[cpg cn=true]


她一邊平靜地說話，一邊把我的手拉開。
[cpg]


我想如果她看到這一點會很糟糕，但她把我帶到了學生諮詢室。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_03_2_up.ui" time=1000]
[WAIT time=2000]


如果我不斷地重複這樣做，它一定會升級的。
[cpg]


如果是這樣的話，我最終會不會也親吻我的妹妹？
[cpg]


我想知道我的妹妹對我有什麼看法，等等。
[cpg]


我不認為我想做她不希望我做的事。
[cpg]


或者......，她還會為我即將死去而感到悲傷嗎？
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



我走出學生指導辦公室，確定沒有人在看。
[cpg]


如果有人看到我，他們又會對我說三道四。
[cpg]


我不能一直做這種事。
[cpg]


我需要更有創意一些，......，但我不知道怎麼做。
[cpg]


我在校園裡的整個過程中，都無法忍耐。
[cpg]



[window target=false]

[WAIT time=2000]

[BG f="b_03_3.ui" time=1500]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



同時，現在是放學後。
[cpg]


我試圖回家。現在是我還能設法忍受的時候，.......。
[cpg]


[OnName num="male_student_A"]
'嘿，小坂。讓我們回家休息一下，找點樂子。 "
[cpg cn=true]


[OnName num="male_student_B"]
'你最近不善於社交。怎麼了？ "
[cpg cn=true]


[OnName num="gorou"]
'不，有事情發生。所以，請讓我回家。 ......"
[cpg cn=true]


[OnName num="male_student_A"]
沒有。好了，我們去電玩城吧。 "
[cpg cn=true]


他一開始就是一個好朋友。我確實不能忽視他們。
[cpg]


但是你知道。 ......，我越晚回家就越難。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夜）******************************************************



男孩們就在我旁邊。或者說，我和所有男孩一起玩。
[cpg]


而我卻在尋找一個暗戀的對象。
[cpg]


我周圍的人似乎不知道發生了什麼事，他們以為我感冒了或什麼。
[cpg]


所以我被提前釋放了，但......，還是已經是午夜了。
[cpg]


[OnName num="gorou"]
'哦，......，這很糟糕，這是...... 糟糕。
[cpg cn=true]



我不禁想到了我母親的臉。我想知道爸爸是否已經回來了。
[cpg]


如果我想讓他做一些事情，我需要盡快做。 ......，我回去了，思考。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa080"]
[OnName num="sawa"]
'歡迎回來。你回來晚了。 "
[cpg cn=true]


[OnName num="gorou"]
'對不起......，對不起。 ......
[cpg cn=true]


[OnName num="father"]
'你在哪裡停了下來？快到晚飯時間了。 "
[cpg cn=true]


[OnName num="gorou"]
是的，......，那是......."
[cpg cn=true]


它不是為了告訴你在哪裡停過車而建造的。
[cpg]


但這還不是最糟糕的部分。爸爸的家。
[cpg]


會不會是在他吃晚飯的時候，我必須堅持下去？
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


我的猜測是正確的。主要是因為我父親回來後，我母親不可能為我做什麼。
[cpg]


我心裡充滿了苦澀，這讓緋紅覺得很好笑。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari091"]
[OnName num="himari"]
'嗯，嗯。 '現在大哥哥，你真可愛。你的母親真狡猾'。
[cpg cn=true]


[OnName num="father"]
'......?'
[cpg cn=true]


爸爸顯然不知道我在說什麼。
[cpg]


這很好，但我當時的情況很危急，我無法圍繞它做出適當的決定。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



在最後一分鐘，我母親對我說。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa081"]
[OnName num="sawa"]
我在我的房間裡等你。你可以隨時來'。
[cpg cn=true]


他現在想去......。我是這麼想的，但我不能讓爸爸起疑。
[cpg]



;//ブラックアウト


遠遠超過了我的忍耐極限，我逐漸失去了自己的立足點。
[cpg]


就在那個時候，我去了我母親的地方。
[cpg]


就像我再也無法忍受了。 ......
[cpg]


;//========================================
;//●ＣＧ（主人公に胸を押しつけるヒロイン。主人公の体に少し触れている感じ）ev_14
;//人物１：ヒロイン３
;//服装１：パジャマ
;//人物２：主人公
;//服装２：パジャマ
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa017"]
[OnName num="sawa"]
'你今天一定過得很辛苦。我要給你一個好的依偎'。
[cpg cn=true]


[OnName num="gorou"]
"...... 母親，先生。"
[cpg cn=true]


[VOICE f="sSawa018"]
[OnName num="sawa"]
'這很難。現在一切都好了。 "
[cpg cn=true]


[OnName num="gorou"]
哦，哦，......."
[cpg cn=true]


我感到很欣慰，忍不住要發出有趣的聲音。
[cpg]


[VOICE f="sSawa019"]
[OnName num="sawa"]
'咯咯笑。這對你來說一定很困難。
[cpg cn=true]


僅僅通過觸摸她，我就能感覺到我大腦中的一些東西。
[cpg]


我不禁知道，這一定是我現在需要的東西。
[cpg]


我很激動，但也鬆了一口氣。這是一種奇怪的感覺，我已經失去了表情。
[cpg]


;**【ＣＧ】 ev_14_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa020"]
[OnName num="sawa"]
'我怎麼能讓你激動呢？
[cpg cn=true]


他一邊說一邊輕輕地撫摸著我的身體。我覺得我無法忍受它。
[cpg]


[OnName num="gorou"]
'我已經夠緊張了。
[cpg cn=true]


[VOICE f="sSawa021"]
[OnName num="sawa"]
'是的。很好'。
[cpg cn=true]


我覺得我似乎想擁抱她，但我忍住了。
[cpg]


[VOICE f="sSawa022"]
[OnName num="sawa"]
'你的脈搏變得非常快。我可以感覺到它。
[cpg cn=true]


緊張是很自然的。有些人說，如果你接近這樣一個美麗的人，你.......
[cpg]


還有來自一個地方的重擊，比如說如果我爸爸發現了會怎麼樣。
[cpg]


我知道光是有這些感覺就是個問題。
[cpg]


我知道我這樣做是不道德的，我也知道光有這些感覺是有問題的，但我不能壓制它們。
[cpg]


;**【ＣＧ】 ev_14_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa023"]
[OnName num="sawa"]
你想今天再一起睡嗎？
[cpg cn=true]


媽媽說了一句相當大膽的話。
[cpg]


[OnName num="gorou"]
'嗯，那是...... 確實不好。
[cpg cn=true]


[VOICE f="sSawa024"]
[OnName num="sawa"]
'我很好。只要五郎沒問題就好。
[cpg cn=true]


當你說這樣的話時，我很想這麼做，但我......，忍住了。
[cpg]


如果我父親發現了，他會懷疑發生了什麼。
[cpg]


我父親在某些方面可以說是直言不諱，但仍然是一個糟糕的......。
[cpg]


[OnName num="gorou"]
'......，我還是不行。我今天要回去了。 "
[cpg cn=true]


[VOICE f="sSawa025"]
[OnName num="sawa"]
'是嗎？我這里永遠歡迎你。 "
[cpg cn=true]


當你說這樣的話時，我幾乎是在考慮。
[cpg]


不過，與我姐姐和緋紅不同，我知道我不會在母親的伴侶身上犯任何錯誤。
[cpg]



;//ブラックアウト

帶著遺憾的心情，我離開了母親的房間。
[cpg]


儘管這是我的職責，但他對我來說是一個不可替代的人，我不知道這樣做是否正確。
[cpg]


這不可能是好事。 ......我知道，但我無法停止。
[cpg]






;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』



之後，我就癱軟在我的房間裡。
[cpg]


不管我怎麼覺得自己被折騰得太厲害了，我都無能為力......，靠自己的意志。
[cpg]


這主要是我的體質。但......
[cpg]


我想知道我母親是否也對你有看法。或者，也許她不像我一樣有任何暗戀的對象。
[cpg]


我還想到了這個：......
[cpg]



;//■選択肢
[switch]
[case "我為我的父親感到遺憾。"]
	[swap]
	[jump target="*select02_1"]
[case "如果你對我有想法，我想回應一下。"]
	[swap]
	[jump target="*select02_2"]
[endswitch]

第一，我為我的父親感到遺憾。
二，如果你對我有看法，我想回應。



;//==============================
;//１、父に申し訳ない
*select02_1|我的耐心已經接近極限了。




我為我的父親感到遺憾，不是嗎？我和媽媽是陌生人，但爸爸和媽媽是夫妻。
[cpg]


這並不意味著我們有血緣關係，但......，我仍然認為我做錯了什麼。
[cpg]


我並不是說，如果是緋紅或我的妹妹，我就不會有任何想法。
[cpg]

[jump target="*select02_3"]


;//==============================
;//２、何か思ってくれてるなら応えたい

*select02_2|我的耐心已經接近極限了。



如果我媽媽還在想什麼，我覺得我別無選擇，只能做出回應。
[cpg]


即使是尖酸刻薄的關係，你也不能突然斷絕關係。也許這是相互的。 ......
[cpg]



[stflag Cha3flg = 1]

;//ヒロイン３が候補に



;//==============================

*select02_3|我的耐心已經接近極限了。


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]



[jump storage="ep004.ks" target="*start"]


;/////////////////////////////////////////////////////////////////////
