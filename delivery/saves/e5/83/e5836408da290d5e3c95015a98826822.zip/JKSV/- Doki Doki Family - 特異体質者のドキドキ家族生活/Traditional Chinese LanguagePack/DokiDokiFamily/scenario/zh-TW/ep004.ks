
*start

;###################################################################
*Ep004|思想和誰在一起？
;###################################################################

[SCENE id=4]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[transition target={false} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





早晨。我被一個不怎麼好的夢驚醒。
[cpg]


我夢見我在一個我不知道在哪裡的地方，周圍有我的母親、姐姐和緋紅。
[cpg]


我認為夢到別人是可以的。但我不這樣做，就有點瘋狂了。
[cpg]


想到這裡，我帶著一種無奈的心情走向餐廳。
[cpg]



;//ブラックアウト


[window target=false]



[BG f="b_04_1_up.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="gorou"]
'嘿，緋紅是在......？
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Sawa099"]
[OnName num="sawa"]
'我不知道--我不知道。也許他還在他的房間裡？
[cpg cn=true]


我有麻煩了。 ......，我得往我的方向走？我感覺我正在失去。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Suzune102"]
[OnName num="suzune"]
'好吧，我現在要走了。回頭見。 "
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se000"]
;//【ＳＥ】『ノック』



我敲了敲緋紅的房間，敲了敲它的門。
[cpg]


[VOICE f="Himari092"]
[OnName num="himari"]
'你可以進來了。你是她的哥哥，對嗎？
[cpg cn=true]


[OnName num="gorou"]
"...... 是的。"
[cpg cn=true]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_04_1_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari093"]
[OnName num="himari"]
'我一直想試試那種情況，你哥哥到我房間來，你知道嗎？
[cpg cn=true]


緋紅是無憂無慮的。我們的生命危在旦夕。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari022"]
[OnName num="himari"]
'你看起來很苦惱。你不能沒有我，對嗎？ "
[cpg cn=true]


[OnName num="gorou"]
'你沒有錯。我生病了'。
[cpg cn=true]


緋紅說她病了，她並不高興。
[cpg]


[VOICE f="sHimari023"]
[OnName num="himari"]
'好吧，我不在乎是不是因為我生病了。只要你到我身邊來'。
[cpg cn=true]



說著，緋紅張開雙手。我無法拒絕這個邀請。
[cpg]


;//移植前シーンカット



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（昼）******************************************************





日子就這樣一點點地過去了。
[cpg]


對我來說，這似乎是一個無盡的時間，但顯然只過去了大約一個星期。
[cpg]


而我又去了醫院。然後我發現：......
[cpg]


[window target=false]


[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



這畢竟是一種未知的憲法，是我們已經知道了一段時間的東西，但我已經看到了一個電燈泡的時刻。
[cpg]


這一線生機是我希望我沒有再看到的。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Sawa100"]
[OnName num="sawa"]
'...... 醫生，你說了一些驚人的事情！ '
[cpg cn=true]


[OnName num="gorou"]
'嗯，是的。 ......，我不知道我是否想考慮太多。
[cpg cn=true]


醫生說，這種情況是一種愛上某人的本能過度活躍的狀態。
[cpg]


他解釋說，通過與別人相愛，憲法會平靜下來。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari113"]
[OnName num="himari"]
'這就像你感冒了，它就會消失。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune103"]
[OnName num="suzune"]
'我認為......，這是不同的。
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





回到家裡，回到我的房間，我遇到了麻煩。
[cpg]


愛上某人了嗎？這是個大問題了。
[cpg]


我沒有女朋友。如果我這樣做，就不會發生這種情況。
[cpg]


...... 緋紅和她的妹妹呢？我從來沒有聽說過她有男朋友，也沒有聽說過她有男朋友。
[cpg]


如果我不檢查，這就不好了。這是一個關於未來的故事。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



這就是為什麼我問我姐姐和緋紅。
[cpg]


[OnName num="gorou"]
'...... 你們倆有男朋友嗎？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune104"]
[OnName num="suzune"]
'你突然間怎麼了......，不，想那種事是很誘人的。
[cpg cn=true]


大姐似乎已經猜到了什麼，臉紅了。還有。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune105"]
[OnName num="suzune"]
'不，我不知道。 緋紅也不例外。 "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari024"]
[OnName num="himari"]
'是的。我也是'。
[cpg cn=true]



緋紅在說這句話時笑了。這看起來是一種歡迎，但這是一種歡迎的態度。 ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune106"]
[OnName num="suzune"]
'我很好。如果是為了五郎'。
[cpg cn=true]


她更進一步。 '好，你是什麼意思？你是什麼意思？
[cpg]


[OnName num="gorou"]
'那是...... 誤聽，聽起來很好？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sHimari025"]
[OnName num="himari"]
'只有你姐姐是偷偷摸摸的。我和你在一起'。
[cpg cn=true]


......，我不得不把我的頭從我的屁股裡拿出來。
[cpg]


姑娘們說，這對我來說很好。甚至愛上了我。 ......
[cpg]



;//■選択肢
[switch]
[case "你不能這樣做。"]
	[swap]
	[jump target="*select03_1"]
[case "我可能不得不這樣做。"]
	[swap]
	[jump target="*select03_2"]
[endswitch]
第一，你不能這樣做。
二，我們可能不得不這樣做。



;//==============================
;//１、そんなことはできない
*select03_1|這個想法在每個人的腦海中都有。




我還是做不到。我不能這樣做......
[cpg]


更不用說你的姐姐和緋紅了，你的母親更糟糕。
[cpg]


我帶著這些想法回到了我的房間。
[cpg]


[jump target="*select03_3"]

;//==============================
;//２、そうするしかないかもしれない

*select03_2|思想是給大家的。



但你不能永遠這樣生活下去，對嗎？
[cpg]


也許有一天我會和其他人在一起。 ......
[cpg]


帶著這些想法，我離開了這個地方。
[cpg]

[stflag Cha1flg = 1]

;//後の選択肢で選択肢４が候補に



;//==============================

*select03_3|思想與誰同在


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





幾天的通行證。在你知道之前，這又是一個工作日。
[cpg]




[window target=false]

[STOPBGM]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





從那時起，我必須定期提高我的心率。
[cpg]


那段日子是如此痛苦，以至於我終於想到要治好病情本身。
[cpg]


然而，我想不出有誰能與之相愛。
[cpg]


班上有一些女孩和我相處得很好，但當我想到我是否喜歡她們時，我想不出有誰......。
[cpg]


不，更重要的是，讓我們撇開你是否愛上某人不談：......
[cpg]


我至少要和一個人談起這個問題才會感到舒服。
[cpg]


我想，如果我要談戀愛，真的，假想一下，會是誰呢？
[cpg]



[if exp={getFlagValue("Cha1flg") == 0 }]
[endif]

[if exp={getFlagValue("Cha2flg") == 0 }]
[endif]

[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*select04_1"]
[endif]
//////////////////////////////////////////

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*C2"]
[endif]

[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*Out2C3"]
[endif]


[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "紀曉嵐"]
	[swap]
	[jump target="*select04_1"]
[case "我無法選擇。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]


[jump target="*select04_1"]
//////////////////////////////////////////
*Out2C3|誰對誰有感情？

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "居順"]
	[swap]
	[jump target="*select04_1"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[case "我無法選擇。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "紀曉嵐"]
	[swap]
	[jump target="*select04_1"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[endswitch]

//////////////////////////////////////////
*C2|你在想誰？
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*C2C3"]
[endif]

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "紀曉嵐"]
	[swap]
	[jump target="*select04_1"]
[case "太陽雨"]
	[swap]
	[jump target="*select04_2"]
[case "我無法選擇。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "壽命說明"]
	[swap]
	[jump target="*select04_1"]
[case "陽光"]
	[swap]
	[jump target="*select04_2"]
[endswitch]

//////////////////////////////////////////
*C2C3|誰在你心中

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "壽命說明"]
	[swap]
	[jump target="*select04_1"]
[case "陽光"]
	[swap]
	[jump target="*select04_2"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[case "我無法選擇。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "紀曉嵐"]
	[swap]
	[jump target="*select04_1"]
[case "太陽雨"]
	[swap]
	[jump target="*select04_2"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[endswitch]








;//■選択肢
[switch]
[case "慶祝長壽"]
	[swap]
	[jump target="*select04_1"]
[case "太陽雨"]
	[swap]
	[jump target="*select04_2"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[case "不能選擇"]
	[swap]
	[jump target="*select04_4"]
[endswitch]

1、鈴音。
2, 緋紅
3，蘇納
4、不能選擇。



;//ここまでの選択で候補になっている選択肢から選択
;//ただし、候補がヒロイン１のみの場合選択肢は発生せずそのまま進行


*select04_1|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[jump storage="ep005.ks" target="*start"]


*select04_2|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[jump storage="ep006.ks" target="*start"]



*select04_3|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[jump storage="ep007.ks" target="*start"]


*select04_4|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[jump storage="ep008.ks" target="*start"]


;//==============================
