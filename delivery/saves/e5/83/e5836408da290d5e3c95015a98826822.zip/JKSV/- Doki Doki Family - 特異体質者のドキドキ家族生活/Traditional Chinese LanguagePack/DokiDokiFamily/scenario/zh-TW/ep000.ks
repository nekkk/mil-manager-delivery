
*start
;//あねいもままの射精管理　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//寿々音　裸　私服　スーツ
;//ひまり　裸　私服　制服
;//砂羽　　裸　私服

;//以下音声なし
;//吾郎 父親 男子学生Ａ 男子学生Ｂ
;//医者 女子学生 女子学生Ａ 女子学生Ｂ 男子学生
;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//寿々音　一人称「私」　ひまり呼び「ひまり」　砂羽呼び「お母さん」　吾郎呼び「吾郎」
;//ひまり　一人称「私」　寿々音呼び「お姉ちゃん」　砂羽呼び「お母さん」　吾郎呼び「お兄ちゃん」
;//砂羽　一人称「私」　寿々音呼び「寿々音」　ひまり呼び「ひまり」　吾郎呼び「吾郎」
;//吾郎　一人称「俺」　寿々音呼び「姉さん」　ひまり呼び「ひまり」　砂羽呼び「母さん」


;###################################################################
*Ep000|神秘的憲法。
;###################################################################

[SCENE id=0]


[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[stflag jump_scene=1]


;///////////////////////////ここからが本編です///////////////////////////



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_me"]
;//ブラックアウト





當我還很年輕的時候。
[cpg]


我的媽媽和爸爸在一次事故中去世。我當時還是個孩子，所以我並不真正知道發生了什麼事。
[cpg]


我記得我也在哭，因為我周圍的人都在哭，這讓我莫名地害怕。
[cpg]


我認為失去父母的真正悲痛是在更遠的地方。
[cpg]


我的一個遠房親戚薩瓦-高坂也參加了葬禮。她現在是我的母親，我的岳母。
[cpg]


我想這也是我第一次見到我的嫂子，鈴音。
[cpg]



;//下記寿々音のセリフは子供の頃の声です






[VOICE f="Suzune001"]
[OnName num="suzune"]
...... 不要哭。你在天堂的母親和父親也會哭泣。
[cpg cn=true]


我想我當時甚至沒有理解他的大部分意思。
[cpg]


我想我姐姐當時是出於好意。
[cpg]


她甚至在忍耐即將到來的淚水。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我的家庭包括我的母親和父親，我的姐姐鈴音和我的妹妹緋紅。而我是被收養的，所以我們有五個人。
[cpg]


沒有一個人與我有血緣關係。我想我與他們有一點關係，但我與緋紅和她的妹妹的關係比我與我的堂兄弟姐妹的關係更遠。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari001"]
[OnName num="himari"]
'哦，我不想去學校。 ......，這是五月的病，不是嗎？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune002"]
[OnName num="suzune"]
'現在已經是六月了。別傻了'。
[cpg cn=true]


緋紅和她的妹妹正在進行這樣的對話。我也有點呆滯。
[cpg]


[OnName num="gorou"]
'我知道這是低氣壓的影響，這......'
[cpg cn=true]

[free time=1000]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa001"]
[OnName num="sawa"]
'咯咯笑。 '但他們說低壓對你有好處！ '
[cpg cn=true]


[OnName num="gorou"]
'真的......？我從來沒有聽說過。 "
[cpg cn=true]


[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune003"]
[OnName num="suzune"]
'我也聽說了。你知道，壽命長的地方氣壓都很低'。
[cpg cn=true]


我不知道。不過我有點懶。
[cpg]


[OnName num="gorou"]
"懶惰會增加你的預期壽命還是......？"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari002"]
[OnName num="himari"]
'那我就會活得更久，因為我每天都很懶惰。嘆氣，我不想去'。
[cpg cn=true]


爸爸已經在工作了，我們卻在進行這種愚蠢的談話。
[cpg]


沒有什麼成果，如果有的話，只是獲得一點瑣事。 ......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************





我姐姐是我所在學校的老師。
[cpg]


所以她當然比我更早離開家。問題是我和緋紅。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Himari003"]
[OnName num="himari"]
'......，我們不是有六月病嗎？我想就是這樣了。 "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa002"]
[OnName num="sawa"]
'我不知道。即使有，我也不認為緋紅會有什麼不同。 "
[cpg cn=true]


[OnName num="gorou"]
'對。它太慢性了，不可能是一種疾病，你知道。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Himari004"]
[OnName num="himari"]
我不知道這是否符合憲法。 ......
[cpg cn=true]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]

[window target=true]


憲法》。是的，這是一個關於憲法的故事。
[cpg]


我過去是，現在仍然是，受到某種體質的影響。
[cpg]




;//ブラックアウト


[window target=false]




[BG f="b_01_1.ui" time=1000]
[WAIT time=1500]


[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





我一邊想，一邊走在與緋紅不同的路上。
[cpg]


有許多方法可以用一個詞來表達憲法。早上難以醒來，對酒精的高度容忍和憤怒也是構成因素。
[cpg]


在這樣的情況下，我已經形成了一種"搗蛋的依賴"。
[cpg]


我最喜歡的漫畫是一部浪漫的喜劇。我最喜歡的動畫片也是一部愛情喜劇。我最喜歡的音樂是偶像們唱的情歌。
[cpg]


這很令人尷尬，但我不能沒有這種東西。 ......
[cpg]


我渴望得到一種叫做"搗蛋"的東西。我甚至不知道我怎麼會變成這樣。
[cpg]


[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[WAIT time=2000]

;//========================================
;//●ＣＧ非エロ（授業をするヒロイン１。黒板に背を向けて本を手に持っている）ev_01
;//人物１：ヒロイン１
;//服装１：スーツ
;//場所　：学園教室
;//時間　：昼
;//========================================


[WAIT time=1000]
[BGM f="bg_d2"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]






[VOICE f="Suzune004"]
[OnName num="suzune"]
'嗯，在這裡很容易出錯......，像這樣......'。
[cpg cn=true]


上午的最後一堂課是我姐姐的。
[cpg]

當她面對黑板時，她很有趣，很聰明。
[cpg]


說實話，她在男孩中相當受歡迎，至少可以這麼說。
[cpg]


[OnName num="male_student_A"]
'...... 小坂老師很漂亮，不是嗎？
[cpg cn=true]


[OnName num="male_student_B"]
'哦......，你太有風格了，那個人。
[cpg cn=true]


但是，儘管她是我的嫂子，當人們這樣稱呼我的家人時，我覺得有點不舒服。
[cpg]


我當然也姓小坂，所以人們問我各種各樣的問題，但我假裝不知道。
[cpg]


如果他們知道我是我妹妹，我就會有大麻煩。
[cpg]


我可以看到，我將被不必要的嫉妒和奇怪的接近所困擾，所以我不告訴他們。 ......。
[cpg]


[OnName num="male_student_A"]
'這些乳房是一種致命的武器。我不知道他們吃什麼才能長成這樣。 ......"
[cpg cn=true]


我也知道，但我沒有說。
[cpg]


;**【ＣＧ】 ev_01_a ***********************
[CG id=0 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Suzune005"]
[OnName num="suzune"]
'嘿，那裡。你應該避免和我說話。 "
[cpg cn=true]


[OnName num="male_student_A"]
'......'
[cpg cn=true]

我的意思是，她說的正是她的妹妹，她可能已經註意到了這一點。


儘管如此，我認為她不動聲色是很好的。
[cpg]


如果你只看她現在的樣子，你會看到她是一個堅實的人。 ......
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[window target=true]


對。她在學校表現得相當穩重，但我知道她有點不在狀態。
[cpg]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『学園教室』（昼）******************************************************





她經常忘記事情。她在當老師時很少犯錯，但在家裡卻相當粗心。
[cpg]


在幫助做飯的時候，她把鹽當成糖是常有的事。
[cpg]


我來到這所學校，因為它是留給我唯一可以滑倒的地方。
[cpg]


對我來說，與我妹妹在同一所學校是很尷尬的。但我再也忍不住了。
[cpg]


我做不起浪人，我在這裡是因為......，我在這裡。
[cpg]


順便說一下，緋紅是一個比較聰明的人。與我相反的是，她是那種看起來不合群但卻能出人意料地做事的人。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************





而與這些情況完全無關的是，我當時遇到了危機。
[cpg]


即使在學校，我對"Doki-Doki "的依賴也沒有減少。
[cpg]


然而，我不能在學校傳播漫畫，所以我用手機聽音樂。
[cpg]


太甜太酸的情歌。儘管這是一首偶像歌曲，但它是現在連學生都不聽的那種東西。
[cpg]


我怎麼會變成這樣？ ......，我是這麼想的，但我對自己是瘋子這一事實無能為力。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************





最重要的是，你不能只是去學校，並期望獲得良好的教育。
[cpg]


我在路上沒有和緋紅碰面。這是與她相反的方向。
[cpg]


[SE f="se003"]
;//【ＳＥ】『ドア開く』

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[OnName num="gorou"]
我回來了。 "
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（主人公に笑顔で抱きつくヒロイン。胸を腕に押し当てている）ev_02
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の家＿玄関
;//時間　：夕方
;//========================================


[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


我一回到家，喜瑪莉就找上我。
[cpg]


[VOICE f="Himari005"]
[OnName num="himari"]
'歡迎回家，大哥哥！
[cpg cn=true]

;//＠
;//彼女は私服に着替えていて、もうとっくに家に戻っていたようだった。


他拍拍屁股走到門口，擁抱了我。
[cpg]


[OnName num="gorou"]
'阿志，你太近了......，都快打到我了。
[cpg cn=true]


;//;**【ＣＧ】 ev_02_a ***********************
;//[CG id=1 index=1 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="Himari006"]
[OnName num="himari"]
你太調皮了。你在用這種方式看我妹妹嗎？ "
[cpg cn=true]


[OnName num="gorou"]
...... 沒什麼。 "
[cpg cn=true]


我很激動，感覺到一些我無法偽造的東西。
[cpg]


[OnName num="gorou"]
我的意思是，緋紅有五月的藍調，對嗎？你看起來已經很好了。 "
[cpg cn=true]


;//;**【ＣＧ】 ev_02_0 ***********************
;//[CG id=1 index=0 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="Himari007"]
[OnName num="himari"]
'我在晚上感覺更好。我想知道為什麼'。
[cpg cn=true]


緋紅假裝不明白，但我認為她只是有一個脆弱的早晨。
[cpg]


這樣的話語幾乎傳入我的喉嚨，但我沒有說出來。
[cpg]


[OnName num="gorou"]
'現在，離我遠點，......，我需要穿上衣服。
[cpg cn=true]



[VOICE f="Himari008"]
[OnName num="himari"]
'Duh.然後我就看著你換衣服'。
[cpg cn=true]


你在說什麼。看我弟弟穿衣服有什麼樂趣？
[cpg]


[OnName num="gorou"]
'我不認為看到我的裸體是件有趣的事，...... 可憐的東西。
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]

我推開試圖進入我房間的緋紅，然後穿上衣服。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





我只是在我的房間裡閒逛。他說："我是一個很有耐心的人，我希望我的朋友們都能理解我。"他說："我希望我的朋友們都能理解我。
[cpg]


你需要做的第一件事是確保你對你所做的事情有充分的了解。我對這樣的事情感到緊張。
[cpg]


我想我的心臟正在遭受某種疾病的折磨。或者頭部。
[cpg]



[window target=false]



[BG f="b_06_4.ui" time=1500]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





之後，我在網上查了查這個，那個。被禁止的部分，或者說是我長期以來一直迴避的部分。
[cpg]


是否有愛的依賴這一回事。實際上，我更依賴刺激本身，而不是愛情。 ......
[cpg]


不是說沒有，顯然。但他們說這在已經和別人有關係的女性中更常見。
[cpg]


我沒有女朋友，我是個男人，......，最近甚至感覺我必須要緊張才能呼吸。
[cpg]


也許我應該偷偷溜去醫院。我會這樣做的。
[cpg]


[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ非エロ（ヒロインが料理をしている。手伝う主人公。主人公が横にいてヒロインは味見してる感じ）ev_03
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の家＿ダイニングキッチン
;//時間　：夜
;//========================================

[WAIT time=1000]

[SE f="se006"]
;//【ＳＥ】『料理』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]




當我走到廚房時，我母親正在準備晚餐。
[cpg]

[OnName num="gorou"]
'我也要做什麼嗎？媽媽。 "
[cpg cn=true]


[VOICE f="Sawa003"]
[OnName num="sawa"]
'哦，你要幫我？謝謝你！ "
[cpg cn=true]



有時我姐姐會幫忙做飯，但我沒有看到她。
[cpg]


[OnName num="gorou"]
你妹妹在哪裡？ "
[cpg cn=true]



[VOICE f="Sawa004"]
[OnName num="sawa"]
'你已經在你的房間裡下去了!她一定也很難受。 "
[cpg cn=true]


我相信你是對的。當她鬆懈時，她鬆懈到了極限。
[cpg]


從這個角度來看，他並不是一個完全穩固的人。
[cpg]


;**【ＣＧ】 ev_03_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Himari009"]
[OnName num="himari"]
祝你好運，你們兩個。
[cpg cn=true]


緋紅的聲音從後面傳來。
[cpg]


我認為這傢伙可以幫助做家務，但他沒有。
[cpg]


他是否像他姐姐那樣懶惰？
[cpg]


緋紅是如此懶惰，以至於她無法關閉。
[cpg]


...... 仔細想想，我的母親是最靠譜的一個嗎？真是不費吹灰之力。
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





這就是為什麼我們都在這裡。當然，爸爸在那裡吃飯。
[cpg]


[OnName num="father"]
'......，這是怎麼回事。五郎，什麼事困擾著你？ "
[cpg cn=true]


[OnName num="gorou"]
'不，謝謝你。我很好。 "
[cpg cn=true]


我看起來很陰沉嗎？好吧，我可以看起來很陰沉嗎？
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Sawa005"]
[OnName num="sawa"]
'我也很擔心。你最近一直表現得很奇怪，很害怕。
[cpg cn=true]


我在努力不讓他們看到我的恐懼。 ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune006"]
[OnName num="suzune"]
'五郎以前受過驚嚇，是嗎？在學院裡更是如此。 "
[cpg cn=true]


你是這樣看的嗎？我有點震驚了。
[cpg]




;//ブラックアウト


[window target=false]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[STOPBGM]
[WAIT time=1000]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************





第二天休息。我正在去醫院的路上。
[cpg]


我仍然有一種想要一直悸動的感覺。我想這只是我的體質。 ......
[cpg]


就這一點而言，我想知道我的身體發生了什麼。
[cpg]


;//ブラックアウト


[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]


[SE f="se003"]
;//【ＳＥ】『ドア開く』

[WAIT time=1000]


所以我在一家小醫院進行了檢查。 ......。
[cpg]


[OnName num="doctor"]
'這是......，發生了什麼事。我不明白。 ......"
[cpg cn=true]


顯然，我的身體正在發生一些奇怪的事情。
[cpg]


他們把我轉到一家更大的醫院，我顯然不得不向家人傾訴。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿玄関』（昼）******************************************************





[OnName num="gorou"]
我回來了。 ......
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa006"]
[OnName num="sawa"]
'歡迎回來。怎麼了，你不是出去購物了嗎？
[cpg cn=true]


[OnName num="gorou"]
我想要的那款產品已經賣完了，.......。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa007"]
[OnName num="sawa"]
'哦，是的。那太糟糕了。 ...... 那是什麼？ "
[cpg cn=true]


[OnName num="gorou"]
啊！ "
[cpg cn=true]


一封介紹信從袋子裡掉了出來。我愣了一下。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[OnName num="father"]
'...... ill?你能單獨去諮詢這個問題，已經很不錯了'。
[cpg cn=true]


[OnName num="gorou"]
'不，我是說，哈哈......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune007"]
[OnName num="suzune"]
'我也很好奇。你有什麼症狀？
[cpg cn=true]


[OnName num="gorou"]
'嘿，我能說什麼呢......，這有點像感冒。
[cpg cn=true]


苦難。我很痛苦。隨著時間的推移，這一切都會變得清晰。
[cpg]


甚至緋紅和她的母親也在做神秘的表情。緋紅的表情是這樣的，我一定讓她擔心了。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夕方）******************************************************





所以我立即前往我被轉診的醫院。我的家人和我一起來到這裡。
[cpg]


從那以後，就很艱難了。他們說我需要進行全面檢查或其他什麼。
[cpg]


據說這是一種罕見的疾病，只影響到數百萬人中的一個，甚至更少。
[cpg]


我很不解，但還是照他們說的做了，解釋說有可能會陷入嚴重的狀況。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





那晚的晚餐很尷尬。
[cpg]


吃飯時還可以，但飯後的家庭會議，或......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa008"]
[OnName num="sawa"]
'......，運氣不好。這就是為什麼你獨自在醫院裡。
[cpg cn=true]


在這一點上，我開始想，我至少可以和我父親談談這個問題。
[cpg]


套用一句話，他的體質使他難以呼吸，除非定期提高心率。這已經隨著年齡的增長而表現出來。
[cpg]


簡而言之，如果你不提高你的心率，最壞的情況是你會誘發其他疾病。
[cpg]


他們威脅我說有可能陷入危急狀態，我就頭疼了。也許我的家人也會。
[cpg]

[free time=800]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sSuzune001"]
[OnName num="suzune"]
'你為什麼不獨自去......，看浪漫漫畫或其他什麼。這可能會有幫助。 "
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="sHimari001"]
[OnName num="himari"]
'不! 如果我不能為此感到興奮，我就會死。
[cpg cn=true]


死亡是一種誇張的說法，但它不是謊言。
[cpg]


畢竟，這是一種未知的疾病，任何事情都可能發生。
[cpg]


[OnName num="father"]
'嗯，這很好。五郎會自己處理好的，太過擔心是不好的。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari011"]
[OnName num="himari"]
'我不知道.........，我對它如此焦慮。
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（昼）******************************************************





我們這樣一談，就同意暫時由我來做自我評判。
[cpg]


日子就這樣一天天過去了。我想知道這樣做是否正確，但沒有別的辦法。
[cpg]


......在這一切之中。
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



一個早晨。爸爸去上班後，舉行了一次家庭會議。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune002"]
[OnName num="suzune"]
'我想，你不是對我們有好感嗎？
[cpg cn=true]



[OnName num="gorou"]
'嘿，你在說什麼？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune003"]
[OnName num="suzune"]
'你是什麼意思，你一定很激動？我和五郎甚至沒有血緣關係'。
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSawa001"]
[OnName num="sawa"]
'是的，沒錯。我知道我也是如此。
[cpg cn=true]


甚至我的母親也會加入進來，談論這些話題。不過，這很好。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSuzune004"]
[OnName num="suzune"]
幸運的是，你白天也和我一起去學校。 ......
[cpg cn=true]


[VOICE f="sSuzune005"]
[OnName num="suzune"]
'如果你有一天有了悸動的衝動，而且變得太硬，你可以指望我們。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="3/3" time=800]
[VOICE f="sHimari002"]
[OnName num="himari"]
'你又不能依靠我！ '這是不可能的。你必須積極主動地與他們調情。 "
[cpg cn=true]


緋紅這麼說，但她不是在開玩笑。
[cpg]

[OnName num="gorou"]
'我不想這樣，我拒絕這樣！ '。我絕對討厭它。 "
[cpg cn=true]

[SE f=se010]
;//【ＳＥ】『走る』
[free time=1000]
[WAIT time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Suzune013"]
[OnName num="suzune"]
'哦，緋紅！別讓他跑了，把他按住。 "
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Himari013"]
[OnName num="himari"]
'我知道! 大哥，你想逃跑是沒有意義的。 "
[cpg cn=true]




[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[WAIT time=2000]
;//ブラックアウト



就這樣。
[cpg]


我受到了我的姐姐、妹妹和母親的所謂'搗蛋管理'。 ......
[cpg]



[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（朝）******************************************************



然後，在了解了我的體質後，我感到有一種額外的慾望，想讓自己激動起來。
[cpg]


我想感到興奮。如果我不碾壓，我就會死。這是一部多麼困難的憲法。
[cpg]


但我不能在上課時聽音樂，上午的課程結束後，我感到很暈眩。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************


當我失去意識時，我的姐姐幫助我。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune014"]
[OnName num="suzune"]
她說：'我想知道我應該去哪裡，.......我知道這將是學生指導辦公室。 ......
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune015"]
[OnName num="suzune"]
'但你也不應該過多地使用它。你怎麼看？
[cpg cn=true]


我只能回答說我不知道。但最後，他們把我帶到了學生諮詢室。
[cpg]


我已經在掙扎著呼吸了，我不能再忍受了。
[cpg]


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

;//ブラックアウト


最後，我和我妹妹單獨在一個封閉的房間裡，沒有人可以看到我。
[cpg]


[VOICE f="sSuzune006"]
[OnName num="suzune"]
'別誤會，我不能為你做那麼多。
[cpg cn=true]


說著說著，姐姐就把手放在了我的胸前。
[cpg]


[OnName num="gorou"]
'Ugh. ......'
[cpg cn=true]


這並不是說我從來沒有意識到我妹妹是個女人。
[cpg]


當她離我如此之近時，我無法停止...... 扑騰。
[cpg]


那是一段無法形容的舒適時光。一個奇怪的時期，我感到緊張，但同時又很自在。
[cpg]

;//移植前シーンカット


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



[OnName num="gorou"]
'......，你每天都堅持這樣做嗎？
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune033"]
[OnName num="suzune"]
'這不是我的錯，是嗎？這更是你的錯。 "
[cpg cn=true]


他從學生指導辦公室出來時這樣說。
[cpg]


一般來說，這是一個相當糟糕的場景。
[cpg]


學生們可能不知道，但老師們知道我和我妹妹是姐妹和兄弟。
[cpg]




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（夕方）******************************************************


在這種事情發生時，時間就會流逝。
[cpg]


儘管從中午到現在沒過多少時間，但我已經接近我的極限了。
[cpg]


如果我不被重擊，我就會得另一種病，我明白了，我想是這樣。 ......
[cpg]


我在掙扎著呼吸，好像在這之前我就要瘋掉了。
[cpg]


[OnName num="female_student"]
'怎麼了？小坂君，你的行為很奇怪。 "
[cpg cn=true]


[OnName num="gorou"]
'爸，我很好。這不算什麼'。
[cpg cn=true]


不可能什麼都沒有，但我決定回答這個問題。
[cpg]


我不能再這樣做了。當我看著女孩們的臉時，這就更難了。
[cpg]


這是一種來自我的體質的痛苦，我的體質顯然與正常男孩的體質不同。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





而我正試圖回到家裡。
[cpg]


我不禁發現街上的所有女人都很有吸引力。這是不正常的。
[cpg]


但我無法單獨控制我的感覺。
[cpg]


受控"這個詞太冷淡了。我正在被折磨，而不是被控制。
[cpg]


我回家的感覺是這樣的。 ......
[cpg]


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[SE f="se003"]
;//【ＳＥ】『ドア開く』
[WAIT time=1000]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa010"]
[OnName num="sawa"]
'歡迎回來。你看起來很痛苦，戈羅。 "
[cpg cn=true]


爸爸離開前的時間。
[cpg]


我想做點什麼，我打算跪下來，向我媽媽求助。
[cpg]


這就是我的真實感受。我無法忍受這一點。
[cpg]


我不想忍受它。我緊緊抓住母親。
[cpg]


[OnName num="gorou"]
我很高興見到她，我也很高興見到她。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa011"]
[OnName num="sawa"]
'咯咯笑。 '對--你這樣看著我，我什麼也做不了。
[cpg cn=true]


這是在爸爸回來之前呢。我希望他能做一些事情。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト



[BG f="b_04_3_up.ui" time=1000]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7" time=1000]
[WAIT time=2000]


我被帶到了我媽媽的房間。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa002"]
[OnName num="sawa"]
'好吧，那我要給你一個擁抱了。
[cpg cn=true]


[OnName num="gorou"]
'是的，你確定嗎......？
[cpg cn=true]




[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa013"]
[OnName num="sawa"]
'沒關係的。看到我的兒子處於痛苦之中，我很痛心'。
[cpg cn=true]


這樣的話語引誘我到......
[cpg]

;//移植前シーンカット

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]


在母親的懷抱中，我的眼淚都快流出來了。
[cpg]


這與興奮的感覺有點不同。
[cpg]


但就解脫而言，我可能比和我妹妹在一起時更解脫。
[cpg]


這就是我母親連我的焦慮都籠罩的程度。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[OnName num="father"]
......
[cpg cn=true]


[OnName num="gorou"]
"......"
[cpg cn=true]


晚餐時，我和爸爸都沉默不語。我認為有些事情，男人可以在某種程度上理解對方。
[cpg]


我是個男人，卻愛上了你，這很令人尷尬，但......。
[cpg]


也許他們多少能理解這種尷尬的感覺。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="Himari014"]
[OnName num="himari"]
'媽媽，把醬油遞給我。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa032"]
[OnName num="sawa"]
'好吧--給你。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune034"]
[OnName num="suzune"]
'你就在它旁邊。自己去拿吧，緋紅'。
[cpg cn=true]


女人進行這樣的對話。這是一件非常、非常隨和的事情。
[cpg]


或者說，他們甚至似乎很興奮。明天他們會不會照顧緋紅呢......？
[cpg]


我仍然不知道我的母親和妹妹的情況。但緋紅是我的妹妹。
[cpg]


對你的妹妹感到緊張是不正常的。
[cpg]


我感到那裡有危險的東西，但我不能說什麼。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





我脫下衣服，換上了睡衣。
[cpg]


在我睡覺的時候，我的症狀並沒有惡化，但這並不能緩解，因為.......。
[cpg]


我深深地嘆了口氣，為即將到來的事情感到擔憂。
[cpg]


真的，會發生什麼......？
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』朝チュン


[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



即使你在考慮要發生什麼，早晨也會正常到來。
[cpg]


我以前睡覺的時候都很好，但今天我夢見我有一個可愛的女朋友。
[cpg]


這是連正常男人都很難醒來的那種夢。
[cpg]


我想找人幫忙，所以我還是去找我姐姐。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[BG f="b_04_1_up.ui" time=1000]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[WAIT time=2000]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune007"]
[OnName num="suzune"]
'什麼？早晨我不負責任。 "
[cpg cn=true]


那是什麼，這樣的輪換已經建立了？
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune036"]
[OnName num="suzune"]
'我把早晨的事情留給了緋紅。所以我希望你去找她。
[cpg cn=true]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari015"]
[OnName num="himari"]
'早上好，大哥哥。你看起來不舒服。
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
不好。他說他的體質本來就很奇怪。
[cpg]


[OnName num="gorou"]
'......, 緋紅......，關於我的體質。
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari003"]
[OnName num="himari"]
'我知道--我知道。那麼？你想讓我做什麼？ "
[cpg cn=true]


他在笑，想讓我告訴他。
[cpg]


看來爸爸已經離家了。我想這就是為什麼Himaru要告訴我這些。 ......
[cpg]


而這並不是一種毫無保留的說法。好吧，只有我、緋紅、我姐姐和我母親知道我們在做什麼。
[cpg]


相反，爸爸是唯一不知道的人。只要我爸爸不在這裡，我說什麼又有什麼關係呢？
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari004"]
[OnName num="himari"]
你曾經和一個女孩牽過手嗎？
[cpg cn=true]


[OnName num="gorou"]
不，我不知道。 "
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari005"]
[OnName num="himari"]
'嗯。那麼如果有人這樣對你，你會感到興奮嗎？
[cpg cn=true]

在她說這句話的時候，緋紅握住了我的手。
[cpg]


然後，將他們的手指交織在一起，成為一種...... 情人的聯繫，或類似的形式。
[cpg]


我變得很緊張。而苦澀的感覺也消失了。
[cpg]


[OnName num="gorou"]
'謝謝你，.......'
[cpg cn=true]

[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari036"]
[OnName num="himari"]
現在你是我的了，大哥哥......ehehe。 "
[cpg cn=true]


緋紅似乎很高興。
[cpg]


緋紅可能也會有佔有欲。
[cpg]


我不知道，但我有一種感覺，她是。 ......。
[cpg]

;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



然後我們吃早餐。姐姐看著我們手拉手，很是不安。
[cpg]


但我知道為什麼會發生這種情況。
[cpg]


早上是緋紅。在下午，或者說在學校，是我妹妹。晚上，我們又有一次與我母親......，我相信。
[cpg]


我昨天和今天發現了這個問題。也許這就是他們一天三次的計算方法。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari037"]
[OnName num="himari"]
'這很好吃。炒蛋看起來不能做'。
[cpg cn=true]


是否有這樣的事情，即不能做炒蛋？就在我這樣想的時候，我妹妹探出頭來。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune037"]
[OnName num="suzune"]
'你只是不想讓他們，你......'。
[cpg cn=true]


緋紅並不覺得她剛才和我牽手。
[cpg]


好像她切換得很快或什麼的。
[cpg]


但她和我單獨在一起時也是這樣嗎？
[cpg]


我不知道。我不知道，但如果你這樣說，我母親也是如此。 ......。
[cpg]


我的姐姐給了我一些"砰"的一聲，但緋紅和我的母親卻沒有那麼多。
[cpg]




;//ブラックアウト


[window target=false]

[STOPBGM]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



在她離開一段時間後，我們也去了學校。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Himari038"]
[OnName num="himari"]
我現在要走了。再見，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'嗯，嗯。那我就走了。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa033"]
[OnName num="sawa"]
'嗯，有一個好的一天。
[cpg cn=true]


這個微笑是什麼意思？不，你的母親看到了一切。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（朝）******************************************************





[OnName num="gorou"]
'哦，......，現在會發生什麼......'。
[cpg cn=true]


我終於對自己說了我想了好幾遍的話。
[cpg]


我不知道如果我不這樣做會發生什麼。
[cpg]


我繼續過著讓家人激動的生活，即使是婆媳關係。
[cpg]


那麼我就不能把我的媽媽、姐姐和緋紅看成只是家人。
[cpg]


我在痛苦中去了學院。
[cpg]





[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="ep001.ks" target="*start"]


;/////////////////////////////////////////////////////////////////////
