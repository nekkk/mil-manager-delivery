

;//３、凪
*select03_3|放っておけない凪



やはり、凪をこのまま泊めておこうと思った。
[cpg]

一番危なっかしいと言えば危なっかしい。晶菜なんかは、放っておいてもなんとでもなりそうだ。
[cpg]

だが、凪は知識の偏りが激しい。妙な大人に騙される可能性だってある。
[cpg]

そう考えると、やはり一番放っておけない。俺は彼女を家に泊めることにした。
[cpg]

*start

;#################################################
*Ep010|放っておけない凪
;#################################################

[SCENE id=10]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

朝になり、会社に向かわなければならなくなる。
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Nagi073"]
[OnName num="nagi"]
「それじゃ、行ってらっしゃい。私は、ずっと待ってますから」
[cpg cn=true]

[OnName num="keigo"]
「退屈するだろ。別に家に留まってなくてもいいぞ」
[cpg cn=true]

と言うかこの間もスーパーに行っていたよな。そう思い返す。
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『マンション通路』（朝）******************************************************

そして俺は会社に向かう途中。
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

後ろからの気配を感じ取って、ちょいちょい振り返ってみるとその度に凪が物陰に隠れようとしている。
[cpg]

隠れようとしているところが見えているので、もう隠れることができてない。
[cpg]

俺がどんな所で働いてるのか興味あるのだろうか。何でも良いんだが……
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（夕方）******************************************************

そして、特に凪には面白いものを見せられないまま夕方だ。
[cpg]

流石に勤務中ずっと待ち伏せるということはしてなかったらしい。凪の姿は見当たらなかった。
[cpg]

;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nagi074"]
[OnName num="nagi"]
「おかえりなさい、景吾さん」
[cpg cn=true]

[OnName num="keigo"]
「ああ。ただいま」
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Nagi075"]
[OnName num="nagi"]
「……ふと思ったのですが、泊めていただいているのですから、景吾様の方が正しいでしょうか」
[cpg cn=true]

[OnName num="keigo"]
「むずかゆいって……やめてくれ」
[cpg cn=true]

人から様付けされるなんて、こっちが客か何かじゃないとありえない。
[cpg]

それでも、下の名前に様付けは滅多にないよな。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


そして夕食を作っていく。今日も凪は見ているだけだ。
[cpg]

いつまでもそれはどうなんだろうと思いながらも、俺は相応以上の対価を手に入れている。
[cpg]

だから、別に気にしないで夕食を作る。そして、二人で食べることにした。
[cpg]

;//[free time=1000]
[SE f="se000"]
;//【ＳＥ】『食器の音』

ほとんど無言の食卓。躾けられてるんだろう。
[cpg]

俺が話しかけても返事をしないということは無いが、向こうからは話してこない。
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Nagi076"]
[OnName num="nagi"]
「ごちそうさまでした」
[cpg cn=true]

凪は手を合わせて、食事を終える。
[cpg]

[OnName num="keigo"]
「お粗末様。それじゃ、風呂にするか」
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_05_4.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]


;//========================================
;//●ＣＧ（背中を向けているヒロイン。）ev_13
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_13_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


そして、風呂を出てからのこと。
[cpg]

[VOICE f="sNagi001"]
[OnName num="nagi"]
「……私が、ベッドを占領してしまっていいんでしょうか」
[cpg cn=true]


[OnName num="keigo"]
「じゃあ一緒に寝るか？」
[cpg cn=true]


彼女は嫌がらなかった。むしろ、何か期待しているかのような顔をしている。
[cpg]

俺の方を少し振り返って、熱っぽい視線を向けていた。
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

しばらくの日々が過ぎる。また、休日だ。
[cpg]



[window target=false]
[free time=1]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

俺は凪を連れて、ちょっとしたデートにでも連れてみることにした。
[cpg]

[OnName num="keigo"]
「お前って、お嬢様なんだよな？」
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nagi097"]
[OnName num="nagi"]
「はい……そうですね。世間で言うところのお嬢様だと思います」
[cpg cn=true]

[OnName num="keigo"]
「どのくらいのお嬢様なんだ？　お前の親って、どれくらいの金持ちなんだ」
[cpg cn=true]

なんて、ぶしつけな質問だな。こんなこと聞くべきじゃないか。
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagi098"]
[OnName num="nagi"]
「……途方も無いですよ。私の事も、警察は捜索してないと思います」
[cpg cn=true]

[OnName num="keigo"]
「どういう意味だ……？」
[cpg cn=true]

少し考えて、分かった。凪の家が独自に調べてると言うことか。
[cpg]

なんかそれって凄く怖いぞ。俺は無事で済むのか。
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Nagi099"]
[OnName num="nagi"]
「家でも、ほとんど自由な時間がないほど、がんじがらめに育てられてきました……」
[cpg cn=true]

[OnName num="keigo"]
「……そうか」
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Nagi100"]
[OnName num="nagi"]
「大学でも、好きな人が居たんですけどね。私のお母様に、そのことを言った日を境に……その」
[cpg cn=true]

[OnName num="keigo"]
「まさか、引き剥がされたとでも……？　そんな話か」
[cpg cn=true]

頷く凪。相当な権力者というか、子供への干渉が過ぎるな。
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagi101"]
[OnName num="nagi"]
「私のお父様の力は至る所に及んでいます。まともな恋愛なんて、こうでもしないとできません」
[cpg cn=true]

そう言って、俺の方を見て笑った。おいおい。
[cpg]

[OnName num="keigo"]
「待て待て。これをまともな恋愛だと思ってるのか」
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Nagi102"]
[OnName num="nagi"]
「思っていますよ。これはデートでしょう？」
[cpg cn=true]

それは否定できない。世間を知らないなら、教えてやりたいと思っているから。
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Nagi103"]
[OnName num="nagi"]
「私、ばってぃんぐせんたーという所に行ってみたいです」
[cpg cn=true]

[OnName num="keigo"]
「……俺もよく知らん所だな。だけど、行ってみるか」
[cpg cn=true]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

そしてバッティングセンターに向かった。俺も凪も散々な結果だった。
[cpg]

が、非力な女の子と殆ど結果が同じというのが情けない。俺も歳なのか。
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

そして、デートも終わりつつあった。もうそろそろ夕方、何もなければ家に戻る時間。
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="sNagi002"]
[OnName num="nagi"]
「なんだか……時間が過ぎるのがもったいないです」
[cpg cn=true]


そう言われると、俺もそんな気になってしまっていた。
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_04_4.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]


;//【ＢＧ】『街』（夜）******************************************************

;//========================================
;//●ＣＧ（主人公に近づくヒロイン。可能であれば背景を変えてください）ev_14
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[wait time=1000]
[window target=true]

;//移植のためシーンをカットしています

家に戻ってから、彼女は今まで以上に俺になついていた。
[cpg]

身を寄せて、キスでも待っているかのような顔をしている。
[cpg]

それでも我慢していると、彼女はこう言ってきた。
[cpg]

[VOICE f="Nagi124"]
[OnName num="nagi"]
「私、いつまでも景吾さんのところでお世話になっていていいんでしょうか……」
[cpg cn=true]

[OnName num="keigo"]
「今更だな。俺が良いって言ってるんだから、良いんだ」
[cpg cn=true]


;//ブラックアウト

[SE f="se010"]
;//【ＳＥ】『歩く』


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

今日も二人寄り添って眠る。
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nagi125"]
[OnName num="nagi"]
「すぅ、すぅ……んん」
[cpg cn=true]

なんて、そう簡単に眠れるわけがない。
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

こんなに可愛い子が隣に居たら……と思っていると、凪も目を覚ましたようだ。
[cpg]

[OnName num="keigo"]
「悪い、起こしたな……もう夜中の一時だ、寝た方が良い」
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sNagi003"]
[OnName num="nagi"]
「いえ。私のせいですよね、ごめんなさい」
[cpg cn=true]


……凪は、想像以上に従順だ。
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

そして俺たちは、今度こそ眠ることにした。
[cpg]

流石に俺も疲れて、眠るしかなかった……
[cpg]

朝になるまでに、俺は布団の中で考える。
[cpg]

凪がどうしても家に帰れない事情を知ってしまった。
[cpg]

欲望が渦巻く。このまま、したいことをするということもできる。
[cpg]

欲望を思うがままぶつけるんだ。それでも、凪は出て行かないだろう。
[cpg]

しかし……凪の事を不憫に思う気持ちもある。
[cpg]

俺は、どうしたら良いんだろう？
[cpg]

;//■選択肢
[switch]
[case "欲望を押しとどめる"]
	[swap]
	[jump target="*select06_1"]
[case "欲望に身を任せる"]
	[swap]
	[jump target="*select06_2"]
[endswitch]

*select06_1|
[jump storage="ep011.ks" target="*select06_1"]


*select06_2|
[jump storage="ep012.ks" target="*select06_2"]

１、欲望を押しとどめる
２、欲望に身を任せる
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//==============================
