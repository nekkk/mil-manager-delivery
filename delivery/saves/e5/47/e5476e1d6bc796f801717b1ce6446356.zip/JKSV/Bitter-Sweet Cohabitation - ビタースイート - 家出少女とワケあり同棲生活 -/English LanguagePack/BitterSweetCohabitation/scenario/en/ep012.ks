
;//２、欲望に身を任せる

*start

;#################################################
*Ep012|Command Nagi
;#################################################

*select06_2|凪を従える

[SCENE id=12]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

[OnName num="keigo"]
“I can't keep you here forever."
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Nagi242"]
[OnName num="nagi"]
“Oh, no...please. Please let me stay here.”
[cpg cn=true]

[OnName num="keigo"]
“If you insist. But you will have to obey my orders.”
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Nagi243"]
[OnName num="nagi"]
"I understand. That's fine.”
[cpg cn=true]

Nagi couldn't goback home, so I decided to command her.
[cpg]


;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

[OnName num="keigo"]
"Nagi, let's go shopping.”
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Nagi259"]
[OnName num="nagi"]
“Uh, yes."
[cpg cn=true]

Why does she look so happy even though it’s just shopping?
[cpg]

I guess she can't see what I am really feeling. I didn’t mind.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

[OnName num="keigo"]
“Come here.”
[cpg cn=true]

Of course, I had no intention of just going shopping.
[cpg]



[OnName num="keigo"]
“Come to think of it, we've never made out in public.”
[cpg cn=true]

I came on to her in the back alley, saying so.
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1100]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sNagi007"]
[OnName num="nagi"]
“You can't ...... do that in a place like this.”
[cpg cn=true]



;//ブラックアウト
;//========================================
;//●ＣＧ（背後からヒロインに迫る主人公）ev_48
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：路地裏
;//時間　：夕方
;//========================================
[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_48_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

I think she must be a person with a strong sense of shame.
[cpg]

But she also seemed to be enjoying this situation.
[cpg]

[VOICE f="sNagi008"]
[OnName num="nagi"]
“Are you going to kiss ...... me?"
[cpg cn=true]


I kissed her forcefully without nodding or replying.
[cpg]

I know she won't mind even if I do so.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]

From then on, I acted the way I wanted to.
[cpg]

It is not even a mere master-slave relationship. My relationship with Nagi was just like that.
[cpg]


;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

I thought such days would continue forever.
[cpg]

However, the end came suddenly. ......
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="keigo"]
“What is going on…….you guys?”
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nagi310"]
[OnName num="nagi"]
“...... mother.”
[cpg cn=true]

But after a while, strange men suddenly came to the room.
[cpg]

Nagi's parents came.
[cpg]

They caught me and told me to tell them what I had done to her.
[cpg]

[OnName num="nagi's_mother"]
“What a lowlife. We have to go to the police.”
[cpg cn=true]

[OnName num="keigo"]
"Damn..."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Nagi311"]
[OnName num="nagi"]
“Mother! Please! Please forgive Keigo.”
[cpg cn=true]

[OnName num="nagi's_mother"]
“You're protecting him like this?”
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Nagi312"]
[OnName num="nagi"]
“Please, please, please! Please..."
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


Thanks to Nagi's intercession, I was able to go back to my old life without suffering too badly.
[cpg]

At the end she said.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Nagi313"]
[OnName num="nagi"]
"...... Goodbye."
[cpg cn=true]

I would never see her again.
[cpg]

I was able to live a free life on those terms.
[cpg]

Maybe there was a different way.
[cpg]

I had no choice but to go back to my old, tasteless life, thinking that those dreamy days were gone.
[cpg]



[SCENE id=18]

[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン３ルート２
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
