
;//１、欲望を押しとどめる

*start

;#################################################
*Ep011|凪の事情を解決できないか
;#################################################

*select06_1|Can't I solve Nagi's situation?

[SCENE id=11]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

I wondered if there was any way to solve the situation at Nagi's house.
[cpg]

[OnName num="keigo"]
“I don't know what to do..."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagi151"]
[OnName num="nagi"]
"Um...Keigo. Will you marry me?”
[cpg cn=true]

[OnName num="keigo"]
“Why so suddenly. Why would we get married?”
[cpg cn=true]

I say even though I had been in despair because I didn’t have anyone to marry in the first place.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Nagi152"]
[OnName num="nagi"]
“To create a document..…”
[cpg cn=true]

[OnName num="keigo"]
“I see.”
[cpg cn=true]

In other words, it’sIt was like getting married because the couple got pregnant.
[cpg]

You can't force someone to decide who they want to marry.
[cpg]

[OnName num="keigo"]
“That’s….. pretty aggressive.”
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Nagi153"]
[OnName num="nagi"]
“Well...I don't really want to do this either, but..."
[cpg cn=true]

Her parents would not listen to her.
[cpg]

[OnName num="keigo"]
“I mean, if you're going to marry another man, why me?”
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Nagi154"]
[OnName num="nagi"]
“Well. I prefer you Keigo.”
[cpg cn=true]

[OnName num="keigo"]
“We don't know much about each other.”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Nagi155"]
[OnName num="nagi"]
“We'll get to know each other better from now on.”
[cpg cn=true]

This was kind of amazing. She is strong.
[cpg]

A woman who has made up her mind is this strong.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagi156"]
[OnName num="nagi"]
“Of course, if you don't mind…"
[cpg cn=true]

[OnName num="keigo"]
"I don't mind."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Nagi157"]
[OnName num="nagi"]
“Then…"
[cpg cn=true]

[OnName num="keigo"]
“You could say that it’s like hanging on to a ship.”
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Nagi158"]
[OnName num="nagi"]
“I'm looking forward to it.”
[cpg cn=true]


;//ブラックアウト
;//移植のためシーンをカットしています

;//========================================
;//●ＣＧ（主人公を抱きしめるヒロイン）ev_43
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================
[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_43_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[VOICE f="sNagi004"]
[OnName num="nagi"]
“No one would ...... do such a thing for me.”
[cpg cn=true]


[OnName num="keigo"]
“If the person is as pretty as you are, they'll do it.”
[cpg cn=true]


[VOICE f="sNagi005"]
[OnName num="nagi"]
“You are such a sweet talker.”
[cpg cn=true]


As we talked about these things, our time together passed.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

Time passes. It was as if there was nothing left but me and Nagi.
[cpg]

We were just happy in these days.
[cpg]


;//ブラックアウト
;//========================================
;//●ＣＧ（背中を向けるヒロインに近づく主人公）ev_44
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[OnName num="keigo"]
“You say you want children, but how many do you want?”
[cpg cn=true]


[VOICE f="sNagi006"]
[OnName num="nagi"]
"Hmmm. It's too soon to tell.”
[cpg cn=true]


It might be. I never thought Nagi would say that to me.
[cpg]

But I love even this conversation.
[cpg]

I had nothing else to look at but Nagi.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

[FACE method="shock_5" pos="2/3"]
[VOICE f="Nagi210"]
[OnName num="nagi"]
“Oh, um! Keigo! I need to talk to you…"
[cpg cn=true]

[OnName num="keigo"]
“What's wrong?”
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Nagi211"]
[OnName num="nagi"]
“Well, I think I’m pregnant.”
[cpg cn=true]

[OnName num="keigo"]
“Oh……"
[cpg cn=true]


But this is also where it all starts.
[cpg]

[OnName num="keigo"]
“How do I get her parents to approve of me?”
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Nagi212"]
[OnName num="nagi"]
“I'll do my best.”
[cpg cn=true]

[OnName num="keigo"]
“That's my line.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Nagi213"]
[OnName num="nagi"]
“If we're going to be a couple, we need to work this out together."
[cpg cn=true]

She said quite abruptly.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

We were planning a strategy. But we couldn't take it that easy.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト

Nagi's parents had started to investigate her whereabouts on their own, and one day they came to us.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

[OnName num="nagi's_mother"]
"Ms. Nagi, we found you.”
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Nagi232"]
[OnName num="nagi"]
"Oh, mother..."
[cpg cn=true]

[OnName num="nagi's_mother"]
“You've done a terrible thing, haven't you?”
[cpg cn=true]

[OnName num="keigo"]
“May I have a word with you?”
[cpg cn=true]

[OnName num="nagi's_mother"]
"Be quiet. Get out of here right now.”
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Nagi233"]
[OnName num="nagi"]
“Please, Mother.”
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Nagi234"]
[OnName num="nagi"]
“I love Keigo. And I have a child in my belly.”
[cpg cn=true]

[OnName num="nagi's_mother"]
“I'm not going to tell you what to do right now. You shouldn't be here in that state.”
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagi235"]
[OnName num="nagi"]
“….. mother.”
[cpg cn=true]

It was the image of a mother, stern but caring for her.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Some time later...
[cpg]

I am now in training to be a suitable marriage partner.
[cpg]

Nagi’s mom is still strict.
[cpg]

She was still thinking of her child, so she ordered me to become a suitable heir.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nagi236"]
[OnName num="nagi"]
“I'm really glad I met you Keigo.”
[cpg cn=true]

[OnName num="keigo"]
“I'm glad to hear you say so. Do you have any regrets?”
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagi237"]
[OnName num="nagi"]
“Regret...? How can that be?”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Nagi238"]
[OnName num="nagi"]
“I met you, you let me stay at your house, and my life changed from there.”
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Nagi239"]
[OnName num="nagi"]
“Thank you so much.”
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Nagi240"]
[OnName num="nagi"]
“I look forward to being with you... for many years to come.”
[cpg cn=true]

[OnName num="keigo"]
“Well, I'll do my best.”
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Nagi241"]
[OnName num="nagi"]
“Mmhmm…..”
[cpg cn=true]

[SCENE id=17]

[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン３ルート１
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//==============================
