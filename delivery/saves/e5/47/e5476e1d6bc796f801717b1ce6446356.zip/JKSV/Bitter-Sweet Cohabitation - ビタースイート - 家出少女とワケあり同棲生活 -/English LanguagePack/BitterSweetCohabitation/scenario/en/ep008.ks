

;//１、晶菜を抱きしめる
*select05_1|晶菜のためなら

俺は布団の中の、晶菜を抱きしめた。
[cpg]

彼女は眠りかかっている。寝ぼけながらも……
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="sAkina010"]
[OnName num="akina"]
「……おじさん」
[cpg cn=true]

晶菜はちょっと照れたような顔をしていた。
[cpg]

俺は決めた。晶菜を愛することを。彼女のためにできることなら何でもしよう。
[cpg]


*start

;#################################################
*Ep008|晶菜のためなら
;#################################################

[SCENE id=8]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

翌朝。少し朝早くに目が覚めて、俺は晶菜と相談することにした。
[cpg]

相談というか、提案だな。俺は彼女を泊めてる見返りを、ちゃんとできてない。
[cpg]

[OnName num="keigo"]
「……俺、晶菜の事が好きなんだ」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina168"]
[OnName num="akina"]
「そりゃどうも。私も、おじさんのこと好きだよ」
[cpg cn=true]

笑顔でそう言ってくる。そうじゃないんだよ。
[cpg]

[OnName num="keigo"]
「……結婚まで行かなくても、これって同棲だろ」
[cpg cn=true]

[OnName num="keigo"]
「それで、お前のお母さんがお金に苦しんでるなら、手伝いたいよ」
[cpg cn=true]

俺はそう言って迫ってみた。晶菜に俺の気持ちが伝わったのか、晶菜は恥ずかしそうにしている。
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Akina170"]
[OnName num="akina"]
「まあ、考えとくよ。でも、お金はまだ要らない。泊めて貰ってるだけで十分助かるし」
[cpg cn=true]

[OnName num="keigo"]
「……そうか」
[cpg cn=true]

まだ足りないか。俺の気持ちは、どうやったら伝わる？
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

俺にあるものと言ったら、お金くらいだ。他人にないものを持ってると言えば……何がある？
[cpg]

決まってる。晶菜への愛情だ。
[cpg]

晶菜を抱いてるであろう他の男には無いものだと思う。
[cpg]

俺だけが、彼女を愛する道があるはず。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

そう思いながら、俺は少し無理してでも働いた。
[cpg]

そうでもしないと、気持ちが落ち着かなかった。
[cpg]

晶菜が頑張ってるのに、俺が何もしないわけにはいかない。
[cpg]

その一心で、がむしゃらに働いた。
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（夜）******************************************************

結果、夜遅くに家に戻る。晶菜は晩飯を食ってくれているだろうか。
[cpg]

これじゃ本末転倒だなと思いながら、帰宅した。
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

;//ここから晶菜は主人公を「景吾」と呼びます
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akina171"]
[OnName num="akina"]
「遅いー。景吾の作ってくれるご飯、楽しみにしてるのに」
[cpg cn=true]

[OnName num="keigo"]
「ああ、悪い……」
[cpg cn=true]

聞き逃してしまいそうになるが、今俺の事を景吾と呼んだ。
[cpg]

おじさん、ではない。しかも下の名前を呼び捨て。
[cpg]

多少は晶菜にも気持ちが伝わったんだろうか。そう思いながら……
[cpg]

俺は急いで料理を作った。晶菜を待たせてしまった分、手早く。しかし心をこめて。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

そして晩飯を食い終わり、風呂にも入って眠ろうというころ。
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Akina172"]
[OnName num="akina"]
「ねえ、景吾。本気なの？」
[cpg cn=true]

[OnName num="keigo"]
「……何がだ」
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Akina173"]
[OnName num="akina"]
「私と結婚するって話」
[cpg cn=true]

[OnName num="keigo"]
「……そこまでは言ってないだろ」
[cpg cn=true]

そう言うと、晶菜がちょっと残念そうにこう言ってきた。
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina174"]
[OnName num="akina"]
「結婚はしてくれないんだ。ふーん、結婚した方が早いのに」
[cpg cn=true]

[OnName num="keigo"]
「……」
[cpg cn=true]


;//========================================
;//●ＣＧ（抱きしめられるヒロイン。背後の主人公に振り返る）ev_32
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_32_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

そんなことを言う彼女に、愛しさがこみ上げてたまらなかった。
[cpg]

[OnName num="keigo"]
「本当に……好きだ。愛してる」
[cpg cn=true]


[VOICE f="sAkina011"]
[OnName num="akina"]
「ふふっ。ひねりがなさすぎ」
[cpg cn=true]


とは言いつつも、彼女も嬉しそうにしてくれていた。
[cpg]

こんなことだけでも、俺は幸せだ……
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

そして日々は過ぎて、休日。俺は一日、晶菜と一緒に居られることになった。
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina193"]
[OnName num="akina"]
「今日は私も色々とお休みかなぁ」
[cpg cn=true]

と言っているので、別の男のところに行くこともないのだろう。
[cpg]

[OnName num="keigo"]
「……どこかに、遊びにでも行くか？」
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Akina194"]
[OnName num="akina"]
「勿体ないでしょ。お金の無駄遣いは」
[cpg cn=true]

[OnName num="keigo"]
「そう言うけどな、自分のためにお金も使わないとストレス溜まらないか？」
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Akina195"]
[OnName num="akina"]
「別に？　元々貧乏だし」
[cpg cn=true]

[OnName num="keigo"]
「……そうか」
[cpg cn=true]

ならば無理強いすることもない。今日はずっと家に居ようか。
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************

そういうわけで、暫く家に居た。すると、晶菜が退屈したらしく、俺にすりよってくる。
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Akina196"]
[OnName num="akina"]
「……ねぇ、景吾。私のこと、本気で好きなんだよね？」
[cpg cn=true]

[OnName num="keigo"]
「ああ。そうだ」
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sAkina012"]
[OnName num="akina"]
「それならさ、一日中でも一緒に居たいよね」
[cpg cn=true]


[OnName num="keigo"]
「そうは言っても……他にすることはないのか」
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="sAkina013"]
[OnName num="akina"]
「お金がもったいないかなぁって思っちゃうんだよね」
[cpg cn=true]


[OnName num="keigo"]
「ある程度なら奢ってやれるけど」
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina199"]
[OnName num="akina"]
「それは、なんか対等じゃないだよなぁ」
[cpg cn=true]

言いたいことは分からないでもない。
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

そして夕方になる。なんだか、無為な日だな……と思っていると。
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina200"]
[OnName num="akina"]
「……外に出ようか。デートしよう、景吾」
[cpg cn=true]

[OnName num="keigo"]
「いいのか。お金は無駄遣いしたくないんだろ」
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Akina201"]
[OnName num="akina"]
「お金を使わないデートもあるでしょ。行こう」
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


ということで、夕方の街へ繰り出した。
[cpg]

晶菜は主にウインドウショッピングを繰り返していた。
[cpg]

わりとお洒落に興味がある奴らしい。
[cpg]

そこはちゃんとしてないと、男も相手してくれないと思っているのかもしれない。
[cpg]

俺はファッションについてはよく分からないが……
[cpg]

晶菜と一緒に居るだけで楽しかった。
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina202"]
[OnName num="akina"]
「楽しいね。景吾」
[cpg cn=true]

[OnName num="keigo"]
「ああ。楽しい」
[cpg cn=true]

晶菜と結婚というのも、悪くないかもしれないな。
[cpg]

年の差はあっても、俺たちなら乗り越えられると思う。
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

かなり遅い時間になってきて、家に戻ろうとする。
[cpg]

[OnName num="keigo"]
「そろそろ帰るか？　腹減ってるだろ」
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Akina203"]
[OnName num="akina"]
「そうだね。戻ろっか」
[cpg cn=true]

晶菜は満足したような表情をしていた。
[cpg]

俺が服を買ってやろうと何度かしてみたが、晶菜は拒んだ。
[cpg]

晶菜にとっては、やはり何もない状態でお金だけ得るというのは違和感あるらしかった。
[cpg]

;//ブラックアウト

;//移植のためシーンをカットしています

そこが彼女の個性というか、プライドなのだろうと思った。
[cpg]

そんなところが俺も好きだったので、無理強いはしない。
[cpg]

そして、また明日が来る……
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina247"]
[OnName num="akina"]
「おはよう。景吾」
[cpg cn=true]

[OnName num="keigo"]
「ん……？　ああ、もう朝か……」
[cpg cn=true]

時計を見るとかなり早い時間。朝の五時。
[cpg]

[OnName num="keigo"]
「……眠れなかったのか」
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Akina249"]
[OnName num="akina"]
「ちょっとね。お母さんのことが心配で」
[cpg cn=true]

[OnName num="keigo"]
「お金はあるんだろ。なら心配要らないじゃないか」
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Akina250"]
[OnName num="akina"]
「……この間もそうだったんだけど、私が稼いだお金を使ってくれないんだよね」
[cpg cn=true]

何だって？　それは何というか、報われない話だ。
[cpg]

[OnName num="keigo"]
「どういうことだ……？」
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sAkina014"]
[OnName num="akina"]
「お母さんも、私にお金を残したいのかもしれないね」
[cpg cn=true]

……そうか。親なら、そう考えるかもしれないな。
[cpg]

それに、何をして稼いできてるか分からないとあれば、余計に使えないか……
[cpg]

[OnName num="keigo"]
「心配なら、家に戻れば良いんじゃないか」
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina252"]
[OnName num="akina"]
「できないよ。私、お母さんの顔見られないもん」
[cpg cn=true]

[OnName num="keigo"]
「どうして……」
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Akina253"]
[OnName num="akina"]
「私に謝ってくるんだよ……？　お母さんが、私に。そんな理由なんてないのにね」
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

なかなかヘビーな話を聞いてしまった。
[cpg]

なおのこと俺が救わなきゃいけない。プロポーズするくらいの覚悟はできてきた。
[cpg]

家に戻ったら、晶菜に言おう。彼女と彼女のお母さんを助けられるのは多分俺だけだ。
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（夕方）******************************************************

仕事を終えて、晶菜の待つ家に戻った。
[cpg]

もちろん居ない可能性もあったが、なんとなく今日は戻ってるんじゃないかと思った。
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

;//「お帰り。おじさん、覚悟決めてくれた？」

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Akina254"]
[OnName num="akina"]
「お帰り。景吾、覚悟決めてくれた？」
[cpg cn=true]

結婚については、晶菜が先に言い出してきた。俺は少したじろぐ。
[cpg]

しかし、ここで何も言えないようではだめだ。
[cpg]

[OnName num="keigo"]
「……結婚、するか。しよう、晶菜」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina255"]
[OnName num="akina"]
「ありがとう。そう言ってくれると思った」
[cpg cn=true]

実はそれで全部解決しちゃうんだよね、と言いながら頭を掻く晶菜。
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina256"]
[OnName num="akina"]
「もちろん、誰でもいいわけじゃないよ？　景吾って、どうしようもないお人よしに見えたから」
[cpg cn=true]

[OnName num="keigo"]
「まあ、そうかもしれないな……否定はしない」
[cpg cn=true]

[OnName num="keigo"]
「それよりも、お母さんに顔を見せてやったらどうだ？」
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Akina257"]
[OnName num="akina"]
「……うん。私、お母さんのところに戻る決意できたよ。景吾も、来てくれる？」
[cpg cn=true]

[OnName num="keigo"]
「まだ、住むことはできないけどな。でも、いつかは一緒に住もう」
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Akina258"]
[OnName num="akina"]
「ふふ。嬉しいよ、景吾……」
[cpg cn=true]

;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

晶菜は身支度を整えて、ここを出ようとしていた。
[cpg]

向かう先は、晶菜の家。彼女の母親が一人待っている筈だと言う。
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Akina277"]
[OnName num="akina"]
「景吾も来るよね？　ううん、来てほしいな」
[cpg cn=true]

[OnName num="keigo"]
「もちろん。ここでついていかないわけないだろ」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina278"]
[OnName num="akina"]
「ふふ。それじゃ、行こう」
[cpg cn=true]

;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

そういうわけで、街に出る。晶菜の家まではわりと遠かった。
[cpg]

歩くには遠い距離なので、電車を使って少し行く。
[cpg]

そして降りた先で、彼女は自分の家に向かって歩き出した。
[cpg]

俺は後をついていく形。そして……
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Akina279"]
[OnName num="akina"]
「ここだよ。第一印象大事だから、気をつけてね」
[cpg cn=true]

[OnName num="keigo"]
「分かってる……」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina280"]
[OnName num="akina"]
「緊張してるね、景吾」
[cpg cn=true]

[OnName num="keigo"]
「お前だってそうだろ……」
[cpg cn=true]

そんな会話をしながら、インターホンを押すが……返事がない。
[cpg]

ドアを開ける。鍵はかかっていなかった。
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina281"]
[OnName num="akina"]
「おかしいな……どうしてだろう」
[cpg cn=true]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]

[SE f="se000"]
;//【ＳＥ】『床歩く』

晶菜が玄関を通って、廊下の方まで進んでいく。俺は家の前で待っていた。
[cpg]

すると、晶菜の悲鳴が聞こえてきた……
[cpg]

;//========================================
;//●ＣＧ非エロ（廊下で倒れているヒロインの母親。抱きかかえながら泣きそうになるヒロイン。ヒロインの表情が見えるアングル）ev_36
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：ヒロイン２の母
;//服装２：私服
;//場所　：ヒロイン２の家＿廊下
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[VOICE f="Akina282"]
[OnName num="akina"]
「お母さん！　お母さん、しっかりしてっ」
[cpg cn=true]

そこでは、晶菜と晶菜の母らしい女性が居た。
[cpg]

晶菜のお母さんは、倒れていたらしい。
[cpg]

[OnName num="keigo"]
「ど、どうする……？　救急車、呼ぶか」
[cpg cn=true]

[VOICE f="Akina283"]
[OnName num="akina"]
「凄い熱……！　ど、どうしようっ、景吾」
[cpg cn=true]

[OnName num="keigo"]
「やっぱり救急車だろ！　俺が呼ぶっ」
[cpg cn=true]

[VOICE f="Akina284"]
[OnName num="akina"]
「しっかりしてっ、お母さん、お母さん！」
[cpg cn=true]

涙ながらに母のことを呼ぶ晶菜。しかし、目を覚ますことはない。
[cpg]

[VOICE f="Akina285"]
[OnName num="akina"]
「やだよぉ……どうして、こんなことに……」
[cpg cn=true]

まだ亡くなってはない。今なら間に合う。
[cpg]

どれほどの間倒れていたのか分からないが、一刻を争う事態ではあると思う……
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

そして、晶菜の母は病院に搬送された。
[cpg]

かなり危ない状態だったらしい。あのまま、長い間倒れていたらしいということだ。
[cpg]

病状はゆるやかに回復しているが、後遺症が残るかもしれないとのことだった。
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

晶菜はずっと付き添っていた。俺は仕事があるのでずっとそこに居るわけにはいかなかったが……
[cpg]

できる限り、彼女の側に居てあげようと思った。
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

そして、病室。晶菜は泣きながらこう言っていた。
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Akina286"]
[OnName num="akina"]
「もう少し……もう少し早く家に戻ってたら、お母さんはこんな目に遭わずにすんだのかな」
[cpg cn=true]

[OnName num="keigo"]
「考えてもしょうがない。それに、晶菜のせいじゃない」
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Akina287"]
[OnName num="akina"]
「私のせいだよ……普通の仕事をして、自分の家に居たら、こんなことにはならなかったよね」
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Akina288"]
[OnName num="akina"]
「私、結局楽な方に逃げちゃったんだよ、きっと……多分。こんな私が生きてるのって、おかしいよね」
[cpg cn=true]

自分が生きていることさえ否定する晶菜。考えすぎだ。
[cpg]

[OnName num="keigo"]
「自分の幸せまで諦めたら駄目だ。晶菜、落ち込みすぎるなよ」
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Akina289"]
[OnName num="akina"]
「……分かってる。私が幸せにならないと、駄目なんだよね」
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

それから。晶菜はチャラチャラした格好をやめようかと考えているらしかった。
[cpg]

お見舞いの品を買いに行って、戻る途中。俺と晶菜は、二人で話をしていた。
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina290"]
[OnName num="akina"]
「お母さんを助けられなかったのって、結局貧乏のせいだよね」
[cpg cn=true]

[OnName num="keigo"]
「……それは……そういう面もあるだろうな」
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Akina291"]
[OnName num="akina"]
「お金が全部なんだよ、結局。私はそんな世の中で負けちゃったんだ」
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Akina292"]
[OnName num="akina"]
「もっと、もっとお金が欲しい……力が欲しい」
[cpg cn=true]

晶菜の視界はかなり狭まっているようだった。
[cpg]

[OnName num="keigo"]
「いや。俺はお前がいるだけで良い。お金が全部とは思わない」
[cpg cn=true]

[OnName num="keigo"]
「お金が全てだと思うほど、お母さんが倒れたのが辛くなるだけだ」
[cpg cn=true]

[OnName num="keigo"]
「……もう一回言うけど、俺は、お前が居れば良いんだ」
[cpg cn=true]

全ては理解してくれないかもしれない。時間がかかることかもしれない。
[cpg]

それでも、少しずつ分かってくれたら。そう思いながら……
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Akina293"]
[OnName num="akina"]
「私、強くなりたいよ」
[cpg cn=true]

[OnName num="keigo"]
「……もう十分強いはずだ」
[cpg cn=true]

俺たちは、前に進もうとしていた。
[cpg]


;//ブラックアウト
[SCENE id=15]

[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン２ルート１
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//ここから、晶菜は主人公を@「おじさん」と呼びます
;//==============================
