
*start


;#################################################
*Ep001|無邪気な少女
;#################################################

[SCENE id=1]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『オフィス内』（昼）******************************************************

[OnName num="colleague"]
「……なんだって？」
[cpg cn=true]

[OnName num="keigo"]
「聞いてなかったのか？　学生の女の子が泊まりに来たんだよ」
[cpg cn=true]

[OnName num="colleague"]
「そりゃお前、羨ましい……いや、危なっかしいことだな」
[cpg cn=true]

[OnName num="keigo"]
「そうだな。それが普通だよな」
[cpg cn=true]

[OnName num="colleague"]
「もう帰したんだろ？　っていうか、そうじゃないとまずいだろ」
[cpg cn=true]

[OnName num="keigo"]
「もちろん。もう、家には誰も居ない……」
[cpg cn=true]

口にすると、ちょっと辛くなる。そうか、やっぱりもう居ないのか。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（夕方）******************************************************

[OnName num="keigo"]
「……」
[cpg cn=true]

凛生への連絡先は残っている。呼ぼうと思えば呼べる。
[cpg]

しかしギリギリの所で思いとどまっていた。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

そんなことを考えながら、日々は過ぎていく。
[cpg]

恐ろしく退屈に思えてくる。それほどに、凛生と過ごした日々はかけがえのないものだった。
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（夕方）******************************************************

そして、ある日の帰り道……
[cpg]

;//========================================
;//●ＣＧ非エロ（玄関の前で座り込んでいるヒロイン。途中で主人公の存在に気がつき、笑顔を向ける）ev_05
;//人物１：ヒロイン２
;//服装１：私服
;//場所　：マンション通路＿主人公の部屋の前
;//時間　：夕方
;//========================================
[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_op"]
;**【ＣＧ】 ev_05_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[OnName num="keigo"]
「……誰だ」
[cpg cn=true]

;//晶菜の名前を？？？と隠してください

[VOICE f="Akina001"]
[OnName num="unknown"]
「ああ。こんばんは、おじさん。景吾とかそんな名前だっけ？」
[cpg cn=true]

[OnName num="keigo"]
「誰だって聞いてるだろ。俺に何のようだ」
[cpg cn=true]

;//ここから晶菜の名前を表示してください

[VOICE f="Akina002"]
[OnName num="akina"]
「いっぺんに答えるね。私は小早川 晶菜（こばやかわ あきな）」
[cpg cn=true]

そう答えた少女は、まだ座り込んでいた。
[cpg]

[VOICE f="Akina003"]
[OnName num="akina"]
「うちさー、行くとこないからさ、泊めてくんない」
[cpg cn=true]

無邪気な声でそう言ってくる。どうしてこんなことになったんだ？
[cpg]

[OnName num="keigo"]
「どうして俺なんだ……凛生のことを知ってるのか」
[cpg cn=true]

[VOICE f="Akina004"]
[OnName num="akina"]
「もち。知ってるよ、凛生とは友達だから」
[cpg cn=true]

聞けば、凛生から泊めてくれそうな場所を聞き出していたらしい。そして凛生は俺の家を挙げたとか。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『マンション通路』（夕方）******************************************************

[OnName num="keigo"]
「……まずいだろ。女の子を泊めるなんて」
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Akina005"]
[OnName num="akina"]
「まずくないって。可愛がってよ、おじさん」
[cpg cn=true]

そう言いながらにっこり笑う。可愛いと思ってしまうが、しかし。
[cpg]

このまま家に上げたら、凛生と同じ事になるんじゃ無いか。
[cpg]

見た限り、彼女は凛生よりもちゃらちゃらしている。それ以上のことになってしまうかもしれない。
[cpg]

;//■選択肢
[switch]
[case "晶菜を家に上げる"]
	[swap]
	[jump target="*select01_1"]
[case "晶菜に帰るように言う"]
	[swap]
	[jump target="*select01_2"]
[endswitch]
１、晶菜を家に上げる
２、晶菜に帰るように言う
;//==============================
;//１、晶菜を家に上げる
*select01_1|無邪気な少女
[stflag Cha2flg = 1]

[OnName num="keigo"]
「分かった。上がってくれ」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina006"]
[OnName num="akina"]
「良いの？　やったっ」
[cpg cn=true]

かなり自由気ままな性格に見える。服装なんかから、察することができる。
[cpg]

やはり上げるのは失敗だったか……と思いながらも、俺は鍵を開けた。
[cpg]

;//晶菜が候補に
[jump target="*select01_3"]
;//==============================
;//２、晶菜に帰るように言う
*select01_2|無邪気な少女
[OnName num="keigo"]
「駄目だ。帰ってくれ」
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Akina007"]
[OnName num="akina"]
「えー。いーじゃん、上げてよっ。お腹空いて死んじゃうよ」
[cpg cn=true]

[OnName num="keigo"]
「……何も食べてないのか」
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Akina008"]
[OnName num="akina"]
「うん。もー、お腹ペコペコ」
[cpg cn=true]

……仕方ない。空腹の相手を突き返すわけにはいかないか。
[cpg]

;//==============================
*select01_3|無邪気な少女

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

そして、部屋に入ってからは晶菜は勝手にくつろぎだした。
[cpg]

凛生は何をするにも遠慮がちだった気がするが、今なんて炊飯器から茶碗にご飯を盛り付けている。
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Akina009"]
[OnName num="akina"]
「おかず無いかなぁ。あ、缶詰がある」
[cpg cn=true]

本当に腹が減っていたらしい。俺が料理を作ってやってもいいのに、それを待たない。
[cpg]

[OnName num="keigo"]
「……お前な、遠慮ってものがないのか」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sAkina001"]
[OnName num="akina"]
「無いねぇ。あはは」
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[SE f="se000"]
;//【ＳＥ】『シャワー』

そして彼女は勝手にシャワーまで浴びてしまった。
[cpg]

バスタオルを用意してなかったらどうするつもりなんだろう。用意してあるけど。
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Akina011"]
[OnName num="akina"]
「ふー、さっぱり。あれ、晩ご飯作ったんだ」
[cpg cn=true]

[OnName num="keigo"]
「まあな」
[cpg cn=true]

即席で作ったものだが、晶菜は興味を示した。
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Akina012"]
[OnName num="akina"]
「私も食べるー。ちょっと貰っていい？」
[cpg cn=true]

[OnName num="keigo"]
「すごい食欲だな……」
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

そしてまた夜だ。しかし、俺は以前のようにまた寝られなくなってしまった。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sAkina002"]
[OnName num="akina"]
「まだ起きてる？」
[cpg cn=true]


[OnName num="keigo"]
「……ああ」
[cpg cn=true]


;//========================================
;//●ＣＧ（左右にベッドに座る。眠れない主人公に話しかけるヒロイン）ev_06
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_06_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


眠れないならと、彼女は俺を隣に座らせた。
[cpg]

[VOICE f="sAkina003"]
[OnName num="akina"]
「寝ないと体に毒だよ」
[cpg cn=true]


いや寝られない原因がそれを言うか……
[cpg]

と思いつつも、彼女も優しいんだと感じていた。
[cpg]

[VOICE f="sAkina004"]
[OnName num="akina"]
「子守歌でも歌ってあげようか？」
[cpg cn=true]


そう言ってからかうのも、なんだか単に意地悪なだけではないように思えた。
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

晶菜は俺が起きても、ぐーすか寝ていた。
[cpg]

鍵を渡しておいて大丈夫だろうか？　と思ったが、渡さないとまた冷蔵庫のものを勝手に食われそうだ。
[cpg]

そういうわけで、鍵と書き置きを残した。
[cpg]

外出するときは鍵をかけとけ、と書き置く。鍵は二個あるので、問題は無い。
[cpg]

そして俺は外に出た。今日も会社だ。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="hidari.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hidari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（朝）******************************************************

仕事が退屈なわけではないが、やはり女の子が家に居るとなると、仕事のやる気は大きく変わる。
[cpg]

退屈でなくなる。家に戻っても何も無いあのときとは明らかに違う。
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_3.ui" time=1000]
[WAIT time=2100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（夕方）******************************************************

そして、仕事を終えて会社を出る……
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（夕方）******************************************************

帰り道はどこか浮かれた気分だ。明らかに気分が浮ついている。
[cpg]

そんな気分のままに、家まで戻る。
[cpg]

帰ったら、晶菜が居る。そう思いながら。
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akina033"]
[OnName num="akina"]
「おかえりー。ヒマすぎて死にそうだったよ」
[cpg cn=true]

[OnName num="keigo"]
「……そうか」
[cpg cn=true]

外に出たんだろうか。わりとこの辺りは街だから、外に出れば暇を潰す場所なんていくらでもある。
[cpg]

[OnName num="keigo"]
「外に出れば、何でも遊べただろ」
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina034"]
[OnName num="akina"]
「私、倹約家だから。あんまりお金使いたくないんだよね」
[cpg cn=true]

そうなのか。意外な一面を見ることになった。
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina035"]
[OnName num="akina"]
「それよりお風呂入ろうよ、もうお湯張ってるから」
[cpg cn=true]

勝手なことを。そう思いながらも、彼女がそう言うならそうするか。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="keigo"]
「……お前は、料理を手伝おうとか思わないのか」
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina054"]
[OnName num="akina"]
「うーん、あんまり得意じゃないよ？」
[cpg cn=true]

凛生は自分から手伝いに来てたけどな。まあいいか。
[cpg]

凛生もそうだけど、晶菜の家の事情も全く分からない。
[cpg]

家が厳しいから飛び出してきたんだろうか。だとしたら学園はどうしてるんだろうか、とか。
[cpg]

色々想像は尽きないが、口には出さない。
[cpg]

それを言ってしまったら、地雷を踏みそうで怖かった。
[cpg]


;//ブラックアウト


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


そういうわけで、夕食ができた。二人で食卓を囲む。
[cpg]


[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1100]
[FACE method="shake_1" pos="2/3"]
[VOICE f="Akina055"]
[OnName num="akina"]
「……一人暮らしにしては、料理上手いよね。一人暮らしだからかな？」
[cpg cn=true]

[OnName num="keigo"]
「素直に褒めてくれてもいいんだぞ」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina056"]
[OnName num="akina"]
「おいしいよ。おじさん、天才」
[cpg cn=true]

そう言って天使みたいに笑う。この子は、この子なら……
[cpg]

それほど、家に泊めていても罪悪感がない。もともとチャラチャラしている。
[cpg]

心が痛まないというか、凛生とは明らかに違う。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

そして。昨日はなんとなく二人寄り添って眠ってしまったが、今日はどうするか悩んだ。
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Akina057"]
[OnName num="akina"]
「別に良いんじゃない？　二人で寝ようよ」
[cpg cn=true]

[OnName num="keigo"]
「狭いだろ。寝返り打てないぞ」
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Akina058"]
[OnName num="akina"]
「気にしないって。ほら、おいで」
[cpg cn=true]

おいでも何も、俺のベッドなんだけどな……と思いつつ、俺は彼女と二人で寝ることにした。
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

そして朝になる。目覚ましが鳴っているというのに晶菜は全く起きる気配が無い。
[cpg]

睡眠時間が人より長いんだろうか。そんなことを想像した。
[cpg]


;//ブラックアウト
[SE f="se000"]
;//【ＳＥ】『鍵かける』


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

鍵をかけて、家を出る。今日は晶菜の分の昼食代を置いていった。
[cpg]

どう使うか分からないが、五百円置いていっただけだから多分昼食で全部使ってしまうだろう。
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『オフィス内』（夕方）******************************************************

何かの理由で、別のことに使うかも知れないかとも思った。倹約家だとも言っていたし。
[cpg]

でも昼飯を我慢してまで貯めたりはしないと思う。そう思っていたが……
[cpg]

;//ブラックアウト

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="hidari.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hidari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Akina059"]
[OnName num="akina"]
「遅いよ。お腹空いた」
[cpg cn=true]

[OnName num="keigo"]
「お腹空いたってお前……まだそんな時間でもないだろ。まさか」
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Akina060"]
[OnName num="akina"]
「ああ、お昼はご飯炊いて勝手に食べたよ。卵かけご飯にした」
[cpg cn=true]

本当か。意外と家事ができるんだな、じゃなくて……
[cpg]

[OnName num="keigo"]
「じゃあ、五百円返してくれ」
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Akina061"]
[OnName num="akina"]
「えーっ、これ貰えると思って節約したのに」
[cpg cn=true]

やっぱりそうだったのか。お金にがめついのはどうしてだろう。
[cpg]

そんなことを思いながら、結局昼食代は返して貰えなかった。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

そして夕食を作って食べて、風呂に入って……
[cpg]

そんな普段通りのことでも、彼女と居ると何かと楽しい。
[cpg]

風呂上がりの彼女はやけに魅力的に見える。良い匂いがする。
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="sAkina005"]
[OnName num="akina"]
「……やらしい目で見てるなー」
[cpg cn=true]


[OnName num="keigo"]
「しょうがないだろ」
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=1000]
彼女は少し笑って、俺の方に近づいてきた。
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

軽く横になっていた俺の隣に、晶菜がやってくる。
[cpg]

;//========================================
;//●ＣＧエロ（ヒロインにクンニする主人公。ヒロインは足を開いてベッドに座っている感じ）ev_08
;//人物１：ヒロイン２
;//服装１：私服（半脱ぎ）
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[VOICE f="sAkina006"]
[OnName num="akina"]
「膝枕でもしてあげよっか？」
[cpg cn=true]


そう言われるとして欲しいような気持ちもあるが、しかし……
[cpg]

[OnName num="keigo"]
「そのまま寝てしまいそうだから、やめとくよ」
[cpg cn=true]


[VOICE f="sAkina007"]
[OnName num="akina"]
「寝ちゃえばいいじゃん」
[cpg cn=true]


とはいえ、このままベッドを占領して寝るわけにもいかない。
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

そんな日々が、数日続いていった。
[cpg]

何をするにも彼女がいるから頑張れる。そんな日々だった。
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

昼と夜が繰り返される。昼の間、晶菜は何をしてるんだろう？
[cpg]

それを聞いても、晶菜は答えてはくれなかった。
[cpg]

そして、休日になる……
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

ある朝、目を覚ますと俺より早く晶菜が目を覚ましていた。
[cpg]

なんだか嫌な予感がした。荷物を纏めていたんだ。
[cpg]

[OnName num="keigo"]
「……どうしたんだ、急に……」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina081"]
[OnName num="akina"]
「またね、おじさん。また別の人のところに行ってくるよ」
[cpg cn=true]

[OnName num="keigo"]
「ど、どうして……」
[cpg cn=true]

いや、どうしても何も無い。俺は彼女を泊めてるだけだ。
[cpg]

退屈に思わせたのかもしれない。だとしたら、別の男のところに行くのも当然。
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina082"]
[OnName num="akina"]
「落ち込まないで。一つの場所に居るとなんとなく嫌ってだけだから」
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Akina083"]
[OnName num="akina"]
「またおじさんの所に来るかも知れないしさ。それじゃあね」
[cpg cn=true]

[OnName num="keigo"]
「ま、待ってくれ」
[cpg cn=true]


凛生の時とまるで逆だ。凛生を出て行くように俺は言って、凛生は出て行こうとしなかった。
[cpg]

その逆。晶菜が出て行こうとしていて、俺はそれを制止している……
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Akina084"]
[OnName num="akina"]
「しつこいと嫌われるよ？　おじさんも、良い人見つけた方がいいかもね」
[cpg cn=true]

[free time=1000]

[WAIT time=1000]
;//ブラックアウト
そんな風にして、晶菜とは連絡先も交換せずに別れることになった。
[cpg]

俺は途方に暮れるというか、言い様もない欲求不満に陥った。
[cpg]

二度も家出少女を泊めてしまった。また同じ思いをしたいと思うようになってしまった。
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

することもなく、街に繰り出す。
[cpg]

もしかしたら、凛生や晶菜のように、家出中の少女が居るかも知れない。
[cpg]

……なんて。そんな偶然ありえない。分かっていながら、俺はぼうっと歩いていた。
[cpg]

凛生に連絡したらいいのかもしれない。だけど、やっぱり違う。
[cpg]

今更どんな顔をして会えば良いのか分からない。彼女も男を知った後かもしれない。
[cpg]

そう思うと、連絡はできなかった。
[cpg]


[jump storage="ep002.ks" target="*start"]

;//=============================================================================
