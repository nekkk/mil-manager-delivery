

;//２、晶菜
*select03_2|危なっかしい晶菜



……晶菜。一番危なっかしい彼女のことが気になった。
[cpg]

彼女を俺が呼び出す場合、凛生を経由して呼び出す必要がある。
[cpg]

しかしそんなことできるだろうか？　泊まって良いと言えば、凛生が先にここに来るんじゃないか。
[cpg]

*start

;#################################################
*Ep007|危なっかしい晶菜
;#################################################

[SCENE id=7]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

そんなことを考えつつ……まず、凪をもう泊められないと思った。
[cpg]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Nagi148"]
[OnName num="nagi"]
「どうしてですか……？　私のこと、泊められないって……何か粗相でもしましたか？」
[cpg cn=true]

[OnName num="keigo"]
「いや、粗相とかじゃなくてだな……」
[cpg cn=true]

[free time=1000]
というようなやりとりをしていた朝。
[cpg]

;//[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akina085"]
[OnName num="akina"]
「おじさーん、遊びに来たよ。鍵開けて」
[cpg cn=true]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

;//ブラックアウト
渡りに船というか、何の偶然か晶菜がやってきていた。
[cpg]

しかし、このままじゃ凪と晶菜が鉢合わせることになる。
[cpg]

……そうは思いつつも、鍵を開けないと事態は進まない。そう思い、鍵を開けた。
[cpg]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[FACE method="shake_7" pos="4/5"]
[VOICE f="Nagi149"]
[OnName num="nagi"]
「……そうだったんですね。彼女さんが居たなら、私に言ってくれても良かったんですよ」
[cpg cn=true]

[OnName num="keigo"]
「え？　あ、ああ。そうなんだ」
[cpg cn=true]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Akina086"]
[OnName num="akina"]
「なになに？　何の話？」
[cpg cn=true]

頼むぞ、晶菜。引っかき回さないでくれ。
[cpg]

[OnName num="keigo"]
「俺には、彼女がいるから……だから、帰ってくれ」
[cpg cn=true]

[FACE method="bow_1" pos="4/5"]
[VOICE f="Nagi150"]
[OnName num="nagi"]
「分かりました。お邪魔しました……お幸せに」
[cpg cn=true]

[free time=1000]
凪はかなり諦めが早かった。そりゃそうかとも思う。
[cpg]

彼女がいる中に無理矢理押しかけているとなれば、負い目もあるだろう。
[cpg]

実際は晶菜も一緒なんだけどな……
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Akina087"]
[OnName num="akina"]
「ねぇねぇ、何だったの？　私、泊まっていっていいの」
[cpg cn=true]

[OnName num="keigo"]
「……ああ。昼飯は、何か適当に食っててくれ」
[cpg cn=true]

俺は彼女に多少お金を渡した。そして、少し時間差をつけてから会社へ向かっていく。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

もう凪は居なくなっていた。
[cpg]

ここでまだ近くに居たら気まずいところだが……まあ、居ないならそれでいい。
[cpg]

俺は会社へ向かう。晶菜はなんだって平日のこんな朝早くにやってきたんだ。
[cpg]

俺が相手できないことくらい分かるだろうに。
[cpg]

解せないものを抱えながら、とにかく遅刻しないように向かっていった。
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（昼）******************************************************

[OnName num="colleague"]
「……お前、なんか疲れた顔してないか？」
[cpg cn=true]

[OnName num="keigo"]
「ああ、まあな……色々あるんだ」
[cpg cn=true]

[OnName num="colleague"]
「良くないな。彼女でも作ったらどうだ」
[cpg cn=true]

ちょっと前の俺なら簡単に言うなと怒っていただろうが、今は何とも思わない。
[cpg]

というか、むしろそれで困ってるんだよな……
[cpg]

[OnName num="keigo"]
「彼女か……」
[cpg cn=true]

[OnName num="colleague"]
「そんな虚しそうな顔をするなよ」
[cpg cn=true]

これは虚しいんじゃないんだ。本当に、ただ困ってる顔なんだ。
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

会社での仕事を終えてから、家まで戻る。
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akina088"]
[OnName num="akina"]
「おかえりー」
[cpg cn=true]

と言いながらスマホを充電しながらいじっている。
[cpg]

こっちのことなど見ていない。今時の女の子ということなんだろうか。
[cpg]

[OnName num="keigo"]
;//「……ここに来たって事は、してもいいんだな」
「……まだここに居るって事は、また泊まるんだな」
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Akina089"]
[OnName num="akina"]
「もちろん。うちもそれ目的で来てるし」
[cpg cn=true]

[OnName num="keigo"]
;//「なら……するか」
「なら……家事をしてもらおうか」
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina090"]
[OnName num="akina"]
「えー。お腹空いた。おじさんの手料理、また食べたい」
[cpg cn=true]

前半が本音だろうな。後半は後付けだ。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

というわけで、俺は適当に料理を作って食わせてやった。
[cpg]

何を作っても美味そうに食う。欲求に素直な奴なのだろうと思う。
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina091"]
[OnName num="akina"]
「ふー、満腹。それじゃ……」
[cpg cn=true]

;//それじゃ、しようか。とでも言ってくると思ったが……
それじゃ、皿洗いでもしようか。とでも言ってくると思ったが……
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Akina092"]
[OnName num="akina"]
「ちょっとお腹いっぱいになったから、寝るね。おやすみ」
[cpg cn=true]

[free time=1000]
こいつはどこまでも、自分の欲求に忠実らしい。
[cpg]

[OnName num="keigo"]
「……あのな……俺が泊めるメリットがないだろ」
[cpg cn=true]

そう言っても起きない。暫く俺は待った。
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

待っている内に深夜。もう起きないんじゃないかと思っていたが、むくりと起き上がって、
[cpg]

;//[FACE method="change_7" pos="2/3"]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1000]
[VOICE f="Akina093"]
[OnName num="akina"]
「……ごめん。結構寝ちゃってたかな」
[cpg cn=true]

ごめんと言ったのが意外なくらいだ。晶菜の性格というのはよく分からない。
[cpg]



;//ブラックアウト
;//========================================
;//●ＣＧ（体を倒して、主人公に近づくヒロイン）ev_29
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_29_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sAkina008"]
[OnName num="akina"]
「ご飯のお礼、してなかったね」
[cpg cn=true]


と言って、彼女は俺に近づいてくる。
[cpg]

何をするつもりかと思っていたけど、そう思っている間に唇を寄せられた。
[cpg]

[VOICE f="sAkina009"]
[OnName num="akina"]
「ふふっ。面白い顔してる」
[cpg cn=true]


俺は思わず目を逸らす。今日はすぐには眠れなさそうだ。
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

そして翌朝。目を覚ますと晶菜がきつく俺を抱きしめていた。
[cpg]

振りほどくのに少し時間がかかった。それと同時に、晶菜が目を覚ます。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Akina113"]
[OnName num="akina"]
「んー。まだ眠いのに」
[cpg cn=true]

[OnName num="keigo"]
「なら、俺にくっついて寝るなよ……」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina114"]
[OnName num="akina"]
「いいじゃん。おじさんも嬉しいでしょ？」
[cpg cn=true]

そうかもしれないけどな。でもそれは言わない。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[FACE method="shake_2" pos="2/3"]

そして会社まで向かう。晶菜は手をぷらぷらと振っていた。
[cpg]

[FACE method="change_2" pos="2/3"]

そのときも笑顔だった。笑顔が多い奴だ。
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（昼）******************************************************

会社での仕事は調子が良かった。普段より眠りは浅いはずなのに。
[cpg]

やはり、晶菜が居るからだろうか。
[cpg]

凪がいた時とはやはり少し違う。俺が居て欲しいと思った相手が居るということが大事なのかもしれない。
[cpg]

家に帰れば晶菜が居る。そう思うだけで、普段より少し頑張れる気がした。
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『マンション通路』（夕方）******************************************************

そして家に戻ると……通路でしゃがみこみ、スマホを操作している晶菜が居た。
[cpg]

[OnName num="keigo"]
「何してる。怪しまれるだろ」
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Akina115"]
[OnName num="akina"]
「多分噂にはもうなってるでしょ。何度も出入りしてるし」
[cpg cn=true]

確かにそうだけど、ここを通った人はどう思うだろうな。
[cpg]

この歳の子供を育てているとは思われないだろうから……誘拐を疑われてもしかたない。
[cpg]

[OnName num="keigo"]
「誘拐だって疑われたらどうする」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina116"]
[OnName num="akina"]
「私が弁解したげる。なんとでもなるよ、きっと」
[cpg cn=true]

そうだろうか……少なくとも晶菜の家出はばれるんじゃないか。
[cpg]

いや、彼女にとって家出がばれることはどうなんだ？　それもよく分からない。
[cpg]

そもそも、どういう理由で家出してるんだろう……？
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="keigo"]
「……お前は、どうして家出してるんだ？」
[cpg cn=true]

お腹いっぱいになって、一息ついている晶菜にそう聞いてみた。今はあくびをしている。
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina117"]
[OnName num="akina"]
「えー？　楽しい話じゃないよ。それでもいい？」
[cpg cn=true]

[OnName num="keigo"]
「お前さえ良ければ。是非聞きたい」
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Akina118"]
[OnName num="akina"]
「んーとね、私とお母さん……まあ、家族かな。母子家庭ってやつなんだけど」
[cpg cn=true]

父親は亡くなってるか、いないらしい。そこは深く聞かなかったが……
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Akina119"]
[OnName num="akina"]
「貧乏なんだ。お母さん、体が弱くってさ、私が生活してるだけでもお金がかかるんだ」
[cpg cn=true]

[OnName num="keigo"]
「そんな……尚更、お前は家に居た方がいいんじゃないのか」
[cpg cn=true]

首を横に振る晶菜。仲が良くないのだろうか。
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Akina120"]
[OnName num="akina"]
「ご飯たべるだけでもお金要るでしょ？　私が居ないだけで、お母さんは楽できる……っていうか、私が居るとパンクしちゃうかな」
[cpg cn=true]

そんな話か。彼女が自分の意思で出ているにしろ、自分のために出ているわけではないらしい。
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

晶菜と二人で眠る。充実したような気分と、空虚な気分。どちらもあった。
[cpg]

晶菜の不幸を癒やせていないじゃないか。
[cpg]

そもそも、晶菜のお母さんはまだ不幸なままだし、晶菜もをそれを気にしていることだろう。
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

そんなことを思っているうちに、朝になる。
[cpg]

[OnName num="keigo"]
「……本当にいいのか。俺の所に居て」
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina139"]
[OnName num="akina"]
「くどいなぁ。私が戻ったら、私の分のご飯が必要になるんだよ？」
[cpg cn=true]

[OnName num="keigo"]
「そりゃ、そうかもしれないが……それなら、晶菜が働くとか」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina140"]
[OnName num="akina"]
「もちろん。昼の間、私が何もしてないと思った？」
[cpg cn=true]

まさか。まさかとは思うが……
[cpg]

[OnName num="keigo"]
「別の男の所に行ってたりするのか……？」
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Akina141"]
[OnName num="akina"]
「ま、想像に任せるけどね。私だってお母さんの力になりたいって精一杯頑張ってるわけだし」
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina142"]
[OnName num="akina"]
「……そう簡単に、口出ししないでほしいな」
[cpg cn=true]

[OnName num="keigo"]
「……」
[cpg cn=true]

俺は何も言えなかった。何も言えるはずがない。
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Akina143"]
[OnName num="akina"]
「それよりも、そろそろ仕事なんじゃないの？　行ってきたら？」
[cpg cn=true]

[OnName num="keigo"]
「あ、ああ……」
[cpg cn=true]

俺はそれ以上何も言えなかった。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

それから仕事に向かうが、あまり集中できない。
[cpg]

こうしている間にも、別の誰かの所に行っているのか。
[cpg]

あくまで俺には、家に泊まるためにこびを売ってる。
[cpg]

食費を浮かすために。本当に、なんてことだ……
[cpg]

俺は彼女を助けたいと思うと同時に。
[cpg]

お金さえあれば、彼女はどうにでもなるんじゃないか。そうも思った。
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『マンション通路』（夕方）******************************************************

俺は仕事を終えて家まで戻る。
[cpg]

晶菜は戻っているだろうか。そんなことを思いながら……
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

やはりというか、晶菜は居なかった。俺に全て打ち明けた後だからな。
[cpg]

気兼ねなく外に出られるということなんだろう。
[cpg]

今も、どこかで稼ぎに行っているんだ……
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

俺は飯を作って待った。晶菜は、一般的な夕食くらいの時間になって帰ってきた。
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akina144"]
[OnName num="akina"]
「ただいまー。えへへ、お待たせ」
[cpg cn=true]

[OnName num="keigo"]
「……いや。お前も大変なんだろ」
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Akina145"]
[OnName num="akina"]
「大変とは思ったことないなぁ。お母さんは大変だろうと思うけど」
[cpg cn=true]

[SE f="se000"]
;//【ＳＥ】『食器の音』

[window target=false]
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

そして飯を食っていく。俺は晶菜が帰るまで手をつけずに待っていた。
[cpg]

その事を茶化されながらも、夕食を食べ終える。
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Akina146"]
[OnName num="akina"]
「さて、と。お風呂入ろっか、おじさん」
[cpg cn=true]

[OnName num="keigo"]
「……一緒にか？」
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Akina147"]
[OnName num="akina"]
「うん。うちと一緒に入るの。だめかな」
[cpg cn=true]

[OnName num="keigo"]
「……」
[cpg cn=true]


迷った挙げ句、結局俺はそうしなかった。
[cpg]

晶菜は寂しがっているということはないだろう。それが想像できたから。
[cpg]



;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

そんなことがあった後、またも晶菜と同じ布団で眠る。
[cpg]

晶菜は不幸な少女だというのを知ってしまった。このまま何もせずにはいられない。
[cpg]

お金をちらつかせれば、なんでもしてくれるだろう。それも選択肢としてある。
[cpg]

俺が、するべきことは……なんだろう。
[cpg]

;//■選択肢
[switch]
[case "晶菜を抱きしめる"]
	[swap]
	[jump target="*select05_1"]
[case "お金をちらつかせる"]
	[swap]
	[jump target="*select05_2"]
[endswitch]

*select05_1|
[jump storage="ep008.ks" target="*select05_1"]


*select05_2|
[jump storage="ep009.ks" target="*select05_2"]

１、晶菜を抱きしめる
２、お金をちらつかせる
;//==============================
