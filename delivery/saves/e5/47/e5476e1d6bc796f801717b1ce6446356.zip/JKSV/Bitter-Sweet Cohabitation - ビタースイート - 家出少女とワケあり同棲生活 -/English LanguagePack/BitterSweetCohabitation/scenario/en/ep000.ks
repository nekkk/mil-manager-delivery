
*start

;//家出少女と泊め男　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//凛生　裸　私服　制服
;//晶菜　裸　私服
;//凪　　裸　私服
;//以下音声なし
;//景吾 同僚 女 警察官
;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//凛生　一人称「私」　晶菜呼び「晶菜ちゃん」　凪呼び「凪さん」　景吾呼び「おじさんor景吾さん」
;//晶菜　一人称「私orうち」　凛生呼び「凛生」　凪呼び「凪さん」　景吾呼び「おじさんor景吾」
;//凪　　一人称「私」　凛生呼び「椎名さん」　晶菜呼び「小早川さん」　景吾呼び「景吾さん」
;//景吾　一人称「俺」　凛生呼び「凛生」　晶菜呼び「晶菜」　凪呼び「凪」
;///////////////////////////ここからが本編です///////////////////////////


;#################################################
*Ep000|Runaway Girl
;#################################################

[SCENE id=0]

[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（朝）******************************************************

Every day I wake up early in the morning, finish breakfast, and get dressed.
[cpg]

Once I made it a habit, I am no longer tired. If anything, the indescribable fatigue I felt when I was in college is gone.
[cpg]

As the days go on and on like this, I naturally miss the holidays.
[cpg]

In that sense I think I wasted a lot of my time as a student, but there's no point in regretting it now.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（朝）******************************************************

My job is so-called accounting. It is a job where I have to deal with a lot of numbers.
[cpg]

It is much easier than dealing with people. Even so, it was impossible for me not to face people at all.
[cpg]

I was not good at socializing. I have not had many friends since I was a student.
[cpg]

This naturally meant that I had few conversations related to women.
[cpg]

When I thought about what was missing in my life, I ended up there.
[cpg]

Keigo Sagami. I am not old enough to be in a hurry to get married, but I am still anxious about my future.
[cpg]

Not financially. It's not in terms of work, I do not work at an illegal company.
[cpg]

[OnName num="colleague"]
“What’s wrong? You don't look well.”
[cpg cn=true]

[OnName num="keigo"]
"I'm ...... just having a woman-related ...... problem."
[cpg cn=true]

[OnName num="colleague"]
"Women ..... There should be more women in accounting.”
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（夕方）******************************************************

I am still young. I am in my twenties. Still, time flies.
[cpg]

I've been struggling to meet someone, but there's no hope for ordinary means of doing so.
[cpg]

It is quite recently that I realized that I am not, in short, a manly man.
[cpg]

Even though I have achieved a certain level of social status, women still don't come to me.
[cpg]

I take care of my appearance. I don't think my body shape is that bad.
[cpg]

So what is the problem? All I can think of is that my face does not stand out.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（夕方）******************************************************

Dating apps. There was a time when the mere mention of it gave me goosebumps.
[cpg]

However, I am not popular enough to even be able to rely on it.
[cpg]

I can't help but wonder why. It is more important to take the first step than to think about the reason and do something about it.
[cpg]

But that doesn't mean that I don’t hesitate. Why do dating sites have such an unsettling appearance?
[cpg]

Even if you withdraw from the site, you may be charged a large sum of money later on. Or, maybe there are married women out there who are planning to get your money.
[cpg]

While imagining all kinds of things, I was going through the screen that prompted me to confirm my registration.
[cpg]

It was all happening on my phone. I guess that these days, dating is all done with this small screen.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

I live in an apartment. I feel lonelier than when I lived at home.
[cpg]

However, I'm not sure if having my family around would help with my loneliness.
[cpg]

I have to watch my parents age. That's tough.
[cpg]

With that in mind, I checked the notification from the dating service and found a message......
[cpg]

[OnName num="keigo"]
“What is it.....?"
[cpg cn=true]

There is a contact from a woman who says she wants to meet me right now.
[cpg]

I didn't even take action. How is this possible?
[cpg]

I chose one of them and decided to contact her.
[cpg]

It was not like a phone call. It was through a chat.
[cpg]

She tells me she is in a hurry, that she really wants to meet me, and so on.
[cpg]

I don't mind if she says "I really want to meet you”. But what does "in a hurry" mean?
[cpg]

It's not like he's in a rush or anything. She is in a hurry. What kind of a situation can you imagine?
[cpg]

Am I being deceived somehow? Even the were the case, it's still a strange message.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『街』（夜）******************************************************

So I decided to meet her at the designated place.
[cpg]



After waiting for a while, it started to rain ......
[cpg]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[SE f="se019" loop=true]
;//【ＳＥ】『雨　ポツポツ』

[BG f="b_08_4.ui" time=1000]
[WAIT time=1000]

[window target=true]

What a hassle, I thought….. and the rain was getting harder and harder.
[cpg]

Still holding an umbrella, I waited.
[cpg]

;//========================================
;//●ＣＧ非エロ（雨の中、疲れた表情で歩いてくるヒロイン。傘は差してない）ev_01
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：私服
;//場所　：街
;//時間　：夜
;//備考　：雨が降っています
;//========================================
[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_op"]
[WAIT time=100]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


Someone walked toward me, but ......
[cpg]

She doesn't have an umbrella, and she looks tired. And she is in a school uniform. She is a student.
[cpg]

[VOICE f="Rio001"]
[OnName num="rio"]
"...... Nice to meet you. My name is Rio Shiina."
[cpg cn=true]

[OnName num="keigo"]
"Oh, uh...... I'm Keigo. Keigo Sagami.”
[cpg cn=true]

[VOICE f="Rio002"]
[OnName num="rio"]
“I have nowhere to go....... Uncle, will you let me stay over?"
[cpg cn=true]

I can't accept that when someone suddenly says something like that.
[cpg]

I'm not sure what I should do. She is, in all likelihood, a runaway,.......
[cpg]

[OnName num="keigo"]
"Just to make sure, are you a runaway?"
[cpg cn=true]

[VOICE f="Rio003"]
[OnName num="rio"]
"Yes,...... that's about it. I can't go home.”
[cpg cn=true]

[OnName num="keigo"]
"Well, ...... but ……"
[cpg cn=true]

It's easy to invite her home. It's not too small for two people to live in.
[cpg]

But this is a bit of a cheat as far as dating apps go, isn't it?
[cpg]

Because I don't want to meet someone like this at all.
[cpg]

I'd like to do this and that with ...... young girls, I guess.
[cpg]


;//ブラックアウト

Anyway, I felt bad about leaving her soaking wet, so I decided to head home.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_se"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="keigo"]
"Come on up."
[cpg cn=true]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sRio001"]
[OnName num="rio"]
"Thank you ......, I'll do anything for you ......."
[cpg cn=true]

Anything? I thought to myself. I this some kind of a scam?
[cpg]

First I decided to lend her my shower.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

[OnName num="keigo"]
“This is troubling…..”
[cpg cn=true]

Hold on, am I in a troubling situation right now? I don't know.
[cpg]

This room is a little big for one person. It's big enough for two people.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rio005"]
[OnName num="rio"]
"Thank you for the shower….…”
[cpg cn=true]

She had already changed her clothes. I guess I'll have to wash ...... what she was originally wearing.
[cpg]

I had my own laundry to do. I started the washing machine, wondering if it was okay to wash them together.
[cpg]

[OnName num="keigo"]
"Rio? Why did you run away from home?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio006"]
[OnName num="rio"]
"It's a bit ...... complicated."
[cpg cn=true]

I guess a lot had happened. Well, you wouldn't come to a man's house like this if there was nothing going on.
[cpg]

I don't think she would have even relied on the dating scene in the first place.
[cpg]

[OnName num="keigo"]
“You haven’t had dinner right? I'll make it right now."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Rio007"]
[OnName num="rio"]
"Well, I'll help you. ...... I think I can help you a little bit."
[cpg cn=true]

This feels like we’re a newlywed and it’s embarrassing. I guess I’ll have to think of her as my younger sister.”
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト
And then I made a simple dinner. A simple dinner made of stir-fried vegetables and miso soup.
[cpg]


;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_se"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[SE f="se000"]
;//【ＳＥ】『食器の音』


Even so, she seemed to be enjoying the food.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Rio008"]
[OnName num="rio"]
“Phew. ...... thanks for the food.”
[cpg cn=true]

I think her expression softened a little. It was a good thing.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

That night, I let her sleep on my bed and I slept on the floor.
[cpg]

Rio didn't want to, but in the end I persuaded her.
[cpg]

I can't let a girl sleep on the floor.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

Morning comes. I had to go to work.
[cpg]


Rio is sound asleep, but I have to tell her something, so I wake her up.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
[WAIT time=1000]

[OnName num="keigo"]
"Hey, I'll lend you the key, so please lock the door when you go out to buy lunch or something.”
[cpg cn=true]


[FACE method="shake_5" pos="2/3"]
[VOICE f="Rio009"]
[OnName num="rio"]
"Are you sure.....? What if I’m a thief?”
[cpg cn=true]

[OnName num="keigo"]
“A thief wouldn't say such a thing. There is not much to steal from my room.”
[cpg cn=true]

We sat around the low desk and nibbled on toast for breakfast.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『マンション通路』（朝）******************************************************

[OnName num="keigo"]
"Well, I'm off then.”
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Rio010"]
[OnName num="rio"]
"Have a good day,......and thank you for everything."
[cpg cn=true]

[OnName num="keigo"]
“Don't worry about it. I'm sure you've got your reasons.”
[cpg cn=true]

It's not a bad feeling. To be relied on by someone.
[cpg]

She is a female student. It makes me happy.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

I leave the apartment and walk along the commuting route.
[cpg]

It's the same scenery as usual, but Rio is probably waiting for me at home when I come back.
[cpg]

That makes me feel a little more motivated.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（夕方）******************************************************

And then, work is over. I decided to go home.
[cpg]

[OnName num="keigo"]
"Well, time to go home. Rio is waiting for me."
[cpg cn=true]

I say to myself. I really feel as if I have a little sister.
[cpg]

If not......it was as if I had a lover with an age difference.
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Rio011"]
[OnName num="rio"]
"Oh, ...... welcome back. Uncle."
[cpg cn=true]

The word "uncle" is a little bit gruesome. I'm not that old.
[cpg]

[OnName num="keigo"]
“Do you have any money? Shall I pay for your lunch?”
[cpg cn=true]

[FACE method="shake_5" pos="2/3"]
[VOICE f="Rio012"]
[OnName num="rio"]
“Oh, no! I’d feel bad.”
[cpg cn=true]

[OnName num="keigo"]
“It's okay. It's better than making you skip lunch.”
[cpg cn=true]

Saying this, I handed her a 500 yen coin. I thought Rio would not accept it, but she took it and said ......
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sRio002"]
[OnName num="rio"]
“I don't want to ...... be unable to repay you for being so kind to me.”
[cpg cn=true]


[OnName num="keigo"]
“I really don't mind."
[cpg cn=true]


Just by being able to experience this situation, it's as if I've already been repaid.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

Rather ……I wondered if there was anything I could do to help.
[cpg]


...... She must have some darkness in her, too.
[cpg]

I want to heal it if I can.
[cpg]

;//========================================
;//●ＣＧ（主人公に近づくヒロイン。背後の主人公の姿は消してください）ev_03
;//人物１：ヒロイン１
;//服装１：制服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]

;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

In the evening, she approaches me as I am sleeping.
[cpg]

[VOICE f="sRio003"]
[OnName num="rio"]
「……」
[cpg cn=true]


I say nothing, pretending to be asleep.
[cpg]

[VOICE f="sRio004"]
[OnName num="rio"]
"Thank you for not kicking me out."
[cpg cn=true]


She sees through me faking my sleep and tells me so.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

And then morning comes. It's Saturday.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio056"]
[OnName num="rio"]
“You're not going to ...... work?”
[cpg cn=true]

[OnName num="keigo"]
“Today is an off day..... you've lost your sense of the day."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Rio057"]
[OnName num="rio"]
"Maybe,...... I haven't been to the academy for a long time.”
[cpg cn=true]

I felt bad for her. There would be no meaning for her to go to school  if she ran away.
[cpg]

 After all, if your parents find out that you're at school, that's the end of it.
[cpg]

[OnName num="keigo"]
“So, let's go shopping or something. What should we do? Should I wait for you at home?”
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Rio058"]
[OnName num="rio"]
“No, I'll go with you. I think I can help you.”
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="hidari.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hidari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

So we headed for the supermarket.
[cpg]

Rio was looking around, probably because the streets around here are so unusual.
[cpg]

She must have come from somewhere far, since she was running away.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『スーパー店内』（朝）******************************************************

Then we went shopping.
[cpg]

I would like to buy some pajamas or something for her, but I doubt the supermarket will have them.
[cpg]

I buy daily necessities and food, while thinking that I should go look at another place.
[cpg]

[OnName num="keigo"]
“Is there something you want to eat?”
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Rio059"]
[OnName num="rio"]
“No. Nothing in particular, just whatever you pick out for me.”
[cpg cn=true]

She says something quite cute. Then, I'm free to make my own choice.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『マンション通路』（昼）******************************************************

On my way home, a man who lives in the same apartment building looked at me with a puzzled look.
[cpg]

[OnName num="woman"]
“Hi......."
[cpg cn=true]

[OnName num="keigo"]
“……"
[cpg cn=true]

I couldn't reply. Because it was suspicious.
[cpg]

It looks as if I had kidnapped her. Since she was so young.
[cpg]

But Rio didn't seem to notice. I returned home without saying anything.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************

After having lunch, I relaxed at home for a while.
[cpg]

I had a movie I had recorded and was going to watch it, but ......
[cpg]

I wonder how that would be in the presence of my roommate.
[cpg]

I was going to take her to a shopping mall somewhere, but then that would look like a date.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio060"]
[OnName num="rio"]
"...... Re you trying to be thoughtful?”
[cpg cn=true]

[OnName num="keigo"]
“How do you know? I was thinking of watching a movie.”
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Rio061"]
[OnName num="rio"]
"If it's about me, don't worry about it. Really, I'm just grateful that you're letting me stay here."
[cpg cn=true]

If that's the case, let's do that.
[cpg]


Yesterday I recorded a Japanese suspense film. It was a popular movie, so I guessed it was interesting.
[cpg]

I'm ashamed to say that I can't watch foreign films. I can watch a dubbed movie, but I can't watch a subtitled movie at all.
[cpg]

I can't remember the names of the characters. With that in mind ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

I killed time. A peaceful holiday passes by.
[cpg]

Even though I'm hiding a girl, I don't feel much different from usual.
[cpg]

On the contrary, it evoked a strange sense of immorality.
[cpg]

While I was watching the movie, Rio was also watching the movie, by the time it was over, she was on her phone.
[cpg]

She had also brought a charger with her. She was hesitant to use it at first, but now she doesn't hesitate.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

Then at night. Rio and I cooked dinner together.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Rio062"]
[OnName num="rio"]
"You're a good cook uncle….”
[cpg cn=true]

I've been living on my own for a long time now. I was on my own when I wasn’t in university as well. I didn't cook for myself as much as I do now though.
[cpg]

I didn't need to brag about it, so I just said,
[cpg]

[OnName num="keigo"]
“Well, yeah.”
[cpg cn=true]

And then……
[cpg]

[FADEOUTBGM]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

That night, I was having trouble falling asleep again.
[cpg]

;//========================================
;//●ＣＧ（主人公に覆い被さるヒロイン）ev_04
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_04_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


I pretended to be asleep, but she came on to me more boldly than before.
[cpg]

I thought she was going to kiss me, but she didn’t.
[cpg]

[VOICE f="sRio005"]
[OnName num="rio"]
"...... You smell…… good."
[cpg cn=true]


Perhaps she was distant from the warmth of people for a while.
[cpg]

I don't know what happened, but I could imagine that.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]

...... But I couldn't stay silent for long either.
[cpg]

I opened my eyes and looked at her.
[cpg]

[OnName num="keigo"]
"This kind of a relationship is not good.”
[cpg cn=true]

[FACE method="shake_5" pos="2/3"]

Rio looked surprised. I told her the following.
[cpg]

[OnName num="keigo"]
"Aren't you loosing track of yourself?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio082"]
[OnName num="rio"]
"I'm not. You’re letting me stay here, so it's only natural.”
[cpg cn=true]

[OnName num="keigo"]
“But that's still not healthy.”
[cpg cn=true]

Rio fell silent. I guess she really doesn't want to go home.
[cpg]

I don't have the guts to accept her wholeheartedly. 
[cpg]

[OnName num="keigo"]
“……Could you leave tomorrow?"
[cpg cn=true]

I couldn't help but say so to control myself.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

We remained silent. I lent Rio my bed again at night.
[cpg]

This is the last time. Tomorrow, I will start looking for a decent relationship again.
[cpg]

This unhealthy relationship is over......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

Sunday. I decided to have breakfast with her.
[cpg]

And Rio was packing her bags. She’s really leaving....
[cpg]

No, it's my decision. Why am I being like this.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Rio084"]
[OnName num="rio"]
“If you ...... change your mind, call me again."
[cpg cn=true]

She said and handed me a small note.
[cpg]

It’s not a phone number. It’s not her social media. I’m not familiar with that kind of thing.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Rio085"]
[OnName num="rio"]
"Thanks for your help......."
[cpg cn=true]

She left with a sad, downcast look on her face.
[cpg]

[SE f="se011"]
;//【ＳＥ】『ドア閉まる』
[free time=1000]
[WAIT time=1000]

But this is good. I can't believe I let her stay over without any romantic feelings.
[cpg]

Am I dreaming too much about love? At my age, would I be considered childish for thinking like this?
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

The holidays passed in the blink of an eye, and the boring routine began.
[cpg]


[jump storage="ep001.ks" target="*start"]

;//=============================================================================
