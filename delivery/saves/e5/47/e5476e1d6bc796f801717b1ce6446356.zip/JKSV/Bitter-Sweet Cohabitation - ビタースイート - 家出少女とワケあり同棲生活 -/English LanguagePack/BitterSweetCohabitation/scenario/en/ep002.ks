
*start


;#################################################
*Ep002|世間知らずな少女
;#################################################

[SCENE id=2]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『街』（夜）******************************************************

昼と夜が繰り返される。馬鹿みたいに、時間は早く過ぎていく。
[cpg]

そうこうしている間に、日曜の夜だ……俺は何をしてるんだ。
[cpg]

そんなことを思っていると、嘘みたいに、その子は居た。
[cpg]

;//========================================
;//●ＣＧ非エロ（疲れて壁を背に座り込んでいるヒロイン。大きな鞄を地面に置いている。主人公が近づき、ヒロインは見上げる）ev_09
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：街
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_op"]
[WAIT time=100]
;**【ＣＧ】 ev_09_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


壁を背にして、座り込む少女。
[cpg]

凛生や晶菜より少し年上だろうか。しかし、疲れきって座り込んでいるという感じだ。
[cpg]

これは、もしかして……
[cpg]

[OnName num="keigo"]
「どうした。家出でもしてきたのか？」
[cpg cn=true]

俺が近づくと、その少女は疲れ切った表情のまま、
[cpg]

;//凪の名前を？？？と隠してください
[VOICE f="Nagi001"]
[OnName num="unknown"]
「と、泊めてくれませんか……？　私、一日寝てなくて、その……足も、棒のようですし」
[cpg cn=true]

[VOICE f="Nagi002"]
[OnName num="unknown"]
「お願いします。一晩だけで良いので……お願いします」
[cpg cn=true]

なんて偶然だ。これも運命というやつだろうか。
[cpg]

[OnName num="keigo"]
「名前は？」
[cpg cn=true]

;//ここから凪の名前を表示してください
[VOICE f="Nagi003"]
[OnName num="nagi"]
「浅間 凪（あさま なぎ）です……」
[cpg cn=true]

凪。可愛い名前だな。
[cpg]

[OnName num="keigo"]
「俺は景吾って言うんだ。苗字は相模。良ければ……家に泊まるか」
[cpg cn=true]

頷く凪。俺は彼女を家まで連れて行くことにした。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『マンション通路』（夜）******************************************************

本当に、足をひきずりながら歩いていた。凪は相当疲れているらしい。
[cpg]

昨日寝ていないとも言っていた。どうしたらそんなことになるか……
[cpg]

女の子が、野宿なんてわけにもいかないもんな。その間も、ずっと泊めてくれる相手を探していたのかもしれない。
[cpg]


[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

部屋に辿り着くと、凪はまずこう言ってきた。
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagi004"]
[OnName num="nagi"]
「すみ、ません……少し、寝て良いですか」
[cpg cn=true]

[OnName num="keigo"]
「ああ。いいぞ」
[cpg cn=true]

[free time=1000]

俺が許してやると、すぐベッドに横になり、寝てしまった。
[cpg]

こんなに一瞬で寝てしまうなんて、よほど疲れていたのだろう。
[cpg]

彼女の服や体はよく見ると薄汚れている。洗ってやろうかと思ったが、勝手に着せ替えていいものか分からなかった。
[cpg]


俺はそのまま、床で寝ることにした。
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

そして月曜の朝。まだ凪は眠っていた。
[cpg]

書き置きをしておくか。例のごとく、鍵も残しておくべきだろう。
[cpg]

そして……朝食くらい食わせてやるか。そう思って、作り置きを食べて良いと書き残した。
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『マンション通路』（朝）******************************************************

そのまま、凪はそこに置いてきた。
[cpg]

別に、身の危険があるわけでもない。追われてるわけでもないだろうし、あの場所に居れば身の危険も無い。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（昼）******************************************************

そういうわけで、昼間は普通に仕事をする。
[cpg]

土日はかなりへこんでいたが、凪を連れてきたことで気持ちが少し持ち直った。
[cpg]

仕事は差し支えなく進んでいく。そして……
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『マンション通路』（夕方）******************************************************

帰り道。お礼の手紙だけ残されて、もう凪はいないなんてことになっていたらどうしようと一瞬思う。
[cpg]

どうしても、晶菜のことが思い出されてしまう。
[cpg]

彼女が出て行くと言い出したのは、本当に突然のことで驚いてしまった……
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nagi005"]
[OnName num="nagi"]
「あ、おかえりなさい……景吾さん」
[cpg cn=true]

しかし、彼女はそこにいた。かなりほっとする。
[cpg]

[OnName num="keigo"]
「疲れてたみたいだな。ずっと寝てたぞ」
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Nagi006"]
[OnName num="nagi"]
「お恥ずかしい限りです……その、ありがとうございました」
[cpg cn=true]

凛生と同じ丁寧語。だけど、どこか厳かというか、うやうやしい。
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

街に買い出しに向かう。スーパーへの道のりを歩いて行った。
[cpg]

街中ではまだよかった。それでも、どこか凪はどこかきょろきょろしていたが……
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="hidari.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hidari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『スーパー店内』（夕方）******************************************************

スーパーに入ってから、凪は余計に周りに興味を示した。
[cpg]

[FACE method="shake_5" pos="2/3"]
[VOICE f="Nagi025"]
[OnName num="nagi"]
「こんなに安いんですか……？　これじゃ、利益が得られないと思うのですが」
[cpg cn=true]

[OnName num="keigo"]
「……スーパーに入ったことが無いのか？　こんなもんだぞ」
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Nagi026"]
[OnName num="nagi"]
「そうなのですね。デフレはここまで深刻なものに……」
[cpg cn=true]

ぶつぶつと呟く凪。スーパーに入ったことはなさそうだな。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『マンション通路』（夜）******************************************************

戻る頃にはすっかり夜。凪にも少しだけ荷物を持ってもらった。
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Nagi027"]
[OnName num="nagi"]
「……今日は、社会勉強になりました。あんな場所があるんですね」
[cpg cn=true]

[OnName num="keigo"]
「スーパーのことか？」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
凪は頷く。俺は呆れつつ、多分世間知らずなのだろうと思った。
[cpg]

[FACE method="change_2" pos="2/3"]
心配に思うと共に、こう考えた……
[cpg]

;//■選択肢
[switch]
[case "凪を大切に扱おう"]
	[swap]
	[jump target="*select02_1"]
[case "何か厄介ごとに巻き込まれるかもしれない"]
	[swap]
	[jump target="*select02_2"]
[endswitch]
１、凪を大切に扱おう
２、何か厄介ごとに巻き込まれるかもしれない
;//==============================
;//１、凪を大切に扱おう
*select02_1|世間知らずな少女
[stflag Cha3flg = 1]

凪を大切に扱おう。放っておくと何をし出すか分からない。
[cpg]

世間知らずなんだから、大事に扱ってやるべきだ。
[cpg]

そうじゃなきゃ、また別の男について行きかねない……
[cpg]

;//凪が候補に
[jump target="*select02_3"]
;//==============================
;//２、何か厄介ごとに巻き込まれるかもしれない
*select02_2|世間知らずな少女
凪は、どう考えてもお嬢様だ。そうじゃなければ、それに準ずる何か。
[cpg]

放っておけば警察では無い何かに追われるかも知れない。
[cpg]

そうなる前に、どうにかしないといけないかもしれないな。
[cpg]

;//==============================
*select02_3|世間知らずな少女
;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

俺は適当に料理を作る。その間凪は手伝おうともしなかった。
[cpg]

凛生や晶菜とは違う。多分、台所に立ったことがない。
[cpg]

となると、やはりお嬢様なんじゃ無いかという疑問が拭えない。
[cpg]

[OnName num="keigo"]
「できたぞ。食うか」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Nagi028"]
[OnName num="nagi"]
「ありがとうございます。では、いただきます」
[cpg cn=true]

そして食器の扱いというか、まあただの箸なんだが……持ち方もちゃんとしてる。
[cpg]

どこか身のこなしが高貴な人を思わせるというか。
[cpg]

ここまでくると俺の思い込みも入ってきてると思う。
[cpg]

それでも、素性は分からないまま、生活を共にした。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

その夜、凪は二人で寝ようと提案してきた。
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Nagi029"]
[OnName num="nagi"]
「泊めて貰っている恩があるのに、床で寝かせるなんてできません」
[cpg cn=true]

[OnName num="keigo"]
「でも、女の子を床で寝かせるほど俺も外道じゃない」
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Nagi030"]
[OnName num="nagi"]
「……二人で寝ましょうか？」
[cpg cn=true]

[OnName num="keigo"]
「どうしてそうなる。狭いぞ」
[cpg cn=true]

凪は首を横に振る。そして、
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Nagi031"]
[OnName num="nagi"]
「私は、端の方で寝ていますから。景吾さんは私の事などお気になさらず」
[cpg cn=true]

そうは言われてもな……と思いつつ、そうすることにした。
[cpg]



;//移植のためシーンをカットしています


[jump storage="ep003.ks" target="*start"]


;//=============================================================================
