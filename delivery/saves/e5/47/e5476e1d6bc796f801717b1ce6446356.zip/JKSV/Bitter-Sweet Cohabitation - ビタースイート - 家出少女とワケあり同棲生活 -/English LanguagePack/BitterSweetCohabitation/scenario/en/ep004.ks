

*start

;//１、凛生
*select03_1|Rio, the girl who started it all.


;//ブラックアウト
The girl who started it all. I thought of Rio.
[cpg]

I wanted to get in touch with her again.
[cpg]

I can't let Nagi get in the way of that, so I have no choice but to get her out of here.....
[cpg]



;#################################################
*Ep004|きっかけとなった凛生
;#################################################

[SCENE id=4]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[FACE method="shake_5" pos="2/3"]
[VOICE f="Nagi146"]
[OnName num="nagi"]
“What do you mean ……? Do you hate me now?”
[cpg cn=true]

[OnName num="keigo"]
“I don't hate you. It's just that I can't let you stay over anymore.”
[cpg cn=true]

[OnName num="keigo"]
“I'm going to introduce you to a colleague of mine at work. He's a very timid man, so I don't think he'll do anything.”
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Nagi147"]
[OnName num="nagi"]
“Oh……”
[cpg cn=true]

So, I ended up kicking Nagi out of my house.
[cpg]

I had no choice. Two girls can't stay over at the same time......
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『マンション通路』（朝）******************************************************

Then I decided to head to the office.
[cpg]

I'll have to tell my co-worker what's going on. I thought to myself as I headed out the door.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="hidari.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hidari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（昼）******************************************************

[OnName num="colleague"]
"Oh...... me? I can't do it!”
[cpg cn=true]

[OnName num="keigo"]
“But you're single and you live alone.”
[cpg cn=true]

[OnName num="colleague"]
“There's no way I can do that! I mean I'm happy, but, but..…”
[cpg cn=true]

I think it’s going to work out. I sent Rio a text message during my lunch break.
[cpg]

I just said that I'd like to see her again. With this one sentence, I thought Rio would come to my house.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（夕方）******************************************************

And on my way home. I was thinking, "What if Rio doesn't come now?”
[cpg]

……That will be then. I did what I could.
[cpg]

And I still can't think of anyone else but Rio.
[cpg]

I like Rio. I realized it again.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト
Then, in front of my room. She was there.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rio086"]
[OnName num="rio"]
“Have you changed your mind……uncle?”
[cpg cn=true]

[OnName num="keigo"]
“Well, something like that.”
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

As far as Rio told me, she is still having trouble finding a place to live.
[cpg]

Even if she tries to get a woman to let her stay, that wouldn't benefit the person.
[cpg]

She was not going to stay in the wild, and she was at his wit's end with moving from one house to another.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio087"]
[OnName num="rio"]
“Do I smell bad ……? I haven't been able to shower much.”
[cpg cn=true]

[OnName num="keigo"]
“You can stay here as long as you want. Why don’t you take a shower first.”
[cpg cn=true]

I recommend to her saying so. Rio nodded.
[cpg]

;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

;//そして、夕食を一緒に食べる。順序がおかしくなってしまったが、まあいい。
Then we ate dinner together.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Rio105"]
[OnName num="rio"]
“Why did you have a change of heart. You didn't contact me for a long time.”
[cpg cn=true]

[OnName num="keigo"]
“I couldn't forget about you. Do you understand that?”
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
Rio looked down. I've said something embarrassing, I guess.
[cpg]

What are we going to do now? I could do it as soon as we finish eating.
[cpg]

She’s been waiting for a long time for ......or rather I've been waiting on my own.
[cpg]

[OnName num="keigo"]
“Hey, Rio.”
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio106"]
[OnName num="rio"]
“What is it, Uncle ……?"
[cpg cn=true]

[OnName num="keigo"]
“I'm going to let you stay here. In return, I want you to stay by my side…"
[cpg cn=true]

After saying it in one breath, I kind of regretted it.
[cpg]

That was too direct. And too hasty.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Rio107"]
[OnName num="rio"]
“Of course. If that's what you want.
[cpg cn=true]

But Rio's reply was as simple as that.
[cpg]

[OnName num="keigo"]
“Are you sure?”
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Rio108"]
[OnName num="rio"]
“You are the one that asked. It's fine.”
[cpg cn=true]

[OnName num="keigo"]
“.... I see. I guess so.”
[cpg cn=true]

We finished dinner in silence.
[cpg]


;//ブラックアウト

But I'm sure she knew what I was thinking, even if I didn't say a word.
[cpg]

;//========================================
;//●ＣＧ（ベッドに横たわるヒロイン。主人公が迫るも、何もできない）ev_17
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：パジャマ
;//場所　：主人公の部屋
;//時間　：夜
;//備考　：差分で布団の中を透けさせる感じでお願いします
;//========================================
[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


That night, she was lying in bed and I got close to her.
[cpg]

Rio did not reject me. It seems as if she can see through my loneliness.
[cpg]

[VOICE f="sRio006"]
[OnName num="rio"]
“It's ...... fine. I wanted to return the favor anyway.”
[cpg cn=true]


I knew what she meant by ‘it’s fine’.
[cpg]

But I didn't have the courage to do anything about it.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

And in the morning. I get ready for work.
[cpg]

Rio was still sleeping. I don't need to leave a note.
[cpg]

I left my keys and a 500 yen coin, so she would understand.
[cpg]

She can stay here. I'm sure she’ll know that I'm here.
[cpg]


;//ブラックアウト
[SE f="se011"]
;//【ＳＥ】『ドア開く』

[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

I walk along the morning commute. The scenery is familiar, but it looks very different now.
[cpg]

Rio will be there when I get home. If she was here, I felt like I could endure anything.
[cpg]

But I don't have a job that I can't stand at the moment.....
[cpg]

I just do my job. Even if that is no different than before, something else is.
[cpg]

I felt like my vision was cleaner, or something like that.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『マンション通路』（夕方）******************************************************

Then I head back home using the same path.
[cpg]

I have to go...... shopping. I wonder if Rio will follow me.
[cpg]

I thought about this and tried to call Rio on the intercom.
[cpg]

...... She doesn't pick up. That's right, she's not the owner of the house.
[cpg]

I unlocked the door and called Rio.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rio127"]
[OnName num="rio"]
"Oh, it was you.”
[cpg cn=true]

[OnName num="keigo"]
“I'm going shopping. You want to come with me?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Rio128"]
[OnName num="rio"]
“Yes. I don't know if I can help though.”
[cpg cn=true]

[OnName num="keigo"]
“But you must be bored. It would be some fresh air for you.”
[cpg cn=true]

With these words, I headed to the supermarket with Rio.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="hidari.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hidari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『スーパー店内』（夕方）******************************************************

[OnName num="keigo"]
“You can bring snacks, juice, or anything else you want to buy.”
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio129"]
[OnName num="rio"]
“You're treating me like a child, aren't you?”
[cpg cn=true]

[OnName num="keigo"]
“I'm just kidding. I see parents saying that to their kids often.”
[cpg cn=true]

Although not as much as parent and child, Rio and I are far apart in age.
[cpg]

I wonder how others would see us. Maybe we look like siblings or something.
[cpg]

We don't really look like a couple.....
[cpg]

With these thoughts in mind, we finished our shopping.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（夜）******************************************************

It was getting quite late. We were getting hungry and were thinking about what we should have for dinner.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Rio130"]
[OnName num="rio"]
“With these ingredients, it's either curry or stew……"
[cpg cn=true]

[OnName num="keigo"]
“I can go with either. Both are similar.”
[cpg cn=true]

Talking like that, we walked back to the house.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

Then, after finishing our meal and taking a bath......Rio said,
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio131"]
[OnName num="rio"]
"We're not going to do anything today......?"
[cpg cn=true]

[OnName num="keigo"]
“I’m not going to refuse…… But why do you go to such lengths to stay the night?”
[cpg cn=true]

[OnName num="keigo"]
“Why don't you go back home in the first place?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sRio007"]
[OnName num="rio"]
"Why not?”
[cpg cn=true]

She doesn’t want to tell me. I'll have to ask her about it sometime.......
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

Then, as I was about to go to bed, Rio said this,
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sRio008"]
[OnName num="rio"]
“Doesn't it hurt, sleeping on the floor?”
[cpg cn=true]


[OnName num="keigo"]
“It’s okay.”
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="sRio009"]
[OnName num="rio"]
“I don’t mind sleeping next to you.”
[cpg cn=true]


I replied,
[cpg]

[OnName num="keigo"]
“I'll think about it if you tell me what's going on at your house.”
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio151"]
[OnName num="rio"]
“…… That's not fair.”
[cpg cn=true]

[OnName num="keigo"]
“I can’t do anything about it.”
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

And then it was morning. Rio was awake, so we decided to have breakfast together.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rio152"]
[OnName num="rio"]
“......You said that you wanted to know what's going on at home.”
[cpg cn=true]

[OnName num="keigo"]
“Yea. Are you going to tell me?”,
[cpg cn=true]

I said think that she wouldn’t tell me, but Rio looked at me seriously.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Rio153"]
[OnName num="rio"]
“My dad is a violent person. It’s not related to discipline or anything like that.”
[cpg cn=true]

It sounds like quite a serious story. I ask.
[cpg]

[OnName num="keigo"]
“So, what about your mother?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Rio154"]
[OnName num="rio"]
“She doesn't stop him……. She seems to have given up.”
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Rio155"]
[OnName num="rio"]
“Sometimes he would beat me so hard that I would bleed, in places where people can't see."
[cpg cn=true]

I had a feeling that it was abuse. Not that she had any bruises on her body.
[cpg]

[OnName num="keigo"]
“.....That's tough.”
[cpg cn=true]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Rio156"]
[OnName num="rio"]
“I'm too scared to go back to that house..... so please let me stay there.”
[cpg cn=true]

She said that to me again. I have no intention or reason to refuse.
[cpg]

[OnName num="keigo"]
"Oh no, you're already staying over and ...... I’m not even trying to kick you out."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Rio157"]
[OnName num="rio"]
“Then that’s fine......."
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『マンション通路』（朝）******************************************************

[OnName num="keigo"]
“I'm off then."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Rio158"]
[OnName num="rio"]
“Good luck. Keigo.”
[cpg cn=true]

Rio calls me uncle or Keigo.
[cpg]

I guess she calls me Keigo more often now.
[cpg]

Thinking about this, I headed for the office.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="hidari.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hidari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（昼）******************************************************

What should I do?
[cpg]

......I thought about it once again. How will I treat her?
[cpg]

;//■選択肢
[switch]
[case "I’ll love Rio."]
	[swap]
	[jump target="*select04_1"]
[case "I want Rio to relief my loneliness."]
	[swap]
	[jump target="*select04_2"]
[endswitch]



*select04_1|
[jump storage="ep005.ks" target="*select04_1"]


*select04_2|
[jump storage="ep006.ks" target="*select04_2"]

1. Rio, the girl who started it all.
2. I want Rio to relief my loneliness.
;//==============================
