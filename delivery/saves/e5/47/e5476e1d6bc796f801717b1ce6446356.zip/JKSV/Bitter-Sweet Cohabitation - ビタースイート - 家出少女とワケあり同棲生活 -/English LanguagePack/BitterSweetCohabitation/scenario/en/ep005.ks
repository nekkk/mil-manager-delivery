


;//１、凛生を愛そう
*select04_1|凛生を愛したい



凛生を愛そう。やはり、愛したい。
[cpg]

俺は彼女を純粋な恋愛の対象として見ていた。
[cpg]

彼女に愛されたいとも同時に思う。自分の気持ちに、嘘偽りがなくなっていった。
[cpg]

*start

;#################################################
*Ep005|凛生を愛したい
;#################################################

[SCENE id=5]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（夕方）******************************************************

そして、会社を終えて家まで戻る。
[cpg]

家にはどんな具材が残っていたか。凛生には何を作ってやれば喜ぶだろうか。
[cpg]

そんなことばかり考えてしまう。自分の気持ちがしっかり定まったからだと思う。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="hidari.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hidari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


[FACE method="bow_1" pos="2/3"]
[VOICE f="Rio159"]
[OnName num="rio"]
「おかえりなさい、景吾さん」
[cpg cn=true]

[OnName num="keigo"]
「ああ。ただいま」
[cpg cn=true]

本当に、まるで同棲生活だ。恋人同士にかなり近い状態。
[cpg]

勿論、凛生はどう思っているか分からない。だけど、いつかは俺のことも好きになってほしい。
[cpg]

だから俺は彼女に協力することにした。
[cpg]

[OnName num="keigo"]
「……お前の親について、色々考えてみたんだ」
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio160"]
[OnName num="rio"]
「え……いいじゃないですか。今は、そんな話」
[cpg cn=true]

[OnName num="keigo"]
「学園にも行けないんじゃ大変だろ。だから……」
[cpg cn=true]

[OnName num="keigo"]
「暴力を振るってるその瞬間を隠し撮りするとか、証拠を掴めばいいんじゃないか？」
[cpg cn=true]

何かしらの犯罪にはなるはずだ。抑止力にはなる、と俺は説明していった。
[cpg]

しかし、凛生の顔は曇っている。
[cpg]

[OnName num="keigo"]
「だから、一度警察に行ってみたらどうだ……って、大丈夫か？」
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Rio161"]
[OnName num="rio"]
「それは……できません。私、父のことが好きですから」
[cpg cn=true]

そうか。その気持ちも当然あるよな……肉親なんだ。
[cpg]

それに警察に言われたら困るのはこの状況も同じか。
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

ままならない。ままならぬままに、夜になる。
[cpg]

そして、凛生が俺に迫ってきた。これに応じるかどうか迷う俺が、情けなく思えた。
[cpg]

;//========================================
;//●ＣＧ（主人公に迫るヒロイン）ev_19
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：パジャマ
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


彼女が俺の体に触れると、それだけで耐えられないような感じがする。
[cpg]

[VOICE f="sRio010"]
[OnName num="rio"]
「……優しいんですね。こんなに迫っても、何もしないなんて」
[cpg cn=true]


俺は優しいんだろうか。そんなことはないと思う。
[cpg]

ただ、臆病なだけだ……
[cpg]

そう思って、俺は首を横に振った。
[cpg]


;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

何日かが経って、休日。普段ならすることがないくらいに暇な時間だが……
[cpg]

今なら、凛生と向き合える。そう思って彼女と話すことにした。
[cpg]

朝食の時。俺は凛生にこうたずねた。
[cpg]

[OnName num="keigo"]
「そんな、暴力振るうような親のことをどうして好きなんだ？」
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Rio179"]
[OnName num="rio"]
「だって……そういうものじゃないですか。育ててくれた人でもありますから」
[cpg cn=true]

[OnName num="keigo"]
「……そうだよな」
[cpg cn=true]

分かりきったことを聞いてしまった。この質問じゃだめな。
[cpg]

[OnName num="keigo"]
「それでも警察に言えば、暴力は振るわなくなるかもしれないぞ」
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Rio180"]
[OnName num="rio"]
「何かの罪には問われますよね。どうなるか、分からないじゃないですか……」
[cpg cn=true]

その気持ちも分かる。どうにもならないな。
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Rio181"]
[OnName num="rio"]
「それよりも、景吾さんと行きたい場所があるんです。いいですか？」
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

そう言って連れられた先は映画館。
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Rio182"]
[OnName num="rio"]
「観たい映画があるんです。少女漫画が原作なんですけど」
[cpg cn=true]

[OnName num="keigo"]
「そういう情報はどこから見つけてくるんだ？」
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Rio183"]
[OnName num="rio"]
「最近は、スマホさえあれば。さあ、行きましょう」
[cpg cn=true]

そう言って手を引いてくるが、しかし……
[cpg]

[OnName num="keigo"]
「行きましょうって言うが……チケット代は俺が出すんだろ」
[cpg cn=true]

とは言いつつ、彼女に出せるお金はないのか。
[cpg]

そう思いながら、俺は映画を観ることにした。
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト
映画はなんというか、想像よりずっと暗い映画だった。
[cpg]

別に極限状態にあるとかそういうわけでもないのに、裏切ったり裏切られたり。
[cpg]

最近の少女漫画はこんなか……？　映画でまで人間関係の辛さを描かなくていいじゃないか。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

しかし、凛生は満足げだった。
[cpg]

[OnName num="keigo"]
「お前、少女漫画が好きなのか」
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Rio185"]
[OnName num="rio"]
「はい。結構持ってますよ……でも、今は家には戻れませんけど」
[cpg cn=true]

そうだよな。元々明るい性格の子じゃないんだ。
[cpg]

沢山辛い目にあってから、今のこの状態になってるんだから。
[cpg]

[OnName num="keigo"]
「……本屋にでも行くか」
[cpg cn=true]

俺も多少は気遣ってやるべきなんだろう。そう思った。
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio186"]
[OnName num="rio"]
「良いんですか？　でも……買っても、読めないですよね」
[cpg cn=true]

[OnName num="keigo"]
「俺の部屋に置けば良い。家に戻る気になったら、持って帰れば良い」
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Rio187"]
[OnName num="rio"]
「でも、お金が……」
[cpg cn=true]

[OnName num="keigo"]
「気にしなくていい。さっき、気にしてなかったくせに」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
凛生は少し明るい顔になった。見たい顔になってきた。
[cpg]

;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_yu"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

そして家まで戻ってくる。夕食を二人で作った。
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Rio188"]
[OnName num="rio"]
「ごちそうさまでした」
[cpg cn=true]

こんな何気ない時間も、俺にとっては大切なものだった。
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************

そして、翌日。
[cpg]

日曜日だから今日も休み。昼食を二人で食べていると……
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="sRio011"]
[OnName num="rio"]
「家に帰ってない間、ずっと娯楽がなかったですから。嬉しかったです」
[cpg cn=true]

[OnName num="keigo"]
「何の話だ？」
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Rio232"]
[OnName num="rio"]
「私が、満足してないって……すぐ見抜いたじゃないですか」
[cpg cn=true]

[OnName num="keigo"]
「ああ。それは俺じゃなくても見抜けると思うぞ」
[cpg cn=true]

なんてことを言ってみるが、凛生は熱っぽい視線を向ける。
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Rio233"]
[OnName num="rio"]
「私はこの生活、好きですよ。勿論、景吾さんの事も好きです」
[cpg cn=true]

[OnName num="keigo"]
「……そりゃどうも。不意打ちだな」
[cpg cn=true]

急にこんなことを言ってくるとは思わなかった。俺からしたら本当に不意打ちだ。
[cpg]

何かしらの感情は抱いてくれていると思っていたが、好きだと面と向かって言われた。
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Rio234"]
[OnName num="rio"]
「私、景吾さんと結婚したいです。この生活が続けられるなら」
[cpg cn=true]

飛躍しすぎだ。そんなこと俺も急には受け入れられない。
[cpg]

[OnName num="keigo"]
「お前、ちょっと落ち着いた方がいいぞ」
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Rio235"]
[OnName num="rio"]
「……落ち着いてますよ。私、もう家には帰りたくないです」
[cpg cn=true]

[FADEOUTBGM]
;//[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

;//ブラックアウト

……このままどうなってしまうかは分からない。
[cpg]

凛生の親は俺たちの関係を認めたりはしないだろうし、俺もどこか実感が湧かない。
[cpg]

そして凛生自身も、本当に俺の事を好きなのか……ちゃんと自分で分かってるんだろうか。
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

そんなことを考えているうちに、また平日だ。
[cpg]

仕事が始まる。俺は凛生に手を振った。
[cpg]

[OnName num="keigo"]
「それじゃ、行ってくる」
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Rio236"]
[OnName num="rio"]
「行ってらっしゃい。景吾さん」
[cpg cn=true]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

日々はあっという間に過ぎる。一週間が過ぎるのが早くなった気がする。
[cpg]

どうしてだろう？　やはり、楽しい時間はすぐ過ぎるという理屈だろうか。
[cpg]

まるで学生時代に戻ったかのような気持ちがあった。
[cpg]

彼女の若さに俺も引っ張られてるのかもしれないな。
[cpg]

そして、会社での勤務を終える……
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『スーパー店内』（夕方）******************************************************

スーパーで買い物を済ませる。少し帰りが遅れるが、凛生は心配したりしないだろう。
[cpg]

心配してたとしたら、謝ればいいだけの話でもある。
[cpg]

俺たちの関係には気兼ねがなくなってきたと思う。
[cpg]

まるで本当の家族のようだ……なんて。
[cpg]

俺も気が早いな。凛生のことを言えない。
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_money.ui" method="window_in_0" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

夕食を取って、寝る前。凛生と俺は狭いベッドで二人目を閉じる。
[cpg]

彼女が、俺の方に寝転んで抱きついてきた。
[cpg]

[FG f="CHA01_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Rio237"]
[OnName num="rio"]
「……景吾さんの匂い、好きです……安心する」
[cpg cn=true]

[OnName num="keigo"]
「見ず知らずのおっさんに言って良い言葉じゃないぞ」
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Rio238"]
[OnName num="rio"]
「もう見ず知らずなんて言わせませんよ。ここまできたら、責任とってくださいね」
[cpg cn=true]

;//========================================
;//●ＣＧ（主人公の上にいるヒロイン。キスをする前）ev_22
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_22_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


彼女が体を起こして、俺の上にのしかかってくる。
[cpg]

[OnName num="keigo"]
「……何をするつもりだ」
[cpg cn=true]


俺は察しつつも、距離を置くような事を言った。しかし、
[cpg]

[VOICE f="sRio012"]
[OnName num="rio"]
「何をするって……何でも、させてください」
[cpg cn=true]


そう言って、彼女は体を倒して、俺にキスをしてきた。
[cpg]

;//ブラックアウト

幸せと言うにはいびつであるが、俺にとってはかけがえのないものだった。
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

日々は過ぎていく。そこに無常なものを感じると言うよりは、いつか来る別れの日を恐れていた。
[cpg]

どこかで受け入れきれない。そんな俺に……
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

その日は、唐突に訪れた。
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se003"]
;//【ＳＥ】『玄関のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『マンション通路』（夜）******************************************************

インターホンに呼び出されて、俺は玄関を開ける。
[cpg]

[OnName num="police_officer"]
「相模景吾さん、ですね？」
[cpg cn=true]

[OnName num="keigo"]
「……はい。相模は俺です」
[cpg cn=true]

いよいよか、と思った。別にここでもめることもない。
[cpg]

俺は、警官に凛生を引き渡した。そして、俺もまた警官に連れられていった。
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト
どうしようもない。だって、そうだろ？
[cpg]

こんな狭い部屋で女の子を隠しきるなんてできない。
[cpg]

むしろ今までの日々が、長すぎたくらいだ……
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（夜）******************************************************

俺はどんな罪になるんだろう。やっぱり監禁か？
[cpg]

そんな想像をしていたが、凛生が庇ってくれたのだろう。
[cpg]

彼女を家に泊めたのも、警察に電話しなかったのも、凛生が無理矢理したこと……ということになっているようだった。
[cpg]

実際に、俺は彼女を監禁していない。全て合意の上でしたことだ。
[cpg]

そういうわけで、俺はすぐに釈放されてしまった。
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（朝）******************************************************

いつもの日々が戻る。と言っても、失ったものは多い。
[cpg]

凛生との思い出だけが残った。それが残ったのが、逆に俺にとっては辛い事だった。
[cpg]

俺は前科者になったりもしていない、仕事を失ったりもしていない。
[cpg]

本当に、何もかもが元通り。
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（昼）******************************************************

失ってみると、俺の人生というのはこんなにも平坦で、つまらなくて……
[cpg]

危険のないものだったんだな、と思い知る。
[cpg]

何かを失う恐怖などというのは、もう完全になくなった。
[cpg]

俺にとって凛生以上に、失いたくないものはなかった。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

ドアを開けたら凛生が居るかもしれない。そんな想像をしながら、
[cpg]

[OnName num="keigo"]
「ただいま」
[cpg cn=true]

と、誰も居ない玄関で呟くのが習慣になってしまった。
[cpg]


[window target=false]
[free time=1500]
[BG f="b_05_2.ui" time=1500]
[WAIT time=2100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************

時間は過ぎる。俺は勤めている会社でも後輩や部下を持つようになった。
[cpg]

俺は今でも思い出す。凛生との最後の会話を。
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

凛生が警察に取り押さえられる前。警察が来たことを俺が告げたとき、凛生は深刻な顔をしていた。
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Rio256"]
[OnName num="rio"]
「……そう、ですか」
[cpg cn=true]

[OnName num="keigo"]
「ああ。もうじきにお前も家に帰らなきゃならなくなる」
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Rio257"]
[OnName num="rio"]
「一度家出してしまいましたから。これからは、もっとがんじがらめになると思います」
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Rio258"]
[OnName num="rio"]
「……部屋から一歩も出して貰えないかもしれませんね」
[cpg cn=true]

俺は今でも思い出す。泣きそうになっているあの顔を。
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Rio259"]
[OnName num="rio"]
「だけどいつか大人になったら、また景吾さんのもとに向かいます。絶対です」
[cpg cn=true]

[OnName num="keigo"]
「……そうか」
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

休日の昼。凛生との電話はずっと繋がらない。
[cpg]

親から取り上げられているのだろうということぐらい想像がつく。
[cpg]

それでも待ち続けた。俺は、ずっと……
[cpg]


[SE f="se003"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=1100]

そんな中、インターホンが鳴って、俺は玄関まで向かう。
[cpg]

[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
[window target=true]


歩く途中、なんとなくそのボタンを押したのが誰か分かる。
[cpg]

俺はおじさんと呼ばれていたが、本当におじさんになってしまった。
[cpg]

凛生は今、どんな姿をしているだろう？　どんな表情をしているだろう？
[cpg]

大人になっていることだろう。そして……きっと、笑顔でいることだろう。
[cpg]

[VOICE f="Rio260"]
[OnName num="rio"]
「……ずっと、待たせてしまいましたね。景吾さん……」
[cpg cn=true]


[SCENE id=13]

[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン１ルート１
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//==============================
