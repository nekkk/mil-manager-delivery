

;//２、お金をちらつかせる
*select05_2|晶菜を思うがままにしたい

やはり……お金をちらつかせても、晶菜を思うがままにしたい。
[cpg]

それを晶菜が拒まないことももう分かってしまった。
[cpg]

一度そのことが頭にちらつくと、どんどんと膨らんできてしまった。
[cpg]

きっとこれも愛情なのだと思う。裏返って、歪んでしまっただけで。
[cpg]

*start

;#################################################
*Ep009|晶菜を思うがままにしたい
;#################################################


[SCENE id=9]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina294"]
[OnName num="akina"]
「それじゃ、行ってらっしゃーい」
[cpg cn=true]

[OnName num="keigo"]
「……ああ」
[cpg cn=true]

晶菜は俺が何を考えているか知らない。しかし、そのうち思い知ることになる。
[cpg]

ただ、今はそのときじゃない……晶菜につぎこむ金も、働かなければ稼げない。
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=1000]

そんな考えで、会社に向かっていった。
[cpg]

仕事をしている最中も、晶菜のことが気になってたまらなかった。
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina295"]
[OnName num="akina"]
「おそーい。お腹空いた」
[cpg cn=true]

晶菜は駄々をこねる。別に俺は彼女に料理を作らなくてもいい。
[cpg]

だけど、作ってやるか。ここに居続けてもらうためにも。
[cpg]

[OnName num="keigo"]
「……ああ。ちょっと待ってくれ」
[cpg cn=true]

そして夕食を作り、食べ終える頃に……俺は切り出した。
[cpg]

[OnName num="keigo"]
「なあ。晶菜、お前は金が欲しいんだろ」
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Akina296"]
[OnName num="akina"]
「まあ、そうだね……そのために色々してるわけだし」
[cpg cn=true]

[OnName num="keigo"]
「俺が金をやるから、俺だけのものになれって言ったらどうする？」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Akina297"]
[OnName num="akina"]
「……高くつくよ。でも、その代わりなんでもしてあげる」
[cpg cn=true]

晶菜が提示してきた金額は、俺が払えないものではなかった。
[cpg]

しかし、確実に貯金を食い潰すであろうという程度のもの。
[cpg]

[OnName num="keigo"]
「上等だ。出してやるよ」
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sAkina015"]
[OnName num="akina"]
「そっか。じゃあ一日中、家に居てあげるね」
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1000]
[window target=true]

[BGM f="bg_yu"]
[WAIT time=100]
;//ブラックアウト

;//移植のためシーンをカットしています


俺は彼女を手に入れたという充足感を得ていた。
[cpg]

それと同時に……こんなことで彼女を手に入れたことになるんだろうか？　という疑念も同時に抱いていた。
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

後片付けを終えた後、俺は眠ることにした。
[cpg]

もう晶菜にベッドを貸してやる理由はない。狭いので晶菜は床に寝かせる。
[cpg]

晶菜は、苦しそうにしている風でもなかった。
[cpg]

むしろ何か……満足げにさえ見えたのは気のせいだろうか。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
;/[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

そんな日々が続いていく内に、俺の貯金はどんどん減っていった。
[cpg]

交わる度に金をせびられる。その状態で金が減っていくのは仕方ない。
[cpg]

別に貯金だって、何に使うでもない貯金ではあるのだが……
[cpg]

これ以上減るのは困る。そのくらいの金額になってきた。
[cpg]

それでも、俺は晶菜をつなぎ止めていたかった。
[cpg]

なんとかして、彼女を俺のものにしていたかった……
[cpg]

そして、時間は過ぎていく。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



多分晶菜は、俺が何をしても受け入れるだろう。
[cpg]

ということは、俺なしでは居られない……という状態には、どうしてもならないんじゃないか。
[cpg]

俺はもどかしくなった。俺がしてることは全く無駄なのかと思えてくる。
[cpg]

;//移植のためシーンをカットしています

[FACE method="bow_7" pos="2/3"]
[VOICE f="sAkina016"]
[OnName num="akina"]
「どうしたの？　怖い顔して」
[cpg cn=true]



俺は晶菜に面と向かって言ってやった。
[cpg]

[OnName num="keigo"]
「覚悟しろよ。俺なしじゃ居られなくしてやる」
[cpg cn=true]

[OnName num="keigo"]
「お前をコントロールしてやる。お金なんて要らないって、お前から言わせてやる」
[cpg cn=true]

晶菜は目を丸くした後、笑った。
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Akina357"]
[OnName num="akina"]
「私、お金なしじゃおじさんのものにはならないよ」
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sAkina017"]
[OnName num="akina"]
「仮に酷いことされても、それは私を繋ぐ理由にはならないから」
[cpg cn=true]

晶菜はそう断言した。言ったな。
[cpg]

[OnName num="keigo"]
「……それじゃ、その証拠を見せて貰おうか」
[cpg cn=true]

[OnName num="keigo"]
「俺に何されても平気なんだな？　それなら、何だってできるだろ」
[cpg cn=true]

頷く晶菜。後悔させてやる。晶菜を俺の物にしてやる……！
[cpg]

;//========================================
;//●ＣＧエロ（蝋燭責め。ヒロインは足を開く感じで体を縛られている。次第に快感に変わって絶頂するヒロイン）ev_40
;//人物１：ヒロイン２
;//服装１：裸
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_40_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


俺は躍起になっていたと思う。冷静ではなかった。
[cpg]

それでも、なんとか彼女をつなぎ止めたい。
[cpg]

[VOICE f="sAkina018"]
[OnName num="akina"]
「キス、してくれるの？　こんなのご褒美だよ」
[cpg cn=true]


[OnName num="keigo"]
「……」
[cpg cn=true]


どうしても、操れない。彼女の心の底が読めない。
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

晶菜は相変わらずだ。本当に、あらゆる手段を使ってもつなぎ止められないかもしれない。
[cpg]

お金でしか、彼女を自由にする方法は無いんだろうか。
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『マンション通路』（昼）******************************************************

どんどん貯金は減っていく。このまま無為に過ごしていられない。
[cpg]

底を尽きるところまで行ってしまってはいけない。そのもっと前でやめるしかない。
[cpg]

だけど……俺は晶菜を手放したくなかった。
[cpg]

晶菜。どうしたらお前を俺のものにできる？
[cpg]

俺はどこかで、何か決定的な間違いを犯したんだろうか。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Akina377"]
[OnName num="akina"]
「おかえりー。どうしたの、顔暗いよ」
[cpg cn=true]

[OnName num="keigo"]
「……晶菜、これ以上はお前に金を出せない」
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Akina378"]
[OnName num="akina"]
「ふーん……それで？　そしたら、私は出て行くけど」
[cpg cn=true]

[OnName num="keigo"]
「他に欲しいものはないのか……？　金以外で、何か……」
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Akina379"]
[OnName num="akina"]
「お金以外のものを手に入れるのって、大体お金が要るからね。何もないよ」
[cpg cn=true]

そうか。やはりそれが晶菜の答えか……
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

そして、俺と晶菜は最後の夜を過ごすことになった。
[cpg]

これで俺と晶菜の関係は終わる……認めたくないことだが、仕方がない。
[cpg]

俺は彼女をつなぎ止めるカードが足りなかった。
[cpg]

男としての魅力なのか。それとも、全く別の所で選択を間違えたか。
[cpg]

今の俺には、想像するしかない。
[cpg]

[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
;//移植のためシーンをカットしています


;//ブラックアウト
最後の夜は、二人寄り添って眠った。俺が望んだことだ。
[cpg]

今更こんなことをしてもしょうが無いのに。俺は何をしてるんだ……
[cpg]

そして。朝がやってくる。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[FACE method="shake_1" pos="2/3"]
[VOICE f="Akina397"]
[OnName num="akina"]
「じゃーねー。さようなら」
[cpg cn=true]

最後の挨拶まで、ひょうひょうとしたものだった。
[cpg]

彼女は俺に何の感情も抱いていないようだった……
[cpg]

[OnName num="keigo"]
「ああ……それじゃあな」
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Akina398"]
[OnName num="akina"]
「ん。バイバイ」
[cpg cn=true]

そして、一人の時間が戻ってくる……
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

俺にとって、本当に一人の時間というのは作れないものだ。
[cpg]

性欲が溜まれば、呼び出せる相手が居る。すなわち、凛生。
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rio356"]
[OnName num="rio"]
「……どうして、急に気が変わったんですか？」
[cpg cn=true]

[OnName num="keigo"]
「ああ……ちょっとな」
[cpg cn=true]

俺は晶菜の代わりに、凛生を呼んで気を紛らわせていた。
[cpg]

でも、今も晶菜が誰かの所に居ると想像するとたまらない気持ちになる。
[cpg]

晶菜、どうしてお前は……そこまで俺の心をかき乱すんだ。
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

時間は経つ。何度も昼と夜がやってくる、その間俺は凛生を家に泊めていた。
[cpg]

そしてある日の、夕方のこと……
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio357"]
[OnName num="rio"]
「あ……えっと、おじさん……お客さんが来てますよ」
[cpg cn=true]

[free time=1000]

[OnName num="keigo"]
「え？」
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akina399"]
[OnName num="akina"]
「やっほー。久しぶり、おじさん。そろそろお金貯まった？」
[cpg cn=true]

久しぶりに、晶菜が顔を見せていた。
[cpg]

俺の財布の事情を見て、やってきたらしい。どこまでも、敵わない……
[cpg]

[free time=1000]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="sAkina019"]
[OnName num="akina"]
「さぁ、何しようか？　私のことが恋しかったでしょ」
[cpg cn=true]

俺は、いざなわれるままに……彼女を受け入れた。
[cpg]

どうしようもない蟻地獄に捕まっているのに、気がつきながら……
[cpg]


;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

俺は、自分から捕まりに行った。
[cpg]


[SCENE id=16]

[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン２ルート２
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//==============================
;//==============================
