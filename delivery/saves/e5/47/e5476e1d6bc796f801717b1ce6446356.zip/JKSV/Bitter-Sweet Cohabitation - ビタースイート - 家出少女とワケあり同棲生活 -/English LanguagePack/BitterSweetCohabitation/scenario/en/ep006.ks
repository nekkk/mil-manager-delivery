

;//２、凛生に孤独を癒してもらおう
*select04_2|凛生に孤独を癒してもらう


凛生に孤独を癒してもらおう。恋になんてならなくていい。
[cpg]

一方的に、俺の願いだけを叶えたい。
[cpg]

……例えば、凛生は暴力に怯えているはずだ。
[cpg]

俺も同じ事をしたら、彼女は怯えるんじゃないか。
[cpg]

トラウマが蘇るんじゃないか……というのは、俺の憶測でしかないが。
[cpg]

もしそうなら、何でも俺の思い通りになるはず……
[cpg]

*start

;#################################################
*Ep006|凛生に孤独を癒してもらう
;#################################################

[SCENE id=6]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（夕方）******************************************************

俺は自分の家まで戻ろうとしていた。
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Rio261"]
[OnName num="rio"]
「おかえりなさい、景吾さん」
[cpg cn=true]

[OnName num="keigo"]
「……」
[cpg cn=true]

純粋な笑顔を向けてくる。俺はちょっと戸惑ったが……
[cpg]

だけど、することは決まってる。
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

夕食を食べた後、俺は凛生に迫った。
[cpg]

凛生は嫌がらない。だけど、嫌がったっていい。
[cpg]

多少無理矢理でも、彼女を思うがままにしたい。
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト

俺は暴力をちらつかせて、彼女の行動をコントロールしようとした。しかし。
[cpg]


;//ブラックアウト
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
;//[BG f="b_05_4.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

凛生は俺に頼み込んできた。
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sRio013"]
[OnName num="rio"]
「あ、あの……脅すようなことは、もう、止めて欲しいんですけど……」
[cpg cn=true]

[OnName num="keigo"]
「どうしてだ？　泊めてくれるならなんでもするだろ」
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sRio014"]
[OnName num="rio"]
「それでも、怖いことがあると……どうしても思い出しちゃうんです」
[cpg cn=true]

[OnName num="keigo"]
「思い出してるのはお前が勝手に思い出してるんだ」
[cpg cn=true]

凛生は黙り込む。そして、俯いた。
[cpg]

そのまま、眠りにつく。俺と凛生、同じベッドで眠った。
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

気分良く目が覚める。俺は凛生に何でもしてやれる。
[cpg]

さあ、今日はどうしようか？　そんなことを考えながら、身支度をしていた。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

そして、家を出る。凛生の表情は、少し曇っていた。
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio284"]
[OnName num="rio"]
「あ、あの……行ってらっしゃい」
[cpg cn=true]

それでも、こういうことを言ってくる程度には俺の事を慕ってくれてるんだ。
[cpg]

[OnName num="keigo"]
「ああ。行ってくる」
[cpg cn=true]

別に慕って貰わなくてもいいが、都合が良いと言えば良い。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="hidari.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hidari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

俺は会社まで向かった。今日も仕事だ。
[cpg]

しかし、帰れば凛生が待っている。それまで何をするか考えているだけで幸せだ。
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（夕方）******************************************************

考えているだけで、一瞬で時間は過ぎる。あっという間に仕事を終えた。
[cpg]

俺の言うことを何でも聞く下僕のようなものだ。
[cpg]

ただ家で恋人が待っているとか、そんなことよりも幸せなことかも知れない。
[cpg]

そう思いながら、俺は家まで帰った。
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rio285"]
[OnName num="rio"]
「お帰りなさい……景吾さん」
[cpg cn=true]

[OnName num="keigo"]
「ああ。それじゃ、飯を作るか」
[cpg cn=true]

下僕らしく、こいつに全部作らせても良いけどな。
[cpg]

でも、俺が食いたいものを食えないのも嫌だ。そう思い、自分で料理を作る。
[cpg]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

そして夕食を終えて、風呂に入る前に凛生に切り出した。
[cpg]

[OnName num="keigo"]
「それじゃ、今日は散歩にでも行くか？」
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio286"]
[OnName num="rio"]
「え……散歩って、何ですか？」
[cpg cn=true]

[OnName num="keigo"]
「分かるだろ。嫌だとは言わせないぞ」
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Rio287"]
[OnName num="rio"]
「いえっ……分かりました。行きます」
[cpg cn=true]

理解した上で、凛生はついてくると言ってきた。
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（屋外でヒロインに迫る主人公。ヒロインは嫌がっている）ev_25
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：私服
;//場所　：公園
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_25_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


俺は、公園で彼女に迫った。
[cpg]

見せつけるようにキスしてやろうと思ったが、凛生は嫌がった。
[cpg]

[OnName num="keigo"]
「どうして嫌がる」
[cpg cn=true]


俺がすごむと、彼女は目線を逸らしながら謝った。
[cpg]

[VOICE f="sRio015"]
[OnName num="rio"]
「ご、ごめんなさい……」
[cpg cn=true]



;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『マンション通路』（夜）******************************************************

公園から戻って、部屋の前まで来る。
[cpg]

凛生は、ちょっと辛そうな顔をしていた。
[cpg]

[OnName num="keigo"]
「嫌になったら、俺の家から逃げ出したっていいんだぞ」
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Rio306"]
[OnName num="rio"]
「それは……そんなこと、しません」
[cpg cn=true]

そうだよな。住む家がなくなるのは凛生も困るだろう。
[cpg]

警察に電話するとしたらよっぽど追い詰められたときだ。
[cpg]

彼女の家には暴力を振るうという父親が居るんだからな。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

そして、俺と凛生は風呂に入った後眠りについた。
[cpg]

凛生は普段なら俺と同じベッドで眠るはずが、今日は床で寝ていた。
[cpg]

ささやかな反抗かもしれないが、俺は気にしない。
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


暫く日々が過ぎる。そして、休日だ。
[cpg]

[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

俺と凛生はデートに出ていた。と言っても、優しくするためじゃない。
[cpg]

凛生は怯えている。俺に何を言われるかと思ってるんだろう。
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rio307"]
[OnName num="rio"]
「……その、今日は、何を……」
[cpg cn=true]

俺は答えないままでいた。彼女の中の恐怖は募っていることだろう。
[cpg]


;//移植のためシーンをカットしています

警察に通報したりしても、おかしくない状態だ。
[cpg]

これからは、ちゃんと見張っておかないとな。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

それから何度か、凛生に手を繋がせたり、恋人のような振る舞いをさせたりした。
[cpg]

そして夕方になり、俺たちは家に戻ることにした。
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



家に戻ってきて、一息つく。凛生はまだ緊張が解けないようだった。
[cpg]

[OnName num="keigo"]
「ちょっとトイレ行ってくるから、妙な事は考えるなよ」
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


俺が少しトイレに席を立っていた瞬間だ。
[cpg]

戻ってくると、凛生が携帯電話で誰かと話そうとしていた。
[cpg]

俺は慌てて取り上げる。俺がいない隙に話そうとする相手なんて、限られている。
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Rio330"]
[OnName num="rio"]
「きゃっ……な、何するんですか。携帯、返してください」
[cpg cn=true]

[OnName num="keigo"]
「駄目だ。これは俺が預かる。お前に持たせてたら、警察にでも通報しかねないからな」
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio331"]
[OnName num="rio"]
「そんなこと……しません。本当に、しませんから」
[cpg cn=true]

[OnName num="keigo"]
「口約束なんて信用できるか」
[cpg cn=true]

そう言って、俺は拳を握りしめる。それだけで、凛生は怯えきってしまう。
[cpg]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Rio332"]
[OnName num="rio"]
「ごめんなさいっ！　もう逆らいませんっ、何もしませんから」
[cpg cn=true]

[OnName num="keigo"]
「……それなら、良いけどな。滅多なことは考えるなよ」
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

とは言っても、携帯電話を取り上げたところで、交番に行くぐらいのことはできるだろう。
[cpg]

それかあるいは、自分の家に戻るかも知れない。あるいは、俺以外の誰かの家に向かうとか……
[cpg]

俺はそうなるのが嫌だった。
[cpg]

[OnName num="keigo"]
「……なあ、凛生」
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Rio333"]
[OnName num="rio"]
「何ですか……？」
[cpg cn=true]

俺は彼女から携帯を取り上げた。暇つぶしの道具を取り上げてしまったんだ。
[cpg]

やっぱりこれはやりすぎだっただろうか。でも、あれはどう見ても誰かに電話しようとしていたよな。
[cpg]

もう通報された後かもしれない。なら、したいことをするだけか？
[cpg]

俺は考える。どうするべきか……
[cpg]

……凛生をつなぎ止められるものは何だろう。
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_05_4.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[free time=1000]
[SE f="se003"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=2000]

そんな中、チャイムが鳴らされた。こんな時間に誰だ。
[cpg]

俺は嫌な予感がしつつも、出ないわけにはいかず、出て行った。
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[OnName num="police_officer"]
「……相模景吾さんですね？」
[cpg cn=true]

警官が二人居る。二対一の上に、向こうは俺より体格が良い。
[cpg]

[OnName num="keigo"]
「……はい」
[cpg cn=true]

俺は背後に振り返る。見える場所に、凛生が居る。
[cpg]

これはまずい。そう思いながらも、凛生は助かったというような、安堵の表情を浮かべていた。
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1000]
[WAIT time=1000]

俺は凛生の方に振り返って、たずねる。
[cpg]

[OnName num="keigo"]
「どうしてだ……！　お前、このままじゃ家に帰らなきゃならなくなるぞ」
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Rio354"]
[OnName num="rio"]
「……もう、良いんです。もうどこにも居場所がないって、分かりましたから」
[cpg cn=true]

そこで俺は気がついた。俺が与えなければならないのは恐怖ではなかった。
[cpg]

居場所を、与えなければならなかったんだ……
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Rio355"]
[OnName num="rio"]
「さようなら。おじさん」
[cpg cn=true]

彼女は、俺の事をもう景吾さんとは呼ばなかった。
[cpg]

;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

その後の証言で、凛生は俺のことをかばってくれたらしい。
[cpg]

罪に問われることはなかった。全て合意の上で、ということになってるんだろう。
[cpg]

だけど……凛生が俺のもとに帰ってくることは、ついになかった。
[cpg]


;//ブラックアウト

[SCENE id=14]

[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン１ルート２
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//==============================
;//==============================
