
*start


;#################################################
*Ep003|気になる少女
;#################################################

[SCENE id=3]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『マンション通路』（朝）******************************************************

慣れないことの連続で疲れてしまったのか、いつもより遅い時間に起きた。
[cpg]

急いで外に出る。朝食は抜きだ。
[cpg]

そのまま、俺は会社まで急いだ。遅刻しそうというわけではないが、それでも走った。
[cpg]


[SE f="se020"]
;//【ＳＥ】『走る』

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="hidari.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hidari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（朝）******************************************************

[OnName num="colleague"]
「珍しいな。相模がこの時間に来るなんて」
[cpg cn=true]

[OnName num="keigo"]
「まあ、色々あるんだよ……女の子を泊めてるとな」
[cpg cn=true]

[OnName num="colleague"]
「なっ、まだ泊めてるのか！？」
[cpg cn=true]

[OnName num="keigo"]
「ああいや……なんでもない」
[cpg cn=true]

なんて失言もしながら。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（夕方）******************************************************

朝は昼になり、夕方になる。
[cpg]

家に戻ったらまた凪になにかされてしまいそうだな。そんなことを思いながら。
[cpg]


;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（夕方）******************************************************

……家に帰る途中、歯ブラシが悪くなっていたのを思い出す。
[cpg]

またスーパーに買いに行くか。他に買いたい物もある。
[cpg]

かといって、あまり帰るのが遅くなると凪は心配するだろうか。
[cpg]

手早く済ましてしまおうと思いながら、スーパーに向かった。
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『スーパー店内』（夕方）******************************************************

[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Nagi049"]
[OnName num="nagi"]
「あ」
[cpg cn=true]

[OnName num="keigo"]
「あ」
[cpg cn=true]

と思っていたら、凪がそこに居た。
[cpg]

[OnName num="keigo"]
「……こんな所に何しに来た？」
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagi050"]
[OnName num="nagi"]
「あまりにカルチャーショックでしたから……もう一度確認しておきたくて」
[cpg cn=true]

[OnName num="keigo"]
「お前って、相当なお嬢様か何かか？」
[cpg cn=true]

凪は少し暗い表情をした。どうしたんだろう。
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Nagi051"]
[OnName num="nagi"]
「……お嬢様なんて良い物じゃありません。籠の鳥です」
[cpg cn=true]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『マンション通路』（夕方）******************************************************

さておき、買い物を済ませて家まで戻った。
[cpg]

[OnName num="keigo"]
「籠の鳥か。自由な時間が無いとか、そんな話か？」
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Nagi052"]
[OnName num="nagi"]
「……はい。その言葉だけでは済みませんが、そんなところです」
[cpg cn=true]

何か決定的に家をでるきっかけになった出来事はあるのだろう。
[cpg]

それにしても、そんな裕福な家庭に育っても家出なんてあるんだな。
[cpg]

俺だったら考えられない……なんて発想しても意味は無いか。
[cpg]

男と女で違う所もある。年齢だってかなり違う。
[cpg]

俺の家庭は平々凡々なものだ。考えるだけ無駄だな。
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[SE f="se000"]
;//【ＳＥ】『食器の音』

そして、凪と夕食を食べることにした。
[cpg]

今日も凪は手伝おうとしなかった。そういう発想そのものがないのだろう。
[cpg]

お嬢様ともなると、母親が料理を作っていないかもしれない。
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Nagi053"]
[OnName num="nagi"]
「ごちそうさまでした……景吾さん、本当に料理がお上手なんですね」
[cpg cn=true]

お上手。そんな言い方にもちょっと引っかかる。
[cpg]

丁寧すぎるというか、そんな感じが前からしていた。
[cpg]
;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

少し時間が経って、俺は眠ることにした。昨日から引き続き、二人で狭いベッドに眠る。
[cpg]

凪の体温とか、息づかいを感じ取る。
[cpg]

俺はふと考える。このまま、凪とずっと一緒に居るのだろうかと。
[cpg]

凛生とは連絡先を知っている関係だ。
[cpg]

晶菜はそうではないが……それでも、会いたいと思えば凛生づてに何かできるかもしれない。
[cpg]

凪は、今まさにここに泊まっている。彼女を大事にすることも、もちろんできるだろう。
[cpg]

俺は考えた。誰のことが一番気になっているか……
[cpg]

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*bun12"]
[endif]
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*bun13"]
[endif]

;//凛生のみ
[switch]
[case "凛生"]
	[swap]
	[jump target="*select03_1"]
[endswitch]

[jump target="*select03_1"]

*bun12|気になる少女
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*bun123"]
[endif]

[switch]
[case "凛生"]
	[swap]
	[jump target="*select03_1"]
[case "晶菜"]
	[swap]
	[jump target="*select03_2"]
[endswitch]

*bun13
[switch]
[case "凛生"]
	[swap]
	[jump target="*select03_1"]
[case "凪"]
	[swap]
	[jump target="*select03_3"]
[endswitch]

*bun123|気になる少女
;//■選択肢
[switch]
[case "凛生"]
	[swap]
	[jump target="*select03_1"]
[case "晶菜"]
	[swap]
	[jump target="*select03_2"]
[case "凪"]
	[swap]
	[jump target="*select03_3"]
[endswitch]

*select03_1|気になる少女
[jump storage="ep004.ks" target="*select03_1"]

*select03_2|気になる少女
[jump storage="ep007.ks" target="*select03_2"]

*select03_3|気になる少女
[jump storage="ep010.ks" target="*select03_3"]

１、凛生
２、晶菜
３、凪


;//※ここまでの候補になっているヒロインから選択
;//※ヒロイン１は必ず候補になっている
;//※一人しか候補が居ない場合固定されそのまま進む
;//==============================
