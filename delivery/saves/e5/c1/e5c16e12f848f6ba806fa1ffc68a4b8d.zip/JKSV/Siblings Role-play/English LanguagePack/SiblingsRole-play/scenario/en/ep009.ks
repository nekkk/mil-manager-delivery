

*start



;//==============================
;//２、麗奈


;#################################################
*Ep009|I can't betray Rena-senpai
;#################################################


*select04_2|I can't betray Rena-senpai.

[SCENE id=9]




[OnName num="yuma"]
......After all, I can't betray my senpai, can I?"
[cpg cn=true]


I realized my feelings.
[cpg]


That I love my seniors the most. I am now unshakably convinced.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************



[SE f="se011"]
;//【ＳＥ】『歩く』





In the morning, I headed to the school.
[cpg]


I'm sorry to tell you this, but the one I really like is my senpai.
[cpg]


If I don't confess my love here, I will regret it for a long time.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]


I was going to officially confess my feelings to my senior, so I was talking to her.
[cpg]


After school, in this classroom. That's all I told her.
[cpg]


After all, it was as if senpai had already confessed to me. ......
[cpg]


I'm sure my senpai is feeling a little impatient. I can't make him wait any longer.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina076"]
[OnName num="reina"]
"...... understand. I'll wait for you.
[cpg cn=true]


[OnName num="yuma"]
I'll be waiting for you. Just wait a little longer.
[cpg cn=true]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_og"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





After school. It was just me and my senior.
[cpg]


I thought about what to say to him, but I forgot about it when he arrived.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina077"]
[OnName num="reina"]
I thought about what to say to him, but when he arrived, I forgot about it. What do you want ......?
[cpg cn=true]


[OnName num="yuma"]
Well, ......, it's about my feelings.
[cpg cn=true]


The first thing you need to do is to make sure that you have a good idea of what you're getting yourself into.
[cpg]


;//========================================
;//●ＣＧ（前のめりに、主人公に詰め寄るヒロイン）ev_53
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================
;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_53_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[wait time=1000]

[VOICE f="Reina078"]
[OnName num="reina"]
I'm still on the fence about ......."
[cpg cn=true]


She pressed closer to me, demanding an answer. I nodded back.
[cpg]


[OnName num="yuma"]
I nodded back, "Senpai, I like you too. I like you, too.
[cpg cn=true]



[VOICE f="Reina079"]
[OnName num="reina"]
I see.
[cpg cn=true]


[OnName num="yuma"]
I feel like I've taken a detour so far, but I'm still ...... in love with you.
[cpg cn=true]


Senpai almost cries as he hugs me.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています



;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_ni"]
;//[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


[FG f="CHA02_p5_03_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Reina080"]
[OnName num="reina"]
"Hey," she said, "please give me a hug. Please, give me a hug from you too."
[cpg cn=true]


[OnName num="yuma"]
......Yes."
[cpg cn=true]


Looking at her earnestness, I could not leave her alone.
[cpg]

;//========================================
;//●ＣＧ（仰向けのヒロイン）ev_54
;//人物１：ヒロイン２
;//服装１：制服（はだけ）
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_54_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


The two of us were alone in the classroom. I complied with her request.
[cpg]

I hugged her. And ......
[cpg]

I kissed her as she closed her eyes.
[cpg]

[VOICE f="Reina081"]
[OnName num="reina"]
I kissed her, "I'm ...... so happy. This is like a dream.
[cpg cn=true]


Neither she nor I will ever forget this moment.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************





[OnName num="yuma"]
......I'm home.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu105"]
[OnName num="chinatsu"]
You're late, Yu-kun. What's wrong?"
[cpg cn=true]


I thought I had to report it to Chinatsu and Koyuki someday.
[cpg]


But you never know what will happen by saying it.
[cpg]


[OnName num="yuma"]
I was scared.
[cpg cn=true]

[free time=1000]


I was scared and decided not to tell my sisters for a while.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Koyuki182"]
[OnName num="koyuki"]
I was scared and decided to keep quiet to my sisters for a while. You're back late.
[cpg cn=true]


[OnName num="yuma"]
Koyuki, you say the same thing. ......
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_og"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





I think about it in my room alone. How should I tell my sisters?
[cpg]


In particular, he has had a relationship with Sister Koyuki.
[cpg]


The best way to do that is to tell them how you feel about it.
[cpg]


[OnName num="yuma"]
I'm sure it would be the same no matter who I chose.
[cpg cn=true]


If I had chosen Koyuki, I probably would have thought the same thing about my senpai.
[cpg]


In the first place, I like senpai. There's no way that would have happened if I had.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





On the way to the school. Today, too, I met with Ms. Nanano.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano040"]
[OnName num="nanano"]
Good morning. It's warm again today.
[cpg cn=true]


[OnName num="yuma"]
Good morning, ......, Ms. Nanano.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano041"]
[OnName num="nanano"]
Did something happen to make you happy?
[cpg cn=true]


[OnName num="yuma"]
What?"　You look like that ......?"
[cpg cn=true]


I thought I was distressed just now, but would I have naturally made that face?
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano042"]
[OnName num="nanano"]
Have you got a girlfriend, by any chance?
[cpg cn=true]


[OnName num="yuma"]
I'm sure you know exactly what I'm talking about. It's just like that.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano043"]
[OnName num="nanano"]
I see. I envy you.
[cpg cn=true]


What does that mean? If you mean you're jealous of my girlfriend, that's a little different.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano044"]
[OnName num="nanano"]
But your sisters are going to be jealous.
[cpg cn=true]


[OnName num="yuma"]
"......, that's right."
[cpg cn=true]


In fact, I could imagine that Chinatsu's sister, but Koyuki's sister is jealous.
[cpg]


Makes me think again. What can I do to help......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





And after finishing class at the school. I was walking home with my seniors.
[cpg]


We were both going home in different directions. But we were walking together. ......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





In short, this is what happened. I was walking to my senior's house.
[cpg]


I had just confessed my feelings to her, and we were both feeling a little awkward.
[cpg]

But there was an atmosphere of happiness, or something like that.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina082"]
[OnName num="reina"]
I said, "...... I'll make you some tea. I'll be back in a minute.
[cpg cn=true]




;//========================================
;//●ＣＧ（お茶を入れようとする途中、振り返っているヒロイン。）ev_56
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_56_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


By the way,...... she is a beautiful person, isn't she?
[cpg]

 As I was staring at it, she suddenly turned around.
[cpg]

[VOICE f="Reina083"]
[OnName num="reina"]
She said, "......Where are you looking?
[cpg cn=true]


[OnName num="yuma"]
I'm not looking.
[cpg cn=true]


 It's too late even if you hesitate and look away.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


;//ブラックアウト

[FG f="CHA02_p3_03_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_10_3.ui" time=1000]
[WAIT time=1000]

;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************


[VOICE f="Reina084"]
[OnName num="reina"]
I'm sorry. I can't seem to control myself.
[cpg cn=true]


[OnName num="yuma"]
What?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Reina085"]
[OnName num="reina"]
I really don't mind being seen. I'm probably too conscious of it.
[cpg cn=true]


The first time I saw him, I was a little awkward with my senpai. ......
[cpg]


I was still feeling awkward, and it was time for me to go home.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************



[SE f="se001"]
;//【ＳＥ】『ドア閉まる』





[OnName num="yuma"]
I'm home.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Koyuki183"]
[OnName num="koyuki"]
It's late. What time do you think it is?
[cpg cn=true]


I returned home and was immediately worried by Koyuki's sister. Or rather, she just scolded me. ......
[cpg]


[OnName num="yuma"]
I was just hanging out with a friend.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki184"]
[OnName num="koyuki"]
Who is this friend?　Who's your friend?
[cpg cn=true]


[OnName num="yuma"]
"It's not a girl. ...... it's a guy. It's a guy. Don't worry about it.
[cpg cn=true]


I lied. I didn't know what would happen if I told the truth.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





And soon dinner. ...... Koyuki still seemed suspicious of me.
[cpg]


It is difficult to avoid suspicion. I had to cover up my suspicions.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





The next morning. I finished my morning preparations and headed to the school.
[cpg]


Will I be doing it again with my senpai? I don't know. ......
[cpg]


But my body won't be able to handle it if I keep doing what I did yesterday for days on end.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina086"]
[OnName num="reina"]
I've been thinking about it since then,....... I've been thinking about how I can control me.
[cpg cn=true]


[OnName num="yuma"]
What are you talking about?"
[cpg cn=true]


She said it was about the other day about being too aware of me.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Reina087"]
[OnName num="reina"]
'There's something I want you to look at: .......'
[cpg cn=true]


She hands me a small note. I take it.
[cpg]


In short, it's about getting down to the business of being a student ...... studies. The idea is to decide whether or not to stay with you based on your test scores.
[cpg]

The proposal was that we would only socialize when I or a senior got a good score on a quiz.
[cpg]


He said that he would be able to get the distance I wanted while devoting himself to his studies to a certain extent.
[cpg]


[OnName num="yuma"]
This is just like ......."
[cpg cn=true]


The first thing that comes to my mind is that it's just like playing lovers proposed by Chinatsu-sis, but I don't say it out loud.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina088"]
[OnName num="reina"]
As if, what?"
[cpg cn=true]


[OnName num="yuma"]
Uh-uh. I'll do it. I'll study hard too."
[cpg cn=true]






;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



The next day.
[cpg]


The next day. The next day, we brought in the answer sheets for the quiz.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]

[OnName num="yuma"]
I brought the answer sheets for the quiz to .......
[cpg cn=true]


Neither of us got a perfect score. That's right, that's how quizzes are supposed to be.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Reina089"]
[OnName num="reina"]
At least get a perfect score for Yuma. ......
[cpg cn=true]


[OnName num="yuma"]
Even if you say so,......, you can't suddenly become smart.
[cpg cn=true]


The days continued to be frustrating like that for a while.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_og"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





But one day. One day, however, a senior finally got a perfect score.
[cpg]


I was promised that I would stay with him for the rest of the day.
[cpg]


;//移植のためシーンをカットしています


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina090"]
[OnName num="reina"]
He said, "......You've been holding back until now, so I'm going to like you even more."
[cpg cn=true]



I didn't feel bad when he said that, but ......
[cpg]

But if it's true, I should be able to get a perfect score too.
[cpg]


;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d2"]
;//[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





We had such a conversation and we parted.
[cpg]


Somehow, I don't think much has changed.
[cpg]


But still, he was no longer coming on to me endlessly.
[cpg]


Thinking that this might be a good distance for us, we followed the rules we had set ourselves.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





Days passed by. There were no tests on holidays, of course.
[cpg]


[OnName num="yuma"]
"I can't have ......."
[cpg cn=true]


I muttered to myself. Then I heard a voice behind me.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki185"]
[OnName num="koyuki"]
"What are you talking about?"
[cpg cn=true]


[OnName num="yuma"]
"Oh my God, ...... sister, you're here."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki186"]
[OnName num="koyuki"]
Yuma is acting strange these days. He's kind of absentminded."
[cpg cn=true]


[OnName num="yuma"]
I don't know.
[cpg cn=true]


I could not reply anything as I know the reason myself.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夕方）******************************************************





Having nothing to do, I went to my room to study.
[cpg]


I could have met with my senpai now, but if I followed the rules we had set, we wouldn't be able to touch each other even if we met.
[cpg]


That would be hard for him and hard for me.
[cpg]


Then I thought I should study now. ......
[cpg]



;//立ち絵を表示しないでください






[VOICE f="Koyuki187"]
[OnName num="koyuki"]
"...... see? All you do is study."
[cpg cn=true]



[VOICE f="Chinatsu106"]
[OnName num="chinatsu"]
I know. ...... what's going on?"
[cpg cn=true]


My sisters are peeping at me.
[cpg]


Well, I guess I just have to not worry about this. ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





Then the next weekday, Monday.
[cpg]


In morning class, we both got perfect scores on our quizzes.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina091"]
[OnName num="reina"]
'...... can't wait to see you after school.'
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Reina092"]
[OnName num="reina"]
'I've been holding out on you for so long. I've been holding out on you for a long time.
[cpg cn=true]


[OnName num="yuma"]
I've been holding back for a long time, too. I've been holding out for a long time too.
[cpg cn=true]


After all, this is also something similar to playing lovers.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





Then after school ...... people disappear from the classroom.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Reina093"]
[OnName num="reina"]
The first thing you need to do is to get a good idea of what you're looking for. Yuma, fill me up."
[cpg cn=true]



I nod and move closer to her. I kiss her......
[cpg]

Somewhere, I felt the energy of frustration.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//移植のためシーンをカットしています



Senpai's feverish eyes are on me.
[cpg]


If we do anything more than that here, there will be no rules, no nothing.
[cpg]


We left the school without doing anything more.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki188"]
[OnName num="koyuki"]
I said to him, "...... Yuuma. I don't think he's interested in playing lover these days."
[cpg cn=true]


[OnName num="yuma"]
Oh, ah,...... yeah, well,......."
[cpg cn=true]


I couldn't respond right away. I'm not sure what to say, but I'm sure you'll be able to find a way.
[cpg]


[OnName num="yuma"]
After all, Koyuki is my sister, even if she's my sister-in-law. ......
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki189"]
[OnName num="koyuki"]
...... so."
[cpg cn=true]


Koyuki's sister is snickering. And ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki190"]
[OnName num="koyuki"]
I was asked, "Why are you studying so hard?"
[cpg cn=true]


I was asked this question, and I couldn't answer it either.
[cpg]


[OnName num="yuma"]
I want to go to a good school.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Koyuki191"]
[OnName num="koyuki"]
I know you don't want to go to school. I know that.
[cpg cn=true]


Saying so, Koyuki takes out a folded memo from her pocket. It is ......
[cpg]


[OnName num="yuma"]
......You went into my room without permission?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki192"]
[OnName num="koyuki"]
I felt bad about it, but I had to check it out. I felt bad, but I'm glad I checked.
[cpg cn=true]


The paper with the rules written on it was in my sister's hand.
[cpg]


I couldn't throw it away, so I kept it in a safe place. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki193"]
[OnName num="koyuki"]
I'm sure it's Rena, right?　I can't think of any other girl in the school that I'm close with.
[cpg cn=true]


Once, Koyuki met with her seniors.
[cpg]


I mean, what Koyuki is saying is totally true. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki194"]
[OnName num="koyuki"]
It's terrible. You could have told me."
[cpg cn=true]


[OnName num="yuma"]
"...... sorry ......"
[cpg cn=true]


Silence. Sis seemed quite shocked.
[cpg]



[jump storage="ep010.ks" target="*start"]


