

*start|



;#################################################
*Ep003|playing lovers
;#################################################

[SCENE id=3]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夜）******************************************************





But one day. One night, Koyuki called me to her room.
[cpg]


Chinatsu was there too. She looked mysterious.
[cpg]


The three of us were sitting there, hardly speaking. Koyuki was the first to open her mouth.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Koyuki042"]
[OnName num="koyuki"]
I'll put it simply. Chinatsu doesn't think our relationship is good as it is.
[cpg cn=true]


[OnName num="yuma"]
...... I'm sure she doesn't.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki043"]
[OnName num="koyuki"]
If all you do is accept Yuma's feelings, you won't be able to stop them.
[cpg cn=true]


Koyuki looked at Chinatsu. Chinatsu nodded.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chinatsu018"]
[OnName num="chinatsu"]
But if I stop altogether, that's going to ...... warp it.
[cpg cn=true]


I see. Chinatsu-sis doesn't think it can be stopped completely either.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chinatsu019"]
[OnName num="chinatsu"]
I don't have any good ideas either.
[cpg cn=true]


[OnName num="yuma"]
I don't have any good ideas either. I don't have any ideas either.
[cpg cn=true]


I can't do anything about it. The silence continued.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chinatsu020"]
[OnName num="chinatsu"]
I should probably talk to my mom and dad about it.
[cpg cn=true]


[OnName num="yuma"]
That's ......."
[cpg cn=true]


Eventually it will. But I also want to solve our problems ourselves.
[cpg]


That's probably what Koyuki's sister thinks as well.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
;//[t_move pos=C 下礼]

[VOICE f="Koyuki044"]
[OnName num="koyuki"]
I think so."
[cpg cn=true]


[FO pos="1/2" time=800]
I'm sure you're thinking the same thing. She took out some cardboard and was cutting it with scissors.
[cpg]


She was writing something on it with a pen. I looked up at her gesture.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki045"]
[OnName num="koyuki"]
How about this?
[cpg cn=true]


There was a piece of cardboard with the words "loyalty card" written on it.
[cpg]


Really, it looked like the kind of loyalty card you might get at a small store.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chinatsu021"]
[OnName num="chinatsu"]
What is this?　Sis.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Koyuki046"]
[OnName num="koyuki"]
I guess so. If I had to name it, I'd call it a ...... point-based lover's game.
[cpg cn=true]


[OnName num="yuma"]
"What? ......?　What are you talking about?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki047"]
[OnName num="koyuki"]
You get points when Yuma helps me with my chores or listens to me.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Koyuki048"]
[OnName num="koyuki"]
On the other hand, Yuma can only be my girlfriend for as long as he uses these points. ......
[cpg cn=true]


I gradually understood. It's a way to keep me in check, so to speak, but it's also a way to ...... keep me in check.
[cpg]


I was also a bit of a tease, in the typical Koyuki way.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="Chinatsu022"]
[OnName num="chinatsu"]
"That's so like you, ...... sister. Do you think about these things on a regular basis?"
[cpg cn=true]


Koyuki shakes her head. It seems it was just an idea.
[cpg]


[OnName num="yuma"]
The first thing to do is to make sure that you have a good idea of what you want to do.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chinatsu023"]
[OnName num="chinatsu"]
I guess it's better than ...... not having anything decided.
[cpg cn=true]


Chinatsu-san thinks with a depressed look on her face. She probably wants to stop doing this.
[cpg]


But she also said she can't stop it completely.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki049"]
[OnName num="koyuki"]
I'm going to go to the next step and try to get a hold of her. Yuma, please keep up the good work. ...... now that Chinatsu's permission has been granted."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="Chinatsu024"]
[OnName num="chinatsu"]
"......Uh, yeah......."
[cpg cn=true]


The two of them are the first to be in the same room together.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





That is why I started helping Koyuki sister with her housework. The next morning.
[cpg]


In the meantime, I started making my own lunch.
[cpg]


[OnName num="mother"]
I wonder if it's going to ...... snow today that Yuma is cooking.
[cpg cn=true]


[OnName num="yuma"]
I'm in the mood today."
[cpg cn=true]


If it's this blatant, I wonder if my mom will find out. This is the pattern I want to avoid the most.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki050"]
[OnName num="koyuki"]
I've been saying for a while now, 'Why don't you make your own?'
[cpg cn=true]


But Koyuki was also very considerate and followed up with me.
[cpg]


[OnName num="mother"]
"Really?　Is that so?
[cpg cn=true]


I couldn't take out my loyalty card while Mom and Dad were looking at it.
[cpg]


I was not going to give it out while my mom and dad were watching me.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I headed to the school. Ms. Nanano told me that my complexion had improved somewhat.
[cpg]


After class, I returned home. Then, he goes back to do what his sister says: ......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夕方）******************************************************





I go do the shopping my sister asked me to do and come back.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki051"]
[OnName num="koyuki"]
Yuma is so blatant,...... I don't even know if your father or mother finds out."
[cpg cn=true]


Inside the frame of the loyalty card, Sis draws a small illustration. Is this a bear?
[cpg]


[OnName num="yuma"]
But, because ...... you'll give it to me if I accumulate enough points, right?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki052"]
[OnName num="koyuki"]
I don't know," she said. "Shopping is almost like exchanging money for money. This doesn't make sense.
[cpg cn=true]


[OnName num="yuma"]
'Maybe so, but ......
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************





The living room after dinner. Rubbing her shoulders from behind her sister who is sitting in a chair.
[cpg]


[OnName num="mother"]
'...... Really, what's wrong with you?　I'm not sure if Yuma and Koyuki had a fight or not.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu025"]
[OnName num="chinatsu"]
Come on, come on,......."
[cpg cn=true]


The actuality that you can find a lot more than one of the most popular types of shoes and boots, you can find a lot more than one of the most popular types of shoes and boots.
[cpg]


My mother was also skeptical, but I thought it could not be helped.
[cpg]





;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Days go by. Today, I made my own lunch again.
[cpg]


Frozen foods are running out fast. It can't be helped. ......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





I've been spending an agonizing amount of time at the school.
[cpg]


I've been in an awkward relationship with a senior since then.
[cpg]


Of course, it doesn't mean that we have lost contact,...... with seniors, we even have dinner together.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina042"]
[OnName num="reina"]
The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it. It's become more frugal.
[cpg cn=true]


[OnName num="yuma"]
I've been trying to make it myself lately. I've been trying to make my own lately.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina043"]
[OnName num="reina"]
I see. ......
[cpg cn=true]


[OnName num="yuma"]
Yeah. ......
[cpg cn=true]


I spend time with my seniors in an awkward atmosphere, but no progress is being made.
[cpg]


 Even if there is progress, it would be a problem, or rather, it would be bad if something other than what happened the other day happened.
[cpg]


If that were to happen, there is also the question of what would happen with Koyuki's sister.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************



[SE f="se011"]
;//【ＳＥ】『歩く』





There are many things to think about.
[cpg]


I have made some rules with my sister. But I can't help but wonder if it's okay to do this, even if it is a deterrent.
[cpg]


But I also couldn't stop. Once I knew the warmth of another person.
[cpg]


I'm not a stranger, but my sister's, I guess. ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夕方）******************************************************





Playing lovers. It was a gradual progression, and points were accumulating.
[cpg]


Koyuki seemed to be satisfied with the increased contact with me, and Chinatsu also seemed to be satisfied to some extent.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki053"]
[OnName num="koyuki"]
She said, "You've accumulated ......5 points. What do you want to do?　Yuma.
[cpg cn=true]


[OnName num="yuma"]
What do you mean by that?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Koyuki054"]
[OnName num="koyuki"]
If I accumulate 10 points, I can do something even more amazing for you, but do you want to use them?
[cpg cn=true]


This is it. Koyuki has a bit of a mean streak in her, doesn't she?
[cpg]


[OnName num="yuma"]
I want to use it. I want to use it.
[cpg cn=true]


She smiled and nodded in exasperation.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

And so began our first ever playtime as lovers.
[cpg]

We didn't have to do anything. But for now, we were not sister and brother.
[cpg]

We were cuddling together as casual lovers.
[cpg]

[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki055"]
[OnName num="koyuki"]
He was a spoiled little boy. She's a spoiled brat.
[cpg cn=true]


She patted my head. I felt as if that was all that was needed to relieve the unbearable feeling I was having.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





By dinner time, we were back to being sisters and brothers again.
[cpg]

But that's okay. Even days like this are much happier than before.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





The next morning. On the way to the school.
[cpg]


I met Ms. Nanano again. I thought, "How often do you meet her? ......
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano014"]
[OnName num="nanano"]
Good morning, Yuma-kun. Yuma-kun."
[cpg cn=true]


[OnName num="yuma"]
"Ms. Nanano,...... Good morning."
[cpg cn=true]


I had a clear goal in mind, so I didn't consult her anymore.
[cpg]


[OnName num="yuma"]
I'm going to be a little late for school, so ...... I'll be going now."
[cpg cn=true]


I was about to leave the place without talking to Ms. Nanano about anything in particular.
[cpg]


There, I was asked by Ms. Nanano.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano015"]
[OnName num="nanano"]
She said, "...... your face has changed.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Nanano016"]
[OnName num="nanano"]
Perhaps you had a crush on someone before and ...... it was fulfilled?
[cpg cn=true]


Unrequited love.
[cpg]


 I couldn't deny it and left without saying anything.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]

And then it was lunchtime at the school. I still feel awkward with my senpai.
[cpg]


I was hesitant to even broach the subject of what had happened between us. ......
[cpg]


[OnName num="yuma"]
......
[cpg cn=true]


But in the end, I couldn't stand the strange distance. I wanted to find out what she really meant.
[cpg]


[OnName num="yuma"]
"Senpai,......, about the other day...
[cpg cn=true]


[OnName num="yuma"]
"After all, why did you do that ......?"
[cpg cn=true]


When I asked her, she did not immediately respond. However, he did say something like
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina044"]
[OnName num="reina"]
"......Would you like to come over to my place after school today?"
[cpg cn=true]


I was a little surprised. I was a little surprised.
[cpg]


It was the first time for me to be invited to a girl's house, and I was a little puzzled, but ......
[cpg]


[OnName num="yuma"]
I was a little confused, but she said, "Ummm, yes. If you don't mind me coming up.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina045"]
[OnName num="reina"]
I'll tell you everything there. Until then, wait.
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（夕方）******************************************************


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]


Then we headed to the senior's house.
[cpg]


There were only a few words. A strange silence followed.
[cpg]


I felt awkward and tried to find something appropriate to talk about.
[cpg]


[OnName num="yuma"]
Have you ever taken a guy home, senpai?
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina046"]
[OnName num="reina"]
I was an only child. I'm an only child and Yuma is the first.
[cpg cn=true]


It became even more awkward. I shouldn't have said anything.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





After that, we went to the senior's house. In the room where we went, there was a small, deformed, human-shaped stuffed animal.
[cpg]


The stuffed animal was wearing clothes that resembled the uniform of the boys at the school we went to.
[cpg]


I had a feeling it was somehow made to look like me, but I couldn't ...... say anything.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina047"]
[OnName num="reina"]
I said, "Can I talk to you for a minute?　I have something I need to return."
[cpg cn=true]


I nodded, wondering if I had lent him anything.
[cpg]


And what he handed me was a handkerchief that I thought I had lost.
[cpg]


[OnName num="yuma"]
It was a handkerchief that I thought I had lost.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Reina048"]
[OnName num="reina"]
I love Yuma. The most important thing to remember is that you can't get rid of the problem by yourself.
[cpg cn=true]


The most important thing to remember is that you can't just take a look at the pictures and see what you want to see.
[cpg]


He also said that the stuffed animal was made because he thought it was me. ......
[cpg]


When I heard that, I thought, "That's too heavy.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Reina049"]
[OnName num="reina"]
I got jealous and impatient when I heard about you and your sister,...... please don't do anything with her."
[cpg cn=true]


[FG f="CHA02_p5_03_a.ui" method="change_4"  pos="2/3" time=800]
I was so jealous and impatient when I heard about you and your sister. I couldn't escape from her.
[cpg]



;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
;//移植のためシーンをカットしています

;//【ＢＧ】『ヒロイン２の部屋』（夕方）


She looked straight at me and said.
[cpg]

[FG f="CHA02_p5_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Reina050"]
[OnName num="reina"]
I love you, Yuma. More than anyone else in this world."
[cpg cn=true]





;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_03_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





I couldn't stay in her house for long.
[cpg]


I couldn't stand it. With that feeling, I came out.
[cpg]


Now it's just me and my senior in front of the entrance.
[cpg]


I received a confession of love from my senior.
[cpg]


But I couldn't respond to her right then and there.
[cpg]


I can neither nod nor deny. Because ......
[cpg]


I was so attracted to Koyuki-senpai as well. I was so attracted to Koyuki that I couldn't answer her.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Reina051"]
[OnName num="reina"]
'You were disillusioned with me, weren't you,...... Yuma?
[cpg cn=true]


[OnName num="yuma"]
I don't think so. I can understand if you are disillusioned with me.
[cpg cn=true]


I denied it, but I couldn't find any words of consolation at that moment.
[cpg]


I left in an awkward mood.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki056"]
[OnName num="koyuki"]
I was so disappointed that I couldn't find any comforting words to say. You're back.
[cpg cn=true]


[OnName num="yuma"]
Yeah, ......, I guess."
[cpg cn=true]


Back at home, I decided to save the points on my credit card.
[cpg]


[OnName num="yuma"]
"Sis, is there anything you want me to do for you?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki057"]
[OnName num="koyuki"]
"Well, I'd like to get a ...... massage.
[cpg cn=true]


Saying that, she went to her room. As one would expect, she can't do so openly in the living room.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夜）******************************************************





The most important thing to remember is that you can't just go to the store and ask for a massage.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki058"]
[OnName num="koyuki"]
"Ah ...... there, there. Yuma can be a bodyworker."
[cpg cn=true]


I still had the feeling that I wanted Koyuki to do it.
[cpg]


I was swaying, but I couldn't choose just one person.
[cpg]


The next point to aim for is 10 points. I had expectations of what she would do this time.
[cpg]


I acted as if I didn't want Koyuki to sense that I was in the dark.
[cpg]


Maybe she's already seen through me by now. ......
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（夜）******************************************************





I couldn't save up 5 or even 10 points right away.
[cpg]


But I thought it would be different if I touched my seniors.
[cpg]






[FADEOUTBGM]
[window target=false]
[BG f="b_09_1.ui" time=2000]
[WAIT time=2000]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





The days went on and on. I'm still awkward when I see my senior at school.
[cpg]


I guess she is still waiting for my reply. I think I'm a scumbag, but I'm not sure what to say to her. ......
[cpg]


But I didn't even know what to say to her again.
[cpg]







[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（夕方）******************************************************





While my sexual desire was growing, I met Ms. Nanano on a holiday.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano017"]
[OnName num="nanano"]
She said, "Good evening. We've been seeing each other a lot lately."
[cpg cn=true]


I had nothing special to do and was on my way home from a play date with a male friend.
[cpg]


[OnName num="yuma"]
I was on my way home from a playdate with a male friend. Good evening.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano018"]
[OnName num="nanano"]
I see you've gone back to your gloomy face again. Something is bothering you again, isn't it?"
[cpg cn=true]


I wonder if this person can really ...... tell everything just by looking at my face.
[cpg]


I think I'm basically the type of person who doesn't show facial expressions.
[cpg]


[OnName num="yuma"]
I'm not. Nothing."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano019"]
[OnName num="nanano"]
If you want, I can ask your sister. What do you think?
[cpg cn=true]


Ms. Nanano said. I was puzzled, but ......
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="yuma"]
Hey, hey!"
[cpg cn=true]


She forcefully pulled my arm. I can't escape.
[cpg]


I thought it was a quirk to ask her to take me up to her house, but she forced me to go with her.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************







Nanano's room was tidy. She is calm, but not at all overflowing.
[cpg]


It was the kind of room that gave me that impression. There, I was asked by Ms. Nanano, "Do you have a problem with a girl?
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano020"]
[OnName num="nanano"]
Is it a girl-related problem?"
[cpg cn=true]


I could only nod. That's absolutely the right answer.
[cpg]


[OnName num="yuma"]
I said, "...... Yes.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano021"]
[OnName num="nanano"]
That's quick, isn't it? I have a simple solution.
[cpg cn=true]


I don't know what you're talking about. What are you thinking about, Ms. Nanano?
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano022"]
[OnName num="nanano"]
'It doesn't look like you're used to girls, so you'll just have to get used to them.
[cpg cn=true]



I guess I should have run away before I finished listening to all that.
[cpg]


But maybe it's too late now.
[cpg]


;//移植のためシーンをカットしています

[OnName num="yuma"]
No. What are you going to do?"
[cpg cn=true]


I reflexively pushed her away as she came at me. And then...
[cpg]

;//========================================
;//●ＣＧ（背中を向けているヒロイン。こけそうになったような感じ）ev_08
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]

;**【ＣＧ】 ev_08_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[wait time=1000]


[VOICE f="Nanano023"]
[OnName num="nanano"]
"Kya!"
[cpg cn=true]


She almost fell down and poked my hand.
[cpg]

Her back was turned to me, and looking at her, how ......
[cpg]

I thought to myself, "Ms. Nanano is a fascinating person, isn't she?
[cpg]

[VOICE f="Nanano024"]
[OnName num="nanano"]
'...... what's wrong?'
[cpg cn=true]


[OnName num="yuma"]
'Yea, it's nothing.'
[cpg cn=true]



;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************


Then Ms. Nanano broke the silence.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Nanano025"]
[OnName num="nanano"]
'......I'm sorry. Suddenly, you were surprised, weren't you?"
[cpg cn=true]


[OnName num="yuma"]
Yes,......, I was surprised.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Nanano026"]
[OnName num="nanano"]
I like cute boys like Yuma,.......
[cpg cn=true]


I couldn't get it straight in my head. The relationship has become strangely complicated.
[cpg]


I'm being approached by three people: my sister Koyuki, my senpai, and Ms. Nanano.......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





Then, Ms. Nanano did not say much.
[cpg]


I also get suspicious if I come home too late. When I told her that, Ms. Nanano didn't keep me around.
[cpg]


[OnName num="yuma"]
I was in a hell of a mess."
[cpg cn=true]



;//==============================
;//選択肢11を選んでいた場合
[if exp={getFlagValue("flag3") == 0 }]
[jump target="*sw3_1"]
[endif]




But somewhere along the way, I didn't see what I had done with Ms. Nanano as just a bad thing.
[cpg]


I also found myself a little bit attracted to Ms. Nanano. ......
[cpg]


[jump target="*sw3_2"]
;//==============================
;//選択肢12を選んでいた場合
*sw3_1|playing lovers




I wanted to forget about today.
[cpg]


It would be best not to tell anyone and pretend it never happened. ......
[cpg]



;//==============================
*sw3_2|playing lover





[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************



I walk back to the house. There were many shoes again.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chinatsu026"]
[OnName num="chinatsu"]
"Welcome home, Yu-kun."
[cpg cn=true]


[OnName num="yuma"]
"Oh, I'm home. ...... Someone's here?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu027"]
[OnName num="chinatsu"]
"Yes, someone's here. I heard her talking in Koyuki's room.
[cpg cn=true]


I was a little concerned when I heard her talking in her room.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se004"]
;//【ＳＥ】『ノック』



The first thing you need to do is to make sure that you have a good idea of what you want to do. The answer came back from inside.
[cpg]



[VOICE f="Koyuki059"]
[OnName num="koyuki"]
Oh, Yuma?　Come in.
[cpg cn=true]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夕方）******************************************************




[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Michiru007"]
[OnName num="michiru"]
"Hello. I'm sorry to bother you.
[cpg cn=true]


Michiru was there. It was a little awkward.
[cpg]


My relationship with Koyuki is different from what it used to be.
[cpg]


I was thinking that I can't talk about the point card in front of Michiru-san.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Michiru008"]
[OnName num="michiru"]
I thought to myself, "Yuma-kun, you are playing lover with Koyuki, aren't you?
[cpg cn=true]


[OnName num="yuma"]
What?
[cpg cn=true]


It seems that she has found out about it.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki060"]
[OnName num="koyuki"]
"Hey, Michiru ......
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Michiru009"]
[OnName num="michiru"]
I'm sorry~. I'm so embarrassed that I felt compelled to tell you.
[cpg cn=true]


I was so embarrassed that I decided to walk away.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



After a while, Michiru left the house.
[cpg]


I helped her with the family dinner, too, and we racked up the points.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_og"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





I was lost. I wasn't sure who I liked after all.
[cpg]


But I still had to make a proper decision.
[cpg]


I have already had relationships with three women.
[cpg]


It is obvious that I have to decide with one of them.
[cpg]


[OnName num="yuma"]
......This would be like cheating on me. ......"
[cpg cn=true]


I mumbled to myself and made up my mind.
[cpg]


The one person I had my heart set on was her.
[cpg]



;//ここまでの選択によって現れる選択肢が変化
;//選択肢１は常に発生。それしか無い場合は選択肢は発生せず進む


[if exp={getFlagValue("flag2") == 1 }]
[jump target="*rootch1_2"]
[endif]


[if exp={getFlagValue("flag3") == 1 }]
[jump target="*rootch1_3"]
[endif]

// No 2 or 3.
[jump target="*select04_1"]


// there's only 3.
*rootch1_3|playing lovers
[switch]
[case "Koyuki"]
	[swap]
	[jump target="*select04_1"]
[case "Nanano"]
	[swap]
	[jump target="*select04_3"]
[endswitch]



*rootch1_2|playing with a lover
[if exp={getFlagValue("flag3") == 1 }]
[jump target="*rootch1_23"]
[endif]

There are only //2
[switch]
[case "Koyuki"]
	[swap]
	[jump target="*select04_1"]
[case "Rena"]
	[swap]
	[jump target="*select04_2"]
[endswitch]


*rootch1_23|playing lovers
//2 and 3 are both there.
;//■選択肢
[switch]
[case "Koyuki"]
	[swap]
	[jump target="*select04_1"]
[case "Rena"]
	[swap]
	[jump target="*select04_2"]
[case "Nanano"]
	[swap]
	[jump target="*select04_3"]
[endswitch]




1, Koyuki
2, Rena
3, Nanano



*select04_1|playing lovers
[jump storage="ep004.ks" target="*select04_1"]

*select04_2|playing lovers
[jump storage="ep009.ks" target="*select04_2"]

*select04_3|playing lovers
[jump storage="ep011.ks" target="*select04_3"]




