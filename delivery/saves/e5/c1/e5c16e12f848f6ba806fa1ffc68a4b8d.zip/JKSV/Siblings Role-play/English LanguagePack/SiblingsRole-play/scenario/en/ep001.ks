
*start




;#################################################
*Ep001|Holidays when seniors come to visit.
;#################################################

[SCENE id=1]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（朝）******************************************************





Then the week ends again and the holiday comes.
[cpg]







[window target=false]
[BG f="b_07_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





Saturday. I was anxious.
[cpg]


My senior is coming. At my house. I was a little nervous.
[cpg]


Would my sisters make any unwanted advances on me?　I wondered.
[cpg]


I wonder if I can behave properly in front of my senpai.
[cpg]



[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』





Then the chime rang. I was sitting in my chair, but I jumped up a little.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina016"]
[OnName num="reina"]
I was sitting in my chair, but I jumped up a little. May I come in?
[cpg cn=true]


[OnName num="yuma"]
Of course. Come on, come on.
[cpg cn=true]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Koyuki022"]
[OnName num="koyuki"]
"......, you're here. Are you the senior?
[cpg cn=true]


Suddenly, Koyuki is restraining me. I thought it was unnecessary again, but there was nothing I could do about it.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Reina017"]
[OnName num="reina"]
I'm Rena Shidakashi.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chinatsu008"]
[OnName num="chinatsu"]
I'm Shikkashi Rena. You're going to have a study session, right?
[cpg cn=true]


[OnName num="yuma"]
I'll be in my room for a while. I'll be in my room for a while. ...... Don't do anything unnecessary, Koyuki.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Koyuki023"]
[OnName num="koyuki"]
Why am I the only one named?"
[cpg cn=true]


I think I've done things that should have been said that way.
[cpg]


The actual "I'm not a fan of the way you do it," he said.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（朝）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina018"]
[OnName num="reina"]
Heh. I guess it's your room after all.
[cpg cn=true]


[OnName num="yuma"]
What do you mean by 'like me'?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Reina019"]
[OnName num="reina"]
What do you mean by "like me"? It smells like me.
[cpg cn=true]


Smell ......?　
[cpg]


[OnName num="yuma"]
The first is the one that is the most popular. I can't watch you study, though.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina020"]
[OnName num="reina"]
I don't even ask you to watch me. I won't even ask you to watch.
[cpg cn=true]







[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（昼）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

So we studied together for a while.
[cpg]


I was always being taught by my senpai.
[cpg]


I was feeling a little miserable, but it couldn't be helped. There is a difference in our grades.
[cpg]



[SE f="se004"]
;//【ＳＥ】『ノック』



[free time=1000]

Then I heard a knock at the door.
[cpg]


[OnName num="yuma"]
"...... Koyuki-sis?"
[cpg cn=true]


I took a guess and said.
[cpg]



[VOICE f="Koyuki024"]
[OnName num="koyuki"]
"Yes. How do you know?
[cpg cn=true]


I thought I knew it, and opened the door. I opened the door.
[cpg]




[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Koyuki025"]
[OnName num="koyuki"]
I brought you something to drink. Tea?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Reina021"]
[OnName num="reina"]
Thank you very much. Thank you very much.
[cpg cn=true]


Sister Koyuki doesn't go as far as glaring at her, but she glances at her seniors.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki026"]
[OnName num="koyuki"]
The first thing you need to do is to make sure that you have a good understanding of what you're doing.
[cpg cn=true]


[OnName num="yuma"]
I'm sure you'll be able to find a way to get a good deal on it.
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="Koyuki027"]
[OnName num="koyuki"]
I'm not going to say it like that. The actuality that you can't get a lot of these things is that they're not really that good.
[cpg cn=true]


The first thing to do is to make sure that you have a good idea of what you're getting into. His chest is hitting me. ......
[cpg]


[OnName num="yuma"]
'No, stop it,......, let go of me.'
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

After doing something like that, Koyuki sister contemplated and left the room.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



[SE f="se005"]
;//【ＳＥ】『ペンでノートに書く』



Silence for a while. I hear the sound of a pen running.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina022"]
[OnName num="reina"]
Hey, Yuma. Is Yuma a cis-con?"
[cpg cn=true]


I almost spewed out the tea in my mouth. I swallowed and then spoke.
[cpg]


[OnName num="yuma"]
"Kyu, what are you suddenly ......?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina023"]
[OnName num="reina"]
You looked so red.
[cpg cn=true]


[OnName num="yuma"]
It's because he was here.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina024"]
[OnName num="reina"]
"Hmmm,......."
[cpg cn=true]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************





The time passed in such a way that the senpai said it was time to go home.
[cpg]


I don't think he is in a very good mood. It was the first time I had him come to my house.
[cpg]


[OnName num="yuma"]
The first time I came to your house, I was in a very bad mood.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina025"]
[OnName num="reina"]
I had a good time today. I had fun today.
[cpg cn=true]


It's probably true that I had a good time. But it seemed like she was holding on to a strange feeling of uncertainty.
[cpg]


The same is true for me. Koyuki's sister is messing with me. ......
[cpg]







[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************





After seeing my senpai off, I go back to my room.
[cpg]


[OnName num="yuma"]
"Sis-con, sis-con or ......?"
[cpg cn=true]


It's a word I've been thinking about. I can't deny it outright.
[cpg]


If you ask me if I've never looked at my sisters in a sexual way, I haven't.
[cpg]


I can't help but think nothing of the excessive skinship Koyuki sisters give me.
[cpg]


I became strangely conscious of her from that day on.
[cpg]


Even when we all gathered around the dinner table, I became strangely conscious of her. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki028"]
[OnName num="koyuki"]
What's wrong?　What's wrong?
[cpg cn=true]


[OnName num="yuma"]
Nothing."
[cpg cn=true]


I can't help but look at my sister's chest.
[cpg]


I finished my dinner, wondering if my father and mother had noticed.
[cpg]







[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************





I was in a daze in the living room. Chinatsu talked to me.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu009"]
[OnName num="chinatsu"]
She said, "Sis, have you done anything unnecessary?"
[cpg cn=true]


[OnName num="yuma"]
I don't know if it's subtle,......, but it's not like I didn't do it.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu010"]
[OnName num="chinatsu"]
So ......."
[cpg cn=true]


Chinatsu-san is also concerned about it. But that doesn't make it any better
[cpg]


What am I supposed to do ......?
[cpg]


I wonder how I should look at Sister Koyuki.
[cpg]


[free time=1000]

The first thing you need to do is to take a look at the following information.
[cpg]



[VOICE f="Koyuki029"]
[OnName num="koyuki"]
I'm going to take a look at the bathtub.
[cpg cn=true]


[OnName num="yuma"]
"Uh-huh. ......."
[cpg cn=true]


I knew something was spreading in my mind.
[cpg]


It might have been something that I wouldn't have even noticed if my seniors hadn't pointed it out to me. ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





The next day. It's Sunday.
[cpg]


Today, both Koyuki and Chinatsu are going to visit Michiru's house.
[cpg]


[OnName num="yuma"]
"......, see you later."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Koyuki030"]
[OnName num="koyuki"]
I'm going to go to the school. See you later, Yuma.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Chinatsu011"]
[OnName num="chinatsu"]
I'm off, Yu-kun.
[cpg cn=true]


I sent them off and left them to their own devices.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





It was now noon and evening. My sisters would not be back for a while yet.
[cpg]


This was really just an idea. Really, it was just a demon.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夕方）******************************************************





Somehow, I entered Koyuki's room with nothing to do.
[cpg]


Her room was unlocked.
[cpg]


I was conflicted, but I also remembered the temptation Koyuki had given me.
[cpg]


She usually does all kinds of weird things to me. I thought it was okay to enter her room without permission.
[cpg]


When I entered the room, I smelled my sister's scent. I was thinking that this is what the older sister meant when she said that she smelled like me.
[cpg]


I saw a wardrobe. This is where my sister's clothes and underwear are kept, I thought.
[cpg]


[OnName num="yuma"]
What am I thinking, ......?"
[cpg cn=true]


I probably have enough time before she comes back.
[cpg]


It's Koyuki's sister who usually seduces me. Even if she makes some mistakes, I think she will pretend she didn't see them.
[cpg]


I had this kind of naivete in my mind. I felt like this was inevitable, rather than something I couldn't stand.
[cpg]


I had accumulated a lot of experience up to now. I think the decisive factor was what my senior said to me, "Am I a siscon?
[cpg]


Was I a siscon? After all this time, it would be strange to deny it.
[cpg]






;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I put my hand on the wardrobe. That moment.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夕方）******************************************************






[VOICE f="Koyuki031"]
[OnName num="koyuki"]
I'm home.
[cpg cn=true]


[OnName num="yuma"]
What?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/2" time=800]

There, Koyuki and Chinatsu were frozen.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chinatsu012"]
[OnName num="chinatsu"]
The first thing that comes to mind is the fact that the two of them are both in the same room.
[cpg cn=true]


Chinatsu-san is confused. I was confused. And only Koyuki was calm.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Koyuki032"]
[OnName num="koyuki"]
I was so confused.
[cpg cn=true]


I was confused and only Koyuki remained calm.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki033"]
[OnName num="koyuki"]
'Do you like me that much?　Yuma."
[cpg cn=true]


I didn't deny it, I couldn't say anything, but I knew it was all her fault.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Koyuki034"]
[OnName num="koyuki"]
I know. I know you do some things I usually do. That's why ......"
[cpg cn=true]


So. What followed that statement was unexpected.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki035"]
[OnName num="koyuki"]
You need to let it go.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Chinatsu013"]
[OnName num="chinatsu"]
Sis, what are you saying ......?"
[cpg cn=true]


That's what Chinatsu said. I feel almost the same way
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夕方）******************************************************





I involuntarily ran away from the place.
[cpg]


It's a hell of a thing. I also have a refrain in my head of what Sister Koyuki has said to me.
[cpg]


What do you mean by divergence?　Didn't Koyuki-sister always see me as just her little brother?






;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



No matter what you think, no matter what happens, time passes equally.
[cpg]


After a sleepless night, it is morning.
[cpg]



[jump storage="ep002.ks" target="*start"]
