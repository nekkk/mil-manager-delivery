
*start


;//==============================
;//６、美知留さんが忘れられない


;#################################################
*Ep008|Michiru is unforgettable
;#################################################


*select06_3|I can't forget Michiru-san.

[SCENE id=8]


;//qwe

......I love Michiru-san.
[cpg]


I remember Michiru-san seducing me.
[cpg]


I don't know what she was like, but I felt a strange attraction there too.
[cpg]


She said she was waiting for an answer,...... but I couldn't give her an answer like this right away.
[cpg]


[OnName num="yuma"]
You can't say it,......."
[cpg cn=true]


Once you have decided to love Koyuki Sis, it is like cheating on her.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





After a while, Michiru-san left.
[cpg]


I felt as if I had something to tell her, but not enough to keep her.
[cpg]


I ...... still care about Michiru-san.
[cpg]


I wonder if she likes someone else. I'm even starting to wonder about that: ......
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





[OnName num="yuma"]
"...... huh."
[cpg cn=true]


I feel somewhat heavy. I had this feeling.
[cpg]


Will I have to shake Koyuki's sister? Thinking of that, I still feel heavy.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I'm basically at the school during the day.
[cpg]


I'm usually at the school during the daytime, and it's only in the evening that I talk to my sisters. So it was the same today. ......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************




[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Michiru021"]
[OnName num="michiru"]
I've never been on an outing with Yuma, have you?
[cpg cn=true]


[OnName num="yuma"]
Yes, I have. ......
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Koyuki168"]
[OnName num="koyuki"]
Don't be so nervous. It's more embarrassing to watch.
[cpg cn=true]


The actual "I'm not a fan of the newest technology," said the woman, "but I'm not a fan of the newest technology, either.
[cpg]


[OnName num="yuma"]
 "Hey, sister...why did you decide to go out?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[VOICE f="Koyuki169"]
[OnName num="koyuki"]
I was wondering if we could do something romantic.
[cpg cn=true]


[OnName num="yuma"]
"What do you mean ......?"
[cpg cn=true]


I followed her and found out the reason.
[cpg]




;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_og"]
;//[WAIT time=100]
;//【ＢＧ】『カラオケ店内』（夕方）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Koyuki170"]
[OnName num="koyuki"]
Karaoke. You and Yuma haven't been here much, have you?
[cpg cn=true]


[OnName num="yuma"]
I'm not a good singer.
[cpg cn=true]



[VOICE f="Michiru022"]
[OnName num="michiru"]
"Oh, you're not into it, are you?
[cpg cn=true]


When you say it like that, I feel like I can't back down either.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


A loverly thing. I don't know if that means singing together.
[cpg]

But ...... I was more conscious of being with Michiru than with my sister.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


After that, the number of meetings between me, Koyuki and Michiru increased.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





Weekdays, daytime at the school. I was alone with my senpai.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina071"]
[OnName num="reina"]
How are things going?　"How have things been going with your sister since then?
[cpg cn=true]


[OnName num="yuma"]
"......Uh-huh.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina072"]
[OnName num="reina"]
"You're not very articulate,......, what's going on?"
[cpg cn=true]


[OnName num="yuma"]
"Nothing's ...... wrong, I'm fine."
[cpg cn=true]


The truth is, there was something going on with all my heart.
[cpg]


Today, too, something like ...... is planned at Michiru's house.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina073"]
[OnName num="reina"]
I'm curious. It's easy to know that Yuma is hiding something from me, isn't it?
[cpg cn=true]


[OnName num="yuma"]
I'm not hiding anything from you.
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************



[SE f="se011"]
;//【ＳＥ】『歩く』





After meeting up with Koyuki at home, we headed to Michiru's house.
[cpg]


She seems to live alone. If that's the case, I'd like to do whatever she wants to do. ......
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru023"]
[OnName num="michiru"]
"Oh, hello, welcome. Please come in.
[cpg cn=true]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Michiru's room was ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン５の部屋』（夕方）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Koyuki171"]
[OnName num="koyuki"]
You really don't clean, do you?
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Michiru024"]
[OnName num="michiru"]
It's not that I don't, it's just that I can't."
[cpg cn=true]


It was a very messy room. There was so much stuff that there was no foothold ......
[cpg]


[OnName num="yuma"]
I'll clean it. ...... You can't do anything in a place like this, can you?
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Michiru025"]
[OnName num="michiru"]
"Really?　That would be a big help!"
[cpg cn=true]


So we started by cleaning Michiru's room.
[cpg]


After an hour of tidying up, the room was finally looking a little cleaner.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Michiru026"]
[OnName num="michiru"]
I was just about to clean up for an hour when she said, "Thank you very much. Then, I should thank you.
[cpg cn=true]


[FG f="CHA05_p5_01_a.ui" method="change_2"  pos="2/2" time=800]
Michiru approached me.
[cpg]


[OnName num="yuma"]
She said, "What?
[cpg cn=true]


;//========================================
;//●ＣＧ（主人公にのしかかっているヒロイン）ev_43
;//人物１：ヒロイン５
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン５の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_43_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています


[VOICE f="Michiru027"]
[OnName num="michiru"]
I'm often told I'm good at massages.
[cpg cn=true]


[OnName num="yuma"]
Is it true?
[cpg cn=true]


[VOICE f="Koyuki172"]
[OnName num="koyuki"]
I've never heard of it.
[cpg cn=true]


I was so uncomfortable that I was afraid to speak to her.
[cpg]

 In front of my sister, it's awkward and I try to shake it off...
[cpg]

[VOICE f="Michiru028"]
[OnName num="michiru"]
I try to shake her off, but she says, "Don't run away now."
[cpg cn=true]


I was so embarrassed and I tried to shake her off, but she said, "You can't run away from me anymore.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





After that happened, I was on my way home.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Michiru029"]
[OnName num="michiru"]
I was on my way home after such an incident. I forgot something.
[cpg cn=true]


[OnName num="yuma"]
What is it?　What is it?
[cpg cn=true]


[FG f="CHA05_p5_01_a.ui" method="change_2"  pos="2/2" time=800]
I wondered if I had taken something that I would forget. I received a small folded note.
[cpg]


I put it in my pocket, thinking that I shouldn't open it right then and there.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Michiru030"]
[OnName num="michiru"]
I put it in my pocket. See you again.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki173"]
[OnName num="koyuki"]
Yes. See you later.
[cpg cn=true]


[OnName num="yuma"]
"See you at ......."
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





In my room, I took out the note I had received earlier.
[cpg]


When he opened it, he found the phone number ....... It was a cell phone.
[cpg]



[SE f="se009"]
;//【ＳＥ】『携帯電話の発信音』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]



[OnName num="yuma"]
"......."
[cpg cn=true]


Without thinking, I call the number. Then, I hear the following message.
[cpg]


;//[lbox on]
[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[VOICE f="Michiru031"]
[OnName num="michiru"]
Good evening. You called me as soon as you could.
[cpg cn=true]


[OnName num="yuma"]
What are you doing calling me at ......?
[cpg cn=true]



[VOICE f="Michiru032"]
[OnName num="michiru"]
Yes. Yuma-kun seems to like me.
[cpg cn=true]


I was at a loss for words. I'm not sure what to do with it. But, I think Koyuki is probably unaware of it.
[cpg]



[VOICE f="Michiru033"]
[OnName num="michiru"]
I thought maybe she wanted to meet me without Koyuki.
[cpg cn=true]


[OnName num="yuma"]
"Well, that's ...... such a thing."
[cpg cn=true]



[VOICE f="Michiru034"]
[OnName num="michiru"]
"Think about it. I'm always free.
[cpg cn=true]



[SE f="se008"]
;//【ＳＥ】『携帯電話の通話終了音』


;//[lbox off] 
[free time=1000]



After such conversation, the phone hangs up.
[cpg]


Various thoughts swirled in my head. As a result of the swirling thoughts, ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（朝）******************************************************



;//[lbox on]



[VOICE f="Michiru035"]
[OnName num="michiru"]
Hello? Hello?
[cpg cn=true]


[OnName num="yuma"]
...... now?"
[cpg cn=true]


I kept in touch with Michiru behind her back.
[cpg]


I made an appointment to go to Michiru's house to visit her.
[cpg]

;//[lbox off]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（昼）******************************************************





It was the daytime on a holiday. I pretended to go to a friend's house and headed to Michiru's house.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru036"]
[OnName num="michiru"]
She said, "Welcome. Come on in, come on in.
[cpg cn=true]


[OnName num="yuma"]
Sorry to bother you.
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『ドア開く』





;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン５の部屋』（夕方）******************************************************




Michiru's room, though better than yesterday's, was still quite messy, showing her lazy personality.
[cpg]


[OnName num="yuma"]
I'll clean up. A messy room makes me feel uncomfortable.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru037"]
[OnName num="michiru"]
"Really?　That would be great.
[cpg cn=true]


I cleaned Michiru's room. It was getting pretty clean and I was about to take a break. ......
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michiru038"]
[OnName num="michiru"]
Hey, Yuma. You're playing lovers with Koyuki, aren't you?
[cpg cn=true]


[OnName num="yuma"]
What's wrong with that?
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru039"]
[OnName num="michiru"]
I'm sure you're playing lovers with Koyuki.　I'll pay you back if you clean my room.
[cpg cn=true]


That's just an excuse. I know.
[cpg]



;//========================================
;//●ＣＧ（座っているヒロイン。普通に座っているような姿勢に変えてください）ev_44
;//人物１：ヒロイン５
;//服装１：私服
;//場所　：ヒロイン５の部屋
;//時間　：昼
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています

[VOICE f="Michiru040"]
[OnName num="michiru"]
Thank you. Then, come over here.
[cpg cn=true]


If Koyuki and Chinatsu found out about my relationship with ...... Michiru, I would be in big trouble.
[cpg]


Despite these thoughts, I could not stop the immoral relationship.
[cpg]



[VOICE f="Michiru041"]
[OnName num="michiru"]
Yuma-kun, you like this kind of thing, don't you?"
[cpg cn=true]


What did he mean by "this kind of thing"?
[cpg]


[OnName num="yuma"]
"......What are you talking about?"
[cpg cn=true]



[VOICE f="Michiru042"]
[OnName num="michiru"]
I know what you are talking about. I know what you mean, Yuma, you really want to be corrupted, don't you?
[cpg cn=true]



[VOICE f="Michiru043"]
[OnName num="michiru"]
I'll help you, sister. I'll help you, let's fall as far as we can.
[cpg cn=true]


;//移植のためシーンをカットしています


;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



;//[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru044"]
[OnName num="michiru"]
Then, please come back again.
[cpg cn=true]


Michiru-san smiled and waved her hand.
[cpg]


I couldn't let this be the end.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





Another day. I went to school as usual in the morning and lied to my ...... sisters that I was going to visit a male friend's house right away instead of going back to my house.
[cpg]


I couldn't tell them the truth. Especially not to Koyuki. ......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





[OnName num="yuma"]
"...... Michiru-san. I'm anxious."
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michiru045"]
[OnName num="michiru"]
I'm worried?　What on earth are you worried about?
[cpg cn=true]


[OnName num="yuma"]
If my sisters ...... Koyuki and Chinatsu find out about this ......
[cpg cn=true]


[OnName num="yuma"]
I don't think they'll forgive me.
[cpg cn=true]


Michiru smiled. Then, she said, "I'm not sure I'm going to be able to do this.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru046"]
[OnName num="michiru"]
I'm not worried about that. Yuma, I don't want you to worry about that, I want you to think only about me.
[cpg cn=true]


I did not know what Michiru was thinking. Without knowing, I was again taken up to Michiru-san's house. ......
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Michiru's house was a mess again.
[cpg]


No matter how many times I clean it up, it always ends up being a mess......
[cpg]


I felt that this was intentional, but I kept coming back to Michiru's place.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『町』（夜）******************************************************





As I spent my time in this way, it was completely nighttime outside.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru047"]
[OnName num="michiru"]
I'll be waiting for you anytime. I'll be waiting for you anytime.
[cpg cn=true]


[OnName num="yuma"]
"...... Yes."
[cpg cn=true]


I wondered if it was right for me to be so close to her.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





Back at home, I ate dinner, took a bath and ...... dawdled.
[cpg]


After I told Koyuki that I liked her. In other words, this is cheating.
[cpg]


The day came sooner than expected, though I thought it was bound to be discovered one day.
[cpg]



[SE f="se002"]
;//【ＳＥ】『ドア乱暴に開く』





[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/2" time=800]
[WAIT time=1100]

[VOICE f="Koyuki174"]
[OnName num="koyuki"]
"Yuma!　I need to talk to you!
[cpg cn=true]


My sister suddenly came into my room.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chinatsu100"]
[OnName num="chinatsu"]
She said, "It's terrible, Yuu-kun. ...... I feel sorry for your sister."
[cpg cn=true]


[OnName num="yuma"]
What are you talking about?
[cpg cn=true]


The first thing you need to do is to get a good idea of what you're talking about.
[cpg]


Apparently, they found out that I was meeting with Michiru behind her back. But why ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki175"]
[OnName num="koyuki"]
Don't play dumb with me ......, how are you going to explain this?"
[cpg cn=true]


Koyuki is angry with a great sword. I was wondering how she found out about it.
[cpg]


[OnName num="yuma"]
"This is ......."
[cpg cn=true]


This is a picture sent to your address. It's a picture of me and Michiru meeting together.
[cpg]


But who sent this?　Would Michiru-san do that directly?
[cpg]


[OnName num="yuma"]
Who sent this to me?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Koyuki176"]
[OnName num="koyuki"]
It's from Michiru. If you're going to talk like that, you must admit it.
[cpg cn=true]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I had to admit it. Things had turned sour between me and my sisters.
[cpg]


But I really don't understand Michiru's intentions. ......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="1/2" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/2" time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





[OnName num="father"]
What's up...... with the fight?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki177"]
[OnName num="koyuki"]
Yeah, that's about right. Something like that.
[cpg cn=true]


[OnName num="yuma"]
"......"
[cpg cn=true]


Sister Koyuki looks quite angry. It shows in her expression.
[cpg]


Chinatsu sister does not even try to intercede for it.
[cpg]


I'm in trouble. This relationship is not going to be repaired in any way.
[cpg]


She said she loved Koyuki sister and was going to someone else. ......
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I wanted to find out the truth. What was Michiru-san thinking when she sent those images?
[cpg]


I headed to Michiru-san's house. There was no need to hide it from my sisters anymore.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





And then I arrived at Michiru's house.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru048"]
[OnName num="michiru"]
Oh, my God, welcome. What's wrong with your scary face?
[cpg cn=true]


[OnName num="yuma"]
I said, "It's not what's wrong. What was your intention, Michiru-san?
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michiru049"]
[OnName num="michiru"]
Oh, that picture?　Oh, that image?
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru050"]
[OnName num="michiru"]
I'm sure you won't be able to look aside at your two sisters anymore. They are probably fighting right now.
[cpg cn=true]


It is said that ....... He wanted his sisters to hate him when they found out about the relationship.
[cpg]


[OnName num="yuma"]
I'm sure I'll end up hating Michiru, too, for doing such a messy ...... thing."
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michiru051"]
[OnName num="michiru"]
I don't. I know that. I know that, that's why I'm doing it.
[cpg cn=true]


I can't deny that. The first thing to do is to make sure that you have a good relationship with the person you are talking to.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru052"]
[OnName num="michiru"]
I'm the only one for you, right?
[cpg cn=true]


I couldn't deny it, but I still thought it was a terrible thing to do.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michiru053"]
[OnName num="michiru"]
So what are you going to do?　Do you want to go out tonight?
[cpg cn=true]


I couldn't refuse even this invitation. ......
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





While cleaning up her room, which was easily disorganized, I reciprocated by making love to her. ......
[cpg]


As these days went on, I realized that we had become somewhat dependent on each other.
[cpg]


But I couldn't get out. I can't escape from Michiru.
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『町』（夜）******************************************************





Everything Michiru-san does is sneaky.
[cpg]


It was as if she knew everything about my mind. Like the way she sent an email to her sister: ......
[cpg]


I thought she was intentionally making a mess in her room. He's pretending to be sloppy.
[cpg]


I feel like I'm putting him in a state of mind that he needs me.
[cpg]


I also think that by giving me a role, he is using it as an excuse.
[cpg]


But I can't escape. I can't get out.
[cpg]


I'm already in her tricks,...... and I couldn't stop everything now.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（昼）******************************************************





Time is passing. On a holiday, I went to Michiru's place again.
[cpg]


My sisters didn't stop me. Me and my sisters were still on bad terms.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru054"]
[OnName num="michiru"]
I said, "That's fine. You have me, don't you?
[cpg cn=true]


[OnName num="yuma"]
But I decided to love you.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michiru055"]
[OnName num="michiru"]
Then you'll have to give me up first.
[cpg cn=true]


And again. I'm not sure I can do it.
[cpg]

;//移植のためシーンをカットしています



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The first thing you need to do is to make sure that you have a good relationship with your partner.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michiru056"]
[OnName num="michiru"]
I was invited to Michiru's house, and we stayed there for a while.
[cpg cn=true]


[OnName num="yuma"]
"...... something I didn't expect. ......"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru057"]
[OnName num="michiru"]
"Ummm....... I don't know what they'll do to me if I see them now.
[cpg cn=true]


Michiru is right. Especially Koyuki's sister must be very angry with Michiru.
[cpg]


Or have they already met?
[cpg]


I wonder if the battle between the women has already started or not,.......
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michiru058"]
[OnName num="michiru"]
I'm sure the academy will be closed tomorrow since it's a holiday, right?　Come back."
[cpg cn=true]


[OnName num="yuma"]
......."
[cpg cn=true]


I left the place without replying.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************





[OnName num="yuma"]
"I'm home, sis."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Koyuki178"]
[OnName num="koyuki"]
"......."
[cpg cn=true]


No answer. The awkward situation at home continued.
[cpg]


I stopped touching my sisters, as Michiru-san intended.
[cpg]


If I continue to go out with Michiru-san, I may ...... lose everything that is superfluous to Michiru-san.
[cpg]


[free time=1000]

Despite this thought, I couldn't stop dating Michiru.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chinatsu101"]
[OnName num="chinatsu"]
"Oh,...... Yuu-kun, you're back."
[cpg cn=true]


[OnName num="yuma"]
"......Yeah. I'm home."
[cpg cn=true]


I was in a state where I didn't know what to say anymore.
[cpg]


I felt like I would anger Sister Koyuki-san if I did anything unnecessary.
[cpg]


On the other hand, Chinatsu-san is also disappointed in me. She won't help me out.
[cpg]


;//[free time=1000]

[OnName num="yuma"]
I'm going back to my room.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Koyuki179"]
[OnName num="koyuki"]
I don't want to see her face. I don't even want to see you.
[cpg cn=true]


I think it's actually hard for her to look at my face.
[cpg]


We haven't even touched each other for a long time. ...... I guess my sister is still fighting her desires.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





It's becoming very difficult. Everything is going the way Michiru wants it.
[cpg]


Where did she start planning this?
[cpg]


She could have chosen to have me love Koyuki single-mindedly.
[cpg]


She knew that I would not choose that. I even think it's scary.
[cpg]


Tomorrow is a holiday. Michiru-san will be waiting for me.
[cpg]


She even asked me to come. ...... What should I do?
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





There was nothing to be done about it. I am already a captive of Michiru.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru059"]
[OnName num="michiru"]
Good morning. Thanks for coming so early in the morning."
[cpg cn=true]


[OnName num="yuma"]
Good morning, ......."
[cpg cn=true]


I didn't even know what kind of face I was making right now.
[cpg]


I have mixed emotions.
[cpg]




;//ブラックアウト



;//========================================
;//●ＣＧ（座っているヒロインが、主人公を脚でつつく）ev_49
;//人物１：ヒロイン５
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン５の部屋
;//時間　：昼
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_49_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[wait time=1000]

[VOICE f="Michiru060"]
[OnName num="michiru"]
I'm thinking about something else.
[cpg cn=true]


[OnName num="yuma"]
I don't think so.
[cpg cn=true]


[VOICE f="Michiru061"]
[OnName num="michiru"]
"Is that so?　Yes.
[cpg cn=true]


She poked me with her foot while saying that.
[cpg]

She seemed completely innocent, but maybe she was thinking of me.
[cpg]

I don't know anymore. ......
[cpg]


;//移植のためシーンをカットしています

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


...... whether it's all natural or calculated.
[cpg]


By the time I realized that she was a magical woman, it was all too late.
[cpg]


Knowing this, there was nothing more I could do.
[cpg]


I am already a captive of Michiru.
[cpg]


She has long since driven me mad,...... and I am now at Michiru's mercy.
[cpg]



;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





Time is passing. Seasons pass rapidly.
[cpg]


The relationship between my sister and I was more than awkward, it was acrimonious.
[cpg]


Time passed without any repair of our relationship.
[cpg]


Autumn came, winter came, ...... spring came again.
[cpg]


During that time, I kept coming back to Michiru's place.
[cpg]


Michiru-san kept repeating to me that it was okay for me to be corrupted.
[cpg]


Then, I was also feeling that I should become so. ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





The graduation ceremony for my seniors was approaching. I was talking with my senior.
[cpg]


I was talking to her, or rather, she was talking to me.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Reina074"]
[OnName num="reina"]
I see things aren't going well with your sister.
[cpg cn=true]


[OnName num="yuma"]
I was talking to her. "Leave it alone,......, it's our problem."
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina075"]
[OnName num="reina"]
I'm sure it's better to leave it at that. The most important thing to remember is that you should never let it go. But don't have any regrets. You should not be corrupt, Yuma.
[cpg cn=true]


Usually, everyone says so. I know that.
[cpg]


Michiru was the only one who told me it was okay to be corrupt.
[cpg]






;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



My seniors graduated. I will graduate next year.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu102"]
[OnName num="chinatsu"]
"...... Yu-kun, what are you going to do about your career?"
[cpg cn=true]


[OnName num="yuma"]
I'm thinking of going on to higher education. It's a little far from here.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu103"]
[OnName num="chinatsu"]
"I see. ...... you're going to stay at a boarding house?"
[cpg cn=true]


[OnName num="yuma"]
I'm going to live there with Michiru. I think I will live there with Michiru."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Chinatsu104"]
[OnName num="chinatsu"]
I don't know what my sister would say if she knew.
[cpg cn=true]


[OnName num="yuma"]
It's fine. It's not like I'm asking my parents to pay rent for two.
[cpg cn=true]


I'm not talking about getting the parents to pay for the two of us.
[cpg]


I don't think money is an issue. The problem is not there.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夜）******************************************************





[OnName num="yuma"]
......Koyuki-sister."
[cpg cn=true]


I'm still hated by her. I want to get things back on track.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Koyuki180"]
[OnName num="koyuki"]
I want you to get out.
[cpg cn=true]


But that didn't seem to be happening.
[cpg]


[OnName num="yuma"]
I need to talk to you.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki181"]
[OnName num="koyuki"]
Get out. Please, don't make me do this.
[cpg cn=true]


[OnName num="yuma"]
......
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（昼）******************************************************





Time ticked away. A year passed in the blink of an eye.
[cpg]


I was not able to see my sister off when I graduated from the school and was going on to higher education.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『町』（夜）******************************************************





Living with Michiru was difficult in some ways.
[cpg]


She rarely did housework. She does, but she is lazy.
[cpg]


She rarely cleans the house. So I had to do the cleaning, even though I'm not the most conscientious person.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru062"]
[OnName num="michiru"]
I was so excited to be able to live with her.
[cpg cn=true]


[OnName num="yuma"]
......I think so too.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michiru063"]
[OnName num="michiru"]
I'm sure we really are lovers now, aren't we? I'll never let you go.
[cpg cn=true]


I was not able to say anything when he told me that.
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I wanted to stay with Michiru as long as I could.
[cpg]


I was so far away from my studies. She really is on the road to depravity.
[cpg]


Michiru-san is extremely lazy and lazy, but she also has a magical nature.
[cpg]


Aside from Chinatsu, Koyuki has not called me.
[cpg]


;//[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michiru064"]
[OnName num="michiru"]
What?　Staring at the phone?
[cpg cn=true]


[OnName num="yuma"]
No, ......, it's nothing.
[cpg cn=true]


;//[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michiru065"]
[OnName num="michiru"]
Are you thinking about Koyuki?　No, I'm not thinking about her.
[cpg cn=true]


;//[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michiru066"]
[OnName num="michiru"]
Yuma, you're too serious. You can be more sloppy.
[cpg cn=true]


Michiru-san tells me that we don't have to think about anything else and that we can corrupt together.
[cpg]


Maybe that's the way to make things easier for me.
[cpg]



;//========================================
;//●ＣＧ非エロ（ヒロインと二人布団で眠っている。ヒロインは主人公に微笑みかけている）ev_52
;//人物１：ヒロイン５
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：主人公の部屋　下宿先
;//時間　：夜
;//========================================



[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_op"]
;**【ＣＧ】 ev_52_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Michiru067"]
[OnName num="michiru"]
Hey, Yuma-kun, ......
[cpg cn=true]


[OnName num="yuma"]
What is it, Michiru?
[cpg cn=true]



[VOICE f="Michiru068"]
[OnName num="michiru"]
Why are all men so serious?
[cpg cn=true]



[VOICE f="Michiru069"]
[OnName num="michiru"]
As far as I know, there aren't that many serious women.
[cpg cn=true]


[OnName num="yuma"]
Is that so?
[cpg cn=true]



[VOICE f="Michiru070"]
[OnName num="michiru"]
Yes, they are. Yes, and the same goes for love. There are a lot more sloppy women out there.
[cpg cn=true]


......That may be what I'm missing. The most important thing to remember is that you should never be afraid to ask for help.
[cpg]



[VOICE f="Michiru071"]
[OnName num="michiru"]
If I were in Yuma's shoes, I would have already forgotten about Koyuki.
[cpg cn=true]


Koyuki and Michiru must have been friends.
[cpg]


But she says such a thing. That is not the same as just being sloppy.
[cpg]


 Even if I think about that... I can't leave Michiru san's place anyway.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I am sure we will continue to fall together wherever we go.
[cpg]



;//ＥＮＤ　ヒロイン５ルート
[SCENE id=15]

[jump storage="epend.ks" target="*start"]


;//==============================

