
*start

;//==============================
;//３、波々乃

;#################################################
*Ep011|The Mysterious Charm of Ms. Nanano
;#################################################


*select04_3|The Mysterious Charm of Ms. Nanano

[SCENE id=11]


......I've had my eye on Ms. Hazuno for a while now.
[cpg]


It was like I was forced to attack her, and we did not live together nor were we schoolmates.
[cpg]


Even so, I found myself attracted to Ms. Nanano's mysterious charm.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





However, going out with Ms. Nanano meant that I would have to choose between Koyuki and my senpai.
[cpg]


I had my doubts, but my feet were leading me to Ms. Nanano's house.
[cpg]


I could have taken a different route, even though it was on my way to school.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano050"]
[OnName num="nanano"]
Good morning, Yuma-kun. Yuma-kun.
[cpg cn=true]


[OnName num="yuma"]
...... hi."
[cpg cn=true]


I'm sure Ms. Nanano can see through all my worries.
[cpg]


But then again, I wish they could see through all my love too.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano051"]
[OnName num="nanano"]
"......What's the matter, stop. Don't you have to go to school?
[cpg cn=true]


[OnName num="yuma"]
No, that ......
[cpg cn=true]


I couldn't say what I was thinking. I went straight to the school.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





The first time I went to the school, it was during lunchtime.
[cpg]


I heard that she and her sister Chinatsu are staying at Michiru's house.
[cpg]


I thought to myself, "They must be really good friends. ...... But I'm pretty sure that today is ......
[cpg]


I'm sure that my mom and dad will be home late too. So it's just me at home?
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





On my way home, I also met Ms. Nanano.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano052"]
[OnName num="nanano"]
She said, "Good evening. You're home early today, aren't you?"
[cpg cn=true]


Ms. Nanano. She's really pretty in this way.
[cpg]


[OnName num="yuma"]
She said, "...... there's no one at home today."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano053"]
[OnName num="nanano"]
What are you talking about?
[cpg cn=true]


Ms. Nanano is a person who notices many things rather easily.
[cpg]


I think he must be aware of my thoughts too. But ...... just for today, I'm pretending I don't know.
[cpg]


[OnName num="yuma"]
"If you want, why don't you come to ...... my house?"
[cpg cn=true]


I said. I'm sure Ms. Nanano knows what that means.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano054"]
[OnName num="nanano"]
She said, "Yes, that's fine. It's okay, I don't have anything special to do.
[cpg cn=true]





;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se001"]
;//【ＳＥ】『ドア閉まる』


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夕方）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

I walked Ms. Nanano up to her room. I had only one thing to do once I got here.
[cpg]


[OnName num="yuma"]
I thought I was going to confess to Ms. Nanano.
[cpg cn=true]


I stayed to confess my feelings to Ms. Nanano.
[cpg]


It is an act of betrayal for both Koyuki's sister and her senpai. With that in mind.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano055"]
[OnName num="nanano"]
I'm not going to tell you all about it. I like you, Yuma-kun."
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Nanano056"]
[OnName num="nanano"]
If you don't feel comfortable saying it, you don't have to say anything."
[cpg cn=true]


Ms. Nanano says to me like that. I had no choice but to indulge her. ......
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト

;//移植のためシーンをカットしています



[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano057"]
[OnName num="nanano"]
I had no choice but to indulge her. "I wonder if your parents and sisters will be home soon.
[cpg cn=true]


[OnName num="yuma"]
She said, "My sisters are staying ...... but my parents might be coming home."
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano058"]
[OnName num="nanano"]
I think I'd better go back then."
[cpg cn=true]


 Nanano san said so and tried to leave the room.
[cpg]


I feel unspeakable. I want to hold them back. But ......
[cpg]


It would be a disaster if I had to keep them and run into my father or mother.
[cpg]


[OnName num="yuma"]
I understand."
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************





After seeing off Ms. Nanano, I was left all alone in the large house.
[cpg]


I feel unspeakable loneliness.
[cpg]


Even though Koyuki's sister and her senpai are fond of me.
[cpg]


Still, I feel lonely because Nanano-san is not here. ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





Morning comes again. I head to the school. The days repeat themselves.
[cpg]


On the way to the school, Nanano-san is sometimes here and sometimes not here.
[cpg]


When I see her, that alone makes me happy, and when she's not there, I look for her, thinking that she's hiding in the shadows somewhere.
[cpg]


I was that crazy about Ms. Nanasno. ......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





On the way home. On my way home, I run into Ms. Nanano.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano059"]
[OnName num="nanano"]
I'm so crazy about Hazuno that I'm looking for her. Yuma-kun,......, what a face you make."
[cpg cn=true]


I don't know if I'm making such a funny face. I don't know anymore.
[cpg]


I'm so happy to see Nanano.
[cpg]


[OnName num="yuma"]
......Nanano-san, are you free right now?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano060"]
[OnName num="nanano"]
I'm free. What's wrong?
[cpg cn=true]


[OnName num="yuma"]
Well, I was wondering if you would like to ......
[cpg cn=true]


It's as if my feelings have already been conveyed. And Ms. Nanano says she likes me.
[cpg]


Then maybe there's nothing for me to say, but I have to say it.
[cpg]


[OnName num="yuma"]
......I want to talk to Ms. Nanano."
[cpg cn=true]


My words are vague. Ｎanano-san laughs.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano061"]
[OnName num="nanano"]
I'd like to talk to you," she said. If you want to talk, I'm here. But ...... is fine. Please come up."
[cpg cn=true]


She understands the meaning of my words. Ms. Ｎanano is really kind ......
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_11_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************




I was taken up to Ms. Ｎanano's house. There, we talked about a few things.
[cpg]


[OnName num="yuma"]
She said, "...... you are often at home, aren't you, Ms. Ｎanano? What do you usually do?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano062"]
[OnName num="nanano"]
I'm a graduate student. I'm not a very serious student.
[cpg cn=true]


If you are a graduate student or a ...... student, you are a little older than Koyuki.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano063"]
[OnName num="nanano"]
You are also a student, aren't you, Yuma?
[cpg cn=true]


[OnName num="yuma"]
Yes,.......
[cpg cn=true]


I think I was more nervous than when I came here before. Then Ms. Ｎanano said to me.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano064"]
[OnName num="nanano"]
I like younger guys. I have my eyes on cute boys like Yuma-kun."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
;//[VOICE f="Nanano065"]
;//[OnName num="nanano"]
;//「最初は、無理矢理しちゃいましたよね。今でも反省してます」
;//[cpg cn=true]
;//
;//
;//[OnName num="yuma"]
;//「いや、そんな……反省だなんて」
;//[cpg cn=true]


There was silence for a while. After that, Ms. Ｎanano said, "I was really happy.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Nanano066"]
[OnName num="nanano"]
I was really happy. When Yuma asked me for me.
[cpg cn=true]


[OnName num="yuma"]
I see.
[cpg cn=true]


;//移植のためシーンをカットしています

;//ブラックアウト


[FG f="CHA03_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Nanano067"]
[OnName num="nanano"]
I like you, Yuma. Do you like me too, Yuma-kun?
[cpg cn=true]


[OnName num="yuma"]
"...... Yes. Of course.
[cpg cn=true]


I had no choice but to answer that.
[cpg]


Now that I have come this far, I have to take responsibility as a man.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





But how do I explain it?　I have to explain to both senpai and Koyuki, ......
[cpg]


But for both of them, Ms. Ｎanano is a stranger.
[cpg]


I wonder if I can tell them such a thing out of the blue. ......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





Morning, with a gloomy mood. I'm heading to the school.
[cpg]


First of all, I have to confide in my senior. If anything, I think she is less depressed.
[cpg]


Telling her I'm going out with someone else is something I can't avoid.
[cpg]


In order to go out with Ｎanano, it is necessary ...... to think so and make up your mind.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="yuma"]
The first thing to do is to make sure that you have a good time with your partner. I need to talk to you about something."
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina130"]
[OnName num="reina"]
"...... what?　You're going to reply to me?"
[cpg cn=true]


[OnName num="yuma"]
I'm going to go to the school today after school. After school today, okay?"
[cpg cn=true]


I make a promise like that and think about how I'm going to explain it to my seniors.
[cpg]


I can't just tell him everything straight out. What should I do ......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





In the meantime, it's after school.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina131"]
[OnName num="reina"]
"...... Let me hear it. My confession, my reply."
[cpg cn=true]


[OnName num="yuma"]
"Yeah. ...... sorry for making you wait.
[cpg cn=true]


[OnName num="yuma"]
I can't go out with my senpai because I have someone I like. That's why I can't go out with my senpai.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina132"]
[OnName num="reina"]
"I see."
[cpg cn=true]


The actual "I'm not a fan of the newest and most popular of the newest and most popular of the newest.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina133"]
[OnName num="reina"]
I'm not going to tell you who I like.
[cpg cn=true]


[OnName num="yuma"]
I can't tell you.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina134"]
[OnName num="reina"]
You don't have to hide it. It's Yuma's sister, isn't it?
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina135"]
[OnName num="reina"]
'There's no one else. ...... If it was someone else, I might not be able to accept it.'
[cpg cn=true]


The older guy goes so far as to say, "I'm sorry. I have no choice but to reply.
[cpg]


[OnName num="yuma"]
I was so excited.
[cpg cn=true]


I was swept away. I'm going to lie as a result, but I guess it can't be helped. ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





I had no way of knowing who I was in love with.
[cpg]


Then, I also thought that it would be good if this lie would convince them.
[cpg]


Thinking about this, I headed to Ｎanano's house. ......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_11_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************




[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano068"]
[OnName num="nanano"]
Welcome. I can't believe that Yuma visited me.
[cpg cn=true]


[OnName num="yuma"]
I was thinking that I wanted to see Ｎanano-san. I wanted to meet Ms. Habino.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano069"]
[OnName num="nanano"]
I'm not saying that I wanted to do something, but that I wanted to see her.　I wanted to do something, didn't I?
[cpg cn=true]


I couldn't answer that. Ms. Ｎanano is smiling.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano070"]
[OnName num="nanano"]
What should we do today?　Is there something you want to do?
[cpg cn=true]


[OnName num="yuma"]
Well, then ......."
[cpg cn=true]


I told her what I wanted her to do.
[cpg]



;//========================================
;//●ＣＧ（主人公に迫るヒロイン。体を密着させている）ev_70
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_70_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Nanano071"]
[OnName num="nanano"]
I told her that I wanted her to stay by my side ......, but really, is that all you want?
[cpg cn=true]

;//移植のためシーンをカットしています


[OnName num="yuma"]
I said, "......."
[cpg cn=true]


Of course, some minds want more than that. But I didn't say anything.
[cpg]

Feeling her body heat is also frustrating.
[cpg]

But I didn't take any steps on my part.
[cpg]


[VOICE f="Nanano072"]
[OnName num="nanano"]
She said, "I'm always waiting for you. So, please come over anytime."
[cpg cn=true]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





And I leave Ｎanano's house.
[cpg]


I want to stay longer. I'd like to stay longer, and I need to tell the truth to Koyuki.
[cpg]


But Koyuki-san is probably even more jealous than her senpai, so ......
[cpg]


I can't tell her the truth about Ms. Nanano even more so.
[cpg]


I think she would be more convinced if I told her that I'm still dating my senpai.
[cpg]



;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d2"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************





I returned home and finished eating dinner. Afterwards, Chinatsu-san asks me this question.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu117"]
[OnName num="chinatsu"]
'...... Yu-kun, are you hiding anything from me?'
[cpg cn=true]


[OnName num="yuma"]
She says, "No, I'm not. ......
[cpg cn=true]


I'm at a loss for words. Will even Chinatsu-sister see through me?
[cpg]


If so, I wouldn't be surprised if Koyuki has already figured it out.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu118"]
[OnName num="chinatsu"]
I'm sure she's still waiting for Yu-kun."
[cpg cn=true]


[OnName num="yuma"]
"......, that's right."
[cpg cn=true]


I have to say something, whether I tell Koyuki sister the truth or a lie.
[cpg]


I'm going to go out with Nanano. As long as that doesn't change, it's terrible to make her wait. ......
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I knew that, but I couldn't get out of my somewhat depraved days.
[cpg]


One holiday while putting off a formal reply to Koyuki's sisters,......
[cpg]






[FADEOUTBGM]
[window target=false]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（昼）******************************************************





I told my sisters that I was going to hang out with some guy friends and meet up with Ms. Nanano.
[cpg]


It was quite far from my house. I was sure I wouldn't run into her by any chance.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano073"]
[OnName num="nanano"]
"Oh, Yuma."
[cpg cn=true]


[OnName num="yuma"]
Sorry, did I keep you waiting ......?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano074"]
[OnName num="nanano"]
No, I just arrived. I just arrived.
[cpg cn=true]


Ms. Nanano laughed softly. In this situation, Koyuki would have complained, and her seniors would have been grumpy.
[cpg]


It's not something to compare with anyone else, but she has room to spare. She charmed me to no end.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano075"]
[OnName num="nanano"]
She was always fascinated with me.
[cpg cn=true]


[OnName num="yuma"]
I've thought about it a lot, in my own way, but, you know, ......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano076"]
[OnName num="nanano"]
I'm sure it's exhausting to lead a girl on a date. You can forget all about it.
[cpg cn=true]


[OnName num="yuma"]
What ......?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano077"]
[OnName num="nanano"]
I'll lead you, Yuma. I'm not sure what you're talking about, but I'm sure you're right.
[cpg cn=true]


They know everything about me. I can't say anything else.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I'm going to walk around town for a while and do some shopping. But it was mostly window shopping.
[cpg]


Even so, it was fun. With Ms. Nanano, everything was fun. ......
[cpg]



;//[FG f="CHA03_p5_00_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano078"]
[OnName num="nanano"]
Yuma, are you on time?"
[cpg cn=true]


[OnName num="yuma"]
"Oh, yes,......, um..."
[cpg cn=true]


I noticed that it was getting quite late ......
[cpg]


[free time=1000]


[OnName num="yuma"]
I'm going to go straight home from there.
[cpg cn=true]





;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夜）******************************************************





I'm going straight home from there. Sister Koyuki would be angry.
[cpg]


She'll probably even suspect that I was playing with a girl.
[cpg]


This time, there may be no escape: ......
[cpg]


How am I going to excuse myself? Or should I just tell them straight up that I'm going out with Ms. Nanano?
[cpg]


I feel like there's no point in even thinking about it.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki207"]
[OnName num="koyuki"]
It's late. What were you doing up until this late?"
[cpg cn=true]


[OnName num="yuma"]
I'm sorry.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Koyuki208"]
[OnName num="koyuki"]
You're hiding something, aren't you? No,...... I'll put it more succinctly. Are you seeing someone else?
[cpg cn=true]


[OnName num="yuma"]
It's ...... that.
[cpg cn=true]


It's now or never. It's now or never. I'm going to tell you a little bit at a time.
[cpg]


[OnName num="yuma"]
I'm sorry. I'm sorry for all the ...... things I did with your sister.
[cpg cn=true]


[OnName num="yuma"]
I like someone else besides you.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki209"]
[OnName num="koyuki"]
"It's ...... Rena, isn't it? I've been aware of it for a while.
[cpg cn=true]


[OnName num="yuma"]
......
[cpg cn=true]


This is not good. I'm going to get twisted if I don't do something about it. I'm not sure what to do with it.
[cpg]


At this rate, Senpai will think that I and Sister Koyuki are dating, and Sister Koyuki-neesan will think that I am dating.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki210"]
[OnName num="koyuki"]
But I can't help it if it's Rena-chan. We've known each other for a long time. ...... Yeah, I think I can give up."
[cpg cn=true]


[OnName num="yuma"]
'...... yeah.'
[cpg cn=true]


I couldn't say anything extra to my sister who was about to give up.
[cpg]


I wondered if it would be okay for me to go through with this, but ......
[cpg]


I decided to tell her step by step because it's the same as going out with someone else.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





I told my senpai that I had an appointment with Koyuki-sis and left the school early.
[cpg]


Conversely, I tell Koyuki that I'm going to meet my senpai and will be home late.
[cpg]


Each of them agreed. I was naturally concerned about it.
[cpg]


Of course, I was not happy about it.
[cpg]



I had no choice but to keep on lying,......, wondering how it could have come to this.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano079"]
[OnName num="nanano"]
Good evening. Yuma-kun."
[cpg cn=true]


[OnName num="yuma"]
"Hi. ......
[cpg cn=true]


I should have been happy to meet with Ms. Nanano, but somewhere in my heart, I was carrying a dim light.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano080"]
[OnName num="nanano"]
......."
[cpg cn=true]


Ms. Nanano may see through that too.
[cpg]


But this is my problem, and it's a problem I have to deal with.
[cpg]


Ms. Nanano won't say anything. I know.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_11_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************





I'm going to ask her to take me to her house.
[cpg]


[OnName num="yuma"]
She says, "I don't see ...... your parents very often, is there something wrong?"
[cpg cn=true]


I wondered if I shouldn't ask, but I was curious and said it out loud.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano081"]
[OnName num="nanano"]
I was wondering if I was not supposed to ask this, but I was curious and spoke up. My father always works late at night.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano082"]
[OnName num="nanano"]
'So you don't need to worry. You can do what you want to do, Yuma-kun.
[cpg cn=true]


[OnName num="yuma"]
"Oh, really? ......?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Nanano083"]
[OnName num="nanano"]
Yes.
[cpg cn=true]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I feel like I'm going to be spoiled all the time. That's how I feel.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夜）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano084"]
[OnName num="nanano"]
I'll see you later. Please come back anytime."
[cpg cn=true]


Ms. Nanano gently enveloped everything I did.
[cpg]


I was spoiled by Nanano-san, who seemed to encompass everything. ......
[cpg]


[jump storage="ep012.ks" target="*start"]


;//==============================


