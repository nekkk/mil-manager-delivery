
*start

;//==============================
;//４、やっぱり小雪姉さんが好きだ



;#################################################
*Ep006|I like Koyuki
;#################################################



*select06_1|I love you, Koyuki!

[SCENE id=6]



......I just can't help it. I really like Koyuki, who was my closest friend.
[cpg]


Michiru is also coming to visit, so it is a good opportunity.
[cpg]


[OnName num="yuma"]
"...... Koyuki-sis. Chinatsu is there now too, right?"
[cpg cn=true]


[OnName num="yuma"]
The four of us have something to talk about.
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夜）******************************************************





We were gathered in Koyuki's room.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Chinatsu036"]
[OnName num="chinatsu"]
"...... what's the story?　Yu-kun.
[cpg cn=true]


[OnName num="yuma"]
I've got an answer for you. I gave an answer. I still love Koyuki.
[cpg cn=true]


From the beginning, I can say that this feeling has not changed at all.
[cpg]


[OnName num="yuma"]
I love Koyuki, and no matter what happens,......, it will probably never change.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Koyuki089"]
[OnName num="koyuki"]
Yuma ......
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[VOICE f="Chinatsu037"]
[OnName num="chinatsu"]
I see. So that's your conclusion, Yu-kun."
[cpg cn=true]


 Despite making a sad face, Chinatu nee-san didn't stop him.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Michiru018"]
[OnName num="michiru"]
I'm sure you're right. But why are you talking to me like that?"
[cpg cn=true]


[OnName num="yuma"]
;//「美知留さんともしたでしょう。これからは、遊びでも触れ合うことはないと思いますから」
'......I wanted to make sure Michiru-san was well informed.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki090"]
[OnName num="koyuki"]
I'm sure you'll be happy to know that I'm not the only one who has a problem with that. Thank you for choosing ...... Yuma."
[cpg cn=true]


[OnName num="yuma"]
I didn't do anything that warranted a thank you.
[cpg cn=true]


Rather, I even made the decision too late. I wish I could have said this line earlier.
[cpg]


[OnName num="yuma"]
I'm sorry. I'm the one who talked about what I wanted to talk about.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="Chinatsu038"]
[OnName num="chinatsu"]
It's okay. I'm glad to know how you feel.
[cpg cn=true]


I'm forcing you to do too much. But this is no longer an option.
[cpg]


I understand Chinatsu's feelings ......, but Koyuki is the only one for me.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





Then Michiru left, my sisters went back to their rooms, and I was left alone.
[cpg]


This is where it all started. My relationship with Koyuki is finally starting.
[cpg]


We are probably still playing lovers.
[cpg]


But in the end, this distance may be a good thing.
[cpg]


It could be said that we can confirm our love for each other.
[cpg]


I felt that the distance between us, whether touching or not, is nurturing our love. ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





After one night, Chinatsu sister had a calm expression on her face.
[cpg]


Koyuki looked happy. The first thing you need to do is to make sure that you have a good understanding of what is going on in your life.
[cpg]


[OnName num="yuma"]
"...... Koyuki-sis."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki091"]
[OnName num="koyuki"]
What?　If you don't do it quickly, you'll be late.
[cpg cn=true]


My sister was there as usual. But she was definitely different from before.
[cpg]


I've already told her that she's the only one for me. ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





Then I headed to the school.
[cpg]


My steps were somewhat light. I and Koyuki can make love to each other without any guilt anymore.
[cpg]


The first thing to do is to make sure that you have a good time.
[cpg]


But I was still happy. ......
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





And then, in the evening, I return home. Such days repeat themselves.
[cpg]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



We left the restaurant after a short time of touching each other.
[cpg]


In the end, we never picked up the microphone and sang. ......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





Everyday comes as it should. But the atmosphere is a little different.
[cpg]


Me and my sister Koyuki became good friends...... is not a word that can describe our relationship.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu039"]
[OnName num="chinatsu"]
I'm jealous. But I'm glad you're happy.
[cpg cn=true]


[OnName num="yuma"]
I'm sorry .......
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chinatsu040"]
[OnName num="chinatsu"]
Don't apologize. You just have to be magnanimous."
[cpg cn=true]


Chinatsu-sister told me that.
[cpg]


I know. I have no choice but to be magnanimous.
[cpg]


[free time=1000]



[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Koyuki092"]
[OnName num="koyuki"]
'What are you two talking about?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Chinatsu041"]
[OnName num="chinatsu"]
Nothing. Just some idle chitchat.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki093"]
[OnName num="koyuki"]
"Oh, really?　Well, that's good.
[cpg cn=true]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se011"]
;//【ＳＥ】『歩く』





Today, as usual, I head off to the academy.
[cpg]


In the past, I used to feel relieved by not being at home, but now it's the opposite.
[cpg]


I miss her so much when I'm at school.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina060"]
[OnName num="reina"]
How have things been going with you and your sister since then?
[cpg cn=true]


[OnName num="yuma"]
I should tell you at ......, right?
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina061"]
[OnName num="reina"]
I know. But I can usually tell without saying it.
[cpg cn=true]


I think you're probably right.
[cpg]


[OnName num="yuma"]
I haven't confessed to my sister Koyuki ...... yet, but I think I probably will.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina062"]
[OnName num="reina"]
"What's that ......?　You haven't confessed to her yet?
[cpg cn=true]


[OnName num="yuma"]
I'm not going to let you down. But, despite everything, Koyuki is the only one for me.
[cpg cn=true]


The first thing you need to do is to make sure that you have a good idea of what you want to do. And then he says this.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina063"]
[OnName num="reina"]
Yuma, you said so from the beginning.
[cpg cn=true]


That may be true. But then again, ......
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina064"]
[OnName num="reina"]
He said, "Oh, no. If only Yuma were an only child.
[cpg cn=true]


It seems that my seniors still like me.
[cpg]


I wondered why I was so popular with older people,......
[cpg]


But I also thought that now was not the time to look aside.
[cpg]


The only thing to think about now is that I love Koyuki.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************





Then I returned home. Koyuki was in the living room.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki094"]
[OnName num="koyuki"]
She said, "...... Yuma. Are you free right now?"
[cpg cn=true]


She said directly to me because Mom and Dad were not around.
[cpg]


[OnName num="yuma"]
What if I'm free?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki095"]
[OnName num="koyuki"]
"Because I want to be with you. You have points.
[cpg cn=true]


[OnName num="yuma"]
But you only have nine ...... points.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki096"]
[OnName num="koyuki"]
Then give me a shoulder massage. I'll give you one point for it.
[cpg cn=true]


I think the purpose is changing. ...... Well, that's okay.
[cpg]

[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
I rubbed her shoulders. I rubbed her shoulders and they didn't seem to be stiff at all.
[cpg]


[OnName num="yuma"]
I'm not at all sure they are stiff.
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki097"]
[OnName num="koyuki"]
I'm just happy to be touched by you.
[cpg cn=true]


It seemed more like just an excuse to get to the 10-point mark.
[cpg]


Well, I rubbed his shoulder, thinking it was okay.
[cpg]





;//ブラックアウト


;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夕方）******************************************************





We spent happy time together.
[cpg]


We were happy just to be able to touch each other. We both needed each other. ......
[cpg]


Maybe from here on out, nothing could ruin our happiness.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki098"]
[OnName num="koyuki"]
I said to her, "...... I've got to go make us some dinner.
[cpg cn=true]


[OnName num="yuma"]
I'll see you later. I'll see you later. ......
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_og"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（朝）******************************************************





Then, the criteria for the points my sister was giving me became more and more lenient.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki099"]
[OnName num="koyuki"]
Good morning, Yuma. Kiss me.
[cpg cn=true]


[OnName num="yuma"]
No, ...... good morning. What do you mean, kiss me?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki100"]
[OnName num="koyuki"]
She said, "Just kiss me. Just kiss me.
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
I woke up from sleep and put my lips to hers.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki101"]
[OnName num="koyuki"]
I'm glad you're ...... listening to me. I'll give you a point for this."
[cpg cn=true]


I felt like I was making up an excuse to score points.
[cpg]


I sensed it and knew that one day I would have to stop playing lover.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu042"]
[OnName num="chinatsu"]
Good morning, Yu-kun. Yu-kun.
[cpg cn=true]


[OnName num="yuma"]
Good morning, Chinatsu.
[cpg cn=true]


The relationship between me and Chinatsu sister did not become strained.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
 Chinatu-nee-san seemed to be relatively flattered.
[cpg]


If it's dragging too much, I'll have to take care of it too. 
[cpg]


But from the looks of it, she seems to be doing fine.
[cpg]


[free time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Koyuki102"]
[OnName num="koyuki"]
Let's have dinner now."
[cpg cn=true]


[OnName num="yuma"]
"Yeah, sure. ......
[cpg cn=true]


I eat dinner with my family. Talking about nothing else.
[cpg]


[OnName num="mother"]
"Chinatsu, have you lost some weight?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="Chinatsu043"]
[OnName num="chinatsu"]
I'm not thin. I've gained a little weight.
[cpg cn=true]


I somehow felt that going out with Koyuki's sister would destroy ...... this view.
[cpg]


 If Sister Koyuki-nee-san and I really don't hide anything when we go out together... Mom and Dad won't be able to stay calm.
[cpg]


I don't know. I don't know.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************





I'm going to go to the school and come back.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki103"]
[OnName num="koyuki"]
I'll go to the school and come back again. I need your help with something.
[cpg cn=true]


Koyuki catches me and tries to get me to do various things.
[cpg]


I can already see her intentions behind the scenes. She wants to be my lover.
[cpg]


Sis puts points on a loose standard.
[cpg]



;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夕方）******************************************************





;//そして、行為の後。俺は姉さんから提案された。というのは……
And after I finished helping her. I was proposed by my sister. Because ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki104"]
[OnName num="koyuki"]
She said, "Hey. Can't we stop playing lovers now?"
[cpg cn=true]


[OnName num="yuma"]
I said, "...... it's fine."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki105"]
[OnName num="koyuki"]
I mean, it's not like we're talking about ...... being able to stop now, is it?
[cpg cn=true]


It's true. We're like lovers now.
[cpg]


[OnName num="yuma"]
Yes, I do. I'll say it again: ...... I like my sister."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki106"]
[OnName num="koyuki"]
I love you too. I love you too.
[cpg cn=true]


[OnName num="yuma"]
I'll always be with you, sis.
[cpg cn=true]


 Somehow, I feel like I'm just playing lovers.
[cpg]


But from this point on, I really thought we were lovers.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki107"]
[OnName num="koyuki"]
I'm not going to hold back from this day forward. I want you to be ready for that.
[cpg cn=true]


[OnName num="yuma"]
I'm not going to hold back. I won't hold back either.
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************





After the family dinner.
[cpg]


After the family dinner, Koyuki and I were chatting in the living room. The actuality of the particulars is that they are not really a lot of.
[cpg]


[OnName num="mother"]
You two are getting along so well these days.
[cpg cn=true]


[OnName num="yuma"]
I don't know if that's true,......?　It's normal.
[cpg cn=true]


I hid it as quickly as I could. I thought Koyuki would get angry.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki108"]
[OnName num="koyuki"]
I'm sure she's right. I thought she would get angry, but she replied, "Yes, we have been good friends for a long time, haven't we?
[cpg cn=true]


She replied, "Yes. I was relieved and said to her: ......
[cpg]


[OnName num="mother"]
I don't know. Well, maybe it's just my imagination.
[cpg cn=true]


Mom said and left. My sister and I looked at each other.
[cpg]



[free time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Chinatsu044"]
[OnName num="chinatsu"]
What's wrong, you look so strange.
[cpg cn=true]


Then, Chinatsu comes over to us.
[cpg]


[OnName num="yuma"]
I was afraid that my mother would find out about it.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Chinatsu045"]
[OnName num="chinatsu"]
"Hmmm, I see. I'm still jealous."
[cpg cn=true]


 I think Chinatu-san must have mixed feelings.
[cpg]


But ...... I have no choice. I've decided I'm going to love you, Koyuki.
[cpg]


I definitely don't think it's right to apologize or anything here.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki109"]
[OnName num="koyuki"]
I'm sorry. ...... Chinatsu."
[cpg cn=true]


I thought, but Koyuki apologized.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Chinatsu046"]
[OnName num="chinatsu"]
She said, "Don't apologize. If you don't stay happy, I'll be sad.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Koyuki110"]
[OnName num="koyuki"]
"......Yes. I know.
[cpg cn=true]


I don't know how close they are. Koyuki and Chinatsu are real sisters.
[cpg]


 I didn't know what to say.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Chinatsu047"]
[OnName num="chinatsu"]
Can I go in first?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki111"]
[OnName num="koyuki"]
Yes.
[cpg cn=true]


I don't think it was my imagination that there was a smile between the two of them. Let's just say it was that good. ......
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I took a bath too and went to sleep in my room.
[cpg]


The next morning. I wake up with a somewhat uncomfortable or pleasant sensation.
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************



[SE f="se001"]
;//【ＳＥ】『ドア閉まる』





I hurried to the school.
[cpg]


[OnName num="yuma"]
Really, I'm going to be late. ......
[cpg cn=true]


But I also had the feeling that it would be fine.
[cpg]


I had a part of me that was putting my studies second.
[cpg]


I could live happily with my sister. That's all I needed to do. ......
[cpg]


If you really think like that, you're going to be corrupted.
[cpg]


I have to think about the future more carefully.
[cpg]


I have to think about it because I will be supporting my sister.
[cpg]


I have to do my best to live in the present. Not only my sister, but I think that's what it means to make people happy.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





Then, at the school. I was talking with my senior.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina065"]
[OnName num="reina"]
"So, how are things going with your sister?"
[cpg cn=true]


[OnName num="yuma"]
"Yeah, ...... we're doing well."
[cpg cn=true]


I was talking to my senior. I think the senior who said ...... looked a little sad.
[cpg]


If things don't work out between me and my sister, does that mean I have a chance?
[cpg]


I don't think she's thinking that far ahead. Maybe he's just genuinely jealous.
[cpg]


[OnName num="yuma"]
'I'll be happy. My senpai told me so.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Reina066"]
[OnName num="reina"]
Of course. I won't accept it if you make a mistake.
[cpg cn=true]


Saying that, he smiled a little.
[cpg]


I felt happy just to be able to see that. ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





It's a strange thing when you think about it.
[cpg]


I don't think I saw her as an object of romantic interest from the beginning.
[cpg]


I was thinking that if I was going to get together with someone, it would be more natural for it to be someone from my senior year.
[cpg]


But it didn't happen that way. ...... I loved Koyuki that much.
[cpg]


The first thing you need to do is to get a good idea of what you're looking for. It's so right in front of you that you don't even know it's there.
[cpg]


I know it's impossible to understand everything, but I still have a feeling that I want to sort it out.
[cpg]


When did I start liking my sister?
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se001"]
;//【ＳＥ】『ドア開く』





[OnName num="yuma"]
I'm home.
[cpg cn=true]







[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夕方）******************************************************





I returned to my room with these thoughts in my head.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki112"]
[OnName num="koyuki"]
Hey, Yuma.
[cpg cn=true]


[OnName num="yuma"]
"Wow,......, you're here."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki113"]
[OnName num="koyuki"]
I'm not going to say "oh my god". I'm your girlfriend, so it's okay for her to be in your room.
[cpg cn=true]


[OnName num="yuma"]
"Well, that may be true, but ......
[cpg cn=true]


I was talking to her and the same question came up again.
[cpg]


[OnName num="yuma"]
I was talking to her and the same question came up again: "......? When did I start liking you?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki114"]
[OnName num="koyuki"]
I don't know. I was a big sister.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki115"]
[OnName num="koyuki"]
I don't think you have to force yourself to remember. There is also love at first sight.
[cpg cn=true]


If you ask me, it does. Does it matter how long I've liked it or how much I like it now?
[cpg]




;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





I was in love with her for a long time, but she didn't let me go for a while.
[cpg]


It's as if my love for her is out of control, just like me sometime ago.
[cpg]


[OnName num="yuma"]
She said, "Sis,...... it's almost time for dinner, isn't it?　I have to go to the kitchen or they'll get suspicious."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki116"]
[OnName num="koyuki"]
"Fine,...... if they find out, then that's when they will."
[cpg cn=true]


I was puzzled and thought that my parents would find out if I was so blatant about it, so I said, "I'm sorry.
[cpg]


[OnName num="yuma"]
'......I might as well put a point on this one, on the contrary.'
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki117"]
[OnName num="koyuki"]
What do you mean?"　I think we're done playing lovers."
[cpg cn=true]


At any rate, I decided to get dressed. I was expressing my intention not to do it any more for now.
[cpg]


[OnName num="yuma"]
I still don't have the courage to tell my dad or mom everything.
[cpg cn=true]


It was already as good as said. It wasn't a question of whether I loved her or not.
[cpg]


[OnName num="yuma"]
So let's make some rules.
[cpg cn=true]






;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





So I came up with the idea of playing sister-brother.
[cpg]

I would make a point card, and we would play sister-brother until the points were accumulated.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki118"]
[OnName num="koyuki"]
I said, "Why are you doing that ......?　Don't you like me anymore?"
[cpg cn=true]


[OnName num="yuma"]
"It's not that I don't like you or anything, it's just that you're about to find out.
[cpg cn=true]



[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Koyuki119"]
[OnName num="koyuki"]
"......, but..."
[cpg cn=true]


[OnName num="yuma"]
"If you don't like me, you'll have to come up with some other rule."
[cpg cn=true]


[OnName num="yuma"]
I can't do it without any limits. Either way.
[cpg cn=true]


At first, Koyuki was reluctant to do so.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki120"]
[OnName num="koyuki"]
The first thing you need to do is to make sure that you have a good relationship with the person you are talking to. I don't want Yuma to hate me.
[cpg cn=true]


In the end, she accepted it for that reason.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Am I saying terrible things? Probably not.
[cpg]


I'm not ready for my parents to find out either.
[cpg]


Days pass by with this thought in my mind.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





Then, Koyuki started to do a lot of things for me.
[cpg]


On the other hand, I wonder if my parents would be suspicious of this.
[cpg]


I was thinking about that, but I started to appreciate what she did for me.
[cpg]





;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]



On the ...... holiday, while all this was going on, I met Koyuki and Chinatsu.
[cpg]





[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『町』（昼）******************************************************





I was out with Koyuki, Chinatsu and myself.
[cpg]


I was so worried that my parents would get suspicious if I was alone with Koyuki. So, Chinatsu came with me.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Chinatsu048"]
[OnName num="chinatsu"]
I hope I'm not interrupting anything.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki121"]
[OnName num="koyuki"]
She said, "No, you're not. You care too much.
[cpg cn=true]


[OnName num="yuma"]
That's right, you don't need to be bothered.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chinatsu049"]
[OnName num="chinatsu"]
I'm the one who's concerned, aren't I?　I don't want to be a part of your relationship.
[cpg cn=true]


[OnName num="yuma"]
But, you know, ......
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Chinatsu050"]
[OnName num="chinatsu"]
I have a few things I want to buy. Then we'll see.
[cpg cn=true]


[OnName num="yuma"]
Hey, Chinatsu!
[cpg cn=true]


[free time=1000]

I tried to chase after her, but Sister Koyuki-san stopped me.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki122"]
[OnName num="koyuki"]
"...... I think Chinatsu has some things to think about too. Maybe Chinatsu doesn't feel comfortable with us."
[cpg cn=true]


[OnName num="yuma"]
"......"
[cpg cn=true]


 If that's the case, I think it's necessary to create a situation where Chinatu nee-san isn't too uncomfortable.
[cpg]





;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

With that in mind, we enjoyed our date, just the two of us. And ......
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





The first thing to do is to make sure that you have a good time.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Chinatsu051"]
[OnName num="chinatsu"]
"How'd it go?　Did you both have fun?"
[cpg cn=true]


[OnName num="yuma"]
"......"
[cpg cn=true]


I couldn't say anything. But Koyuki said, "Yes.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki123"]
[OnName num="koyuki"]
Yeah. Lots of things.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chinatsu052"]
[OnName num="chinatsu"]
Yes. Good. ...... Make Yu-kun happy, okay?
[cpg cn=true]


There seemed to be no restraint where sisters were concerned.
[cpg]


It seemed to me that if Chinatsu's sister is satisfied with this, then this might be a good idea......
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]


The next thing I know, I'm back at home before the sun goes down.
[cpg]


[OnName num="mother"]
 "Welcome back. You guys are really good friends."
[cpg cn=true]


[OnName num="yuma"]
Ummm, yeah. ......
[cpg cn=true]


I couldn't respond quickly enough.
[cpg]

;//[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Chinatsu053"]
[OnName num="chinatsu"]
It's natural, isn't it? We're sisters and brothers.
[cpg cn=true]


 Said Chinatu nee-san firmly.
[cpg]


I feel kind of bad about it. But it's my choice......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki124"]
[OnName num="koyuki"]
I'll help you, won't I?　I'll help you."
[cpg cn=true]


It's a normal scene. I don't know how long these days will last.
[cpg]


I can only imagine what would happen if Koyuki and I were to start dating. ......
[cpg]


I can only imagine, but I could at least imagine that it would not be that easy.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I finished dinner and went to my room to relax.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





As she had said, Koyuki seemed to be unable to control her feelings.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki125"]
[OnName num="koyuki"]
She said, "Hey, is there anything I can do for you ......?"
[cpg cn=true]


It's the opposite of the relationship we once had. But there was also a sense that this was fun.
[cpg]


[OnName num="yuma"]
I don't know if there is anything else. I know it's hard, but bear with it.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

He looks pained at my words.
[cpg]


Koyuki is a very sweet person. But I can't let her get away with it.
[cpg]


If that were to happen, I would really lose all restraint. ......
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I'm sure she'll be very devoted to me. I could put a point on it any way I want, but ......
[cpg]


I tried to adjust it so that it would take about three days to accumulate. I figured she would be able to tolerate that long.
[cpg]


And then three days pass. ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夕方）******************************************************


We only became lovers once every three days, and only when we were alone together.
[cpg]

Repeating such things, we gradually deepened our bond.
[cpg]






;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





On my way to school, I saw Ms. Nanano in town. I greeted her.
[cpg]


[OnName num="yuma"]
Good morning, Ms. Hazuno. Ms. Nanano.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano030"]
[OnName num="nanano"]
Good morning, Yuma. I heard you went out with Koyuki-san.
[cpg cn=true]


[OnName num="yuma"]
"......" "Who told you?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano031"]
[OnName num="nanano"]
"From him. He was talking about how happy he was.
[cpg cn=true]


I see,...... sister, you're surprisingly light-spoken.
[cpg]


[OnName num="yuma"]
Please don't tell your father and mother even if you meet them.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano032"]
[OnName num="nanano"]
Of course. Of course, I won't tell anyone.
[cpg cn=true]


I had a relationship with Ms. Nanano, too, didn't I? ......
[cpg]


On top of that, it means that I dumped her.
[cpg]


And yet you treated me so nicely, I really don't know what to say.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano033"]
[OnName num="nanano"]
I told you before, please be happy."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano034"]
[OnName num="nanano"]
'I don't want to see you looking depressed, Yuma-kun. Come on, look up."
[cpg cn=true]


[OnName num="yuma"]
I'm sorry. ......
[cpg cn=true]


After talking about what I said, I went to the school.
[cpg]





;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夕方）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]

That evening. I was taken to my room by my sister.
[cpg]


[OnName num="yuma"]
I haven't even accumulated ...... points yet.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Koyuki126"]
[OnName num="koyuki"]
I was so happy to see her. I don't care who finds out.
[cpg cn=true]


She said reckless things. But she seemed to be ready for it.
[cpg]





;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



[OnName num="yuma"]
"Hey, sis!"
[cpg cn=true]





;//========================================
;//●ＣＧ（騎乗位。体を密着させていて、胸を当てているくらいの感じ）ev_25
;//人物１：ヒロイン１
;//服装１：私服（はだけ）
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================



[BGM f="bg_h2"]
;**【ＣＧ】 ev_25_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]


She pushed me down and held me close. I was so excited that I couldn't even pretend anymore.
[cpg]



[OnName num="yuma"]
"You think it's okay if ...... parents find out?"
[cpg cn=true]


[VOICE f="Koyuki127"]
[OnName num="koyuki"]
I was so afraid that my parents would find out about this. At least, I am.
[cpg cn=true]


[OnName num="yuma"]
Then I'd better make up my mind,.......
[cpg cn=true]


I don't know if I'll be able to decide right away. But I knew it was going to happen at some point.
[cpg]



[VOICE f="Koyuki128"]
[OnName num="koyuki"]
I'm sure we'll both understand. We'll both understand."
[cpg cn=true]


She's optimistic, but from my point of view, they're my in-laws.
[cpg]


Or is that better than ...... to someone you don't even know?
[cpg]

;//移植のためシーンをカットしています


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

More time passes from there. My sister and I were getting to know each other even better.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************





But Dad didn't say anything to us.
[cpg]


[OnName num="mother"]
Koyuki. Aren't you going to bring a boyfriend?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Koyuki129"]
[OnName num="koyuki"]
"Yes,......."
[cpg cn=true]


Mom says subtle things like this.
[cpg]


She may or may not be aware of it.
[cpg]


She speaks in really subtle lines,...... and we were at a loss for reactions.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki130"]
[OnName num="koyuki"]
'I don't have a boyfriend,.......'
[cpg cn=true]


[OnName num="mother"]
I don't have a boyfriend," she said. You are very attached to Yuuma.
[cpg cn=true]


[OnName num="yuma"]
I'm really at a loss for reactions.
[cpg cn=true]


I really don't know how to react to this.
[cpg]


 It's been a long time since I've been exposed.
[cpg]


 I think that maybe my sister and I have already been exposed.
[cpg]


Especially my mom, who looked at us with a smiling face.
[cpg]







[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン４の部屋』（夕方）******************************************************



[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[OnName num="yuma"]
I wonder if ...... they know."
[cpg cn=true]


I became anxious and asked my sister Chinatsu so.
[cpg]


If I ask Sis Koyuki, she will not give me an objective reply. That's what I was thinking, though: ......
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu054"]
[OnName num="chinatsu"]
I don't know. Ask your mother directly."
[cpg cn=true]


[OnName num="yuma"]
I know. ......"
[cpg cn=true]


I didn't get the answer I wanted. After all, if I wanted to know, I would have to ask him directly.
[cpg]


But that requires a way of asking that doesn't make you look suspicious. ......
[cpg]


Or maybe I should confide in her. I don't know.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu055"]
[OnName num="chinatsu"]
But ...... I don't think you have anything to worry about.
[cpg cn=true]


[OnName num="yuma"]
I don't have any proof. I don't have any evidence to support that.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chinatsu056"]
[OnName num="chinatsu"]
They won't do that. You worry too much, Yu-kun.
[cpg cn=true]


 Me and Chinatu-san had that kind of conversation, but in the end there was no conclusion.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夜）******************************************************





I told Koyuki what was on my mind.
[cpg]


I told her that my parents might be against it. I told her that.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki131"]
[OnName num="koyuki"]
I told her, "......I understand your concern. But I can't help thinking about it.
[cpg cn=true]


[OnName num="yuma"]
I wonder if that's true.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki132"]
[OnName num="koyuki"]
I'm worried too. I know they are in-laws to Yuma, but to me they are ...... my real parents."
[cpg cn=true]


[OnName num="yuma"]
I know. ...... I hope it goes well.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki133"]
[OnName num="koyuki"]
I don't think it's all about how you tell the story.
[cpg cn=true]


I certainly think so. Slowly, gradually letting it percolate through won't have much of an effect.
[cpg]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_og"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夜）******************************************************





How long can we keep it hidden?
[cpg]


I've stopped playing sister-brother to hide it in the first place and to avoid being found out.
[cpg]


But we'll have to talk about it someday. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki134"]
[OnName num="koyuki"]
"Shall we both go to bed together today? ......"
[cpg cn=true]


[OnName num="yuma"]
No, we can't. What if he sees you coming out?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki135"]
[OnName num="koyuki"]
"...... Yuma. I love you so much.　I love you so much.
[cpg cn=true]


[OnName num="yuma"]
"......"
[cpg cn=true]


I see. Is there perhaps nothing to fear?
[cpg]


If your parents are against you, maybe you just need to leave home.
[cpg]


Even if you get into a fight, that's what you need to do.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（昼）******************************************************





So, one holiday.
[cpg]


[OnName num="father"]
I said, "What's the matter?　You two are talking alone.
[cpg cn=true]


[OnName num="mother"]
"And it's not just that ...... you wanted to see us."
[cpg cn=true]


How should I start the conversation? I was lost.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki136"]
[OnName num="koyuki"]
Where should I start with ......?
[cpg cn=true]


But I didn't want to ask Koyuki to start the conversation.
[cpg]


[OnName num="yuma"]
I'll tell you first. I'll tell you first. ...... Dad, Mom.
[cpg cn=true]


[OnName num="yuma"]
I'm dating Koyuki.
[cpg cn=true]


[OnName num="father"]
......"
[cpg cn=true]


Dad had an unreadable expression on his face. If I had to say, he looked awestruck.
[cpg]


[OnName num="yuma"]
I'm sorry. I've been quiet all this time, but I hope you'll forgive me for going out with you."
[cpg cn=true]


[OnName num="father"]
"...... hahaha."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
Dad burst out laughing. Mom is giggling, too.
[cpg]


What kind of laugh is this? Is it a laugh that comes before anger?
[cpg]


[OnName num="mother"]
I've already heard from Chinatsu," he said. But I can't believe you guys told me.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Koyuki137"]
[OnName num="koyuki"]
"What, ...... by Chinatsu?"
[cpg cn=true]


What is it? You're hearing from Chinatsu-sis?
[cpg]


That should be such an attitude. It's out of tune. ......
[cpg]


[OnName num="father"]
We give you our blessing. Hey, Mom.
[cpg cn=true]


[OnName num="mother"]
Of course. I always thought this day would come.
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン４の部屋』（昼）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Koyuki138"]
[OnName num="koyuki"]
"...... Chinatsu. You told me everything.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chinatsu057"]
[OnName num="chinatsu"]
"I'm sorry,......, but I tried to be creative.
[cpg cn=true]


[OnName num="yuma"]
"Yeah, I kind of understand that. ...... Mom and dad accepted it, too.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Chinatsu058"]
[OnName num="chinatsu"]
I'm not lying when I say I want you to be happy.
[cpg cn=true]


 Chinatu-san won't tell you anything to interfere with our relationship anymore.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Koyuki139"]
[OnName num="koyuki"]
I'm sure that's the case. I can say that thanks to you, I was able to talk to her quickly. ......
[cpg cn=true]


The first thing to do is to make sure that you have a good relationship with your partner.
[cpg]


 The three of us seem to be able to remain good friends as siblings.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





The first thing you need to do is to make sure that you have a good relationship with your partner.
[cpg]



;//========================================
;//●ＣＧ非エロ（主人公と腕を組みながら歩くヒロイン。笑顔）ev_28
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：町
;//時間　：昼
;//========================================



[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_op"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]



It was early afternoon on a holiday. We were out on the town.
[cpg]


It's okay if anyone finds out. Or rather, there was no one to whom we could reveal it. We walked arm in arm.
[cpg]



[VOICE f="Koyuki140"]
[OnName num="koyuki"]
"Hey, Yuma. I'm glad to hear that everyone has been more supportive of us than we ...... thought.
[cpg cn=true]


[OnName num="yuma"]
I don't know if I would have ...... become like this if it weren't for the advice from the seniors at ...... the school and all that."
[cpg cn=true]



[VOICE f="Koyuki141"]
[OnName num="koyuki"]
I'm sure that's true. If that's the case, it must have been our destiny to end up like this.
[cpg cn=true]


Fate. Fate. I thought that was a pretty apt description of the situation.
[cpg]



[VOICE f="Koyuki142"]
[OnName num="koyuki"]
I won't leave you. I'm following you."
[cpg cn=true]


[OnName num="yuma"]
"You're following me ......?　Not the other way around?
[cpg cn=true]



[VOICE f="Koyuki143"]
[OnName num="koyuki"]
Not the other way around. You're a boy."
[cpg cn=true]


I see. ...... Well, it doesn't matter at this point whether he's older or not.
[cpg]


I have to be a man that Koyuki can be proud of.
[cpg]


I have to be able to say that I am the man of destiny for her as well. ......
[cpg]


I still have to move forward.
[cpg]


Of course, with Koyuki sister ...... no, with Koyuki.
[cpg]


[OnName num="yuma"]
Koyuki."
[cpg cn=true]



[VOICE f="Koyuki144"]
[OnName num="koyuki"]
"...... don't call me that all of a sudden. You startled me.
[cpg cn=true]


[OnName num="yuma"]
I'm sorry. ...... Koyuki-san, or something like that would be better.
[cpg cn=true]



[VOICE f="Koyuki145"]
[OnName num="koyuki"]
You're being a stranger. It's okay to be a little snow. Yeah. ...... I have to graduate from being a big sister, too."
[cpg cn=true]


That's what I'm saying. I, too, have to outgrow being just my sister's brother.
[cpg]


I still have to move on. ......
[cpg]




;//ブラックアウト
;//ＥＮＤ　ヒロイン１ルート
[SCENE id=13]

[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

