

*start|


;#################################################
*Ep002|Time to make up your mind.
;#################################################

[stflag flag2 = 0]

[if exp={ isSystemFlagsEnabled( "sysfla2") }]
[if exp={getFlagValue("flag2") == 0 }]
[stflag flag2 = 1]
[endif]
[endif]


[SCENE id=2]






[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]


[OnName num="father"]
"...... what's up. The three of you shut up."
[cpg cn=true]


[OnName num="mother"]
"Yeah, I know. It's like a funeral.
[cpg cn=true]


[OnName num="yuma"]
"It's nothing. It's all right.
[cpg cn=true]


Neither Mom nor Dad knew what was going on. That was a good thing for me.
[cpg]


Since yesterday, my relationship with Koyuki has been strained.
[cpg]


She has been less tempting to me. On the other hand, I can't do it even though I know that if I ask her for something, something might happen.
[cpg]

Chinatsu-san acts as if nothing has happened.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





In the morning, when I headed to the school, she was in a high state of blankness.
[cpg]


I don't know what I should look like when I talk to my senpai.
[cpg]


In the first place, it was not a good idea to talk to my senpai.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I think my senpai noticed something was wrong when he saw my face.
[cpg]


But she didn't inquire any further.
[cpg]


From her point of view, I'm sure she would have wanted to ask me something, but ......
[cpg]


But she didn't go any further than she had to.
[cpg]


Maybe she saw me confused and got confused too.
[cpg]







[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





On the way home. I was a little depressed but also hopeful to be back home with Koyuki.
[cpg]


She had said that I should vent.
[cpg]

Maybe if I pressed her, she might be able to satisfy my feelings.
[cpg]






;//ブラックアウト

[SE f="se001"]
;//【ＳＥ】『ドア閉まる』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




[OnName num="yuma"]
"I'm home. ......"
[cpg cn=true]


I made sure Koyuki's shoes were there and headed for my room.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夕方）******************************************************





I was so excited to be able to see her, and I was so excited to be able to see her.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki036"]
[OnName num="koyuki"]
I went to her room and asked her, "......, you must have something to tell me. You came to my room."
[cpg cn=true]


There was an awkward, nervous silence.
[cpg]


[OnName num="yuma"]
I said, "About the other day..."
[cpg cn=true]


I said that much and couldn't say anything else.
[cpg]


My mouth is dry. What should I do? What should I do?
[cpg]


;//========================================
;//●ＣＧ（しゃがんで主人公に近づくヒロイン）ev_01
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[wait time=1000]

While I'm thinking this, my sister comes closer to me.
[cpg]



[VOICE f="Koyuki037"]
[OnName num="koyuki"]
You look bitter, Yuma.
[cpg cn=true]


[OnName num="yuma"]
"It's not hard at all," she said.
[cpg cn=true]



[VOICE f="Koyuki038"]
[OnName num="koyuki"]
I told you that you should vent. I didn't mean it half-heartedly.
[cpg cn=true]


[OnName num="yuma"]
I'm going to run away again.
[cpg cn=true]


I was about to run away again. I'm not going to run away again.
[cpg]


I can't run away, I thought, and I gave up.
[cpg]



[VOICE f="Koyuki039"]
[OnName num="koyuki"]
"Hey, Yuma."
[cpg cn=true]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Then she kissed me.
[cpg]


It was just a touch, but I could feel how she felt. ......
[cpg]

;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夕方）******************************************************


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]


[OnName num="yuma"]
......"
[cpg cn=true]


We didn't say much to each other.
[cpg]


We've crossed the line. I couldn't help but think nothing of it.
[cpg]

I can't go back to the way things were with Koyuki.
[cpg]



[VOICE f="Koyuki040"]
[OnName num="koyuki"]
"Hey, Yuma."
[cpg cn=true]


I was about to say something to her, but I interrupted her.
[cpg]


[OnName num="yuma"]
I'm sorry, Koyuki, ...... forget about today.
[cpg cn=true]



[VOICE f="Koyuki041"]
[OnName num="koyuki"]
What?
[cpg cn=true]


[OnName num="yuma"]
I know it's very selfish of me, but I want you to forget ...... about it.
[cpg cn=true]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I'm depressed. Even though I'm depressed, I'm still hungry.
[cpg]


It was hard to eat face to face with my sister, but I couldn't not.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





I take a bath and then wrap myself up in a blanket in my room.
[cpg]


I did something I shouldn't have done. This was definitely not right.
[cpg]


Why couldn't I control my desires ......?
[cpg]


I can't help it. ...... I'm like this.
[cpg]


After venting, I'm left with nothing but regret. I know that, but I can't stop.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************



[SE f="se011"]
;//【ＳＥ】『歩く』





I was on my way to the school in a depressed state. I met Ms. Nanano.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano006"]
[OnName num="nanano"]
She said, "Yuma-kun. Good morning.
[cpg cn=true]


[OnName num="yuma"]
Good morning. ......
[cpg cn=true]


My tone was dark. I couldn't hide the fact that I was depressed.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano007"]
[OnName num="nanano"]
'......Yuma, are you feeling down about something?
[cpg cn=true]


[OnName num="yuma"]
I'm not that depressed.
[cpg cn=true]


Even Ms. Nanano can see that he is depressed.
[cpg]


 I was trying to hide it, but it was exposed.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano008"]
[OnName num="nanano"]
I tried to hide it, but she knew. I'm sure you'll feel better after talking to me.
[cpg cn=true]


[OnName num="yuma"]
Please leave me alone. ...... I'm in no condition to talk to anyone.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Nanano009"]
[OnName num="nanano"]
But you look very gloomy.
[cpg cn=true]


Ms. Nanano tries to dig up the root of the matter, but I hide it from her.
[cpg]


She was suspicious, but didn't pry any further at this point.
[cpg]


[OnName num="yuma"]
I'm sorry, I really can't talk about it. I really can't talk about it.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano010"]
[OnName num="nanano"]
I understand."
[cpg cn=true]


I thought to myself, "Nanano-san doesn't ask too many questions.
[cpg]



;//■選択肢
[switch]
[case "She's so thoughtful and kind."]
	[swap]
	[jump target="*select03_1"]
[case "I just wanted her to listen more."]
	[swap]
	[jump target="*select03_2"]
[endswitch]


11. She's a caring and kind person.
12. I wanted her to listen more.



;//==============================
;//11、気を遣ってくれて優しい人だ
*select03_1|When I made up my mind


;//後の選択肢３が発生する
[stflag flag3 = 1]
[system sysflg3=true]



I think she's been caring and hasn't been prying.
[cpg]


I think she is not only calm, but thoughtful.
[cpg]


[jump target="*select03_3"]
;//==============================
;//12、もっと聞いて欲しかった
*select03_2|When I make up my mind


;//後の選択肢３が発生しない
[system sysflg3=false]




I had a feeling that I really wanted her to listen more. But I couldn't say it myself.
[cpg]


I walked down the street to school with a hazy feeling in my heart.
[cpg]



;//==============================
*select03_3|Time to make up my mind


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************





In the meantime, I arrived at the school.
[cpg]


I was listening to the morning class with an open mind. ......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





[FG f="CHA02_p3_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Reina026"]
[OnName num="reina"]
I asked him, "...... are you okay?　Are you listening to me?"
[cpg cn=true]


[OnName num="yuma"]
"Yeah, um, ...... what was that?"
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina027"]
[OnName num="reina"]
I guess you're not listening to ...... anymore."
[cpg cn=true]


I can't help but feel depressed even in front of my seniors.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina028"]
[OnName num="reina"]
What's wrong?　You've been acting strange lately, Yuma.
[cpg cn=true]


The senior staff members are a bit skeptical and try to ask the truth.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina029"]
[OnName num="reina"]
Did something happen with your sister, by any chance?
[cpg cn=true]


[OnName num="yuma"]
What?
[cpg cn=true]


I guess he was just guessing.
[cpg]


[OnName num="yuma"]
No, that's not true. That's the only thing that's definitely different. ......
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina030"]
[OnName num="reina"]
So ......."
[cpg cn=true]


That's not good. I reacted unnecessarily.
[cpg]


Senpai knows me. You would imagine that my sister and I would not have had a fight.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina031"]
[OnName num="reina"]
"...... maybe you and your sister ...... something, did you?"
[cpg cn=true]


So he asks me this ......
[cpg]


The way he asks, not what happened, but what did you do.
[cpg]


I fall silent. This is like an affirmation.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina032"]
[OnName num="reina"]
I'm not sure if that's a good idea. I'd like you to stay in the classroom for a bit after school today. ......
[cpg cn=true]


[OnName num="yuma"]
What?　Why ......?
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina033"]
[OnName num="reina"]
I don't know. I don't know either.
[cpg cn=true]


That's not an answer. But we decided to meet up again after school.
[cpg]






;//ブラックアウト



[SE f="se007"]
;//【ＳＥ】『学園のチャイム』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


And then after school came. I was in a blank mind, but I guess my senpai was the same way.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





After school at the school. Alone with senior.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina034"]
[OnName num="reina"]
He said to me, "I'm sorry for taking up your time. Sorry to take up your time.
[cpg cn=true]


[OnName num="yuma"]
I said, "Okay, but what was it about?　What was it?
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina035"]
[OnName num="reina"]
"Nothing....... Well, that's..."
[cpg cn=true]


The senior did not confess to me, and the delicate time passed.
[cpg]


;//========================================
;//●ＣＧ（二人立っている状態。ヒロインの胸が主人公に当たっている）ev_02
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[wait time=1000]

However,......, her intentions were conveyed by her actions immediately after that.
[cpg]

 If you want to ask me something, you don't need to be so close.
[cpg]



[VOICE f="Reina036"]
[OnName num="reina"]
She said, "Hey, Yuma. I'm going to ask you one more time, did you do something with your sister?"
[cpg cn=true]


[OnName num="yuma"]
"No, that's not ...... true."
[cpg cn=true]


I tried to hide it by becoming slurred.
[cpg]


However, I also thought that the reaction would not be good for the seniors.
[cpg]



[VOICE f="Reina037"]
[OnName num="reina"]
The first thing you need to do is to look at the picture. Turn around.
[cpg cn=true]


[OnName num="yuma"]
"......?　The actuality is that you can't just go to the store and buy a new one.　Hey, mugg!
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The senior kissed me. I was so surprised that I froze.
[cpg]



[VOICE f="Reina038"]
[OnName num="reina"]
I was so surprised that I froze.
[cpg cn=true]


Senpai continued kissing me. He didn't put his tongue in, but it was a long kiss.
[cpg]

;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[wait time=1000]

[VOICE f="Reina039"]
[OnName num="reina"]
I was so surprised that I froze. Huh......."
[cpg cn=true]


[OnName num="yuma"]
What's wrong, senpai?
[cpg cn=true]


I was suddenly at a loss for what to do.
[cpg]


I was confused by the suddenness of the situation.　No, how is that possible ......?
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





I was surprised, but I couldn't escape.
[cpg]


[FG f="CHA02_p5_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Reina040"]
[OnName num="reina"]
"......Ah, ah, ah, ah, ah, ah, ah, ah, ah, ah, ah, sorry, you're surprised."
[cpg cn=true]


I was so surprised, but I couldn't get out of there.
[cpg]


I didn't know why he did that.
[cpg]


[FG f="CHA02_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina041"]
[OnName num="reina"]
I was so sorry," he said. Forget it, forget everything that happened today."
[cpg cn=true]


I had heard that line somewhere before. This time, I was the one who was told.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I couldn't watch her crying face for long as she said, "Forget it.
[cpg]


I left the room just like that. ......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





Confusing. Confused, usually. I returned to my house without being able to think straight.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano011"]
[OnName num="nanano"]
"Welcome home, Yuma.
[cpg cn=true]


[OnName num="yuma"]
"Oh, ...... thanks."
[cpg cn=true]


I meet Ms. Nanano on my way home. I was thinking about letting out everything that was in my mind there, but ......
[cpg]


I couldn't get involved because I was the most uninvolved. Thinking this, I could not say anything.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano012"]
[OnName num="nanano"]
You look paler than you did on the way there.
[cpg cn=true]


[OnName num="yuma"]
'That may be so. ......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano013"]
[OnName num="nanano"]
I'm always willing to listen to what you have to say. But I won't force you.
[cpg cn=true]


[OnName num="yuma"]
"Thank you, .......
[cpg cn=true]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Back at home, we had a family meal together.
[cpg]


[OnName num="father"]
What's wrong, Yuma? You seem to be eating a little too much.
[cpg cn=true]


[OnName num="yuma"]
You're always like this,......, you worry too much."
[cpg cn=true]


Koyuki's sister also looked uncomfortable.
[cpg]


 Chinatu-nee-san, who was looking at it, was looking at her with eyes that made her wonder if something had happened.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************





The living room at night when no one is around. I was watching TV alone.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu014"]
[OnName num="chinatsu"]
I asked her, "Yu-kun,......, what's wrong?"
[cpg cn=true]


I've been getting a lot of questions lately about what's wrong or what's wrong with me.
[cpg]


But it can't be helped. I'm out of my mind right now.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu015"]
[OnName num="chinatsu"]
"Did something happen with your sister?"
[cpg cn=true]


I knew it. I knew that she had sensed that I had done something with Koyuki, and she mentioned it to me.
[cpg]


I decided to give up, thinking I couldn't hide it any longer.
[cpg]


[OnName num="yuma"]
"...... actually ......"
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




I dared not tell him what had happened with my senpai and only told him what had happened with Koyuki.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu016"]
[OnName num="chinatsu"]
Yes, it was. ......
[cpg cn=true]


 Chinatu nee-san also just made an awkward face.
[cpg]


After all, saying it won't help. I thought so.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chinatsu017"]
[OnName num="chinatsu"]
I'll think about it in my own way.
[cpg cn=true]


[free time=1000]

With that, she went back to her room.
[cpg]


I returned to my room, wondering what was going on .......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（昼）******************************************************





Several days pass. I can't take back what I did with Koyuki and my senpai now.
[cpg]


The awkward, hazy, and uncomfortable time went on.
[cpg]


[jump storage="ep003.ks" target="*start"]
