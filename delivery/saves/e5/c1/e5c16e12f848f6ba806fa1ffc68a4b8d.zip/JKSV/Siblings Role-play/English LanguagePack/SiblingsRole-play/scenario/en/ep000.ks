
*start



;#################################################
*Ep000|Dangerous existence that leads to corruption
;#################################################


[SCENE id=0]


;//姉あそび　シナリオ
;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり

;//小雪　　　　　私服
;//麗奈　　　　　私服　制服
;//波々乃　　　　私服
;//千夏　　　　　私服　アルバイトの制服
;//美知留　　　　私服

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//小雪　　　　　一人称「私」　小雪呼び「なし」　麗奈呼び「麗奈ちゃん」
;//　　　　　　　波々乃呼び「波々乃さん」　千夏呼び「千夏」　美知留呼び「美知留さん」　悠真呼び「悠真」
;//麗奈　　　　　一人称「私」　小雪呼び「小雪さん」　麗奈呼び「なし」
;//　　　　　　　波々乃呼び「波々乃さん」　千夏呼び「千夏さん」　美知留呼び「美知留さん」　悠真呼び「悠真」
;//波々乃　　　　一人称「私」　小雪呼び「小雪さん」　麗奈呼び「麗奈さん」
;//　　　　　　　波々乃呼び「なし」　千夏呼び「千夏さん」　美知留呼び「美知留さん」　悠真呼び「悠真くん」
;//千夏　　　　　一人称「私」　小雪呼び「お姉ちゃん」　麗奈呼び「麗奈ちゃん」
;//　　　　　　　波々乃呼び「波々乃さん」　千夏呼び「なし」　美知留呼び「美知留さん」　悠真呼び「ゆうくん」
;//美知留　　　　一人称「私」　小雪呼び「小雪」　麗奈呼び「麗奈さん」
;//　　　　　　　波々乃呼び「波々乃さん」　千夏呼び「千夏さん」　美知留呼び「なし」　悠真呼び「悠真くん」
;//悠真　　　　　一人称「俺」　小雪呼び「小雪姉さん」　麗奈呼び「先輩」
;//　　　　　　　波々乃呼び「波々乃さん」　千夏呼び「千夏姉さん」　美知留呼び「美知留さん」　悠真呼び「悠真」


;//以下、残したＣＧを列挙いたします
;//小雪　　ev_01 ev_13 ev_25 ev_28
;//麗奈　　ev_02 ev_53 ev_54 ev_56 ev_67
;//波々乃　ev_08 ev_70 ev_74 ev_80
;//千夏　　ev_30 ev_32 ev_41
;//美知留　ev_43 ev_44 ev_49 ev_52


[stflag flag2 = 0]
[stflag flag3 = 0]
[stflag flag5 = 0]
[stflag flag6 = 0]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





Spring. Late afternoon on a holiday.
[cpg]


It's that time of year when the mood is somehow buoyant, but it's already been a long time since the start of a new semester.
[cpg]


The mid-term exam has been bothering me.
[cpg]


I, Yuma Amagayi, was facing a kind of crisis.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夕方）******************************************************





[OnName num="yuma"]
......"
[cpg cn=true]


I study alone, in my room. Without looking aside from everything else.
[cpg]


But as I was trying to get lost in my studies, there was a temptation.
[cpg]



;//下記セリフは？？？と名前を隠してください





[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki001"]
[OnName num="unknown"]
Hey Yuma, it's not efficient to be so rooted in the past. Let's play with your sister.
[cpg cn=true]


[OnName num="yuma"]
......
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki002"]
[OnName num="unknown"]
"Yuma, Yuma. I'm not wrong when I say it's important to take a break.
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
Koyuki, the older sister, who keeps her body close to mine.
[cpg]



;//ここから名前欄を隠さないでください




;//[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
Temptation for me. Koyuki and Chinatsu, my two older sisters.
[cpg]


;//[free time=1000]
;//[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
;//[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

I lost my parents when I was very young. It was an accident.
[cpg]



My two older sisters are the daughters of my father's older brother. That's why they share the same last name as mine.
[cpg]


In other words, they are my cousins. They are my step-sisters, but they have been with me since I was quite young.
[cpg]



She was like a real sister to me.
[cpg]


[free time=1000]


[SE f="se004"]
;//【ＳＥ】『ノック』


As I was thinking this, there was a knock at the door.
[cpg]

[SE f="se001"]
;//【ＳＥ】『ドア開く』

[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chinatsu001"]
[OnName num="chinatsu"]
"Oh, Yu-kun,......, you're still studying, aren't you?"
[cpg cn=true]


[OnName num="yuma"]
Leave me alone,...... sisters, don't you have anything else to do?"
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki003"]
[OnName num="koyuki"]
I just have to make fun of Yuma and the day will go by.
[cpg cn=true]


He says such things without hesitation.
[cpg]


 I don't think there is any hesitation about it at all, but Sister Koyuki-san is this kind of person.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chinatsu002"]
[OnName num="chinatsu"]
But, Sis, I have to make dinner soon.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki004"]
[OnName num="koyuki"]
Oh, is it that time already?　It can't be helped.
[cpg cn=true]


Finally, Koyuki leaves my body.
[cpg]


The two sisters were a dangerous existence for me, leading me into depravity.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



The two are older than Koyuki and Chinatsu, but Koyuki is the one with the more childlike personality.
[cpg]


Both of them are good cooks. The two of them are very good at cooking, especially Koyuki, who even claims that cooking is her hobby.
[cpg]


[OnName num="yuma"]
I'm in a slightly low state of excitement. ......
[cpg cn=true]


I'm a little low ...... because I didn't get a lot of studying done today. ......
[cpg]


The first thing to do is to make sure that you have a good time.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************




[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chinatsu003"]
[OnName num="chinatsu"]
Sis, you're cooking well again.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki005"]
[OnName num="koyuki"]
I know. I have to get a firm grip on Yuma's stomach.
[cpg cn=true]


The first time I went to the beach, I was in the middle of the ocean.
[cpg]


 I'm embarrassed, but I don't think Sister Koyuki-nee-san doesn't mind that kind of thing.
[cpg]


Or is she doing it on purpose to see my reaction? ......
[cpg]


[OnName num="mother"]
Koyuki would make a good wife.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Koyuki006"]
[OnName num="koyuki"]
I agree. I think so too. What do you think, Yuma?"
[cpg cn=true]


Mom says unnecessary things. I'm not sure if it's a good idea to have a newborn baby, but I'm sure it's a good idea to have a newborn baby.
[cpg]


[OnName num="yuma"]
I don't know,......, if she's a good wife, she won't tease my brother and interfere with his studies.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki007"]
[OnName num="koyuki"]
I'm embarrassed. I don't know,louis vuitton handbags outlet.
[cpg cn=true]


No matter what I said, Koyuki's pace would always be the same. I was no longer able to make a poor rebuttal.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_og"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





I have always wanted to be corrupted.
[cpg]


The two sisters are the symbols of my corruption.
[cpg]


But both Koyuki and Chinatsu are like sisters to me.
[cpg]


I should not look at them with ill-omened eyes. I have to get rid of these feelings. ......
[cpg]


With this in mind, I tried to concentrate on my studies.
[cpg]


[OnName num="yuma"]
I try to concentrate on my studies with this thought in mind. ...... I should probably take a bath soon.
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************





I went through the living room on my way to take a bath. Then........
[cpg]


I was wondering around in my bath towel. She probably knew that I might pass by here.
[cpg]


;//[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki008"]
[OnName num="koyuki"]
"Oh, Yuma. Did you admire my sister's beauty?
[cpg cn=true]


[OnName num="yuma"]
I'm not admiring her beauty. I just came here to take a bath.
[cpg cn=true]


;//[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki009"]
[OnName num="koyuki"]
I just came here to take a bath. You are still looking at me with your eyes.
[cpg cn=true]


I know you're going to say that whether your eyes are swimming or not. I know.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I take a bath and think alone.
[cpg]


I'm still fine with Chinatsu. I'm not sure what Koyuki is thinking about.
[cpg]


I'm struggling every day not to make her an object of my sexual desire. ......
[cpg]


In every aspect of my daily life, especially Koyuki is actively trying to seduce me.
[cpg]


Of course, she does more than just deceive me.
[cpg]


She can study, she's smart and ...... I respect her, but I think she's tempting me too much.
[cpg]




;//ブラックアウト





I walk back to my room with these thoughts in my head.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





[OnName num="yuma"]
Wow!"
[cpg cn=true]


Then I found Koyuki sleeping on my futon.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki010"]
[OnName num="koyuki"]
Yuma, you've lost some weight.
[cpg cn=true]


[OnName num="yuma"]
Get out of my room, I'm going to change now.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki011"]
[OnName num="koyuki"]
You can change here. I'm going to change my clothes now.
[cpg cn=true]


[OnName num="yuma"]
Why are you sleeping on my futon?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki012"]
[OnName num="koyuki"]
Of course it's because I want to sleep with you.
[cpg cn=true]


It's a mess. There is never a moment when you can escape her clutches. ......
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



After that, I managed to drag her out of the room, changed into my pajamas and went to sleep.
[cpg]


[OnName num="yuma"]
I can't ......
[cpg cn=true]


I can't sleep. I can't sleep because she tempts me every time.
[cpg]


I know she's playing with me, teasing me. I can tell if she wants to have a relationship with me or not.
[cpg]


I'm sure she doesn't really want to have a relationship with me or anything like that.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（朝）******************************************************






[VOICE f="Koyuki013"]
[OnName num="koyuki"]
"Soooo, sooo ......
[cpg cn=true]


[OnName num="yuma"]
"......Koyuki-sis."
[cpg cn=true]


When I woke up in the morning, there was something strangely warm and soft that made me feel uncomfortable.
[cpg]


[OnName num="yuma"]
'Come on!　Don't sneak into someone's futon without permission.
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki014"]
[OnName num="koyuki"]
Nn......?　Oh, good morning. Good morning, Yuma.
[cpg cn=true]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



There was no peace in the house. I ate breakfast and decided to go out.
[cpg]


Today is Sunday. A walk would be nice for a change.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





As I was walking, I saw a familiar face.
[cpg]

[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
It was Ms. Nanano Kisaragi. She is a beautiful older sister who lives in the neighborhood.
[cpg]


She lives at home and is often seen tending to her garden.
[cpg]


I have never asked her age, but she is probably older than Koyuki.
[cpg]


She had an adult atmosphere, was calm, and was a comforting person for me.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano001"]
[OnName num="nanano"]
"Ah, Yuma-kun. Good morning.
[cpg cn=true]


[OnName num="yuma"]
Good morning, Ms. Nanano.
[cpg cn=true]


Unlike Koyuki, she never tried to seduce me, so we never had a strange relationship.
[cpg]


I just wanted her to heal me.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano002"]
[OnName num="nanano"]
The first thing that comes to mind is the fact that the weather is getting warmer and warmer,......, and I can't sleep at this time of the year.
[cpg cn=true]


[OnName num="yuma"]
I know,......, I also feel sleepy when I have to study.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano003"]
[OnName num="nanano"]
The first thing to do is to get a good idea of what you are looking for. Why do you study?
[cpg cn=true]


They say some pretty fundamental things. But my answer was firmly set in stone.
[cpg]


[OnName num="yuma"]
It's to go to a good school.
[cpg cn=true]


I didn't need to explain the necessity of that.
[cpg]


I had thought so, but Ms. Nanano gave me an unexpected answer.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano004"]
[OnName num="nanano"]
Studying is good, but you also have to work on your love life.
[cpg cn=true]


[OnName num="yuma"]
Love?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano005"]
[OnName num="nanano"]
Yes," she said. Yuma, don't you have a girlfriend?
[cpg cn=true]


[OnName num="yuma"]
......Studies are still important to me.
[cpg cn=true]


Ms. Nanano is a beautiful woman, but the most important thing for me is still the future.
[cpg]


 I wanted to succumb to Sister Koyuki nee-san's temptation, and I suppressed my feelings of wanting to have a good relationship with Nanano san.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（昼）******************************************************



[SE f="se001"]
;//【ＳＥ】『扉開く』



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

After a short walk, I returned to my room to find Koyuki sitting in my chair reading manga.
[cpg]


Normal. She was doing so with an attitude as if to say that this is normal.
[cpg]


[OnName num="yuma"]
'Sis ......, really, come on.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki015"]
[OnName num="koyuki"]
What?"
[cpg cn=true]


What," she came. Really, I have no idea how to convince her.
[cpg]


I drag my sister out of the room. This feels like something I did yesterday. ......
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Time passes quickly as I think about this and study.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン４の部屋』（夜）******************************************************





I had finished dinner and the group afterwards had passed, and I had come to Chinatsu-sis's place.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu004"]
[OnName num="chinatsu"]
You look so serious. What's wrong?"
[cpg cn=true]


[OnName num="yuma"]
'I can make a face like this, ...... Koyuki-sis, can't you do something about it?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chinatsu005"]
[OnName num="chinatsu"]
I think Sis also likes Yu-kun."
[cpg cn=true]


I guess Chinatsu-sister is right. It must be some kind of warped expression of affection.
[cpg]


[OnName num="yuma"]
I think it's better to say something directly to her.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu006"]
[OnName num="chinatsu"]
I think it would be better to say something directly to her. It would not make much sense for me to tell you.
[cpg cn=true]


Chinatsu sister is an intelligent person. My vague suggestions will be corrected.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



 That said, it would be difficult for me to completely Sister Koyuki-san.
[cpg]


I was at a point where I didn't know what to do.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





After the holiday was over, I headed to the school.
[cpg]


I don't dislike the school, in fact, I like it.
[cpg]


It's not just that everyone is there for the same reason, but there is someone I want to meet.
[cpg]


I can't see that person during the morning. I mean, he/she is not my classmate.
[cpg]



;//ブラックアウト
[window target=false]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





Her name is Rena Hayagashi.
[cpg]

[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina001"]
[OnName num="reina"]
She's not my classmate in the morning. Your sister is interrupting me."
[cpg cn=true]


[OnName num="yuma"]
I wonder if ...... I can do something about it.
[cpg cn=true]


He is a senior to me. But I don't feel like using polite words.
[cpg]


She was usually friendly, and it even felt distant to use polite words.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina002"]
[OnName num="reina"]
I don't know, I'm an only child. I don't know, I'm an only child.
[cpg cn=true]


[OnName num="yuma"]
I don't know...it's a matter of life and death if you can't study at this critical time in your life.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina003"]
[OnName num="reina"]
I can't think of any good ideas.
[cpg cn=true]


In this way, we are not at each other's throats.
[cpg]


Of course, we are not lovers, but I think we are close enough to be best friends.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina004"]
[OnName num="reina"]
But I know the test is coming up. I was thinking that I would like to study with someone too.
[cpg cn=true]


[OnName num="yuma"]
What?　What do you mean by that?
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Reina005"]
[OnName num="reina"]
I'd like to hold a study group. I'd like to go to Yuma's house too.
[cpg cn=true]


I'd like to go to Yuma's house too.
[cpg]


But what would your sisters think?　I heard my senpai's words, and I thought to myself.
[cpg]



;//■選択肢
[switch]
[case "I would gladly accept it."]
	[swap]
	[jump target="*select01_1"]
[case "I wouldn't feel comfortable inviting them to my house with my sisters"]
	[swap]
	[jump target="*select01_2"]
[endswitch]


7, I would gladly accept.
8. I would not be comfortable inviting them to my sister's house.



;//==============================
;//７、喜んで受け入れる
*select01_1|Dangerous existence that leads to depravity


;//後の選択肢２が発生する
[stflag flag2 = 1]
[system sysflg2=true]



[OnName num="yuma"]
I don't wish it. Thank you. When shall we do it?
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina006"]
[OnName num="reina"]
"Maybe the next weekend. How about Yuma?
[cpg cn=true]


[OnName num="yuma"]
"Yeah, that's fine. Then, I'll look forward to it.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina007"]
[OnName num="reina"]
Me too. I'm genuinely interested in what Yuma's room is like.
[cpg cn=true]


 Unlike Sister Koyuki-san, who always sees her as an older sister, she still sees seniors as strangers.
[cpg]


The actuality of this is that there was a little bit of expectation.
[cpg]


I had a feeling of fidgeting.
[cpg]


[jump target="*select01_3"]
;//==============================
;//８、姉の居る家に呼ぶのは気が引ける
*select01_2|Dangerous existence that leads to depravity


;//後の選択肢２が発生しない

[system sysflg2=false]



[OnName num="yuma"]
I was thinking, "Yes, it's fine,......, my sister is there too, and she's probably going to be attracted to me."
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina008"]
[OnName num="reina"]
I'm not going to pull that on you. I would never pull away from something like that.
[cpg cn=true]


[OnName num="yuma"]
But ......
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Reina009"]
[OnName num="reina"]
It's decided. I'll be at Yuma's the next weekend or so.
[cpg cn=true]


[OnName num="yuma"]
......
[cpg cn=true]


The actual "I'm not a fan of the way you do it, but I'm not a fan of the way you do it.
[cpg]



;//==============================
*select01_3|A dangerous existence that leads to corruption.




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Then I leave the academy after promising a study session with my senpai.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





It's strangely warm. This winter was mild, but still too warm.
[cpg]


It's almost lukewarm.
[cpg]


They say that the number of perverts increases in spring, and somehow I feel as if I don't understand that.
[cpg]


I'm also about to give in to the temptation of ...... Koyuki's sister. ......
[cpg]


[OnName num="yuma"]
What are you thinking?"
[cpg cn=true]


I said to myself, then raised my depressed face and walked away.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************





When I got back to the house, there was one more shoe.
[cpg]


It was a woman's shoe, but it wasn't Koyuki's or Chinatsu's. They were not my mother's shoes either.
[cpg]


I wondered what it was and headed to my room. ......
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





On the way there, I heard a conversation coming from Koyuki's room.
[cpg]


I wondered if someone was coming. Thinking so, I knocked.
[cpg]



[SE f="se004"]
;//【ＳＥ】『ノック』


[WAIT time=2500]



[VOICE f="Koyuki016"]
[OnName num="koyuki"]
"Oh, Yuma?　Come in."
[cpg cn=true]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夕方）******************************************************





There was a woman, probably about the same age as Koyuki.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Koyuki017"]
[OnName num="koyuki"]
I'll introduce you to her, her name is Michiru. She's a friend of mine from college.
[cpg cn=true]


[OnName num="yuma"]
"......, hi."
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Michiru001"]
[OnName num="michiru"]
Oh, she's so cute! Is this the Yuma that Koyuki was talking about?
[cpg cn=true]


There's no one else. I'm the only one with three siblings, me and my two sisters.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki018"]
[OnName num="koyuki"]
I'm so proud of you, aren't you? Isn't he cute? I'm so proud of him.
[cpg cn=true]


Koyuki also said that without hesitation.
[cpg]


I feel embarrassed, but ...... Michiru is a beautiful woman.
[cpg]


She seems like an adult woman, different from Ms. Nanano.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Michiru002"]
[OnName num="michiru"]
Come here, Yuma. Let's talk with your sister.
[cpg cn=true]


I did as I was called and sat down near Michiru-san.
[cpg]


While Ms. Nanano is calm and collected, Michiru is more ...... sloppy.
[cpg]


The way he speaks, or the atmosphere he is surrounded by, or something.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="Michiru003"]
[OnName num="michiru"]
The first thing to do is to make sure that you have a good idea of what you're looking for. I want to eat her.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki019"]
[OnName num="koyuki"]
I want to eat him. I won't let anyone take Yuma away from you.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA05_p5_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Michiru004"]
[OnName num="michiru"]
"That's okay, just a little bit. Here, there you go.
[cpg cn=true]


Michiru-san patting my head. I wonder if this is skinship.
[cpg]


 Even so, it was awfully sticky, and I thought.
[cpg]



;//■選択肢
[switch]
[case "She's so familiar with me."]
	[swap]
	[jump target="*select02_1"]
[case "I don't feel bad about being treated so nicely."]
	[swap]
	[jump target="*select02_2"]
[endswitch]


9、He is so familiar with me.
10. I don't feel bad for being so cute.



;//==============================
;//９、馴れ馴れしい人だ
*select02_1|Dangerous existence that leads you to depravity


;//後の選択肢６が発生しない
[system sysflg6=false]
;//[free time=1000]




[OnName num="yuma"]
"Oh, no, please don't do that. ......"
[cpg cn=true]


[FG f="CHA05_p5_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Michiru005"]
[OnName num="michiru"]
"Oh, my God, why?　I wonder if she's shy.
[cpg cn=true]


He touched my cheek. I was startled and stood up.
[cpg]



[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[OnName num="yuma"]
I ...... will go back to my room.
[cpg cn=true]


With that, I left Koyuki's room.
[cpg]



[SE f="se001"]
;//【ＳＥ】『ドア閉まる』





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[jump target="*select02_3"]
;//==============================
;//10、こんなに可愛いがられて悪い気はしない
*select02_2|Dangerous existence that leads to depravity


;//後の選択肢６が発生する
[stflag flag6 = 1]
[system sysflg6=true]




I didn't feel bad about being treated like this.
[cpg]


I was happy to have a connection with a beautiful sister. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Koyuki020"]
[OnName num="koyuki"]
Hey, Michiru. That's enough!
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Michiru006"]
[OnName num="michiru"]
I was happy to have a connection with a beautiful older woman. I'm not going to say that.
[cpg cn=true]


The first time I saw her blush, I thought Koyuki was burning with jealousy.
[cpg]



[SE f="se001"]
;//【ＳＥ】『ドア閉まる』





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





After that, I left Koyuki's room.
[cpg]



;//==============================

*select02_3|A dangerous existence that leads you to depravity




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





After a while, Michiru-san left.
[cpg]


We all eat dinner together, and I go back to my room afterwards.
[cpg]


[OnName num="yuma"]
......"
[cpg cn=true]


Alone, I think silently. I was wondering why I was only liked by the older people.
[cpg]


I noticed that everyone loves me like an older sister and everyone loves me like a younger brother.
[cpg]


But when it came to lovers, I felt it was different.
[cpg]


If I had to say, my senpai was the closest in age to me, and I wondered if she would be the one to be my girlfriend.
[cpg]


[OnName num="yuma"]
No, that's not quite right. ......
[cpg cn=true]


This was also based on a process of elimination.
[cpg]


That's how unlikely Koyuki and Chinatsu are as lovers.
[cpg]


I couldn't see my sister-in-law as a lover, which was something I couldn't think deeply about myself either.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





The night dawned again. I was getting ready to go to the school.
[cpg]


Koyuki and Chinatsu were also getting ready to leave for the university.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Koyuki021"]
[OnName num="koyuki"]
Yuma. Your sleeping habit is terrible.
[cpg cn=true]


[OnName num="yuma"]
I looked in the mirror.　I looked in the mirror.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Chinatsu007"]
[OnName num="chinatsu"]
Do you want me to fix it for you?
[cpg cn=true]


[OnName num="yuma"]
"No, ......, I can do it myself."
[cpg cn=true]


Despite all the comments from my overprotective older sisters, I headed off to the school.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





I'm going to the school and I'm going to meet my seniors.
[cpg]


Oh, by the way, we're going to have a study group soon.
[cpg]


Thinking about that, I headed for the school.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se007"]
;//【ＳＥ】『学園のチャイム』





I arrived at the school and the morning classes were over.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





My senpai had come to my class. We ate lunch together.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina010"]
[OnName num="reina"]
Yuma's lunch always looks so delicious, doesn't it?
[cpg cn=true]


[OnName num="yuma"]
Yuma's lunch always looks so good. My sister makes it for me.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina011"]
[OnName num="reina"]
......I knew it. This could be a competitor. .....
[cpg cn=true]


[OnName num="yuma"]
"Hmm?　What did you say?
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina012"]
[OnName num="reina"]
Nothing. Bon appétit.
[cpg cn=true]


[OnName num="yuma"]
"Uh, yeah. ......, Bon appétit."
[cpg cn=true]


Me and my senior are good friends. The first thing to do is to get a good idea of what you're looking for.
[cpg]


 I don't really remember how it all started, or how we became friends.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



 The two of us finished our meal while talking nonchalantly.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA02_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Reina013"]
[OnName num="reina"]
I'm looking forward to the study meeting soon. I'm looking forward to it.
[cpg cn=true]


Yes. I was a little nervous because it was the first time I had ever had a senior student come to my house.
[cpg]


[OnName num="yuma"]
"I'll tell you again, ......, I have two older sisters in my house.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina014"]
[OnName num="reina"]
I know. Koyuki and Chinatsu, right?
[cpg cn=true]


The first time I met them, I had already told my seniors about my two older sisters, but this was the first time I actually met them.
[cpg]



;//==============================
;//選択肢７を選んでいた場合
[if exp={getFlagValue("flag2") == 0 }]
[jump target="*sw7_1"]
[endif]





But I was still looking forward to that day.
[cpg]


I was looking forward to meeting the older sister.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina015"]
[OnName num="reina"]
I was also looking forward to meeting the older sister. I'd like to see Yuma's room, too.
[cpg cn=true]


[OnName num="yuma"]
'Yeah, I'd like to see Yuma's room. Either way, this weekend, right?
[cpg cn=true]


[jump target="*sw7_2"]
;//==============================
;//選択肢８を選んでいた場合
*sw7_1|Dangerous existence that leads to depravity




I was concerned about the presence of the sisters who were flirting with me.
[cpg]


I hope things will pass without incident, I thought as the days went by.
[cpg]



;//==============================

*sw7_2|Dangerous existence that leads to depravity

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





Days pass by. I am in the midst of my youth, and time should be passing slowly, but I still feel as if it is passing too fast. ......
[cpg]


But still, I felt like it was passing too fast.
[cpg]


[jump storage="ep001.ks" target="*start"]

