

*start


;#################################################
*Ep010|Happy times.
;#################################################


[SCENE id=10]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





There's nothing you can do from me. Even if I do nothing, morning comes.
[cpg]


In the morning, I have to go to the school.
[cpg]


Then I can meet my senpai .......
[cpg]


I have senpai. The first thing you need to do is to make sure that you have a good time.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina094"]
[OnName num="reina"]
"...... I see, your sister and ......"
[cpg cn=true]


[OnName num="yuma"]
I'm not sure what to do about it. We're not getting along. ...... I'm trying to work things out, too."
[cpg cn=true]


My senior listened to me seriously. But I think I'm relieved somewhere.
[cpg]


The more you are not getting along with me and my sister, the more relieved I am for her.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina095"]
[OnName num="reina"]
I wonder if words like "I'm here, ......" will help you.
[cpg cn=true]


[OnName num="yuma"]
No, I'm glad you're here. I'm glad you're here.
[cpg cn=true]


;//ブラックアウト
;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************



[SE f="se011"]
;//【ＳＥ】『歩く』





[OnName num="yuma"]
I'm glad. ......."
[cpg cn=true]


I walk around thinking alone. I think Koyuki is a very possessive person.
[cpg]


And it's not just a sister-brother relationship. If that were the case, it would be as if I had pushed my sister away.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu107"]
[OnName num="chinatsu"]
"Oh, Yu-kun. Are you home now?"
[cpg cn=true]


[OnName num="yuma"]
"Is Chinatsu-sis ...... going home too?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu108"]
[OnName num="chinatsu"]
I'm not sure. I heard you're dating ...... Rena-chan?"
[cpg cn=true]


Has Chinatsu-sis been told about it? That's right.
[cpg]


But they don't seem that shocked.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Chinatsu109"]
[OnName num="chinatsu"]
She said, "Hey, ...... can you and your sister make up?　I feel sorry for your sister if you don't."
[cpg cn=true]


Rather, she even went so far as to intercede in what was turning into a fight.
[cpg]


But I don't think Koyuki sister would understand.
[cpg]


That would be the only way to bring senpai directly to her. ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="1/3" time=800]
[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="3/3" time=800]
So, another day. I invited my senpai to my house.
[cpg]


My parents were there. I decided to skip over my sister and tell my parents.
[cpg]


[OnName num="yuma"]
I said, "...... we're dating. I know, right?"
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Reina096"]
[OnName num="reina"]
"Umm, yeah...... what can I say, well, I'm sorry."
[cpg cn=true]


My senior was stiff and nervous.
[cpg]


;//[free time=1000]


[OnName num="father"]
The actuality is, you can't just go to the store and buy a new one. I'm sorry.
[cpg cn=true]


[OnName num="mother"]
The actuality is that the actuality is that the actuality is not really a good thing. Koyuki can also give her blessing, right?
[cpg cn=true]


It's a very implicit way of saying it.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Koyuki195"]
[OnName num="koyuki"]
"Blessing ......, blessing ......."
[cpg cn=true]


There's no way I can do it,......," murmured Koyuki in a small voice.
[cpg]


The senior is still nervous. The first thing that comes to mind is the fact that the two of them have been in the same house for a long time.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************



[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]

After that, senpai often came to my house to visit and even stayed over.
[cpg]


There, she would show me the answer sheet with the perfect score.
[cpg]

[OnName num="yuma"]
He said, "Maybe ...... if you flirt with her now, your sister will find out.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina097"]
[OnName num="reina"]
So you're going to stop?　I don't want to put up with that."
[cpg cn=true]



I couldn't refuse. ......
[cpg]



;//ブラックアウト
;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Still, all along, I was concerned about my sister Koyuki.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





In the end, I ended up doing exactly what Nanano said.
[cpg]


Sister Koyuki is jealous. That, too, is quite ......
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano045"]
[OnName num="nanano"]
Yuma-kun. It's been a while."
[cpg cn=true]


[OnName num="yuma"]
"Oh ...... Nanano-san. Good morning."
[cpg cn=true]


I hesitated whether to say anything or not, then I told him about the current situation.
[cpg]


[OnName num="yuma"]
I said, "It turned out just like you said, ......Nanano-san."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano046"]
[OnName num="nanano"]
What are you talking about?
[cpg cn=true]


[OnName num="yuma"]
Koyuki-sister was shocked that me and senpai are dating,.......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano047"]
[OnName num="nanano"]
"Oh ...... but that's nothing I can do for her.
[cpg cn=true]


Nanano-san says that she can't help you with anything, that we have to solve our own problems by ourselves.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Nanano048"]
[OnName num="nanano"]
Still, it's important not to drown in that ......
[cpg cn=true]



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano049"]
[OnName num="nanano"]
'Because love can drive people crazy. It's important to maintain moderation."
[cpg cn=true]


I thought about the meaning of those words, but didn't fully understand them right now.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





As usual, we showed each other our answers. Today, both of us were in good shape.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Reina098"]
[OnName num="reina"]
"Hmmm...another perfect score. Another perfect score.
[cpg cn=true]


[OnName num="yuma"]
What should I do with ......?"
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina099"]
[OnName num="reina"]
"Why don't you come over to my place?　Yuma's sister isn't there either.
[cpg cn=true]


[OnName num="yuma"]
"......, I guess so."
[cpg cn=true]


The rivalry with the older sister can be glimpsed in every word of the senpai.
[cpg]


 Senpai is a senior, and he probably intends not to give up even one step.
[cpg]


[OnName num="yuma"]
"Well then, see you after school."
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Reina100"]
[OnName num="reina"]
I'll see you after school. Let's do that.
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************



[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]

The end of the school day. We went to his house.
[cpg]


He seemed happy.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Reina101"]
[OnName num="reina"]
"Hey," he said. Shall we hold hands, Yuma?
[cpg cn=true]


[OnName num="yuma"]
"......Yes."
[cpg cn=true]


I hold hands with my senior. We're already lovers for all intents and purposes, and we think of each other as lovers.
[cpg]


But it wasn't without any obstacles at all.
[cpg]


In my mind, Koyuki's sister was always in my mind. ......
[cpg]



;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************

And after spending some time at her house.
[cpg]

[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="yuma"]
"It's getting pretty late,......, I'm going home soon.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina102"]
[OnName num="reina"]
"What ......?　Let's spend more time together.
[cpg cn=true]


[OnName num="yuma"]
I would love to, but I don't know if they'll let me. I'd like to do the same, but my sisters...
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina103"]
[OnName num="reina"]
I'd love to, but my sisters..." "Don't worry about your sister.　Just look at me."
[cpg cn=true]


The senior said and took my hand.
[cpg]


[OnName num="yuma"]
I said to her, "...... I guess so. Let's stay a little longer."
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夜）******************************************************





In the meantime, it was really deep time.
[cpg]


I wondered if everyone had already eaten dinner. I returned home with that thought in my mind.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu110"]
[OnName num="chinatsu"]
I went back to my house.
[cpg cn=true]


When I returned home, I found Chinatsu in the living room.
[cpg]


[OnName num="yuma"]
I'm sorry," she said. I'm sorry I'm home late.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu111"]
[OnName num="chinatsu"]
I'm really sorry. Sis, you were mad at me.
[cpg cn=true]


[OnName num="yuma"]
"I'll go apologize to her after .......
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu112"]
[OnName num="chinatsu"]
She said she would later, but in the end she didn't say anything, did she?
[cpg cn=true]


The actual "I'm not a fan of the newest and most popular" type of clothing.
[cpg]


But I can't help it. ...... I have a relationship with my sister Koyuki.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu113"]
[OnName num="chinatsu"]
I know Yu-kun and Rena-chan are lovers. I think you should take good care of them."
[cpg cn=true]


[OnName num="yuma"]
'......I'm sorry.'
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chinatsu114"]
[OnName num="chinatsu"]
I'm not finished talking with you yet, so don't apologize.
[cpg cn=true]


[OnName num="yuma"]
......"
[cpg cn=true]


The actual "I'm not a fan of the way you do it," he said, "but I'm not a fan of the way you do it either.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu115"]
[OnName num="chinatsu"]
She has always been in love with you, too, sister. I think it's terrible to neglect her.
[cpg cn=true]


......I'm aware of it too. The next morning, the two of them were in the same room.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

The next morning. The first thing you need to do is to make sure that you have a good time with your family.
[cpg]


It was more like she was in pain.
[cpg]


 Right now, I have no choice but to do nothing... I'm not prepared enough to take a good look at my relationship with Sister Koyuki-san.
[cpg]

[free time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Koyuki196"]
[OnName num="koyuki"]
I'm going to go then."
[cpg cn=true]


The first thing to do is to make sure that you have a good time with your family.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Chinatsu116"]
[OnName num="chinatsu"]
Yeah. Be careful."
[cpg cn=true]


[OnName num="yuma"]
I'll see you at ......."
[cpg cn=true]


My sister doesn't respond to my words. A frustrating feeling is growing in my heart.
[cpg]



;//ブラックアウト
;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





Happy time. In the meantime, a feeling suddenly comes over me.
[cpg]


I'm sure Koyuki would resent me for this. I can't help but think about it.
[cpg]


I should probably confide in my senpai about this.
[cpg]


It's not about cheating or anything like that, but I can't let go of this rift with Koyuki.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina104"]
[OnName num="reina"]
I'm not going to let it go.　You look a little gloomy.
[cpg cn=true]


[OnName num="yuma"]
"I don't think so.
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina105"]
[OnName num="reina"]
I don't think so. If there is something wrong, let's hear it.
[cpg cn=true]


My senpai says so. Maybe I should tell him this.
[cpg]


[OnName num="yuma"]
"......, actually."
[cpg cn=true]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




I told him everything. I'm not sure if it's a good idea or not, but I'm sure it's a good idea.
[cpg]


Even so, the seniority of the students is still the most important thing.
[cpg]


I want to continue going out with my senpai,.......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************


[VOICE f="Reina106"]
[OnName num="reina"]
What the hell. That's what's bothering me."
[cpg cn=true]


[OnName num="yuma"]
"You say that, but ...... it's very serious."
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Reina107"]
[OnName num="reina"]
"Yuma, I think you can solve it right away.
[cpg cn=true]


[OnName num="yuma"]
What?
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina108"]
[OnName num="reina"]
I should talk to your sister directly, right?
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





The first thing to do is to get a good idea of what you're looking for. On Saturday, my senior was to come to my house.
[cpg]


Senpai has not talked much with Koyuki-sister.
[cpg]


I hoped there would be no conflict, but that might be inevitable.
[cpg]


I waited for that moment with trepidation.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（昼）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]


And then, Senpai, me, and Koyuki.
[cpg]


Chinatsu had nothing to persuade us now, so the three of us were in her room.
[cpg]


[OnName num="yuma"]
"......, Koyuki-san."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Koyuki197"]
[OnName num="koyuki"]
What?"
[cpg cn=true]


He replies coldly and shortly.
[cpg]


[OnName num="yuma"]
I like my senpai. Please allow me to go out with you.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki198"]
[OnName num="koyuki"]
I've already heard that. You're going to go out with him even if I don't allow it, right?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Reina109"]
[OnName num="reina"]
I'll go out with you even if you don't allow me to. ......
[cpg cn=true]


I'm in trouble. I suddenly stumbled.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Koyuki199"]
[OnName num="koyuki"]
What do you want to do, Yuma?　You don't have to be in my good mood.
[cpg cn=true]


[OnName num="yuma"]
I've always been a big sister and brother to my ...... sister. I don't want to fight."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Koyuki200"]
[OnName num="koyuki"]
'Then let me tell you something too. I'm still waiting for you to play the lover's game,.......
[cpg cn=true]


Sister Koyuki will say something like that. But I can't nod here.
[cpg]


[OnName num="yuma"]
I'm not going to do that. If you do that with your sister, it would be cheating.
[cpg cn=true]


Even if I'm good, it's not good for senpai. I thought so, but ......
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Reina110"]
[OnName num="reina"]
I'm good."
[cpg cn=true]


I couldn't believe my ears. What did you just say ......?
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Reina111"]
[OnName num="reina"]
I'm sure you'll be able to find a way to get a good deal on the newest and most up-to-date information about the newest and most up to date products and services.　If that's the case,......
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki201"]
[OnName num="koyuki"]
"......, are you serious?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="Reina112"]
[OnName num="reina"]
Yeah," she said, "I'm sure we'll see each other again. Even if we don't see each other for a long time, even if we die and leave each other, we're still ...... real lovers."
[cpg cn=true]


The senpai says challenging things. The most important thing to remember is that you can't be too careful when it comes to your health and wellbeing.
[cpg]


However,......, I don't think Koyuki will back down if she is told that much.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Koyuki202"]
[OnName num="koyuki"]
I'm not going to hold back. Then I won't hold back.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Reina113"]
[OnName num="reina"]
I'm not going to hold back. That's why, you understand?　Yuma.
[cpg cn=true]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





The situation is like a harem. It's like a dream if I say it's like a dream.
[cpg]



;//[SE f="se006"]
;//【ＳＥ】『衣擦れ』

;//移植のためシーンをカットしています



I think our relationship was strained.
[cpg]


But I also feel that it has become strangely stable.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





Then night falls. I was alone in my room, thinking.
[cpg]


I wondered if I could say that the problem had been solved. I don't think either Koyuki or my senpai benefited from it.
[cpg]


If I had to say, it's a strange situation that only I am benefiting from.
[cpg]


But neither of them looked unhappy.
[cpg]


So I'm not sure if this is okay. It's a strange feeling ......
[cpg]


But for once, I think this might be okay.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





Sunday passes, and it's another weekday.
[cpg]


On a sleepy Monday morning, I rubbed my eyelids as I left the house.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki203"]
[OnName num="koyuki"]
"Well, see you later," he said.
[cpg cn=true]


[OnName num="yuma"]
I'm off.
[cpg cn=true]


I was able to exchange greetings with my sister today.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina114"]
[OnName num="reina"]
"How have you been with your sister since then?
[cpg cn=true]


[OnName num="yuma"]
"Yes, we are getting along rather well. I think we get along relatively well.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Reina115"]
[OnName num="reina"]
I'm glad to hear that. I'm glad to hear that. ......"
[cpg cn=true]


The senior smiled wryly. The most important thing to remember is that the best way to get the most out of your money is to be careful what you spend.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina116"]
[OnName num="reina"]
I'm doing well these days, aren't I?
[cpg cn=true]


I showed him the answer sheet of the quiz. She had gotten a perfect score.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Reina117"]
[OnName num="reina"]
I'm going to ask you to go out with me again today.
[cpg cn=true]


There was no reason for him to refuse his senpai's invitation.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_og"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina118"]
[OnName num="reina"]
Hey, Yuma.
[cpg cn=true]


[OnName num="yuma"]
"...... what?　Senpai.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Reina119"]
[OnName num="reina"]
I'm going to ask you to go out with me today. I don't want to see Yuma in some kind of trouble because of me.
[cpg cn=true]


[OnName num="yuma"]
Yeah, that's ...... what I'd like to do.
[cpg cn=true]


All of this is the result of my senior's own concern for me.
[cpg]


I'm going to be able to get a lot more information about the actuality of the particulars.
[cpg]


 I will continue my relationship with Sister Koyuki... I thought that was a betrayal of my seniors.
[cpg]


But she says it's fine.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************





;//それから、小雪姉さんとも何度かした。
I've been playing lovers with Koyuki for a while now.
[cpg]


The first thing that comes to mind is the fact that the two of them have been in a relationship for a long time.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki204"]
[OnName num="koyuki"]
I'm sorry for ...... being so selfish all this time. I've been so selfish all this time.
[cpg cn=true]


[OnName num="yuma"]
I've been selfish all the time. I'm the one who should be ...... with you.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki205"]
[OnName num="koyuki"]
I'm sure it's my fault. I'm sure it's my fault. I knew I was jealous.
[cpg cn=true]


I listened silently to her. The first thing to do is to make sure that you have a good relationship with your partner.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki206"]
[OnName num="koyuki"]
Yuma. Be happy with Rena-chan."
[cpg cn=true]


[OnName num="yuma"]
I said to her, "...... yes."
[cpg cn=true]


Eventually, she came to congratulate us.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（昼）******************************************************





The days pass by at a dizzying pace.
[cpg]


As it passed, I think Sister Koyuki came to understand me quite well.
[cpg]


Giving up on me, that's not a very flattering way of putting it, but ......
[cpg]


She had come to accept my relationship with my senpai.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_co"]
;//[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************





Holiday. I went to my senior's house to hang out.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Reina120"]
[OnName num="reina"]
'Maybe it's a good thing we set some rules together.'
[cpg cn=true]


[OnName num="yuma"]
What do you mean by ......?　The quiz, that story?
[cpg cn=true]


An arrangement similar to playing lovers. That was a good thing, the senior said.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina121"]
[OnName num="reina"]
I think it would have been better if we had stayed the same. If we had stayed the same,...... I think we would have had a different future.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Reina122"]
[OnName num="reina"]
I might not have been able to make that kind of decision about your sister.
[cpg cn=true]


I thought that might be true. But ......
[cpg]


[OnName num="yuma"]
If that were the case,......, we wouldn't need it anymore. I don't need this rule anymore.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Reina123"]
[OnName num="reina"]
"Hmmm... I guess so."
[cpg cn=true]


;//移植のためシーンをカットしています

;//========================================
;//●ＣＧ非エロ（二人小さな机を囲んで勉強している。対面しているヒロイン）ev_67
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：昼
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_67_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]



But we were still studying.
[cpg]



[VOICE f="Reina124"]
[OnName num="reina"]
'...... there, you spelled it wrong.
[cpg cn=true]


[OnName num="yuma"]
What?　I don't think so."
[cpg cn=true]



[VOICE f="Reina125"]
[OnName num="reina"]
"Huh. ...... I may teach Yuuma, but not the other way around, right?
[cpg cn=true]


[OnName num="yuma"]
"...... sorry."
[cpg cn=true]



[VOICE f="Reina126"]
[OnName num="reina"]
I'm sorry. The actual "I'm sorry.
[cpg cn=true]


 When I was wondering what was going on, the senior continued to speak.
[cpg]



[VOICE f="Reina127"]
[OnName num="reina"]
I'm sorry to say that I'm also glad that I'm your senior. I think you're probably right.
[cpg cn=true]


[OnName num="yuma"]
Well,......, I won't deny it.
[cpg cn=true]



[VOICE f="Reina128"]
[OnName num="reina"]
I'm not going to deny it. I am relieved that I was born before Yuma.
[cpg cn=true]


I don't understand.
[cpg]


She probably wants to say that if Koyuki is in the strike zone, then she must be, too. ......
[cpg]


Female mind is a difficult thing to understand. I thought the same thing about Koyuki's case.
[cpg]



[VOICE f="Reina129"]
[OnName num="reina"]
Come on, let's focus on our studies. Where were we? ......"
[cpg cn=true]


[OnName num="yuma"]
......
[cpg cn=true]


The love affair between me and my seniors will continue. I'll still be a student for a while.
[cpg]


We need to balance it with our studies. That's why I'm making a rule.
[cpg]


These rules are much like playing lovers with my sister.
[cpg]


I wondered for a moment if I like that kind of thing that can't be left to chance after all.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





But for the love itself with ...... senpai, I'd prefer to have as few obstacles as possible.
[cpg]



;//ＥＮＤ　ヒロイン２ルート
[SCENE id=16]

[jump storage="epend.ks" target="*start"]


