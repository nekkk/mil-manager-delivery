
*start



;//==============================
;//１、小雪


;#################################################
*Ep004|Koyuki, the sister who is like a sister to me
;#################################################

[stflag flag6 = 0]

[if exp={ isSystemFlagsEnabled( "sysfla6") }]
[if exp={getFlagValue("flag6") == 0 }]
[stflag flag6 = 1]
[endif]
[endif]


*select04_1|Koyuki, the sister who is like an older sister

[SCENE id=4]


I still love Koyuki, who is like an older sister to me.
[cpg]


I'm sorry to my senpai, but I still feel the same way.
[cpg]


I want to keep playing this lover game.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





And from tomorrow, I will continue to listen to Koyuki-san.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki061"]
[OnName num="koyuki"]
It's been a big help since Yuma started helping me with the cooking."
[cpg cn=true]


[OnName num="yuma"]
'...... yeah.
[cpg cn=true]


There is the matter of playing lovers. I couldn't answer immediately.
[cpg]

Soon you will have 10 points. Also, you can become a lover, albeit a temporary one.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************





And that evening.
[cpg]


I looked at the point card with the illustration for 10 points.
[cpg]


With this, I could get more things done. I took a swallow and said to Koyuki.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="yuma"]
"Sis, ......, about the points..."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki062"]
[OnName num="koyuki"]
I looked at her and said, "Oh, yes, about the points. I've already accumulated 10 points. I'm sure you've already accumulated 10 points, so you can sneak me into your room at night.
[cpg cn=true]


With my heart pounding, I waited for the moment.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



And at night ...... I went to Koyuki's room.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夜）******************************************************



[SE f="se001"]
;//【ＳＥ】『ドア開く』





[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]


[VOICE f="Koyuki063"]
[OnName num="koyuki"]
"Welcome to ....... Come on, spoil me as much as you want."
[cpg cn=true]


I was standing next to Koyuki, who said.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chinatsu028"]
[OnName num="chinatsu"]
What's wrong, you look surprised.
[cpg cn=true]


Chinatsu was there. That's a surprise.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Chinatsu029"]
[OnName num="chinatsu"]
I'll stay with you too. I'll stay with you.
[cpg cn=true]


[OnName num="yuma"]
Is that so?
[cpg cn=true]


I didn't know what Chinatsu sister was thinking.
[cpg]


The first thing that comes to mind is that Chinatsu originally tried to stop me and Koyuki from having a relationship, but ......
[cpg]


On the contrary, it is strange that Chinatsu sister joins this relationship.
[cpg]


Or maybe Chinatu-nee-san likes me too, so she thought of doing it that way so that Sister Koyuki-nee-san wouldn't take it away.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Koyuki064"]
[OnName num="koyuki"]
What's wrong?"　You're not doing anything."
[cpg cn=true]


[OnName num="yuma"]
I was just surprised because Chinatsu sister was there. I was just surprised because Chinatsu sister was there.
[cpg cn=true]


I can only imagine, but if Chinatsu sister likes me, I will be happy if she likes me. ......
[cpg]



;//■選択肢
[switch]
[case "If she likes me, I'm happy."]
	[swap]
	[jump target="*select05_1"]
[case "Koyuki is the only one for me."]
	[swap]
	[jump target="*select05_2"]
[endswitch]


13. I'm happy if she likes me
14. I have only Koyuki sister



;//==============================
;//13、好かれているなら嬉しい
*select05_1|Koyuki is like a sister to me


;//後の選択肢５が発生する
[stflag flag5 = 1]
[system sysflg5=true]



I'm happy if Chinatsu sister likes me.
[cpg]


I thought there might be a future in which I would get married to Chinatsu-sis, not Koyuki-sis.
[cpg]


Of course, that's just a matter of time before that happens. ......
[cpg]


[jump target="*select05_3"]
;//==============================
;//14、自分には小雪姉さんしか居ない
*select05_2|Koyuki sister who is like a sister to me


;//後の選択肢５が発生しない
[system sysflg5=false]




After all, it's no good. Koyuki is the only one for me.
[cpg]


Even if Chinatsu likes me, I have to pretend not to notice.
[cpg]



;//==============================
*select05_3|Koyuki is like a sister to me.

[free time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki065"]
[OnName num="koyuki"]
I'll give you 10 points for that. Shall we be more like lovers than before?
[cpg cn=true]


[OnName num="yuma"]
"Uh-huh.
[cpg cn=true]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
;//移植のためシーンをカットしています

Then I stayed with her.
[cpg]

She suggested that I get on my knees and scratch her ear ......, and I couldn't say no.
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夜）******************************************************





[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/2" time=800]

Happy time. There was no doubt about that.
[cpg]


But I felt uncomfortable. I wondered if it was okay for me to do this.
[cpg]


Both Koyuki and Chinatsu acted as if this distance was normal.
[cpg]

I thought it was strange, but I couldn't ...... push them away.
[cpg]





;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



The days go by like that. The girlfriend game with Koyuki continued.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="yuma"]
I was thinking, "...... Hey, senpai. I have something important to tell you.
[cpg cn=true]


I waited for the right moment and told her so.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina052"]
[OnName num="reina"]
What is it?　What's so important?
[cpg cn=true]


I had a feeling that Senpai was also somewhat prepared. He had that look on his face.
[cpg]


[OnName num="yuma"]
I like you, Koyuki. So I can't go out with senpai."
[cpg cn=true]


[OnName num="yuma"]
I probably won't ...... do it anymore.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina053"]
[OnName num="reina"]
"...... I see."
[cpg cn=true]


I guess I didn't have to say it during the day. The most important thing to remember is that you can't just go to the store and ask for a discount.
[cpg]


I thought so, but I didn't want to make it serious if possible.
[cpg]


[OnName num="yuma"]
I'm not going to cry, senpai,......, because I'm going to cry too."
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina054"]
[OnName num="reina"]
I don't think there's anything for you to cry about. You don't have anything to be sad about.
[cpg cn=true]


I'm not going to cry," he said. I'm sure that's the reaction you're going to get.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina055"]
[OnName num="reina"]
I've always wanted you to be happy. I can only say, "I wish you happiness.
[cpg cn=true]


He ended the conversation like that.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





I had settled the matter with my senpai. I guess you could say that I turned him down. ......
[cpg]


But I'm glad I did. My feelings were not going to change now.
[cpg]


Then there is Ms. Nanano. I have had a bit of a relationship with her as well.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="yuma"]
......Hanano-san.
[cpg cn=true]


I often meet her on my way to school. Today was no different.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano027"]
[OnName num="nanano"]
"Good evening. What is it?　Yuma-kun.
[cpg cn=true]


[OnName num="yuma"]
"Well, ...... its..."
[cpg cn=true]


I don't think she has a definite liking or love for me.
[cpg]


;//性欲が溜まっていて、たまたま可愛い男の子が好きでその相手が俺だった。
I don't think I'm a little bit cute, but I think I'm a little bit cute.
[cpg]


I don't think I'm cute at all, but that's probably it.
[cpg]


Still, I want to be reasonable. I have to say that I won't have anything more to do with Ms. Nanano.
[cpg]


[OnName num="yuma"]
"Ms. Nanano. I have found someone I like.
[cpg cn=true]



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano028"]
[OnName num="nanano"]
He looks like he is. You look determined."
[cpg cn=true]


Even at a time like this, it's still my face, isn't it? Am I really that sensitive?
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano029"]
[OnName num="nanano"]
I'm sure you'll be happy with the person you love, Yuma. Yuma-kun."
[cpg cn=true]


Ms. Nanano is talking to me like I'm a senior. I guess I'll just have to be happy.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chinatsu030"]
[OnName num="chinatsu"]
Welcome back, Yuu-kun."
[cpg cn=true]


[OnName num="yuma"]
'...... where's Koyuki's sister?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu031"]
[OnName num="chinatsu"]
I think she's in her room. What's wrong?"
[cpg cn=true]


[OnName num="yuma"]
Nothing. ......
[cpg cn=true]


I couldn't stand still when I thought I wanted to be with Koyuki.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se001"]
;//【ＳＥ】『ドア開く』






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夕方）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki066"]
[OnName num="koyuki"]
The actuality that you can't get a good deal more than a few of the best way to get a good deal on a new product or service. What's wrong?"
[cpg cn=true]


[OnName num="yuma"]
I was just wondering if you could help me out. I'm here to talk about playing lovers.
[cpg cn=true]


[OnName num="yuma"]
How many ...... points does it take to become a real lover?"
[cpg cn=true]


She was hardly upset when I said what almost sounded like a confession.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki067"]
[OnName num="koyuki"]
I said, "I think it's about 20 points," she said. Do you think you can hold out until then?
[cpg cn=true]


[OnName num="yuma"]
I said, "Yes. Yes, I'll try.
[cpg cn=true]


I said firmly. She nodded her head.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki068"]
[OnName num="koyuki"]
Yes, I will. If you want to accumulate points, can you run the washing machine?
[cpg cn=true]


[OnName num="yuma"]
"Sure. Okay.
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





Time passes. The delicate distance between me and Koyuki continues.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





As I accumulate 5 or 10 points, I want to use them.
[cpg]


If I can be like a lover for a moment, I think it would be good.
[cpg]


But I can't do that. I want to be with you.
[cpg]


To show that determination, I want to show that I can control myself.
[cpg]


[OnName num="yuma"]
I'm off.
[cpg cn=true]


Today, I'm heading off to the school.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************





And when I get home, I will ask for Koyuki's favor.
[cpg]


Day by day, I accumulate more and more points. It really was a sign that the day was approaching when Koyuki would no longer be my sister in law.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夕方）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki069"]
[OnName num="koyuki"]
I'm almost at 20 points. ...... I didn't think Yuma would be this patient. I, too, must be prepared."
[cpg cn=true]


[OnName num="yuma"]
"Does that mean ...... you didn't want to go out with him in the first place?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki070"]
[OnName num="koyuki"]
The first thing you need to do is to make sure that you have a good understanding of what you're doing. The actuality that you can get a lot more than one of these, it's not as if you're going to be able to get a lot more than one of these.
[cpg cn=true]


The actuality of this is that the actuality of this is the fact that the actuality of this is the fact that the actuality of this is the fact that the actuality of this is the fact of this is the fact of this is the fact of this.
[cpg]


 However, I couldn't confirm that.
[cpg]


I really might have imagined all of this when she first approached me.
[cpg]


Maybe Koyuki thought it was okay for her to have that kind of relationship with me.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



More time passes. Housework, errands, small requests.
[cpg]


I finally accumulated 20 points.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_og"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（夜）******************************************************


;//移植のためシーンをカットしています

Now there were no more obstacles between us.
[cpg]

[OnName num="yuma"]
She said, "I like ....... I want you to go out with me.
[cpg cn=true]


She would respond to my words as well.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki071"]
[OnName num="koyuki"]
"Yes, I like you too. I like you too.
[cpg cn=true]


Koyuki looked happy. I'm sure she is aware of my love for her.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki072"]
[OnName num="koyuki"]
I'm sure she knows how much I like her. I think we'll be ruined if we lose all restraint.
[cpg cn=true]


[OnName num="yuma"]
......Yeah, I guess so."
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki073"]
[OnName num="koyuki"]
Let's keep playing lovers. I'm sure you'll be able to find a way to get a good deal on it.
[cpg cn=true]


The first time I went to the beach, I was in the middle of the ocean, and I was in the middle of the ocean.
[cpg]


But I was okay with that. I'm sure it's true that you shouldn't be free at all.
[cpg]


[OnName num="yuma"]
"...... Hey, Koyuki-sis."
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki074"]
[OnName num="koyuki"]
What is it?　You look so serious."
[cpg cn=true]


I almost want to say it. I want to reveal everything, my desires.
[cpg]


I want to go out with my sister Koyuki. Not in the form of playing lovers. ......
[cpg]


[OnName num="yuma"]
I knew it. It's nothing. Sorry.
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki075"]
[OnName num="koyuki"]
"...... weird Yuma. Well, okay."
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





I couldn't sleep that day.
[cpg]


My eyes were strangely restless. Various thoughts were jumbled together in my head.
[cpg]


Will I really be with Koyuki? Am I doing something I shouldn't be doing?
[cpg]


I can't get my thoughts together. I spend the rest of the night with little sleep, unable to get my thoughts in order.
[cpg]


I wonder if my sister is thinking about something similar.
[cpg]


If so, I wonder if she is spending sleepless nights like me.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





After that, I continued to accumulate points and play lover with my sister.
[cpg]


I am on my way to the school now. But I can talk to her again when I get back.
[cpg]


I was looking forward to that, but I was also a little scared.
[cpg]


I need to think about what I want to do with my sister once again.
[cpg]


I would probably be able to think about it by talking to her. That was also scary.
[cpg]


I felt like I was going in a direction I shouldn't go.
[cpg]


I feel like I can't go back to being the sister and brother I once was, and that scares me. ......
[cpg]







[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





Then, after taking all the classes, I leave the academy and come back home again.
[cpg]


I wasn't sure myself whether my steps were heavy or light.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki076"]
[OnName num="koyuki"]
Welcome back. Yuma.
[cpg cn=true]


[OnName num="yuma"]
Yuma: "Yes, I'm home. I'm home.
[cpg cn=true]


Koyuki is beautiful today. Regardless of what happens between me and my sister, I can't suppress this feeling.
[cpg]


[OnName num="yuma"]
Is there anything I can do for you?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki077"]
[OnName num="koyuki"]
I can see your ulterior motive.
[cpg cn=true]


I was unable to say anything after she said that.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Koyuki078"]
[OnName num="koyuki"]
I was unable to say anything.
[cpg cn=true]

[OnName num="yuma"]
'...... yeah.'
[cpg cn=true]

;//========================================
;//●ＣＧ（ヒロインにマッサージをする主人公）ev_13
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：昼
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_13_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[wait time=1000]


When I touch my sister, I feel like it fills me up.
[cpg]

[VOICE f="Koyuki079"]
[OnName num="koyuki"]
I was so happy to see her. "...... what's wrong?　You don't do that anymore."
[cpg cn=true]


At the same time, a void is being created that I can't stand.
[cpg]

[OnName num="yuma"]
I'm sorry. Let's call it a day."
[cpg cn=true]


The point of playing lover is gradually accumulating again.
[cpg]

I can be a lover with Koyuki again. Looking forward to it, I continued to be patient.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



A little while later, during the daytime on a holiday.
[cpg]


I had accumulated 20 points and was about to play lover with my sister again.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（昼）******************************************************




[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Michiru010"]
[OnName num="michiru"]
I said to her, "Ojamashimasu! Oh, Yuma.
[cpg cn=true]


[OnName num="yuma"]
Oh, hi. ......
[cpg cn=true]


I was about to use my points today when Michiru came to my house.
[cpg]


Michiru came to my house. You missed the timing. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="Koyuki080"]
[OnName num="koyuki"]
You're blatantly disappointed. It's okay if you don't want to, you can do it now.
[cpg cn=true]


[OnName num="yuma"]
What ......?"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Michiru011"]
[OnName num="michiru"]
I know what's going on~"
[cpg cn=true]


What a surprise. Even Michiru-san knows about us?
[cpg]



[OnName num="yuma"]
But...
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Michiru012"]
[OnName num="michiru"]
If it's about me, don't mind me.
[cpg cn=true]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se001"]
;//【ＳＥ】『ドア閉まる』

;//移植のためシーンをカットしています


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（昼）******************************************************




[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Michiru013"]
[OnName num="michiru"]
"You two are so close. You seem really happy.
[cpg cn=true]

Koyuki's sister, without worrying about being seen ......, is rubbing up against me like she's showing me off.
[cpg]

 Rather than being embarrassed, I have a strong sense of immorality, wondering if I should do something like this.
[cpg]


;//移植のためシーンをカットしています

Koyuki sister is also Koyuki sister, but it is also strange to say that Michiru-san doesn't mind.
[cpg]


So, both Michiru-san and ...... Chinatsu-san. I think she likes me more or less.
[cpg]


I don't think my face is that good, and I don't think even my personality is properly known, but ......
[cpg]


Is there something about her that tickles my maternal feelings? I don't know.
[cpg]





;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





And then, on my way out the door.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki081"]
[OnName num="koyuki"]
"I'll see you at the university."
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Michiru014"]
[OnName num="michiru"]
Yes. And Yuma-kun.
[cpg cn=true]


Michiru whispered in my ear.
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="Michiru015"]
[OnName num="michiru"]
I can make you happier than if you went out with Koyuki.
[cpg cn=true]


[OnName num="yuma"]
......"
[cpg cn=true]


I didn't know what to say back.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Koyuki082"]
[OnName num="koyuki"]
I didn't know what to say.　What did you just say?
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Michiru016"]
[OnName num="michiru"]
Nothing.
[cpg cn=true]



;//==============================
;//選択肢９を選んでいた場合
[if exp={getFlagValue("flag6") == 1 }]
[jump target="*sw6_1"]
[endif]




Maybe Michiru says this to everyone.
[cpg]


I thought it was nothing to worry about, so I decided to let it slide.
[cpg]


If I took every single thing she said seriously, I would become a cheater.
[cpg]


[jump target="*sw6_2"]
;//==============================
;//選択肢10を選んでいた場合
*sw6_1|Koyuki, the sister who is like a sister to me




I was more than a little moved.
[cpg]


I had originally been interested in Michiru-san. So, when she said this to me: ......
[cpg]


I can't help but take it as serious.
[cpg]



;//==============================

*sw6_2|Koyuki-sister is like a big sister to me




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************





And so the night goes on.
[cpg]


I've been playing lovers with Koyuki, but I can't say that there's nothing going on with ...... Chika or Michiru either.
[cpg]


The first thing to do is to make sure that you have a good time with your friends and family.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki083"]
[OnName num="koyuki"]
I was in love with Koyuki, even though I thought it was strange. Aren't you going to take a bath?
[cpg cn=true]


[OnName num="yuma"]
I'm going to take a bath now. I was just going to take a bath. ......
[cpg cn=true]


I was so happy to see her, she seemed to know that I was with someone else, but she seemed to be able to afford it.
[cpg]


I guess you think Koyuki-sister is the best for me.
[cpg]


Otherwise, I don't think I could take this attitude.
[cpg]



[jump storage="ep005.ks" target="*start"]



