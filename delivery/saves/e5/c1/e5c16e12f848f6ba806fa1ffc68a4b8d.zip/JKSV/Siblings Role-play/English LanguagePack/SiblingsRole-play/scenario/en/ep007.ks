
*start


;//==============================
;//５、千夏姉さんの事が気になる


;#################################################
*Ep007|I'm worried about Chinatsu-san
;#################################################


*select06_2|I'm worried about Chinatsu-sis.

[SCENE id=7]



There are three of us here. I can say that I would go out with any one of them.
[cpg]


......I still like my sister Chinatsu. I've realized that.
[cpg]


But it's like I've been dating Koyuki's sister all this time. ......
[cpg]


;//もちろん肉体関係を持ってしまってる。それをいきなり振るだなんて……
And to suddenly dump her like that is just ......
[cpg]


I didn't have the courage to end the relationship with Koyuki. ......
[cpg]


[OnName num="yuma"]
......
[cpg cn=true]


I knew that saying it now would solve everything, but I kept quiet.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（昼）******************************************************





Time passes mercilessly. Or perhaps it's worse that I'm not doing anything.
[cpg]


It's the middle of the day on a holiday. Dad and mom are out.
[cpg]


We've accumulated enough points for playing lovers, and me and my sisters are on our way to ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Koyuki146"]
[OnName num="koyuki"]
I've never had such a great opportunity. Hey, Yuma.
[cpg cn=true]


[OnName num="yuma"]
"...... yeah."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Chinatsu059"]
[OnName num="chinatsu"]
We're always ready.
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（昼）******************************************************





I'm going to be a lover with Koyuki for a moment. The most important thing to remember is that you can't just take a look at your own personal computer.
[cpg]


I feel indescribable. The truth is that I love Chinatsu-sis the most.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
;//移植のためシーンをカットしています



 In my mind, I kept an ambiguous distance without making anything concrete.
[cpg]


In the midst of all this, Chinatsu-san said this.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chinatsu060"]
[OnName num="chinatsu"]
"Oh ...... I have a part-time job coming up soon.
[cpg cn=true]


[OnName num="yuma"]
"Part-time job ......?　I've never heard of it.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki147"]
[OnName num="koyuki"]
"Oh, you don't know Yuma?　He's been working lately."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chinatsu061"]
[OnName num="chinatsu"]
I've never heard of it before. I work at a restaurant ......, if you want to come, Yuu-kun.
[cpg cn=true]


[OnName num="yuma"]
I'll go to ...... one of these days.
[cpg cn=true]


[free time=1000]


;//ブラックアウト


I watched Chinatsu-san leave, saying something like
[cpg]


I and Koyuki probably had the same plan. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Koyuki148"]
[OnName num="koyuki"]
I'd like to see where Chinatsu works, wouldn't you?
[cpg cn=true]


[OnName num="yuma"]
"...... yes."
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（昼）******************************************************





Chinatsu-sis, is there something you want to buy?
[cpg]


 Whether it was or not, I wanted to see my sister working.
[cpg]


 A restaurant has some kind of uniform.
[cpg]


Besides, Chinatsu's sister also asked me to come, so ...... this is not a problem.
[cpg]


There was something strangely swelling in my heart in the midst of these feelings.
[cpg]


I want to see Chinatsu's sister in a way I've never seen her before. This is still ......
[cpg]


It was something that I could say it was a love affair.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





And then we enter the restaurant. I was not very hungry.
[cpg]



;//========================================
;//●ＣＧ非エロ（アルバイト中）ev_30
;//人物１：ヒロイン４
;//服装１：アルバイトの制服
;//場所　：レストラン店内
;//時間　：昼
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_op"]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]



Chinatsu-san in her school uniform was dazzling. Really, just cute.
[cpg]


My sister seemed like a different person.
[cpg]


[OnName num="customer"]
"Clerk, a moment!"
[cpg cn=true]



[VOICE f="Chinatsu062"]
[OnName num="chinatsu"]
Yes!　Let me ask you something.
[cpg cn=true]


Chinatsu's work ethic was quite impressive. ...... I don't know if it's rude of me to call her that.
[cpg]


 I have never had a part-time job. I can't say anything great.
[cpg]



[VOICE f="Koyuki149"]
[OnName num="koyuki"]
"...... Chinatsu, you're so cute. I might want to wear that uniform."
[cpg cn=true]


Sister Koyuki is saying something that can't be described as jealousy.
[cpg]


But ...... if I were a woman, I might think that.
[cpg]


 I thought it was so cute.
[cpg]




;//[window target=false]
;//[BG f="b_03_2.ui" time=1000]
;//[WAIT time=1100]
;//[window target=true]

;//【ＢＧ】『レストラン店内』（昼）******************************************************


;//[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
;//[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chinatsu063"]
[OnName num="chinatsu"]
 “You came, Yuu-kun, Onee-chan.”
[cpg cn=true]



;//[FACE method="change_2" pos="1/2"]
[VOICE f="Koyuki150"]
[OnName num="koyuki"]
I said, "Yes, you can come. I was told I could come."
[cpg cn=true]


[OnName num="yuma"]
"You're ...... cute, Chinatsu-sis."
[cpg cn=true]


;//[FACE method="change_2" pos="2/2"]
[VOICE f="Chinatsu064"]
[OnName num="chinatsu"]
"Heh heh heh. Thank you.
[cpg cn=true]


I've always thought that Chinatsu sister is a bit of a spoiled brat.
[cpg]


 But on the contrary, I wonder if they're trying to spoil me.
[cpg]


;//[FACE method="change_1" pos="2/2"]
[VOICE f="Chinatsu065"]
[OnName num="chinatsu"]
So, what can I get you?　I can't just come here, you know."
[cpg cn=true]


[OnName num="yuma"]
Okay, let's see... ......, what's the cheapest?
[cpg cn=true]


;//[FACE method="change_4" pos="1/2"]
[VOICE f="Koyuki151"]
[OnName num="koyuki"]
Don't say cheapest, please. ......
[cpg cn=true]


So I ordered a drink and Koyuki ordered a parfait.
[cpg]


Then, for a while, he watches Chinatsu sister work.
[cpg]


He didn't seem like a screw-up. Rather, he seemed like a hard worker.
[cpg]

;//[FACE method="change_4" pos="1/2"]
[VOICE f="Koyuki152"]
[OnName num="koyuki"]
The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it.
[cpg cn=true]


[OnName num="yuma"]
"Really?　I think you could be like that if you tried working.
[cpg cn=true]


;//[FACE method="change_6" pos="1/2"]
[VOICE f="Koyuki153"]
[OnName num="koyuki"]
I don't think so. I'm such a dullard.
[cpg cn=true]


[OnName num="yuma"]
"Well, I don't know about ...... that.
[cpg cn=true]


But I think we both work harder than I do.
[cpg]


They listen to everything I ...... tell them to do, even if it's just to pamper me.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Then we head back to the house. Chinatsu sister will be back much later.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夕方）******************************************************





I sort out my feelings. My feelings for Chinatsu sister have become more certain after today.
[cpg]


This is love. But I am in touch with Koyuki.
[cpg]


But one day, Koyuki will find out about these feelings.
[cpg]


Even now, I'm waiting for Chinatsu-sis to come back soon.
[cpg]


I have no one else but Chinatsu,......, but that may be the same as how Koyuki feels about me.
[cpg]


I spent my days with these thoughts in mind.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************



[SE f="se011"]
;//【ＳＥ】『歩く』





On the way to the school. On the way to the school, Ms. Nanano spoke to me.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano035"]
[OnName num="nanano"]
What's wrong?　Haven't you been sleeping well lately?
[cpg cn=true]


[OnName num="yuma"]
What makes you think so?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano036"]
[OnName num="nanano"]
You look pale. You look like you're either very troubled or not sleeping.
[cpg cn=true]


[OnName num="yuma"]
That's not true,.......
[cpg cn=true]


He denies it, but they see through his worries.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano037"]
[OnName num="nanano"]
If you have any worries, please tell me. It's not good to keep them to yourself.
[cpg cn=true]


Ms. Nanano is kind. She is trying to get me to be lenient with her.
[cpg]


Of course, my feelings don't flutter to Ms. Nanano now, but ......
[cpg]


She's a good person, too. That's what I thought.
[cpg]


[OnName num="yuma"]
"I'll tell you ...... then. I have someone I like."
[cpg cn=true]


I blurted it out quite a bit. The actuality is that I like Chinatsu, but I'm in a relationship with Koyuki.
[cpg]


It seemed like cheating when I blurted it out, but Ms. Nanano took it seriously.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano038"]
[OnName num="nanano"]
She said, "I understand most of what you mean. But ...... Yuma-kun, you are a little timid."
[cpg cn=true]


[OnName num="yuma"]
Is that so,......?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano039"]
[OnName num="nanano"]
I'm sure you'll be able to find a way to get a good deal on it. The girl is always waiting for it.
[cpg cn=true]


...... Indeed you are right. I guess I need to make up my mind.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町』（夕方）******************************************************





And on the way home. The next time you are in the market for a new car, you should consider the cost of a new one.
[cpg]


The next time you have a chance to talk to Chinatsu and Koyuki,......, you can talk to them together.
[cpg]


Or rather, can I create that opportunity for you?
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_og"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





;//そしてある日の恋人ごっこ。行為を始める前に、俺は切り出した。
Then one day we played lovers. Before we started that, I cut him off.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[OnName num="yuma"]
I said, "...... You know what? I have to talk to you both for a minute.
[cpg cn=true]


I announced to Chika and Koyuki.
[cpg]


[OnName num="yuma"]
I like you, Chinatsu.
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
The first thing to do is to make sure that you have a good understanding of what you are doing and how to do it. But Koyuki would not understand just by saying this.
[cpg]


In fact, she was at a loss for words. She was waiting for the next words, wondering what they meant.
[cpg]


[OnName num="yuma"]
I want to love you, Chinatsu," he said. If I go out with Koyuki, it would be cheating.
[cpg cn=true]


[OnName num="yuma"]
"So ...... nothing more ...... with Koyuki sis."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chinatsu066"]
[OnName num="chinatsu"]
"Yu-kun,...... that's no good."
[cpg cn=true]


No. What is it that is no good? Is it that Koyuki's sister is shocked?
[cpg]


[OnName num="yuma"]
I'm not saying no. I, really, Chinatsu sister.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Koyuki154"]
[OnName num="koyuki"]
I really love Chika.
[cpg cn=true]


Sister Koyuki must have been shocked. She was about to start crying at any moment.
[cpg]


[free time=1000]


[SE f="se002"]
;//【ＳＥ】『扉乱暴に閉まる』





 Then he leaves the room. On the other hand, Chinatu-nee-san seemed happy, but also apologetic.
[cpg]


I heard the front door open. Koyuki must have left the house.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu067"]
[OnName num="chinatsu"]
I think you should go after ....... Yu-kun.
[cpg cn=true]


[OnName num="yuma"]
I don't know. If I go after him now, I feel like what I said will be meaningless.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu068"]
[OnName num="chinatsu"]
"Really, are you sure it's ok ...... with me?"
[cpg cn=true]


[OnName num="yuma"]
It has to be Chinatsu-sis. So ......
[cpg cn=true]


Chinatsu-san still looked apologetic.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



And with Koyuki's sister out ...... we touched each other.
[cpg]


I was the one who kissed her. I couldn't stay with this current desire and ......
[cpg]


Above all, I wanted to drown out my debt to Koyuki in some way.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu069"]
[OnName num="chinatsu"]
I was really going to leave my ...... big sister alone.
[cpg cn=true]


[OnName num="yuma"]
I can't do anything about it.
[cpg cn=true]


The first time I went to the store, I was in a relationship and unilaterally rejected the idea.
[cpg]


I don't think it's possible to be so selfish. I couldn't say anything to Koyuki simply because I felt guilty.
[cpg]


[OnName num="yuma"]
...... Anyway, right now I just want to think about my sister Chinatsu.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu070"]
[OnName num="chinatsu"]
I see. I'm sure the three of us ...... won't ever go back to our original relationship.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Chinatsu071"]
[OnName num="chinatsu"]
I've already done that much,.......
[cpg cn=true]


[OnName num="yuma"]
The first thing you need to do is to get a good idea of what you're looking for.
[cpg cn=true]


 I felt like I had nothing more to say.
[cpg]


I want to love Chinatsu. That's all I really want.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu072"]
[OnName num="chinatsu"]
I don't know if ...... she's coming home.
[cpg cn=true]


[OnName num="yuma"]
I don't know,......, she might not come home.
[cpg cn=true]


But that doesn't mean she won't pick up the phone.
[cpg]


I had a definite falling out with Sister Koyuki.
[cpg]


The word "differences" is too simple a word to describe it. ...... I betrayed her.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu073"]
[OnName num="chinatsu"]
I'm not going to make that kind of face. I'll ...... distract you."
[cpg cn=true]


[OnName num="yuma"]
Thanks to ....... Chinatsu sis.
[cpg cn=true]






;//ブラックアウト

;//========================================
;//●ＣＧ（ヒロインにキスをする主人公）ev_32
;//人物１：ヒロイン４
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_32_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

The first time I saw her, I was so excited.
[cpg]

 As if to erase my indebtedness, Chinatu-nee-san distracted me.
[cpg]



And then, the night dawned.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





Koyuki did not come home. Naturally, my parents were surprised.
[cpg]


[OnName num="mother"]
I asked her, "Did you get into a fight ......?　Yuma."
[cpg cn=true]


[OnName num="yuma"]
"Well, something like that,......."
[cpg cn=true]


I couldn't answer properly. I couldn't answer them properly.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu074"]
[OnName num="chinatsu"]
Maybe he'll be back in a while.
[cpg cn=true]


[OnName num="father"]
I'm worried. I'm not sure what's going on with you and Chinatsu.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu075"]
[OnName num="chinatsu"]
"Well, I'm not sure.
[cpg cn=true]


After that, Chinatsu told me secretly.
[cpg]


He had sent an email to his sister Koyuki. He wondered where she was now.
[cpg]


The reply was short: "I'm at Michiru's." "I'm at Michiru's," she replied.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu076"]
[OnName num="chinatsu"]
I think she's at Michiru's place. Don't worry about it for now.
[cpg cn=true]


[OnName num="yuma"]
I was sorry, but I was on my way to the school.
[cpg cn=true]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I was sorry, but I went to the school.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se007"]
;//【ＳＥ】『学園のチャイム』





The first time I went to the school, I was in the middle of my lunch break. The first thing to do is to make sure that you have the right tools and the right people to help you.
[cpg]


[OnName num="yuma"]
I was with my sisters and I was going through some stuff.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina067"]
[OnName num="reina"]
What do you mean "they"?　What do you mean by "the others"?
[cpg cn=true]


[OnName num="yuma"]
"Well,......, a lot of things happened. Various things.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina068"]
[OnName num="reina"]
"Yeah, well... I'm curious about the way you say "sisters".
[cpg cn=true]


I wonder if she saw right through me. I'm not sure.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina069"]
[OnName num="reina"]
　I'm in the position of having been rejected long ago. I don't want to see you in trouble.
[cpg cn=true]


[OnName num="yuma"]
"I'm sorry, .......
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina070"]
[OnName num="reina"]
Don't apologize. If you're going to apologize, you might as well get it off your chest.
[cpg cn=true]


I guess so. I thought I had made my decision, but I knew I wasn't ready to face Koyuki-sis.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




[SE f="se011"]
;//【ＳＥ】『歩く』


I think about it on my way home. It's easy to be happy with Chinatsu.
[cpg]


But that is not considering Koyuki's feelings at all.
[cpg]


I wondered if I should have gone after her at that time.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン４の部屋』（夜）******************************************************





The first thing you need to do is to make sure that you have a good time with your friends and family.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu077"]
[OnName num="chinatsu"]
I was in Chika's room. "......You still look lost, don't you?
[cpg cn=true]


[OnName num="yuma"]
I don't know what to do. I don't know what to do.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chinatsu078"]
[OnName num="chinatsu"]
I can accept whatever you want to do. I can accept whatever you want to do.
[cpg cn=true]


[OnName num="yuma"]
I can do whatever you want to do.
[cpg cn=true]


I could only reply like that.
[cpg]


[OnName num="yuma"]
Right now, I just miss my sister Chinatsu.
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu079"]
[OnName num="chinatsu"]
I'll make that wish come true, too. I will stand by you no matter what.
[cpg cn=true]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



And after all, Koyuki did not come back home that day.
[cpg]


I probably shouldn't just wait for her to come home.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





Holiday. I got the address from Chinatsu and decided to head to Michiru's house.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu080"]
[OnName num="chinatsu"]
I asked her, "......, do you want me to go with you?"
[cpg cn=true]


[OnName num="yuma"]
I'm not going to go with you. I'm fine on my own.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu081"]
[OnName num="chinatsu"]
I was shocked and thought, "Yes, I can go. I'm sure ...... your sister must have been quite shocked.
[cpg cn=true]


[OnName num="yuma"]
I know that. I know that. That's why I'm going.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu082"]
[OnName num="chinatsu"]
I'll leave it to Yu-kun, then.
[cpg cn=true]


 After having that conversation with Chinatu-nee-san, I left the house.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************



[SE f="se011"]
;//【ＳＥ】『歩く』





 I haven't seen Sister Koyuki-san for two days.
[cpg]


The first time this has happened in a long time,......, or is it the first time?
[cpg]


The first time I saw her, I thought she was going to be a great actress.
[cpg]


I never thought this would happen.
[cpg]


If I had realized my feelings earlier, I might not have hurt Koyuki-san.
[cpg]





;//ブラックアウト


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


Michiru's room was in an apartment. She seems to live alone.
[cpg]


No, it's just the two of us now. ......, I thought as I pressed the intercom.
[cpg]



[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=2000]


[SE f="se001"]
;//【ＳＥ】『ドア開く』





[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michiru019"]
[OnName num="michiru"]
Hi, Yuma-kun. Oh, Yuma-kun.
[cpg cn=true]


[OnName num="yuma"]
"Are you there, ...... Koyuki-san?"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michiru020"]
[OnName num="michiru"]
I'm here. Koyuki, your brother is here.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

Koyuki came to the door from the back of the room.
[cpg]


[OnName num="yuma"]
I'm sorry about the other day. I want to talk to you properly, sister.
[cpg cn=true]


Koyuki looked like she was about to cry. I'm not sure if she was crying the whole time or not.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Koyuki155"]
[OnName num="koyuki"]
Shall we talk outside ......? I don't want Michiru to hear."
[cpg cn=true]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]


We walked outside and talked.
[cpg]


[OnName num="yuma"]
I still like Chinatsu.
[cpg cn=true]


[OnName num="yuma"]
But I also like Koyuki. This is not love.
[cpg cn=true]


[OnName num="yuma"]
I love you as a family. That's why I want you to come back.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Koyuki156"]
[OnName num="koyuki"]
You're so selfish. ...... you don't know what I was thinking the last two days.
[cpg cn=true]


[OnName num="yuma"]
"......I'm sorry."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Koyuki157"]
[OnName num="koyuki"]
I'm sorry. "If you want me to come back, I will. But don't think this will make up for it.
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（昼）******************************************************





[OnName num="yuma"]
"......, I'm home."
[cpg cn=true]


[OnName num="mother"]
Welcome back, Yuma. ......Where did Koyuki go?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki158"]
[OnName num="koyuki"]
I got into a bit of a fight. I'm not sure what to do with the rest of it.
[cpg cn=true]


 Sister Koyuki-san who said that was blatantly in a bad mood.
[cpg]


 Sister Koyuki-san will continue to be jealous of Chinatu nee-san for a while.
[cpg]


[free time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/2" time=800]

[VOICE f="Chinatsu083"]
[OnName num="chinatsu"]
 "Welcome back... you came back, Onee-chan."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Koyuki159"]
[OnName num="koyuki"]
I often say that. The reason why I left is also on you.
[cpg cn=true]


[OnName num="mother"]
What do you mean?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Koyuki160"]
[OnName num="koyuki"]
Don't you notice?"　Yuma likes Chinatsu. Of course, not as a sister and brother."
[cpg cn=true]


[OnName num="mother"]
......
[cpg cn=true]


Mom fell silent.
[cpg]


 I think it can't be helped for Sister Koyuki-san to say something like this.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



 Just like that, Sister Koyuki went back to her room.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_og"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************





[OnName num="father"]
I see,......, Chinatsu and Yuma.
[cpg cn=true]


[OnName num="yuma"]
I'm sorry I didn't ...... tell you.
[cpg cn=true]


[OnName num="father"]
The actuality is that the actuality is that the actuality is not really a good thing.
[cpg cn=true]


I'm sure you're right. I am not sure if I can be of any help.
[cpg]


I need to make up with her at least. That's ......
[cpg]


[OnName num="mother"]
Why is Koyuki mad at me?"
[cpg cn=true]


Mom seemed to be thinking something similar.
[cpg]


[OnName num="yuma"]
I can't explain it to ...... you.
[cpg cn=true]


;//体の関係の話にもなる。ぼかして説明するしかない。
It can be an awkward conversation. I had no choice but to blur it out and explain.
[cpg]


[OnName num="mother"]
'Yes,' she said. But we'll be sad if you three don't get along.
[cpg cn=true]


[OnName num="father"]
I have no doubt about that."
[cpg cn=true]


I wonder what ...... I should do. I wonder what kind of words Koyuki-san is waiting for me to say.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン４の部屋』（夜）******************************************************





I know that. I know what she is looking for.
[cpg]


I know that. I want her to tell me she loves me, not as a sister or brother.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

But I can't say that. I have Chinatsu sister. ......
[cpg]


[OnName num="yuma"]
What should I do?
[cpg cn=true]



[VOICE f="Chinatsu084"]
[OnName num="chinatsu"]
I don't ...... know.
[cpg cn=true]


[OnName num="yuma"]
I don't know what to do." "Maybe it was better when I was two-timing Chinatsu and Koyuki,.......
[cpg cn=true]


The actuality that the actuality that the actuality is that the actuality is the actuality that the actuality is the actuality is the actuality that the actuality is the actuality is the actuality.
[cpg]


 Chinatu nee-san fell silent for a moment. I thought I was wrong, but Chinatu nee-san gave an unexpected reply.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu085"]
[OnName num="chinatsu"]
Then you can give me a two-timing.
[cpg cn=true]


[OnName num="yuma"]
What do you mean ......?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chinatsu086"]
[OnName num="chinatsu"]
'Of course, I have a monopoly on you. But I don't want Yu-kun to choose just one person.
[cpg cn=true]


[OnName num="yuma"]
......"
[cpg cn=true]


That's a bit too much to be lenient. Chinatsu-sis wouldn't be asking for this.
[cpg]


[OnName num="yuma"]
I can't be that picky.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chinatsu087"]
[OnName num="chinatsu"]
I'm not going to be that lenient. The actuality that you can't get a lot of these types of things.
[cpg cn=true]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



...... I'm just as Chinatsu's sister invites me.
[cpg]


No, is it the other way around?
[cpg]


Is she asking me out or am I giving her free reign? Without knowing any more, I couldn't hold back my inferiority complex and pressed closer to my sister.
[cpg]

;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン４の部屋』（夜）******************************************************





[OnName num="yuma"]
I was so excited that I went to ...... and asked her to come over to me.
[cpg cn=true]


I suddenly come back to myself. Koyuki is in her room by herself while I'm doing this.
[cpg]


Is it ok to leave her alone and love Sis Chinatsu?
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu088"]
[OnName num="chinatsu"]
What?　Yu-kun.
[cpg cn=true]


[OnName num="yuma"]
I'm not qualified to love just one person.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chinatsu089"]
[OnName num="chinatsu"]
I'm not qualified to love just one person.　I'm good."
[cpg cn=true]


[OnName num="yuma"]
"......, so you're being too picky."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu090"]
[OnName num="chinatsu"]
I told you it's okay to be picky.
[cpg cn=true]


Similar exchanges are repeated. No matter what I say any more, it might go like this.
[cpg]



;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu091"]
[OnName num="chinatsu"]
"I wonder if I could have taught ...... Yu-kun something."
[cpg cn=true]


He says something indescribable. But it's no good if I can't answer that I was taught.
[cpg]


[OnName num="yuma"]
"Thank you ....... Chinatsu sis,...... I'll give you my answer in my own way."
[cpg cn=true]


;//千夏姉さんと交わった後、俺は自室に戻って一人考える。
After discussing it with Chinatsu, I went back to my room and thought about it alone.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（朝）******************************************************





I can't sleep. The most important thing to remember is that you can't just take a look at your own personal information.
[cpg]


But no matter how many times I thought about it, it was the same. I came to the conclusion that I have no choice but to get close to Koyuki again.
[cpg]


Chinatsu and I are lovers. I can't stop that.
[cpg]


I can't treat Koyuki sister and Chinatsu sister equally now.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se001"]
;//【ＳＥ】『ドア開く』






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン１の部屋』（朝）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki161"]
[OnName num="koyuki"]
I'm not going to stop it.　What do you want to talk about?
[cpg cn=true]


[OnName num="yuma"]
Sis. After all, we ...... should go out together."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Koyuki162"]
[OnName num="koyuki"]
What are you talking about? You said you like Chinatsu, right?
[cpg cn=true]


[OnName num="yuma"]
I'll go out with Chinatsu. The most important thing to remember is that you should not be afraid to ask for help from your friends and family. The most important thing to remember is that you should not be afraid to ask for help.
[cpg cn=true]


[OnName num="yuma"]
If you really need me, you can touch each other......... I can't say it well enough.
[cpg cn=true]


[OnName num="yuma"]
It's all my fault, isn't it, that Koyuki is so angry with me?
[cpg cn=true]


This is a decision for me, beyond love and all that. I never thought I would do this.
[cpg]


[OnName num="yuma"]
I'm sorry, it's a little late for that. But I hope you can get back in a good mood.
[cpg cn=true]


[OnName num="yuma"]
I think I can be a good brother for you, Koyuki.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki163"]
[OnName num="koyuki"]
I understand.
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************



[SE f="se011"]
;//【ＳＥ】『歩く』





Thus, after talking to her, I headed to the school.
[cpg]


I wonder what Koyuki thought about it.
[cpg]


She might not approve of my two-timing situation.
[cpg]


She might think it's such an ambiguous thing. ......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





By the time I got home after school, I was getting anxious.
[cpg]


[OnName num="yuma"]
'Huh. ......
[cpg cn=true]


But it's all my doing. I'm the one who has to fix it.
[cpg]


Because I'm sure my sister had to go through more pain than I did.
[cpg]


So ...... this is all good.
[cpg]



;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

After returning home from school, we had a family gathering.
[cpg]


[OnName num="mother"]
She seems to be in a better mood. Koyuki.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Koyuki164"]
[OnName num="koyuki"]
"What?　I wonder if it's ...... true.
[cpg cn=true]


[OnName num="mother"]
Yes, I am. You don't have to be so surprised.
[cpg cn=true]


I wonder if Mom is aware. I wonder if my mom is aware of what we're doing.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="Koyuki165"]
[OnName num="koyuki"]
But Yuma and I have made up ...... with each other. I know I sound like a child.
[cpg cn=true]

[free time=1000]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Chinatsu092"]
[OnName num="chinatsu"]
"......, I see. I'm glad.
[cpg cn=true]


Chinatsu knows everything. We had such a conversation at an indescribable distance.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『レストラン店内』（昼）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]


On holidays, I went out with my sisters. I went out with my sisters.
[cpg]


Now we are having lunch at Chinatsu-sis's office. Of course, Chinatsu is not working today.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Chinatsu093"]
[OnName num="chinatsu"]
I think it's been quite a while since the three of us went out together.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki166"]
[OnName num="koyuki"]
I'm sure it has. When was the last time you went out together ......?
[cpg cn=true]


Before I knew it, the animosity between Sister Koyuki-san and Chinatu nee-san disappeared.
[cpg]


 The three of us decided to go somewhere, so we took a random walk in the morning.
[cpg]


We didn't have any particular purpose in mind for each of us.
[cpg]


No, in fact, we were all thinking the same thing. In other words, each of us wants to be by each other's side.
[cpg]






;//ブラックアウト



[SE f="se011"]
;//【ＳＥ】『歩く』



;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





Just being by their side makes them happy. Such a time passes by.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Koyuki167"]
[OnName num="koyuki"]
"Yuma_......, may I cross your arms?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Chinatsu094"]
[OnName num="chinatsu"]
Oh, that's not fair. Then, me too.
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/2" time=800]
Flowers in both hands.
[cpg]


I don't think I'll ever be able to have a proper relationship again. Still, I think about what will happen now.
[cpg]


......For me. I'm not sure if this is a good idea or not, but it's a good idea.
[cpg]

Koyuki's sister seems to be slowly understanding and agreeing with this.
[cpg]


I think she's not jealous now and is happy with the relationship she has now.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『町』（夜）******************************************************





The relationship between me and my sisters will continue.
[cpg]


If the best thing for me is Chinatsu by all means, then ......
[cpg]


I wonder if Koyuki will give up on me one day.
[cpg]


Whether that day comes or not, ...... I will only give my love to both of them.
[cpg]






;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]



And then, the night dawns completely.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_og"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************





[OnName num="yuma"]
'Huh,...... I'm sleepy.'
[cpg cn=true]


Without a wink of sleep, I try to head to the school.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu095"]
[OnName num="chinatsu"]
Why don't you go to bed?　I'm a little sleepy, too.
[cpg cn=true]


The first time I went to the school, I was so tired I could hardly stand to look at the school.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chinatsu096"]
[OnName num="chinatsu"]
I'll put you on my lap. Come here.
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（ソファに座るヒロインの膝枕で眠る主人公）ev_41
;//人物１：ヒロイン４
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の家＿リビング
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_41_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="yuma"]
"...... sis."
[cpg cn=true]



[VOICE f="Chinatsu097"]
[OnName num="chinatsu"]
What is it?　Yu-kun.
[cpg cn=true]


I was about to fall asleep on her lap.
[cpg]


[OnName num="yuma"]
If I fall asleep like this, you won't be able to move either.
[cpg cn=true]



[VOICE f="Chinatsu098"]
[OnName num="chinatsu"]
I'm going to sleep like this, too. I'm thinking of falling asleep too.
[cpg cn=true]


[OnName num="yuma"]
I'm thinking of going to sleep like this. ......
[cpg cn=true]


The love between us has become complicated.
[cpg]


Chinatsu sister is the most important person in my life, but I also have an ongoing relationship with Koyuki sister.
[cpg]


This was the only way, I know, but I still feel bad for both of them.
[cpg]


[OnName num="yuma"]
Well, good night."
[cpg cn=true]



[VOICE f="Chinatsu099"]
[OnName num="chinatsu"]
Good night. 
[cpg cn=true]


I wonder if I made the right choice. No, it wasn't.
[cpg]


There is no right answer to who you love. I loved Chinatsu because I wanted to love her.
[cpg]


Even if you don't feel happy about this situation, it doesn't mean that the love inside me is the problem.
[cpg]


And I'm not unhappy now, I'm even positively happy.
[cpg]


Then I fell asleep, thinking that nothing is lost. ......
[cpg]



;//ブラックアウト
;//ＥＮＤ　ヒロイン４ルート
[SCENE id=14]

[jump storage="epend.ks" target="*start"]




