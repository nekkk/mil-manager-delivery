
*start



;#################################################
*Ep012|The truth that will one day be known
;#################################################


[SCENE id=12]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************





I will continue to lie to my sister Koyuki and to my senpai.
[cpg]


I wondered if this was the right thing for me to do, but I did nothing from here.
[cpg]


Even Ms. Nanano does not know the truth. I wonder if I should just talk to her about it. ......
[cpg]


I think a lie like this will be exposed soon. I need to figure out what to do before she finds out.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Then one day. I was in a tight spot.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina136"]
[OnName num="reina"]
I was in a tight spot. Can I come over to your house today?
[cpg cn=true]


[OnName num="yuma"]
"What, ......?"
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina137"]
[OnName num="reina"]
"Sure, why not? I've been dumped, but that doesn't mean we're no longer friends.
[cpg cn=true]


There is no reason to refuse here. But it would be bad if I don't give some reason to refuse.
[cpg]


The actuality that the two of you are now in a twisted lying situation, it's not good for the two of you to run into each other.
[cpg]


[OnName num="yuma"]
I'm not going to do that. Look, my room is a mess.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Reina138"]
[OnName num="reina"]
I won't go up to your room. That's fine.
[cpg cn=true]


[OnName num="yuma"]
I have something to do today.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina139"]
[OnName num="reina"]
What kind of errands?　What is it? Are you trying to hide something?
[cpg cn=true]


Oh, no. If I don't do anything, I'll be pushed aside.
[cpg]


I thought so, but I was the one who couldn't push myself through at a time like this.
[cpg]


It all started with my lie. It's impossible for me to push through this. ......
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se001"]
;//【ＳＥ】『ドア開く』




[VOICE f="Reina140"]
[OnName num="reina"]
Ojamashimasu!
[cpg cn=true]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夕方）******************************************************




[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/2" time=800]

In the end, my senpai came to my house.
[cpg]



[VOICE f="Koyuki211"]
[OnName num="koyuki"]
"...... Oh, Rena. You came."
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Reina141"]
[OnName num="reina"]
Yes. I wanted to give up, or ...... to get it over with."
[cpg cn=true]


The first thing to do is to make sure that you have a good time with your family.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Koyuki212"]
[OnName num="koyuki"]
Well, whatever you do, be happy with ...... Yuma.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Reina142"]
[OnName num="reina"]
The actuality is, you can't just give up on your own.　What are you talking about?
[cpg cn=true]


Koyuki sis is Koyuki sis and she is saying things that make senpai jealous.
[cpg]


[OnName num="yuma"]
Come on, come on, come on. You want to see me, let's go up to my room."
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Reina143"]
[OnName num="reina"]
Why?　I thought it was a mess.
[cpg cn=true]


Chinatsu was listening to our conversation and was very irritated. I'm not sure if this is a good idea.
[cpg]


They're going to find out I'm dating someone else.
[cpg]


Then they will try to find out who I am dating and with whom. ......
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Chinatsu119"]
[OnName num="chinatsu"]
"Hey, Yu-kun,...... are you hiding anything from me?"
[cpg cn=true]


[OnName num="yuma"]
I'm not. I'm fine. ......
[cpg cn=true]


I probably shouldn't have said, "It's okay. If you're not hiding anything, just be open about it.
[cpg]


I can't help it if I tell lies like this that I don't have to. ......
[cpg]


Or is it a necessary lie? I'm not sure what I'm supposed to do anymore.
[cpg]


I was beginning to lose my mind.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



In the end, everything was not exposed that day, but it was pretty close.
[cpg]


Both Koyuki and my senpai are suspicious of me.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************



[SE f="se011"]
;//【ＳＥ】『歩く』





[OnName num="yuma"]
"...... Good morning, Ms. Nanano.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano085"]
[OnName num="nanano"]
Good morning. I'm not sure what to do with the rest of it.
[cpg cn=true]


That's because I'm like this for ...... Nanano-san, who is also tired.
[cpg]


But it's also different to impose it on Nanano-san. I'm doing this on my own.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano086"]
[OnName num="nanano"]
I'm going to go to the academy again today, aren't I? See you later.
[cpg cn=true]


[OnName num="yuma"]
"Yes. ...... Well, um..."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano087"]
[OnName num="nanano"]
You can come back later in the evening. I'll be waiting for you anytime.
[cpg cn=true]


Ms. Nanano anticipates the answer I want and says it before I do.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





Then, in the evening. I head to Ms. Nanano's house.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano088"]
[OnName num="nanano"]
;//「来てくれたんですね。それじゃあ、しましょうか」
She says, "I'm glad you came.
[cpg cn=true]


[OnName num="yuma"]
Let's see, ......, Ms. Nanano.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano089"]
[OnName num="nanano"]
What is it?　Yuma-kun.
[cpg cn=true]


I was about to tell you all about it. The story of the two girls I dumped......
[cpg]


But it wasn't directly related to Ms. Nanano. So I didn't tell her.
[cpg]


[OnName num="yuma"]
'No, it's nothing.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano090"]
[OnName num="nanano"]
'...... is that so?　Then that's fine."
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



After arriving home, Ms. Nanano went into the bathroom to wash off the sweat she had worked up walking around town.
[cpg]


I was going to wait in my room, but she asked me to stay in front of the bathroom and talk to her.
[cpg]

;//========================================
;//●ＣＧ（背中を向けつつ、振り返るヒロイン）ev_74
;//人物１：ヒロイン３
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：風呂場
;//時間　：夜
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_74_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています

;//様々なフラストレーションが溜まる中、愛しい人は紛れもなく目の前に居る。
Across the doorway, my beloved was sweating.
[cpg]

I must have been going crazy in that situation.
[cpg]

[OnName num="yuma"]
I thought to myself, "...... Nanano-san!"
[cpg cn=true]


;//迫られて、彼女は頬を染めながらも嫌がらない。
I was calling out to Ms. Nanano in a way that would be embarrassing if I were calm.
[cpg]

[VOICE f="Nanano091"]
[OnName num="nanano"]
What is it?　I think I can meet your desires.
[cpg cn=true]


I think she is a wonderful person. But there are still obstacles to being united with her without any indebtedness. ......
[cpg]


I have to tell the truth to Koyuki and my senpai.
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano092"]
[OnName num="nanano"]
Well, I'll see you later. Give my regards to your sister."
[cpg cn=true]


[OnName num="yuma"]
"...... yes."
[cpg cn=true]


I'm not in a position to say hello. But it can't be helped.
[cpg]


Ms. Nanano probably has no idea what I'm going through.
[cpg]


But I still think about it. What was I supposed to do?
[cpg]


I lied to both Koyuki and my senpai.
[cpg]


But, should I have not lied there?
[cpg]


If I had stayed away from lying, they would have tried to sabotage Nanano and I's relationship, or something like that ......
[cpg]


I don't think so. ...... Neither my sister nor my senpai have that kind of personality.
[cpg]


If that's the case, is the lie I'm telling you completely pointless?
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano093"]
[OnName num="nanano"]
You are troubled by something, aren't you? Yuma-kun.
[cpg cn=true]


[OnName num="yuma"]
"Well, that's ...... not true."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano094"]
[OnName num="nanano"]
Please tell me when you can. I think I can help you.
[cpg cn=true]


It is not so easy to say that you think you can help.
[cpg]


 I thought that Nanano san must be a really confident woman.
[cpg]






;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I continue to date Ms. Nanano with a secret in my mind.
[cpg]


While I was thinking what I was doing, Koyuki-sister and senpai seemed to be aware of my lie in some way.
[cpg]


Maybe it would be better to wait for them to realize it.
[cpg]


But I thought that would be too pathetic.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『町』（昼）******************************************************





Day off, noon. I go to Ms. Nanano's place as usual.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano095"]
[OnName num="nanano"]
Hello, Yuma-kun. Yuma, please come in.
[cpg cn=true]


[OnName num="yuma"]
"......, Ms. Nanano."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano096"]
[OnName num="nanano"]
What's wrong?　Are you ready to tell me about the trouble you've been having?
[cpg cn=true]


I can see through everything. But it's not something you talk about on the doorstep.
[cpg]


[OnName num="yuma"]
Yes, I'm here. May I go up to ......?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano097"]
[OnName num="nanano"]
"Yes. Please come in.
[cpg cn=true]





;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_11_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]


Finally, I reveal my secret to Ms. Nanano.
[cpg]


I told Koyuki and my senpai ...... that I had lied to them both.
[cpg]


I know that neither of them are acquainted with Ms. Nanano, but I wanted to tell them.
[cpg]


[OnName num="yuma"]
"I lied to ...... both of them. I told my senpai that I was dating Koyuki-sama,......."
[cpg cn=true]


[OnName num="yuma"]
"On the contrary, I told Koyuki that I was going out with my senpai.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano098"]
[OnName num="nanano"]
So that's what happened. How did that happen?"
[cpg cn=true]


[OnName num="yuma"]
I wonder how it came to that. I don't know. I didn't have that much contact with Ms. Nanano at the time.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano099"]
[OnName num="nanano"]
You say that so casually. I think you're probably right.
[cpg cn=true]


I think ...... that would be the case. It was insensitive.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano100"]
[OnName num="nanano"]
If you're going to keep lying to me, it means you can't be proud to say you're dating me, right?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano101"]
[OnName num="nanano"]
I don't want to do that. But in the end, it's up to you to decide.
[cpg cn=true]


[OnName num="yuma"]
"Even though ......, I ......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano102"]
[OnName num="nanano"]
I'm sure you already know what you want to do.
[cpg cn=true]


That's right. We can't dwell on it forever.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano103"]
[OnName num="nanano"]
I'm sure you've already figured out what you want to do.　You're not going to do anything with me?
[cpg cn=true]


[OnName num="yuma"]
No, I'm not going to do anything with you. No. I've asked for your advice.
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
I kiss Nanano on the mouth. The truth is that we love each other.
[cpg]


;//移植のためシーンをカットしています
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


I felt that if I could correct my shitty lies, we could hang out more comfortably.
[cpg]


That's why those lies come out because I'm not confident. ......
[cpg]


It's also terribly disrespectful to Ms. Nanano. I'm not confident in myself to love her.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





By the time I left the house, it was already late in the evening.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano104"]
[OnName num="nanano"]
I was so disappointed that I had to leave the house.　Was I of any use to you?
[cpg cn=true]


[OnName num="yuma"]
Yes, I have. Yes, I feel like I can finally put my heart on the line.
[cpg cn=true]


It's a little early for that, isn't it? I haven't corrected my lie yet.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano105"]
[OnName num="nanano"]
"Hmmm. You look much better than the other day.
[cpg cn=true]


I think you're right. It's a lot different now that you've made up your mind. ......
[cpg]


[OnName num="yuma"]
I'll see you later. I'll be back.
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano106"]
[OnName num="nanano"]
Yes, anytime. I'll be here anytime.
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





I was alone in my room, thinking. I wonder how best to explain it.
[cpg]


I think it's okay to talk to them individually, but ...... I think it's better to invite the seniors to my house.
[cpg]


What shall we do with Ms. Nanano at ......? I feel like I shouldn't be there.
[cpg]


She didn't do anything wrong, but I don't want to make her feel awkward.
[cpg]


I spent the rest of the night thinking about this and that.
[cpg]


Really, it's all my own fault, but I don't want to think it's too much trouble because of .......
[cpg]


I want to think it over and make the right decision.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（昼）******************************************************




[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Reina144"]
[OnName num="reina"]
I said to myself, "So, ......, what's the story?　What do you want to talk about?
[cpg cn=true]


[OnName num="yuma"]
I owe you both an apology.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki213"]
[OnName num="koyuki"]
Apologize for what?
[cpg cn=true]


[OnName num="yuma"]
I've been lying to you both. I'm sorry. I'm not dating your sister or your senior.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Koyuki214"]
[OnName num="koyuki"]
What?　Is that so?
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Reina145"]
[OnName num="reina"]
"I had a feeling that you were.
[cpg cn=true]


The reaction of the two was different. But that's not really the issue. The problem starts here.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Reina146"]
[OnName num="reina"]
So?　Then who are you dating?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Koyuki215"]
[OnName num="koyuki"]
Yes, it's not you or me, is there someone else you're close to?
[cpg cn=true]


[OnName num="yuma"]
I can't tell you that. I thought about it a lot yesterday, but I want to keep it a secret.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki216"]
[OnName num="koyuki"]
It's selfish. I can't do it.
[cpg cn=true]


[OnName num="yuma"]
"I can't. ...... you and your sister Koyuki might get into a fight.
[cpg cn=true]


[OnName num="yuma"]
I know it's my fault for lying to you, but I don't think you'll be able to keep your cool.
[cpg cn=true]


You are so selfish. I can't complain about what she says to me.
[cpg]


[OnName num="yuma"]
I love her enough to think that way. I want to protect her."
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Reina147"]
[OnName num="reina"]
'...... I'm good. No matter who I dated, I was dumped in the end."
[cpg cn=true]


It's different from the lies I've told before. Just a secret. I'm not saying anything wrong.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Koyuki217"]
[OnName num="koyuki"]
"...... I'm not convinced.
[cpg cn=true]


She was joking a little too. I guess she understood what I was trying to say.
[cpg]


Nothing more happened that day. She said a lot of things, but she didn't immediately take my cell phone and check it.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************



[SE f="se011"]
;//【ＳＥ】『歩く』





I was able to come to terms with the situation and go to Nanano's place without any rancor.
[cpg]


On my way home on Monday. I was on my way to her place.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano107"]
[OnName num="nanano"]
"Welcome home, Yuma. Yuma-kun.
[cpg cn=true]


[OnName num="yuma"]
Good evening, Ms. Nanano. ...... I told you everything.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano108"]
[OnName num="nanano"]
I've said it all. How are you feeling?
[cpg cn=true]


[OnName num="yuma"]
"As you can imagine,......, I feel much better after all.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nanano109"]
[OnName num="nanano"]
I know," he said. It takes a lot of energy just to tell a lie.
[cpg cn=true]


The actuality that you can be a lot more than just a little bit of a liar.
[cpg]


[OnName num="yuma"]
I'm sure you've always been straightforward with me, haven't you?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano110"]
[OnName num="nanano"]
I've always been that way.　I've always been that way.
[cpg cn=true]


The whole thing was my one-woman show. Even though I know that, I feel ashamed.
[cpg]




;//ブラックアウト
;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





Later, after we returned home and finished dinner.
[cpg]



[SE f="se004"]
;//【ＳＥ】『ノック』





I took a bath, and while I was sitting in my room, someone knocks on the door.
[cpg]



[VOICE f="Koyuki218"]
[OnName num="koyuki"]
"May I come in?"
[cpg cn=true]


[OnName num="yuma"]
"Come in to ......."
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『ドア開く』





[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki219"]
[OnName num="koyuki"]
Can I ...... talk to you for a minute?
[cpg cn=true]


[OnName num="yuma"]
"Yes, I'd like to talk to you. What is it?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Koyuki220"]
[OnName num="koyuki"]
I saw you. I saw you go into that woman's house.
[cpg cn=true]


[OnName num="yuma"]
"......, did you really follow me?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki221"]
[OnName num="koyuki"]
No way. It was just a coincidence.
[cpg cn=true]


I don't know. I don't know, but I think my sister would at least follow me. ...... That aside, I'm sure she'd be pissed.
[cpg]


He would be angry. He might even say that he wants to talk to Ms. Nanano and the three of us from now on ...... and be ready to do so.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki222"]
[OnName num="koyuki"]
"She was really beautiful,....... If it's with a beautiful woman like that, it can't be helped."
[cpg cn=true]


[OnName num="yuma"]
What?"
[cpg cn=true]


Unlike the reaction I had expected, I was out of sync.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki223"]
[OnName num="koyuki"]
I'm sorry," he said. I may have unconsciously put pressure on her not to go out with someone I don't know.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Koyuki224"]
[OnName num="koyuki"]
So I'm sure Yuma lied to you too.
[cpg cn=true]


[OnName num="yuma"]
No, that's not true. ......
[cpg cn=true]


I can't say that I don't, but I still think it would be strange if I didn't say it was my fault, even though I can't say it isn't. 
[cpg]


[OnName num="yuma"]
I'm sure you don't have anything to feel guilty about. You didn't do anything wrong.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Koyuki225"]
[OnName num="koyuki"]
I don't think so.
[cpg cn=true]


[OnName num="yuma"]
I don't think so. Don't apologize.
[cpg cn=true]


I don't want you to apologize. I don't know what to do. But ......
[cpg]


But now that Koyuki told me that, I feel a little better again.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（朝）******************************************************



[SE f="se011"]
;//【ＳＥ】『歩く』





Days go by. I was still in a relationship with Ms. Nanano.
[cpg]


But it's still the same as before. ......
[cpg]


But it was still a happy time for me.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





Even when I'm at school, all I can think about is Nanano-san.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina148"]
[OnName num="reina"]
"Hey. Yuma, are you listening?"
[cpg cn=true]


[OnName num="yuma"]
"Oh, I'm sorry, ...... what was it?"
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina149"]
[OnName num="reina"]
I was thinking about that guy I've been going out with. Were you thinking about that guy you're going out with?
[cpg cn=true]


[OnName num="yuma"]
"......."
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina150"]
[OnName num="reina"]
I'm so glad you're happy.
[cpg cn=true]


The senior smiled as if he had given up somewhat.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina151"]
[OnName num="reina"]
If you want to keep who I'm dating a secret, you can. But ...... you'll have to tell me sometime."
[cpg cn=true]


[OnName num="yuma"]
...... yeah."
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町』（夕方）******************************************************





I went out with Nanano with the encouragement of my senpai.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano111"]
[OnName num="nanano"]
'Good evening. Yuma-kun."
[cpg cn=true]


[OnName num="yuma"]
"Good evening,...... now, okay?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Nanano112"]
[OnName num="nanano"]
I was just about to wait for you to come. I was just about to wait too, so please come to ......."
[cpg cn=true]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se001"]
;//【ＳＥ】『ドア開く』

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_11_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************



We were happy. We talked about nothing but each other more and more.
[cpg]


[OnName num="yuma"]
I think my sister and senpai understood ...... each other, or rather they understood me.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano113"]
[OnName num="nanano"]
I see. I'm glad to hear that.
[cpg cn=true]


[OnName num="yuma"]
I'm glad to hear that," she said. If Ms. Nanano hadn't said anything to me, I would have ......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano114"]
[OnName num="nanano"]
That would be strange. If I hadn't been there, you wouldn't have had to lie to the two of us, would you?
[cpg cn=true]


Well, that's true. But I want to tell you that I am grateful.
[cpg]


[OnName num="yuma"]
I said, "...... Still, thank you. I feel like I'm constantly being saved by Ms. Nanano.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano115"]
[OnName num="nanano"]
I'm sure it's just my imagination. I didn't do anything.
[cpg cn=true]


;//移植のためシーンをカットしています


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_11_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************




The first thing to do is to make sure that you have a good understanding of what you are doing and how you are doing it.
[cpg]


About the future of each other... it's an exaggeration to say so.
[cpg]


I don't know what to say, but that's what we were talking about. Both of us, Nanano and I, are looking to the future.
[cpg]

[free time=800]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[WAIT time=1100]

[VOICE f="Nanano116"]
[OnName num="nanano"]
Yuma, how many children do you want to have? How many children do you want?"
[cpg cn=true]


[OnName num="yuma"]
I guess so. ...... right now, though I'm still a student myself.
[cpg cn=true]


[OnName num="yuma"]
But I want lots of them. I want a lot of children, don't you, Nanano?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Nanano117"]
[OnName num="nanano"]
I want to have a lot of children with Yuma. If it's a child with Yuma, I want one.
[cpg cn=true]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町』（夜）******************************************************



[SE f="se001"]
;//【ＳＥ】『ドア閉まる』





I left Nanano's house after that.
[cpg]


I'll have to say hello to her father someday.
[cpg]


I've been putting it off for a long time, or maybe it's just that I haven't had a chance to meet him. ......
[cpg]


But now I felt like there was nothing to be afraid of.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I returned home. Koyuki-san is not as grumpy as before.
[cpg]


Chinatsu seemed to be able to tell the truth through Koyuki.
[cpg]


A peaceful dinner passed. Then I return to my room at .......
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（夜）******************************************************





When I am alone, I have a lot to think about.
[cpg]


I've been thinking about doing something to support Ms. Nanano.
[cpg]


But even if I said such a thing, Nanano-san would probably say that I should study properly.
[cpg]


I can't sleep at night when I think about Ms. Nanano.
[cpg]


I think I love her too much. Could it be that she is feeling this way right now too?
[cpg]


Unable to stay awake, I contact her even though I have no business with her.
[cpg]



[SE f="se009"]
;//【ＳＥ】『携帯電話の発信音』


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


When I call, Ms. Nanano answers.
[cpg]


;//[lbox on]
[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[VOICE f="Nanano118"]
[OnName num="nanano"]
Hello. How can I help you?　Yuma-kun."
[cpg cn=true]


[OnName num="yuma"]
'Oh, um,...... somehow I feel like I can't sleep without hearing your voice.
[cpg cn=true]



[VOICE f="Nanano119"]
[OnName num="nanano"]
I see. I was in that mood too."
[cpg cn=true]


I don't know if what Ms. Nanano said was true or not, but somehow I was happy.
[cpg]


[OnName num="yuma"]
"...... Nanano. What the hell is going to happen to us?"
[cpg cn=true]



[VOICE f="Nanano120"]
[OnName num="nanano"]
What's wrong?　I'm not sure if it's true or not, but I'm kind of happy.
[cpg cn=true]


[OnName num="yuma"]
I've been thinking about how I could fool my sister and senpai.
[cpg cn=true]


[OnName num="yuma"]
But now that I'm no longer thinking about that, I'm thinking more about the uncertainties of the ...... future.
[cpg cn=true]



[VOICE f="Nanano121"]
[OnName num="nanano"]
I'm sure you don't have to worry about it. I'm sure you don't have to worry about it.
[cpg cn=true]



;//ブラックアウト



I'm sure you'll be able to find a way to get a good night's sleep.
[cpg]


 From the outside, they must be an annoying couple... I thought, but no one saw them.
[cpg]



[VOICE f="Nanano122"]
[OnName num="nanano"]
I know,...... your sister is convinced, isn't she?
[cpg cn=true]


[OnName num="yuma"]
Yes. Yes, I do."
[cpg cn=true]



[VOICE f="Nanano123"]
[OnName num="nanano"]
Then, can I go to Yuma's house once?
[cpg cn=true]


There was no reason for me to refuse. I decided to accept.
[cpg]


[OnName num="yuma"]
It's okay. It's a little messy.
[cpg cn=true]



[VOICE f="Nanano124"]
[OnName num="nanano"]
I'd like to see it even more. When shall we do it then?
[cpg cn=true]


[OnName num="yuma"]
I'll see what I can do. ......
[cpg cn=true]


We talked and made an appointment.
[cpg]


;//[lbox off] 

After exchanging words of love, we fell asleep.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（昼）******************************************************





The day of the appointment. It was a holiday, so both Ms. Nanano and I were able to meet in the daytime.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Nanano125"]
[OnName num="nanano"]
She said, "Hello. Yuma-kun ...... and his sisters."
[cpg cn=true]


There they were, the sisters. I guess they wanted to meet at first sight.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="Koyuki226"]
[OnName num="koyuki"]
I've heard about you, Mr. Nanano. I've heard about you, right, Ms. Hadano?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Chinatsu120"]
[OnName num="chinatsu"]
You're dating that ...... Yuu-kun, right?"
[cpg cn=true]


It's not like Chinatsu's sister. It's direct.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano126"]
[OnName num="nanano"]
Yes. We're in a relationship."
[cpg cn=true]


Ms. Nanano was also direct. I'm not sure if it's too formal or not.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Koyuki227"]
[OnName num="koyuki"]
"Please make Yuma happy, .......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano127"]
[OnName num="nanano"]
Of course.
[cpg cn=true]


Nanano-san laughed. The first thing to do is to make sure that you have a good time with your friends and family.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿主人公の部屋』（昼）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano128"]
[OnName num="nanano"]
 "It's not messy at all, is it?"
[cpg cn=true]


[OnName num="yuma"]
I guess so. ...... Well, not much has changed since before.
[cpg cn=true]


I'm not the first person to bring Ms. Nanano up to my house.
[cpg]


It's the first time ...... that I'm raising them to my room in a situation where we are really, really lovers.
[cpg]


The sisters went out, perhaps out of concern for us.
[cpg]

;//移植のためシーンをカットしています


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano129"]
[OnName num="nanano"]
Sisters, both of you were beautiful."
[cpg cn=true]


[OnName num="yuma"]
'Well,...... I certainly think so, even from my brother's point of view.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nanano130"]
[OnName num="nanano"]
'And yet, it makes me ...... happy to think that you chose me. Hmm."
[cpg cn=true]


[OnName num="yuma"]
'......Whoever and wherever you are, it's the same. I think I would have found you, Nanano-san."
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nanano131"]
[OnName num="nanano"]
'You make me so happy. Yuma-kun."
[cpg cn=true]


A little silence. Ms. Nanano's cheeks are tinted again.
[cpg]


;//俺たちは服を着たばかりだというのに、また近づいていく。
We can no longer hold back our feelings and move closer.
[cpg]



;//========================================
;//●ＣＧ非エロ（キスをする二人。座っている状態）ev_80
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================



[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_op"]
;**【ＣＧ】 ev_80_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]



We can't stay apart anymore.
[cpg]


I'm sure Ms. Nanano knows that. At least I think I understand.
[cpg]


You never know what will happen in the future. We stumbled quite a bit at the beginning of our relationship. ......
[cpg]


I don't know if something like that will happen from now on.
[cpg]


But even so, I'm glad. If it's an ordeal that Nanano and I can face together, I'd like to ...... overcome it.
[cpg]


I thought of this as I felt her body heat.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





At the very least, I don't want to tell her any more bad lies.
[cpg]


That alone might be considered a great progress.
[cpg]


Ms. Nanano is so receptive that she seems to be able to correct ...... everything I do wrong.
[cpg]


Right now, I just want to be pampered. That's how I feel.
[cpg]



;//ＥＮＤ　ヒロイン３ルート
[SCENE id=17]

[jump storage="epend.ks" target="*start"]


;//==============================


