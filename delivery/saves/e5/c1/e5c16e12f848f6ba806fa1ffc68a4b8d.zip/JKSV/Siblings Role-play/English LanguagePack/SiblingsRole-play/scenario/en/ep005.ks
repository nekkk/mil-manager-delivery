
*start


;#################################################
*Ep005|Distance not a perfect lover.
;#################################################

[stflag flag3 = 0]
[stflag flag5 = 0]
[stflag flag6 = 0]

[if exp={ isSystemFlagsEnabled( "sysfla3") }]
[if exp={getFlagValue("flag3") == 0 }]
[stflag flag3 = 1]
[endif]
[endif]

[if exp={ isSystemFlagsEnabled( "sysfla5") }]
[if exp={getFlagValue("flag5") == 0 }]
[stflag flag5 = 1]
[endif]
[endif]

[if exp={ isSystemFlagsEnabled( "sysfla6") }]
[if exp={getFlagValue("flag6") == 0 }]
[stflag flag6 = 1]
[endif]
[endif]



[SCENE id=5]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（昼）******************************************************





We spend our days together. Me and Koyuki's sister were still the same distance.
[cpg]


The distance that is not a perfect lover. We kept that distance.
[cpg]


In the midst of spending my days like that, there was something that I was worried about.
[cpg]


It was about Chinatsu. Why did she come between me and Koyuki?
[cpg]


Maybe she wanted to avoid Koyuki and me from getting close to each other too quickly.
[cpg]


But I didn't have the courage to ask Chinatsu directly.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



[OnName num="yuma"]
I was so scared that she might have done it to avoid Koyuki and me getting close to each other.
[cpg cn=true]


Then one night. I was so excited to see her.
[cpg]


I thought about shutting it without saying a word, but I thought it would be better to tell her, so I glanced inside.
[cpg]


I just wanted to see if she was in the room.
[cpg]


Looking back, I think I was careless. I peeked into a woman's room.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン４の部屋』（夜）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Chinatsu032"]
[OnName num="chinatsu"]
......Yu-kun
[cpg cn=true]


There, Chinatsu was calling my name.
[cpg]

In his hand he holds a picture of me.
[cpg]

I think it was more than just calling her brother's name, it seemed to have that nuance.
[cpg]



;//==============================
;//選択肢13を選んでいた場合

[if exp={getFlagValue("flag5") == 0 }]
[jump target="*sw5_1"]
[endif]



I knew she was doing me a favor. ......
[cpg]


My hunch was not a misunderstanding. I am becoming convinced.
[cpg]


The events of the past are connected. I couldn't take my eyes off of Chinatsu.
[cpg]


[jump target="*sw5_2"]
;//==============================
;//選択肢14を選んでいた場合
*sw5_1|The distance that is not a perfect lover.




I saw something I shouldn't have seen.
[cpg]

However, I could not leave the place.
[cpg]




;//==============================
*sw5_2|The distance that is not a perfect lover

;//移植のためシーンをカットしています



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Then, I felt a presence behind me and turned around to find Koyuki there.
[cpg]

She was looking at me just as I was looking at Chinatsu.
[cpg]


[SE f="se001"]
;//【ＳＥ】『ドア開く』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ヒロイン４の部屋』（夜）******************************************************





Then Koyuki opened the door.
[cpg]


The three of us were all together in a situation where there was no room for deception.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Chinatsu033"]
[OnName num="chinatsu"]
What?　What's wrong, you two?
[cpg cn=true]


The first thing to do is to make sure that you have a good time with your friends and family.
[cpg]



[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki084"]
[OnName num="koyuki"]
I'm sorry I didn't notice it until now,.......
[cpg cn=true]


 Sister Koyuki-san might have noticed it vaguely.
[cpg]


I'm sorry I didn't notice, I thought that kind of thing was hidden in the words.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Koyuki085"]
[OnName num="koyuki"]
Yuma, did you notice it?
[cpg cn=true]


[OnName num="yuma"]
...... somehow."
[cpg cn=true]


I answered vaguely. And that's not what we should be discussing.
[cpg]


[OnName num="yuma"]
Maybe I'll just have to pick one of them.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Chinatsu034"]
[OnName num="chinatsu"]
You don't have to take ...... it that seriously.
[cpg cn=true]


[OnName num="yuma"]
I don't have to take it that seriously. I don't want to see you two squabbling.
[cpg cn=true]


It may not come to that.
[cpg]


But I was already sure that they would be fighting each other.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Koyuki086"]
[OnName num="koyuki"]
If you think I have to choose one of you, I want you to give me an answer as soon as possible.
[cpg cn=true]


I shut up. Then, Chinatsu-san comes to my rescue.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chinatsu035"]
[OnName num="chinatsu"]
I can wait," she said. I can wait.
[cpg cn=true]


It's not that Koyuki has no patience.
[cpg]


Normally, they would want an answer here and there. Chinatsu-san is clearly overreacting.
[cpg]


[OnName num="yuma"]
Can't you wait a little longer? ......
[cpg cn=true]


Still, I took advantage of my sister Chinatsu who was pushing me too hard.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



If that's true, I would prefer to give you the answer right here. We know that.
[cpg]


But I was lost.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（朝）******************************************************


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/2" time=800]


In the morning. We eat in an awkward atmosphere.
[cpg]


[OnName num="father"]
What's the matter, did you guys get into a ...... fight?
[cpg cn=true]


Rather, it was the opposite. I couldn't say, "What's the matter?
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Koyuki087"]
[OnName num="koyuki"]
It's nothing. I'm fine.
[cpg cn=true]


Koyuki sister says so, but ...... we don't even know how long we can keep this up.
[cpg]


We should try to come to a conclusion as soon as possible.
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



[OnName num="yuma"]
I'm off.
[cpg cn=true]


I'm heading to the school. I'm not even bitter because it's a daily habit.
[cpg]


Rather, the hardest part is when I'm at home ...... I even felt like I could have some relief for a little while.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina056"]
[OnName num="reina"]
"So?　You're not sure who you're going out with?"
[cpg cn=true]


[OnName num="yuma"]
Yes,......."
[cpg cn=true]


I had told my seniors everything.
[cpg]


I was in such a state of mind that I couldn't help but tell someone.
[cpg]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina057"]
[OnName num="reina"]
I'm stunned,......, you dumped me and now you're wondering if you should?
[cpg cn=true]


That's right. That's how I would react.
[cpg]


[OnName num="yuma"]
But..."
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Reina058"]
[OnName num="reina"]
Oh, God. I don't want to see Yuma in trouble when I don't have a chance. I don't want to see Yuma worrying when I don't have a chance anymore.
[cpg cn=true]


[OnName num="yuma"]
......
[cpg cn=true]


I see. I'm not just the sisters, but also the seniors.
[cpg]


It's not just the sisters. I have no choice but to make a decision.
[cpg]


[OnName num="yuma"]
"Thank you, senpai. I think I can make a decision.
[cpg cn=true]


[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Reina059"]
[OnName num="reina"]
"Yeah. I'm glad to hear that.
[cpg cn=true]


I can't afford to be lost now, can I? It's obvious. ......
[cpg]






;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se011"]
;//【ＳＥ】『歩く』





The senior's words were also a boost, and I knew I had no choice but to make a decision.
[cpg]


I had no choice but to do it. It was time to make up my mind.
[cpg]






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿リビング』（夜）******************************************************




[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Michiru017"]
[OnName num="michiru"]
"Oh, welcome back. Nice to see you.
[cpg cn=true]


[OnName num="yuma"]
"...... Michiru-san."
[cpg cn=true]


I know she's after me, too.
[cpg]


Maybe you are thinking something similar to sister Chinatsu.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Koyuki088"]
[OnName num="koyuki"]
I'm waiting for your answer, ...... Yuma. I'm waiting for your answer.
[cpg cn=true]


I think about it. After thinking about it, I decided to come to a conclusion.
[cpg]



;//ここまでの選択によって現れる選択肢が変化
;//選択肢４は常に発生。それしか無い場合は選択肢は発生せずすすむ



[if exp={getFlagValue("flag5") == 1 }]
[jump target="*rootch2_5"]
[endif]


[if exp={getFlagValue("flag6") == 1 }]
[jump target="*rootch2_6"]
[endif]

// There is no 5 or 6.
[jump target="*select06_1"]


//There is only 6.
*rootch2_6|Distance not a perfect lover.

;//■選択肢
[switch]
[case "I still love Koyuki sister"]
	[swap]
	[jump target="*select06_1"]
[case "I can't forget Michiru"]
	[swap]
	[jump target="*select06_3"]
[endswitch]



*rootch2_5|The distance that is not a perfect lover
[if exp={getFlagValue("flag3") == 1 }]
[jump target="*rootch2_56"]
[endif]

I have only //5
;//■選択肢
[switch]
[case "I still love Koyuki"]
	[swap]
	[jump target="*select06_1"]
[case "I care about Chinatsu"]
	[swap]
	[jump target="*select06_2"]
[endswitch]


*rootch2_56|The distance that is not a perfect lover
I have both //5 and //6

;//■選択肢
[switch]
[case "I still like Koyuki"]
	[swap]
	[jump target="*select06_1"]
[case "I care about Chinatsu"]
	[swap]
	[jump target="*select06_2"]
[case "I can't forget Michiru"]
	[swap]
	[jump target="*select06_3"]
[endswitch]


4、I still love Koyuki sister
5、I care about Chinatsu
6、I can't forget Michiru



*select06_1|The distance which is not a perfect lover
[jump storage="ep006.ks" target="*select06_1"]

*select06_2|The distance that is not a perfect lover
[jump storage="ep007.ks" target="*select06_2"]

*select06_3|The distance that is not a perfect lover
[jump storage="ep008.ks" target="*select06_3"]





