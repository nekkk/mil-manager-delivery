

*start

;###################################################################
*Ep009|What will you use that body to change?
;###################################################################


[SCENE id=9]

[window target=false]


[BG f="black.ui"  time=1000]
[WAIT time=100]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]

[stflag Jumpflg = 0]


[if exp={getFlagValue("Jumpflg") == 0 }]
[stflag Cha1flg = 1]
[stflag Cha2flg = 1]
[stflag Cha3flg = 0]
[stflag Cha4flg = 0]
[stflag Cha5flg = 0]

[stflag Gameflg = 0]

[stflag Jumpflg = 1]
[endif]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="06"]
;//【ＢＧ】『平原』（昼）******************************************************


[OnName num="renzi"]
Dazzling ......"
[cpg cn=true]


I'll mutter to myself, but I'm just happy to be able to talk to myself as a human being.
[cpg]


It's been a long time since I was dressed as a human. With a somewhat buoyant feeling, I set out for the human town.
[cpg]



[SE f=se020]
;//【ＳＥ】『草原歩く』

[window target=false]

[BG f="b_09_3.ui" time=1000]
[WAIT time=1500]

[window target=true]
;//【ＢＧ】『平原』（夕方）******************************************************





It's not that I lack confidence in my physical strength. I exercise as much as anyone else.
[cpg]


But I wondered if my body would be able to survive in this world after my reincarnation.
[cpg]


In fact, I had no trouble walking, but there was still a subtle sense of discomfort.
[cpg]


After all, that's probably because I used to be a demon.
[cpg]


The sun was setting in no time. I heard that the town is located in a place that cannot be reached in a day, so I walked patiently.
[cpg]


[SE f=se020]
;//【ＳＥ】『草原歩く』


[window target=false]

[BG f="b_09_4.ui" time=1000]
[WAIT time=1500]

[window target=true]
;//【ＢＧ】『平原』（夜）******************************************************





The only things we had to carry were money and food. We did not bring anything for camping.
[cpg]


There was a village of ogres between the dungeon and the human town.
[cpg]


The ogres were more like demons than humans, and according to Janice, they were not to be mistreated.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『鬼の集落』（夜）******************************************************





[OnName num="renzi"]
“It’s here...”
[cpg cn=true]


I am on the edge of food. I have to stop here to save money...
[cpg]


Still, it looks kind of like old Japan.
[cpg]


It's more relaxing than being in a dungeon. I guess it is important to have a certain amount of sunlight.
[cpg]


[OnName num="demon_A"]
Wait a minute. Who are you?
[cpg cn=true]


Two ogres stood at the entrance of the village. They were gatekeepers.
[cpg]



[OnName num="demon_B"]
What do you humans want? We cannot allow you to enter.
[cpg cn=true]


[OnName num="renzi"]
No, I'm a demon. I'm a shapeshifter, and I'm a ......."
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_01_1 ***********************
;//カットイン
[CUTIN f="ci_01_1.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


I decided to untransform and reveal my first serpentine form.
[cpg]


[CUTIN f="ci_01_1.ui" show={false} method="slideout"]
[WAIT time=1000]

The ogres looked a little surprised, but then became rather relieved.
[cpg]


I guess that was because I was able to prove that I was not human.
[cpg]


[OnName num="demon_A"]
I said to them, "You're a ...... demon tribe. You should not quarrel with humans as much as you do with me."
[cpg cn=true]


That's not a story I'm involved in about that. But ...
[cpg]


[OnName num="renzi"]
"Yeah..."
[cpg cn=true]


What an appropriate reply, I decided to be let into the settlement.
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]




I revert back to my human form once more. This form was calmer than the demon form.
[cpg]


By the way, Janice said she wouldn't be rude to me, but I didn't feel very welcome.
[cpg]


Perhaps they'll let me stay, but I have a feeling they'll let me stay. ......
[cpg]


[OnName num="renzi"]
“Excuse me..."
[cpg cn=true]


I call out from in front of the house. It is night, but not yet midnight.
[cpg]


If ogres live in this house, I would think they would be awake, but there was no answer.
[cpg]


I went from house to house. It was just like old Japan, where they were very strict about strangers.
[cpg]


Sometimes the door was opened just a little and then closed.
[cpg]


I was almost discouraged, but I still went around the houses and found ......
[cpg]

[SE f=se009]
;//【ＳＥ】『歩く』

[window target=true]
[WAIT time=100]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
;//【ＢＧ】『鬼の集落』（夜）******************************************************


;//暫く、サツキの名前欄を「鬼の娘」と隠してください


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Satuki001"]
[OnName num="demon_girl"]
"Who are you...? You look human. How did you get in here?"
[cpg cn=true]


Oh, oh ...... right, that's why no one would let me in.
[cpg]


If they were human, they shouldn't have been allowed in the village in the first place.
[cpg]


[OnName num="renzi"]
“I'm a demon. I can just turn into a human... Shall I demonstrate?"
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


[FACE method="change_5" pos="2/3"]

I showed myself as a goblin, and the ogre was amazed.
[cpg]



[VOICE f="Satuki002"]
[OnName num="demon_girl"]
I was surprised to see such a demon. I've never seen anything like it.
[cpg cn=true]


[OnName num="renzi"]
I don't really know if there are demons like this either.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Satuki003"]
[OnName num="demon_girl"]
What do you mean?"
[cpg cn=true]


[OnName num="renzi"]
I'm new to this world. I know you won't believe me."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki004"]
[OnName num="demon_girl"]
I wonder if you could tell me more about .......
[cpg cn=true]


It's kind of like they're interested in you. Good, I was afraid I wouldn't be allowed in any of the houses.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************



[SE f=se021]
;//【ＳＥ】『扉開く』



;//ここからサツキの名前欄を隠さないでください




[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki005"]
[OnName num="satsuki"]
I'm sorry it took me so long to introduce myself. My name is Satsuki.
[cpg cn=true]


[OnName num="renzi"]
I'm sorry. My name is Renji."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Satuki006"]
[OnName num="satsuki"]
I can't offer you any hospitality, but I can at least let you stay the night. Are you hungry?"
[cpg cn=true]


[OnName num="renzi"]
I am, but I don't know if ...... is a good idea.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Satuki007"]
[OnName num="satsuki"]
I guess so. I don't think a normal demon would go this far.
[cpg cn=true]



[window target=true]
[WAIT time=100]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************



With that, Satsuki left the room once.
[cpg]


Then she brought me a meal. I was almost in tears because I thought that perhaps I would be staying in the field today.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Satuki008"]
[OnName num="satsuki"]
She said, "Thanks for your long journey. Here you go."
[cpg cn=true]


[OnName num="renzi"]
Thank you very much. Bon appétit."
[cpg cn=true]



[SE f=se011]
;//【ＳＥ】『食器の音』



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Satuki009"]
[OnName num="satsuki"]
“If you're stopping in this village, you must be heading for the human city...”
[cpg cn=true]


[OnName num="renzi"]
Yeah. I had some business to attend to.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki010"]
[OnName num="satsuki"]
Is he going to use his power to trick the humans?
[cpg cn=true]


[OnName num="renzi"]
No, I really just need to do a little shopping.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Satuki011"]
[OnName num="satsuki"]
I'm at ....... Is that right?　If I had your power, I wouldn't try to use it just for shopping.
[cpg cn=true]


That's for sure. I could end the conflict at will, that's for sure.
[cpg]


But it's also a bit of a burden, to gather information...
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Satuki012"]
[OnName num="satsuki"]
The war between humans and demons has been going on for a long time. You don't know about it, do you?"
[cpg cn=true]


[OnName num="renzi"]
Yes," he said. I'm from a different world than this one.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Satuki013"]
[OnName num="satsuki"]
I don't know how much I believe you, but if it's true, it's a disaster.
[cpg cn=true]


Indeed. But I feel more alive than when I was in the modern world.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki014"]
[OnName num="satsuki"]
If I can change my appearance at will, I can do ...... anything I want.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Satuki015"]
[OnName num="satsuki"]
With your power, perhaps a peaceful, undivided world will come.
[cpg cn=true]


[OnName num="renzi"]
“Do you really think so...?"
[cpg cn=true]


Why are we talking about this? I don't know if it's okay to ask.
[cpg]


[OnName num="renzi"]
You insist on talking about conflict and peace. What's going on?"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Satuki016"]
[OnName num="satsuki"]
...... it is."
[cpg cn=true]


Clouded expression. I don't have to force myself to ask.
[cpg]


[OnName num="renzi"]
'I'm sorry. I didn't mean to pry.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki017"]
[OnName num="satsuki"]
It's okay. I said some thought-provoking things too.'
[cpg cn=true]


There was silence for a while. Then Satsuki spoke.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Satuki018"]
[OnName num="satsuki"]
I'm a human being. I'm in love.
[cpg cn=true]


With that one word, I had a pretty good idea what to expect. Humans are not supposed to be allowed in this village.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki019"]
[OnName num="satsuki"]
In this world of constant conflict, it is difficult for people to be united. I would say it is impossible.
[cpg cn=true]


The Ogre Tribe is also forbidden to head for human villages, and we may never see each other again, it seems.
[cpg]


[OnName num="renzi"]
“It's a tough world..."
[cpg cn=true]


I was dazed, but I knew that a situation of conflict between demons and humans was not good.
[cpg]


Not only Satsuki, there would be all kinds of problems all over the world.
[cpg]


I wonder if we have to make peace or one of the races will completely dominate the world ......
[cpg]


As I was thinking this, Satsuki pushed me further.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Satuki020"]
[OnName num="satsuki"]
What do you think?　What do you want to use your power for?"
[cpg cn=true]


[OnName num="renzi"]
It's ......"
[cpg cn=true]


;//
;//;//■選択肢
;//
;//[switch]
;//[case "人間族との和平の為に使う"]
;//	[swap]
;//	[jump target="*IseSel03_1"]
;//[case "魔族の繁栄の為に使う"]
;//	[swap]
;//	[jump target="*IseSel03_2"]
;//[endswitch]
;//
;//１、人間族との和平の為に使う
;//２、魔族の繁栄の為に使う
;//


;//==============================
;//１、人間族との和平の為に使う
*IseSel03_1|何を変えるためにその身を使うのか




[OnName num="renzi"]
I still want to use it for peace.
[cpg cn=true]


It could be for me, for everyone in the dungeon, or for Satsuki.
[cpg]


[OnName num="renzi"]
I didn't really think about it until now. Thank you for reminding me.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki021"]
[OnName num="satsuki"]
I didn't do anything. I just talked about how I hope peace will come.
[cpg cn=true]


She laughed and was awfully beautiful.
[cpg]


Her beauty was different from that of Dorothy and Asha. She might be a little close to Janice.
[cpg]

[jump target="*IseSel03_3"]

;//==============================
;//;//２、魔族の繁栄の為に使う
;//*IseSel03_2|何を変えるためにその身を使うのか
;//
;//
;//
;//
;//[OnName num="renzi"]
;//「魔族の皆には、恩がありますから。返したいと思います」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_1" pos="2/3"]
;//[VOICE f="Satuki022"]
;//[OnName num="satsuki"]
;//「そう。この戦いを終わらせるのは、貴方かもしれないわね」
;//[cpg cn=true]
;//
;//
;//俺は、あくまで魔族のために力を使いたいと思っていた。
;//[cpg]
;//
;//
;//ドロシーやジャニス、アーシャに対する恩を忘れてはいなかった。
;//[cpg]
;//
;//
;//ダンジョンやそこに住む魔族を守りたい。俺の本心から出た言葉だった。
;//[cpg]
;//
;//
;//[FACE method="change_2" pos="2/3"]
;//[VOICE f="Satuki023"]
;//[OnName num="satsuki"]
;//「きっと、優しい人なのね。なんとなく分かるわ」
;//[cpg cn=true]
;//
;//
;//サツキはそう言って笑った。どきっとする笑顔だった。
;//[cpg]
;//
;//
;//
;//;//※変数+1
;//[stflag Gameflg = 1]
;//
;//
;//
;//;//==============================

*IseSel03_3|何を変えるためにその身を使うのか



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************



I was asked to stay in the parlor, if you can call it that.
[cpg]


It was late at night. She must have been sleeping.
[cpg]


Somehow, there is no sign of anyone but her in this house...
[cpg]


I wonder if he lives alone for some reason.
[cpg]


;//＠シナリオカット用テキスト
;//それにしても、美人だった。俺は彼女のことが気になっていた。
I went to sleep with this in mind. ......
[cpg]


[SE f=se012]
;//【ＳＥ】『衣擦れ』

[OnName num="renzi"]
“Hmm...?”
[cpg cn=true]


As I was sleeping, a cat was coming toward me.
[cpg]


It rubbed up against me and I patted its head while I was sleeping.
[cpg]


But I never thought a cat would come up to a private house like this.
[cpg]


[OnName num="renzi"]
It kind of bothers me."
[cpg cn=true]


I get up and go to look at the front door.
[cpg]


The door was open. I let the cat out and then close it.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





[OnName num="renzi"]
'...... I guess so. ......'
[cpg cn=true]


Cats, cats, huh? I had a little idea.
[cpg]


Tomorrow I would say goodbye to her. I couldn't do anything about it.
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[BG f="white.ui" time=1]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************



[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki024"]
[OnName num="satsuki"]
A shapeshifter, huh? I wonder how far he'll go.
[cpg cn=true]

;**【ＣＧ】ci_14_0 ***********************
;//カットイン
[CUTIN f="ci_14_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


I sneak into her room in the form of a cat.
[cpg]

[CUTIN f="ci_14_0.ui" show={false} method="slideout"]
[WAIT time=1000]


Smells like flowers, like soap. I approach her, thinking it must be the smell of a satsuki.
[cpg]



[FACE method="change_5" pos="2/3"]
[VOICE f="Satuki025"]
[OnName num="satsuki"]
I go to her room and ask, "Is that ......?　How did you get here?
[cpg cn=true]


I take on the form of a cat and pretend to be friendly to her.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki026"]
[OnName num="satsuki"]
No, you can't come into my house without permission.
[cpg cn=true]


She smiles gently and says so. But...
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Satuki027"]
[OnName num="satsuki"]
Kya!"　What?
[cpg cn=true]


I jumped on her body. She is startled and falls down.
[cpg]



;//========================================
;//●ＣＧ（猫に変身した主人公。倒れ込んでいるヒロインに近づく）ev_05
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：無し
;//場所　：和風の室内
;//時間　：夜
;//備考　：主人公は猫に変身しています
;//========================================

;//*Scene010
[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="10"]
;**【ＣＧ】 ev_05_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1500]



[VOICE f="Satuki028"]
[OnName num="satsuki"]
“What’s wrong...with you, so suddenly?"
[cpg cn=true]


Satsuki looks at me in surprise.
[cpg]


She doesn't try to force me off of her. She thinks I am a cat.
[cpg]


I guess that means I can't be too rough with her.
[cpg]

;**【ＣＧ】 ev_05_a ***********************
[CG id=1 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sSatuki001"]
[OnName num="satsuki"]
She says, "Do you want me to ...... care about you anymore?"
[cpg cn=true]

When she caresses me with her hand, I feel like I want to be pampered.
[cpg]


I don't think it's possible that even my heart has turned into a cat, but...
[cpg]


The view in my eyes, or rather the Satsuki in front of me, was unmistakably that of a cat loving Satsuki.
[cpg]

;**【ＣＧ】 ev_05_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sSatuki002"]
[OnName num="satsuki"]
She was a cat loving Satsuki. Now I'm going to bed, I can't leave you alone."
[cpg cn=true]


However..., I feel that no matter how much she spoils me in this appearance, there is no point.
[cpg]


For example, there is no way to see the expression on her face that she would only show to someone she has feelings for.
[cpg]


In that respect, I felt a sense of futility.
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="07"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************




[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Satuki055"]
[OnName num="satsuki"]
Good night. Cat."
[cpg cn=true]

[FO pos="2/3" time=1000]
[SE f=se012]
;//【ＳＥ】『衣擦れ』

With all her desires satisfied, Satsuki seemed to be asleep.
[cpg]


I leave her room and return to the room I was in earlier.
[cpg]



;//ここからしばらく、サツキのセリフ名前欄を「サツキ（蓮司）」と置き換えてください




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="07"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************




But I cannot sleep. My eyes are wide awake, or rather ......
[cpg]


The thought that I might be able to transform into Satsuki makes it even harder to control myself.
[cpg]


She was right next to me, so I would have smelled her, but I don't know.
[cpg]



;////////////////////////
;////////////////////////
;//三度目の変身システム//
;////////////////////////
;////////////////////////


;//選択肢用フラグ
[stflag IseSel04flg = 0]

I'm sure the first smell was something like...
[cpg]


[switch]
[case "vanilla"]
	[swap]
	[jump target="*hen41"]
[case "Fruits"]
	[swap]
	[jump target="*hen41"]
[case "flowers"]
	[swap]
	[stflag IseSel04flg = 1]
	[jump target="*hen41"]
[endswitch]


*hen41|何を変えるためにその身を使うのか


The second smell is...
[cpg]



[switch]
[case "mint"]
	[swap]
	[jump target="*hen42"]
[case "Perfume"]
	[swap]
	[jump target="*hen42"]
[case "soap"]
	[swap]
	[stflag IseSel04flg = 1]
	[jump target="*hen42"]
[endswitch]

*hen42|何を変えるためにその身を使うのか


[window target=true]

[WAIT time=100]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FACE method="out" pos="4/7"]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="04"]


[window target=true]


[if exp={getFlagValue("IseSel04flg") == 2 }]
[jump target="*IseSel04_2"]
[endif]


[jump target="*IseSel04_1"]

;//■選択肢Ａ
1. vanilla
2. fruit
3. flowers

;//■選択肢Ｂ
4. mint
5. Perfume
6. soap





;//==============================
;//３、花　６、石けん　を選んでいた場合
*IseSel04_2|何を変えるためにその身を使うのか



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[FG f="CHA05_p4_01_a.ui" method="change_1"  pos="2/3" time=1]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;//【ＢＧ】『ヒロイン５の家＿室内』（夜）


That's what I thought, but it seems my fears were unfounded. I could turn into Satsuki too.
[cpg]

In this form, I still want to see myself.
[cpg]


But there is no mirror in this room. I had no choice but to observe what I could see from myself.
[cpg]

;//移植前シーンカット


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//ヒロイン５ルートの可能性が残る

[jump target="*IseSel04_3"]



;//==============================
;//３、花　６、石けん　のいずれかを外した場合
*IseSel04_1|何を変えるためにその身を使うのか



I still can't remember for sure. There is no way to transform.
[cpg]


I had no choice, so I went to sleep with a hazy feeling.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//ヒロイン５ルートの可能性がなくなる

[stflag Cha5flg = -1]

;//==============================

*IseSel04_3|何を変えるためにその身を使うのか





[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ヒロイン５の家＿室内』（朝）******************************************************



The next morning. I get up from the futon.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Satuki083"]
[OnName num="satsuki"]
Good morning. I hope you slept well.
[cpg cn=true]


[OnName num="renzi"]
Yes. Thank you.
[cpg cn=true]


Satsuki had even prepared breakfast for me. Why is she doing this for me?
[cpg]


I wonder why she expects so much from me in terms of peace between demons and humans.
[cpg]


After finishing my meal, I looked around the room and said, "I'm sorry.
[cpg]


[OnName num="renzi"]
You are the only one in this house, aren't you?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Satuki084"]
[OnName num="satsuki"]
“Yes. My father and mother both died when I was young.”
[cpg cn=true]


[OnName num="renzi"]
"I see..."
[cpg cn=true]


I wondered if it might have a little something to do with being in love with a human being.
[cpg]


I wonder how long I've been living alone, I wonder how long I've been living alone. I feel like there is something there.
[cpg]


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep010.ks" target="*start"]
