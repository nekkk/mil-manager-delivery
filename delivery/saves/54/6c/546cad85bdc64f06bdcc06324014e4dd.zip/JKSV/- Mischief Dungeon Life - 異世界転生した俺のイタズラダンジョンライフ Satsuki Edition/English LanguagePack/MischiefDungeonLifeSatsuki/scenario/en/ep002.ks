
*start


;###################################################################
*Ep002|The Uses of Transformation
;###################################################################

[SCENE id=2]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]
;//ブラックアウト

[BG f="black.ui"  time=1000]
[WAIT time=100]


[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="05"]


;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[window target=true]


The next day, if it even is the next day, since it's dark in here all the time...
[cpg]


As far as I sensed, another morning came and I headed for the mess hall.
[cpg]


I might have a problem with Asha's appearance, but still, I couldn't eat without a mouth to feed.
[cpg]



[SE f=se009]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************

[window target=true]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="5/3" time=800]
[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/3" time=800]

[SE f=se008]
;//【ＳＥ】『喧噪』

Everyone was surprised when I headed to the mess hall dressed as her.
[cpg]


I felt like I was confusing them unnecessarily, but I had no choice but to stay in this appearance.
[cpg]


[SE f=se009]
;//【ＳＥ】『歩く』

[move from="2/3" to="2/5" ease="easeInOutSine" time=1000]

[move from="5/3" to="4/5" ease="easeInOutSine" time=2000]

[VOICE f="Arsha039"]
[OnName num="asha"]
'Yes, I'll be waiting for you. Eat a lot."
[cpg cn=true]


The real Asha brings my meal to me.
[cpg]


Then she looks at me seriously...
[cpg]


[FACE method="change_7" pos="2/5"]
[VOICE f="Arsha040"]
[OnName num="asha"]
Really, they look so much alike. It's like there's another me."
[cpg cn=true]


I replied, "Thanks," but I don't know if that was the right response.
[cpg]

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

[WAIT time=1000]
[FO pos="2/5" time=1]
[FO pos="4/5" time=1]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

[window target=true]



Then, after we finished eating, Janice came to call me.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Janice008"]
[OnName num="janice"]
“The Demon King wants to see you.”
[cpg cn=true]


She is quite reticent. And yet, she's not a talkative person.
[cpg]


She is wearing armor, so I imagine that she is a warrior.
[cpg]

[SE f=se009]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[BGM f="08"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





[OnName num="rudolf"]
How is she? Have you tried to see what you can turn into since then?
[cpg cn=true]

[FG f="CHA04_p4_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="3/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Arsha041"]
[OnName num="renzi_to_asha"]
Yes, to a certain extent. After all, I can only transform into this body or something inorganic.
[cpg cn=true]


I still don't know what the basic principles are, but some things have become clear.
[cpg]


You cannot transform into a goblin or an orc. You can't turn into Dorothy or Janice either.
[cpg]


[FACE method="change_7" pos="3/3"]
[VOICE f="Dorothy007"]
[OnName num="dorothy"]
Something inorganic?　So I wonder if that means Dullahan or gargoyles would work too."
[cpg cn=true]


[VOICE f="Arsha042"]
[OnName num="renzi_to_asha"]
“I’m not sure...?"
[cpg cn=true]


There is no way to try. It would be impossible to transform into something you have never seen before.
[cpg]


[FACE method="change_1" pos="1/3"]
[VOICE f="Janice009"]
[OnName num="janice"]
Shall I bring him to you?
[cpg cn=true]


[OnName num="rudolf"]
Oh," he said. Please."
[cpg cn=true]




;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="3/3" time=1]
[FO pos="2/3" time=1]
[FO pos="1/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[window target=true]


Then several inorganic demons gathered in the king's room.
[cpg]


[OnName num="dullahan"]
「……」
[cpg cn=true]


[OnName num="gargoyle"]
「……」
[cpg cn=true]


None of them spoke, so I kept quiet, too.
[cpg]


[OnName num="rudolf"]
How's it going? Can you do it?"
[cpg cn=true]


[FG f="CHA04_p4_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha043"]
[OnName num="renzi_to_asha"]
I don't know, but I'll try."
[cpg cn=true]


I wish to transform. Then...
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_03_0 ***********************
;//カットイン
[CUTIN f="ci_03_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]


After all, it was done. I don't know what it is, but it has something in common with the Golem.
[cpg]

[CUTIN f="ci_03_0.ui" show={false} method="feadout"]
[WAIT time=1000]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Dorothy008"]
[OnName num="dorothy"]
It's really amazing. I've never seen such a monster that can transform into anything.
[cpg cn=true]


[OnName num="renzi"]
......"
[cpg cn=true]


I was about to reply, but Dullahan's form still had no mouth.
[cpg]

[FACE method="change_3" pos="2/5"]

[VOICE f="Janice010"]
[OnName num="janice"]
“There must be some kind of principle to this.”
[cpg cn=true]


[OnName num="rudolf"]
'Yes, I suppose so. I don't see how Asha could turn into one simply by being inorganic."
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="4/5" time=1]
[FO pos="2/5" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[window target=true]


I was exempted from standing guard near the dungeon entrance for a while because I was a rare demon.
[cpg]


They said they didn't want anything to happen to me.
[cpg]



;//ここからアーシャのセリフ名前欄を元に戻してください




[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="4/5" time=800]
[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Arsha044"]
[OnName num="asha"]
Ah. It's me.
[cpg cn=true]


I see Asha in a place outside of the mess hall.
[cpg]


Since I looked like Asha, she approached me while saying “Oh. It’s me”.
[cpg]


[FACE method="change_7" pos="4/5"]
[VOICE f="Arsha045"]
[OnName num="asha"]
'Not too much, you can't tell the difference when you're dressed as me.
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

I explained that I was sorry about that, but that I had no other body that could speak though.
[cpg]


[FACE method="change_5" pos="4/5"]
[VOICE f="Arsha046"]
[OnName num="asha"]
'Really ......?　I don't know why. There are some things you just can't transform into."
[cpg cn=true]


[FACE method="change_3" pos="4/5"]
[VOICE f="Arsha047"]
[OnName num="asha"]
I'm not really in the mood for this right now," he said. Hey, come here."
[cpg cn=true]


[FO pos="2/5" time=1000]
[FO pos="4/5" time=1000]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





So she said, and I was taken by her.
[cpg]



[window target=false]

[FACE method="feadin_up" pos="4/7"]


[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="06"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[window target=true]


There, further into the dungeon. It was somehow dimmer and brighter than the other rooms.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA04_p4_01_a.ui" method="change_7"  pos="2/5" time=800]

[VOICE f="Arsha048"]
[OnName num="asha"]
“This is a magic light. It's almost like sunlight..."
[cpg cn=true]


Apparently, they were also using magic to grow vegetables and grains and raise livestock.
[cpg]


I wondered if that was true after all, but then again, magic can be anything.
[cpg]


I guess I could say the same thing about myself.
[cpg]


[OnName num="therianthropy_A"]
"Hey, Asha," he said, "I'm so glad you're here. You came.
[cpg cn=true]


There they were, beastmen of different races. There were several women. They seemed to be taking a breather with their farm equipment.
[cpg]


[FACE method="change_2" pos="4/5"]
[VOICE f="Arsha049"]
[OnName num="asha"]
'I've brought him, the shapeshifter. Explain it to him."
[cpg cn=true]


[OnName num="therianthropy_B"]
“You're the...look-alike?”
[cpg cn=true]


I've been listening to these beasts.
[cpg]


[OnName num="therianthropy_C"]
I mean, it's a bad crop, but can't you do something about it?"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

The power of transformation has nothing to do with agriculture... As I tried to tell them that...
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Arsha050"]
[OnName num="asha"]
He said, "Well, well, well, don't say that. There might be something in it for you.
[cpg cn=true]


Asha responded in that manner. I owe her a debt of gratitude, and I myself would be in trouble if we ran out of food again.
[cpg]


[OnName num="therianthropy_A"]
Maybe we don't have enough water, but water is also a limited resource."
[cpg cn=true]


[OnName num="therianthropy_B"]
“Yes, yes. Undine are also very free-spirited."
[cpg cn=true]


Undine. Is there such a thing? Is it a spirit or something?
[cpg]


[OnName num="therianthropy_C"]
Oh. They can control water at will.
[cpg cn=true]


;//ブラックアウト
[SE f=se009]
;//【ＳＥ】『歩く』

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1000]
[BG f="b_04_5_up.ui" time=1]


So I was on my way with Asha to the spirits called Undine.
[cpg]



[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1500]


[FACE method="change_7" pos="4/5"]

[VOICE f="Arsha051"]
[OnName num="asha"]
How's it going?　Do you think you can turn into one?"
[cpg cn=true]


I answer, "I'll try," and I remind him. If you ask me if it's inorganic, I'm not so sure.
[cpg]


The Undine is quite small and looks more like water itself turned into a humanoid than a living creature.
[cpg]


I don't know if I can imitate its characteristic of floating, but I tried to remind myself of it.
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FO pos="2/5" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_04_0 ***********************
;//カットイン
[CUTIN f="ci_04_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

Then I succeeded in becoming itself and was able to float. But ......
[cpg]

[CUTIN f="ci_04_0.ui" show={false} method="feadout"]

[WAIT time=1000]

[FACE method="change_2" pos="4/5"]
[VOICE f="Arsha052"]
[OnName num="asha"]
I did it!　How, do you think you can control the water?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

Even when I was a golem, I was inefficient and slow to move.
[cpg]


Considering this, there was a possibility that even if I could look like a golem, I might not be able to copy its abilities.
[cpg]


[OnName num="renzi"]
I don't think I can use something like ...... magic."
[cpg cn=true]



Undine seems to have something like vocal cords and can speak.
[cpg]


But at least I couldn't help it if I just thought about it.
[cpg]


If there were some logic behind the manifestation of magic, there was nothing more I could do.
[cpg]


[FACE method="change_4" pos="4/5"]
[VOICE f="Arsha053"]
[OnName num="asha"]
“I see..., you can't copy their power.”
[cpg cn=true]


;//【ＢＧ】『ダンジョン＿通路』（暗い）



Undine's ability to manipulate water would be useful for agriculture. It would be best if we could enlist the help of the undine itself.
[cpg]


However, the dungeon-dwelling undine are said to have a carefree personality and cannot be handled well.
[cpg]


[OnName num="therianthropy_A"]
“I'm worried. If the crops continues to fail, we'll be in trouble..."
[cpg cn=true]


[FACE method="change_4" pos="4/5"]
[VOICE f="Arsha054"]
[OnName num="asha"]
Yeah. ...... When we run out of food, we'll just have to loot the humans."
[cpg cn=true]


It would be called an invasion. I can imagine that they would not have done so before.
[cpg]


As for me, I want to live in peace, so I've got my wits about me.
[cpg]


No, wait...
[cpg]


[OnName num="renzi"]
“Hey, is there a demon called Mandragora?”
[cpg cn=true]


[OnName num="therianthropy_C"]
There is. Though that one has an unrestrained personality, too.
[cpg cn=true]


[OnName num="renzi"]
I'd like to copy that. Will you take me there?"
[cpg cn=true]


So I decided to ask Asha to help me once again.
[cpg]


She guides me to the location of the mandragora.
[cpg]


[window target=false]


[SE f=se009]
;//【ＳＥ】『歩く』

[STOPBGM]

[FO pos="4/5" time=1000]

[BG f="black.ui"  time=1000]
[WAIT time=2000]
;//ブラックアウト



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[BG f="black.ui"  time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="06"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************

[window target=true]


;**【ＣＧ】ci_05_0 ***********************
;//カットイン
[CUTIN f="ci_05_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

I was able to copy the mandragora's appearance as well.
[cpg]


It seems that I can copy more than just inorganic objects. Aside from that...
[cpg]

[CUTIN f="ci_05_0.ui" show={false} method="slideout"]
[WAIT time=1000]



[OnName num="renzi"]
'Try burying me in the dirt,' he said. Maybe you can figure out something from a plant's perspective."
[cpg cn=true]


I was able to talk. The mandragora is a mysterious creature.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha055"]
[OnName num="asha"]
'Yeah. ...... I don't know if I'm allowed to do that.'
[cpg cn=true]



[SE f=se003]
;//【ＳＥ】『スコップで穴を掘る』

[WAIT time=2000]


[SE f=se003]
;//【ＳＥ】『スコップで穴を掘る』


I don't know if that's such a good idea, either.
[cpg]


But I want to do something useful. The feeling was unmistakable.
[cpg]



And when I was buried, I began to understand the feeling of ...... soil.
[cpg]


By feel, I don't mean just the sense of touch, but the nutrients in the soil.
[cpg]


[OnName num="renzi"]
I feel like there is not enough alkali. You should sprinkle some lime or something on it.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Arsha056"]
[OnName num="asha"]
What do you mean ......?　What's lime?"
[cpg cn=true]


[OnName num="renzi"]
I don't know how to say it, the soil is acidic.
[cpg cn=true]


Anyway, now that I knew the nature of the soil, I asked them to dig it up again.
[cpg]


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FG f="CHA04_p4_01_a.ui" method="change_3"  pos="2/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="4/5" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

Once more I transformed into Asha's form. Then he went on to talk to the beasts in detail.
[cpg]



[OnName num="therianthropy_A"]
“Understood..., I guess that's how the situation is.”
[cpg cn=true]


At least the concept of acidity and alkalinity seemed to exist in this world.
[cpg]


[OnName num="therianthropy_B"]
Once we know that, we have to do something about it.
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FACE method="out" pos="4/7"]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[window target=true]

[SE f=se009]
;//【ＳＥ】『歩く』

I never thought I'd become a plant, either.
[cpg]


I was grateful to Asha and the beasts in charge of cultivation for my unexpected ability.
[cpg]


I guess I can be useful in this place even if I don't fight...
[cpg]

[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Arsha057"]
[OnName num="asha"]
“Thank you! I kind of have a feeling that it's going to work out."
[cpg cn=true]


Asha takes my hand and smiles at me.
[cpg]


I could smell that scent, the same as when I first met her.
[cpg]

[window target=false]


[FO pos="2/5" time=1000]
[FO pos="4/5" time=1000]

[BG f="black.ui"  time=1000]
[WAIT time=1500]

[STOPBGM]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************

[window target=true]

I don't feel bad about being thanked by people. Until now, I had done almost nothing but eat for them.
[cpg]

;**【ＣＧ】ci_07_0 ***********************
;//カットイン
[CUTIN f="ci_07_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

Since then, I have been trying to transform myself in various ways. For example, I was able to transform into a slime, although it doesn't seem to be inorganic.
[cpg]



I was also able to take on a humanoid-like appearance, so I'm thinking I'll be staying in this outfit for the foreseeable future. ......
[cpg]

[CUTIN f="ci_07_0.ui" show={false} method="slideout"]
[WAIT time=1000]

[SE f=se009]
;//【ＳＥ】『歩く』

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]

[WAIT time=2000]


[VOICE f="Janice011"]
[OnName num="janice"]
Renji."
[cpg cn=true]


[OnName num="renzi"]
“What is it...?"
[cpg cn=true]



I reply, dressed as a humanoid slime.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Janice012"]
[OnName num="janice"]
I hear you're active."
[cpg cn=true]


[OnName num="renzi"]
“Yes, well.., I hope so."
[cpg cn=true]


I could somewhat hoard with Asha, but I couldn't do that with Janice or Dorothy.
[cpg]


Janice is a little scared of Janice herself, and Dorothy is a little scared of her dad.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Janice013"]
[OnName num="janice"]
“The Demon King wants to see you. Follow me."
[cpg cn=true]


She continues to look as grim as ever.
[cpg]


Has she forgiven me to some extent, or has she become a little softer ......?
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************


[window target=true]


[OnName num="rudolf"]
How have you been since then? Have you gotten used to living in this world?"
[cpg cn=true]


[OnName num="renzi"]
“Yes, well... I'm not so much used to this body as I am to this world.”
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Dorothy009"]
[OnName num="dorothy"]
I guess so. If I could transform myself, I wouldn't be able to stay calm either.
[cpg cn=true]


Both the Demon King and his daughter, Dorothy, understood my feelings to some extent.
[cpg]


[OnName num="rudolf"]
Only you can be sure of your power," he said. Let me know if you learn anything new."
[cpg cn=true]


[OnName num="renzi"]
“Yes..."
[cpg cn=true]


I had been trying to transform into another creature, or rather another form, since then.
[cpg]


[OnName num="renzi"]
I can only transform into something inorganic-like. I could turn into a slime.
[cpg cn=true]


For example, when I transformed into Undine, I could float, but I could not control water.
[cpg]


I guess that's just basic for me. It's not a universal transformative ability.
[cpg]


[OnName num="renzi"]
“Like with the mandragora, he can mimic its ecology to some extent."
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Dorothy010"]
[OnName num="dorothy"]
Heh. I wonder if that means he's perfect at mimicry, but weak in a fight.
[cpg cn=true]


[OnName num="renzi"]
That's pretty much it.
[cpg cn=true]


I would probably be very weak in a fight. If I were to fight for the demon tribe, I should just go scouting for information like the Demon King said.
[cpg]


[OnName num="rudolf"]
I guess I need to do more research on how limited they are in what they can transform into."
[cpg cn=true]


[OnName num="rudolf"]
One way or another, you may turn out to be a trickster. I have high hopes for you."
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[window target=true]


[OnName num="renzi"]
“Dorothy..., was quite adorable."
[cpg cn=true]


Leaving the King's Chamber, I can't help but talk to myself.
[cpg]


She's not the only one. Even Janice is more than a pretty ......, she's a beautiful person.
[cpg]


I want to do something for her. If I were a trickster for the demon tribe.
[cpg]


I can't help thinking that I should at least get something in return for it.
[cpg]



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="ep003.ks" target="*start"]
