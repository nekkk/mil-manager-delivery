

*start


;#################################################
*Ep008|Mastering the Art of Magic
;#################################################


*select_first_masic|Magic at its Finest


[SCENE id=8]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（朝）******************************************************


The next morning. We decided to go out to exterminate demons.
[cpg]


The Great Forest of Acecto has always been damaged by demons.
[cpg]


It is said that slime-like creatures are occurring again.
[cpg]


[OnName num="itsuki"]
My power up to now may not be enough. ......
[cpg cn=true]


Ariel nods at me. I decided to be prepared, just in case.
[cpg]


I had obtained the "Magic II" skill.
[cpg]


It would be a purely higher level of Magic. I could imagine.
[cpg]


I could have taken this one from the start. Any skill is at your disposal. But ......
[cpg]


When I got that skill, it came with a skill called "Complacency".
[cpg]


[OnName num="itsuki"]
What is this ......?"
[cpg cn=true]


Most skills can be used by thinking about them, but this one is ......
[cpg]


What does it mean?　Can you use it by trying to use it?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
;//[t_move pos=C ゆらゆら]
[VOICE f="Ariel124"]
[OnName num="ariel"]
"I've never seen this skill before. ...... what is it?"
[cpg cn=true]


[OnName num="itsuki"]
"...... Well, any skill that can't be used is good. You got Magic II, that's all you need."
[cpg cn=true]


Abram nodded. And.
[cpg]


[OnName num="abram"]
I'm going to help you, my hero. I'll help you.
[cpg cn=true]


We are united. We're going into battle.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel125"]
[OnName num="ariel"]
"Let's go. Let's take back our forest. ......
[cpg cn=true]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_fi"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


My magic was impossible.
[cpg]


Magic is supposed to attack with fire and lightning.
[cpg]


But it no longer felt like killing something with magic.
[cpg]


It has gone beyond the concept of magic and become a mere attack.
[cpg]


It seemed to have jumped over the process of attacking.
[cpg]


Whatever I perceived as an enemy was being destroyed from one side to the other. I am being killed, not killed.
[cpg]


[OnName num="abram"]
'Amazing ...... this isn't normal .......'
[cpg cn=true]


I was afraid of my own power, but I defeated them.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Ariel126"]
[OnName num="ariel"]
'I really ...... can't stop staring at it.'
[cpg cn=true]


I used attack magic as I took in those words.
[cpg]


[OnName num="itsuki"]
"...... is it okay to use such strong magic,......?"
[cpg cn=true]


There is a price to pay. I was afraid to use it, but I couldn't not use it.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ariel127"]
[OnName num="ariel"]
The first thing that comes to mind is the fact that the "magic" is so powerful that it can be used for a lot of purposes. Let's keep going at this rate.
[cpg cn=true]


The slimes were quickly eradicated.
[cpg]


As I watched, I felt strangely uneasy.
[cpg]


No, I think it's good that things are going well. But then, ......
[cpg]


I still had a feeling that it might be going too well.　I still had the feeling that it was going too well.
[cpg]


I wonder if it's any use thinking about it now.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夕方）******************************************************


By the time evening came, most of the demons had been defeated. Now, there won't be an increase in them all at once. ......
[cpg]


We'll be safe for a while. Both Ariel and I were relieved to know that.
[cpg]


And the elves were having a joyous feast. I'm the star of the show.
[cpg]


Abram is talking to me.
[cpg]


[OnName num="abram"]
It was amazing. It was a magic that I could not believe my eyes.
[cpg cn=true]


He says something like that to me.
[cpg]


[OnName num="itsuki"]
I'm not a genius myself, you know.
[cpg cn=true]


[OnName num="abram"]
He says to me, "No, it's not. If it's natural, it's a gift.
[cpg cn=true]


[OnName num="itsuki"]
I don't know if it is,......."
[cpg cn=true]


Abram was a rather friendly guy.
[cpg]


In other words, he was easy-going, and I was oddly comfortable with him.
[cpg]


I thought I could work with him to restore this forest.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
I was a little concerned about his relationship with Ariel, though.
[cpg]


[OnName num="itsuki"]
I thought, "Even Abram was pretty active.
[cpg cn=true]


[OnName num="abram"]
No way!　I was there with or without him.
[cpg cn=true]


[OnName num="itsuki"]
That's modesty.
[cpg cn=true]


[OnName num="abram"]
No, no, no, no, you're the one who's ......
[cpg cn=true]


As we were saying these things to each other, Ariel spoke to me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ariel128"]
[OnName num="ariel"]
'Really, I don't know what to say,...... I can't thank you enough, Tree-sama.
[cpg cn=true]


[OnName num="itsuki"]
I'm so glad to hear you say that, it makes all the work I did worth it.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel129"]
[OnName num="ariel"]
I will follow you for the rest of my life. I promise."
[cpg cn=true]


I didn't feel bad. The first thing to do is to make sure that you have a good relationship with Ariel.
[cpg]


What kind of relationship would I have with Ariel?
[cpg]


I was somewhat aware of these feelings.
[cpg]


Knowing that no one knows if it's okay to continue like this or not,......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************

;//上下に黒帯を入れてください



[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel130"]
[OnName num="ariel"]
Oh, um, ...... tree-sama."
[cpg cn=true]


And then night falls. Ariel came again to the hut where I was sleeping.
[cpg]


[OnName num="itsuki"]
'...... you're here again, Ariel?'
[cpg cn=true]


Ariel nodded. I scratched my head.
[cpg]


[OnName num="itsuki"]
This is no night crawl, is it ......?
[cpg cn=true]


Ariel blushed faintly. And then she said, "No, don't tell me.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Ariel131"]
[OnName num="ariel"]
No, please don't say that," she said. I don't want you to say such a dirty thing.
[cpg cn=true]


Even if she said that, it wouldn't make much difference if she did or didn't. Ariel is a pretty horny type of girl.
[cpg]


Ariel is a very horny type, I guess.
[cpg]


In any case, I wasn't going to refuse her if she came on to me.
[cpg]


[OnName num="itsuki"]
So ...... what is it that you want?"
[cpg cn=true]


I dared to ask something that I knew was obvious.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel132"]
[OnName num="ariel"]
I'm ...... curious about you, Itsuki.
[cpg cn=true]


I know. I think that's what he's talking about.
[cpg]


Ariel approached me like that, and I responded and ...... put my lips to hers.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//移植のためシーンをカットしています

But for some reason, Ariel looked unfulfilled.
[cpg]

;//[FACE method="change_4" pos="2/3"]
[VOICE f="Ariel133"]
[OnName num="ariel"]
'I don't know why,...... I feel kind of frustrated.
[cpg cn=true]


[OnName num="itsuki"]
I don't know why. ......"
[cpg cn=true]


Even if I want more than this, I'm on my way to defeating the evil god.
[cpg]

So, I can't afford to go the extra mile.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（朝）******************************************************


Things are slowly changing.
[cpg]


The Great Forest of Acecto was returning to normal. That means ...... I have the next mission.
[cpg]


[OnName num="itsuki"]
Well,...... it's time for me to go back to the underground city."
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
Ariel looks a little dejected as she says, "I see.
[cpg]


Why does he look depressed? Not knowing why, I ask.
[cpg]


[OnName num="itsuki"]
What's wrong?　Ariel is going too, right?
[cpg cn=true]


Ariel shakes her head. Is there any reason why I should stay?
[cpg]


[OnName num="itsuki"]
Can't you go with me ......?　Why?"
[cpg cn=true]


She replies to my words with a dejected look on her face.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel134"]
[OnName num="ariel"]
'...... I can't. I have to give orders for the recovery and my position ...... doesn't allow me to leave here."
[cpg cn=true]


I see. I'm sure you do. ...... I'm sure you also want to protect your hometown.
[cpg]


I thought so, and this time I spoke to Abram.
[cpg]


[OnName num="itsuki"]
"Is that so,...... Abram?"
[cpg cn=true]


[OnName num="abram"]
What?　Are you talking about me taking over for you?
[cpg cn=true]


[OnName num="abram"]
'You miss Ariel that much,...... well, I can't say I don't understand.
[cpg cn=true]


I'm sure he's mistaken about something. I shook my head.
[cpg]


[OnName num="itsuki"]
No, no, no. I meant to say, "Take care of Ariel.
[cpg cn=true]


[OnName num="itsuki"]
You don't want anything to happen to me. If there are demons or something, please.
[cpg cn=true]


Abram looked a little surprised.
[cpg]


[OnName num="abram"]
He looked a little surprised. Me and Ariel go way back.
[cpg cn=true]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


And I'm off on my own.
[cpg]


[OnName num="itsuki"]
I'm off to the Underground City then.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel135"]
[OnName num="ariel"]
"Well, Itsuki, take care of ...... yourself."
[cpg cn=true]


[OnName num="itsuki"]
"Oh. Don't worry so much.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel136"]
[OnName num="ariel"]
I'm sorry to leave you, but ...... I'm going to stay here.
[cpg cn=true]


After that conversation, we separated.
[cpg]

;//////////////////////
;//ヒロイン1に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************

;//上下に黒帯を入れてください



[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

My body was going crazy. I think I was lonely to begin with.
[cpg]

There is also the fact that I don't have a tree-sama. I have no one to satisfy my feelings.
[cpg]


That's true, of course, but ......
[cpg]


This time is especially strange. It's as if there is some invisible force at work.
[cpg]


If you ask me what force is at work, I am at a loss to answer.
[cpg]


But I felt something other than my will was at work.
[cpg]


It was as if ...... someone's skills were at work.
[cpg]


Then Abram came to my room.
[cpg]


[OnName num="abram"]
'Ariel,...... now, okay?'
[cpg cn=true]


Abram looked mysterious.
[cpg]


It didn't sound like a good topic. I braced myself.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel137"]
[OnName num="ariel"]
What ......?　What's wrong?
[cpg cn=true]


[OnName num="abram"]
I heard it from the other elves. I heard from the other elves about the relationship between you and the brave ......."
[cpg cn=true]


I was startled. I was so shocked. Love between an elf and a human is forbidden.
[cpg]


Who saw me? That was my first concern.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
;//[t_move pos=C 動揺]
[VOICE f="Ariel138"]
[OnName num="ariel"]
I was so shocked that I asked myself, "Who saw you ......?　Who told you?"
[cpg cn=true]


I said it, but then I thought, "Oh no.
[cpg]


[OnName num="abram"]
'If you say so, then it must be true .......'
[cpg cn=true]


It was like I had just confessed myself.
[cpg]


Abram goes on to tell me, "You know.
[cpg]


[OnName num="abram"]
You know. Elves have to marry elves."
[cpg cn=true]


I can't argue with that. He's right.
[cpg]


[OnName num="abram"]
Ariel should know better than that. She's in a position to lead in the reconstruction.
[cpg cn=true]


Even if I'm good, I'll be ostracized by my own people. No, it's not enough to be ostracized.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel139"]
[OnName num="ariel"]
"Well, that's ...... but I'm going to ...... about Tree-sama.
[cpg cn=true]


If I were to have a child with Tree-sama, I would be treated as a heretic.
[cpg]


But still. I'm not going to give up.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel140"]
[OnName num="ariel"]
I love you, Tree-sama. There is nothing I can do about it.
[cpg cn=true]


Abram nodded. I knew he understood that.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[VOICE f="Ariel141"]
[OnName num="ariel"]
'...... hey ......!'
[cpg cn=true]


;//========================================
;//●ＣＧ（後ろから抱きつかれるヒロイン）ev_43
;//人物１：ヒロイン１
;//服装１：着衣（はだけ）
;//人物２：エルフの男・親友ポジション
;//服装２：着衣
;//場所　：
;//時間　：
;//========================================

[BGM f="bg_h1"]
;**【ＣＧ】 ev_43_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]

He hugged me as I turned away.
[cpg]

[OnName num="abram"]
'But ...... I can't give up.'
[cpg cn=true]


Abram makes a proposal. He was a man who had been in the business for a long time.
[cpg]


[OnName num="abram"]
I'm not going to give up on you," he said. If you have a child with a brave man, I'll tell him it's mine and I'll cover for you.
[cpg cn=true]


That's ...... a wish come true. But ......
[cpg]


[VOICE f="Ariel142"]
[OnName num="ariel"]
I think it's a ...... good idea, but I still can't do it.
[cpg cn=true]


Abram's expression changed a little. He looks like he's in dire straits.
[cpg]


[OnName num="abram"]
Don't say that."
[cpg cn=true]


The first thing you need to do is to get a good idea of what you are going to do. I felt that way.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（朝）******************************************************


The situation in the forest has also calmed down. There would be no more demons.
[cpg]


And the reconstruction had reached a certain stage.
[cpg]


It would be fine without me from here on. That's why I decided to go after Itsuki.
[cpg]


I was a little worried that Abram would be with me,......, but I couldn't reject the idea.
[cpg]


It's everyone's consensus. The most important thing to remember is that you need someone to keep an eye on the relationship between you and the tree.
[cpg]


They suspect me,......, and there's nothing I can do about it.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


I headed over with Abram. There was little conversation.
[cpg]


[OnName num="abram"]
He'd say, "...... I'm not giving up on you."
[cpg cn=true]


He would say things like that, but I couldn't answer him.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『地下都市』（夕方）******************************************************


Then, I met up with ...... Itsuki, who reaches the underground city.
[cpg]

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（夕方）******************************************************


I had gained the 《魔術 II》 skill in the defense of the underground city.
[cpg]


Probably a higher level skill of 《魔術》. My magic became even more powerful.
[cpg]


Then, a skill that I had never seen before and did not know what it did came along with it.
[cpg]

I knew there was something strange about this skill. I don't know why.
[cpg]

I thought it was eerie, but I couldn't do anything about it. It was in this situation that I met Ariel again.
[cpg]


[OnName num="itsuki"]
"Ariel, ......!　You came."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ariel143"]
[OnName num="ariel"]
"Tree-sama ......, I've been wanting to see you for a long time, ah ......."
[cpg cn=true]


Ariel even almost spills a tear and hugs me.
[cpg]


[OnName num="itsuki"]
"Oh ......, me too."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel144"]
[OnName num="ariel"]
'I'm so happy to see you,...... I kind of feel like I'm going to cry.
[cpg cn=true]


[OnName num="itsuki"]
'You can cry, Ariel.'
[cpg cn=true]


I return it gently. But .......
[cpg]


[free time=1000]

My skills are strange. There are a number of skills that are unidentified at this point.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Littule077"]
[OnName num="littule"]
They're hot, aren't they?
[cpg cn=true]


Ritul is chilling. I wonder if our relationship will go as smoothly as Ritul says.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Mercurio043"]
[OnName num="mercurio"]
"...... yes, but the Itsuki-san looks unflattering. ......"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Littule078"]
[OnName num="littule"]
"Oh, yeah?　Well, come to think of it."
[cpg cn=true]


[FG f="CHA06_p1_02_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Mercurio044"]
[OnName num="mercurio"]
I'm wondering what's going on,.......
[cpg cn=true]


[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（夜）******************************************************

;//上下に黒帯を入れてください



That night, I was with Ariel again.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel145"]
[OnName num="ariel"]
'......I wonder why. I always wanted to be with you.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Ariel146"]
[OnName num="ariel"]
"I feel that way,...... as if being with you is rather unfulfilling."
[cpg cn=true]


She said something as if she was in a hurry.
[cpg]

I, on the other hand, wanted to take care of her and couldn't do anything more.
[cpg]


;//////////////////////
;//ヒロイン1に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（昼）******************************************************

Several days and nights passed.
[cpg]

[window target=false]
[BG f="b_08_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『地下都市』（夜）******************************************************

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1100]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

[OnName num="abram"]
I'm going to go into Ariel......."
[cpg cn=true]


He might be able to fulfill it.
[cpg]


I couldn't help but have that expectation. I felt sorry for Itsuki.
[cpg]


My loneliness was unstoppable, and I couldn't refuse Abram who was forcibly approaching me. ......
[cpg]


[OnName num="abram"]
......Ariel. You're really lonely."
[cpg cn=true]


Abram is trying to hit the bull's-eye. I'm lost.
[cpg]


Once you make a mistake, you may have to cheat from there.
[cpg]


I was lost. I was lost, and I said to myself, "I'm not going to go to .
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel147"]
[OnName num="ariel"]
"......No, it's still no good. ......"
[cpg cn=true]


After all, I could not say anything definite.
[cpg]


[OnName num="abram"]
"What are you confused about? Isn't this to protect the elven code ...... to fool everyone's eyes?"
[cpg cn=true]


Abram is always trying to be convenient.
[cpg]


But it was also convenient for me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel148"]
[OnName num="ariel"]
I'm sure that's true,......, but it's also convenient for me.
[cpg cn=true]


;//ブラックアウト

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


;//ブラックアウト

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（朝）******************************************************


The battle in the underground city is over. Now we are safe here.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
The battle in the underground city was over.
[cpg]


The people in that forest need her, after all.
[cpg]


[OnName num="itsuki"]
I see. ...... I'm going to miss her a little bit.
[cpg cn=true]


I said and tried to stall her a little.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
;//[t_move pos=C 溜息]
[VOICE f="Ariel149"]
[OnName num="ariel"]
I'm fine. I'm fine by myself.
[cpg cn=true]


Ariel says so. I wonder if she really thinks so.
[cpg]


I wonder if she's forcing herself to smile. I'm sure she misses me, too. ......
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


I care about Ariel. But we couldn't stop.
[cpg]


We have to defeat the evil god. And to do that, we need more friends.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Littule079"]
[OnName num="littule"]
Then, let's go defeat the evil god. Let's go, guys!
[cpg cn=true]


Ritul says so, but not suddenly. ......
[cpg]


[OnName num="itsuki"]
"It's just me, Mercurio, and Ritul. ......
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
;//[t_move pos=C ゆらゆら]
[VOICE f="Littule080"]
[OnName num="littule"]
Don't interrupt me.
[cpg cn=true]


I'm just telling the truth rather than watering it down.
[cpg]


Whatever the case, we have to go look for Charlotte and Hermia.
[cpg]

[free time=1000]

[OnName num="itsuki"]
Well, I have to go and convince the rest of the members. I'm off.
[cpg cn=true]


So this is where we, Ariel, and Abram part ways.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel150"]
[OnName num="ariel"]
Well, I'm going to go now and pray for the safety of the ...... tree.
[cpg cn=true]


[OnName num="abram"]
Be well. Be well, my hero.
[cpg cn=true]


[OnName num="itsuki"]
"Yeah. Abram, take care of yourself.
[cpg cn=true]


With these words, we parted.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel151"]
[OnName num="ariel"]
"Take care of yourself, ......."
[cpg cn=true]


;//ブラックアウト

;//////////////////////
;//ヒロイン1に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（朝）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
After that, our forest was getting back to normal.
[cpg]


It was a joy. The land, now without trees, will soon be restored to its original state.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
I was happy to hear that,......, but I was still thinking about the tree.
[cpg]


The first thing that comes to my mind is that it is impossible for me to be married to the tree. That's what I think.
[cpg]


I sighed and thought about him.
[cpg]


In the midst of all this, I received an unexpected visitor.
[cpg]

[free time=800]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/2" time=800]

[VOICE f="Elmyr069"]
[OnName num="elmyr"]
It's been a long time. Ariel, you don't look ...... well."
[cpg cn=true]


Hermia. How did she end up here ......?
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
I was too stunned to respond immediately.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Elmyr070"]
[OnName num="elmyr"]
You're still in love with the tree, aren't you?
[cpg cn=true]


Hermia was very open about my situation.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Ariel152"]
[OnName num="ariel"]
I was so busy with my own business that I had to leave the room.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Elmyr071"]
[OnName num="elmyr"]
I've been busy with various things."
[cpg cn=true]


I answer my question in a slightly stunned manner.
[cpg]


I asked him, wondering what there was to be aghast about.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Elmyr072"]
[OnName num="elmyr"]
Elves are supposed to bond with other elves. Are you trying to break the code?"
[cpg cn=true]


Oh, that or ...... about it.
[cpg]


I can't respond. I can't respond.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Elmyr073"]
[OnName num="elmyr"]
You may be good for one person, but what about the child?
[cpg cn=true]


Yes, I know. I may be fine, but the child will never be happy.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


After that, Hermia and the other elves lectured me again and again.
[cpg]


The elves are supposed to be united with other elves.
[cpg]


Anything out of the ...... norm is considered heresy.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************


After that, the tree-sama would come to check on our forest from time to time.
[cpg]


He is concerned about this forest that I have restored to its original state.
[cpg]


[OnName num="itsuki"]
Things seem to be going well."
[cpg cn=true]


I nodded. Then Ritul said to me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Littule081"]
[OnName num="littule"]
'Yeah. It's all thanks to the trees.
[cpg cn=true]


There was a face there that I hadn't seen before.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Charlotte020"]
[OnName num="charlotte"]
'......That's true. It's like we were divided just a few minutes ago.
[cpg cn=true]


Charlotte had returned. The most important thing to remember is that the most important thing is that you have to be able to see the world.
[cpg]


[OnName num="itsuki"]
'Why don't you come along too Ariel?　After all, can't you ......?"
[cpg cn=true]


I couldn't reply. I just shut up.
[cpg]


I was the only one who could not follow him.
[cpg]


I want to follow you too, Tree-sama, but I couldn't ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************

;//上下に黒帯を入れてください



[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

I couldn't make up my mind. I can't be with Master Trees no matter how I try.
[cpg]


What should I do? The more I think about it, the more I don't have an answer.
[cpg]


Still, I think about it. While sitting still in my room ......
[cpg]


At that time, I had a visitor. I was startled.
[cpg]


[OnName num="elf_man_A"]
"Dear Ariel, are you still thinking about it? Are you still thinking about it?
[cpg cn=true]


A man came in without knocking. There were two of them.
[cpg]


[OnName num="elf_man_B"]
I thought to myself, "Why am I even thinking about this? Ariel-sama is someone who is desperately needed in this forest.
[cpg cn=true]


Instinctively sensing something dangerous, I was alarmed.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
;//[t_move pos=C 動揺]
[VOICE f="Ariel153"]
[OnName num="ariel"]
'Hey, what are you doing here ......?　I'm going to scream."
[cpg cn=true]


I restrained him, but one of the men shook his head.
[cpg]


[OnName num="elf_man_A"]
I shake my head. All the elves in the forest are aware of your relationship with the hero.
[cpg cn=true]


Then he tells me this ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel154"]
[OnName num="ariel"]
'No such ......
[cpg cn=true]


[OnName num="elf_man_B"]
I'm not going to let you go. I'm going to have Ariel-sama give up on this."
[cpg cn=true]


I see. So that's how it is. ......
[cpg]


I'm doomed to never get married.
[cpg]


[OnName num="elf_man_A"]
I have to make sure that I have no desire to mingle with humans.
[cpg cn=true]


[OnName num="elf_man_B"]
Yeah. We have to change their minds.
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Maybe ...... I've come to an untenable dead end.
[cpg]


The most important thing to remember is that you can't just take a look at the actual product or service and expect it to be good.
[cpg]


I can't get a connection with Itsuki in the end. I don't know if I'll ever ...... get together with Abram.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


The first thing to do is to make sure that you have a good understanding of what you're doing and how to do it.
[cpg]


;//しかし私は隠れてセックスばかりしていた。
;//[cpg]


I have no face to match with Tree-sama. Even so, he comes back every now and then.
[cpg]


I feel irresistible. I don't want to even have these feelings.
[cpg]


[OnName num="itsuki"]
"Ariel ...... have you lost weight?"
[cpg cn=true]


In fact, I think I have lost some weight. I have too much on my mind.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
;//[t_move pos=L ゆらゆら]
[VOICE f="Ariel155"]
[OnName num="ariel"]
No, I'm fine. I'm fine.
[cpg cn=true]


The tree encouraged me by saying, "The world will be restored to peace in a little while.
[cpg]


[OnName num="itsuki"]
Peace will be restored in a little while. Just wait and see.
[cpg cn=true]


I say the words of love to him. I hate myself for lying. But there was no going back.
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]

;//移植のためシーンをカットしています


I became more and more thin day by day. I lost weight.
[cpg]


All because I was thinking about my relationship with Itsuki.
[cpg]


I was caught between my feelings for Itsuki, and I couldn't help it.
[cpg]


I wondered if it wouldn't have happened if he hadn't been there.
[cpg]


I wonder if I would have been able to connect with Abram in a normal way.
[cpg]


[OnName num="abram"]
Ariel ......, are you okay?
[cpg cn=true]


[VOICE f="Ariel156"]
[OnName num="ariel"]
'I'm fine. I'm fine, so don't ...... worry about Abram."
[cpg cn=true]


So I'm going to act strong. That's all I have to do.
[cpg]


;//========================================
;//●ＣＧ（男と抱き合うヒロイン。疲れ切っている感じ）ev_48
;//人物１：ヒロイン１
;//服装１：着衣
;//人物２：エルフの男
;//服装２：着衣
;//場所　：
;//時間　：
;//========================================

[BGM f="bg_h2"]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]

He puts his lips to mine. I no longer refuse.
[cpg]

[OnName num="abram"]
I'm going to ...... make a proposal to the other elves. To the other elves."
[cpg cn=true]


Abram says this with a determined look on his face.
[cpg]


[VOICE f="Ariel157"]
[OnName num="ariel"]
What are you proposing,......?
[cpg cn=true]


He replies to my question.
[cpg]


[OnName num="abram"]
I'm going to tell them that since I love Ariel, I'm going to go out with the elves ...... and I don't want them to talk to me anymore.
[cpg cn=true]


[OnName num="abram"]
That would solve everything, wouldn't it, ...... Ariel?"
[cpg cn=true]


[VOICE f="Ariel158"]
[OnName num="ariel"]
Abram. You think so much of me."
[cpg cn=true]


Abram nodded. He nodded and continued.
[cpg]


[OnName num="abram"]
'Oh. I can't keep quiet after they did this to my precious childhood friend."
[cpg cn=true]


I was about to start crying.
[cpg]

;**【ＣＧ】 ev_51_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Ariel159"]
[OnName num="ariel"]
'...... it's late.
[cpg cn=true]


...... a little more. If you had told me a little earlier. No, but the same.
[cpg]


It's the same that I end up betraying Tree-sama. I can't help it.
[cpg]


I was pregnant with someone else's child.
[cpg]

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_ni"]
[WAIT time=100]


;//ブラックアウト


We were finally going to defeat the evil god.
[cpg]


Almost all of our people are coming together.
[cpg]


We can't take any more time. So we decided to go to the floating city where the evil god was.
[cpg]


There was no objection. We are going to the final battle. ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************


And the day before we went to defeat the evil god.
[cpg]


I was wandering around in the middle of the night, unable to sleep for some reason.
[cpg]


[OnName num="itsuki"]
I said, "......What is it......?　I hear a noise. ......."
[cpg cn=true]


I hear Ariel's voice. I head in that direction.
[cpg]


I have a bad feeling. But I can't stop my footsteps.
[cpg]


I've discovered something extraordinary.
[cpg]



;//ブラックアウト


;//移植のためシーンをカットしています

;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************

;//上下に黒帯を入れてください



[OnName num="itsuki"]
"...... Ariel."
[cpg cn=true]


I call out to Ariel. Ariel turned around in surprise.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
;//[t_move pos=C 動揺]
[VOICE f="Ariel160"]
[OnName num="ariel"]
I looked at Ariel and said, "What are you doing here, ......?　What are you doing here?
[cpg cn=true]


Abram didn't seem too surprised. Well, that's okay.
[cpg]


[OnName num="abram"]
What would Ariel say?
[cpg cn=true]


What would Ariel say? I asked her.
[cpg]


[OnName num="itsuki"]
"Were you dating Abram, ......?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel161"]
[OnName num="ariel"]
"No, no, no. ......!　No, no, no!
[cpg cn=true]


Ariel is still trying to make things right.
[cpg]


The most important thing to remember is that you can't just go to the store and ask for a discount. I don't think she can.
[cpg]


Abram was silent. I guess he thought it would be okay if everything became clear.
[cpg]


[OnName num="itsuki"]
If not, then what is it?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Ariel162"]
[OnName num="ariel"]
This is a ritual, a ritual passed down ...... to the elves, and the elves have to stay together ......."
[cpg cn=true]


[OnName num="itsuki"]
"...... we have to stay together?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel163"]
[OnName num="ariel"]
I mean, I can't make love with another species like the tree-sama, uh,...... that's what I mean,......."
[cpg cn=true]


The actuality of the ceremony is that it's a very important part of the ceremony.
[cpg]


I don't believe it. I don't believe it, but ......
[cpg]


I couldn't go any further.
[cpg]


My head hurts. It's getting hard to think. I've had enough.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel164"]
[OnName num="ariel"]
"Dear tree,...... it's not a lie, it's the truth."
[cpg cn=true]


Ariel says this too,...... and now I have no choice but to cling to the lie.
[cpg]


[OnName num="itsuki"]
I'll believe you, Ariel. I believe in you, Ariel."
[cpg cn=true]


I left Ariel with these words and walked away.
[cpg]


I knew it was a lie, but I decided to fool myself by replacing it with the truth.
[cpg]


What in the world would be the point of all this ......?
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夕方）******************************************************


And the next day. The day of the defeat arrived.
[cpg]


Defeat the evil god. Settle everything ...... no.
[cpg]


There are some things that can't be solved by this. But I had to go.
[cpg]


[OnName num="itsuki"]
I'm going to defeat the evil god now. Why don't you go, Ariel?
[cpg cn=true]


I asked Ariel before I left. Then she said.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
;//[t_move pos=C ゆらゆら]
[VOICE f="Ariel165"]
[OnName num="ariel"]
I'm sorry, I'm pregnant. I'm pregnant.
[cpg cn=true]


She said something surprising. I had never heard that before.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel166"]
[OnName num="ariel"]
I can't go ...... but it's my child with Itsuki.
[cpg cn=true]


I asked Ariel, skeptical.
[cpg]


[OnName num="itsuki"]
...... you mean I'm going to be a father?"
[cpg cn=true]


I confirmed to Ariel. She started to cry.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel167"]
[OnName num="ariel"]
I asked Ariel, "...... yes, you will be. You will be. ......
[cpg cn=true]


I somehow understand the reason for her tears.
[cpg]


I understand, but I can't ask her any more.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel168"]
[OnName num="ariel"]
"Gosh, hiccup......I'm so happy, I should be ...... gushing."
[cpg cn=true]


[OnName num="itsuki"]
Why are you crying,......, Ariel?
[cpg cn=true]


I can only say such vague things.
[cpg]


What should I do? What should I do?　What should I say?
[cpg]


;//他のエンディングを三つ以上通っていない場合この選択肢は発生しない
[stflag count_end = 0]
[if exp={isSystemFlagsEnabled("cl_001")}]
[stflag count_end = 1]
[endif]
[if exp={isSystemFlagsEnabled("cl_002")}]
[stflag count_end = 1]
[endif]
[if exp={isSystemFlagsEnabled("cl_003")}]
[stflag count_end = 1]
[endif]
[if exp={isSystemFlagsEnabled("cl_004")}]
[stflag count_end = 1]
[endif]
[if exp={isSystemFlagsEnabled("cl_005")}]
[stflag count_end = 1]
[endif]
[if exp={isSystemFlagsEnabled("cl_006")}]
[stflag count_end = 1]
[endif]
[if exp={isSystemFlagsEnabled("cl_009")}]
[stflag count_end = 1]
[endif]
[if exp={isSystemFlagsEnabled("cl_010")}]
[stflag count_end = 1]
[endif]

;//他のエンディングを三つ以上通っていない場合この選択肢は発生しない
;//選択肢が発生しない場合「１７、放っておく」で固定される
[if exp={getFlagValue("count_end") < 3}]
[jump target="*select08_2"]
[endif]

;//■選択肢
[switch]
[case "I'll get to the bottom of it."]
	[swap]
	[jump target="*select08_1"]
[case "I leave it alone."]
	[swap]
	[jump target="*select08_2"]
[endswitch]


16. get the truth out of him
17. let go


;//==============================
;//１６、真相を聞き出す
*select08_1
[jump storage="ep013.ks" target="*start"]



;//==============================
;//１７、放っておく
*select08_2
[jump storage="ep009.ks" target="*start"]

