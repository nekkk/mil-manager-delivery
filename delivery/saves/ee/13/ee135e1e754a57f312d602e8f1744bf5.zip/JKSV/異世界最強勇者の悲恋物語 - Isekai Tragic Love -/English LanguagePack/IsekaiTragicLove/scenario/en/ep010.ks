
*start

;#################################################
*Ep010|Underground City Defense
;#################################################

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（昼）


*select03_2|Defending the Underground City

[SCENE id=10]


[free time=1000]

[OnName num="itsuki"]
......I'm going to defend the Underground City.
[cpg cn=true]


I've decided. I will defend the underground city. The moment I said it.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]


[VOICE f="Littule086"]
[OnName num="littule"]
"Oh yeah, ......!　I knew you would say that.
[cpg cn=true]


Ritul shook my hand in delight.
[cpg]


;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Ariel178"]
[OnName num="ariel"]
'...... so, is that so,......?'
[cpg cn=true]


On the other hand, Ariel's expression was not buoyant. I think it's only natural.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Littule087"]
[OnName num="littule"]
I know how hard it is for you, Ariel, but I need you to cooperate with me here.
[cpg cn=true]


Ritul also bowed his head. Ariel didn't respond.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Mercurio047"]
[OnName num="mercurio"]
Ariel's face was pale and her eyes were wide.　Ariel?
[cpg cn=true]


[OnName num="itsuki"]
Please. I will definitely protect the Great Forest.
[cpg cn=true]


Ariel was told that much, finally.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Ariel179"]
[OnName num="ariel"]
"Yes. If you say so, Itsuki."
[cpg cn=true]


She said. Good ......
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mercurio048"]
[OnName num="mercurio"]
'Yes, I know, I can't help you if you don't solve the problem in turn.
[cpg cn=true]


Mercurio is Mercurio, and I'm sure he wants us to do something about the mermaid poaching.
[cpg]


We have to solve it right away. I thought so and hurried.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Littule088"]
[OnName num="littule"]
"All right, let's take down those demons!"
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

We were united. I wasn't sure about Hermia, but ......
[cpg]


At least the people here, or at least the non-humans, were united in our goal.
[cpg]


I'm still concerned about the lack of strength, but still, according to Litru, "If only we had a tree, we'd be a hundred strong.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Littule089"]
[OnName num="littule"]
As long as we have the trees, we are a hundred strong.
[cpg cn=true]


He said, "If we have the tree, we can be a hundred strong.
[cpg]


[free time=1000]

It's good that they are buying me, but if I can't play an active role after being told so much, it's going to be tough.
[cpg]


With this in mind, I went into battle.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_fi"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（夜）******************************************************


Ritul's words, "As long as I'm here, I'm all you've got. His words were about to become true.
[cpg]


I was knocking down demons so ...... well that I didn't even feel myself responding.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_5"  pos="2/2" time=800]

[VOICE f="Mercurio049"]
[OnName num="mercurio"]
Amazing ...... too strong ......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Ariel180"]
[OnName num="ariel"]
I'm really ...... amazed."
[cpg cn=true]


The most important thing to remember is that you can't just take your eyes off the road. I even had time to look at it.
[cpg]


The most important thing to remember is that you can't just go out and buy a new car.
[cpg]


Ritul is fighting with me. There is nothing to be afraid of.
[cpg]


And we are defeating more and more demons. ......
[cpg]


Before we knew it, we had defeated most of the demons and we were ......
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（夜）******************************************************


We were done with the fight. I was so stunned that I wondered if this was the end.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Littule090"]
[OnName num="littule"]
"Ho, did we really defeat them ......?　This is the end, right?
[cpg cn=true]


[OnName num="itsuki"]
Yeah, I think we probably beat all of ......."
[cpg cn=true]


There was still no response. Is that a good thing or a bad thing?
[cpg]


The most important thing to remember is that the best way to get the most out of your money is to use the best tools available to you. However, the peace of this underground city seems to have been preserved.
[cpg]


[STOPBGM]


Ritul smiled. Then he took my hand.
[cpg]

[BGM f="bg_m2"]

[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
;//[t_move pos=C 下礼]
[VOICE f="Littule091"]
[OnName num="littule"]
We did it, we did it!　You did it, Tree, you did it!
[cpg cn=true]


I felt embarrassed when he was that happy.
[cpg]


But I was also happy. I had really become a brave man.
[cpg]


It was something I didn't really feel, but after all this time, I still feel like I'm ......
[cpg]


[free time=800]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Ariel181"]
[OnName num="ariel"]
I'm sure you're very happy to ...... be so excited."
[cpg cn=true]


Ariel says something like that to Ritul, but...
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Littule092"]
[OnName num="littule"]
I'm not surprised!　We've taken back our home.
[cpg cn=true]


Ritul replies, "Of course we did.
[cpg]


Ritul is not the only one who is excited. It was not only Ritul who was excited, but all the dwarves were happy.
[cpg]


[OnName num="dwarf_man_A"]
Now we can live without fear of demons. ......
[cpg cn=true]


[OnName num="dwarf_man_B"]
Oh," he said, "I owe it all to the brave master. It's all thanks to you, the brave man.
[cpg cn=true]


I'm still embarrassed. The most important thing to remember is that you can't just take a look at the pictures.
[cpg]


The most important thing to remember is that it's the power of skill.
[cpg]

[free time=1000]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
;//[t_move pos=C 下礼]
[VOICE f="Littule093"]
[OnName num="littule"]
"All right, I'll definitely defeat the evil god!
[cpg cn=true]


[OnName num="itsuki"]
Ah, you can count on me, Ritul. I'm counting on you, Ritul.
[cpg cn=true]


I replied to Ritul like that.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Littule094"]
[OnName num="littule"]
But he said, "No, I'm not just going to defeat the Evil God!　I'll listen to anything you say.
[cpg cn=true]


Ritul said that much to me. I guess she really will do whatever she says now. ......
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The day was festive with the Dwarf tribe.
[cpg]


A race that laughs a lot, I thought. No, it was because the demons had been vanquished.
[cpg]


I was caught up in it too. ......
[cpg]


In the midst of the festivities, Mercurio said to me.
[cpg]


;//[FG f="CHA06_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mercurio050"]
[OnName num="mercurio"]
'Next, I have that ...... happening to me, or rather, the problem.'
[cpg cn=true]


I didn't forget. But.
[cpg]


I'm not forgetting anything. I have to solve what's going on with Mercurio's family.
[cpg]


[OnName num="itsuki"]
There was poaching, wasn't there?
[cpg cn=true]


;//[FG f="CHA06_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mercurio051"]
[OnName num="mercurio"]
"Yes, ......, can you do something about it?"
[cpg cn=true]


There is no way we can say we will do nothing.
[cpg]


For Mercurio's sake. I decided to help.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『地下都市』（昼）******************************************************


And so we left the underground city.
[cpg]


The dwarves seemed to be regretting their absence, but ...... we also could not stay for long.
[cpg]


That's why we were headed to ......
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************


Mermaid's Village. It's a place I went to one day.
[cpg]


[OnName num="itsuki"]
We should go to the beach sometime, right?
[cpg cn=true]


There were mermaids on the beach. We thought we would be able to hear their stories if we went there, but ......
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
;//[t_move pos=C ゆらゆら]
[VOICE f="Mercurio052"]
[OnName num="mercurio"]
No,...... there doesn't seem to be anyone there anymore.
[cpg cn=true]


[OnName num="itsuki"]
"What ......?　What do you mean, no one is there?
[cpg cn=true]


Mercurio continued to speak.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mercurio053"]
[OnName num="mercurio"]
I heard that they are all on their guard now, diving to the bottom of the sea.
[cpg cn=true]


Diving to the bottom of the sea. Then I guess we're safe now.
[cpg]

[free time=800]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Littule095"]
[OnName num="littule"]
'...... is that so?　Then poaching won't happen anymore.
[cpg cn=true]


I agree. Ritul continued.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]


[VOICE f="Littule096"]
[OnName num="littule"]
How do you catch a mermaid on the bottom of the ocean?
[cpg cn=true]


Ritul's question is a fair one.
[cpg]


If poaching is still happening, I don't know if it's a human thing or not.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Ariel182"]
[OnName num="ariel"]
No, why do mermaids get poached in the first place?"
[cpg cn=true]


Ariel asks another question. Hermia seemed to know the truth.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Elmyr092"]
[OnName num="elmyr"]
Oh, I wonder if Ariel knows.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Ariel183"]
[OnName num="ariel"]
I don't know ...... what?"
[cpg cn=true]


Hermia looked at Mercurio.
[cpg]


Mercurio frowned, looking disgusted.
[cpg]


I don't know what happens to mermaids when they are poached, either.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Mercurio054"]
[OnName num="mercurio"]
I heard that ...... the flesh of mermaids has the power of immortality.
[cpg cn=true]


[OnName num="itsuki"]
'...... well, that's what they say.'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
;//[t_move pos=LL 動揺]
[VOICE f="Littule097"]
[OnName num="littule"]
"Ugh...... you're going to eat it? That's a little......"
[cpg cn=true]


Ritul is imagining it and looking pale.
[cpg]


I thought it would be useless to react like that.
[cpg]


[OnName num="itsuki"]
Whatever it is, it's unforgivable.
[cpg cn=true]


Mercurio nodded at my words.
[cpg]

[free time=800]

[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="3/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/3" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Mercurio055"]
[OnName num="mercurio"]
Yes, I can't forgive him either. I can't forgive him either.
[cpg cn=true]


[free time=1000]

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


We then proceeded to the bottom of the sea. With the help of Mercurio, the mermaid, it was easy.
[cpg]


We listened to what the mermaids had to say. To prevent poaching, we first needed to identify the culprits.
[cpg]


[OnName num="itsuki"]
I need your help," Merkurio said. We need your opinion.
[cpg cn=true]


He asked the mermaids for their cooperation.
[cpg]


[OnName num="mermaid_A"]
I wonder who the culprit is. ...... There are rumors that it is a vampire.
[cpg cn=true]


One of the mermaids said it was a vampire.
[cpg]


[OnName num="mermaid_B"]
One mermaid says it's a vampire, another says it's a human.
[cpg cn=true]


One mermaid says she's human. Both are possible.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Littule098"]
[OnName num="littule"]
"Not human, anyway?　If they're obsessed with immortality, they've got a short life expectancy.
[cpg cn=true]


[OnName num="itsuki"]
I'm sure it is. Shorter than an elf or something.
[cpg cn=true]


[free time=800]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Elmyr093"]
[OnName num="elmyr"]
I don't know. I wonder if they might be vampires, who are originally close to immortality.
[cpg cn=true]


Yes. It is because they are close to immortality that they are frightened of death.
[cpg]


It was also a conceivable story. That we see perfect immortality, and that's why we aim for it.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ariel184"]
[OnName num="ariel"]
I don't know,...... either of which seems possible."
[cpg cn=true]


Ariel crosses her arms. And Mercurio throws a question to me.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]

[FG f="CHA06_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mercurio056"]
[OnName num="mercurio"]
What do you think, Itsuki-san?"
[cpg cn=true]


[OnName num="itsuki"]
I think it's possible for both ...... to happen.
[cpg cn=true]


I think. Which do you think is the culprit?
[cpg]


A human with a short life span? A vampire with a shorter lifespan or a vampire who is closer to immortality?
[cpg]

;//■選択肢
[switch]
[case "Human"]
	[swap]
	[jump target="*select09_1"]
[case "Vampire"]
	[swap]
	[jump target="*select09_2"]
[endswitch]


18, human
19, vampire



;//==============================
;//１８、人間
*select09_1
[jump storage="ep011.ks" target="*select09_1"]


;//==============================
;//１９、ヴァンパイア
*select09_2
[jump storage="ep012.ks" target="*select09_2"]
