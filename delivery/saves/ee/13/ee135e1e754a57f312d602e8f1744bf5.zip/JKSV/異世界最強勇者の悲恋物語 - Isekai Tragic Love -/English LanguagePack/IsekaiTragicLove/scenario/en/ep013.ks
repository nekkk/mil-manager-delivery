
*start

;#################################################
*Ep013|The Truth About Ariel Starting to Cry
;#################################################


[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夕方）



*select08_1|The Truth About Ariel Starting to Cry


[SCENE id=13]



[OnName num="itsuki"]
Ariel said, "It's a happy thing, isn't it? Are you crying because you're happy?"
[cpg cn=true]


I asked, half realizing the truth.
[cpg]


Ariel wiped her tears and spun desperate words.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel169"]
[OnName num="ariel"]
'......I'm sorry. The truth is, I'm not your child."
[cpg cn=true]



[OnName num="itsuki"]
......Yes, or ......."
[cpg cn=true]


I was aware of it. I was aware of it, but I still felt pain.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ariel170"]
[OnName num="ariel"]
It's Abram's baby."
[cpg cn=true]



I didn't want to hear any more. But Ariel continued.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel171"]
[OnName num="ariel"]
So I'm sure ...... this child will be ...... too.
[cpg cn=true]


I can't raise this child with me, either. I guess that's what she's trying to say.
[cpg]


[OnName num="itsuki"]
"......"
[cpg cn=true]


I had no idea what she was talking about.
[cpg]


It's true that lately she's been feeling uncomfortably lonely.
[cpg]

But it's strange then. Would Ariel betray me that easily?
[cpg]


We had already confirmed our love for each other. This is not right.
[cpg]


I couldn't help but feel that there was some kind of power at work in the world that I didn't know about. I couldn't help but feel that.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（朝）******************************************************


[FG f="CHA02_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
;//[t_move pos=C 下礼]
[VOICE f="Littule082"]
[OnName num="littule"]
"Hey, what do you mean you're not going to defeat the evil god?　Are you scared?
[cpg cn=true]


That's what I had told Ritul and the others. I meant what I said.
[cpg]


[OnName num="itsuki"]
I didn't. ...... I didn't know what I was trying to protect anymore.
[cpg cn=true]


I don't know if saving the world or something like that is what I should be doing right now.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
;//[t_move pos=C 下礼]
[VOICE f="Littule083"]
[OnName num="littule"]
What are you talking about?　It's too late for that.
[cpg cn=true]


Ritul has a point.
[cpg]


[free time=800]

[FG f="CHA06_p1_02_a.ui" method="change_5"  pos="1/2" time=800]

[OnName num="itsuki"]
I'm sorry, but I can't explain it, and I don't want to.
[cpg cn=true]


I replied tiredly. Mercurio was also concerned.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Mercurio045"]
[OnName num="mercurio"]
I'm sorry, I can't explain it,......," he said tiredly, "but I can't explain it.
[cpg cn=true]


But even that concern was alien to me. I had such a feeling.
[cpg]


[OnName num="itsuki"]
I said, "What does it matter ......?"
[cpg cn=true]


And I just walked away.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Mercurio046"]
[OnName num="mercurio"]
Oh ...... tree."
[cpg cn=true]

[free time=1000]

I said that and shut myself up in the shed.
[cpg]


I don't want to do anything else ......
[cpg]


;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


I hear a big commotion outside.
[cpg]


Ritul, Mercurio, and Charlotte...... these three are probably the main ones making noise.
[cpg]


Mercurio is not the type to make a fuss. But I'm sure they're confused.
[cpg]


They are going to fight without me, or trying to convince me to do so. It didn't matter anymore.
[cpg]


Could I ever love Ariel again? I don't think I could.
[cpg]


Would I be able to talk to Abram? I don't think I can.
[cpg]


What should I do? I felt like there was nothing I could do.
[cpg]


Let's just let everything die. ......
[cpg]


While I was thinking this, I received an unexpected visitor.
[cpg]


It was Hermia, whom I had not seen for a long time.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr074"]
[OnName num="elmyr"]
It's been a long time. I knew this would happen.
[cpg cn=true]


[OnName num="itsuki"]
"Hermia ......?"
[cpg cn=true]


I said unintentionally. Why this timing?
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Elmyr075"]
[OnName num="elmyr"]
Really, it's pretty much as I expected. It had to happen.
[cpg cn=true]


I was at a loss for words, but still tried to get what I wanted out of him.
[cpg]


[OnName num="itsuki"]
What do you mean you expected this to happen?
[cpg cn=true]



Hermia smiled wryly. And then he came closer to me.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
He was so close, I thought I could almost breathe on him. I could almost breathe on him.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr076"]
[OnName num="elmyr"]
I knew this was going to happen," he said.　I knew this would happen.
[cpg cn=true]


[OnName num="itsuki"]
How could you have possibly seen that coming?
[cpg cn=true]


I ask Hermia, not knowing what to think.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Elmyr077"]
[OnName num="elmyr"]
I have no idea what's going on, so I ask Hermia, "It's all a setup. It's all a set-up.
[cpg cn=true]


A set-up. You mean you set it up?
[cpg]


Hermia?　What do you mean he set it up?
[cpg]


[OnName num="itsuki"]
What are you talking about,......, I mean, where have you been all this time?
[cpg cn=true]


I ask all at once what I don't know.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr078"]
[OnName num="elmyr"]
I ask a bunch of questions I don't know. I don't care, it doesn't matter, Ariel dumped you, didn't she?
[cpg cn=true]


[OnName num="itsuki"]
How do you know that?
[cpg cn=true]


How do you know? No, I don't care who you are, just ask the elf.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Elmyr079"]
[OnName num="elmyr"]
I've been watching you. I've been looking at you, thinking I deserve you more than Ariel.
[cpg cn=true]


I don't know what Hermia is talking about. He's been off topic for a while now.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr080"]
[OnName num="elmyr"]
Hey, tree."
[cpg cn=true]

;//========================================
;//●ＣＧ（主人公に迫るヒロイン）ev_05
;//人物１：ヒロイン３
;//服装１：着衣
;//人物２：主人公
;//服装２：旅人服
;//場所　：小屋
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_05_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]


Hermia said that, and closed the distance between us further.
[cpg]


He kisses me. And then, he pulls his lips away from mine.
[cpg]


[VOICE f="Elmyr081"]
[OnName num="elmyr"]
Or am I not attractive enough for you?
[cpg cn=true]


My heart is racing. I can't believe I'm still feeling this way.
[cpg]


[VOICE f="Elmyr082"]
[OnName num="elmyr"]
I know it's not true. ......
[cpg cn=true]


Am I right to be swept away here at ......?
[cpg]


[OnName num="itsuki"]
I think I was halfway through the ......
[cpg cn=true]


I think I was desperate. I also wanted to forget about Ariel.
[cpg]


[OnName num="itsuki"]
"Okay. ......
[cpg cn=true]


What did I know? I don't know anything.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


That's fine. But something was nagging at me. The catch swelled up in my head and ......
[cpg]


...... and became uncomfortable in my mind. I thought it was strange.
[cpg]


I feel that with Hermia's partner, there's not a strange passing.
[cpg]


[OnName num="itsuki"]
'Even though it didn't work out with ...... Ariel.
[cpg cn=true]


;//[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Elmyr083"]
[OnName num="elmyr"]
'Of course it would have. It was all my idea.
[cpg cn=true]


Hermia says something meaningful again.
[cpg]


[OnName num="itsuki"]
I ask, "What ......?"
[cpg cn=true]


I asked, but Hermia didn't give me any answer.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


The girls were supposed to be on their way to defeat the enemy, but their confusion continued.
[cpg]


They were divided among themselves. Even though it was my fault, ......
[cpg]


Ritul and Mercurio tried to persuade me, and Charlotte decided that persuasion was impossible and went to the Evil God already.
[cpg]

Can Charlotte defeat me by herself? I think it is impossible.
[cpg]

As a result, it became impossible to defeat the evil god no matter how I tried.
[cpg]


Maybe she can't defeat the evil god without me. That's why I was summoned.
[cpg]


That's what I mean. I lost the will to fight ...... and that's where it all ended.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夕方）******************************************************


Ariel's belly swelled. I couldn't watch her give birth like this.
[cpg]


I couldn't stand it. I couldn't stay sane. So I decided to leave alone.
[cpg]


No one would find me. If I was about to be found, I would just use my skills. ......
[cpg]


There must be something, some skill to hide yourself. I was already desperate.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『草原』（夕方）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

As I set off, Hermia followed me.
[cpg]


I didn't feel bad about it. I also felt uncomfortable traveling alone.
[cpg]


Hermia didn't say much. He was just following me.
[cpg]


I felt strangely trustworthy.
[cpg]


[free time=1000]

We camped somewhere that was neither a town nor a village.
[cpg]

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
Hermia had brought us portable food. He also made a simple soup.
[cpg]


[OnName num="itsuki"]
Thank you for ......."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
I thanked him, and he said, "You're welcome.
[cpg]


I sip the soup and feel kind of sleepy .......
[cpg]


No, what is this sleepiness? This is not normal.
[cpg]

;//========================================
;//●ＣＧ（座っているヒロイン。冷たいまなざしで真相を明かす）ev_15
;//人物１：ヒロイン３
;//服装１：着衣
;//人物２：主人公
;//服装２：旅人服
;//場所　：宿の一室
;//時間　：夜
;//備考　：ラフ04.jpgのシーンです
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_15_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Elmyr084"]
[OnName num="elmyr"]
'I'll tell you all about it. I desperately needed to break ranks to get what I wanted."
[cpg cn=true]


Hermia is saying strange things. I can't even sit still anymore.
[cpg]



[VOICE f="Elmyr085"]
[OnName num="elmyr"]
'I've had a lot of things planted in my head to make that happen.
[cpg cn=true]


I try to say, "What do you mean by that? ......," but my tongue won't roll.
[cpg]


Sleeping pills or something, they made me take them. Was it in the soup?
[cpg]


[SE f="se013"]
;//【ＳＥ】『倒れる』

I just fell right into it.
[cpg]


What if Hermia is behind everything? No, how is that possible?
[cpg]


She was one of the ones who summoned me. There's a reason why I betrayed her: ......
[cpg]


Wait, ...... did you betray me because you were part of the ones who summoned me?
[cpg]


Was she betraying me in the first place?　I let my imagination run wild.
[cpg]



;//ブラックアウト



;//////////////////////
;//ヒロイン3に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************

[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]

I had been enchanted by the evil gods in the first place.
[cpg]


Worshippers of evil gods, human beings or their equivalents. Or an evil religion composed of demons.
[cpg]


As a dark elf, my family has been a believer in paganism for generations.
[cpg]


I did not want the world to be saved. Rather, I actively wished for the destruction of the world.
[cpg]


[OnName num="itsuki"]
I was a member of the "......a......else......mia."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Elmyr086"]
[OnName num="elmyr"]
I was a servant of the Evil God. In the midst of all this, various races colluded to summon the heroes,.......
[cpg cn=true]


When that story came up, I was also impatient.
[cpg]


The most important thing to remember is that you can't just take a chance on a new person. I was to be present at the summoning.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr087"]
[OnName num="elmyr"]
It wasn't good for me. I didn't want the world to be saved.
[cpg cn=true]


When I was present at the summoning, I secretly played a trick.
[cpg]


The ultimate curse that would lead everything to collapse. ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Elmyr088"]
[OnName num="elmyr"]
Does this sound familiar?　The words, "Chosen hero, I give you the power of salvation. That was my voice."
[cpg cn=true]


The tree seems unable to say anything else.
[cpg]


Is that because he is surprised by my change? Or was it the sleeping pills?
[cpg]


Either way, it doesn't matter. After all is said and done, everything is fine.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr089"]
[OnName num="elmyr"]
I said to her, "......Well, you'd be surprised, wouldn't you? If you suddenly ask me something like this..."
[cpg cn=true]


The tree has opened its eyes. He must have heard what I said.
[cpg]


I continued to speak triumphantly. Since this is a good opportunity, I'm going to reveal the whole story.
[cpg]


But there is not much more to say.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
I was the one who created his skill.
[cpg]


Those who have this skill will surely be interrupted in their love.
[cpg]


Not only will they be thwarted, but they will be taken by others.
[cpg]


It was surely going to be an obstacle in defeating the evil god.
[cpg]


It could break the bonds between the women who were colluding, and it could also break the hearts of the heroes.
[cpg]


The most important thing was that it would provoke a split in the ranks.
[cpg]


The skill I had set in motion was to kill two birds with one stone and more.
[cpg]


[OnName num="itsuki"]
Say ...... what you ......."
[cpg cn=true]


The tree didn't seem to fully understand. I didn't have much more to say to him.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr090"]
[OnName num="elmyr"]
It means exactly what it says. It's nothing more than that.
[cpg cn=true]


I guess he didn't think I was betraying him.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Elmyr091"]
[OnName num="elmyr"]
You have skills that I don't know what's in them," he said. I wonder if you remember that."
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
There was another one called "heaven forbid. That's not a skill that occurs often, but it's a skill that says the opposite when it's all around you.
[cpg]


Could it have happened to him?　It might have happened to him if he had fallen in love with someone else instead of Ariel.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

But ...... whatever, in the end. My purpose has been fulfilled.
[cpg]


;//移植のためシーンをカットしています


;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************


By the time I ...... woke up, Hermia was gone.
[cpg]


So ...... I lose not only Ariel, but Hermia as well.
[cpg]


I realize I've really lost everything. No, can I still save the world if I want to ......?
[cpg]


Can I start over? With someone else......
[cpg]


That's ...... different. Such an idea. I've got skills and stuff.
[cpg]


I'm done. I don't need anything else.
[cpg]


That's how I felt. I couldn't take any more loss.
[cpg]


I had accepted the world as it was dying. ......
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//ヒロイン３　ルート　黒幕発覚
;//ＥＮＤ


;//[Ending_SetUp cl=cl_005 ss=false]

[system cl_005=true]

[SCENE id=21]


[jump storage="epend.ks" target="*start"]

