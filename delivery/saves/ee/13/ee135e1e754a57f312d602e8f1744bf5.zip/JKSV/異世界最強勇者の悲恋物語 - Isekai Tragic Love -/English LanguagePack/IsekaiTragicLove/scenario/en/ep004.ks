
*start


;#################################################
*Ep004|Ariel is important.
;#################################################


*select06_1|Ariel is important.

[SCENE id=4]

;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[OnName num="itsuki"]
"......, let's go find Ariel. You come first.
[cpg cn=true]


[OnName num="abram"]
"......, all right. Let's go look again for the tentacle creature's nest.
[cpg cn=true]


We were bitterly disappointed, but we made the search for Ariel a priority.
[cpg]


We headed back to the tentacle nest with Abram and the elf men.
[cpg]

Again and again, the same thing happens. It can't be a coincidence anymore. ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1500]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

Ariel is brought back. But she took her eyes off the road for a bit and tried to go somewhere else.
[cpg]


She was clearly in an abnormal state. I even felt that the Ariel I knew was not the Ariel I knew.
[cpg]


However, her appearance and words were the Ariel I knew.
[cpg]


Only her behavior seemed to have been switched.
[cpg]


[OnName num="itsuki"]
'Ariel, what's really wrong with you,......?
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
;//[t_move pos=C ゆらゆら]
[VOICE f="Ariel104"]
[OnName num="ariel"]
"......I don't know either,.......
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Ariel105"]
[OnName num="ariel"]
'But I know I'm bothering you, ...... tree-sama. Please forget about me."
[cpg cn=true]


[OnName num="itsuki"]
What are you talking about? I love you, Ariel, no matter what.
[cpg cn=true]


Ariel hugged me with tears in her eyes.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

For a few days. Still, there were calm and happy times.
[cpg]


I hoped that this kind of happiness would continue ...... but it didn't.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3"]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夕方）******************************************************


A little while later, the news came that the underground city of the dwarves had fallen.
[cpg]


I was shocked. Should I have gone to Ritul after all?
[cpg]


[OnName num="itsuki"]
It's my fault ...... what happened to Ritul ......?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
;//[t_move pos=C ゆらゆら]
[VOICE f="Ariel106"]
[OnName num="ariel"]
It's not your fault, Itsuki. It's my fault."
[cpg cn=true]


[OnName num="itsuki"]
'What did Ariel do to you, ......?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel107"]
[OnName num="ariel"]
It's all my fault. ...... You don't have to say anything else.
[cpg cn=true]


We lick each other's wounds. But I can't see through Ariel's mind.
[cpg]


What is this relationship we have?　We could no longer call ourselves mere lovers.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The underground city has fallen. That means the expansion of the demons' power.
[cpg]


It could have come this far. The elves were terrified.
[cpg]


If they were to attack this forest, they would ...... imagine it. I had that too.
[cpg]


But I'll be fine. I'm going to defeat them all,......, that's how much I was thinking.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_fi"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


The demons that attacked the underground city had marched into the forest.
[cpg]


There was a horrifying sight ......
[cpg]

;//移植のためシーンをカットしています


[OnName num="itsuki"]
What a number ......."
[cpg cn=true]


The hordes of monsters were so numerous that it shook my earlier resolve.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
In the midst of all this, Ariel was about to act strangely again.
[cpg]


Ariel wandered off in the direction of the monsters. I couldn't understand what she was doing.
[cpg]


[OnName num="itsuki"]
Hey, Ariel!　What's wrong?"
[cpg cn=true]


Ariel muttered quietly, "Don't stop me.
[cpg]


[OnName num="itsuki"]
Of course I'm going to stop you!"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
;//[t_move pos=C 溜息]
[VOICE f="Ariel108"]
[OnName num="ariel"]
'......I'm sorry. I really don't care about me anymore."
[cpg cn=true]


[OnName num="itsuki"]
'Oh no,...... really, what's wrong with you?'
[cpg cn=true]


I was in a state of release, but I was still thinking about Ariel.
[cpg]

[SE f="se006"]
;//【ＳＥ】『剣を振りかざす』

[OnName num="itsuki"]
Danger!"
[cpg cn=true]


A troll attacked Ariel. I quickly took the hit.
[cpg]


[SE f="se013"]
;//【ＳＥ】『鈍器で殴る』


[OnName num="itsuki"]
"Ggggghh......!"
[cpg cn=true]


My consciousness faded. In the midst of all this, on her, on her body, I saw a pattern that I had seen one day.
[cpg]


I saw the pattern that I had seen one day. ......
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I was not dead, even after all this.
[cpg]

Monsters are also stuffy, I thought, and ...... there was only one thing for me to do.
[cpg]

[SE f="se006"]
;//【ＳＥ】『剣を振りかざす』

I swung my sword grubbily. Defeat the trolls.
[cpg]


It was too late for everything. I knew that, but I couldn't help but ...... do nothing.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************


The trolls were annihilated. But the demons kept coming one after another.
[cpg]


Because they had not defeated the evil gods. It should have been my role to defeat the evil gods.
[cpg]


But I abandoned that responsibility.
[cpg]


There was no longer any reason for me to fight. ......
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


Mercurio is missing in an underground city. Furthermore, news arrived that Charlotte had also been attacked in her hometown and had been killed in battle.
[cpg]


I don't care anymore. I decided to protect her in this forest.
[cpg]


Our relationship had become strained.
[cpg]


Ariel would continue to put herself in danger. Ariel continues to put herself in danger, as if she enjoys the thrill of it.
[cpg]


I wonder if Ariel still loves me. I don't think she does.
[cpg]


I love Ariel. I'm sure of it.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel109"]
[OnName num="ariel"]
I've already figured it out. I already know the pattern, the skills I don't remember.
[cpg cn=true]


All this was to tear us apart. Both Ariel and I were coming to realize that.
[cpg]

[OnName num="itsuki"]
If it was someone else's fault, why would they want this?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Ariel110"]
[OnName num="ariel"]
I'm sure they wanted to neutralize you by cutting me down,......, which is the hand of the evil god.
[cpg cn=true]


But I haven't given up yet. I haven't let go of this snoring love yet.
[cpg]

[OnName num="itsuki"]
I'm still fighting. No matter what happens to Ariel, I'm going to keep this love until the end.
[cpg cn=true]


Ariel looks apologetic, but that's okay.
[cpg]

No matter what happens to Ariel, I will protect her.
[cpg]

With that in mind, I kissed the somewhat broken Ariel on the mouth.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


How did our love come to this?
[cpg]

I wonder if there was a choice somewhere that would have made that clear: ......
[cpg]


;//移植のためシーンをカットしています

;//ヒロイン１　ルート　モンスター寝取られ
;//ＥＮＤ


;//[Ending_SetUp cl=cl_002 ss=false]


[SCENE id=15]

[system cl_002=true]

[jump storage="epend.ks" target="*start"]

