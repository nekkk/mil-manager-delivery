
*start

;#################################################
*Ep012|Vampires are suspicious
;#################################################

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）

*select09_2|Vampires are suspicious

[SCENE id=12]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]

[OnName num="itsuki"]
I'm thinking, "...... What if vampires aren't completely immortal?　They must have a weakness, like sunlight or something."
[cpg cn=true]


I've heard stories too, but I think the other thing I heard was that staking them or something like that would kill them.
[cpg]


[OnName num="itsuki"]
The closer you are to immortality, the more you think you're almost there.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Ariel185"]
[OnName num="ariel"]
Sure ...... that's likely."
[cpg cn=true]


Ariel sympathized, but Ritul nodded his head.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Littule099"]
[OnName num="littule"]
'Err, I don't know.　I wonder if that's possible."
[cpg cn=true]


We don't know what the facts are.
[cpg]


In any case, we had to move on with our observations.
[cpg]


[OnName num="mermaid_C"]
'I did see him!　It was a vampire. ...... I'm sure of it."
[cpg cn=true]


[OnName num="itsuki"]
'Well ...... for now, we'll just have to assume it was a vampire and move on.
[cpg cn=true]


Ritul nodded, though not too aggressively.
[cpg]


It's settled. We decided to go to the vampire's place of residence.
[cpg]


[free time=1000]


;//上下の黒帯を外してください



But it seems that vampires are not so easy to meet.
[cpg]


Vampires rarely appear in the first place.
[cpg]


I can imagine that sunlight is their weak point. ......
[cpg]


The family lives in a place called Eul Aurea.
[cpg]


A city that exists in the shadow of eternal darkness. A land where vampires live.
[cpg]


It is said to be everywhere and nowhere.
[cpg]


This is Hermia's story. It is abstract and a little difficult to understand.
[cpg]


First of all, if it is everywhere, does it mean that you can go there from anywhere?
[cpg]


If it is nowhere, does that mean you can't get to it from anywhere?
[cpg]


I think Ermia is just playing a joke on me. Thinking so, I asked him one more time.
[cpg]


[OnName num="itsuki"]
I asked again, "What exactly do you mean by ......?"
[cpg cn=true]


With a sigh, Ariel began to explain.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Ariel186"]
[OnName num="ariel"]
It is said to exist in certain places, with only limited means to get to it.
[cpg cn=true]


[OnName num="itsuki"]
What, you mean that ......?"
[cpg cn=true]


I felt like a fool for thinking it was a romantic story.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Mercurio057"]
[OnName num="mercurio"]
Oh, I see. ...... I didn't know that."
[cpg cn=true]


Mercurio didn't know either.
[cpg]


After all, it seemed to be a little-known place.
[cpg]


[OnName num="itsuki"]
 "A way to get there... I guess there's no point in walking blindly, it's dark."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Littule100"]
[OnName num="littule"]
I'm sure ...... Charlotte had something in her possession.　I think it was the compass of ever-darkness,......, or something like that.
[cpg cn=true]


Ritul says something like that. This is also new to me.
[cpg]


[OnName num="itsuki"]
I've never heard of this either.
[cpg cn=true]


[FG f="CHA06_p1_02_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Mercurio058"]
[OnName num="mercurio"]
;//「ドラゴン族が何か持ってるんでしょうか……？　どうしましょう、樹様」
'Do you think the dragon tribe has something ......?　What should we do, Itsuki?
[cpg cn=true]


I also wanted to make Charlotte my friend.
[cpg]


The most important thing to do is to make sure that you have the right tools for the right job.
[cpg]


[OnName num="itsuki"]
......Well, let's head there, just in case."
[cpg cn=true]


I said that and decided on a course of action.
[cpg]


But I don't know where Charlotte is .......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Ariel187"]
[OnName num="ariel"]
"I think that's a good idea. We should head over."
[cpg cn=true]


[OnName num="itsuki"]
I'm counting on you. Will you come with me, Ritul?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Littule101"]
[OnName num="littule"]
Of course. Of course. I'll go wherever the tree goes.
[cpg cn=true]


The others nodded in agreement.
[cpg]


It was decided, we would head to Charlotte's place.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Ariel knew where she was.
[cpg]


She only knew the general location, but I guess that means Ariel was the one who gathered everyone together for the summoning.
[cpg]


Aside from that, this road is ......
[cpg]


[OnName num="itsuki"]
"It's steep. Is everyone all right?"
[cpg cn=true]


Mercurio seems to be having a hard time. He is not used to walking on land to begin with.
[cpg]


But we have to go through here to get there ...... or rather, there is a settlement in the middle of these mountains.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m2"]
[WAIT time=100]
;//【ＢＧ】『ドラゴンの住処』（夜）******************************************************


And we made it to the dragon's abode.
[cpg]

[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
We were able to meet Charlotte right away.
[cpg]


She didn't seem to feel bad about leaving without permission. ......
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
;//[t_move pos=C ゆらゆら]
[VOICE f="Charlotte023"]
[OnName num="charlotte"]
I don't have it. It's a family treasure.
[cpg cn=true]


[OnName num="itsuki"]
"Well,...... even if I did, I need it.
[cpg cn=true]


[OnName num="itsuki"]
I'm asking you, please. Please, please negotiate with them to give it to me.
[cpg cn=true]


[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte024"]
[OnName num="charlotte"]
It's not something I can handle on my own.
[cpg cn=true]


Ritul was puzzled.
[cpg]


[free time=800]

[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Littule102"]
[OnName num="littule"]
'Yes, is that right ......?　I thought I heard it from Charlotte.
[cpg cn=true]


[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Charlotte025"]
[OnName num="charlotte"]
Maybe I'm not wrong, but I can't do it anyway.
[cpg cn=true]


Ritul looks frustrated.
[cpg]


But there was no point in pressing Charlotte any further.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Ariel188"]
[OnName num="ariel"]
'What should we do, should we negotiate with the chief or someone else?
[cpg cn=true]


[OnName num="itsuki"]
'Well, ...... we'll just have to do that.
[cpg cn=true]


[OnName num="itsuki"]
We can't take too long, but we have no choice.
[cpg cn=true]


[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Mercurio059"]
[OnName num="mercurio"]
"It's a long way, but I guess that's the only way. ......
[cpg cn=true]


Then we decided to take the rest of the day off for now.
[cpg]


Everyone was pretty worn out. We were lent an inn for the night ......
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_fi"]
[WAIT time=100]
;//【ＢＧ】『ドラゴンの住処』（昼）******************************************************


We then had a dialogue with the chief of the dragon tribe.
[cpg]


A rather old dragonut man.
[cpg]


He seemed very hard-nosed and I was a little scared just to interact with him, but ......
[cpg]


[OnName num="itsuki"]
"...... please. Can I borrow your compass of everlasting darkness?
[cpg cn=true]


[OnName num="elder"]
The compass of everlasting darkness is a tradition of my tribe. If you want to defeat the evil god, I can give it to you, but I cannot give it to the weak.
[cpg cn=true]


So that's what they are talking about.
[cpg]


The actuality that the actual dragon tribe is so much more focused on power is not surprising.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel189"]
[OnName num="ariel"]
 "Then it's okay, Itsuki-sama is extremely strong, and he protected the underground city all by himself..."
[cpg cn=true]


[OnName num="elder"]
I don't think I've seen that. I'm sure I didn't see that. Can't you prove it with power rather than with words?
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
That's right. That's what we're talking about, too.
[cpg]


[free time=1000]

Then who am I going to fight to prove my power? ......
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte026"]
[OnName num="charlotte"]
I'll fight for you. Is that okay?"
[cpg cn=true]


[OnName num="itsuki"]
Huh?"　Charlotte, are you serious ......?
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte027"]
[OnName num="charlotte"]
I'd like to see you fight. I wanted to see how strong you are.
[cpg cn=true]


Charlotte licks her tongue.
[cpg]


 I wonder if she's a bit of a combat fanatic, too.
[cpg]


[free time=1000]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Littule103"]
[OnName num="littule"]
She said, "Hey, are you going to fight amongst yourselves ......?　That's crazy.
[cpg cn=true]


Ritul tries to stop her. Ritul, who has a rather messy personality, is trying to stop her.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Mercurio060"]
[OnName num="mercurio"]
'Yes, let's keep things civil here.'
[cpg cn=true]


Mercurio tries to stop more.
[cpg]


What should we do? It would be easy to fight Charlotte and win.
[cpg]


I was lost. After much deliberation, I decided to ......
[cpg]

;//ヒロイン４が居なくなったため、この選択肢は発生しません
;//２１を選んだことにして、ジャンプしてください

;//[jump target="*select10_2"]


;//==============================
;//２１、話をする（ヒロイン５ルートへ）

;#################################################
;//*Ep012|話をする
;#################################################

;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_04_2.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]

*select10_2|Let's talk.

[free time=1000]

[OnName num="itsuki"]
Hey, let's talk.
[cpg cn=true]


I didn't like the idea of using force to solve everything.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Charlotte028"]
[OnName num="charlotte"]
What?"
[cpg cn=true]


But Charlotte seemed to dislike it even more.
[cpg]


The words became even stronger than her usual attitude.
[cpg]


It is obvious that she is in a bad mood.
[cpg]


Charlotte is strong. Among her friends, she is probably stronger than Ritul.
[cpg]


Maybe that's why I felt like I was being made a fool of.
[cpg]


Charlotte said to me in a strong tone, "Are you making fun of me...?
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte029"]
[OnName num="charlotte"]
You're making fun of me...you're making fun of me ......."
[cpg cn=true]


Something like steam blows out from her body.
[cpg]


Is it the power of a dragonut? Or is this ......
[cpg]


Is she wearing some kind of magic? I'm not the only one who can use magic.
[cpg]


What I do know is that Charlotte has built up a lot of anger.
[cpg]


I'm going to get hit. I had a hunch.
[cpg]


If I wanted to avoid it, I could, and I could return it with my fist.
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte030"]
[OnName num="charlotte"]
Haaaaah!"
[cpg cn=true]


A momentary incident.
[cpg]


Charlotte, accelerated, closes the gap at once and blows me away.
[cpg]

[SE f="se013"]
;//【ＳＥ】『殴る』


;//ホワイトアウト

[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=500]
[WAIT time=500]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=1]
[WAIT time=1]
[transition target={true} rule="bakuhatu2.webp" color={0xffffffff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu2.webp" color={0xffffffff} time=500]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『ドラゴンの住処』（昼）


;//[SE f="se013"]
;//【ＳＥ】『倒れ込む』

But that was fine. There is nothing better than this to convey my feelings.
[cpg]


I was really blown away. I rolled on the ground for a while.
[cpg]


It was so painful that I felt as if my senses had been shut out.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Charlotte031"]
[OnName num="charlotte"]
What the...?
[cpg cn=true]


And Charlotte, who felt the response, seemed surprised.
[cpg]


[free time=1000]



[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_5"  pos="2/2" time=800]

[VOICE f="Littule113"]
[OnName num="littule"]
'Trees!
[cpg cn=true]

[VOICE f="Mercurio089"]
[OnName num="mercurio"]
Tree!"
[cpg cn=true]


Ritul tries to approach me as I fall down.
[cpg]

No, that's not good enough. I should not be here to take advantage of these women.
[cpg]


That would make Charlotte look like the bad guy.
[cpg]

[free time=1000]


I put out my hand to stop the girls who were trying to run up to me.
[cpg]

[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
I manage to get up and walk back to Charlotte's side.
[cpg]


I thought Charlotte was going to hit me a second time, but that was not the case.
[cpg]


Charlotte becomes agitated and says to me.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte032"]
[OnName num="charlotte"]
'Why didn't you avoid...!
[cpg cn=true]


If it were true, I could have avoided it. And I could have avoided it.
[cpg]


But I thought it was for the best. If I had avoided the attack, it would have turned into a fistfight.
[cpg]


Even if we didn't end up in a fistfight, I was sure that Charlotte would attack me next.
[cpg]


[OnName num="itsuki"]
I told you...let's talk.
[cpg cn=true]


You have a cut on your mouth. It's hard to talk.
[cpg]


But Charlotte must be hurting her knuckles.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte033"]
[OnName num="charlotte"]
This is a discussion. For us warriors, our fists speak! They tell us everything!
[cpg cn=true]


Warrior. I guess that's what Dragonutes are like.
[cpg]


I thought they were probably the most powerful race too.
[cpg]


[OnName num="itsuki"]
'I can sort of see that. I can sort of understand that, and the ways of Charlotte and the others. But I can't fight against girls.
[cpg cn=true]


Was it unnecessary to say "with girls"?
[cpg]


But my feelings were there. Charlotte had probably never been treated this way before.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte034"]
[OnName num="charlotte"]
"You're making fun of me...! You're taunting a proud Dragonute with the blood of a dragon!
[cpg cn=true]


[OnName num="itsuki"]
If you want me to show strength, I will. I'm going to follow your manners. But I will not fight Charlotte.
[cpg cn=true]


[OnName num="itsuki"]
I'll show you something else. I'll show it in some other way, like defeating demons, or whatever.
[cpg cn=true]


Charlotte is trembling.
[cpg]


I have no intention of doing so.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte035"]
[OnName num="charlotte"]
Why...why...?
[cpg cn=true]


Why? Come to think of it, why?
[cpg]


It's natural to be nice to girls. But Charlotte probably needs a reason.
[cpg]


If her veins are so important to her, how about this?
[cpg]


[OnName num="itsuki"]
My grandfather told me to be nice to girls.
[cpg cn=true]


I gave a good reason and did not tell the truth.
[cpg]


Charlotte still continued to speak. Charlotte still continued to speak.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte036"]
[OnName num="charlotte"]
I'm... a female, but I'm a ...... warrior!
[cpg cn=true]


[OnName num="itsuki"]
You still say ...... that, I already know that."
[cpg cn=true]


Charlotte asks why then.
[cpg]


[OnName num="itsuki"]
'I'm a warrior or a girl before that. I'm sorry, but that's non-negotiable. That's my style."
[cpg cn=true]


If she was going to bring up the way of doing things, then so was I. I have my own way of doing things, too.
[cpg]


There are some things I can't bend. Even if I have to hit Charlotte in order to move forward, I still can't do it.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte037"]
[OnName num="charlotte"]
"Damn..."
[cpg cn=true]


Charlotte finally shut up.
[cpg]


I don't think there are any more words to say. The most important thing to remember is that you can't just take a chance on a new person.
[cpg]


While I was thinking that, ...... another dragonute called out to me.
[cpg]


The old dragonut that was there earlier.
[cpg]


[OnName num="elder"]
'That's enough.'
[cpg cn=true]


Charlotte was already looking like she had lost her will to fight.
[cpg]


No, I guess she hasn't lost her will to fight. But she must have thought she was being drained.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Charlotte038"]
[OnName num="charlotte"]
"Hey, Elder..."
[cpg cn=true]


[OnName num="itsuki"]
How do you like it, Elder? I would like to show my will by something other than force if possible.
[cpg cn=true]


I tried to negotiate with the dragonute who was called the Elder.
[cpg]


[OnName num="itsuki"]
Even if we fight, I can't do it with Charlotte.
[cpg cn=true]


I reminded him again. Then the one called the Elder also said ......
[cpg]

[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[OnName num="elder"]
"Very well," he said, "you must listen to Charlotte. Charlotte, listen carefully."
[cpg cn=true]


Charlotte turns over. Then, the elder said, "This is a special case.
[cpg]


[OnName num="elder"]
I will grant you a special exception this time. "My hero."
[cpg cn=true]


He made a concession. Frankly speaking, I am grateful.
[cpg]


I had been thinking about what I would do if he said no. I had been thinking about what I would do if he said no.
[cpg]


I was thinking what if he was the type of person who was preoccupied with fighting all the way to the elders.
[cpg]


[OnName num="itsuki"]
I am grateful to you. I will take good care of the compass.
[cpg cn=true]


[OnName num="elder"]
Of course. That goes without saying.
[cpg cn=true]


The conversation was coming to an end. But, Charlotte seemed to have not given up yet.
[cpg]


And then, she said to me like this.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte039"]
[OnName num="charlotte"]
No, no, no, no! No, no, no! Fight, fight, fight! Fight!
[cpg cn=true]


He was like a child, whining.
[cpg]


The dignity he had just displayed was gone. This may be what it means to be a warrior.
[cpg]


[free time=1000]

In Charlotte's case, a girl ...... before a warrior is what I said.
[cpg]


And then Ariel approached. She seems to be concerned about my safety.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel201"]
[OnName num="ariel"]
'Are you all right, Itsuki?'
[cpg cn=true]


To be honest, it only hurts this much. It's no big deal at all.
[cpg]


[OnName num="itsuki"]
I'm fine. Thank you.
[cpg cn=true]


And so we were on our way to the city where the vampires lived.
[cpg]


;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『ドラゴンの住処』（夜）******************************************************

We didn't leave right away.
[cpg]


Everyone was tired and I was especially injured.
[cpg]


I guess they were concerned about me. We decided to stay the night.
[cpg]


That evening ......
[cpg]

[SE f="se009"]
;//【ＳＥ】『ノック』


The door was opened a little. Charlotte was there.
[cpg]


[OnName num="itsuki"]
Charlotte?　What are you doing here at this time of night?"
[cpg cn=true]


I wondered if she was still thinking about the match we had just had.
[cpg]


It's quite possible. But I don't think she's going to tell me she's not rampaging enough now.
[cpg]


;//[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte040"]
[OnName num="charlotte"]
Can I come in to ......?"
[cpg cn=true]


Charlotte asks, and I reply.
[cpg]


[OnName num="itsuki"]
Ah... come in."
[cpg cn=true]

[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
I let Charlotte, who has a serious look on her face, up to my room.
[cpg]


I'm the only one in the room at the inn, as I always am.
[cpg]


Because I'm a guy. I'm a guy. Girls sometimes stay in the same room with me.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
While I was thinking like that, Charlotte came strangely close to me.
[cpg]


She was a little too close to me sitting on the bed.
[cpg]


She looks like she wants to kiss me, but her expression is not like that.
[cpg]


In fact, it was the exact opposite. It's like she's trying to put up another fight.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte041"]
[OnName num="charlotte"]
......"
[cpg cn=true]


I couldn't stand the silence any longer.
[cpg]


[OnName num="itsuki"]
"......What the hell? Don't shut up."
[cpg cn=true]


Yeah ......," Charlotte said, neither closing the distance nor letting go.
[cpg]


[OnName num="itsuki"]
What's wrong?"
[cpg cn=true]


I decided to ask her directly.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte042"]
[OnName num="charlotte"]
I'm not convinced yet.
[cpg cn=true]


Convinced. I see, so that's what they're talking about.
[cpg]


Then I could understand the look on her face when she was about to challenge me to a fight.
[cpg]


[OnName num="itsuki"]
When you say convinced, do you mean during the day?
[cpg cn=true]


Charlotte nodded.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte043"]
[OnName num="charlotte"]
Yes, that's right. I can't be convinced so easily.
[cpg cn=true]


That's true.
[cpg]


Charlotte's character, and also the race of Dragonute.
[cpg]


 It might just be that he, who seems to be an Elder, is special.
[cpg]


Anyway, Charlotte seems to want to win the game in some way.
[cpg]


However, I can't go wild in the inn, and I still don't agree with the idea of talking to each other with my fists.
[cpg]


If it were between men, I would understand. But I still don't want to do it if I can help it.
[cpg]


[OnName num="itsuki"]
But even if you say so,.......
[cpg cn=true]


Charlotte is as close as ever.
[cpg]


 I didn't know what to do and was confused.
[cpg]


[OnName num="itsuki"]
I don't care how many times you say it, I'm not going to raise my hand to you.
[cpg cn=true]


Why not?　Charlotte asked.
[cpg]


[OnName num="itsuki"]
I'm not going to raise my hand to you, no matter how many times you tell me not to.
[cpg cn=true]


Charlotte still won't let go of this distance.
[cpg]


I'm in trouble. What should I do?
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte044"]
[OnName num="charlotte"]
So I'll settle it my way.
[cpg cn=true]

[SE f="se011"]
;//【ＳＥ】『ドサッ』


While I was thinking about that, she suddenly brought her face close to mine.
[cpg]


No, rather than that, what am I being made to do?
[cpg]


I was wondering what Charlotte was thinking, and then she started to laugh.
[cpg]


It was a devilish smile, too.
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte045"]
[OnName num="charlotte"]
Fufufu♪"
[cpg cn=true]


Charlotte closes the distance between us further with a smile.
[cpg]


I'm going to settle this my way, she said.
[cpg]


I don't think that's possible, but I don't think so. ......
[cpg]


[OnName num="itsuki"]
What are you ...... doing?
[cpg cn=true]


I'm aware of it, but I can't make the connection somewhere.
[cpg]


Charlotte is that type of person? I couldn't even imagine it.
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Charlotte046"]
[OnName num="charlotte"]
 "If you say you can't fight because you're a woman...I'll challenge you to a fight that you can do because you're a woman."
[cpg cn=true]



While I was thinking about this and that, Charlotte made a declaration.
[cpg]


It was a one-sided declaration. I think there's a better way to say that too.
[cpg]


[OnName num="itsuki"]
What?
[cpg cn=true]


I stopped thinking for a moment. There was a time lag before I realized what he meant.
[cpg]


I knew what it meant, but I couldn't make the connection. I could only say that. For example, I know that Hermia is aggressive.
[cpg]


But I never dreamed that Charlotte would do something like this.
[cpg]


While I was thinking that, Charlotte comes close enough to kiss me.
[cpg]


I push her back with my hand. As soon as I do so, she says, "Why?
[cpg]


[OnName num="itsuki"]
Eh, that ...... seriously?"
[cpg cn=true]


My mouth starts to say "eh," "um," and "seriously?" come out of my mouth.
[cpg]


I can see myself getting confused. In response to that, he says
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte047"]
[OnName num="charlotte"]
I'm serious.
[cpg cn=true]


Charlotte's eyes were serious, as if she had found her prey.
[cpg]


I thought this was a bad idea. I knew this was a bad idea.
[cpg]


[OnName num="itsuki"]
No, no,......, you can do something else if you want to win the game.
[cpg cn=true]


I said that, and tried to refuse somehow.
[cpg]


[OnName num="itsuki"]
I'd better take better care of myself..."
[cpg cn=true]


The only person who can really do that is the person you love.
[cpg]


Or does Charlotte say she likes me?
[cpg]


No, could that happen too ......?　I don't know anymore.
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte048"]
[OnName num="charlotte"]
I've put up with a lot of embarrassment and came all this way...! I'm not going to fight even with this...?
[cpg cn=true]


Charlotte said such a thing, and her face turned red as she moved away a little.
[cpg]


The actuality of the fact that the particulars are not really a lot of.
[cpg]


Charlotte has this kind of place, doesn't she?
[cpg]


The gap is great because he originally has a sexy look, or rather a mature look.
[cpg]


I think she is aware of it, but she must be a natural.
[cpg]


I don't think she's a natural, either.
[cpg]


I think she's a fascinating person. Not a person, but a dragonet.
[cpg]


She has a cute side and a strong core.
[cpg]


I found myself thinking ...... that it would be okay to be swept away here.
[cpg]


Charlotte is still angry. I think it's only natural. ......
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte049"]
[OnName num="charlotte"]
"Muuuuuuhhhh..."
[cpg cn=true]


I can't help but laugh. I wonder if it's a little rude.
[cpg]


[OnName num="itsuki"]
'Pfft. Ha ha ha! I'll take that match. I'll take that match.
[cpg cn=true]


I decided to accept the match with Charlotte.
[cpg]


When I answered, she brightened her face and wagged her tail.
[cpg]


She looks more like a dog than a dragon.
[cpg]


It's really cute,......, and I was starting to get into the mood.
[cpg]


Charlotte approaches me once more, stripping off her clothes.
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte050"]
[OnName num="charlotte"]
'You should have said so from the start! Hmph... be prepared."
[cpg cn=true]


Saying that, she kissed me.
[cpg]


When she kissed me, she closed her eyes and made an expression she had never shown before, which made me nervous.
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//========================================
;//●ＣＧ（キス。目を閉じているヒロイン）ev_12
;//人物１：ヒロイン５
;//服装１：着衣
;//人物２：主人公
;//服装２：旅人服
;//場所　：宿の一室
;//時間　：夜
;//備考　：ラフ05.jpgのシーンです
;//========================================


[BGM f="bg_h1"]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Charlotte051"]
[OnName num="charlotte"]
'Nn...... fufufu...'
[cpg cn=true]


I put my lips on hers. The breath hitting me feels indescribable.
[cpg]

I felt like I couldn't move and kept kissing her.
[cpg]

However, it was Charlotte who first let go of my lips.
[cpg]

[VOICE f="Charlotte052"]
[OnName num="charlotte"]
'Haaah ......!　Maybe I don't know how to breathe while we're kissing."
[cpg cn=true]


I thought she was supposed to do it through her nose, but I didn't tell her that.
[cpg]


;//ブラックアウト

;//ブラックアウト


;//========================================
;//●ＣＧ（キスの後、誘惑するようなヒロイン）ev_13
;//人物１：ヒロイン５
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：宿の一室
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_13_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]


That's how we ended up kissing for the first time.
[cpg]

It was a happy time,...... we were filling each other up.
[cpg]


Charlotte still did not leave, leaving an awkward feeling.
[cpg]

[VOICE f="Charlotte053"]
[OnName num="charlotte"]
She said, "Hey. Don't you do anything else?"
[cpg cn=true]


[OnName num="itsuki"]
I don't do ......."
[cpg cn=true]


I answered that, although I was unsure about it. The mission to save the world comes first.
[cpg]


The most important thing to remember is that you can't just take a chance on a new person and expect them to do the same for you.
[cpg]


The most important thing to remember is that you should never be afraid to ask for help.
[cpg]


No, if she wasn't good, she wouldn't have come at me.
[cpg]


I wonder how she will treat me tomorrow morning when I imagine .......
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m2"]
[WAIT time=100]
;//【ＢＧ】『ドラゴンの住処』（昼）******************************************************


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte054"]
[OnName num="charlotte"]
It~tsu~ki~!"
[cpg cn=true]


Charlotte was no longer hiding her fondness for me.
[cpg]


[OnName num="itsuki"]
She was attached to me and wouldn't move away from me. ......
[cpg cn=true]


She stuck to me and didn't move away. Charlotte has been sticking with me since this morning.
[cpg]


It is like saying, "Something happened last night.
[cpg]


[OnName num="itsuki"]
No, no, it's just that ......
[cpg cn=true]


I try to say something like that to explain myself, but it doesn't seem to make much sense.
[cpg]


[free time=1000]

There were a variety of reactions around me.
[cpg]

[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="1/3" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="3/3" time=800]


Ariel looks a little sad. Mercurio is smiling and Ritul is blatantly jealous.
[cpg]


Charlotte is still attached to me.
[cpg]


She won't let go of me. To us, Mercurio said this.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="1/3" time=800]
[VOICE f="Mercurio090"]
[OnName num="mercurio"]
You like scales, don't you?
[cpg cn=true]


What is this hobby of yours?
[cpg]


It's not that I'm offended, but it's just too maniacal for me to understand.
[cpg]


But Charlotte is exquisitely inhuman, isn't she?
[cpg]


That's what makes her so cute. Does that also mean that you like scales or something like that ......?
[cpg]


[free time=1000]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Charlotte055"]
[OnName num="charlotte"]
'There's no comparison between mermaid scales and dragonscale, is there? Hmph."
[cpg cn=true]


Charlotte says so triumphantly.
[cpg]


I don't think it's a match for that kind of place, but ...... well, that's okay.
[cpg]


[OnName num="itsuki"]
Ha, ha ...... Mercurio, sorry if I offended you."
[cpg cn=true]

[FG f="CHA06_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
Mercurio laughs, shaking his head.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Littule114"]
[OnName num="littule"]
It's not fair! The tree is going to be my husband! Get your hands off me!
[cpg cn=true]


What...I've never heard of that story either....
[cpg]

[FG f="CHA02_p3_02_a.ui" method="change_3"  pos="2/2" time=800]
I thought, but then Ritul grabbed my left arm.
[cpg]


Charlotte is hugging my right arm, so ......
[cpg]


;//[t_move pos=L 引き左]
;//[t_move pos=R 引き右]



It is a form of being pulled from both sides. It could be said to be a flower in both hands.
[cpg]

[SE f="se084"]
;//【ＳＥ】『引っ張る』

[OnName num="itsuki"]
I said to myself, "Ouch, ouch, ouch!"
[cpg cn=true]


I couldn't help but say so. I am not a thing.
[cpg]


It's not like I was forcibly pulled down to become someone else's property.
[cpg]


I thought so, but neither Charlotte nor Ritul seemed to back down even a step.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="1/2" time=800]

;//[t_move pos=L end]
;//[t_move pos=R end]
;//[t_move pos=L 引き左]
;//[t_move pos=R 引き右]

[VOICE f="Charlotte056"]
[OnName num="charlotte"]
It's already my turn! Let go of me, you too!
[cpg cn=true]


Charlotte was also pulling me along in a flirtatious manner.
[cpg]


;//[t_move pos=L 引き左]
;//[t_move pos=R 引き右]

;//[t_move pos=L end]
;//[t_move pos=R end]


[free time=1000]

I glanced over and saw Ariel.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel202"]
[OnName num="ariel"]
......"
[cpg cn=true]


Ariel looked a little sad.
[cpg]


I was wondering if she was thinking about me or not.
[cpg]


How popular is she, I thought to myself. ......
[cpg]


[OnName num="itsuki"]
Oh, Ariel...help me."
[cpg cn=true]


I said like that to get her to help me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ariel203"]
[OnName num="ariel"]
'Yes. When you get sick of Charlotte-san... please come to me."
[cpg cn=true]


No, it's not that kind of forward-looking help.
[cpg]


It's like Ariel hasn't given up at all, that's what I'm getting at.
[cpg]


But I felt so much like Charlotte was the only one for me.
[cpg]


[free time=1000]

I'm sorry to Ritul and Ariel, but I don't think that's going to change.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte057"]
[OnName num="charlotte"]
'What the hell, all of you! I won't let you go~!"
[cpg cn=true]


Charlotte pulls even more.
[cpg]


There was something like this, wasn't there? The Oooka Judgment, right?
[cpg]


But they pull at each other without giving each other a single step.
[cpg]


[OnName num="itsuki"]
It's like, "Oida-da-da-da-da-da! Break, break, break."
[cpg cn=true]


I was taken on with such force that it might affect my future fights.
[cpg]


[free time=1000]

Mercurio is smiling in his usual mood.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mercurio091"]
[OnName num="mercurio"]
Oh dear."
[cpg cn=true]


It's not oh dear, if Ariel won't help me, Mercurio will. ......
[cpg]


What a thought, Ariel said to me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="3/3" time=800]

[VOICE f="Ariel204"]
[OnName num="ariel"]
I teased you a little too much, didn't I?"
[cpg cn=true]

[VOICE f="Littule115"]
[OnName num="littule"]
"Garurururu~~"
[cpg cn=true]


Ritul is getting pretty ferocious.
[cpg]


I guess he thought Charlotte would take me.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mercurio092"]
[OnName num="mercurio"]
How dare you?"
[cpg cn=true]


Mercurio calmed him down and I was finally released.
[cpg]


I was worried about the future.
[cpg]


Charlotte and I are both being celebrated in a way.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Then ......
[cpg]


We visited the vampire's abode.
[cpg]


We went to the vampire's abode to settle the issue of poaching mermaids.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************


After all, that's what we were there for in the first place.
[cpg]


Remembering that, we headed there.
[cpg]


We have the tools to find out where the vampires live.
[cpg]


We were ready to go. We were ready to go when we arrived at the vampire's place.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『エウルアウレア・暗闇の街』（夜）******************************************************

Finally, we arrived at the city of darkness.
[cpg]


We asked the vampire directly, but he didn't give us any answer.
[cpg]


It seems there is an acquaintance of Hermia's, so we left the investigation to her. ......
[cpg]


We probably waited for about three days. Then, on the morning of the fourth day, ...... or is it night?
[cpg]


I think it must be peculiar to this city that the sun doesn't shine all the time, so it's hard to discern the time.
[cpg]


In any case, Hermia called us out.
[cpg]


We are on our way to her.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『エウルアウレア・暗闇の街』（夜）******************************************************


[OnName num="vampire_woman"]
I apologize deeply for the poaching of the Mermaid tribe, and thank you for your cooperation. I also appreciate your cooperation.
[cpg cn=true]


And then we came to a conclusion. The vampire woman bows her head.
[cpg]


In short, it became clear that the vampire had done it.
[cpg]


I felt sorry for her, thinking that I knew it was so.
[cpg]


[OnName num="vampire_woman"]
'I never thought...that my people had done this...'
[cpg cn=true]


It all depends on what Mercurio thinks about this one.
[cpg]


;//だけど、メルクーリオは気性が荒い人ではなかった。[cpg]


[free time=1000]


[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="2/2" time=800]

But Mercurio says, calmly, "It's not everyone's fault."
[cpg]

;//[OnName num="vampire_woman"]「貴方が直接したわけじゃないでしょう。皆が悪いわけでは無いですから」[cpg cn=true]

She says so calmly. I'm glad she has a gentle disposition.
[cpg]


And Charlotte interrupts her and says, "I don't know if you can call them a family.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Charlotte058"]
[OnName num="charlotte"]
Charlotte interrupts and says, "Even though we are a family, we are not monolithic. My family is not monolithic either.
[cpg cn=true]


Charlotte's way of following up. She is also a kind person after all.
[cpg]


I am also attracted to that.
[cpg]


Then the vampire raised his head and made a proposal to Mercurio.
[cpg]



[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[OnName num="vampire_woman"]
I don't know if it will atone for my sins, but... we will fully support the restoration of the Mermaid tribe."
[cpg cn=true]


She felt guilty to that extent. Mercurio said that she was not responsible for this.
[cpg]

I guess vampire women are also kind at heart. ......
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mercurio093"]
[OnName num="mercurio"]
Thank you very much. It helps a lot."
[cpg cn=true]


Mercurio also returned it politely.
[cpg]


[OnName num="vampire_woman"]
Thank you....even though it was all caused by us..."
[cpg cn=true]


Anyway, it looks like we're on our way to a solution now.
[cpg]


Now that everything is out in the open, I don't think the vampires will be poaching again.
[cpg]


[free time=1000]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Elmyr102"]
[OnName num="elmyr"]
Well, it's resolved, so why not?"
[cpg cn=true]


In the midst of all this, Hermia says something plausible.
[cpg]


It doesn't matter if she apologizes here and now.
[cpg]


Instead, we have to move on.
[cpg]


The mermaid poaching thing has been resolved.
[cpg]


[free time=1000]

They were manipulating humans to think it was the work of men, but it seems the mastermind was a vampire.
[cpg]


Now that we know that much, there are no more problems.
[cpg]


The humans were bound to stop poaching, along with them.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Now that the problem was solved, it was time to take down the evil gods.
[cpg]


We were tired of resting in the city.
[cpg]


We had plenty of energy. We were strong enough to leave as we were.
[cpg]


So we headed for the location of the evil god.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_fi"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************

[SE f="se015"]
;//【ＳＥ】『剣戟』


[OnName num="itsuki"]
Damn...there are so many!
[cpg cn=true]


I was facing so many enemies that I wondered if I should release more of my skills.
[cpg]


The other two are also fighting back,......, but I don't know how much longer I can fight them.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Littule116"]
[OnName num="littule"]
There are more and more of them!"
[cpg cn=true]


Ritul is losing a lot of strength.
[cpg]


The actuality that the movement was slowing down was evident even from a distance.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/3" time=800]
[VOICE f="Ariel205"]
[OnName num="ariel"]
Everyone, stay close!
[cpg cn=true]


Ariel gave instructions to each of them as if she was in command.
[cpg]


But Charlotte didn't listen and rushed forward.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_3"  pos="3/3" time=800]
;//[t_move pos=C 下礼]
[VOICE f="Charlotte059"]
[OnName num="charlotte"]
I'm going to kick the crap out of these people!
[cpg cn=true]


This is not good. No matter how strong she is, ......
[cpg]


I think it's tough against this number of people. I try to stop her.
[cpg]


[OnName num="itsuki"]
"Wait, Char! Don't go in alone!
[cpg cn=true]


But Charlotte didn't listen to my words and went in.
[cpg]


[free time=1000]


Did she want to look good in front of me?
[cpg]


Either way, it was backfiring.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte060"]
[OnName num="charlotte"]
Yaaaaaaaaaaaah!"
[cpg cn=true]

[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1000]
;//ホワイトアウト


We were all together and set out to defeat the evil gods.
[cpg]


However, things did not go so easily.
[cpg]


As we got closer to the evil god, we had more and more battles with more and more powerful demons.
[cpg]


Combined with the evil god's miasma, the battle against the demons became more and more severe.
[cpg]



;//ブラックアウト

;//////////////////////
;//ヒロイン5に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_ne"]
[WAIT time=100]


[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte061"]
[OnName num="charlotte"]
"N...... u...... this place is..."
[cpg cn=true]


[OnName num="oak"]
"Oh, you're awake! You're awake!
[cpg cn=true]


You're restrained so that you can't move. I thought about tearing them apart, but I couldn't.
[cpg]


I was apparently being held captive by an orc, which is a lower class demon.
[cpg]


Normally, I would not have been defeated by a weak demon like an orc.
[cpg]


I had defeated many of them before. I had never lost to them even if they were all together.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte062"]
[OnName num="charlotte"]
How could I have lost?
[cpg cn=true]


I was not the one to lose.
[cpg]


[OnName num="oak"]
I'm going to be very loving to you from now on. I'm going to take good care of you from now on.
[cpg cn=true]


I thought about it. Why couldn't I be in good form?
[cpg]


[OnName num="oak"]
"But still, how could you try to force them to fight against this number?"
[cpg cn=true]


Yes, that's right. I ran into a group of orcs, and then ......
[cpg]


The most important thing to remember is that the best way to get the most out of your car is to make sure that it is not a problem for you.
[cpg]


There may have been a difference between the evil god's miasma and simple numbers, but ......
[cpg]


But still, I couldn't admit defeat.
[cpg]


;//========================================
;//●ＣＧ（オークに襲われるヒロイン）ev_30
;//人物１：ヒロイン５
;//服装１：着衣
;//人物２：オーク
;//服装２：無し
;//場所　：オークのねぐら
;//時間　：
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="oak"]
Now, how can I taste it?"
[cpg cn=true]


[VOICE f="Charlotte063"]
[OnName num="charlotte"]
The most important thing to remember is that you can't just take a chance on a newbie. I was trying to show him how good looking I was, and I felt like an idiot..." I regretted it, but I didn't want to do it again.
[cpg cn=true]


I regretted it, but it was too late for anything else.
[cpg]


And then the orc comes closer. I refuse.
[cpg]

;**【ＣＧ】 ev_30_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Charlotte064"]
[OnName num="charlotte"]
Don't come here, you filthy orcs! I will tear your ugly faces off!
[cpg cn=true]


I tried to scare him as much as I could, but it didn't seem to have much effect.
[cpg]


[OnName num="oak"]
I'm not afraid of you, you little bitch! I don't mind a bitch like that.
[cpg cn=true]


[VOICE f="Charlotte065"]
[OnName num="charlotte"]
Don't...don't...don't...come...oh no!
[cpg cn=true]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


It has been quite some time since I was captured.
[cpg]


The tree, however, seemed to have not given up.
[cpg]


[OnName num="itsuki"]
"Charles, are you safe?
[cpg cn=true]


I heard his voice. At that moment, I was about to cry.
[cpg]


But I couldn't stay crying. I had to run away.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Charlotte066"]
[OnName num="charlotte"]
"Hey, Tree...did you come to save me?"
[cpg cn=true]

I asked him. He nodded and grabbed my hand.
[cpg]


[OnName num="itsuki"]
Of course," I said, "I'm here to help you. Come on, let's get out of here!
[cpg cn=true]


His hand was warm. I felt a soft, inexpressible emotion welling up inside me.
[cpg]


Oh my God, I must be in love.
[cpg]


That's why I can't be just another useless person.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte067"]
[OnName num="charlotte"]
"Uh-huh!
[cpg cn=true]


This is not good. I've been dragging ...... the tree down.
[cpg]


I want to fight more for the tree. But that feeling is what got me into this mess.
[cpg]


I was useless as a dragonut.
[cpg]


The strongest race. Next to the tree, I thought I was the strongest.
[cpg]


In the end, I was useless. I can't be proud to be the tree's lover.
[cpg]


That's why ...... I want to be useful to the tree from now on.
[cpg]


To be useful, I have to be. ......
[cpg]


The most important thing to remember is that you can't just go out and buy a new car.
[cpg]


The first thing to do is to get a good look at the picture. I'm sorry, tree," he said.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
;//[t_move pos=C 溜息]
[VOICE f="Charlotte068"]
[OnName num="charlotte"]
Tree, I'm sorry...I..."
[cpg cn=true]


I'm sorry...I..." I'm sure he knows what happened to me.
[cpg]


I was so afraid that he might not like me.
[cpg]


I was just that excited, but...
[cpg]


[OnName num="itsuki"]
No, it's okay. It must have been difficult for you too.
[cpg cn=true]


He just forgave me. I was just reckless and got caught.
[cpg]


He forgives me for my recklessness and getting caught.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte069"]
[OnName num="charlotte"]
I'm sorry, I'm sorry...I'm sorry ...... I'm ......
[cpg cn=true]


[OnName num="itsuki"]
Char...I love you."
[cpg cn=true]


The tree whispers words of love to me at times like this.
[cpg]


I can't help but think ...... nothing of this.
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Charlotte070"]
[OnName num="charlotte"]
I love you too,......," he said.
[cpg cn=true]


The most important thing to remember is that you should not say these things at a time like this.
[cpg]


The most important thing to remember is that you can't just say "I love you" and expect to be loved.
[cpg]


;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************


 I wondered what would happen if Charlotte was kidnapped by an Ork, but I managed to rescue her.
[cpg]


It is impossible not to imagine what was happening behind the scenes of .......
[cpg]


But I didn't have time to get caught up in that now.
[cpg]


After passing the home of the orcs and fending off more demons... we came to the evil god.
[cpg]


The floating city of realm realm. We were about to reach there.
[cpg]


We released our magic skills and flew through the air to the floating city.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『浮遊都市レルムレルム』（夜）******************************************************

[SE f="se015"]
;//【ＳＥ】『剣戟』


The area near the evil god was full of ferocious monsters.
[cpg]


Monsters that we had never seen on our journey up to this point, monsters that looked like they were a combination of demons and monsters.
[cpg]


I had to fight them off. I had my friends with me, and I knew there was nothing I couldn't do.
[cpg]


Finally, I reach ....... The figure of the evil god can be seen in the distance.
[cpg]


It's finally time. Time to settle everything.
[cpg]


It's been a long journey, but it's over.
[cpg]


[OnName num="itsuki"]
"Teyaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa!"
[cpg cn=true]


[SE f="se015"]
;//【ＳＥ】『剣戟』

He swung his sword at the towering wall-like evil god.
[cpg]


Releasing the power of his skills to the utmost, he tries to smash the evil god.
[cpg]


Of course, one blow didn't help.
[cpg]


In the meantime, another demon also appears. Charlotte and Ritul had defeated them.
[cpg]


I became desperate, and as I struck my sword again and again, ......
[cpg]



With a loud sound and a tremor of the earth, the evil god collapsed.
[cpg]

[STOPBGM]
[SE f="se142"]
;//【ＳＥ】『邪神倒れる』
[WAIT time=1500]

;//[fadeoutbgm]
It was the moment the long battle was ...... finally over.
[cpg]


;//[STOPBGM]
[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1000]
;//ホワイトアウト


At ...... last. Finally I can go back to reality.
[cpg]


But even while thinking that,......
[cpg]


I was wondering if that was really the right thing to do.　Somewhere I was thinking, "Is that really what I want?
[cpg]


[STOPBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


Peace has been restored to the world.
[cpg]


What can I say, but there was not a big visible change all at once.
[cpg]


However, it seems that the power of demons is weakening all over the world.
[cpg]


I was deeply moved that I had really accomplished what I needed to do.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel206"]
[OnName num="ariel"]
"Tree-sama, are you sure...it's okay?"
[cpg cn=true]


And Ariel says so.
[cpg]


Because I had expressed one intention.
[cpg]


[OnName num="itsuki"]
Yes, I'm staying here.
[cpg cn=true]


In the first place, I am not a resident of this world.
[cpg]


I'm not a resident of this world to begin with.
[cpg]


I had defeated the evil gods and fulfilled my duty as a brave warrior.
[cpg]


So I can return to the other world as I promised.
[cpg]


[OnName num="itsuki"]
But I can't just come and go as I please, can I? Then I will stay here.
[cpg cn=true]


Charlotte, too, had been thinking about this for a long time.
[cpg]


She must have been thinking about what would happen if I went back to the other world.
[cpg]


But I won't let her worry about that anymore. I've made up my mind.
[cpg]


[OnName num="itsuki"]
I still want to go back, but I have something important here, too.
[cpg cn=true]


[free time=1000]

Above all, I have found someone I love.
[cpg]


I can't leave without her. I can't leave without her.
[cpg]


I thought so and looked at Charlotte.
[cpg]



[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Charlotte071"]
[OnName num="charlotte"]
"Itsuki..."
[cpg cn=true]


Her eyes are moist. She's really cute.
[cpg]


I'm sure that just meeting her is the reason why I came to this world.
[cpg]


[FACE method="change_2" pos="1/2"]
[VOICE f="Ariel207"]
[OnName num="ariel"]
I understand. If you need anything, you can always count on me. I will help you."
[cpg cn=true]


Ariel also said that to me.
[cpg]


[OnName num="itsuki"]
Thank you. You're a big help.
[cpg cn=true]


But I probably won't need Ariel's help.
[cpg]


In a world where peace has been restored, Charlotte and I will live happily ever after.
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="Ariel208"]
[OnName num="ariel"]
It is we who should thank you." Thank you, Itsuki. For restoring peace to the world..."
[cpg cn=true]


[OnName num="itsuki"]
I'm embarrassed to be thanked so many times. ......
[cpg cn=true]


I scratch my head. The most important thing to remember is that you can't just take a chance on a new product or service and expect it to work.
[cpg]


[FACE method="change_2" pos="2/2"]
[VOICE f="Charlotte072"]
[OnName num="charlotte"]
I'll take good care of you.
[cpg cn=true]


I'm from a different world, so I'm sure I'm not mistaken,.......
[cpg]


[OnName num="itsuki"]
I'm from a different world, so I'm sure I'm not mistaken.
[cpg cn=true]


 When I said that, Charlotte puffed up her face in dissatisfaction.
[cpg]


[FACE method="change_3" pos="2/2"]
[VOICE f="Charlotte073"]
[OnName num="charlotte"]
Why not!"
[cpg cn=true]


Ariel was laughing at us.
[cpg]


No, it's not just Ariel. Charlotte and I both found ourselves laughing as well.
[cpg]


[FACE method="change_2" pos="1/2"]
[VOICE f="Ariel209"]
[OnName num="ariel"]
"Hmph!
[cpg cn=true]


[OnName num="itsuki"]
"Ha-ha-ha."
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Charlotte074"]
[OnName num="charlotte"]
"Giggle."
[cpg cn=true]


There is no more anxiety. Peace has been restored to the world.
[cpg]


From now on, I won't be going out on an adventurous journey with Charlotte.
[cpg]


Then I might as well stay in one place.
[cpg]


In this other world, as a brave man after saving the world ......
[cpg]


Or as the only human being. From now on, I will build a happy family with her.
[cpg]


Maybe that's all right for a while.
[cpg]


;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************


And we decided to go back to Charlotte's hometown.
[cpg]


Because we had a certain purpose.
[cpg]


It was something we could only do in Charlotte's hometown. It's okay to say it's okay to do it in those cities, but ......
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ドラゴンの住処』（昼）******************************************************


We were going to get married.
[cpg]


Her mother and father, who are both Dragonites, gave their blessing.
[cpg]


As you can imagine, or rather, her father's side was strict, but ......
[cpg]


Her mom was a lot more helpful.
[cpg]


I don't think any of this would have been possible if I hadn't been the brave man who saved the world.
[cpg]


Charlotte looked great in her wedding dress.
[cpg]


I will never forget this scene.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『ドラゴンの住処』（夕方）******************************************************


After that, I lived for a while in the place where the dragons lived.
[cpg]


There was no inconvenience in most things.
[cpg]


People were kind to me, even though I was of a different race. ......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ドラゴンの住処』（夜）******************************************************


But behind the scenes, shadows were eating away at us.
[cpg]

I had never seen the skill ...... called "disconnection," and I didn't even know when it came about.
[cpg]

I looked it up and found out what it was. The one with this skill ......
[cpg]

It was the inability to have children.
[cpg]

;//////////////////////
;//ヒロイン5視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]



;//ブラックアウト

;//////////////////////
;//ヒロイン視点切り替わり
;//////////////////////

Perhaps as a compensation for the skill of defeating the evil gods, I could no longer have children with the tree.
[cpg]



I decided to do something about it and looked around for a solution.
[cpg]



[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『エウルアウレア・暗闇の街』（夜）******************************************************


First of all, I went to the vampire who seemed to know more about curses than magic .......
[cpg]


The compass was originally handed down to the dragon tribe. If I wanted to use it, I could.
[cpg]


Then I visited the vampire's place: ......
[cpg]

I didn't get any useful information from the vampire, but ......
[cpg]


I was told that Hermia might be able to tell me something. I might be right.
[cpg]


Curses are something that might have something to do with dark elves.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


I met up with Hermia in a certain town.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Elmyr103"]
[OnName num="elmyr"]
It's been a long time, Charlotte. Charlotte. I didn't expect to hear from you.
[cpg cn=true]


Hermia said something like that. But I feel the same way.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Charlotte075"]
[OnName num="charlotte"]
I didn't think I'd be asking Hermia for a favor either.
[cpg cn=true]


Seeing my serious face, Hermia also looks serious.
[cpg]


I wonder if it's okay to tell Hermia everything. Can I really trust her?
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Elmyr104"]
[OnName num="elmyr"]
So, what's up?"
[cpg cn=true]


There's no need to hesitate now. I'm going to start clutching at straws.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Charlotte076"]
[OnName num="charlotte"]
I told her everything.
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I told him everything.
[cpg]


The tree might not like to be told, but I couldn't even think about it.
[cpg]


And after hearing everything, ......
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Elmyr105"]
[OnName num="elmyr"]
I see..."
[cpg cn=true]


The most important thing to remember is that the best way to get the most out of your money is to be honest with yourself.
[cpg]


I wonder if you have any idea. If you have, I want you to tell me right away.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Charlotte077"]
[OnName num="charlotte"]
Please! If you know someone who knows how to break the curse or someone who knows how to break the curse, please tell me..."
[cpg cn=true]


I pleaded with him. In this situation, Hermia is the only one I can rely on.
[cpg]


Mercurio and Ariel also seem to be familiar with magic, but I don't know if they are familiar with curses or not.
[cpg]


Ritul would not be able to use magic in the first place. ......
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Charlotte078"]
[OnName num="charlotte"]
If this is the case, me and the tree will ......
[cpg cn=true]


Hermia thought for a moment, then nodded.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Elmyr106"]
[OnName num="elmyr"]
I understand.
[cpg cn=true]


[FG f="CHA05_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Charlotte079"]
[OnName num="charlotte"]
Really?
[cpg cn=true]


I couldn't help but yell out.
[cpg]


Hermia was a little surprised, but continued to speak.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Elmyr107"]
[OnName num="elmyr"]
I don't know much about that side of things, but I'm sure I know someone who does. I'll write you a letter of introduction, and you can go to my hometown.
[cpg cn=true]


It seemed that Hermia herself was not familiar with curses.
[cpg]


So, of course, it can't be lifted. But ......
[cpg]


The mere fact that she knew someone who knew someone who knew someone who knew someone who knew someone who knew someone who knew someone who knew someone who knew someone who knew someone.
[cpg]


I don't know where Hermia's acquaintances are, but ......
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Charlotte080"]
[OnName num="charlotte"]
Oh, thank you! I owe you!"
[cpg cn=true]


I smiled at Hermia. Hermia smiled a little too.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Elmyr108"]
[OnName num="elmyr"]
I'm glad you're here," she said. We've traveled together, and it's not like I don't like you.
[cpg cn=true]


I see. I thought it was just me and the tree, but it's not.
[cpg]


I have friends. I was so happy to have such a feeling.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
;//[t_move pos=C 下礼]
[VOICE f="Charlotte081"]
[OnName num="charlotte"]
Hermia~~~...... love you!
[cpg cn=true]


I hugged Hermia. The first thing to do is to make sure that you have the right tools to do the job.
[cpg]


The curse on the tree might be managed with this.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Elmyr109"]
[OnName num="elmyr"]
I'm not a cash cow," she said. If you're going to be a mother, you need to calm down a little bit more.
[cpg cn=true]


Oh, I see. If this goes well, I'm going to be a mother.
[cpg]


I hadn't thought about that at all.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Charlotte082"]
[OnName num="charlotte"]
Yes, I will try my best. Oh-ho-ho-ho!
[cpg cn=true]


I got excited and said something like that.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Elmyr110"]
[OnName num="elmyr"]
She said, "C'mon, you don't look good at all. What's that, it doesn't suit you at all.
[cpg cn=true]


Hermia laughed a little.
[cpg]


It's kind of nice. ...... I thought we were no longer involved in anything after the trip was over, but I was wrong.
[cpg]


This will break the curse of the tree. I set out in high spirits.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Hermia introduced me to a place called Berazaza, the home of the Dark Elves.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『ダークエルフの森』（昼）******************************************************


[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte083"]
[OnName num="charlotte"]
This is...Verrazaza.
[cpg cn=true]


What an eerie place. Hermia grew up in a place like this.
[cpg]


[OnName num="dark_elf_man"]
"Dragon people? What do you want here?"
[cpg cn=true]


A dark elf man, who seemed to be a resident, looked in my direction and spoke to me.
[cpg]


I didn't want to keep quiet. I picked up the letter of introduction.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte084"]
[OnName num="charlotte"]
I was introduced by Hermia.
[cpg cn=true]


I wondered if he knew Hermia's name.
[cpg]


When was the last time she was in this forest?
[cpg]


What if she says she doesn't know anyone like that? ......
[cpg]


With this anxiety in my mind, I hand the man the letter of introduction.
[cpg]


The person seemed to have read it right.
[cpg]


[OnName num="dark_elf_man"]
He said, "...... I see, I understand. It's me you're looking for."
[cpg cn=true]


What?　I said in a crazy voice.
[cpg]


[OnName num="crow"]
I'm Crow. Nice to meet you.
[cpg cn=true]


Crowe. I've been looking for him for a long time now.
[cpg]


The dark elf who knows a lot about curses ...... is kind of interesting and doesn't look like a person who has anything to do with such things.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte085"]
[OnName num="charlotte"]
Nice to meet you."
[cpg cn=true]


I bowed my head.
[cpg]


[OnName num="crow"]
I bowed and said, "Follow me. My house is just around the corner.
[cpg cn=true]


[OnName num="crow"]
I'll make you a cup of tea. I'll make you some tea.
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//上下に黒帯を入れてください


[SE f="se008"]
;//【ＳＥ】『ドア閉まる』


[FACE method="change_4" pos="2/3"]
[VOICE f="Charlotte086"]
[OnName num="charlotte"]
So... how do I break the curse?
[cpg cn=true]


I asked Crowe as soon as possible.
[cpg]


[OnName num="crow"]
I asked Crowe. There is a way.
[cpg cn=true]


I almost jumped out of my skin. I almost jumped out of my skin. I had never thought it would be so easy to get the answer I wanted.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Charlotte087"]
[OnName num="charlotte"]
Really? How? Please tell me!
[cpg cn=true]


I was so excited that I started shouting.
[cpg]


[OnName num="crow"]
You'd better calm down. Are you going to use it?
[cpg cn=true]


[OnName num="crow"]
I'm not going to be able to teach you how to do it. I don't know how long it would take you to learn how to ...... use it, but it would have to be done by a professional magician.
[cpg cn=true]


I was a little disappointed, but I hung on to the words, "There is such a thing.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte088"]
[OnName num="charlotte"]
Well, yes, but you can break the spell.
[cpg cn=true]


[OnName num="crow"]
I was disappointed, but he said, "Yes, but there is an antidote. Like the antidote, it should be possible to manage it with medicine.
[cpg cn=true]


[OnName num="crow"]
A curse is like a magically created disease. It just takes time.
[cpg cn=true]


Crow says so. I was clinging to the straw.
[cpg]


I could not stop just because it was going to take time.
[cpg]


I really wanted to be with the tree.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte089"]
[OnName num="charlotte"]
If you can heal me, I'd like to ask you to do it.
[cpg cn=true]


I asked him.
[cpg]


Crow then looked a little apologetic.
[cpg]


[OnName num="crow"]
And there's one more thing. It's a matter of money.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte090"]
[OnName num="charlotte"]
Oh, money..."
[cpg cn=true]


I have very little money on me. ......
[cpg]


The first thing to do is to make sure that you have a good idea of what you're getting into.
[cpg]


[OnName num="crow"]
It takes a lot of money to remove a single curse. I don't know how much or how many your husband has to pay, but it's a lot of money.
[cpg cn=true]


This is the same as time. I couldn't back down just because it cost money.
[cpg]


I really needed to get the medicine. ......
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte091"]
[OnName num="charlotte"]
I'll get you the money. Please."
[cpg cn=true]


Crowe took me at my word and said, "I'll take care of the money.
[cpg]


[OnName num="crow"]
I'll do the math,...... roughly, but I'll do the math.
[cpg cn=true]


The numbers he came up with were outrageous.
[cpg]


I can't pay ...... this kind of money.
[cpg]


How much would it take me to earn?　If I work like a normal person, it would take more than ten years.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
;//[t_move pos=C 動揺]
[VOICE f="Charlotte092"]
[OnName num="charlotte"]
"What...this much?
[cpg cn=true]


I was surprised.
[cpg]


And then Crowe said something like this.
[cpg]


[OnName num="crow"]
"If you're the brave man who saved the world... can you pay this much?"
[cpg cn=true]


The brave man who saved the world. There is no doubt about that.
[cpg]


But it's not very much.
[cpg]


[OnName num="crow"]
I know, right?
[cpg cn=true]


That's right. We didn't fight for money.
[cpg]


Even though we saved the world, it was almost like charity.
[cpg]


We were admired, but not financially enriched.
[cpg]


And Crowe is a brave man who saved the world just because he is ......
[cpg]


I was very nervous.
[cpg]


I'm in a hurry. The most important thing to remember is that you can't go home without anything.
[cpg]


But what should I do? ...... Will I have to go into debt or something?
[cpg]


The first thing to do is to make sure that you have a good idea of what you're getting into.
[cpg]


[OnName num="crow"]
I can't help it. Just give up."
[cpg cn=true]


It's easy to say. But for me and the tree, it's a big problem.
[cpg]


It's a big problem for both of us.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte093"]
[OnName num="charlotte"]
There's no way I can give up!
[cpg cn=true]


I said to him and pressed him. But Crowe was calm.
[cpg]


[OnName num="crow"]
Even if it's a loan, do you have anyone who can lend you this amount of money?
[cpg cn=true]


I was at a loss for words. It's a tremendous amount of money.
[cpg]


I couldn't immediately think of anyone to borrow it from.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte094"]
[OnName num="charlotte"]
I could ask one of my friends..."
[cpg cn=true]


[OnName num="crow"]
Is your friend that rich?
[cpg cn=true]


......Yes, that's right. That's right.
[cpg]


I can't rely on the family. If I tell them this story, they might dissolve my relationship with the tree.
[cpg]


I think it's only natural. I thought it was a bad idea to just bring it to light.
[cpg]


But I have friends.
[cpg]


Ariel, Ritul and Mercurio are all young ladies. I'm sure they'll give you some money .......
[cpg]


......I think about it. I wonder if that's a good thing.
[cpg]


We've traveled together, but are we friends?
[cpg]


Maybe we are friends. Friends who have fought for their lives together.
[cpg]


So I'm sure you can sympathize with me a little. ......
[cpg]


I guess you could say we took the tree from everyone.
[cpg]


Friends, I guess. ...... And suddenly asking for money. ......
[cpg]


I was in trouble. I've finally found a way to get better.
[cpg]


I can't just back out now.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte095"]
[OnName num="charlotte"]
"......."
[cpg cn=true]


Crowe crossed his arms. And then he opened his mouth.
[cpg]


[OnName num="crow"]
I have a proposal.
[cpg cn=true]


[FG f="CHA05_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte096"]
[OnName num="charlotte"]
What?"
[cpg cn=true]


I listened to him, wondering if there was any way to borrow money.
[cpg]


I was willing to accept any way.
[cpg]


[OnName num="crow"]
I would pay the money back little by little," he said. But in some lump sum, and on a regular basis."
[cpg cn=true]


......Something like that. If I could do that, I wouldn't have a hard time.
[cpg]


Or do you think you know how to do that?
[cpg]


It's not that easy.
[cpg]


[OnName num="crow"]
Don't be so alarmed. It's simple.
[cpg cn=true]


[OnName num="crow"]
How about you as collateral... yourself?"
[cpg cn=true]


I couldn't believe my ears.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Charlotte097"]
[OnName num="charlotte"]
I couldn't believe my ears.
[cpg cn=true]


Is Crowe serious?　I'm trying so hard to have a baby with him. ......
[cpg]


That's just the original plan, isn't it?
[cpg]


[OnName num="crow"]
I've always wanted a dragonut to work for me. They fetch a high price as a rarity."
[cpg cn=true]


Against my will, Crowe kept going on and on.
[cpg]


[OnName num="crow"]
Yes, and I'll pay you your fair share, too. "Yes, and you'll get your cut, and you'll pay off your debts twice or three times as fast as usual.
[cpg cn=true]


Crowe is being reckless. I know, I know, but it's just not right.
[cpg]


I know, but that doesn't mean ......
[cpg]


[OnName num="crow"]
I don't think I've ever had a better deal in my life. ......
[cpg cn=true]


It's a betrayal of the tree. It's not just betrayal.
[cpg]


It's not just betrayal, it's being held by someone other than him. It's not just betrayal, it's also being held by someone other than him.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte098"]
[OnName num="charlotte"]
"Kuku......"
[cpg cn=true]


I already fully understood what was being said.
[cpg]


The best way to do this is to get a good, clean, and healthy diet.
[cpg]


I'm not going to accept such a thing.
[cpg]


No matter how much the tree's curse can be lifted, this is too much. ......
[cpg]


[OnName num="crow"]
If you don't like it, then we won't talk about it this time."
[cpg cn=true]


...... but if you don't break the curse here.
[cpg]


If there are no children between me and the tree.
[cpg]


The family might break off the engagement. I don't want that.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte099"]
[OnName num="charlotte"]
Wait, wait, ...... wait!
[cpg cn=true]


I had no other choice.
[cpg]


I had nothing else to rely on.
[cpg]


I was on the verge of tears as I clung to Crowe.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte100"]
[OnName num="charlotte"]
Please,...... break the curse of the tree....
[cpg cn=true]


[OnName num="crow"]
You don't have to look so pained.
[cpg cn=true]


Even if you say that, I can't believe this isn't hard for you.
[cpg]


[OnName num="crow"]
I'll break the curse. It's give and take.
[cpg cn=true]


I couldn't back down now that I had come this far.
[cpg]


I had come this far ...... far, and I knew I had to do everything to save the tree.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
;//[t_move pos=C 動揺]
[VOICE f="Charlotte101"]
[OnName num="charlotte"]
I'm not just doing it for the tree.
[cpg cn=true]


The most important thing to remember is that you should never be afraid to ask for help.
[cpg]


The most important thing is that you should be able to see the difference between the two.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte102"]
[OnName num="charlotte"]
I'm sorry,...... but I'm sure I'm going to help you,.......
[cpg cn=true]


And ...... I accepted the proposal.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Charlotte has disappeared.
[cpg]


It was only after I told him that I would take care of my inability to do so.
[cpg]


You're doing something for me. Even though I know that. ......
[cpg]


My anxiety grew. I was worried that the demons would get her on the way.
[cpg]


I knew she was the only one who could do that, but I waited anxiously.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『ドラゴンの住処』（昼）******************************************************


[OnName num="itsuki"]
"Where have you been, Charlotte......!　I was worried about you.
[cpg cn=true]

[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

Charlotte looked tired.
[cpg]


And in her hand was a vial of medicine ......
[cpg]


[OnName num="itsuki"]
'You've been traveling all this time,...... to get this?'
[cpg cn=true]


Charlotte nodded.
[cpg]


She was traveling to break my curse.
[cpg]


I almost cried at her single-mindedness.
[cpg]


But I guess this will heal me. ...... From now on, I can finally live with Charlotte.
[cpg]


I thought so, and I lent my shoulder to the tired Charlotte and took her home.
[cpg]


I'm glad......this is the end of the matter.
[cpg]


;//[fadeoutbgm]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[STOPBGM]

At ...... least, that's what I thought.
[cpg]

;//////////////////////
;//ヒロイン5に視点切り替わり
;//////////////////////


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『ダークエルフの森』（昼）******************************************************


[FG f="CHA05_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
;//[t_move pos=C 下礼]
[VOICE f="Charlotte103"]
[OnName num="charlotte"]
What the hell is going on?"
[cpg cn=true]


I was furious and went to Crowe.
[cpg]


[OnName num="crow"]
What's all the racket?
[cpg cn=true]


Crowe looked at me without a hint of apology.
[cpg]


He could have guessed that I would be angry with him.
[cpg]


The medicine he had received had not lifted the curse.
[cpg]


He remained incapacitated. He didn't even seem to be getting better.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte104"]
[OnName num="charlotte"]
It's been a month, and the curse has not been lifted! What's going on?
[cpg cn=true]


I grabbed Crowe by the neck.
[cpg]


[OnName num="crow"]
I grabbed him by the neck. You're the one who should be worried if I'm in a bad mood.
[cpg cn=true]


He told me that, and I let go of his hand. ...... And then...
[cpg]


[OnName num="crow"]
And then, "Hmmm. This is more troublesome than I imagined.
[cpg cn=true]


Crowe said something like that.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte105"]
[OnName num="charlotte"]
I felt betrayed.
[cpg cn=true]


I felt betrayed. I had endured so much pain and suffering.
[cpg]


[OnName num="crow"]
"Hey, hey, hey. You're being rude. I'm surprised too.
[cpg cn=true]


But it seems that Crowe really didn't expect this.
[cpg]


[OnName num="crow"]
We're going to need stronger drugs...and more money.
[cpg cn=true]


[OnName num="crow"]
It's your choice from here on out. No, it's always been that way.
[cpg cn=true]


I had an inkling. The drug wasn't fake.
[cpg]

[FG f="CHA05_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
The curse is too strong. If it were more effective...
[cpg]


I demand it. But ......
[cpg]


The price was even higher. I can't afford it, but I can't afford it.
[cpg]


[OnName num="crow"]
What do you want?　Let me hear it from you.
[cpg cn=true]


I answered, trembling.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte106"]
[OnName num="charlotte"]
What do you want?
[cpg cn=true]


Crowe nodded. And then he said.
[cpg]


[OnName num="crow"]
I nodded, and said, "...... got it. I'll get it for you.
[cpg cn=true]


He was going to get me some medicine.
[cpg]


Now I ...... lose my freedom again.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte107"]
[OnName num="charlotte"]
"Damn ......, damn ......."
[cpg cn=true]


This is a betrayal. But if I stop this, there is no way for the tree to go back to the way it was.
[cpg]


[OnName num="crow"]
I have a store. You can work there.
[cpg cn=true]


[OnName num="crow"]
Girls like you come in here every once in a while. Of course, it's not just the curse of disconnection.
[cpg cn=true]


I listened to Crowe's words with a somewhat vacant mind.
[cpg]


[OnName num="crow"]
I heard Crowe's words with a somewhat vacant look on his face, "Maybe it's for a girl who was born with a curse on her leg that prevents her from walking, or maybe it's for her own curse.
[cpg cn=true]


[OnName num="crow"]
You should go for it, too. I'm here to help.
[cpg cn=true]


This dark elf named Crowe was ......
[cpg]


I really thought he was a horrible person. He sees others as nothing more than tools.
[cpg]



;//ブラックアウト

;//========================================
;//●ＣＧ（ベッドに座っているヒロイン。これからのことを示唆するような感じ）ev_34
;//人物１：ヒロイン５
;//服装１：着衣
;//人物２：男
;//服装２：着衣
;//場所　：
;//時間　：
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

I worked in a shady store run by Crowe.
[cpg]


As I worked there, my heart was slowly being corrupted.
[cpg]


All the girls around me seemed to have their hearts broken.
[cpg]


I thought some of them had a core, but they were all in despair.
[cpg]


I won't be like this. I wonder how long I can endure ...... with that in mind.
[cpg]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


I was still stuck in Crowe's clutches.
[cpg]


The fact that there is nothing from Crowe himself is also eerie.
[cpg]

It was as if he was really just using them to make money.
[cpg]

He said that dragonuts were rare and valuable. ......
[cpg]



Maybe he is long past that stage.
[cpg]


I work today, imagining such things.
[cpg]


[OnName num="woman_A"]
"You're always so cheerful, ......," he said.
[cpg cn=true]


[OnName num="woman_B"]
You look like you have some kind of hope. ......
[cpg cn=true]


It's obvious. I can't give in. When I respond like that.
[cpg]


[OnName num="woman_A"]
I envy you. I wonder if I ever had a time like that.
[cpg cn=true]


She responded in that way.
[cpg]


I would not give in. I was not going to give in yet.
[cpg]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています



;//ブラックアウト

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『ドラゴンの住処』（昼）******************************************************


I waited for Charlotte's return at the dragon's dwelling.
[cpg]


The medicine she brought me the other day did not break my curse.
[cpg]


Charlotte comes back every once in a while to report that she's okay, but ......
[cpg]


blatantly, she is losing weight. I'm not so much losing weight as getting thin.
[cpg]

[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

[OnName num="itsuki"]
"Hey, Charlotte,......, are you sure you're okay?"
[cpg cn=true]


The most important thing to remember is that you can't just take a look at your own personal information.
[cpg]


I'm not saying that I'm okay or not okay.
[cpg]


 I'm just worried, but even if I hit Charlotte with it, nothing will happen.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『ドラゴンの住処』（夜）******************************************************


After staying only a few days, Charlotte would leave again.
[cpg]


......I've made up my mind too. I'm me and I'm going to look for clues to break the curse.
[cpg]



;//ブラックアウト




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『エウルアウレア・暗闇の街』（夜）******************************************************


I wanted to go to Hermia, who seemed to know the most about the curse, but I couldn't locate her.
[cpg]


Whenever, I headed for the vampire's place. Then she said something strange: ......
[cpg]


Charlotte said she was headed to Hermia.
[cpg]

[free time=1000]
She said she was looking for clues to break my curse in the forest where the dark elves live.
[cpg]


I decided to find out from the vampire where that forest was.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************


Then I walked towards the forest.
[cpg]


I realize that this is the first time I am traveling alone.
[cpg]


But this will also give me an idea of what is happening to Charlotte.
[cpg]


I went towards it, thinking that what I was doing was not in vain,.......
[cpg]



;//ブラックアウト

;//////////////////////
;//ヒロイン5に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_m1"]
[WAIT time=100]


I'm not saying that I didn't want to be saved.
[cpg]


But I felt like there was nowhere to turn.
[cpg]


The people I was working with were getting sicker and sicker.
[cpg]


[OnName num="woman_A"]
I asked myself, "...... are you okay?　Keep your head up, Ms. Charlotte."
[cpg cn=true]


No, I'm the one who's the sickest. ......
[cpg]


She is worried about me, because she looks sick from the outside.
[cpg]


I had no choice but to reply that I was fine.
[cpg]


I can't just collapse in a place like this.
[cpg]


I have to be ...... happy. I'm going to live with the tree.
[cpg]


;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ダークエルフの森』（昼）******************************************************


In between jobs, I headed to Crow's house.
[cpg]


How much more money do I have to earn to finish? I wanted to ask him.
[cpg]


[OnName num="crow"]
He said, "It's going well. If I work every day, I should be able to finish in two years.
[cpg cn=true]


I felt dizzy. Two more years if I work every day. ......
[cpg]


What kind of hell is this? I had a feeling that after two years, I would forget about him.
[cpg]


I had a hunch. But there was nothing I could do. ......
[cpg]


For the sake of our happiness,......
[cpg]


Happiness, happiness......
[cpg]


What is happiness?
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[OnName num="crow"]
"...... he's going to lose it.
[cpg cn=true]


[OnName num="crow"]
I thought I had a good moneymaker, but ...... it's time to move on.
[cpg cn=true]


;//移植のためシーンをカットしています


;//ブラックアウト

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『ダークエルフの森』（昼）******************************************************


I came to the dark elf forest.
[cpg]


The first thing you need to do is to find out who is familiar with curses and how to lift them.
[cpg]


One dark elf emerged.
[cpg]


His name was Crow. I went to his house.
[cpg]


[OnName num="crow"]
He said, "I'm ....... I'm Crowe,...... but could he be Charlotte's husband?"
[cpg cn=true]


[OnName num="itsuki"]
"Charlotte is ...... here?"
[cpg cn=true]


[OnName num="crow"]
I've been coming here for a long time now. It's about time you took him in.
[cpg cn=true]


[OnName num="crow"]
If she does that, she won't be able to meet the needs of her clients,.......
[cpg cn=true]


I didn't know what Crowe was talking about.
[cpg]


I didn't know what Crowe was talking about, but something terrible was going on. That much I do know, and I ask her where she is.
[cpg]


[OnName num="crow"]
She's at the store I run. Want me to show you around?"
[cpg cn=true]


I spat and followed Crowe's lead.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


And then. There, ah, in that place: ......
[cpg]
Charlotte, already broken, was there.
[cpg]


;//移植のためシーンをカットしています

;//[FG f="CHA06_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Charlotte108"]
[OnName num="charlotte"]
"......Tree ......Why are you here?"
[cpg cn=true]


I realized everything. She had been sacrificing herself for me all along.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Charlotte109"]
[OnName num="charlotte"]
Don't come ...... and don't look at me like this."
[cpg cn=true]


I couldn't get close to her as she refused. I feel like my heart has already left her.
[cpg]

But ...... I guess I still wanted to atone for my sins.
[cpg]

The first thing to do is to make sure that you have a good time with your family and friends.
[cpg]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="Charlotte110"]
[OnName num="charlotte"]
I wondered if I could start this love ...... again.
[cpg cn=true]


I wonder if I can start this love all over again.
[cpg]

I don't know where I went wrong. I don't even know what was set up.
[cpg]

But everything is ...... a choice to know what was going on.
[cpg]


;//ブラックアウト

;//ＥＮＤ：ヒロイン５ルート
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[Ending_SetUp cl=cl_010 ss=false]

[system cl_010=true]

[SCENE id=20]

[jump storage="epend.ks" target="*start"]

