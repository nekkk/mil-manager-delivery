
*start

;#################################################
*Ep014|Obsessed with Hermia
;#################################################

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『草原』（朝）


*select04_1|I'm obsessed with Hermia.

[SCENE id=14]


[OnName num="itsuki"]
'......, could you go on ahead of me for a minute?'
[cpg cn=true]


I tell Ariel. It's a little selfish of me, but I can't help it.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel072"]
[OnName num="ariel"]
'......?　Is something wrong?"
[cpg cn=true]


I don't tell Ariel everything. I don't tell her everything.
[cpg]


[OnName num="itsuki"]
"It's okay."
[cpg cn=true]


I let Ariel go on ahead of me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel073"]
[OnName num="ariel"]
I'll go ahead ......."
[cpg cn=true]


I decided to use my skill. The name of the skill is <<Analysis>>.
[cpg]


I don't know if it's enough to find Hermia.
[cpg]


I looked around in "Analysis" and couldn't find anything that looked like it.
[cpg]


I immediately used Detection to look around.
[cpg]


It was a strange skill, as if I could see through it.
[cpg]


And then I saw it. I went in the direction of the shadow of a person, ...... different from a demon.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr024"]
[OnName num="elmyr"]
Oh my. I thought we were going to the Great Forest of Acecto.
[cpg cn=true]


I finally found Hermia, and she said to me like that.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Elmyr025"]
[OnName num="elmyr"]
Or did you think I was a bit of a jerk?
[cpg cn=true]


Well, you're almost right about that, ...... but let's not say so.
[cpg]


[OnName num="itsuki"]
Don't be too selfish. Don't be too selfish. I don't like it when you suddenly disappear.
[cpg cn=true]


I said, a little offended by Ermia's behavior.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr026"]
[OnName num="elmyr"]
I'm not even a good asset to the cause, so why not?"
[cpg cn=true]


I shook my head. That's no reason for you to suddenly disappear.
[cpg]


[OnName num="itsuki"]
;//「そうも行かないだろ」
It's not going to work that way.
[cpg cn=true]


Hermia looks like she can afford it. He's a little uptight.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Elmyr027"]
[OnName num="elmyr"]
So ...... that means there's something else going on.
[cpg cn=true]


He said. What is he trying to make me say?
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr028"]
[OnName num="elmyr"]
If that's the case, I'd like to hear the reason. You're that obsessed with me.
[cpg cn=true]


He hit me right to the heart of the matter. How should I respond to Hermia's words?
[cpg]


Should I be honest with her ......?
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Elmyr029"]
[OnName num="elmyr"]
Well, I have confidence in my good looks.
[cpg cn=true]


Hermia laughed and said, "Well, I have confidence in my good looks. I replied.
[cpg]


[OnName num="itsuki"]
Oh, that's right. Yes, I'm obsessed with you. I'm obsessed with you.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[OnName num="itsuki"]
I don't care how you take it, just come back to me.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
Hermia blushed a little. No, I don't have time for this exchange.
[cpg]


[OnName num="itsuki"]
'Please, ...... Hermia.'
[cpg cn=true]


I said, for the umpteenth time, I don't know how many times. But.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Elmyr030"]
[OnName num="elmyr"]
'Anyway, I can't go with you.
[cpg cn=true]


Hermia did not shake her head.
[cpg]


I wonder why. I don't know how many times I've told her that, but I can't go with her.
[cpg]


[OnName num="itsuki"]
"That's the kind of ...... that makes me want to hear why."
[cpg cn=true]


I was going to bite the bullet. I can't let him go away like this without telling me.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr031"]
[OnName num="elmyr"]
But you're worried about me. Thank you, I'm glad to hear that.
[cpg cn=true]


Hermia said and thought about it for a moment.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Elmyr032"]
[OnName num="elmyr"]
'...... in return, yes. ......
[cpg cn=true]


I look up when I think I've thought about it.
[cpg]


The first thing to do is to make sure that you have a good time. I was so surprised.
[cpg]


I was so startled that I immediately said, "Wait, where are you going?
[cpg]


[OnName num="itsuki"]
Where are you going?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr033"]
[OnName num="elmyr"]
I have a date. Please go with me.
[cpg cn=true]


[OnName num="itsuki"]
I said, "A date......... Wait a minute.
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_m2"]
;//ブラックアウト


He took me around the city on what he called a date.
[cpg]


At each stop, I tried to convince Hermia to go with me.
[cpg]


Each time, Hermia would ask me if I liked her that much.　he would ask me.
[cpg]


I was already ready to affirm it, and I told Hermia to accompany me. ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Elmyr034"]
[OnName num="elmyr"]
'Hmph,...... when you say that much, I'm tempted to go along with you.
[cpg cn=true]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


I did, and it took me all night.
[cpg]


I had to meet up with Ariel,...... or I could manage with 《detection》. ......
[cpg]


But it's a time-sensitive situation for the recovery of that great forest.
[cpg]


We can't stay that long. I was thinking that.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr035"]
[OnName num="elmyr"]
"Hey, tree."
[cpg cn=true]


[OnName num="itsuki"]
What the hell,......, I don't have time to stay overnight."
[cpg cn=true]


I said that to Hermia, and she replied.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Elmyr036"]
[OnName num="elmyr"]
'I'd like to stay with you just a little longer. How about it?"
[cpg cn=true]


......Why is this happening to me? I've been irresistible since I came into this world.
[cpg]


But, yeah. If only she would listen to me now.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadout" layer=20 pos="4/7"]


;//========================================
;//●ＣＧ（主人公を抱きしめるヒロイン）ev_14
;//人物１：ヒロイン３
;//服装１：着衣
;//人物２：主人公
;//服装２：旅人服
;//場所　：宿の一室
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]

I'd cuddle up with her in a room.
[cpg]

I'd rather be by Ermia's side than do as she says.
[cpg]

[VOICE f="Elmyr037"]
[OnName num="elmyr"]
I can smell the tree."
[cpg cn=true]


She says this and puts her hand around my back.
[cpg]

I wonder if I should at least kiss her. I had no idea what to do in such a situation.
[cpg]


;**【ＣＧ】 ev_14_a ***********************
[CG id=0 index=1 time=1000]
;***************************************
[WAIT time=1000]

But I couldn't stop myself from doing so because Ermia had her eyes closed and looked as if she was waiting for something.
[cpg]

[VOICE f="Elmyr038"]
[OnName num="elmyr"]
'Choo-choo.'
[cpg cn=true]


Even though I knew this was not something I should do lightly,...... it was no good.
[cpg]

[OnName num="itsuki"]
'......I'm being courted by another girl.'
[cpg cn=true]


I say so honestly. Hermia just laughs.
[cpg]

;**【ＣＧ】 ev_14_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Elmyr039"]
[OnName num="elmyr"]
I know most of them. I've heard rumors.
[cpg cn=true]


I see. Then I guess I don't have to worry about it either. ......?
[cpg]


But that's not just Hermia's problem.
[cpg]


It's my problem too. Cheating is not a good thing.
[cpg]


;//ブラックアウト


;//////////////////////
;//ヒロイン3に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]



[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_ni"]
[WAIT time=100]


I used 《Analysis》 on myself and found out.
[cpg]


Maybe it's a result of him getting the "Detection" skill. I had the skill of Temporary Heat.
[cpg]


Perhaps it was because of this skill that I developed a kind of affection for him.
[cpg]


It was a skill that I acquired in order for him to lose his heart. The love that sprouted for him to be heartbroken.
[cpg]


I felt sorry for him, but ...... I had seriously fallen in love with the tree.
[cpg]


Even if this is 《temporary fever》. I can't shake it off.
[cpg]


I've fallen in love with the tree,...... and there's no way I can fool myself anymore.
[cpg]


I wanted to know more about him.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『草原』（朝）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

Before he woke up, I was on my way to the pagan church.
[cpg]


He left me at the inn in the example. I think that's good.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
It is not only dark elves like me who worship ...... paganism. There were also humanoid demons such as orcs and lizardmen.
[cpg]


[OnName num="guru"]
Hermia. How did it go?"
[cpg cn=true]


The guru of this paganism. I had received my orders.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Elmyr040"]
[OnName num="elmyr"]
"...... Yes. It's going well."
[cpg cn=true]


I told him exactly what I had been doing.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Elmyr041"]
[OnName num="elmyr"]
"If things continue as they are, I thought that a split in the fellowship would eventually ...... occur."
[cpg cn=true]


I was a believer in paganism, a religion that worships evil gods.
[cpg]


I have been for a long time. With a family history of dark elves, my mother and father both wished for the return of the evil gods.
[cpg]


Not just my mother and father. They have been waiting for the resurrection of the evil gods since their ancestors.
[cpg]


So, not wanting to be disturbed by a brave man, I was to be present at his summoning.
[cpg]


As a result, I fell in love with him, which was ridiculous.
[cpg]


I can't believe that I've ...... And that I've become worried about him.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Elmyr042"]
[OnName num="elmyr"]
'Well, Oyasama,......, by all means, do we have to kill the brave man?
[cpg cn=true]


[OnName num="guru"]
"...... what do you mean?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Elmyr043"]
[OnName num="elmyr"]
'Now that the resurrection of the evil god has come true, isn't it okay to leave him alone?
[cpg cn=true]


I will think of a way to keep the tree from dying as much as possible.
[cpg]


[OnName num="guru"]
I'm not saying it has to die, but we can't let that thing interfere with the evil god, can we?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Elmyr044"]
[OnName num="elmyr"]
Then, how about capturing it alive ......
[cpg cn=true]


No, no. There will be no reason to keep him alive. It's more ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Elmyr045"]
[OnName num="elmyr"]
No, how about persuading him not to defeat the evil god?
[cpg cn=true]


[OnName num="guru"]
You are very much on the side of evil. Weren't you a follower of the evil ......?"
[cpg cn=true]


Oyasama is suspicious of me. I think I'm saying things that should not be doubted.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Elmyr046"]
[OnName num="elmyr"]
"...... that's right. I would do anything for Evil God-sama."
[cpg cn=true]


;//ブラックアウト

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


I had not only the skill of 《Temporary Heat》 but also the skill of 《Camouflage》.
[cpg]


I don't remember getting this skill. But surely it is necessary for me not to be tied to the tree?
[cpg]


Perhaps it is a skill to hide from detection.
[cpg]


If the tree can search for you by "detection" all the time, the tree will find out where the paganism is based.
[cpg]


That would be a problem. ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（昼）******************************************************


[OnName num="itsuki"]
Oh, that ......?　Hermia, there you are."
[cpg cn=true]


I was on my way to the tree for the first time in a long time.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Elmyr047"]
[OnName num="elmyr"]
'...... yeah.'
[cpg cn=true]


[OnName num="itsuki"]
'Its...... been a long time.
[cpg cn=true]


Maybe it was because of what had happened with me, but Itsuki looked embarrassed.
[cpg]


He can no longer look for me in the "detection". So he's probably doing what he has to do.
[cpg]


I am sure that he has solved the problem of the Great Forest.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
I am sure that the reason he is in the underground city now is to solve a new problem.
[cpg]


I was even more attracted to him.
[cpg]


He sacrifices himself for others. I was even more attracted to him. ......
[cpg]


I loved him for his willingness to spare no effort for the happiness of others.
[cpg]


It didn't matter if this was due to his skills or not.
[cpg]

[free time=800]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Littule030"]
[OnName num="littule"]
It's been a long time, Hermia. I've been looking for you.
[cpg cn=true]


Ritul spoke to me. I looked for you, I mean ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Elmyr048"]
[OnName num="elmyr"]
I was a little surprised, but I returned it.
[cpg cn=true]


I replied, a little surprised.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Ariel074"]
[OnName num="ariel"]
You didn't look for me ......, but I did. Hermia."
[cpg cn=true]


Ariel was looking for me. I can't say I'm on good terms with her.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Elmyr049"]
[OnName num="elmyr"]
......Yes."
[cpg cn=true]


I muttered to myself. I'm not even worth looking for.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Elmyr050"]
[OnName num="elmyr"]
'I'm not even worth looking for. ......
[cpg cn=true]


Ariel nods her head. And then.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Ariel075"]
[OnName num="ariel"]
"What?　Did I say something?"
[cpg cn=true]


I couldn't tell her the ...... whole truth.
[cpg]


I had to swallow it all myself. There was nothing else I could do.
[cpg]


I guess I would have to continue to misrepresent everything.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Elmyr051"]
[OnName num="elmyr"]
I had no other choice but to swallow it all by myself. It's nothing.
[cpg cn=true]


Still, I wondered if I should continue to do this.
[cpg]


I was feeling unbearable.
[cpg]


The trees were right, weren't they? It is not right for a god to destroy the world.
[cpg]


I had never felt this way before.
[cpg]


My parents had taught me that, and my parents' parents and ancestors had been steeped in paganism for generations.
[cpg]


But I still feel like this. ......
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


I am going back to church again. Even though I didn't want to go back, I needed to report the tree's behavior.
[cpg]


I would return to the church and report back. Oyasama saw through my heart.
[cpg]


[OnName num="guru"]
It seems you still have some unfinished business. I can't help it.
[cpg cn=true]


I had no choice but to obey Oyasama. There is no doubt about it anymore. ......
[cpg]


[OnName num="guru"]
'I love you, my dear. What more could I ask for?"
[cpg cn=true]


Saying this, Oyasama approached me. I turn my face away.
[cpg]

I might forget the feelings I first had for the tree.
[cpg]


That was what I was afraid of. ......
[cpg]


;//移植のためシーンをカットしています


;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


I groaned and woke up.
[cpg]


I have a bad premonition. I wandered around the city at night, unaware of what that premonition was.
[cpg]


I convinced Charlotte. Now if only Hermia were here, we would all be together.
[cpg]


Hermia...... where are you doing?
[cpg]


I'm not even sure why he disappears so often.
[cpg]


Why don't they just tell us why?
[cpg]


You can't tell us? Is it something they just can't tell us?
[cpg]


Maybe it's something that will turn them against us if we tell them.
[cpg]


I don't know. It's still late at night. No sign of sunrise. ......
[cpg]


I'm going to try to go back to sleep.
[cpg]



;//ブラックアウト

;//////////////////////
;//ヒロイン3に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]

;//========================================
;//●ＣＧ（教祖がヒロインに近づく。リザードマンだったキャラクターの肌の色を変えてください）ev_69
;//人物１：ヒロイン３
;//服装１：着衣
;//人物２：教祖
;//服装２：着衣
;//場所　：拷問部屋
;//時間　：夜
;//========================================


;**【ＣＧ】 ev_69_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


I was called to a room in the church.
[cpg]

[OnName num="guru"]
I wonder, "Will you accept my love? Will you accept my love?"
[cpg cn=true]


Oyasama was very insistent on me.
[cpg]

It was as if fate was trying to tear me away from the tree.
[cpg]

All of this must be due to the tree's skill.
[cpg]


Because I have made contact with the tree ......
[cpg]


It is too late for regrets. I have no choice but to accept this fate.
[cpg]

[VOICE f="Elmyr052"]
[OnName num="elmyr"]
What will happen if I refuse to ......"
[cpg cn=true]


[OnName num="guru"]
'What are you talking about?　I know I can't refuse."
[cpg cn=true]


...... Yes, you can. I have been steeped in pagan teachings all my life.
[cpg]

I can't change myself so easily now.
[cpg]

[OnName num="guru"]
I love you. Hermia."
[cpg cn=true]


And then Oyasama put her lips to mine.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************


In the journey that followed, Hermia appeared and disappeared from time to time.
[cpg]


She was thoughtful, and she became even more thoughtful.
[cpg]


Like she wanted to say something, or something like that. ......
[cpg]


Then one night. While I was camping out on the road, I heard someone's voice waking me up.
[cpg]


;//[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr053"]
[OnName num="elmyr"]
Wake up. It's Hermia.
[cpg cn=true]


It's Hermia. I could tell just by the voice.
[cpg]


[OnName num="itsuki"]
"...... Hermia, huh?"
[cpg cn=true]


I get up and listen to Hermia's words in my hazy consciousness.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Elmyr054"]
[OnName num="elmyr"]
I hear her voice. "......I'm sorry, Tree. I can't be yours."
[cpg cn=true]


Hermia was crying. I had never seen her like this.
[cpg]


[OnName num="itsuki"]
What's wrong ......?　What are you crying about?
[cpg cn=true]

;//[t_move pos=C ゆらゆら]
Hermia wiped her own tears and said.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Elmyr055"]
[OnName num="elmyr"]
'I ...... couldn't see for myself that I'm calloused, couldn't I?
[cpg cn=true]


[OnName num="itsuki"]
'What are you talking about,...... tell me more.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Elmyr056"]
[OnName num="elmyr"]
'You really are a helpless woman, ...... this is how it's supposed to be.'
[cpg cn=true]


I don't know if you can hear my words or not.
[cpg]


[free time=1000]


In the end, with those words, Hermia left.
[cpg]


It was strange that Hermia was crying. I couldn't understand it.
[cpg]


I didn't understand what she was saying until the end.
[cpg]


No,...... I wonder if one day I will understand.
[cpg]


Somehow, I have a bad feeling about it. But I still can't realize what it is.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel076"]
[OnName num="ariel"]
"Hmmm,...... that, I think I just heard Hermia's voice,.......
[cpg cn=true]


I woke Ariel up, it seems.
[cpg]


[OnName num="itsuki"]
"......Yeah, that's right......."
[cpg cn=true]


Hermia. She's carrying something dark.
[cpg]


[free time=1000]


[OnName num="itsuki"]
What happened, Hermia?
[cpg cn=true]


I still loved Hermia. If she had a reason to cry, I wanted to solve it.
[cpg]


But still, the truth was too mysterious.
[cpg]


Maybe she was getting more and more bogged down without my knowledge.
[cpg]


But she didn't ask me to help her.
[cpg]



;//ブラックアウト

;//////////////////////
;//ヒロイン3に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_ne"]
[WAIT time=100]


I reported how the trees were acting for the sake of the evil religion.
[cpg]


Gradually, the friends are coming together. And problems in various places are being resolved, she said.
[cpg]


[OnName num="religious_A"]
'If this continues, won't the evil god be overthrown ......?
[cpg cn=true]


[OnName num="religious_B"]
No, it won't. You have the broken heart skill, that should break them apart."
[cpg cn=true]


[OnName num="religious_A"]
"Really?　Couldn't you have done something more useful?
[cpg cn=true]


[OnName num="religious_B"]
It was Hermia's idea. It was Elmire's idea, no doubt about it.
[cpg cn=true]


[OnName num="guru"]
That's right. That's what it's all about, causing a rift. By the way, Elmire, ......
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Elmyr057"]
[OnName num="elmyr"]
What is ......?
[cpg cn=true]


I stiffen. I wonder if they will do something to me again.
[cpg]


[OnName num="guru"]
I wonder if they're going to do something to me again.
[cpg cn=true]


It's not rebellion. No, I wonder if it is rebellion.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Elmyr058"]
[OnName num="elmyr"]
It's ...... that ......
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Elmyr059"]
[OnName num="elmyr"]
'I am not thinking of rebelling. But ......."
[cpg cn=true]


I choose my words carefully. But they see right through me.
[cpg]


[OnName num="guru"]
But what?　It's shallow. You tipped us off to the hero's activities, yet you still say you're not his enemy.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Elmyr060"]
[OnName num="elmyr"]
I can't ...... answer that."
[cpg cn=true]


I was beginning to lose sight of what I was.
[cpg]


The actuality that the actuality is that you can't get a lot of these things. I was also wondering why I had developed these feelings.
[cpg]


I was ...... regretting it, knowing that it was all my doing.
[cpg]


[OnName num="guru"]
'Am I still not educated enough?　I guess that kind of attitude is because he really likes me."
[cpg cn=true]


...... I can't help it. I can't do anything about it.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


Will he defeat the evil god at this point? If he does, will this evil religion also be destroyed?
[cpg]


It is as if they are wishing for it or not.
[cpg]


In any case, I cannot receive the love of the tree. I am not qualified for it.
[cpg]


Everything has already gone crazy. Everything is slow ......
[cpg]


Where did I go wrong...... I didn't even know what kind of heroes would be summoned.
[cpg]


More to the point, I didn't think anything of it when I first met him.
[cpg]


I felt that I had fallen in love with him regardless of the "temporary heat" any longer.
[cpg]


But is any of this a trick ......?
[cpg]

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************


On our way to defeat the evil god, we found an old church.
[cpg]


It was dark, somehow. The metal parts were rusted and plants were running down the outer walls.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Ariel077"]
[OnName num="ariel"]
"It's a creepy church. ...... Is it some kind of devil-worshiping place?"
[cpg cn=true]


[OnName num="itsuki"]
"I don't know. ...... let's go in."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Littule031"]
[OnName num="littule"]
I don't think we should go in there, it's too ...... creepy."
[cpg cn=true]


I kind of felt like I had to go in here.
[cpg]


Where did this feeling come from? I don't know.
[cpg]


[free time=1000]

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


I saw a familiar figure among the people praying there.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Elmyr061"]
[OnName num="elmyr"]
"...... you've come, tree."
[cpg cn=true]


[OnName num="itsuki"]
"Hermia ......?　How did you end up in this place ......?"
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

I don't know what was going on there.
[cpg]

But Hermia then said something suggestive.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Elmyr062"]
[OnName num="elmyr"]
Hey, Tree," he said, "there are terrible people in this world. There are terrible people in this world.
[cpg cn=true]


;//[FACE method="change_1" pos="2/3"]
[VOICE f="Elmyr063"]
[OnName num="elmyr"]
If there are those who are destined to fall, there are those who are destined to orchestrate it.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Elmyr064"]
[OnName num="elmyr"]
I'm sure ...... that's me.
[cpg cn=true]


[OnName num="itsuki"]
I don't know what you're talking about.
[cpg cn=true]


I pretended not to understand. I pretended not to understand, knowing that she must be on the side of the evil gods.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Elmyr065"]
[OnName num="elmyr"]
I'm sure you're going to suffer whatever ...... choice you make because of what I did.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Elmyr066"]
[OnName num="elmyr"]
I'm sure your girlfriend, who was standing next to you at the time, would have suffered ...... along with you.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Elmyr067"]
[OnName num="elmyr"]
I've been punished for that. I will never be happy."
[cpg cn=true]


[OnName num="itsuki"]
......
[cpg cn=true]


Hermia feels an unknowable responsibility.
[cpg]

I couldn't say something so careless. But ...... there is one thing that is still certain.
[cpg]

[OnName num="itsuki"]
I think I'm the kind of person who can't stop liking someone, even if that person can't make me happy.
[cpg cn=true]


[OnName num="itsuki"]
Then it's not just Hermia's fault.
[cpg cn=true]


When I said that, Hermia cried.
[cpg]

I just told her the truth,......, but I wonder if that made her feel any better.
[cpg]

Heartbreak is not a one-person problem. And ......
[cpg]

Love is not like life. Once lost, it could have sprouted again.
[cpg]

Even if I had made a different choice and had a different ending,...... surely.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Elmyr068"]
[OnName num="elmyr"]
You're not so good at giving up on ......."
[cpg cn=true]


[OnName num="itsuki"]
I'm not going to give up on Elmia either. I'm not going to give up on Ermia either.
[cpg cn=true]


;//ヒロイン３ルート（トゥルー）　エンド

;//ヒロイン３　ルート　寝取られエンド
;//ＥＮＤ
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[Ending_SetUp cl=cl_001 ss=false]

[system cl_001=true]

[SCENE id=22]


[jump storage="epend.ks" target="*start"]

