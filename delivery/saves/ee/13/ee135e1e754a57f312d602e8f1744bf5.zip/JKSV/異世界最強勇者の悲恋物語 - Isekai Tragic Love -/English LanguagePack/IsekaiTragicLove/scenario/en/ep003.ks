
*start

;#################################################
*Ep003|Mastering the Art of Swords
;#################################################


*select_first_ken|Mastering the art of swordsmanship

[SCENE id=3]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_fi"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（朝）******************************************************


Then we went on defeating monsters for a while.
[cpg]


Monsters kept popping up one after another. I was not satisfied with my "swordsmanship" skill.
[cpg]


I got not only the "Swordsmanship" skill, but also its higher skill, "Swordsmanship II.
[cpg]


I also got the skill "Unmatch," which is probably something to do with swordsmanship.
[cpg]


My swordsmanship was destroying demons. At a frightening speed.
[cpg]


The most important thing to remember is that the best way to get the most out of your money is to be a good businessman.
[cpg]


[OnName num="abram"]
"As expected... Hero-sama, you're amazing."
[cpg cn=true]


[OnName num="itsuki"]
I'm just doing what I can. I'm just doing what I can.
[cpg cn=true]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夕方）******************************************************


In the evening, the stones are getting tired.
[cpg]


The nighttime, the demons have the upper hand.
[cpg]


At this rate, I'll be able to completely destroy the demons. ......
[cpg]

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]


And in the middle of the reconstruction, I was meeting with Ariel in hiding.
[cpg]

;//[free time=1000]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
Not forgetting, of course, that it was forbidden. Hiding, that is.
[cpg]

But I don't know why, but Ariel looks guilty when she meets me.
[cpg]

Does she think it's wrong for elves and humans to mingle?　But ......
[cpg]

I think she was convinced about that.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************

;//上下に黒帯を外してください


After those events, our relationship became delicate. On the surface, it was business as usual.
[cpg]


[OnName num="itsuki"]
"...... Ariel, that ......."
[cpg cn=true]


When I tried to talk to her, her attitude was slightly different.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel094"]
[OnName num="ariel"]
I tried to talk to her, but her attitude was slightly different.　Itsuki, ......."
[cpg cn=true]


I turn to Abram while I'm saying.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel095"]
[OnName num="ariel"]
'Oh, Abram ...... about the recovery, or rather, the procedure for taking down the tree.
[cpg cn=true]


[OnName num="abram"]
Oh, what?"
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


Even if I don't, if I feel like I'm about to do more than kiss him, I'll give him a reason to leave the place.
[cpg]


He began deliberately avoiding me to avoid being alone with me.
[cpg]


......Why? It wasn't supposed to be like this.
[cpg]


It was as if there was some kind of curse on me, and the relationship wasn't going well.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************


Naturally, I couldn't stand it, so I whispered my love to her again.
[cpg]


[OnName num="itsuki"]
I whispered to him again, "Hey, you know what? Can we be alone together again?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ariel096"]
[OnName num="ariel"]
"Thank you very much. I'm glad you have feelings for me.
[cpg cn=true]


I'm glad you have feelings for me. But the words were already proof that he was rejecting them.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel097"]
[OnName num="ariel"]
But we have time, so let us nurture our love slowly ......, okay?"
[cpg cn=true]


He said in a roundabout way. I nodded ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_fi"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


I'm going to concentrate on defeating the demons because there is no way to solve such a problem.
[cpg]


As if mocking me, the monsters did not stop multiplying.
[cpg]

[SE f="se015"]
;//【ＳＥ】『剣戟』


As we crossed swords, Ariel was captured.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[OnName num="itsuki"]
Ariel!　Damn it!
[cpg cn=true]


I tried to chase after Ariel. But even with my "Swordsmanship II," there were too many of them.
[cpg]


Ariel is disappearing into the crowd of demons.
[cpg]


What will I do if I get killed like this?
[cpg]


Cold sweat broke out from my body. If Ariel is killed at this rate, there is nothing I can do.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


[SE f="se024"]
;//【ＳＥ】『走る』


I go looking for Ariel. But I can't reach her.
[cpg]


There are so many demons. They are out of the ordinary.
[cpg]


It was beyond the level where it could be solved with swordsmanship or something like that.
[cpg]


I decided to get a new swordsmanship skill because I knew that I was going to be left behind if I continued like this.
[cpg]


I wondered if "total attack" really meant what it sounded like in RPGs.
[cpg]


I can't even imagine what it would be like physically, but I'll take it.
[cpg]


This time, getting that skill did not come with any accompanying skills.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

And I managed to get rid of the monsters and rescue Ariel as well.
[cpg]


[OnName num="itsuki"]
...... Ariel, are you okay?"
[cpg cn=true]


However, Ariel, who had been rescued, was acting somewhat strangely.
[cpg]

Instead of turning pale with fear, her cheeks were turning red. ......
[cpg]

;//////////////////////
;//ヒロイン1に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]


[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夕方）******************************************************

;//上下に黒帯を入れてください


There was something wrong with my body.
[cpg]


And when I used the 《Analysis》 skill, a strange skill was given to me.
[cpg]


I don't know what kind of effect the 《Suspension Bridge Effect》is .......
[cpg]

The "Analysis" skill is a very good way to get a better understanding of what is going on in your mind.
[cpg]

I still don't know what it is. But there was no doubt that something was wrong with my body.
[cpg]


Is it something that can be managed with recovery magic ......?　Nope.
[cpg]


What if it was something that could not be cured, and what if it was something that would not be good if others found out about it?
[cpg]


I could not talk to anyone about it.
[cpg]


Of course, I couldn't even talk to Tree-sama, ......the person I couldn't do the most.
[cpg]


[FG f="ci_lbox.ui" method="feadout" layer=20 pos="4/7"]

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************


And it was when I was falling asleep.
[cpg]


[SE f="se089"]
;//【ＳＥ】『物音』
[WAIT time=1000]


I was awakened by a strange noise. I knew that someone was breaking in.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Ariel098"]
[OnName num="ariel"]
I said to myself, "Oh my God, ...... what?　Who are you ......?
[cpg cn=true]


There were goblins in such numbers that I could not compete with them.
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（ゴブリンに体を掴まれるヒロイン）ev_52
;//人物１：ヒロイン１
;//服装１：着衣
;//人物２：ゴブリン
;//服装２：布きれ
;//人物３：ゴブリン
;//服装３：布きれ
;//人物４：ゴブリン
;//服装４：布きれ
;//場所　：洞窟
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_52_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]

I was trapped again.
[cpg]


Why me? Why am I the only one who gets caught?
[cpg]


I can't help but think that something unseen is at work here.
[cpg]


[OnName num="goblins_A"]
"That's pretty good, isn't it?"
[cpg cn=true]


[OnName num="goblins_B"]
"Keep quiet. If you yell, I'll kill you.
[cpg cn=true]


[VOICE f="Ariel099"]
[OnName num="ariel"]
No, don't. ......!　Let me go!
[cpg cn=true]


No matter how much I resisted, it was no use. And why does my heart flutter at such a situation?
[cpg]

I don't know what's working on my mind, but it doesn't feel right.
[cpg]


;//移植のためシーンをカットしています


;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]


[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_fi"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（朝）******************************************************


By the time I woke up in the morning, I had discovered something unusual.
[cpg]


Simple things, really. But it was something that disturbed me.
[cpg]


[OnName num="itsuki"]
'Ariel's not here. ......!　Damn, did someone take her away again ......?"
[cpg cn=true]


[OnName num="abram"]
We've got to go help her soon, my brave friend. Do you have any idea?
[cpg cn=true]


[OnName num="itsuki"]
No ......, but we'll have to look for him.
[cpg cn=true]


I'm going to look for Ariel, who is missing.
[cpg]


I really don't have any idea. If one of the demons did it, I have no idea.
[cpg]


[SE f="se024"]
;//【ＳＥ】『走る』


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


By noon, Ariel was still nowhere to be found.
[cpg]


Assuming that she had been taken away by a demon, I thoroughly searched the place where the demon might be.
[cpg]


After searching and searching, ...... finally found her.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


Deep in the cave ...... Ariel was found.
[cpg]


[OnName num="itsuki"]
Damn it!　Why did they do this to Ariel?
[cpg cn=true]


[OnName num="goblins_A"]
What?　What is it?
[cpg cn=true]


[OnName num="goblins_B"]
"A human. I'm going to get back at you ......."
[cpg cn=true]


[SE f="se006"]
;//【ＳＥ】『剣を振りかざす』

Before I could finish my sentence, I swung my sword.
[cpg]


And only Ariel remained ...... I asked her.
[cpg]


[OnName num="itsuki"]
"Ariel,......, what's the pattern?"
[cpg cn=true]


;//[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel100"]
[OnName num="ariel"]
"Yes,......?　What is this ......?
[cpg cn=true]


I had no idea what it was, but I was puzzled. I had no idea what it was, and I was baffled.
[cpg]


;//[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel101"]
[OnName num="ariel"]
"Surely, maybe .......
[cpg cn=true]


[OnName num="itsuki"]
Do you know anything about it?"
[cpg cn=true]


;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
;//[t_move pos=C ゆらゆら]
[VOICE f="Ariel102"]
[OnName num="ariel"]
No. ......."
[cpg cn=true]


Ariel shakes her head. I didn't know what to say to her.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************


Then I told Ariel not to go out alone.
[cpg]


Not just me. I was also warned by my fellow elves.
[cpg]


Ariel just seemed to take the words in stride.
[cpg]


Now Ariel won't be kidnapped anymore ......
[cpg]


I couldn't be so reassured. Something strange is going on.
[cpg]


I couldn't keep track of it all, but I knew I couldn't be too careful.
[cpg]


I was thinking that, and then, as I thought, ......
[cpg]


[OnName num="itsuki"]
"Ariel......, why aren't you here......!"
[cpg cn=true]


When I visited her room. She was not in her room.
[cpg]


Ariel had disappeared again.
[cpg]


What is making her do this? She seems to be enjoying the thrill of being caught by a demon.
[cpg]


But what was the reason? I had no idea.
[cpg]


Where is Ariel? Is she already with the demons?
[cpg]


Or is she still around here? I searched aimlessly.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3"]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_fi"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************


And then I found ...... Ariel.
[cpg]


[OnName num="itsuki"]
"Oh, Ariel ......?"
[cpg cn=true]

;//[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
I happened to find Ariel walking aimlessly.
[cpg]


;//移植のためシーンをカットしています

;//========================================
;//●ＣＧ（触手に捕まっているヒロイン）ev_46
;//人物１：ヒロイン１
;//服装１：着衣
;//人物２：触手
;//服装２：無し
;//場所　：洞窟
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_46_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]

She was standing in a place where she should have known that demons would appear.
[cpg]


She is facing a giant tentacle creature. And she doesn't look frightened.
[cpg]


[OnName num="itsuki"]
What are you doing?　Run away!"
[cpg cn=true]


[VOICE f="Ariel103"]
[OnName num="ariel"]
"I'm sorry, Tree-sama ......."
[cpg cn=true]


I couldn't just smash the tentacled creature. I just went after it.
[cpg]


[OnName num="itsuki"]
Damn .......
[cpg cn=true]


But the more I followed, the more tentacles I saw. ......
[cpg]


At least we'll have company. I had no choice but to pull out.
[cpg]


Why does this happen every time?　It's as if she's creating a dangerous situation for herself.
[cpg]


I wondered if this was fate or something, and I hated God.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************


Ariel is missing. An emergency situation was compounded by an emergency situation.
[cpg]


[OnName num="itsuki"]
"...... is that ......?"
[cpg cn=true]


[OnName num="abram"]
"Dwarves or ......!　You're covered in scratches!"
[cpg cn=true]


Abram calls out to the fallen dwarf.
[cpg]


[OnName num="dwarf_man"]
He said, "Oh, my God, my underground city is ...... in danger!"
[cpg cn=true]


[OnName num="abram"]
Hey, what's going on?　Talk to me, man!
[cpg cn=true]


[OnName num="dwarf_man"]
I'm not going to make it ...... any longer.
[cpg cn=true]


[OnName num="itsuki"]
Abram, you can't force him to talk!　Somebody patch me up. ......
[cpg cn=true]


From there, elves skilled in recovery magic gathered to patch up the dwarves.
[cpg]


But they could not reach him in time. The messenger died.
[cpg]


It may be that there is recovery magic, but there is no resuscitation magic ...... in this world.
[cpg]


[OnName num="abram"]
"What do we do, brave man,......?"
[cpg cn=true]


[OnName num="itsuki"]
Oh, yes,......."
[cpg cn=true]


We guessed that the situation was quite dangerous. I can't just leave it like this.
[cpg]


But there is also Ariel. What should we do?
[cpg]

;//■選択肢
[switch]
[case "I'm going to find Ariel."]
	[swap]
	[jump target="*select06_1"]
[case "Go to Ritul's place."]
	[swap]
	[jump target="*select06_2"]
[endswitch]


12. Find Ariel
13. Go to Ritul's place (*go to the route of heroine 2)


;//==============================
;//１２、アリエルを捜す

*select06_1|Where I have mastered the art of swordsmanship
[jump storage="ep004.ks" target="*start"]




;//==============================
;//１３、リトゥルの所へ
*select06_2|I'm worried about the underground city.


[SCENE id=23]

[OnName num="itsuki"]
...... Abram, take care of Ariel.
[cpg cn=true]


[OnName num="abram"]
"Are you sure ...... you want to take care of Ariel?"
[cpg cn=true]


Abram seems to see through it. Still, I wanted to save Ritul.
[cpg]


I had to save ...... the world.
[cpg]


[OnName num="itsuki"]
It doesn't matter. It's my mission to save this world.
[cpg cn=true]


[OnName num="abram"]
I see. I'll save Ariel no matter what.
[cpg cn=true]


[OnName num="itsuki"]
I'll do whatever it takes to save Ariel. I'm counting on you.
[cpg cn=true]


I knew I could trust Abram. And so I went on.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************


I was heading for the underground city by myself.
[cpg]


Strangely enough, I wasn't worried. I thought I could make it on my own. ......
[cpg]


On the way, I encountered some demons, but I was no match for them.
[cpg]


I was getting stronger by leaps and bounds. There is nothing that can stop me now.
[cpg]


I have to keep going and save the ...... underground city.
[cpg]



;//ブラックアウト

;//ストーリーはこのまま下の流れで進行
;//==============================
[jump storage="ep005.ks" target="*start"]

