

;//１１、地下都市へ戻るの場合はここから開始

*start|Worried about the Underground City

;#################################################
*Ep005|Worried about the Underground City
;#################################################


[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_m1"]
[WAIT time=100]

*select05_2|I'm worried about the underground city.


[SCENE id=5]

I'm still worried about the underground city... and the dwarves.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I stayed in the forest for a while. During that time, many things happened.
[cpg]


I was approached by Ariel, and Ariel was kidnapped by demons. ......
[cpg]


But I would have looked at this properly if I had made some other choice.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************


[OnName num="itsuki"]
'...... sorry, you take care of this place.'
[cpg cn=true]


[OnName num="abram"]
Yeah, I'll take care of it."
[cpg cn=true]


I promised I'd be back soon, and it's dangerous over there.
[cpg]


I decided to go alone to the underground city.
[cpg]



;//ブラックアウト

;//ストーリーはこのまま下の流れで進行
;//==============================


[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_fi"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（夜）******************************************************

[SE f="se015"]
;//【ＳＥ】『剣戟』


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
And there it was. I saw Ritul and his men fighting back against the demons.
[cpg]


The battle was on the verge of collapse.
[cpg]


[OnName num="itsuki"]
I said, "I'm going to help you, Ritul!
[cpg cn=true]


I said, and offered my sword to Ritul.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
;//[t_move pos=C 下礼]
[VOICE f="Littule032"]
[OnName num="littule"]
"Tree ......!　You came!
[cpg cn=true]


Ritul looked happy. I don't think I can afford to look that way.
[cpg]


Still, he must be very happy that I came. ......
[cpg]

[free time=800]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Mercurio023"]
[OnName num="mercurio"]
"Itsuki-san, ......!　Thank goodness, I was afraid you wouldn't come ......."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
;//[t_move pos=L 下礼]
[VOICE f="Littule033"]
[OnName num="littule"]
But now I can fight back!　Let's go!"
[cpg cn=true]


I know, right? I was supposed to stay here.
[cpg]


[OnName num="itsuki"]
I'm sorry. But from now on, I'm going to protect this place.
[cpg cn=true]


I vowed to do so and decided to fight.
[cpg]


The demons were being pushed back little by little. ...... And then.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Once there, the demons retreated.
[cpg]


I don't know when they'll come again, but I think I've managed ...... once and for all.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（夜）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
;//[t_move pos=C 下礼]
[VOICE f="Littule034"]
[OnName num="littule"]
I'm not sure what's coming next, but I think I've got it under control once and for all. Thank you so much.
[cpg cn=true]


Ritul is happy. Seeing that, I feel indescribable.
[cpg]


[OnName num="itsuki"]
I think, "No,...... I don't know when I'll be back again. I can't let my mind wander.
[cpg cn=true]


I left Ariel behind. She's not in a normal state either.
[cpg]


I blamed myself, as if I had abandoned her.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
;//[t_move pos=C 溜息]
[VOICE f="Mercurio024"]
[OnName num="mercurio"]
But you managed it once. The quintessence is Mr. Itsuki.
[cpg cn=true]


[free time=1000]

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


The underground city was not in a festive mood after defeating the demons.
[cpg]


It's only natural, I think. The battle was not yet completely over.
[cpg]


When will the next one come? It seemed that everyone was worried about that.
[cpg]

[SE f="se009"]
;//【ＳＥ】『ノック』


[OnName num="itsuki"]
Who is ......?"
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
It was the same for Ritul. ......
[cpg]


Ritul had come to my room.
[cpg]


The expression on his face was a little bit embarrassed, like he was embarrassed.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Littule035"]
[OnName num="littule"]
He said, "Hey, tree,......, I'm lonely and scared, sleep with me."
[cpg cn=true]


Maybe it's a matter of being in the throes of it.
[cpg]


[OnName num="itsuki"]
I'm ...... a man, after all."
[cpg cn=true]


When I said this in a mischievous way, she replied, "I'm a man, after all.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Littule036"]
[OnName num="littule"]
'I'm ...... glad you think that way, Zo.
[cpg cn=true]


[FG f="CHA02_p5_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Littule037"]
[OnName num="littule"]
You can take it that way. If you are happy with me...
[cpg cn=true]


I could not immediately respond to that.
[cpg]


Because there is Ariel. She remains broken.
[cpg]


Abram would have rescued her, ...... but I still cared.
[cpg]


[OnName num="itsuki"]
No. I have Ariel. Because I have Ariel. ......"
[cpg cn=true]


I refuse to say so. But Ritul says to me.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Littule038"]
[OnName num="littule"]
Ariel, Ariel or ...... me, can't I be a little more girly?"
[cpg cn=true]


[OnName num="itsuki"]
'No, I think that's ...... cute, Ritul does.
[cpg cn=true]


[OnName num="itsuki"]
But you'd better take care of yourself."
[cpg cn=true]


Ritul shakes his head. And.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
;//[t_move pos=C ゆらゆら]
[VOICE f="Littule039"]
[OnName num="littule"]
But I can't. I can't just leave. I can't just leave like this."
[cpg cn=true]


He said that to me. I feel bitter.
[cpg]


I wonder if I can forget about Ariel.
[cpg]


...... No. That and whether or not to let Ritul go home like this are two separate issues.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ブラックアウト


;//========================================
;//●ＣＧ（二人寄り添って眠る。元の画像より近づいているアングル）ev_16
;//人物１：ヒロイン２
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：民家の一室
;//時間　：夜
;//========================================


;**【ＣＧ】 ev_16_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1100]
[window target=true]

[BGM f="bg_ni"]

Ritul is sleeping beside me.
[cpg]

I'm glad I didn't refuse him.
[cpg]

There's only so much I can do, but I want to help everyone as much as I can.
[cpg]

[OnName num="itsuki"]
......
[cpg cn=true]


But still, the defense of the underground city?
[cpg]


The most important thing to remember is that you can't just go out and buy a new car and then buy a new one. I think it would be better to call in someone ...... to help us.
[cpg]


I think about that. I felt like I could do something about that with my skills.
[cpg]


No, if I could do something with my skills, there was no need to call for help.
[cpg]


It might be something I could handle on my own. ......
[cpg]


Thinking about it, I made a decision.
[cpg]

;//■選択肢
[switch]
[case "I would not call for help."]
	[swap]
	[jump target="*select07_1"]
[case "Call for help"]
	[swap]
	[jump target="*select07_2"]
[endswitch]


14. I don't call for help.
15. I'll call for help.


;//==============================
;//１４、助けを呼ばない
*select07_1|I'm worried about the Underground City.
[jump storage="ep006.ks" target="*start"]


;//==============================
;//１５、助けを呼ぶ
*select07_2|I'm worried about the Underground City.
[jump storage="ep007.ks" target="*start"]

