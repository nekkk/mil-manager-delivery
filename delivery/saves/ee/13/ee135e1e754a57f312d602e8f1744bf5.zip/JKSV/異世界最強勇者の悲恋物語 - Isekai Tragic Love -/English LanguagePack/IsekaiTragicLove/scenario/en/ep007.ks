
*start


;#################################################
*Ep007|I need help.
;#################################################


*select07_2|We need help.

[SCENE id=7]


[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（朝）******************************************************


As a result, we decided to call for help.
[cpg]


[OnName num="itsuki"]
We've got to have more friends. Let's call for help.
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="2/2" time=800]

[VOICE f="Mercurio031"]
[OnName num="mercurio"]
"How do you ...... call for help?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
;//[t_move pos=L ゆらゆら]
[VOICE f="Littule057"]
[OnName num="littule"]
"That's right, Zoë," he said. There is no way to call for help.
[cpg cn=true]


[OnName num="itsuki"]
"There's ...... something about that.
[cpg cn=true]


I'm going to look for skills in Analysis. I looked for a skill in Analysis and found one called "Mental Attunement.
[cpg]


I don't know what it's about for a moment. I don't know what it's about for a moment, but I think I might have missed it.
[cpg]


But I do know what it is. It's the Japanese word for telepathy.
[cpg]


In other words, I thought, "If I use this, I can talk to someone far away. ......
[cpg]


[OnName num="itsuki"]
Do you know this skill ...... called "psychic sensing?
[cpg cn=true]


Both Mercurio and Ritul shook their heads.
[cpg]


The most important thing to remember is that the best way to get the most out of your money is to use the right tools and equipment. It is classified as magic or ......?
[cpg]


In any case, this is what I'm asking for. I get it.
[cpg]


When I got "Mental Attunement," it also came with a skill called "Complaints Granting," but I didn't know what it was.
[cpg]


And then I got ...... the skill, and I couldn't have it.
[cpg]


[OnName num="itsuki"]
I thought, "...... what am I going to do from here?
[cpg cn=true]


I don't know how to use it. I don't know how to use it.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
;//[t_move pos=L ゆらゆら]
[VOICE f="Littule058"]
[OnName num="littule"]
"I don't know, Zoë. ...... that's what the tree did."
[cpg cn=true]


[OnName num="itsuki"]
Mercurio doesn't know either, right?"
[cpg cn=true]


Mercurio nodded. Then he continued.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Mercurio032"]
[OnName num="mercurio"]
I don't know about 《Mental Sensitivity》 either, so ...... why don't you try using it for now, Tree?"
[cpg cn=true]


For now, I'll just try to remind you. The strongest ally ...... seems to be.
[cpg]


[free time=1000]

Charlotte, huh? I'll try to picture her face, and then imagine that I'm calling out to her.
[cpg]


I can't see her, but I feel like I can call out to her. But I somehow felt like I could call out to her.
[cpg]


I think I can reach her ...... and I strongly remind myself of that.
[cpg]


[OnName num="itsuki"]
I think to myself, "...... Charlotte, can you hear me? Can you hear me, Charlotte?
[cpg cn=true]


I wouldn't want this <<Mental Sensing>> to be one-sided.
[cpg]


The most important thing to remember is that the "spirit sensation" is not a one-way street.
[cpg]


;//[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte011"]
[OnName num="charlotte"]
The most important thing to remember is that the best way to get the most out of your money is to use it.　Is this some kind of telekinesis?
[cpg cn=true]


As I was thinking that, I was able to get through.
[cpg]


;//[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte012"]
[OnName num="charlotte"]
"(I'm so surprised. ...... don't scare me, tree.)"
[cpg cn=true]


I heard it. It was Charlotte's voice.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Littule059"]
[OnName num="littule"]
How are you doing?　Are you speaking well?
[cpg cn=true]


[OnName num="itsuki"]
'Yes, I can talk,...... hey, be quiet.'
[cpg cn=true]


Ritul nodded and closed his mouth. In the meantime, I told him what I wanted.
[cpg]


[OnName num="itsuki"]
No, I don't care where you are.　(No, I don't care where you are.)"
[cpg cn=true]


That's not the point. Should I tell him the important thing first?
[cpg]


[OnName num="itsuki"]
The underground city is in danger. Come and help us.
[cpg cn=true]


Charlotte was silent for a while. Then, she returns with this.
[cpg]


;//[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte013"]
[OnName num="charlotte"]
I don't have the right to do that. I summoned the tree, so that's enough, isn't it?　I thought you were going to defeat the evil gods, but you're just moping around.
[cpg cn=true]


Since I could not see the color of his face, I could not tell how angry he was.
[cpg]


I can't tell how angry he is because I can't see the color of his face, but it sounds like he's pretty angry. ...... I guess I'll have to apologize for this.
[cpg]


[OnName num="itsuki"]
"(I'm sorry about that, please, come ......)"
[cpg cn=true]


[OnName num="itsuki"]
"(I don't have anyone else I could ask. Charlotte)"
[cpg cn=true]


When I said that much, Charlotte finally agreed.
[cpg]


;//[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte014"]
[OnName num="charlotte"]
(......I can't help it. Not me?　The guy from Dragonut would be more useful, right?)
[cpg cn=true]


[OnName num="itsuki"]
(Really? ......!　(Thank you.)" "Oh, really?
[cpg cn=true]


;//[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte015"]
[OnName num="charlotte"]
"I'll look for some people who might be able to help us.
[cpg cn=true]


That's how we ended our conversation.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（昼）******************************************************


A few days went by. We were on the defensive again and again, and we were getting poorer and poorer. ......
[cpg]


Ritul is here. And reinforcements were coming.
[cpg]


I felt like I could endure. It is good to have someone to love.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（夜）******************************************************

;//上下に黒帯を入れてください



The first thing that comes to mind is the fact that the first time you see a person in the marketplace, you will know that he or she is a good person.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Littule060"]
[OnName num="littule"]
He said, "You know,...... I've been acting strange lately.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Littule061"]
[OnName num="littule"]
When I talk to you, I feel like I'm not satisfied,......, like I can't talk enough."
[cpg cn=true]


The most important thing to remember is that you can't just take the word of pure love. But ...... there was something strange about the way he was acting.
[cpg]

[OnName num="itsuki"]
"Do you mean you want to kiss me?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Littule062"]
[OnName num="littule"]
No, no,...... no, it's nothing."
[cpg cn=true]


The most important thing to remember is that the best way to get the most out of your money is to use the right tools. He used the word "unfulfilled feelings," but ......
[cpg]

The exact nature of this feeling remains unknown.
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_fi"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（昼）******************************************************


Then. A couple of Dragonut men arrived, and the battle changed considerably.
[cpg]

[SE f="se015"]
;//【ＳＥ】『剣戟』


It looked like we were going to be able to push through. Both Ritul and I sensed that we were going to win, and we were both eager to get going.
[cpg]


The demons were being pushed more and more. It was the opposite of what had happened before.
[cpg]


The men of Dragonute were brave and simply strong.
[cpg]


[OnName num="itsuki"]
"Looks like we can go, Ritul......!
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Littule063"]
[OnName num="littule"]
Oh, I'm so powerful!
[cpg cn=true]


Ritul and I call out to each other. Mercurio is behind us.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Mercurio033"]
[OnName num="mercurio"]
"Good luck, you two, ......!
[cpg cn=true]


[OnName num="dragonute_A"]
We're going to push through!
[cpg cn=true]


[OnName num="dragonute_B"]
Yeah, it's a fight we can win.
[cpg cn=true]


We keep knocking them down. Finally, he defeated ...... the monster of the underground city, the master of the underground city.
[cpg]


The end was a piece of cake....... I didn't think it would be decided in such a split second.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m2"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（夕方）******************************************************


Everything was over. I thought everyone would loosen up there.
[cpg]


But that is not the nature of dwarves.
[cpg]


Rather than taking a break, it was the complete opposite.
[cpg]


The day was a riot. Everyone except the soldiers, who were tired from the battle, were having a festive party.
[cpg]


Ritul was caught up in it. He said he was a brave Dwarf soldier.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

;//[t_move pos=L ゆらゆら]

[VOICE f="Littule064"]
[OnName num="littule"]
'Oh, don't praise me too much. ...... I'm ashamed of you.
[cpg cn=true]


[FG f="CHA06_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mercurio034"]
[OnName num="mercurio"]
'That's really good, that's all sorted ...... out.'
[cpg cn=true]


[OnName num="itsuki"]
'Oh, yes,...... that's really good.'
[cpg cn=true]


And then everyone got drunk and went to bed. ......
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（昼）******************************************************


After that, they were to remain in the underground city for a few days.
[cpg]


Ritul wanted to do that, so that's what happened.
[cpg]


I thought I didn't have long ...... to wait, but it seemed that Ritul and the other dwarves were preparing something.
[cpg]


One day, Ritul proposed to me.
[cpg]


But it wasn't that long after the attack by the dwarves.
[cpg]


I went to the church in the underground city, thinking, "What timing .......
[cpg]


Then, the dwarves gathered to celebrate our marriage in grand style.
[cpg]


Apparently, Ritul was going around calling out to them.
[cpg]


[OnName num="itsuki"]
'...... you been staying for this all this time?'
[cpg cn=true]


Ritul chuckled.
[cpg]


Somehow, I couldn't help but feel that I was being misled,.......
[cpg]


If you and Ritul are going to be together forever, I don't want anything more than that.
[cpg]


In front of God, I pledged my eternal love.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And a little more time passes.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『草原』（朝）******************************************************


Me, Ritul, and Mercurio decided to go back to the forest for now.
[cpg]


Ariel had gone missing and there was no word from her.
[cpg]


Or perhaps that's not surprising, since ...... is quite far from this underground city.
[cpg]


The first thing to do is to meet up with Ariel. And I wanted to have Charlotte with me.
[cpg]


The first thing to do is to get a good idea of what you're looking for.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mercurio035"]
[OnName num="mercurio"]
"As for ...... Ariel, can't you do something about it with the ...... skills you mentioned?"
[cpg cn=true]


[OnName num="itsuki"]
'...... ah. That's for sure.
[cpg cn=true]


It's true. I didn't realize ...... that, and I used "Mental Sensitivity".
[cpg]


[free time=1000]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]

[OnName num="itsuki"]
"(...... Ariel. (Ariel)."
[cpg cn=true]


I thought of Ariel and called out to her.
[cpg]


Ariel was still missing and I had come to help Ritul.
[cpg]


I called out to Ariel, feeling a little uneasy.
[cpg]


[OnName num="itsuki"]
Ariel. Are you safe?
[cpg cn=true]


Silence for a while. I wondered if she was already dead.
[cpg]


If so, my choice was wrong.
[cpg]


;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel111"]
[OnName num="ariel"]
"(Are you ...... tree-sama?　I'm fine, Abram saved me)."
[cpg cn=true]


A normal, normal Ariel voice came back.
[cpg]


[OnName num="itsuki"]
'Ha, ha .......'
[cpg cn=true]


I was weak. The first thing to do is to make sure that you have a good time with your friends and family.
[cpg]


;//[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mercurio036"]
[OnName num="mercurio"]
"Are you safe?　Both Ariel and the forest itself."
[cpg cn=true]


[OnName num="itsuki"]
The forest itself is also safe. Ariel herself is at least safe.
[cpg cn=true]


I asked Ariel more questions. I still don't know about the forest itself," I continued, "but I don't know if she is somewhere else.
[cpg]


I don't know about the forest itself, but I don't know if she is somewhere else.
[cpg]


[OnName num="itsuki"]
"Will we be able to meet up? How about the forest?
[cpg cn=true]


Well, it's going great. That's as good as it gets.
[cpg]


;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel112"]
[OnName num="ariel"]
"(I think Abram can handle the forest, too. ...... I'll join you if we can go together.)"
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel113"]
[OnName num="ariel"]
"...... long time no see. Itsuki."
[cpg cn=true]


Ariel and I have been through a lot. It's awkward, but I have Ritul.
[cpg]

[free time=800]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]

;//[t_move pos=R 下礼]

[VOICE f="Littule065"]
[OnName num="littule"]
I've been worried about you. I was worried about you.
[cpg cn=true]


Ritul is attached to Ariel. They had been friends for a long time," Ritul said.
[cpg]


We were getting pretty close to the first group.
[cpg]


[OnName num="itsuki"]
That's half of .......
[cpg cn=true]


Ariel. Ritul. And Mercurio ...... half of us.
[cpg]


The other half are all a bit of a fickle lot. I don't think we're going to get them all soon.
[cpg]


[OnName num="itsuki"]
Who do we go to next ......?"
[cpg cn=true]


Hermia seems to be a bit of a rogue, and Charlotte seems to be a bit of a hard-ass.
[cpg]


The most likely to be able to be a companion is the most likely to be able to be a companion.
[cpg]


[OnName num="itsuki"]
The one who seems the most likely to join us is Charlotte or ......?"
[cpg cn=true]


The remaining three nodded. It seemed that they had already reached a consensus.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Littule066"]
[OnName num="littule"]
I agree. The other day, they sent us reinforcements of dragonutes.
[cpg cn=true]


I guess so. It wasn't like they didn't listen to us.
[cpg]


Just because they send their friends, it can be taken as a sign of trust.
[cpg]


[OnName num="itsuki"]
The question is, where are they ......?
[cpg cn=true]


[OnName num="itsuki"]
Should we try asking him again?"
[cpg cn=true]


Ariel shakes her head. Then he says, "Yes.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Ariel114"]
[OnName num="ariel"]
'Well, ...... if it's where the dragons live, I can tell you where they are.
[cpg cn=true]


[OnName num="itsuki"]
Well, that makes things a lot quicker.
[cpg cn=true]


So we head off to the township where the dragons live......
[cpg]



;//ブラックアウト

;//////////////////////
;//ヒロイン2に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1100]
[window target=true]
;//[BGM f="bg_ne"]
;//[WAIT time=100]


We had a long walk ahead of us.
[cpg]

No matter how far we walked, we never got tired when we were with the tree.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『ドラゴンの住処』（昼）******************************************************


And then we arrived at the home of the dragons. ...... It was a sheer mountain or valley.
[cpg]


[OnName num="itsuki"]
It's an amazing place,...... a fantasy."
[cpg cn=true]


There was a mix of real dragons there, and a dragonaut-like race of dragon people called Dragonutes.
[cpg]


Charlotte must be here too. I immediately had an idea.
[cpg]


[OnName num="itsuki"]
Look ......, that's really a dragon."
[cpg cn=true]


The fact that dragons and dragonutes are conversing with each other is a strange sight.
[cpg]


And then we went to see where Charlotte was.
[cpg]


Charlotte looked unhappy.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte016"]
[OnName num="charlotte"]
I'm sorry for your trouble," she said. But I'm not going.
[cpg cn=true]


[OnName num="itsuki"]
If you don't defeat the ...... evil god, the world will be destroyed.
[cpg cn=true]


Charlotte was feeling unattached.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
;//[t_move pos=C ゆらゆら]
[VOICE f="Charlotte017"]
[OnName num="charlotte"]
"And we never know what we'll find in our hometowns."
[cpg cn=true]


[free time=800]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Littule067"]
[OnName num="littule"]
'Oh, no,...... but if we defeat the evil gods, it'll be quicker.
[cpg cn=true]


I thought it was a good thing to say.
[cpg]


And then she said, "Why are you telling me what to do?
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Charlotte018"]
[OnName num="charlotte"]
You're telling me what to do?　I can't keep up with you.
[cpg cn=true]


I have never been able to negotiate well in such situations.
[cpg]


I wondered if I wasn't a good negotiator.
[cpg]


[OnName num="itsuki"]
"This is going to take a long time to convince them. ......
[cpg cn=true]


[OnName num="itsuki"]
But I'll convince him. I'll persuade him.
[cpg cn=true]


[free time=1000]

I was so curious that I let my curiosity get the better of me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Littule068"]
[OnName num="littule"]
"Okay, I get it. I want to do some sightseeing. Let's all go together."
[cpg cn=true]


Mercurio and Ariel were puzzled.
[cpg]


Maybe they think the more people they persuade, the better.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="1/3" time=800]
[VOICE f="Mercurio037"]
[OnName num="mercurio"]
'Yes, are you sure ......?'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="Ariel115"]
[OnName num="ariel"]
Maybe it's good because Tree-sama says so. ......
[cpg cn=true]


I've never been to a place like this before.
[cpg]


The world really is a big place.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ドラゴンの住処』（昼）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="1/3" time=800]

[VOICE f="Littule069"]
[OnName num="littule"]
It's strange that there is a town on such a rocky shore.
[cpg cn=true]


I looked at the city as I scanned the landscape.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="3/3" time=800]
[VOICE f="Ariel116"]
[OnName num="ariel"]
It sure is different from my hometown, isn't it?
[cpg cn=true]


It must be an unusual place, even for Ariel.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Littule070"]
[OnName num="littule"]
I wonder what life is like for a dragonut?　I'm going to go in for a look.
[cpg cn=true]


I said and tried to enter the house.
[cpg]


Ariel and Mercurio, who have more common sense than I do, stopped me.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_5"  pos="1/3" time=800]
[VOICE f="Mercurio038"]
[OnName num="mercurio"]
Mr. Ritul, you can't!
[cpg cn=true]


[free time=1000]

I didn't even hear them stop me, and I walked right into the house of the dragonet.
[cpg]


I said, "Ojamashimasu! Then, I see ......
[cpg]

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


[SE f="se007"]
;//【ＳＥ】『ドア開く』

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

There, the Dragonutes were living as they pleased.
[cpg]


[OnName num="dragonute_A"]
Oh, my dear, dear girl.
[cpg cn=true]


[OnName num="dragonute_B"]
Are you the brave group I told you about?　Well, take your time.
[cpg cn=true]


They are all so kind to sudden visitors. ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『ドラゴンの住処』（夜）******************************************************

;//上下に黒帯を入れてください


The tree negotiations went on for a long time.
[cpg]


I think it's partly because Charlotte is stubborn. But the result is the same.
[cpg]


All the while, I was suppressing my desire to talk to the tree.
[cpg]


[SE f="se007"]
;//【ＳＥ】『ドア開く』


The door opens. I wondered if I had locked the door.
[cpg]


By chance, a man in a dragonut came in while I was changing my clothes.
[cpg]


[OnName num="dragonute"]
He said, "Oh my God, ......, I'm sorry."
[cpg cn=true]


He was opening the door after I had seen him naked the other day. He must have had something to do with me, because he walked in without knocking.
[cpg]


I was puzzled, but tried to make things right.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Littule071"]
[OnName num="littule"]
I was embarrassed, but made myself comfortable.
[cpg cn=true]


[free time=1000]

I was blushing bright red. The reason for this is because I was just embarrassed.
[cpg]


How can you say that you don't expect something to happen after this ......?
[cpg]


And then I faced that dragonut. The business wasn't much.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Littule072"]
[OnName num="littule"]
"I'm sorry,...... I didn't mean to startle you."
[cpg cn=true]


[OnName num="dragonute"]
No, no. I'm sorry I didn't knock.
[cpg cn=true]


[OnName num="dragonute"]
I thought you were a man, since you said you were a dwarf with a brave man.
[cpg cn=true]


And then the conversation got down to business. He wanted me to come along with him to get some food for his long stay. ......
[cpg]


It didn't matter. I would do that as much as I could.
[cpg]


I answered, and kept him in the dragonet's arms.
[cpg]



[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Littule073"]
[OnName num="littule"]
I said, "Hey, can I talk to you for a minute? I just have a few more things I want to talk to you about.
[cpg cn=true]


There was really nothing to talk about. But I wanted to drown my loneliness.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I was beyond the point of feeling sorry for him.
[cpg]


I'm betraying you.
[cpg]


But for some reason,......, even when I was with the tree, I had a feeling that I wasn't satisfied.
[cpg]

;//移植のためシーンをカットしています

;//qwe

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『ドラゴンの住処』（夜）******************************************************


I managed to convince Charlotte.
[cpg]


I understand, I'll go with you. How long did it take to get that one word out of her?
[cpg]


Thinking it was a long time, I went to report to Ariel, Ritul, and Mercurio.
[cpg]


Ariel was honestly pleased.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Ariel117"]
[OnName num="ariel"]
'I see,......, that's good.
[cpg cn=true]


[FG f="CHA06_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mercurio039"]
[OnName num="mercurio"]
'Well, that's a relief, isn't it?
[cpg cn=true]


[OnName num="itsuki"]
'What about Hermia?　I think we should take her with us.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Ariel118"]
[OnName num="ariel"]
'Hermia's ...... well, I suppose. She's always here, or she's not.
[cpg cn=true]


Indeed. That's the way I feel about it.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Mercurio040"]
[OnName num="mercurio"]
I wonder what she's thinking .......
[cpg cn=true]


I reported like that, and at the end of the day, when Ritul was alone .......
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I saw ...... something extraordinary in Ritul's room.
[cpg]


I didn't want to see it. But I did.
[cpg]

;//移植のためシーンをカットしています

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1000]

Ritul is kissing a dragonet, who I don't know who it is.
[cpg]

[OnName num="itsuki"]
"Oh no............why?"
[cpg cn=true]


Ritul notices me and looks surprised.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Littule074"]
[OnName num="littule"]
The tree ...... is that ......."
[cpg cn=true]


Ritul tries to make things right.
[cpg]

It looks like it's been left alone for a long time.
[cpg]


I tried to say. I tried to say, "Ritul, I still love you.
[cpg]


But the words that came out of my mouth were: ......
[cpg]


[OnName num="itsuki"]
I don't know you anymore......!　I don't even want to see your face."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
Ritul looked a little sad.
[cpg]


I mean, what did I just say?　Why am I saying this?
[cpg]


I tried to correct him and said again. Words of love: ......
[cpg]


[OnName num="itsuki"]
You didn't give a shit about me from the very beginning!
[cpg cn=true]


No, I'm not. This is not what I'm trying to say.
[cpg]


I'm not trying to say this, but I'm wondering if there's some kind of skill at work here, words that are so different from my feelings.
[cpg]


I couldn't stand what was happening to me and what was happening right in front of me, so I got out of there.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[free time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************


The next day we had to leave.
[cpg]


Ritul and I remain awkward. Even as we think like that, demons appear.
[cpg]


We have to fight. I thought about Ritul, but my mind kept flickering back to Ritul.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
;//[t_move pos=C 動揺]
[VOICE f="Ariel119"]
[OnName num="ariel"]
I thought to myself, "Tree-sama, look out!
[cpg cn=true]


I was fighting while thinking unnecessary things, I guess. ......
[cpg]



[SE f="se013"]
;//【ＳＥ】『倒れ込む』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************


I received a heavy blow to the back of my head and fell down.
[cpg]


I was calmly thinking, "This pain is a series of blunt objects. ......
[cpg]


I didn't even properly grasp what I was fighting. I'm fighting with that kind of feeling, and that's why I'm in this ......
[cpg]


[OnName num="itsuki"]
Gosh,......."
[cpg cn=true]


[SE f=se085]
;//【ＳＥ】『倒れる』
[WAIT time=1000]

I fell down, and after the fight, the girls were worried about me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_3"  pos="2/2" time=800]

[VOICE f="Mercurio041"]
[OnName num="mercurio"]
"Pull yourself together, Itsuki-san!"
[cpg cn=true]


I hear Mercurio's voice.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Ariel120"]
[OnName num="ariel"]
Don't die, please!　Don't die, please ......!"
[cpg cn=true]


I hear Ariel's earnest voice: ......
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Mercurio042"]
[OnName num="mercurio"]
The wounds must be shallow,......, did they shake your brain?
[cpg cn=true]


[free time=800]

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Charlotte019"]
[OnName num="charlotte"]
Wake up!　Tree, tree, tree, tree iiiiiiiiiiiiiiiiiiiiiiii"
[cpg cn=true]


Charlotte's plaintive voice. I wanted to say something in reply.
[cpg]


[OnName num="itsuki"]
"......."
[cpg cn=true]


But no voice came out. Oh, is it over already?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Ariel121"]
[OnName num="ariel"]
Please!　Wake up!
[cpg cn=true]


They repeatedly called out to me.
[cpg]


[free time=1000]

The only voice calling my name like that was not from ...... Ritul.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Littule075"]
[OnName num="littule"]
......."
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Oh, in short, I thought, that's what it's all about.
[cpg]


With Ariel, would I have been better off if I had tied the knot...... No, that idea itself is already wrong.
[cpg]


I'm sure I'm not supposed to be with the person I really love.
[cpg]


......But then.
[cpg]


Why couldn't I just say the words of love straight to her?　I think back.
[cpg]


Come to think of it, there was also a skill called "Heaven's Evil. ......
[cpg]


What kind of skills was that?
[cpg]

;//ヒロイン２　ルート　人間寝取られ

;//////////////////////
;//ヒロインに視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『草原』（夕方）******************************************************

There is someone who is trying to tear apart the relationship between ...... tree and me.
[cpg]

The most important thing to remember is that you can't get a good deal on a good deal on a good deal on a good deal on a bad deal on a good deal on a bad deal.
[cpg]

I'm sure he still loves me.
[cpg]

I understand that feeling. I couldn't leave him, even if he doesn't wake up now.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/5" time=800]
[VOICE f="Littule076"]
[OnName num="littule"]
I'm going to stay here. I want to start over with you.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="4/5" time=800]
[VOICE f="Ariel122"]
[OnName num="ariel"]
I'm sure you'll be able to find a way to get a new job. And ......
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Ariel123"]
[OnName num="ariel"]
"Maybe the two of you are destined to never be together."
[cpg cn=true]


Ariel dares to say harsh words.
[cpg]

 But I didn't give up yet.
[cpg]

I had betrayed the tree many times, so ......
[cpg]

I couldn't betray him again.
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

So I kept waiting for the tree to wake up.
[cpg]

I've been waiting for the tree to wake up for a long time.
[cpg]

But as long as she didn't wake up,......, I thought this was not a lost love.
[cpg]


;//ＥＮＤ：ヒロイン２　ルート　人間寝取られ


;//[Ending_SetUp cl=cl_004 ss=false]


[SCENE id=17]

[system cl_004=true]


[jump storage="epend.ks" target="*start"]
