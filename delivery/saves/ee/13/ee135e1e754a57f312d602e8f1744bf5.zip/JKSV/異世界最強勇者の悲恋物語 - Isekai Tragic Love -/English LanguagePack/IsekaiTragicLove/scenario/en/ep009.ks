
*start


;#################################################
*Ep009|Despite my doubts
;#################################################


[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夕方）


*select08_2|Despite my doubts.

[SCENE id=9]


...... No, I'm with you no matter what you think.
[cpg]


I had my doubts, but I set out.
[cpg]


I'm going to take Ritul and the others to defeat the evil gods.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_op"]
;//背景をいくつか流す感じで場面転換
[WAIT time=2000]
;//【ＢＧ】『草原』（昼）******************************************************

[BG f="b_05_2.ui" time=1000]
[WAIT time=2000]
;//【ＢＧ】『街』（昼）******************************************************

[BG f="b_09_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『浮遊都市レルムレルム』（朝）******************************************************

The floating city of realm realm. We go to the final battle.
[cpg]

The demons were unusually powerful there.
[cpg]

The evil god itself was a huge stone, or really just something like that.
[cpg]

The evil god did not attack me. The demons, which became unusually strong with the power of the evil god, attacked us.
[cpg]


We can't fight them with the magic we've used so far. Even "Magic II" didn't work.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/3" time=800]
[FG f="CHA05_p1_01_a.ui" method="change_3"  pos="3/3" time=800]

In addition, the attacks of Ritul and Charlotte were also ineffective against the demons.
[cpg]

So I decided to acquire a new skill.
[cpg]


It was called "Magic III. I had obtained the ultimate skill.
[cpg]


;//[OnName num="itsuki"]
;//「くらえっ！」
;//[cpg cn=true]

;//[SE f="se016"]
;//【ＳＥ】『爆発』

I inflicted a wound on the evil god, which could not be wounded by any normal attack.
[cpg]


;//[SE f="se017"]
;//【ＳＥ】『爆発』

It cracks. It cracks. It shatters, almost.
[cpg]

;//[SE f="se016"]
;//【ＳＥ】『爆発』

;//皆が魔物を抑えてくれている間に、早く…早くっ…！
;//[cpg]

And the ...... moment when the evil god is defeated.
[cpg]


I never thought I'd come this far. I didn't expect ...... to hear those words.
[cpg]


[OnName num="itsuki"]
"What ......?"
[cpg cn=true]


I was stabbed in the back by someone.
[cpg]



[SE f="se018"]
;//【ＳＥ】『刺す音』

[free time=1000]
[BG f="red.ui" time=1000]
[WAIT time=1000]
;//赤フラッシュ



[SE f="se013"]
;//【ＳＥ】『倒れる』

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


I didn't have any enemies behind me. I thought so, but I was caught off guard.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Charlotte021"]
[OnName num="charlotte"]
I was just thinking that, and then I was caught off-guard.　Tree, hey ......!
[cpg cn=true]

I hear Charlotte's voice. Ritul's voice was also ......
[cpg]



[free time=800]

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/2" time=800]

[VOICE f="Littule084"]
[OnName num="littule"]
No, you can't die, Tree!
[cpg cn=true]


I was just fading away.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Charlotte022"]
[OnName num="charlotte"]
I was still in and out of consciousness. "Oh no, who's there, patch him up ......!"
[cpg cn=true]


[VOICE f="Littule085"]
[OnName num="littule"]
No! Wake up, wake up, please!
[cpg cn=true]


;//ブラックアウト

;//////////////////////
;//ヒロイン1に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夕方）******************************************************

[FG f="CHA01_p3_03_a.ui" method="change_4"  pos="2/3" time=800]

I received the news of his death.
[cpg]


I was not surprised by the news. I thought so.
[cpg]


The news was that Itsuki had been killed in battle. ......
[cpg]

;//[t_move pos=C 動揺]
I was flabbergasted. Was it true?
[cpg]


I heard that he was killed in battle with an evil god. I had a strange feeling in my heart.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
Abram held me in his arms as I wobbled.
[cpg]


[OnName num="abram"]
I was so upset that I couldn't even think about it.　Ariel, pull yourself together, I know you're sad that he's dead.
[cpg cn=true]


Sad. That's probably a necessary emotion.
[cpg]


I would be crazy not to feel sad under the circumstances.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel172"]
[OnName num="ariel"]
'...... it's different. There were other emotions at play here than sadness.
[cpg cn=true]


I am. Why am I having these feelings?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel173"]
[OnName num="ariel"]
I was relieved ...... that I didn't have to make excuses to my tree-sama.
[cpg cn=true]


Such a woman, not even Abram deserves to be loved......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel174"]
[OnName num="ariel"]
"I'm such a helpless woman,...... I'm sure I was always like that."
[cpg cn=true]


Abram speaks kindly to me as I say this.
[cpg]


[OnName num="abram"]
He says, "...... you're not terrible, you're just normal. It's a normal feeling.
[cpg cn=true]


Abram is kind. I want to leave everything to him.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel175"]
[OnName num="ariel"]
I'm not normal. I have such an ugly heart. ......
[cpg cn=true]


I'm sure he'll return these words in kind. ......
[cpg]


[OnName num="abram"]
You've done nothing wrong, ......."
[cpg cn=true]


See, that's right. I am spoiled by him.
[cpg]


But I can't get enough of that relationship ...... and it calms me down.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel176"]
[OnName num="ariel"]
Don't be so kind, ......."
[cpg cn=true]


This disturbed emotion settles in Abram's arms.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel177"]
[OnName num="ariel"]
"Gosh, ohhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh!"
[cpg cn=true]


This body, stained with pleasure, is no longer in control.
[cpg]


Will my sinfulness ever truly be forgiven......
[cpg]


I don't know. I don't know, but the tree is dead.
[cpg]


I don't know how to atone for it, but I don't know if it was a sin that could be atoned for.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************


Later, I gave birth to a child.
[cpg]


Then a startling revelation came to light.
[cpg]


I was half-human, which means I was the child of ...... tree-sama.
[cpg]


If I raised him as such, he would be considered a heretic. I left him with a tribe of torrents who lived deep in the forest.
[cpg]


It was painful for me because I felt like I was really parting ...... ways with my tree-sama, but I had no choice.
[cpg]


But I had to do this. I have to find my happiness.
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（恋人にすがりつくヒロイン）ev_50
;//人物１：ヒロイン１
;//服装１：着衣
;//人物２：エルフの男・親友
;//服装２：着衣
;//場所　：
;//時間　：
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="abram"]
I don't have ...... anything to feel guilty about anymore. Ariel."
[cpg cn=true]


Abram told me so. But I still had my doubts.
[cpg]

I still wanted to fill the hole in my heart.
[cpg]


I sought and clung to someone who wasn't Tree-sama.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



After that, Abram and I made love.
[cpg]


The evil god was crushed and peace came to the world. It was all thanks to the tree.
[cpg]


It's as if everything was moving for me to be united with Abram. ......
[cpg]


I don't know what happened to bring about this ending.
[cpg]


I don't know, I don't know.
[cpg]


I was happy now. ......
[cpg]

;//ヒロイン１　ルート　親友寝取られ
;//ＥＮＤ


;//[Ending_SetUp cl=cl_006 ss=false]

[SCENE id=18]


[system cl_006=true]

[jump storage="epend.ks" target="*start"]

