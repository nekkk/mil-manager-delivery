
*start


;#################################################
*Ep0002|Protecting the Great Forest
;#################################################


[if exp={isSystemFlagsEnabled("sysSel1flg")}]
[stflag Sel1flg = 2]
[else]
[stflag Sel1flg = 1]
[endif]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（昼）


*select03_1|Defending the Great Forest

[SCENE id=2]

[free time=800]

[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="2/2" time=800]


[OnName num="itsuki"]
...... can we let Ritul and Mercurio handle this situation?"
[cpg cn=true]


I made a hard decision. I just can't protect it all.
[cpg]


[VOICE f="Littule025"]
[OnName num="littule"]
"What ......?　Then ......."
[cpg cn=true]


Ritul looked surprised.
[cpg]


[OnName num="itsuki"]
'I'm concerned about the Great Forest of Acecto. I can't leave it alone."
[cpg cn=true]


That was the conclusion I came to. Mercurio was also surprised.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Mercurio019"]
[OnName num="mercurio"]
"Why? Do you mean that you will leave us alone?
[cpg cn=true]


I had no answer. But the fact was that he was going to leave us alone.
[cpg]


I was going to give top priority to Ariel. That's what he was saying.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Littule026"]
[OnName num="littule"]
I managed to keep my mouth shut.
[cpg cn=true]


I continue to say the words that I manage to cover up.
[cpg]


[OnName num="itsuki"]
I'm not sure, but if you completely revive the Great Forest of Acecto, you can summon other people besides me, right?
[cpg cn=true]


[free time=800]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Ariel065"]
[OnName num="ariel"]
I wonder, Hermia ......?
[cpg cn=true]


Ariel asked Hermia.
[cpg]


 Hermia put her hand on her chin and made a thinking gesture.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Elmyr022"]
[OnName num="elmyr"]
I don't know," she said, "I don't know. ...... It could happen.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Elmyr023"]
[OnName num="elmyr"]
'You could say the opposite. If that forest gets hit, we're stuck with it.
[cpg cn=true]


I see. It makes sense to protect that forest after all.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Ariel066"]
[OnName num="ariel"]
But is it good for you ......?　If you're doing that with me in mind, then ......
[cpg cn=true]


[OnName num="itsuki"]
No, it's more of a calculating thing. Never mind."
[cpg cn=true]


I said that to Ariel, but she was pouting and her cheeks were stained.
[cpg]


I guess I've fallen for it,......, although that seems like it would make me happy.
[cpg]


Or rather, that's what I'm hoping for.
[cpg]


[free time=1000]

If I defend that forest, Ariel won't be able to ...... about me.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
;//[t_move pos=C 下礼]
[VOICE f="Littule027"]
[OnName num="littule"]
"Oh, I'm not going ...... there. I'm not going to . I'm going to protect this place.
[cpg cn=true]


Ritul looked angry. I think he had every right to be.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Littule028"]
[OnName num="littule"]
I will protect my hometown. If the tree doesn't protect me, I will.
[cpg cn=true]


Mercurio followed Ritul's words.
[cpg]


[free time=1000]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA06_p3_02_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Mercurio020"]
[OnName num="mercurio"]
I agree with you. Even here, we are in danger of being attacked by demons at any moment.
[cpg cn=true]


That's right. The same is true for both of us when it comes to danger.
[cpg]


[FG f="CHA06_p3_02_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Mercurio021"]
[OnName num="mercurio"]
And ...... we mermaids are no longer helping with the poaching, are we?
[cpg cn=true]


Mercurio seemed a little irritated. I don't think I have a choice in this either.
[cpg]


I chose that path, so I had no choice.
[cpg]


[OnName num="itsuki"]
I'm sorry. I'll be right back.
[cpg cn=true]


I bowed my head. I bowed my head.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
;//[t_move pos=L 下礼]
[VOICE f="Littule029"]
[OnName num="littule"]
"Tree ......, I'll be there for you.
[cpg cn=true]


[FG f="CHA06_p3_02_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Mercurio022"]
[OnName num="mercurio"]
I'll be waiting for you at ......."
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se002"]
;//【ＳＥ】『泳ぐ』


So, with the help of Mercurio and Mermaid, we returned to the ground again.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


We decided to take a rest in a town on the way.
[cpg]


We take a lodging. At that time, Ariel said to me.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ariel067"]
[OnName num="ariel"]
Thank you so much. I am so happy ...... I don't know what to do."
[cpg cn=true]


Ariel's face was red as she said this.
[cpg]


I was so embarrassed that I didn't know how to answer.
[cpg]


[OnName num="itsuki"]
I don't do it for Ariel, I do it for me.
[cpg cn=true]


I said with a hint of embarrassment.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
Ariel didn't say anything. Ariel just looked at me and stared blankly.
[cpg]


...... I was also thinking of restoring the Great Forest of Acecto, since Ariel is a bit concerned about the actual problem.
[cpg]


But I did my best not to let her realize that.
[cpg]


If they realized that, they would be too sorry to Ritul and Mercurio. ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

;//上下に黒帯を入れてください



We decided to rest at the inn.
[cpg]


In the midst of all this, as expected,...... Ariel visited my room.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Ariel068"]
[OnName num="ariel"]
"I'd like to thank you for ...... something,...... tree-sama."
[cpg cn=true]


Ariel seemed to have a slightly hot or sexy expression on her face.
[cpg]


The first thing that comes to mind is the fact that the two are not the same.
[cpg]


[OnName num="itsuki"]
"Didn't I tell you not to worry about it?　It's what I want to do."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel069"]
[OnName num="ariel"]
'Thank you ....... Are you sure, I don't have to do anything?"
[cpg cn=true]


Ariel seemed to be concerned about it all the time.
[cpg]


I was trying to figure out what to say to her.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel070"]
[OnName num="ariel"]
'I'll do whatever I can, so ......
[cpg cn=true]


[OnName num="itsuki"]
"That's okay. Don't worry about it."
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『草原』（朝）******************************************************




And then morning came again, and we walked for a while, and we went back to the Great Forest.
[cpg]


[OnName num="itsuki"]
Hey, I don't see Hermia .......
[cpg cn=true]


Hermia's not here. I told Ariel about it.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel071"]
[OnName num="ariel"]
I told Ariel about it, but he said, "It's happened before. She's fickle.
[cpg cn=true]


And yet, she is gone, having alerted us to the crisis in the Great Forest of Asekto. ......
[cpg]


What does that mean? Should we look for Hermia?
[cpg]


Or should we prioritize returning to the Great Forest?
[cpg]

;//「ヒロイン３　ルート　黒幕発覚」を通っていない場合この選択肢は発生しない
;//選択肢が発生しない場合「９、今は大森林に戻る」で固定される


[if exp={isSystemFlagsEnabled("cl_005")}]
[jump target="*No_Kuromaku"]
[endif]

[jump target="*select04_2"]



*No_Kuromaku|Protecting the Great Forest


;//■選択肢
[switch]
[case "Going after Hermia"]
	[swap]
	[jump target="*select04_1"]
[case "Now back to the Great Forest"]
	[swap]
	[jump target="*select04_2"]
[endswitch]


8, follow Hermia
9, Now return to the Great Forest

;//==============================
;//８、エルミアの後を追う
*select04_1|Obsessed with Hermia
[jump storage="ep014.ks" target="*start"]



;//==============================
;//９、今は大森林に戻る


*start


;#################################################
;//*Ep002|大森林を守る
;#################################################


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『草原』（朝）


*select04_2|Protecting the Great Forest


I still think the Great Forest should be my priority, so I head back to the forest.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]


[OnName num="elf_man"]
'You're back, Ariel ......!　And you too, my brave sir."
[cpg cn=true]


I was told by an elven man whom I did not know who he was.
[cpg]


He had a smile on his face. Had I ever talked to him before?
[cpg]


[OnName num="itsuki"]
"Well, ......, have we met somewhere?"
[cpg cn=true]


[OnName num="elf_man"]
Oh, I'm sorry ...... you're surprised to hear me speak to you so suddenly.
[cpg cn=true]


The elf man says so. And then Ariel called me this.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel078"]
[OnName num="ariel"]
'Abram. You're safe. ......"
[cpg cn=true]


The man called Abram was also an elf.
[cpg]


What kind of relationship does he have with Ariel?　He is quite easygoing.
[cpg]


What is your relationship with Ariel?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel079"]
[OnName num="ariel"]
What's going on in the forest right now?
[cpg cn=true]


[OnName num="abram"]
What's going on in the forest right now? I want you to take a look at this map: ......."
[cpg cn=true]


Abram spread the map on the desk. I recognized it as a map of this forest.
[cpg]


The Great Forest of Acecto. The forest, which had been divided, is now trying to return to one village again after eliminating the demons.
[cpg]


There are several cross marks on the map. It seems that ......
[cpg]


It seems that the demon is springing from here. And it seems that they are not just springing up.
[cpg]


They were springing up one after another. I don't even know how they came about.
[cpg]


[OnName num="itsuki"]
Is it possible for the number of demons to increase that much ......?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel080"]
[OnName num="ariel"]
The power of the evil god. I'm not going to be able to do anything about it without defeating that thing.
[cpg cn=true]


[OnName num="itsuki"]
"Yes,......, but we have to do something about this place first,.......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel081"]
[OnName num="ariel"]
I'll leave it up to you to decide what to do,...... but I'll ......
[cpg cn=true]


I think.
[cpg]


You can find a lot of different types of products and services available on the market.
[cpg]


I'm also concerned about the underground city. What should I do? After thinking about it, I came to a conclusion.
[cpg]

;//■選択肢
[switch]
[case "Prioritize the forest."]
	[swap]
	[jump target="*select05_1"]
[case "Back to the underground city"]
	[swap]
	[jump target="*select05_2"]
[endswitch]


*select05_2|Return to the underground city
[jump storage="ep005.ks" target="*select05_2"]


10. Forest first.
11. Return to the underground city


;//==============================
;//１０、森を優先

;#################################################
;//*Ep002|大森林を守る
;#################################################

*select05_1|Protecting the Great Forest


[OnName num="itsuki"]
I know ......, but I want to do something about the Great Forest of Acecto first.
[cpg cn=true]


It is also for Ariel's sake. I don't want to see her sad face.
[cpg]


It is already quite personal, but I can't help it.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ariel082"]
[OnName num="ariel"]
Oh, thank you, ...... tree-sama."
[cpg cn=true]


I may be the hero of salvation, but I'm just a person. I can't stand to see someone in trouble.
[cpg]


With this in mind, I asked Ariel, "Where should I go first?
[cpg]


[OnName num="itsuki"]
Where should I go first?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel083"]
[OnName num="ariel"]
The demons are springing up again at ...... and at this point.
[cpg cn=true]


[OnName num="abram"]
I don't know what to do.
[cpg cn=true]


Ariel points to the crossed-out mark on the map. The map is quite extensive," Ariel said.
[cpg]


Can you go ahead and defeat them all... No.
[cpg]


No. We can't go in there weak. I want to finish this as soon as possible.
[cpg]


[OnName num="abram"]
What do we do now, brave man?　I think we should take a break here. ......
[cpg cn=true]


I wanted to see Ariel's smiling face,.......
[cpg]


[OnName num="itsuki"]
The most important thing to remember is that you can't just go out and buy a new one. Let's go."
[cpg cn=true]


[OnName num="abram"]
I'm not sure I'm ready for this.　But ......
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
;//[t_move pos=C 動揺]
[VOICE f="Ariel084"]
[OnName num="ariel"]
But  I'm not. It's nighttime. We can't fight in here.
[cpg cn=true]


[OnName num="itsuki"]
That's true, but ...... I can't stand by and watch the forest get hit.
[cpg cn=true]


I'm not going to stand by and watch the forest get hit.
[cpg]


[OnName num="abram"]
I'm not going to stand by and watch the forest get hit.　Demons have better night vision, you might want to rethink that.
[cpg cn=true]


[OnName num="itsuki"]
Don't stop me. The more we do this, the more damage will be done.
[cpg cn=true]


[OnName num="abram"]
No, if the hero-sama gets hit, it won't be about more damage!
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel085"]
[OnName num="ariel"]
Yes, no matter how many trees you have, I think you will be at a disadvantage in this battle.
[cpg cn=true]


I finally reconsidered after being told that much.
[cpg]


However, the feeling of unwillingness remained.
[cpg]


[OnName num="itsuki"]
...... I see that. ......
[cpg cn=true]


What a brave man. I can't do anything after all. ......
[cpg]

[free time=1000]

It's frustrating. I decided to take a rest that day, feeling frustrated.
[cpg]

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


Then I rested for a while in the hut. Ariel comes again.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel086"]
[OnName num="ariel"]
Thank you, Itsuki. Thank you very much, Itsuki.
[cpg cn=true]


[OnName num="itsuki"]
I said, "...... it's a little early to thank you yet."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel087"]
[OnName num="ariel"]
I don't even have the words.......I've never been so kind."
[cpg cn=true]


Ariel is still saying it. I stopped her.
[cpg]


[OnName num="itsuki"]
I'm not going to thank you anymore. I'm not thanking you anymore, I'm thinking about tomorrow.
[cpg cn=true]


Ariel shakes her head. Then he comes closer to me.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Ariel088"]
[OnName num="ariel"]
I can't do this to us elves and not return the favor .......
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
With that, she moves closer to me. Ariel is there, just close enough for our lips to touch.
[cpg]


[OnName num="itsuki"]
I said to her, "...... you shouldn't take this kind of thing lightly."
[cpg cn=true]


I said, trying to hold Ariel back and calm myself down at the same time.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Ariel089"]
[OnName num="ariel"]
I'm serious. I love you.
[cpg cn=true]


[OnName num="itsuki"]
Ariel ......
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel090"]
[OnName num="ariel"]
No one moves my heart more than you do.
[cpg cn=true]


I had a feeling that one day this would happen. I had a feeling that this would happen someday, and I couldn't deny it.
[cpg]


Ariel is beautiful. There was no such a beautiful girl in the reality I was in.
[cpg]


But I shouldn't take advantage of ...... her goodwill either.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Ariel091"]
[OnName num="ariel"]
"...... Itsuki-sama. In truth, it is forbidden for humans and elves to fall in love, right?"
[cpg cn=true]


[OnName num="itsuki"]
Is that so,......?"
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel092"]
[OnName num="ariel"]
Yes, it is. You don't know that, do you?
[cpg cn=true]


No, it's very likely. Elf seems like a noble thing.
[cpg]


They hated Hermia, the dark elf, and maybe they don't like mixed blood.
[cpg]


But if it was ......, why did Ariel approach me?
[cpg]


I stare at Ariel, wondering about that.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Ariel093"]
[OnName num="ariel"]
But I'm done."
[cpg cn=true]


[OnName num="itsuki"]
I see."
[cpg cn=true]


I could only say that.
[cpg]


[OnName num="itsuki"]
I've never had a girlfriend before.
[cpg cn=true]


Ariel laughs a little. She might be similar to me.
[cpg]


I couldn't say anything clever. Still, Ariel seemed to think something of me.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

And so we exchanged kisses.
[cpg]

Ariel seemed happy to see me. ......
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

;//==============================
;//最初の選択肢で「剣」を選んでいた場合
[if exp={getFlagValue("Sel1flg") == 2 }]
[jump target="*select_first_masic"]
[endif]

[jump storage="ep003.ks" target="*select_first_ken"]


;//==============================
;//最初の選択肢で「魔法」を選んでいた場合
*select_first_masic
[jump storage="ep008.ks" target="*select_first_masic"]

