
*start

;#################################################
*Ep006|We're on our own.
;#################################################


*select07_1|We'll protect it alone.

[SCENE id=6]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（朝）******************************************************


Then comes morning.
[cpg]


Already, we had a plan. It wasn't much of a plan, though.
[cpg]


We decided to hit the demons from our side.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_3"  pos="2/2" time=800]

[VOICE f="Mercurio025"]
[OnName num="mercurio"]
You mean intercepting them. ......
[cpg cn=true]


Mercurio looked anxious.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Littule040"]
[OnName num="littule"]
'It's going to be an interceptive battle. That's different from what we've been doing.'
[cpg cn=true]


Until now, it was a defensive battle. It can be said to be the opposite.
[cpg]


[OnName num="itsuki"]
It's going to be like that. Anyone who disagrees doesn't have to come. It's dangerous.
[cpg cn=true]


I had planned to do it on my own. I wasn't going to force Mercurio or anyone else to go with me.
[cpg]


I had an idea how Ritul would react to ...... the situation.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
;//[t_move pos=L 下礼]
[VOICE f="Littule041"]
[OnName num="littule"]
I'm going to go. I can't retreat here."
[cpg cn=true]


[OnName num="itsuki"]
I knew you would say that. Let's go.
[cpg cn=true]


[FG f="CHA06_p1_02_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Mercurio026"]
[OnName num="mercurio"]
"I ...... can't go with you. It's too risky."
[cpg cn=true]


Mercurio's reaction is generally as you might imagine.
[cpg]


But that doesn't mean we can't do nothing here.
[cpg]


[OnName num="itsuki"]
I don't care. I'm going.
[cpg cn=true]


As a result, Mercurio decided to stay and go with Ritul and the others.
[cpg]


We had no choice but to do it. We had come this far, we had to win.
[cpg]


We went into battle. ......
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_fi"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（昼）******************************************************

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


[SE f="se015"]
;//【ＳＥ】『剣戟』


The fight turned out to be tougher than I thought.
[cpg]


I was naive to think I could do it alone. There were too many of them.
[cpg]


We were being pushed little by little,...... and that's when Ritul was captured.
[cpg]


;//========================================
;//●ＣＧ（触手に捕まっているヒロイン）ev_56
;//人物１：ヒロイン２
;//服装１：着衣
;//人物２：触手
;//服装２：なし
;//場所　：洞窟
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_56_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


The first thing you need to do is to get a good idea of what you're looking for.
[cpg]


[VOICE f="Littule042"]
[OnName num="littule"]
　I'm not delicious even if you eat me.
[cpg cn=true]


[OnName num="itsuki"]
Ritul!
[cpg cn=true]


I screamed out. I tried to save Ritul, but the people around me would have none of it.
[cpg]


But the people around me didn't agree. Or rather, ......
[cpg]


They are trying to run away. They think this battle is unfavorable.
[cpg]


[OnName num="dwarf_man"]
"Let's retreat for now!　Brave man, you're being reckless."
[cpg cn=true]


He's running away. What happens if he escapes?
[cpg]


Ritul would be taken prisoner. Worst of all, he would die.
[cpg]


;**【ＣＧ】 ev_56_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Littule043"]
[OnName num="littule"]
"Haaaaaaaaahhhh, treeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii!"
[cpg cn=true]


I couldn't bear to lose the person I loved twice. I couldn't stay calm.
[cpg]


[OnName num="itsuki"]
But Ritul is ......."
[cpg cn=true]


I turned to Ritul and said so.
[cpg]


The dwarves were fighting and calling out to me.
[cpg]


;//[free time=1000]

[OnName num="dwarf_man"]
'Brave man!　I need you to be calm and make a decision."
[cpg cn=true]


[OnName num="itsuki"]
I said, "...... understand. Let's retreat.
[cpg cn=true]


So they said, and we retreated. ......
[cpg]


It was a tough decision, but we had no choice.
[cpg]


;//ブラックアウト

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（昼）******************************************************


I thought desperately. How to save Ritul.
[cpg]


[OnName num="itsuki"]
"We have to save Ritul. ...... what they're doing to him while we're doing this."
[cpg cn=true]


[FG f="CHA06_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Mercurio027"]
[OnName num="mercurio"]
"We can't win if we're on the defensive,...... and it's hard to get Ritul out of there,......?
[cpg cn=true]


Yes. The most important thing to remember is that you can't just go out and buy a new pair of jeans and a new pair of jeans.
[cpg]


The most important thing to remember is that you can't just take the time to do what you want to do. The most important thing to remember is that you can't just take a chance on the market.
[cpg]


I suddenly thought of Ariel. I'm going to lose the person I love again.
[cpg]


[OnName num="itsuki"]
"Oh ......, what should I do?
[cpg cn=true]


I'm in a headlock. Mercurio looks apologetic.
[cpg]


And then he mumbles to me like this.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
;//[t_move pos=C ゆらゆら]
[VOICE f="Mercurio028"]
[OnName num="mercurio"]
'I'm sorry ...... I can't think of anything to do.'
[cpg cn=true]


I see. I'm sure you're right. I can't think of anything either.
[cpg]


I know it's not good, but I have no choice but to stay like this.
[cpg]


What should I do? With Ritul as a hostage, I can't even push him with my strong skills.
[cpg]


I wondered if Ariel would be able to lend me some wisdom.
[cpg]


I feel as if I want to go back to Ariel even now.
[cpg]


[OnName num="itsuki"]
No, no,......, don't be weak.
[cpg cn=true]


I muttered to myself. Then, I got back into the swing of things.
[cpg]


But Ritul is no longer a stranger to me. I can't leave him alone.
[cpg]



;//ブラックアウト

;//////////////////////
;//ヒロイン2に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_08_2.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]


[BGM f="bg_m1"]
;//[WAIT time=100]
;//【ＢＧ】『地下都市』（昼）

;//========================================
;//●ＣＧ（触手に拘束されて、尋問されるヒロイン）ev_57
;//人物１：ヒロイン２
;//服装１：着衣（破れ）
;//人物２：触手
;//服装２：なし
;//場所　：洞窟
;//時間　：夜
;//========================================

;**【ＣＧ】 ev_57_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]

[window target=true]


The place that seems to be the stronghold of the demon army.
[cpg]


I was being held there.
[cpg]


The demon army was strangely well controlled, so I thought there was someone in charge of attacking the underground city. ......
[cpg]


I knew there was.
[cpg]


A demon with the wisdom ...... and intelligence to take control.
[cpg]


It looked like a Centaur.
[cpg]


A demon like that, which might be called a man-horse.
[cpg]


[OnName num="centaur"]
"......This is beautiful,......."
[cpg cn=true]


The first time I saw it, it looked at me and said something like that.
[cpg]


I continued to glare at him.
[cpg]


At times like this, this kind of attitude may be futile.
[cpg]


I knew that, but I couldn't break my strong attitude.
[cpg]


I was the last person who could do anything about it.
[cpg]


[VOICE f="Littule044"]
[OnName num="littule"]
What are you talking about,......, you're going to kill me, aren't you?
[cpg cn=true]




[OnName num="centaur"]
I'm not just going to kill you. It would be a shame to treat a beautiful woman like you like dirt.
[cpg cn=true]


;**【ＣＧ】 ev_57_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=1000]



Huh?　I can't help but say.
[cpg]


I was a little taken aback by this strange thing that was said.
[cpg]


We were silent for a while. Then the centaur looked at me.
[cpg]


There are a few demons that look like entourage members. But the centaur dispels them with a lookout.
[cpg]


[OnName num="centaur"]
'Well, ...... now we are alone.
[cpg cn=true]


What are they thinking? Really, what are they thinking?
[cpg]


I didn't understand, and on the contrary, I was getting scared.
[cpg]


The most important thing to remember is that you can't be alone with your partner.
[cpg]


;//========================================
;//●ＣＧ（捕虜となって、座り込んでいるヒロイン。ケンタウロスの姿は消してください）ev_20
;//人物１：ヒロイン２
;//服装１：着衣
;//場所　：洞窟
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_20_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]

I was released from the restraints by the tentacles, and she asked me, "What is your name?
[cpg]


[OnName num="centaur"]
What is your name?
[cpg cn=true]


I wasn't going to answer right away.
[cpg]


[VOICE f="Littule045"]
[OnName num="littule"]
I didn't have a name to give him.
[cpg cn=true]


I wondered if he would be a little annoyed if I told him this. I thought, "Okay, just tell me.
[cpg]


[OnName num="centaur"]
"Just tell me.
[cpg cn=true]


The centaur kept his voice soft and gentle.
[cpg]


I felt like I couldn't resist and answered.
[cpg]


;**【ＣＧ】 ev_20_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Littule046"]
[OnName num="littule"]
...... liturgy."
[cpg cn=true]


I replied. The centaur then says ......
[cpg]


[OnName num="centaur"]
'Well then, Ritul. Don't you think this battle is futile?"
[cpg cn=true]


A waste. What does that mean?
[cpg]


I wondered if the demons thought that they didn't want to fight, or something like that.
[cpg]


I asked, thinking that it was unimaginable.
[cpg]


[OnName num="centaur"]
The evil god is beginning to have power. It is a battle that the demons are bound to win.
[cpg cn=true]


You can't know that until you try. I thought so, but ......
[cpg]


The current state of affairs suggests that this is indeed the case.
[cpg]


[OnName num="centaur"]
"As far as we're concerned, this whole underground city could be our home."
[cpg cn=true]


That's unacceptable. It's our home.
[cpg]


That's what I thought, but they are willing to compromise a little more.
[cpg]


[OnName num="centaur"]
I believe we can coexist with the humans if they don't put up a fight.
[cpg cn=true]


If you ask me, they are really intelligent demons. ......
[cpg]


There are demons like this. I had no image of him in my mind.
[cpg]


I was a little worried about whether or not I should follow him or not.
[cpg]


Normally, I would have rejected him without thinking.
[cpg]


[OnName num="centaur"]
But all the demons are very hot-blooded. Besides, humans don't like demons either, so they attack them."
[cpg cn=true]


The centaur continued quietly.
[cpg]


[OnName num="centaur"]
I repeat, this battle is futile.
[cpg cn=true]


I'm not fooling you, ......, I thought.
[cpg]


Maybe, I thought, it really is useless to fight.
[cpg]


[OnName num="centaur"]
And also the monster army will soon be increased,...... humans don't have a chance to win.
[cpg cn=true]


The most important thing to remember is that you can't just take the time to do what you want to do. The most important thing to remember is that you can't be fooled by the fact that you're not a human being.
[cpg]


[VOICE f="Littule047"]
[OnName num="littule"]
I will not be fooled by that. ...... I am going to fight.
[cpg cn=true]


I don't know if this was the right answer. I don't know. ......
[cpg]


[OnName num="centaur"]
I thought ...... you were smarter than this, but I guess I was wrong.
[cpg cn=true]


I'm not going to be broken by this.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
;//[BG f="b_08_2.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（昼）

;//上下に黒帯を入れてください


[OnName num="centaur"]
I'm not going to snap at you like this. I'm going to change my tactics a little. I'm going to take Ritul hostage.
[cpg cn=true]


[OnName num="centaur"]
That would make things a lot smoother.
[cpg cn=true]


I had no idea what he was talking about. ......
[cpg]


I didn't understand what he was saying, but he made me memorize the lines to persuade the trees.
[cpg]


;//ブラックアウト


;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_fi"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（昼）******************************************************


One day when Ritul was not around, a swarm of demons reappeared in the underground city.
[cpg]


They are all in full force. If they attacked us all together, it would be another bitter fight.
[cpg]


But the situation is a little different ...... and Ritul is standing at the front of the line, not looking like he is about to fight.
[cpg]


[OnName num="itsuki"]
"Ritul,...... why?"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Littule048"]
[OnName num="littule"]
Yes, tree ......."
[cpg cn=true]


The first thing to do is to make sure that you have a good time with your friends and family.
[cpg]


The actuality that the actuality is that the actuality is not really a good idea.
[cpg]


 I had a vague idea that it was probably a commander class.
[cpg]


So, ...... this is a negotiation?
[cpg]


[OnName num="itsuki"]
"......What are you trying to do?"
[cpg cn=true]


[OnName num="centaur"]
I'm not very good at guessing. I'll have to explain everything.
[cpg cn=true]


He sounded more like a fool and less like a fool.
[cpg]


[OnName num="centaur"]
I'm here to tell you to surrender. Ritul, please.
[cpg cn=true]


Then he called her name, Ritul, and she stepped forward.
[cpg]


She looked frightened. What was she frightened of?
[cpg]


;//[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Littule049"]
[OnName num="littule"]
I heard that the number of ...... demons is increasing on earth. And the number of them is staggering.
[cpg cn=true]


[OnName num="itsuki"]
That ...... would be true.
[cpg cn=true]


;//[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Littule050"]
[OnName num="littule"]
I got a magical call that more troops are coming this way. ......
[cpg cn=true]


Contacted by magic. That might be possible.
[cpg]


But we still don't know if it's true or not, do we?
[cpg]


[OnName num="itsuki"]
"Do you believe ......?　It could be a bluff.
[cpg cn=true]


I asked Ritul. Ritul replied, "It could be a bluff.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Littule051"]
[OnName num="littule"]
It might be a bluff,...... but if it is, even a tree can't beat it.
[cpg cn=true]


......That may indeed be the case.
[cpg]


There are limits to skill. It doesn't mean that you can do everything.
[cpg]


The most important thing to keep in mind is that you should not be afraid to ask for help from your friends and family.
[cpg]


Of course, if it is friend or foe, I may be able to become stronger, but that is not the point. ......
[cpg]


[OnName num="centaur"]
Listen to me. If you surrender, I won't kill any more of you. All you have to do is give us this underground city."
[cpg cn=true]


The centaur said calmly.
[cpg]


I knew what he meant. I knew what he meant.
[cpg]


[OnName num="itsuki"]
"You mean in exchange for ......?"
[cpg cn=true]


The centaur nodded. Then he gave me a signal.
[cpg]


[OnName num="centaur"]
I knew what he meant. If you can't hear me, .......'
[cpg cn=true]


Then a goblin who seemed to be a member of the centaur's entourage put a blade to Ritul's neck.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
Ritul is frightened. She is not prepared to die.
[cpg]


[OnName num="centaur"]
Of course she's going to die."
[cpg cn=true]


[OnName num="itsuki"]
...... I see."
[cpg cn=true]


[OnName num="centaur"]
I'm not just going to kill her, I'm going to kill all of you. Do you understand?
[cpg cn=true]


I understand. It's going to be a full-on confrontation.
[cpg]


I ...... didn't even have time to think about it.
[cpg]


I could see it in the faces of the other dwarves.
[cpg]


More men might be coming. Besides, if we don't comply here, Ritul will die.
[cpg]


And that opinion seemed to be agreed upon by many of the dwarves. ......
[cpg]


[OnName num="itsuki"]
"All right,......, let's agree to the terms.
[cpg cn=true]


[OnName num="itsuki"]
We surrender. We lose.
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

We have accepted that we have lost this battle.
[cpg]


Then the demons stopped killing people.
[cpg]


Really, they stopped killing anyone at all.
[cpg]

;//////////////////////
;//ヒロイン2に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（夕方）******************************************************

;//上下に黒帯を入れてください



[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

The home of the demon army. I was treated with respect.
[cpg]


I wondered about that and asked why they did that.
[cpg]


[OnName num="centaur"]
I asked him why he did that. If I was rough with you, I might lose my credibility.
[cpg cn=true]


I understood. I understood that because he was a hostage, he was being taken care of.
[cpg]


The demons didn't bother me at all.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Littule052"]
[OnName num="littule"]
I know,......," he said.
[cpg cn=true]


In this way, they are well-organized creatures......
[cpg]


I was thinking about this, but at the same time, I had one more thought.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Littule053"]
[OnName num="littule"]
You're being awfully nice, aren't you?
[cpg cn=true]


I asked him. What would he say?
[cpg]


[OnName num="centaur"]
"Don't you want me to be nice to you?"
[cpg cn=true]


......It's a little mean, isn't it? But I found it charming in that way, too.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Littule054"]
[OnName num="littule"]
......That is."
[cpg cn=true]


I'm stuck for an answer. I can't answer that question right away.
[cpg]


I didn't know. I was not aware that there was such a gentlemanly type among the demons.
[cpg]


I felt like I was attracted to the stronger males. ......
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（夕方）******************************************************


The underground city was then a place where both demons and dwarves came and went.
[cpg]


It was a strange sight, but it was also strange how it became familiar as I watched.
[cpg]


Of course, there is a gap between the two. There were objections to sharing resources and so on.
[cpg]


But there was a solution to all of that.
[cpg]


A centaur, who seemed to be quite a shrewd man and did more than just unite the demons. ......
[cpg]


He was also in a good mood with the dwarves. He also wanted to share the resources that were on the demons' side.
[cpg]


Even the demons can't live without eating anything, can they?
[cpg]


Coexistence was about to become a reality.
[cpg]


No matter how many demons increase or invade, only this place would be safe.
[cpg]


No matter what happens, the centaurs will protect us.
[cpg]


In a dying world, even if the evil gods could not be defeated, the Dwarves might remain.
[cpg]


Everyone seemed satisfied with that situation. ......
[cpg]


As a brave man, I had mixed feelings.
[cpg]


What happened to Ariel? Is that great forest safe?
[cpg]


As I was walking around thinking about these things,......
[cpg]


[OnName num="itsuki"]
hmm......?"
[cpg cn=true]


I heard someone's voice at the back of the cave. It was a woman's voice. It sounded familiar ......
[cpg]



;//ブラックアウト

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=800]

Come to think of it, I haven't talked to Ritul in a while. I thought I didn't have to worry about that.
[cpg]


But it seems that's what I should have been concerned about.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Littule055"]
[OnName num="littule"]
Oh, um,......, I want you to look at me as a girl."
[cpg cn=true]


I gulped. The person to whom Ritul said that was the centaur in charge of the demons in this place.
[cpg]

[OnName num="centaur"]
I was so surprised that he didn't say anything. You don't have a girlfriend?"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Littule056"]
[OnName num="littule"]
'No,...... there's no one else I love.
[cpg cn=true]


...... I lost and he won. Does it mean that I was attracted to a stronger man?
[cpg]


;//移植のためシーンをカットしています

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（夜）******************************************************


I was stunned for a while. I even thought about going back to Ariel. ......
[cpg]


I heard that Ariel was found safe and sound after that.
[cpg]


But that wasn't all. Because ......
[cpg]


I received the news that Ariel was pregnant with Abram's child.
[cpg]


I understood. I knew what my unique skills were.
[cpg]


This couldn't just be a coincidence.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mercurio029"]
[OnName num="mercurio"]
"Cheer up, Tree-san ......."
[cpg cn=true]


Mercurio tried to comfort me.
[cpg]


But even his voice sounded scary.
[cpg]


[FG f="CHA06_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Mercurio030"]
[OnName num="mercurio"]
"Why don't you go back to the ground,......?　Looking for Ariel-san......kyah!
[cpg cn=true]


;//[t_move pos=C 動揺]


[OnName num="itsuki"]
Don't come any closer......!"
[cpg cn=true]


[SE f=se086]
;//【ＳＥ】『振り払う』

[free time=1000]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]

I paid off Mercurio's outstretched hand.
[cpg]


Perhaps if I love Mercurio, someone else will take her again.
[cpg]


I can't love anyone anymore.
[cpg]



;//ブラックアウト

;//ヒロイン２　ルート　モンスター寝取られ
;//ＥＮＤ
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[Ending_SetUp cl=cl_003 ss=false]

[system cl_003=true]

[SCENE id=16]

[jump storage="epend.ks" target="*start"]

