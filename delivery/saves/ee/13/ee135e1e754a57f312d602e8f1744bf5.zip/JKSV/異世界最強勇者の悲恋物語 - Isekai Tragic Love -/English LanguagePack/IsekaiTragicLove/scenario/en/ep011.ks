
*start

;#################################################
*Ep011|Humans are suspicious
;#################################################

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA06_p3_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）


*select09_1|I doubt it's human.

[SCENE id=11]


I suspect human. Humans are poaching mermaids.
[cpg]


That's somewhat of an opinion. I still think that creatures with short life spans want immortality.
[cpg]


And I also think that humans are more complicated than vampires.
[cpg]


[OnName num="itsuki"]
I guess it's humans after all. ......
[cpg cn=true]


With my one word, the opinion of the group was unanimous. It was settled.
[cpg]


Ritul was excited, saying, "It's settled.
[cpg]


Mercurio agreed with me.
[cpg]


We decided to go back to the city and investigate again, since it was the work of humans.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


We returned to the city. It was nighttime and we decided to rest for the day.
[cpg]

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


After returning to the city, we stayed at the same inn.
[cpg]


I had some street money. Even if I lost it, I was sure I could manage with my skills.
[cpg]


I think it's too convenient,......, really, I wonder if I can use this kind of power without limit.
[cpg]


Thinking about this, I lay in bed and stared at the ceiling.
[cpg]


It's hard to sleep. It was in the middle of such a situation.
[cpg]

[SE f="se009"]
;//【ＳＥ】『ノック』


Someone knocks on my door.
[cpg]


[OnName num="itsuki"]
"......, who is it?"
[cpg cn=true]


The knocker was Mercurio.
[cpg]


He looked at me with a pouty face and looked me up and down.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mercurio061"]
[OnName num="mercurio"]
I knew I couldn't ...... not thank him in any way.
[cpg cn=true]


[OnName num="itsuki"]
'Fine,......, I don't need you to thank me in this way.
[cpg cn=true]


Mercurio shakes his head. I wonder why he liked me so much.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//========================================
;//●ＣＧ（横たわるヒロイン。キスを待っている）ev_18
;//人物１：ヒロイン６
;//服装１：着衣
;//人物２：主人公
;//服装２：旅人服
;//場所　：宿屋
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Mercurio062"]
[OnName num="mercurio"]
"You are kind to everyone, Itsuki,...... I have never met anyone like this.
[cpg cn=true]


It's embarrassing to be told that much, but it's true I don't want anything in return.
[cpg]

[VOICE f="Mercurio063"]
[OnName num="mercurio"]
"...... tree-san, that ......"
[cpg cn=true]


She's waiting for me to kiss her. I wasn't sure if I should take her up on it or not.
[cpg]

If I kiss you on the mouth here, there is no going back later.
[cpg]

But ...... I couldn't just let her leave now, could I?
[cpg]

[OnName num="itsuki"]
Mercurio.
[cpg cn=true]


;**【ＣＧ】 ev_18_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]


She looked a little happy when I called her name.
[cpg]

And I put my lips to hers.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


A few days later. A few days later, someone from the village of Mermaid came out to join the investigation.
[cpg]


[OnName num="mermaid_A"]
I said to her, "Hello. You must be the brave one, right?
[cpg cn=true]


[OnName num="mermaid_B"]
Please take care of me. I will do whatever I can to help.
[cpg cn=true]


There were two kinds of mermaids I saw in the sea.
[cpg]


Some mermaids had legs and others had lower bodies that were fish. ......
[cpg]


I believe that those who have lived for a long time have the power and can grow human legs by magic.
[cpg]


Mercurio taught me that.
[cpg]


She is a mermaid, so she must be right.
[cpg]


But how long is a long time ......?
[cpg]


I don't look that old.
[cpg]


[OnName num="itsuki"]
Well then, I guess I'll be asking you for a lot of favors, too.
[cpg cn=true]


[OnName num="mermaid_A"]
Really, you're going to prevent me from poaching ......?"
[cpg cn=true]


One of the mermaids seemed suspicious of me.
[cpg]


I'm human, aren't I? I had just determined that humans were poaching.
[cpg]


[OnName num="mermaid_B"]
I'm afraid you're a ...... brave man," he said.
[cpg cn=true]


The other seemed to think I was a brave man.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Mercurio064"]
[OnName num="mercurio"]
"Well, well, well. Itsuki-san doesn't care about that."
[cpg cn=true]


[OnName num="itsuki"]
Oh. I understand why you doubt me.
[cpg cn=true]


[OnName num="mermaid_A"]
'...... hmmm.'
[cpg cn=true]


He is defiant. This is going to take a lot of work to build trust. ......
[cpg]

[VOICE f="Mercurio065"]
[OnName num="mercurio"]
'But more importantly, let's think about what we're going to do.
[cpg cn=true]

[free time=1]
;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/3" time=1]

So we decided to come up with a plan with the few of us who could operate on land.
[cpg]


We were somewhere like a small cafeteria, exchanging words.
[cpg]


We could not come up with a plan, but it was hard to come up with anything concrete.
[cpg]


The discussion stalled. Then Mercurio said to me, "By the way, why are we having a strategy meeting here?
[cpg]

[VOICE f="Mercurio066"]
[OnName num="mercurio"]
By the way, why are we having the strategy meeting here?　We could have done it at the Mermaid Village. ......
[cpg cn=true]


She has a point. However.
[cpg]


[OnName num="itsuki"]
Oh, yeah,......, that would have been fine, too.
[cpg cn=true]


That place was too wary of humans, and it was hard to stay ...... there.
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

;//上下に黒帯を入れてください



And today, I'm going to lodge again. With my legs, I don't realize I'm a mermaid.
[cpg]


We each stay in separate rooms. Ariel and Ritul and the others are also in separate rooms.
[cpg]


I always stay in a single room. Although it is inevitable because I am a man, I feel a little alienated.
[cpg]


On the other hand, I wonder if the girls feel uncomfortable because of the small room. ......?
[cpg]

[SE f="se009"]
;//【ＳＥ】『ノック』


Then I hear a knock at the door. I answered.
[cpg]


[OnName num="itsuki"]
...... please come in."
[cpg cn=true]


Two mermaids who were not Mercurio had come to my room.
[cpg]


They looked grim-faced. The more wary mermaid especially.
[cpg]


It looked almost like hostility.
[cpg]


[OnName num="mermaid_A"]
I said, "...... tree, right?　I'm warning you.
[cpg cn=true]


[OnName num="itsuki"]
What is it, ......?"
[cpg cn=true]


[OnName num="mermaid_A"]
Mercurio is our childhood friend. So I'm going to go out on a limb and say it.
[cpg cn=true]


[OnName num="mermaid_A"]
Don't try to force your way into our mermaids' lives. It's just like poachers.
[cpg cn=true]


......That's what you're talking about. Is that what you've been warning us about?
[cpg]


[OnName num="itsuki"]
I'm not going to force you to do anything. I don't force anything.
[cpg cn=true]


[OnName num="mermaid_A"]
What do you mean by that, ......?
[cpg cn=true]


Oh no. I slipped up. I tried to get away from the topic.
[cpg]


[OnName num="itsuki"]
Mermaids don't like to mingle with other mermaids, do they?
[cpg cn=true]


[OnName num="mermaid_B"]
Well, that's true for any species.
[cpg cn=true]


[OnName num="itsuki"]
But they can't have children without men.
[cpg cn=true]


[OnName num="itsuki"]
I've never seen a male mermaid.
[cpg cn=true]


[OnName num="mermaid_B"]
That's true, but ......
[cpg cn=true]


I wonder if there are. I don't really want to see them, if there are.
[cpg]


In any case, I've learned that mermaids rely on other species for their offspring.
[cpg]


[OnName num="itsuki"]
If that's the case, Mercurio will always be alone. It's a pity, isn't it?
[cpg cn=true]


[OnName num="mermaid_A"]
'That's why I added "forced."'
[cpg cn=true]


They must be very wary about Mercurio.
[cpg]


The feelings of these women are painfully clear to me.
[cpg]


Maybe it is a woman's peculiar idea. Or should I say mermaid-specific?
[cpg]


I mean, if it was a guy and his friend got a girlfriend, he would be happy, even if it was a little forced.
[cpg]


[OnName num="itsuki"]
Anyway, I understand what you're saying.
[cpg cn=true]


[OnName num="mermaid_A"]
I'm sure it's true. ......
[cpg cn=true]


I mean, it's already too late for that. ......
[cpg]



;//ブラックアウト

;//移植のためシーンをカットしています
;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


After that, my friends and I continued to investigate poaching.
[cpg]


Who is catching the mermaids? More often than not, people didn't know about it, but ......
[cpg]


[OnName num="itsuki"]
I asked them, "Hey, do you know anything about poaching mermaids?　Anything, just tell me."
[cpg cn=true]


[OnName num="traveller_A"]
'Oh ...... well, there's a rumor about that.'
[cpg cn=true]


[OnName num="traveller_B"]
Is it true?
[cpg cn=true]


[OnName num="traveller_A"]
"Yes, I heard it's true. Of course, there's a humanitarian issue, so they're doing it under the radar.
[cpg cn=true]


[OnName num="itsuki"]
Who is doing it? Who's doing it?
[cpg cn=true]


[OnName num="traveller_A"]
I don't know who it is, but since ...... the evil gods came out, there are more and more people doing bad things.
[cpg cn=true]


[OnName num="traveller_B"]
You mean humans are doing it?　Is that true ......?
[cpg cn=true]


[OnName num="traveller_A"]
At least that's what I'm hearing."
[cpg cn=true]


After investigating poaching for a long time, the substance of the story gradually became clear.
[cpg]


Me and Ariel nodded to each other as we listened.
[cpg]


This kind of information didn't stop at just one or two. More people are aware of the rumors.
[cpg]


After all, people are doing it. There may be more hidden masters behind the scenes, but ......
[cpg]


For example, it is not impossible that another species is behind it.
[cpg]


It is possible that a vampire is behind it, or something like that.
[cpg]


But the culprit is a human being. We have found out that much.
[cpg]


Even if there is a big boss, we can manage to destroy him by destroying this place.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]



[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA06_p3_02_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Littule104"]
[OnName num="littule"]
Anyway, it looks like the peace of the Mermaid tribe will be protected now.
[cpg cn=true]


[FACE method="change_5" pos="2/2"]
[OnName num="itsuki"]
Ritul......, you're speaking very loudly.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
Why is that?　Ritul says loudly about poaching, saying, "I don't know.
[cpg]



[FACE method="change_4" pos="2/2"]
[VOICE f="Mercurio067"]
[OnName num="mercurio"]
"Shhh ...... if you say it too loud, you'll stand out. ......"
[cpg cn=true]


[FACE method="change_4" pos="1/2"]
[VOICE f="Littule105"]
[OnName num="littule"]
Oh ...... bad."
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Mercurio068"]
[OnName num="mercurio"]
If poachers hear you, it's a bad thing.
[cpg cn=true]


We're looking into poaching. That's like saying you have a mermaid in your crew.
[cpg]


Mercurio could have been targeted, not to mention poached.
[cpg]


I can understand why Ritul's character would want to say such a thing, but ......
[cpg]


It's still too early to rejoice. And.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//[fadeoutbgm]

The first thing to do is to make sure that you have a good idea of what you're looking for.
[cpg]

;//////////////////////
;//ヒロイン6に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_6.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_m1"]
[WAIT time=100]


The investigation was about to come to a close.
[cpg]


I was close to finding out who was doing it and where.
[cpg]


Having reached that point, I was about to return to the sea. There must be a few more mermaids who could work on land.
[cpg]


They were reluctant to accept my invitation, but ......
[cpg]


I had a feeling that if I was close enough to find the poachers, they would be willing to help.
[cpg]


I was hoping he would be a little more involved in the investigation, however ...... that action was thoughtless.
[cpg]


Or maybe someone had been watching me the whole time.
[cpg]


[FG f="CHA06_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Mercurio069"]
[OnName num="mercurio"]
Kya!"
[cpg cn=true]


Back to the sea. On the way there, I got entangled in something that looked like a net.
[cpg]


I struggle, but still cannot pull it off.
[cpg]


[free time=1000]

It seems to be filled with some kind of magical power, and I start to lose my strength.
[cpg]


[OnName num="man_A"]
I pull it up. It's a mermaid."
[cpg cn=true]


It might have been such a tool, made against mermaids.
[cpg]


And I am pulled ashore.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//[BGM f="bg_fi"]
[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[FG f="CHA06_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mercurio070"]
[OnName num="mercurio"]
No, no, no!　Let go of me!
[cpg cn=true]


[OnName num="man_B"]
"We're gonna catch a lot of fish this year. We're going to make a lot of money this year."
[cpg cn=true]


I was in a desperate situation.
[cpg]


I had no friends. I was about to go back to the sea alone.
[cpg]


Apparently, I couldn't handle this situation alone. ......
[cpg]



;//ブラックアウト

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


;//[STOPBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
;//[BG f="b_05_3.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[OnName num="man_A"]
'You're awfully pretty,' she said. It would be a shame to take you to the boss."
[cpg cn=true]


The man is coming on to me, saying, "I'm sorry.
[cpg]

I can't escape anymore. I'm in a helpless situation......
[cpg]

[STOPBGM]

But there.
[cpg]


[BGM f="bg_fi"]

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Littule106"]
[OnName num="littule"]
Let go of Mercurio!"
[cpg cn=true]

[SE f="se013"]
;//【ＳＥ】『斧を振るう』


Then, Ritul appeared. Wielding his weapon, he took out one of the men in an instant......
[cpg]


[OnName num="man_A"]
"Gghh......, ah......!"
[cpg cn=true]


He fell to the ground and said nothing.
[cpg]


Mr. Ritul said that he would not kill him, but it was so instantaneous that it made me uneasy.
[cpg]


Then he holds up his weapon toward the other guy ......
[cpg]


[OnName num="man_B"]
I said, "No, don't do that, I'm sorry."
[cpg cn=true]


The other man did not run away, but begged for his life.
[cpg]

;//;//[fadeoutbgm]

;//[STOPBGM]

Then Mr. Ritul approaches me.
[cpg]

[BGM f="bg_se"]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Littule107"]
[OnName num="littule"]
He said, "Hi, terrible ...... I can't believe there are really people who would do something like this."
[cpg cn=true]


I was speechless.
[cpg]


But I was so happy with Ritul's kindness that I started ...... crying.
[cpg]


I cried and cried and cried and cried, "I was so scared.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Littule108"]
[OnName num="littule"]
That's why people are just too good ...... trees, I knew it."
[cpg cn=true]


It was warm in Mr. Ritul's arms, and I felt a little safer.
[cpg]


[free time=1000]

Then, with a look of dismay on his face, Mr. Hermia said.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Elmyr094"]
[OnName num="elmyr"]
'Well, I guess the poachers got what they deserved.
[cpg cn=true]


He then looked at me and gave me a slightly pitying look.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr095"]
[OnName num="elmyr"]
Then he looked at me and gave me a slightly pitiful look, "But what's more pitiful is Mercurio."
[cpg cn=true]


I wasn't sure how to respond.
[cpg]


[free time=1000]

I was crying until now, and I couldn't even say it was okay......
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA06_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Mercurio071"]
[OnName num="mercurio"]
'I'm fine...... I don't care.'
[cpg cn=true]


That's what I thought, but when I put it into words, it was still "okay.
[cpg]


Maybe I have a personality that is easily overwhelmed.
[cpg]


I think Hermia might have seen through that, too.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Elmyr096"]
[OnName num="elmyr"]
He asked me, "Are you sure you're okay?　Are you sure you're not pushing yourself too hard?"
[cpg cn=true]


As proof, he would say to me: ......
[cpg]


I just kept repeating the same words.
[cpg]


[FG f="CHA06_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Mercurio072"]
[OnName num="mercurio"]
'...... I'm fine.'
[cpg cn=true]


I'm fine. Those were the words I kept telling myself.
[cpg]


;//ブラックアウト

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


I took my eyes off the road for a minute and got separated from my people.
[cpg]


[OnName num="itsuki"]
"Ah, there you are, ...... where have you been?"
[cpg cn=true]


I meet up with Mercurio and the others. But the air was heavy.
[cpg]


[OnName num="itsuki"]
"......?　What's wrong?
[cpg cn=true]


I asked, but Ariel looked thoughtful for a moment and then said, "Nothing.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Ariel190"]
[OnName num="ariel"]
Nothing," she said. Nothing.
[cpg cn=true]


Nothing," she said. That's a tricky thing to say.
[cpg]


[OnName num="itsuki"]
"Oh, really?　Well, good.
[cpg cn=true]


[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Mercurio073"]
[OnName num="mercurio"]
Yes, it is. If Mr. ...... tree knows about this kind of thing ......
[cpg cn=true]


Mercurio said something in a whisper.
[cpg]


Did you just say something about what if I found out?
[cpg]


[OnName num="itsuki"]
What?　I knew something was wrong.
[cpg cn=true]


Everyone looks a little downcast. Mercurio's face was particularly pale.
[cpg]


[OnName num="itsuki"]
Or is it something you can't tell me ......?"
[cpg cn=true]


Mercurio bites his lip and looks frustrated.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Mercurio074"]
[OnName num="mercurio"]
'There's nothing to ...... really ...... about it.'
[cpg cn=true]


His hand was clenched. If she doesn't want to tell me, she can't hear it from me either.
[cpg]


And if it's something I can't solve, there's no point in asking. ......
[cpg]


On the other hand, if she wants help, I'm sure she'll tell me right away.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Elmyr097"]
[OnName num="elmyr"]
I'll go back to the inn. You need to get some rest."
[cpg cn=true]


Hermia says something that makes me extra worried, but I don't dare ask why.
[cpg]


[free time=1000]


I knew we were all hiding something, but I didn't say anything.
[cpg]


[OnName num="itsuki"]
"......"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/2" time=800]

[VOICE f="Littule109"]
[OnName num="littule"]
"(...... that's a terrible story. ...... I can't let you get away with it. zzzz)"
[cpg cn=true]


;//[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr098"]
[OnName num="elmyr"]
"(Yeah, really.)"
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


And then Hermia was right, we were going back to the inn.
[cpg]


The first thing to do is to make sure that you have a good time.
[cpg]

;//////////////////////
;//ヒロイン6に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_6.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_ne"]
[WAIT time=100]


......I was scared. I never thought something like that would happen.
[cpg]



I didn't know what to do when this happened.
[cpg]


He shouldn't even be aware of it now. I didn't say anything to him and ......
[cpg]


There should be no reason for Ariel, Ritul, or Hermia to tell him.
[cpg]


If I can keep this hidden, that's fine. But ......
[cpg]


All I could think about was the anxiety that was coming over me.
[cpg]


If it became known that I was being pressed with another man, Itsuki would hate me.
[cpg]


I couldn't stand that.
[cpg]


I only have Itsuki. If he hates me, I have nothing left.
[cpg]


That is how much I was in love with Itsuki.
[cpg]


I didn't want him to know anything ugly about me.
[cpg]


Maybe it is impossible to fall in love with such a feeling, but at least that is what I thought.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

;//上下に黒帯を入れてください



Then, when I was resting at the inn.
[cpg]


As I was resting alone, I heard a knock at the door.
[cpg]

[SE f="se009"]
;//【ＳＥ】『ノック』


[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mercurio075"]
[OnName num="mercurio"]
'Hmmm ...... who is it?'
[cpg cn=true]


Rubbing my sleepy eyes, I got up and saw ...... an unfamiliar figure.
[cpg]


[OnName num="merman"]
I was not a suspicious person. It's just a passing monster."
[cpg cn=true]


[FG f="CHA06_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Mercurio076"]
[OnName num="mercurio"]
"A half-fishman,......?　What are you doing out here in the middle of nowhere?
[cpg cn=true]


Half-fish people are different from mermaids, being between fish and people.
[cpg]


They were not on friendly terms with us mermaids, nor were they hostile.
[cpg]


They had nothing to do with us who are now investigating poaching. I thought so, but ......
[cpg]


I could no longer ignore him: ......
[cpg]


[OnName num="merman"]
"I have something I'd like you to look at,...... do you remember this?"
[cpg cn=true]


So saying, the half-fishman showed me a cut-out jewel-like tool.
[cpg]


A crystal of record. It could record the image at the moment it was first held up and project it again later.
[cpg]


It was a useful, but expensive, magical tool that was not widely used.
[cpg]


The image is then projected on the wall from the recording crystal: ......
[cpg]

;//CG使いたいセピア

There, I was projected on the wall.
[cpg]


Recording crystals cannot record sound. But this was so ...... obvious.
[cpg]


It was footage of me at the moment I was being approached by the poachers.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Mercurio077"]
[OnName num="mercurio"]
This, this is ......."
[cpg cn=true]


I don't know what he's thinking, and I try to squeeze the sound out of my voice, horrified.
[cpg]


What does he want from me? I somehow knew that, but I couldn't ......
[cpg]


I couldn't admit it.
[cpg]


[OnName num="merman"]
I happened to be in the immediate area, and I got the whole thing on film."
[cpg cn=true]


I was so desperate. Please don't let him see this.
[cpg]


[OnName num="merman"]
I couldn't do it for free. You already have a pretty good idea what I'm talking about.
[cpg cn=true]


The half fisherman tells me. I felt like crying ...... out.
[cpg]


[OnName num="merman"]
You know what I'm saying?　I want my share of the profits.
[cpg cn=true]


I knew it was going to come down to that.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mercurio078"]
[OnName num="mercurio"]
I was like, "Oh my God, ...... why am I the only one in this mess?"
[cpg cn=true]


I was so upset that I couldn't stop myself from saying those words.
[cpg]


[OnName num="merman"]
Don't feel bad. I'm just doing what I can.
[cpg cn=true]


I had to avoid having my record crystal seen by Itsuki.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mercurio079"]
[OnName num="mercurio"]
If Itsuki sees ...... something like this, he's going to be very upset.
[cpg cn=true]


That's why I'm at his mercy ......
[cpg]


Is it ultimately a gain or loss for me?
[cpg]


[OnName num="merman"]
Don't cry. Have you got time to cry?"
[cpg cn=true]


I didn't even have to think about it. I don't want Itsuki to hate me.
[cpg]


While apologizing to Itsuki in my heart, I accepted.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//========================================
;//●ＣＧ（半魚人に迫られるヒロイン。辛そうな表情）ev_27
;//人物１：ヒロイン６
;//服装１：着衣
;//人物２：半魚人
;//服装２：着衣
;//場所　：路地裏
;//時間　：夜
;//========================================


[BGM f="bg_h1"]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="merman"]
You can stay here for a while. Will you be my mistress, even for a moment?
[cpg cn=true]


The half-fisherman said to me, "Will you be my mistress even for a moment? I could not disobey.
[cpg]


I knew what he would do to me if I just obeyed him.
[cpg]


[VOICE f="Mercurio080"]
[OnName num="mercurio"]
What good would that do?
[cpg cn=true]


[OnName num="merman"]
You talk so cheeky."
[cpg cn=true]


The half-fish man, saying so, came close to me again and tried to kiss me forcibly.
[cpg]


I accepted the kiss, feeling sick.
[cpg]


[OnName num="merman"]
'Can't you think of any disadvantages to not doing it?　I know who you think of, too."
[cpg cn=true]


They know that much. I knew it.
[cpg]


I also thought that such a thing could only be realized if I had done a very thorough preparation.
[cpg]


;**【ＣＧ】 ev_27_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Mercurio081"]
[OnName num="mercurio"]
I knew that I had to be very thorough in my preparations.
[cpg cn=true]


I couldn't go against it. ......
[cpg]


If I disobeyed here, Itsuki would know the truth.
[cpg]


[OnName num="merman"]
So what are you going to do?　I can reveal it all here, or I can do one of two things."
[cpg cn=true]


I couldn't even think about it when he said that.
[cpg]


No matter what the comparison, I wanted to avoid having Itsuki know everything.
[cpg]


With that one thought in mind, I said to him, "I understand.
[cpg]


;**【ＣＧ】 ev_27_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Mercurio082"]
[OnName num="mercurio"]
I understand. ...... Please don't let Itsuki see this."
[cpg cn=true]


Tears were about to spill from my eyes.
[cpg]


I said, oh, how could I let this happen to my eyes ......
[cpg]



;//ブラックアウト

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


Then, at Mercurio's suggestion, the mermaids decided to disband for once.
[cpg]


The poachers were caught by Ritul. Then, we could rest easy for a while.
[cpg]


The poachers were a pair of men.
[cpg]


The poachers were a pair of men. There could have been more, but ......
[cpg]


Rumors spread through the city that the poachers had been caught.
[cpg]


If there were other poachers, they would be too scared to do anything.
[cpg]


But ...... that should not be a reason for Mercurio not to accompany them.
[cpg]


[OnName num="itsuki"]
I wonder what's going on,...... Mercurio.
[cpg cn=true]


I went to the reconstruction of the Great Forest of Acecto without being able to explain.
[cpg]


[OnName num="itsuki"]
'Well, it's no use thinking about it. Ariel, we're heading for the Great Forest.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel191"]
[OnName num="ariel"]
'Thank you, you remembered me.
[cpg cn=true]


[OnName num="itsuki"]
I'm not so naive as to forget. I'm not so heartless as to forget.
[cpg cn=true]


Ariel looked happy. Finally, I can solve the problem of my hometown.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ariel192"]
[OnName num="ariel"]
I was afraid that maybe you had forgotten about me.
[cpg cn=true]


Ariel said, a little jokingly.
[cpg]


[OnName num="itsuki"]
So I'm not so heartless as to forget.
[cpg cn=true]


But then Ermia interrupts the conversation.
[cpg]

[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Elmyr099"]
[OnName num="elmyr"]
I forgot."
[cpg cn=true]


He interrupted her like that. I don't know if she can read the air or not. ......
[cpg]


Ariel is upset. And he glared at Ermia a little.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Ariel193"]
[OnName num="ariel"]
'Hey, hey,...... don't say that kind of thing.'
[cpg cn=true]


;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************


So we walk down the street at night.
[cpg]


The demons came out every now and then, but nothing to get worked up about.
[cpg]


We have a lot of people and we have a lot of skill. We were no match for them.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Littule110"]
[OnName num="littule"]
Mercurio, I wonder why he stayed behind.
[cpg cn=true]


[OnName num="itsuki"]
'It's true. I'm sure Mercurio's personality would say that he wants to help with the recovery.
[cpg cn=true]


Both Ritul and I were worried. I thought Ariel looked a little gloomy.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Elmyr100"]
[OnName num="elmyr"]
'It's probably nothing for us to worry about.'
[cpg cn=true]


Hermia says to me. That's certainly true ......
[cpg]


Blowing off my hesitation, we headed off to the great forest of Asecto.
[cpg]

;//////////////////////
;//ヒロイン6に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_6.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000][BGM f="bg_ne"]

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[WAIT time=100]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


Then I was taken to his dwelling ...... cave, a half-fish man.
[cpg]


I was at his mercy.
[cpg]


I start to feel unwell. But he didn't care about that, he just kept calling me.
[cpg]


Of course, some of the mermaids noticed that something was wrong with me.
[cpg]


Some of the mermaids were worried that something was wrong. ......
[cpg]


I could not answer them properly about it.
[cpg]


Some of the mermaids even got to the heart of the matter, saying that someone was threatening them.
[cpg]


I couldn't hear them.
[cpg]


If I admitted that it was, it would become important.
[cpg]


I wanted to avoid that.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mercurio083"]
[OnName num="mercurio"]
Here I am, Mercurio ......."
[cpg cn=true]


And then we go to the half-fish man's dwelling place.
[cpg]


Just imagining ...... being held by him today makes me want to reject him.
[cpg]


[OnName num="merman"]
'Here you are. You look beautiful today."
[cpg cn=true]


He is coming on to me, saying such things.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mercurio084"]
[OnName num="mercurio"]
'......Ugh, I don't even want to do this.'
[cpg cn=true]


I utter the words of rejection. However.
[cpg]


[OnName num="merman"]
'Then go home. You know what you have to do."
[cpg cn=true]


He would not allow such a thing.
[cpg]


I had one more thing to do.
[cpg]


Of course, I couldn't leave here.
[cpg]


[FG f="CHA06_p3_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mercurio085"]
[OnName num="mercurio"]
......Yes."
[cpg cn=true]


I had no choice but to obey. ......
[cpg]

;//移植のためシーンをカットしています

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[OnName num="merman"]
'What's the matter?　You can't pretend to be tired."
[cpg cn=true]


I don't mean to do that, but he said it to me like that.
[cpg]


Do I look like that? I was offended, but ......
[cpg]


I couldn't go against him no matter what.
[cpg]


No matter what terrible things he said to me, in the end I just accepted what he did.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト


I was getting to the point where I could not back down.
[cpg]


I had no face to match with Itsuki-san anymore. That's what I was thinking.
[cpg]


I want to disappear and disappear...... like that.
[cpg]


I felt so much that it would be a great help if Itsuki-san was now going to the great forest of the acecto.
[cpg]


If he had been right beside me, I would not have been able to fool around.
[cpg]


That's how crazy I was going ......
[cpg]

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『草原』（朝）******************************************************


We went through the meadows and into the Great Forest of Acecto.
[cpg]


We arrived at Ariel's hometown, the great forest where the demons were nesting.
[cpg]


;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（朝）******************************************************


We immediately started by exterminating the demons.
[cpg]


Ariel seemed pleased with me. ......
[cpg]


I was worried about Mercurio.
[cpg]


Why didn't she follow me?
[cpg]


There must have been a reason. Something she couldn't even tell me. ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


[OnName num="itsuki"]
Mercurio......
[cpg cn=true]


In the middle of reconstruction. I should really be concentrating on my role as a brave man.
[cpg]


I muttered to myself. I haven't talked to her for a long time.
[cpg]


I want to at least see her face and hear her voice.
[cpg]


But what can I do in this world without cell phones?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel194"]
[OnName num="ariel"]
I'm sure it's hard for you. Itsuki."
[cpg cn=true]


Ariel looks into my face.
[cpg]


[OnName num="itsuki"]
I'm having a bit of a hard time, but I'll be fine. But I'll be fine.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel195"]
[OnName num="ariel"]
Do you miss seeing Mercurio?"
[cpg cn=true]


Ariel gets to the heart of the matter. I wonder if she heard me talking to myself.
[cpg]


[OnName num="itsuki"]
Yeah, well, ...... a little bit."
[cpg cn=true]


Ariel looked lost.
[cpg]


I wondered. How did she get that look?　I was puzzled.
[cpg]


[OnName num="itsuki"]
What's wrong? Ariel, is there something you want to say?
[cpg cn=true]


Ariel looked up and turned to me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel196"]
[OnName num="ariel"]
'After all, ...... I'm going to tell you the truth. It's rather pathetic that she's trying to hide it.
[cpg cn=true]


I couldn't stop a bad feeling from rising in my chest.
[cpg]


I felt as if I was afraid to know everything. But I couldn't stop myself from asking.
[cpg]


[OnName num="itsuki"]
What is it ......?"
[cpg cn=true]


I spat, then asked. Ariel opened his mouth.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel197"]
[OnName num="ariel"]
Mercurio is ...... a poacher who is ...... a poacher."
[cpg cn=true]


[OnName num="itsuki"]
What kind of ...... is that?
[cpg cn=true]


I was at a loss to understand. Poachers?
[cpg]


But what did that have to do with tying her to the place?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel198"]
[OnName num="ariel"]
"Heal her wounds," he said.
[cpg cn=true]


I was at a loss, but I knew I had to get back to Mercurio as soon as possible.
[cpg]


;//ブラックアウト

;//////////////////////
;//主人公に視点切り替わり
;//////////////////////

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


The Great Forest of Acecto had been restored to some degree.
[cpg]


The mighty demons were gone. The local elves would be able to manage the rest.
[cpg]


More than that, I heard the whole truth from Ariel.
[cpg]


I can't just leave it like this. We decided to go back to that town.
[cpg]


Ritul and Hermia seemed to know what had happened.
[cpg]


I was the only one who didn't know. ...... I felt frustrated and strange.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************


Then we headed through the meadow to Mercurio's place.
[cpg]


I want to get back there as soon as possible, but there is no way I can do anything about it in a hurry.
[cpg]


And then that city approaches...... where I investigated Mercurio and poaching.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


I looked for Mercurio. Where is he?
[cpg]


I don't know if I can find him. But I can't think that I can.
[cpg]


I might not find him even if I looked for him in the dark, but I still looked for him.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Littule111"]
[OnName num="littule"]
"Hey!　Mercurio!"
[cpg cn=true]


Ritul, Hermia, and Ariel were also helping us.
[cpg]


They even asked around, but they could not get any useful information.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="3/3" time=800]
[VOICE f="Elmyr101"]
[OnName num="elmyr"]
They might be in the ocean. If so, there's no way to find them.
[cpg cn=true]


Hermia said hopelessly. If so, we can't look for her now that Mercurio is not here.
[cpg]


I need her help to go underwater for a long time.
[cpg]


I'm going to look around for her with my eyes.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel199"]
[OnName num="ariel"]
"I don't know. ......... do you still want to look?"
[cpg cn=true]


Ariel asked me, to which I immediately replied, "Yes, I'll look.
[cpg]


[OnName num="itsuki"]
Yes, I'll look for her. I'll find her.
[cpg cn=true]


[OnName num="itsuki"]
She might still be hurting, right?
[cpg cn=true]


[OnName num="itsuki"]
She might have another reason for not following us.
[cpg cn=true]


I hope she is just healing her heart. But ......
[cpg]


Maybe she is being threatened with something.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel200"]
[OnName num="ariel"]
'Yes, that's right. Then we'll split up and go around the coast ......."
[cpg cn=true]


Ariel remained calm, but he understood my feelings.
[cpg]


And Ritul is also cooperating with me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="Littule112"]
[OnName num="littule"]
'Yeah, okay, Zod.
[cpg cn=true]


[OnName num="itsuki"]
'Sorry, but I'm asking for ......, guys.'
[cpg cn=true]


And after searching, we found a cave ......
[cpg]




;//========================================
;//●ＣＧ（主人公がヒロインを発見する。瞳はうつろになっている）ev_72
;//人物１：ヒロイン６
;//服装１：着衣
;//人物２：半魚人
;//服装２：無し
;//場所　：洞窟
;//時間　：昼
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_72_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


There, he found Mercurio, with his vacant eyes, and a strange, half-fish-like demon.
[cpg]

[OnName num="merman"]
Oops. I guess it's finally time to go."
[cpg cn=true]


[VOICE f="Mercurio086"]
[OnName num="mercurio"]
"Itsuki ......."
[cpg cn=true]


Somehow, I guessed what was happening.
[cpg]

[OnName num="itsuki"]
What are you doing there, ......?"
[cpg cn=true]


The demon, without a trace of malice, had no idea what he was ...... doing.
[cpg]

I was so excited that I wanted to kill the half-fish.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_ne"]
[WAIT time=100]
;//ブラックアウト


I had no intention of killing the half-fish.
[cpg]


I could have done anything I wanted. But I also felt that I could have killed him.
[cpg]


There was nothing I could do, even if I let my anger get the better of me.
[cpg]


Ritul, who came later, seemed to have figured it all out and half killed him, but it ...... didn't matter.
[cpg]


What was more important was what state Mercurio was in now.
[cpg]


That was much, much more important.
[cpg]


[OnName num="itsuki"]
I said, "Mercurio,...... I'm sorry you had to go through that. It's my fault."
[cpg cn=true]


[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mercurio087"]
[OnName num="mercurio"]
"I'm sorry ...... me, me ......."
[cpg cn=true]


Mercurio kept apologizing. He kept apologizing, telling me that I was a petty woman and that I didn't deserve to live.
[cpg]


It was just getting harder and harder to listen to him. I couldn't listen any longer.
[cpg]


[OnName num="itsuki"]
"You don't have to say anything more. ......
[cpg cn=true]


So I told Mercurio.
[cpg]


Still, Mercurio continued to speak.
[cpg]


Repeatedly, he said things that he blamed himself for.
[cpg]


Mercurio's heart seemed to be sensitive. I loved her like that.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mercurio088"]
[OnName num="mercurio"]
"I ...... think a woman like me should be dead already ......."
[cpg cn=true]


Don't be so hard on yourself. Such words didn't seem to reach her.
[cpg]


[OnName num="itsuki"]
'That's enough,......, that's enough.'
[cpg cn=true]


I hugged her as I said that, but what was the point of such behavior?
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（夜）******************************************************


Too many things had happened. I was tired, and Mercurio must have been tired too.
[cpg]


We decided to rest at the inn for the night. But ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


When morning came, Mercurio was already gone.
[cpg]


He had disappeared without a word to us.
[cpg]


Mercurio had apparently gone to the bottom of the sea.
[cpg]


No one could reach her. We never saw her.
[cpg]


We could not dive into the sea without Mercurio's help.
[cpg]


There was no way for us to get to the ocean.
[cpg]


I wondered if the mermaids knew where she was: ...... No. I wondered if there was any point in even thinking about it anymore.
[cpg]


It's useless to think about that now.
[cpg]


The first thing that comes to mind is the fact that the two of them have been in love for a long time.
[cpg]


I can't help this love anymore, it's broken. ......
[cpg]


;//ブラックアウト

;//ヒロイン６　ルート　エンド

;//ＥＮＤ
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[Ending_SetUp cl=cl_009 ss=false]

[system cl_009=true]

[SCENE id=19]

[jump storage="epend.ks" target="*start"]

