
*start

;#################################################
*Ep001|A Time of Decision
;#################################################

[SCENE id=1]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（朝）******************************************************

;//上下の黒帯を外してください


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/2" time=800]

[VOICE f="Ariel051"]
[OnName num="ariel"]
Good morning, Itsuki-san.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Elmyr016"]
[OnName num="elmyr"]
Good morning. Tree......, you look like you've made up your mind.
[cpg cn=true]


[OnName num="itsuki"]
"Oh, yes. I'll put off the evil gods after all.
[cpg cn=true]


The reconstruction of the Great Forest of Asekto. The defense of the undersea subterranean city.
[cpg]


I thought I would go ahead with all of them.
[cpg]


[OnName num="itsuki"]
First of all, let's deal with this forest. There might still be remnants of demons in the forest.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ariel052"]
[OnName num="ariel"]
That's ......, but that's more ......
[cpg cn=true]


[OnName num="itsuki"]
What's wrong?　It's what Ariel wanted, isn't it?
[cpg cn=true]


Ariel mumbled something. Then, after some hesitation, she said to me, "I'm worried about Ritul.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Ariel053"]
[OnName num="ariel"]
I'm worried about Ritul. I don't know if she can protect the underground city by herself.
[cpg cn=true]


[OnName num="itsuki"]
But don't you want to restore this forest?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
;//[t_move pos=L ゆらゆら]
[VOICE f="Ariel054"]
[OnName num="ariel"]
I said, "Don't worry. I'm sure the rest of us will be able to handle it.
[cpg cn=true]


Certainly, I was able to grasp the general situation of being devastated by monsters.
[cpg]


[OnName num="itsuki"]
Then, can we go to the underground city or go to ......?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
;//[t_move pos=R 下礼]
[VOICE f="Elmyr017"]
[OnName num="elmyr"]
Yes, let's go. Let's go.
[cpg cn=true]


;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************


We headed for the underground city.
[cpg]


I don't know where this underground city is, but it's called an underground city, so it must be underground.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="itsuki"]
Where's Hermia?
[cpg cn=true]


Along the way, Hermia had suddenly disappeared. Ariel looked used to it.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
;//[t_move pos=C 溜息]
[VOICE f="Ariel055"]
[OnName num="ariel"]
'She's always like this, you know.
[cpg cn=true]


[OnName num="itsuki"]
'...... I see. ......'
[cpg cn=true]


After all, it seems that elves and dark elves have a bit of an acrimonious relationship.
[cpg]


There's a lot going on because of the proximity of their existence,...... but really, considering the number of people that were there at the beginning, it's decreased considerably.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


And on the way, we reach a town.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
Diverse races come and go. Ariel, an elf, blended in so well.
[cpg]


If I asked her to stay at an inn or something, she'd probably let me stay over.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
;//[t_move pos=C 溜息]
[VOICE f="Ariel056"]
[OnName num="ariel"]
What should we do? I have some roadside silver.
[cpg cn=true]


[OnName num="itsuki"]
Yes. ......
[cpg cn=true]


Reconstruction of the great forest of Assekt. The defense of the undersea subterranean cities.
[cpg]


The prevention of poaching against the Mermaid tribe. It's a lot of work to do it all.
[cpg]


I had a general grasp of the situation in which the Great Forest of Asekto had been ravaged by demons, so I wanted to head for the underground city. ......
[cpg]


[OnName num="itsuki"]
So, Ariel,......, where is this underground city?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel057"]
[OnName num="ariel"]
At the bottom of the sea.
[cpg cn=true]


[OnName num="itsuki"]
What about ......?"
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


After getting accommodation, we decided to have a strategy meeting in the cafeteria.
[cpg]


I don't know what an underground city is.
[cpg]


[OnName num="itsuki"]
If it were at the bottom of the ocean, we wouldn't be able to go there. ......
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
;//[t_move pos=C 下礼]
[VOICE f="Ariel058"]
[OnName num="ariel"]
Not really. With the help of mermaids, we can breathe under water.
[cpg cn=true]


[OnName num="itsuki"]
"I see...... but Mercurio isn't here now, is he?"
[cpg cn=true]


Ariel says that the dwarves who live underground also usually cooperate with the mermaids.
[cpg]


Ritul and Mercurio, you mean. I wonder if they are good friends too.
[cpg]


I get the feeling that Ariel and Ritul are friends. ......
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

;//上下に黒帯を入れてください


So, another night. No one disturbed my sleep today, as the quintessence of the day ......
[cpg]


But that made me a little sad. I sometimes wondered if Hermia was there or if she would come.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************

;//上下の黒帯を外してください


And finally, it was time to go, or ...... to the underground city.
[cpg]


For that reason, we once headed to the place where the mermaids are said to dwell.
[cpg]


It is said that there is a kind of settlement around the seashore.
[cpg]


Ariel guessed that Mercurio would be there.
[cpg]

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


;//0911修正
Ariel guessed that Mercurio would be there. That seems to be the home of the mermaids.
[cpg]


The place of residence itself seems to be at the bottom of the sea.
[cpg]


The coast is probably a garden that the girls know well.
[cpg]


[OnName num="itsuki"]
...... Ah!
[cpg cn=true]

[FG f="CHA06_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
Mercurio was there after all.
[cpg]


Surprisingly...she looked like a mermaid from a fairy tale.
[cpg]


No, I had heard that, and I suppose it was only natural.
[cpg]


Mermaids who have lived long enough to gain power are said to be able to grow human legs at will through magic.
[cpg]


The fact that she didn't have a tail fin when we first met her was probably due to magic.
[cpg]


[FG f="CHA06_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mercurio004"]
[OnName num="mercurio"]
Oh, ...... tree ......
[cpg cn=true]


The first time I saw her, she was a little bit nervous. The first thing you need to do is to get a good idea of what you're looking for.
[cpg]


[OnName num="itsuki"]
The first time I saw him, he was in a hurry to get to the Underground City.
[cpg cn=true]


[OnName num="mermaid_A"]
Hey, that's .......
[cpg cn=true]


[OnName num="mermaid_B"]
It's a human being. I wonder what they're doing here. ......
[cpg cn=true]


Not a very welcoming situation. I guess it's the poaching and all.
[cpg]


Not so much unwelcoming as blatantly alarmist.
[cpg]


[FG f="CHA06_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
;//[t_move pos=C ゆらゆら]
[VOICE f="Mercurio005"]
[OnName num="mercurio"]
"......I'm sorry, Itsuki-san, ......I can't help you."
[cpg cn=true]


I knew it. That's right. ......
[cpg]


[FG f="CHA06_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mercurio006"]
[OnName num="mercurio"]
I know a colleague who approached me under that guise and suffered a terrible fate.
[cpg cn=true]


[free time=800]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[FG f="CHA06_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

;//[t_move pos=L 下礼]

[VOICE f="Ariel059"]
[OnName num="ariel"]
Oh no!　Do you really think Itsuki would do such a thing?
[cpg cn=true]


[FG f="CHA06_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Mercurio007"]
[OnName num="mercurio"]
I don't think so.
[cpg cn=true]


The actuality is that the actual mermaids are not really the same as the other mermaids.
[cpg]


I'm not saying that, but I can't cooperate because of the eyes of those around me.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
It was a convincing story. I would have done the same thing if I were in the opposite situation.
[cpg]


It's a good use of skill. Thinking so, I used 《Analysis》 on myself and called up a list of skills.
[cpg]


[FG f="CHA06_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Mercurio008"]
[OnName num="mercurio"]
"Eh, ......?　Itsuki-san what are you doing?
[cpg cn=true]


[OnName num="itsuki"]
Well, wait a minute.
[cpg cn=true]


If you look closely, you will see that from left to right, there are swordsmanship or combat skills, magic skills in the center, and to the right of that, there are some ancient characters that I don't know what they are .......
[cpg]


I guess they are categorized. Thinking it was convenient, I chose one of the magic skills.
[cpg]


In other words, the skill of 《negotiation skill》. I could see this one from a very early stage.
[cpg]


I'm going to get this ...... Now, what will happen?
[cpg]


[OnName num="itsuki"]
Let me ask you again. I want to go to the Underground City, but I won't stop there.
[cpg cn=true]


[OnName num="itsuki"]
I know the mermaids are being poached. I'll fix it, I promise.
[cpg cn=true]


[OnName num="itsuki"]
"I'll not only solve it, but I'll figure out a way to fight it. So please."
[cpg cn=true]


[OnName num="mermaid_A"]
"......"
[cpg cn=true]


[OnName num="mermaid_B"]
"I don't know if it's true ......, but if it's true ......"
[cpg cn=true]


I said loud enough for the mermaid watching from afar to hear.
[cpg]


I was able to do that unconsciously. The "good negotiator" skill seems to have an effect.
[cpg]


[FG f="CHA06_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Mercurio009"]
[OnName num="mercurio"]
I understand ....... You have my word.
[cpg cn=true]


All right, I'm off to Ritul's now. Now I can go to Ritul's place.
[cpg]


I look at Ariel, smile a little, and nod to each other.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Ariel060"]
[OnName num="ariel"]
I looked at Ariel and nodded a little, "...... what is that?　What's that skill?
[cpg cn=true]


[OnName num="itsuki"]
What?　That's true.
[cpg cn=true]


Among the countless letters, there is a skill that has already been mastered.
[cpg]


The most important thing to remember is that the best way to get the most out of your money is to be a good negotiator.
[cpg]


What is this? I thought, "What is this?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ariel061"]
[OnName num="ariel"]
What is this? I've never heard of ...... the "natural wickedness" skill.
[cpg cn=true]


The same seems to be true for Ariel.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


The first thing to do is to find a good place to live.
[cpg]


Several mermaids, including Mercurio, cast a spell on us.
[cpg]


Then we could really breathe in the water.
[cpg]


I know it's strange, but no wait... ......
[cpg]


Was there ever a plan for me to use my skills to get the art of breathing underwater?
[cpg]


...... I can't help but think about that now. Besides, I was going to solve Mercurio's problems either way.
[cpg]


The first thing I did was to swim for a while, and then I came to a place that seemed to me to be an underground city.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（昼）******************************************************


There was a huge space.
[cpg]


[OnName num="itsuki"]
No, wait, ...... why doesn't seawater flow here?　That's crazy."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Ariel062"]
[OnName num="ariel"]
There's a magic circle they say was created by a great wizard in the past. It is said that it is still in effect.
[cpg cn=true]


Come to think of it, it's impossible to breathe in a place like this.
[cpg]


[FG f="CHA06_p1_02_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Mercurio010"]
[OnName num="mercurio"]
"Theoretically, it is the same magic that we mermaids use. Though on a much different scale.
[cpg cn=true]


While we were having this conversation, a shadow in the distance looked at us.
[cpg]

[SE f="se024"]
;//【ＳＥ】『走る』


Then, with loud footsteps, it came running toward us.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
;//[t_move pos=R 下礼]
[VOICE f="Littule016"]
[OnName num="littule"]
Ariel!　I'm so glad you came.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Ariel063"]
[OnName num="ariel"]
Of course I'm here. I know that your homeland is in danger.
[cpg cn=true]


Ritul wondered how good his eyesight was, thinking .......
[cpg]


[OnName num="itsuki"]
What's going on here ......?　How do you get food and stuff?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Littule017"]
[OnName num="littule"]
Ritul asked, "We're basically self-sufficient. Well, well, well, aren't you hungry?"
[cpg cn=true]


We were indeed a little hungry. So we had lunch with the dwarves.
[cpg]


The dwarves welcomed us with open arms.
[cpg]


[OnName num="dwarf_A"]
You've come a long way!　You are the hero of salvation.
[cpg cn=true]


[OnName num="dwarf_B"]
You must be hungry, I'll cook for you.
[cpg cn=true]


The meal he served us was a meal containing vegetables and fish.
[cpg]


The fish was still good, but how do they grow the vegetables?
[cpg]


Would they grow in a place where the sun never reaches? Or is there something magically wrong with them?
[cpg]


[OnName num="itsuki"]
You say that ...... so ...... demons are invading?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Littule018"]
[OnName num="littule"]
'We're a little further out. But if we don't protect the magic circle, this village will be finished. ......
[cpg cn=true]


I see. I can see the logic. It means that this place will be submerged.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（夜）******************************************************

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


And we stayed in one of the houses built in the underground city.
[cpg]


A facility like an inn. I tried to sleep in one of the rooms there, but I had a strange feeling in my chest.
[cpg]


I can't sleep ...... I wake up.
[cpg]


And then I felt a presence, as if someone was coming.
[cpg]

;//■選択肢
[switch]
[case "Is it Ritul?"]
	[swap]
	[jump target="*select02_1"]
[case "Would it be Mercurio?"]
	[swap]
	[jump target="*select02_2"]
[endswitch]


4, is it Ritul?
5, Would it be Mercurio?


;//==============================
;//４、リトゥルかな？
*select02_1|Time to make up my mind

[stflag Sel2flg = 1]

[system sysSel2flg=false]

;//（直後の選択肢で選択肢７が発生）


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Littule019"]
[OnName num="littule"]
"Sorori-Sorori-......"
[cpg cn=true]


It's Ritul. He comes closer, saying, "Sorori-Sorori-Soriri. That's a little too obvious.
[cpg]


[OnName num="itsuki"]
What are you doing?
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Littule020"]
[OnName num="littule"]
Oh!　Well, it looks like Tree can't sleep, so I thought I'd give him a little company.
[cpg cn=true]


I don't think you can tell that from outside the room. Well, let's talk to each other.
[cpg]


[OnName num="itsuki"]
"No, I'm just ....... I couldn't sleep.
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Littule021"]
[OnName num="littule"]
I know how you feel. I know how you feel. You might have to fight a demon afterwards.
[cpg cn=true]


[OnName num="itsuki"]
I know. I know. And so does Ritul.
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Littule022"]
[OnName num="littule"]
I'm ...... not sleeping right now for another reason.
[cpg cn=true]


[OnName num="itsuki"]
What do you mean ......?"
[cpg cn=true]


As I was saying this, Ritul was coming on to me.
[cpg]


[FG f="CHA02_p5_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Littule023"]
[OnName num="littule"]
I'm sure you're a great swordsman, Tree. I like strong men.
[cpg cn=true]


[OnName num="itsuki"]
It's best not to say things like ...... like that too casually.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Littule024"]
[OnName num="littule"]
"Don't say that,......, but I'd like to stay with you a little longer.
[cpg cn=true]


;//移植のためシーンをカットしています

;//ブラックアウト

[free time=1000]
;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


After that happened, Ritul went back to his room.
[cpg]

I'm not sure why I'm feeling so popular. Is this normal in your current position?
[cpg]


[jump target="*select02_3"]
;//==============================
;//５、メルクーリオだろうか？
*select02_2|A Time of Decision


[stflag Sel2flg = 2]

[system sysSel2flg=true]


[SE f="se009"]
;//【ＳＥ】『ドアノックする』

[free time=1000]


[VOICE f="Mercurio011"]
[OnName num="mercurio"]
I'm going to ask you to come to my room. May I?"
[cpg cn=true]

[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[OnName num="itsuki"]
"Yeah. Come in, I haven't slept either."
[cpg cn=true]


Silence for a while. Then Mercurio came to sit by my side.
[cpg]


[FG f="CHA06_p3_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mercurio012"]
[OnName num="mercurio"]
He said, "I can't sleep either. Maybe even now, my people are being kidnapped."
[cpg cn=true]


[OnName num="itsuki"]
I see. ......I'll take care of it, as long as you said I would."
[cpg cn=true]


[FG f="CHA06_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mercurio013"]
[OnName num="mercurio"]
Thank you. I'm glad you said that."
[cpg cn=true]


Silence for a while. Then Mercurio got up from the bed where he was sitting and tried to kiss me.
[cpg]

[FG f="CHA06_p5_02_a.ui" method="change_2"  pos="2/3" time=800]
[OnName num="itsuki"]
He said, "...... wait a minute. What do you mean?"
[cpg cn=true]


[FG f="CHA06_p5_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mercurio014"]
[OnName num="mercurio"]
'I ...... have always been interested in you, Itsuki.
[cpg cn=true]


[OnName num="itsuki"]
I've been thinking about you for a long time.
[cpg cn=true]


[FG f="CHA06_p5_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mercurio015"]
[OnName num="mercurio"]
The first thing you need to do is to make sure that you have the right tools to do the job. The most important thing to remember is that you can't be sure when you're going to die,......, so why don't you let us make some memories?
[cpg cn=true]


What should I do? The most important thing to remember is that you are not alone.
[cpg]


[OnName num="itsuki"]
"I'm sorry, but wouldn't it be better to do it with ...... Mercurio's significant other?"
[cpg cn=true]


I refused softly. An awkward silence fell. Then, he said, "You're hot.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[VOICE f="Elmyr018"]
[OnName num="elmyr"]
You're hot, aren't you?
[cpg cn=true]


Hermia suddenly appeared. No, wait a minute, how long have you been watching me?
[cpg]

[free time=800]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_5"  pos="2/2" time=800]

[VOICE f="Mercurio016"]
[OnName num="mercurio"]
What?　Oh, um, since when ......"
[cpg cn=true]


I ask the exact same thing.
[cpg]


[OnName num="itsuki"]
'You've been peeping at me. Since when?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Elmyr019"]
[OnName num="elmyr"]
From the beginning. It was so embarrassing to watch.
[cpg cn=true]


[FG f="CHA06_p1_02_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="Mercurio017"]
[OnName num="mercurio"]
I'm leaving!
[cpg cn=true]

[SE f="se008"]
;//【ＳＥ】『ドア閉まる』


[free time=1000]

Mercurio left the room saying so.
[cpg]

I felt kind of bad. ......
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト


;//==============================
*select02_3|A Time of Decision

;//上下の黒帯を外してください


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『地下都市』（昼）******************************************************


The next day. Hermia, who had disappeared somewhere, appeared and with a serious expression on her face, cut in with the following words.
[cpg]

[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="3/3" time=800]

[VOICE f="Elmyr020"]
[OnName num="elmyr"]
The Great Forest of Acecto is in a bad way. The next day, he appeared and said with a serious look on his face, "The Great Forest of Asekto is in a bad way.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
;//[t_move pos=C 動揺]
[VOICE f="Ariel064"]
[OnName num="ariel"]
Oh, no. ......
[cpg cn=true]


[FG f="CHA06_p1_02_a.ui" method="change_4"  pos="1/3" time=800]
[VOICE f="Mercurio018"]
[OnName num="mercurio"]
What should we do ......?　
[cpg cn=true]


I understand the situation in the underground city. The actuality that they are in the middle of a defensive battle right now.
[cpg]


The demons are attacking from deeper inside this underground city.
[cpg]


These demons seem to be demons that don't seem to have any wisdom. ......
[cpg]


It would be easy to just get rid of them, but it seems that the war is gradually becoming a war of attrition.
[cpg]


[OnName num="itsuki"]
We have to save this underground city,.......
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="Elmyr021"]
[OnName num="elmyr"]
But there's also the Great Forest of Acecto. And what about the Mermaid Tribe?"
[cpg cn=true]


I was lost. I was lost, but I decided what I was going to do.
[cpg]

;//（直前の選択肢で何を選んでいたかによって発生する選択が変化）
;//（選択肢６は常に発生。選択肢が二つない場合は６の方へ）


[if exp={getFlagValue("Sel2flg") == 2}]
[jump target="*select03_1"]
[endif]

;//■選択肢
[switch]
[case "Return to the Great Forest."]
	[swap]
	[jump target="*select03_1"]
[case "Defensive Battle of the Undersea Subterranean City"]
	[swap]
	[jump target="*select03_2"]
[endswitch]


6, Return to the Great Forest
7, Defense of the Undersea City


;//==============================
;//６、大森林へ戻る
*select03_1
[jump storage="ep002.ks" target="*select03_1"]


;//==============================
;//７、海底の地下都市の防衛戦
*select03_2
[jump storage="ep010.ks" target="*select03_2"]

