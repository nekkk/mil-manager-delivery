
*start
;//寝取られスキル　シナリオ
;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり

;//アリエル　　　裸　着衣
;//リトゥル　　　裸　鎧　普段着
;//エルミア　　　裸　着衣
;//シャルロッテ　裸　着衣
;//メルクーリオ　裸　着衣

;//上記以外のキャラクターには音声がありません
;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//アリエル　一人称「私」　リトゥル呼び「リトゥル」　エルミア呼び「エルミア」
;//　　　　　シャルロッテ呼び「シャルロッテ」　メルクーリオ呼び「メルクーリオ」　樹呼び「樹様」
;//リトゥル　一人称「あたし」　アリエル呼び「アリエル」　エルミア呼び「エルミア」
;//　　　　　シャルロッテ呼び「シャルロッテ」　メルクーリオ呼び「メルクーリオ」　樹呼び「樹」
;//エルミア　一人称「私」　アリエル呼び「アリエル」　リトゥル呼び「リトゥル」
;//　　　　　ヴィクトリア呼び「ヴィクトリア」　シャルロッテ呼び「シャルロッテ」　メルクーリオ呼び「メルクーリオ」　樹呼び「樹」
;//シャルロッテ　一人称「あたし」　アリエル呼び「アリエル」　リトゥル呼び「リトゥル」　エルミア呼び「エルミア」
;//　　　　　　　メルクーリオ呼び「メルクーリオ」　樹呼び「樹」
;//メルクーリオ　一人称「私」　アリエル呼び「アリエルさん」　リトゥル呼び「リトゥルさん」　エルミア呼び「エルミアさん」
;//　　　　　　　ヴィクトリア呼び「ヴィクトリアさん」　シャルロッテ呼び「シャルロッテさん」　樹呼び「樹さん」
;//樹　一人称「俺」　アリエル呼び「アリエル」　リトゥル呼び「リトゥル」　エルミア呼び「エルミア」
;//　　シャルロッテ呼び「シャルロッテ」　メルクーリオ呼び「メルクーリオ」

;//物語の視点が変わる部分があります。ウィンドウ色を変えるなどして、変化をつけてください
;//視点は主人公視点、ヒロイン視点の二種類です
;//物語は主人公視点からスタートし、切り替わる部分では「（キャラ名）に視点切り替わり」と表記してあります


;//////////////////////////////////////
;///////////////以下本編///////////////
;//////////////////////////////////////


;#################################################
*Ep000|The Brave Man Who Saves the World
;#################################################


[SCENE id=0]


[stflag Sel1flg = 0]
[stflag Sel2flg = 0]

;//タイトルコールのリセットの為
;//[VOICE f="Reset000"]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Suppose, for example, you wish to be a brave man who saves the world.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


I think it is unfortunate that people who want to be something that they normally cannot be are unhappy in their lives.
[cpg]


Astronauts and prime ministers are the most extreme examples.
[cpg]


Even if you don't want to be an astronaut or a prime minister, it's hard to be an athlete or an artist.
[cpg]


Kazara Itsuki is a normal male student who leads a normal life. An ordinary male student leading an ordinary life.
[cpg]


I didn't have anything I wanted to be. I even thought it was a happy thing.
[cpg]


In this day and age when it is difficult to have a normal family while pursuing your dreams, I was riding the rails that would allow me to have a normal family to some extent.
[cpg]


[OnName num="male_student"]
I was on the track to have a somewhat normal family.
[cpg cn=true]


[OnName num="itsuki"]
"By 'you guys,' I mean ...... who and who?"
[cpg cn=true]


[OnName num="male_student"]
I said, "You guys. I'm saying "you guys." You want me to name names?
[cpg cn=true]


That's what my friend said. He said it in a loud voice, so I ......
[cpg]


My childhood friend is blushing in the distance. I think he was referring to me and my childhood friend when he said, "When are you going out with me?
[cpg]


[OnName num="itsuki"]
I said, "No, no, no, no. Don't do that, it's embarrassing."
[cpg cn=true]


I was happy, but only moderately so.
[cpg]


I thought I would be surrounded by friends, childhood friends, and juniors and live the same life as many others.
[cpg]


But that idea was to be denied me in a way I never imagined, in a way I really never imagined.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


The school I attended had an atmosphere of rigidity, or rather, an atmosphere in which slacking off was not tolerated.
[cpg]


There were many scary teachers, even though there were no delinquents. I can only say that it was the nature of the school.
[cpg]


There were many teachers who could not just say, "I'm sorry, I'm late!　There were also many teachers who would not just say, "I'm sorry, I'm late! And I was late for the class of such a teacher.
[cpg]


[OnName num="itsuki"]
It was not enough to say, "I'm sorry, I was late. ......
[cpg cn=true]


It didn't end with "I'm sorry I was late. I was given a pretty severe penalty on the spot, whether it was to make an example of me or not.
[cpg]

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


The school's old warehouse. I guess there are several of these things, but this was one of them.
[cpg]


I was told to clean it, and I had no choice but to start cleaning it.
[cpg]


It's a terrible mess, by the way. It's almost as if they intentionally make the place messy to punish students like me.
[cpg]


The warehouse was a mess of various things, and it looked completely unkempt.
[cpg]


[OnName num="itsuki"]
'Oh dear, ...... what are we going to do?'
[cpg cn=true]


I couldn't not do what I was told. I put things away one by one.
[cpg]


In the middle of it all, I found an old large mirror. It was dirty.
[cpg]


[OnName num="itsuki"]
I thought, "What the hell is this for?"
[cpg cn=true]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************


[SE f=se088]
;//【ＳＥ】『窓拭く』



I thought, but carefully wiped it down. Cleaning the warehouse was a tough job, and by the time I finished, it was nighttime.
[cpg]


I thought, "I should go home. I was about to open the door when I heard a voice at ......
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


[OnName num="itsuki"]
What?　Oh, what's that?
[cpg cn=true]

[SE f="se005"]
;//【ＳＥ】『鍵がかかった扉を動かす　ガチャガチャ』

It's locked. It was locked from the outside.
[cpg]


The teacher on patrol must have inadvertently locked the door.
[cpg]


This is not good. ...... I'll have to spend the night here.
[cpg]


No, it's too early to give up. I wondered if I could unlock the door from the inside with something.
[cpg]

;//[free time=1000]
[BG f="b_06_4e2.ui" time=1000]

That's when it happened. A voice came out of nowhere.
[cpg]


[OnName num="itsuki"]
"......, is someone there?"
[cpg cn=true]


It couldn't be. I had been cleaning here the whole time.
[cpg]


;//[BG g="white" rule="enn1" time=800]

[window target=false]
[transition target={true} rule="enn1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0xffffffff} time=1]
[WAIT time=1]

;//[WAIT time=100]
;//ホワイトアウト
;//ゆっくりとフェード
;//[fadeoutbgm]
;//BGMをフェードアウト

[STOPBGM]


[WAIT time=1000]


;//召喚エフェクトここに




[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="e_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[SE f="se001"]
;//【ＳＥ】『光がぱーとか衝撃的な感じ』



[BG f="e_01_2.ui" time=1000]
[WAIT time=2000]


[transition target={true} rule="enn2.webp" color={0xffffffff} time=1000]
[WAIT time=1000]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn2.webp" color={0xffffffff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


And then the great mirror emitted a blinding ...... light and I was sucked into it.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[SE f="se002"]
;//【ＳＥ】『水に落ちる』


It was painful and cold. I can't breathe. It's like I'm under water.
[cpg]

I don't have time to think about what I'm going through.
[cpg]

I move my arms and legs frantically.
[cpg]


[OnName num="itsuki"]
What is that voice?
[cpg cn=true]


Then...out of nowhere, I heard a voice.
[cpg]


I swam frantically in the direction of the voice.
[cpg]

;//上下の黒帯を外してください



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************

;//注釈があるまでヒロイン達の名前欄を「？？？」と置き換えてください
;//誰がどのセリフであるかは立ち絵を表示するタイミングで表してください

As I moved my body in search of air, I emerged from the water.
[cpg]


[OnName num="itsuki"]
Gee, gee, gee, gee, gee!　What the hell is this? ......"
[cpg cn=true]

I coughed, as if I had drunk the water.
[cpg]

[VOICE f="Ariel001"]
[OnName num="unknown"]
I coughed, as if I had drunk some of the water.
[cpg cn=true]

I heard a voice worried about me.
[cpg]

Yeah? - Yeah. Am I a brave man? You got the wrong guy? But maybe she' s talking about me... she should be.
[cpg]


[OnName num="itsuki"]
Ha ha ha, no...I thought I was going to die.
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]


It was a skin-colored world. No, no. I was surrounded by women in light clothing.
[cpg]

;//手を伸ばせば触れる距離にまで裸の美女が近づく。わけの分からない状況だ。
I was surrounded by beautiful women in light clothing, and if I reached out to touch them, I could almost touch them. It was an incomprehensible situation.
[cpg]

Was I bathing in the water?
[cpg]

;//いや、でも…裸の美女は一人じゃない。俺を取り囲む様にして大勢居る。
No, but...the beautiful woman in light clothing was not alone. There are many of them surrounding me.
[cpg]


[free time=800]
;//[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA05_p5_01_a.ui" method="change_1"  pos="2/3" time=800]


Each of them is unique in appearance. They have long ears. They have horns. Or a tail. ......
[cpg]


[free time=800]

[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Ariel002"]
[OnName num="unknown"]
But still,......, I could really summon them,.......
[cpg cn=true]


;//[free time=1000]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Littule001"]
[OnName num="unknown"]
"Oh come on, Ariel didn't have faith in you?　I knew it was going to work.
[cpg cn=true]


;//0911修正
At my feet, or rather where I was sleeping, there was a huge pattern painted on the ground.
[cpg]


It looked like the magic circle you often see in video games.
[cpg]

And there is also a large mirror like the one in the warehouse.
[cpg]


The magic circle is disappearing little by little. It disappears while emitting light. ......
[cpg]

[free time=800]

[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr001"]
[OnName num="unknown"]
I'm sure there are many things you want to ask. But what I can say now is ......
[cpg cn=true]

;//[free time=800]

[FG f="CHA03_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Elmyr002"]
[OnName num="unknown"]
You are the brave one who will save this world.
[cpg cn=true]


That's absurd. I can't say that I'm a brave man who will save the world.
[cpg]


I can't say that I'm a brave person. I was overwhelmed by the strangeness of the place.
[cpg]


[free time=800]

[FG f="CHA05_p5_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Charlotte001"]
[OnName num="unknown"]
Well, you can't know everything all of a sudden, can you?
[cpg cn=true]

[FG f="CHA06_p5_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Mercurio001"]
[OnName num="unknown"]
Well, first of all, the ...... summoning ritual went well, so why don't you put on some clothes?
[cpg cn=true]


When they said that to me, I thought for a minute that I couldn't speak for others.
[cpg]

;//0911修正
There are people with wings and tails over here.
[cpg]

The pink lady looks relatively normal, but....
[cpg]

I can't help but think that she must be in some kind of trouble....
[cpg]


[OnName num="itsuki"]
Wait a minute... ...... not all of it, just explain it to me."
[cpg cn=true]


;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


So we were taken to a hut-like place and given an explanation, not the whole thing.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="3/3" time=800]

Everyone was already dressed. It seems that the light clothing and kneeling were necessary for the summoning.
[cpg]


By the way, I was dressed like a traveler in a fantasy ......, which was strangely embarrassing.
[cpg]

;//ここからアリエルの名前をそのまま表示してください


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel003"]
[OnName num="ariel"]
I was strangely embarrassed. I am Ariel Lounds,...... and as a race I am classified as a high elf among elves."
[cpg cn=true]


Elves. That's what they look like when you put it that way.
[cpg]


The ears are pointed and somewhat out-of-this-world.
[cpg]


[OnName num="itsuki"]
Oh, hi. ......."
[cpg cn=true]


And I said, "Hi," as he introduced himself.
[cpg]


There was no "hi" in this situation, but I had nothing else to say.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ariel004"]
[OnName num="ariel"]
"May I ask your name?"
[cpg cn=true]


I wonder if Japanese names are understood in this world. ...... Ariel is not a Japanese name by any means.
[cpg]


[OnName num="itsuki"]
I'm Shikaraku Tatsuki .......
[cpg cn=true]


I was afraid to say my name. She nodded her head and said her name was Ariel.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel005"]
[OnName num="ariel"]
Well then, Trees. Let me start by explaining your assigned role ......, or rather, your destiny.
[cpg cn=true]


Fate. I braced myself as I heard these rather heavy words.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel006"]
[OnName num="ariel"]
The first thing to remember is that you are truly a brave man. You are the one who will save this world.
[cpg cn=true]


So I'm a brave man. I didn't think so.
[cpg]


I had been riding the rails of my life too normally. I could not suddenly make this change.
[cpg]


[OnName num="itsuki"]
I can't suddenly make this switch. ......
[cpg cn=true]


Ariel said something even more serious to my bewildered state of mind.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel007"]
[OnName num="ariel"]
If you can't save this world, you can't return to your original world.
[cpg cn=true]


[OnName num="itsuki"]
Oh, no. ......."
[cpg cn=true]


That's absurd. What do you mean you can't go back to ......?　So, if you don't do something to save this world or something, you're going to live here for the rest of your life?
[cpg]


That's fine at a hundred percent. But how can they speak the language?
[cpg]


They don't look Japanese, and this place doesn't look like Japan.
[cpg]


If there is such a thing as an otherworldly language, that's what they should be using.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]

But Ariel and some of the names around there seem to be English-speaking. ......
[cpg]

;//ここからシャルロッテの名前をそのまま表示してください


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte002"]
[OnName num="charlotte"]
Well, I guess I should introduce myself too.　My name is Charlotte. ......"
[cpg cn=true]


Charlotte. That sounds English too. If not English, it sounds like somewhere in Europe.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
;//;//[t_move pos=C 羽ばたき]
[VOICE f="Charlotte003"]
[OnName num="charlotte"]
"Charlotte Dianda. I don't know if you can tell that my race is a dragonut .......
[cpg cn=true]


[OnName num="itsuki"]
"Well, ......, it's a little hard to tell."
[cpg cn=true]


'Dragoneut. I've heard of them, but I don't know what they are.
[cpg]


It would be something like a dragon person.
[cpg]


And Charlotte asked more questions.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte004"]
[OnName num="charlotte"]
I'm sure there's some unusual power in the tree right now. Are there any ...... unfamiliar voices in your head?
[cpg cn=true]


What a contradictory sentence. How could I possibly hear an unfamiliar voice? I thought, "No, there's ......
[cpg]


[OnName num="itsuki"]
There's ....... What the heck, this is ......."
[cpg cn=true]


That being said, I do remember hearing some voices.
[cpg]


I must have come to this world all of a sudden. In my head, there was something etched in my mind that I couldn't tell was a man's voice or a woman's voice.
[cpg]


In other words, "Chosen hero, I give you the power of salvation.
[cpg]


The power of salvation. What kind of power? I can't even imagine.
[cpg]


I mean, this situation really confirms that I am a brave man, doesn't it?
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]

[OnName num="itsuki"]
"...... my head hurts ......"
[cpg cn=true]


Too much information. Too much information, too sudden, too much of everything.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Elmyr003"]
[OnName num="unknown"]
I don't want to overstep. I can explain in detail tomorrow.
[cpg cn=true]


From next door, she said, a little different from Ariel, but elf-like.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Ariel008"]
[OnName num="ariel"]
Don't be a divider, Hermia. We are supposed to be equals.
[cpg cn=true]


Ariel said angrily.
[cpg]


The dark elfish one over there is called Hermia," Ariel said angrily. And, as expected, she and Ariel didn't get along.
[cpg]

;//ここからエルミアの名前をそのまま表示してください
;//ここからメルクーリオの名前をそのまま表示してください

[free time=800]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]

[FG f="CHA06_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mercurio002"]
[OnName num="mercurio"]
The first thing to do is to make sure that you are not going to be able to get a good deal of money from the company. Mercurio Smale."
[cpg cn=true]


[FG f="CHA06_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
Mercurio. I don't know her race. What is it ......?
[cpg]


I know she's not human. But I don't know what is not human.
[cpg]


If I had to guess, is she a mermaid?　She has that vibe, but she has legs.
[cpg]


I wonder if a mermaid with legs would be called a mermaid. ......
[cpg]

[free time=800]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]

[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Elmyr004"]
[OnName num="elmyr"]
And ...... this girl over here is Ritul the Dwarf.
[cpg cn=true]

;//ここからリトゥルの名前をそのまま表示してください



[FG f="CHA02_p3_02_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Littule002"]
[OnName num="littule"]
Nah!　I just got done with it!　I'm a Dwarf.
[cpg cn=true]


The dwarf who was called Ritul is angry.
[cpg]


The five of them never seem to get along well with each other. But ......
[cpg]


He also called me a brave man. I wonder if they are temporarily cooperating with each other ......?
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夕方）******************************************************


While I was thinking about this, I was hungry and the sun was shining.
[cpg]


There were some hut-like buildings in the forest, and they seemed to be living there.
[cpg]


And another group of elves ...... I imagined that this is where the basic elves live.
[cpg]


I was assigned one of the huts, and it was very spacious.
[cpg]


It was also well furnished. I was relaxing, wondering if it had been built for me.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Littule003"]
[OnName num="littule"]
"Hey, Tree. I want you to come over here for a minute.
[cpg cn=true]


[OnName num="itsuki"]
What now, ......?"
[cpg cn=true]


[STOPBGM]

[free time=1000]

;//上下の黒帯を外してください


That evening, I was surrounded by Ariel and his friends again.
[cpg]

[BGM f="bg_se"]

I was surrounded by Ariel and the others again that evening, but this time to get a briefing from them about my mission.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Ariel009"]
[OnName num="ariel"]
First of all, I should start by explaining the world itself. It's different from the world you used to live in, isn't it?
[cpg cn=true]


[OnName num="itsuki"]
Oh, please. ......
[cpg cn=true]


The name of the world, according to him, is Egiltes. The world we lived in didn't have a name, but this one does, apparently.
[cpg]


Maybe they had the concept from the beginning that there were several worlds.
[cpg]


Otherwise, they would not have thought of summoning me from another world.
[cpg]


And this place is called the L'Evole Forest.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Littule004"]
[OnName num="littule"]
In our world, several races coexisted and there was a good balance .......
[cpg cn=true]


[OnName num="itsuki"]
But?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ariel010"]
[OnName num="ariel"]
An evil god has appeared.
[cpg cn=true]


Evil gods. Jashin. Maybe this is the right kanji, or maybe there are kanji in this world.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Elmyr005"]
[OnName num="elmyr"]
The appearance of the evil god has upset the balance. The demon tribe has become unusually powerful.
[cpg cn=true]


Even the races that are not demons, everyone is moving with selfish thoughts, and their hearts are inclined toward the evil way.
[cpg]


In short, it is said that they are sprinkling the world with a kind of miasma.
[cpg]


[OnName num="itsuki"]
What kind of ...... evil god is that? What does it look like, and what kind of thoughts does it have?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Ariel011"]
[OnName num="ariel"]
I don't know if that thing has any thoughts. ...... What does it look like?"
[cpg cn=true]


The girls looked at each other. Then Ritul said, "What is it?
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Littule005"]
[OnName num="littule"]
'A pillar?
[cpg cn=true]


[FG f="CHA06_p3_02_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Mercurio003"]
[OnName num="mercurio"]
'It looks like a stake, doesn't it?
[cpg cn=true]


I don't know,...... I don't get it at all.
[cpg]


But I could imagine that it looks like an inorganic object.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ariel012"]
[OnName num="ariel"]
Now, it's stuck in the floating city of Realm Realm. Any sane creature would be hit by the miasma just by trying to get close to it. ......
[cpg cn=true]

[free time=800]

I am the only one who can crush that evil god, they say.
[cpg]



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

Ariel is an elf. Hermia, a dark elf.
[cpg]

[free time=800]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

And Ritul, a dwarf, and Charlotte, a dragonute. ......
[cpg]

[free time=800]
[FG f="CHA06_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

Mercurio, by the way, is also a mermaid, in short.
[cpg]


The two are now temporarily cooperating with each other in order to confront the evil god, although their races are divided in various ways.
[cpg]


[free time=800]

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte005"]
[OnName num="charlotte"]
So, we had to defeat that thing.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte006"]
[OnName num="charlotte"]
We decided ...... to summon the traditional "heroes" and ask for their help.
[cpg cn=true]


[OnName num="itsuki"]
That's all well and good, but why me?
[cpg cn=true]

[free time=800]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ariel013"]
[OnName num="ariel"]
That ...... I don't understand either.
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Littule006"]
[OnName num="littule"]
But I'm sure you have the right person for the job. But I'm sure you have the right person for the job.
[cpg cn=true]


[free time=800]

I wonder if that's true,.......
[cpg]


;//[free time=800]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel014"]
[OnName num="ariel"]
In any case, you are the only one who can save this world.
[cpg cn=true]


Hearing Ariel's powerful words, I felt like I couldn't go against her in any way. ......
[cpg]


I can't go back to the present day right away. The most important thing to remember is that you can't go back to the present day.
[cpg]


The most important thing to remember is that you can't live as a hero and just be thrown out into another world.
[cpg]


I had no choice but to accept the treatment as a brave man.
[cpg]


I didn't feel bad about being begged by all the pretty girls. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel015"]
[OnName num="ariel"]
I'm sorry. You're really angry, aren't you?"
[cpg cn=true]


[OnName num="itsuki"]
What ......?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel016"]
[OnName num="ariel"]
I was brought into this world out of the blue, and it's impossible not to feel something.
[cpg cn=true]


[OnName num="itsuki"]
I don't care. It's what this world needs.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel017"]
[OnName num="ariel"]
But ...... you can be more selfish.
[cpg cn=true]


I guess those words were said out of guilt.
[cpg]


It was like he was trying to do his best for me to keep me in a good mood as much as possible.
[cpg]

[STOPBGM]
[free time=1000]

;//上下に黒帯を入れてください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


[BGM f="bg_ni"]

Later, while I was in the hut thinking about what I was going to do, a sumptuous meal was brought in.
[cpg]


She was an elf, but she was dressed like a maid.
[cpg]


[OnName num="itsuki"]
She said, "...... can't eat all this food. It's too sumptuous."
[cpg cn=true]


I wonder if fish can be caught in a forest like this. I wonder if that's the meal they're making for me.
[cpg]


[OnName num="itsuki"]
Anyway, take half of it home and share it with everyone. ......
[cpg cn=true]


[OnName num="maid"]
I can't do that!　If you are not brave enough, I will be killed.
[cpg cn=true]


[OnName num="itsuki"]
"That's all right. Just take it home.
[cpg cn=true]


I didn't like being treated so politely. And the maid gave up and took some of the food and left.
[cpg]


Ariel arrived shortly thereafter.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Ariel018"]
[OnName num="ariel"]
Did the maid do something wrong?　Or didn't you like the food......?
[cpg cn=true]


[OnName num="itsuki"]
No, it's not that. ...... Never mind."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel019"]
[OnName num="ariel"]
I understand, something the maid said offended you, so behead that maid. ......
[cpg cn=true]


[OnName num="itsuki"]
How could you do that?
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I was not going to stop there.
[cpg]


After that, every night, I don't know what their intentions were, but they would send a woman to me.
[cpg]


;//[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Ariel020"]
[OnName num="ariel"]
I would say to them, "Dear ...... tree, I'm not satisfied with those women. If those women don't satisfy you, I will ......"
[cpg cn=true]


And when I turned them all down, Ariel herself would come in and annoy the hell out of me.
[cpg]


[OnName num="itsuki"]
I said, "No, thank you!　Go away!"
[cpg cn=true]


I sighed a little as I thought about my future in a different world where everything is different from what I know.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************


One night. One night, I had a visitor in my hut.
[cpg]


I guess they couldn't meet me just because I was a rarity. I could understand that somehow.
[cpg]


But those five people who were there when I was summoned came to me in turn.
[cpg]

[SE f="se007"]
;//【ＳＥ】『ドア開く』


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel021"]
[OnName num="ariel"]
I asked them, "Are you all right, ......?　Are you free?"
[cpg cn=true]


[OnName num="itsuki"]
No, I'm fine. Thank you.
[cpg cn=true]

[SE f="se008"]
;//【ＳＥ】『ドア閉まる』


Ariel was worried about me, but I let her go.
[cpg]


[free time=1000]


[SE f="se007"]
;//【ＳＥ】『ドア開く』


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
;//[t_move pos=C 下礼]
[VOICE f="Littule007"]
[OnName num="littule"]
I let her go. "Hey, hey, what kind of a tree are you?
[cpg cn=true]


[OnName num="itsuki"]
...... human?"
[cpg cn=true]


Ritul is curious. I'm a brave man, but he treats me like this.
[cpg]


[SE f="se008"]
;//【ＳＥ】『ドア閉まる』

After a few words, Ritul left.
[cpg]

[STOPBGM]

[free time=1000]

[SE f="se007"]
;//【ＳＥ】『ドア開く』

[BGM f="bg_ni"]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Elmyr006"]
[OnName num="elmyr"]
I'm in love with you at first sight. I think I fell in love with you at first sight.
[cpg cn=true]


She came to me at the end and said something like that. I'm not surprised by anything she says to me anymore.
[cpg]


[OnName num="itsuki"]
Don't ...... joke around and say things like that so carelessly."
[cpg cn=true]


I'm talking to someone else instead. I'm getting more and more tired even if I don't.
[cpg]


The first thing you need to do is to make sure that you have a good understanding of what you're doing and how to do it.
[cpg]


[OnName num="itsuki"]
'Hey,...... is Hermia a dark elf or something?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr007"]
[OnName num="elmyr"]
I'm sure you know exactly what I'm talking about. I'm sure you're right, but are there dark elves in your world too?
[cpg cn=true]


No, it's just a concept. But ......
[cpg]


[OnName num="itsuki"]
"So you're saying that because they're dark elves, they're attracted to a certain race or ...... something like that?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Elmyr008"]
[OnName num="elmyr"]
'Giggle, what is that?　No, that's not true, I'm genuinely interested in you."
[cpg cn=true]


Saying that, Hermia was really coming on to me.
[cpg]

[OnName num="itsuki"]
I said, "No, don't do that. ......!"
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植のためシーンをカットしています

Hermia looked a little disappointed, but she gave up.
[cpg]


[SE f="se000"]
;//【ＳＥ】『ドア閉まる』

And I just watched in silence as Hermia walked away.
[cpg]

I couldn't sleep that night. ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************

;//上下に黒帯を入れてください
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]

[SE f="se009"]
;//【ＳＥ】『ドアをノックする』


The next morning. Or rather, time passed a bit, noon.
[cpg]


[OnName num="itsuki"]
'...... who are you?'
[cpg cn=true]


;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel022"]
[OnName num="ariel"]
'Um, it's me. I'm Ariel."
[cpg cn=true]


[OnName num="itsuki"]
Oh, come in."
[cpg cn=true]


I was a little tired of thinking. I wondered if time was moving forward in the real world even as I was doing this.
[cpg]


I was horrified to think that I had been reported missing.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel023"]
[OnName num="ariel"]
I have a first assignment for you, if you don't mind.
[cpg cn=true]


I nodded. If I don't do something, I'm going to be in trouble if I'm not on the road back to reality, even if it's just a little.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel024"]
[OnName num="ariel"]
'This forest is called the Great Forest of Asekto,......, and within it is a settlement called Levulle.
[cpg cn=true]


They had to summon me here for the convenience of summoning magic. That's fine. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel025"]
[OnName num="ariel"]
The Great Forest of Asekto is divided into two settlements, Ruaim and Levulu.
[cpg cn=true]


The reason for the division into two is said to be due to the appearance of an evil god in this world.
[cpg]


The two were originally human names, and they were brother and sister elves who were very close to each other.
[cpg]


They were separated during the march of the demon tribe, but they managed to reunite with other elves and rebuild their village.
[cpg]


The two had dreamed of meeting again someday,......, but both lost their lives in the battle.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel026"]
[OnName num="ariel"]
So it is the longing of us elves to restore the division of this great forest.
[cpg cn=true]


[OnName num="itsuki"]
You mean the ...... demons are nesting and dividing it?"
[cpg cn=true]


Ariel nodded. It's quite an epic story.
[cpg]


Truly a story of life and death. I wasn't sure if I should nod so easily, but ......
[cpg]


But if I faltered here, it would be impossible for me to return to reality.
[cpg]


[OnName num="itsuki"]
I understand. I don't know if I can do it.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

Seeing Ariel's happy face, I was glad I had complied.
[cpg]



[SE f="se008"]
;//【ＳＥ】『ドア閉まる』


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夕方）******************************************************

;//上下に黒帯を入れてください


And then the afternoon turned into evening.
[cpg]


I know it's a little sad to eat dinner in a cabin by myself, but I also know that it's not the air of ...... while chatting and laughing with everyone else.
[cpg]


I'm not interested in that, what I have to do is to restore the Great Forest of Asekto, the division of the forest.
[cpg]


They say that we are going to fight demons. What do demons look like? ......
[cpg]


I've seen them in RPGs and such, but when I see them in front of me, I'll probably stand still.
[cpg]


For the most part, I can't even imagine what kind of power a brave man might have.
[cpg]


With that thought in my mind, night falls.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************

;//上下の黒帯を外してください
;//[FG f="ci_lbox.ui" method="feadout" layer=20 pos="4/7"]


As night falls, I feel the need to work up a sweat.
[cpg]


There are baths in this world, right? There must be a problem of hygiene at any cultural level.
[cpg]


So I called out to Ritul.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Littule008"]
[OnName num="littule"]
What's the matter?　You need something?
[cpg cn=true]


[OnName num="itsuki"]
Oh, no, I was just wondering if you have ...... baths.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Littule009"]
[OnName num="littule"]
Oh. I was wondering if there was a bath at . "Yeah, didn't you take one yesterday?　If you want a bath, it's over there.
[cpg cn=true]


He said so and led me to the place he pointed to.
[cpg]


;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************


The place he led me to was a men's bath. Ritul and I parted on the way.
[cpg]


There was steam coming out of the waterfall that normally flows. This is strange. ......
[cpg]


Hot springs don't usually gush out in places like this, do they?
[cpg]


Does it flow in a forest like this?
[cpg]


When I touch my fingers a little, the right temperature is also the right temperature. This is not normal either.
[cpg]


In the world where I used to live, the temperature of hot springs is somehow regulated.
[cpg]


Then, I thought that it might be something that is done by magic in this world.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）
;//上下に黒帯を入れてください


And after taking a bath, new clothes were prepared for me by the time I returned to the hut.
[cpg]


I was grateful, but also thought that it was a bit too polite, so I changed.
[cpg]


;//[FG f="ci_lbox.ui" method="feadout" layer=20 pos="4/7"]

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（朝）******************************************************


The next morning. I immediately go to defeat the demons that are nestled in the forest that divides the great forest of Acecto.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel027"]
[OnName num="ariel"]
I'll give you a set of weapons and a set of armor .......
[cpg cn=true]


The armor was lightweight. But I still don't know how to put it on.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte007"]
[OnName num="charlotte"]
I don't know how to put it on?　I wonder if you really are a brave man. ......
[cpg cn=true]


Charlotte said so as if she was taken aback. The most important thing to remember is that you can't just take a look at the website and see what's going on.
[cpg]


[OnName num="itsuki"]
Wow, bad ......."
[cpg cn=true]


The first thing you need to do is to get a good idea of what you want to do. The most important thing to remember is that you should never be afraid to ask for help.
[cpg]


[free time=1000]


And the sword is heavy. It looks like you can't even swing it properly. ......
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Elmyr009"]
[OnName num="elmyr"]
'Shall we go then, and strike down the nemesis of the elves?'
[cpg cn=true]


Elmire says so, but I was filled with anxiety about whether I could do it.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel028"]
[OnName num="ariel"]
'Wait a minute. Tree-sama ......."
[cpg cn=true]


Ariel stalls me, and I turn around in a way that makes it hard for me to move.
[cpg]


[OnName num="itsuki"]
What's wrong?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel029"]
[OnName num="ariel"]
'Just a moment please, I'm using ...... "Analyze".'
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
I didn't understand what she was saying, but Ariel closed her eyes and reminded me.
[cpg]


Then, in front of my eyes, a light gathers. It gathers and wriggles into elongated ...... letters.
[cpg]


The letters are really letters. They look Japanese to my eyes, but I wonder if this is just another language from another world that looks Japanese.
[cpg]


[OnName num="itsuki"]
What is this ......?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel030"]
[OnName num="ariel"]
I used 《Analysis》. I'm seeing the skills you have and the skills you can acquire. ......
[cpg cn=true]

[free time=800]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Littule010"]
[OnName num="littule"]
Is this true?　I've never seen someone who can acquire so many skills.
[cpg cn=true]


[OnName num="itsuki"]
Isn't this normal?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Littule011"]
[OnName num="littule"]
I've never seen a person who can acquire so many skills. ...... skills are acquired by training and training.
[cpg cn=true]


I saw a huge number of letters lined up in front of me.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Elmyr010"]
[OnName num="elmyr"]
And ......, there's some kind of strange skill attached to it right from the start. I can't read it, but I think it's an ancient script. ......
[cpg cn=true]


[OnName num="itsuki"]
Is that so?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Ariel031"]
[OnName num="ariel"]
"If it's a skill I can't read, what is it? ...... I don't think it's a bad skill."
[cpg cn=true]


[OnName num="itsuki"]
Anyway, what do I need to do to be able to call this up too?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Littule012"]
[OnName num="littule"]
The most important thing to do is just to wish that you can get "Analysis". You can call it "praying.
[cpg cn=true]


I was told that, and I looked at the letters and wished for it.
[cpg]


I felt it enter my mind. And then the letters change their order.
[cpg]


It seems that the letters that have already been acquired are displayed in large letters, as if they were floating in the air.
[cpg]


I get 《Analysis》 along with the unreadable skill.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Ariel032"]
[OnName num="ariel"]
He continued, "That's the way it is. Even on the battlefield, you will be able to get skills, so please use ...... well."
[cpg cn=true]


[OnName num="itsuki"]
I understand. I'm looking forward to working with you. ......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Ariel033"]
[OnName num="ariel"]
Let's head out then.  Hermia is ...... going too, of course.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Elmyr011"]
[OnName num="elmyr"]
You don't have to tell me. You don't have to tell me. You don't have to drag me down with you.
[cpg cn=true]


The two of them are sparking off each other. The two of them are not getting along well.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_fi"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************

The first thing to do is to get a good look at the newest version of the game.
[cpg]

As they get closer, they get stronger, from small fry to something that is not a small fry, to something that is strong enough to be a handful.
[cpg]

The demons that were nesting there looked like slime.
[cpg]

I don't even know if a sword would go through it, but I can't help it since I don't have access to magic.
[cpg]

And as expected, I can't wield a sword.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Elmyr012"]
[OnName num="elmyr"]
'Damn ...... there's so many of them.
[cpg cn=true]

[free time=800]

[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/2" time=800]

[VOICE f="Ariel034"]
[OnName num="ariel"]
'Stop whining, Hermia!　It is the long-cherished wish of us elves to reclaim this place."
[cpg cn=true]


Ariel and Hermia still don't seem to be getting along ...... well.
[cpg]


I'm really useless at this point.
[cpg]


[free time=1000]

The five of them, plus the elves, have been adding reinforcements, but even so, they are being pushed around.
[cpg]


I can't swing my sword even if I had it in my hand. This situation reminds me of something.
[cpg]


I remember the words in my head, I remember ...... that if I paid the price, I could become a master of the sword and a master of magic.
[cpg]


A price. I want to be able to control a sword or magic, even if there is a price to pay.
[cpg]


The power I wanted was ......
[cpg]


;//■選択肢
[switch]
[case "Sword"]
	[swap]
[jump target="*select01_1"]
[case "magic"]
	[swap]
[jump target="*select01_2"]
[endswitch]


1. sword
2. magic

;//ここにあった選択肢３はどのルートにも繋がっていませんので、削除しました
;//欠番となっており、選択肢４が次の選択肢になっています

;//==============================
;//１、剣
*select01_1|The brave man who saves the world.

[stflag Sel1flg = 1]

[system sysSel1flg=false]


Use 《Analysis》 on yourself. Skills appear in front of me.
[cpg]


I wished to make 《Swordsmanship》 my own.
[cpg]

[SE f="se006"]
;//【ＳＥ】『剣を振りかざす』

And I swing my sword. My body suddenly felt light.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Ariel035"]
[OnName num="ariel"]
"What?　Itsuki, that's ......."
[cpg cn=true]


;//エフェクトから元背景に
[window target=false]
[transition target={true} rule="kosuri5.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kosuri5.webp" color={0x000000ff} time=1]
[WAIT time=1]


[SE f="se003"]
;//【ＳＥ】『剣で敵を倒す』


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="e_02_1.ui" time=1]
[WAIT time=1]
[transition target={false} rule="sita.webp" color={0x000000ff} time=300]
[WAIT time=300]


[transition target={true} rule="sita.webp" color={0x000000ff} time=300]
[WAIT time=300]
[BG f="black.ui" time=1]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=300]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="e_03_1.ui" time=1]
[WAIT time=1]
[transition target={false} rule="sita.webp" color={0x000000ff} time=300]
[WAIT time=300]


[transition target={true} rule="sita.webp" color={0x000000ff} time=300]
[WAIT time=300]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


I swung the sword that I couldn't swing before, and the place where it didn't hit ripped open.
[cpg]


It cuts monsters along with the ground.
[cpg]


I feel a surge of power. I can't imagine what the cost of this would be.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Elmyr013"]
[OnName num="elmyr"]
It's amazing, Tree!　Keep on going and take it down!"
[cpg cn=true]


[OnName num="itsuki"]
Oh, you don't have to tell me. ......!
[cpg cn=true]


Saying that, I swung my sword around wildly.
[cpg]


Strangely enough, it doesn't hit the people I consider to be my allies. And my enemies were cut down at every turn.
[cpg]


[jump target="*select01_3"]
;//==============================
;//２、魔法
*select01_2|The brave man who saves the world.

[stflag Sel1flg = 2]

[system sysSel1flg=true]


I use 《Analysis》 on myself. Skills appear in front of me.
[cpg]


In the midst of it, I wished to make 《Witchcraft》 my own.
[cpg]


I gave up swinging my sword. Instead, I held up my hand.
[cpg]

;//[CutBG g="e_04_2"]

I wondered if I needed a spell to use magic. No, I somehow knew that I didn't need one.
[cpg]


[SE f="se004"]
;//【ＳＥ】『炎燃えさかる』


[window target=false]
[transition target={true} rule="fire1.webp" color={0x0000ffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="blue.ui" time=1]
[WAIT time=200]
[transition target={false} rule="fire1.webp" color={0x0000ffff} time=1]
[WAIT time=1]
[transition target={true} rule="fire1.webp" color={0x0000ffff} time=1]
[WAIT time=1]
[BG f="e_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="fire1.webp" color={0x0000ffff} time=1000]
[WAIT time=3000]

[transition target={true} rule="kosuri4.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="kosuri4.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


;//[CutBG g="e_04_2"]

Without knowing, a blue-white flame gushed out.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Ariel036"]
[OnName num="ariel"]
"Soooo, awesome ......."
[cpg cn=true]


It really looks like the game will be won in an instant. I visualize the flames once more.
[cpg]

;//==============================

*select01_3|The brave man who saves the world.

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夕方）******************************************************


Everything was over. Almost all the demons that were dividing the Great Forest of Acecto have been defeated by me ......?
[cpg]


I don't feel it either. It seems that I have defeated the demons which could not be defeated by dozens and dozens of people in a bunch.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel037"]
[OnName num="ariel"]
I'm going to take a break. I'm sure everyone is exhausted. ......
[cpg cn=true]


[OnName num="itsuki"]
Is that okay?　Do we have that kind of time?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel038"]
[OnName num="ariel"]
I'm fine. You should take a rest, too, Tree-sama.
[cpg cn=true]


So, we rested in the great forest of Asekto, each of us in our own place.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se023]
;//【ＳＥ】『歩く（外）』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

I was not so exhausted. So, when I was strolling ......
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Elmyr014"]
[OnName num="elmyr"]
"Oh, my. You came again. I won't let you go."
[cpg cn=true]


I could see the look in Ermia's eyes as she looked at me, and she seemed to have an unusual emotion in them.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Elmyr015"]
[OnName num="elmyr"]
I love the smell of a man who has finished a battle.
[cpg cn=true]


While I was saying this, I felt someone's presence. Oh, shit, I thought.
[cpg]


;//移植のためシーンをカットしています


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/3" time=800]
[VOICE f="Ariel039"]
[OnName num="ariel"]
'......?　What are you doing in a place like this?"
[cpg cn=true]


[OnName num="itsuki"]
He said, "Uh, no. Nothing."
[cpg cn=true]

;//＠
I was glad I was dressed. It was a close call.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[VOICE f="Ariel040"]
[OnName num="ariel"]
"Shall we go back then? Itsuki"
[cpg cn=true]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************


When I returned after the fight, I heard the panicked voices of Ritul and the maid.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

;//[t_move pos=L 下礼]
[VOICE f="Littule013"]
[OnName num="littule"]
No, no, no, no!　I'm waiting for you to come back.
[cpg cn=true]


[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Charlotte008"]
[OnName num="charlotte"]
'You're so picky every time. Do you want to be a scorched dwarf?"
[cpg cn=true]


Ritul, and some of the maids stopped Charlotte.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Ariel041"]
[OnName num="ariel"]
What's going on, Charlotte ......?
[cpg cn=true]


[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
;//[t_move pos=R ゆらゆら]
[VOICE f="Charlotte009"]
[OnName num="charlotte"]
Nothing. I was just trying to get back to my hometown, but everyone was stopping me.
[cpg cn=true]


That's how it is. ...... Charlotte has a hometown too, and that place might have been affected by the evil god.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
;//;//[t_move pos=R 羽ばたき]
[VOICE f="Charlotte010"]
[OnName num="charlotte"]
"I came here with the promise to summon a hero, so I've done what I came here to do, haven't I?　I'm going home."
[cpg cn=true]


The reason the disparate tribes had gathered in one place was because Ariel had gathered them under the guise of summoning heroes.
[cpg]

[free time=1000]


In fact, Mercurio was already gone. He seems to have returned to his hometown.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Littule014"]
[OnName num="littule"]
I'm really worried about my hometown too,......, but all of this is for the sake of defeating the evil gods.
[cpg cn=true]


The most important thing to remember is that the best way to get the most out of your time in the world is to be a good friend to Ariel and stay there. The most important thing to remember is that you can't just go to the store and ask for a discount.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Ariel042"]
[OnName num="ariel"]
I'm sure he'll be fine, Ritul. Thank you. You should go back home."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Littule015"]
[OnName num="littule"]
"What, ......?　So, but..."
[cpg cn=true]


[OnName num="itsuki"]
Yes.　We're going to defeat the evil ...... god."
[cpg cn=true]

;//[t_move pos=R ゆらゆら]
Ariel just shook her head.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（朝）******************************************************


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
By the time morning came, everyone was in pieces.
[cpg]


;//[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
;//[t_move pos=C 溜息]
[VOICE f="Ariel043"]
[OnName num="ariel"]
'Hah ...... I'm in trouble. We need the power of these girls as priestesses to defeat the evil gods."
[cpg cn=true]


I guess they each have their own problems with their species, individuals, etc.
[cpg]


It's a difficult road ahead, but that doesn't mean we can't save this world, I suppose.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

A few days after the first battle. Things were stagnant.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_m1"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（昼）******************************************************


Until a few days ago, the place was lively, but few of the members who had gathered at the time of the summons remained.
[cpg]


[OnName num="itsuki"]
What do we do now?　Should we just go out and defeat the evil gods?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
;//[t_move pos=C 下礼]
[VOICE f="Ariel044"]
[OnName num="ariel"]
No way!　Are you kidding me?
[cpg cn=true]


[OnName num="itsuki"]
Because it seems you can get an inexhaustible supply of skills, and you don't even need to ...... train them.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ariel045"]
[OnName num="ariel"]
It should be difficult ...... to defeat the evil god right away."
[cpg cn=true]


But whatever that is.
[cpg]


And then Ariel said, "If you're gone, it's going to be very difficult to defeat the evil god.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel046"]
[OnName num="ariel"]
If you are gone, then there is no hope. Please take care of yourself. ......"
[cpg cn=true]


I couldn't say anything back to her.
[cpg]


But that did not mean I could do nothing.
[cpg]


If I did nothing, things would not progress.
[cpg]


I thought I might be able to find some clues, so I started by saying something like this: "I'm not a member of .
[cpg]


[OnName num="itsuki"]
Why did Ritul and Mercurio return to their hometowns?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel047"]
[OnName num="ariel"]
Each of them has a lot going on in their hometowns due to the influence of the evil gods.
[cpg cn=true]


[OnName num="itsuki"]
'Is that so,...... specifically?'
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ariel048"]
[OnName num="ariel"]
Ritul said that the underground city is under attack by demons and that they are in trouble,.......
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ariel049"]
[OnName num="ariel"]
And Mercurio is also having trouble with poaching against the mermaid tribe.
[cpg cn=true]


I see. The actuality is that the actuality is that the actuality is not really a good idea.
[cpg]


I wonder if there is something to Charlotte or Hermia. I'm not sure about that. ......
[cpg]


Maybe there is something they want to solve.
[cpg]


[OnName num="itsuki"]
What about Ariel?　Is nothing troubling you?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ariel050"]
[OnName num="ariel"]
'Well,...... if I could, I'd like to see this forest completely restored, but that would be an absurd thing to do.'
[cpg cn=true]


I wish I could completely restore this forest, but it's too much to hope for. Ariel has hopes after all.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『アセクトの大森林』（夜）******************************************************

;//上下に黒帯を入れてください


It is not possible to defeat them suddenly. I somehow understood that.
[cpg]


Even if you have an inexhaustible supply of skills, you don't know if you'll be able to use them.
[cpg]


I would have to experience it firsthand and get a feel for it.
[cpg]


I thought about that as I slept in my hut.
[cpg]


[jump storage="ep001.ks" target="*start"]



;============================================================================
