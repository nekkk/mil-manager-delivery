

*start

;#################################################
*Ep002|Overthrowing Martina
;#################################################


[SCENE id=2]

;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夕方）******************************************************





[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Lily093"]
[OnName num="lily"]
How did you like it, Daigo-dono ......?
[cpg cn=true]


[OnName num="daigo"]
If Daisy, the elf, isn't lying, we have the upper hand.
[cpg cn=true]


Lily was relieved. She seemed seriously concerned, even though she and Charlotte would be strangers.
[cpg]


I explained about the stone in a nutshell. I explained about the stones in general, but I just said what I was told.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe080"]
[OnName num="chloe"]
The question is how to use it.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Lily094"]
[OnName num="lily"]
"I suppose so. ......If possible, it would be better to put them to sleep from the inside. ......
[cpg cn=true]


[OnName num="daigo"]
That's not a problem," he said. The other side wants to trade me for Charlotte.
[cpg cn=true]


[OnName num="daigo"]
"I dare them to catch me. As long as I'm in their pocket, that's all that matters."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Lily095"]
[OnName num="lily"]
No way!　If they restrain you or find the stone, you're done!
[cpg cn=true]


They don't trust you. I'm going to make it work.
[cpg]


[OnName num="daigo"]
Don't worry. I won't fail by any chance."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily096"]
[OnName num="lily"]
There's no basis for that!　If you are caught by the bandits, this country will be ......!
[cpg cn=true]


[OnName num="daigo"]
But we can't abandon Charlotte either. We have no choice but to go.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe081"]
[OnName num="chloe"]
We must trust Daigo-sama here. Your Majesty."
[cpg cn=true]


Lily looked disapproving. But, but ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************





I pretended to give in to their demands once I was in the pocket of the bandits.
[cpg]


I come to the place where I was called. Of course, I have the stone in my pocket.
[cpg]


I also brought the knights with me so that the bandits wouldn't know I was there.
[cpg]


[OnName num="bandit"]
"There you are. This way!
[cpg cn=true]


A few of the bandits come and try to take me away.
[cpg]


That's what I want. I'll catch the whole bandit group from here.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『洞窟』（昼）******************************************************




[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA05_p2_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Martina003"]
[OnName num="martina"]
You're surprisingly obedient," he said. I didn't think you'd come.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Charlotte019"]
[OnName num="charlotte"]
"Brother ......!　Why did you come?
[cpg cn=true]


We meet up with Martina and Charlotte.
[cpg]


[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Martina004"]
[OnName num="martina"]
But I'm sorry, I can't let Charlotte go.
[cpg cn=true]


[OnName num="daigo"]
Why, ...... you meant in exchange for me."
[cpg cn=true]


Martina smiles and says, "I like her.
[cpg]


[FG f="CHA05_p2_01_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="Martina005"]
[OnName num="martina"]
I like her. I like this girl, and I'm not giving her up now.
[cpg cn=true]


[OnName num="daigo"]
She looks at him regretfully.
[cpg cn=true]


I tried to look disappointed. Fortunately, my body was not restrained.
[cpg]


There were quite a few bandits. The actual "I'm not a fan of the way you do things," he said.
[cpg]


[OnName num="daigo"]
I'm sure they think it's impossible for me to escape unarmed.
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Martina006"]
[OnName num="martina"]
I'm not. I'm a sucker for a pretty girl.
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
I'm not going to run away from you.
[cpg]




;//[FG f="CHA03_p2_01_a.ui" method="change_5"  pos="1/2" time=800]
[FACE method="change_5" pos="1/2"]
;//[t_move pos=L 動揺]

[VOICE f="Charlotte020"]
[OnName num="charlotte"]
I'm not going to ...... touch you.　Don't touch me!
[cpg cn=true]



;//移植のためシーンをカットしています

Martina seemed more interested in Charlotte than in me.
[cpg]

And if I tried to resist, there were two bandits by my side to restrain me at any time.
[cpg]

But I wasn't going to resist either.
[cpg]



;//[FG f="CHA05_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[FACE method="change_7" pos="2/3"]
[VOICE f="Martina007"]
[OnName num="martina"]
But you really don't put up any resistance, do you?
[cpg cn=true]


[OnName num="daigo"]
"Yes," I said, "but you really don't put up any resistance. So, please let Charlotte go.
[cpg cn=true]


;//[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[FACE method="change_1" pos="2/3"]
[VOICE f="Martina008"]
[OnName num="martina"]
I'm sorry, but I don't think I can do that. ......
[cpg cn=true]


;//移植のためシーンをカットしています



;//[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[FACE method="change_2" pos="2/3"]
[VOICE f="Martina009"]
[OnName num="martina"]
As long as you're locked up in here, we won't have any problems eating.
[cpg cn=true]



;//[free time=1000]

I took the stone out of my pocket and tossed it under my feet.
[cpg]


;//[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[FACE method="change_7" pos="2/3"]
[VOICE f="Charlotte021"]
[OnName num="charlotte"]
"Is that ......?"
[cpg cn=true]


And I stomped on it with my foot. Then ......
[cpg]



;//フラッシュ

;//[free time=1000]
;//[BG f="white.ui" time=1000]
;//[WAIT time=1000]

[STOPBGM]
[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=1]
[WAIT time=1]
[window target=true]


A dazzling light emitted from the stone. From that moment on,......
[cpg]



;//[FG f="CHA05_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
;//[t_move pos=C 動揺]
[VOICE f="Martina010"]
[OnName num="martina"]
"Nn...... ugh, phew, this is ......!"
[cpg cn=true]


;//[free time=1000]
[window target=false]
[transition target={true} rule="sita.webp" color={0xffffffff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『洞窟』（夕方）******************************************************


The magic of the elves was terribly effective, and the bandits were all asleep.
[cpg]


Of course, if a woman used this, they would all be asleep, so no one but me would be able to exploit it.
[cpg]


I should wake Charlotte up first.
[cpg]


[OnName num="daigo"]
Charlotte. Wake up."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte022"]
[OnName num="charlotte"]
"Nnnn...... umm... ...... I...
[cpg cn=true]


[OnName num="daigo"]
The Elves gave me this stone, and all the bandits are asleep.
[cpg cn=true]


[OnName num="daigo"]
The knights must be near their hideout. Anyway, we need to get out of here."
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte023"]
[OnName num="charlotte"]
Thank you, brother.
[cpg cn=true]


[OnName num="daigo"]
I'll thank you later. Now get out of here."
[cpg cn=true]



[free time=1000]


Charlotte hesitated for a moment and then walked away.
[cpg]


[OnName num="daigo"]
"Well, and ......."
[cpg cn=true]


When Charlotte comes to the entrance of the hideout, the knights will probably attack.
[cpg]


;//＠
;//その前に、マルティナを抱いておきたい。
Before that happens, I need to ask Martina something.
[cpg]


That's why I had Martina tied up behind her back.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ非エロ（腕を後ろ手に縛られている。服装を乱して眠っていて、途中主人公に起こされる）ev_17
;//人物１：ヒロイン５
;//服装１：着衣（はだけ）
;//場所　：盗賊のアジト
;//時間　：夕方
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=100]



I want to see how such a rebellious guy will react when he is alone and in a weaker position.
[cpg]


[OnName num="daigo"]
"Wake up, Martina. Martina.
[cpg cn=true]



[VOICE f="Martina011"]
[OnName num="martina"]
"Oh ......, you're ......."
[cpg cn=true]


[OnName num="daigo"]
Good morning. You looked so pretty in your sleep.
[cpg cn=true]



[VOICE f="Martina012"]
[OnName num="martina"]
"Ugh, my hand is ......!　I can't untie my hand.
[cpg cn=true]


[OnName num="daigo"]
What am I going to do now?　What do you want me to do?
[cpg cn=true]


When he pronounced this to Martina, she turned blue.
[cpg]



[VOICE f="Martina013"]
[OnName num="martina"]
No, no, no!　Stay away from me, please!
[cpg cn=true]


I knew that would be the reaction. She also showed interest in Charlotte, who is of the same gender.
[cpg]

She seemed to be extremely averse to men as a reaction to that.
[cpg]


Me, I have some doubts, and I'm not sure if I'm going to hit it or not.
[cpg]



;//■選択肢
[switch]
[case "I ask him why he does bad things."]
	[swap]
	[jump target="*select03_1"]
[case "He doesn't say anything."]
	[swap]
	[jump target="*select03_2"]
[endswitch]


15. I ask him why he does bad things.
16. I say nothing.



;//==============================
;//15、どうして悪事を働くのか聞き出す
*select03_1|Overthrowing Martina




[OnName num="daigo"]
Why do you do bad things?
[cpg cn=true]



[VOICE f="Martina014"]
[OnName num="martina"]
"Why do you do ...... anything? Instead of that, untie me from this ......!"
[cpg cn=true]


What's the matter with you? I'm trying to be nice to you, but you won't even give me a straight answer.
[cpg]


[OnName num="daigo"]
I can't do that. You can't do that.
[cpg cn=true]



[VOICE f="Martina015"]
[OnName num="martina"]
"Oh no, somebody wake up, why are you all asleep?
[cpg cn=true]




;//変数　善+1
[stflag goodflg = 1]

[system selflg_02=false]


[jump target="*select03_3"]
;//==============================
;//16、何も言わない
*select03_2|Beat Martina!


[OnName num="daigo"]
......
[cpg cn=true]


Well, if you have a question, how do you know they'll answer it?
[cpg]


[VOICE f="Martina016"]
[OnName num="martina"]
"Oh, no!　Don't come any closer, don't touch me.
[cpg cn=true]



;//変数　悪+1
[stflag evilflg = 1]

[system selflg_02=true]

;//==============================
*select03_3|Martina vanquished

;//移植のためシーンをカットしています

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『洞窟』（夕方）******************************************************

Meanwhile, the knights entered the cave. There is no way back from here.
[cpg]


;//移植のためシーンをカットしています

There is no need to take Martina's life, or rather, let her reflect on what she has done.
[cpg]





;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夜）******************************************************





And by the time I return to the castle town, it's already night.
[cpg]


Charlotte was waiting for me there.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte024"]
[OnName num="charlotte"]
Thank you, big brother,......, I was so scared.
[cpg cn=true]


[OnName num="daigo"]
Did this Martina guy do something to you?"
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_6"  pos="2/3" time=800]
Charlotte said nothing and blushed.
[cpg]

In cases like this, I don't need much, even unnecessary encouragement. ......
[cpg]

[OnName num="daigo"]
I'm glad you persevered," she said. Great job."
[cpg cn=true]


I patted Charlotte on the head and walked back to the castle.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************



I had done my part, and I was a little tired. I had more work to do tomorrow.
[cpg]


Tired, I went straight to sleep: ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





And in the morning. I wake up and think about what I'm going to do.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chloe082"]
[OnName num="chloe"]
Good morning, Mr. Daigo. Daigo-sama.
[cpg cn=true]


[OnName num="daigo"]
"Oh, good morning. ......
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe083"]
[OnName num="chloe"]
I heard you had a good day the other day.
[cpg cn=true]


[OnName num="daigo"]
"Well. But what's really great is Daisy."
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe084"]
[OnName num="chloe"]
Don't be modest. You are a higher being than us just because you are a man.
[cpg cn=true]


I don't know if I'd go so far as to call you a superior being. Chloe has also come to hold me in high esteem.
[cpg]


But I guess it's all because of the battle.
[cpg]


Lily. Chloe. Martina, Daisy. ...... There's no woman I can't have my way with.
[cpg]

The only exception would be ...... Charlotte.
[cpg]


[OnName num="daigo"]
I guess so,......."
[cpg cn=true]


I muttered to myself and decided to head over to Charlotte's place.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（朝）******************************************************



And in front of Charlotte's house.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte025"]
[OnName num="charlotte"]
"There you are, big brother!　Come on in!
[cpg cn=true]


Charlotte welcomed me and I went up to her room.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（昼）******************************************************





[FG f="CHA03_p2_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Charlotte026"]
[OnName num="charlotte"]
Thank you," Charlotte said. For helping me with that ...... the other day.
[cpg cn=true]


[OnName num="daigo"]
I didn't need to thank you. It was something I needed to do.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte027"]
[OnName num="charlotte"]
You mean getting ...... Ms. Martina?
[cpg cn=true]


[OnName num="daigo"]
Oh. Are you jealous?"
[cpg cn=true]


Charlotte blushed and shook her head.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte028"]
[OnName num="charlotte"]
She shakes her head. I can't have children, so I don't have a choice.
[cpg cn=true]


I didn't mean to talk about that. But I guess it is her complex.
[cpg]


[OnName num="daigo"]
I don't know, Charlotte. Don't be so down on yourself.
[cpg cn=true]


[OnName num="daigo"]
You should be aware that you are attractive. Well, you're beautiful even if you don't realize it.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte029"]
[OnName num="charlotte"]
Then it doesn't matter what I say. ......
[cpg cn=true]


Charlotte laughed a little. I'd love to see a face like that.
[cpg]


;//移植のためシーンをカットしています

[OnName num="daigo"]
"I'll be back then."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Charlotte030"]
[OnName num="charlotte"]
I'll be back. I'll be back anytime.
[cpg cn=true]



Charlotte says something cute.
[cpg]


I turn my back on her and leave the house.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I had been acting as much as I wanted in this world.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





[OnName num="daigo"]
......"
[cpg cn=true]


A little bit of a concern is whether or not I can go back to the world I was in.
[cpg]


Lily said I could. I just ......
[cpg]


I was concerned that he looked a little gloomy at the time.
[cpg]


She looked as if she felt some kind of guilt toward me.
[cpg]


I can't help but think about it. Let's go to bed today,......, I thought, and lay down in bed.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





And the next morning. I always see his face first thing.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe085"]
[OnName num="chloe"]
Good morning, Daigo-sama. How are you doing today?"
[cpg cn=true]


What I do today is much the same as yesterday.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





I'm always in demand when I go out on the town. There is no end to the number of women who want me.
[cpg]


However, I still have some concerns.
[cpg]


I really wanted to find out, so I decided to pay Lily a visit.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夜）******************************************************





[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily097"]
[OnName num="lily"]
"Daigo-dono. Can I help you?
[cpg cn=true]


[OnName num="daigo"]
"Oh, yes. I'd like to ask you something.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily098"]
[OnName num="lily"]
"Whatever you want. If there is anything I can tell you, please tell me.
[cpg cn=true]


Lily's words prompted me to ask the same question again: "Can I really come back to reality?
[cpg]


[OnName num="daigo"]
Can I really come back to reality?"
[cpg cn=true]


Lily still had a dark look on her face.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily099"]
[OnName num="lily"]
She said, "You can go back to ....... Just ......."
[cpg cn=true]


Lily clammed up. It's going to be a big deal for me whether or not I get the details here.
[cpg]



;//■選択肢
[switch]
[case "I'll get the details."]
	[swap]
	[jump target="*select04_1"]
[case "I'm not going to worry about it."]
	[swap]
	[jump target="*select04_2"]
[endswitch]


One, get the details out.
2, I don't care.


;//==============================
;//１、詳しく聞き出す

*select04_1
[jump storage="ep003.ks" target="*select04_1"]


;//==============================
;//２、気にしないでおく
*select04_2|Someone I can say I like.


[OnName num="daigo"]
"...... Well, okay. If it's something you don't feel comfortable saying, you don't have to."
[cpg cn=true]


I didn't question Lily's silence.
[cpg]



Even noble women like Lily and Chloe can do as they please.
[cpg]


I decided to behave as I wanted to behave.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************



In the midst of all this, I thought of someone.
[cpg]

Someone who has always taken care of me. Someone I can say I love: ......
[cpg]



;//■選択肢
[switch]
[case "Lily"]
	[swap]
[jump target="*select06_1"]
[case "Chloe."]
	[swap]
[jump target="*select06_2"]
[endswitch]


6, Lily.
Seven, Chloe.



All options always occur

;//==============================
;//６、リリー


*select06_1
[jump storage="ep007.ks" target="*select06_1"]


;//==============================
;//７、クロエ

*select06_2
[jump storage="ep010.ks" target="*select06_2"]
