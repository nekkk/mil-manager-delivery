
*start


;//俺のアレが神聖過ぎて重宝されるんだが！？　シナリオ
;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//リリー　　　　裸　着衣
;//クロエ　　　　裸　着衣
;//シャーロット　裸　着衣
;//マルティナ　　裸　着衣
;//デイジー　　　裸　着衣
;//上記以外のキャラクターには音声がありません
;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//リリー　　　　一人称「私」　クロエ呼び「クロエ」　シャーロット呼び「シャーロット」
;//　　　　　　　マルティナ呼び「マルティナ」　デイジー呼び「デイジー」　大吾呼び「大吾殿」
;//クロエ　　　　一人称「私」　リリー呼び「陛下」　シャーロット呼び「シャーロット」
;//　　　　　　　マルティナ呼び「マルティナ」　デイジー呼び「デイジー」　大吾呼び「大吾様」
;//シャーロット　一人称「私」　リリー呼び「リリー様」　クロエ呼び「クロエさん」
;//　　　　　　　マルティナ呼び「マルティナさん」　デイジー呼び「デイジーさん」　大吾呼び「お兄ちゃん」
;//マルティナ　　一人称「あたし」　リリー呼び「リリー」　クロエ呼び「クロエ」　シャーロット呼び「シャーロット」
;//　　　　　　　　デイジー呼び「デイジー」　大吾呼び「大吾」
;//デイジー　　　一人称「私」　リリー呼び「リリー様」　クロエ呼び「クロエ」　シャーロット呼び「シャーロットさん」
;//　　　　　　　　マルティナ呼び「マルティナさん」　大吾呼び「大吾様」
;//大吾　　　　　一人称「俺」　リリー呼び「リリー」　クロエ呼び「クロエ」　シャーロット呼び「シャーロット」
;//　　　　　　　　マルティナ呼び「マルティナ」　デイジー呼び「デイジー」　
;//物語終盤、シャーロットが大吾を呼ぶとき、単に大吾と呼ぶことがあります

;//以下、残したＣＧを列挙いたします
;//リリー　　　　ev_01 ev_03 ev_55 ev_60 ev_61
;//クロエ　　　　ev_04 ev_11 ev_64 ev_71
;//シャーロット　ev_07 ev_26 ev_32 ev_33
;//マルティナ　　ev_17 ev_37 ev_38 ev_44
;//デイジー　　　ev_13 ev_24 ev_49




[stflag goodflg = 0]
[stflag evilflg = 0]


;//////////////////////////////////////
;///////////////以下本編///////////////
;//////////////////////////////////////


;#################################################
*Ep000|Why were we called to another world?
;#################################################

[SCENE id=0]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『現実＿街』（夕方）******************************************************



Why is the ratio of men to women in the world exactly 50/50?
[cpg]


With a 50-50 ratio, there would be only men in workplaces suited to men.
[cpg]


There would be no such thing as encounters. There should be more women in the world.
[cpg]


Of course, if the current ratio collapses and there are more women, men will have to marry more women.
[cpg]


Perhaps the position of men will be in jeopardy. However.
[cpg]


If there are two humans, there should be one woman, so why can't I meet one? ......
[cpg]


[OnName num="daigo"]
Huh. ......
[cpg cn=true]


Daigo Igarashi. He is an ordinary businessman who can be found anywhere.
[cpg]


Walking the streets on holidays, it is true that about half of the people seem to be women.
[cpg]


However, if this balance were to be upset, I wonder if I would be happy.
[cpg]


Will I be happy or unhappy? ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『現実＿街』（夜）******************************************************





I don't complain about boredom in my boring days.
[cpg]


I don't need anything special. That's how I live my life.
[cpg]


Even though I didn't need anything, I was still hungry for women.
[cpg]


I thought my sexual desire would decrease with age, but it didn't. The number of times I masturbated increased.
[cpg]


The frequency of masturbation only increased. On a good day, five times a day was not enough.
[cpg]


But I am used to that.
[cpg]


Yesterday, today, and probably tomorrow, my daily life would pass as usual.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『現実＿街』（昼）******************************************************



One day at work, I was on my way to a public restroom.
[cpg]


I was on my way to a public restroom. I was getting close to it recently, but I guess that's just my age.
[cpg]

Feeling somewhat pathetic, I opened the door to the public restroom ......
[cpg]


[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[OnName num="daigo"]
"...... this is ......."
[cpg cn=true]


The view was like nothing I had ever seen before.
[cpg]


It is a place like a temple. And on the ground, there is a magic circle.
[cpg]


[OnName num="daigo"]
......"
[cpg cn=true]


I didn't do anything to come to this place, and I don't think it would happen if I tried.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily001"]
[OnName num="unknown"]
"Oh, ......!　Ladies and gentlemen, we have successfully summoned you!"
[cpg cn=true]


A cheer goes up. But I had no idea what was going on.
[cpg]


Hundreds of women had stopped praying, and were now clasping hands in joy.
[cpg]


Then, a woman ...... who was in the front of the line, looking like a princess, wearing some kind of extravagant dress, steps forward.
[cpg]


[OnName num="daigo"]
"Hey, what are you ......?"
[cpg cn=true]


Then, the princess-like person began to introduce herself.
[cpg]

[free time=1000]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Lily002"]
[OnName num="lily"]
I am Lily, Queen of the Land of Lilum. This is the Prime Minister, Chloe .......
[cpg cn=true]


;//[t_move pos=R 下礼]
[VOICE f="Chloe001"]
[OnName num="chloe"]
It is a pleasure to meet you. I am honored to meet you.
[cpg cn=true]


I've never met anyone before in my life who said they were honored to meet you.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily003"]
[OnName num="lily"]
You must be surprised by the suddenness of our meeting.
[cpg cn=true]


If you ask me whether I am surprised or not, I am surprised.
[cpg]


But there was also a part of me that was somewhat calm. The emergency situation was so great that my mind was taking it as if it were something else.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





I've come to another world. It is not easy to say that.
[cpg]


However, it was hard to imagine that it was such a large-scale prank or a surprise.
[cpg]


Above all, the smell of the air was different. It's different from the air of my parents' house, where I lived, and it's also different from the air of the countryside. ......
[cpg]


It's awfully clear. I imagined that science and technology had probably not progressed that far in this world.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily004"]
[OnName num="lily"]
"Now, please get on the carriage. I will explain as we go.
[cpg cn=true]


[free time=1000]

In my unclear consciousness, I felt a little fear.
[cpg]


The people of this world are friendly toward me. That's good.
[cpg]


I knew that I probably wouldn't be able to leave so easily.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Lily005"]
[OnName num="lily"]
I wonder where I should start. I had imagined a lot of things for this day, but ......"
[cpg cn=true]


She, who calls herself the queen, and the prime minister. They travel in a carriage.
[cpg]


On the way, the women are prostrating themselves. They are in a posture like getting down on their knees, and when they see us.
[cpg]


[OnName num="woman_A"]
'Oh, ...... that's them!
[cpg cn=true]


[OnName num="woman_B"]
It's His Highness the Divine Messenger. ......!　We must bow our heads quickly.
[cpg cn=true]


Shinshidekana. Since he would not be a gentleman, if I were to write it in kanji characters, it would be "kamishinshi" and "highness".
[cpg]


It seems strange to be a messenger of God and yet have the rank of a man, "highness," attached to it. ......
[cpg]


I guess it is so in this world. And I don't know who it refers to.
[cpg]


Lily is the queen. Chloe is the Prime Minister. Then, the person in this carriage is ......
[cpg]


[OnName num="daigo"]
"......, His Highness the Divine Envoy, does that mean me?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Lily006"]
[OnName num="lily"]
Yes. You are more like God himself than a messenger of God.
[cpg cn=true]


I think "divine messenger" is the right word. But you also said that you are close to God himself.
[cpg]


Without thinking too much about it, I was swayed by the carriage as I was being swept along.
[cpg]


A woman bows her head deeply. Wherever I go, there are always women.
[cpg]


[OnName num="daigo"]
"......, aren't there too many women?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe002"]
[OnName num="chloe"]
"...... Do you mind if I explain it to them, Your Majesty?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Lily007"]
[OnName num="lily"]
No, I will. It is the queen's duty to explain everything to His Highness the messenger.
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
I don't understand. The person named Lily seemed to be on a mission of some sort.
[cpg]


[OnName num="daigo"]
"Are you saying that everyone is bowing down because ...... you are all so high and mighty?
[cpg cn=true]


I decided to speak politely because I didn't know how I would be treated.
[cpg]


I decided to speak politely because I didn't know how I was going to be treated, and if I was going to be treated badly, I would be, and if I wasn't, I shouldn't be.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Lily008"]
[OnName num="lily"]
No," he said. It's you that everyone is bowing down to.
[cpg cn=true]


[OnName num="daigo"]
'...... is that so?'
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Lily009"]
[OnName num="lily"]
'Let me answer your earlier question with you. There are only women in this world.
[cpg cn=true]


[OnName num="daigo"]
That's absurd, isn't it, ...... and soon it will be destroyed?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe003"]
[OnName num="chloe"]
It is not so. It is true that an unknown plague killed off all the men and destroyed the ......
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily010"]
[OnName num="lily"]
"Hey, Chloe, let me explain. Let me explain.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe004"]
[OnName num="chloe"]
...... pardon me."
[cpg cn=true]


The queen is happy and seems to want to tell me everything.
[cpg]


The vizier, on the other hand, has not lost his crisp expression.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Lily011"]
[OnName num="lily"]
'Even if a male were born, he would die soon.
[cpg cn=true]


[OnName num="daigo"]
......"
[cpg cn=true]


I'm beginning to see what you're talking about. So I'm God himself.
[cpg]


[OnName num="daigo"]
Is that why you summoned me, or rather, summoned ...... me?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe005"]
[OnName num="chloe"]
That's right. I don't know about your world, but men are considered sacred here. ......
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Lily012"]
[OnName num="lily"]
Chloe!
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe006"]
[OnName num="chloe"]
I'm sorry.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





[OnName num="daigo"]
Sorry, .......
[cpg cn=true]


I was made to change my clothes in the blink of an eye.
[cpg]


I was made to change my clothes, and all the people who showed me to my room were women.
[cpg]


It seemed that there were really only women in the room. This situation made me feel uneasy.
[cpg]


If there are only women, men must be of great value for the procreation of offspring.
[cpg]

I wondered if I might be treated like a slave. ......
[cpg]


I thought so, but apparently not.
[cpg]



[SE f="se009"]
;//【ＳＥ】『ノック』





[OnName num="daigo"]
"...... go ahead."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily013"]
[OnName num="lily"]
Excuse me. Have you calmed down a bit?"
[cpg cn=true]


[OnName num="daigo"]
No,......, it's hard to feel at home in such a luxurious room.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily014"]
[OnName num="lily"]
Even if you say so,...... a humble room is not appropriate for such a holy person like you.
[cpg cn=true]


Everywhere I went, I was politely entertained.
[cpg]


Lilum country, I think. The person who claims to be the queen there is treating me so politely.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily015"]
[OnName num="lily"]
May I ask your name?
[cpg cn=true]


[OnName num="daigo"]
"It's ...... Daigo Igarashi .......
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Lily016"]
[OnName num="lily"]
'Igarashi Daigo ...... what a sacred .......'
[cpg cn=true]


Lily becomes enraptured. He might be a bit of a dangerous person.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily017"]
[OnName num="lily"]
Then, His Highness Igara Daigo Shinsaishou ...... is about ready to eat."
[cpg cn=true]


[OnName num="daigo"]
Wait a minute. What did you say?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily018"]
[OnName num="lily"]
What's wrong?　"His Highness, Messenger Daigo Igara."
[cpg cn=true]


[OnName num="daigo"]
It's too long. Can't you make it shorter?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily019"]
[OnName num="lily"]
"That being said, ...... this is an ancient and sacred name for men."
[cpg cn=true]


I think I heard that before.
[cpg]


[OnName num="daigo"]
I'm sure you've heard that before. Let's talk to each other in a language that's a little easier to understand.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Lily020"]
[OnName num="lily"]
"But, ......?"
[cpg cn=true]


[OnName num="daigo"]
"It's hard to call you with such a long name, isn't it?"
[cpg cn=true]


I gave him another push. Lily agreed.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Lily021"]
[OnName num="lily"]
"In ......, I will call you Daigo-dono, .......
[cpg cn=true]


[OnName num="daigo"]
That's fine. I can stop ...... using polite words, too.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily022"]
[OnName num="lily"]
I'm not going to say that. It was itchy to be spoken to by a man in a polite manner.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





The dinner that was laid out in front of me was probably dinner, but it was already amazing.
[cpg]


The meal was much more luxurious than that of Lily, who is supposed to be the queen. Not only was it sumptuous, it was simply huge.
[cpg]


[OnName num="daigo"]
I ate too much ......."
[cpg cn=true]


I returned to my room, which was disproportionately large for me, feeling a little light-headed.
[cpg]


There is even a maid of honor in the room. It's a perfect place.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Lily023"]
[OnName num="lily"]
"Are you all right?　Daigo"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe007"]
[OnName num="chloe"]
I am sorry. Men are supposed to eat more than women. ......
[cpg cn=true]


I'm not wrong, but the tradition is exaggerated.
[cpg]


[OnName num="daigo"]
But how did you manage to develop such a city with so many ...... women?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe008"]
[OnName num="chloe"]
May I explain that to ...... Your Majesty, Daigo-sama?
[cpg cn=true]


Chloe calls me Daigo-sama too. Thank goodness it's properly penetrated.
[cpg]

[free time=1000]

[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Lily024"]
[OnName num="lily"]
No, I do."
[cpg cn=true]


And Lily really wants to explain herself.
[cpg]


She may be a bit flustered by the fact that she is facing a man for the first time.
[cpg]


[free time=1000]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily025"]
[OnName num="lily"]
'This world has evolved in its own way. Women fought off the plague by extending their lifespan and becoming the only ones born as girls.
[cpg cn=true]


[OnName num="daigo"]
Is that possible ......?"
[cpg cn=true]


No, it has happened, so I don't have to doubt it.
[cpg]


You never know how organisms can change over a long period of time.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily026"]
[OnName num="lily"]
'Still, women cannot have children with each other. By summoning men from other worlds, we have escaped the danger of extinction.
[cpg cn=true]


[OnName num="daigo"]
Is summoning such an easy thing to do?
[cpg cn=true]


[free time=1000]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe009"]
[OnName num="chloe"]
No, it is not. Due to the influence of magic, it can only be done once every decade or so.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Lily027"]
[OnName num="lily"]
Chloe!　How many times do I have to tell you that I will explain it to you?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe010"]
[OnName num="chloe"]
I'm sorry, .......
[cpg cn=true]


I can't quite figure out the power relationship between the two of them. I guess Lily is probably in a better position than me.
[cpg]

[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[OnName num="daigo"]
Once in a decade, ...... is the best time to .......
[cpg cn=true]


;//「こほん。十数年に一度の高等魔法ですので、誰もが貴方の子種を求めることでしょう」
[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Lily028"]
[OnName num="lily"]
"Oh, yes. Since this is a once-in-a-decade high magic, there are plenty of people who are looking for you."
[cpg cn=true]


It is easy to imagine. I suppose it is a woman's dream to become a mother in this world as well.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Lily029"]
[OnName num="lily"]
"For at least a year, you will have to procreate with women all over the world.
[cpg cn=true]


[OnName num="daigo"]
One year......"
[cpg cn=true]


But that doesn't necessarily mean you'll have three hundred and sixty-five children .......
[cpg]

Besides, what about procreation is also something I can refuse to do.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Lily030"]
[OnName num="lily"]
'Daigo-dono. Please have mercy on us, ......."
[cpg cn=true]


Lily bowed her head, and Chloe and the attendants bowed their heads as well.
[cpg]


[OnName num="daigo"]
What if I refuse?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe011"]
[OnName num="chloe"]
'I don't want to ......, but we'll have to force our way in.
[cpg cn=true]


So you don't intend to take a hard line at the moment?
[cpg]


Men must be sanctified. Perhaps they think that if they force their way, they will be punished.
[cpg]


[OnName num="daigo"]
I understand most of what you are saying. I'll do my part.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Lily031"]
[OnName num="lily"]
Thank you. ......!
[cpg cn=true]


Lily bowed her head. Chloe also bowed.
[cpg]


There is only one reason why she agreed to such a reckless request.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Probably because the women in this world are so choosy.
[cpg]


I was thinking about Lily.
[cpg]


Lily. Chloe. How would she react if I gave her what she wanted?
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





[OnName num="daigo"]
"Hmmm... ......"
[cpg cn=true]


I wake up to the light of day.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe012"]
[OnName num="chloe"]
Good morning, Daigo-sama. Daigo-sama.
[cpg cn=true]


[OnName num="daigo"]
"......, you're not dreaming, are you?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chloe013"]
[OnName num="chloe"]
Yes, it's not a dream. It's not a dream. It's already morning, let's get dressed.
[cpg cn=true]


[OnName num="daigo"]
Oh, yes.
[cpg cn=true]


Lily was not there. She was probably on official business or something.
[cpg]


[OnName num="daigo"]
I can get dressed by myself.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe014"]
[OnName num="chloe"]
I'm supposed to take care of myself.
[cpg cn=true]


Chloe was a strict person who seemed to be somewhat cold when she was alone.
[cpg]


[OnName num="daigo"]
So ......?　I'm going to be able to choose all the women I want, or something like that.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe015"]
[OnName num="chloe"]
He looks a little stern.
[cpg cn=true]


He looked a little stern. Then Chloe continued.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chloe016"]
[OnName num="chloe"]
'Your Majesty lifts you up unconditionally, but I have no intention of doing so.
[cpg cn=true]


[OnName num="daigo"]
'...... I see.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe017"]
[OnName num="chloe"]
'Yes, I do. Of course, Daigo-sama is not wrong.
[cpg cn=true]


[OnName num="daigo"]
I knew it, didn't I?　Then ......
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe018"]
[OnName num="chloe"]
It is up to you to decide who you want to have children with.
[cpg cn=true]


Chloe still seems like a bit of a demanding person. I'm tempted to do this kind of partner as well.
[cpg]


Is it the effect of the epidemic spreading in this world, or is it the current circumstances that make it so?
[cpg]



[free time=1000]

[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Lily032"]
[OnName num="lily"]
May I come in now?"
[cpg cn=true]


In the midst of all this, Lily comes in. I had just what I wanted to hear from her.
[cpg]


[OnName num="daigo"]
"Lily. Who do you want me to do it with?"
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Lily033"]
[OnName num="lily"]
"Well, ......, basically, you can do whatever you want to do, Daigo-dono.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe019"]
[OnName num="chloe"]
Lily: "Your Majesty. That won't work unless you do us a favor.
[cpg cn=true]


[OnName num="daigo"]
What do you mean, wish? ......
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Chloe020"]
[OnName num="chloe"]
In this country, no, in this world, men are the most precious.
[cpg cn=true]


At this point, it seems that procreation is equivalent to that.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Lily034"]
[OnName num="lily"]
If you conceive and bear a child, you will be given status and honor in this world. Simply put, a commoner can become a nobleman.
[cpg cn=true]


After he said that, I could somehow understand what he was talking about.
[cpg]


[OnName num="daigo"]
You're telling me that everyone is approaching me?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe021"]
[OnName num="chloe"]
"Yes, sir.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily035"]
[OnName num="lily"]
If you fail to bear a child, the nobles will fall and become commoners,......, and even I, the queen, will find my position in jeopardy.
[cpg cn=true]


I think. It's not something that can be taken care of unnecessarily, however,.......
[cpg]


[OnName num="daigo"]
I wouldn't complain if it was a pretty girl or a beautiful person.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Lily036"]
[OnName num="lily"]
Thank you!"
[cpg cn=true]


Two people bowing their heads. I was puzzled because I am not used to being adored and bowed to.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Lily037"]
[OnName num="lily"]
They were not accustomed to being bowed to and I was puzzled.
[cpg cn=true]


[OnName num="daigo"]
For example, ...... that girl who's standing guard in front of my room right now?"
[cpg cn=true]


I guess he is not a person of high status because he is uniformly wearing the same armor like a uniform.
[cpg]


But I glanced at him when he took off his helmet and he looked pretty cute.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Chloe022"]
[OnName num="chloe"]
Yes," he said. I'm sure he will weep with joy.
[cpg cn=true]


My heart raced. I could talk to any woman I saw, depending on my mood that day. Isn't that great?
[cpg]


[OnName num="daigo"]
I'd like to know a little more about this world. Anything I should know, you tell me."
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe023"]
[OnName num="chloe"]
She said, "Well, ...... there are six countries in this world, and all of them are similarly populated with only women."
[cpg cn=true]


In each country, they are calling men from other worlds in the same way.
[cpg]


I guess those men are treated the same way I am.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe024"]
[OnName num="chloe"]
We will be very careful, but please do not go alone.
[cpg cn=true]


[OnName num="daigo"]
Why?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily038"]
[OnName num="lily"]
;//「攫われる危険があります。常に護衛を付けているのもそういう理由です」
There is a danger of being attacked. That is the reason why we always have an escort.
[cpg cn=true]


Thieves may come after you for money, or other countries may kidnap you and try to take you for their own.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Lily039"]
[OnName num="lily"]
If you are caught by bandits, you will be sold somewhere. If they catch you, they will sell you somewhere and make you work like a slave.
[cpg cn=true]


It was hard to believe, but she said it, so it must be true.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily040"]
[OnName num="lily"]
If other countries are involved, there will be war. Anyway, take care of yourself. Daigo-dono is very important.
[cpg cn=true]


He is a near-god, a political tool, and even a gold nugget with legs.
[cpg]


What a crazy place we've come to. ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（朝）******************************************************





Aside from that, I can move freely to some extent. So I was taken outside.
[cpg]


As I walked through the gate and out into the castle town, there were women who were surprised to see me, and some who were too obviously confused.
[cpg]


[OnName num="woman_A"]
"Daigo-sama ......!　It's real, isn't it ......?"
[cpg cn=true]


The name "Daigo-sama" seemed to have taken hold among the common people.
[cpg]


[OnName num="woman_B"]
Please come this way, Daigo-sama.
[cpg cn=true]


The women prostrated themselves on the spot. They look desperate.
[cpg]


It looks like the god treatment will continue for a while. ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夕方）******************************************************





After that, it was completely dark when I looked around the town for a while.
[cpg]


I return to the castle with my escort.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





And inside the castle, apparently Lily's study.
[cpg]


She is talking with Chloe, unaware of my presence.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Lily041"]
[OnName num="lily"]
How was Daigo-dono?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Chloe025"]
[OnName num="chloe"]
He seems to be getting on with it. Daigo-sama must like this world very much.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Lily042"]
[OnName num="lily"]
I'm glad to hear that,......, but please make sure not to stress him out or put him in a bad mood. You will lose your head. Even you.
[cpg cn=true]


I see.
[cpg]


I guess I could use that to my advantage. ......
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe026"]
[OnName num="chloe"]
My head is a small price to pay for the prosperity of the queen and the country.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily043"]
[OnName num="lily"]
I would be in trouble if you were to leave. If you leave, I will not be able to drink good coffee.
[cpg cn=true]


Eavesdropping on such conversation, I went back to my room.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（朝）******************************************************

The next morning.
[cpg]

[OnName num="daigo"]
Where are you headed today?"
[cpg cn=true]


A few days later. I was to begin my work as a savior.
[cpg]

[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe027"]
[OnName num="chloe"]
"Please take a look at this," he said.
[cpg cn=true]


And I'm handed a stack of papers. It's a list of people you're going to meet today.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chloe028"]
[OnName num="chloe"]
Here is a list of all the people you will meet today.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe029"]
[OnName num="chloe"]
We expect to introduce about ten people a day.
[cpg cn=true]


[OnName num="daigo"]
I was surprised when I heard the number.
[cpg cn=true]


I was surprised to hear the number. Isn't that a lot of people?
[cpg]

No, but can I choose what I want to do with ......?
[cpg]

While I was thinking about this and that, the carriage stopped in front of a luxurious mansion.
[cpg]


[OnName num="nobility"]
The carriage stopped in front of the luxurious mansion.
[cpg cn=true]


The whole family was there to greet and welcome me.
[cpg]


The way he is dressed and the house looks, he seems to be an aristocrat.
[cpg]


[OnName num="nobility"]
"Ishrina. Come."
[cpg cn=true]


The girl called Ishrina stepped forward.
[cpg]


It seems that she is the heiress of the family.
[cpg]


[OnName num="noble_daughter"]
My name is Ishrina. My name is Ishrina, my savior. Please have mercy on me."
[cpg cn=true]


I wasn't invited to make small talk. She wouldn't want that.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_pi"]
;//ブラックアウト




[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe030"]
[OnName num="chloe"]
"Daigo. It's time.
[cpg cn=true]


[OnName num="daigo"]
Uh, ah, ah, ......."
[cpg cn=true]


I said goodbye to her, wondering if it would be that soon.
[cpg]


[free time=1000]

Ishrina takes my hand in hers.
[cpg]


[OnName num="noble_daughter"]
I hope to see you again, Daigo-sama," she says with a blush on her cheeks.
[cpg cn=true]


I'm sure you'll be able to find out more.
[cpg]


[OnName num="daigo"]
I say, "Well, if you can. ......
[cpg cn=true]


[OnName num="noble_daughter"]
I'm sure you will."
[cpg cn=true]


I'm simply thrilled at how cute she is.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





And then lunch break. He was looking forward to a meal and a break, but when he entered the ...... restaurant, he said he was panicking.
[cpg]


So we decided to eat our sandwiches in the carriage. And on the move.
[cpg]


[OnName num="daigo"]
I thought to myself, "...... this isn't the way to treat people."
[cpg cn=true]


I was disgusted with the stones. Unlike when I was in the castle, I felt like I was being worked like a cart horse.
[cpg]



[OnName num="daigo"]
"Why don't we take a break somewhere?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe031"]
[OnName num="chloe"]
I'm sorry, sir. I'm sorry, but I'm also busy with my plans for the rest of the day.
[cpg cn=true]


Chloe apologized to Taira, but he only apologized to her, and in the end, she dismissed him out of hand.
[cpg]


[OnName num="daigo"]
Then can't we have dinner at the nobleman's house we're going to next? Sandwiches aren't tasty enough.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe032"]
[OnName num="chloe"]
'It will take time to prepare now. Besides, I don't want you to get too close to one nobleman.
[cpg cn=true]


I see. I see. Will there be criticism from the other nobles? ...... Even so.


Suddenly they make you do this and that, and tell you no, no, no. If I had listened to them maturely, ...... everyone would have been irritated.
[cpg]


[OnName num="daigo"]
"Don't I have any human rights?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe033"]
[OnName num="chloe"]
"I'm sorry, but for the sake of this world.
[cpg cn=true]


[OnName num="daigo"]
I don't care what this world looks like to me."
[cpg cn=true]




An awkward silence ensues, but I think my intentions were conveyed.
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





We continued to visit the homes of the nobles in the afternoon.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夜）******************************************************





The sun had set and it was nighttime. In the carriage back to the castle.
[cpg]



[OnName num="daigo"]
I was tired. My back hurts, I'm hungry.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe034"]
[OnName num="chloe"]
You talk like a child.
[cpg cn=true]


[OnName num="daigo"]
Children don't talk about their backs aching.
[cpg cn=true]


[free time=1000]

My mood was at its peak.
[cpg]



[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe035"]
[OnName num="chloe"]
We are almost at the castle. We have prepared a meal for you.
[cpg cn=true]


The carriage was tiring, even just moving around.
[cpg]

[OnName num="daigo"]
Let me just ...... lie down for a minute."
[cpg cn=true]



I shudder to think that this would go on every day for a year.
[cpg]


I'm not going to do it unless I get something in return.
[cpg]




;//移植のためシーンをカットしています


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************



Then the next day.
[cpg]


Last night I ran out of energy as soon as I finished my meal.
[cpg]


Today I'm supposed to head to the daughter of a nobleman who is also on the list.
[cpg]


[OnName num="daigo"]
I'm at my wits' end. ...... I need to get out for a distraction."
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe036"]
[OnName num="chloe"]
But it's too dangerous.
[cpg cn=true]


[OnName num="daigo"]
I'm sure I'll be fine with an escort. I'm counting on you.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe037"]
[OnName num="chloe"]
......, I don't have a choice.
[cpg cn=true]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[WAIT time=100]
;//【ＢＧ】『城下町』（朝）******************************************************




So I went outside with a few guards.
[cpg]

The women in town are sneaking around and looking at me from a distance.
[cpg]


;//誰と交わるかというのも自分の一存で決められる。と思いながら街を歩いてみると、
I walk down the street wondering if all of these stares want a child.
[cpg]


[OnName num="woman"]
Please!　Please have mercy on me!"
[cpg cn=true]


A woman in rags and tattered clothing is hanging on to me.
[cpg]


She, too, is trying to raise her own status by conceiving a child.
[cpg]


[OnName num="escort"]
"Back off," she says. Don't touch Daigo-sama.
[cpg cn=true]



[OnName num="woman"]
Please, please. ......
[cpg cn=true]


Even though she said so, I had no intention of doing anything with this kind of attitude.
[cpg]


[free time=1000]

As I was thinking this, I saw a girl who was not confused about me.
[cpg]


[OnName num="daigo"]
Oops. ......."
[cpg cn=true]


I walked toward the girl. She was approaching me too.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte001"]
[OnName num="unknown"]
I wanted to see her. You're a guy, right?
[cpg cn=true]


[OnName num="daigo"]
"Yes, I am. Yes, I am.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte002"]
[OnName num="charlotte"]
I'm Charlotte. Your name is Daigo, right?"
[cpg cn=true]


He speaks to me in a rather casual manner. Then he took my hand.
[cpg]


[OnName num="escort"]
Don't touch Daigo-sama so casually. It's disrespectful.
[cpg cn=true]


But finally, I met a woman who wasn't all flirtatious with me.
[cpg]

It's this kind of person that I want to treasure. Lily is the only one who bows down to me enough.
[cpg]


[OnName num="daigo"]
Why don't you bow down to me or flatter me?"
[cpg cn=true]


I asked him frankly. I asked him frankly.
[cpg]

[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte003"]
[OnName num="charlotte"]
Because I can't have children anyway. So there's no point in flirting with me.
[cpg cn=true]


[OnName num="daigo"]
I said, "You can't have children ......?"
[cpg cn=true]


I see. Of course there are women like that. I thought women in this world had evolved in their own unique way, but it seems that they are the same there.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte004"]
[OnName num="charlotte"]
I'm frail and weak. So ...... hey, big brother."
[cpg cn=true]


[OnName num="daigo"]
"...... big brother?"
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte005"]
[OnName num="charlotte"]
I'm not a big brother. I know that's what you say to your older siblings.
[cpg cn=true]


It's a word, but me and Charlotte aren't related by blood or anything.
[cpg]


[OnName num="daigo"]
You're not brother and sister to me. ......
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte006"]
[OnName num="charlotte"]
I had a sister. I had a sister, but she got sick and died.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte007"]
[OnName num="charlotte"]
"Hey, it's okay, right?　I want to call you big brother.
[cpg cn=true]


 Even though I think it's familiar, it's a rare type in this world.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte008"]
[OnName num="charlotte"]
"Brother, come to my house. I have something to tell you."
[cpg cn=true]


[OnName num="daigo"]
"......"
[cpg cn=true]


I wasn't sure what I was going to do, but I could always go if I wanted to.
[cpg]




;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I did not go to Charlotte's house that day.
[cpg]


But I was left with a strong impression.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





If you're frail and don't know if you'll be able to carry a child to term, you're in a ......
[cpg]


I would be in a weak position in this world. Thinking this, I asked Chloe.
[cpg]


[OnName num="daigo"]
Do you know a woman named Charlotte?　I think she's an aristocrat or something, because she's pretty well dressed.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe038"]
[OnName num="chloe"]
I know her, she's a . I know her, she's in a ...... pitiful situation, isn't she?
[cpg cn=true]


Chloe spoke up, a little at a loss for words.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe039"]
[OnName num="chloe"]
'It's a world where you don't know if you'll be able to have any offspring. It's a more difficult world for sickly women than the one you're in.
[cpg cn=true]


It seems that the ability to have children is the most important status.
[cpg]


But still, there is something that concerns me about .......
[cpg]


[OnName num="daigo"]
"...... this world turns with a summons every decade or so?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe040"]
[OnName num="chloe"]
Yes. There's a good chance that twins or triplets will be born.
[cpg cn=true]


But that's still not enough at all. I was skeptical.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe041"]
[OnName num="chloe"]
Most of the people in this world are living in this Lilum country," he said.
[cpg cn=true]


[OnName num="daigo"]
You mean there is no other big country like it?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe042"]
[OnName num="chloe"]
Yes. Most of them have died out due to the plague.
[cpg cn=true]


Yes, it's serious. It's a serious matter, but it's something that ...... I'm going to have to do something about.
[cpg]



[OnName num="daigo"]
"On a different note, Chloe,...... don't you want kids?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chloe043"]
[OnName num="chloe"]
I'm sure you do. I'm sure you do. That's why I'm serving you like this.
[cpg cn=true]


I'm sure you'll be able to find a way to get a good deal on the newest and most up-to-date information. I think so.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe044"]
[OnName num="chloe"]
However, I also have the role of determining whether you are the right person to beget offspring.
[cpg cn=true]

;//＠
[OnName num="daigo"]
;//「堅苦しいな。俺に抱かれる気は無いのかってことだよ」
That's a bit formal. Are you sure you don't want to have a child with me?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chloe045"]
[OnName num="chloe"]
Yes, I do. But, Daigo-sama,......, do you think about this country and act accordingly?
[cpg cn=true]


Don't be rude. I'll think of an answer.
[cpg]



;//■選択肢
[switch]
[case "I act with proper discretion."]
	[swap]
	[jump target="*select01_1"]
[case "You don't want children?"]
	[swap]
	[jump target="*select01_2"]
[endswitch]


9. You are acting with proper discretion.
10. You don't want kids?



;//==============================
;//９、きちんとわきまえて行動している
*select01_1|Why were you called to another world?




[OnName num="daigo"]
"Of course I was called to another world. You don't have to doubt that."
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
Chloe smiled at my words.
[cpg]


[OnName num="daigo"]
Come to think of it, I haven't really taken good care of you.
[cpg cn=true]



;//変数　善+1
[stflag goodflg = 1]

[system selflg_01=false]

[jump target="*select01_3"]

;//==============================
;//10、お前は子供が欲しくないのか？
*select01_2|The Reason Why I Was Called to Another World




[OnName num="daigo"]
Don't you want kids?"
[cpg cn=true]


I was angry, so I answered, "No, I don't want a child.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe046"]
[OnName num="chloe"]
"Your name is ......."
[cpg cn=true]



;//変数　悪+1
[stflag evilflg = 1]

[system selflg_01=true]


;//==============================
*select01_3|The Reason I Was Called to Another World

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

That's why I decided to mess with Chloe.
[cpg]

She, too, has her own position. She didn't reject me explicitly.
[cpg]



;//========================================
;//●ＣＧ（背後からヒロインを抱きしめる主人公）ev_04
;//人物１：ヒロイン２
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：城内＿主人公の部屋
;//時間　：夜
;//========================================


[BGM f="bg_h1"]
;**【ＣＧ】 ev_04_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=100]




[VOICE f="Chloe047"]
[OnName num="chloe"]
'......It's embarrassing to be embraced by a man, isn't it?
[cpg cn=true]


[OnName num="daigo"]
'By a man?　Does that mean it's okay if it's the same sex?
[cpg cn=true]


[VOICE f="Chloe048"]
[OnName num="chloe"]
'Yes, well,...... there are only women in this world.
[cpg cn=true]


I guess things like homosexuality are treated differently in the world I was in.
[cpg]

With that thought in mind, I stroked Chloe's hair.
[cpg]

[VOICE f="Chloe049"]
[OnName num="chloe"]
It tickles."
[cpg cn=true]


[OnName num="daigo"]
'That's a cute reaction. Show me more.'
[cpg cn=true]


I stayed by her side for a while, saying such things to Chloe.
[cpg]


;//移植のためシーンをカットしています

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//移植のためシーンをカットしています

I have become somewhat accustomed to life in another world, to the point where I can afford to do this.
[cpg]


I'm getting used to it, but just because I'm used to ...... doesn't mean I'm not worried.
[cpg]


The next morning, the first thing I did was to go to the bathroom.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（朝）******************************************************





The next morning. I went to Lily's room.
[cpg]


Chloe was there too. I wondered if they were discussing something.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily044"]
[OnName num="lily"]
What's wrong?　Daigo-dono.
[cpg cn=true]


[OnName num="daigo"]
Yes, I have something to ask you. I would like to ask you something.
[cpg cn=true]


Lily got up from her chair and turned to me, saying, "Whatever you want to ask me.
[cpg]


[OnName num="daigo"]
Can I go back to my world?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily045"]
[OnName num="lily"]
Yes. Yes, because the path between this world and your world, which is connected by summoning magic, is still open. You will definitely be able to return in a year's time.
[cpg cn=true]


[OnName num="daigo"]
Is that so? Then I guess I can call one more man.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily046"]
[OnName num="lily"]
It is difficult to explain, and I don't really understand it either, but I heard that ...... one man is limited to one round trip.
[cpg cn=true]


I see. I understand. It's like they only sell round-trip tickets.
[cpg]


If you use it to call someone, you probably won't be able to go back.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily047"]
[OnName num="lily"]
So you can definitely go back, just ......."
[cpg cn=true]


After saying "just," Lily looked apologetic.
[cpg]


[OnName num="daigo"]
What is it?　Is there something you don't want to tell me?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily048"]
[OnName num="lily"]
No," she said. No, it's nothing.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily049"]
[OnName num="lily"]
But still, I can't believe that ...... Daigo-dono is here.
[cpg cn=true]


Lily shakes her head a little and tries to change the subject.
[cpg]


[OnName num="daigo"]
The actuality is, it's a whim. But more importantly, what I'm going to ...... do now."
[cpg cn=true]


[OnName num="daigo"]
You sure you don't want me to pick someone on my own?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily050"]
[OnName num="lily"]
'That's of course. No one will go against what you say.
[cpg cn=true]


I knew it. I'd like to know a little more about how this world works.
[cpg]


[OnName num="daigo"]
Procreation is the basis of life. But this is a world where that doesn't work, right?
[cpg cn=true]

[free time=1000]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Chloe050"]
[OnName num="chloe"]
I guess so."
[cpg cn=true]


Chloe said something, but Lily did not interrupt her anymore. Lily also seems to have calmed down somewhat.
[cpg]


[free time=1000]

[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily051"]
[OnName num="lily"]
 “It’s just as Mr.Daigo said, it’s a world where commoners can become Nobleman if they conceive a Sawayama child.”
[cpg cn=true]


[OnName num="daigo"]
I see,...... that you need children so much.
[cpg cn=true]


The world I was in may have been similar. The world I was in might be similar.
[cpg]


By building a family, you gain social credibility....... No, is it the other way around?
[cpg]


You can't build a family unless you are financially stable. Then again, I guess things are different from my world.
[cpg]


I've already decided what I'm going to do.
[cpg]


[OnName num="daigo"]
So, Lily must be dying to have a baby.
[cpg cn=true]

[free time=1000]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_5"  pos="2/2" time=800]

[VOICE f="Chloe051"]
[OnName num="chloe"]
"Nah. ......."
[cpg cn=true]


Chloe raised her voice. I know I'm being rude.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily052"]
[OnName num="lily"]
I know I'm being rude. I'm sure you're right.
[cpg cn=true]

[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]

[OnName num="daigo"]
I know you're the queen. You can wield that power and force ...... them to do it, can't you?
[cpg cn=true]


But somehow I felt I couldn't do that.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Lily053"]
[OnName num="lily"]
I said, "No, I can't do that. If we tried to monopolize it with the queen's power, we would incur the public's opprobrium.
[cpg cn=true]



Lily is desperate. She hides it.
[cpg]


[OnName num="daigo"]
She is trying to hide it. Then I'll do it if you get down on your knees and flirt with me."
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe052"]
[OnName num="chloe"]
'......'
[cpg cn=true]


Chloe was silent. Lily was silent, too.
[cpg]


Chloe was not going to be able to interfere with that because of her position.
[cpg]


And Lily probably wouldn't even get down on her knees. She was born into royalty, that kind of thing ......
[cpg]


[OnName num="daigo"]
Huh?"
[cpg cn=true]


Lily plunged to her knees. Then she bowed her head.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
;//[t_move pos=L 下礼]

[VOICE f="Lily054"]
[OnName num="lily"]
'Please. Please ......"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Chloe053"]
[OnName num="chloe"]
'Your Majesty!　Please don't!"
[cpg cn=true]


Chloe put her hand on my shoulder to stop me. I was puzzled.
[cpg]


I was puzzled.
[cpg]


And all because she wants to have a child.
[cpg]


I had to realize that I was in a truly tremendous position ......
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





I go back to my room, but it's too big for me to settle down.
[cpg]


It's impossible to be comfortable in a situation like this.
[cpg]


I have learned that people are more fidgety when they can have whatever they want.
[cpg]


Dinner was already finished. Today's meal was a moderate amount.
[cpg]


All that was left was to take a bath and go to sleep.
[cpg]



[SE f="se009"]
;//【ＳＥ】『ノック』





[VOICE f="Lily055"]
[OnName num="lily"]
I was just about to go to bed when I heard a voice saying, "...... Daigo-dono. I'm Lily.
[cpg cn=true]


[OnName num="daigo"]
"Yes, come in. Come in.
[cpg cn=true]


Lily was calling for me, so I invited her in. I wanted to repair the relationship with her.
[cpg]


[OnName num="daigo"]
"Lily. Have you taken a bath yet?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily056"]
[OnName num="lily"]
No, I haven't. What's wrong with ......?
[cpg cn=true]


[OnName num="daigo"]
"We'll take a bath together. Let's get naked together.
[cpg cn=true]


I took Lily's hand. I pulled her hand, and although she didn't resist, she didn't even try.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Lily057"]
[OnName num="lily"]
I pulled her hand and she didn't resist, but she said, "Oh, my God, I'm so afraid of you!
[cpg cn=true]


I'm afraid of you!
[cpg]


[OnName num="daigo"]
It's okay. You don't care about me, do you?　You don't."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily058"]
[OnName num="lily"]
"Uu...... that's true, but..."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





So we decided to rent out the biggest bath in the castle.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe054"]
[OnName num="chloe"]
'......Yes, sir.'
[cpg cn=true]


Chloe can make anything happen if I want her to.
[cpg]


Even if they don't, even if they are not Chloe, there is no one who won't follow my word.
[cpg]


[free time=1000]

 While thinking so, I try to take off my clothes before entering the bath.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Lily059"]
[OnName num="lily"]
......"
[cpg cn=true]


[OnName num="daigo"]
What's up?　Lily.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily060"]
[OnName num="lily"]
"It's the first time I've ...... seen a man's body."
[cpg cn=true]


She seems excited. She doesn't want to take off her clothes.
[cpg]


[OnName num="daigo"]
"Do you want me to undress you?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Lily061"]
[OnName num="lily"]
No, I'll take off my own clothes. ......
[cpg cn=true]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

In the end, Lily was too shy to be naked.
[cpg]

The two were in their swimsuits,......, and in this world, too, there is such a thing as a swimsuit.
[cpg]


;//========================================
;//●ＣＧエロ（二人でお風呂。主人公と隣り合って顔を赤らめるヒロイン）ev_01
;//人物１：ヒロイン１
;//服装１：水着
;//人物２：主人公
;//服装２：水着
;//場所　：城内＿風呂場
;//時間　：夜
;//========================================


[BGM f="bg_pi"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=100]




[VOICE f="Lily062"]
[OnName num="lily"]
"I didn't ...... think this kind of thing ...... really existed."
[cpg cn=true]


[OnName num="daigo"]
What is such a thing?"
[cpg cn=true]


I'm meeting the opposite sex for the first time and this is happening right out of it.
[cpg]


I know how Lily feels, but I dare her to say it.
[cpg]



[VOICE f="Lily063"]
[OnName num="lily"]
'Well,......, taking a bath together is something that not many women have experienced, even amongst themselves.
[cpg cn=true]


Maybe that's true when you're as high up in the ladder as she is.
[cpg]


I could only imagine, but I spent some relaxing time with her.
[cpg]

;**【ＣＧ】 ev_01_a ***********************
[CG id=1 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Lily064"]
[OnName num="lily"]
I was so happy to see her. Let me ...... that."
[cpg cn=true]


[OnName num="daigo"]
What's wrong?"
[cpg cn=true]


Lily's face was pale and her mouth was clammy. Then she finally spoke up.
[cpg]



[VOICE f="Lily065"]
[OnName num="lily"]
Is it possible that Daigo-dono will love me ......?
[cpg cn=true]


It seemed like her way of saying it. It was too polite and conveyed her feelings rather well.
[cpg]


[OnName num="daigo"]
I'm thinking about it."
[cpg cn=true]


I ventured to blurt it out. Lily looked frustrated.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//移植のためシーンをカットしています

I stayed by her side after she got out of the bath.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夜）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

I followed her to her room, and she looked thrilled.
[cpg]

[OnName num="daigo"]
...... Lily."
[cpg cn=true]


She is shy and doesn't look straight at me.
[cpg]

She is cute in that way too. I wondered what would happen if I pressed a little closer.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[VOICE f="Lily066"]
[OnName num="lily"]
Crap."
[cpg cn=true]


;//========================================
;//●ＣＧエロ（ベッドに倒れているヒロイン。主人公が押し倒している）ev_03
;//人物１：ヒロイン１
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：城内＿ヒロイン１の部屋
;//時間　：夜
;//備考　：10-.jpgのシーンです
;//========================================

[BGM f="bg_h1"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="Lily067"]
[OnName num="lily"]
"...... Daigo, which ......?"
[cpg cn=true]


She rolls her eyes, then looks away again, as if realizing something.
[cpg]

[OnName num="daigo"]
The first thing that comes to my mind is that I'm not going to do anything. I'm not doing anything.
[cpg cn=true]


[VOICE f="Lily068"]
[OnName num="lily"]
Is that so?　The first thing you need to do is to make sure that you have a good understanding of what you're doing.
[cpg cn=true]


...... not so easy, you say things like you know me.
[cpg]

The first thing to do is to make sure that you have a good understanding of what is going on in your life.
[cpg]

The actual "I'm not a fan of the way you do it," he said.
[cpg]

;**【ＣＧ】 ev_03_a ***********************
[CG id=2 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Lily069"]
[OnName num="lily"]
"N......"
[cpg cn=true]


From Lily's point of view, it was probably her first kiss.
[cpg]

She looked satisfied, but I was embarrassed to see her reaction.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





After that, the hospitality continued.
[cpg]


I complained about the carriage ride, so the method was changed.
[cpg]

The women were allowed to visit the castle, but ......
[cpg]



[OnName num="daigo"]
"......Boring. ......
[cpg cn=true]


Boring. The hard schedule only improved, I thought.
[cpg]


[OnName num="daigo"]
'I need to get out. As long as I get Lily's permission, right?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe055"]
[OnName num="chloe"]
'...... I don't think she'll let me first.'
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





A short time later, Lily came to my room.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Lily070"]
[OnName num="lily"]
She said, "Are you going outside?　I'm going to go outside. ......
[cpg cn=true]


[OnName num="daigo"]
I don't care. I want to go alone.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe056"]
[OnName num="chloe"]
That's not going to happen. I will at least have an escort. I'll go with you.
[cpg cn=true]


[OnName num="daigo"]
You are exaggerating. Do you think I will be attacked in a world where there are only women?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe057"]
[OnName num="chloe"]
That's right. If you were kidnapped, it would be very serious.
[cpg cn=true]


You will be kidnapped. Is there such a possibility?
[cpg]


No, it might be possible. ...... They will do whatever it takes to ensure their offspring.
[cpg]


I'm being treated well now, but I'm sure there are others who are thinking of doing the opposite.
[cpg]


So, I can't act too recklessly, can I?
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************



Still, after a few days, I couldn't stand the cramped life and tried to get out of it.
[cpg]


When neither Lily nor Chloe were around. I asked the lady-in-waiting, who was also my guard, "Hey, you.
[cpg]


[OnName num="daigo"]
Hey, you. I need you to take me out of the castle.
[cpg cn=true]


[OnName num="maid"]
If I help you, ...... I will be killed.
[cpg cn=true]


[OnName num="daigo"]
Don't worry, I'll cover for you later. Don't worry, I'll cover for you later, and you won't be able to resist me.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


I went to the city.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





After that, I was out in the city again.
[cpg]


No escort. I hide my face, I hide my identity.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


There are certain times when people can hide their faces.
[cpg]

For example, it is impossible to hide one's face during a meal.
[cpg]

Still, I was hungry, so I entered a diner in the city for fun. I went to ......
[cpg]

[OnName num="shop_owner"]
What?　Daigo-sama!"
[cpg cn=true]


A woman who seemed to be the owner of the restaurant came up to me and was surprised to see me.
[cpg]


She looked at me in amazement.
[cpg]


[OnName num="daigo"]
If you have time to be surprised, serve me food.
[cpg cn=true]


[OnName num="shop_owner"]
I'll bring it to you right away.　I'll bring it to you now.
[cpg cn=true]


And what was brought to me was probably the best feast in the restaurant.
[cpg]


Naturally, they don't ask for money.
[cpg]

An unusual situation. I don't feel bad, but I also feel like I'm being hit by the strangeness of the situation.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Afterwards, I was pretty pissed at Lily.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Lily071"]
[OnName num="lily"]
She said, "I can't believe you ...... snuck out of the castle on your own."
[cpg cn=true]


[OnName num="daigo"]
But you can't even keep me locked up, can you?"
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily072"]
[OnName num="lily"]
"That's true, but it's ...... troubling. If you get kidnapped by bandits or something, ......"
[cpg cn=true]


I've been wondering about this for a while. The bandit is called that bandit.
[cpg]


[OnName num="daigo"]
What is this bandit going to steal from me?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily073"]
[OnName num="lily"]
What is it that they want to steal? Their goal is to kidnap Daigo, isn't it?
[cpg cn=true]


[OnName num="daigo"]
What do you mean?　What do you mean? Do you want a child that badly?
[cpg cn=true]


I thought it was quite possible, but after listening to the story, it seems that this is not the case.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Lily074"]
[OnName num="lily"]
There are people who are trying to make a fortune by kidnapping Daigo-dono for ransom.
[cpg cn=true]


[OnName num="daigo"]
What's that ......?"
[cpg cn=true]


I couldn't believe my ears. I couldn't believe my ears.
[cpg]


[OnName num="daigo"]
I couldn't believe my ears. "In this world, there are no other men, are there?　Don't you want to have children yourself?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily075"]
[OnName num="lily"]
'There's a part of me that doesn't get that either. ......
[cpg cn=true]


If you ask me, they are more interested in living happily in the present than in procreation.
[cpg]


[OnName num="daigo"]
I see that ...... happens even if they are all women."
[cpg cn=true]


But they might be in the world where they were originally from. I think it's more common among men, though.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily076"]
[OnName num="lily"]
The leader of the bandits, Martina, is said to be particularly ferocious and troublesome.
[cpg cn=true]


[OnName num="daigo"]
"Yes, so you've never seen him?"
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Lily077"]
[OnName num="lily"]
No, I have not. If I had, I would have him arrested.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
 
I thought about what I was going to do.
[cpg]


I am me, and I can't just go along with the flow.
[cpg]


I thought about it, and one person came to mind.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe058"]
[OnName num="chloe"]
Good morning, Mr. Daigo. Daigo-sama.
[cpg cn=true]


[OnName num="daigo"]
"...... Ah, good morning. Good morning."
[cpg cn=true]


When I wake up in the morning, Chloe is there, as she is every day.
[cpg]


[OnName num="daigo"]
'You're not sleeping?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe059"]
[OnName num="chloe"]
I do sleep. I'm a short, deep sleeper.'
[cpg cn=true]


If there was a way to do that, everyone would be doing it. Chloe must be pushing herself too hard.
[cpg]


[OnName num="daigo"]
'Well, that's all right. I just have someplace I want to go."
[cpg cn=true]


I've been thinking about it since yesterday. I've been thinking about Charlotte.
[cpg]


[OnName num="daigo"]
"Chloe. I want to go to Charlotte's, okay?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe060"]
[OnName num="chloe"]
"Charlotte?　What about her?
[cpg cn=true]


[OnName num="daigo"]
I'm just curious. She's an unusual type.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe061"]
[OnName num="chloe"]
I don't like to get too attached to one aristocrat, but ...... I guess so.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************



So I visited Charlotte's house, and she answered the door.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte009"]
[OnName num="charlotte"]
He said, "Oh, brother!　You came.
[cpg cn=true]


[OnName num="daigo"]
I had an appointment. So, what did you want to talk about?
[cpg cn=true]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（昼）******************************************************



I followed Charlotte's lead to her room.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte010"]
[OnName num="charlotte"]
I have a lot to tell you," she said. What is it about the male body?
[cpg cn=true]


Charlotte seemed curious.
[cpg]


Charlotte was curious. "It's true that it's easy to build up muscles," she said.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Charlotte011"]
[OnName num="charlotte"]
I wonder if it's true that it's easy to build up muscles.　I'd like to see it.
[cpg cn=true]


[OnName num="daigo"]
I'll tell you if you force ...... me to."
[cpg cn=true]


I was the childish part of Charlotte, and I was mischievous.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Charlotte012"]
[OnName num="charlotte"]
"What ......, big brother!
[cpg cn=true]



[SE f="se011"]
;//【ＳＥ】『ベッドに倒れる』



;//========================================
;//●ＣＧ非エロ（ヒロインを押し倒す主人公）ev_07
;//人物１：ヒロイン３
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：ヒロイン３の部屋
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_pi"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="Charlotte013"]
[OnName num="charlotte"]
What's wrong ......?　What's wrong with ?
[cpg cn=true]


I thought Charlotte would be pleased or disgusted, but ......
[cpg]

The first thing that comes to mind is that the baby is not a baby. I was surprised that she was so complex about not being able to have a baby.
[cpg]

[OnName num="daigo"]
I thought, "......"
[cpg cn=true]


I felt like it wasn't right to force a kiss, so I just stroked her head.
[cpg]

I'm aware that I'm doing something kind of weird on top of being a coward, but I couldn't do anything about it.
[cpg]

[VOICE f="Charlotte014"]
[OnName num="charlotte"]
'......Seriously, what's wrong with you?'
[cpg cn=true]


[OnName num="daigo"]
No, it's nothing."
[cpg cn=true]



;//ブラックアウト
;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（昼）******************************************************



Then I asked Charlotte, "What's wrong?
[cpg]

[OnName num="daigo"]
Don't you want to have ...... children?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte015"]
[OnName num="charlotte"]
I do. But you know what?
[cpg cn=true]


[OnName num="daigo"]
I pity you.
[cpg cn=true]


I thought, "I pity her.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte016"]
[OnName num="charlotte"]
I'm not going to say that. It makes me even sadder.
[cpg cn=true]


I think about it. And then I said something like this.
[cpg]

[OnName num="daigo"]
'...... is there anything you want?'
[cpg cn=true]


It was a sign that he thought I could solve everything. I thought it was hubris.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Charlotte017"]
[OnName num="charlotte"]
I said, "I don't want anything, but ...... then I'd like the necklace you're wearing."
[cpg cn=true]


Come to think of it, I was wearing it because I saw something like that in the clothes that the castle people had picked out for me. ......
[cpg]

[OnName num="daigo"]
What are you going to do with it?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Charlotte018"]
[OnName num="charlotte"]
'Because what a man wears is worth a lot more than that.
[cpg cn=true]


It could be something like that. Not that there is actually anything to it, but in a spiritual sense, I suppose.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************


As I walked out of Charlotte's house, I was pondering.
[cpg]

I had never seen her type in this world.
[cpg]

I wondered if I could do something about it ...... and realized that I couldn't do anything about it because I was a man.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And because I was thinking that way, I didn't even notice the presence of someone or something following me.
[cpg]

[ENDTRIAL]
[jump storage="ep001.ks" target="*start"]


;//////////////////////////////////////////////////////////////////
