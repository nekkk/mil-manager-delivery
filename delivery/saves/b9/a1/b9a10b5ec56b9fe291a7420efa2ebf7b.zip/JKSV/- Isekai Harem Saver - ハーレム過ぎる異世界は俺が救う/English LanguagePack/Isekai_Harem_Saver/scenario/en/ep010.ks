
*start

;#################################################
*Ep010|The Intellectual Chloe
;#################################################

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************



[if exp={ isSystemFlagsEnabled( "selflg_01") }]
[stflag evilflg= 1]
[endif]

[if exp={ isSystemFlagsEnabled( "selflg_02") }]
[stflag evilflg= 1]
[endif]




*select06_2|The Intellectual Chloe

[SCENE id=10]


......Yes, that's right. I still prefer an intelligent woman like Chloe.
[cpg]


Lily seems to be accepting no matter what she does. Chloe is different.
[cpg]


She's trying to be cool with me.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





So, I called Chloe through a maid of honor.
[cpg]


[OnName num="daigo"]
"Hello, Chloe. Welcome to my house.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe167"]
[OnName num="chloe"]
"...... what is it? What is it that you wanted to see me about?
[cpg cn=true]


[OnName num="daigo"]
I called Chloe through a Samurai woman. You want to have kids?
[cpg cn=true]


I decided to say it in a roundabout way. Chloe would not deny it.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe168"]
[OnName num="chloe"]
"That's ...... of course," she said.
[cpg cn=true]


[OnName num="daigo"]
"Oh, yeah. I'll do anything for it.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe169"]
[OnName num="chloe"]
'I can't ...... do everything, but I'll do what I can.
[cpg cn=true]


I knew you were cool about that. Lily and Charlotte would answer anything.
[cpg]


[OnName num="daigo"]
I like that about you. Come here.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Chloe170"]
[OnName num="chloe"]
What is it, ......?
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





I left with Chloe and went out to town. Chloe didn't restrain me, I guess she thought I had something to do at some house.
[cpg]


But it isn't.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe171"]
[OnName num="chloe"]
"Are you going this way ......?　It's a dead end.
[cpg cn=true]


[OnName num="daigo"]
"Oh, yeah. Just as well.
[cpg cn=true]



;//ブラックアウト

;//========================================
;//●ＣＧエロ（屋外。立っているヒロインに口づけをする主人公）ev_64
;//人物１：ヒロイン２
;//服装１：着衣（はだけ）
;//人物２：主人公
;//服装２：着衣
;//場所　：路地裏
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_64_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="Chloe172"]
[OnName num="chloe"]
What are you going to do?
[cpg cn=true]


[OnName num="daigo"]
I'm going to do this.
[cpg cn=true]


I approach Chloe. She turned her face away from me.
[cpg]

I kissed her, forcing her to turn her face away from me.
[cpg]


;**【ＣＧ】 ev_64_a ***********************
[CG id=18 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Chloe173"]
[OnName num="chloe"]
I kissed her. ......
[cpg cn=true]


[OnName num="daigo"]
It's a cute reaction," I said.
[cpg cn=true]


Chloe was still too shy to look at me.
[cpg]


;//移植のためシーンをカットしています
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





From the alleyway back to the main street. Chloe was red in the face.
[cpg]


I feel that this kind of cuteness is unique to Chloe.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Chloe174"]
[OnName num="chloe"]
I'm not going to ...... let this kind of thing go on any longer.
[cpg cn=true]


[OnName num="daigo"]
"Now that you put it that way, I'm tempted to do it again."
[cpg cn=true]


The first time I saw him, I thought he was going to say something, but in the end he didn't say anything.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





We know what kind of person Chloe is.
[cpg]


If she has a complaint, she'll say it, and she might not be happy about the situation that I'm in with Chloe all the time.
[cpg]


But I don't mind that. I just do what I want to do.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





[FG f="CHA02_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Chloe175"]
[OnName num="chloe"]
I'm not going to be able to do that.
[cpg cn=true]


After that, I continued to approach her whenever the opportunity arose.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe176"]
[OnName num="chloe"]
"No, please don't do that. ......
[cpg cn=true]


[OnName num="daigo"]
Why not?　You don't like it?"
[cpg cn=true]


;//＠俺はそう言って、彼女とまぐわう。
I said and hugged her.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Chloe177"]
[OnName num="chloe"]
'I don't hate it, but ......
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夜）******************************************************



I have my duty today. I'm about to finish it and head back to the castle when I ......
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe178"]
[OnName num="chloe"]
'...... Daigo-sama. Lately, have you been paying attention to ...... me all the time?
[cpg cn=true]


[OnName num="daigo"]
I said, "Oh, yes. Is something wrong?"
[cpg cn=true]


No, said Chloe, looking a little down. She looks worried about something.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe179"]
[OnName num="chloe"]
Good morning, Mr. Daigo. Good morning, Mr. Daigo.
[cpg cn=true]


Chloe usually wakes me up in the morning. That's what I like to do.
[cpg]

I felt a sense of insecurity rising in my heart when I saw her face.
[cpg]


[OnName num="daigo"]
"Chloe, why don't we take a break today? How about we take a break today?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe180"]
[OnName num="chloe"]
"Break ......?　What are you talking about?
[cpg cn=true]


[OnName num="daigo"]
It's the Sabbath. I just want to be with Chloe.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe181"]
[OnName num="chloe"]
That's not how it works. I'm not going to be the exclusive ......"
[cpg cn=true]


[OnName num="daigo"]
I told you, I'm taking a break. It's not like it's going to stay that way forever.
[cpg cn=true]


What a way to put it. I want to love only Chloe all the time.
[cpg]


[OnName num="daigo"]
I'm sure you'll be glad to hear that. It's supposed to make you happy, too.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe182"]
[OnName num="chloe"]
"I'm sure it is," I managed to say.
[cpg cn=true]


;//移植のためシーンをカットしています

;//ブラックアウト

I managed to talk my way out of it and decided to flirt with Chloe.
[cpg]

But Chloe looks like she has an idea. It's a little cloudy.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chloe183"]
[OnName num="chloe"]
Daigo-sama. I don't think His Majesty will be satisfied with this."
[cpg cn=true]


[OnName num="daigo"]
What's wrong with Lily? I'm saying I'm going to love you.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe184"]
[OnName num="chloe"]
...... I see."
[cpg cn=true]


Chloe is still saying something that doesn't seem to add up.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夜）******************************************************



Then they go outside for a date, just the two of them.
[cpg]

I think it would be bad if the populace could see this too.
[cpg]

But I couldn't help myself.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夜）******************************************************


After having dinner outside, we go back to the castle. Chloe's expression was as gloomy as ever.
[cpg]


I wonder if she is not satisfied with the fact that she is loved by me.
[cpg]


She is the prime minister. She might be thinking about the people and the queen.
[cpg]


But I was under the impression that there was nothing I could do about it.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************



I guess it was all my own fault for being so complacent.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe185"]
[OnName num="chloe"]
"Good morning, Daigo-sama."
[cpg cn=true]


[OnName num="daigo"]
Good morning, Chloe.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe186"]
[OnName num="chloe"]
Here's today's schedule. First of all, I'd like to start with .......
[cpg cn=true]


[OnName num="daigo"]
'Sorry. Today is another break, I only want to love Chloe."
[cpg cn=true]


Chloe sighs at my words.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe187"]
[OnName num="chloe"]
I thought you would say so. I'm sorry," she said, snapping her fingers.
[cpg cn=true]



[SE f="se004"]
;//【ＳＥ】『指を鳴らす』



[free time=1000]



Chloe snaps her fingers. Some attendants come into the room.
[cpg]


[OnName num="daigo"]
"What's this?　What is it?
[cpg cn=true]


There were soldiers there, too. They come up behind me.
[cpg]

I was pinned down by a soldier. It was not so strong that I could shake it off.
[cpg]


But I was startled as soon as I saw him. While I was surprised, I was sniffing the drugs.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（昼）******************************************************





[OnName num="daigo"]
I said, "......, this is ......."
[cpg cn=true]


When I woke up, I was in the basement. Chloe was there.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]


[OnName num="daigo"]
"You ...... know what you're doing?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe188"]
[OnName num="chloe"]
"Daigo-sama, do you know what you're doing?"
[cpg cn=true]


[OnName num="daigo"]
What are you talking about? I just wanted to love Chloe ......."
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe189"]
[OnName num="chloe"]
That kind of selfishness will not be tolerated. You will stay here until you have a change of heart.
[cpg cn=true]


He says some disturbing things. No, it's disturbing enough that he's keeping me here.
[cpg]


[OnName num="daigo"]
What are you saying ......?　Does Lily approve of this?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe190"]
[OnName num="chloe"]
'I'm sure Your Majesty will agree. Daigo-sama says he loves no one but me.
[cpg cn=true]


;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（夕方）******************************************************



From there, I was locked in there until I changed my mind.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





There was only one expectation I could have.
[cpg]


I could only hope that Lily would oppose this policy. It all depended on whether or not Lily would see this as inhumane.
[cpg]


If she doesn't think so, I may never get out of here. ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（夕方）******************************************************





With this uncertainty in my mind, I enter my second day in the basement.
[cpg]


I am fed. There is a toilet. But that is all.
[cpg]


It's the opposite of the luxury I've enjoyed up until now. ......
[cpg]


Will I ever really get out of here?
[cpg]



;//※※※変数によって分岐

[if exp={getFlagValue("evilflg") == 2 }]
[jump target=*VectorEvil3]
[endif]
[if exp={getFlagValue("evilflg") == 1 }]
[jump target=*VectorEvil3]
[endif]



;//==============================
;//善の変数が悪の変数より多い場合
;//[jump target=*VectorGood3]
[jump storage="ep011.ks" target="*VectorGood3"]


;//==============================
;//悪の変数が善の変数より多い場合

*VectorEvil3
[jump storage="ep012.ks" target="*VectorEvil3"]
