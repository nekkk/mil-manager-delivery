
*start

;#################################################
*Ep001|Emergence of a band of thieves
;#################################################

[SCENE id=1]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





[OnName num="daigo"]
Whew. ......"
[cpg cn=true]


After eating dinner and taking a bath, I took a break.
[cpg]



[SE f="se009"]
;//【ＳＥ】『ノック』





Then I hear a knock at the door. I go to the door and open it.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily078"]
[OnName num="lily"]
I ask, "Daigo-dono,......, what did you do at Charlotte's house?"
[cpg cn=true]


[OnName num="daigo"]
Should I tell you that from ...... one?"
[cpg cn=true]


I told him some of what had happened.
[cpg]

I told her some of what had happened, that I had found out that she could not get pregnant.
[cpg]


Lily, after all," she said, and slumped.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Lily079"]
[OnName num="lily"]
She said there had been a burglary at Charlotte's house.
[cpg cn=true]


[OnName num="daigo"]
'What ......?'
[cpg cn=true]



[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily080"]
[OnName num="lily"]
The soldier said it was probably the work of a gang of thieves.
[cpg cn=true]


[OnName num="daigo"]
That's what I'm hearing so far.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Lily081"]
[OnName num="lily"]
They must be selling them on the black market for a lot of money. What do you think?
[cpg cn=true]


[OnName num="daigo"]
What do you say we do ......?"
[cpg cn=true]


But that necklace is the one I gave to Charlotte.
[cpg]


[OnName num="daigo"]
"All right, then. Then we'll go out on our own. Where are the bandits?"
[cpg cn=true]


I figured I might as well try to catch the bandits or something.
[cpg]


I like a strong woman. Martina must be very strong-willed.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily082"]
[OnName num="lily"]
The bandits seem to have a stronghold in the ...... frontier of Lilum country. ......
[cpg cn=true]


[OnName num="daigo"]
I'm going to go and finish them off."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Lily083"]
[OnName num="lily"]
"But it's ...... dangerous. I doubt Daigo-dono will survive.
[cpg cn=true]


[OnName num="daigo"]
"You'll have to defend him at all costs."
[cpg cn=true]


Lily would not shake her head. Lily would not shake her head.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily084"]
[OnName num="lily"]
I understand. But please be careful not to get caught.
[cpg cn=true]


[OnName num="daigo"]
'Oh. I know. ......
[cpg cn=true]

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





The next morning. I also called out to Chloe.
[cpg]


[OnName num="daigo"]
Chloe, you're not following me?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe062"]
[OnName num="chloe"]
If Daigo-sama says so. I will accompany you.
[cpg cn=true]


[OnName num="daigo"]
Then follow me. Lily can't leave the castle, can she?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe063"]
[OnName num="chloe"]
That's right. Unlike Lily-sama, I am Daigo-sama's caretaker.
[cpg cn=true]


I'm sure you'll follow me.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城下町』（朝）******************************************************



We headed out with a larger than usual number of escort knights.
[cpg]


I'm sure that if we're going to defeat the bandits, we'll be outnumbered by a half-dozen.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chloe064"]
[OnName num="chloe"]
Daigo-sama, let's head out.
[cpg cn=true]


[OnName num="daigo"]
"Oh, yes. Let the bandits know how much we value them.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************



;//[SE f="se000"]
;//【ＳＥ】『馬車走る』





We headed out on a horse-drawn carriage across the plain. The ride was uncomfortable, but there was nothing else to do at this cultural level.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『平原』（夜）******************************************************





We took two days to reach a village near the bandits' hideout, resting once in a town along the way.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『辺境の村』（昼）******************************************************



Then we arrived at a remote village. Even there, I felt like I was in the running for a job. ......
[cpg]

That's not the goal this time. So I decided to conserve my strength.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『辺境の村』（夜）******************************************************



;//上下に黒帯を入れてください



;//[lbox on]



And the night before I entered the village, I went to ......
[cpg]


The village offered hospitality in its own way. Even though it was country cooking, it was not bad.
[cpg]


A place like an inn was rented out, and the soldiers led by Chloe and me stayed there.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chloe065"]
[OnName num="chloe"]
The bandits seem to have increased their numbers with the money from the sale of the necklace you were wearing.
[cpg cn=true]


[OnName num="daigo"]
So what?　So what?
[cpg cn=true]


Chloe shook her head. I wasn't going to turn back now.
[cpg]

;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『平原』（昼）******************************************************





And I was going to go further from there.
[cpg]


I wasn't even going to go out there, but I was still heading there.
[cpg]


And then I see the bandits' hideout, a cave-like place.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『洞窟』（昼）******************************************************





[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Chloe066"]
[OnName num="chloe"]
Daigo-sama, it is dangerous from here. I think Daigo-sama and I should wait around here.
[cpg cn=true]


[OnName num="daigo"]
"Oh, yes. Yes, that's right.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


So the battle began quietly.
[cpg]



[SE f="se015"]
;//【ＳＥ】『剣戟』



[free time=1000]



The number of soldiers on our side was considerable. However, if there were more bandits, it would be a different story.
[cpg]


Or if they were setting ...... traps.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『洞窟』（昼）******************************************************



And my hunch came true.
[cpg]


[OnName num="female_soldier_A"]
"Captain!　No more ......."
[cpg cn=true]



[OnName num="female_soldier_B"]
I understand your feelings, but please remain calm!
[cpg cn=true]


The number of wounded is increasing. It seemed that they had reached the point where they could not attack any further.
[cpg]


The bandits, though they are bandits, seem to be not without thought, and are quite cunning.
[cpg]


[free time=1000]


A certain person appeared before the exhausted soldiers.
[cpg]


[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="captain"]
"Oh, you are ......!　Martina.
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Martina001"]
[OnName num="martina"]
Are you the general?　I'm sorry, but our lives are at stake here.
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Martina002"]
[OnName num="martina"]
I'm sorry, but my life is on the line too. If you don't, I'm going to kill you.
[cpg cn=true]


The woman called Martina was a picture of a female bandit.
[cpg]



[OnName num="daigo"]
......, we're leaving.
[cpg cn=true]


[OnName num="captain"]
But ......!
[cpg cn=true]


[OnName num="daigo"]
It's all right. You better run."
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************



There was still plenty of strength on the other side. If Martina had fallen back, she would have been forced to fight another slow battle.
[cpg]


[OnName num="daigo"]
We didn't have enough soldiers," she said. We should return to the castle.
[cpg cn=true]

The captain looked regretful, but Chloe followed up.
[cpg]

[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe067"]
[OnName num="chloe"]
'It is also my responsibility as Prime Minister. I am sorry.
[cpg cn=true]


[OnName num="daigo"]
'Not at all.
[cpg cn=true]


I didn't dare argue with that. It would give me an excuse to do something for Chloe. ......
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『城下町』（夜）******************************************************





And again, we return to the castle.
[cpg]


By then, the soldiers were too tired to go into battle right away like this.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夜）******************************************************



[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Lily085"]
[OnName num="lily"]
'...... I see. I didn't realize the bandits had grown so powerful."
[cpg cn=true]


He said he was heading to Lily's place to report, so I was following him.
[cpg]



Chloe apologized for underestimating the enemy.
[cpg]


The more soldiers we send to defeat them, the thinner the castle will be.
[cpg]


It was something that had to be done, I suppose, but I couldn't let the pretext slip away.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Lily086"]
[OnName num="lily"]
I'm not angry. I'm not angry.
[cpg cn=true]


[OnName num="daigo"]
I'm angry, Chloe. I'm angry at you, Chloe.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe068"]
[OnName num="chloe"]
I know you are.
[cpg cn=true]




;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（昼）******************************************************





[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe069"]
[OnName num="chloe"]
What are you ...... doing in a place like this?
[cpg cn=true]


[OnName num="daigo"]
I told you. I'm punishing you."
[cpg cn=true]


I said, and then I ordered Chloe.
[cpg]


[OnName num="daigo"]
"Let me see you sit there."
[cpg cn=true]



;//========================================
;//●ＣＧエロ（足を開いて、座り込んでいるヒロイン）ev_11
;//人物１：ヒロイン２
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：城内＿地下室
;//時間　：夜
;//備考　：02.bmpのシーンです
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_11_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="Chloe070"]
[OnName num="chloe"]
'......I hope that's all right.'
[cpg cn=true]


......I'd like to make her look more humiliating, but, well, that doesn't have to be now.
[cpg]

[OnName num="daigo"]
Good." "Good. Then tell me whose judgment was wrong this time."
[cpg cn=true]


[VOICE f="Chloe071"]
[OnName num="chloe"]
"I spared ...... the troops, and this is what happened.
[cpg cn=true]


[OnName num="daigo"]
......"
[cpg cn=true]


I wonder if Chloe knows what I'm trying to do.
[cpg]

This is a kind of punishment, but it's also a kind of role play.
[cpg]

[OnName num="daigo"]
Can't you say it in a more flirtatious way?"
[cpg cn=true]


[VOICE f="Chloe072"]
[OnName num="chloe"]
'I don't understand ...... if you say flirtatious.'
[cpg cn=true]


But whether Chloe knew it or not, it seemed that she couldn't ask for more.
[cpg]

Well, I guess that means he's a hard man to the end of the line. That's a good thing.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





[OnName num="daigo"]
Well, and ......."
[cpg cn=true]


I went back to my room after that, and someone asked me.
[cpg]



[SE f="se009"]
;//【ＳＥ】『ノック』





[OnName num="daigo"]
"Hmm?　Who is it?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily087"]
[OnName num="lily"]
"It's Lily. ...... Well, I've been thinking about it since then. ......"
[cpg cn=true]


You thought about it?　I wondered what he was talking about.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily088"]
[OnName num="lily"]
I'm desperately short of soldiers. We can't leave the castle so short when we go to kill the bandits.
[cpg cn=true]


[OnName num="daigo"]
So?　You sound as if you have some strange idea.
[cpg cn=true]


Lily nodded. Lily nodded and continued.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily089"]
[OnName num="lily"]
;//「街の人に、その……大吾様から直接、戦いに加わるように言ってくれませんか？」
"Could you tell the people of the city to join the fight directly from that ...... Daigo-dono?"
[cpg cn=true]


[OnName num="daigo"]
......."
[cpg cn=true]


It was completely up to me, but it seemed like an effective strategy.
[cpg]


The other party is also a woman. If so, ordinary people would be a force to be reckoned with.
[cpg]


[OnName num="daigo"]
It's a strange world, isn't it? ......
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily090"]
[OnName num="lily"]
If it's all right with you, Daigo-dono, please think about it.
[cpg cn=true]


[OnName num="daigo"]
Oh, I understand. I understand.
[cpg cn=true]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





And then, after dawn.
[cpg]


I decided to do what Lily told me to do yesterday.
[cpg]

[OnName num="daigo"]
"Hey, you. Hey, you guys.
[cpg cn=true]


[OnName num="woman_A"]
Yes, sir!
[cpg cn=true]


[OnName num="woman_B"]
Daigo-sama personally ...... what is it?
[cpg cn=true]


[OnName num="daigo"]
I have an order, or rather, a favor to ask of you, and that is to join ...... the battle.
[cpg cn=true]


[OnName num="woman_A"]
A battle, sir?
[cpg cn=true]


[OnName num="daigo"]
"Oh, yes. We desperately need more soldiers to take down the bandits."
[cpg cn=true]


[OnName num="woman_B"]
"Oh no,...... I've never held a sword,.......
[cpg cn=true]


[OnName num="daigo"]
I've never held a sword before.　Then this is the end of the story.
[cpg cn=true]


[OnName num="woman_B"]
No, no!　I'll do it. I'll do anything.
[cpg cn=true]


Most of them were on board. They wanted to have a connection with me.
[cpg]

They all wanted children so badly. I took advantage of that and increased my strength.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************



Then they headed back to the bandits' hideout.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Chloe073"]
[OnName num="chloe"]
If there are this many of them, ...... we should be able to get rid of the bandits this time.
[cpg cn=true]


[OnName num="daigo"]
If we lose this time, we will be defeated again. If we lose this time too, there is nothing we can do.
[cpg cn=true]



Nevertheless, it is hard to imagine that the bandits we saw the other day are even more numerous.
[cpg]

Even if they sold that necklace, there is a limit.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『辺境の村』（夜）******************************************************





Then we reach a village on the way.
[cpg]


It is already nighttime, and there are civilians mixed in. Considering everyone is exhausted, I decide to rest here.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





But ...... first I attacked the bandits' hideout, then I went back to the castle and called out to the women to get them on my side ......
[cpg]


And then we came back again. I guess the bottom line is that we took too long.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『洞窟』（昼）******************************************************




There was no one in that place where the bandits should have been.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chloe074"]
[OnName num="chloe"]
'...... this is not good.'
[cpg cn=true]


[OnName num="daigo"]
Oh. Maybe they are attacking the castle town. ......
[cpg cn=true]


There are still some soldiers left. Even if it is not enough to invade the castle,......
[cpg]


There was a good chance that they were looting the castle town.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『平原』（夕方）******************************************************





We were back on the plains again. I had a bad feeling growing inside my chest.
[cpg]


Even if they don't invade the castle, it could happen just before the castle. In other words, ......
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夜）******************************************************





[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Lily091"]
[OnName num="lily"]
Oh, you're back, Daigo-dono ......!
[cpg cn=true]


[OnName num="daigo"]
What happened to the bandits? There was no one in that cave.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily092"]
[OnName num="lily"]
They came to ...... the castle town and kidnapped Charlotte.
[cpg cn=true]


Charlotte. I see. ......
[cpg]


;//＠俺の精液を持っていた相手。俺が何か思いを寄せていると判断されてもおかしくない。
The one who had my necklace. It could be determined that I have some feelings for her.
[cpg]


They must have thought I was good enough as a hostage.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





The situation from then on was not good.
[cpg]


The bandits led by Martina naturally wanted me.
[cpg]


The emissary of the bandits said they wanted to exchange me for Charlotte.
[cpg]


If I didn't agree to it, they said they would torture Charlotte and then kill her. ......
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]


[OnName num="daigo"]
You failed ......."
[cpg cn=true]


To begin with, I think I have more of a fighting edge than the average woman, however, I am flesh and blood.
[cpg]


I'm not talking about being able to use special magic or being a master of swordsmanship at all.
[cpg]


[OnName num="daigo"]
Lily, what do you have in mind? Do you have any bright ideas?
[cpg cn=true]

[FG f="CHA01_p2_01_a.ui" method="change_4"  pos="1/2" time=800]
Lily shakes her head. Or we could go head-to-head and fight again.
[cpg]



If they have hostages and are demanding to take us into custody, there is no doubt where they are holding their position.
[cpg]


This means that we may be able to bring the whole force to bear.
[cpg]


However, ...... they are cunning people. They have been played for tricks all this time.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe075"]
[OnName num="chloe"]
...... I have a little idea what they are up to.
[cpg cn=true]


[OnName num="daigo"]
Really?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe076"]
[OnName num="chloe"]
How about enlisting the help of the elves? They may have access to magic we don't. ......
[cpg cn=true]


Elves. Apparently, there are such people.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************





The life span of an elf is nearly ten times longer than that of a human being, and because of the effects of the plague, there are only women.
[cpg]


However, the probability of conceiving a child is much lower than humans. Therefore, they did not reproduce more than humans.
[cpg]


They have the wisdom of having lived for a long time and are skilled in magic to deal with bandits. ......
[cpg]


I visited the elves with Chloe and the soldier escort to see if they might be able to help.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（夕方）******************************************************





The area was a forest covered with trees. There was indeed a person who seemed to be an elf living there.
[cpg]


They seemed to be wary of us. There might have been some historical quarrel or something.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy001"]
[OnName num="daisy"]
How do you do? I am Daisy ......, head of the elves.
[cpg cn=true]


The elf who introduced herself as Daisy was a calm and composed woman.
[cpg]


Chloe also bowed her head and introduced herself.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy002"]
[OnName num="daisy"]
The newly summoned man is you, right?
[cpg cn=true]


[OnName num="daigo"]
Yes, you know my name, don't you?
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy003"]
[OnName num="daisy"]
Yes, Daigo-sama. Daigo-sama ......, right? I've heard of you.
[cpg cn=true]


The only man in the world who didn't seem upset to be standing in front of me.
[cpg]


[OnName num="daigo"]
Did you hear how the bandits were behaving just now?
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy004"]
[OnName num="daisy"]
Of course. That's why you're here.
[cpg cn=true]


[OnName num="daigo"]
I'm glad you're here so quickly. I'm glad you're here. I need your wisdom.
[cpg cn=true]


Of course, from Daisy's point of view, there was no reason to help us.
[cpg]


There was only one thing for us to negotiate. I am what I am.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy005"]
[OnName num="daisy"]
You know as well as I do that if ...... you want it, I want the child.
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Daisy006"]
[OnName num="daisy"]
We are struggling to leave our tribe behind. You understand that, don't you?"
[cpg cn=true]


[OnName num="daigo"]
'...... what exactly do you want?
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Daisy007"]
[OnName num="daisy"]
I want us elves to stay in the forest.
[cpg cn=true]


[OnName num="daigo"]
Things are getting a little tense at the moment, though."
[cpg cn=true]


Daisy still persisted.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Daisy008"]
[OnName num="daisy"]
Please," Daisy persisted. Do it for our own good.
[cpg cn=true]


That's not going to work. Humans would argue the same thing.
[cpg]


But in exchange for Charlotte's life, I don't know. ......
[cpg]


[OnName num="daigo"]
I understand. Then I'll stay a little while.
[cpg cn=true]


[OnName num="daigo"]
But I can't stay too long. I'm talking about staying in this house.
[cpg cn=true]


[OnName num="daigo"]
That's good enough for you personally, isn't it?"
[cpg cn=true]


Daisy was not convinced. She might still be up to something.
[cpg]


But in the end, she nodded her head.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（夜）******************************************************





Then night. Chloe and the soldiers who had come to escort her were tired and asleep.
[cpg]



;//========================================
;//●ＣＧ非エロ（泉で身を清めているヒロイン。主人公が見ているのを知って、少し恥ずかしそう。月明かりに照らされている）ev_13
;//人物１：ヒロイン６
;//服装１：水着
;//場所　：森の中の泉
;//時間　：夜
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_13_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=100]


Daisy invited me to a spring in the forest.
[cpg]


[VOICE f="Daisy009"]
[OnName num="daisy"]
"This fountain is special. Of course, some people wonder how effective this kind of wishful thinking is."
[cpg cn=true]


[OnName num="daigo"]
...... isn't it cold?
[cpg cn=true]



[VOICE f="Daisy010"]
[OnName num="daisy"]
You should try to touch the water.
[cpg cn=true]


When I touched it, it was indeed strangely warm. I touched the water, and it was indeed strangely warm.
[cpg]


There was one more thing that caught my attention.
[cpg]


[OnName num="daigo"]
Your face is red. If you have a longer life span than humans, you must have met a man before.
[cpg cn=true]



[VOICE f="Daisy011"]
[OnName num="daisy"]
I've never been stared at by a man before.
[cpg cn=true]


I've never been stared at by a man before. I was surprised. I thought that since she was the chief, she must have had a child.
[cpg]



[VOICE f="Daisy012"]
[OnName num="daisy"]
I just became ...... chief. I've been waiting for this day to come.
[cpg cn=true]





[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（夜）******************************************************


I guess Daisy's way of approaching me was to introduce me to this place.
[cpg]

How could I not respond?
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（昼）******************************************************





And then, one night later in the Elven Forest, "Since then," she said, "I've been going to  in my own way.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="1/2" time=800]

[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Daisy013"]
[OnName num="daisy"]
Since then,...... I've been trying to come up with my own effective way to get rid of the bandits.
[cpg cn=true]



[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Daisy014"]
[OnName num="daisy"]
I think this stone will be the most effective. Use it.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Chloe077"]
[OnName num="chloe"]
What is this ......?"
[cpg cn=true]


Chloe had never seen one before and asked Daisy about it.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Daisy015"]
[OnName num="daisy"]
Chloe had never seen it before and asked Daisy about it. It has a power similar to that of the plague.
[cpg cn=true]


When the stone is crushed, all women within a certain radius around it will fall asleep," she said.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Daisy016"]
[OnName num="daisy"]
It has no effect on men. It's the opposite of the plague.
[cpg cn=true]


[OnName num="daigo"]
With this, ...... I can do whatever I want while the bandits are asleep?
[cpg cn=true]


It's as useful as it gets. Of course, if there is no man over here, it will have no effect at all.
[cpg]


On the other hand, if there is a man on the other side, it has no effect. But I am the only man in this world.
[cpg]


[OnName num="daigo"]
I owe you. Then, I'll take it.
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="Daisy017"]
[OnName num="daisy"]
"Yes. If you ever need anything else, please come to me.
[cpg cn=true]


Daisy blushed a little as she said this.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************




[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]


[OnName num="escort"]
"And by the way, ...... that elf Daisy ......?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe078"]
[OnName num="chloe"]
She was in love with Daigo-sama. She was in love with Daigo-sama, wasn't she?
[cpg cn=true]



[OnName num="daigo"]
"Hmm?　What did you say?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chloe079"]
[OnName num="chloe"]
No. I was talking about this.
[cpg cn=true]


I'm kind of curious. Aside from that, I've got what I need.
[cpg]


I can go to Martina's as soon as possible. It's a time-sensitive situation, that's for sure.
[cpg]


[jump storage="ep002.ks" target="*start"]


;//////////////////////////////////////////////////////////////////
