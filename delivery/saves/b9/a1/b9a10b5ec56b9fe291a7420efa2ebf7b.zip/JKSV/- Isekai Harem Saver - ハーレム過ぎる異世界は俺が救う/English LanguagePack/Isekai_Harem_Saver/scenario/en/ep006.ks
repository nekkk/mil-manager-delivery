
*start


;#################################################
*Ep006|Make Daisy Your Own
;#################################################


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************



*select05_3|Make Daisy your own.

[SCENE id=6]


I don't care what happens to this world. Daisy is the one who holds the trump card to get rid of the plague.
[cpg]


As long as Daisy is dropped, I'll be saved.
[cpg]


Then there's nothing else to think about.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************



I decided to take Chloe to the Elven Forest.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe136"]
[OnName num="chloe"]
What is your business in the Elven Forest, ......?
[cpg cn=true]


Of course, I had to come up with a reason to convince Chloe. So, I asked her.
[cpg]


[OnName num="daigo"]
I wanted to ask Daisy about what Martina had said about the possibility of women getting pregnant with each other.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Chloe137"]
[OnName num="chloe"]
I don't have a choice, then. It is true that when it comes to magic, we are better than humans.
[cpg cn=true]


She agreed. We were a bunch of pussies.
[cpg]


And then we set off for the elven forest.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************



We were being rocked by a horse-drawn carriage. I wanted to get to the elven forest right away, but at this level of civilization, it takes a long time to get there.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（夜）******************************************************





We reached the elven forest around nightfall.
[cpg]


[OnName num="daigo"]
It's been a long time, Daisy.
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy047"]
[OnName num="daisy"]
"Yes. What can I do for you?
[cpg cn=true]



[OnName num="daigo"]
I have a question. A bandit named Martina told me about ......
[cpg cn=true]


[OnName num="daigo"]
She said the two women got pregnant. Is there any place where that could happen?
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy048"]
[OnName num="daisy"]
I can't say that it doesn't. But ......
[cpg cn=true]


Daisy said that it is difficult to pinpoint the place where the phenomenon occurs.
[cpg]


But if Martina says it's true, then there's a good chance it's true, she said.
[cpg]


[OnName num="daigo"]
......"
[cpg cn=true]


Should we start working on getting the truth from Martina now?
[cpg]


No, no. We can't do that now.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy049"]
[OnName num="daisy"]
It's late. Stay the night.
[cpg cn=true]


I didn't have to go through all that trouble, I just had to get her to go along with it.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





That night, I made my way to the cabin where Daisy slept.
[cpg]


[FG f="CHA06_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Daisy050"]
[OnName num="daisy"]
I said, "Hmmm........., what?"
[cpg cn=true]


[OnName num="daigo"]
I'm glad you told me about Martina. This is for you.
[cpg cn=true]


[FG f="CHA06_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Daisy051"]
[OnName num="daisy"]
What are you talking about ......?　Don't do that.
[cpg cn=true]


I said, "Don't do it," but she couldn't refuse.
[cpg]


[FG f="CHA06_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Daisy052"]
[OnName num="daisy"]
I'm saying stop, but she can't refuse. "Okay, okay, ......!　Wait a minute."
[cpg cn=true]


;//移植のためシーンをカットしています

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（朝）******************************************************



The next day, after all that had happened. I had ostensibly completed my business.
[cpg]

The guards ask me if I'm coming back, but I ......
[cpg]


[OnName num="daigo"]
I said, "No, wait a minute.
[cpg cn=true]


I couldn't go back here.
[cpg]


Daisy was the objective this time. As the chief of the elves, if I can't manipulate her to do what I want, I won't be able to accomplish my goal.
[cpg]


[OnName num="daigo"]
"Daisy. I want you to be part of the investigation.
[cpg cn=true]


[free time=1000]

[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy053"]
[OnName num="daisy"]
"...... me?　I don't mind, but ...... another elf would be better.
[cpg cn=true]


[OnName num="daigo"]
Another elf is fine, but are you okay with that?
[cpg cn=true]


Daisy wanted a child too, how could she say no?
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************





And then we were back on the wagon again. One more person than on the way there, but it didn't matter much.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Daisy054"]
[OnName num="daisy"]
I can't believe you asked me out. ...... I wonder if you like me that much."
[cpg cn=true]


I don't think Daisy is unaware of my intentions either.
[cpg]


But either way, it was the same thing I was going to do.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夕方）******************************************************





We walk back to town. Daisy is swaying around.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy055"]
[OnName num="daisy"]
Really, people's cultures are ...... frighteningly dizzying, aren't they?
[cpg cn=true]


She and the others probably get that impression because of the difference in life expectancy.
[cpg]


[OnName num="daigo"]
Even this is a lower level of culture than the world I used to live in.
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy056"]
[OnName num="daisy"]
Is that so ......?　I wonder if magic is more advanced in your world.
[cpg cn=true]


It's like magic. It's like magic, from the point of view of today's world.
[cpg]

[free time=1000]


[OnName num="daigo"]
Well, let's get to the castle then. Chloe, will you make room for Daisy?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe138"]
[OnName num="chloe"]
Yes, sir.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Now let's see what we can do. It's good that you lured Daisy here.
[cpg]


But we will really have to head to the investigation.
[cpg]


We'll have to give Chloe a reason, too. Otherwise, it would be difficult to keep Daisy here.
[cpg]



[SE f="se009"]
;//【ＳＥ】『ノック』





Just then, I heard a knock on the door.
[cpg]


[OnName num="daigo"]
It was the door. You may come in."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily132"]
[OnName num="lily"]
"Daigo-dono,......, I hear you invited Daisy to the castle."
[cpg cn=true]


[OnName num="daigo"]
Yes. Nothing wrong with that, is there?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily133"]
[OnName num="lily"]
Yes, there is, but don't forget ...... that you were summoned by a human, not an elf. You were summoned by a human, not an elf.
[cpg cn=true]



The actuality is, you can't just go out and buy a new one. I will not make a difference.
[cpg]


[OnName num="daigo"]
I'm not going to make a difference. I will do what I have to do.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily134"]
[OnName num="lily"]
"Then that's good. ......
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





Well. I'm going to drop Daisy right away.
[cpg]


I was calling Daisy through the maid of honor.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy057"]
[OnName num="daisy"]
You're already going to investigate?　You're being quick.
[cpg cn=true]


[OnName num="daigo"]
You're the one who's quick-tempered. Since you've come all the way to the castle, you'll have to stay by my side.
[cpg cn=true]


Daisy didn't look very happy.
[cpg]

But I can't say I don't like it. I'm the only man in the world.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************



If I kept on calling her, she might not be able to be without me one day.
[cpg]


What an expectation, I thought, would turn into an expectation that she would exorcise my plague.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



And as soon as I got back to the castle, Lily called me up.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夕方）******************************************************



;//＠

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily135"]
[OnName num="lily"]
;//「デイジーに入れ込んでいるようですね。大吾様」
'I see you're getting into Daisy. Daigo-dono.
[cpg cn=true]


[OnName num="daigo"]
Oh. Is that bad?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily136"]
[OnName num="lily"]
It's not right to be so attached to one woman.
[cpg cn=true]


[OnName num="daigo"]
You didn't refuse Lily and her friends' request. You didn't refuse Lily and her friends' request, so it shouldn't be a problem.
[cpg cn=true]


Lily seemed dissatisfied with my words.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily137"]
[OnName num="lily"]
"It's not that easy. There are plenty of people who want you."
[cpg cn=true]


[OnName num="daigo"]
I'm a human being, too, and we're not all equal.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily138"]
[OnName num="lily"]
So let me ask you,...... do you like Daisy?
[cpg cn=true]


If you're asking me if I like ......, I'm not sure.
[cpg]


If I didn't like her, I don't think I would have chosen to drop Daisy.
[cpg]



Did you not do so because you ...... unconsciously like Daisy?
[cpg]


No, whatever. It doesn't make much difference how you answer here.
[cpg]


[OnName num="daigo"]
It doesn't matter."
[cpg cn=true]


I told her that, and Lily didn't say anything more.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I think to myself. About Daisy. Lily's words were the catalyst.
[cpg]


Do I love her? I think I probably do, but ......
[cpg]


I can't sort out my feelings. I know that if I don't drop her, I won't be able to exorcise my plague.
[cpg]


I still have to train her and make her mine.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





And then morning comes again.
[cpg]


As planned, we were to head for the ruins of the site.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily139"]
[OnName num="lily"]
Daigo-dono. We are ready to leave.
[cpg cn=true]


[OnName num="daigo"]
"Yes, I'm coming. I'm on my way.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Daisy was the one who made me stay by her side during the ride in the carriage.
[cpg]

She might be trying to find out my true intentions.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************




[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

We had arrived at the temple ruins. I wonder if Daisy is feeling anything.
[cpg]


[OnName num="daigo"]
What do you think, Daisy?
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Daisy058"]
[OnName num="daisy"]
"Yeah, ......, it's like some kind of magical singularity.
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Daisy059"]
[OnName num="daisy"]
I guess you could call it the power to conceive a child. ...... It's also possible that the two women could be pregnant. ......
[cpg cn=true]


I can't get anything definite out of him. But that's okay.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Chloe139"]
[OnName num="chloe"]
"So in the end, nothing is certain?"
[cpg cn=true]


[OnName num="daigo"]
"Well, well, well. You can't know everything because you're an elf. Don't be so hard on yourself."
[cpg cn=true]


[OnName num="daigo"]
If it's more ...... about the power to conceive a child, then it doesn't have to be between women."
[cpg cn=true]


I said this to Daisy and she rolled her eyes.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Daisy060"]
[OnName num="daisy"]
She said, "What?　What do you mean ......?"
[cpg cn=true]


I meant exactly what I said, but Daisy didn't seem to understand.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


We were to stay near the temple site for a while to investigate.
[cpg]

During the night, I brought Daisy to the temple site ......
[cpg]



[FG f="CHA06_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Daisy061"]
[OnName num="daisy"]
'...... what are you going to do in such a sacred place?
[cpg cn=true]


[OnName num="daigo"]
'Just what I told you during the day.'
[cpg cn=true]


I said and pressed her.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************



[FG f="CHA06_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy062"]
[OnName num="daisy"]
'...... when are they going to finish their investigation and send us back to the elven forest?
[cpg cn=true]


[OnName num="daigo"]
I doubt it. I think you want to stay here too.
[cpg cn=true]


Daisy is silent as she says, "That's not true. I guess so.
[cpg]


[FG f="CHA06_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy063"]
[OnName num="daisy"]
I think I'm pregnant. I think it would be a shame for you to love only me anymore.
[cpg cn=true]


[OnName num="daigo"]
That's great," she said. You like me even more now, don't you?"
[cpg cn=true]


Daisy didn't laugh or get angry at my lighthearted comment.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************



She cares about me, that's for sure. There was no doubt about that.
[cpg]

From here, I think it's just a matter of when to start talking. She wouldn't want to lose me now.
[cpg]


If that's the case, then maybe I should just tell her already.
[cpg]


In other words, exorcise the plague. ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





Still, I was being somewhat cautious.
[cpg]


I had to bond with Daisy more.
[cpg]


Definitely, I should cut it out when I was in a situation where she was really going to save me.
[cpg]


Otherwise, it would be obvious that I approached her for that purpose.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Chloe140"]
[OnName num="chloe"]
Good morning." Daigo-sama,...... and Daisy."
[cpg cn=true]


[FG f="CHA06_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Daisy064"]
[OnName num="daisy"]
'Hmm ...... good morning ......'
[cpg cn=true]


Daisy was allowed to live in my room.
[cpg]


With my authority, that much was possible.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（朝）******************************************************





[OnName num="daigo"]
"Who are you going to visit today?"
[cpg cn=true]


I asked Chloe. I couldn't take Daisy out this time of night.
[cpg]


It might make her jealous, I thought. ......
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte104"]
[OnName num="charlotte"]
I said, "Hey, big brother. Long time no see."
[cpg cn=true]


By chance, I met Charlotte, who was out walking.
[cpg]


[OnName num="daigo"]
She said, "Oh, Charlotte. Haven't seen you around lately."
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte105"]
[OnName num="charlotte"]
I'm telling you the truth,......, you don't like me anymore.
[cpg cn=true]


[OnName num="daigo"]
I'm sorry, but I'm not in the mood for this right now."
[cpg cn=true]


Charlotte seems unhappy, but I have to do what I have to do.
[cpg]


To save my life. This was necessary.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte106"]
[OnName num="charlotte"]
I've heard rumors. You're living with Daisy, the elf.
[cpg cn=true]


[OnName num="daigo"]
......Who told you?"
[cpg cn=true]


I looked at Chloe. She answered.
[cpg]


[free time=1000]

[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Chloe141"]
[OnName num="chloe"]
I didn't tell you. I guess you can't put words in people's mouths.
[cpg cn=true]


[OnName num="daigo"]
'I don't see why not. ......
[cpg cn=true]


I hope Daisy doesn't get the wrong end of the stick.
[cpg]


But no matter what I think, I'm still going to do what I'm going to do.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夕方）******************************************************





I've done my part for the day and I'm heading back to the castle, back to Daisy.
[cpg]


On the way, Chloe asks me, "Daigo-sama.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe142"]
[OnName num="chloe"]
Daigo-sama. What do you think about Daisy?
[cpg cn=true]


[OnName num="daigo"]
I told you before. I told you before, didn't I tell Lily?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chloe143"]
[OnName num="chloe"]
Don't be silly. You obviously have a special interest in Daisy.
[cpg cn=true]


I can't deny that now. But ......
[cpg]


[OnName num="daigo"]
I don't see why you should be offended.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe144"]
[OnName num="chloe"]
"It doesn't work that way. The world is full of people looking for you."
[cpg cn=true]


;//「……好きな人を抱いて何が悪い。それを止められる筋合いはない」
[OnName num="daigo"]
"...... what's wrong with wanting to be with someone you love. There is no reason for you to stop me from doing so.
[cpg cn=true]


I felt my mind was made up as I put it into words.
[cpg]


I still love Daisy. That's why I didn't choose Charlotte or Martina.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





[FG f="CHA06_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Daisy065"]
[OnName num="daisy"]
I said, "Welcome back to ......, Daigo-sama. Daigo-sama."
[cpg cn=true]


Her belly was getting bigger day by day.
[cpg]


Our purpose was different at first. But the thought of having a child with her makes me feel ...... indescribable.
[cpg]


This must be love or something like that.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I look at Daisy, who is completely caged up, and I think.
[cpg]


Would you ask her now to exorcise the plague and would she do it?
[cpg]


She said it was a once-in-a-century feat of magic. That means she can't do it alone.
[cpg]


She would have to convince all the elves.
[cpg]


Even so, Daisy is a powerful woman among the elves, and I wondered if she would be willing to lie to everyone.
[cpg]


I'll have to make a plan for that, too.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************



[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]

The next morning. I made my first move on Daisy.
[cpg]


[OnName num="daigo"]
Hey, Daisy. I heard you said you have a great spell that can exorcise pestilence. ...... Will you use it on me?"
[cpg cn=true]


I cut him off frankly. There was no bargaining.
[cpg]


But I was confident that it would be all right.
[cpg]


I knew that it would be hard for Daisy to see me die.
[cpg]


[FG f="CHA06_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy066"]
[OnName num="daisy"]
"That's not something I can do on my own. ......
[cpg cn=true]


[OnName num="daigo"]
"Can I convince someone else to do it?　Could I convince another elf to do it?
[cpg cn=true]


[FG f="CHA06_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy067"]
[OnName num="daisy"]
If ...... they would live in the elf forest for a while and bear children for us."
[cpg cn=true]


The conditions are quite loose. Nothing reckless was said.
[cpg]


Lily and Chloe would probably object, but they wouldn't be forced to do so.
[cpg]


As far as I was concerned, I didn't care if the elves and humans had a beef or not.
[cpg]


As long as my life is saved, that's all that matters. ......
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『平原』（朝）******************************************************



I decided to escape from the castle. I could handle the guards.
[cpg]


The problem was that Lily and Chloe would notice.
[cpg]


They would be looking for me. If Daisy had disappeared with me, it was only natural that she would suspect the Elven Forest.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



But that was okay. Once the plague was purged from my body, I didn't care what happened to the rest.
[cpg]


I would follow Lily and Chloe. I'm ready for that.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（朝）******************************************************



[OnName num="elf_A"]
"Dear Daisy, ......!　I'm so glad you're finally home.
[cpg cn=true]


[OnName num="elf_B"]
I was so worried. What have you been up to?
[cpg cn=true]


[FG f="CHA06_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy068"]
[OnName num="daisy"]
......, thanks for keeping us waiting so long, guys.
[cpg cn=true]


I've been here a little too long for the reason that I've been out investigating the temple ruins.
[cpg]


But that's okay. I'm glad you're all here.
[cpg]


[FG f="CHA06_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy069"]
[OnName num="daisy"]
I need to talk to you all about something. I'm going to purge the plague from Daigo-sama's body."
[cpg cn=true]


[OnName num="elf_A"]
"Oh, ......?　Why is that ......?
[cpg cn=true]


[OnName num="elf_B"]
Is it that he is worthy of that great magic?
[cpg cn=true]


[FG f="CHA06_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Daisy070"]
[OnName num="daisy"]
He says he sides with the elves, not the humans.
[cpg cn=true]


[OnName num="elf_A"]
"Is that ...... that he will do everything in his power to help us prosper, not ...... humans?"
[cpg cn=true]


I didn't say that much. But Daisy's own ingenuity must have been used.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



From there, Daisy gathered the elves and told them how much they needed me.
[cpg]


Some of the elves were a bit apprehensive, but I guess Daisy was originally a smart and trustworthy person.
[cpg]


Most of the elves seemed to be willing to work for me.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（夜）******************************************************





And then, in the elven forest, in the hut.
[cpg]

;//ブラックアウト

;//========================================
;//●ＣＧエロ（ベッドに座ってほおを染めるヒロイン。主人公の姿はない）ev_49
;//人物１：ヒロイン６
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：エルフの森＿小屋の中
;//時間　：夜
;//備考　：ヒロインは妊娠六ヶ月くらいです
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_49_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=100]

[OnName num="daigo"]
'Thanks for the trouble, Daisy. Daisy.
[cpg cn=true]


[VOICE f="Daisy071"]
[OnName num="daisy"]
No, I did it for you. I'll do ...... anything for you.
[cpg cn=true]


I have to reward her, too. I gotta love her.
[cpg]


[OnName num="daigo"]
I love you.
[cpg cn=true]


;**【ＣＧ】 ev_49_a ***********************
[CG id=14 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Daisy072"]
[OnName num="daisy"]
"...... me too."
[cpg cn=true]

Whatever I do, Daisy will be happy. She's mine now.
[cpg]

[VOICE f="Daisy073"]
[OnName num="daisy"]
I want her by my side forever. ......
[cpg cn=true]


[OnName num="daigo"]
I promise. I promise."
[cpg cn=true]



;//移植のためシーンをカットしています


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（夜）******************************************************



And the night goes on. In the meantime, the preparation of the magic formula is in progress.
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（朝）******************************************************




A huge magic circle was drawn. It seemed that not even the slightest deviation would be tolerated.
[cpg]


[OnName num="elf_A"]
But what did ...... Daisy-sama find so valuable in him that she would use a magic formula on him?
[cpg cn=true]


[OnName num="elf_B"]
Shush. It's rude to even question it.
[cpg cn=true]


[OnName num="elf_A"]
"I'm inclined to doubt it. Maybe Lady Daisy is just in love with him. ......"
[cpg cn=true]


I was eavesdropping. And I'm usually right on the money with that.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（昼）******************************************************





After a while, Lily came in, as I thought she might.
[cpg]


She would know right away that I was missing, and she would have guessed it from my obsession with Daisy.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Lily140"]
[OnName num="lily"]
"I've been looking for you, Daigo-dono ......!　I can't have you suddenly disappear."
[cpg cn=true]


[OnName num="daigo"]
So what?　Are you going to bring me back?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily141"]
[OnName num="lily"]
Of course!　If I've come this far, I'll bring you back, even if it's by force.
[cpg cn=true]


[OnName num="daigo"]
I can't do that. I'm almost finished with the formula.
[cpg cn=true]


Lily seemed to take some time to understand my words.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Lily142"]
[OnName num="lily"]
I don't think you mean ......?
[cpg cn=true]


[OnName num="daigo"]
Lily was a little slow to understand what I was talking about. She is going to use it for me.
[cpg cn=true]


Lily was surprised. She, too, seems to know that this is a once-in-a-century magic.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily143"]
[OnName num="lily"]
I don't think so,.......
[cpg cn=true]


[OnName num="daigo"]
I'm thinking about that too."
[cpg cn=true]


Let's not deny it. The only thing that would make it more difficult is if you deny it.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Lily144"]
[OnName num="lily"]
How can we allow such a thing?　We have no choice but to resort to violent measures.
[cpg cn=true]


[OnName num="daigo"]
"Can we?　If you do that, I'll fight back, no matter what it takes.
[cpg cn=true]


[OnName num="daigo"]
I'm going to die anyway. If you guys forcefully restrain me, I will use any means to get out.
[cpg cn=true]


Lily was silent. In fact, it would be difficult to lock me up completely.
[cpg]


The people who have me locked up can negotiate with any commoner they want.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily145"]
[OnName num="lily"]
...... promise you'll come back to us once the plague is exorcised?"
[cpg cn=true]


I didn't answer. I don't want to make any promises down the road, I'm free to spend my time.
[cpg]



;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（夜）******************************************************



A little time passes from there.
[cpg]

The day came when the formula was completed and the day of the actual activation.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（昼）******************************************************





[FG f="CHA06_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Daisy074"]
[OnName num="daisy"]
'Then I will activate the jutsu formula,...... Daigo-sama, are you ready?
[cpg cn=true]


[OnName num="daigo"]
I feel ...... strange."
[cpg cn=true]


I was lying in the center of a huge magic circle.
[cpg]


I waited for the right moment, wondering if I shouldn't be standing up, or maybe not.
[cpg]


Twelve elves, including Daisy, are standing around the perimeter of the magic circle with mysterious expressions on their faces.
[cpg]


Then they kneel down and put their hands on the ground.
[cpg]



[SE f="se016"]
;//【ＳＥ】『魔法　パッド系の音』



[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1000]
;//ホワイトアウト





Then I realized that I was surrounded by a light so bright that I couldn't see what was in front of me.
[cpg]


I was puzzled, but I somehow knew that if I moved now, it would be even more dangerous.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（昼）******************************************************





[FG f="CHA06_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Daisy075"]
[OnName num="daisy"]
I said to myself, "...... succeeded. Daigo-sama, wake up."
[cpg cn=true]


The light seemed to last for about a minute, but really it could have been shorter.
[cpg]


Then Daisy said it was a success. I didn't see any change in my body, but if she said it was a success, then it must be.
[cpg]


[OnName num="elf_A"]
We did it, Miss Daisy. ...... Now my Elf clan is safe and sound.
[cpg cn=true]


[OnName num="elf_B"]
Yes," he said. All thanks to Miss Daisy's persuasion of him. ...... Miss Daisy?"
[cpg cn=true]


[FG f="CHA06_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy076"]
[OnName num="daisy"]
"Yes, I know. ...... I'm not going to lose you, am I?　Daigo-sama.
[cpg cn=true]


[OnName num="daigo"]
"......Yes."
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



For a while after that, I lived in the elf forest and did what the elves wanted.
[cpg]


However, it soon became boring. The culture is not as developed as in the castle town.
[cpg]


I miss Lily, Chloe, and Charlotte.
[cpg]




[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『平原』（夜）******************************************************





[OnName num="daigo"]
......"
[cpg cn=true]


I had sneaked out of the elven forest.
[cpg]


I already know the ins and outs of elves. There are not as many of them as there are humans.
[cpg]


Even if they could do magic, their numbers would not be enough to make up for it.
[cpg]


If I returned to the human side, the elves would have nothing to do.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（朝）******************************************************





And then, at dawn. I return to the castle town. By chance, I meet Charlotte.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Charlotte107"]
[OnName num="charlotte"]
She says, "What ......?　Is that your brother?
[cpg cn=true]


[OnName num="daigo"]
"Yeah, I'm back from the elven forest. I came back from the elven forest.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte108"]
[OnName num="charlotte"]
I was afraid you wouldn't be coming back here anymore.
[cpg cn=true]


I still like to be in an environment where I can love whom I want as much as I want.
[cpg]


That's all a matter of my personality, I guess.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





It's the opposite of what it used to be. This time, there was an immediate protest from the elf side.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Daisy077"]
[OnName num="daisy"]
"Daigo-sama,......, are you going to abandon us?　We are the elves who saved you.
[cpg cn=true]


[OnName num="daigo"]
It wasn't my intention to get infected with the plague in the first place. This is how it's supposed to be.
[cpg cn=true]


[OnName num="daigo"]
I'd say it's about even, now, wouldn't you?　There is no reason to follow the elves.
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy078"]
[OnName num="daisy"]
"Oh no ......, you don't even think about me anymore?"
[cpg cn=true]


This is hard to answer. But it's true that I've been using you until now.
[cpg]


It was true that I had achieved my goal and lost interest.
[cpg]


[OnName num="daigo"]
"Oh, I don't think about it. I don't think anything of it.
[cpg cn=true]


I dare to be cold. I hope Daisy will give up now.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Daisy079"]
[OnName num="daisy"]
I was glad she loved me, even if it was only for a moment. I'm glad you loved me, even if it was only for a moment.
[cpg cn=true]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





;//それから、代わる代わる女達を抱いていく。
Then he proceeds to have children with all the women, one after the other.
[cpg]


But there is no entertainment as there is today. The essence of his life was essentially the same as when he was in the elven forest.
[cpg]


[OnName num="daigo"]
Hey, Lily," he said, "I'm Chloe. Chloe.
[cpg cn=true]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Chloe145"]
[OnName num="chloe"]
What is it?
[cpg cn=true]


[OnName num="daigo"]
'I'd like to go back to reality now, ...... can you do that?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily146"]
[OnName num="lily"]
'Well, it's ...... going to have to be here for a little while longer still.
[cpg cn=true]



[OnName num="daigo"]
How long exactly is that going to be?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Lily147"]
[OnName num="lily"]
At least one more year. Just one more year is enough for me.
[cpg cn=true]


[OnName num="daigo"]
I see. I see. It's surprisingly short.
[cpg cn=true]


During that time, I'll behave as I like.
[cpg]


I may be bored out of my mind after a year. ...... But I don't know if I want to live in this incomprehensible world for the rest of my life.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夜）******************************************************





The days pass by in a hurry. The days pass by at a frighteningly fast pace.
[cpg]


I long for the day when I can come back to reality......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





Daisy seemed to have been thinking about me for a long time.
[cpg]


But she never approached me positively. I only received information through others.
[cpg]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Time passes. Time passes.
[cpg]


And the day comes. The promised one year has passed.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（昼）******************************************************





[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily148"]
[OnName num="lily"]
"......You're going, by all means, aren't you?"
[cpg cn=true]


[OnName num="daigo"]
Oh, yes. Of course you are, you've been in a world like this for so long, I don't know what I'm going to do.
[cpg cn=true]


Lily looks gloomy. Then she looks up at me.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily149"]
[OnName num="lily"]
"I think it's a dream come true for men," she said.
[cpg cn=true]


She says, "I think it's a dream environment for men. It's hard to answer.
[cpg]


[OnName num="daigo"]
It's a dream come true, and I'm not going to get used to it.
[cpg cn=true]


[OnName num="daigo"]
I've had a lot of fun, but most importantly, I have my family over there.
[cpg cn=true]


What a surprise. I don't have a wife or kids, though.
[cpg]

[free time=1000]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Chloe146"]
[OnName num="chloe"]
'It can't be helped. Your Majesty, I understand your feelings, but ......
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily150"]
[OnName num="lily"]
"......, that's right. Shall we go then?
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Someday, I'll be taken to the same place I was taken to when I came into this world.
[cpg]


It's the same door I came in through then. I can go back to this world again.
[cpg]


[OnName num="daigo"]
......Bye then."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily151"]
[OnName num="lily"]
Yes. Thank you for everything, goodbye ......"
[cpg cn=true]


Daisy never came to the end.
[cpg]


Well, I guess she has her own things to think about. ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se007"]
;//【ＳＥ】『扉開く』


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『現実＿街』（昼）******************************************************








When I opened the door, it was the world I used to be in.
[cpg]


[OnName num="daigo"]
"...... you're back."
[cpg cn=true]


Now, I wonder how I'm going to be treated this past year.
[cpg]


I wonder if I'll be reported missing. And will I still be able to work?
[cpg]


But I had done something that no normal human being would ever experience. I thought I would be able to handle it.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『現実＿街』（夕方）******************************************************





Then I lived in the town for a while and found out that.
[cpg]


Time hasn't passed. I went to that world and spent a year there, but here, almost no time has passed.
[cpg]


It's the opposite of Urashima Taro. A year on the other side of the world is like an hour on this side of the world, or something like that.
[cpg]


[OnName num="daigo"]
...... haha.
[cpg cn=true]


It seemed I could still work in this world. The routine of the past is suddenly back.
[cpg]


I was amazed, but this was exactly what I had been looking for.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Was it a dream? I still can't believe it was a dream.
[cpg]


It was too long to be a dream. And yet, I had no regrets.
[cpg]


Everything was fine. If I had to say, I'm a little worried about Daisy. ......
[cpg]


It's my decision. She's a strong woman and she'll raise the kids without me.
[cpg]


Besides, if I cared about that, I'd have a lot more kids left on the other side of the world.
[cpg]


Don't worry about it. I spent a few days thinking that way.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『現実＿街』（夜）******************************************************





[OnName num="daigo"]
"...... hmm?"
[cpg cn=true]


At first, I thought someone was dressed strangely.
[cpg]


Then I rubbed my eyes, wondering if it might be Daisy.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Daisy080"]
[OnName num="daisy"]
'...... long time no see. Daigo-sama."
[cpg cn=true]


[OnName num="daigo"]
'Are you Daisy or ......?'
[cpg cn=true]


I thought she looked a little different. She seemed to have gone through childbirth and her stomach was back to normal.
[cpg]


Next to her, she had a girl about five years old with her.
[cpg]


Is it my baby?　No, that's ridiculous. It couldn't have been that long ......
[cpg]


I thought, "But the year I spent there was compressed into about an hour.
[cpg]


If that were the case, wouldn't the math rather add up?　No, elves grow slowly and have a long life span.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy081"]
[OnName num="daisy"]
"Look," he said, "there's your father. Here's your father.
[cpg cn=true]


[OnName num="daisy_daughter"]
"...... nice to meet you. I've always wanted to meet you, ...... father.
[cpg cn=true]


[OnName num="daigo"]
"...... how did you get here?"
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Daisy082"]
[OnName num="daisy"]
It was hard work. In principle, it's the same thing that brought you here.
[cpg cn=true]


Sure, I could come back from the other side. Can you apply it?
[cpg]


If so, how many years have passed?
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Daisy083"]
[OnName num="daisy"]
I haven't seen you in a really long time. ...... I'm sorry, I had decided not to cry."
[cpg cn=true]


Daisy's eyes were filled with tears.
[cpg]


[OnName num="daigo"]
'......'
[cpg cn=true]


I once pushed her away. I wonder if I have the right to hold her here and now.
[cpg]


I feel like I don't have ....... Still, I held her body.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Even though I wondered what she was doing in front of her real daughter, I couldn't stop hugging her.
[cpg]


The town at night. In the real town, we met again.
[cpg]


I vaguely thought, "I'm going to have a hard time.
[cpg]


What would happen to Daisy's family register? How would she be educated?
[cpg]


While imagining these things, ...... I somehow felt that we would be able to live happily ever after.
[cpg]

[SCENE id=15]

;//ＥＮＤ　ヒロイン６ルート
[jump storage="epend.ks" target="*start"]

