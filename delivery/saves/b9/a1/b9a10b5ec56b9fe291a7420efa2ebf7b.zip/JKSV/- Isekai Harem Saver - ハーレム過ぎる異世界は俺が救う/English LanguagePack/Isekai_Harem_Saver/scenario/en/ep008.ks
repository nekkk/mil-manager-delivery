
*start

;#################################################
*Ep008|Lily and I will never tie the knot.
;#################################################



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_sl"]
[WAIT time=100]


*VectorGood2|Lily and I will never tie the knot.

[SCENE id=8]


One thought alone would not produce an answer. It wasn't as if the nation would change just because of one thought of mine.
[cpg]


What I could do was limited.
[cpg]


The same is true for Lily. Even though I am the queen, I don't have all the power concentrated in me.
[cpg]


All we want is to be united with each other, but it's not going to happen. ......
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************


;//＠少しの日々が過ぎる。俺が種付けしていった女達は次々とお腹を膨らませていった。
A few days pass. One by one, the women who had been with me grew belly up.
[cpg]


Lily was no exception to that ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily175"]
[OnName num="lily"]
"Look how much she's grown, Daigo-dono,.......
[cpg cn=true]


[OnName num="daigo"]
......"
[cpg cn=true]


I wasn't really feeling it.
[cpg]



I was not really feeling the fact that all the children that would be born from now on would be mine. I didn't really feel it.
[cpg]


Everything somehow remained unrealistic.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





No matter what I do, no matter what I ...... do. I don't know what to do, but no matter what I do, Lily and I will never be able to be together.
[cpg]


I mean, we can't be a couple.
[cpg]


I can't love only her.
[cpg]


[OnName num="daigo"]
"...... Lily. Do you love me?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Lily176"]
[OnName num="lily"]
That's it. Liking and loving are not words enough.
[cpg cn=true]


I think that's true. In part because I'm the only man she's ever had.
[cpg]


Even with that, I've been into Lily. She must have noticed that, too.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************



I couldn't help but think about it. We can't be husband and wife after getting Lily pregnant.
[cpg]


Lily would also want to be married to me and me alone.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe155"]
[OnName num="chloe"]
So, Daigo-sama ...... Daigo-sama?　Are you listening?"
[cpg cn=true]


[OnName num="daigo"]
What ......?　I'm sorry, what are you talking about?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe156"]
[OnName num="chloe"]
"I'm sorry, what are you talking about?" "......, you seem to be distracted. We were talking about taking a break.
[cpg cn=true]


[OnName num="daigo"]
"Oh, that's great. Oh, that's great. I'll do that.
[cpg cn=true]


I didn't seem to hear much of what Chloe was saying.
[cpg]


Not because of Chloe. It was because it wasn't Lily.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe157"]
[OnName num="chloe"]
She must love you very much.
[cpg cn=true]


[OnName num="daigo"]
"......, that's for sure."
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe158"]
[OnName num="chloe"]
I'm sorry, but I have no choice but to give up. It is impossible to be united with one woman.
[cpg cn=true]


Chloe says so. Of course I couldn't give up.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





In the evening, we come back to the castle.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily177"]
[OnName num="lily"]
I'm so tired, Daigo-dono. Daigo-dono."
[cpg cn=true]


With the moonlight, Lily's stomach grows bigger and bigger.
[cpg]


[OnName num="daigo"]
Oh ......, I'm really, really tired. I wonder how much longer I can go on living like this.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily178"]
[OnName num="lily"]
Yes,...... but the people are happy.
[cpg cn=true]


I'm the one who wants to please them, Lily. But I can't begin to say that.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

But that doesn't mean I can't go on like this. Lily is also talking to me knowing that we will not be able to tie the knot.
[cpg]

So I decided to make a proposal. I'm going to propose one proposal: ......
[cpg]


[OnName num="daigo"]
Is there such a thing as a wedding in this world?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily179"]
[OnName num="lily"]
...... what?"
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夜）******************************************************


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]

Later, I decided to formally propose it again.
[cpg]


In the presence of Chloe, I declared: "I want to get married with Lily.
[cpg]


[OnName num="daigo"]
I want to get married with Lily. As big as possible.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe159"]
[OnName num="chloe"]
I know there used to be a concept of marriage when there were men.
[cpg cn=true]


Chloe knows about it. But it is a concept that has long since disappeared.
[cpg]


[OnName num="daigo"]
What do you think? Lily, do you agree with me?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily180"]
[OnName num="lily"]
"No way. ...... It would mean making it public that you are favoring me.
[cpg cn=true]


Lily explains that it is not possible in this world for one person to be united with another.
[cpg]


But I still wanted to have a wedding.
[cpg]


[OnName num="daigo"]
Please. I don't want anything else as long as I get this.
[cpg cn=true]


;//「どうしても他の女を抱かなきゃいけないなら、せめて……リリーを妻にしたい」
[OnName num="daigo"]
If I must have children with many women, I would at least have a ceremony with ...... Lily.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe160"]
[OnName num="chloe"]
What will the people think? They might take it as a sign that you don't care about other women.
[cpg cn=true]


[OnName num="daigo"]
I'll prove it by my actions. You really need a child, don't you?
[cpg cn=true]


Chloe pondered. Lily turned to me and looked serious.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





In the end, I pushed her into it.
[cpg]


Lily and I are getting married. A culture that had long since disappeared was to be recreated once again.
[cpg]


[OnName num="woman_A"]
"Did you hear?　It's a wedding?
[cpg cn=true]


[OnName num="woman_B"]
Yes, His Majesty and Daigo-sama are getting married. ......
[cpg cn=true]


[OnName num="woman_C"]
Does Daigo-sama not care about us anymore?
[cpg cn=true]


There were many rumors flying around the town. However, Lily was magnificent as a stone.
[cpg]


We have the desire to be with each other. She has no regrets, even though she feels guilty about that.
[cpg]


And at first, there were people who said that Lily would monopolize me. ......
[cpg]


Gradually, the people were remembering the culture of marriage.
[cpg]


I guess it was many generations ago when I say remembering. It is not something you can do from memory.
[cpg]


They knew that marriage was something that women longed for, based on past literature and other sources.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Lily's stomach was growling. As the wedding day approached, the people began to support our marriage.
[cpg]


Some wanted to have their wedding dresses tailored, others wanted us to hold the ceremony in our church.
[cpg]


In the end, the wedding was to be held at the castle, but the ...... wedding dress was to be tailored.
[cpg]


[VOICE f="Lily181"]
[OnName num="lily"]
The wedding dress was made for the bride and groom, and the bride's wedding dress was made for her. Does it look good on you, Daigo-dono?
[cpg cn=true]


[OnName num="daigo"]
"Oh. It looks good on you, Lily."
[cpg cn=true]


The waiting room just before the wedding. I spend time with Lily. I'm a little nervous and uncomfortable.
[cpg]

;//移植のためシーンをカットしています

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





And then we got married.
[cpg]


Many people had gathered in front of the castle.
[cpg]


All of them were women. As far as the eye could see, everyone was ......
[cpg]



;//========================================
;//●ＣＧ非エロ（笑顔で主人公の隣に居るヒロイン。民衆に手を振っている）ev_60
;//人物１：ヒロイン１
;//服装１：ウェディングドレス
;//人物２：主人公
;//服装２：着衣
;//場所　：城＿露台　バルコニーのような場所
;//時間　：昼
;//備考　：ヒロインは妊娠六ヶ月くらいです
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_pi"]
;**【ＣＧ】 ev_60_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=100]



Lily looked happy. I think she must be really happy.
[cpg]


It's because this is a world where you can never be tied to just one person.
[cpg]


I thought this kind of formality is important. ......
[cpg]


I also think that it is only in this way that we will be united.
[cpg]


Everything seemed to be fine with this. The fact that there is a smiling Lily next to me is really the only thing that makes ...... me feel as if everything will be rewarded.
[cpg]



[VOICE f="Lily182"]
[OnName num="lily"]
I'm so happy for you, Daigo-dono.
[cpg cn=true]


[OnName num="daigo"]
Oh. We're probably ...... happier than anyone else in the world right now.
[cpg cn=true]



[VOICE f="Lily183"]
[OnName num="lily"]
Yes, we will never forget this day. I will never forget what happened today.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（昼）******************************************************





The days pass by in a flash.
[cpg]


It seems that ten months and ten days have already passed since Lily became pregnant.
[cpg]


I didn't realize it at all, but it was about time for the baby to be born.
[cpg]


[OnName num="daigo"]
"Are you okay, Lily?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily184"]
[OnName num="lily"]
Yes,...... but I think she will be born soon."
[cpg cn=true]


She looked tired. I felt so miserable because I didn't have anything to do.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily185"]
[OnName num="lily"]
I'm happy ...... not to have that look on my face. I'm going to have your child.
[cpg cn=true]


[OnName num="daigo"]
"...... I see."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Lily186"]
[OnName num="lily"]
'So ...... ugh, kuuuuh.'
[cpg cn=true]


Lily's face twitched. I call the maid of honor as soon as I can.
[cpg]


From there, there was really nothing I could do. I guess it's not my role as a man to get involved, but still, ...... something about it made me feel strangely helpless.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





I can't sit still. I wander around in my room, a room in the castle.
[cpg]


I couldn't stay there, thinking that Lily was suffering right now.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





It seemed like an infinitely long time from there until Chloe told me that she had given birth.
[cpg]


[OnName num="daigo"]
Oh, thank goodness...... Lily."
[cpg cn=true]



[VOICE f="Lily187"]
[OnName num="lily"]
"Phew...... it hurt like hell, but it was ...... a happy pain."
[cpg cn=true]


The baby's crying and the joyful cries of the attendants.
[cpg]


Tears welled up naturally, but I held back, feeling that I shouldn't spill these tears.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Of course, the baby was a girl. There was no possibility that a boy would be born.
[cpg]


This child would have to carry the role of royalty, or perhaps a kind of fate.
[cpg]


Still, I couldn't help but love her. I didn't think such feelings existed in me.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily188"]
[OnName num="lily"]
Daigo-dono,...... what shall we do about the second one?"
[cpg cn=true]


[OnName num="daigo"]
I'll do as much as you want, Lily. I'll give you as much as you want, Lily.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily189"]
[OnName num="lily"]
I'll do as much as you want, Lily. It's just like you.
[cpg cn=true]


Lily smiled softly. The happy time passed.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





Of course, the fact that Lily and I are now a married couple does not mean that my mission has ceased.
[cpg]


I still have my wife, but I still go to see other women every day. There was no way around that.
[cpg]


Still, I feel that both Lily and I can now relax.
[cpg]


[OnName num="daigo"]
"Hmmm, ......?　That's ......."
[cpg cn=true]


In the middle of these days, I met an unexpected person.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy084"]
[OnName num="daisy"]
"Long time no see, Daigo-sama.
[cpg cn=true]


I wondered why he had come all the way from the Elven Forest, and we had a little chat.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Daisy085"]
[OnName num="daisy"]
We had two things to talk about. The first is that you must have been infected with the plague.
[cpg cn=true]


[OnName num="daigo"]
...... what?"
[cpg cn=true]


[free time=1000]

[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA06_p2_01_a.ui" method="change_3"  pos="2/2" time=800]

I looked at Chloe and she looked apologetic.
[cpg]


[OnName num="daigo"]
She looked at me apologetically, "That's funny,......, I'm a normal living person."
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Daisy086"]
[OnName num="daisy"]
The second thing I came to tell you is that you apparently have antibodies.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Chloe161"]
[OnName num="chloe"]
"Oh ...... is that so?"
[cpg cn=true]


I'm not asking if you have antibodies. I was told something very important, wasn't I?
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Daisy087"]
[OnName num="daisy"]
You must have been infected with the plague for quite some time, and yet you haven't shown any symptoms.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Chloe162"]
[OnName num="chloe"]
Certainly. ......
[cpg cn=true]


[OnName num="daigo"]
No, no, no, wait. I don't see the story. Tell me more."
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





Then Daisy told me the truth.
[cpg]


That normally, a man who is summoned from another world will die within a decade or so.
[cpg]


It is the same when he returns from the other world to his original world. It seems that there is no way to escape from this.
[cpg]


[OnName num="daigo"]
"How could you ...... keep such a thing from me?"
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily190"]
[OnName num="lily"]
I'm sorry,......, but I just couldn't say it.
[cpg cn=true]


I know how Lily feels, but I think you should understand how I feel too. But it's okay, because it's past.
[cpg]


[OnName num="daigo"]
I don't know why my body has antibodies,......?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily191"]
[OnName num="lily"]
"Well, I don't know. ...... God must have blessed me."
[cpg cn=true]


[OnName num="daigo"]
"God ......?"
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily192"]
[OnName num="lily"]
Yes. I think the reason they hold weddings in churches is so that God can see them.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Lily193"]
[OnName num="lily"]
So God must have thought it would be a shame to tear us apart.
[cpg cn=true]


......It's a romantic story. It's a romantic story, but it's very Lily.
[cpg]


[OnName num="daigo"]
"But we did get married in a castle, though."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily194"]
[OnName num="lily"]
I'm sure that's true. It's true.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I can't be sure of anything anymore. It might have been just a coincidence.
[cpg]


If I had asked Lily for more details when I first felt uncomfortable, a different fate might have awaited me.
[cpg]


Or perhaps my devilish nature would have kicked up a fuss and I might have caused Lily more pain in the future.
[cpg]


But I was content with the way things ended.
[cpg]


I no longer wanted to return to this world, and Lily didn't ask me not to return.
[cpg]

[SCENE id=16]

;//ＥＮＤ　ヒロイン１善ルート
[jump storage="epend.ks" target="*start"]


