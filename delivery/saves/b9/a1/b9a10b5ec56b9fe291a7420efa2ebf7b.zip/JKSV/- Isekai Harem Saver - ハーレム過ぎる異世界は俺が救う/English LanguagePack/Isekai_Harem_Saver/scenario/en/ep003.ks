
*start

;#################################################
*Ep003|Why Men Are Not Born
;#################################################


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夜）******************************************************


*select04_1|Why Men Are Not Born

[SCENE id=3]

[OnName num="daigo"]
Tell me more. Why do you look like that?"
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily100"]
[OnName num="lily"]
'Well, ...... someday, you'll find out.'
[cpg cn=true]


Lily then seemed to have made up her mind.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily101"]
[OnName num="lily"]
You said it was because of the plague that no more men were born into this world, didn't you?
[cpg cn=true]


[OnName num="daigo"]
'Yes, I did. What about it?"
[cpg cn=true]


Lily was still thinking, perhaps choosing her words.
[cpg]


As for me, I feel impatient to know the truth as soon as possible.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Lily102"]
[OnName num="lily"]
She says, "The plague hasn't ...... gone away from this world. So perhaps ...... Daigo-dono is already ...... too."
[cpg cn=true]


I was taken aback by what Lily said.
[cpg]


[OnName num="daigo"]
I was surprised to hear Lily say, "...... that can't be true. I'm fine.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily103"]
[OnName num="lily"]
I'm not going to develop it right away. However, your life expectancy may be extremely shortened.
[cpg cn=true]


[OnName num="daigo"]
Are you serious, ......?"
[cpg cn=true]


Lily clammed up. It seems to be true.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily104"]
[OnName num="lily"]
There have been cases of men who have had antibodies. They may be able to live at least as long as a normal human, however ......."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily105"]
[OnName num="lily"]
"Perhaps in a decade or so when the next male can be summoned,...... by which time you too,......
[cpg cn=true]


[OnName num="daigo"]
Well, then send me back to reality right away."
[cpg cn=true]


I say to Lily, confused. But ......
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily106"]
[OnName num="lily"]
'It's no use. Just because you return to reality doesn't mean that the plague will be removed from your body.
[cpg cn=true]


[OnName num="daigo"]
Oh no. ......"
[cpg cn=true]


I was so surprised and confused that I couldn't say anything.
[cpg]


To whom should I take this fear, this anger?
[cpg]


No matter who I ...... took it out on, it would be the same.
[cpg]

;//ブラックアウト

;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Whatever my feelings, I must conquer the plague. You said you only have a dozen more years to live.......?
[cpg]


I have to get over the plague. You only have a dozen more years to live, ......?
[cpg]


No kidding. Did Lily and her friends summon me knowing that?
[cpg]


Of course it was a matter of life and death for her as well. I know that, but I can't shake the feeling that it's not going to work.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily107"]
[OnName num="lily"]
I really ...... feel like I've gotten her into something terrible.
[cpg cn=true]


[OnName num="daigo"]
If you're going to apologize, do something about it."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily108"]
[OnName num="lily"]
I can't ...... do anything about it."
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I was unable to sleep that night.
[cpg]


Is it still ripping away at my body? What kind of end will I face?
[cpg]


I was not in the mood to worry. But even if I worried about it alone, I would not get an answer.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





It would soon be morning. Chloe came over, and I asked her for advice.
[cpg]


[OnName num="daigo"]
"Chloe ......, you knew about the plague, too?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe086"]
[OnName num="chloe"]
When you say about the plague, do you mean ......?"
[cpg cn=true]


Chloe blurts out. I know, it's probably best not to tell her the truth.
[cpg]


It would be a big deal if the only man left in the room turned desperate. I understand the logic. I get it, but ......
[cpg]


[OnName num="daigo"]
"Don't hide it. You know the truth.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe087"]
[OnName num="chloe"]
Did Your Majesty ask you?
[cpg cn=true]


[OnName num="daigo"]
Yes, he did. I know I don't have much time left.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe088"]
[OnName num="chloe"]
I can't tell you anything about it. Daigo-sama, you have no choice but to accept it as your destiny. ......
[cpg cn=true]


I can't accept such a fate. I asked Chloe, a little frustrated.
[cpg]


[OnName num="daigo"]
Is there no way to cure the plague? A way to completely exorcise the plague, even if it's just me alone.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe089"]
[OnName num="chloe"]
If there was such a thing, we would have used it on you.
[cpg cn=true]


Is that indeed true? It doesn't matter how long a man lives.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe090"]
[OnName num="chloe"]
But the ...... elves may have a secret trick up their sleeves.
[cpg cn=true]


[OnName num="daigo"]
"Really? Then call the guards and we'll go to the elven forest again.
[cpg cn=true]


I've made up my mind. I would survive at all costs.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************


I leave the castle. I leave the castle, with a few soldiers guarding me.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************





I walk across the plain. I'm used to walking since I came to this world.
[cpg]


If only there was a way to cure the plague, this world would be a utopia for me.
[cpg]


If I can return to this world at any time, even more so ......, I must definitely cure the plague.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（夕方）******************************************************





And again I visited the forest of elves.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy018"]
[OnName num="daisy"]
I wondered what had happened this time. What happened this time?"
[cpg cn=true]


[OnName num="daigo"]
"You know what's going on, don't you? You know I have the plague, too.
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy019"]
[OnName num="daisy"]
"...... and you want to cure the plague?"
[cpg cn=true]


[OnName num="daigo"]
Yes, I do. They say elves are good at magic.
[cpg cn=true]


I pressed Daisy. Daisy was relatively calm.
[cpg]



[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy020"]
[OnName num="daisy"]
There is a way to cure it. I'm not saying there isn't."
[cpg cn=true]


[OnName num="daigo"]
Then use it, ......!
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Daisy021"]
[OnName num="daisy"]
But it's really big magic. Summoning magic comes once in a decade, but dispelling the ...... plague is a once-in-a-century feat.
[cpg cn=true]


And only one person can escape the plague with it, he said.
[cpg]


[OnName num="daigo"]
I don't care. Use it on me.
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy022"]
[OnName num="daisy"]
We'll think about it even if you don't care. "If you don't mind, we'll still wonder if you're the right person to outlive us."
[cpg cn=true]


[OnName num="daigo"]
How are you going to ...... decide if it's right?
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Daisy023"]
[OnName num="daisy"]
It's simple. It's easy. If you can solve the problems of this world, ......
[cpg cn=true]


The problems of the world. Of course, it's about the fact that it's all women.
[cpg]


But ...... can I solve that on my own?
[cpg]


If this happens, I'm going to have to do something with a lot of momentum.
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧエロ（詰め寄られるヒロイン。顔を赤らめる）ev_24
;//人物１：ヒロイン６
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：エルフの森
;//時間　：夕方
;//========================================

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_24_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=100]

[OnName num="daigo"]
Just help me!"
[cpg cn=true]


I'm going to have to do something about this on my own.
[cpg]



[VOICE f="Daisy024"]
[OnName num="daisy"]
"Hey ......?
[cpg cn=true]


[OnName num="daigo"]
I'm going to love you. I'll love you and let you have as many children as you want. That's not good enough for you?
[cpg cn=true]


I couldn't accept my own fate.
[cpg]

;**【ＣＧ】 ev_24_a ***********************
[CG id=7 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Daisy025"]
[OnName num="daisy"]
"Please don't ......."
[cpg cn=true]


But Daisy didn't offer to help me.
[cpg]

I snapped out of it and noticed the elves around me looking at me.
[cpg]


What am I ...... doing, I thought. Threatening Daisy probably won't help her on her own.
[cpg]


But then again, I wouldn't be able to threaten the elves as a whole.
[cpg]



She said it's a once-in-a-century magic. If a man could summon it once every ten years, it would be disproportionate.
[cpg]


There's nothing I can do about it. Besides, I feel bad for Daisy. ......
[cpg]


[OnName num="daigo"]
......"
[cpg cn=true]


I thought about it, but I didn't apologize.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（夜）******************************************************





At night, we were to stay at the elves' dwelling.
[cpg]


A hut-like place. Not much different from the house we lived in.
[cpg]


[OnName num="daigo"]
......"
[cpg cn=true]


I told them I wanted to be alone, so they gave me an empty room.
[cpg]



[SE f="se009"]
;//【ＳＥ】『ノック』





As I lay alone in the bedroom, there was a knock at the door.
[cpg]


[OnName num="daigo"]
Who is it?
[cpg cn=true]



[VOICE f="Daisy026"]
[OnName num="daisy"]
It's me. Daisy,...... may I come in?"
[cpg cn=true]


I was in no mood to talk to anyone, but the plague could really kill me if I let it.
[cpg]


[OnName num="daigo"]
"Yeah. Come in.
[cpg cn=true]



[SE f="se007"]
;//【ＳＥ】『ドア開く』





[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy027"]
[OnName num="daisy"]
You look so depressed. You don't look so good.
[cpg cn=true]


[OnName num="daigo"]
Of course I'm feeling sorry for myself. It would be crazy not to feel something in this situation.
[cpg cn=true]


I agree," Daisy said, crossing her arms against the wall.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy028"]
[OnName num="daisy"]
You're not out of all means yet, Daigo. You are a man.
[cpg cn=true]


[OnName num="daigo"]
What's the matter with you that I'm a man?
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Daisy029"]
[OnName num="daisy"]
It means you might be able to do things a woman can't."
[cpg cn=true]


I can't think of anything that you can say that I can do. ......
[cpg]


[OnName num="daigo"]
"...... that only I can do?"
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy030"]
[OnName num="daisy"]
I'm sure there's plenty you can do. There must be a lot, you just don't know it yet.
[cpg cn=true]


It's an abstract and unhelpful consolation. But I could tell that Daisy cared about me.
[cpg]


[OnName num="daigo"]
You don't want me to die, do you?
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy031"]
[OnName num="daisy"]
'Of course I do. But I can't do the big magic by myself.
[cpg cn=true]


Daisy looks a little gloomy as she says this.
[cpg]


In short, all you need is a name. A pretext that you need to help me, or that I am worthy of your help.
[cpg]


I didn't think of it right away, but I thought I saw a glimmer of light.
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（朝）******************************************************



[SE f="se003"]
;//【ＳＥ】『鳥の鳴き声』



And then morning came again. This time I took it seriously.
[cpg]


It seems there really is no other way to save the world.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="daigo"]
I may come back here again. I'll look forward to seeing you then.
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Daisy032"]
[OnName num="daisy"]
"Yeah. See you then.
[cpg cn=true]


We said our goodbyes and were about to leave the forest. ...... I'll find a way to save the world and I'll come back here sooner or later.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************



[SE f="se001"]
;//【ＳＥ】『歩く』


I don't think there are a number of ways to save this world. There are only two that come to mind for me.
[cpg]


First, if a boy is born, that would solve everything.
[cpg]


Second, if a woman could get pregnant without a man, that would be good. ......
[cpg]


Easy to put into words, but both seem difficult.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『城下町』（夕方）******************************************************

And now we are back to the castle town.
[cpg]

[OnName num="daigo"]
I said, "...... Well, what shall we do now?"
[cpg cn=true]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

After thinking about it, I decided to consult Lily again.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夜）******************************************************





[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily109"]
[OnName num="lily"]
'......You don't look well, Daigo-dono.
[cpg cn=true]


[OnName num="daigo"]
'Well, you must look pale too,...... because it's your fault.
[cpg cn=true]


Lily looked apologetic.
[cpg]


[OnName num="daigo"]
'Daisy told me she'd exorcise the plague if I solved the problems of this world.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily110"]
[OnName num="lily"]
I see. ......"
[cpg cn=true]


I'm sure Lily won't be coming up with such a means anytime soon.
[cpg]


If she had thought of it, she would have done it herself. Then again, there is no way not to take advantage of the fact that I am a man.
[cpg]


I guess I would have to look for someone somewhere, a woman with a unique constitution who could give birth to a boy.
[cpg]


[OnName num="daigo"]
Lily, if you have any ideas, please let me know. If you have any ideas, please let me know.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Lily111"]
[OnName num="lily"]
I'm sure I can help. I would like to help Daigo-dono, too.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





Then I woke up again in my room.
[cpg]


[OnName num="daigo"]
I woke up again in my room. "...... Is it morning already?
[cpg cn=true]


I haven't slept for days. I was also tired from the trip.
[cpg]


Still, I didn't feel like I was sleeping deeply. That's how impatient I am.
[cpg]


I was in such a hurry because my life was at stake.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe091"]
[OnName num="chloe"]
Good morning, Mr. Daigo. Daigo-sama,......, are you still troubled?
[cpg cn=true]


[OnName num="daigo"]
Have you come up with anything that will save you from worrying?
[cpg cn=true]


No," said Chloe, shaking her head.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（朝）******************************************************





[OnName num="woman_A"]
No," said Chloe, shaking her head, "Oh no, Daigo-sama,......!
[cpg cn=true]


[OnName num="woman_B"]
It's an interesting ...... day, but I don't have time to gawk.
[cpg cn=true]


The women want me as much as they can. And yet, none of them are willing to assault me.
[cpg]


If I keep doing this, I might have a boy somewhere.
[cpg]


I had to hang on to that faint hope. ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************




;//＠
My libido seemed to be endless.
[cpg]


My body had clearly changed from when I was in reality. In the midst of all this......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte031"]
[OnName num="charlotte"]
I was in the middle of a conversation with my brother. Oh, brother!"
[cpg cn=true]


Charlotte appeared. She spots me and comes up to me.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Charlotte032"]
[OnName num="charlotte"]
She's been very enthusiastic lately, and seems to be doing that ...... thing with everyone.
[cpg cn=true]


[OnName num="daigo"]
She looks at me and says, "Yeah, things have changed. Things have changed.
[cpg cn=true]

[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
I nod my head. Maybe Charlotte doesn't know.
[cpg]


[OnName num="daigo"]
My body is like a plague," I said. I'm going to die in about ten years.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Charlotte033"]
[OnName num="charlotte"]
What the hell is that?　What is that?
[cpg cn=true]


I guess she doesn't know. I told Charlotte everything.
[cpg]


[OnName num="daigo"]
The plague that killed off all those men is still out there, and it's taking its toll on my body, too.
[cpg cn=true]


Charlotte listened with a serious expression on her face.
[cpg]


[OnName num="daigo"]
'So ...... they say there's nothing I can do to get back to reality.
[cpg cn=true]


[OnName num="daigo"]
There is a way to get the plague exorcised with the help of the elves,...... but it doesn't look like they're going to do that either."
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte034"]
[OnName num="charlotte"]
Why not?　The elves are just as important as men, aren't they?
[cpg cn=true]


[OnName num="daigo"]
No, it's not the same. It's a more time-consuming magic than summoning a man.
[cpg cn=true]


[OnName num="daigo"]
I'm just asking if I'm worth that much magic.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Charlotte035"]
[OnName num="charlotte"]
No way. ......!"
[cpg cn=true]


Charlotte seems to be concerned about me, but that doesn't mean she's going to do anything for me. ......
[cpg]


[OnName num="daigo"]
'After all, that's the point. Whether I can save this world or not. If I can't do that, then it seems I'll just have to die."
[cpg cn=true]


With that in mind, I talk with Charlotte. Then.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte036"]
[OnName num="charlotte"]
"...... I might be able to save my brother."
[cpg cn=true]


[OnName num="daigo"]
...... what?"
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte037"]
[OnName num="charlotte"]
I'm, you know, frail and ...... I don't know if I can even have children."
[cpg cn=true]


Charlotte begins to tell her story.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte038"]
[OnName num="charlotte"]
But there are people around me who have high hopes for me. When I'm born, ...... they think I might have a boy who can withstand the plague."
[cpg cn=true]


[OnName num="daigo"]
What?"
[cpg cn=true]


For a moment I thought I saw hope, but there was no evidence of such a thing anywhere.
[cpg]


[OnName num="daigo"]
How could you say such a thing?
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte039"]
[OnName num="charlotte"]
The priest said he received an oracle. When I was a baby.
[cpg cn=true]


[OnName num="daigo"]
'I see. ......
[cpg cn=true]


I don't know how much I can trust this world's magic or oracle.
[cpg]


But it is such a world that we call people from other worlds. Can we trust them to some degree ......?
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I think. I think I see one silver lining, but not everything can be solved by an effort in this direction.
[cpg]


I need more information. So I take action.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（夜）******************************************************





[FG f="CHA05_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina017"]
[OnName num="martina"]
"Oh, it's you. What can I do for you?
[cpg cn=true]


[OnName num="daigo"]
I need to ask you something. No, let me hear it.
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Martina018"]
[OnName num="martina"]
I don't have any reason to follow you.
[cpg cn=true]


[OnName num="daigo"]
I'm the one who makes the decisions for the queen. I can decide what to do with you at my discretion. ......
[cpg cn=true]


I didn't mention the "may" part.
[cpg]


[FG f="CHA05_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina019"]
[OnName num="martina"]
...... So?　What is it that you want to ask me?
[cpg cn=true]


[OnName num="daigo"]
I'm glad you're talking so fast. It's about my longevity.
[cpg cn=true]


I'll tell you how it happened. I'm trying to find out how to save the world, or rather, how to save me.
[cpg]


[OnName num="daigo"]
You know what's going on around here, don't you? If you know something, let me know.
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Martina020"]
[OnName num="martina"]
I say, "Well, ...... no, this is my trump card, so it's not so easy to say."
[cpg cn=true]


[OnName num="daigo"]
You know something?　I can get you out of here, depending on what it is.
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Martina021"]
[OnName num="martina"]
It's not that easy to say.
[cpg cn=true]


[OnName num="daigo"]
If you don't tell me, you'll be stuck here forever. Is that what you want?
[cpg cn=true]


With a click of her tongue, Martina began to speak.
[cpg]


[FG f="CHA05_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina022"]
[OnName num="martina"]
We are in love with other women. It's not just us, it happens all the time in this world.
[cpg cn=true]


What do you mean by that? What does it matter?
[cpg]


[OnName num="daigo"]
You're not going to tell me that two women got pregnant?
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Martina023"]
[OnName num="martina"]
I don't know what your logic is, but I don't see why not. I don't know what the logic is, but one of the bandits was carrying his only child.
[cpg cn=true]


I can't read ....... It is possible that he is lying to free himself.
[cpg]


[FG f="CHA05_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Martina024"]
[OnName num="martina"]
If you want to hear any more, you're going to have to get me out of here.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





[OnName num="daigo"]
...... you have three choices.
[cpg cn=true]


Three big choices. With Charlotte, I would bet on the possibility of a boy being born.
[cpg]


Next, get Martina out of jail and find out why she says a child was conceived.
[cpg]


Finally, I could also come up with the idea of ...... corrupting Daisy herself with pleasure.
[cpg]


If I trained her to do whatever I told her, it might not be a matter of saving the world or not saving the world in the first place.
[cpg]


I thought about it and came up with an answer.
[cpg]



;//■選択肢
[switch]
[case "Let Charlotte have a boy."]
	[swap]
	[jump target="*select05_1"]
[case "Find a way for women to have children with each other."]
	[swap]
	[jump target="*select05_2"]
[case "I would make Daisy my own."]
	[swap]
	[jump target="*select05_3"]
[endswitch]


3. Let Charlotte have a boy.
4, I'll find a way to have children with other women.
5, Make Daisy yours



;//※※※全ての選択肢が常に発生



;//==============================
;//３、シャーロットに男の子を産ませる
*select05_1
[jump storage="ep004.ks" target="*select05_1"]

;//==============================
;//４、女同士で子供を作る方法を探し出す
*select05_2
[jump storage="ep005.ks" target="*select05_2"]

;//==============================
;//５、デイジーを自分のものにする

*select05_3
[jump storage="ep006.ks" target="*select05_3"]
