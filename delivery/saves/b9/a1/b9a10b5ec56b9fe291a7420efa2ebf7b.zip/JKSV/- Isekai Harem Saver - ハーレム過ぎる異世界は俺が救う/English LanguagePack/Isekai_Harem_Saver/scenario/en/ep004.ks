
*start


;#################################################
*Ep004|Betting on Charlotte
;#################################################


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************


*select05_1|Betting on Charlotte

[SCENE id=4]

I guess the most realistic thing to do is to go to Charlotte's.
[cpg]


When I say realistic, I'm relying on the uncertainty of an oracle: ......
[cpg]


If the boy is born normally, that's perfectly fine.
[cpg]


[OnName num="daigo"]
I agree. ......
[cpg cn=true]


It would be against Lily and Chloe's wishes. It would be patronizing one woman.
[cpg]


But we have to be prepared for that. If I explained the benefits, they would be convinced.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





So, I immediately cut to Chloe the next morning.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe092"]
[OnName num="chloe"]
She said, "No. You and Charlotte will be the object of public outrage.
[cpg cn=true]


[OnName num="daigo"]
So, ...... we could make them live in this castle so that they won't be found out. ......
[cpg cn=true]


Chloe looks reluctant. No, but we can't choose our means.
[cpg]



[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chloe093"]
[OnName num="chloe"]
'Still, there is a problem. As I said before, you can't get too attached to one woman.
[cpg cn=true]


[OnName num="daigo"]
'Still, if it means that a boy might be born, then maybe this country will cooperate with us.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe094"]
[OnName num="chloe"]
"......We don't have a choice. ......
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





So, the measure I took was to hide my identity and head to Charlotte's house.
[cpg]


It was difficult, though, to do so while avoiding rumors around me. ......
[cpg]


But even so, I couldn't do nothing.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（昼）******************************************************





[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte040"]
[OnName num="charlotte"]
'I'm glad you came, brother,......, and I'm glad to see you again.
[cpg cn=true]



[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte041"]
[OnName num="charlotte"]
Do you like me that much?"
[cpg cn=true]


It was frustrating to be making unnecessary exchanges.
[cpg]


That's about all I felt like doing, but I still had to take care of it.
[cpg]


[OnName num="daigo"]
Charlotte. If you're carrying a child, you might have a boy, right?
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte042"]
[OnName num="charlotte"]
'I can't say for sure. I don't know everything about my body.
[cpg cn=true]


I know. I asked the obvious question.
[cpg]


;//ブラックアウト


;//========================================
;//●ＣＧエロ（後ろ向きの騎乗位。ヒロインの方から腰を振る）ev_26
;//人物１：ヒロイン３
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：ヒロイン３の部屋
;//時間　：昼
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_26_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=100]




Right next to Charlotte, I whisper my love to her.
[cpg]

Or rather, it was Charlotte who was ...... aggressive.
[cpg]

;**【ＣＧ】 ev_26_a ***********************
[CG id=8 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Charlotte043"]
[OnName num="charlotte"]
'Your brother's smell, it's so soothing .......'
[cpg cn=true]


I was feeling rather unsettled at all, but that's okay.
[cpg]

The desire to love Charlotte is the same whether or not there are various other factors ......
[cpg]

No, I guess not. I was still unsure of my feelings.
[cpg]

With that thought in mind, we made love......
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夜）******************************************************





Then back to the castle, Lily's room.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily112"]
[OnName num="lily"]
She says, "You seem to be very fond of ...... Charlotte."
[cpg cn=true]


[OnName num="daigo"]
'Oh. I'm afraid for my life too, you know.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily113"]
[OnName num="lily"]
But is it okay?　Is she happy to be loved for that reason?
[cpg cn=true]



Am I saying something wrong? Lily looked down a little.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily114"]
[OnName num="lily"]
I feel a little sorry for Charlotte and a little envious of her.
[cpg cn=true]


[OnName num="daigo"]
What does that ...... mean?"
[cpg cn=true]


Lily said, then shook her head.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily115"]
[OnName num="lily"]
'Nothing. You can do as you please, Daigo-dono."
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（昼）******************************************************





After that, I continued on my way to Charlotte's house.
[cpg]


Charlotte adores me.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte044"]
[OnName num="charlotte"]
'Ehehe ...... big brother always comes over, so I'm happy.'
[cpg cn=true]


[OnName num="daigo"]
'Oh well,.......
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte045"]
[OnName num="charlotte"]
I'm sure you like me a lot. I couldn't answer her question.
[cpg cn=true]


I couldn't answer. I'm not doing this because I like her.
[cpg]


But I guess that's what happens when you do things like this.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte046"]
[OnName num="charlotte"]
Why do you look like that ......?"
[cpg cn=true]


[OnName num="daigo"]
'...... Charlotte. I'm not doing this for you.
[cpg cn=true]


[OnName num="daigo"]
All I'm doing is betting on the fact that you might have a boy, that's all.
[cpg cn=true]


[OnName num="daigo"]
So ...... it's not that I don't like you.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte047"]
[OnName num="charlotte"]
"I see."
[cpg cn=true]


Charlotte looked a little disappointed.
[cpg]


I could have lied through my teeth here. But I felt like I couldn't do that.
[cpg]


[OnName num="daigo"]
"So, Charlotte. Don't like me. You can even hate me."
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Charlotte048"]
[OnName num="charlotte"]
I don't think so.
[cpg cn=true]


Charlotte laughed.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





Then again, I had a problem with the fact that I kept going to Charlotte's house.
[cpg]


Chloe seemed to see it as a particular problem, and I invited Charlotte to the castle.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Charlotte049"]
[OnName num="charlotte"]
'This room is really awesome, ...... it was made for your brother, wasn't it?'
[cpg cn=true]


[OnName num="daigo"]
'Yeah, apparently so.'
[cpg cn=true]



Charlotte is looking at this room with a twitch. I take her hand.
[cpg]

[OnName num="daigo"]
I take her hand. "From now on, you can stay with me as long as you like, okay?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
Charlotte nods. Her smile is pure.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Charlotte was then assigned a room and took up residence in the castle.
[cpg]


Charlotte seems happy to be by my side, but ......
[cpg]


I had a feeling that she was not truly happy.
[cpg]


I guess she is thinking about the reason why I love her after all.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（朝）******************************************************



[OnName num="daigo"]
"......Charlotte......"
[cpg cn=true]


I mumbled to myself with nothing or no one by my side. She was a source of comfort to me in more ways than one.
[cpg]

Was she that important to me?
[cpg]

How could she be nothing to me? To tweet alone is like being a lover.
[cpg]

...... lover. I wonder how it is. I still couldn't answer that question.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夕方）******************************************************


There are plenty of other women out there. What is the difference between them and Charlotte?
[cpg]


I couldn't answer that question yet. I felt that it was more than just the possibility of having a boy.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe095"]
[OnName num="chloe"]
You are troubled, Mr. Daigo.
[cpg cn=true]


[OnName num="daigo"]
'...... what are you talking about?'
[cpg cn=true]


I blurted out, but Chloe seemed to see right through me.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe096"]
[OnName num="chloe"]
I'm sure you don't know what to do with Charlotte, do you?
[cpg cn=true]


[OnName num="daigo"]
It's ......
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe097"]
[OnName num="chloe"]
It was your decision to bring her to the castle, so you need to be sincere with her.
[cpg cn=true]


I don't understand what you're talking about.
[cpg]


What is in the best interest of Charlotte ......
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]


I had called Charlotte to my room today.
[cpg]



Charlotte is showing a carefree smile.
[cpg]


I was heartbroken, but I couldn't sort through my feelings.
[cpg]


[OnName num="daigo"]
Charlotte ...... are you happy to be loved by me?"
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Charlotte050"]
[OnName num="charlotte"]
I was so happy to be loved by you," she said. What woman wouldn't want to?
[cpg cn=true]


Oh, no. No, that's not what I want to hear.
[cpg]


I don't care what you say about all women. I'm just trying to figure out what I want to do with Charlotte and ......
[cpg]


...... and what do I want to be?
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植のためシーンをカットしています


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Then Charlotte and I cuddled up and went to sleep.
[cpg]


Maybe it's not acceptable for the only man, me, to act like I'm sleeping with one woman, but ......
[cpg]


Still, I wanted to be with her.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Chloe098"]
[OnName num="chloe"]
I was so glad you had a good night's sleep. Daigo-sama, Charlotte."
[cpg cn=true]

[free time=1000]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p2_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Charlotte051"]
[OnName num="charlotte"]
'Whee...... ah, good morning!　Chloe-san!"
[cpg cn=true]


Charlotte immediately straightened her posture and bowed to Chloe.
[cpg]


Although it's attached to Chloe, there seems to be a subtle difference in position between the Nobleman and the prime minister.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Chloe099"]
[OnName num="chloe"]
I'm not too impressed with this kind of thing. It's just better that it's not leaked to the outside world. ......
[cpg cn=true]


Charlotte shudders. Then Chloe continues.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Chloe100"]
[OnName num="chloe"]
If it all comes out, Charlotte will be hated to the point that her life will be in danger.
[cpg cn=true]


[OnName num="daigo"]
You don't have to say it like that, Chloe.
[cpg cn=true]


But I guess I'm telling the truth.
[cpg]


Me and Charlotte can't fall in love as a normal man and a normal woman.
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





At all hours, I suddenly think about Charlotte.
[cpg]


Of course, that was partly because I wanted to save her from the plague. ......
[cpg]


But it was also purely out of concern for Charlotte.
[cpg]


Would I be able to get pregnant and have a baby?
[cpg]


I'm also wondering if I'll conceive a boy. ......
[cpg]


I found myself developing a kind of affection for Charlotte.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************



More time passed from there. Finally, ......
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte052"]
[OnName num="charlotte"]
Good morning, big brother. Big brother."
[cpg cn=true]


[OnName num="daigo"]
'Good morning ......, is that Chloe ......?"
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte053"]
[OnName num="charlotte"]
I had her change just for today. I wanted to try waking up my brother.
[cpg cn=true]


[OnName num="daigo"]
Why did you do that again ......?
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte054"]
[OnName num="charlotte"]
"Ehehe. I was kind of in that mood, so ...... ugh!"
[cpg cn=true]

[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]

[OnName num="daigo"]
What's wrong, Charlotte?　What's wrong, Charlotte?
[cpg cn=true]


[free time=1000]


Charlotte seems nauseous, clamps her mouth shut and leaves the room.
[cpg]


I thought, "What if...?
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





And I was right. Charlotte was pregnant.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************





Some time passed. Charlotte's belly is growing.
[cpg]


At this time, at this level of culture, there is no way to tell if a baby is a girl or a boy.
[cpg]


But the elves seemed to have a way.
[cpg]


We headed for the forest. We were accompanied not only by Chloe, but also by Lily, as it was a matter of great national importance.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Lily116"]
[OnName num="lily"]
'...... If we really are having a boy, then this country will be safe for a while. We have Charlotte to thank for that."
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Charlotte055"]
[OnName num="charlotte"]
'Hehehe ...... thank you. Dear Lily."
[cpg cn=true]


Charlotte seemed honestly happy to be pregnant with a child.
[cpg]


But I still don't know if my life will be saved. My heart was not at peace.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（夕方）******************************************************





Then we arrived at the elf forest.
[cpg]


Daisy and a few other elves decided to use magic to find out about Charlotte.
[cpg]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
It's a delicate magic, so Lily, Chloe ...... and I wait elsewhere.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily117"]
[OnName num="lily"]
Oh, God ......."
[cpg cn=true]


Lily is praying. Chloe seems calm, but I don't think she's really calm.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『エルフの森』（夕方）******************************************************



Then Daisy comes back in.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy033"]
[OnName num="daisy"]
'About her, ...... that's amazing. She's definitely pregnant with a boy."
[cpg cn=true]


[OnName num="daigo"]
"Really ......?
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Daisy034"]
[OnName num="daisy"]
"Yes. You promised me that if I could save the world, I would rid you of your plague. ......
[cpg cn=true]


It should not matter whether Charlotte's child is a girl or a boy.
[cpg]


Either way, you know you should bless the life that comes into being. ......
[cpg]


I was relieved. It looks like I'm going to survive.
[cpg]


[free time=1000]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Lily118"]
[OnName num="lily"]
'Thank goodness......!　This will save the Lilim nation.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Chloe101"]
[OnName num="chloe"]
I should be thankful to Charlotte. I have to thank Charlotte ...... and Daigo-sama.
[cpg cn=true]


[OnName num="daigo"]
Oh, ah,......."
[cpg cn=true]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『平原』（朝）******************************************************





The next morning. We leave the forest and go back to the castle.
[cpg]


The people around me praised Charlotte with all their mouths. The main character of this time is undoubtedly Charlotte.
[cpg]


The actual Charlotte, however, had a complicated expression on her face.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte056"]
[OnName num="charlotte"]
Hey, big brother .......
[cpg cn=true]


[OnName num="daigo"]
What?"
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte057"]
[OnName num="charlotte"]
I don't know if there is any value other than being able to have a boy. I mean, I'm ......"
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte058"]
[OnName num="charlotte"]
'I've always read a lot of books. I've always read a lot of books, and all the characters in them have a meaning to their lives, a value.
[cpg cn=true]


[OnName num="daigo"]
......
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte059"]
[OnName num="charlotte"]
But do I have that?
[cpg cn=true]


I was not allowed to be at a loss for an answer here. I answered immediately.
[cpg]


[OnName num="daigo"]
Yes, I do. You're the only one who ever called me big brother instead of worshipping me.
[cpg cn=true]


[OnName num="daigo"]
I've always cared about you. Even before we found out we were having a boy.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte060"]
[OnName num="charlotte"]
Yeah, ......, I guess you're right."
[cpg cn=true]


Charlotte was still not convinced.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夕方）******************************************************





Then they reached the castle town. Lily and Chloe seemed to be torn between when to tell the good news and when to tell the people.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Lily119"]
[OnName num="lily"]
Should we tell the people after the baby is born?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe102"]
[OnName num="chloe"]
Lily and Chloe were wondering when they should tell the people the good news. If we unnecessarily raise expectations, what will happen to Charlotte? ......
[cpg cn=true]


Lily and Chloe seemed to be thinking about Charlotte's frailty.
[cpg]


Whether or not she will be able to bear a child properly. I guess that means that this has not yet been determined.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I was alone in my room, just taking it easy. I felt a little discouraged.
[cpg]


It was still too early to feel relieved. Besides, it means I'm going to be a father.
[cpg]


But once the danger to my life was averted, it made me feel weak. It was making me feel weak.
[cpg]



[SE f="se009"]
;//【ＳＥ】『ノック』





[OnName num="daigo"]
"...... Charlotte?"
[cpg cn=true]



[VOICE f="Charlotte061"]
[OnName num="charlotte"]
Yeah. I'm coming in, big brother.
[cpg cn=true]



[SE f="se007"]
;//【ＳＥ】『ドア開く』





Charlotte enters the room. And she comes right in front of me, too close.
[cpg]


And then she says to me.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte062"]
[OnName num="charlotte"]
"Big brother, do you really like me? Do you really like me?　After you have the baby, will you hate me?"
[cpg cn=true]


[OnName num="daigo"]
He said, "No, I won't. Don't worry. Don't worry.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte063"]
[OnName num="charlotte"]
"But ...... if the baby is a girl, won't you be disappointed?"
[cpg cn=true]


[OnName num="daigo"]
"No, I won't. I'm telling you it's going to be fine.
[cpg cn=true]


Charlotte still repeats "but" and "but".
[cpg]


Seeing her anxious, I feel indescribable.
[cpg]


I think being by my side is a burden.
[cpg]


;//移植のためシーンをカットしています




[OnName num="daigo"]
You can go home today. You've been living in the castle for too long, and you must miss your home.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Charlotte064"]
[OnName num="charlotte"]
What?
[cpg cn=true]


[OnName num="daigo"]
What's wrong?　Don't you want to go home?
[cpg cn=true]


I said Charlotte, and she looked like she was going to start crying when I said that.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte065"]
[OnName num="charlotte"]
'Don't you want to stay with me, ...... big brother?"
[cpg cn=true]


[free time=1000]

Before I could hear her reply, Charlotte ran out of the room.
[cpg]


[OnName num="daigo"]
Wait, that's it."
[cpg cn=true]


I may have said the wrong thing.
[cpg]


It was too late to regret it, but I still regretted it ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





As I asked myself, I was becoming unsure myself.
[cpg]


Did I not love Charlotte for the reason that she could give birth to a man?
[cpg]


I can't deny it completely. But it is also true that Charlotte is special without that.
[cpg]


When I was having unspeakable feelings, ......
[cpg]



[VOICE f="Lily120"]
[OnName num="lily"]
I was thinking, "Excuse me. Daigo-dono."
[cpg cn=true]



[SE f="se007"]
;//【ＳＥ】『ドア開く』





[OnName num="daigo"]
Oh, what is it ......?"
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily121"]
[OnName num="lily"]
"Daigo-dono, did you say something to Charlotte?"
[cpg cn=true]


[OnName num="daigo"]
"What do you mean, what's wrong ......?"
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Lily122"]
[OnName num="lily"]
She's been very depressed. She has to take care of herself. ......
[cpg cn=true]


[OnName num="daigo"]
I see.
[cpg cn=true]


Is there anything I can do to help?
[cpg]


I can't think of anything. I'm afraid I'm going to go to her and say something wrong again.
[cpg]


I think it's better not to do anything until I've made up my mind properly.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





As the time passed by, I was still asking myself questions.
[cpg]


It's hard to get an answer. I don't know how to treat Charlotte .......
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





And today, I'm headed to another group of women.
[cpg]


I wonder if this is cheating on Charlotte.
[cpg]


But I can't do nothing about it. If that's the case, then ......
[cpg]

I had to get rid of Charlotte's anxiety at least. I knew that if I loved her, I had to put it into words.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************



Then we return to the castle. Charlotte still seemed to be blocked up, but one day she ......
[cpg]


[OnName num="daigo"]
"...... hmm?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte066"]
[OnName num="charlotte"]
...... big brother."
[cpg cn=true]


In the bedroom where she was sleeping, Charlotte snuck under the covers.
[cpg]


[OnName num="daigo"]
"What's up, Charlotte ......?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte067"]
[OnName num="charlotte"]
'Hey, do you really like me?　Do you love me?"
[cpg cn=true]


[OnName num="daigo"]
I've told you before. I told you before.
[cpg cn=true]


I had to act like a gentleman here, but I couldn't come up with any kind words at the moment.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte068"]
[OnName num="charlotte"]
'I'm ...... pregnant, aren't I? I thought that was all I was worth."
[cpg cn=true]


Struggling for words, Charlotte continues to speak.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte069"]
[OnName num="charlotte"]
'But if you love me pregnant, that's real love.
[cpg cn=true]


[OnName num="daigo"]
'...... Charlotte.'
[cpg cn=true]


I am reminded. I knew that somewhere along the line, I didn't see Charlotte as a woman.
[cpg]


I was only looking at her as a tool to save my life.
[cpg]


I regretted my past actions. I had not thought about Charlotte's feelings.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





Then I made a decision.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Chloe103"]
[OnName num="chloe"]
I said to myself, "Are you serious ......?　Both Charlotte and Daigo-sama will incur the wrath of the people.
[cpg cn=true]


[OnName num="daigo"]
I've already made up my mind. I can no longer stay in this castle.
[cpg cn=true]


I declared that I would leave this castle and live in Charlotte's house.
[cpg]



Of course, Lily and Chloe were vehemently opposed.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily123"]
[OnName num="lily"]
I told them, "Please reconsider. You're just what this country needs.
[cpg cn=true]


[OnName num="daigo"]
'It's just a change of residence, that's all.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Lily124"]
[OnName num="lily"]
But ...... you'll be out of Charlotte's house every time. And then they'll know you live there.
[cpg cn=true]


[OnName num="daigo"]
What's the problem?　We're about to have a baby boy.
[cpg cn=true]


[OnName num="daigo"]
The country is safe, right? Then you won't have to fight for me.
[cpg cn=true]


[free time=1000]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe104"]
[OnName num="chloe"]
How are you doing, Your Majesty?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily125"]
[OnName num="lily"]
"......, I have no choice."
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（朝）******************************************************





So I was out of the castle.
[cpg]


I was allowed to live in Charlotte's house. Of course, I brought Charlotte with me.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte070"]
[OnName num="charlotte"]
I was told, "Are you sure?　I would have been happy if we could have lived together in the castle.
[cpg cn=true]


[OnName num="daigo"]
"There are a lot of people in that castle. I want to live with Charlotte as much as possible."
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte071"]
[OnName num="charlotte"]
Thank you ...... for that, big brother.
[cpg cn=true]


[OnName num="daigo"]
And please don't call me big brother anymore.
[cpg cn=true]


Charlotte blushed and nodded yes.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Charlotte072"]
[OnName num="charlotte"]
'Would it be okay if I called you Daigo,......?
[cpg cn=true]


[OnName num="daigo"]
Charlotte blushed and nodded. "Yes, feel free to call me that.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（朝）******************************************************





Charlotte and I began to live together.
[cpg]


It may be smaller than a castle, but it's still a nobleman's house. There are always maidens.
[cpg]


But not as many as in the castle. I was able to spend my time more or less comfortably.
[cpg]


And above all, I was getting closer to Charlotte.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte073"]
[OnName num="charlotte"]
I'll cook lunch," she said. I've never had anyone eat a home-cooked meal before.
[cpg cn=true]


[OnName num="daigo"]
"Yeah, that's true.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte074"]
[OnName num="charlotte"]
I can cook, you know. You can count on me.
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



So, Charlotte pushed aside the attendants and stood in the kitchen.
[cpg]


I watched anxiously. I was worried that she might not be able to cook if she had been left to the care of the maidservants since she was a child.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（朝）******************************************************


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte075"]
[OnName num="charlotte"]
"Please, enjoy your meal.
[cpg cn=true]


[OnName num="daigo"]
......Itadakimasu."
[cpg cn=true]


But when I put the food in my mouth.
[cpg]


[OnName num="daigo"]
It's delicious. It's delicious, Charlotte.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte076"]
[OnName num="charlotte"]
"Heh heh. I know.
[cpg cn=true]


[OnName num="daigo"]
Charlotte will make a good mother.
[cpg cn=true]


Charlotte's cheeks flushed when I said that.
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************



A few more days passed. Charlotte's belly was getting bigger and bigger.
[cpg]



[FG f="CHA02_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chloe105"]
[OnName num="chloe"]
I said to her, "...... Daigo-sama, your face has changed, hasn't it?"
[cpg cn=true]


[OnName num="daigo"]
"Really?　How have I changed?
[cpg cn=true]


I put my question directly to Chloe.
[cpg]


[free time=1000]

[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe106"]
[OnName num="chloe"]
I think he's calmed down or ...... more like a father figure.
[cpg cn=true]


[OnName num="daigo"]
Is there such a thing?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chloe107"]
[OnName num="chloe"]
"Yes, there is. I would so much like to be in Charlotte's position."
[cpg cn=true]


Oh, really? Well, I'm really trying to be a father. ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夕方）******************************************************





Then, after finishing his role for the day, he returns to Charlotte's house, not to the castle.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Chloe108"]
[OnName num="chloe"]
She said, "Your Majesty misses you. Please show your face once in a while."
[cpg cn=true]


[OnName num="daigo"]
'Yes, when I feel like it.'
[cpg cn=true]


I replied reluctantly. Chloe looked disappointed.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe109"]
[OnName num="chloe"]
You, ......, don't know your place, do you?
[cpg cn=true]


[OnName num="daigo"]
I think I do. I think I know what I'm doing.
[cpg cn=true]


[OnName num="daigo"]
But I have my own will. There are people who like me.
[cpg cn=true]



Chloe murmured, "I guess so.
[cpg]


I'm sorry Lily, but I've got my own thing to do.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（夜）******************************************************





Then we go back to Charlotte's house and finish dinner.
[cpg]

[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]

I know Charlotte still has a lot of worries, but she seems happy.
[cpg]

Her smile makes me feel at peace, too.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（朝）******************************************************



[SE f="se003"]
;//【ＳＥ】『鳥の鳴き声』



Even though I sleep with Charlotte, I wake up in the morning and ......
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte077"]
[OnName num="charlotte"]
'Are you still sleeping?　It's already morning."
[cpg cn=true]


She makes breakfast for me and ...... she says she is frail, but she may be quite strong in her heart.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（朝）******************************************************


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

[OnName num="daigo"]
I'm going to go then.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Charlotte078"]
[OnName num="charlotte"]
I'll see you later. Be careful.
[cpg cn=true]


I can't be just Charlotte's today.
[cpg]


I'm also wondering what Charlotte thinks about that.
[cpg]


[OnName num="daigo"]
I'm wondering what Charlotte thinks about that. "...... Hey, Charlotte. Don't you think what I'm doing is cheating on you?
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Charlotte079"]
[OnName num="charlotte"]
I don't think it's cheating. It's cheating because it's flirtatious, isn't it?　Then it's not, is it?
[cpg cn=true]


Sure it is. Charlotte is the only one I can truly ask for.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Chloe110"]
[OnName num="chloe"]
Totally, you guys are ......."
[cpg cn=true]


Chloe wanted to say something, but I didn't say anything.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





The happy days go on. It seemed as if it would go on forever.
[cpg]


But as the day of the birth approached, one concern emerged.
[cpg]


It was ...... still Charlotte's frail constitution.
[cpg]


Would she be able to deliver the baby safely?
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe111"]
[OnName num="chloe"]
'You're worried about Charlotte again, aren't you?
[cpg cn=true]


[OnName num="daigo"]
You know exactly what I mean.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe112"]
[OnName num="chloe"]
I was closest to you. Now Charlotte has taken her place.
[cpg cn=true]


Chloe is quite jealous, isn't she? While thinking about such things,......
[cpg]


The worries are endless. It's something I won't know until the day comes after all.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夕方）******************************************************



And today, I'm back home again. Charlotte's presence was becoming my reason for living.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Chloe113"]
[OnName num="chloe"]
I'm going to go back to my house today. Daigo-sama.
[cpg cn=true]


[OnName num="daigo"]
"Oh, I'll see you tomorrow. See you tomorrow.
[cpg cn=true]


I said goodbye to Chloe.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se007"]
;//【ＳＥ】『ドア開く』




[OnName num="daigo"]
I'm home. Charlotte.
[cpg cn=true]


[VOICE f="Charlotte080"]
[OnName num="charlotte"]
"Welcome home. Dinner's ready.
[cpg cn=true]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（夜）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte081"]
[OnName num="charlotte"]
Hey, Daigo,...... when there were still men in the world, there was the idea of a married couple.
[cpg cn=true]


[OnName num="daigo"]
Yeah,......, so did the world I was in.
[cpg cn=true]


Charlotte was the perfect wife.
[cpg]


But the concept of husband and wife does not exist in this world. There are no men.
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧエロ（体を起こしているヒロイン。主人公とキスをする）ev_32
;//人物１：ヒロイン３
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：ヒロイン３の家＿寝室
;//時間　：夜
;//備考　：ヒロインは妊娠六ヶ月くらいです
;//備考２：11.bmpのシーンです
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_32_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="Charlotte082"]
[OnName num="charlotte"]
If people from other worlds saw me and you ......, maybe we would look like a married couple.
[cpg cn=true]


[OnName num="daigo"]
I'm sure they would. Because you're the only one for me."
[cpg cn=true]



[VOICE f="Charlotte083"]
[OnName num="charlotte"]
Heh. Glad to hear it ...... Daigo."
[cpg cn=true]


Charlotte laughs when she says that. And then.
[cpg]

;**【ＣＧ】 ev_32_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="Charlotte084"]
[OnName num="charlotte"]
"Kiss me,......."
[cpg cn=true]


I nodded and put my lips to hers. I nodded and put my lips to hers.
[cpg]

I would do anything she wants.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（夜）******************************************************





There are still so many things I want to do for her.
[cpg]


We can still be happy ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（朝）******************************************************



More time passes. Step by step, the due date approaches.
[cpg]


This world, too, is equipped for just having a baby. But ......
[cpg]


The baby to be born is a boy. So we talked about taking precautions.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





The safest place in the world to give birth to a child. And the place with the best doctors was the castle.
[cpg]


Charlotte and I went back to the castle. It wasn't that I didn't like it, but ......
[cpg]


I was not happy about it. I wondered if Charlotte would be all right.
[cpg]



[VOICE f="Charlotte085"]
[OnName num="charlotte"]
I was thinking, "Don't worry about her. I still have a lot of things I want to do with Daigo. ......
[cpg cn=true]


Charlotte said something similar to what I was thinking.
[cpg]


I couldn't help but love that. ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





When her child was finally going to be born, it was in the evening.
[cpg]


She told me to wait in my assigned room. So that's what I had to do.
[cpg]


They said they couldn't help it if I stayed by their side. It was pathetic, but I had no choice but to leave it to the women.
[cpg]


The setting sun shines on me, alone. I feel indescribable.
[cpg]


All I can do is get impatient, and there is nothing I can do about it.
[cpg]


Even now, I can almost hear Charlotte's voice as she endures the pain.
[cpg]


I wonder how she is doing now. I think she must be in unimaginable pain.
[cpg]


Of course, that's just my imagination, but that's how I felt. ......
[cpg]


And then we wait. Waiting, waiting for hours. ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Chloe114"]
[OnName num="chloe"]
"Daigo-sama!"
[cpg cn=true]


Chloe came. I couldn't say anything right away.
[cpg]


[OnName num="daigo"]
What's wrong? You were born?
[cpg cn=true]


Chloe seemed to be upset, too. I had never seen her like this.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe115"]
[OnName num="chloe"]
Yes, mother and child are both healthy ...... and ......."
[cpg cn=true]


With tears in her eyes, Chloe said, "We have a baby boy.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chloe116"]
[OnName num="chloe"]
A boy has been born."
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I hurried over to Charlotte.
[cpg]


She must have been in a lot of pain, she looked so tired that she couldn't hide her exhaustion.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte086"]
[OnName num="charlotte"]
'Oh ...... Daigo, I'm so ...... glad you're here.'
[cpg cn=true]


I was also about to cry, but I managed to hold it in.
[cpg]


[OnName num="daigo"]
'Good ...... you did well, Charlotte.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte087"]
[OnName num="charlotte"]
I thought I was going to die from the pain, but I managed ...... ehehe."
[cpg cn=true]




[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





A child was born resistant to the plague. The news traveled across the country.
[cpg]


It was unmistakably me, Charlotte, and our child in the middle of the news.
[cpg]


[OnName num="woman_A"]
It is truly a miracle that a boy was born. ......
[cpg cn=true]


[OnName num="woman_B"]
It's Daigo-sama's child, isn't it?
[cpg cn=true]


[OnName num="woman_C"]
I know it is. There's no one else to carry the child.
[cpg cn=true]


[OnName num="woman_A"]
At any rate,...... this will save the world.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（昼）******************************************************





We were living in Charlotte's house again, not in the castle.
[cpg]


We would raise the baby in Charlotte's house.
[cpg]


I was a bit confused, too, because I wasn't used to this, but I felt like a father.
[cpg]



;//========================================
;//●ＣＧ非エロ（座って赤子を抱くヒロイン３。幸せそうな表情）ev_33
;//人物１：ヒロイン３
;//服装１：着衣
;//場所　：ヒロイン３の家＿寝室
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=100]



[OnName num="daigo"]
......This is going to save the world, isn't it?"
[cpg cn=true]


I murmured to Charlotte.
[cpg]



[VOICE f="Charlotte088"]
[OnName num="charlotte"]
I was so excited. It's all thanks to Daigo.
[cpg cn=true]


She replied with a calm expression on her face.
[cpg]


Charlotte was holding a baby in her arms. It's our child.
[cpg]



[VOICE f="Charlotte089"]
[OnName num="charlotte"]
Hey, Daigo," she said, "we're going to be happy, aren't we? We're going to be happy, aren't we?
[cpg cn=true]


She said that to me, but I didn't want her to ask me that.
[cpg]


[OnName num="daigo"]
Don't ask the obvious. Yes, we need Daisy to exorcise the plague.
[cpg cn=true]


I had forgotten until just now. I had been too focused on whether or not Charlotte would be able to have the baby safely.
[cpg]


Charlotte nodded at my words and said.
[cpg]



[VOICE f="Charlotte090"]
[OnName num="charlotte"]
'Yes, I suppose so. I have this baby to take care of, so just go with Daigo."
[cpg cn=true]


Oh no. I couldn't do that.
[cpg]


[OnName num="daigo"]
I can't do that. I said, "Charlotte, let's go with you.
[cpg cn=true]


I said, and we decided to take Charlotte and our child to the Elven Forest.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************





Charlotte had risen in status by giving birth to a boy. She was no longer a mere noblewoman.
[cpg]


She was not royalty by any means, but she was still treated well.
[cpg]


The carriage took him to the elven forest.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（夕方）******************************************************





[OnName num="daigo"]
I see,......," said Daisy.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA06_p2_01_a.ui" method="change_3"  pos="2/2" time=800]

[VOICE f="Daisy035"]
[OnName num="daisy"]
I see,...... that you have saved the world in your own way.
[cpg cn=true]


I'm not saying in my own way, I'm just doing what I can do.
[cpg]


The best way to do this is to get a good, clean, healthy, and healthy diet.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Charlotte091"]
[OnName num="charlotte"]
I also want to ask you to do something for me. Please help Daigo.
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Daisy036"]
[OnName num="daisy"]
Well, that was the deal. I'm not going to make any mistakes.
[cpg cn=true]


[OnName num="daigo"]
Then go to .......
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Daisy037"]
[OnName num="daisy"]
Yes. I'm going to exorcise your plague. It's not a ceremony that will last more than a day or two, so you'll have to stay a while. ......
[cpg cn=true]


At last, we were coming to an end.
[cpg]


It feels like it's been a long time to get to this point, but I'm going to be saved. ......
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（昼）******************************************************





Three days and three nights passed from there. The elves were preparing something.
[cpg]


They were drawing a huge magic circle on the ground. Meanwhile, we were acting as weights for our child.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte092"]
[OnName num="charlotte"]
He too seems to be at a loss in a place he's not used to.
[cpg cn=true]


[OnName num="daigo"]
I'm sure he is. ......
[cpg cn=true]


I held her in my arms. I felt the weight of life.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte093"]
[OnName num="charlotte"]
I'll stay with Daigo for as long as I can bear the child.
[cpg cn=true]


[OnName num="daigo"]
"You say so, but ...... you're sickly, aren't you?"
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte094"]
[OnName num="charlotte"]
I'm sure I am, but I'll be fine."
[cpg cn=true]


I say that with no basis in fact. But I wanted to have at least one more child too.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（夜）******************************************************





And then night. I stood in the center of the completed magic circle and had the plague exorcised.
[cpg]


Whether it worked or not, there was no way for me to know for sure.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Daisy038"]
[OnName num="daisy"]
"It worked. ...... Don't worry, you're safe now."
[cpg cn=true]


[OnName num="daigo"]
"Really ......?　I don't feel it.
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy039"]
[OnName num="daisy"]
I know you don't, but you have to take our word for it.
[cpg cn=true]


I know, I know. And even if the plague isn't exorcised, it's still the same.
[cpg]


I'll be with Charlotte for the rest of my life. That's all there is to it.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『平原』（朝）******************************************************





And then we were back in the castle town. We were on the plains.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte095"]
[OnName num="charlotte"]
Charlotte soothes the child.
[cpg cn=true]


Charlotte soothed the child. She looked like a mother.
[cpg]


[OnName num="daigo"]
Charlotte was the mother of the child. You want to make a plan for the second one?
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte096"]
[OnName num="charlotte"]
Charlotte was looking at the child, her mother's face. I want a boy next time.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（昼）******************************************************





And my role remained the same.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe117"]
[OnName num="chloe"]
I'm sorry, but if the plague has been exorcised, we have no recourse to you. But now that the plague has been exorcised, we have no choice but to turn to you.
[cpg cn=true]


[OnName num="daigo"]
"Yeah, I'm fine. I'll be fine, but Charlotte can ......
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte097"]
[OnName num="charlotte"]
I'll be fine. I'm not jealous. I believe in Daigo.
[cpg cn=true]


I knew she would say that. Charlotte would understand everything about me.
[cpg]


I want to understand everything about Charlotte.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Charlotte means a lot to me. I think I could be someone who matters to Charlotte, too.
[cpg]


And she is also an important part of ...... our family.
[cpg]


One thing I worry about is the fate that awaits her as a man.
[cpg]


But I had a feeling that even that ...... would be manageable.
[cpg]


Charlotte can give birth to a boy who is resistant to the plague. If she goes on to have more children, grandchildren, and great-grandchildren, there will be more and more men.
[cpg]


And I hope the world will come to a point where everyone can fall in love freely.
[cpg]


[SCENE id=13]

;//ＥＮＤ　ヒロイン３ルート
[jump storage="epend.ks" target="*start"]

