
*start

;#################################################
*Ep009|Just do what I want to do.
;#################################################


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_sl"]
[WAIT time=100]


*VectorEvil2|Just do what I want to do.

[SCENE id=9]



No. I don't know what to do.
[cpg]


I do what I want to do. What's the reason to hesitate?
[cpg]


What about the people? If there is growing discontent, let them be discontent on their own.
[cpg]


Whether the nation is overturned or not, it doesn't change what I do. ......
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（昼）******************************************************



From then on, I would ignore the words of Lily and Chloe and love only Lily.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily195"]
[OnName num="lily"]
"If ...... this continues, there will indeed be a riot. Even if it doesn't, the vassals are distrustful."
[cpg cn=true]


[OnName num="daigo"]
'I'll make sure that doesn't happen. You just have to deal with the key political guy."
[cpg cn=true]


I will create a situation where everyone will follow my orders. I will do whatever it takes to achieve that.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





That's why I've been trying to deal with Chloe, the prime minister, and Charlotte, the aristocrat, and others. ......
[cpg]

But still, I basically stayed by Lily's side. The other people were just an added bonus.
[cpg]





[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（昼）******************************************************





[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte112"]
[OnName num="charlotte"]
The other two are the same person, but they're not the same person. Are you going to keep going on like this?
[cpg cn=true]


[OnName num="daigo"]
What? You're telling me what to do?
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte113"]
[OnName num="charlotte"]
"Yeah, I know how you feel. I understand how you feel, but I can't love just one person in this world.
[cpg cn=true]


[OnName num="daigo"]
......
[cpg cn=true]


It was a good argument. But I was not going to follow it.
[cpg]


The thing that I'm saying, what I'm trying to do is wrong. I knew that, but I went ahead with it.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte114"]
[OnName num="charlotte"]
I knew it was wrong, but I went ahead with it. I'm worried about you, okay?"
[cpg cn=true]


[OnName num="daigo"]
'Shut up, .......'
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Charlotte115"]
[OnName num="charlotte"]
But I'm doing it for my brother's sake. ......
[cpg cn=true]

;//[t_move pos=C 動揺]
[OnName num="daigo"]
Shut up!"　Women should just do what men tell them to do."
[cpg cn=true]


I yell at Charlotte in frustration.
[cpg]


She freaked out and didn't say anything.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Charlotte116"]
[OnName num="charlotte"]
I said, "I'm sorry, ......."
[cpg cn=true]


I felt indescribable when I saw her apologize.
[cpg]


I wondered if this is what I wanted,......, and I thought, "Yes, this is what I should have wanted.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（昼）******************************************************





In the meantime, Lily's stomach was growling.
[cpg]


I realize that a lot of time has passed. It must have been four months since she got pregnant. ......?
[cpg]


All the while, I kept my eyes only on the political centerpiece.
[cpg]



;//ブラックアウト

;//========================================
;//●ＣＧエロ（ベッドに倒れ込んでいるヒロイン）ev_61
;//人物１：ヒロイン１
;//服装１：着衣（はだけ）
;//人物２：主人公
;//服装２：着衣
;//場所　：城内＿ヒロイン１の部屋
;//時間　：昼
;//備考　：ヒロインは妊娠四ヶ月くらいです
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_61_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=100]

Today, as usual, I flirt with Lily.
[cpg]



[VOICE f="Lily196"]
[OnName num="lily"]
'Daigo-dono,...... really, are you sure you want to do this?
[cpg cn=true]


[OnName num="daigo"]
What?　Are you going to meddle?"
[cpg cn=true]


Lily goes silent. If you have something to say, just say it.
[cpg]


But whether or not I'm going to listen to it is another matter.
[cpg]


[OnName num="daigo"]
You're happy to have me all to yourself, aren't you?
[cpg cn=true]

;**【ＣＧ】 ev_61_a ***********************
[CG id=17 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Lily197"]
[OnName num="lily"]
"That's true, but ......
[cpg cn=true]


[OnName num="daigo"]
You're still trying to say something.
[cpg cn=true]


[VOICE f="Lily198"]
[OnName num="lily"]
"Oh, ......."
[cpg cn=true]


I forcibly took her lips and silenced her.
[cpg]

Of course, there are some things you can't cover up with something like this.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夜）******************************************************





Two more months pass.
[cpg]


Discontent is growing among the people. I can no longer go out and walk around carelessly.
[cpg]


I was almost kidnapped when I was walking in the castle town before. I was almost kidnapped by someone who was not a bandit.
[cpg]


I guess they are trying to recapture me from the royalty.
[cpg]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe163"]
[OnName num="chloe"]
Things are not looking good.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily199"]
[OnName num="lily"]
"...... Yes. A nation cannot exist without its people. ......
[cpg cn=true]


He talks like that in front of me, as if he's trying to get me to do something.
[cpg]


[OnName num="daigo"]
I don't care about the people. I've made up my mind."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Lily200"]
[OnName num="lily"]
You can't just say that ...... again.
[cpg cn=true]


[OnName num="daigo"]
I said I'm only going to love Lily. What's wrong with that?
[cpg cn=true]

[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
Lily looked down. Chloe looked serious.
[cpg]

;//ブラックアウト

;//ブラックアウト

We kissed each other on the mouth. All I wanted was Lily.
[cpg]

I don't know if it's fate or what, but I don't want to be obliged to do that.
[cpg]


Of course, the people would not agree. Chloe is working hard to put out the fire.
[cpg]


I've been turning those things over to others. Even though she knew that one day it would be too much.
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（昼）******************************************************



[FG f="CHA01_p2_01_a.ui" method="change_4"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]


And the time has come when the bill for everything will come due.
[cpg]

[OnName num="soldier"]
"Chloe!　The people are pouring into the castle.
[cpg cn=true]

The soldiers had come to Lily's room looking impatient.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe164"]
[OnName num="chloe"]
...... how long do you think you can hold out?"
[cpg cn=true]


Chloe seemed calm, but did that mean she was prepared?
[cpg]


[OnName num="soldier"]
'I can't hold it any longer,......!　No matter how much, we are outnumbered."
[cpg cn=true]


Chloe nodded in response to the soldier's words.
[cpg]


[OnName num="daigo"]
'...... what are you going to do?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe165"]
[OnName num="chloe"]
I'm going to make you run away, Your Majesty. Run away, you may possibly be treated as a guilty person for monopolizing Daigo-sama."
[cpg cn=true]


Lily is shocked by Chloe's words.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Lily201"]
[OnName num="lily"]
'Oh no. ......!　I can't just run away and leave everyone behind.
[cpg cn=true]


Chloe sighs at Lily's sad words.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe166"]
[OnName num="chloe"]
If you won't run away, then be prepared for whatever happens. I can't be responsible for this.
[cpg cn=true]


Lily looked lost. I'm going to encourage her. That is, ......
[cpg]


[OnName num="daigo"]
"Let's be open to the end, Lily," I said, "we just made love. We just made love.
[cpg cn=true]


Come to think of it, I was just trying to make her my own.
[cpg]


If that is a sin, then there is no such thing as love in this world.
[cpg]


I did nothing wrong. Lily is not to blame either.
[cpg]


[OnName num="daigo"]
"Chloe, go back to your post. I need to talk to Lily.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



Lily and I must be separated. We're both going to be treated like sinners.
[cpg]


[OnName num="daigo"]
"Did ...... I do something wrong ......?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Lily202"]
[OnName num="lily"]
No, nothing. ...... I love you, too.
[cpg cn=true]


I don't know how I let this happen. ......
[cpg]

;//移植のためシーンをカットしています

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


The last time. We were spending Lily's last moments as queen.
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夕方）******************************************************





[OnName num="woman_A"]
"There you are!　There you are, both of you. ......!
[cpg cn=true]


[OnName num="woman_B"]
How dare you monopolize us all this time!　You don't even know how we feel!"
[cpg cn=true]


Lily was silent. At the end, the moment she was seized, she didn't resist anything.
[cpg]


I was me, and I did nothing, knowing that a harsh fate probably awaited me in the future.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



......And then.
[cpg]


Lily and Chloe were treated as sinners who moved to monopolize me.
[cpg]


The state has transformed into such a state where politics is conducted not by royalty, but by people elected by the people.
[cpg]


Democracy does not sprout so easily. Maybe other countries have already been like this.
[cpg]


In any case, my actions are now more strictly controlled than ever.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（夜）******************************************************





In the end, I never got to meet Lily or her daughter.
[cpg]


We just loved each other.
[cpg]


I don't know where I ...... went wrong. ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[SCENE id=17]

;//ＥＮＤ　ヒロイン１悪ルート
[jump storage="epend.ks" target="*start"]


