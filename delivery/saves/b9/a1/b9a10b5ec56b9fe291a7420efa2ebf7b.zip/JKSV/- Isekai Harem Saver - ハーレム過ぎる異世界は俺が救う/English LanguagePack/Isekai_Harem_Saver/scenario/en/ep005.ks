
*start


;#################################################
*Ep005|Betting on Martina's Story
;#################################################

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************


*select05_2|Betting on Martina's Story

[SCENE id=5]

;//ブラックアウト





I make up my mind. I'll bet everything on what Martina said.
[cpg]


It's the most eyebrow-raising, but it's the least risky.
[cpg]


For example, if I drop Daisy, if I make a mistake, it could have the exact opposite effect.
[cpg]


I am also concerned about Charlotte's frailty. Then, there was no other choice.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





So, I immediately tried to contact Martina.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe118"]
[OnName num="chloe"]
"Martina ......?　Do you believe what she says?"
[cpg cn=true]


[OnName num="daigo"]
"Yes, I believe her. I have no other choice.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe119"]
[OnName num="chloe"]
But ...... it's hard to believe it no matter how you think about it. It seems to me that she is lying to free herself.
[cpg cn=true]


[OnName num="daigo"]
If so, I need to be sure it's a lie.
[cpg cn=true]


If I were to act differently, it would be after destroying the possibility.
[cpg]


If possible, there is the least amount of uncertainty. I had to try.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Chloe120"]
[OnName num="chloe"]
Please don't make the mistake of deciding whether or not to let me out of ...... jail."
[cpg cn=true]


[OnName num="daigo"]
Don't worry. Besides, even you won't allow it.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe121"]
[OnName num="chloe"]
'Well, that's true, but...'
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（昼）******************************************************





So, I came to the dungeon.
[cpg]


[FG f="CHA05_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina025"]
[OnName num="martina"]
"You or ...... get me out of here for good!"
[cpg cn=true]


[OnName num="daigo"]
"Yeah, I'll let you out. I'll let you out, but let me tell you a story.
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Martina026"]
[OnName num="martina"]
"You mean the one about the two women getting pregnant?　If I tell you, you'll let me out?
[cpg cn=true]


[OnName num="daigo"]
I promise.
[cpg cn=true]


The truth is, I can't make promises on my own.
[cpg]


I can't make a promise on my own. I used to be so powerful that I could shake the country. It's not an easy decision to make.
[cpg]


[FG f="CHA05_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina027"]
[OnName num="martina"]
I'm sorry, but I'm not in the mood for ...... talk. I'm not in the mood to talk, and this dark place isn't helping.
[cpg cn=true]


[OnName num="daigo"]
What do you want to say? I'm just asking you to be frank.
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Martina028"]
[OnName num="martina"]
I need some sunlight. Maybe then I'll be in the mood to talk.
[cpg cn=true]


You're talking about reversing the order of things. They are going to let him out and then they are going to talk to him.
[cpg]


But that's not going to happen. I don't trust him.
[cpg]


[OnName num="daigo"]
The moment we let him out of jail, he might run away.
[cpg cn=true]


If that happens, not only will we miss our only lead, but we will leave the bandit on the loose. We have to be very careful.
[cpg]


[FG f="CHA05_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Martina029"]
[OnName num="martina"]
Then I have nothing to say to you.
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

From there, I negotiated with Martina for a long time, but she would not talk.
[cpg]


However, forcing them to listen to her is also a humanitarian issue.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

In addition to the usual routine, I had the added task of getting Martina to open up.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************



Around evening, I return to the castle and go to question Martina.
[cpg]


[OnName num="daigo"]
"Shall we go to ...... hey, Chloe?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe122"]
[OnName num="chloe"]
You're heading to ...... Martina's place, aren't you?"
[cpg cn=true]


[OnName num="daigo"]
You look like you don't want to go. Are you that anxious?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe123"]
[OnName num="chloe"]
'It's, well. I'm always anxious to make the right decision.
[cpg cn=true]


Well, I don't know how you feel. ...... I've been acting selfishly too.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（夕方）******************************************************





[OnName num="daigo"]
Martina, are you awake? Are you awake?"
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina030"]
[OnName num="martina"]
"...... you're here again?"
[cpg cn=true]



[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Martina031"]
[OnName num="martina"]
I'm not going to tell you what they did to me,.......
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



The longer she remained in prison, the weaker Martina became.
[cpg]


Clearly, her spirit was not strong. I wonder how she was able to serve as the leader of the bandits.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夜）******************************************************





When I passed by Lily's room. I suddenly overheard their conversation.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Lily126"]
[OnName num="lily"]
How is Martina? How is Martina?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe124"]
[OnName num="chloe"]
She's very weak. She's very weak. ......
[cpg cn=true]



[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Lily127"]
[OnName num="lily"]
But then again, ...... if women really could have children with each other.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe125"]
[OnName num="chloe"]
We would be saved. If only it were true.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************



The next day. The next day, I walk through the city with my escort.
[cpg]

Everyone there is looking for me.
[cpg]

It means that, like Martina, it is quite rare to be a man-hater.
[cpg]

It's ...... that's why, if women could have children with each other, it would turn even their ethics upside down.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（夕方）******************************************************


And I headed off to the dungeon again.
[cpg]




;//ブラックアウト

;//========================================
;//●ＣＧエロ（迫られ、追い詰められるヒロイン。涙目になっている）ev_37
;//人物１：ヒロイン５
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：城内＿地下室
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_37_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="Martina032"]
[OnName num="martina"]
What are you ...... doing?"
[cpg cn=true]


I pressed Martina. She was in tears and didn't want to do it.
[cpg]

[OnName num="daigo"]
I said, "What, you'll tell me what you're going to do?
[cpg cn=true]


[OnName num="daigo"]
I can do anything you want, and you're not going to talk to me anyway.
[cpg cn=true]


[VOICE f="Martina033"]
[OnName num="martina"]
'...... yeah. If you're going to tell me anything, you're going to have to get me out of here first."
[cpg cn=true]


You're surprisingly stubborn. But that makes it worth hunting down.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





But will he really start talking if I continue like this?
[cpg]


Maybe there's no talking itself. In other words, he is lying.
[cpg]


I didn't have that question, but I couldn't do anything if I kept thinking about it.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe126"]
[OnName num="chloe"]
I wondered, "Will ...... Martina ever talk?"
[cpg cn=true]


Chloe, who was in the room, says so. I'm thinking the same thing.
[cpg]


[OnName num="daigo"]
I'm not asking you to do that either," she said.
[cpg cn=true]


For me, she's my only recourse. If she's lying about having a child with a woman from the beginning, ......
[cpg]


No, I still shouldn't think about it. It seems unlikely even as a possibility.
[cpg]


I also thought that this is not a lie that comes out on the spur of the moment.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『平原』（朝）******************************************************



Still, my anxiety is growing. I decided to research the history of this world.
[cpg]


Especially, I thought that elves, who have a longer lifespan than humans, might know something about it.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（昼）******************************************************





[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy040"]
[OnName num="daisy"]
"Pregnancy between women ......?　Sure, there are legends about that.
[cpg cn=true]


[OnName num="daigo"]
"Is there? Tell me more about it.
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy041"]
[OnName num="daisy"]
No one knows the details," he said. If we knew that, the world wouldn't need men anymore.
[cpg cn=true]


That's true. ...... But then I continued, "Maybe there is a way.
[cpg]


[OnName num="daigo"]
"Maybe there is a way to do that. Daisy, would you be willing to help with the investigation?"
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy042"]
[OnName num="daisy"]
'...... that's an interesting story.
[cpg cn=true]


[OnName num="daigo"]
Well, will you come to town with me?
[cpg cn=true]


Daisy thought about it and agreed.
[cpg]


She wanted to have a child, too. It was a natural decision.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夕方）******************************************************



And then, we made the long trip back to town again. I was indeed tired, but I was not discouraged.
[cpg]


Now, I have to torture Martina again today.
[cpg]


With that in mind, I met Charlotte on my way to town.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte098"]
[OnName num="charlotte"]
'Big brother...... hasn't been coming to my place lately.
[cpg cn=true]


[OnName num="daigo"]
She said, "Oh. I've found another purpose.
[cpg cn=true]


Charlotte has a complicated expression on her face. Maybe she's a girlfriend and wants to monopolize me.
[cpg]


I think I had that future. Charlotte is the only woman who might be able to have a boy.
[cpg]


But I didn't go down that road. I spent a lot of time and effort getting the truth out of Martina.
[cpg]


I couldn't afford to take any half-hearted action now. With that in mind, I said goodbye to Charlotte.
[cpg]


[OnName num="daigo"]
'So ...... I'll bother you again when I've achieved my goal.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Charlotte099"]
[OnName num="charlotte"]
I promise. I believe in you.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（夜）******************************************************



And inside the castle. I come to the basement and visit Martina again.
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧエロ（壁にもたれているヒロイン。弱っている）ev_38
;//人物１：ヒロイン５
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：城内＿地下室
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_38_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="Martina034"]
[OnName num="martina"]
She goes to ......."
[cpg cn=true]


She leans against the wall and stops talking.
[cpg]


[OnName num="daigo"]
'It's about time you decided to speak.
[cpg cn=true]



[VOICE f="Martina035"]
[OnName num="martina"]
'...... please ...... let me out.
[cpg cn=true]


[OnName num="daigo"]
I've told you a thousand times I can't do that."
[cpg cn=true]


Martina is the one who doesn't get it. But there is no doubt that he is weak.
[cpg]


[OnName num="daigo"]
I'm sure he's a weak man. Wouldn't it be better for both of us if you talked to me before you leave here?
[cpg cn=true]


[OnName num="daigo"]
I'm just afraid you'll run away before you can talk.
[cpg cn=true]


[OnName num="daigo"]
I wouldn't have mistreated you if you'd been useful.
[cpg cn=true]


;**【ＣＧ】 ev_38_a ***********************
[CG id=12 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Martina036"]
[OnName num="martina"]
...... Really, really?"
[cpg cn=true]



;//移植のためシーンをカットしています

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Martina began.
[cpg]



;//画面をセピア調にしてください


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************





;//[FG f="CHA05_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina037"]
[OnName num="martina"]
We used to have a hideout in ...... an abandoned building.
[cpg cn=true]


[OnName num="daigo"]
Ruins?　What kind of ruins?
[cpg cn=true]


;//[FG f="CHA05_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Martina038"]
[OnName num="martina"]
It was a dump in the middle of a plain as far as the eye could see. It looked like the remains of a temple or something.
[cpg cn=true]


A ruined temple. That's what it looked like.
[cpg]


[OnName num="daigo"]
So?　And that's where you were pregnant?
[cpg cn=true]


;//[FG f="CHA05_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina039"]
[OnName num="martina"]
Yes, two of my ...... men were pregnant at the same time. They were in love.
[cpg cn=true]



I dig deeper and deeper into this interesting story.
[cpg]



;//色調を元に戻してください



;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



After she was pregnant with the child, Martina and the others, who felt uneasy, changed their hideout.
[cpg]


The ruins of the temple are quite far from here. However, it seems that it is not impossible to get there by horse-drawn carriage.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（夜）******************************************************





[OnName num="daigo"]
I see. Thank you.
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina040"]
[OnName num="martina"]
I never thought I'd be thanked by you. Well, that's all you have to say. ......
[cpg cn=true]


[OnName num="daigo"]
"Here's a thank-you. It's nice of you.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Martina041"]
[OnName num="martina"]
What?　That's not what you said!
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I pressed Martina again. I didn't even let her out of the dungeon, just in case.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（朝）******************************************************





From there, we went about our business.
[cpg]


Lily and Chloe were interested in what I had to say.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy043"]
[OnName num="daisy"]
I asked Lily and Chloe if I could join in on the action. I really want to have a baby.
[cpg cn=true]


[OnName num="daigo"]
I said, "Yes. You can come with me, too.
[cpg cn=true]


It's going to be a pretty big group. Lily, being the queen, can't leave the castle much, but ......
[cpg]


Chloe was to accompany her. Of course, she will be accompanied by an escort.
[cpg]


[free time=1000]


[OnName num="daigo"]
Maybe we can bring some commoners with us later on.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe127"]
[OnName num="chloe"]
Why?"
[cpg cn=true]


[OnName num="daigo"]
'You can't prove that there aren't also women who aren't related to me. Even if she did get pregnant, it might be my baby.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe128"]
[OnName num="chloe"]
I'm sure that's true. I'll start recruiting them.
[cpg cn=true]


But first we have to make sure that the temple is really there.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『平原』（昼）******************************************************



[SE f="se000"]
;//【ＳＥ】『馬車走る』


From there, we will drive the wagon to the temple.
[cpg]


Indeed, there remained a battered temple there, with almost only pillars.
[cpg]


According to Martina, two people in love were pregnant at the same time.
[cpg]

[OnName num="daigo"]
I wonder at what point they had the child ......."
[cpg cn=true]


Because it is not between a man and a woman, children are not inherently possible.
[cpg]

So, it could have been at any time ......
[cpg]

Trouble was, we couldn't get any clues about the temple either.
[cpg]

;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************


So we decided to spread rumors among the commoners.
[cpg]

It would be bad if we struck out with a big proclamation, "If you get married at that temple site, you will have a child.
[cpg]

On the other hand, we felt that no one would go if we declared that we had heard this information from bandits and that its authenticity was not certain.
[cpg]

After consulting with Lily and the others, they came to the conclusion that they would spread a rumor that seemed to be true.
[cpg]


[OnName num="woman_A"]
Did you hear about the temple ruins?　The story of the temple ruins. ......
[cpg cn=true]


[OnName num="woman_B"]
Yes. I can't believe it ...... that if you get married, you can have children.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************



In this world, it seems that same-sex relationships are a rather common occurrence.
[cpg]


That's naturally so, I thought, but it was a strange feeling.
[cpg]


If this works out, there will be no need to summon a man.
[cpg]


A paradise where there are only women as far as the eye can see would really be established.
[cpg]


If men would not even interfere, it would be a dream come true in a sense. ......
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily128"]
[OnName num="lily"]
Daigo-dono. It is time for you to go.
[cpg cn=true]


[OnName num="daigo"]
Oh, I know. I know.
[cpg cn=true]


If that temple had some mysterious power and could conceive a child, I'd be out of a job too, I thought.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『城下町』（夜）******************************************************





A few moments pass.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************



Then, a little time passes, and I hear some startling news. Namely, ...... that a commoner, unrelated to me, is pregnant.
[cpg]



[OnName num="daigo"]
I thought to myself, "Great. ...... Really, really?"
[cpg cn=true]


I wonder what the logic is. Even in the world I was in, female-to-female couples can't have children.
[cpg]


There was talk of a pluripotent cell that would make it happen or something, but even so, it was something that had yet to become a reality.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************



More days went by, and other commoners became pregnant.
[cpg]


[OnName num="daigo"]
I can't let this happen. ...... This is a big deal.
[cpg cn=true]


This world could be saved. My life might be saved.
[cpg]


The second half is what I'm thinking, but the first half is what the whole nation is thinking.
[cpg]


It didn't take Lily to order the restoration of that temple. ......
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（夜）******************************************************





[FG f="CHA05_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina042"]
[OnName num="martina"]
"...... long time no see, Daigo."
[cpg cn=true]


[OnName num="daigo"]
Oh. It seems everything you told me was true.
[cpg cn=true]



[VOICE f="Martina043"]
[OnName num="martina"]
There's no merit in lying. Did you ever doubt that?
[cpg cn=true]


[OnName num="daigo"]
This world is going to be saved because of you. You're going to save the world and, in turn, my life. Thank you.
[cpg cn=true]


He thanked Martina again.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Martina044"]
[OnName num="martina"]
If you're going to thank me, you might as well get me out of here.
[cpg cn=true]


Now let's see what we're going to do. I don't think they'll retaliate now, but we must not make the wrong decision.
[cpg]


[FG f="CHA05_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina045"]
[OnName num="martina"]
I'm ...... apparently pregnant with your child too.
[cpg cn=true]


[OnName num="daigo"]
Is that so?　No, I'm not.
[cpg cn=true]


[FG f="CHA05_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Martina046"]
[OnName num="martina"]
I don't want to have a baby in a place like this....... Please, Daigo."
[cpg cn=true]


It must be Martina who has done the most good.
[cpg]



;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト


If we get Martina out of here, I think we may be done with her.
[cpg]


If that happens, will she be a bandit again?　Would she learn her lesson from the quicksand?
[cpg]


[OnName num="daigo"]
I'll talk to Lily. I'll talk to Lily.
[cpg cn=true]


[FG f="CHA05_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Martina047"]
[OnName num="martina"]
Is that true, ......?　If you're lying, I'm not going to do it.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夜）******************************************************





[OnName num="daigo"]
Lily. Lily, I need you to get Martina out of here.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily129"]
[OnName num="lily"]
What are you talking about?　Have you forgotten what she did?
[cpg cn=true]


[OnName num="daigo"]
I haven't forgotten. I haven't forgotten what you've done to her, what you've done to her, what you've done to her, what you've done to her, what you've done to her.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily130"]
[OnName num="lily"]
Then why ......
[cpg cn=true]


[OnName num="daigo"]
She did a lot of good, didn't she? After all, without her, there would have been no way to prosper without a man.
[cpg cn=true]


In a way, Martina was also a savior. It is an undeniable fact.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Lily131"]
[OnName num="lily"]
But ...... no, that's true."
[cpg cn=true]


And in the end, Lily agreed.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夜）******************************************************





Then the temple was being restored.
[cpg]


Weddings would be performed and children would be given.
[cpg]


It was a miraculous power. In this world where there were many homosexuals to begin with, it was even desired.
[cpg]

Of course, that didn't stop them from needing me. ......
[cpg]





[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





[OnName num="daigo"]
Oops. ......
[cpg cn=true]




I saw Martina working in a tavern after she got out of jail.
[cpg]


She is cleaning the tavern in the daytime, before it opens.
[cpg]


[OnName num="daigo"]
'Martina. You've come to take your work seriously, that's great.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Martina048"]
[OnName num="martina"]
I'm not serious, I'm just doing what I have to do to survive.
[cpg cn=true]


Even as she said this, she looked a little clearer.
[cpg]


I guess it's partly because she' s been in jail all this time.
[cpg]


But the biggest change of all was that her stomach was distended.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina049"]
[OnName num="martina"]
She said, "I'm pregnant with your child, .......
[cpg cn=true]


[OnName num="daigo"]
I know," she said. I know, it must be hard for you, a man-hater, to bear it.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Martina050"]
[OnName num="martina"]
Yes,......, well, I'm not happy to let it go.
[cpg cn=true]


Oops. He seemed more or less pleased with the answer.
[cpg]


[OnName num="daigo"]
"Are you somewhat in love with me?"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Martina051"]
[OnName num="martina"]
"...... No way."
[cpg cn=true]


He blushed. I'm sure that's probably what this means.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

[OnName num="daigo"]
Well, I guess I'll just have to keep working diligently.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina052"]
[OnName num="martina"]
I don't need you to tell me what to do. ...... I can't live without it.
[cpg cn=true]


[OnName num="daigo"]
You still call me "you. Do you hate me that much?"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Martina053"]
[OnName num="martina"]
"I don't resent ...... you. In fact, I'm ...... grateful to you.
[cpg cn=true]


That's very honest for Martina. I decided to take it head on.
[cpg]


;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************



I was sure that word must have spread to the Elven Forest that I had restored the temple.
[cpg]


I wanted to leave for the Elven Forest right away, but I was a little concerned about Martina. ......
[cpg]


I was a little concerned about Martina.
[cpg]


I was thinking that I might make her my wife, or rather my only lover.
[cpg]


Well, could that come later? First, I had to head over to Daisy's place.
[cpg]


[OnName num="daigo"]
Chloe. I need you to go to the Elven Forest to exorcise the plague, okay?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe129"]
[OnName num="chloe"]
Yes. Yes, that's fine. ...... We don't want you to die, even if we do.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chloe130"]
[OnName num="chloe"]
More than being a man, you are the man who saved this world.
[cpg cn=true]


You seem to understand. I'm leaving tomorrow.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『平原』（朝）******************************************************



And I'm going to the elf forest with Chloe.
[cpg]

[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA05_p2_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Martina054"]
[OnName num="martina"]
Why, even I'm coming along ...... with you.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Chloe131"]
[OnName num="chloe"]
Daigo-sama's order. I won't let you say I won't obey.
[cpg cn=true]


I wanted to take Martina with me wherever I went.
[cpg]


[OnName num="daigo"]
Martina would want to be with me.
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Martina055"]
[OnName num="martina"]
Don't make up stories about things I didn't say.
[cpg cn=true]


[OnName num="daigo"]
You're not in love with me?　I thought you were in love with me."
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_4"  pos="2/2" time=800]
Martina said nothing more.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『エルフの森』（夕方）******************************************************





We finish our move and reach the elven forest.
[cpg]


[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Daisy044"]
[OnName num="daisy"]
'I've heard rumors. The elves are on their way to the temple.
[cpg cn=true]


[OnName num="daigo"]
I see. Well, then, can you exorcise the plague?
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Daisy045"]
[OnName num="daisy"]
But first, are you thinking straight?　What if another bandit takes over the temple?
[cpg cn=true]


Yes, that's exactly what I'm going to do. Yes, that's exactly what I'm going to do.
[cpg]


[OnName num="daigo"]
Lily's taking care of that.
[cpg cn=true]


[free time=1000]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA06_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Chloe132"]
[OnName num="chloe"]
Yes. Not as well as the castle, but we have soldiers stationed there. Don't worry about it.
[cpg cn=true]


[FG f="CHA06_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Daisy046"]
[OnName num="daisy"]
I don't know about that. ...... No, but we're going to get rid of your plague one way or another.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





And so, my plague was exorcised.
[cpg]


It was not a quick process, as it was quite a big magic trick.
[cpg]


Still, my body seemed to have escaped the plague.
[cpg]


I thanked Daisy and left the elven forest. ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





Some time has passed since then.
[cpg]


More pregnancies were born, and Martina's belly grew larger.
[cpg]


[OnName num="daigo"]
She said, "You've grown up so well. It's adorable.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina056"]
[OnName num="martina"]
"Pretty ......?　Is that me now?
[cpg cn=true]


[OnName num="daigo"]
"Yes, I feel more like a woman than before. I feel more like a woman than before.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Martina057"]
[OnName num="martina"]
Don't be silly,......, I don't want to raise a child.
[cpg cn=true]


She's still adamant. I'm sure she would raise a child if she had one.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Anyway, what I had to do wasn't necessarily necessary anymore.
[cpg]

That said, I was the one who triggered it, and it didn't diminish my position.
[cpg]


;//ブラックアウト


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（夕方）******************************************************


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

Then again, I came to the bar where she worked.
[cpg]

She said, "You look busy," and I nodded.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Martina058"]
[OnName num="martina"]
I nodded and said, "...... I'd like to be the only one you've got."
[cpg cn=true]


[OnName num="daigo"]
I nodded and said, "Oh, yeah. Jealous?"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina059"]
[OnName num="martina"]
No,...... I'm not jealous. It's just ......"
[cpg cn=true]


I said "just" and didn't finish.
[cpg]


I may be disloyal to Martina, but my role in this world is the same as it was when I was transferred here.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン３の部屋』（夕方）******************************************************



Today, I was supposed to go to Charlotte's. Charlotte might be able to give birth to a boy.
[cpg]


Charlotte might be able to give birth to a boy. She may have been taking that possibility into account.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte100"]
[OnName num="charlotte"]
I asked her, "Hey, big brother, you like this Martina person, don't you?"
[cpg cn=true]


[OnName num="daigo"]
......Who told you that?"
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte101"]
[OnName num="charlotte"]
I know you don't deny it. I knew it.
[cpg cn=true]


Charlotte looks a little sad.
[cpg]


[OnName num="daigo"]
"Chloe?　Well, that sounds like something she' d say"
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Charlotte102"]
[OnName num="charlotte"]
"No, it's not. It's the talk of the town."
[cpg cn=true]


Oh, that's the story, huh? Well, it's nothing to hide. ......
[cpg]


[OnName num="daigo"]
Yeah. I'm not exaggerating when I say he saved my world.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte103"]
[OnName num="charlotte"]
No, that's not what I'm asking. No, that's not what I'm asking. I'm going to ask you one more time, do you like Martina?
[cpg cn=true]


[OnName num="daigo"]
"......, that's ......."
[cpg cn=true]


It's hard to answer when someone else asks. But.
[cpg]


[OnName num="daigo"]
I'm not going to ask that question again. "Yes, I like her. I think he's cute."
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
My mind was made up. Charlotte smiled a little when she heard that.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************



I like Martina. I wonder what she thinks about it and many other things. ......
[cpg]


In any case, there is no doubt that Martina and I are attracted to each other.
[cpg]


[OnName num="daigo"]
Chloe. Can't we just invite Martina to the castle?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe133"]
[OnName num="chloe"]
...... can't be too much into her who used to be a bandit."
[cpg cn=true]


I knew that would be the case. I guess there's no point in saying it.
[cpg]


Well, we can change things little by little. The same goes for Martina herself.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町』（朝）******************************************************





I also see Martina at the bar before it opens. I decided to call out to her.
[cpg]


[OnName num="daigo"]
"Hello, Martina.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina060"]
[OnName num="martina"]
You ...... care about me so much again?
[cpg cn=true]


[OnName num="daigo"]
"Yes, of course. Of course I do, because I like you.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Martina061"]
[OnName num="martina"]
...... don't joke, it's embarrassing. It's embarrassing.
[cpg cn=true]


[OnName num="daigo"]
I'm not joking.
[cpg cn=true]


Martina blushed. I had a feeling she didn't mind.
[cpg]

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





And more time passes. ......
[cpg]


It had been ten months and ten days. She was about to give birth.
[cpg]


I wondered how advanced the medical care or medicine was in this world. ......
[cpg]


I heard that there are excellent doctors in the castle. Martina will give birth in the castle.
[cpg]


If she can give birth properly, that's all that matters. That's what I thought. ......
[cpg]


I couldn't be there for the birth, partly because I am a man.
[cpg]


I just waited in my room.
[cpg]


[OnName num="daigo"]
......"
[cpg cn=true]


Silence. It's quiet, the attendants are there, but no one says a word.
[cpg]


Waiting is a fidgety thing.
[cpg]


I felt as if I couldn't stand still, but I had to do nothing.
[cpg]


;//どれほど大勢を種付けしたところで、子供が産まれる瞬間に緊張するというのは変わらないらしかった。
No matter how many people I had impregnated, it seemed that the moment the child was born, I would always be nervous.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe134"]
[OnName num="chloe"]
Daigo-sama."
[cpg cn=true]


Chloe came in. I immediately questioned her.
[cpg]


[OnName num="daigo"]
'Oh, Chloe ...... how is Martina?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe135"]
[OnName num="chloe"]
I can't even look at her. I can't stand to look at her. I'm not a stranger to the fact that I'm going to have a baby one of these days, too.
[cpg cn=true]


Martina seemed to be in a lot of pain.
[cpg]


And also Chloe herself seems to be getting anxious.
[cpg]


That's right. Chloe's stomach is growling too.
[cpg]


[OnName num="daigo"]
It's frustrating that I can't ...... do anything about it."
[cpg cn=true]



[SE f="se002"]
;//【ＳＥ】『走る』





While I was saying this, I heard a flurry of running.
[cpg]


[OnName num="maid"]
'Daigo-sama!　It's born!"
[cpg cn=true]


I heard that and felt as if my heart had been grabbed.
[cpg]


[OnName num="daigo"]
Really?
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Martina had given birth to a child. I rushed to her.
[cpg]


Martina looked like she was dying. She must have been in a lot of pain.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Martina062"]
[OnName num="martina"]
"Oh, it's you. ......
[cpg cn=true]


She still seemed to recognize me.
[cpg]


[OnName num="daigo"]
"You did well, Martina," I said to her.
[cpg cn=true]


I called out to her. I replied, "You did well, Martina.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Martina063"]
[OnName num="martina"]
I thought I was going to die from the pain. I really don't want to go through something like this again."
[cpg cn=true]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





And then, one by one, the women became pregnant and had children. One after another, the women became pregnant and had children.
[cpg]


All of them girls. It is natural for them to do so, since that is how they evolved.
[cpg]



;//========================================
;//●ＣＧ非エロ（赤子をあやすヒロイン。優しく微笑んでいる）ev_44
;//人物１：ヒロイン５
;//服装１：着衣
;//場所　：城内＿主人公の部屋
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=100]




[VOICE f="Martina064"]
[OnName num="martina"]
"All right, ......, don't cry."
[cpg cn=true]


She soothed the baby. It's my baby.
[cpg]


Martina is becoming more and more like a mother.
[cpg]


Specifically, her violent personality had changed through the birth of the baby.
[cpg]


But it's odd, isn't it? Now that I know that there are places in this world where women can get pregnant with other women, ......
[cpg]


The only child that I can unequivocally say is mine is now Martina's child.
[cpg]


;//俺が種付けしたと言い切れるのはマルティナだ。[cpg]


On top of that, the child also had my face on it: ......
[cpg]


That made Martina even more special to me.
[cpg]



[VOICE f="Martina065"]
[OnName num="martina"]
"Are you ever going to go back to your world?
[cpg cn=true]


I don't plan to. No, that depends.
[cpg]


[OnName num="daigo"]
If Martina wants to come, I will.
[cpg cn=true]


I told her, and she shook her head.
[cpg]



[VOICE f="Martina066"]
[OnName num="martina"]
I can't do that. I am also attached to this world.
[cpg cn=true]


Then I won't go back to my world, either.
[cpg]


From that point on, Martina and I grew closer.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[FG f="CHA05_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina067"]
[OnName num="martina"]
But still, am I really allowed to live in this castle?
[cpg cn=true]


[OnName num="daigo"]
I'm the one who approved it.
[cpg cn=true]


[FG f="CHA05_p2_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Martina068"]
[OnName num="martina"]
But ...... you used to be a bandit, remember?
[cpg cn=true]


[OnName num="daigo"]
Before that, you're a mother now.
[cpg cn=true]

[FG f="CHA05_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
I told her, and Martina laughed silently.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





My personality has not changed much compared to what it used to be.
[cpg]


Even so, Martina accepted me as I was.
[cpg]


Martina had changed after becoming a mother.
[cpg]


I wonder if I could have changed too after becoming a father. ......
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Martina069"]
[OnName num="martina"]
"But still,...... you've changed, haven't you?"
[cpg cn=true]


[OnName num="daigo"]
"...... me?"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Martina070"]
[OnName num="martina"]
I've become kinder. I think your face has changed.
[cpg cn=true]


...... seems to have changed. I don't really feel it.
[cpg]


Surprisingly, Martina may not even feel that she has changed.
[cpg]


Maybe that's what happens when a person becomes a parent.
[cpg]


[SCENE id=14]

;//ＥＮＤ　ヒロイン５ルート
[jump storage="epend.ks" target="*start"]


