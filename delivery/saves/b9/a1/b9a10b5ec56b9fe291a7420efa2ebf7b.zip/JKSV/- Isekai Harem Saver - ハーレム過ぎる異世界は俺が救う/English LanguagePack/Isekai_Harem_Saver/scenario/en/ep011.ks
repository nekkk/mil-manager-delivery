
*start


;#################################################
*Ep011|The Result of Acting Selfishly
;#################################################


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（夕方）******************************************************



*VectorGood3|The Result of Acting Selfishly

[SCENE id=11]



[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Chloe191"]
[OnName num="chloe"]
"How are you doing?　Have you changed your mind?
[cpg cn=true]


[OnName num="daigo"]
"...... No."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Chloe192"]
[OnName num="chloe"]
"It can't be helped. I think I need to be a little rough with you.
[cpg cn=true]

[free time=1000]

Chloe came up to me and said, "What are you going to do? I'm like, "What are you doing?
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Lily203"]
[OnName num="lily"]
"Wait a minute!
[cpg cn=true]


Lily had arrived. Charlotte was there, too.
[cpg]


[OnName num="daigo"]
"Lily, Charlotte ......, you're here."
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Charlotte117"]
[OnName num="charlotte"]
I'm here to help you, big brother. Are you okay?　Are you hurt?"
[cpg cn=true]


'No, I'm not hurt enough to be hurt, but it's nice of you to worry about me.
[cpg]


[OnName num="daigo"]
Get me out of here, Lily!　Please."
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Chloe193"]
[OnName num="chloe"]
'...... Don't listen to Daigo-sama. Your Majesty."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Lily204"]
[OnName num="lily"]
'It won't come to that. I cannot approve of this kind of disregard for human rights."
[cpg cn=true]


Lily seems to be working on the side of helping me.
[cpg]


I'm detained and can't do anything. I just listen to the conversation.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Charlotte118"]
[OnName num="charlotte"]
She is trying to help me, too.
[cpg cn=true]


She is trying to help me, too. If I keep this up, I'm going to be free.
[cpg]


[OnName num="daigo"]
"Charlotte...... that much about me. ......
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe194"]
[OnName num="chloe"]
But if things continue as they are, the population will only decrease.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily205"]
[OnName num="lily"]
That's true, but ......
[cpg cn=true]


Oh, come on, why break there. Is it a natural decision for a queen?
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Charlotte119"]
[OnName num="charlotte"]
"......, then, why don't we do it this way?"
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


What Charlotte and the others proposed was quite harsh.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Charlotte120"]
[OnName num="charlotte"]
What about calling the women to the castle instead of letting your brother go somewhere because he might run away?
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Chloe195"]
[OnName num="chloe"]
Surely then there's no need to keep Daigo-sama locked up. ......
[cpg cn=true]


[OnName num="daigo"]
No, no, wait.
[cpg cn=true]


They didn't listen to me and the conversation went on and on.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Chloe196"]
[OnName num="chloe"]
I'm sure that if you put a lot of guards in one room and make it hard for them to move, it will make it even harder for them to escape.
[cpg cn=true]


[OnName num="daigo"]
That's house arrest!　That's just like house arrest!
[cpg cn=true]


;//俺の主張は通らない。今まで、クロエだけを抱こうとしてきたツケがまわってきたのだ。
My point is not valid. I had been putting Chloe first, and now the bill for that had come due.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





And I returned to my luxurious room for the first time in a while.
[cpg]


I had to eat and do everything in this room. I could hardly leave this room all day long.
[cpg]


My treatment had changed. I was no longer a guest, at least not an important guest.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I had really come to a crazy world.
[cpg]


It was also a ridiculous world, and after I came to it, I behaved too selfishly ......
[cpg]


I thought I was too special. No, on the other hand, was it bad that I didn't understand that?
[cpg]


In any case, I was no longer given the freedom to ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************



[OnName num="daigo"]
"...... Chloe ......"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe197"]
[OnName num="chloe"]
Yes, sir. Yes, sir?"
[cpg cn=true]


[OnName num="daigo"]
'I liked you, ...... really, that's all.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chloe198"]
[OnName num="chloe"]
'That's a nice thing to say.'
[cpg cn=true]


But Chloe doesn't stay in her place.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I don't think anyone could be truly happy about this situation.
[cpg]


That's not to say I'm particularly weird. ......
[cpg]


;//移植のためシーンをカットしています

[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="daigo"]
'......Chloe. I'm sorry I was selfish, so ......
[cpg cn=true]


[OnName num="daigo"]
'Can you please forgive me now?　I'll do what I have to do."
[cpg cn=true]


Chloe pouted a little, then laughed and said, "I don't trust you.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chloe199"]
[OnName num="chloe"]
I don't trust you.
[cpg cn=true]


I don't trust you," was all she said. That's right.
[cpg]


I was taking advantage of me being special. ......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=false]



Chloe's stomach growled next.
[cpg]


Still, the power relationship remained the same. I continued to be the butt of Chloe's ass.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Lily206"]
[OnName num="lily"]
I asked her, "How are you feeling, ......?　Daigo-dono."
[cpg cn=true]


Lily came to my room. I replied.
[cpg]


[OnName num="daigo"]
"Not well. ......
[cpg cn=true]


I couldn't lie. I was not going to lie. If I said I was feeling well, I would be like this for the rest of my life.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily207"]
[OnName num="lily"]
I said, "......I'm sorry, but I'm going to have to ask you to be patient for a little while longer."
[cpg cn=true]


I know. I've been too much of a jerk.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I barely know what's going on out there.
[cpg]


But I did hear rumors. Rumors of the maids of honor, and what Lily tells me, all together ......
[cpg]


I found out that Chloe is apparently supported by the people.
[cpg]


She is gaining more power as the Prime Minister. Everything might be going according to Chloe's plan.
[cpg]


[OnName num="daigo"]
I want to get out of ......."
[cpg cn=true]


I said that in front of Chloe.
[cpg]


Of course, I just thought it couldn't come true,.......
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chloe200"]
[OnName num="chloe"]
Yes, that's fine.
[cpg cn=true]


She agreed, and I was out of breath.
[cpg]


[OnName num="daigo"]
Is it good ......?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe201"]
[OnName num="chloe"]
He said, "Well, Daigo-sama has been listening to us lately.
[cpg cn=true]


Besides, I heard him mumble something about ...... anyway.
[cpg]


What is it anyway? I felt that there was some strange implication in the words that I might not have heard.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily208"]
[OnName num="lily"]
'Well, ...... Chloe, that's ...... such a thing.'
[cpg cn=true]


[OnName num="daigo"]
I'm sure I said that anyway. I said sure, anyway."
[cpg cn=true]


In the past, Lily has mouthed something and not said it.
[cpg]


Or it might be related. I decided to take the plunge and ask.
[cpg]


[OnName num="daigo"]
Is there something important that I'm not aware of?　Is there something you're not telling me?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily209"]
[OnName num="lily"]
'...... yes, I do. There's no point in hiding it anymore."
[cpg cn=true]


Lily began to speak little by little. What is happening to me......
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily210"]
[OnName num="lily"]
'Daigo-dono's body is already suffering from the plague. Perhaps in the next decade or so, the ...... disease will spread through your body."
[cpg cn=true]


[OnName num="daigo"]
What ......?"
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily211"]
[OnName num="lily"]
I apologize for my silence. I apologize for not telling you, but there is nothing I can do about it now.
[cpg cn=true]


[OnName num="daigo"]
How could you keep such an ...... important story from me?"
[cpg cn=true]


Lily turned her head and spoke up.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Lily212"]
[OnName num="lily"]
"If you become desperate, it will be a matter of survival for us."
[cpg cn=true]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I was too shocked to do anything that day.
[cpg]


[OnName num="daigo"]
......Why didn't you tell me?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe202"]
[OnName num="chloe"]
Did His Majesty tell you the truth?
[cpg cn=true]


[OnName num="daigo"]
"Yes. You were playing a trick on me, weren't you?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe203"]
[OnName num="chloe"]
I'm sorry to hear that. It's all right, don't worry. ......
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（お腹を膨らませているヒロイン。寝ている主人公の隣に座って頭をなでる）ev_71
;//人物１：ヒロイン２
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：城内＿主人公の部屋
;//時間　：夜
;//備考　：ヒロインは妊娠六ヶ月くらいです
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_71_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=100]




[VOICE f="Chloe204"]
[OnName num="chloe"]
They say the elves have a secret spell. A magic so powerful it could purge you of your plague.
[cpg cn=true]


[OnName num="daigo"]
Is that true, ......?
[cpg cn=true]



[VOICE f="Chloe205"]
[OnName num="chloe"]
Yes. If only you could convince the elves that they need to protect you. ......
[cpg cn=true]



[VOICE f="Chloe206"]
[OnName num="chloe"]
In layman's terms, if you do your part better, you'll be able to exorcise the plague.
[cpg cn=true]


That's ...... too much to ask them to follow.
[cpg]


It would be convenient for Chloe.
[cpg]


Is it okay to be in a situation where we've been left to do what we've been made to do so far ......?
[cpg]


No, it's not good, it's not good at all. ...... I want to save my life.
[cpg]



[VOICE f="Chloe207"]
[OnName num="chloe"]
'So you have nothing to worry about. Just follow my lead and that's ...... it."
[cpg cn=true]


And I stopped thinking about it.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Then the days passed.
[cpg]


Time flew by so fast. And then ......
[cpg]


Just before Chloe gave birth. Chloe was smiling.
[cpg]


It was calm. I knew she could afford to be.
[cpg]



[VOICE f="Chloe208"]
[OnName num="chloe"]
She said, "I'm going to give birth to Daigo-sama's child now, so please pray that I can ...... give birth properly."
[cpg cn=true]


I couldn't nod my head, but I decided to pray nonetheless.
[cpg]


[OnName num="daigo"]
She said, "......Oh, I understand. I understand.
[cpg cn=true]


More time passed. Chloe began to suffer from contractions.
[cpg]


From that point on, I couldn't even be there for the birth.
[cpg]


Maybe that's natural. I am a man.
[cpg]


In a somewhat alienated state, she gave birth.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





Looking at her, my daughter, I felt indescribable.
[cpg]


Indescribable feeling may be a little different.
[cpg]


More specifically, I felt like I couldn't die. ......
[cpg]


The sight of Chloe holding the baby is also a strange feeling in itself.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chloe209"]
[OnName num="chloe"]
"All right,......, Daigo-sama, you can also fawn over him."
[cpg cn=true]


Chloe says so and looks at me.
[cpg]


[OnName num="daigo"]
'Is it me, ......?'
[cpg cn=true]


I've never done that before, of course.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe210"]
[OnName num="chloe"]
I've never done that before, of course. I'm her father.
[cpg cn=true]


[OnName num="daigo"]
"Oh, yeah. ...... okay."
[cpg cn=true]


I hold the baby in my arms.
[cpg]


I feel the same way. I will not die. I'll do anything for it. ......
[cpg]


Chloe had a baby. She's my child. I can't let her, I can't let her be sad.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chloe211"]
[OnName num="chloe"]
Well, I look forward to working with you today, Daigo-sama.
[cpg cn=true]


[OnName num="daigo"]
I will. I think it's time for us to go.
[cpg cn=true]


The balance of power has been completely reversed.
[cpg]


I'm in a situation where most of the things I want to do aren't going to happen.
[cpg]


But ...... I thought I could do my best for this girl.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



It's a strange fate. I just wanted to love Chloe, but that didn't happen.
[cpg]


But still, strangely enough, I had no regrets. ......
[cpg]


I feel like it was destined to happen anyway.
[cpg]



Chloe didn't seem to be jealous.
[cpg]


Perhaps it is because she truly loves him that she can behave that way. ......
[cpg]


[SCENE id=18]

;//ＥＮＤ　ヒロイン２善ルート
[jump storage="epend.ks" target="*start"]

