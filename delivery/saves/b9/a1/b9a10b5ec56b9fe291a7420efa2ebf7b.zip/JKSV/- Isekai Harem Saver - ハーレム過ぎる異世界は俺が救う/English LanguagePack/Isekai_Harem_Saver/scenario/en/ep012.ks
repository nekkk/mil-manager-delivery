
*start



;#################################################
*Ep012|Chloe's Downfall
;#################################################


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（夕方）******************************************************



*VectorEvil3|Chloe's Downfall

[SCENE id=12]

[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Chloe212"]
[OnName num="chloe"]
'Well, ...... how shall we do today?　If only Daigo-sama would be honest with me.
[cpg cn=true]


[OnName num="daigo"]
"There's no way I can be honest with you. ......!　Get me out of here!
[cpg cn=true]


[free time=1000]

[VOICE f="Lily213"]
[OnName num="lily"]
That's right. ......!　What are you going to do with Daigo-sama?
[cpg cn=true]

[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
I heard a voice that wasn't Chloe. It was Lily ...... who was there.
[cpg]


[free time=800]

[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Lily214"]
[OnName num="lily"]
"Chloe ......!　How dare you do this to me!"
[cpg cn=true]


Chloe is flabbergasted. But she soon became calm.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Chloe213"]
[OnName num="chloe"]
She immediately looked calm and said, "Your majesty, this is necessary. Please listen to me."
[cpg cn=true]


[OnName num="daigo"]
Don't listen to me!　Lily, Chloe has done me a terrible disservice.
[cpg cn=true]


I told Chloe everything I knew to get her to retaliate.
[cpg]


Chloe had done something to me that bordered on torture, or something like that. Chloe, of course, denied it, but ......
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Lily215"]
[OnName num="lily"]
"Oh my God, ......!　Chloe, you missed it!"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Chloe214"]
[OnName num="chloe"]
No, sir!　Daigo-sama is lying, I didn't go that far.
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





As a result, Chloe is no longer Prime Minister.
[cpg]


I'm in jail now. I'm in prison now.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿地下室』（夜）******************************************************





[OnName num="daigo"]
"Chloe, you've done well. You've done well.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe215"]
[OnName num="chloe"]
"......, you're the one. How dare you lie to me?
[cpg cn=true]


[OnName num="daigo"]
Because it's true you locked me up. That's treasonous, isn't it?
[cpg cn=true]


;//移植のためシーンをカットしています


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Time passed. Chloe was already pregnant and her belly was growing.
[cpg]


In prison, the child grew.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





In the end, we decided that it was a bad idea to have the birth in jail, so Lily and I decided to get Chloe out of the jail.
[cpg]


But Chloe still had masochistic desires.
[cpg]



[OnName num="daigo"]
She said, "You're going to have a baby soon, aren't you?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Chloe216"]
[OnName num="chloe"]
Will you ever forgive me?"
[cpg cn=true]

[OnName num="daigo"]
'...... there's nothing to forgive.
[cpg cn=true]

I replied in a somewhat annoyed tone of voice and walked away.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Chloe217"]
[OnName num="chloe"]
"Wait, Daigo-sama. ...... ah"
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



It is true that I like Chloe. But it got complicated and troublesome.
[cpg]


At first I tried to love only Chloe, which didn't last because she didn't think it was a good idea....
[cpg]


As a result, it was like we were back to square one.
[cpg]

I shook her off and went on to the other women.
[cpg]

[SCENE id=19]

;//ＥＮＤ　ヒロイン２悪ルート
[jump storage="epend.ks" target="*start"]



;//==============================

