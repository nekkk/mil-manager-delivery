
*start

;#################################################
*Ep007|Lily, the Queen
;#################################################

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************


[if exp={ isSystemFlagsEnabled( "selflg_01") }]
[stflag evilflg= 1]
[endif]

[if exp={ isSystemFlagsEnabled( "selflg_02") }]
[stflag evilflg= 1]
[endif]


*select06_1|Lily, the Queen.

[SCENE id=7]



After all, I am Lily, the queen of this country.
[cpg]

I am probably the most important person in the world, but I am next in line.
[cpg]

No, I am the most important person in the world, but I am the next most important person in the world.
[cpg]





[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夜）******************************************************





[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily152"]
[OnName num="lily"]
Ah, Daigo-dono ......, what are you doing here so late at night?
[cpg cn=true]


[OnName num="daigo"]
No, I just wanted to see your face. I just wanted to see you.
[cpg cn=true]


Lily is perplexed. I guess she has never been told this before.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



From there, I flirted with Lily until morning.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





I didn't get much sleep last night. I went out on the town again, sleepy as a clam.
[cpg]



[SE f="se013"]
;//【ＳＥ】『地面に倒れ込む』


[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I must have been too tired. During the trip, I collapsed.
[cpg]


;//[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Chloe147"]
[OnName num="chloe"]
"Daigo-sama!　Are you all right?
[cpg cn=true]


[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夕方）******************************************************





[OnName num="daigo"]
"Nn......, what is it?"
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily153"]
[OnName num="lily"]
"Are you awake, Daigo-sama? You are reckless, aren't you?
[cpg cn=true]


[OnName num="daigo"]
Was this ...... where I fainted?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily154"]
[OnName num="lily"]
I was out cold. Chloe was panicking.
[cpg cn=true]


[OnName num="daigo"]
I see. Well, that's to be expected.
[cpg cn=true]


Just getting around is a big deal in this world.
[cpg]

In addition, yesterday, I didn't get any rest. ......
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily155"]
[OnName num="lily"]
How about taking a rest?　It's not good to push yourself too hard."
[cpg cn=true]


[OnName num="daigo"]
"......, I'll let you do that."
[cpg cn=true]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I decided to go back to my room and get some rest.
[cpg]


Lily had ordered me to do so. I'm sure Chloe won't force me into a reckless schedule either.
[cpg]



[OnName num="daigo"]
...... Lily."
[cpg cn=true]


I muttered to myself. Before I knew it, I was attracted to her.
[cpg]


She is, after all, the noblest person in the world.
[cpg]


;//彼女を手込めにするのは、世界を征服するのに等しい。
To win her would be like conquering the world.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





I wake up with this thought in my head.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe148"]
[OnName num="chloe"]
Good morning, Daigo-sama. Daigo-sama."
[cpg cn=true]


[OnName num="daigo"]
"Oh, ......."
[cpg cn=true]



[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe149"]
[OnName num="chloe"]
"Please rest today. His Majesty said so.
[cpg cn=true]


[OnName num="daigo"]
Is that so?
[cpg cn=true]


Then, since I'm here, I'll take a break.
[cpg]



Just when I was thinking that I wanted to deepen my relationship with Lily as well,.......
[cpg]


I'll have to make the most of this time.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（朝）******************************************************



[SE f="se009"]
;//【ＳＥ】『ドアノック』





[OnName num="daigo"]
Lily, are you there?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily156"]
[OnName num="lily"]
Yes. Come on in, Daigo.
[cpg cn=true]


[OnName num="daigo"]
I know you've been looking out for me and giving me the day off. Thank you.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily157"]
[OnName num="lily"]
No. You collapsed suddenly, didn't you?　It is natural to be concerned.
[cpg cn=true]


That's right. It would be a disaster if something happened to me.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily158"]
[OnName num="lily"]
Please take it easy today. It's important to rest.
[cpg cn=true]


[OnName num="daigo"]
"Yes, I will. I'll do that.
[cpg cn=true]


After that conversation, I stayed in Lily's room.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily159"]
[OnName num="lily"]
I went to ...... and asked, "How can I help you?　Can't you go to your room to rest?
[cpg cn=true]


[OnName num="daigo"]
I want to stay with you. Can't I?
[cpg cn=true]


Lily blushed. He's a cute guy.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Lily160"]
[OnName num="lily"]
If Daigo-dono says so,......, I want to stay with you too.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





That's why I decided to spend time with Lily.
[cpg]


There are many things about her that I don't know. I wanted to know as much as I could about her.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夜）******************************************************





[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily161"]
[OnName num="lily"]
Do you drink alcohol, Daigo-dono?
[cpg cn=true]


[OnName num="daigo"]
"Oh. As much as anyone. ...... What about Lily?"
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Lily162"]
[OnName num="lily"]
I'm a bit of a drinker myself. If you like, you can join us.
[cpg cn=true]


Lily is preparing something like a glass of wine.
[cpg]


[OnName num="daigo"]
Then I will do so. ......
[cpg cn=true]


And what the lady-in-waiting brought was still wine.
[cpg]


As a world view, no other alcohol would fit. From the raw materials and production method, it's probably not impossible to make it, but ......
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily163"]
[OnName num="lily"]
Then let's have a toast.
[cpg cn=true]


[OnName num="daigo"]
Oh ...... cheers."
[cpg cn=true]



[SE f="se005"]
;//【ＳＥ】『乾杯　ワイングラス』
[WAIT time=1300]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


From there, I was astonished. I was going to help her get drunk, but Lily didn't seem to be having any problems.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（夜）******************************************************





But Lily never got drunk. On the contrary, my vision began to wobble.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily164"]
[OnName num="lily"]
I know this is what happens to everyone when they drink with me. ......
[cpg cn=true]


[OnName num="daigo"]
"Yeah, well, ......, I guess so."
[cpg cn=true]


I was on the verge of giving up and getting drunk.
[cpg]


Lily seems to be quite a heavy drinker. I didn't think it would go this far. ......
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





I ended up waking up that day in a limp state.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe150"]
[OnName num="chloe"]
"Please don't be too reckless,......."
[cpg cn=true]


[OnName num="daigo"]
'Oh ...... I was going to get Lily drunk.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chloe151"]
[OnName num="chloe"]
'That's next to impossible,...... and Daigo-sama looks strong too, but it was still impossible.
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Then, while normal life returned to normal,......
[cpg]

I was more attracted to Lily. I called her into my room as soon as we got back to the castle.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily165"]
[OnName num="lily"]
She said, "You are ...... too much into me, Daigo-sama. Daigo-dono."
[cpg cn=true]


[OnName num="daigo"]
"Really?　I'm the only man you've got. I'm the only man you've got.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily166"]
[OnName num="lily"]
"But ...... my close aide, Chloe, and my retainers are also dissatisfied.
[cpg cn=true]


Certainly, I should be left with many partners and children.
[cpg]


The only thing I can do is to make sure that I am not the only man in the family. It can't be helped.
[cpg]


I can't make any excuses for it. In fact, I've been by Lily's side the whole time.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily167"]
[OnName num="lily"]
"Couldn't you love me more, without dividing us?"
[cpg cn=true]


[OnName num="daigo"]
......"
[cpg cn=true]


I felt rejected. I know that's not the point.
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧエロ（ベッドに押し倒されるヒロイン）ev_55
;//人物１：ヒロイン１
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：城内＿主人公の部屋
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_55_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="Lily168"]
[OnName num="lily"]
"Kyah!"
[cpg cn=true]


I pushed Lily down. I pushed her down and forced her to come closer to me.
[cpg]


[OnName num="daigo"]
I know that's not what she really meant. I'm going to have to punish you for that.
[cpg cn=true]


I take her lips. She doesn't seem to really dislike me.
[cpg]

If that were the case, I would have liked to behave a little more as I pleased.
[cpg]

I only wanted to love ...... Lily.
[cpg]

;**【ＣＧ】 ev_55_a ***********************
[CG id=15 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="Lily169"]
[OnName num="lily"]
I said to myself, "...... no. I'm the only one who can do this ......."
[cpg cn=true]



;//移植のためシーンをカットしています

;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************



From there, I stayed by Lily's side until morning. We were sleeping together.
[cpg]

Chloe came over. She had a look of dismay on her face.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe152"]
[OnName num="chloe"]
I've got a lot of work to do today, too, Daigo-sama. If you don't get ready soon, I'll have to ask you to ......."
[cpg cn=true]



[OnName num="daigo"]
"Oh, I'm not going to do that today," he said. I'm not going to do that today.
[cpg cn=true]

[FG f="CHA02_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
Chloe was speechless for a moment. So I continued.
[cpg]


[OnName num="daigo"]
I don't care if it's to save the world or not. I'm fine as long as I can be with Lily.
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chloe153"]
[OnName num="chloe"]
What are you saying?　If you do that, the people will become dissatisfied and eventually revolt.
[cpg cn=true]


[OnName num="daigo"]
I don't care. It's none of my business.
[cpg cn=true]



;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************


Then I put the nobles and the people and all that stuff aside and stayed with Lily.
[cpg]

I was satisfied. As long as Lily was there, that was all that mattered.
[cpg]

Of course, I could understand that the people would be dissatisfied.
[cpg]

However, I can't help it if they force me to fall in love with her. ......
[cpg]

I was naive enough to think that way, but the bill soon came due.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『城内＿ヒロイン１の部屋』（昼）******************************************************




[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Chloe154"]
[OnName num="chloe"]
"...... Your Majesty. I'm sure you know that. ......
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Lily170"]
[OnName num="lily"]
Yes. The mob must have swept this far.
[cpg cn=true]


Both Lily and Chloe were talking as if it was obvious.
[cpg]


I felt a little sorry for them, but I thought I was just doing what I wanted to do.
[cpg]


[free time=1000]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Lily171"]
[OnName num="lily"]
Daigo-dono. I was still able to get rid of them.
[cpg cn=true]


[OnName num="daigo"]
...... is that so?"
[cpg cn=true]


Lily continued, "I don't know what's going to happen in the future.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily172"]
[OnName num="lily"]
I don't know what will happen in the future. It depends on how Daigo-dono acts.
[cpg cn=true]


Worst case scenario, the nation will be overthrown. I think that's what it means to have a child.
[cpg]


[OnName num="daigo"]
"Is Lily good for ......? Wouldn't you like to be united only with me?"
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Lily173"]
[OnName num="lily"]
I am sorry, but it is impossible for a man summoned to this world to be united with only one woman.
[cpg cn=true]


In this world, there is no such thing as a married couple.
[cpg]


I was somewhat shocked, but I also felt that it would be natural for them to do so. ......
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Lily174"]
[OnName num="lily"]
I was shocked, but I felt that of course it was true. I am not supposed to be monopolizing Daigo-dono in the first place.
[cpg cn=true]


I fall silent. I'm going to have to accept it.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町』（昼）******************************************************





Then I was to go to a non-royal, a woman other than Lily.
[cpg]


Through Lily, it was declared. I can't go back on my word now.
[cpg]



They say the people have grown discontent, but what about my discontent ......?
[cpg]


As I was walking along the road thinking about this, I ran into Charlotte. We exchanged a few words.
[cpg]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte109"]
[OnName num="charlotte"]
She said, "Brother, I see you've reconsidered......."
[cpg cn=true]


[OnName num="daigo"]
'Yeah, well .......
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Charlotte110"]
[OnName num="charlotte"]
'I know it's hard for you, brother,...... but I'm glad we did this.
[cpg cn=true]


[FG f="CHA03_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Charlotte111"]
[OnName num="charlotte"]
We all want to have children. Don't forget that."
[cpg cn=true]


He said heavy words. I couldn't say anything.
[cpg]



;//ブラックアウト


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





[OnName num="daigo"]
......"
[cpg cn=true]


My quota for the day was met. But is this enough?
[cpg]


Can I say that me and Lily are connected? I don't think so.
[cpg]


What am I supposed to do ......?
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//※※※変数によって分岐

[if exp={getFlagValue("evilflg") == 2 }]
[jump target=*VectorEvil2]
[endif]

[if exp={getFlagValue("evilflg") == 1 }]
[jump target=*VectorEvil2]
[endif]



;//==============================
;//善の変数が悪の変数より多い場合

;//[jump target=*VectorGood2]
[jump storage="ep008.ks" target="*VectorGood2"]


;//==============================
;//悪の変数が善の変数より多い場合

*VectorEvil2
[jump storage="ep009.ks" target="*VectorEvil2"]
