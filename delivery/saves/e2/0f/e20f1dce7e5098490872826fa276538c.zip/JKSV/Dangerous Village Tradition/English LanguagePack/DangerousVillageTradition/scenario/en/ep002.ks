
*start

;#################################################
*Ep002|Festival to pray for a good harvest
;#################################################

[SCENE id=2]


;//ＢＫ
;//綾子に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（昼）******************************************************


I had just finished my chores for the day and was about to start working in the fields.
[cpg]

[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

The doorbell rang, and I opened the door.
[cpg]

I see a familiar figure. I felt a little relieved.
[cpg]

I was a little worried that Mr. Masuda might come again.
[cpg]

[OnName num="kawayama"]
I asked, "May I have a moment?　"Uh, Ayako Sumii.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako124"]
[OnName num="ayako"]
Yes, ......, what can I do for you?
[cpg cn=true]

There she was, the village mayor, Mr. Kawayama. He was quite a contrast to Mr. Masuda.
[cpg]

As usual, he was a friendly old man.
[cpg]

[OnName num="kawayama"]
In a rural area like this, there are still customs and traditions," he said.
[cpg cn=true]

[OnName num="kawayama"]
It's spring now, isn't it? There is a festival to pray for a good harvest.
[cpg cn=true]

I was puzzled. I was puzzled by the festival. ......
[cpg]

I wondered when that was going to happen. No way, right now?
[cpg]

But if they don't say a specific time, does that mean that's what it's about?
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako125"]
[OnName num="ayako"]
Let's see,...... right now, right?"
[cpg cn=true]

Mr. Kawayama nodded. I knew it. Somehow, it feels a little strange.
[cpg]

[OnName num="kawayama"]
Yes. Yes, right now. You will come, won't you?
[cpg cn=true]

Mr. Kawayama was coming on to me a little too forcefully. It was a little different from the usual Mr. Kawayama.
[cpg]

And that's strange. I thought festivals were usually held on ordinary nights.
[cpg]

Is it my stereotype? Either way, I couldn't refuse.
[cpg]

If I am going to live in this village, I have to do what the village head says.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako126"]
[OnName num="ayako"]
Eh, ah, yes,...... please wait a little while, I'll get ready."
[cpg cn=true]

I couldn't say no to Mr. Kawayama's insistence.
[cpg]

I couldn't believe that it was a festival in the afternoon on a weekday like this. ......
[cpg]

And even though I had a bad feeling about it.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟へ続く道』（昼）******************************************************

I was taken to a place that looked like an animal trail.
[cpg]

Of course, it was not paved. What could be at the end of such a road?
[cpg]

It was so bad that I felt as if I might fall down. Where does it lead to?
[cpg]

I don't think it leads to a place where a festival can be held. ......
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayako127"]
[OnName num="ayako"]
"Really, a festival in a place like this......?"
[cpg cn=true]

I can't imagine people gathering at this end of the street.
[cpg]

I can't imagine people gathering at this end of the street, because if it's called a festival, people will probably gather there.
[cpg]

[OnName num="kawayama"]
I can't imagine that a festival would be held in such a place.
[cpg cn=true]

Is that so? If you say so, I have no choice but to agree.
[cpg]

I decided to think of it as more of a ritual than a festival.
[cpg]

If so, it could be done anywhere. Even in a small place, it might be possible .......
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako128"]
[OnName num="ayako"]
Maybe it's ...... something like that."
[cpg cn=true]

I replied, though I still didn't know much about it.
[cpg]

[OnName num="kawayama"]
I said, "We're almost there. Watch your step.
[cpg cn=true]

Yes," I replied, walking cautiously. I walked with caution so that I could get out of there immediately.
[cpg]

Fortunately, Mr. Kawayama did not grab my hand or anything like that.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako129"]
[OnName num="ayako"]
I asked, "Well, where does this road lead to?"
[cpg cn=true]

I see some kind of cave. A cave that seems to be man-made to some extent, or perhaps it was originally created spontaneously, but it looks like it has been touched by human hands.
[cpg]

Could it be, maybe, ...... that, in there?
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako130"]
[OnName num="ayako"]
I see something that looks like a cave, but I don't think it's ...... in there."
[cpg cn=true]

[OnName num="kawayama"]
That's right. You guessed right.
[cpg cn=true]

Now, this is getting suspicious. I'm getting scared of what's going on.
[cpg]

I hope it is not something magical or religious.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟』（昼）******************************************************

A cave. We are led into a lit but dimly lit place.
[cpg]

It is daytime, but there is no sunlight. It really is a cave.
[cpg]

;//ここから、千夏の名前は？？？と隠してください

We walk through it. I try to hold back my foot from slipping.
[cpg]

[VOICE f="sChinatsu001"]
[OnName num="unknown"]
I go to .......
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

What?　I said unintentionally. I could hear voices.
[cpg]

As I followed her suspiciously, I heard a woman's voice coming from inside.
[cpg]

[OnName num="kawayama"]
She said, "Well, well, well, don't worry about it. Please follow me.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

I had a bad feeling. I had a bad feeling that once I got this far, I would never be able to go back.
[cpg]

But I couldn't stop my footsteps. I've come this far, and I want to know everything.
[cpg]
;//移植のためシーンをカットしています

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

There, a man wearing an ogre's mask was approaching the woman.
[cpg]

They were in skin-to-skin contact, and as if they were lovers, they were shifting their masks and even kissing.
[cpg]

I involuntarily looked away and turned back to Mr. Kawayama.
[cpg]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_zh"]
[WAIT time=100]
;//【ＢＧ】『洞窟』（昼）******************************************************

[FACE method="change_3" pos="2/3"]
[VOICE f="Ayako134"]
[OnName num="ayako"]
'......Can you explain it to me properly, Mr. Kawayama?
[cpg cn=true]

[OnName num="kawayama"]
Yes, sure. It's your first time and you must be confused."
[cpg cn=true]

With a gentle expression on her face and the same tone in her voice, Ms. Kawayama explained the situation to me.
[cpg]

He explains about this crazy custom, as if it were a given.
[cpg]

[OnName num="kawayama"]
In this village, for some time now, there has been a custom of men wearing devil masks attacking women like this.
[cpg cn=true]

[OnName num="kawayama"]
It is more like pretending to attack rather than attacking.
[cpg cn=true]

[OnName num="kawayama"]
It has been handed down from generation to generation under the name of "Oniwabari.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

I couldn't help but mutter to myself, "Oh, no. I was sure that my face was pale.
[cpg]

Mr. Kawayama explained the situation without hesitation. He seemed to be saying that this was a normal thing to do.
[cpg]

As if he did not care that I was upset.
[cpg]

[OnName num="kawayama"]
By having a person attacked by an ogre dressed as an ogre, the ogre has already appeared, and it is a prayer for a good harvest that the evil has already passed.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

I can see that. I can understand that, but it could also be that way.
[cpg]

[OnName num="kawayama"]
In the countryside, people often blame unknown things for bad harvests, so you could say it's a vestige of that.
[cpg cn=true]

But that's not the point. How did it end up this way?
[cpg]

No, I'm more concerned about ...... than that.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayako135"]
[OnName num="ayako"]
"But are these people ...... lovers?"
[cpg cn=true]

[OnName num="masuda"]
'They don't have to be lovers, do they?　This is a ritual.
[cpg cn=true]

[OnName num="masuda"]
Chika was happy, too. It's just a game, don't worry about it.
[cpg cn=true]

Play. Is it no longer a festival or a ritual?
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="sAyako003"]
[OnName num="ayako"]
It's not even such a ...... thing .......
[cpg cn=true]

[OnName num="masuda"]
"Pfft, ha ha ha ha!　Well, that's a flustered reaction."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

Masuda-san seemed to be mocking me as I was devastated. What on earth was he thinking when he laughed?
[cpg]

Is it really that funny to see me confused?
[cpg]

[OnName num="kawayama"]
More importantly, Ayako-san, would you like to join me in this demon exorcism?"
[cpg cn=true]

And Kawayama-san, being Kawayama-san, asks recklessly.
[cpg]

[FACE method="shock_3" pos="2/3"]
[VOICE f="sAyako004"]
[OnName num="ayako"]
He said, "Mmm, I can't do it!　Even if the other party is Yuto-san, I can't do this in public.
[cpg cn=true]

[OnName num="kawayama"]
"Yuto-san?　The other party is Mr. Yuto?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

The other party is Mr. Yuto? What's so funny?
[cpg]

Are you implying that someone else is going to be my partner?
[cpg]

[OnName num="kawayama"]
What are you talking about?　Yuto-san must be busy during the day. We can take your place."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
That's crazy. There is nothing more I can do, though there is nothing I can do in the first place.
[cpg]

Kawayama-san said so, and now he is trying to get close to Chinatsu-san.
[cpg]

Is this okay? I'm not going to allow this to go on.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sAyako005"]
[OnName num="ayako"]
Chika-san ...... are you okay with this?"
[cpg cn=true]

[free time=1000]
I thought so, and I spoke to the person who introduced me as Chinatsu.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Chinatsu026"]
[OnName num="chinatsu"]
I was thinking that, I spoke to the person who introduced me as Chinatsu.
[cpg cn=true]

Oh, I see. Oh, so that's the kind of reply I get.
[cpg]

Does Chinatsu-san even question the customs of this village any longer?
[cpg]

It's not that she can't judge whether it's crazy or not, it's that she doesn't.
[cpg]

This is crazy. ......
[cpg]

;//移植のためシーンをカットしています

;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_06_2.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//
;//[BGM f="bg_zh"]
;//[WAIT time=100]
;//【ＢＧ】『洞窟』（昼）******************************************************

;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="masuda"]
;//「さて、と。あんた、綾子とかそんな名前だったよね。畑が趣味なんだろ？」
You, Ayako, or something like that, right? Hatake is your hobby, right?"
[cpg cn=true]

I am surprised when he suddenly speaks to me and tells me that his hobby is farming.
[cpg]

[FACE method="shock_5" pos="2/5"]
[VOICE f="Ayako141"]
[OnName num="ayako"]
How did you know that?　I'm sure I didn't tell you. ......"
[cpg cn=true]

Mr. Masuda laughed. Then, he said, "In such a rural area, you can't share any information with anyone.
[cpg]

[FACE method="change_5" pos="2/5"]

[OnName num="masuda"]
In a place like this, it's like sharing any information. I know where you live, what your hobbies are, everything.
[cpg cn=true]

[OnName num="masuda"]
There's no way out for you. That's the way it is in the country.
[cpg cn=true]

[OnName num="masuda"]
That's why. Ayako, you'd better get used to it for your own sake.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

Ayako," he called me and said such a thing.
[cpg]

The actuality is, it might be true. In this countryside, there is no escape.
[cpg]

I'm sure the word will spread soon that I refused to be an ogre exorcist. But ......
[cpg]

Where can a woman say "yes" to such a request?
[cpg]

At least, I am not one of them. I can't do it.
[cpg]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Ayako142"]
[OnName num="ayako"]
I can't do this. I am sorry, but please excuse me.
[cpg cn=true]

I said firmly. Mr. Masuda kept a relaxed expression on his face.
[cpg]

I couldn't stand it any longer and was about to leave when Mr. Masuda threw his words behind my back as if to stop me,
[cpg]

As if to stop me, Mr. Masuda threw a few words behind my back.
[cpg]

[OnName num="masuda"]
I told him, "One more thing, those who can't follow these customs can't live in the countryside.
[cpg cn=true]

[OnName num="masuda"]
Your precious farm might not be safe.
[cpg cn=true]

That's what Mr. Masuda said to me at the end.
[cpg]

I was still okay with it. I left the cave believing that I could make it.
[cpg]

There was no way I was going to act like a lover to Masuda-san, no matter what I weighed in the balance.
[cpg]

[SE f="se012"]
;//【ＳＥ】『走る』

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟へ続く道』（夕方）******************************************************

[VOICE f="Ayako143"]
[OnName num="ayako"]
"Hah, hah...... why, why did this happen......?"
[cpg cn=true]

There were a few tears. The peaceful country life I had hoped for was gone.
[cpg]

I ran away from the place as if I was running away from something.
[cpg]

No, I was actually running away. From Mr. Masuda and Mr. Kawayama.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako144"]
[OnName num="ayako"]
"That's the custom of this village ......, it's a normal thing in this village ......."
[cpg cn=true]

It is the norm in this village. It is the norm in the city. There may be something wrong with both of them.
[cpg]

But that doesn't mean that we can't hold on to them. The strange things are strange after all.
[cpg]

[FACE method="shock_4" pos="2/3"]
[VOICE f="sAyako006"]
[OnName num="ayako"]
But ...... I can't, I can't think of anyone else but Yuto.
[cpg cn=true]

I cannot betray Yuto. No matter what the consequences might be.
[cpg]

[FACE method="change_4" pos="2/3"]

Maybe they will do something to me, like harass me. Still, I will endure.
[cpg]

I will never waver in my will. No matter what happens in the future.
[cpg]

That is how much I love Yuto.
[cpg]

;//悠斗に視点切り替わり

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『オフィス内』（夕方）******************************************************

I finished work today and decided to go home.
[cpg]

[OnName num="yuuto"]
"Oh, I'm sleepy,......, this road makes you sleepy.
[cpg cn=true]

Also, it's an hour and a half each way. It's more depressing than work, but lately I've decided to just call it a drive.
[cpg]

It's not a stress-relieving drive, but, well, it can't be helped.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『扉開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************

[OnName num="yuuto"]
"I'm home. Ayako.
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ayako146"]
[OnName num="ayako"]
"Oh, welcome home, ...... you."
[cpg cn=true]

Ayako was waiting for me at home. But she was looking a little pale.
[cpg]

I can't think of any reason. She didn't look sick or anything like that.
[cpg]

No, it's true that if you get sick here, there are no hospitals nearby,.......
[cpg]

[OnName num="yuuto"]
"What's the matter?　You look pale."
[cpg cn=true]

I call out to Ayako, worried about her. But,
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Ayako147"]
[OnName num="ayako"]
I'm fine," she said, "I'm fine. Nothing, nothing, nothing. ......
[cpg cn=true]

I was brushed off. I wondered if it was something that made him feel guilty.
[cpg]

[OnName num="yuuto"]
Nothing," he said. You're bleeding.
[cpg cn=true]

Pale is a more apt description. It's not like he's sick, but more like he's under a lot of stress.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayako148"]
[OnName num="ayako"]
I asked him, "Are you sure you're all right? ...... Please, don't ask me any more questions.
[cpg cn=true]

When I hear that, I want to ask even more. That's how much she's holding it in.
[cpg]

But I had to respect Ayako's wishes. I endured it because I was told not to ask.
[cpg]

[OnName num="yuuto"]
I told her, "I see. Then, it's okay.
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Ayako149"]
[OnName num="ayako"]
I'm sorry. I didn't answer properly. ......
[cpg cn=true]

I was getting more and more anxious as he apologized, but I couldn't help it.
[cpg]

[OnName num="yuuto"]
No, that's okay. I'm sorry I was too close to you.
[cpg cn=true]

I apologized too, and that was the end of the conversation.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿寝室』（夜）******************************************************


After finishing dinner prepared by Ayako and taking a bath, which she gave me, I went to bed that night.
[cpg]

[OnName num="yuuto"]
I knew I wouldn't be able to ...... sleep. ......
[cpg cn=true]

I was also concerned about the fact that Ayako seemed to be in poor health, and I just couldn't sleep.
[cpg]

I slink out of the futon and get up. Rather than being disoriented, I was already fully awake.
[cpg]

The first thing you need to do is to make sure that you have a good night's sleep.
[cpg]

[VOICE f="Ayako150"]
[OnName num="ayako"]
'Nnnn...... nnnn.'
[cpg cn=true]

Ayako seemed to be having some sort of nightmare, but I couldn't do anything about it. With that in mind, I leave the house.
[cpg]


[SE f="se019"]
;//【ＳＥ】『扉開く』


[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（夜）******************************************************

I can't sleep. Walking around without being able to sleep, I realized once again that it is dark in the countryside.
[cpg]

There are only a few streetlights, and of course they are not LED lights.
[cpg]

Some streetlights have no lights. I was thinking that this kind of maintenance is not done well in such a rural area. ......
[cpg]

Then, I saw a shadow.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki020"]
[OnName num="misaki"]
The first thing that comes to my mind is that it's Yuto. Can't you sleep either, Yuto?"
[cpg cn=true]

I looked closely, or rather I recognized the voice, but the figure was Misaki-san.
[cpg]

He talks to me in a friendly manner, but it is correct to say that I cannot sleep. I wonder if Yuto and Misaki can't sleep either.
[cpg]

[OnName num="yuuto"]
I was a little concerned about something.
[cpg cn=true]

I was not interested in what was bothering me.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Misaki021"]
[OnName num="misaki"]
If you can't sleep, I'll tell you something that will make you even more sleepless. About the customs of this village.
[cpg cn=true]

What is it?　About the customs of this village?　I hope you're not telling me a ghost story.
[cpg]

[OnName num="yuuto"]
If it's a scary story, I won't listen to it.
[cpg cn=true]

It's not that I don't like scary stories, but I don't like women who are happy to tell scary stories.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="sMisaki001"]
[OnName num="misaki"]
I'm not a fan of scary stories, but I'm not a fan of women who are happy to tell scary stories. I looked it up on the Internet.
[cpg cn=true]

But it was a scary story in a much different direction than I had imagined.
[cpg]

[OnName num="yuuto"]
"What is ......?　What is that?
[cpg cn=true]

She seemed pleased with my reaction. I wondered if it might be a lie she had made up.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Misaki023"]
[OnName num="misaki"]
I think that the countryside is full of customs like this. Festivals and rituals that seem to continue even though we don't understand their meaning.
[cpg cn=true]

But this time, he was talking as if it really existed.
[cpg]

[OnName num="yuuto"]
"That's absurd. ...... How is such a thing possible nowadays?
[cpg cn=true]

[OnName num="yuuto"]
"It's impossible, even if it's in a place where the police can't see you.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sMisaki002"]
[OnName num="misaki"]
I don't know.
[cpg cn=true]

I was horrified. If it was true, I could only say that he was crazy.
[cpg]

[OnName num="yuuto"]
What's that, ......, it's a lie anyway?
[cpg cn=true]

Misaki-san wrinkled her brow and said, "I don't know. But it was too dark to see much.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Misaki025"]
[OnName num="misaki"]
I'm not lying. I know, let's go to that cave right now, just the two of us.
[cpg cn=true]

[OnName num="yuuto"]
'...... that's ...... so, yes.'
[cpg cn=true]

Oh no, no way. I thought so, but then I remembered that Ayako was having a nightmare.
[cpg]

It's just a story of maybe, just maybe,......
[cpg]

Ayako might also be having nightmares about this ......?
[cpg]

Furthermore, my unpleasant imagination was growing. This is also hypothetical,
[cpg]

Could it be that someone is already closing in on her?　My heart boggles at the thought of it.
[cpg]

My chest tightens painfully.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_zh"]
[WAIT time=100]
;//【ＢＧ】『洞窟へ続く道』（夜）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki026"]
[OnName num="misaki"]
It's dark underfoot, so be careful. If you slip, you'll be in trouble.
[cpg cn=true]

Misaki's guide led us to an impassable animal trail.
[cpg]

Not only did I not want to slip, but I didn't know where I was walking at the moment.
[cpg]

Without the light of my phone, it would have been difficult to move forward.
[cpg]

[OnName num="yuuto"]
I asked him, "...... Are you sure there's a cave at the end of this road?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki027"]
[OnName num="misaki"]
I asked, "Maybe. If the rumors on the Internet are true, then ......, there was.
[cpg cn=true]

Indeed, there is a cave that is big enough for a person to enter. Or rather, there is a lighted ......
[cpg]

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟』（夜）******************************************************

Misaki's words are gradually being corroborated. In the midst of all this, a familiar person appeared.
[cpg]

[OnName num="kawayama"]
'Hey there, you two. Do you guys want to join us?　Right now, Mr. Suzurin is joining us."
[cpg cn=true]

The one who appeared was Mr. Kawayama. He was wearing a strange mask, but I could tell by his voice.
[cpg]

[OnName num="yuuto"]
"Suzubayashi-san, ......?"
[cpg cn=true]

Suzubayashi. I had never heard of him before.
[cpg]

But I have never heard of him. I don't know why, but I felt like I knew him somehow.
[cpg]

[OnName num="kawayama"]
I wondered, "Do you know her?　It's Chinatsu-san, you must have seen her before.
[cpg cn=true]

[OnName num="kawayama"]
She is the only daughter of the general store owner. She is also a very devoted and nice girl.
[cpg cn=true]

[OnName num="yuuto"]
"The general store ......?"
[cpg cn=true]

;//========================================
;//●ＣＧエロ（ヒロインが男に跪いている）ev_38
;//人物１：ヒロイン２
;//服装１：白装束
;//人物２：間男
;//服装２：白装束（鬼の面をつけている）
;//場所　：洞窟
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_38_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//@
There was a face there that I was sure I had seen before. He was dressed in white, perhaps for a ceremony.
[cpg]

;//@
[OnName num="yuuto"]
"...... this, this is ...... really ...... such a thing."
[cpg cn=true]

;//@
Oh, I see, her name is Chinatsu. What a pity, I don't have time to be deeply moved.
[cpg]

There, indeed, things were happening just as I had heard.
[cpg]

A scene that is hard to believe. But here it is happening.
[cpg]

[OnName num="yuuto"]
What is this?　Mr. Kawayama!
[cpg cn=true]

I asked Mr. Kawayama. But before Mr. Kawayama could answer, Misaki said, "That's why I explained it to you.
[cpg]

[VOICE f="Misaki028"]
[OnName num="misaki"]
I told you as I explained. Can't you convince me by looking at this?
[cpg cn=true]

[OnName num="yuuto"]
I don't think I can convince you!　This is not right. ......
[cpg cn=true]

;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟』（夜）******************************************************


[FACE method="bow_6" pos="2/3"]
[VOICE f="sMisaki003"]
[OnName num="misaki"]
Look, we have to pretend to be lovers, too. Right, Yuto?
[cpg cn=true]

[OnName num="kawayama"]
That would be nice.
[cpg cn=true]

[OnName num="yuuto"]
I can't do it. I'm getting out of here.
[cpg cn=true]

[OnName num="kawayama"]
If you want to get out, go ahead. If you can.
[cpg cn=true]

There are several other men watching this place. We have nowhere to go?
[cpg]

Are they going to force us to cheat on them? Is there no way for me to resist?
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Misaki030"]
[OnName num="misaki"]
"You'd better accept that you don't have a choice.
[cpg cn=true]

Misaki says this to me in a carefree manner. Misaki is not normal.
[cpg]

[OnName num="yuuto"]
But, I have a wife. This is crazy."
[cpg cn=true]

I can't do anything that would betray Ayako. If I did that and if she found out about it, she would ......
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Misaki031"]
[OnName num="misaki"]
I would have to come all the way here and leave for free, because that would be more ridiculous."
[cpg cn=true]

Misaki-san says things that shouldn't be that way. It's the place that's strange.
[cpg]

;//========================================
;//●ＣＧエロ（主人公に覆い被さるヒロイン）ev_39
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：洞窟
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_39_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

Before I could even think about it, Misaki-san approached me.
[cpg]

She covered me and pulled my skin close to hers.
[cpg]

No matter how much I thought something was wrong, she wouldn't move away from me.
[cpg]

She seemed to be happy. Even now, she is smiling.
[cpg]

I didn't know what was making her so happy. ......
[cpg]

[VOICE f="Misaki050"]
[OnName num="misaki"]
"It's nice...... I wanted to be tied to a cool guy like Yuto."
[cpg cn=true]

Misaki explains to me. Misaki-san utters a rather crazy, imaginary thought.
[cpg]

[VOICE f="Misaki051"]
[OnName num="misaki"]
It's so romantic to have a ceremony like this in the countryside, isn't it?
[cpg cn=true]

It's not normal. I don't understand how she can think it's romantic.
[cpg]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟』（夜）******************************************************

[OnName num="yuuto"]
"......What am I doing ......?"
[cpg cn=true]

I knew I shouldn't have done this. With that in mind, I try to get out of the cave.
[cpg]

;//服を手にとって、着ていく。この場から出るという意思を表す。
;//[cpg]

[FACE method="change_4" pos="4/5"]
[VOICE f="Misaki070"]
[OnName num="misaki"]
"Oh, hey, Yuto?"
[cpg cn=true]

Misaki-san is looking at me as if she is regretting leaving me. I don't like it when she looks at me like that.
[cpg]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Chinatsu061"]
[OnName num="chinatsu"]
Yuto-san ...... is already going home?"
[cpg cn=true]

Two people stop me. I don't care, if I keep getting caught up in this, I'm going to go really crazy.
[cpg]

[OnName num="yuuto"]
I'm sorry,......, but I'm out of here.
[cpg cn=true]

[free time=1000]

I'm going to leave. There is only one way out of the cave.
[cpg]

I was barely able to get out when I was blocked by a couple of guys,
[cpg]

[OnName num="kawayama"]
I was so scared, but I said, "Don't do this, I'm not going to let you leave today. It would be better to let them go home today.
[cpg cn=true]

With a single word from the village head, they opened the way for us.
[cpg]

I knew I shouldn't get involved in something like this. I thought to myself once again.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『洞窟へ続く道』（夜）******************************************************

I had gotten myself into a terrible situation. I was thinking that, but I was still somewhat high-minded that Ayako wouldn't find out.
[cpg]

[OnName num="yuuto"]
"It's all right, right? It's ...... all right, it should be ...... all right."
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿寝室』（夜）******************************************************

[VOICE f="Ayako151"]
[OnName num="ayako"]
Soo, soo ......."
[cpg cn=true]

Somehow I thought Ayako might have noticed that I wasn't there, but that wasn't the case.
[cpg]

Back in the bedroom, Ayako is just sleeping and doesn't seem to have woken up in the middle of the night.
[cpg]

[OnName num="yuuto"]
I'm sure they don't know. That's all right then."
[cpg cn=true]

I lay down too. I was tired, so sleep came naturally.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

In that sleep, I dreamed that I saw ......
[cpg]

[if exp={getFlagValue("f_Chinatsu") == 0 }]
[jump target=*SelRoot1]
[endif]

[if exp={getFlagValue("f_Misaki") == 0 }]
[jump target=*SelRoot2]
[endif]

;//C=1 M=1
;//■選択肢
[switch]
[case "Ayako"]
	[swap]
	[jump target="*select03_1"]
[case "Chika"]
	[swap]
	[jump target="*select03_2"]
[case "Misaki"]
	[swap]
	[jump target="*select03_3"]
[endswitch]


1, Ayako
2, Chinatsu
3, Misaki

;//////////////////////////////////////////

*SelRoot1|Festival to pray for a good harvest
;//C=0
[if exp={getFlagValue("f_Misaki") == 0 }]
;//C=0 M=0
[jump target=*select03_1]
[endif]

;//C=0 M=1
[switch]
[case "Ayako"]
	[swap]
	[jump target="*select03_1"]
[case "Misaki"]
	[swap]
	[jump target="*select03_3"]
[endswitch]

;//////////////////////////////////////////

*SelRoot2|Festival to pray for a good harvest
;//C=1 M=0
[switch]
[case "Ayako"]
	[swap]
	[jump target="*select03_1"]
[case "Chika"]
	[swap]
	[jump target="*select03_2"]
[endswitch]

;//１、綾子
;//２、千夏
;//３、美咲

;//各ヒロインのルートに分岐します
;//ここまでの選択肢によってヒロイン２およびヒロイン３を選択できるかどうか変わります
;//ヒロイン２、ヒロイン３とも選択肢がない場合、選択肢そのものが出現せず、ヒロイン１のルートで固定されます
;//ヒロイン２、ヒロイン３両方の選択肢がある場合、ヒロイン１は選択できません


*select03_1|Festival to pray for a good harvest
[jump storage="ep003.ks" target="*start"]
*select03_2|Festival of Prayers for a Bumper Crop
[jump storage="ep005.ks" target="*start"]
*select03_3|Festival of Prayers for a Bumper Crop
[jump storage="ep007.ks" target="*start"]

