
*start

;#################################################
*Ep004|Daily life going crazy
;#################################################

[SCENE id=4]


;//悠斗に視点切り替わり

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************


Lately, Ayako has been acting strangely. No, this is not the first time she has been acting strange.
[cpg]

She has been a little strange before, but recently she has been especially strange. So strange, in fact, that I can say with certainty that she has been acting strangely.
[cpg]

Specifically, her physical condition, which I thought had picked up once, seemed to be collapsing again.
[cpg]

Is it a physical condition or a state of mind?　I don't know what to call that kind of thing.
[cpg]

Something about the way he looks, like he's depressed. She is not here now, the kind of person who smiles at the slightest thing.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Ayako305"]
[OnName num="ayako"]
......Thanks for the food, that was it."
[cpg cn=true]

This hasn't happened many times since we started dating.
[cpg]

Or rather, it might be the first time. I've never seen anything this strange before.
[cpg]

It is obvious that she is not in good spirits. I think I've never seen Ayako like this before.
[cpg]

[OnName num="yuuto"]
"Hey, what's up?"
[cpg cn=true]

I boldly ask. I may have asked her this before.
[cpg]

[OnName num="yuuto"]
I've noticed you've been acting strange before, but lately you've been acting especially strange.
[cpg cn=true]

[OnName num="yuuto"]
If it's something I can ask, I'll ask, just tell me .......
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Ayako306"]
[OnName num="ayako"]
'It's nothing, anything ...... really, I'm fine.
[cpg cn=true]

Again. Again, this reply. No matter how many times I ask, they keep repeating the same thing.
[cpg]

Maybe it's something that's hard for me to say.
[cpg]

If that's the case, I may not be able to get anything out of him directly.
[cpg]

I guess I'll just have to follow the rumors.
[cpg]

[OnName num="yuuto"]
I'm sure that's fine.
[cpg cn=true]

Ayako's odd behavior is not limited to the daytime.
[cpg]

There were also indications that they were out somewhere at night.
[cpg]

That was just a sign, and I don't remember it properly either.
[cpg]

But there were times when I thought she was going to the bathroom and she didn't come back at all: ......
[cpg]

I can't say with confidence that I did it properly, because I was tired and sleeping during the night.
[cpg]

Besides, I was slumbering, so it might have been a dream, but still, I'm curious.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayako307"]
[OnName num="ayako"]
"Well, go on then. ......
[cpg cn=true]

[OnName num="yuuto"]
Huh?　Oh, I see.
[cpg cn=true]

It was already that time. I was a bit frazzled and decided to leave the house.
[cpg]

[OnName num="yuuto"]
Then, I'm going to go, Ayako.
[cpg cn=true]

Her words of "see you later" were also somber.
[cpg]


[SE f="se019"]
;//【ＳＥ】『扉閉まる』

;//【ＳＥ】『車のエンジン音』

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（昼）******************************************************

I think about it during the day at work.
[cpg]

Because I can't concentrate on my work. I want to solve this problem first.
[cpg]

What might be happening to Ayako. I think of all the possibilities.
[cpg]

Harassment. She might be out somewhere at night.
[cpg]

As I thought about it, one thing came to mind. One that I know about.
[cpg]

It's a pretty wild guess, and I don't think it's the right one.
[cpg]

I don't think he might be participating in the demon exorcism.
[cpg]

Participating is a little different. I guess I'm being forced to participate.
[cpg]

There has been no recent damage to the fields. That may be because Ayako has started to observe the village customs, right?
[cpg]

On the other hand, Ayako may have been forced to participate in the demon exorcism before. That means that Ayako must have been forced to participate in the demon exorcism before by Mr. Kawayama and others.
[cpg]

Because they refused to do so, their fields were destroyed, or something like that. ......?　Is it possible that the whole village is involved?
[cpg]

In other words, the harassment may have been in retaliation. If so, it's a hell of a village. ......
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]

Thinking about this, I headed home.
[cpg]

No matter what I think, I can't be sure without hearing it from him.
[cpg]

Or, without seeing the scene, you can't be sure. ......
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************


[OnName num="yuuto"]
"......you know, you've been ...... lately."
[cpg cn=true]

I cut him off. No, I tried to cut him off.
[cpg]

I didn't finish. I didn't finish it, because I didn't know why.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Ayako308"]
[OnName num="ayako"]
I was so proud of today's dish ......, this simmered dish.
[cpg cn=true]

Ayako interrupted my words.
[cpg]

I don't think it's a topic that I should interrupt her to talk about. The Ayako of old would not have done this.
[cpg]

She probably meant that she didn't want me to get involved any further.
[cpg]

She doesn't want me to worry about her, so she forces me to talk about this kind of thing.
[cpg]

[OnName num="yuuto"]
I guess so."
[cpg cn=true]

I couldn't say anything more and just responded to what I was told.
[cpg]

And that too, a reply that would reassure Ayako.
[cpg]

[OnName num="yuuto"]
It's delicious. Ayako's cooking is always delicious.
[cpg cn=true]

Ayako looked relieved. But even that relieved look was a little dark.
[cpg]

There is something a little dark. Somehow, there is a sense of hesitation, of not being blown away.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Ayako309"]
[OnName num="ayako"]
So, that's good. ......
[cpg cn=true]

See, there's something wrong with your reply, too. For someone who asked me on his own, he didn't expand on the subject.
[cpg]

I'm already in the middle of a conversation. While I'm talking, I keep worrying about Ayako behind her back.
[cpg]

And Ayako, who is being worried about, is also talking, but with an air of superiority about it. I don't know why.
[cpg]

It's as if the Ayako I knew before has gone somewhere else. It is as if Ayako is no longer here.
[cpg]

And I am also changing because of it. I have lost my emotional support and have become unstable.
[cpg]

The more I think about it, the more I feel uncomfortable.
[cpg]

Should I consider the possibility of the case?　If so, I can't ask him directly.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayako310"]
[OnName num="ayako"]
There's been no harassment recently, and it's really a very comfortable village to live in.
[cpg cn=true]

Ayako warps the topic from simmered dishes, and comes to me saying such a thing. In her mind, they must be connected.
[cpg]

[OnName num="yuuto"]
She says, "Yeah, I agree. I think so too.
[cpg cn=true]

I certainly agree, but. Ayako, do you really mean what you say?
[cpg]

It's as if she's saying it to herself. Something is stuck.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿寝室』（夜）******************************************************

And in the end, without saying anything about it, I pretended to ...... fall asleep.
[cpg]

I'll just follow Ayako when she leaves.
[cpg]

If she doesn't, that's fine. It means nothing happened that I know of.
[cpg]

I thought that would clear everything up. It might be a bit of a sneaky trick.
[cpg]

But since Ayako was not talking to me, I couldn't think of anything else to do.
[cpg]

I couldn't just stand by and watch Ayako's depression.
[cpg]

[SE f="se029"]
;//【ＳＥ】『衣擦れ』

[FG f="CHA01_p1_04_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=1000]

[VOICE f="Ayako311"]
[OnName num="ayako"]
She was already asleep.
[cpg cn=true]

Ayako asked me, who was pretending to be asleep. I was so worried about the fact that I was sleeping.
[cpg]

So, does that mean he's doing something behind my back? Hey, Ayako.
[cpg]

I can't say anything. I have to pretend to be asleep.
[cpg]

[OnName num="yuuto"]
"......"
[cpg cn=true]

I don't reply. I just kept quiet and pretended to be asleep and breathing.
[cpg]

After a while, Ayako got up from the futon.
[cpg]

[FO pos="2/3" time=1000]

Slowly, not making a sound, probably to keep me from noticing. And ......
[cpg]

[SE f="se019"]
;//【ＳＥ】『扉閉まる』

I opened my eyes thinly as she seemed to be leaving the room.
[cpg]

[free time=1000]
[WAIT time=1000]

Ayako is still trying to leave. She seems to be going somewhere during the night.
[cpg]

[OnName num="yuuto"]
'......What do you mean, Ayako?'
[cpg cn=true]

I muttered to myself after Ayako had completely left the house.
[cpg]

I had a bad feeling inside me that was only getting worse. So I had no choice but to find out.
[cpg]

I secretly followed Ayako.
[cpg]

I have to keep my distance, so I have to get out of here soon.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_zh"]
[WAIT time=100]
;//【ＢＧ】『洞窟へ続く道』（夜）******************************************************

And my bad premonition came true. Because I've been down this road ...... too.
[cpg]

Ayako is heading to the cave. The bad premonition was no longer a premonition.
[cpg]

Ayako is heading ...... to the cave where the demon exorcism took place and where I had an affair with Misaki.
[cpg]

I don't know if this is allowed to happen. It can't be.
[cpg]

Was this happening to my beloved wife without my knowledge?
[cpg]

I followed her, desperately stifling the imagination that welled up in me and the urge to scream.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟』（夜）******************************************************

And in that cave, as ...... expected, it was happening.
[cpg]

;//移植のためシーンをカットしています

[OnName num="yuuto"]
Ayako!"
[cpg cn=true]

I felt like I was stepping on the wrong foot when I shouted out. Or rather, I couldn't control my reason anymore.
[cpg]

I found myself jumping out of the way. I was trying to pull them off of me.
[cpg]

[OnName num="masuda"]
I was so excited. Who the hell is this guy ......?"
[cpg cn=true]

But I was thwarted. I couldn't get the guy off her.
[cpg]

[OnName num="man"]
I said, "Be quiet. The exorcism is a sacred ritual.
[cpg cn=true]

I fell down on the ground. I fell to the ground and was seized by another group of men.
[cpg]

I couldn't see if there were others or not,...... but I couldn't untie them.
[cpg]

Still, I could speak. I protested loudly.
[cpg]

[OnName num="yuuto"]
Let go of me! Let go of me!　Please explain!
[cpg cn=true]

What is this? Someone please explain.
[cpg]

I want to know what the hell is going on here that I don't know about, and how many times this has happened.
[cpg]

I want to hear it. I don't want to guess, I want the facts.
[cpg]

Just as I was thinking this, another person starts talking to me.
[cpg]

[OnName num="kawayama"]
I told you from the beginning that you should have brought your husband.
[cpg cn=true]

That voice is Mr. Kawayama. He is the village head of this village. In other words, something was going on in the whole village.
[cpg]

Well, it had to be the whole village.
[cpg]

It could not have been the village.
[cpg]

[OnName num="yuuto"]
What do you mean, what is this ......?
[cpg cn=true]

[OnName num="kawayama"]
What is this, you ask? It's just what I see.
[cpg cn=true]

[OnName num="yuuto"]
I don't understand it, that's why I'm asking you!
[cpg cn=true]

[OnName num="kawayama"]
It's just that Ayako-san has accepted her fate.
[cpg cn=true]

[OnName num="yuuto"]
What is that?　That's not an explanation!
[cpg cn=true]

Ayako had been silent all this time. She seemed to have lost her voice.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Ayako329"]
[OnName num="ayako"]
"...... Oh, you ...... me, have you been following me?"
[cpg cn=true]

The words she finally spoke were something like that.
[cpg]

Ayako looks at me with surprised eyes. That's right, I'm surprised.
[cpg]

I think I did it in a cowardly way. I can't apologize enough for that.
[cpg]

[OnName num="yuuto"]
Ah. I've been feeling strange lately. ......"
[cpg cn=true]

But I had no choice but to chase after her. Because I love Ayako.
[cpg]

[OnName num="yuuto"]
Why are you doing this, Ayako?
[cpg cn=true]

I ask the obvious question again.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako330"]
[OnName num="ayako"]
I'm sorry ......, but I have no choice.
[cpg cn=true]

Yes, it is. I knew I was going to get a response like this, but I had to ask.
[cpg]

;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『洞窟へ続く道』（夜）******************************************************


By the time the demon exorcism was over, my mind had already lost all sense of normalcy.
[cpg]

Or maybe I was feeling the same way until the end of the exorcism.
[cpg]

I wanted to curse everything in this world. And yet, I couldn't even muster up the energy to do so.
[cpg]

In any case, I was extremely tired. It was not my body, but my mind that was being drained.
[cpg]

[OnName num="yuuto"]
I said, "You're tired, Ayako.
[cpg cn=true]

But I think Ayako must be more tired than I am.
[cpg]

But I was worried about Ayako. I was just worried about Ayako, even though it was a dumb thing to say.
[cpg]

I said that, hoping that my concern would be conveyed.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Ayako371"]
[OnName num="ayako"]
I said, "Yes,......, I might be tired.
[cpg cn=true]

That's right. Ayako must have been tired too,......, because she kept doing this over and over again.
[cpg]

That's what you've been hiding from me. Yes, this is not the first time.
[cpg]

I'm at my limit. I can't help but be shocked after what happened.
[cpg]

I'm going to sleep for now. If it's all a nightmare, we can end this.
[cpg]

;//ＢＫ
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1000]


Yes, that's right. It's okay if it's all a dream. That's what I thought.
[cpg]

When Ayako woke up in the morning, she would act as if nothing had happened.
[cpg]

If another morning comes tomorrow and nothing happens, then that's good enough.
[cpg]

If it's all my fantasy, if it's all my imagination, ...... or if it's really a dream, how much more enjoyable can it be?
[cpg]

If it really is a dream, how much easier it would be. ......
[cpg]

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************


But morning comes, cruelly.
[cpg]

Morning itself is good, but the memory remains clear, and so does Ayako.
[cpg]

In other words, it wasn't a dream. It was undeniably real.
[cpg]

We talked without breakfast.
[cpg]

I was the one who initiated the conversation. I asked Ayako a question.
[cpg]

[OnName num="yuuto"]
"Did you do that to make them stop harassing you?"
[cpg cn=true]

She's a lot calmer than she was at that moment when the demon exorcism was taking place.
[cpg]

After one night, I became calm and put things in perspective.
[cpg]

Calm, though, is still more confused than I was before this whole thing broke out. ......
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Ayako372"]
[OnName num="ayako"]
I said to myself, "......Yeah. I had to do it this way, I'm sorry."
[cpg cn=true]

Ayako returns the affirmation. Well, I guess so.
[cpg]

I mean, you would have thought that would be the case for the most part, even while the demon exorcism was taking place.
[cpg]

For some reason, though, I couldn't accept that at the time. I must have been that distraught.
[cpg]

[OnName num="yuuto"]
'Oh, so ...... that's how it was.'
[cpg cn=true]

But still. The more I think about it, the more cowardly it sounds.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako373"]
[OnName num="ayako"]
"Really, I don't know how to apologize, but still ......
[cpg cn=true]

It's not that. The actuality is, you can't just go out and get a new one. You don't have to say you're sorry.
[cpg]

You don't have to say that. I'd rather have you apologize to someone else.
[cpg]

Masuda and Kawayama-san. They will never apologize, though.
[cpg]

[OnName num="yuuto"]
"No need to apologize. Let's get out of this village. It doesn't have to be here.
[cpg cn=true]

[OnName num="yuuto"]
There must be some other village out there that would be a better place to live. Villages without these ridiculous rituals."
[cpg cn=true]

[OnName num="yuuto"]
There are plenty of villages like this in this country. That's fine.
[cpg cn=true]

Ayako has an unflattering expression on her face. Yes, there is a problem.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Ayako374"]
[OnName num="ayako"]
But what about the renovation costs of these houses?　We haven't paid it off yet, and what about your job?"
[cpg cn=true]

She hit me right where it hurts. Yes, that's right.
[cpg]

The renovation costs are not free. In fact, it's quite a lot of money for us.
[cpg]

My job is not all ...... about what I want it to be.
[cpg]

[OnName num="yuuto"]
It's ...... not all about me."
[cpg cn=true]

The first thing you need to do is to make sure that you have a good understanding of what you're doing.
[cpg]

I'm going to see if I'm being cool about this. I'm not sure if I'm serious right now.
[cpg]

And the answer to that was obvious: ......
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayako375"]
[OnName num="ayako"]
"Are you going to start all over ......?"
[cpg cn=true]

Yes. I can't start all over again.
[cpg]

I can't leave this village for various reasons. I was getting a little hot.
[cpg]

I can't leave this village. At the very least, not right now.
[cpg]

On top of that, the happy life that Ayako wants will not be possible unless she joins the demon exorcism. That's a crazy story, isn't it?
[cpg]

The more I think about it, the more I realize how ridiculous it sounds.
[cpg]

[OnName num="yuuto"]
I ask, "Is that too much, ...... Ayako, is that what you want?"
[cpg cn=true]

I would ask that, but it may no longer matter what ...... Ayako says.
[cpg]

Suppose Ayako says she is fine with that. Even if Ayako says that she will continue to live as she is.
[cpg]

I'm not so sure I can accept that. ......
[cpg]

If that is the case, am I speaking for my own reasons? I wonder if Ayako is able to bear it.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se043"]
;//【ＳＥ】『車のエンジン音』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_08_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


When it comes time for work, I have to go out. There is nothing I can do about that.
[cpg]

I have a life too. I want to protect the life that Ayako wanted to protect.
[cpg]

I'm going to work again today. At night, or even during the day, Ayako may be being pressed by someone.
[cpg]

With those people, it's possible. Kawayama-san, in particular, probably doesn't have anything to do during the day.
[cpg]

The imagination comes to mind. No matter how hard I try to submerge them, the more I try, the more they float away.
[cpg]

My wife is being pestered by someone. I'm working for her.
[cpg]

And imagine, I couldn't get any work done. People around me were worried about me, but I couldn't do anything on my own.
[cpg]

[OnName num="colleague"]
'Are you all right, you ...... really, you don't look right. You don't look so good."
[cpg cn=true]

[OnName num="yuuto"]
"Yeah, I'm fine, I'm fine ......."
[cpg cn=true]

But that doesn't mean I can't ask for someone's help.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************

At night, we returned home for dinner. During that time, there was hardly any conversation.
[cpg]

We just sank into each other and just brought the food to our mouths.
[cpg]

And this is what happened after dinner.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Ayako376"]
[OnName num="ayako"]
'...... then, I'm off to exorcise the demons.'
[cpg cn=true]

I get nervous. Even though I know it, my body reacts with a jerk.
[cpg]

[OnName num="yuuto"]
So ......, you're being called out again today."
[cpg cn=true]

Ayako replies, "Yes. It must have been Mr. Kawayama or someone like him who approached her.
[cpg]

I know, I'm sure it's not something that can be forgiven just once or twice. I really don't want to believe it, though.
[cpg]

Just because I don't want to believe it doesn't mean I can't help it.
[cpg]

For Ayako, there is no need to hide it anymore. At night, Ayako started declaring that she was going to the cave.
[cpg]

She's not saying this to push me into a corner. Rather, it was the opposite.
[cpg]

I guess this is her way of showing concern. I understand.
[cpg]

She must be thinking that it would be more dishonest for me to go to the cave without telling her.
[cpg]

But I couldn't just send her off without telling her.
[cpg]

I was her husband, of course. But I couldn't keep her from going. Then.
[cpg]

[OnName num="yuuto"]
Can I go along with ...... too?
[cpg cn=true]

Ayako raised her voice, "What? I know, it's natural to be surprised.
[cpg]

Ayako is upset. Ayako might not understand why I'm following her.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayako377"]
[OnName num="ayako"]
But it's just too hard for you, right?
[cpg cn=true]

That's right. It's just hard for me. But even so, ......
[cpg]

There are more painful things. I explained this to Ayako.
[cpg]

[OnName num="yuuto"]
She said, "That's okay. It's better than being forced into a place you don't know. ......
[cpg cn=true]

[OnName num="yuuto"]
It's better than not knowing what they're doing to you in the cave.
[cpg cn=true]

[OnName num="yuuto"]
I feel like I'd be crushed if I had to wait for you at home."
[cpg cn=true]

I shudder to think of it. Alone, I wouldn't even be able to sleep.
[cpg]

But it would be much better than waiting at home. I would rather not have to endure that.
[cpg]

If that is the case, I would at least like to watch Ayako by my side. That would be much better.
[cpg]

When I explained this to Ayako, she agreed.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako378"]
[OnName num="ayako"]
She said, "I understand. Then, let's go together.
[cpg cn=true]

[OnName num="yuuto"]
I'm sorry, Ayako. I'm sorry, Ayako, for asking so much of you. ......
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_zh"]
[WAIT time=100]
;//【ＢＧ】『村』（夜）******************************************************

The village at night has very few lights.
[cpg]

There are not even that many streetlights.
[cpg]

Even on an empty, paved road, you could easily fall down.
[cpg]

Even on paved roads, there are weeds breaking through the asphalt in places.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayako379"]
[OnName num="ayako"]
It's dark. ...... This village is always like this at night.
[cpg cn=true]

It is dark. Blackness that seems to swallow everything.
[cpg]

[OnName num="yuuto"]
"Oh ...... sure, it sure is. It's hard to see in the evening.
[cpg cn=true]

[OnName num="yuuto"]
There are not many streetlights. I wonder what it is like at night.
[cpg cn=true]

[OnName num="yuuto"]
I wonder if it's not inconvenient for the people in this village. Haha ......"
[cpg cn=true]

Holding hands, Ayako's hands are trembling.
[cpg]

Or perhaps my hand is trembling. I don't know which.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayako380"]
[OnName num="ayako"]
I'm scared ...... that this darkness is going to swallow us all up.
[cpg cn=true]

It's funny, isn't it? I thought I came to the countryside because I loved these pitch-dark nights.
[cpg]

There was a time when I loved this darkness.
[cpg]

[OnName num="yuuto"]
"...... oh."
[cpg cn=true]

Now I am just scared. It's as if I'm inhabiting the madness of this village.
[cpg]

As Ayako said, we will be consumed by this darkness.
[cpg]

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟』（夜）******************************************************

[OnName num="kawayama"]
"Oh, you've come. I'm tired of waiting.
[cpg cn=true]

[OnName num="kawayama"]
You are a little late today, aren't you? You were trying to persuade your husband, weren't you?
[cpg cn=true]

I couldn't stand the thought of Ayako being pressed at this point, so I offered.
[cpg]

I am sure I will be rebuffed, but I have to say it.
[cpg]

I knew it was futile, but I couldn't stop resisting.
[cpg]

[OnName num="yuuto"]
......Will you let me do it, too?
[cpg cn=true]

[OnName num="kawayama"]
"Hmmm, I will. I'll join you in the exorcism, is that correct?
[cpg cn=true]

[OnName num="yuuto"]
I'm going to participate in the exorcism. I'll help you with that ...... too.
[cpg cn=true]

[OnName num="kawayama"]
Then, I'll ask you to help me with Chinatsu-san.
[cpg cn=true]

[OnName num="yuuto"]
"Oh ......, no.
[cpg cn=true]

Oh no, how could he come up with that idea?　He must be really crazy.
[cpg]

[OnName num="yuuto"]
No, sir!　It's not that, I'll ...... be Ayako's partner."
[cpg cn=true]

[OnName num="kawayama"]
"Hmmm, I see, I guess so."
[cpg cn=true]

I offered, but Kawayama-san groaned and twisted his head.
[cpg]

[OnName num="kawayama"]
I'm sorry to hear you say that. Mr. Yuto, you just joined, you don't have the authority to make decisions."
[cpg cn=true]

There is no real reason for that. It doesn't matter if you just joined or not.
[cpg]

Mr. Kawayama would say such cruel things. This man may be a genius at stirring people's hearts.
[cpg]

;//========================================
;//●ＣＧエロ（男に押し倒されるヒロイン）ev_20
;//人物１：ヒロイン１
;//服装１：白装束
;//人物２：村長
;//服装２：白装束（鬼の面をつけている）
;//場所　：洞窟
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_20_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

After this day, it all came crashing down. I definitively lost my sane mind.
[cpg]

Ayako also broke down. She was no longer the person she had been.
[cpg]

[VOICE f="sAyako011"]
[OnName num="ayako"]
......Yuto, I'm sorry."
[cpg cn=true]

Maybe this day was the beginning of a gradual breakdown of us, but either way, we had come to the point of no return.
[cpg]

We had come to the point of no return.
[cpg]

;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]

Time passed. As we spent our days exorcising the demons, spring was coming to an end.
[cpg]

The end of spring meant the end of the demon exorcism. It was a festival to pray for a good harvest.
[cpg]

[window target=false]
[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_00_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（昼）******************************************************

It was daytime on a holiday.
[cpg]

The sky was cloudless. In the slightly hot sunlight.
[cpg]

We had regained a moment of peace,......, but it wasn't a moment of peace.
[cpg]

[OnName num="yuuto"]
The first thing to do is to get a good look at the newest version of the site. Go ahead."
[cpg cn=true]

Even though we no longer needed the seasonal demon exorcism, I had sent Ayako to someone else's place.
[cpg]

I had to do it, or I wouldn't even feel very much alive anymore.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako421"]
[OnName num="ayako"]
'Well then, I'm off. ......
[cpg cn=true]

I didn't follow her, but only let Ayako go with me.
[cpg]

I'm not going to be able to do that. In the past, I would have done exactly the opposite.
[cpg]

[OnName num="yuuto"]
Oh, ......."
[cpg cn=true]

Only I stayed home to feel the solitude of being alone.
[cpg]

And then, I am surrounded by a painful silence.
[cpg]

;//綾子に視点切り替わり

;//【ＢＧ】『空』（昼）
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『村』（昼）******************************************************


[VOICE f="Ayako422"]
[OnName num="ayako"]
'Hello, Mr. Kawayama,...... I need to come in and discuss something with you.
[cpg cn=true]

I had come to Mr. Kawayama's house. I had come to his house, where I had no business to be.
[cpg]

I had come to his house to pretend to be his lover. There is no other reason why I would dare to visit this house again.
[cpg]

The exorcism was already over.
[cpg]

[OnName num="kawayama"]
What is the matter? The exorcism is over, isn't it?"
[cpg cn=true]

;//私は、そんなこととは無関係に、貴方に迫られなきゃいけない。
I have to put you in a good mood, irrespective of that.
[cpg]

Knowing this, Mr. Kawayama seemed to be pretending not to know.
[cpg]

But if he wants me to explain, I will explain. I couldn't do it without his cooperation.
[cpg]

;//ＢＫ

I said. I told him what kind of condition Yuto-san was in and what had happened to me.
[cpg]

[OnName num="kawayama"]
He said, "Hmm, I see. That happened without my knowledge.
[cpg cn=true]

Kawayama-san chuckled. It was not until I joined the demon exorcism that I began to notice the snarl in his smile.
[cpg]

If I had noticed it earlier, I wonder if something would have changed.
[cpg]

[OnName num="kawayama"]
I wonder," he said. It must have been because of the demon exorcism, I feel sorry for you.
[cpg cn=true]

I think he meant "because of you. I was tempted to say so, but decided not to.
[cpg]

So, ......," I asked further. Mr. Kawayama answered.
[cpg]

[OnName num="kawayama"]
Of course. If I can be of help to you, I would be honored.
[cpg cn=true]

;//========================================
;//●ＣＧエロ（主人公以外の男とキスをするヒロイン。携帯電話は消してください）ev_22
;//人物１：ヒロイン１
;//服装１：裸
;//人物２：村長
;//服装２：裸
;//場所　：村長の家・寝室
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_22_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sAyako012"]
[OnName num="ayako"]
'...... nn.......'
[cpg cn=true]


Yuto is not next to me. So it should be the same whether I do this or not.
[cpg]

And yet ...... things like this kept us going.
[cpg]

The more we thought we had to stop, the more we couldn't stop.
[cpg]


;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
;//悠斗に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『扉開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************


[OnName num="yuuto"]
"......Welcome back."
[cpg cn=true]

;//綾子が帰ってきた。顔を赤らめて、雌の表情をしていた。
Ayako came home. She blushed and ......
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Ayako463"]
[OnName num="ayako"]
'I'm home, Yuto,...... um,...... I'm going to make dinner, I'll do it.'
[cpg cn=true]

Then, Ayako fell silent and asked, "Are we okay with this?
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako466"]
[OnName num="ayako"]
I'm sure we're doing fine. There's nothing wrong with that, right?
[cpg cn=true]

[OnName num="yuuto"]
I guess so. I don't know if we're crazy or ...... crazy.
[cpg cn=true]

[OnName num="yuuto"]
What do you think, ......?"
[cpg cn=true]

Ayako ponders. She pondered, and then, as if sighing, she said, "I'm sure everyone is like that.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Ayako467"]
[OnName num="ayako"]
I'm sure that everyone is like that,...... and I think that married couples do things while holding on to something that's not right.
[cpg cn=true]

Oh, that may be true, indeed. I think there are degrees to that, though.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Ayako468"]
[OnName num="ayako"]
So you're fine with ...... this much, aren't you?"
[cpg cn=true]

[free time=300]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

I hugged Ayako. Ayako's body was hot.
[cpg]

[OnName num="yuuto"]
I'm sure he'll be fine. "Yeah, I'm sure I'll be fine."
[cpg cn=true]

Ayako also stretches her arms around me. She hugs me.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Ayako469"]
[OnName num="ayako"]
We can stay together forever, right ......?
[cpg cn=true]

She said as if to confirm. I had no choice but to nod.
[cpg]

[SCENE id=9]

;//ＥＮＤ：ヒロイン１ルート・エンド

[jump storage="epend.ks" target="*start"]


;//==============================
