
*start

;//【鬼鎮の雌贄_シナリオ】
;//物語の視点が変わる部分があります。ウィンドウ色を変えるなどして、変化をつけていただけると助かります
;//視点は悠斗視点、綾子視点の二種類です
;//物語は悠斗視点からスタートし、切り替わる部分では「（キャラ名）に視点切り替わり」と表記してあります
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//以下音声あり
;//綾子 千夏 美咲
;//以下音声なし
;//悠斗 河山 益田 同僚 男

;//以下、残したCGを列挙します

;//綾子 01 02 06 12 14 17 20 22 33
;//千夏 07 26 31 35 36 38 47
;//美咲 08 39 44 48


;#################################################
*Ep000|Our usual routine
;#################################################

[SCENE id=0]


[stflag f_Chinatsu = 0]
[stflag f_Misaki = 0]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『空』（昼）******************************************************

The countryside, I didn't think it would be this rural.
[cpg]

;//========================================
;//●ＣＧ非エロ（春の田んぼの間、あぜ道を歩く。手を繋いで幸せそうにする二人）ev_01
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：あぜ道
;//時間　：昼
;//========================================

[free time=1000]
[window target=false]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

Next to me, the place where I walk with my wife, Ayako, is a dirt road.
[cpg]

Paved roads are rare in this village.
[cpg]

There are only a few houses, and most of them are in rice paddies.
[cpg]

There are no houses or anything else that you would find in the city.
[cpg]

There are only woods and forests. There is just a lot of greenery. This is a village that is returning to nature.
[cpg]

The road we are walking on is called "Azemichi," so there are rice fields on both sides of the road.
[cpg]

[VOICE f="Ayako001"]
[OnName num="ayako"]
Seedlings are beautifully planted. Do you like this kind of scenery, Yuto?
[cpg cn=true]

I said frankly what I was thinking. I'm sure no one would say that they don't like what they see.
[cpg]

[OnName num="yuuto"]
'Well, if you ask me if I like it or not, I guess I do. ......
[cpg cn=true]

Ayako smiled in response to my reply.
[cpg]

[VOICE f="Ayako002"]
[OnName num="ayako"]
"Phew. You'll see it every day from now on. No, every year."
[cpg cn=true]

[OnName num="yuuto"]
Every year?　Isn't every day enough?
[cpg cn=true]

[VOICE f="Ayako003"]
[OnName num="ayako"]
"Because it is, isn't it?　This view changes with the seasons.
[cpg cn=true]

Well, sure. Can't we see it every day, these seedlings grow and grow and grow, with ears of rice ......
[cpg]

In the city, it is hard to experience such seasonal changes.
[cpg]

I thought again that we were really in the countryside.
[cpg]

[VOICE f="Ayako004"]
[OnName num="ayako"]
It's nice. ...... really makes you realize that your dreams have come true.
[cpg cn=true]

[OnName num="yuuto"]
But even so, it's hard to just go for a walk on a holiday when you've got so much to do. ......
[cpg cn=true]

Ayako is smiling all the time. If Ayako is having fun, that's fine, but ......
[cpg]

For that matter, you're just walking down a road with nothing on it.
[cpg]

[VOICE f="Ayako005"]
[OnName num="ayako"]
It's nice. Just a walk in such a lovely place would be refreshing, wouldn't it?"
[cpg cn=true]

[OnName num="yuuto"]
"That's, well, I suppose it certainly is. ......
[cpg cn=true]

[VOICE f="Ayako006"]
[OnName num="ayako"]
I think I'm going to like this village even more than I already do. I am sure you will too, Yuto.
[cpg cn=true]

[window target=false]
[free time=1000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（昼）******************************************************

Yuto Sumii. He is a little different from the usual salaryman.
[cpg]

It is not that his occupation is unique. His work is not so different from that of an ordinary salaryman.
[cpg]

What is decidedly unusual is where he lives.
[cpg]

I don't mean to say that people living in the countryside are unusual. It's not that. ......
[cpg]

To begin with, we both were born and raised in the city.
[cpg]

There is a reason why we suddenly came to the countryside from there.
[cpg]

My wife, Ayako, is a big country lover, or rather, a person who wants to live in the countryside.
[cpg]

We had our wedding in the city, but Ayako wanted to move to the countryside deep in the mountains.
[cpg]

I still remember how she pushed aside the opposition from those around her, as if she were about to elope.
[cpg]

;//ＣＧ再び表示
[free time=1000]
[window target=false]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]



I now live in an abandoned house that has been renovated. At first it was full of inconveniences, but I was getting used to it.
[cpg]

It is inconvenient while I am getting used to it. But Ayako didn't seem to mind.
[cpg]

[VOICE f="Ayako007"]
[OnName num="ayako"]
She said, "I can get to the city in an hour and a half by car. It's not inconvenient.
[cpg cn=true]

An hour and a half. That's how long it takes to get to the nearest densely populated area.
[cpg]

[OnName num="yuuto"]
You say it's easy, but even if you ...... spend that much time, it's not much of a town.
[cpg cn=true]

[OnName num="yuuto"]
It's more like a village than a town. ......
[cpg cn=true]

[VOICE f="Ayako008"]
[OnName num="ayako"]
"Oh, I don't know. But that's about the right distance for me.
[cpg cn=true]

[OnName num="yuuto"]
That's what you ...... would say, wouldn't you?
[cpg cn=true]

That's right. Ayako is that kind of personality. She is a rather calm woman who does not like to be pushy.
[cpg]

[OnName num="yuuto"]
But how did she manage to live in the city all this time?
[cpg cn=true]

[VOICE f="Ayako009"]
[OnName num="ayako"]
I just can't stand the cluttered atmosphere of the city. ...... It's strange that you were born and raised in the city.
[cpg cn=true]

[OnName num="yuuto"]
I wouldn't say it's weird. I have those feelings too.
[cpg cn=true]

I'm not saying it's weird. I would not have gone this far if I didn't have the desire to live in the countryside.
[cpg]

I had a longing for the countryside, too, though not as much as Ayako.
[cpg]

[VOICE f="Ayako010"]
[OnName num="ayako"]
'Really?　Then I can live in this village without any worries.
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（昼）******************************************************



I decided to get out of the rice paddies and go for a walk in the village.
[cpg]

[OnName num="yuuto"]
'...... amazing scenery, really.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]

Even just walking around the village, the scenery is completely different from what you see in the city.
[cpg]

Nothing is what it seems. There is no clutter of color like in the city at all.
[cpg]

Green. And then there's the blue of the sky. It blends in so well with nature, or rather, it becomes nature itself.
[cpg]

While I was thinking about this, another person came walking from the other side of the street.
[cpg]

The elderly man coming from the other side of the road was Mr. Kawayama. He is the village head of this village.
[cpg]

[OnName num="yuuto"]
He bowed his head and said, "Oh, hi, hello ......."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]

He bowed to me from the other side. In the countryside, not many people live here, so it is common practice for people to bow when they pass by someone.
[cpg]

[OnName num="kawayama"]
Hello," he said. Are you two going for a walk?
[cpg cn=true]

[OnName num="kawayama"]
"There must be a lot of inconveniences in this village. This village is full of inconveniences, isn't it?
[cpg cn=true]

[OnName num="yuuto"]
No, it's not inconvenient at all. It's not inconvenient at all.
[cpg cn=true]

I said the opposite of what I had said before. It is hard to say so when you hear it from the residents of this village to your face.
[cpg]

[OnName num="kawayama"]
Have you gotten used to this village?
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayako011"]
[OnName num="ayako"]
Yes, thanks to you. Thanks to you. It's a nice place, isn't it?
[cpg cn=true]

[OnName num="kawayama"]
I am glad to hear that. As the village head, I am very happy to hear that.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayako012"]
[OnName num="ayako"]
I want to stay here forever. I want to stay in this village until I become a grandmother.
[cpg cn=true]

Kawayama-san laughs. It certainly seems difficult for me to stay here until I become a grandmother.
[cpg]

[OnName num="kawayama"]
"Ha-ha-ha. By then, this village will be gone.
[cpg cn=true]

The idea that the village will be gone is not an exaggeration at all.
[cpg]

There are too few young people and children.
[cpg]

How are they doing with the schools?　When we have kids, we'll have to think about it.
[cpg]

I mean, ......, that's what people usually think about before they emigrate.
[cpg]

It really is a daredevil elopement. While I was thinking about that, their conversation continued.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayako013"]
[OnName num="ayako"]
Oh, no. Such a wonderful place won't disappear.
[cpg cn=true]

[OnName num="kawayama"]
Is that so?　But if things continue as they are, the population will only decrease.
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Ayako014"]
[OnName num="ayako"]
I think there are many ways to revitalize the village.
[cpg cn=true]

Mr. Kawayama crossed his arms and said, "Hmmm.
[cpg]

[OnName num="kawayama"]
I think there are many ways to revitalize the village. I'm trying to think of various ways, but it's not easy.
[cpg cn=true]

[OnName num="kawayama"]
This village used to be a proper farming village, you know.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako015"]
[OnName num="ayako"]
But if too many people start coming here, I may be in trouble. ......
[cpg cn=true]

[OnName num="kawayama"]
Is that so?　What do you mean by that?
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Ayako016"]
[OnName num="ayako"]
Because I like this village as it is now.
[cpg cn=true]

The two of us struck up a conversation. I had originally been heckled by the hustle and bustle of the city, so I was reasonably satisfied with my current life.
[cpg]

Although I can't always keep up with Ayako, who is always happy to see me. ......
[cpg]

Still, I like the countryside.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_go"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（夕方）******************************************************

We are living in a renovated house that was originally there.
[cpg]

We did this because we didn't want to build a new house in such a rural area.
[cpg]

So, of course, there is no second floor. It is a one-story Japanese-style house.
[cpg]

Since the house has been renovated, it is not difficult to use.
[cpg]

I like the atmosphere of this house. When I first came here, I was a little surprised to see it. ......
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

I walked through the front door and greeted the empty living room.
[cpg]

[OnName num="yuuto"]
I say, "I'm home.
[cpg cn=true]

It's an old habit. I thought I couldn't change it now,......, but then Ayako said, "Oh, wait a minute.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Ayako017"]
[OnName num="ayako"]
Oh, wait a minute, I've got something to do. I have something to do.
[cpg cn=true]

Business?　What kind of errands could she be running in the countryside?
[cpg]

[OnName num="yuuto"]
I thought to myself, "errands?
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（夕方）******************************************************

But, as I thought, I was right. Ayako was tending to the field behind her house.
[cpg]

[OnName num="yuuto"]
She was taking care of the field behind her house. She's a diligent person, or rather, she does it well.
[cpg cn=true]

Ayako is enthusiastic about this kind of thing. She's even more than enthusiastic; she's so into it that it's a little strange.
[cpg]

What may seem out of the ordinary to me, to Ayako, is something she longs to do every day.
[cpg]

[FACE method="change_1" pos="2/3"]

This is what Ayako originally moved here to do. It seems to have become a natural routine for her.
[cpg]

[OnName num="yuuto"]
"You take care of this every day, don't you?　Not just once a day, either.
[cpg cn=true]

[OnName num="yuuto"]
If it were me, I wouldn't be able to do it because it's too much trouble."
[cpg cn=true]

Ayako looks at me while bending over at the waist.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Ayako018"]
[OnName num="ayako"]
She looks at me, bending over at the waist. I'm sorry for being a housewife, I wish I could go out to earn money too.
[cpg cn=true]

Oh, no. I didn't know she was that worried about me.
[cpg]

[OnName num="yuuto"]
I said, "That's fine. I don't know what kind of work there is in such a rural area.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako019"]
[OnName num="ayako"]
"Oh, God. You don't have to speak so ill of this village, do you?
[cpg cn=true]

Oh, shit. I didn't mean it that way.
[cpg]

[OnName num="yuuto"]
I didn't mean anything bad by it, I was just concerned about Ayako.
[cpg cn=true]

Thank you, Ayako said. I'm glad you understood right away.
[cpg]

[OnName num="yuuto"]
Well, but it sure is a nice village. ......
[cpg cn=true]

Yes," Ayako replies. Then she continued.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayako020"]
[OnName num="ayako"]
'It's a lovely place,......, you grow your own food, and eat it yourself.'
[cpg cn=true]

Something that modern people have forgotten, or rather, something that comes naturally to them.
[cpg]

Somehow, cooking food has changed to mean cooking.
[cpg]

[OnName num="yuuto"]
'...... I know, I know. It's a good thing."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayako021"]
[OnName num="ayako"]
'I kind of feel like I'm going to live longer. Don't you think so, Yuto?"
[cpg cn=true]

That was me, thinking that might be true.
[cpg]

If I live a regular life in this village, I'll have a decade longer life expectancy.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（夜）******************************************************

Evening turns to night, and tomorrow will soon come again.
[cpg]

My beloved holiday has passed, and it's just another weekday as usual.
[cpg]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[window target=false]
[free time=1000]
[BG f="b_07_1.ui" time=1000]
[WAIT time=3000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_00_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************


[OnName num="yuuto"]
I'm off then.
[cpg cn=true]

I put on my shoes and grab my bag. I turned around and greeted Ayako.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayako022"]
[OnName num="ayako"]
Yes," she said, "have a good day. Have a good day.
[cpg cn=true]

Ayako always sends me off with a smile.
[cpg]

[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]

After a brief greeting, I head off to work. ......
[cpg]

Getting to work is another challenge.
[cpg]

There is the one and a half hour problem. I think it's safe to say that this is already a problem.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_go"]
[WAIT time=100]

I have to drive an hour and a half each way to get to the city. It is a deserted town, not even a regional city.
[cpg]

It is somewhere between a village and a city, or so it seems to me.
[cpg]

I was an office worker at a company there.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（昼）******************************************************

[OnName num="colleague"]
I heard you came from Tokyo.　How can you call this town a town?
[cpg cn=true]

A co-worker spoke to me. If I told him that I lived in a more rural area, he would sit up and take notice.
[cpg]

[OnName num="yuuto"]
No, I don't think so. If you saw the hustle and bustle of the city, you would think the opposite, I bet.
[cpg cn=true]

Yes, that's right. I only need to see the city once in a while.
[cpg]

I'm starting to get a little attached to this deserted town.
[cpg]

[OnName num="yuuto"]
I like this view better. Look, the sky is so wide.
[cpg cn=true]

There are only a few things of any kind.
[cpg]

Or, rather, there is nothing at all. There is nothing.
[cpg]

As I said before, the sky is very wide, and at night you can see the stars very well.
[cpg]

What was laid out in the city seems to have been scattered. Not a single tall building can be seen in front of the station.
[cpg]

I spent the day thinking, "I wonder if that would be one of the tall buildings in the countryside. ......
[cpg]

[OnName num="colleague"]
I'm a sucker for things. I'm longing for the city.
[cpg cn=true]

[OnName num="yuuto"]
"Ha-ha. Well, I'll trade you where we lived.
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（夜）******************************************************

And then night falls, I finish work, and get ready to go home.
[cpg]


;//ＢＫ
[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_08_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


It's another hour and a half back home. I drove on a straight road with no traffic, thinking, "This is a long way.
[cpg]

Not only was there no traffic, but there were only a moderate number of cars on the road. This is unthinkable in the city.
[cpg]

I guess I will eventually get used to it.
[cpg]

I hope that everything will become more natural in the countryside.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************


[OnName num="yuuto"]
I'm home.
[cpg cn=true]

Ayako greets me with a smile. She greets me with a smile, just as she does when she leaves the house.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayako023"]
[OnName num="ayako"]
Welcome home, dear.
[cpg cn=true]

At home, Ayako was waiting for me, having cooked dinner.
[cpg]

Most of the dishes are vegetable-based, but there are also some meats. I guess she is taking care of me.
[cpg]

If Ayako was the only one eating, it would really only be vegetables and grains.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Ayako024"]
[OnName num="ayako"]
Ayako said, "This one and this one are vegetables we picked at our house. Isn't it amazing?"
[cpg cn=true]

[OnName num="yuuto"]
"Well, you moved here not too long ago, didn't you?
[cpg cn=true]

[OnName num="yuuto"]
Can you harvest them that quickly?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]

Ayako answered, "Yes. Yes," Ayako answered.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayako025"]
[OnName num="ayako"]
I sowed some vegetables that grow quickly.
[cpg cn=true]

[OnName num="yuuto"]
I don't know much about growing vegetables at all.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako026"]
[OnName num="ayako"]
And these are vegetables that I got as a gift from ...... Masuda-san, I think it was.
[cpg cn=true]

[OnName num="yuuto"]
"Masuda-san. ...... I may or may not have seen him on the nameplate."
[cpg cn=true]

[OnName num="yuuto"]
There are a lot of similar surnames around here. ......
[cpg cn=true]

Is this also something peculiar to the countryside? There are many similar surnames.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayako027"]
[OnName num="ayako"]
I'm sure you'll be able to find a way to get a hold of her. Maybe Yuto will meet her sometime soon.
[cpg cn=true]

[OnName num="yuuto"]
Maybe so. I'll thank you again then.
[cpg cn=true]

[OnName num="yuuto"]
I'm hungry. ...... Can I eat now?
[cpg cn=true]

Ayako laughed a little when I said something childish.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayako028"]
[OnName num="ayako"]
The actuality is that you can get a lot more than just a few. Then, let's eat.
[cpg cn=true]

A healthy dining table. Every day, I feel somewhat refreshed in body and soul, but also somewhat uninspired.
[cpg]

It would be true to say that this is the way it is in the countryside, but even so, there is still too much stimulation missing.
[cpg]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿寝室』（夜）******************************************************

The only stimulus that I found at ...... was Ayako herself.
[cpg]

It may sound rude to say so, but she is the most important person in my life.
[cpg]


;//========================================
;//●ＣＧエロ（ヒロインと一緒に眠る主人公）ev_02
;//人物１：ヒロイン１
;//服装１：パジャマ
;//人物２：主人公
;//服装２：パジャマ
;//場所　：主人公の家・寝室
;//時間　：夜
;//========================================

[window target=false]
[free time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[OnName num="yuuto"]
Hey, Ayako.
[cpg cn=true]

[VOICE f="sAyako001"]
[OnName num="ayako"]
...... what is it?"
[cpg cn=true]

[OnName num="yuuto"]
Do you want me to help you with the vegetables in your garden?
[cpg cn=true]

[VOICE f="sAyako002"]
[OnName num="ayako"]
"Don't force yourself. I know you're not interested.
[cpg cn=true]

I felt my heart being healed just by the unimportant conversation.
[cpg]

;//綾子に視点切り替わり
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;//========================================
;//●ＣＧエロ（主人公と一緒に眠るヒロイン。主人公は寝ているため消してください）ev_06
;//人物１：ヒロイン１
;//服装１：パジャマ
;//人物２：主人公
;//服装２：パジャマ
;//場所　：主人公の家・寝室
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
;**【ＣＧ】 ev_06_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

Yuto-san was tired and fell asleep first.
[cpg]

I feel happy in casual conversation with him.
[cpg]

I am not lying about how I feel now. It is true that I feel happy.
[cpg]

[VOICE f="Ayako160"]
[OnName num="ayako"]
...... huh."
[cpg cn=true]

Still. I wanted to talk to him just a little bit more. I really wanted him to hold my hand.
[cpg]

This moment is the hardest. I want to feel the same way he does.
[cpg]

It's not enough. It's not enough at all, but Yuto doesn't notice this feeling.
[cpg]

This was our usual routine.
[cpg]

;//移植のためシーンをカットしています

[jump storage="ep001.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
