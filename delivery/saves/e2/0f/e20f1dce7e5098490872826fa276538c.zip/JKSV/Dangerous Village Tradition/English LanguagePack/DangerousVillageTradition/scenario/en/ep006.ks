
*start

;#################################################
*Ep006|Love Ayako and help Chika
;#################################################

[SCENE id=6]


;//ＢＫ
;//悠斗に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************



The next morning, Ayako's complexion was even worse. Or rather, her expression was dark.
[cpg]

[OnName num="yuuto"]
She said, "...... What's wrong, Ayako? You look really pale."
[cpg cn=true]

Ayako says, "Yeah, I'm just ...... a little bit. She was not very articulate.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Ayako491"]
[OnName num="ayako"]
She said, "Hey, you. Are you hiding something from me?"
[cpg cn=true]

I was startled. I feign calmness and answer.
[cpg]

[OnName num="yuuto"]
No, I'm not. Why do you ask me that?
[cpg cn=true]

[OnName num="yuuto"]
"Am I doing something that would make you suspicious of me?　If so, please tell me.
[cpg cn=true]

I try to be a little aggressive and go that far. Then, Ayako responded.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako492"]
[OnName num="ayako"]
No, I'm going to be straight to the point. You're not cheating on me, are you ......?"
[cpg cn=true]

...... I see. I guess it's something that's been made known.
[cpg]

[OnName num="yuuto"]
"No, ......, I didn't. I can assure you."
[cpg cn=true]

I managed to reply calmly, my heart pounding.
[cpg]

Did they see you?　Or did they hear some kind of gossip?
[cpg]

Either way, it's pretty bad. I had to get out of this situation.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayako493"]
[OnName num="ayako"]
If you didn't, that's okay. It's okay, don't worry about it. ......
[cpg cn=true]

[OnName num="yuuto"]
"......, okay. Why did you think that?
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Ayako494"]
[OnName num="ayako"]
I'm sorry, I know it's a weird thing to ask. I'm fine, I've made up my mind. ......
[cpg cn=true]

That's not an answer. And what do you mean, "made up my mind"?
[cpg]

[OnName num="yuuto"]
What do you mean, "made up your mind"?
[cpg cn=true]

Ayako looked disgusted. I wrinkled my brow a little.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Ayako495"]
[OnName num="ayako"]
......What, you know, whatever.
[cpg cn=true]

It was as if she was going to spit it out. I was so happy to see her.
[cpg]

This was the first time we had ever been like this.
[cpg]

It was the first time we had ever been in such a bad place, or that Ayako, who hates to fight, would behave this way.
[cpg]

I wondered if she had seen me after all.
[cpg]

If so, there was no way to cover it up. There is nothing I can do about it now.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（昼）******************************************************

I thought about it during the day. Did they find out about the demon exorcism after all?
[cpg]

In this rural area, gossip spreads quickly.
[cpg]

Did someone tell Ayako about this? I don't think that's very likely. ......
[cpg]

But if someone was plotting to have a falling out between us, it might be possible.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************

And then night. Dinner was as usual, nothing out of the ordinary.
[cpg]

However, after dinner, Ayako cut in.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayako496"]
[OnName num="ayako"]
I have something to do. So I won't be home tonight.
[cpg cn=true]

Business?　Because there is nothing around here.
[cpg]

[OnName num="yuuto"]
What kind of errand? What kind of errand in the countryside?
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Ayako497"]
[OnName num="ayako"]
What do you want?　It's not like I'm talking to you.
[cpg cn=true]

It's not something you should be talking to me about. I never thought Ayako would talk to me like this.
[cpg]

As I thought in the morning, Ayako is a mild-mannered person. She's really angry.
[cpg]

[OnName num="yuuto"]
I thought to myself in the morning, but Ayako is a very mild person. What's going on?
[cpg cn=true]

[OnName num="yuuto"]
If you have a problem, I'll listen, you can tell me.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayako498"]
[OnName num="ayako"]
"I'm sorry, ....... I may be going crazy.
[cpg cn=true]

Ayako says apologetically. I'm getting even more anxious.
[cpg]

[OnName num="yuuto"]
"...... What's that? What the hell does that mean?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako499"]
[OnName num="ayako"]
But it's ...... nothing.
[cpg cn=true]

But it is. What will follow after that?
[cpg]

But it's your fault, I wonder if it will continue.
[cpg]

The bad premonition is confirmed.
[cpg]

Maybe, just maybe, ......
[cpg]

I think Ayako is heading for that place.
[cpg]

I think she is trying to do the same thing to me in retaliation for what I did to her.
[cpg]


;//【ＳＥ】『扉開く』
;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[VOICE f="Ayako500"]
[OnName num="ayako"]
I'm off then."
[cpg cn=true]

[SE f="se019"]
;//【ＳＥ】『扉閉まる』

Ayako left the house after saying that.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『村』（夜）******************************************************

[SE f="se001"]
;//【ＳＥ】『歩く』

After a slight delay in leaving the house, I headed for the cave.
[cpg]

Today, too, the demon exorcism should be taking place. Believe that Ayako is not there.
[cpg]

Believing that only Chinatsu was there, I headed to .......
[cpg]

The first thing you need to do is to make sure that you have a good time.
[cpg]

With that in mind, I headed out and ...... arrived at the cave.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟へ続く道』（夜）******************************************************

I arrived at the cave. My heart is still beating loudly.
[cpg]

There I heard a woman's voice that was not Chinatsu-san.
[cpg]

No, it wasn't Chika-san, or rather, this was like ......
[cpg]

Ayako's voice, isn't it?
[cpg]

;//移植のためシーンをカットしています

;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟』（夜）******************************************************

;//@0708追加===================================

I enter the cave and hide in the shadows to peek inside.
[cpg]

I don't want to see. I don't want to see this. Such a thing was happening.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=1000]
[WAIT time=1000]

Ayako was participating in a ...... demon exorcism ......
[cpg]

Oh my God. What I feared the most had become a reality.
[cpg]

[OnName num="yuuto"]
Ayako!　Get away from those guys right now!"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

I couldn't resist revealing that I was here and yelling.
[cpg]

Ayako turns to me. She looked at me and was surprised.
[cpg]

[OnName num="yuuto"]
I was so surprised to see her looking at me!　I really love you. ......
[cpg cn=true]

;//@0708追加===================================

[free time=300]
[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="4/5" time=800]

;//@
;//そして千夏さんが、後からやってきた。
I love you. Before I could say that much, Chinatsu-san came in.
[cpg]

The first thing you need to do is to make sure that you have a good understanding of what you're doing.
[cpg]

He looked at us, surprised at first, but then seemed to have a general idea what was going on.
[cpg]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Chinatsu152"]
[OnName num="chinatsu"]
She looked at us, surprised at first, but then made a generally knowing expression. I knew it was going to be like this.
[cpg cn=true]

Chika, you also foresaw this coming, didn't you?
[cpg]

I had no idea. I was the only mosquito in the room.
[cpg]

[FACE method="shake_4" pos="2/5"]
[VOICE f="sAyako015"]
[OnName num="ayako"]
Yuto, will you stop me?"
[cpg cn=true]

[OnName num="yuuto"]
"Isn't it obvious, ......?　I can't believe you're pretending to be someone else's lover.
[cpg cn=true]

[OnName num="yuuto"]
Just looking at him was unbearably painful.
[cpg cn=true]

I thought to myself as I was saying it, ah, I'm being selfish.
[cpg]

[FACE method="shake_3" pos="2/5"]
[VOICE f="sAyako016"]
[OnName num="ayako"]
Then promise me you won't see Chika again.
[cpg cn=true]

That's ......, that's ......
[cpg]

[OnName num="yuuto"]
......."
[cpg cn=true]

I couldn't answer. Immediately, the words did not come out.
[cpg]

I couldn't let go of Chinatsu-san. I've gotten into her that much.
[cpg]

It seemed that I was the only one who had reached the point of no return.
[cpg]

I was the only one who had gone crazy.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『洞窟へ続く道』（夜）******************************************************

After the day's demon exorcism, we were about to leave the cave.
[cpg]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Chinatsu153"]
[OnName num="chinatsu"]
I said, "...... Yuto, are you all right?　You look pale."
[cpg cn=true]

Chinatsu was worried about me. Of course, she must have looked pale.
[cpg]

[OnName num="yuuto"]
I'm fine.
[cpg cn=true]

Still, I just said okay. Because I couldn't say it wasn't okay and then worry about it again.
[cpg]

[FACE method="bow_7" pos="2/5"]
[VOICE f="Ayako522"]
[OnName num="ayako"]
"......Hey, Mr. Yuto. Are you going to keep repeating these things?"
[cpg cn=true]

[OnName num="yuuto"]
No,...... I don't want to. I can't endure this kind of thing over and over again."
[cpg cn=true]

I may look like a spoiled child. Still, I said, "If you didn't want me to do this, I wouldn't have done it.
[cpg]

[FACE method="shake_3" pos="2/5"]
[VOICE f="Ayako523"]
[OnName num="ayako"]
If you don't want me to do this,......, then you need to cut your ties with Chinatsu.
[cpg cn=true]

[FACE method="change_4" pos="4/5"]

I declared this in front of her, in front of my eyes. Chinatsu-san's face fell.
[cpg]

But this does not mean that Chika-san and Ayako are getting nasty or anything like that.
[cpg]

It's not a battle of the women or anything like that. It's all my fault.
[cpg]

It's all my fault. ...... I knew it was all my fault, my either/or attitude.
[cpg]

[FACE method="bow_3" pos="2/5"]
[VOICE f="Ayako524"]
[OnName num="ayako"]
I'm going home first then. I'd like to hear from you in the morning, if that's okay.
[cpg cn=true]

[OnName num="yuuto"]
"Oh, wait a minute."
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』

[FO pos="2/5" time=1000]

And Ayako leaves early. I and Chinatsu were left behind.
[cpg]

[OnName num="yuuto"]
I said, "......, you didn't have to leave so quickly."
[cpg cn=true]

[free time=300]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

Chinatsu-san is staring at me. Her gaze pierces me painfully.
[cpg]

[free time=300]
[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu154"]
[OnName num="chinatsu"]
She said she would help me, didn't she?"
[cpg cn=true]

I am puzzled by the confirmation of the fact. Surely, I said so.
[cpg]

[OnName num="yuuto"]
I say, "......Yes."
[cpg cn=true]

[OnName num="yuuto"]
I'm still with you. Even now, we are the same.
[cpg cn=true]

Then, Chika continued to say.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Chinatsu155"]
[OnName num="chinatsu"]
I don't care what happens to Ayako-san," he said. Please take me out of this village.
[cpg cn=true]

[OnName num="yuuto"]
But, I can't lose Ayako. ...... No, Chinatsu-san is important, but..."
[cpg cn=true]

It's no good. This is not good enough. I know it, but I can't stop.
[cpg]

I give an indecisive reply. I know it's not good for me.
[cpg]

I can't have it both ways. It's obvious to everyone.
[cpg]

But I don't know what else to say. I care about both Ayako and Chinatsu.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Chinatsu156"]
[OnName num="chinatsu"]
"...... I see. Is that the kind of person you are, Yuto?"
[cpg cn=true]

He looked at me with contempt, I felt.
[cpg]

And I thought, maybe I'm doing something that should be looked at that way.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

After that, Chinatsu-san also left the place.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

When I returned home, Ayako was sleeping. That alone was enough to reassure me.
[cpg]

Should I protect this family after all?
[cpg]

Or should I save one unfortunate woman? I don't know.
[cpg]

I slept in my bedroom, and the night passed.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_nh"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako525"]
[OnName num="ayako"]
I wondered if he had thought about ......'s reply. Mr. Yuto."
[cpg cn=true]

I had breakfast in front of me, but I didn't touch it. With an empty stomach, the two of us talk.
[cpg]

[OnName num="yuuto"]
Oh, yeah, I know, I know. I know, um, ......."
[cpg cn=true]

I choose my words. I'm sure I've thought of a lot of things, but they don't come out right away.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Ayako526"]
[OnName num="ayako"]
I'll wait, so there's no rush. I'll wait, so don't be in a hurry."
[cpg cn=true]

[OnName num="yuuto"]
I want to help ...... Chika-san.
[cpg cn=true]

[OnName num="yuuto"]
I took pity on Chika-san, and I wanted to help her, and I still feel the same way."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

Ayako stopped, staring at me.
[cpg]

He listens to my words with a near expressionless face, silently.
[cpg]

I think her face is a little more angry than expressionless. I can't tell what it is.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako527"]
[OnName num="ayako"]
I can't tell what she looks like. So?
[cpg cn=true]

[OnName num="yuuto"]
I don't want to neglect Ayako, even so.
[cpg cn=true]

[OnName num="yuuto"]
I care about Ayako, too. This is true, believe me.
[cpg cn=true]

Ayako cut in this time, saying, "Yes.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako528"]
[OnName num="ayako"]
So ...... what are you going to do?　I want you to cut off your hands with Chinatsu.
[cpg cn=true]

Ayako is important too. I want to help Chinatsu-san.
[cpg]

I can't do both at the same time. I was at a loss for words.
[cpg]

[OnName num="yuuto"]
I couldn't reply.
[cpg cn=true]

I couldn't reply. After all, it seems I was just trying to figure out how to get along with the two of them.
[cpg]

It seems that I just want to own ...... both of them at the same time.
[cpg]

I feel sorry for myself, I can't help it, but I'm sure that's what I'm really like.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako529"]
[OnName num="ayako"]
"......I really can't help it, how did this situation ...... end up like this?"
[cpg cn=true]

It's my fault, I'm sorry. It's not something that can be managed by saying, "I'm sorry.
[cpg]

From that point on, there was little conversation at the dinner table. There was only silence, and I felt crushed.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************

And then, after work, night falls. ......
[cpg]

Ayako had eyes that held determination. I don't even need to imagine what I'm going to do now.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayako530"]
[OnName num="ayako"]
I'm going to go and exorcise the demons, then. Okay?"
[cpg cn=true]

I know. I know that, but when you say it again, it's ......
[cpg]

It's a heart wrenching word. They are relentless, and they are directed at me.
[cpg]

[OnName num="yuuto"]
"No, don't do that,......, that's enough.
[cpg cn=true]

[OnName num="yuuto"]
I'm sorry ...... for what I've done, so just stop it."
[cpg cn=true]

I know that being sorry is not enough. I know.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayako531"]
[OnName num="ayako"]
It's my decision, isn't it?　It's not your decision."
[cpg cn=true]

That's right. I asked him to stop, but it won't change anything.
[cpg]

I can't stop him. Then, at least.
[cpg]

[OnName num="yuuto"]
Then ...... at least let me go with you, that's fine.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayako532"]
[OnName num="ayako"]
You can ...... do whatever you want."
[cpg cn=true]

Ayako said so as if she was going to spit it out.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟へ続く道』（夜）******************************************************

They walked down the path to the cave. As expected, there was little conversation.
[cpg]

At this rate, we're going to be separated. I have a feeling that we are about to be separated from each other.
[cpg]

But I don't know how I can hold Ayako together either.
[cpg]

I don't know what else I can do but to give up on Chinatsu-san. But I can't do that either. ......
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayako533"]
[OnName num="ayako"]
"...... hey, you. How much do you care about ...... me?"
[cpg cn=true]

How much? That's exactly what I can't express in words.
[cpg]

[OnName num="yuuto"]
"I care about you more than anyone else,...... and that's true.
[cpg cn=true]

[OnName num="yuuto"]
But,...... I don't care about Chinatsu-san,.......
[cpg cn=true]

[OnName num="yuuto"]
I'm not asking you to understand, but I can't help feeling pity for Chika-san,.......
[cpg cn=true]

Sigh, sighs Ayako. That's right.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Ayako534"]
[OnName num="ayako"]
We're a couple, aren't we?　Why don't you think this is funny?"
[cpg cn=true]

Yes, I'm crazy. I do think it's strange.
[cpg]

Ayako is right in her argument. There is no escape for me.
[cpg]

I can't stop thinking I'm crazy, and as a result, I'm trapped, and I'm blaming others for it.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayako535"]
[OnName num="ayako"]
Or maybe we shouldn't have been a couple in the first place?"
[cpg cn=true]


;//移植のためシーンをカットしています
;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Words I don't want to hear. And what I don't want to happen happens even more.
[cpg]

The demon exorcism was taking place again today. There, Chinatsu was ......
[cpg]

I was with Masuda.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟』（夜）******************************************************

I felt like my body was moving, like I was in kinbaku.
[cpg]

My body moved. If I jumped at her now, I could pull her away from Masuda.
[cpg]

If I do it now, I can still get Chinatsu back. That's what I felt.
[cpg]

If it's still not too late ......, I can't do nothing!
[cpg]

I rallied myself with a loud voice.
[cpg]

I know in my head. This is just a ritual.
[cpg]

[FO pos="4/7" time=1000]

[OnName num="yuuto"]
Let go of Chinatsu-san, let go of Chinatsu-san!
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

I still head for Masuda's place and try to jump on him.
[cpg]

[OnName num="masuda"]
He said, "What the hell?　You're still here?"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Chinatsu174"]
[OnName num="chinatsu"]
Huh? !"　Yuto-san ......!
[cpg cn=true]

I jumped at him and tried to pull him off, but I was held down by another man.
[cpg]

He held me to the ground as it was, and I couldn't move.
[cpg]

I see, these men are in charge of getting rid of anyone who gets in the way of this ritual.
[cpg]

[FACE method="change_7" pos="2/3"]

[OnName num="man"]
"Be quiet," he said. Do not interfere with the sacred ceremony.
[cpg cn=true]

I could not remain silent when I was told to be quiet. I asked Chinatsu-san.
[cpg]

[OnName num="yuuto"]
You said I would save you, Chinatsu-san!
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

Chinatsu-san looked sad. Then, she replied to my words.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Chinatsu175"]
[OnName num="chinatsu"]
I understood that Yuto-san would not be able to help me after all. So, I'm fine now."
[cpg cn=true]

I can't believe you're okay. ...... So you're saying you're going to be the lover of someone you don't like in this village for the rest of your life?
[cpg]

I don't like that, and I've been Chika's partner until now.
[cpg]

[OnName num="yuuto"]
I'm not going to do that!　I'll help you out!
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Chinatsu176"]
[OnName num="chinatsu"]
You don't have to worry about me anymore.
[cpg cn=true]

The distance between us is getting further and further apart. The distance between the heart and the mind is growing.
[cpg]

[OnName num="yuuto"]
"Oh no,...... I'm serious,...... about you."
[cpg cn=true]

And it's not just Chinatsu whose hearts are growing distant from her.
[cpg]

I could see Ayako becoming discouraged by my words. But I couldn't help but say something.
[cpg]

Even if I would lose both of them, I wanted to get both of them. ......
[cpg]

;//移植のためシーンをカットしています
[free time=300]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

Then Ayako said to me, "I'm not sure I'm going to be able to do this. It was a single word, as if she was confirming something to me.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako536"]
[OnName num="ayako"]
"Are you ...... okay with any woman?"
[cpg cn=true]

The words hit me right at the heart of the matter. I immediately wanted to say no, but then I thought, "Well, think about it.
[cpg]

Think about it. What kind of actions have I taken?　Can you deny it with your chest out?
[cpg]

[OnName num="yuuto"]
"......, that's not what ...... means."
[cpg cn=true]

And I couldn't deny it properly.
[cpg]

What have I been doing that might make you think so? Have I become that kind of man?
[cpg]

And you didn't realize that until just now.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Ayako537"]
[OnName num="ayako"]
Which is more important, me or Chinatsu-san?　Are they both important to you?"
[cpg cn=true]

[OnName num="yuuto"]
"I'm not talking about ...... importance or anything like that.
[cpg cn=true]

[OnName num="yuuto"]
"It's just that ...... we both love each other, although our vectors are different, or ......
[cpg cn=true]

A series of words that were not well-spoken. This is not good enough.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayako538"]
[OnName num="ayako"]
"You know what I mean, don't you, Yuto? ...... what you're claiming."
[cpg cn=true]

And then Mr. Kawayama appeared. Had he been there all along, or had I just not noticed him?
[cpg]

[OnName num="kawayama"]
He said, "Well, well, well. It's a sacred ceremony, there's no need to get so nasty.
[cpg cn=true]

[OnName num="kawayama"]
The point is to make it clear which is more important, isn't it?"
[cpg cn=true]

Mr. Kawayama spoke to me, as if he was interceding or something.
[cpg]

[OnName num="yuuto"]
I'm sorry for my half-hearted attitude until now,...... Chinatsu-san,.......
[cpg cn=true]

[free time=300]
[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="4/5" time=800]

[OnName num="yuuto"]
I like you. I still want to help you out.
[cpg cn=true]

[OnName num="yuuto"]
So will you ...... answer me, Chinatsu?
[cpg cn=true]

[FACE method="shock_5" pos="4/5"]
[VOICE f="Chinatsu196"]
[OnName num="chinatsu"]
"Then, will you love me, Yuto-san? ......
[cpg cn=true]

My response here would make all the difference. Knowing this, I nodded my head.
[cpg]

[OnName num="yuuto"]
"...... yes."
[cpg cn=true]

Ayako had a look of disbelief on her face.
[cpg]

[FACE method="shake_3" pos="2/5"]
[VOICE f="Ayako539"]
[OnName num="ayako"]
She said, "Oh no,......, are you insane?"
[cpg cn=true]

If you ask me if I'm insane, I don't think I am. But I had no choice.
[cpg]

[OnName num="yuuto"]
I'm sorry, Ayako. But I can't help it.
[cpg cn=true]

I have no choice but to apologize. I'm sorry, but I can't change my mind.
[cpg]

[FACE method="change_7" pos="2/5"]
[VOICE f="Ayako540"]
[OnName num="ayako"]
I've always loved you, I've always loved you.
[cpg cn=true]

That's why I'm apologizing. What more do you want from me?
[cpg]

[OnName num="yuuto"]
I said I'm sorry ...... and I still love you.
[cpg cn=true]

[OnName num="yuuto"]
I really love you. You can't have both, so ......
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[VOICE f="Ayako541"]
[OnName num="ayako"]
"This is too much, ...... I, I ......
[cpg cn=true]

No amount of words would get through to Ayako. And I am sure I am speaking on a technicality.
[cpg]

[FO pos="2/5" time=1000]

[VOICE f="Ayako542"]
[OnName num="ayako"]
"Ughhhh, ahhhhh..." Ayako breaks down in tears.
[cpg cn=true]

Ayako breaks down in tears. While holding a strong sense of guilt, ......
[cpg]

;//========================================
;//●ＣＧエロ（主人公がヒロインに近づく）ev_31
;//人物１：ヒロイン２
;//服装１：白装束
;//人物２：主人公
;//服装２：白装束（鬼の面をつけている）
;//場所　：洞窟
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_31_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

I approached Chika.
[cpg]

I couldn't stop myself, knowing that this would determine everything.
[cpg]

What kind of end result is waiting for me? I think I know what the outcome will be.
[cpg]

[VOICE f="sChinatsu006"]
[OnName num="chinatsu"]
"Yuto, Ms. ......."
[cpg cn=true]

I was so happy to hear her call my name, that was all I needed.
[cpg]

;//移植のためシーンをカットしています
;//綾子に視点切り替わり
;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『洞窟』（夜）******************************************************


[VOICE f="Ayako562"]
[OnName num="ayako"]
"I believed in you,......, Yuto, and I wanted you,......."
[cpg cn=true]

[OnName num="yuuto"]
"......"
[cpg cn=true]

Mr. Yuto does not look at me. He does not even look at me, even though he looks apologetic.
[cpg]

I will never go back to this person. I thought so.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（夜）******************************************************

After the exorcism, Yuto and I walked home together on the same street.
[cpg]

It was only natural, since we were going back to the same house. There is no reason beyond that.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayako563"]
[OnName num="ayako"]
Hey, you are ......."
[cpg cn=true]

I spoke to him. There was no response.
[cpg]

[OnName num="yuuto"]
"......."
[cpg cn=true]

Yuto is just looking straight ahead. It's more than that he has determination in his heart.
[cpg]

I felt that he was sorry and couldn't look at me. I felt like that.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako564"]
[OnName num="ayako"]
Did you really fall in love with Chinatsu?"
[cpg cn=true]

I asked her again what she was most concerned about. I already know the answer to that question.
[cpg]

[OnName num="yuuto"]
"......Ah."
[cpg cn=true]

I knew it. I wonder if Yuto knows what he is talking about.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayako565"]
[OnName num="ayako"]
You just came to this village, didn't you?　Did you fall in love with me just because you wanted to help me?"
[cpg cn=true]

I asked him deeply. Then, Yuto said, "I don't know,
[cpg]

[OnName num="yuuto"]
I don't know. ......
[cpg cn=true]

I don't know," he said. He said he didn't know why he left his wife.
[cpg]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Ayako566"]
[OnName num="ayako"]
Was that the extent of your love for me, too,......?"
[cpg cn=true]

[OnName num="yuuto"]
......."
[cpg cn=true]

He didn't even respond to the last question. It's like he didn't reply to anything else either.
[cpg]

I decided not to say anything else either, thinking that there was no point in asking any more questions.
[cpg]

Yuto was walking next to me in silence.
[cpg]

It was a night in the countryside, and the silence seemed to melt everything away.
[cpg]

;//悠斗に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************

I couldn't answer any of Ayako's questions yesterday.
[cpg]

She makes me breakfast. So I guess it's not quite the end of the day yet.
[cpg]

However, even after breakfast, there is no conversation. We are on the verge of a breakdown, and the only thing that hasn't broken down is ......
[cpg]

It's because we have reasons for each other. Me and Ayako have different reasons.
[cpg]

Ayako wants to live in the countryside. This is something she has been saying for a while.
[cpg]

And I, on the other hand, want to live in this village where Chinatsu lives.
[cpg]

Each of us has to stay in this village for different reasons.
[cpg]

In other words, we no longer have any reason to live in the same house.
[cpg]

There is no reason for us to see each other in this house.
[cpg]

Even if we sit around the same dinner table, it's just awkward. ......
[cpg]

[SE f="se019"]
;//【ＳＥ】『扉開く』

[window target=false]
[free time=1000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（昼）******************************************************

When I left the house, I said, "Well, I'm off.
[cpg]

[OnName num="yuuto"]
I'm off then.
[cpg cn=true]

To such words, there was a reply. Surprisingly, there was a reply.
[cpg]

;//[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ayako567"]
[OnName num="ayako"]
"......Go ahead and do whatever you want......."
[cpg cn=true]

But this was not a reply. Still, is it better than no reply at all?
[cpg]

In any case, our relationship had cooled off. It was only natural.
[cpg]

;//【ＳＥ】『扉閉まる』

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

I couldn't get any work done during the day. I didn't know what kind of face to show Ayako when I got home.
[cpg]

Even though it was all my fault and I was the cause of everything, I couldn't stop thinking about it.
[cpg]

When I get back home, everything will be resolved for some reason. I hope for that.
[cpg]

It's impossible.
[cpg]

I'm still imagining dreamy things. For example, ......
[cpg]

Take Chinatsu out of the village and live with Ayako?
[cpg]

That's impossible. What am I thinking in these monogamous times?
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『扉開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_zh"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************

[OnName num="yuuto"]
"I'm home. ...... Huh?"
[cpg cn=true]

When I returned home, I found an unexpected person.
[cpg]

Quite unexpected. I was sure that he was someone who should not be here, or rather, someone Ayako would not have called.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu215"]
[OnName num="chinatsu"]
"Hello, hello, ......, I'm sorry to bother you."
[cpg cn=true]

Chinatsu-san was there, looking uncomfortable. I didn't understand Ayako's intention.
[cpg]

But she must have been thinking about something. I asked Ayako about it.
[cpg]

[OnName num="yuuto"]
I asked Ayako, "...... what do you mean, Ayako?
[cpg cn=true]

[free time=300]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]

[VOICE f="Ayako568"]
[OnName num="ayako"]
Oh, Chinatsu," he said. I called her."
[cpg cn=true]

Ayako says so. The mystery deepens.
[cpg]

[OnName num="yuuto"]
I can sort of understand that," she says. You're the only one who's been around while I've been gone.
[cpg cn=true]

[OnName num="yuuto"]
But why?　There's no reason for me to call you.
[cpg cn=true]

Ayako seemed quite upset. Maybe she doesn't even know what she is doing anymore.
[cpg]

[FACE method="bow_4" pos="2/5"]
[VOICE f="sAyako017"]
[OnName num="ayako"]
'Yuto, you can kiss me here or whatever you want ......
[cpg cn=true]

[OnName num="yuuto"]
'...... wait. Aren't you getting desperate?"
[cpg cn=true]

[FACE method="shake_7" pos="2/5"]
[VOICE f="sAyako018"]
[OnName num="ayako"]
I'm going to go visit someone else. Is that all right with you?
[cpg cn=true]

[OnName num="yuuto"]
Why are you saying such a thing ......?
[cpg cn=true]

[OnName num="yuuto"]
Ayako has no reason to go to someone else, ......!
[cpg cn=true]

Ayako's expression faded. Then, with a sigh, she said
[cpg]

[FACE method="shake_4" pos="2/5"]
[VOICE f="Ayako571"]
[OnName num="ayako"]
"......At least I'll have my revenge. ......I haven't been able to sort out my feelings myself."
[cpg cn=true]

[OnName num="yuuto"]
If you're not so organized,......, you're not so organized,......," she said.
[cpg cn=true]

[OnName num="yuuto"]
If you can't sort it out, then don't do anything about it."
[cpg cn=true]

Ayako shakes her head. She seems to have made up her mind.
[cpg]

[FACE method="bow_4" pos="2/5"]
[VOICE f="Ayako572"]
[OnName num="ayako"]
Maybe she still wants you to look back on her. ......
[cpg cn=true]

[OnName num="yuuto"]
'......Don't say such a thing. Don't embarrass me."
[cpg cn=true]

Chinatsu-san is silently listening to this conversation. I wonder how she feels about it.
[cpg]

Then, Ayako puts on her shoes at the entrance. Then she turns back to me.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/5" time=800]
[VOICE f="Ayako573"]
[OnName num="ayako"]
Then, she looks back at me and says, "Well then, ...... goodbye."
[cpg cn=true]

[FO pos="2/5" time=1000]
Goodbye. Ayako leaves the house, leaving behind a few clichéd parting words.
[cpg]

I couldn't chase after her. I don't think I'll be able to do anything by chasing after her.
[cpg]

[OnName num="yuuto"]
"......Ayako......I see, so this is goodbye, huh?"
[cpg cn=true]

I was feeling like my heart was about to burst, but I also thought that I could bear it if Chika was there.
[cpg]

I look back at Chinatsu. She smiled a little and said
[cpg]

[free time=300]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chinatsu216"]
[OnName num="chinatsu"]
We are alone, aren't we? ......
[cpg cn=true]

I was saved by that smile. I tried to think that I was being saved.
[cpg]

[OnName num="yuuto"]
Yes, it is.
[cpg cn=true]

My heart is still in my chest. But I decide not to care.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Chinatsu217"]
[OnName num="chinatsu"]
Have you given up on Ayako-san?
[cpg cn=true]

I must not be at a loss for words here. The only thing that Chinatsu-san is seeking is love.
[cpg]

[OnName num="yuuto"]
......Yes."
[cpg cn=true]


;//綾子に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_nh"]
[WAIT time=100]
;//【ＢＧ】『村』（夜）******************************************************

I walked down the street at night, crying.
[cpg]

There's not that many places to go. Definitely not someone who can comfort me.
[cpg]

I was going to Kawayama-san's place. He would comfort me.
[cpg]

[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=1500]
[SE f="se019"]
;//【ＳＥ】『扉開く』

I rang the chime and Kawayama-san answered the door.
[cpg]

[OnName num="kawayama"]
What can I do for you, at this late hour of the night?
[cpg cn=true]

I told him everything without concealment. I told him the whole story.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sAyako019"]
[OnName num="ayako"]
I told him everything about ...... and how it all ended.
[cpg cn=true]

;//========================================
;//●ＣＧエロ（泣き崩れるヒロイン）ev_33
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：村長
;//服装２：裸
;//場所　：村長の家・寝室
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//移植のためシーンをカットしています

I've built up a lot of things. I have shared too much time with him.
[cpg]

It's painful. I feel like my heart is going to be torn apart.
[cpg]

I have the feeling that my body is about to be split in two.
[cpg]

The feeling of hating Yuto and the feeling of loving Yuto are tearing me ...... apart.
[cpg]

No, this isn't a metaphor or anything.
[cpg]

I really wish that my body, as it is, would tear itself apart.
[cpg]

If there was a me who could be swept away to one side or the other, I would like to be that person.
[cpg]

;//移植のためシーンをカットしています

;//ＢＫ
;//悠斗に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_zh"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************


After being with Chinatsu day after day, I had my doubts boiling over.
[cpg]

Is this what I want? Was this really what I wanted?
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Chinatsu220"]
[OnName num="chinatsu"]
I was wondering if this is really what I wanted.　Is there something on your mind?"
[cpg cn=true]

If I said something like this, Chinatsu would become disillusioned again.
[cpg]

[OnName num="yuuto"]
After all, I'll go look for Ayako.
[cpg cn=true]

Still, I said it. I am that kind of person after all, it seems.
[cpg]

I just can't hold back. I can't help but wonder how Ayako is doing.
[cpg]

I can't help but wonder who Ayako is with right now.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Chinatsu221"]
[OnName num="chinatsu"]
I'm like, "...... wait a minute. After all, don't you care about me?"
[cpg cn=true]

Chinatsu-san says something plausible. It's no wonder she thinks so.
[cpg]

[OnName num="yuuto"]
'I don't care about you, ...... you're my wife, I'm just worried about you.'
[cpg cn=true]

I somehow try to justify seeking out Ayako without disillusioning Chika as well.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Chinatsu222"]
[OnName num="chinatsu"]
I'm like a wife to you right now. Can't I be your wife?"
[cpg cn=true]

That's true. That's right, but I can't.
[cpg]

I can't choose one or the other, even though it's obvious.
[cpg]

I thought many times that both are important. And I still think so.
[cpg]

[SE f="se019"]
;//【ＳＥ】『扉開く』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[OnName num="yuuto"]
Anyway, I'm off. ...... Chinatsu-san."
[cpg cn=true]

I shook off Chinatsu-san's attempts to stop me and ran out.
[cpg]

[SE f="se012"]
;//【ＳＥ】『走る』

No longer really knowing what I was doing, I started running.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[FACE method="change_4" pos="2/3"]
[VOICE f="Chinatsu223"]
[OnName num="chinatsu"]
I ran to the door, "...... that person ......."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Chinatsu224"]
[OnName num="chinatsu"]
"That person, if it's a woman, can it be anyone ......?"
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se012"]
;//【ＳＥ】『走る』

[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（夜）******************************************************

[OnName num="yuuto"]
"...... hah, hah."
[cpg cn=true]

I looked for Ayako. I looked all over the village. I was running and gasping for breath.
[cpg]

I'm sorry Chinatsu, but I still have to get Ayako back.
[cpg]

I've been sharing time with her for a long time. I couldn't just end it like this.
[cpg]

I searched for her, but I couldn't find her at ...... Kawayama's house. I couldn't find her at Masuda's house either.
[cpg]

[OnName num="yuuto"]
...... Where are you, Ayako?"
[cpg cn=true]

No, she's just hiding. Should I go to their house one more time?
[cpg]

If it's someone completely different, there's no way to deal with it. What should I do then? ......
[cpg]

Or if they're not at someone else's place at all, or ...... the cave in the example.
[cpg]

I wonder if the demon exorcism is still going on.
[cpg]

[SE f="se012"]
;//【ＳＥ】『走る』

[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟へ続く道』（夜）******************************************************

We headed toward the cave. It has already been quite some time.
[cpg]

Kawayama-san and Masuda-san might be here.
[cpg]

It was almost midnight, and I was heading for the cave.
[cpg]

And in the cave, there was an unexpected person.
[cpg]

;//========================================
;//●ＣＧエロ（別の男に迫っているヒロイン）ev_35
;//人物１：ヒロイン２
;//服装１：白装束
;//人物２：間男
;//服装２：白装束（鬼の面をつけている）
;//場所　：洞窟
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

Chinatsu-san was there with another guy.
[cpg]

This is going backwards ......, but I knew this was going to happen somewhere.
[cpg]

I can't hold on to her after all.
[cpg]

[VOICE f="sChinatsu007"]
[OnName num="chinatsu"]
She said, "...... Oh. You came."
[cpg cn=true]

;//移植のためシーンをカットしています
;//========================================
;//●ＣＧエロ（別の男に迫られるヒロイン）ev_36
;//人物１：ヒロイン２
;//服装１：白装束
;//人物２：間男
;//服装２：白装束（鬼の面をつけている）
;//場所　：洞窟
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//移植のためシーンをカットしています

[OnName num="yuuto"]
"Wait,...... I was seriously trying to help you."
[cpg cn=true]

There wasn't much else to say. I'm going to play all the cards I have.
[cpg]

[OnName num="yuuto"]
I wanted to take you out on the town and show you the outside world.
[cpg cn=true]

But when I think about it, all the words I could have said would have been ......
[cpg]

;//[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Chinatsu261"]
[OnName num="chinatsu"]
"I'm tired of hearing that, ......."
[cpg cn=true]

That's right. I've said it many times. And yet.
[cpg]

[OnName num="yuuto"]
"Even though I'm tired of hearing it, let me say it!　I love you.
[cpg cn=true]

I want to hold on to Chinatsu. I want to somehow restore the relationship.
[cpg]

;//[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Chinatsu262"]
[OnName num="chinatsu"]
I don't think there's anything more I can say to you. So."
[cpg cn=true]

Is it useless? Is it futile? Have I come to that point already?
[cpg]

Before you know it, you'll be so, so disliked ...... differently, you won't even like it.
[cpg]

;//[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Chinatsu263"]
[OnName num="chinatsu"]
I'm not even hated. I was really happy in the beginning."
[cpg cn=true]

It was rather painful to hear him say that he was happy in the beginning.
[cpg]

The first time you see a person, you know that you're not doing anything wrong. Where did I go astray?
[cpg]

Or was it too much for someone like me to carry in the first place?
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

......And then...
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************

I got into the routine of going to work in the morning without breakfast.
[cpg]

I don't think it's the right word to call it a routine. It's more like "I just can't help it.
[cpg]

It's hard to drive with a hungry stomach, but it can't be helped.
[cpg]

My usual pattern is to finish breakfast at a convenience store.
[cpg]

I just couldn't bring myself to sit around the table with Ayako in the morning.
[cpg]

[OnName num="yuuto"]
......"
[cpg cn=true]

Even now, I can't bring myself to sit face to face with Ayako.
[cpg]

Because, what kind of conversation should I have there?　After all, I had already betrayed her.
[cpg]

Ayako might think we are enemies. I don't think so.
[cpg]

[OnName num="yuuto"]
Well then, I'm off. ......
[cpg cn=true]

There is no resting place. No matter where I was, there was never a moment of peace.
[cpg]

I was just getting used to this house, ...... but it didn't matter.
[cpg]

I said, "I'm going to go," in a voice that sounded exhausted.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako616"]
[OnName num="ayako"]
Go on ...... and have a good day."
[cpg cn=true]

I headed to the office with Ayako's unenthusiastic "see you later" behind my back.
[cpg]

I wonder if I can really ...... do this kind of thing?
[cpg]

I'm worried that the quality of my work will suffer.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（昼）******************************************************

I'm sure Ayako and Chinatsu are with someone else while I'm working like this.
[cpg]

When I think about it, I can't even think about work.
[cpg]

I can't stand it. But I brought this on myself.
[cpg]

Who is to blame? It is not that I wish Masuda or Kawayama had not been there or anything like that.
[cpg]

I think it was all my fault. I made the wrong choice many times, and that was the end of it.
[cpg]

Or maybe it was a mistake not to choose. Maybe I didn't even choose anything.
[cpg]

Yes, somewhere along the way I could have said something that would have made everything all right, but I didn't. But I couldn't.
[cpg]

I couldn't come up with it. Or maybe I did, but I got greedy and wanted to have them both.
[cpg]

Either way, it was equally sinful. I am guilty of being stupid, but I am also guilty of being indecisive.
[cpg]

I am a sinner. I deserve to be punished. This is what I had to do.
[cpg]

This is the result of not getting what I wanted to get....... This is the result of wanting to get it.
[cpg]

If I didn't think so, I wouldn't be able to do it. If I think that it is an unreasonable treatment, I feel that I cannot endure it.
[cpg]

;//綾子に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_nh"]
[WAIT time=100]
;//【ＢＧ】『村』（昼）******************************************************

I don't know why we became good friends after that.
[cpg]

Yes, we became friends. If it were the other way around, I would understand.
[cpg]

I thought things were going to get nasty, but Chinatsu-san started talking to me.
[cpg]

I wonder what she said to me. She said something like, "It's hard for you too, Ayako-san.
[cpg]

We were both supposed to be in love with one man, but now we have become friends with similar feelings.
[cpg]

I should have been left alone after losing the person of Mr. Yuto, but I was not.
[cpg]

I had unexpectedly gained emotional support and managed to maintain a sense of normalcy.
[cpg]

Because Chinatsu-san is here, I can bear it. I have come to be able to think that much.
[cpg]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Chinatsu264"]
[OnName num="chinatsu"]
......Yuto, have you always been such an indecisive person?
[cpg cn=true]

Chinatsu-san asks me that. How was it?
[cpg]

I've been trying to remember. I think Yuto used to be like that,.......
[cpg]

I never thought I was that indecisive. Even though there were some things that seemed to be so.
[cpg]

I don't think he was that indecisive in the past. If I had known he was like this, I wouldn't have married him.
[cpg]

So maybe it was my fault for not seeing through it.
[cpg]

Regardless of whether it's because we're in the country or not, or whether we're paying the devil, someday, somewhere ......
[cpg]

I might have found a new love and weighed it against me.
[cpg]

[FACE method="bow_4" pos="2/5"]
[VOICE f="Ayako617"]
[OnName num="ayako"]
'Yes, I had that tendency, but I never thought it would ...... go this far.
[cpg cn=true]

[FACE method="bow_2" pos="4/5"]
[VOICE f="Chinatsu265"]
[OnName num="chinatsu"]
I guess we are kind of like each other now, aren't we?"
[cpg cn=true]

I replied, "Maybe we are. The tone of the voice was similar to a sigh.
[cpg]

In response to my words, Chinatsu-san continued to speak.
[cpg]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Chinatsu266"]
[OnName num="chinatsu"]
'We were both wanted at the same time, and we wanted one love ......
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[VOICE f="Chinatsu267"]
[OnName num="chinatsu"]
But that was not going to happen. We are on our way to exorcise the demons."
[cpg cn=true]

I feel kind of pathetic when I put it into words.
[cpg]

I guess both Chika and I just looked for a place where we could be satisfied because we were not satisfied in the end.
[cpg]

[FACE method="change_7" pos="2/5"]
But sadly, what Chinatsu-san is saying is completely true.
[cpg]

In the first place, it may be strange for me and Chinatsu-san to become friends.
[cpg]

It could be said that the love that was given only to me was taken by Chinatsu-san. ......
[cpg]

But I don't feel like hating Chinatsu-san at all. On the contrary.
[cpg]

Somehow, I feel sympathy for Chinatsu-san as well. We have become such a relationship.
[cpg]

[FACE method="bow_1" pos="2/5"]
[VOICE f="Ayako618"]
[OnName num="ayako"]
Yes, you're right. ......
[cpg cn=true]

I didn't, we didn't get the love we wanted.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="4/5" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_zh"]
[WAIT time=100]
;//【ＢＧ】『洞窟』（昼）******************************************************

At the cave, Kawayama-san and Masuda-san were already waiting for us.
[cpg]

They were going to put on the masks of demons. We had to change into white, too.
[cpg]

[OnName num="masuda"]
"Ah, here you are at last. Come on, come here.
[cpg cn=true]

Yes," said Chinatsu-san, heading for Masuda-san.
[cpg]

I wondered if Kawayama-san would be my partner. I thought to myself.
[cpg]

[OnName num="kawayama"]
I've been waiting for you. Shall we begin then?
[cpg cn=true]

This was also an attack on Yuto.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟』（夕方）******************************************************

[OnName num="masuda"]
The more I hear about this Yuto guy, the worse he sounds.
[cpg cn=true]

[OnName num="masuda"]
It may not be impossible to love two women seriously, but...
[cpg cn=true]

[OnName num="masuda"]
You were going to marry two women?　You know that's impossible.
[cpg cn=true]

[OnName num="kawayama"]
"That's absolutely right. You are not seeing the reality of the situation.
[cpg cn=true]

[OnName num="kawayama"]
If you had been physical from the beginning, like we were, you could have had them both.
[cpg cn=true]

Well, from the beginning, our relationship is established because of our physical relationship .......
[cpg]

Is that why I am getting along so well with Ms. Kawayama and Mr. Masuda? I just realized that.
[cpg]

And Chinatsu-san replies to their words.
[cpg]

[FACE method="bow_7" pos="4/5"]
[VOICE f="Chinatsu279"]
[OnName num="chinatsu"]
Yes,...... it is impossible for a single heart to be completely connected to more than one person of the opposite sex."
[cpg cn=true]

Yes, in general, that may be true. If you explain this situation to others, you may get such a response.
[cpg]

However, when it comes to Mr. Yuto, the problem goes beyond that.
[cpg]

Yuto does not have enough love and affection for both of them.
[cpg]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Ayako628"]
[OnName num="ayako"]
Even if he could ......, he's not strong enough."
[cpg cn=true]

I spat out with such feelings. Kawayama-san laughed again.
[cpg]

[OnName num="masuda"]
He laughed again, "Pfft, hahaha, you're right, that may be so."
[cpg cn=true]

Masuda-san also laughed. He must be amused by Yuto.
[cpg]

[OnName num="kawayama"]
Ayako-san says, "You say that too. Ha-ha-ha.
[cpg cn=true]

I may have said too much. But this is more of a comedy than a tragedy.
[cpg]

I may be a terrible woman, just as I am. Still, what I do at ......
[cpg]

What I do is not much different. What I say to him does not change.
[cpg]

I fall into pleasure, saying things that belittle the person I once loved.
[cpg]

Rather than falling away, I was returning to the place where I originally belonged.
[cpg]

I am sure that Chinatsu-san is the same way. ......
[cpg]

I am sure that Chinatsu-san is just returning to the place where she used to be.
[cpg]

Masuda-san and Kawayama-san helped her.
[cpg]

I think they are good people. At least, much better than Yuto.
[cpg]

Yuto is the only one who is not in this place. The man who should have loved us is gone.
[cpg]

Even now, I can easily remember his face and voice. But he is not here.
[cpg]

But I think it can't be helped now. ......
[cpg]

;//ＥＮＤ：ヒロイン２ルート・エンド

[SCENE id=10]

[jump storage="epend.ks" target="*start"]


;//==============================
