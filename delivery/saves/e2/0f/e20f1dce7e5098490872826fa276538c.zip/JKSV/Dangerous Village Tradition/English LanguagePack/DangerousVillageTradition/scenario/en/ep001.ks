
*start

;#################################################
*Ep001|New encounters in the village
;#################################################

[SCENE id=1]

;//悠斗に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_go"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿寝室』（朝）******************************************************

The next morning. I woke up very early in the morning.
[cpg]

I was tired yesterday, but I wondered if my rhythm of life had changed after coming to the countryside.
[cpg]

[VOICE f="Ayako067"]
[OnName num="ayako"]
"Soo. Soo. ......"
[cpg cn=true]

When I looked at Ayako sleeping next to me, her mouth was moving.
[cpg]

The first thing you need to do is to make sure that you have a good understanding of what you're doing.
[cpg]

Then she said something like this: ......
[cpg]

[VOICE f="Ayako068"]
[OnName num="ayako"]
'Nnnn......Yuto-san......
[cpg cn=true]

[OnName num="yuuto"]
He said, "Heh. I'm here."
[cpg cn=true]

I kiss her cheek as she is talking in her cute sleep.
[cpg]

She still doesn't wake up. Ayako seems to be sleeping soundly.
[cpg]

Well, what shall I do? There is no way to kill time in the countryside.
[cpg]

I would say that there is no way to kill time in the countryside, but I wonder if there is anything I can do.
[cpg]

[SE f="se019"]
;//【ＳＥ】『ドア開け』

[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（朝）******************************************************

I thought I might as well see what early morning in the countryside was like, so I walked toward the general store anyway.
[cpg]

Yes, in fact, there is a general store within a ten-minute walk from my house.
[cpg]

It is a good distance to kill time, but it is rare in such a rural area.
[cpg]

In such a closed village, there is a general store, albeit a rundown one.
[cpg]

When we first moved here together, I was surprised to see that ......
[cpg]

As expected, the shopkeepers at the general store were often elderly people. Or rather, most of them were.
[cpg]

I am now convinced that this is just how it is. I can imagine that the shop has been in business for generations.
[cpg]

Perhaps it is not profitable. Even so, there must be a meaning in continuing the business.
[cpg]

I imagine that the few children in this village probably go to this store to buy candy.
[cpg]

[OnName num="yuuto"]
I decided, "Yes, let's go to that store.
[cpg cn=true]

I decided and started walking.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

;//========================================
;//●ＣＧ非エロ（雑貨屋で、おどおどしながら接客するヒロイン）ev_07
;//人物１：ヒロイン２
;//服装１：私服
;//場所　：雑貨屋
;//時間　：朝
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


;//ここから、千夏の名前は？？？と伏せてください

As usual, the store was usually manned by an old man or an old woman.
[cpg]

But that day, the store keeper was different. She was a young woman.
[cpg]

Our eyes met, and I was struck by her beauty. She is quite beautiful.
[cpg]

[VOICE f="Chinatsu001"]
[OnName num="chinatsu"]
She said, "Yes, welcome to ......."
[cpg cn=true]

She bowed to me, saying, "Welcome.
[cpg]

[OnName num="yuuto"]
She bowed to me, saying, "......, thank you.
[cpg cn=true]

And I bowed back. Then I looked away.
[cpg]

[VOICE f="Chinatsu002"]
[OnName num="chinatsu"]
Well, please take your time and look around.
[cpg cn=true]

If I go to ...... and take my time, I'll be late for work.
[cpg]

I'm going to be late for work if I take my time," he said, "and there's not much to look at.
[cpg]

[OnName num="yuuto"]
"......"
[cpg cn=true]

[VOICE f="Chinatsu003"]
[OnName num="chinatsu"]
"......"
[cpg cn=true]

I have nothing to say. No, that's normal in a grocery store, or any store for that matter.
[cpg]

Me and the woman. We were both silent.
[cpg]

I felt awkward about it.
[cpg]

My silence was partly due to my surprise that such a pretty person could be found in such a village.
[cpg]

On top of that, I thought it would be strange for me, coming from the city, to talk to them, so I kept silent.
[cpg]

And the reason why they are silent is probably because they are not good at talking.
[cpg]

I may be prejudiced to think this in a situation where we haven't even talked that much yet, but ......
[cpg]

She seems somewhat frightened and doesn't seem to be suited for the customer service industry.
[cpg]

So, what should I do? I could have stayed silent, but....
[cpg]

I was going to just buy a can of coffee and go home, but then I thought about talking to her a little.
[cpg]

;//■選択肢
[switch]
[case "I'll talk to her."]
	[swap]
	[jump target="*select01_1"]
[case "I will not talk to her."]
	[swap]
	[jump target="*select01_2"]
[endswitch]

;//１、話しかけてみる
;//２、話しかけないでおく

;//==============================
;//１、話しかけてみる
;//（この選択の場合、【承】の選択肢に「千夏」が出現する）
*select01_1|New encounters in the village
[stflag f_Chinatsu = 1]

[OnName num="yuuto"]
"You are also from this village, aren't you?"
[cpg cn=true]

A casual topic of conversation. I mean, coming from the city, I have nothing else to say.
[cpg]

I don't think there is anything weird about it. I don't think I said anything strange.
[cpg]

[VOICE f="Chinatsu004"]
[OnName num="chinatsu"]
What?
[cpg cn=true]

But their reaction was bigger than I had imagined.
[cpg]

[OnName num="yuuto"]
"...... don't be so surprised ......"
[cpg cn=true]

I told him frankly what I thought. I told him frankly what I was thinking, and he became even more nervous.
[cpg]

[VOICE f="Chinatsu005"]
[OnName num="chinatsu"]
I was so surprised. Well, you are, you know..."
[cpg cn=true]

I wonder what this person is. I wonder if he is a little younger than me or the same age as me.
[cpg]

When I spoke to her, she was startled and began to look frightened.
[cpg]

She was so startled that I decided to explain to her why I was talking to her.
[cpg]

[OnName num="yuuto"]
I said, "Excuse me. I had an image of an elderly person as a clerk in this grocery store.
[cpg cn=true]

I simply told her that. I simply said that, without putting any emotion into it.
[cpg]

[VOICE f="Chinatsu006"]
[OnName num="chinatsu"]
I simply said, "No, no, ......, please come again.
[cpg cn=true]

Then he cut me off this time.
[cpg]

I tried to continue the conversation, but he said, "Please come again.
[cpg]

How could someone who is supposed to be a store keeper cut off a conversation with a customer? ......
[cpg]

I thought to myself, "There are people of this type even in the countryside.
[cpg]

I wonder if I, coming from the city, am a foreigner to this village. Maybe this kind of attitude is more natural.
[cpg]

[OnName num="yuuto"]
I haven't bought anything yet. Please give me this.
[cpg cn=true]

I picked up a canned coffee of my favorite brand. I was glad they had it here, too.
[cpg]

[VOICE f="Chinatsu007"]
[OnName num="chinatsu"]
"Well, yes, that will be 120 yen. ......
[cpg cn=true]

[OnName num="yuuto"]
"I think I have 120 yen ......."
[cpg cn=true]

I searched for change, though I was sure there was no way I could get change.
[cpg]

I handed over exactly 120 yen. The other party remained frightened the whole time, and our conversation was over.
[cpg]

[VOICE f="Chinatsu008"]
[OnName num="chinatsu"]
Thank you very much. ......
[cpg cn=true]

Even this last sentence was a little clumsy.
[cpg]

I wondered if he could live in the countryside with such a frightened appearance. ......
[cpg]

Or is he this nervous because it's me he's talking to?
[cpg]

[jump target="*select01_3"]
;//==============================
;//２、話しかけないでおく
*select01_2|New encounters in the village

Without talking to him, I decided to just buy a can of coffee and leave the general store.
[cpg]

I wonder how old this person is. I guessed he was a little younger than me or about the same age.
[cpg]

[VOICE f="Chinatsu009"]
[OnName num="chinatsu"]
Thank you very much for your purchase. ......
[cpg cn=true]

I don't think he was hired from somewhere.
[cpg]

I thought he was probably a resident of this village, so I just bailed him out lightly.
[cpg]

[OnName num="yuuto"]
"Thank you, ......."
[cpg cn=true]

Then, the person on the other side bowed at an angle about twice that. I wondered what was going on.
[cpg]

There are people like this in the countryside, I thought.
[cpg]

;//==============================
*select01_3|New Encounters in the Village

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『村』（朝・雨）******************************************************

[OnName num="yuuto"]
What was that ...... just now?
[cpg cn=true]

A drop of water hit my head. And then, "Oh, no, I don't think so,
[cpg]

[SE f="se041"]
;//【ＳＥ】『雨』

;// キャラクターの前面に雨を表示;// 通常
;//[create id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } }]

[BG f="b_03_5.ui" time=1000]
[WAIT time=2000]

After that, it rained suddenly.
[cpg]

[OnName num="yuuto"]
"This is really sudden. ......
[cpg cn=true]

I was on a street between a grocery store and a house, and I was thinking, what am I going to do ......
[cpg]

I remembered. There are places with roofs, even here in the country.
[cpg]

[OnName num="yuuto"]
Yes, there was a bus stop around here, I think ......
[cpg cn=true]

There was a bus stop. There was a roof over my head, so I decided to wait until it stopped.
[cpg]

;//前面に雨 停止
;//[create id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } }]

;//========================================
;//●ＣＧ非エロ（雨の中、ベンチに座りながら主人公を見上げるヒロイン）ev_08
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：バス停の屋根の下
;//時間　：朝
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//ここから、美咲の名前は？？？と伏せてください

;//[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
There was another person in front of me. It was a young woman.
[cpg]

It was the first time for me to meet young people in such a rural area.
[cpg]

[VOICE f="Misaki001"]
[OnName num="unknown"]
It's raining suddenly, isn't it? Don't you have an umbrella or something?
[cpg cn=true]

Unfortunately, I didn't have one. I left the house without my bag.
[cpg]

[OnName num="yuuto"]
Yes. ......."
[cpg cn=true]

The woman smiled at me and said, "I'm sorry, but I don't have an umbrella.
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Misaki002"]
[OnName num="unknown"]
In this area, it is rare to find a place with a roof over your head. A folding umbrella is a must.
[cpg cn=true]

She is a very friendly person, isn't she? Or rather, she was friendly.
[cpg]

A woman waiting for the bus at a bus stop. She suddenly spoke to me.
[cpg]

The way she smiled was completely different from Ayako's, of course. Her smile is somewhat unfriendly or too bright.
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki003"]
[OnName num="unknown"]
She said, "Well, there are some shady spots. There are insects this time of year.
[cpg cn=true]

[OnName num="yuuto"]
......Yes, that's true. It's spring, so maybe it's too much.
[cpg cn=true]

[VOICE f="Misaki004"]
[OnName num="unknown"]
But are you so unconcerned that you would move into a place like this?
[cpg cn=true]

[OnName num="yuuto"]
What?　Why ......?
[cpg cn=true]

I was a little surprised. How did you know I was moving in?
[cpg]

How did he know I was moving in?
[cpg]

[OnName num="yuuto"]
How did you ...... know I was moving in?"
[cpg cn=true]

It may be a stupid question, but I'm going to ask it.
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Misaki005"]
[OnName num="unknown"]
You are from the city, aren't you?　It's the talk of the village.
[cpg cn=true]

I knew it. In the countryside like this, word spreads fast.
[cpg]

[OnName num="yuuto"]
"Is that so? I guess it is a rumor after all. ......
[cpg cn=true]

I half mumbled, and the woman continued to talk to me.
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki006"]
[OnName num="unknown"]
How old are you?　I'm 22.
[cpg cn=true]

The woman kept talking to me one after another. I was embarrassed.
[cpg]

What does it matter how old I am? Is it so unusual for her to be a young person?
[cpg]

If I had lived in the countryside all my life, I might be, but somehow I don't think so.
[cpg]

[OnName num="yuuto"]
She says, "I'm ...... 25."
[cpg cn=true]

Oh," he says. Nothing, I suppose, would surprise me.
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Misaki007"]
[OnName num="unknown"]
You're close. So you don't mind if I talk to you as if you're my friend?　No, it's fine.
[cpg cn=true]

[OnName num="yuuto"]
"Ha, ha........., it's fine, though."
[cpg cn=true]

No, three away, I thought ......, and I was pulling away from the woman who was coming at me so hard.
[cpg]

;//ここから、美咲の名前を表示してください

;//[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki008"]
[OnName num="misaki"]
My name is Misaki. Toudou Misaki."
[cpg cn=true]

[OnName num="yuuto"]
"Uh, ...... is that right? Nice to meet you.
[cpg cn=true]

I said something casual. She started talking more and more.
[cpg]

[VOICE f="Misaki009"]
[OnName num="misaki"]
I'm from the city too. I'm from the city, too, and I'm here a little earlier than you are.
[cpg cn=true]

I wondered where the city was. I wondered, but when I told him, he replied, "I'm from the city.
[cpg]

I didn't want to tell him because I thought it would come back to me about ten times over.
[cpg]

[OnName num="yuuto"]
I didn't say anything. "...... I see. ......."
[cpg cn=true]

I was ashamed of myself. I was ashamed of myself, but all I could get out of my mouth was, "Oh, I see.
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misaki010"]
[OnName num="misaki"]
I've got a ritual I'm interested in ......, but the timing is a little off."
[cpg cn=true]

A ritual. Rituals," she said, "are a bit of a mystery to me. That's not a good thing to hear.
[cpg]

Even if it comes back tenfold, I'm curious, so I asked.
[cpg]

[OnName num="yuuto"]
Ritual?　What kind of ritual is a ritual?
[cpg cn=true]

[VOICE f="Misaki011"]
[OnName num="misaki"]
I guess I didn't do enough research. I've been here since last fall, haven't I?
[cpg cn=true]

But he didn't answer me about the content of the ritual.
[cpg]

He was a man of his own pace. I replied, a little taken aback.
[cpg]

[OnName num="yuuto"]
Haa...... is that so?"
[cpg cn=true]

The other side looked into my face. So close, so close.
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki012"]
[OnName num="misaki"]
I mean, you haven't told me your name yet. What's your name?
[cpg cn=true]

I was surprised that he would go that far. Well, he said his name on his own.
[cpg]

[OnName num="yuuto"]
I thought it was okay to ask him his name. It's our first meeting, right?
[cpg cn=true]

After some hesitation, I answered. He looked a little peeved.
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Misaki013"]
[OnName num="misaki"]
It's okay," he said, "we're just friends from the city who came to the countryside here. Tell me about it.
[cpg cn=true]

I don't know if I like the way he said "countryside. I can't speak for others either.
[cpg]

[OnName num="yuuto"]
I can't speak for others, but I can say this: "I'm Yuto Sumii from ....... Yuto Sumii.
[cpg cn=true]

I was pushed into saying my name. Then, Misaki said ......
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki014"]
[OnName num="misaki"]
I see. Then I will call you Yuto.
[cpg cn=true]

She decided to call me by my first name. He suddenly called me by my first name, and he also called me by my last name.
[cpg]

Even his wife, Ayako, calls him Yuto. It's beyond friendly.
[cpg]

You're familiar to me everywhere. ...... I thought about what I'm going to do now.
[cpg]

It's still raining outside on the roof, however.
[cpg]

;//■選択肢
[switch]
[case "I get out of the bus stop and run home."]
	[swap]
	[jump target="*select02_1"]
[case "Here I wait for the rain to stop."]
	[swap]
	[jump target="*select02_2"]
[endswitch]

;//１、バス停から出て、家まで走る
;//２、ここで雨が止むのを待つ

;//==============================
;//１、バス停から出て、家まで走る
*select02_1|New encounters in the village

[OnName num="yuuto"]
'Excuse me, I think I'll go back to my house now.
[cpg cn=true]

It doesn't matter that it's raining. It doesn't matter anymore.
[cpg]

;//[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misaki015"]
[OnName num="misaki"]
Let's talk some more. There are no young people in this village, so I'd like to make friends with you.
[cpg cn=true]

He was still talking to me in a friendly manner. I thought he might switch to polite if I started to pull away.
[cpg]

[OnName num="yuuto"]
No, I really have to head to ...... company.
[cpg cn=true]

This was true. I'm not lying, if I don't get going soon, I won't make it in time.
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki016"]
[OnName num="misaki"]
I'll lend you my umbrella, then?"
[cpg cn=true]

I'll lend you an umbrella," said Misaki, fumbling with her bag.
[cpg]

For a moment, I thought that might be a good idea, but no, not good.
[cpg]

If I borrowed it, I would have to return it.
[cpg]

If I did, I would have to return it, and then we would have to have another long conversation.
[cpg]

With that in mind, I did not accept the loan. I know I was making a very rude assumption about the person I was talking to. ......
[cpg]

But I think I was so familiar with them that I could have been forgiven for making that assumption.
[cpg]

[OnName num="yuuto"]
I said, "It's okay. It's okay. ......"
[cpg cn=true]

I leave Misaki there, who says, "Ehhh.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（朝・雨）******************************************************

[SE f="se012"]
;//【ＳＥ】『走る』
;//【ＳＥ】『雨の中走る』

I'm going back to the house as if to run away. It's raining, so it won't feel strange to run away.
[cpg]

If there was any discomfort, I don't know about it anymore. I don't want to get too involved with this guy.
[cpg]

...... And on the way, the rain stopped.
[cpg]

I got caught up in something strange, and in the end I didn't understand what the ritual was all about.
[cpg]


[jump target="*select02_3"]
;//==============================
;//２、ここで雨が止むのを待つ
(In this case, "Misaki" appears in the "Sei" option.
*select02_2|New encounters in the village

[stflag f_Misaki = 1]

;//[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Misaki017"]
[OnName num="misaki"]
I'm going to meet a new person in the village. It's rare to meet someone your own age in this village, isn't it?"
[cpg cn=true]

[OnName num="yuuto"]
(......) "We haven't met yet, have we? I'm older than you, and he is older than me.
[cpg cn=true]

I am older and she is younger. The tone of voice is reversed.
[cpg]

Still, I spoke in the same tone to encourage polite language over there.
[cpg]

And Misaki didn't care about that at all.
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misaki018"]
[OnName num="misaki"]
She said, "Hehehe. I'm happy too. You probably didn't come to this village alone, did you?
[cpg cn=true]

[OnName num="yuuto"]
Yes, well, ...... I did.
[cpg cn=true]

[OnName num="yuuto"]
I'm here with my wife. I think we will have a chance to meet sooner or later.
[cpg cn=true]

Misaki-san says, "Yes, that's right. Then he continued.
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Misaki019"]
[OnName num="misaki"]
'I'll be back to greet your wife again.
[cpg cn=true]

While we were talking like this, the rain stopped, and I went back to my house.
[cpg]

I took my time in a strange way.
[cpg]

;//==============================
*select02_3|New Encounters in the Village


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（朝）******************************************************

I had taken an unexpected road trip. Ayako might be looking for me, too.
[cpg]

If so, we would have gotten on the wrong side of each other. Fearing this, I ran.
[cpg]

[SE f="se012"]
;//【ＳＥ】『走る』

[window target=false]
[free time=1000]
[BG f="b_00_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ayako069"]
[OnName num="ayako"]
Oh, welcome back. What are you doing out at this hour?
[cpg cn=true]

Ayako looked at me with a slightly worried expression. If I made you worry, I am sorry.
[cpg]

[OnName num="yuuto"]
I'm sorry if I made you worry. I just went for a walk. I'm sorry for worrying you.
[cpg cn=true]

[OnName num="yuuto"]
I woke up at a strange hour. "I woke up at a weird time, so I went for a walk to pass the time."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako070"]
[OnName num="ayako"]
"Hmm. I'm glad you did, but don't worry too much about me.
[cpg cn=true]

[OnName num="yuuto"]
"It's ......, isn't it? You worry me. I'm sorry.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Ayako071"]
[OnName num="ayako"]
He's my one and only, dear husband. Breakfast is already ready.
[cpg cn=true]

Oh, right, breakfast wasn't ready either. But I don't have much time.
[cpg]

[OnName num="yuuto"]
No, breakfast is fine. If I eat it, I might be late for work.'
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

Ayako looked a little disappointed, but it couldn't be helped.
[cpg]

I felt sorry for her, but started to get ready to leave the house.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Ayako072"]
[OnName num="ayako"]
I started to get ready to leave the house, feeling sorry for myself. Well then, I guess I don't have a choice."
[cpg cn=true]

Oh, I'm sorry. I'm really sorry. But apologizing so many times makes me sound frivolous.
[cpg]

[OnName num="yuuto"]
I'm really sorry. I wish it hadn't rained on the way.
[cpg cn=true]

Still, the words of apology came out of my mouth. It was pathetic.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Ayako073"]
[OnName num="ayako"]
It's okay, I don't mind. Well then, have a good trip.
[cpg cn=true]

Ayako sent me off with a smile at the end. Just seeing her face was a relief.
[cpg]

[OnName num="yuuto"]
I'll see you later. I'll see you later.
[cpg cn=true]

I left the house.
[cpg]


[SE f="se019"]
;//【ＳＥ】『扉閉まる』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（朝）******************************************************

[SE f="se043"]
;//【ＳＥ】『車のエンジン音』

I felt bad for Ayako. I didn't mean to take so much time for my morning walk.
[cpg]

It's hard that it's not so much that I'm going to make it up to her again somewhere .......
[cpg]

It's just a small thing, and I'm sorry for the opposite. I was in such a mood.
[cpg]

[OnName num="yuuto"]
It was a strange morning, even so,.......
[cpg cn=true]

I had a feeling that I might have some kind of connection ...... with the two people I met today.
[cpg]

I didn't know the name of that person who was tending to the store, but I even knew the name of the other one.
[cpg]

Well, it was just a hunch, not a solid reason or confidence, but.
[cpg]

I had a feeling that I would have a strong connection with those two people somewhere .......
[cpg]

The first thing that comes to mind is the fact that the two of them have a very strong connection.
[cpg]

It's not that I had anything bad happen to me.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（昼）******************************************************

At the company, I will concentrate on my work. In the meantime, I wondered what Ayako was doing in the countryside.
[cpg]

Well, it's Ayako. I can imagine that she is probably working in the fields anyway. ......
[cpg]

Still, I worry about whether she is doing well in the countryside. Especially if she is getting along with the people around her.
[cpg]

I'm sure she's much better at socializing than I am, but I'm worried.
[cpg]

I wonder how they are doing now.　I wonder if Ayako will notice that I'm thinking about her.
[cpg]

Ah, Ayako. Today, too, I feel the urge to go home early.
[cpg]

;//綾子に視点切り替わり

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_go"]
[WAIT time=100]
;//【ＢＧ】『村』（昼）******************************************************

It's too bad Yuto didn't eat breakfast. But it can't be helped.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako074"]
[OnName num="ayako"]
"Phew. ......"
[cpg cn=true]

I was doing farm work in the field. I was doing some farming in the field, though it wasn't much more than farming.
[cpg]

But someday I would like to develop it into something that can be called farming.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayako075"]
[OnName num="ayako"]
"This one looks like it won't be harvested for a long time. ......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako076"]
[OnName num="ayako"]
"I wonder if this ...... looks edible. ......
[cpg cn=true]

I find myself judging things based on whether or not they look the same as what I see in the store.
[cpg]

I started a vegetable garden with complete amateur knowledge, but it didn't go well.
[cpg]

I was born in the city, so maybe the plants are rejecting me.
[cpg]

But I mustn't be so timid. I'm going to live in the countryside.
[cpg]

So, I have to get along with the plants as well. ...... It may be a long way to go.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Ayako077"]
[OnName num="ayako"]
No," he said. Someday, I'll become self-sufficient ...... and even become a farmer.
[cpg cn=true]

I try to express my determination when no one is listening.
[cpg]

I felt that putting it into words gave me courage. Ten years later, I imagine myself growing enough vegetables to ship.
[cpg]

[FACE method="shake_2" pos="2/3"]

......I would be laughed at if I told Yuto about this fantasy.
[cpg]

But even if I were to do chores at home, we don't have children between us yet. I have too much time to do only housework all day long.
[cpg]

I have to do some work, and when I look for a job, I can't find anything good at .......
[cpg]

I don't intend to think that it is because we are in the countryside.
[cpg]

The advantages of living in this village are greater than the lack of work, at least for me.
[cpg]

Besides, if you don't have a job, the best thing you can do is grow vegetables. There is never enough time to take care of the fields.
[cpg]

With this thought in mind, I start to weed the fields.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako078"]
[OnName num="ayako"]
Weeding is so tiring for my posture. ...... I wonder if that's why all country grannies have rounded backs."
[cpg cn=true]

When I am alone, I talk to myself more. And that's when I remembered, in an associative game way.
[cpg]

There was an old lady who brought me a portion of her food.
[cpg]

I have yet to give anything back to her. In the city, it might be okay if I did, but in the countryside, I don't think it would be so.
[cpg]

After all, not many people live there. I think I remember who gave me something and what I gave them.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Ayako079"]
[OnName num="ayako"]
I think you have to go and return something, after all. ......
[cpg cn=true]

So I packed some vegetables that I thought I could harvest into a plastic bag and decided to take them with me.
[cpg]

I'm glad I didn't cook them all. And I'm glad I sowed the ones I could harvest early.
[cpg]

Well, I try to remember where that guy lives ......, but I can't remember.
[cpg]

That's right. He came from the other side of the country, so it was no wonder I couldn't remember.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（昼）******************************************************

I was sure that his last name was Mr. Masuda. I searched for him, relying on the nameplate.
[cpg]

This kind of steady work was only possible because I had time. I'm sorry to Yuto, but....
[cpg]

I heard that in the countryside, there are many people with the same surname, but there was only one Masuda in this area.
[cpg]

[FACE method="change_1" pos="2/3"]

Maybe it's here. If I looked harder, I might be able to find it somewhere else, but I think I'll just have to make a mistake.
[cpg]

[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

When I rang the chime of the house I found, it was not the old lady who came out of the house.
[cpg]

[SE f="se002"]
;//【ＳＥ】『扉開く』

I was quite taken aback by what I had expected. The person who came out of the front door looked like ......
[cpg]

[OnName num="masuda"]
What?"　You want to see my mom?"
[cpg cn=true]

He was a flirtatious man who still looked young.
[cpg]

There are people like this in the countryside, or maybe there are.
[cpg]

Still, I had not assumed it to be a quirk and became a little suspicious of his behavior.
[cpg]

Mother, this man said. Well, sure enough, I was about the age of this person's mother. ......
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako080"]
[OnName num="ayako"]
Yes,......, um, are you there?"
[cpg cn=true]

I was a little stumped, but tried to get what I wanted out of him.
[cpg]

[OnName num="masuda"]
She said, "No, I'm not here. If you need something, I'll let you know.
[cpg cn=true]

He replied bluntly. I was starting to feel like leaving, but I had to tell her.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayako081"]
[OnName num="ayako"]
I wanted to return the favor for the vegetables I got the other day. ......
[cpg cn=true]

[OnName num="masuda"]
"Hmmm. Payback, huh, payback. Mother, you did that."
[cpg cn=true]

[OnName num="masuda"]
You're from the city, aren't you?
[cpg cn=true]

I respond with a smile even to those who are suddenly familiar with me.
[cpg]

I don't panic, I don't panic. I have to get along with this person, too.
[cpg]

I was a little surprised to know that there are people like this in the countryside.
[cpg]

But I am sure there are people like this everywhere. Then, we should not keep them away from us more than necessary.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Ayako082"]
[OnName num="ayako"]
"Yes, my name is Ayako Sumii. My name is Ayako Sumii. Um, you are .......
[cpg cn=true]

[OnName num="masuda"]
Oh, me?　I'm a freelancer living in this village.
[cpg cn=true]

[OnName num="masuda"]
In the countryside like this. I was having a hard time finding a cute girl.
[cpg cn=true]

There was no reply by name. Before I could answer, he started talking about cute girls.
[cpg]

He looked at me, staring at my body. I endured the uncomfortable stares.
[cpg]

I endure the uncomfortable stares and ...... move away just a little bit.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako083"]
[OnName num="ayako"]
"Oh,...... pretty girl, huh?"
[cpg cn=true]

[OnName num="masuda"]
"Yes, yes, sweetie. Someone like you."
[cpg cn=true]

You can take these lines as flattery. I don't mind, I don't mind.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayako084"]
[OnName num="ayako"]
...... such." Please accept my compliments."
[cpg cn=true]

[OnName num="masuda"]
I don't know what to do. I'll take it.
[cpg cn=true]

[OnName num="masuda"]
"You're going to leave after I give it to you, aren't you?　I don't want to do that.
[cpg cn=true]

Of course I'm leaving. There was no point in having a long conversation with someone who was not the person in question.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako085"]
[OnName num="ayako"]
Or should I ask you again?
[cpg cn=true]

[OnName num="masuda"]
Were you listening to me?　I said the opposite.
[cpg cn=true]

[OnName num="masuda"]
I said, "If you take it, the conversation is over. Let's talk a little longer.
[cpg cn=true]

Mr. Masuda was smiling, although his tone was a little strong.
[cpg]

Was he hitting on me? I was suspicious and tried to cut the conversation short.
[cpg]

I tried to end the conversation frankly, without being dexterous.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Ayako086"]
[OnName num="ayako"]
"Well, ...... if you're hitting on me, I have a husband, so ......
[cpg cn=true]

[OnName num="masuda"]
"Oh, I see. Oh, that's right, I'm sure. Yes.
[cpg cn=true]

[OnName num="masuda"]
Okay, I'll take that. I'll see you again.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

I said, "What? So easily?
[cpg]

[FACE method="change_7" pos="2/3"]

Masuda-san accepted the gift in return. I had expected her to press me for more, but the conversation ended unexpectedly easily. What was it all about?
[cpg]

[SE f="se002"]
;//【ＳＥ】『扉閉まる』

But I will have to think about when to return the gift to Mr. Masuda. ......
[cpg]

With these thoughts in mind, I walked home.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（昼）******************************************************


After returning to my house, I went back to work on the farm.
[cpg]

And gathering information about it. Even in such a rural area, I can connect to the Internet with a smartphone.
[cpg]

I thought to myself, "How convenient," as I looked up various things.
[cpg]

I can't just keep doing the same thing over and over again in the dark.
[cpg]

I need to learn more about vegetables, even if it's just a little bit at a time.
[cpg]

Yes, I haven't forgotten my dream of becoming a farmer someday.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayako087"]
[OnName num="ayako"]
I was thinking, "I wonder if it's not time to harvest that vegetable ...... yet. ......"
[cpg cn=true]

I checked and found that I was just a little bit wrong about the harvest time.
[cpg]

It wasn't the season, but rather, it was growing too late. But.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Ayako088"]
[OnName num="ayako"]
I think to myself, "No, they know I'm from the city, right?"
[cpg cn=true]

I think to myself, "No, they know I'm from the city.
[cpg]

But you can't imagine that a city dweller would suddenly be able to grow vegetables.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako089"]
[OnName num="ayako"]
Besides, that lady seemed like a nice person, ...... so I'm sure she'll be fine.
[cpg cn=true]

I thought about this earlier, that being alone makes me talk to myself more.
[cpg]

Of course, I'm talking to myself because I'm talking to myself. ......
[cpg]

Talking to myself is good for me to convince myself. I feel like I can sort out my situation.
[cpg]

For example, it might be a little dangerous if I start talking to vegetables.
[cpg]

;//悠斗に視点切り替わり

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（夕方）******************************************************

[SE f="se019"]
;//【ＳＥ】『扉開く』

After finishing work, I return home. Today, I was able to finish work a little early.
[cpg]

Ah, I'm tired again today. I opened the front door without saying, "I'm tired today.
[cpg]

[OnName num="yuuto"]
I don't see her at .......
[cpg cn=true]

Ayako was not in the living room. So, it's the field in the back.
[cpg]

I'm sure that's the first place she would be. There is no other place for her to be.
[cpg]

Or he could be talking to someone in the village,......, which is possible at this time of night.
[cpg]

Either way, it was outside. So I put my shoes back on.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（夕方）******************************************************

Sure enough, Ayako was in the field behind the house. She was wiping the sweat from her forehead.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ayako090"]
[OnName num="ayako"]
Ah, welcome home, dear. "Oh, you.
[cpg cn=true]

I replied, relieved that my beloved was there.
[cpg]

[OnName num="yuuto"]
I'm home, Ayako. How was your day?
[cpg cn=true]

[OnName num="yuuto"]
Tell me if there's anything unusual.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayako091"]
[OnName num="ayako"]
Today, I brought you something in return for the gift you gave me sometime ago.
[cpg cn=true]

I brought something in return for the gift I gave you sometime ago. I guess I brought something for that person.
[cpg]

[OnName num="yuuto"]
"I see. Masuda-san, were you pleased?
[cpg cn=true]

I don't think I heard anything strange.
[cpg]

[FACE method="change_7" pos="2/3"]

However, Ayako had a complicated expression on her face. I wondered if something was wrong.
[cpg]

And after that complicated expression, she smiled,
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Ayako092"]
[OnName num="ayako"]
'......Yes. She was happy."
[cpg cn=true]

She answered. There was a strange pause. Was it my imagination?
[cpg]

Even if it wasn't my imagination, I couldn't ask him any more questions.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************

[OnName num="yuuto"]
Bon appétit!
[cpg cn=true]

I clasped my hands together in front of the food Ayako had prepared.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayako093"]
[OnName num="ayako"]
Itadakimasu.
[cpg cn=true]

Ayako also joins her hands together, and we eat together.
[cpg]

I say "Itadakimasu" in appreciation of Ayako's cooking, but for Ayako, it's different.
[cpg]

I can tell without having to ask her. Ayako may have been trained that way. ......
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayako094"]
[OnName num="ayako"]
I think I've come to understand the meaning of itadakimasu since I started growing my own vegetables.
[cpg cn=true]

I am sure that is true. I'm sure that's true, because I now know how much work it takes to make food.
[cpg]

[OnName num="yuuto"]
I think that's true. Maybe so."
[cpg cn=true]

[OnName num="yuuto"]
I'm just working, so maybe I don't feel it as much as ...... Ayako does.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Ayako095"]
[OnName num="ayako"]
"It's hard to realize that we are given life, especially in the city. Especially in the city.
[cpg cn=true]

That's right. I never felt this way in the past.
[cpg]

[OnName num="yuuto"]
In the city, there are convenience stores within walking distance. ......
[cpg cn=true]

The city is a place where large quantities of food are produced and then discarded rather than consumed.
[cpg]

The countryside is the opposite. I want to consume every last bit of it.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Ayako096"]
[OnName num="ayako"]
I am happy with my life now. How about you?
[cpg cn=true]

[OnName num="yuuto"]
I am happy. Of course, it's partly because this is the country I've always wanted to live in.
[cpg cn=true]

[OnName num="yuuto"]
With you, I'd be happy anywhere. I think we can be happy together.
[cpg cn=true]

I answered. Ayako looked a little embarrassed.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Ayako097"]
[OnName num="ayako"]
I'm sure I can be happy anywhere with you," I replied. Thank you.
[cpg cn=true]

[OnName num="yuuto"]
No, I didn't say anything that warranted a thank you.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayako098"]
[OnName num="ayako"]
But I'm sorry. I'm sure you also wanted to stop me from living in the countryside.
[cpg cn=true]

[OnName num="yuuto"]
You don't have to say you're sorry about that, too.
[cpg cn=true]

[OnName num="yuuto"]
You don't have to say you're sorry about that, too. I don't want to stop you. If that's what you think, I'm usually in agreement with you.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

When I say this, Ayako dyes her cheeks. It's as if she looked like she did when we were dating ...... or even before we started dating.
[cpg]

Even as a married couple, Ayako sometimes gives me this look.
[cpg]

I'm sure she'll always love me.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Ayako099"]
[OnName num="ayako"]
I really ...... owe you a debt of gratitude that I could never repay even if it took me a lifetime to repay it.
[cpg cn=true]

[OnName num="yuuto"]
Don't call it a favor. I'm not motivated by gratitude or anything like that.
[cpg cn=true]

[OnName num="yuuto"]
And you're overreacting. I didn't do that much.
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Ayako100"]
[OnName num="ayako"]
I'm not exaggerating. I love you, Yuto.
[cpg cn=true]

;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


I don't feel bad about the exaggerated affection I'm receiving. It was such a day.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_go"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************

Then morning. We had breakfast together.
[cpg]

[OnName num="yuuto"]
"Itadakimasu."
[cpg cn=true]

There is nothing strange about the dining table. It was a happy breakfast with two smiling faces.
[cpg]

Ayako also put her hands together and said, "Itadakimasu.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako122"]
[OnName num="ayako"]
You have to have breakfast every day. It has something to do with your life expectancy.
[cpg cn=true]

She was probably referring to the fact that she had missed breakfast the other day.
[cpg]

But life expectancy,......, that's a long way off, isn't it?
[cpg]

[OnName num="yuuto"]
Isn't that an exaggeration,......?
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako123"]
[OnName num="ayako"]
I don't think that's an exaggeration. I don't know what I would do if you were to predecease me. ......
[cpg cn=true]

And then he looks really worried. Oh, come on.
[cpg]

He's that worried about me? That's amazing.
[cpg]

I feel like they love me so hard, but this is quirky.
[cpg]

[OnName num="yuuto"]
"......, Ayako, you're moving too fast."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

Ayako says, "I wonder if that's true. I'm sure she's not aware that she's quick-tempered.
[cpg]

[OnName num="yuuto"]
"Well, then, ......
[cpg cn=true]

I'm at work again today. I'm not going to be able to see Ayako for most of the day.
[cpg]

I have to leave as soon as I finish breakfast.
[cpg]

If this were in a city, I might worry about whether it would be safe to leave Ayako alone.
[cpg]

For example, would someone take her away? Is there such a worry, perhaps?
[cpg]

However, I thought it was unlikely that someone would take it away from me in such a rural area, so I left the house without worrying.
[cpg]

[OnName num="yuuto"]
I left the house with peace of mind.
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]

Seeing him wave goodbye to me, I left the house.
[cpg]

[SE f="se019"]
;//【ＳＥ】『扉閉まる』



[jump storage="ep002.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

