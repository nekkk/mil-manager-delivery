;//３、美咲
*start

;#################################################
*Ep007|Misaki's dream during the demon exorcism
;#################################################

*select03_3|Misaki's dream during the demon exorcism

[SCENE id=7]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_03_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

In my dream, Misaki appeared.
[cpg]

I was slumbering, not sure but ...... Misaki was there, I think.
[cpg]

It was a strange dream. It was a dream as if I was remembering the time of the exorcism.
[cpg]

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************

[FACE method="shake_2" pos="2/3"]
[VOICE f="Ayako629"]
[OnName num="ayako"]
I'm getting used to living in the countryside, aren't I? How about you?"
[cpg cn=true]

...... Don't ask me such difficult questions. Is Ayako getting used to it?
[cpg]

Well, I wonder if she has gotten used to it. I guess I'm getting used to it, but I still can't believe that I'm in Japan.
[cpg]

The night is so much quieter than in the city. And the day is quiet too.
[cpg]

[OnName num="yuuto"]
"Oh, I guess it's okay. It's okay.
[cpg cn=true]

It's easy to live here. I'm getting used to it, but it doesn't feel real.
[cpg]

So the reply was "so-so.
[cpg]

Ayako looked a little strange. I guess so, because Ayako is probably used to it by now.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayako630"]
[OnName num="ayako"]
Really?"　I'm already getting used to it. I'm happy to see this view every day.
[cpg cn=true]

[OnName num="yuuto"]
I'm glad you're happy. Ayako has already become accustomed to the countryside, hasn't she?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako631"]
[OnName num="ayako"]
No, I wonder if she thinks that because she is not accustomed to the countryside. I wonder.
[cpg cn=true]

Well, you have a point. Maybe she doesn't think that being accustomed to something doesn't make her happy.
[cpg]

But ...... Ayako would probably say she's happy in either pattern.
[cpg]

And if that's the case, I think it doesn't matter either way.
[cpg]

[OnName num="yuuto"]
I think she would say, "It doesn't matter either way, does it?　As long as you're happy.
[cpg cn=true]

[OnName num="yuuto"]
I'm sure you'll be able to live here in the countryside forever.
[cpg cn=true]

Ayako smiled a little in response to my answer.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayako632"]
[OnName num="ayako"]
Yes, that's right. ......."
[cpg cn=true]

She sounded deeply moved.
[cpg]

It's so cute. I think I can live with this person for the rest of my life. I'm happy with that.
[cpg]

The casual conversation, the days that seem to be nothing.
[cpg]

Days that are as calm and indifferent as the scenery of this countryside.
[cpg]

I wish these days could go on forever. That's all we want.
[cpg]

We want nothing more than that. We have had enough of risk and reward.
[cpg]

I thought that we should just continue to have children and grow old.
[cpg]

If we were ever going to be unhappy, it would be when it was no longer possible.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『扉開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

I had done everything I needed to do to get to work. All I had to do was leave the house.
[cpg]

[FACE method="change_1" pos="2/3"]
[OnName num="yuuto"]
I'm off then.
[cpg cn=true]

I left my usual greeting and started to leave the house.
[cpg]

Ayako waved her hand in the air. She really is a lovely person.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayako633"]
[OnName num="ayako"]
Yes," she said, "have a good day. See you later.
[cpg cn=true]

Ayako is the same as usual. She smiled at me and saw me off.
[cpg]

If only days like this could go on forever,......, is what I thought earlier.
[cpg]

;//【ＳＥ】『扉閉まる』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（昼）******************************************************

It's peaceful days. Peace, I think.
[cpg]

Peace like the sky, without the slightest trace of light, yet not too bright.
[cpg]

Well, if I may say so, the ...... example of the demon exorcism is a little stuck in my mind.
[cpg]

I've had an affair, at least with someone who isn't Ayako.
[cpg]

If that were to come to light, if that were to come to light, our lives could fall apart.
[cpg]

However, despite such a snag, nothing else in particular is happening.
[cpg]

I don't think that, in and of itself, it would cause that much of an anomaly.
[cpg]

Because there is no one who would benefit from such a thing.
[cpg]

So, I go about my work, thinking that there is nothing to worry about after all. ......
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

In the days of thinking like that, an anomaly occurred suddenly.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************

After finishing work, I returned home. I came home, and there were no words to greet me as there always should be.
[cpg]

[OnName num="yuuto"]
I'm home. ...... What's wrong?
[cpg cn=true]

When I returned home, I found Ayako in the living room with a very angry expression on her face.
[cpg]

I knew something bad was going on. I had never seen Ayako like this.
[cpg]

Ayako's angry expression was close to what most people would call rage.
[cpg]

She is a mild-mannered person to begin with, so she would not normally have this kind of expression on her face.
[cpg]

[free time=300]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ayako634"]
[OnName num="ayako"]
She said, "No problem, ......!　What do you mean by this picture?"
[cpg cn=true]

Saying so, I was confronted with, ...... ah, that picture.
[cpg]

[OnName num="yuuto"]
"This, this is ...... not, hey, it's not, Ayako."
[cpg cn=true]

I can't help but deny it. I have no choice but to deny it. Because.
[cpg]

That picture was of Misaki and I kissing.
[cpg]

Aside from Misaki-san, my face is clearly visible and I can't get away with it.
[cpg]

I didn't realize when the picture was taken. ...... Maybe Masuda-san or someone else took the picture?
[cpg]

[OnName num="yuuto"]
I don't know what the picture is of. I don't know what this picture is either.
[cpg cn=true]

No, this is a bigger problem than that. If things go on like this, it's going to be more than a big fight.
[cpg]

If we come here and talk about breaking up, there's nothing we can do about it.
[cpg]

If it goes badly, I may regret moving to this rural area for the rest of my life.
[cpg]

[OnName num="yuuto"]
I don't ...... remember doing this, I don't even know this place!"
[cpg cn=true]

[OnName num="yuuto"]
"It's a composite or something, I didn't do this!　Believe me!"
[cpg cn=true]

Ayako is silently listening to my words. She still looks angry.
[cpg]

[OnName num="yuuto"]
She is still listening to my words in anger.　In general, why would you be in a cave-like place like this ......?"
[cpg cn=true]

While pretending not to know, and with lies, I try to explain somehow, but ...... Ayako doesn't get it.
[cpg]

No matter what words I use, I can't explain that this photo is a lie.
[cpg]

And then there is the part of me that knows that this photo is neither a lie nor a composite, but a fact.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayako635"]
[OnName num="ayako"]
I believed you when you said, "I believed you, ......!"
[cpg cn=true]

The one word he finally said was one of rejection.
[cpg]

Ayako gets up and runs out of the house. The door is violently opened.
[cpg]

[SE f="se012"]
;//【ＳＥ】『走る』
[free time=1000]

[OnName num="yuuto"]
Wait a minute!　I'm telling you the truth!　Believe me!
[cpg cn=true]

[SE f="se024"]
;//【ＳＥ】『扉乱暴に開く』

[OnName num="yuuto"]
'Really ...... true, what the ......'
[cpg cn=true]

I couldn't do anything more than turn back to Ayako.
[cpg]

[OnName num="yuuto"]
"......Why, how did this ...... happen?"
[cpg cn=true]

Aghast, I propped my elbows on the desk. Tears were threatening to well up, but I held them back.
[cpg]

But I couldn't go after him.
[cpg]

What was I going to do by chasing after him? There is nothing more to say.
[cpg]

It would be useless to explain anything to Ayako.
[cpg]

Because that explanation is a lie. Because it's true that I kissed Misaki. ......
[cpg]

Maybe there's nothing I can do about it now.
[cpg]

I have definitively betrayed Ayako. I can't convince her of that without lying.
[cpg]

And a lie is bound to have frayed edges.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（夜）******************************************************

I couldn't go after Ayako right then and there. It couldn't be helped.
[cpg]

[OnName num="yuuto"]
"Where did she go, Ayako ......?"
[cpg cn=true]

However, there was no way to avoid looking for Ayako, who was not coming back anytime soon.
[cpg]

That is exactly what they would say later, why didn't they look for her?
[cpg]

If I were to say that, it would also be a question of why they didn't go after her.
[cpg]

Anyway, I left the house and looked for Ayako in the village. Somewhere, Ayako must be there. ......
[cpg]

I walk. I walk and search for Ayako in a similar landscape.
[cpg]

Can you really find them with such a steady walk around?
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="yuuto"]
"Oh ...... Chinatsu, san."
[cpg cn=true]

As I was thinking that, I met Ms. Chinatsu.
[cpg]

I was asked, "What's wrong? I was that pale.
[cpg]

But it would be great if you could help me, so I'll tell you what happened.
[cpg]

[OnName num="yuuto"]
I explained what happened while I was away from home for work.
[cpg cn=true]

[OnName num="yuuto"]
It seems a picture was delivered to my house. ......
[cpg cn=true]

[OnName num="yuuto"]
The picture was a ...... picture of me and Misaki, you know, having sex.
[cpg cn=true]

The actual photo was probably taken during the demon exorcism. So, someone must have taken it.
[cpg]

I explained to him what had happened.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Chinatsu280"]
[OnName num="chinatsu"]
I said, "Well, I'm sorry to hear ...... that that happened. ......
[cpg cn=true]

[OnName num="yuuto"]
He said, "......Yes."
[cpg cn=true]

Chinatsu-san gave me a really sympathetic look.
[cpg]

I am grateful for her sympathy, but that in itself doesn't solve anything.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Chinatsu281"]
[OnName num="chinatsu"]
But if you're looking for a picture, ...... Masuda-san once took a picture of you, saying it was a memorial or something.
[cpg cn=true]

[OnName num="yuuto"]
What, ......?　Mr. Masuda?　Why on earth?
[cpg cn=true]

I didn't realize that. I didn't notice it at all.
[cpg]

Wait a minute, it's already rather ...... that they took a picture of me so that I wouldn't notice.
[cpg]

Maybe he was daring me not to notice. Could it be that someone asked me to do it or ......?
[cpg]

I thought about it and realized I was out of my mind.
[cpg]

It can't be. Even if I did, who would ask me to do it?
[cpg]

Would Misaki herself ask?　What for?
[cpg]

[OnName num="yuuto"]
Why is it being delivered to my house? ......
[cpg cn=true]

I consider again what I once thought was a broken idea.
[cpg]

Maybe the person who delivered it to my house and the person who asked me to take a picture of it were the same person.
[cpg]

Someone is trying to break us up. Whoever it is, I don't know.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Chinatsu282"]
[OnName num="chinatsu"]
Come on, ......."
[cpg cn=true]

Chinatsu-san answered without effort. That's right, you'll just get in trouble if you ask me this.
[cpg]

[FACE method="change_7" pos="2/3"]

However, there are many possibilities about this case.
[cpg]

Is it harassment, or is she just doing this kind of thing for the fun of it?
[cpg]

I think harassment is still more likely. I can't think of any other possibility other than these two.
[cpg]

It's a rural area, so even if the suspects are narrowed down, they can't be identified.
[cpg]

This is definitely a rural area. There are far fewer people living here than in the city.
[cpg]

Nevertheless, there are too many people living here for us to hit them one by one.
[cpg]

What are you going to do if you hit them one by one? It is not always possible to get the truth out of them.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Chinatsu283"]
[OnName num="chinatsu"]
Ayako-san may have gone to someone's house. If we go door to door, we might find her. ......
[cpg cn=true]

I see. First we have to find out where Ayako is.
[cpg]

It might be best to do that as well as find out who took the photo.
[cpg]

[OnName num="yuuto"]
Thank you for the ......." Well then."
[cpg cn=true]

I bowed to Chinatsu and went to look for Ayako again.
[cpg]

;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


Searching further. My legs felt like sticks.
[cpg]

I was so tired that I wondered if it was okay to be so tired, even though I had to work tomorrow.
[cpg]

When it was almost midnight, I went to ......
[cpg]

I met another person. And there it all became clear.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（夜）******************************************************

[FACE method="change_2" pos="2/3"]
[VOICE f="Misaki090"]
[OnName num="misaki"]
Oh, Yuto, you liked that picture. Yuto, did you like that picture?"
[cpg cn=true]

The person I ran into was Misaki. She was still smiling, as if she didn't know what I was thinking.
[cpg]

But what she said gave me room to think. What did she mean by "liked it"?
[cpg]

I don't have to think about that. That means, no way, I had this picture taken.
[cpg]

[OnName num="yuuto"]
"Misaki-san ......!　That means, that picture."
[cpg cn=true]

Misaki-san nodding at me. I'm sure she's nodding her head here.
[cpg]

You mean Misaki-san asked you to take it?　And then sent them to me?
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki091"]
[OnName num="misaki"]
I think I'm better suited for Yuto than his wife.
[cpg cn=true]

If he told me this much, there's no doubt about it. I am sure of it, but I have to hear it from him.
[cpg]

[OnName num="yuuto"]
Then the one you sent to my place is also ......."
[cpg cn=true]

Misaki-san only chuckled and did not give me any answer.
[cpg]

[OnName num="yuuto"]
She just chuckled and didn't give me any answer.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Misaki092"]
[OnName num="misaki"]
I took the picture, too. I wanted to monopolize Yuto, so I kinda, kinda did it."
[cpg cn=true]

Oh my God, ...... this guy is not sane.
[cpg]

[OnName num="yuuto"]
What the hell are you doing ......?　Are you insane?"
[cpg cn=true]

Misaki nodded. I don't know if she is claiming to be sane or insane.
[cpg]

Either way, what kind of person is he? He was reckless to the point of insanity.
[cpg]

I wonder if she ever thinks about how the other person would feel if she does something like this.
[cpg]

Is he someone who is not afraid to do something inconvenient for me? If so, it's dangerous to have such a person around.
[cpg]

Besides, you want to monopolize me?　There are other ways, you know, like approaching me gradually. ......
[cpg]

That's because I have a wife, so maybe he didn't think he could go about it the right way.
[cpg]

But even that is beyond the point of overkill.
[cpg]

In general, don't you think about my feelings and Ayako's feelings?
[cpg]

Can't you even imagine how much they will hate me if my family falls apart?
[cpg]

Then, it would be more than just monopolizing me.
[cpg]

After all, does he have some other true intentions? Did I do something to make him hate me?
[cpg]

[OnName num="yuuto"]
"......, I'm cutting my ties with you."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sMisaki004"]
[OnName num="misaki"]
Why?　Have you forgotten what you did?
[cpg cn=true]

[OnName num="yuuto"]
Yes, but that was...
[cpg cn=true]

I'm not sure I can answer that question, either. That's right, that's right. ......
[cpg]

I don't know what to say to him. How do I escape this person's clutches?
[cpg]

[OnName num="yuuto"]
That ...... was, isn't that like an accident?"
[cpg cn=true]

It may be an irresponsible statement. But if I don't say something like this, he won't be able to understand my anger.
[cpg]

[OnName num="yuuto"]
Besides, at that time,...... that..."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki094"]
[OnName num="misaki"]
Oh, you're at a loss for a reply. I knew you cared, you're a good person.
[cpg cn=true]

I'm just a little stuck on a word, and he says something like that. I don't mind.
[cpg]

In fact, I wish I hadn't done anything if he was going to do something like this.
[cpg]

[OnName num="yuuto"]
I didn't mean it like that!　How did you come up with that idea?
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Misaki095"]
[OnName num="misaki"]
I really like you, Yuto. So, keep that in mind."
[cpg cn=true]

I gulp and spit. This guy is really crazy.
[cpg]

[OnName num="yuuto"]
"I'll think about it, what ......"
[cpg cn=true]

Don't tell me you think you still have a chance to win?　Really, no way.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki096"]
[OnName num="misaki"]
"You're asking me if I'm going to stay with my current wife forever. ...... Then..."
[cpg cn=true]

[OnName num="yuuto"]
"Do you want to do it with ...... Ayako?"
[cpg cn=true]

I don't think so. The actuality that you can't get a lot of these types of things, you'll be able to't get a lot of these types of things.
[cpg]

What is he talking about, after all this time?
[cpg]

I've been having an affair with an extraordinary person, it seems.
[cpg]

No matter how many times you say it was an accident, have you done something you can no longer take back?
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



In the end, Ayako was never found. Time was passing rapidly.
[cpg]

It was the middle of the night. No one would answer.
[cpg]

In the first place, it was impolite to ring the chime.
[cpg]

The night is turning into midnight, and it is about to turn into morning.
[cpg]

If I did not go to sleep, it would be a problem for my work tomorrow. So I returned home.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[OnName num="yuuto"]
I thought to myself, "......Ah, Ayako ...... where did she go?"
[cpg cn=true]

And then I went to sleep alone. ......
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『扉開く』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako636"]
[OnName num="ayako"]
"......I'm home."
[cpg cn=true]

Ayako came home. Where was she until morning?
[cpg]

[OnName num="yuuto"]
"Welcome home,......, where have you been, Ayako?"
[cpg cn=true]

I asked. Ayako replies with a dark face and a dark voice.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Ayako637"]
[OnName num="ayako"]
'Anywhere would be fine, right?　I have something I want you to hear.
[cpg cn=true]

Something I want you to hear. It is probably not a very cheerful topic.
[cpg]

I couldn't hide a bad feeling from her rather serious expression.
[cpg]

I don't believe it, but you're not talking about ...... ending things with me, are you?
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako638"]
[OnName num="ayako"]
In this village, there is an event called 'Oniwari' (exorcism of demons). I think you know about it.
[cpg cn=true]

Oh. Oh, that. That's something I hadn't imagined. I never thought Ayako would say something like that.
[cpg]

[OnName num="yuuto"]
"......Wait, wait. Don't say it.
[cpg cn=true]

Don't say it. Don't say any more. Please. ......
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako639"]
[OnName num="ayako"]
I'm going to get in on it.
[cpg cn=true]

I can't stop it, this collapse. Was the crime I committed that serious?
[cpg]

[OnName num="yuuto"]
Why do you say that ...... you're going to go to another man, a man you don't like?"
[cpg cn=true]

Ayako nodded. She seems determined. I think about how to stop her.
[cpg]

But before I can think of a way to stop her, Ayako offers me a condition.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Ayako640"]
[OnName num="ayako"]
She said, "If you want to stop me, you have to cut ties with Misaki-san. Promise me that you will never see her again.
[cpg cn=true]

What, you mean like that? Of course I won't do this again. I won't do it.
[cpg]

[OnName num="yuuto"]
I'm not making a promise, I'm going to do it.
[cpg cn=true]

[OnName num="yuuto"]
I only have Ayako, it's only natural,......, I don't want to do anything that will make people suspect me.
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako641"]
[OnName num="ayako"]
Really, really,......?　I promise, Yuto.
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Later, Ayako made me breakfast. She is not in a good mood, but she is trying to get her life back to normal.
[cpg]

After eating that breakfast, I left the house.
[cpg]

;//【ＳＥ】『車のエンジン音』

[window target=false]
[free time=1000]
[BG f="b_08_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

While I was driving, I couldn't stop feeling uneasy.
[cpg]

I had the feeling that this was not the end.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オフィス内』（昼）******************************************************

[OnName num="colleague"]
What's wrong?　You look pale."
[cpg cn=true]

When I was working at the office, my coworkers were worried about me.
[cpg]

[OnName num="yuuto"]
No, it's nothing. ...... It's nothing.
[cpg cn=true]

It's nothing. Of course I had to answer that and pretend it was nothing.
[cpg]

I had originally intended to have no contact with Misaki-san.
[cpg]

Nothing more. Threatening her with a picture was beyond despicable.
[cpg]

Just by meeting that person again, just by having a short conversation with her, I feel as if something might happen again.
[cpg]

I think it's better not to have any more contact with that person. Really, I don't know what's wrong with him as a person. ......
[cpg]

......No, that's a bit irresponsible thinking.
[cpg]

I guess I was just as crazy then as I am now. I was just like that.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_zh"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************

When I got home, Ayako was gone.
[cpg]

I thought she was probably in the field behind the house, but apparently not.
[cpg]

There was a picture on the desk. It was just a picture of her affair with Misaki sometime ago, taken at a different time and from a different angle.
[cpg]

However, it must have looked to Ayako as if he had cheated on her again.
[cpg]

Was this Misaki's idea, too?　To what extent is she a coward?
[cpg]

Anyway, I couldn't sit still. I had an idea where Ayako was.
[cpg]

[SE f="se012"]
;//【ＳＥ】『走る』

[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟へ続く道』（夜）******************************************************

I ran, out of breath. Ayako had said she was going to join the demon exorcism.
[cpg]

She said she would go to someone else if I didn't cut off Misaki's hand. ......
[cpg]

Then she could be in that cave. No, I definitely don't want him to be there. ......
[cpg]

Either way, we have to be sure. With that in mind, I headed for the cave.
[cpg]

Ah. Help me, Ayako, stop this chest pain.
[cpg]

;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And my hunch was right.
[cpg]

Ayako had joined the demon exorcism, and I tried ...... to pull her away, but I couldn't.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟』（夜）******************************************************

I was seized and asked Ayako.
[cpg]

It's a last ditch effort. That's about as much as I'm willing to do.
[cpg]

[OnName num="yuuto"]
How did ...... this happen?
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="sAyako020"]
[OnName num="ayako"]
It's because you cheated on Misaki-san, isn't it?
[cpg cn=true]

I remembered. I didn't break my promise.
[cpg]

I haven't seen Misaki-san since then. This is an undeniable fact.
[cpg]

[OnName num="yuuto"]
That's why I haven't seen her once since then!　Believe me, that's a picture from that time.
[cpg cn=true]

[OnName num="yuuto"]
It's true. ......　Please, look at me!"
[cpg cn=true]

Ayako didn't even look at me anymore.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="sAyako021"]
[OnName num="ayako"]
'...... either way. I'm such a weak woman that I can't stand being kissed once by someone else."
[cpg cn=true]

It's more than desperation, it's self-deprecation.
[cpg]

[OnName num="yuuto"]
"I don't care either way ...... such ......."
[cpg cn=true]

She really seems to be feeling sad about it. And I think she also feels a sense of guilt towards me.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako679"]
[OnName num="ayako"]
I'm sorry. I can't be decent to you anymore, I'm sure.
[cpg cn=true]

I'm sorry. Ayako apologized, she didn't want to hear such a thing at this stage of her life.
[cpg]

[OnName num="yuuto"]
"......"
[cpg cn=true]

There's nothing more to say. That's what I thought over and over again.
[cpg]

Still, I can't give up. I thought that if I did something here, the wound would still heal.
[cpg]
;//移植のためシーンをカットしています




[jump storage="ep008.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

