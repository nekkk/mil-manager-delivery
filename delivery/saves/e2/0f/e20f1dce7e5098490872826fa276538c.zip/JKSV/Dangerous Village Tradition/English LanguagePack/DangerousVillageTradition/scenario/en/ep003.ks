;//１、綾子
*start

;#################################################
*Ep003|A dream in which Ayako is suffering
;#################################################

*select03_1|A dream in which Ayako is suffering

[SCENE id=3]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_03_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[BGM f="bg_nh"]
[WAIT time=100]

In the dream, Ayako appeared.
[cpg]

My beloved wife. She is the only person I love and will never love anyone else as a woman.
[cpg]

She appeared in my dream.
[cpg]

That in itself is not unusual. It happens often because we are a family.
[cpg]

Because we are family. ...... Of course, I often dreamed about her when we first started dating. ......
[cpg]

But still, I've never had a dream like this.
[cpg]

I had a dream that I saw Ayako in pain.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

Was the demon exorcism leaving a strong impression on me? When I thought so, I woke up.
[cpg]


[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿寝室』（朝）******************************************************

When I opened my eyes, I saw the ceiling as usual. Nothing had changed.
[cpg]

[OnName num="yuuto"]
I turned my head to the side and looked at Ayako.
[cpg cn=true]

I turned my head to the side and looked at Ayako. It is the same as usual.
[cpg]

Ayako is sleeping next to me. I don't think she's going anywhere.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayako155"]
[OnName num="ayako"]
I ask her, "How is ...... today's breakfast?"
[cpg cn=true]

This question itself is not unusual. However, the tone of her voice sounded a little strange to me.
[cpg]

It was a little dark or somber. It was not the usual Ayako.
[cpg]

So, I was a little stuck for an answer.
[cpg]

[OnName num="yuuto"]
"What ......?　No, it's delicious.
[cpg cn=true]

Oh no, I thought for a moment.
[cpg]

Sensing Ayako's unusual behavior, I responded in a different way than usual. I said, "What?
[cpg]

But there was something so strange that I had no choice but to reply in that way.
[cpg]

Ayako's behavior was different from usual. No, was that the case before?
[cpg]

When I think about it, rather ...... strange feeling, is it decreasing?
[cpg]

You could say that it is getting closer to the previous Ayako than before.
[cpg]

I think I was also told not to ask any more about what happened. I chose not to ask deeply.
[cpg]

...... don't have to ask deeply. It would be bad if I asked badly and stepped on some landmine.
[cpg]

But really, I don't know if it's okay. Am I missing something important?
[cpg]

I'm wondering if I'm not missing something important, something like the dream I had today.
[cpg]

I'm wondering if ...... is the right thing to do.
[cpg]

I'm the one who chooses the safe topics. Topics that don't need to be said or not said.
[cpg]

[OnName num="yuuto"]
Ayako, are you getting used to the countryside?　I'm still getting used to it.
[cpg cn=true]

Ayako responds to my repeated questions like this.
[cpg]

Ayako tells me that she is getting used to it. That's because I came here at Ayako's request.
[cpg]

[OnName num="yuuto"]
I see. That's right, I'm just slow to get used to it.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayako156"]
[OnName num="ayako"]
Ayako said, "Well, it's still inconvenient only for shopping. I have to stock up.
[cpg cn=true]

Well, that's true. I can't help but compare it to when I lived in the city.
[cpg]

In the city, I could do shopping every day, but now I can't. Not only can I not do it every day, but I have to be prepared for it.
[cpg]

Not only that, but it's something you have to be prepared for.
[cpg]

[OnName num="yuuto"]
Oh. Yes, ...... there is quite a distance to the nearest supermarket.
[cpg cn=true]

Quite a bit is an understatement.
[cpg]

It's a bit of a drive. What do the other villagers do?
[cpg]

[OnName num="yuuto"]
That's a bit more of a jaunt than a shopping trip, isn't it?
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako157"]
[OnName num="ayako"]
If it takes that long to get to town, I can't get out that often. ......
[cpg cn=true]

Ayako gives me an apologetic look. What, she feels indebted to me?
[cpg]

I don't have to make that face. I'm not saying that shopping is a woman's job.
[cpg]

The most important thing is that you should be able to find the right one for you.
[cpg]

[OnName num="yuuto"]
You don't have to do it. You can just stock up on groceries, or I'll go out and get some for you.
[cpg cn=true]

[OnName num="yuuto"]
But I'll probably be home from work, so I'll be a little late. ......
[cpg cn=true]

As I am wondering what to do, Ayako now returns to me.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Ayako158"]
[OnName num="ayako"]
The most important thing to remember is that you can't just leave everything up to you. I can't leave everything to you.
[cpg cn=true]

And a little bit of chest puffing. What the heck, it looks okay.
[cpg]

I return to my initial feeling of discomfort. And that feeling of discomfort has disappeared considerably.
[cpg]

Her complexion is brighter and her voice is brighter as well.
[cpg]

It's the same Ayako. The true form of the person I loved.
[cpg]

As we talked, she gradually regained her normal tone.
[cpg]

[OnName num="yuuto"]
"I see. I'm sorry, Ayako.
[cpg cn=true]

[OnName num="yuuto"]
If I could do my job more efficiently, I could come home earlier.
[cpg cn=true]

Ayako tells me not to worry about it. There was no more discomfort in her expression.
[cpg]

It looks like I don't need to worry. What I saw in my dream seems to be just a dream.
[cpg]

I felt a little relieved and began to think that it was time to leave the house.
[cpg]

But first, I had to finish my meal. I can't leave it behind.
[cpg]

I finished my breakfast and joined my hands together.
[cpg]

[OnName num="yuuto"]
Thank you for the food.
[cpg cn=true]

Ayako says, "Thanks for the food. She even begins to smile a little.
[cpg]

[OnName num="yuuto"]
I'm off then. I've got work today.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayako159"]
[OnName num="ayako"]
Yes, have a good day.
[cpg cn=true]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

Then she started to get ready to go out.
[cpg]

Ayako didn't sigh or anything like that while she was getting ready.
[cpg]

[OnName num="yuuto"]
I'll be fine, right?
[cpg cn=true]

I mumbled a little. Ayako could not hear me.
[cpg]

Ayako's expression was unclouded. Yes, it's all in my head. ......
[cpg]

I hope it's just my imagination .......
[cpg]

The dream was just a dream, I thought, as I left the house.
[cpg]

Well, it would be more difficult to actually reproduce such a dream.
[cpg]

;//綾子に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_nh"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿寝室』（昼）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako160"]
[OnName num="ayako"]
"...... huh."
[cpg cn=true]

Normally, I would be working in the fields at this time of the day.
[cpg]

But I don't feel like working in the fields. I was feeling so overwhelmed.
[cpg]

The scenery I saw in the cave. It was burned into my mind.
[cpg]

I was disturbed in no small way. I don't think I want to participate at all, though.
[cpg]

;//========================================
;//●ＣＧエロ（一人で気持ちを持て余す感じのヒロイン）ev_12
;//人物１：ヒロイン１
;//服装１：私服
;//場所　：主人公の家・寝室
;//時間　：昼
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sAyako007"]
[OnName num="ayako"]
......"
[cpg cn=true]


Chinatsu-san said that that was the normal situation in this village.
[cpg]

I wonder what would have happened to ...... if I had not refused, right there and then.
[cpg]

[VOICE f="sAyako008"]
[OnName num="ayako"]
What should I do,......?
[cpg cn=true]


Oh, nothing. It's best to do nothing. I know.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ

;//悠斗に視点切り替わり

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『扉開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************

[OnName num="yuuto"]
"I'm home......, I'm tired again today."
[cpg cn=true]

I greeted her properly even though I was exhausted from work.
[cpg]

When I returned home, Ayako looked pale. No, pale is not quite the right word.
[cpg]

She looked strangely red or pale. It was an expression I had never seen before.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Ayako177"]
[OnName num="ayako"]
Welcome home ...... you."
[cpg cn=true]

There was a short pause before he answered. What was that pause?
[cpg]

I knew something was wrong. Something is happening that I don't know about.
[cpg]

This morning, I thought for a moment that things had returned to normal, but it seems that's not the case.
[cpg]

But as long as Ayako is trying to hide it, I'm not going to interfere. ......
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************

As it is, it's time for dinner, and Ayako and I are sitting around the table.
[cpg]

[OnName num="yuuto"]
'Well, then again, it's another dinner with lots of vegetables.
[cpg cn=true]

The first thing to do is to make sure that you have a good time.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako178"]
[OnName num="ayako"]
I don't know if you don't like it,......, but I moved to the country because I wanted this kind of life.
[cpg cn=true]

No, no, no, no, no, no, no, no, no, no, no, no, no, no, no, no. No, no, no, no, no, no, no, no, no, no, no, no, no, no.
[cpg]

[OnName num="yuuto"]
No, no, no, I don't. I don't mind. Not at all. I'm just amazed at the endless variations you come up with each time.
[cpg cn=true]

I didn't mean to be sarcastic, but you're being strangely negative.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Ayako179"]
[OnName num="ayako"]
I'm glad to hear that. ......
[cpg cn=true]

The reply, too, was brusque. I wonder what is wrong with him.
[cpg]

After all, it is a little different from usual. It's like a shadow cast by a moment.
[cpg]

I can't figure out what it is. It's so frustrating, I don't know what's going on.
[cpg]

;//移植のためシーンをカットしています

;//@07/06追加===================================

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_04_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_nh"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿寝室』（夜）******************************************************


When I was getting ready for bed.
[cpg]

[VOICE f="Ayako180"]
[OnName num="ayako"]
He said, "Hey, hey ......, you said you were tired today, do you want to go to bed that ...... soon?"
[cpg cn=true]

For a moment, I didn't understand what he meant. But I soon guessed.
[cpg]

I've been busy with work lately and haven't been able to spend much time with Ayako, holding her hand or anything like that.
[cpg]

Maybe that's why she misses me so much.
[cpg]

But I ......
[cpg]

[OnName num="yuuto"]
"Sorry ...... I'm at my limit ......."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

I was very tired and wanted to go to bed right now.
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Ayako9198"]
[OnName num="ayako"]
It's okay, don't apologize."
[cpg cn=true]

She says that with a sad look on her face.
[cpg]

I can't help but feel sorry for him. As a husband, there may be nothing more frustrating than this.
[cpg]

[FACE method="bow_4" pos="2/3"]
Ayako apologizes, saying she's sorry. But I want to tell him that Ayako did nothing wrong.
[cpg]

[OnName num="yuuto"]
"...... then, good night ......."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayako200"]
[OnName num="ayako"]
"......Good night, dear."
[cpg cn=true]


;//@07/06追加===================================

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************

The next morning. The next morning, we have breakfast together.
[cpg]

It's very awkward. It's awkward, but I can't help it if I don't talk to her.
[cpg]

;//@
[OnName num="yuuto"]
;//「その、悪かったよ。俺が、上手く出来なくて」
I'm sorry about that. I'm really tired.
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
Ayako shakes her head. Don't give me that look. ......
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Ayako201"]
[OnName num="ayako"]
I said, "Fine,......, you don't have to apologize."
[cpg cn=true]

[OnName num="yuuto"]
That may be true, but ......
[cpg cn=true]

I'm not going to let being told not to apologize take away the feeling of being sorry.
[cpg]

[FACE method="change_1" pos="2/3"]
;//[VOICE f="Ayako202"]
[VOICE f="Ayako9202"]
[OnName num="ayako"]
;//「それに、私もどうかしてたわ。あんなに無理やりしたら、あなたも困るって分かってたのに」
And I was out of my mind. I knew you'd be in trouble too."
[cpg cn=true]

The actuality that you can't get a good deal more than a few of these. I'm not going to let that happen.
[cpg]

[OnName num="yuuto"]
But ...... like this, I'm not a good husband, right?"
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
Ayako laughs gently, saying that it's not true.
[cpg]

I hope you really think so,.......
[cpg]

[OnName num="yuuto"]
Thanks for the food."
[cpg cn=true]

While talking like this, we finish our breakfast. Today's menu was also delicious.
[cpg]

[OnName num="yuuto"]
Ayako is not only a farmer, but also a talented cook.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
Ayako smiles. Even though things are not completely back to normal, with a little bit of discomfort, I believed that happiness would continue. ......
[cpg]

At that time, the incident had already happened.
[cpg]

Unbeknownst to us, people around us were starting to move.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『村』（朝）******************************************************

[FACE method="change_5" pos="2/3"]
[VOICE f="Ayako203"]
[OnName num="ayako"]
"Oh no,......, who in the world would do such a thing?"
[cpg cn=true]

[OnName num="yuuto"]
This is ...... who, who would do such a thing?"
[cpg cn=true]

Ayako's cherished field had been vandalized.
[cpg]

It's not just vandalized, it's trashed and in terrible shape. I feel a strong malicious intent.
[cpg]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Ayako204"]
[OnName num="ayako"]
I have been taking great care of ...... and nurtured it."
[cpg cn=true]

Tears welled up in her eyes. I don't want to see Ayako like this.
[cpg]

The first time I saw this, I was furious. Seeing this, I was furious.
[cpg]

I couldn't stay calm. I couldn't stay silent after being subjected to such an act.
[cpg]

[free time=1000]

I tried to get the truth from a passerby. It may not have been the coolest decision, but it was the right one.
[cpg]

Because I now knew the depth of darkness in this village.
[cpg]

[OnName num="yuuto"]
"Hey, you guys, don't you know who trashed the fields?
[cpg cn=true]

It was just a man passing by. It really was a random selection.
[cpg]

[OnName num="man"]
"......"
[cpg cn=true]

Not even a "I don't know" or "I don't know" or anything like that.
[cpg]

People who should have had no contact with us reacted that way.
[cpg]

They just give us a cold look and leave.
[cpg]

[OnName num="yuuto"]
......What the hell is going on, this!"
[cpg cn=true]

Seeing Ayako breaking down in tears, my anger is rising and rising.
[cpg]


;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I asked several other people in the village the same way, but they did not give me any answers.
[cpg]

Some of them even gave me a blatantly disgusted look.
[cpg]

Then I realized that something was going on in the whole village.
[cpg]

[OnName num="yuuto"]
I thought to myself, "My God, ......, this can't be happening.
[cpg cn=true]

Is it called "village ostracism"?　Does such a thing happen nowadays?
[cpg]

No, that's fine. Let's say that such a thing does exist in this day and age.
[cpg]

If it does, what is the cause?
[cpg]

I had no idea, so I was at a loss.
[cpg]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（朝）******************************************************

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayako205"]
[OnName num="ayako"]
......Gusu, gusu, ugh."
[cpg cn=true]

When I returned to the field, Ayako was still there crying.
[cpg]

I don't want to see Ayako crying. I don't want to see her crying, but ...... what can I do?
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako206"]
[OnName num="ayako"]
I was looking forward to living in this village, but this is terrible.
[cpg cn=true]

[OnName num="yuuto"]
"...... don't worry. I'll take care of it."
[cpg cn=true]

I'm going to say it like I'm determined, but when the enemy is all the inhabitants of this village, I feel like I can't do anything about it.
[cpg]

Really, what can I do?
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_07_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

Days go by. The harassment continued, as if they were mocking us.
[cpg]

It went beyond harassment and escalated.
[cpg]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se045"]
;//【ＳＥ】『ガラス割れる』

[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako207"]
[OnName num="ayako"]
"There's a broken window. ...... Really, why are you doing this to me?"
[cpg cn=true]

The house was littered with broken glass. Naturally, it was scattered in such a way that it looked as if it had been broken from the outside.
[cpg]

And there were stones inside the house. Probably, this was thrown into the house.
[cpg]

It wasn't a child's prank or anything like that. It was the same as the other day when they trashed the field.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayako208"]
[OnName num="ayako"]
"Oh, no,......, there's no point in moving here,......," Ayako says, crying.
[cpg cn=true]

Ayako says so in tears. I can't stand to look at her.
[cpg]

[OnName num="yuuto"]
I can't help it. "...... don't cry, Ayako. Wipe your tears.
[cpg cn=true]

But I can't irresponsibly say don't cry. I can only do something about it if I say I will do something about it.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako209"]
[OnName num="ayako"]
What should I do?　Yuto, I can't stand this.
[cpg cn=true]

It is precisely because Ayako had a strong yearning to live in the countryside that she could not bear it.
[cpg]

She must not have wanted to see the countryside's dampness, or something like that.
[cpg]

[OnName num="yuuto"]
She must not have wanted to see such things. We have to find out the cause.
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Ayako210"]
[OnName num="ayako"]
After all, that time ......
[cpg cn=true]

[OnName num="yuuto"]
That time, what was it?
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

No," Ayako said, and stopped to continue.
[cpg]

I'm curious, but since he doesn't want to tell me, I won't pursue it any further either.
[cpg]

[OnName num="yuuto"]
If you don't want to tell me, I won't ask. Ayako."
[cpg cn=true]

Perhaps it had something to do with when she was acting strange.
[cpg]

If it's a problem Ayako wants to hide, there's no need for me to dig it up. I could just encourage her.
[cpg]

With that in mind, I thought of something that would make Ayako feel better.
[cpg]

Even though she enjoys farming, she's at home all the time. ......
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se043" loop=true]
;//【ＳＥ】『車の走行音』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『空』（昼）******************************************************

So, on my day off. I took Ayako for a drive.
[cpg]

A drive for a change of pace may be an easy thing to do, but I couldn't think of anything else.
[cpg]

And even if I say drive, I can't go out to the city without a car. It was no different from my usual commuting route. ......
[cpg]

[VOICE f="Ayako211"]
[OnName num="ayako"]
...... This road is lovely, isn't it? It's covered in greenery all over."
[cpg cn=true]

Ayako looked a little more relaxed.
[cpg]

Just seeing their faces made the trip worthwhile.
[cpg]

[OnName num="yuuto"]
Oh," she said. Except for the paved areas, it's all mountains.
[cpg cn=true]

[OnName num="yuuto"]
There must be a lot of roads like this all over the country. We just don't know about them.
[cpg cn=true]


[VOICE f="Ayako212"]
[OnName num="ayako"]
When there are no more people left, this planet will probably turn back to green.
[cpg cn=true]

Ayako says something outrageous. She seems to be getting sentimental.
[cpg]

[OnName num="yuuto"]
She seems to be getting sentimental.
[cpg cn=true]

[VOICE f="Ayako213"]
[OnName num="ayako"]
I've always dreamed of living in harmony with nature."
[cpg cn=true]

Ayako says something like that with a faraway look in her eyes. As if to say, "I can't do it anymore.
[cpg]

[VOICE f="Ayako214"]
[OnName num="ayako"]
"Nun...... wanted to live with people who live in harmony with nature, I guess. ......"
[cpg cn=true]

And then, her expression turns a little sad again. I didn't want to see that face, so I brought him along for the drive.
[cpg]

[OnName num="yuuto"]
"I know ...... that. But ......."
[cpg cn=true]

But," he said, and then he didn't continue. In the meantime, Ayako continues to speak.
[cpg]

[VOICE f="Ayako215"]
[OnName num="ayako"]
But I wonder if that dream won't come true either.
[cpg cn=true]

[OnName num="yuuto"]
It's too serious. You don't have to think so much about it.
[cpg cn=true]

[OnName num="yuuto"]
You don't have to think so much about it. It's not like everything is over here.
[cpg cn=true]

[VOICE f="Ayako216"]
[OnName num="ayako"]
I don't think so. ......
[cpg cn=true]

I guess "cheer up" is not the word that will cheer me up.
[cpg]

So I knew I had to figure out a way to break the harassment.
[cpg]

[OnName num="yuuto"]
I thought, "Yes, that's right. If we can find out what's causing it, we might be able to do something about it.
[cpg cn=true]

There was no reply to these words.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（夕方）******************************************************

As we talked about these things, Ayako looked as if she had made up her mind.
[cpg]

I don't know what she had decided. I only sensed it from her facial expression.
[cpg]

But at least she no longer had a gloomy expression on her face.
[cpg]

She no longer cried, and I thought that was good enough for me.
[cpg]

I thought that if I could now find out the cause of the harassment, that would be the end of it. ......
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

And the next morning. Weekday as usual.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_go"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************


[OnName num="yuuto"]
"Thanks for the food."
[cpg cn=true]

I finished my breakfast. After that, I got myself cleaned up. It was an ordinary weekday, nothing had changed.
[cpg]

No matter what the circumstances, every day comes as it always does. I had to work.
[cpg]

I can't spend all day at home cheering Ayako up, or in the village looking for the cause of the harassment.
[cpg]

[OnName num="yuuto"]
I'm off then.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayako217"]
[OnName num="ayako"]
"Yes. See you later.
[cpg cn=true]

Perhaps the drive had an effect, Ayako's complexion was good.
[cpg]

The expression of the face is also not ...... without any discomfort, but it is not negative.
[cpg]


;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


The most important thing to remember is that you can't just take a look at the website and say, "I'm not going to do that. The most important thing to remember is that you can't just take a look at the pictures.
[cpg]

But if Ayako is not depressed, that's fine.
[cpg]

I left the house with some relief.
[cpg]


;//綾子に視点切り替わり

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（昼）******************************************************


I had already made up my mind.
[cpg]

I would lose a lot. Perhaps I would lose everything.
[cpg]

But I couldn't bear to stay like this. If I was going to lose something, I wanted to do it myself.
[cpg]

No matter how much I hate being forced by others, I will protect the life I want.
[cpg]

[FACE method="change_7" pos="2/3"]

Even if that means betraying Yuto.
[cpg]

If it is to protect my life with Mr. Yuto, I think it is a forgivable betrayal.
[cpg]

Rather than ......, I can't do it unless I think so.
[cpg]

That's how far into something so bizarre you have to go. It is impossible to have a sane nerve.
[cpg]

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（昼）******************************************************


[OnName num="kawayama"]
Hmm?　Ah, Ayako-san. How can I help you?"
[cpg cn=true]

I went to Ms. Kawayama's house. I couldn't answer right away because of the look on Mr. Kawayama's face.
[cpg]

[OnName num="kawayama"]
I was not able to answer her immediately when I saw her face.　Unfortunately, I am the only one in the house right now.
[cpg cn=true]

Just as well, he was the only one in the house. It sounded as if he was daring to emphasize that fact.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayako218"]
[OnName num="ayako"]
He said, "I'm ......, uh, ...... about the demon exorcism."
[cpg cn=true]

I felt as if he had been waiting for those words.
[cpg]

Or maybe he was waiting for it, or maybe he was expecting it. Either way.
[cpg]

Mr. Kawayama, keeping his smiling face, said, "Hmmm.
[cpg]

[OnName num="kawayama"]
"Hmmm. I wonder what happened to the demon exorcism?　You're not going to participate, are you?
[cpg cn=true]

[OnName num="kawayama"]
Or would you like to observe again?　No problem.
[cpg cn=true]

It seems that this person really ...... has a different nature from the impression I had at first.
[cpg]

He is not a kind person. He may be kind, but it is not his true nature.
[cpg]

;//========================================
;//●ＣＧエロ（思い詰めた感じのヒロイン）ev_14
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：村長
;//服装２：私服
;//場所　：村長の家・客間
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[VOICE f="Ayako219"]
[OnName num="ayako"]
"I will participate in the demon exorcism, I will do it,......, so please stop harassing us."
[cpg cn=true]

Is it okay to do this without even a little consultation with Yuto?
[cpg]

Fine, I have to think. Because, there is no other way.
[cpg]

There is no way that Yuto would forgive me if I asked him.
[cpg]

[OnName num="kawayama"]
"Oh, I'll participate in the demon exorcism. You're going to participate in the demon exorcism?
[cpg cn=true]

Yes, I answered. He reminded me, I had to answer right away.
[cpg]

[OnName num="kawayama"]
That's good, but what kind of change of heart is it?　I'd like to know more.
[cpg cn=true]

What was the point of asking such a question? What was he going to do by asking me such a question?
[cpg]

[VOICE f="Ayako220"]
[OnName num="ayako"]
I've always dreamed of living in the countryside, and I don't want it to be shattered like this.
[cpg cn=true]

I was so miserable that I almost fell apart when he said it. But I shouldn't have done that.
[cpg]

I have my pride. I want to say that I'm doing it because I want to.
[cpg]

[OnName num="kawayama"]
I was so sorry to hear that. I'm sorry to hear that.
[cpg cn=true]

The way he said that caught my attention. I knew it was true.
[cpg]

I'm sorry to hear that. He doesn't deny the harassment.
[cpg]

So, this is the person behind the scenes manipulating me. Is this the person I should hate?
[cpg]

I don't know, I don't know, but I had to ask him.
[cpg]

I don't know, I don't know, but I had to ask him.
[cpg]

[VOICE f="Ayako221"]
[OnName num="ayako"]
'So please, please ...... please ......'
[cpg cn=true]

I say, bowing my head. It's the most humiliating thing I've ever had to do.
[cpg]

[OnName num="kawayama"]
I was so humiliated that I couldn't even think about it. It's just a matter of determination.
[cpg cn=true]

;//ＢＫ
;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『村』（昼）******************************************************

And so, after I left the house, I was nailed.
[cpg]

Or perhaps it was more like a reminder. I was not going to be able to escape.
[cpg]

[OnName num="kawayama"]
I'll see you later. See you in the cave tonight.
[cpg cn=true]

It wasn't just a goodbye. He had already decided where and what we would do next.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako240"]
[OnName num="ayako"]
"...... I know."
[cpg cn=true]

Don't refuse. Don't be frightened. I've made my decision. I will protect my home.
[cpg]

I replied, clenching my hands tightly.
[cpg]

Kawayama-san chuckled and added, "If you want, you can bring your husband with you.
[cpg]

[OnName num="kawayama"]
If you want, why don't you bring your husband with you?　Either one would be fine.
[cpg cn=true]

[OnName num="kawayama"]
Wouldn't you be more comfortable if your husband were with you, Ayako-san?
[cpg cn=true]

I could not believe my ears. I already know that he is crazy.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako241"]
[OnName num="ayako"]
I can't do such a thing, not very much. ......
[cpg cn=true]

Not only would it make me feel better, but it would be the exact opposite. It's not easy, but it's the opposite.
[cpg]

But common sense is not going to work with this person, and certainly not in this village.
[cpg]

It's the kind of village that will harass you just for not participating in their crazy festival.
[cpg]

[OnName num="kawayama"]
Is that so?　I suppose that's an interesting twist, too.
[cpg cn=true]

So, interesting or not interesting, ...... no, I don't want to think about it anymore.
[cpg]

I don't want to put Mr. Kawayama's words in my head.
[cpg]

[OnName num="kawayama"]
I don't want to put his words in my head. You can do as you like."
[cpg cn=true]

Finally, he told me to do as I liked. I can't do whatever I want, that's why I'm in this situation.
[cpg]

This man is crazy. I've known this for a long time, but I can't handle it anymore.
[cpg]

;//悠斗に視点切り替わり

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]

I finished work today and went home.
[cpg]

[SE f="se019"]
;//【ＳＥ】『扉開く』

[window target=false]
[free time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************

[OnName num="yuuto"]
I'm home.
[cpg cn=true]

I managed to make it home, exhausted again today.
[cpg]

I guess the commute to and from work is taking a toll on me. I wonder if I can do something about it. ......
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ayako242"]
[OnName num="ayako"]
Welcome back, dear."
[cpg cn=true]

The usual greeting is returned as usual.
[cpg]

[OnName num="yuuto"]
...... You look well, Ayako."
[cpg cn=true]

Ayako replies, "Yeah. What's the matter, has it blown over?
[cpg]

I wondered about Ayako's health, or rather her condition, but it doesn't seem to be anything to be concerned about.
[cpg]

At least, it was nothing like I was worried about during the day.
[cpg]

The tone of her voice was cheerful. Had she come up with something to counter the harassment?
[cpg]

If so, I wondered if it was something I could help with. Maybe I could ask him.
[cpg]

Or maybe you're going to go and stop the reason why the harassment is happening.
[cpg]

If so, I'd like to know too, but if they don't dare tell me ......, I guess I don't have to touch it.
[cpg]

Or maybe they are in a better mood for some completely different reason. I wouldn't know. ......
[cpg]

[free time=300]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="yuuto"]
"Yo, ...... ah, I'm tired today too."
[cpg cn=true]

I roll my shoulders. Even though I am not that old, I feel that my body is more fatigued than in the past.
[cpg]

I wondered if Ayako was the same way, and was about to say something about the topic, but ......
[cpg]

I glanced back at Ayako as I put my bag down.
[cpg]


[FACE method="change_6" pos="2/3"]

Something about her, like she was pushing herself too hard. It looked that way, so I decided not to.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Then...
[cpg]

After dinner, I tried to flirt with Ayako. But.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿寝室』（夜）******************************************************

[OnName num="yuuto"]
"......, why can't I?"
[cpg cn=true]

Ayako looked tired and said.
[cpg]

[FG f="CHA01_p3_04_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ayako243"]
[OnName num="ayako"]
"......I'm sorry. I'm too tired today. ......
[cpg cn=true]

And then she refused. What did I do that was so tiring? She didn't look tired at all.
[cpg]

So, the fact that she is looking tired right now looks like an act.
[cpg]

But if she says so, I have no choice but to believe her. She must have a reason for acting.
[cpg]

I believe her. I have no other way to support her. Only Ayako wouldn't try to do something bad without telling me.
[cpg]

Or, she wouldn't be involved in something bad. Probably.
[cpg]

[OnName num="yuuto"]
I'm like, "Oh, yeah. No, it's okay. If you're tired, I can't help it.
[cpg cn=true]

Ayako says good night. And then she lies down.
[cpg]

I guess she's telling me to go to bed early. If that's the case, I'll do so. ......
[cpg]

Why do I have to go to bed early? I can't stop thinking about it.
[cpg]

If he wants me to go to bed early, he must be doing something during the night.
[cpg]

Something is making my heart flutter. I have a very bad feeling.
[cpg]

The exorcism is burned into my mind.
[cpg]

For example, I wonder if he's going to that cave while I'm sleeping?
[cpg]

[OnName num="yuuto"]
Hey, Ayako ......, why are you so tired?"
[cpg cn=true]

I boldly ask. Then,
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Ayako244"]
[OnName num="ayako"]
"Never mind, it's no big deal, really."
[cpg cn=true]

I was told, probably lying, that it was no big deal.
[cpg]

[OnName num="yuuto"]
If you say so, fine. ......
[cpg cn=true]

But that doesn't mean I should pursue the matter with a lie. Compassion is important for a married couple.
[cpg]

I doubt if this is included in consideration, but ...... I couldn't make up my mind.
[cpg]

[OnName num="yuuto"]
I'm going to go to bed. Then I'm going to bed."
[cpg cn=true]

Ayako nodded. And Ayako closes her eyes too.
[cpg]

I lay down too, and the two of us snuggled up together and tried to sleep.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Ayako245"]
[OnName num="ayako"]
Then, good night. ......
[cpg cn=true]

The lights went out. I was really tired, so sleep came quickly to me.
[cpg]

Ayako must be ...... tired, too. I'm sure she's sleeping soundly, right?
[cpg]

;//綾子に視点切り替わり
;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se029"]
;//【ＳＥ】『衣擦れ』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_04_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************


[OnName num="yuuto"]
......"
[cpg cn=true]

In the middle of the night, I get up from the futon. It seems that my pretending to be asleep was working.
[cpg]

Still, I checked once more to see if he was asleep.
[cpg]

I heard that people who are truly asleep don't swallow spit. I checked to see if he had fallen asleep.
[cpg]

Yuto was asleep. After confirming this, I slipped out of the house at night.
[cpg]

I whisper a small "I'm sorry.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『扉閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟へ続く道』（夜）******************************************************



I lied and left the house without his permission.
[cpg]

No matter what it was, that alone seemed like a terrible betrayal.
[cpg]

The thought of what I was about to do was going to ...... me out of control.
[cpg]

I'm cheating on Yuto. I can't stand that.
[cpg]

And deceiving is not the word I would use to describe it, it's so disobedient.
[cpg]

I can't keep my nerve.
[cpg]

Many times I wondered whether or not I should go back the way I came, but my legs still moved.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_zh"]
[WAIT time=100]
;//【ＢＧ】『洞窟』（夜）******************************************************

In the cave, Masuda-san, Kawayama-san, and some other men were wearing demon masks.
[cpg]

Even though I could not see their faces, I could somehow recognize them by their physiques and voices.
[cpg]

Still, it is an odd sight no matter how many times I see it. In a place like this, a man and a woman, who should have had little contact with each other, are acting as if they are lovers.
[cpg]

There is even Chinatsu-san and a woman I don't know there.
[cpg]

;//移植のためシーンをカットしています

Even if I had made up my mind, my body was trying to escape.
[cpg]

I involuntarily backed away one step at a time. Then I bumped into a man.
[cpg]

Naturally, he was wearing an ogre's mask. I thought it was impossible to be afraid of such a thing, but ......
[cpg]

It was scary. He looks like a real demon. At least, to me now.
[cpg]

[OnName num="man"]
......"
[cpg cn=true]

He doesn't say anything. It just stands there, silent.
[cpg]

I felt the silent pressure, and even I stood still.
[cpg]

Is this person watching me so that I don't run away?
[cpg]

If so, I can't escape. I don't think I can escape.
[cpg]

My arms are not strong enough to handle this man.
[cpg]

Or will this man come after me later?
[cpg]

If so, I'm even more scared. ...... No, no.
[cpg]

Everything is too late now. I can't run away now. I'm determined to be ready.
[cpg]

I turn around. Toward the back of the cave, where the deed is done.
[cpg]

And with determination, I say I will not run away.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="sAyako009"]
[OnName num="ayako"]
I said, "I know ...... I won't run away. I won't run away. ......
[cpg cn=true]

[OnName num="masuda"]
I'm not going to run away. You can't stop an oni exorcist from doing this kind of thing sometimes."
[cpg cn=true]

;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

;//========================================
;//●ＣＧエロ（ヒロインが男に迫る）ev_17
;//人物１：ヒロイン１
;//服装１：裸
;//人物２：間男
;//服装２：裸（鬼の面をつけている）
;//場所　：洞窟
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

Just pretend to be a lover. Up to the kiss, it's all right.
[cpg]

No matter how much I thought of that, something important was being taken from me.
[cpg]

[VOICE f="sAyako010"]
[OnName num="ayako"]
"...... Yuto-san."
[cpg cn=true]

Without thinking, I call out the name of my precious one.
[cpg]

It's a voice that he can't possibly hear, or rather, I don't want him to hear it.
[cpg]

;//移植のためシーンをカットしています

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『村』（夜）******************************************************


I stumbled along the night street.
[cpg]

It was dark. I was supposed to like the countryside at night, but it was starting to look like an abomination.
[cpg]

I felt a little unsteady on my feet. No, it is not only my body that is unsteady.
[cpg]

I feel as if my feet are not on the ground, even in my spirit. I feel as if I am far away from home.
[cpg]

I am tired. I'm so tired that my mind is unstable. I want to sleep beside him as soon as possible.
[cpg]

I want to sleep beside the one and only person I love. ......
[cpg]

[SE f="se019"]
;//【ＳＥ】『扉閉まる』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿寝室』（夜）******************************************************

When I returned home, there was no sign of Yuto being awake.
[cpg]

[OnName num="yuuto"]
......"
[cpg cn=true]

He probably didn't even notice that I had woken up.
[cpg]

Yuto was breathing in his sleep. I snuggled up next to him.
[cpg]

And I feel warmth. A feeling of healing and a reminder of my sins wells up in me.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako304"]
[OnName num="ayako"]
Good night, my dear ......."
[cpg cn=true]

And the sinfulness swells. The fact that he is so close to me makes it all the more excessive.
[cpg]

Yuto has long since fallen asleep. With a chest full of guilt, I also fell asleep.
[cpg]

[FACE method="change_4" pos="2/3"]

;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

In my slumber, I thought similar thoughts over and over again.
[cpg]

In the futon, I repented in my heart. I am sorry, I am sorry.
[cpg]

No matter how many times I apologize, it will never be forgiven. I had done such a terrible thing.
[cpg]

I kept apologizing ......, wondering if it was okay for me to sleep next to him like this.
[cpg]

I must not say it out loud. He would ask me what I was apologizing for.
[cpg]

So I have to apologize in my heart. Of course, I knew that this kind of penance would never reach Yuto.
[cpg]



[jump storage="ep004.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

