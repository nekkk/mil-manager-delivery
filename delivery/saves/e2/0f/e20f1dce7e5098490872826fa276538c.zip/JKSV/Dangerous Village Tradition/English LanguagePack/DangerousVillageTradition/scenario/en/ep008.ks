
*start

;#################################################
*Ep008|A loved one leaving.
;#################################################

[SCENE id=8]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]

The next day, we had a face-to-face talk.
[cpg]

;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************

[OnName num="yuuto"]
"Why, I don't see you anymore, Misaki-san.
[cpg cn=true]

[OnName num="yuuto"]
I'm not going to see her again, and I don't want to kiss her.
[cpg cn=true]

I had recovered enough to be able to say this. I still have a shattered heart, however.
[cpg]

[FO pos="4/7" time=800]
[FACE method="change_4" pos="2/3"]
[VOICE f="sAyako022"]
[OnName num="ayako"]
I've already told you that. I can't stand it after all, just because I kissed her once.
[cpg cn=true]

The feelings that should have recovered, the words that should have cooled her head, did not reach Ayako.
[cpg]

[OnName num="yuuto"]
'That's not what you promised me. ......!
[cpg cn=true]

Not expecting this turn of events, I say something emotional.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Ayako699"]
[OnName num="ayako"]
'My heart isn't bound by promises. It's not necessarily true that I feel the same way now as I did then.
[cpg cn=true]

[OnName num="yuuto"]
'Well, that may be true,...... but then.
[cpg cn=true]

What am I supposed to do then?　You're saying there's nothing more I can do.
[cpg]

There must still be something, still something that can help me get back together with Ayako.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako700"]
[OnName num="ayako"]
You said it was a composite at first, then you admitted it, but you only did it once. But then he said he only did it once. ......
[cpg cn=true]

That's where he's going to dig up the story. Certainly, looking back on it now, it was a bad decision.
[cpg]

It would have been more sincere to admit that I did it and say I would never do it again. But.
[cpg]

[OnName num="yuuto"]
I was confused at the time. ......
[cpg cn=true]

No. These words are not enough to hold me together.
[cpg]

I wish I could go back in time and start over. I can't stop thinking about that.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako701"]
[OnName num="ayako"]
I think I've seen something wrong with you. No, I think I've seen some things about you that are definitely different. ......
[cpg cn=true]

No, we moved to this part of the country because we agreed on something.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayako702"]
[OnName num="ayako"]
So I'm going to say goodbye. So, goodbye, Mr. Yuto."
[cpg cn=true]

[free time=1000]

I'm leaving you, my beloved wife. My one and only partner who was supposed to be with me all along.
[cpg]


I couldn't go after her.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]

From that day on, Ayako disappeared without a trace.
[cpg]

She never returned to the village, and of course she never returned home.
[cpg]

There was nothing I could do, so I just went on with my days. ......
[cpg]

[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（昼）******************************************************

Even on my days off, I had nothing to do. Without Ayako, I had nothing to do.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

While I was walking around the village thinking this, I met Misaki-san.
[cpg]

;//ＢＫ

I told her how it happened. She told me that Ayako had stopped coming home and the reason why.
[cpg]



;//【ＢＧ】『村』（昼）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki097"]
[OnName num="misaki"]
She said, "I think she left the village.　There's not many buses or anything like that, but it doesn't matter.
[cpg cn=true]

[OnName num="yuuto"]
Oh no. ......
[cpg cn=true]

Oh no. I wonder if Ayako has gone back to her parents' house.
[cpg]

I had completely lost all sense of comfort.
[cpg]

I would have to leave this village too. ...... And I would have to go after Ayako. ......
[cpg]

[free time=300]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Misaki098"]
[OnName num="misaki"]
The first thing you need to do is to get to know me better. Right?"
[cpg cn=true]

As I was thinking that, Misaki said something like that to me.
[cpg]

And then she pulled my hand toward the bushes.
[cpg]

I wondered what she was going to do, but it seems that ......
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中』（昼）******************************************************


[VOICE f="Misaki099"]
[OnName num="misaki"]
Even if Ayako-san is gone, you'll be safe with me, right?"
[cpg cn=true]

It seems that he is inviting me to join him.
[cpg]

[OnName num="yuuto"]
"...... so, is that so? ......"
[cpg cn=true]

I had lost my cool. I should have hated him.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Misaki100"]
[OnName num="misaki"]
Because I really love you.
[cpg cn=true]

But at least Misaki seemed to love me.
[cpg]

I see. I see. I have Misaki-san?
[cpg]

Then there's nothing to worry about. Even without Ayako, we're together.
[cpg]

I force myself to convince my mind that this is a relief .......
[cpg]

[OnName num="yuuto"]
You ...... really love me, don't you?"
[cpg cn=true]

Of course," Misaki replies. That smile seemed cute.
[cpg]

I even thought that if push came to shove, I could just dump Ayako and stick with Misaki.
[cpg]

;//========================================
;//●ＣＧエロ（主人公がヒロインに迫る）ev_44
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：森の中
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

I move closer to her. Misaki-san looked happy.
[cpg]

[VOICE f="sMisaki005"]
[OnName num="misaki"]
'From now on, look only at me.
[cpg cn=true]


I wonder if that would save everything.
[cpg]

I ...... wonder if that's enough.
[cpg]

I put my lips to hers without knowing.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[OnName num="yuuto"]
...... then it's time for me to head back home."
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Misaki120"]
[OnName num="misaki"]
I'm sorry to leave, but I can always see you again, right?
[cpg cn=true]

[OnName num="yuuto"]
I'll see you soon. I'll see you later.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Misaki121"]
[OnName num="misaki"]
We'll do it again. See you later.
[cpg cn=true]

After having such a conversation with Misaki, I went back to my house.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（夜）******************************************************

Day and night, my house was empty. Since Ayako was gone, I was alone all the time.
[cpg]

But I have Misaki. I have someone who loves only me.
[cpg]

Thinking of that, I felt like I could bear it.
[cpg]

[OnName num="yuuto"]
......Thank you for dinner.
[cpg cn=true]

I finish dinner alone. It's not that I don't feel lonely, but if I tell Misaki-san, she might even come to this house.
[cpg]

While I was thinking about that, at my house, I had a visitor.
[cpg]

[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

[OnName num="yuuto"]
'Yes, yes, I'm coming. ......'
[cpg cn=true]

[SE f="se019"]
;//【ＳＥ】『扉開く』

I opened the door and there he was: ......
[cpg]

[OnName num="kawayama"]
"Hello, Mr. Yuto. How are you?
[cpg cn=true]

[OnName num="yuuto"]
......Not really, just fine. What can I do for you?
[cpg cn=true]

It's Mr. Kawayama. What does he want from me?
[cpg]

[OnName num="kawayama"]
"Would you like to join the demon exorcism now?"
[cpg cn=true]

[OnName num="yuuto"]
Onibarai......
[cpg cn=true]

The ritual. The crazy feast. Are they still doing it? That's what I was thinking. ......
[cpg]

I thought to myself, "I'm not involved anymore, am I?　I thought.
[cpg]

[OnName num="yuuto"]
"Exorcising demons, I mean. ......
[cpg cn=true]

[OnName num="kawayama"]
What's the matter?　Not keen on it?
[cpg cn=true]

[OnName num="yuuto"]
I'm not sure I'm in the mood.
[cpg cn=true]

[OnName num="yuuto"]
I mean, what's the point of me going there?
[cpg cn=true]

Yes, what's the point if I go?
[cpg]

Ayako is not there. If Misaki loves me of course, she won't go.
[cpg]

If she is going to be pressed by someone other than me, then of course she would not go.
[cpg]

So, there is no one else but Chinatsu.
[cpg]

Of course, if I'm asked to be Chika's partner, I will do it. ......
[cpg]

I don't have much contact with Chinatsu-san.
[cpg]

And if I'm told to pretend to be her lover, I'll just do so, but I don't actively want to get close to her.
[cpg]

I'm not even a girlfriend,......, so when I was thinking that, I was forcefully taken by Ms. Kawayama.
[cpg]

[OnName num="yuuto"]
Hey, Mr. Kawayama?"
[cpg cn=true]

[OnName num="kawayama"]
'Well, come along. I think you will see something interesting.
[cpg cn=true]

What are you talking about? A chill ran down my back.
[cpg]

[OnName num="yuuto"]
I followed his lead and went to .......
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟へ続く道』（夜）******************************************************

I did as I was told, and there it was: ......
[cpg]

I couldn't believe what I was seeing. I couldn't accept the reality.
[cpg]

;//移植のためシーンをカットしています

[window target=false]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_zh"]
[WAIT time=100]
;//【ＢＧ】『洞窟』（夜）******************************************************

[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=800]

Misaki-san was having an exorcism with another man.
[cpg]

She did not try to pull the men off. If I did that, they would have seized me like before.
[cpg]

[OnName num="yuuto"]
Please explain to me what's going on, Misaki-san!
[cpg cn=true]

[OnName num="yuuto"]
Didn't you like me, ......?
[cpg cn=true]

No, I don't. This is what I just said. This is not good.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Misaki139"]
[OnName num="misaki"]
I told you. I don't care about any man. ......
[cpg cn=true]

[OnName num="yuuto"]
......Do you still feel that way?
[cpg cn=true]

Misaki replied, "Of course. She seemed calm now.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki140"]
[OnName num="misaki"]
She was one of them. Of course, I love him. I'm not lying when I say that.
[cpg cn=true]

[OnName num="yuuto"]
She was saying, "Are you seriously saying that?　Because ......
[cpg cn=true]

[OnName num="yuuto"]
"That's no way to say I love you. ......
[cpg cn=true]

Maybe it's my own logic. Maybe common sense doesn't apply to this person.
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Misaki141"]
[OnName num="misaki"]
But I love you all. ...... Will you love me even if I'm like this?
[cpg cn=true]

She asks me if I love her. I wondered if she was aware that she might be disappointed.
[cpg]

[FACE method="change_6" pos="2/3"]

I was lost. How could I love someone who has a lover but goes to another man?
[cpg]

Still, now that Ayako has left me, I can't give up my attachment to Misaki-san.
[cpg]

I have no choice but to love her. There is no other way. ......
[cpg]

;//移植のためシーンをカットしています

Maybe it doesn't make any sense. Feeling this way, I said.
[cpg]

[OnName num="yuuto"]
"...... I'm done."
[cpg cn=true]

[OnName num="masuda"]
I said, "What?　Enough, dude."
[cpg cn=true]

That's how shocked I was at what was in front of me.
[cpg]

I was not satisfied with just one of the many men in my life. I want you to be just me, Misaki-san.
[cpg]

But if I walk away, I won't even be one of the many.
[cpg]

I don't know what to do. It's not so easy to come to a conclusion about something like this.
[cpg]

I'm in a dilemma of emotions. As I think about it, ......
[cpg]

Misaki-san smiled at me. It was a carefree smile.
[cpg]

No devilishness or anything like that. Just a smile.
[cpg]

;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟』（夜）******************************************************

In the midst of despair and suffering. I think I was asking someone for help.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Chinatsu284"]
[OnName num="chinatsu"]
"Well, I'm sorry I'm late for ......."
[cpg cn=true]

Whether or not my wish was answered, I received a completely different visitor.
[cpg]

[OnName num="yuuto"]
'...... Chika-san, you came, too,.......'
[cpg cn=true]

Chinatsu-san had arrived. Will she also participate in the demon exorcism?
[cpg]

I guess she will do it. She has known about this ritual for a long time.
[cpg]

And not only did she know about it, she also participated in it.
[cpg]

It's a tough situation for all of us, isn't it? I feel as if there is no such thing as proper love in this world.
[cpg]

[free time=300]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p3_02_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Misaki177"]
[OnName num="misaki"]
Oh, Ms. Chinatsu. Oh, yes, you should take care of Yuto.
[cpg cn=true]

[OnName num="yuuto"]
"Is it ......?　Chika-san is my partner?
[cpg cn=true]

I couldn't believe my ears. Does this person really think that anyone can be tied to anyone else?
[cpg]

Just as Misaki-san is willing to deal with anyone, does she feel the same way about me?
[cpg]

Is she not jealous or something?
[cpg]

If so, your view of love is already completely different from mine.
[cpg]

I doubt if it can even be called love.
[cpg]

If that's the case, then the word "like" that she was talking about is not the word I think of as "like. ......
[cpg]

I guess it meant something completely different than what I thought the word "like" meant.
[cpg]

;//========================================
;//●ＣＧエロ（ヒロイン２が主人公に近づく）ev_47
;//人物１：ヒロイン２
;//服装１：白装束
;//人物２：主人公
;//服装２：白装束
;//場所　：洞窟
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_47_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

While I'm thinking about that, Chinatsu-san is closing in on me.
[cpg]

She puts her lips to mine. She doesn't seem to feel any different there.
[cpg]

I'm not even sure if it's me who's crazy or everyone else.
[cpg]

[VOICE f="sChinatsu008"]
[OnName num="chinatsu"]
I say, "...... Don't look at me like that. It's easier to just drift away now."
[cpg cn=true]


...... Maybe it is, maybe it is.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


And so ended today's demon exorcism.
[cpg]

I can no longer distinguish between happiness and loss.
[cpg]

It seems as if I am losing everything, gaining everything, and still losing everything.
[cpg]

I have lost my calm judgment and have decided to think of this place as heaven.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『空』（昼）******************************************************

Boring days repeat themselves.
[cpg]

Ayako's absence has left a hole in my daily life.
[cpg]

Even when I was a student living alone, I don't think I had such empty days.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_00_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************

Days pass, and on another holiday morning, Ayako is gone. Ayako is not there. She doesn't seem to be coming home.
[cpg]

I can't reach her. If I call her parents' house, I might get some kind of answer. ......
[cpg]

Even if I could call now and talk to Ayako, I don't think I have enough cards.
[cpg]

She would just distance herself again. So now is not the right time......
[cpg]

What a thought, but in the end I'm just running away. I'm afraid to talk to Ayako.
[cpg]

I wonder if we're going to end up like this.
[cpg]

If that's the case, should I just get together with Misaki?
[cpg]

But I don't think I can get along with Misaki-san either. She's crazy. ......
[cpg]

She is the kind of person who falls in love with anyone and everyone. She says she loves all of them.
[cpg]

I guess I'm an anomaly if I call her an anomaly. I think I've come to think that any woman is good enough for me.
[cpg]

I feel like I'm becoming strangely self-deprecating. Maybe a trip to the hospital will give me some kind of diagnosis.
[cpg]

[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Just then the doorbell rang, and I went out to the front door.
[cpg]

[SE f="se019"]
;//【ＳＥ】『扉開く』
[WAIT time=1000]

[VOICE f="Misaki188"]
[OnName num="misaki"]
Good morning, Yuto.
[cpg cn=true]

[OnName num="yuuto"]
"Misaki, san. ......?"
[cpg cn=true]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************

He slunk into the living room. Should I have left the door unlocked?
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Misaki189"]
[OnName num="misaki"]
I'm not really looking for anything. I'm just wondering if you're eating alone today.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
He looks around the living room and says something like that. It doesn't matter, what.
[cpg]

[OnName num="yuuto"]
It's fine, just ...... leave me alone."
[cpg cn=true]

This time, he came closer to me. This guy's behavior is so unconnected.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="sMisaki006"]
[OnName num="misaki"]
I said, "You're lonely, aren't you?　I know you miss me. But don't worry, I'm here.
[cpg cn=true]

;//========================================
;//●ＣＧエロ（ヒロインにキスをする主人公）ev_48
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//人物３：ヒロイン１
;//服装３：私服
;//場所　：主人公の家寝室
;//時間　：朝
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_48_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sMisaki007"]
[OnName num="misaki"]
"Kya!"
[cpg cn=true]


I was holding my broken head, but I still liked Misaki-san.
[cpg]

When I tried to kiss her, she didn't mind.
[cpg]

Maybe this is okay, I thought for a little while.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（夕方）******************************************************

This is fine. ......
[cpg]

[window target=false]
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=3000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟』（夜）******************************************************

[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]

Today, at the cave, I'm going to participate in the demon exorcism.
[cpg]

Of course Misaki will be there. I'm not alone. I'm not alone.
[cpg]

Looking at Misaki-san, who was engaging with anyone and everyone, I wondered idly if this was really the right thing for me to do.
[cpg]

She is not my only girlfriend. I have thought that many times. ......
[cpg]

;//移植のためシーンをカットしています
;//ＢＫ
;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（朝）*****************************************************

And then...
[cpg]

It was a sunny day, just like any other. After spring, the demon exorcism was gone.
[cpg]

From that day on, Misaki-san disappeared from the village in a huff.
[cpg]

It may be a matter of course. The demon exorcism had kept us together.
[cpg]

Then, a letter was posted to Kawayama's house, saying, "Now that I have a general idea of the customs of this village, I will go somewhere else.
[cpg]

[OnName num="yuuto"]
"You're leaving me, Misaki-san,.......
[cpg cn=true]

You're not taking me with you, are you? Well, she would.
[cpg]

I can't even sigh. I'm just so vapid now. I have nothing now.
[cpg]

Ayako and Misaki are gone. I am left alone with a scar on my chest that will ...... never go away.
[cpg]

;//ＥＮＤ：ヒロイン３ルート・エンド

[SCENE id=11]

[jump storage="epend.ks" target="*start"]
