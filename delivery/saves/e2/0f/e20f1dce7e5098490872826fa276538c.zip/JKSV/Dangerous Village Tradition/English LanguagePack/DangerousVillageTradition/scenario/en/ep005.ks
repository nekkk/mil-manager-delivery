;//２、千夏
*start

;#################################################
*Ep005|Chinatsu's dream of asking for help
;#################################################

*select03_2|Chinatsu's dream of asking for help

[SCENE id=5]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p3_03_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_nh"]
[WAIT time=100]

For some reason, Chinatsu appeared in my dream.
[cpg]

Is it a little strange to say that Chinatsu-san appeared? It was a dream in which only sounds could be heard.
[cpg]

I heard a voice groaning in pain.
[cpg]

[VOICE f="sChinatsu002"]
[OnName num="chinatsu"]
Someone is suffering.
[cpg cn=true]

I don't know why she is suffering, there is no image, but it is a dream in which I can recognize Chinatsu's voice.
[cpg]

It is a strange dream, I have never had a dream like this.
[cpg]

Maybe something is wrong with me, too, since I saw the demon exorcism.
[cpg]

[VOICE f="Chinatsu066"]
[OnName num="chinatsu"]
Someone, help me ......!"
[cpg cn=true]

And finally, help, I'm sure I heard. It's a dream, so it's like it's nothing. ......
[cpg]

Still, it left me with an uncomfortable feeling, as if it suggested something.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_zh"]
[WAIT time=100]
;//【ＢＧ】『村』（昼）******************************************************


Days passed, and one day off.
[cpg]

Mr. Kawayama showed up. Ayako was heading for the front door, wondering what he was up to.
[cpg]

Yes, Ayako was the one who answered the doorbell, but for some reason I was the only one summoned.
[cpg]

[OnName num="kawayama"]
'Actually, I have something to discuss with you, ......, will you listen to me?'
[cpg cn=true]

When the village head called me for a consultation immediately, I had no choice but to listen anyway.
[cpg]

[OnName num="yuuto"]
Yes, what is it ......?"
[cpg cn=true]

Mr. Kawayama had an almost expressionless face, but even so, there was an indescribable sense of intimidation about him.
[cpg]

[OnName num="kawayama"]
He was almost expressionless, but still he was indescribably intimidating.
[cpg cn=true]

[OnName num="yuuto"]
"...... Um, that's ...... no way."
[cpg cn=true]

I was alarmed. I was afraid it would happen again.
[cpg]

I was not going to let that happen again. あんな裏切りは、もうあっちゃいけない。
[cpg]

Even if Chinatsu-san were to appear in my dreams.
[cpg]

[OnName num="yuuto"]
Are you going to drag me into something like that again?"
[cpg cn=true]

I said in a slightly angry tone. But he didn't change his expression.
[cpg]

In fact, he scratched his head a little and smiled.
[cpg]

[OnName num="kawayama"]
If you don't come, I can't guarantee what will happen to your wife's prized fields or your house.
[cpg cn=true]

What he said was not the kind of thing you say with a smile on your face. There is something wrong with this man.
[cpg]

[OnName num="yuuto"]
He said, "......, that's just a threat, isn't it?"
[cpg cn=true]

Mr. Kawayama did not deny it. On the contrary, he nodded.
[cpg]

[OnName num="kawayama"]
He nodded. "Harassment in the countryside is frightening. Would you like to experience it?"
[cpg cn=true]

He threatens me by saying so. But I didn't need to be threatened. ......
[cpg]

I felt betrayed, but still, I would be lying if I said I was not at all eager to go.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿居間』（昼）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayako470"]
[OnName num="ayako"]
What was your business?　Mr. Kawayama......"
[cpg cn=true]

Ayako spoke to me in a concerned tone. I don't know if I had a worried look on my face or not.
[cpg]

[OnName num="yuuto"]
I was just wondering if I looked like I was worried. It's not a big deal. There are vermin around here.
[cpg cn=true]

There are vermin around here, you know. Let's just say we've been talking about this.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayako471"]
[OnName num="ayako"]
Vermin?　That's scary.
[cpg cn=true]

[OnName num="yuuto"]
"Well, they'll eat your crops, that's all. Don't worry.
[cpg cn=true]

[OnName num="yuuto"]
''They said monkeys, wild boars, ...... that kind of thing.''
[cpg cn=true]

Ayako only answered, "Yes.
[cpg]

I made up the story as I went along, but I'm sure it was a lie based on a sense of guilt.
[cpg]

I'm sorry, so it's a lie that comes out of guilt. ...... No.
[cpg]

I'm not going to tell you the truth, even if I could. I'm having an affair with another woman.
[cpg]

It's the kind of story that would destroy our family if the truth came out.
[cpg]

And I waited for the night to come.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_nh"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿寝室』（夜）******************************************************

[VOICE f="Ayako472"]
[OnName num="ayako"]
"Duh, duh. ......
[cpg cn=true]

[OnName num="yuuto"]
"...... sleeping?　Ayako."
[cpg cn=true]

She is sleeping, breathing in her sleep. I'm sorry, but I'm going to another woman's place now.
[cpg]

Just thinking about it in my head, it's a crazy story.
[cpg]

It's a betrayal beyond my control, but it can't be helped. It can't be helped.
[cpg]

If I don't do this, she said something about Ayako's cherished fields.
[cpg]

Then this action is also for Ayako's sake.
[cpg]


[SE f="se019"]
;//【ＳＥ】『扉開く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟へ続く道』（夜）******************************************************

And this is also to protect my house. I convinced myself.
[cpg]

[OnName num="yuuto"]
Kawayama-san also sounded like he was trying to scare me. ......
[cpg cn=true]

Actually, I don't need to convince him, but I think he is right.
[cpg]

If you are cut off from your village in such a rural area, you may not be able to survive.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟』（夜）******************************************************

In that cave, there were Mr. Masuda and Mr. Kawayama. There were several other men wearing demon masks.
[cpg]

[OnName num="masuda"]
They were wearing ogre masks. You came, uh, Yuto, right?"
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=1000]

Chika was there, too.
[cpg]

[OnName num="kawayama"]
"Come on, come on, Yuto, put on this mask.
[cpg cn=true]

I was still a little hesitant. I was a little hesitant.
[cpg]

You can't act like a lover with someone you hardly know.
[cpg]

But when I thought about it, I felt my heart pounding.
[cpg]

And I decided to let myself be swallowed by this crazy situation.
[cpg]

I can't say it was a result of thinking about Ayako.
[cpg]

;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
;//ＢＫ

[free time=300]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[WAIT time=1000]

[VOICE f="sChinatsu003"]
[OnName num="chinatsu"]
'...... fingers, you're so thin.'
[cpg cn=true]


The first thing that comes to mind is the fact that the two of you are not the only ones who have been through the same thing.
[cpg]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟』（夜）******************************************************

[OnName num="kawayama"]
I guess that's about it for today, then. See you tomorrow.
[cpg cn=true]

[OnName num="masuda"]
I guess so. Then, good work. Be careful on the streets at night, Chinatsu."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="sChinatsu004"]
[OnName num="chinatsu"]
"...... Yes."
[cpg cn=true]

The strange ritual was about to come to an end.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『洞窟へ続く道』（夜）******************************************************

The actual "I'm not a fan of the way you do it," he said, "but I'm not a fan of the way you do it.
[cpg]

I was the only one next to her. Masuda-san and Kawayama-san were not there.
[cpg]

[OnName num="yuuto"]
"Have you been doing this for a long time?"
[cpg cn=true]

I asked her fearfully. Then, without hesitation, Chinatsu answered.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="sChinatsu005"]
[OnName num="chinatsu"]
Yes, I have been doing this since I was a child. Ever since I was a little girl, I have been using .......
[cpg cn=true]

I don't know when she started ...... as a child, but it must have been a long time ago.
[cpg]

[OnName num="yuuto"]
I pity you,......, is there any need to follow such a custom?"
[cpg cn=true]

Chinatsu-san looked a little uncomfortable. Did I say something to harass her?
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Chinatsu109"]
[OnName num="chinatsu"]
I'm not saying ...... that you have to take pity on me. I'm finally over the misery."
[cpg cn=true]

Oh, yeah, I knew it was ...... right. That's right.
[cpg]

She, too, was miserable. That's a natural feeling, isn't it?
[cpg]

I may have asked a question without delicacy.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Chinatsu110"]
[OnName num="chinatsu"]
It's not that I didn't feel any pain until I got used to this demon-purification.
[cpg cn=true]

It must have taken him years to get used to it, to finally be able to immerse himself in its pleasures as he was now.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Chinatsu111"]
[OnName num="chinatsu"]
I finally got used to it," he said. So please leave me alone."
[cpg cn=true]

But the fact that he had to get used to it seemed strange in itself.
[cpg]

[OnName num="yuuto"]
If only I could get out of this village, I could get away from the ridiculous customs. ......
[cpg cn=true]

[OnName num="yuuto"]
There are no such customs outside this village. Of course, you know that.
[cpg cn=true]

;//========================================
;//●ＣＧエロ（木に手をついて、辛そうなヒロイン）ev_26
;//人物１：ヒロイン２
;//服装１：私服
;//場所　：森の中
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_26_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

But even when I said that, she just looked pained.
[cpg]

She was on the verge of tears and leaned against a tree.
[cpg]

[VOICE f="Chinatsu112"]
[OnName num="chinatsu"]
She leaned against a tree and said, "No one will ever take me out of .......
[cpg cn=true]

No one will take you out, huh? That's a heavy word. I guess it's not like I can suddenly go out to the city and live by myself.
[cpg]

[OnName num="yuuto"]
......"
[cpg cn=true]

I haven't forgotten about Ayako. I have not forgotten about Ayako, but I have been thinking about it.
[cpg]

I wondered if it was my role to take Chinatsu out.
[cpg]

Because it is too pitiful if it is left as it is.
[cpg]

I'm sorry to Ayako, but I had to save her, I thought.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中』（夜）******************************************************

I turned off the road and took Chinatsu to a place in the forest.
[cpg]

I took Chika to a place where no one could see her.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Chinatsu113"]
[OnName num="chinatsu"]
Excuse me, my house is not this way.
[cpg cn=true]

Chinatsu-san said something crazy.
[cpg]

[OnName num="yuuto"]
"...... I'll take her out. I'll take Chinatsu-san out.
[cpg cn=true]

[OnName num="yuuto"]
I don't have to go along with this ridiculous custom. Is that not so?
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Chinatsu114"]
[OnName num="chinatsu"]
"What ......?"
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

Chinatsu-san blushed. Then, after staring at me, she averted her gaze.
[cpg]

[OnName num="yuuto"]
I'll take care of all your misery and pain. I'll take care of all your misery and pain."
[cpg cn=true]

I thought to myself, "I'll take care of all your misery and pain. I never thought I would say such a thing to a woman other than Ayako.
[cpg]

I hugged her after saying that. And then, Chinatsu-san said,
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Chinatsu115"]
[OnName num="chinatsu"]
'It's like a dream come true that a nice guy like Yuto-san would say such a thing to me. ......'
[cpg cn=true]

She said that in a sweet voice while almost crying a little.
[cpg]

;//移植のためシーンをカットしています
;//綾子に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se029"]
;//【ＳＥ】『衣擦れ』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_04_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_zh"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿寝室』（夜）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako473"]
[OnName num="ayako"]
The "...... Yuto-san?"
[cpg cn=true]

I woke up in the middle of the night, at what seems like the middle of the night.
[cpg]

The reason is simple. I woke up with no sign of Yuto next to me.
[cpg]

However, I wonder if I would notice in my sleep that there is no sign of anyone next to me.
[cpg]

I woke up thinking that I must really like Yuto, that I can wake up with this kind of thing. ......
[cpg]

I looked for him. I thought he was in the house, but apparently he was not.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako474"]
[OnName num="ayako"]
Where did he go?　Where did he go at this late hour ......?"
[cpg cn=true]

I searched for him, muttering to myself. He was nowhere to be found.
[cpg]

I have a bad feeling about this. I have no idea what's going on, if anything.
[cpg]


;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


I searched the house, but at least he was not in or around the house.
[cpg]

I was inconsolable and decided to hurry up and get dressed and go outside.
[cpg]

It's such a rural area, I doubt anyone would be out and about in the middle of the night.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『扉開く』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（夜）******************************************************

Yuto-san was somehow over here. Was it our marital bond or a woman's intuition that made me think so?
[cpg]

But I was jealous of the marital bond or a woman's intuition.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中』（夜）******************************************************


[VOICE f="Ayako476"]
[OnName num="ayako"]
"......, Mr. Yuto."
[cpg cn=true]

I was astonished. No words came out except his name.
[cpg]

[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
;**【ＣＧ】 ev_26_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


There, I saw Chinatsu and Yuto.
[cpg]

I don't know what it means. I don't know, but the scene in front of me is the same.
[cpg]

As if they were lovers. But this is not a demon exorcism cave.
[cpg]

But Chinatsu-san was a participant in the demon exorcism before. I don't know if Yuto was also a part of the demon exorcism.
[cpg]

;//[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako477"]
[OnName num="ayako"]
"Why ...... why, why like this ......?"
[cpg cn=true]

I whisper to the other side so they don't notice.
[cpg]

I almost collapse on the spot. But I hold on.
[cpg]

I couldn't watch them, so I walked away.
[cpg]

My legs were shaking and I couldn't help it. ......
[cpg]

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『村』（夜）******************************************************

I had to get back first before Yuto returned. I thought so and went back to the house.
[cpg]

I was so shaky that I couldn't even walk properly.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_04_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿寝室』（夜）******************************************************

I pretended to sleep desperately after I got back home. So that Yuto would not find out.
[cpg]

I didn't want him to know that I was aware of him.
[cpg]

;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

Of course, I couldn't sleep. There was no way I could sleep after such a shocking experience.
[cpg]

If I had been able to sleep, I would have thought it was unusual.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿居間』（朝）******************************************************

[OnName num="yuuto"]
You have dark circles under your eyes. Are you all right?
[cpg cn=true]

The next day, Yuto was worried about me. But.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako478"]
[OnName num="ayako"]
"...... it's just, I couldn't sleep."
[cpg cn=true]

If you have time to worry about such things, don't go to Chinatsu. I thought so.
[cpg]

[OnName num="yuuto"]
Can't sleep?　Are you okay or something?"
[cpg cn=true]

So you didn't have to worry. Instead of that, if you honestly told me everything, ...... I would be able to be at ease.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako479"]
[OnName num="ayako"]
'Don't worry about it. It's okay, it's okay. ......
[cpg cn=true]

Anyway, I couldn't hear it out as long as he didn't say it out.
[cpg]

In front of Yuto-san, I was able to fake it. I had to fake it because I felt I had to fake it.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se019"]
;//【ＳＥ】『扉開く』

[OnName num="yuuto"]
I'm off then."
[cpg cn=true]

I just waved him off as he left the house. I could act normal up to that point.
[cpg]

[VOICE f="Ayako480"]
[OnName num="ayako"]
Yes, have a good day, dear .......
[cpg cn=true]

;//【ＳＥ】『扉閉まる』

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（昼）******************************************************



But during the day, when I'm tending to the fields, I'm at a loss.
[cpg]

Oh," I sigh. What to do, really, what to do?
[cpg]

Why? Why, Yuto, why ......
[cpg]

I decided not to think about it, because the more I thought about it, the deeper I would get into it.
[cpg]

There must be some compelling reason. If I don't think so, I won't be able to keep my sanity.
[cpg]

[OnName num="kawayama"]
"Hey, hey, hey. Ayako, hello.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako481"]
[OnName num="ayako"]
"Ah, ......, Ms. Kawayama."
[cpg cn=true]

Mr. Kawayama appeared. I turned my tired face to him.
[cpg]

[OnName num="kawayama"]
'You're looking spry, Ayako-san,...... no, you look pale?'
[cpg cn=true]

And he immediately sees through it. That's right, he was in on the demon exorcism too.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayako482"]
[OnName num="ayako"]
Yeah, yeah. Well, I'm a little shocked.
[cpg cn=true]

Not just a little. In fact, I was so shocked that I wanted to start crying right now.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayako483"]
[OnName num="ayako"]
It's nothing. It's nothing. ......
[cpg cn=true]

[OnName num="kawayama"]
You don't have to look like it's the end of the world.
[cpg cn=true]

[OnName num="kawayama"]
It's nothing," he said. I'm sure it's nothing.
[cpg cn=true]

I was a little shaken. I thought it would be okay to talk to this person.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayako484"]
[OnName num="ayako"]
I asked him if he would be willing to consult with me for a few minutes.
[cpg cn=true]

And then I asked him for advice. I couldn't back down now.
[cpg]

[OnName num="kawayama"]
I said, "Yes. If it's okay with me."
[cpg cn=true]

I told him everything. Everything I'd seen. His betrayal.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="sAyako013"]
[OnName num="ayako"]
Yuto-san was cheating on Chinatsu-san. That man who used to take part in the demon exorcism. ......"
[cpg cn=true]

Mr. Kawayama listened silently while I was talking. Then, after I finished, I said,
[cpg]

[OnName num="kawayama"]
"...... I see. You saw that."
[cpg cn=true]

He replied. He looks serious. I don't know if it was an act or not.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sAyako014"]
[OnName num="ayako"]
Is Yuto-san also participating in the demon exorcism?"
[cpg cn=true]

Kawayama-san groaned. Then he continued, "I'm not at liberty to say.
[cpg]

[OnName num="kawayama"]
I don't think I should be the one to tell you. But if you want to hold on to Yuto," he continued.
[cpg cn=true]

[OnName num="kawayama"]
If you participate in the exorcism ceremony, Yuto might be jealous of you.
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

No, you mustn't do that. The actuality is that you can't do that. The actuality that the actuality is that you can't get a lot of these things.
[cpg]

But surely, it could be immensely ...... effective.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayako487"]
[OnName num="ayako"]
"......It's ......."
[cpg cn=true]

But I still hesitate. I can't take such a step right away.
[cpg]

I know what the devil's punishment is. I have a logical reason to do the same thing, but it's a quandary, it's something I shouldn't do.
[cpg]

[OnName num="kawayama"]
I don't mean to force you to do it. But if you can increase the number of participants, even just one, that would be great.
[cpg cn=true]

[OnName num="kawayama"]
I am always open to you. I'm always ready to welcome you, if you feel so inclined.
[cpg cn=true]

Was it kindness or madness that Mr. Kawayama showed?
[cpg]

I don't know. I don't know, but I thought he had a point.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Ayako488"]
[OnName num="ayako"]
I said, "......Yes."
[cpg cn=true]

And although I said yes, I thought again that it was still impossible. I just couldn't do it.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_nh"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿寝室』（夜）******************************************************

The next night. I pretended to be asleep.
[cpg]

I am not very good at pretending to be asleep. I had never done it before.
[cpg]

[VOICE f="Ayako489"]
[OnName num="ayako"]
"......Sooo, sooo ......nnggg."
[cpg cn=true]

That is how much I trusted Yuto. The actuality that you can't get a lot of these things is that they're not really that easy to get.
[cpg]

[OnName num="yuuto"]
"...... Ayako?　You've already gone to bed."
[cpg cn=true]

I'm sure he's already done that.
[cpg]

There was no doubt about it. I was sure of it, but I followed him to confirm it.
[cpg]

My legs started shaking again. Even when I stood up, I didn't feel like I was walking well.
[cpg]

But I had to walk. I have to get to him.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟へ続く道』（夜）******************************************************


[VOICE f="Ayako490"]
[OnName num="ayako"]
I thought to myself, "This is a lie. ......
[cpg cn=true]

And Yuto, oh, Yuto, he ......
[cpg]

He disappeared into the cave. I thought many times about turning back. But I couldn't overlook it.
[cpg]

I already know what is happening inside. There was no way Yuto could just sit there and watch.
[cpg]

If I got any deeper into it, it would be me who would get hurt. I know this, but I can't stop myself.
[cpg]

Someone, anyone, stop me. ......
[cpg]

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_zh"]
[WAIT time=100]
;//【ＢＧ】『洞窟』（夜）******************************************************

;//@0707追加===================================

I don't even need to look anymore. I don't even need to check.
[cpg]

[OnName num="yuuto"]
"Chinatsu-san ......
[cpg cn=true]

Seeing such a place would only hurt me. Still, I couldn't help but look.
[cpg]

And there, ah, there ...... was a scene almost as expected.
[cpg]

......Chika and Yuto are kissing.
[cpg]

And I also know what Yuto is thinking .......
[cpg]

[window target=false]
[free time=1000]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洞窟へ続く道』（夜）

;//@0707追加===================================

The first thing you need to do is to make sure that you have a good understanding of what you're doing.
[cpg]

How did this happen? How did this happen? Was my love not enough?
[cpg]

Rather than being taken by Chinatsu, I wonder if Yuto is cheating on me with her.
[cpg]

It seemed that way to me. Chinatsu just likes Yuto.
[cpg]

I don't see her as trying to forcefully elope with Yuto or anything like that.
[cpg]

But Yuto is different. Rather, it is the opposite.
[cpg]

Yuto-san is trying to take Chinatsu-san out of this village.
[cpg]

In other words, Yuto-san is actively in love with Chinatsu-san from his side. ......
[cpg]

I couldn't believe it, I was frustrated, I was in pain,...... and I couldn't help myself.
[cpg]

I can no longer believe in anything and everything. Neither Yuto's nor my own feelings.
[cpg]



[jump storage="ep006.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

