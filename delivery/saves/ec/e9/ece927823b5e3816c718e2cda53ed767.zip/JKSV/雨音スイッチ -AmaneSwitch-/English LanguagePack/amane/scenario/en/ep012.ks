*start

;#################################################
*Ep012|Barbarism.
;#################################################
[SCENE id=12]

;//エフェクト
;//木崎家中庭
;//普通レベルの雨


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="danger"]
[BG f="b_k_co_t1_1.ui" time=1000]
;//【ＢＧ】木崎家　中庭　午後　雨

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、小雨】

;//////////////////////////////////////////////////////////////////////////





[FG f="izumi_p5_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0148"]
[OnName num="izumi"]
"Yaaaah, not again. ......"
[cpg cn=true]

[OnName num="father_in_law"]
"Shut up! You're a damned stupid girl if you can't understand the love of your parents!"
[cpg cn=true]

A regular event in the Kizaki house, repeated every time it rains.
[cpg]

This is a great way to make sure you are getting the most out of your money.
[cpg]

[OnName num="father_in_law"]
"I'm not sure what to say. It's funny!"
[cpg cn=true]

The woman, his wife, is frozen like a sculpture, tipping the bottle as she talks to him.
[cpg]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0149"]
[OnName num="izumi"]
"'Mother, help me!　Why aren't you talking!"
[cpg cn=true]

[OnName num="mother"]
"'..................'
[cpg cn=true]

The sisters' own mother, who had become a moron, leaned back in her garden chair and stared at the scene with lightless eyes.
[cpg]

[OnName num="father_in_law"]
"'Your mother is on my side. Not yours. Because he's crazy about me!"
[cpg cn=true]

My father-in-law grinned meaningfully and fumigated his bottle.
[cpg]

The smart Izumi understood what he was saying and could no longer look at her.
[cpg]

Because she missed this man, she abandoned her and Shizuku him.
[cpg]

She thought that she and her sisters had given themselves to this man in order to keep him alive.
[cpg]

It's dirty. My mother and this man.
[cpg]

It's a great way to make sure you get the most out of your vacation.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="danger"]
[BG f="b_k_co_t1_1.ui" time=1000]
;//【ＢＧ】木崎家　中庭　午後　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

;//【雨、大雨】





[OnName num="shinzi"]
"What ......?"
[cpg cn=true]

At that time, Shinji witnessed the ridiculous scene from behind the tree.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

A scene with parents and sisters.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[OnName num="shinzi"]
"This is...what the hell ......?
[cpg cn=true]

The brain of Shinji is extremely confused.
[cpg]

It is not possible .......
[cpg]

The actual scene that should not be there was there in reality.
[cpg]



;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//ブラックアウト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="sir"]
[BG f="b_k_co_t1_1.ui" time=1000]
;//【ＢＧ】木崎家　中庭　午後　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、大雨】





And so some time passed...
[cpg]

[OnName num="father_in_law"]
"Ha...ha...ha........., Shizuku , clean up after yourself, ......."
[cpg cn=true]

After finishing his education, the father-in-law staggered away.
[cpg]

In the event you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

;//精液がかかった状態の立ち絵が必要。
;//[cpg]

[FG f="izumi_p1_02_a.ui" method="change_4" pos="4/5" time=800]

[FG f="shizuku_p1_02_a.ui" method="change_7" pos="2/5" time=800]

[WAIT time=100]
[VOICE f="Izumi0150"]
[OnName num="izumi"]
"'Uh...ugh ...... ohhhhh.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Shizuku0146"]
[OnName num="shizuku"]
"Sis!"
[cpg cn=true]

What is left behind are two sisters who are covered in various mucus and exhausted.
[cpg]

It is not saved.
[cpg]

I'm not sure when it will end, but two poor girls left behind in hell.
[cpg]

[FACE method="change_4" pos="2/5"]
[FACE method="change_4" pos="4/5"]


[WAIT time=100]
[VOICE f="Izumi0151"]
[OnName num="izumi"]
"Woooo!　Unhhhhhh!
[cpg cn=true]

[move from="2/5" to="3/5" ease="easeInOutSine" time=1000]
[WAIT time=100]
[VOICE f="Shizuku0147"]
[OnName num="shizuku"]
"Sis, aaan!"
[cpg cn=true]

Shizuku In the event that you've got a lot of time, you'll be able to take a look at a few of these.
[cpg]

This is also all his fault .......
[cpg]

It's a great way to make sure you're getting the most out of your time with your family. Amane
[cpg]

[FACE method="change_3" pos="3/5"]

[WAIT time=100]
[VOICE f="Shizuku0148"]
[OnName num="shizuku"]
"I'm untying you now!　Uhh... uhh... ......
[cpg cn=true]

[free time=800]

[FG f="izumi_p5_02_a.ui" method="change_4" pos="4/5" time=800]
[FG f="shizuku_p5_02_a.ui" method="change_4" pos="2/5" time=800]

[OnName num="shinzi"]
"I'll give you a hand. ......
[cpg cn=true]


[FACE method="change_5" pos="2/5"]
[FACE method="change_5" pos="4/5"]


[WAIT time=100]
[VOICE f="Shizuku0149"]
[OnName num="shizuku"]
"What?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Izumi0152"]
[OnName num="izumi"]
"Wha...?　Mizushima ......, what, why?　What? What?　What ......?
[cpg cn=true]

In the event that you're not sure what you're looking for, you'll be able to find out more about it here.
[cpg]

Izumi This is a great way to make sure that you are getting the most out of your money.
[cpg]

[OnName num="shinzi"]
"I'm sorry ....... But for now, let me help you ......."
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0150"]
[OnName num="shizuku"]
"I'm not sure what to say, but I'm sure you'll understand.
[cpg cn=true]

Ignoring the emotions of the sisters for the moment, I untied the rope that restrained the hands of Izumi .
[cpg]

[OnName num="shinzi"]
"....................."
[cpg cn=true]

In the event that you've got a lot of money, you'll be able to use it to get the most out of your money.
[cpg]

[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0153"]
[OnName num="izumi"]
"I'm sure you'll be able to understand why.
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0151"]
[OnName num="shizuku"]
"This is a great way to make sure that you get the most out of your vacation.
[cpg cn=true]

I'm not sure if this is a good idea, but I think it's a good idea. Izumi mumbled sadly next to a sobbing Shizuku as he stared helplessly at the ground.
[cpg]

[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0154"]
[OnName num="izumi"]
"I'm not sure what to say, but I'm not going to say anything. Please, ......."
[cpg cn=true]

[OnName num="shinzi"]
"...... Yes."
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0152"]
[OnName num="shizuku"]
"'It's all ...... her fault, it's all her fault!　Me and my sister, it's all her fault!
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0155"]
[OnName num="izumi"]
" Shizuku ...!　Stop it.
[cpg cn=true]

[OnName num="shinzi"]
"She's ......?
[cpg cn=true]

Shizuku You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0153"]
[OnName num="shizuku"]
"It's a Amane senior!"
[cpg cn=true]

[OnName num="shinzi"]
"......What?　What do you mean?
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0154"]
[OnName num="shizuku"]
"His father is that man!　Our stepfather is his parent!
[cpg cn=true]

[OnName num="shinzi"]
"What... what?
[cpg cn=true]

I was so confused and upset that I asked Izumi for an explanation.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0156"]
[OnName num="izumi"]
Amane Satonaka "I'm not sure if this is a good idea, but it's a good idea. Because of the child support and alimony paid to Amane Satonaka , our father-in-law is in debt, and he is still pouring money into that child, eating up our property. And on top of that... you saw it. It's all her fault!
[cpg cn=true]

[OnName num="shinzi"]
"Such ......"
[cpg cn=true]

Didn't Amane her father evaporate?
[cpg]

He was this close, and yet he paid Amane for ......?
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0157"]
[OnName num="izumi"]
"If only the boy ...... and his mother had been able to keep him in line, we wouldn't be in this mess ....... If only that kid hadn't taken the money, we ...... would be!"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0155"]
[OnName num="shizuku"]
" Mizushima , you understand ....... We can't forgive that man!
[cpg cn=true]

[OnName num="shinzi"]
"I know you're both in pain. But it's none of ...... or Amane 's business.
[cpg cn=true]

;//[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0158"]
[OnName num="izumi"]
"It's none of ......'s business. ......?
[cpg cn=true]

Amane Izumi In the event that you've got a lot of time, you'll be able to take a look at the following.
[cpg]

;//[FACE method="change_3" pos="4/5"]
[FG f="izumi_p7_02_a.ui" method="change_3" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Izumi0159"]
[OnName num="izumi"]
"This is a great way to make sure you are getting the most out of your money.　This is a great way to get the most out of your business.　If the word "irrelevant" is allowed, then it is we who are the most irrelevant!　This is what Amane Satonaka deserves!
[cpg cn=true]

[OnName num="shinzi"]
"......!
[cpg cn=true]

;//////////////////////////////////////////////////////////////////////////

;//loop
[SE f="se004" loop=true]
;//【ＳＥ】雨（さっきまでより激しく）

[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]

;//[FACE method="change_4" pos="4/5"]

[FG f="izumi_p5_02_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Izumi0160"]
[OnName num="izumi"]
"Go home, ....... .......
[cpg cn=true]

I understand why the seniors disliked Amane and I understand why Shizuku left Amane . ...... I'm sorry.
[cpg]

So I had no choice but to leave the Kizaki house without saying anything more back.
[cpg]



;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//loop
[stopse g=2]
[stopse g=6]

[jump storage="ep013.ks" target="*start"]
