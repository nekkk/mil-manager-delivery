*start

;//////////////////////////////////////////////////////////////////////////
;#################################################
*Ep015|It's funny.
;#################################################
[SCENE id=15]

;//エフェクト


[free time=800]
[BG f="black.ui" time=800]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_pa_t1_0.ui" time=800]
;//【ＢＧ】学園　廊下　午前　曇り

[WAIT time=800]



A week later, I came to school and all the teachers and students were concerned and had kind words for me.
[cpg]

[OnName num="teacher"]
"'Are you okay?　If you took more time off, I could tutor you.
[cpg cn=true]

[OnName num="male_student"]
"When you're feeling better, let's go out. Invite me anytime. Right?
[cpg cn=true]

[OnName num="female_student"]
"You need a notebook?　Do you want me to get you a copy?
[cpg cn=true]

I smile as much as I can at them and say, "I'm fine.
[cpg]

It's not that I don't feel empty, but I'm more touched by the warmth with which they look at me.
[cpg]




[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_s_3f_t1_0_deskup.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午前　曇り


;//これ以降、終始雨音の目付きがおかしい





[FG f="amane_p5_01_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0734"]
[OnName num="amane"]
"Good morning, Shinji ."
[cpg cn=true]

[OnName num="shinzi"]
"......!"
[cpg cn=true]

It's the same Amane voice that I've always heard.
[cpg]

But I no longer understood the normalcy of it.
[cpg]

I'm not sure what to make of that.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[FG f="amane_p7_01_a.ui" method="change_8" pos="2/3" time=800]
[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0735"]
[OnName num="amane"]
"What's wrong?　You don't look well."
[cpg cn=true]

[OnName num="shinzi"]
There's no such thing as "fine." ......
[cpg cn=true]

;//[FACE method="change_6" pos="2/3"]
[FG f="amane_p5_01_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0736"]
[OnName num="amane"]
"I don't know. But I made a bento lunch for Shinji you!
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, .......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0737"]
[OnName num="amane"]
"Yes!　Eat it!
[cpg cn=true]

It's not even the start of first period yet, but Amane puts his lunch on the desk.
[cpg]

This is a great way to make sure you are getting the most out of your investment.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to say.
[cpg cn=true]

;//ドロドロとした中身が全て腐っている
[BGM f="danger"]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

This is a great way to make sure you are getting the most out of your money.
[cpg]

[OnName num="shinzi"]
"Ugh...geez..."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0738"]
[OnName num="amane"]
"It looks delicious, right?　I've studied cooking, you know?
[cpg cn=true]

[OnName num="shinzi"]
"What's so delicious about it?　It's rotten!
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0739"]
[OnName num="amane"]
"Oh, that's because I didn't know when Shinji would be coming to school. That's why I kept it in my locker, just in case he came.
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

So this is what you made a week ago?
[cpg]

I hold my mouth and nose before inhaling the muffled rotten smell and put the lid on the lunchbox full of what looks like filth.
[cpg]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0740"]
[OnName num="amane"]
"'You won't eat me,......?　I tried so hard, but it's ...... terrible."
[cpg cn=true]

[OnName num="shinzi"]
"Which one is the terrible one?
[cpg cn=true]

It's a good idea to take off the lid again and stick your chopsticks into the discolored meatball Amane .
[cpg]

;//[FACE method="change_6" pos="2/3"]
[FG f="amane_p7_01_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0741"]
[OnName num="amane"]
"It's a good idea to have a good idea of what you're doing.
[cpg cn=true]

[OnName num="shinzi"]
"Ugh, ......, stop it!
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】バンッ！　ドチャッ！


[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0742"]
[OnName num="amane"]
"Oh.
[cpg cn=true]

[OnName num="shinzi"]
"............"
[cpg cn=true]

This is a great way to get the most out of your business.
[cpg]

[OnName num="female_student"]
"You can get a lot more information on the web.
[cpg cn=true]

[OnName num="male_student"]
"What's that ......?
[cpg cn=true]

[SE f="se053"]
;//【ＳＥ】ザワザワ……


This is a great way to make sure you are getting the most out of your money.
[cpg]

[FO pos="2/3" time=800]

Amane In the event that you have any kind of questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

[SE f="se085"]
;//【ＳＥ】グッチャグッチャ……


;//[FACE method="change_8" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0743"]
[OnName num="amane"]
"I'm not sure what to make of it. But it's okay because of the three second rule. ......"
[cpg cn=true]

Amane A lot of the time, the best way to get the most out of your money is to use it to pay off your debts.
[cpg]

This is a great way to get the most out of your business.
[cpg]

[SE f="se085"]
;//【ＳＥ】グチャッ…ビッチャ……

[WAIT time=1000]
[FG f="amane_p7_01_a.ui" method="change_6" pos="2/3" time=800]
;//[FACE method="change_2" pos="2/3"]
[WAIT time=1000]

[WAIT time=100]
[VOICE f="Amane0744"]
[OnName num="amane"]
"Yes, Shinji ...... ah."
[cpg cn=true]

[OnName num="shinzi"]
".........!!!"
[cpg cn=true]

It's a great way to make sure you're getting the most out of your money.
[cpg]




[SE f="se010"]
;//【ＳＥ】ダッシュ


[transition target={true} rule="101.jpg"  time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1200]
[transition target={false} rule="101.jpg"  time=0]

[FG f="amane_p9_01_a_mup.ui" method="change_6" pos="2/3" time=0]
[WAIT time=100]
[VOICE f="Amane0745"]
[OnName num="amane"]
"I'm so Shinji ...... embarrassed."
[cpg cn=true]




;//エフェクト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_s_ph_t1_0.ui" time=800]
;//【ＢＧ】学園　保健室　午前　曇り

[stopse g=2]
[stopse g=6]

[WAIT time=900]

This is a great way to make sure you are getting the most out of your time with your family.
[cpg]

This is a great way to make sure you are getting the most out of your vacation.
[cpg]

But that didn't mean my heart was at ease.
[cpg]

Because ......
[cpg]



[SE f="se031"]
;//【ＳＥ】メッセージ着信



;//メッセージ画面


" Amane " Where are you?
[cpg]

What do you do when you're not in class?
[cpg]

Do you want to know what the test is about?
[cpg]

Come back and I'll tell you. (*^_^*)
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





;//メッセージ画面


" Amane " I'm not mad at you, okay?
[cpg]

Are you worried about what I said earlier?
[cpg]

Ahahaha! I'm not mad at you at all.
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





;//メッセージ画面


" Amane " Oh, I have a question, okay?
[cpg]

I forgot to give out the wedding gifts.
[cpg]

I'm going to go shopping after school, okay?　(^o^)
[cpg]




[OnName num="shinzi"]
"Wha..., what are you talking about ......?
[cpg cn=true]

I'm not sure what you mean by a wedding, is it your mother's funeral?
[cpg]

Amane I'm not sure what to make of it, but I'm sure it's a good idea.
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





;//メッセージ画面


" Amane " Consultation Part 2.
[cpg]

I've got a list of possible honeymoon destinations because Shinji won't let me decide on anything.
[cpg]

You can choose any of these places!
[cpg]

Hawaii, Las Vegas, Dubai.
[cpg]

I'm fine with anywhere!　 As long as it's with Shinji (//heart) (//^_^//)
[cpg]




[OnName num="shinzi"]
"I'm sick of ......
[cpg cn=true]

The incomprehensible content that comes incessantly, I finally typed a reply to ...... 'Please, stop it.
[cpg]

I'm afraid of Amane .......
[cpg]

I don't know why I think like this, why I say these things without hesitation, I have no idea.
[cpg]

I thought I liked him. ......
[cpg]

I swore I'd protect you: ......
[cpg]

I was going to take good care of you. ......
[cpg]

I can't do this anymore. ......
[cpg]




[transition target={true} rule="sita.jpg"  time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1200]
;//【ＢＧ】ブラックアウト

[WAIT time=1000]

[BGM f="eye2"]




;//スマホを見ている雨音


[transition target={false} rule="sita.jpg"  time=10]


;//[FG f="amane_p5_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0746"]
[OnName num="amane"]
"Why are you ......, why are you ......?"
[cpg cn=true]

When Amane saw the reply from Shinji , he was alone in the bathroom, stunned.
[cpg]

I love you so much, I love you more than anyone, but I don't know why you don't understand me.
[cpg]




[SE f="se048"]
;//【ＳＥ】携帯のボタン乱打


[WAIT time=1000]


;//[FG f="amane_p5_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0747"]
[OnName num="amane"]
"If you don t Shinji ...... like it, you can go anywhere. Anywhere with a domestic warm Izumi or even an amusement park Shinji !"
[cpg cn=true]

However, after that, Shinji finally did not receive a reply.
[cpg]

;//[FG f="amane_p5_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0748"]
[OnName num="amane"]
"Why ......, why ......?"
[cpg cn=true]

My hands shake with rattling.
[cpg]

A week ago, a loved one who had a spectacular wedding ceremony did not even reply to me now.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

;//[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0749"]
[OnName num="amane"]
"What should I do?　I...what should I do ......?"
[cpg cn=true]

I left the bathroom in a daze, clutching my phone.
[cpg]



[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="danger"]
;//[BG f="b_s_pa_t1_0.ui" time=0]
;//【ＢＧ】学園　廊下　午前　曇り

;//[transition target={false} rule="162.jpg"  time=1000]

[SE f="se053"]
;//【ＳＥ】ザワザワ

[BG f="b_s_pa_t1_0.ui" time=800]
;//【ＢＧ】学園　廊下　午前　曇り

[WAIT time=1000]

;//[BG f="b_s_pa_t1_0.ui" time=0]

There was a crowd in the hallway, and everyone was looking at the same bulletin board and muttering something.
[cpg]

[OnName num="female_student"]
"'Unbelievable ......'.
[cpg cn=true]

[OnName num="male_student"]
"This is insane. ......"
[cpg cn=true]



[BG f="Board.ui" time=1000]
;//掲示板に張り出されている複数の写真（葬式の時の雨音を写した物）

[WAIT time=1000]

;//[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0750"]
[OnName num="amane"]
"Oh, ......."
[cpg cn=true]



It was a picture of me and Shinji 's wedding.
[cpg]

Some kind person must have taken the picture and put it up here at some point.
[cpg]

;//[FACE method="change_6" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0751"]
[OnName num="amane"]
"'Lovely!　Who took it for you?"
[cpg cn=true]

I jumped into the group with a big smile on my face, and like a wave receding, a space was created around Amane .
[cpg]

[BG f="b_s_pa_t1_0.ui" time=800]

;//move
[FG f="amane_p5_01_a.ui" method="change_6" pos="2/5" time=800]
[FG f="youko_p5_01_a.ui" method="change_1" pos="5/4" time=800]
[WAIT time=800]
;//[move from="2/3" to="2/5" ease="easeInOutSine" time=800]
[move from="5/4" to="4/5" ease="easeInOutSine" time=800]



[WAIT time=100]
[VOICE f="Youko0229"]
[OnName num="youko"]
"Now, who could it be, ......?
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0752"]
[OnName num="amane"]
"' Yoko ?　Thank you!　Can I ask you to burn some more?
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0230"]
[OnName num="youko"]
"Ha, ha!　Are you ...... stupid?
[cpg cn=true]

[FACE method="change_6" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0753"]
[OnName num="amane"]
"I love that we grew up together.　I've never had a gift this good.
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0231"]
[OnName num="youko"]
"You're ......."
[cpg cn=true]

Yoko was amused by the behavior of Amane .
[cpg]

What can you do to make it unbearable for this guy?
[cpg]

There is something wrong with .......
[cpg]

[FO pos="4/5" time=800]
[FO pos="2/5" time=800]
;//[free time=10]
;//[WAIT time=20]

[FG f="izumi_p5_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0166"]
[OnName num="izumi"]
"What the hell is going on here?
[cpg cn=true]

Izumi In the event that you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]


;//move

[FG f="amane_p5_01_a.ui" method="change_2" pos="1/8" time=800]
[WAIT time=20]
[move from="2/3" to="4/5" ease="easeInOutSine" time=800]
[move from="1/8" to="2/5" ease="easeInOutSine" time=800]



[WAIT time=100]
[VOICE f="Amane0754"]
[OnName num="amane"]
Kizaki "I'm not sure what to say, but I'm sure you'll understand.
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0167"]
[OnName num="izumi"]
"What about ......?"
[cpg cn=true]

Amane Izumi In the event you're not sure what's going on, you may want to take a look at the following.
[cpg]

Yoko In the event that you have any questions concerning where and how to use the internet, you can contact us at the web site.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0168"]
[OnName num="izumi"]
"What's a congratulatory gift?　You know what I'm talking about!"
[cpg cn=true]

When Izumi finally spoke up, Amane smiled and said something outrageous.
[cpg]

[FACE method="change_8" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0755"]
[OnName num="amane"]
"It's a good idea to have a good idea of what you're doing.　 One million yen in the name of Kizaki ."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0169"]
[OnName num="izumi"]
"Aaah!
[cpg cn=true]

Shocked as if hit in the head with a bat.
[cpg]

I immediately understood that it was the child support for this month that my father-in-law had transferred to Amane .
[cpg]

And a million yen!
[cpg]

I'm not sure what to make of that.
[cpg]

The flame of anger blazes up inside Izumi .
[cpg]

[FACE method="change_3" pos="4/5"]


[WAIT time=100]
[VOICE f="Izumi0170"]
[OnName num="izumi"]
"This .........
[cpg cn=true]

[FG f="shizuku_p5_01_a.ui" method="change_7" pos="5/4" time=800]
[move from="5/4" to="5/5" ease="easeInOutSine" time=800]


[WAIT time=100]
[VOICE f="Shizuku0161"]
[OnName num="shizuku"]
"Sister!
[cpg cn=true]


[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0171"]
[OnName num="izumi"]
"......!"
[cpg cn=true]

Shizuku In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

Izumi This is a great way to get the most out of your business.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0172"]
[OnName num="izumi"]
"You guys!　Go back to your classrooms!"
[cpg cn=true]

Instead, he yells at the crowd of onlookers, and as they reluctantly leave, Izumi says to Amane , "You know what you did.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0173"]
[OnName num="izumi"]
"Do you know what you've done and what you're saying, ......?
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0756"]
[OnName num="amane"]
"Oh, I'll get you a proper gift soon!　 Shinji and we'll both choose ......"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0174"]
[OnName num="izumi"]
"What?
[cpg cn=true]

I'm not engaging in the conversation.
[cpg]

You can find a lot of people who are looking for the best way to get the most out of their lives. Amane does not even realize that they are not getting along!
[cpg]

[move from="2/5" to="2/3" ease="easeInOutSine" time=800]
[move from="4/5" to="4/3" ease="easeInOutSine" time=800]
[move from="5/5" to="5/4" ease="easeInOutSine" time=800]

A frustrated Yoko pokes Amane in the shoulder and yells at him.
[cpg]


[FO pos="4/3" time=400]
[FO pos="5/4" time=400]

;//[WAIT time=210]

;//move
[FG f="youko_p5_01_a.ui" method="change_5" pos="1/8" time=800]
[WAIT time=20]
[move from="1/8" to="2/4" ease="easeInOutSine" time=200]
[WAIT time=210]

[SE f="se011"]
;//【ＳＥ】ドンッ！

[move from="2/3" to="4/5" ease="easeInOutSine" time=400]
[move from="2/4" to="2/5" ease="easeInOutSine" time=400]


[WAIT time=100]
[VOICE f="Youko0232"]
[OnName num="youko"]
"That's enough!　 Shinji doesn't give a shit about you anymore!　He realized my feelings for you!　You're about to be dumped!"
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0757"]
[OnName num="amane"]
"What .........?"
[cpg cn=true]

This is the first time that Amane 's ears have heard Yoko 's words, and his eyes have come into focus.
[cpg]

It's a good thing, then, that Yoko continued to speak.
[cpg]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0233"]
[OnName num="youko"]
"It's a good thing that I'm not the only one who has a relationship with Shinji .　A crazy woman like you is destined to be thrown away!
[cpg cn=true]

[FACE method="change_8" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0758"]
[OnName num="amane"]
"That's a lie, ....... Don't lie to me!
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0234"]
[OnName num="youko"]
"Shut up!　Rain woman!　You're a freak like your mother!
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0759"]
[OnName num="amane"]
"A psycho ......?　No. ...... No, no, no, no!　Your mother is not a freak. No, no, no, no, no, no, no, no, no, no, no, no, no.
[cpg cn=true]

[FO pos="2/5" time=10]
[FO pos="4/5" time=10]
[WAIT time=20]

[FG f="izumi_p5_01_a.ui" method="change_3" pos="2/3" time=800]
[FG f="shizuku_p5_01_a.ui" method="change_5" pos="4/4" time=400]
[WAIT time=410]
[move from="4/4" to="3/4" ease="easeInOutSine" time=400]


[WAIT time=100]
[VOICE f="Shizuku0162"]
[OnName num="shizuku"]
"......? !"
[cpg cn=true]

Amane Shizuku Izumi In the event that you've got a lot of time, you'll be able to take a look at a few of the best ways to get the most out of your home.
[cpg]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0175"]
[OnName num="izumi"]
"You can find a lot of people who are interested in this kind of thing.
[cpg cn=true]

[FG f="youko_p5_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Youko0235"]
[OnName num="youko"]
"It's a good idea to have a good time. It's a waste of time to get involved in this kind of thing.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0176"]
[OnName num="izumi"]
"Yeah, yeah,.......
[cpg cn=true]


[FO pos="1/3" time=800]
[FO pos="2/3" time=800]
[FO pos="3/4" time=800]


Amane In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0760"]
[OnName num="amane"]
"'Chiggau chiggau chiggau chiggau ......
[cpg cn=true]

;//回想シーン（セピア）

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="sir"]
[BG f="b_a_old_t1_0.ui" time=1000]
;//【ＢＧ】過去の雨音の家　リビング


;//電話中、様子がおかしい母と幼い雨音


[OnName num="mother"]
"'I don't need your money!　If you need it I'll work for you, just come back!　Hey, what's wrong with this money!　I can't accept that kind of money as a handout ......!　You, you!　Oh, .......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0761"]
[OnName num="amane"]
"Mom, ...... who is it from?
[cpg cn=true]

[OnName num="mother"]
"Ugh... ugh... ...... Oh, my God!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0762"]
[OnName num="amane"]
"Mom?
[cpg cn=true]

;//家の中にホースで放水する母


[SE f="se024"]
;//【ＳＥ】ジャーーーッ！



[WAIT time=100]
[VOICE f="Amane0763"]
[OnName num="amane"]
"Oh, my God!　What are you doing?
[cpg cn=true]

[OnName num="mother"]
" Amane - Oh, it's raining!　Make it rain!　When it rains, Dad can't go to work. He's off!　When it rains, he'll come home!　When it rains, we're happy!　When it rains, we'll be happy!"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0764"]
[OnName num="amane"]
"When it rains, we'll be ...... happy. ......?"
[cpg cn=true]

[OnName num="mother"]
"More rain!　More rain!　Ahahahahahaha!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0765"]
[OnName num="amane"]
"When it rains, ...... be happy ......?"
[cpg cn=true]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_en_t2_0.ui" time=1000]
;//【ＢＧ】学園　昇降口　午後　曇り


In the end I decided to leave early without going to class.
[cpg]

I turned off my phone, left my bag in the classroom, and went straight from the infirmary to the elevator .......
[cpg]

[OnName num="shinzi"]
"......!"
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0766"]
[OnName num="amane"]
" Shinji !"
[cpg cn=true]

I was so surprised that I thought my heart would jump out of my mouth.
[cpg]

Why are you here Amane ?
[cpg]

I was supposed to be in class and you had no idea where I was.
[cpg]

[FACE method="change_8" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0767"]
[OnName num="amane"]
"I've been waiting for you. Let's go home together."
[cpg cn=true]

Don't tell me you've been waiting for me here all along?
[cpg]

When I thought about it, a cold sweat began to run down my spine.
[cpg]

[OnName num="shinzi"]
"I'm not going home with you. ......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0768"]
[OnName num="amane"]
"Why ......
[cpg cn=true]

[OnName num="shinzi"]
"I don't even want you to make me lunch anymore. I also want you to stop contacting me.
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0769"]
[OnName num="amane"]
"Why?　You don't like me anymore?
[cpg cn=true]

[OnName num="shinzi"]
"............ Anyway, just leave me alone for a while!
[cpg cn=true]



[FO pos="2/3" time=800]


[SE f="se010"]
;//【ＳＥ】ダッシュ





I ran as fast as I could without even looking behind me.
[cpg]




;//背景グニャリと歪んだ状態で固定





I heard Amane yelling something behind my back, but I couldn't possibly listen calmly now.
[cpg]

Amane is the daughter ...... of the woman who sent my father to his death.
[cpg]

She is partly responsible for Kizaki Sisters ...... the misfortune.
[cpg]

Neither can be said to be Amane their own fault.
[cpg]

You can say that she is also a victim.
[cpg]

I understand that in my head.
[cpg]

But then ......
[cpg]

It's not as if all people in that situation are going to go off and do strange things.
[cpg]

I don't understand Amane .
[cpg]

I can not understand Amane .
[cpg]

A feeling of hopeless helplessness and accumulated fear drove my legs and I kept running ...... until I reached home.
[cpg]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
[BG f="b_si_d_t2_0.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　夕方　曇り


[FG f="yukika_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0096"]
[OnName num="yukika"]
"Are you okay ......?"
[cpg cn=true]

[OnName num="shinzi"]
"Yeah,......."
[cpg cn=true]

Ever since the day my mom died, my Yukika sister has been coming to visit me every day.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0097"]
[OnName num="yukika"]
"Still no appetite?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, ......, sorry.
[cpg cn=true]

There was hot food on the table today, but I could only swallow a few bites.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0098"]
[OnName num="yukika"]
"I'm not going to tell you to get well right away, ....... Take it easy."
[cpg cn=true]

[OnName num="shinzi"]
"Thanks ......."
[cpg cn=true]

[FG f="yukika_p7_01_a.ui" method="change_2" pos="2/3" time=800]

Yukika My sister hugs me gently from behind.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0099"]
[OnName num="yukika"]
"I'm here for you, ....... Don't worry about a thing. ......"
[cpg cn=true]

In fact, it was your Yukika sister who took care of all the details of your mother's funeral, and I was just crying and distraught and useless.
[cpg]

I'm not sure what to make of that, but I'm grateful that you don't blame me for that, and that you come here every day to support me.
[cpg]


[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Yukika0100"]
[OnName num="yukika"]
" Shinji ....... It's okay, ......."
[cpg cn=true]

You can find a lot more than just a few things to do.
[cpg]

[OnName num="shinzi"]
"Come on, ......, you're not a kid anymore.
[cpg cn=true]

[FG f="yukika_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0101"]
[OnName num="yukika"]
"I'm not a fan. You'll be able to find a lot of people who are interested in this kind of thing.　Or do you want me to stop coming?
[cpg cn=true]

[OnName num="shinzi"]
"No, I'm not. Come on, come on.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0102"]
[OnName num="yukika"]
"Ha-ha-ha. ......
[cpg cn=true]

I'm glad that my sister is able to get me to say something lighthearted like this.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll be happy to hear that.　Isn't college hard?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0103"]
[OnName num="yukika"]
"I'm a good student, even though I look like this.　 Unlike Shinji !
[cpg cn=true]

[OnName num="shinzi"]
"Oh, .......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0104"]
[OnName num="yukika"]
"Huh. Oh, there's melon in the fridge. I'm leaving now.
[cpg cn=true]

[OnName num="shinzi"]
"You're leaving?　Why don't you just stay here, for God's sake?
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0105"]
[OnName num="yukika"]
"Yeah, .......
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, .......
[cpg cn=true]

Yukika It's a great way to get the most out of your time and money.
[cpg]

[OnName num="shinzi"]
"I'm just kidding,.......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0106"]
[OnName num="yukika"]
"I'm sure you're right.　I know, I know, I know!　See you later!
[cpg cn=true]

[FO pos="2/3" time=800]


[SE f="se036"]
;//【ＳＥ】ドタドタ＆ドア締まる





[OnName num="shinzi"]
"What?
[cpg cn=true]

The always quiet Yukika sister leaves in a flurry, and our house is suddenly quiet.
[cpg]

[OnName num="shinzi"]
"............"
[cpg cn=true]

I sat in front of my mom's altar and looked at the picture in a daze.
[cpg]

[OnName num="shinzi"]
I sat in front of Mom's altar and stared at the picture. "Mom ......, did you see Dad ......?"
[cpg cn=true]

When I muttered in front of the smiling picture of my mom, tears started to fall down again on their own.
[cpg]

When will these tears stop coming?
[cpg]

Is it because I'm still a child that I cry like this?
[cpg]

Since then, I've spent my days sitting in front of the altar like this every night, talking to my mother, and then falling asleep exhausted.
[cpg]

It's a great way to make sure you're getting the most out of your time with your family and friends.
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト


[SE f="se017"]
;//【ＳＥ】玄関チャイム

[WAIT time=3000]

[SE f="se026"]
;//【ＳＥ】玄関チャイム×２

[WAIT time=5000]

[SE f="se027"]
;//【ＳＥ】玄関チャイム×４



[OnName num="shinzi"]
"Nn ......"
[cpg cn=true]

[SE f="se027"]
;//【ＳＥ】玄関チャイム乱打


;//以降、停止指示まで鳴り続ける


[OnName num="shinzi"]
"!"
[cpg cn=true]

[SE f="se075"]
;//【ＳＥ】ガバッ！


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_si_r_t4_4.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　夜　豪雨


I jumped up at the crazy chime that woke me from my sleep.
[cpg]

[OnName num="shinzi"]
"Two o'clock!
[cpg cn=true]

[SE f="se027"]
The hands on the clock were pointing to midnight, telling me that it was an hour that the chime should not have rung.
[cpg]

[OnName num="shinzi"]
" Amane ...!"
[cpg cn=true]

[SE f="se027"]
It's only him who does this kind of thing .......
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[BGM f="danger"]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト


[SE f="se035"]
;//【ＳＥ】ドア開ける


[SE f="se006"]
;//【ＳＥ】針のように細く速度の速い雨（サーーッ）





[OnName num="shinzi"]
"I'm sure you'll agree.
[cpg cn=true]




;//ドアチャイムに齧り付くようにしてボタンを押しまくる雨音


It's a strange sight.
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
;//[BGM f="rain"]
[BG f="b_ex_sz_t3_3.ui" time=1000]
;//【ＢＧ】通学路　夜　豪雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]


;//【雨、豪雨】


He grabbed the edge of the chime firmly with both hands, pulled his face up to a millimeter in front of the button, and continued to press it over and over again, alternating between his left and right thumbs Amane .......
[cpg]

[FG f="amane_p8_02_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0770"]
[OnName num="amane"]
"'Get out, get out, get out, ......
[cpg cn=true]

[OnName num="shinzi"]
"Stop it!
[cpg cn=true]

;//チャイム停止


[FG f="amane_p7_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0771"]
[OnName num="amane"]
"There you are.
[cpg cn=true]

[OnName num="shinzi"]
"Of course they're here!
[cpg cn=true]

My head was spinning .......
[cpg]

How can a student not be home at 2 am on a weekday?
[cpg]

[OnName num="shinzi"]
"I'm not sure why you're here at this hour. Don't you think it's insane?
[cpg cn=true]

Even though I knew it was useless, I couldn't help but say it.
[cpg]

Sure enough, Amane ignored the insanity and said with a soaking wet smile.
[cpg]

[FACE method="change_8" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0772"]
[OnName num="amane"]
"You know what?　Today, Shinji was acting strangely, so I came here because I was worried.
[cpg cn=true]

[OnName num="shinzi"]
"What does ...... mean by strange?
[cpg cn=true]

I wonder if I don't fit into Amane 's definition of "strange".
[cpg]

[OnName num="shinzi"]
"I'm fine, just go home.
[cpg cn=true]

[FG f="amane_p8_02_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0773"]
[OnName num="amane"]
"No. I know exactly what's going on.
[cpg cn=true]




[OnName num="shinzi"]
"What?
[cpg cn=true]

Amane walked up to me, grabbed my arm and pulled me close to him, hugging me like a lover.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

I don't understand.
[cpg]

I don't understand what she's thinking.
[cpg]

After all the crazy stuff that's happened, she's still acting like she...
[cpg]

Oh, by the way... are we still... going out...?
[cpg]

What's the point of ...... not doing that when you can use your man power to get rid of it?
[cpg]

Is it compassion ...... for Amane ?
[cpg]

Pity for ......?
[cpg]

[FG f="amane_p8_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0774"]
[OnName num="amane"]
"Uffffff."
[cpg cn=true]

A creepy laugh that echoes in the evening rain.
[cpg]

I'm afraid of Amane .
[cpg]




[FG f="amane_p7_02_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0775"]
[OnName num="amane"]
"...Hey, Shinji , how many babies do you want?"
[cpg cn=true]

[OnName num="shinzi"]
"How many babies do you want?"
[cpg cn=true]

I was really surprised that Amane suddenly said such a thing, and an alarm called fear sounded loudly in me.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll agree.
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0776"]
[OnName num="amane"]
"I'm sure you'll agree.
[cpg cn=true]




[SE f="se024"]
;//【ＳＥ】バチャッ！！


[free time=800]
;**【ＣＧ】ev_49_0 ***********************
[CG id=14 index=0 time=1000]
;*****************************************


Amane It's a good idea to have a good idea of what you're looking for and how to get there.
[cpg]


[WAIT time=100]
[VOICE f="Amane0777"]
[OnName num="amane"]
"I want one boy and two girls,......," he said.
[cpg cn=true]

[OnName num="shinzi"]
"Don't say it!"
[cpg cn=true]

I didn't want to even joke about having a child with Amane .
[cpg]

Before I knew it, I was ...... straining my hands around Amane her neck.
[cpg]


[WAIT time=100]
[VOICE f="Amane0778"]
[OnName num="amane"]
"Women's...children...even twins are ...... cute...yeah, ugh ......."
[cpg cn=true]

[OnName num="shinzi"]
"'Don't...don't...don't...don't!'
[cpg cn=true]

Why is it that only Amane 's voice comes clearly into my ears, avoiding the sound of the rain?
[cpg]

Amane In the event that you've got a lot more than one, you'll be able to get a lot more than one.
[cpg]


[WAIT time=100]
[VOICE f="Amane0779"]
[OnName num="amane"]
"I'm not sure what to do, but I'm sure it's a good idea.
[cpg cn=true]

[OnName num="shinzi"]
"......!!!"
[cpg cn=true]

Amane It's a good idea to have a good idea of what you're going to be doing.
[cpg]

[free time=800]
;**【ＣＧ】ev_49_a ***********************
[CG id=14 index=1 time=1000]
;*****************************************



[WAIT time=100]
[VOICE f="Amane0780"]
[OnName num="amane"]
"I'm not sure what to do.
[cpg cn=true]

[OnName num="shinzi"]
"What...?"
[cpg cn=true]

Whenever Amane 's eyes were looking straight at me.
[cpg]


[WAIT time=100]
[VOICE f="Amane0781"]
[OnName num="amane"]
"If Shinji you want ...... to do that, kill ...... me."
[cpg cn=true]

[OnName num="shinzi"]
"!"
[cpg cn=true]

With a gentle smile, Amane closes his eyes as if it were his own desire.
[cpg]

The hand on Amane the neck was trembling as a different kind of fear began to creep into me from earlier.
[cpg]

[OnName num="shinzi"]
"I don't want to kill Amane you, ....... I don't want him to die. ......"
[cpg cn=true]

It was an honest truth.
[cpg]

Amane You can find a lot of things that you can do to make your life easier.
[cpg]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_ex_sz_t3_3.ui" time=1000]
;//【ＢＧ】通学路　夜　豪雨


;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]



[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0782"]
[OnName num="amane"]
".................."
[cpg cn=true]

When I helped Amane her up, she looked at me curiously and was in a daze.
[cpg]

[OnName num="shinzi"]
"Go home today,....... Please, ......."
[cpg cn=true]

[FG f="amane_p2_02_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0783"]
[OnName num="amane"]
"..................."
[cpg cn=true]

Amane This is a great way to get the most out of your time and money.
[cpg]

This is a great way to make sure you are getting the most out of your time and money.
[cpg]

[OnName num="shinzi"]
" Amane ......."
[cpg cn=true]

I'm not sure why .......
[cpg]

Why don't I understand you ......?
[cpg]

Does Amane want me to kill you? ......?
[cpg]

Does Amane want me to die ......?
[cpg]

No. ......
[cpg]

No. ......
[cpg]

You're never supposed to do that. ......
[cpg]




;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]




[jump storage="ep016.ks" target="*start"]
