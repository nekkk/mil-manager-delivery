*start


;#################################################
*Ep001|The new students...
;#################################################
[SCENE id=1]
[BG f="b_s_3f_t1_1.ui" time=800]
[BGM f="eye1"]


[SE f="se009"]
;//【ＳＥ】学校のチャイム





As the students who had been enjoying chatting scattered hurriedly took their seats, an elderly male homeroom teacher walked into the classroom as if he had timed it just right.
[cpg]

[OnName num="shinzi"]
"Stand up!
[cpg cn=true]

[SE f="se062"]
;//【ＳＥ】ガタガタ（起立）


[OnName num="shinzi"]
"Attention, bow!
[cpg cn=true]

[OnName num="Students"]
"Good morning, sir.
[cpg cn=true]

[OnName num="homeroom_teacher"]
"Good morning.
[cpg cn=true]

[OnName num="shinzi"]
"Be seated.
[cpg cn=true]

[SE f="se062"]
;//【ＳＥ】ガタガタ


Once the teacher confirmed that we were seated, she placed the attendance book on the table and began to speak.
[cpg]

[OnName num="homeroom_teacher"]
"Well, first of all, I'd like to introduce a new student."
[cpg cn=true]

[OnName num="shinzi"]
"New students?　At this time of year, ......?
[cpg cn=true]

[SE f="se053"]
;//【ＳＥ】ザワザワザワ


No matter what time of year it is, for bored students, the irregular presence of a 'new student' is a bit of an irritant, and our class was immediately buoyed by the homeroom teacher's words.
[cpg]

[OnName num="homeroom_teacher"]
"Quiet!　I'm sure you'll agree. You ...... should come in.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0001"]
[OnName num="unknown"]
"Yes, ......."
[cpg cn=true]

[BG f="b_s_3f_t1_0_Cup_m.ui"time=800]
[WAIT time=800]

[FG f="amane_p3_02_a.ui" method="change_1" pos="5/4" time=1000]
[WAIT time=10]

[move from="5/4" to="2/3" ease="easeInOutSine" time=2000]


[BGM f="eye2"]
[SE f="se028"]
;//【ＳＥ】ゆっくり歩く


[OnName num="shinzi"]
"............!
[cpg cn=true]

;//雨音・PU
[FG f="amane_p7_02_a.ui" method="change_1" pos="2/3" time=800]

The girl who came in slowly looked somewhat different from us at first glance.
[cpg]

It's a great way to make sure you're getting the most out of your time with us.
[cpg]

In the event that you have any questions regarding where and how to use the internet, you can call us at our own website.
[cpg]

[FG f="amane_p4_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0002"]
[OnName num="unknown"]
"It's Amane Satonaka (Satonaka Amane).
[cpg cn=true]

[OnName num="shinzi"]
"Satonaka...... Amane......
[cpg cn=true]

A clear voice.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

It seems like a different thing, and I'm trapped in a strange feeling.
[cpg]

[OnName num="male_student"]
"Oh man, ......, aren't you super cute?"
[cpg cn=true]

I'm not sure what to make of it.
[cpg]

;// [FG f="amane_p7_02_a.ui" method="change_1" pos="2/3" time=800]

;//[BG f="b_s_3f_t1_0_Cup_m.ui"time=800]

[WAIT time=100]
[VOICE f="Amane0003"]
[OnName num="amane"]
"..................."
[cpg cn=true]

It's a great way to make sure you're getting the most out of your money.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

But ......
[cpg]

[OnName num="female_student"]
"I'm not sure what to say.　I'm not sure what to do.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0004"]
[OnName num="amane"]
"Yes,.......
[cpg cn=true]

Yes, ....... That was my first discomfort with Amane Satonaka .
[cpg]

At any rate, she was dripping Shizuku from the end of her long hair, and the fabric of her blouse was stuck to her arms in places.
[cpg]

It is natural to notice this first, but why did I pay attention to ...... the voice or the expression?
[cpg]

[OnName num="shinzi"]
"I'm not sure what to say. When did this happen ......?
[cpg cn=true]

[free time=800]
[BG f="b_s_3f_t1_1_Lup.ui"time=800]

In the event that you have any questions regarding where and how to use the internet, you can call us at our own web site.
[cpg]

In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site. It didn't seem like the kind of rain that would get me that wet.
[cpg]


[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]

[BG f="b_s_3f_t1_0_Cup_m.ui"time=800]

[OnName num="female_student"]
"I'll lend you a towel. Yes.
[cpg cn=true]


;//[FG f="amane_p3_02_a.ui" method="change_2" pos="2/3" time=800]
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Amane0005"]
[OnName num="amane"]
"Oh, I'm fine. Thank you very much.
[cpg cn=true]

One of the girls offered a sports towel out of kindness.
[cpg]

You can find a lot more information on the web at Amane Satonaka . This is a great way to make sure that you get the most out of your time with your family and friends.
[cpg]

[OnName num="female_student"]
"So,......?
[cpg cn=true]

The girls on the refused side were not encouraged to go any further, and in the end, the classmates somehow ...... left the new student wet.
[cpg]

[OnName num="homeroom_teacher"]
"'Ah, but you see,.......
[cpg cn=true]

In the event that you've got a lot more than one, you'll be able to take a look at a few of them.
[cpg]

[OnName num="homeroom_teacher"]
"In the event that you've got a lot of time, you'll be able to take a look at a few of these.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, yes,....... Then let's go .......
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0006"]
[OnName num="amane"]
"...... Yes.
[cpg cn=true]

In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

I heard a muttered "I'm jealous ......" from the shadows, but I pretended not to hear it as I left the classroom.
[cpg]

[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="healing"]
[BG f="b_s_ph_t1_1.ui" time=1000]
;//【ＢＧ】学園　保健室　午前　雨


[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0007"]
[OnName num="amane"]
"I'm sorry, it's my fault. ......"
[cpg cn=true]

[OnName num="shinzi"]
"Hmm?　No, no, no,......."
[cpg cn=true]

As soon as I reached the infirmary, where the school nurse was not present, the girl threw me an apology.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll be happy to hear that.　Maybe there's a spare shirt or jersey on the shelf somewhere."
[cpg cn=true]

[SE f="se077"]
;//【ＳＥ】ガタゴト……


I've seen them lend out shirts to students who were injured and tore their uniforms before.
[cpg]

Relying on that memory, I took the liberty of rifling through the shelves of the infirmary. ......
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0008"]
[OnName num="amane"]
"Oh, it's fine. Really ...... me."
[cpg cn=true]

The new student stopped me from moving.
[cpg]

[OnName num="shinzi"]
"'Yeah, but ......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0009"]
[OnName num="amane"]
"It dries quickly, and I'm used to it.
[cpg cn=true]

[OnName num="shinzi"]
"Used to?"
[cpg cn=true]

She smiled weakly and lightly wiped the Shizuku from her hair with her hand, which was better than before.
[cpg]

[FG f="amane_p6_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0010"]
[OnName num="amane"]
"'I get caught in the rain a lot. Maybe it's because of my name ......."
[cpg cn=true]

[OnName num="shinzi"]
"The name ......, Satonaka ...... Amane. Ah.
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0011"]
[OnName num="amane"]
It's written "sound of rain."
[cpg cn=true]

[OnName num="shinzi"]
"I see.
[cpg cn=true]

I was strangely convinced, and I wondered how to continue the conversation from there. I managed to find a towel with my shaky hands and handed it to Amane .
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0012"]
[OnName num="amane"]
"Thank you ......."
[cpg cn=true]

This time, Amane received the towel, but did not show any pretense of using it.
[cpg]

I'm not sure what to do with it, but I'm sure it'll help.
[cpg]

[OnName num="shinzi"]
"Oh, you know what ......."
[cpg cn=true]

The gaze is so straightforward that I suddenly feel embarrassed and begin to speak abruptly.
[cpg]

[OnName num="shinzi"]
"I'm a class officer, so if there's anything you don't understand, just ask.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0013"]
[OnName num="amane"]
"Yes. So, .......
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, what do you want?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0014"]
[OnName num="amane"]
"Tell me your name, .......
[cpg cn=true]

[OnName num="shinzi"]
"Oh, .......
[cpg cn=true]

When he asked me, I finally realized that I hadn't told him my name yet, and I felt my face suddenly heat up.
[cpg]

[OnName num="shinzi"]
" Shinji ...... Mizushima Shinji !"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0015"]
[OnName num="amane"]
"Mizushima...kun."
[cpg cn=true]

Amane muttered in my mouth as I heard her name.
[cpg]

[OnName num="shinzi"]
" Shinji is fine."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0016"]
[OnName num="amane"]
" Shinji ......."
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, yeah."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0017"]
[OnName num="amane"]
"Cus..."
[cpg cn=true]

[OnName num="shinzi"]
"Heh heh ......."
[cpg cn=true]

I'm kind of embarrassed that my attitude seems stupid.
[cpg]

Even so, I was pleased to see that Amane finally laughed, even in a small voice, and decided to continue the conversation further.
[cpg]

[OnName num="shinzi"]
"'Where did you come from, Amane -chan?
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0018"]
[OnName num="amane"]
"'Um, ......, rather close by, but from a different ward.
[cpg cn=true]

[OnName num="shinzi"]
"Did you move here because of your parents' work?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0019"]
[OnName num="amane"]
"No, no. ......
[cpg cn=true]

[OnName num="shinzi"]
"Then ............."
[cpg cn=true]

After I said that much, I thought, "Oh no.
[cpg]

I thought it was a normal question for a new student, but the expression on Amane his face disappeared.
[cpg]

[OnName num="shinzi"]
"Oh...!　Well, let's see, ...... here!　The food at the store is pretty good!
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0020"]
[OnName num="amane"]
"Purchasing?"
[cpg cn=true]

Oh, I'm such an idiot, ...... I thought to myself.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

But perhaps because of my concern, Amane was more than willing to talk about it.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0021"]
[OnName num="amane"]
"I'm a little excited because I didn't have to buy anything at my old school.
[cpg cn=true]

[OnName num="shinzi"]
"So?　If that's the case, would you like to go check it out at lunch today?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0022"]
[OnName num="amane"]
"Sure.
[cpg cn=true]

[OnName num="shinzi"]
"Okay, I'll show you around.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0023"]
[OnName num="amane"]
"Yes, please.
[cpg cn=true]

I regained my energy when Amane smiled at me with narrowed eyes.
[cpg]

By that time, I had already forgotten that her uniform had not yet dried and that she was not cold.
[cpg]

[OnName num="shinzi"]
"'Well, let's go back. Class is about to start.
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0024"]
[OnName num="amane"]
"Yes.
[cpg cn=true]

[OnName num="shinzi"]
"But .........
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0025"]
[OnName num="amane"]
"What?
[cpg cn=true]

At that time, I remembered what the teacher had said, "I'll show you around the school.
[cpg]

[OnName num="shinzi"]
"I'll give you a tour of the school.
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0026"]
[OnName num="amane"]
"What?　Is that okay?"
[cpg cn=true]

Amane This is a great way to get the most out of your time and money.
[cpg]

[OnName num="shinzi"]
"It's a good idea. It's a great way to get the most out of your day.
[cpg cn=true]

When I smiled, Amane also smiled a little and said: " is interesting.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0027"]
[OnName num="amane"]
" Shinji is funny."
[cpg cn=true]

[OnName num="shinzi"]
"Really?　Let's go.
[cpg cn=true]

It is possible that the evaluation of "interesting" may be taken negatively by some people, but for now, I was happy.
[cpg]

This is a great way to make sure you are getting the most out of your money.
[cpg]

When I took Amane out of the infirmary, I decided to go around various places in the school building with my feet.
[cpg]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BG f="b_s_gy_t1_1.ui" time=1000]
;//【ＢＧ】学園　体育館　午前　雨


[OnName num="shinzi"]
"This is the gym.
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0028"]
[OnName num="amane"]
"'Wow, that's a big ...... one. It's probably the best I've ever seen.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, we have a lot of students. We have a lot of students, so it has to be as big as this for a general assembly.
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0029"]
[OnName num="amane"]
"You can play basketball and volleyball at the same time.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah. Yes, both are quite strong. Do you play either one, Amane ?
[cpg cn=true]

I asked the question in a social manner.
[cpg]

But Amane shook his head a little awkwardly.
[cpg]

[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0030"]
[OnName num="amane"]
"I'm not really good at sports. I'm not very good at sports... I don't even particularly like them. ......
[cpg cn=true]

Usually these conversations between people who don't know each other well are cut off at that point, but Amane is different. ......
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0031"]
[OnName num="amane"]
"What about Shinji ?"
[cpg cn=true]

But is different.
[cpg]

It's not that I don't like either of them.
[cpg]

[OnName num="shinzi"]
"It's not that I don't like either of them, but I think I prefer soccer to basketball and volleyball.　If it's a ball game."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0032"]
[OnName num="amane"]
"Do you play soccer?
[cpg cn=true]

[OnName num="shinzi"]
"Oh, no. I don't like it that much. I watch it.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0033"]
[OnName num="amane"]
"Oh, I see.
[cpg cn=true]

When I think about it, it's funny that you say you don't like it that much!　I thought to myself, "It's funny that you said you don't like it that much!" But Amane seemed to find my talk interesting.
[cpg]

[OnName num="shinzi"]
"What about other sports?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0034"]
[OnName num="amane"]
"I don't like it or hate it, but ......"
[cpg cn=true]

In response to my question, Amane twisted his head to think a bit.
[cpg]

[OnName num="shinzi"]
"So, are you with me?　I have a 3 in gym."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0035"]
[OnName num="amane"]
"Oh, ......, same."
[cpg cn=true]

It really doesn't matter, but the fact that you share something with a stranger is enough to create a sense of solidarity.
[cpg]

For example, if you share the same birth month or blood type, it somehow makes things more exciting.
[cpg]

[OnName num="shinzi"]
"It's good to have physical education, but it's not so good without it.
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0036"]
[OnName num="amane"]
"I really think so.
[cpg cn=true]

[OnName num="shinzi"]
"You know those idiots in PE?　Like, if there's no P.E., they don't come.
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0037"]
[OnName num="amane"]
"What?　Who's that?　Couscous.
[cpg cn=true]

Before I knew it, I was trying to say something funny while looking for Amane 's reaction.
[cpg]

It's very strange, because I usually don't act like that when I'm talking to anyone.
[cpg]

Now I seem to be somewhat excited.
[cpg]

[OnName num="shinzi"]
"'So, what's your favorite subject?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0038"]
[OnName num="amane"]
"Let's see, ......, let's see, ......."
[cpg cn=true]

[OnName num="shinzi"]
"Not really?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0039"]
[OnName num="amane"]
"Hmmm ...... all of them, maybe I don't like or dislike ......
[cpg cn=true]

[OnName num="shinzi"]
"Well, I'm with you!
[cpg cn=true]

I'm the same way.
[cpg]

I don't like classes in the first place.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

I was starting to feel happy that I had more and more things in common with her.
[cpg]

[OnName num="shinzi"]
"So, let's go to the science lab next.
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0040"]
[OnName num="amane"]
"Yes."
[cpg cn=true]

;//×【ＢＧ】学園　体育館渡り廊下　午前　雨

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye2"]
[BG f="b_ex_sk_t2_1.ui" time=1000]
;//【ＢＧ】空　午前　雨

;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

;//loop
[SE f="se007" loop=true]
;//【ＳＥ】雨の音

;//[FG f="amane_p6_02_a.ui" method="change_1" pos="2/3" time=800]

The corridor from the gymnasium to the science lab faces outside and is only partially covered with cheap tin.
[cpg]

This is why I was curious about the state of the rain as I could inevitably see the schoolyard.
[cpg]

[OnName num="shinzi"]
"It's getting heavier and heavier. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0041"]
[OnName num="amane"]
"'..................'
[cpg cn=true]

It certainly sounded like I was talking to myself, but Amane was mute at my words.
[cpg]

I knew it, and I wondered if he was worried about getting wet in the rain.
[cpg]

At that time, I thought it was normal.
[cpg]

[OnName num="shinzi"]
"The science room also has a unique atmosphere.
[cpg cn=true]

;//[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0042"]
[OnName num="amane"]
"Is that so?　I'm looking forward to it.
[cpg cn=true]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]



;//loop
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BG f="b_s_sr_t1_0.ui" time=1000]
;//【ＢＧ】学園　理科室　午前　雨


[OnName num="shinzi"]
"Isn't it amazing?　The number of specimens!
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0043"]
[OnName num="amane"]
"Wow. ......
[cpg cn=true]

It seems that there are many rich children in our school and there is a system of donation.
[cpg]

This is a great way to get the most out of your time and money.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0044"]
[OnName num="amane"]
"It looks like some kind of laboratory.
[cpg cn=true]

[OnName num="shinzi"]
"I hear it's a real treat for those who are interested.
[cpg cn=true]

I explained as we walked past the specimen shelves.
[cpg]

[OnName num="shinzi"]
"This area is like Jellyfish-something , and this is ....... And this is fish-something ......, which is only found in hot countries."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0045"]
[OnName num="amane"]
"Pfft ...... couscous."
[cpg cn=true]

Amane , who had been listening to my explanation, suddenly burst out laughing.
[cpg]

[OnName num="shinzi"]
"What's that?
[cpg cn=true]

;//[FACE method="change_7" pos="2/3"]
[FG f="amane_p6_02_a.ui" method="change_2" pos="2/3" time=800]


[WAIT time=100]
[VOICE f="Amane0046"]
[OnName num="amane"]
"I don't know anything about some nonsense ......."
[cpg cn=true]

[OnName num="shinzi"]
"Aha!　That's right!
[cpg cn=true]

I laughed myself into a frenzy.
[cpg]

In fact, it would have been nice if I could have said something cool like, "This is from South Africa," but unfortunately I didn't have that kind of knowledge.
[cpg]

[OnName num="shinzi"]
"If it had come to this, I should have studied harder.
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0047"]
[OnName num="amane"]
"What do you mean by this?"
[cpg cn=true]

Amane I'm not sure what to make of this.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll be happy to know that I'm not the only one who has a problem with that.
[cpg cn=true]

;//[FACE method="change_5" pos="2/3"]
[FG f="amane_p6_02_a.ui" method="change_5" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane0048"]
[OnName num="amane"]
"Eh...?"
[cpg cn=true]

[OnName num="shinzi"]
"What...?"
[cpg cn=true]

For a moment, Amane looked confused, and I panicked a little.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

But it seems that this was an unfounded fear. Amane is ......
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0049"]
[OnName num="amane"]
"I ...... am not cute. ......"
[cpg cn=true]

I'm not a pretty face," he said, turning over with a grin.
[cpg]

[OnName num="shinzi"]
"Oh, no!　You're cute!"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0050"]
[OnName num="amane"]
"Eh..."
[cpg cn=true]

[OnName num="shinzi"]
"What...?　No!　No, no, no!
[cpg cn=true]

To be honest, this is the first time I've ever had this kind of conversation, or rather I've never felt that a girl I've never met before is cute.
[cpg]

It's also the first time I've ever felt that a girl I've never met was cute, and I've never had a reaction like this, so I can't help but be impatient.
[cpg]

[FG f="amane_p5_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0051"]
[OnName num="amane"]
"I'm sorry, I'm sorry. I've never had anyone say that to me before. ......"
[cpg cn=true]

[OnName num="shinzi"]
"Oh, I've never heard anyone say that before either. ......"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0052"]
[OnName num="amane"]
"What?
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0053"]
[OnName num="amane"]
"Oh, thank you so much. ......
[cpg cn=true]

[OnName num="shinzi"]
"Oh, you're welcome. ......
[cpg cn=true]

In my head, I thought, "What the ...... hell is this?" and then Amane seemed to think so too. ......
[cpg]

[FG f="amane_p6_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0054"]
[OnName num="amane"]
"Pfft........."
[cpg cn=true]

And then he started laughing.
[cpg]

So I couldn't help but ......
[cpg]

[OnName num="shinzi"]
"Ahahahahaha."
[cpg cn=true]

I'm not sure what to say.
[cpg]

It's as awkward as a scene between a man and a woman on an arranged marriage.
[cpg]

But it felt very fresh to me.
[cpg]

I couldn't help but think to myself that I was such a guy.
[cpg]

If it's the first time you've met this girl, you might assume that there's something special about her that you're compatible with.
[cpg]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
;//[BGM f="eye1"]
[BG f="b_s_pa_t1_1.ui" time=1000]
;//【ＢＧ】学園　廊下　午前　雨


After that, I took Amane to various places and finally asked him: "Where else can I see?
[cpg]

[FG f="amane_p6_02_a.ui" method="change_1" pos="2/3" time=800]
[OnName num="shinzi"]
"Is there any other place you want to see?"
[cpg cn=true]

She thought for a moment and said, "Well....
[cpg]

[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0055"]
[OnName num="amane"]
She thought for a moment and said, "Well...the rooftop, then."
[cpg cn=true]

[OnName num="shinzi"]
"The rooftop?　You can usually get there by going up the stairs.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0056"]
[OnName num="amane"]
"Can I have a look?
[cpg cn=true]

[OnName num="shinzi"]
"I don't mind.
[cpg cn=true]

I took Amane to the roof without question.
[cpg]

[SE f="se014"]
;//【ＳＥ】鉄扉開く

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_s_ro_t1_1.ui" time=1000]
;//【ＢＧ】学園　屋上　午前　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、通常】


[OnName num="shinzi"]
"It's raining, so I can't get out. ......
[cpg cn=true]

;//loop
[SE f="se007" loop=true]
;//【ＳＥ】雨


In the event that you have any kind of questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

;//[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0057"]
[OnName num="amane"]
"It's huge. ......
[cpg cn=true]

[OnName num="shinzi"]
"Oh, hey ......"
[cpg cn=true]

Amane In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

[free time=0]
[FG f="amane_p3_02_a.ui" method="change_1" pos="4/3" time=0]
[move from="4/3" to="2/3" ease="easeInOutSine" time=2000]

[SE f="se131"]
;//【ＳＥ】雨の中歩く


Pish...
[cpg]

Clap...
[cpg]

Clap...
[cpg]

The sound of Amane 's feet stepping into the puddle of water was heard, and the pouring rain soaked her more and more.
[cpg]

[OnName num="shinzi"]
"You'll get wet!"
[cpg cn=true]

I said hurriedly, Amane turned a little and ......
[cpg]

[FG f="amane_p4_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0058"]
[OnName num="amane"]
"I'm sure you'll be fine.
[cpg cn=true]

I'm sure you'll be happy to hear that.
[cpg]

[FG f="amane_p3_02_a.ui" method="change_2" pos="2/3" time=800]
In the event that you've got a lot of money, you'll be able to use it to get the most out of your money.
[cpg]

[move from="2/3" to="1/3" ease="easeInOutSine" time=2000]
[SE f="se131"]
;//【ＳＥ】雨の中歩く

I'm not sure what to do.
[cpg]

[FG f="amane_p4_02_a.ui" method="change_2" pos="1/3" time=100]
[WAIT time=100]
[move from="1/3" to="2/3" ease="easeInOutSine" time=2000]

Click, click, click...
[cpg]

The sound of water echoing at regular intervals, like the rhythm of some song.
[cpg]

The wind caresses the rain that has soaked into my uniform, and I am surrounded by a chilly air.
[cpg]

[OnName num="shinzi"]
"'Do you like the rooftop?'
[cpg cn=true]

[FG f="amane_p3_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0059"]
[OnName num="amane"]
"''Hmph. ......''
[cpg cn=true]

Without giving a clear answer to my question, Amane looked up at the sky.
[cpg]

;//[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0060"]
[OnName num="amane"]
"Do you know what It's Raining Song is?
[cpg cn=true]

[OnName num="shinzi"]
" It's Raining Song ?　What's that about?"
[cpg cn=true]

The title didn't ring a bell, so I asked Amane back.
[cpg]

Then ......
[cpg]

[FG f="amane_p4_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0061"]
[OnName num="amane"]
"Ame ame, fure fure, my mother is ......"
[cpg cn=true]

Amane I'm not sure what to make of it, but I'm sure it's a good idea.
[cpg]

[OnName num="shinzi"]
"Oh, that or ......."
[cpg cn=true]

That reminded me of It's Raining Song and I started to sing it myself.
[cpg]

[OnName num="shinzi"]
"I'm happy to welcome you with snake eyes."
[cpg cn=true]

Then Amane turns to me, looking very happy.
[cpg]

[FG f="amane_p3_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0062"]
[OnName num="amane"]
"Yes, yes!"
[cpg cn=true]

And then he narrowed his eyes.
[cpg]

[OnName num="shinzi"]
"It's all pitter-patter, patter, patter, patter, patter."
[cpg cn=true]

;//[FACE method="change_1" pos="2/3"]
[FG f="amane_p4_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0063"]
[OnName num="amane"]
"Yes, yes. You know it, too, Shinji ."
[cpg cn=true]

I sang it all the way through, and Amane looked really happy.
[cpg]

[OnName num="shinzi"]
"Everybody knows it."
[cpg cn=true]

I wasn't sure if he'd learned it in kindergarten or heard it on a children's show when he was younger, but I found it surprising that Amane would be interested in such a nursery rhyme.
[cpg]

;//[FACE method="change_7" pos="2/3"]
[FG f="amane_p3_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0064"]
[OnName num="amane"]
"It doesn't seem like it?"
[cpg cn=true]

[OnName num="shinzi"]
"Really?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0065"]
[OnName num="amane"]
"Because you're the first person ...... who's sung it with me.
[cpg cn=true]

[OnName num="shinzi"]
"Really?"
[cpg cn=true]

I answered smoothly, but the fact that he called me 'you' made my heart pound a little.
[cpg]

Usually, Japanese people don't use the word 'you' very often when they call someone.
[cpg]

If you have a very close relationship with someone, or if you are a close family member, or if you are a teacher and a pupil, or if you are a man and a woman who are at least equals, you probably don't say 'you' very often, do you?
[cpg]

And yet, the fact that he suddenly called me "you" made me experience a kind of mushy feeling.
[cpg]

Well, I guess that's just because I'm not used to women .......
[cpg]

But that made me feel better, and I started singing again, in tune.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to say, but I'm going to say it.
[cpg cn=true]

Then Amane followed happily.
[cpg]

[FG f="amane_p4_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0066"]
[OnName num="amane"]
"I'm so happy to see you with your snake eyes."
[cpg cn=true]

[OnName num="shinzi"]
"Chirp-chirp-chirp, chirp-chirp, chirp-chirp..."
[cpg cn=true]

We sang a nursery rhyme together, which made me feel itchy and happy, and I asked a simple question.
[cpg]

[OnName num="shinzi"]
"What's a snake's eye?
[cpg cn=true]

[FG f="amane_p3_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0067"]
[OnName num="amane"]
"Don't you know?"
[cpg cn=true]

[OnName num="shinzi"]
"I don't know. ......
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0068"]
[OnName num="amane"]
"The snake's eye is a ......
[cpg cn=true]

Amane tilted his head in a slightly troubled way and explained to me in a gentle tone.
[cpg]

[WAIT time=100]
[VOICE f="Amane0069"]
[OnName num="amane"]
"It's an old umbrella, you know?"
[cpg cn=true]

[OnName num="shinzi"]
"An old umbrella?"
[cpg cn=true]

;//↓蛇の目傘の絵を挿入（蛇の目と比較して表示すると面白い）

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0070"]
[OnName num="amane"]
"The old umbrellas had a round pattern in the shape of a band, and the shape resembled a snake's eye, so they were called snake eyes umbrellas.
[cpg cn=true]

[OnName num="shinzi"]
"A snake's-eye umbrella!　It's the umbrella that people in kimonos wear!　I know, I know!
[cpg cn=true]

I jumped up, convinced like an idiot.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0071"]
[OnName num="amane"]
"I don't think it has anything to do with kimonos. ......
[cpg cn=true]

[OnName num="shinzi"]
"But it's a snake's eye umbrella!　Oh, now I understand for the first time!
[cpg cn=true]

Song lyrics, whether in English or Japanese, can be sung without being convinced.
[cpg]

So, even if you don't know the meaning of a song, you can remember it by the sound and don't know it well.
[cpg]

[OnName num="shinzi"]
"You're so knowledgeable, Amane -chan!"
[cpg cn=true]

I was a little impressed and complimented Amane .
[cpg]

I was a little impressed and complimented Amane , but flapped her hands in humility at my compliment.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0072"]
[OnName num="amane"]
"It's not me, it's what my mom taught me,......."
[cpg cn=true]


;//【雨、通常】

;//loop
[SE f="se007" loop=true]
;//【ＳＥ】雨（少し強くなる）


That's when I heard the rain pattering harder against the concrete of the rooftop.
[cpg]

When I got there, I finally remembered that Amane I'd been soaking wet for a while now.
[cpg]

[OnName num="shinzi"]
"Oh no, it's really starting to pour. Come on in!"
[cpg cn=true]

I urged him back inside.
[cpg]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[free time=400]
[BG f="black.ui" time=400]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_la_t1_0.ui" time=1000]
;//【ＢＧ】学園　階段、踊り場　午前　雨


[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]

[OnName num="shinzi"]
"Oh, ......."
[cpg cn=true]

In front of the soaking wet Amane , I regretted violently.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]
;//@
[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0073"]
[OnName num="amane"]
"....................."
[cpg cn=true]

Amane I'm not sure what to make of it, but I'm sure it's a good idea.
[cpg]

;//[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[OnName num="shinzi"]
"Let's go back to the infirmary one more time.
[cpg cn=true]

This time, I must get a rental jersey or uniform.
[cpg]

I thought so, but Amane refused to do so.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0074"]
[OnName num="amane"]
"It's okay. It's not cold, and you'll dry off quickly in the classroom.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, but ......".
[cpg cn=true]

From my own experience, leaving wet clothes on can cause you to catch a cold, but I was still worried, so I told Amane .
[cpg]

[OnName num="shinzi"]
"Then you should at least wipe it off with a towel or something,.......
[cpg cn=true]

But Amane refused even that.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0075"]
[OnName num="amane"]
"I'm really fine. I'm really fine, I'm even comfortable with this, don't worry.
[cpg cn=true]

Comfortable ......?
[cpg]

You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

Or do girls like that kind of feeling?
[cpg]

In any case, you can't push what you think is good for you.
[cpg]

[OnName num="shinzi"]
"So, ......, should we head back to class?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0076"]
[OnName num="amane"]
"Yes. Thanks for showing me around.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah.
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0077"]
[OnName num="amane"]
"Oh, and I'll see you at lunch at .......
[cpg cn=true]

[OnName num="shinzi"]
"Buying!　I'll take care of it!
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

The fact that Amane brought up the idea of lunch suggests that they don't feel bad about me.
[cpg]

I'm glad to hear that you might have even taken a liking to me.
[cpg]

When lunchtime comes, I can take Amane to the purchasing area again.
[cpg]

We can talk again about my recommendations, what she likes, and more.
[cpg]

I was already starting to feel excited about the next few hours.
[cpg]

I went to ...... and didn't care that I had forgotten one thing about lunch.
[cpg]

;//エフェクト
;//loop
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=900]

[BG f="b_s_3f_t1_0.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午前　曇り


[OnName num="teacher"]
"And because there is, ......
[cpg cn=true]

Back in the classroom, teachers and students alike glanced Amane at each other as they began taking classes.
[cpg]

[BG f="b_s_3f_t1_0_Lup.ui" time=800]

[FG f="amane_p6_02_a.ui" method="change_1" pos="2/3" time=1000]
[WAIT time=100]
[VOICE f="Amane0078"]
[OnName num="amane"]
".................."
[cpg cn=true]

Amane Shizuku In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

[OnName num="female_student"]
"Are you okay with this? ......
[cpg cn=true]

[OnName num="male_student"]
"What did you go to the infirmary for? ......
[cpg cn=true]

You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

[free time=800]

[SE f="se009"]
;//【ＳＥ】チャイム


[SE f="se053"]
;//【ＳＥ】ザワザワ


[OnName num="female_student1"]
"You can find a lot more information on the web.
[cpg cn=true]

[OnName num="female_student2"]
"Mizushima!　Where did you take Satonaka ?
[cpg cn=true]

At recess, I was under fire from the whole class.
[cpg]

[OnName num="male_student1"]
"What were you doing in the infirmary?"
[cpg cn=true]

[OnName num="male_student2"]
"Where were you taking the new student?
[cpg cn=true]

[OnName num="shinzi"]
"Well, that's, um, ......
[cpg cn=true]

In the event that you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

However, Amane is ......
[cpg]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0079"]
[OnName num="amane"]
"It's not the same. You will find a lot of people who are looking for a new way to live. In the event that you've got a lot of money, you'll be able to take advantage of it. Mizushima-kun stopped me.
[cpg cn=true]

And he protected me.
[cpg]

So, as expected, my classmates couldn't take it any further, and after that, they kept asking me "Aren't you cold? or "Can I lend you my jersey?" and "Can I lend you a jersey?" They exchanged comments about how much they cared about Amane .
[cpg]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=800]

[SE f="se009"]
;//【ＳＥ】チャイム

So, the second and third periods passed, Shizuku did not fall out of Amane 's hair, and ...... the lunch break came.
[cpg]

[BG f="b_s_3f_t1_0.ui" time=800]



[WAIT time=2000]

[SE f="se053"]
;//【ＳＥ】ザワザワ


[OnName num="female_student1"]
"I'm not sure what to say.　Purchase?
[cpg cn=true]

[OnName num="female_student2"]
"O-bento?"
[cpg cn=true]

[OnName num="female_student1"]
"Seriously?　I'll get it for you, just wait for me.
[cpg cn=true]

The classroom is filled with an atmosphere of excitement unlike any other time of the day.
[cpg]

[OnName num="male_student1"]
"I'm going to get some tea from the vending machine.
[cpg cn=true]

[OnName num="male_student2"]
"I'll go to the vending machine and get some tea.
[cpg cn=true]

This is the time when everyone is happy to satisfy their hunger with the lunch they brought from home or purchased from the store.
[cpg]

Amane In the event that you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

I want to show my new student Amane around my prized purchase and have a good conversation with him again like we did in the morning.
[cpg]

That's all I could think about.
[cpg]

[BG f="b_s_3f_t1_0_Lup.ui" time=800]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0080"]
[OnName num="amane"]
".................."
[cpg cn=true]

It was in this mood that I looked at Amane and saw that he had just put his class notes away on his desk and was putting away his writing materials.
[cpg]

It's just the right time to call out to them.
[cpg]

[OnName num="shinzi"]
"'Ama ......'
[cpg cn=true]


The moment I breathed in a small amount of air for Amane and turned it into a voice ......
[cpg]

;//[FO pos="2/3" time=0]
[BG f="b_s_3f_t1_0_deskup.ui" time=0]

[FG f="youko_p5_01_a.ui" method="change_2" pos="2/3" time=0]
[WAIT time=100]
[VOICE f="Youko0015"]
[OnName num="youko"]
"Shhhh..."
[cpg cn=true]

[OnName num="shinzi"]
"I don't know.
[cpg cn=true]

This is a great way to make sure that you get the most out of your time with us.
[cpg]

[OnName num="shinzi"]
"What, you again? ......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0016"]
[OnName num="youko"]
"What do you mean again?
[cpg cn=true]

[SE f="se011"]
;//【ＳＥ】バンッ（弁当箱が机に置かれる）


In the event that you're fed up with Yoko entering the classroom without permission, a mysterious package was placed on my desk.
[cpg]

[OnName num="shinzi"]
"What is this?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0017"]
[OnName num="youko"]
"I'm sure you're not the only one.　It's a good idea.　I've made one for you as well.
[cpg cn=true]

[OnName num="shinzi"]
"Bento?
[cpg cn=true]

[OnName num="male_student"]
"Huh?　A bento for your loving wife?　I'm jealous.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0018"]
[OnName num="youko"]
"Yeah.
[cpg cn=true]

[OnName num="shinzi"]
"............"
[cpg cn=true]

I was sick and tired of my classmates whistling here and there, as well as Yoko who didn't seem to mind the teasing.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[OnName num="shinzi"]
"You know, .......
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

The moment you think you're going to complain about the fact that you're not even dating anymore ......, a voice calls out to you from behind.
[cpg]



[move from="2/3" to="2/5" ease="easeInOutSine" time=800]
;//move

[FG f="amane_p5_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Amane0081"]
[OnName num="amane"]
" Shinji "
[cpg cn=true]

[OnName num="shinzi"]
"Oh, Amane -chan."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0082"]
[OnName num="amane"]
"Purchasing, can we go...?"
[cpg cn=true]

[OnName num="shinzi"]
"Oh, yeah!
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0019"]
[OnName num="youko"]
"Who's ......?"
[cpg cn=true]

Amane I'm not sure if this is a good idea or not, but it's a good idea.
[cpg]

Yoko This is a great way to make sure you are getting the most out of your investment.
[cpg]

[OnName num="shinzi"]
Amane Satonaka "It's a great way to make sure you get the most out of your time with your family.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0020"]
[OnName num="youko"]
"Oh, you're a new student?
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0083"]
[OnName num="amane"]
"Hello. Nice to meet you.
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0021"]
[OnName num="youko"]
"My name is Yoko Minegishi and I'm in Class A. Nice to meet you!
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Amane0084"]
[OnName num="amane"]
"Nice to meet you.
[cpg cn=true]

Yoko smiles at Amane with his natural vivacity.
[cpg]

Amane I'm not sure what to make of that.
[cpg]

The two side by side, like the sun and the moon, seem to be creatures of completely different natures.
[cpg]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0022"]
[OnName num="youko"]
"You know, Satonaka ."
[cpg cn=true]

I'm not sure what to make of it.
[cpg]

It's a great way to make sure you get the most out of your time with your family.
[cpg]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0023"]
[OnName num="youko"]
"What school did you come from?　Why are you here at such an inopportune time?　What does your father do for a living?
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0085"]
[OnName num="amane"]
"'Eh, .......
[cpg cn=true]


[OnName num="shinzi"]
"Stop it. That's rude!
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0024"]
[OnName num="youko"]
"What?
[cpg cn=true]

[OnName num="shinzi"]
"What's ......?
[cpg cn=true]

I stopped Yoko remembering the Amane in the infirmary, but Yoko was smiling as if it was natural.
[cpg]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0025"]
[OnName num="youko"]
"It's good to know that it is the fate of new students to be questioned. See?　 Satonaka "
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Amane0086"]
[OnName num="amane"]
"Oh, yeah. ......"
[cpg cn=true]

[OnName num="shinzi"]
"Oh, Amane , you need to go buy lunch!　I'll show you where to buy it!
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0087"]
[OnName num="amane"]
"Yeah, but .........
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0026"]
[OnName num="youko"]
"Buy?　Wait a minute, Shinji !　Where's my lunch?
[cpg cn=true]

[OnName num="shinzi"]
"I'm the class president and I have to take care of the new students!　If you want to eat, you have to eat your lunch.
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0027"]
[OnName num="youko"]
"What's that!　Hey, hey!
[cpg cn=true]

[free time=800]

I shook off the troublesome Yoko and left the classroom along with Amane .
[cpg]

[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=900]

[BG f="b_s_pa_t2_1.ui" time=800]
;//【ＢＧ】学園　廊下　午後　雨


[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=1000]
[WAIT time=100]
[VOICE f="Amane0088"]
[OnName num="amane"]
"Is that ...... okay?
[cpg cn=true]

[OnName num="shinzi"]
"What?"
[cpg cn=true]

Amane You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

As I suspected, Amane was a bit puzzled by my "what? I'm not sure what to do.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0089"]
[OnName num="amane"]
"I think that person is your girlfriend,.......
[cpg cn=true]

[OnName num="shinzi"]
"It's not like that.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0090"]
[OnName num="amane"]
"Are you sure it's ......?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah. Nothing to do with it.
[cpg cn=true]

[FO pos="2/3" time=800]

The word "nothing" may be a bit of a misnomer, but it was annoying to explain.
[cpg]

It is true that Yoko may be my ex-girlfriend, but in reality, our relationship is not that great.
[cpg]

"In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

So, to be honest, I was interested in the relationship of a lover, and I was also very interested in the physical relationship derived from it, but more than that, I thought it was troublesome.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

But at least I couldn't have such feelings towards Yoko .
[cpg]

So, I asked him to break up with me when I thought it was troublesome.
[cpg]

At first, I thought that I might like him if I went out with him, but it was not like that.
[cpg]

It may be an excuse to say that I don't know anything about it, but I still don't understand what love is.
[cpg]

However, for some reason, at this time, I really disliked the fact that Amane misunderstood that I had a girlfriend.
[cpg]

It's a good idea to have a good idea of what you're looking for and how to get there.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[OnName num="shinzi"]
"I'm sure it's because I'm not familiar with such things.　The most popular one is yakisoba bread."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0091"]
[OnName num="amane"]
"Is that so?"
[cpg cn=true]

I wonder if I made him that wary.
[cpg]

Amane I'm not sure what to make of it.
[cpg]

This is a great way to make sure you are getting the most out of your investment.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll be pleased to know that I'm not the only one.　If you don't eat this, it's not worth coming to Shuei !"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0092"]
[OnName num="amane"]
"Well, I think I'll have the Shinji recommendation today.
[cpg cn=true]

[OnName num="shinzi"]
"You should do that!　Come on, they're gonna sell out!
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_2" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane0093"]
[OnName num="amane"]
"Okay.
[cpg cn=true]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//【ＢＧ】ブラックアウト


[FG f="amane_p2_01_a.ui" method="change_2" pos="2/3" time=800]
Me and Amane hurried to the purchase together.
[cpg]

In the event you're not sure what you're looking for, you'll be able to find out more about it by visiting our website.
[cpg]

I hate it when people use honorifics because they care about other people.
[cpg]

I just want to have a normal, fun conversation with this Amane girl!
[cpg]

That's all I was thinking at the time.
[cpg]

Even if there was a little bit of fondness or ulterior motive, I was not that conscious of it.
[cpg]

But from this day on, ......
[cpg]

The gears of my fate had begun to go haywire,.......
[cpg]

[FG f="amane_p7_01_a.ui" method="change_1" pos="2/3" time=400]

[WAIT time=1200]

[FACE method="change_2" pos="2/3"]

[WAIT time=400]
[free time=800]
[BG f="black.ui" time=800]
[WAIT time=900]
[BGM f="eye1"]
[BG f="b_s_pa_t2_1.ui" time=800]
;//【ＢＧ】学園　廊下　午後　雨


[OnName num="shinzi"]
"I'm sorry~......"
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=1000]
[WAIT time=100]
[VOICE f="Amane0094"]
[OnName num="amane"]
"It's not Shinji my fault. ......"
[cpg cn=true]

Yoko In the event that you're looking for the best way to get the most out of your business, then you'll want to look at the following.
[cpg]

In the event that you've got a lot of time, you'll be able to take a look at a few of the best ways to get the most out of your home.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0095"]
[OnName num="amane"]
"Really."
[cpg cn=true]

Amane In the event that you have any questions regarding where by and how to use it, you can contact us at our own web site.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0096"]
[OnName num="amane"]
"It's a great way to make sure you get the most out of your time with your family. You can always go to ......."
[cpg cn=true]

[OnName num="shinzi"]
"Hmm?
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0097"]
[OnName num="amane"]
" Shinji , what are you doing for lunch?　Well, ......, if it's me you're after, don't worry about it, just go.
[cpg cn=true]

[OnName num="shinzi"]
"Go where?"
[cpg cn=true]

When I asked him back, Amane hesitated a bit awkwardly and mentioned Yoko .
[cpg]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0098"]
[OnName num="amane"]
Minegishi "You can find a lot of people who are looking for the best way to get the most out of their lives.　I'll take your lunch ......."
[cpg cn=true]

[OnName num="shinzi"]
"Oh!"
[cpg cn=true]

Of course, Amane was probably concerned about that lunchbox.
[cpg]

In the event that you're not sure what you're looking for, there are a few things you can do.
[cpg]

If you do that, Yoko is sure to turn on you like a demon.
[cpg]

[OnName num="shinzi"]
"It's okay, you know. First of all, you need to get lunch for Amane , so let's go shopping together.
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0099"]
[OnName num="amane"]
"But Aunt ...... says there's nothing left.
[cpg cn=true]

I told the purchasing lady, "It's too late to come now!" I'm not sure what to make of that.
[cpg]

But I still have a few tricks up my sleeve.
[cpg]

[OnName num="shinzi"]
"Actually, you can go to the convenience store in the back.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0100"]
[OnName num="amane"]
"Convenience store?　Can I go out there?
[cpg cn=true]

[OnName num="shinzi"]
"Well, actually, no. ......
[cpg cn=true]

In the event that you have any questions regarding where and how to use the internet, please do not hesitate to contact us.
[cpg]

In the event that you're not sure what to do, you can always try to find out more about it.
[cpg]

[OnName num="shinzi"]
"Let's go.
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0101"]
[OnName num="amane"]
"Uh, yeah. ......"
[cpg cn=true]

Amane , who does not know how to do it, has no choice but to obey me and follow me with trepidation.
[cpg]

[SE f="se038"]
;//【ＳＥ】小走り

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye2"]
[BG f="b_s_en_t1_1.ui" time=1000]
;//【ＢＧ】学園　昇降口　昼　曇り

;//loop
[SE f="se006" loop=true]
;//【ＳＥ】雨の音


[OnName num="shinzi"]
"Oh, my God. ......
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0102"]
[OnName num="amane"]
"What's wrong?
[cpg cn=true]

[OnName num="shinzi"]
"I didn't have an umbrella with me. ......
[cpg cn=true]

It is still raining outside as you take off your shoes in the shoe box.
[cpg]

[OnName num="shinzi"]
"You can find a lot of people who are looking for a great deal more than just a great deal more.
[cpg cn=true]

It's a good idea to have a good idea of what you're doing.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0103"]
[OnName num="amane"]
"You can't do that. ......
[cpg cn=true]

[OnName num="shinzi"]
"It's fine. You can put it back later.
[cpg cn=true]

I think Amane is a serious girl.
[cpg]

I've been trying to stop myself from using someone else's umbrella.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0104"]
[OnName num="amane"]
"If it rains like this, you don't need an umbrella."
[cpg cn=true]

[OnName num="shinzi"]
"I'm not so sure. ......
[cpg cn=true]

Well, maybe it's good that Amane is already wet.
[cpg]

If so, I'm hesitant to put up an umbrella alone.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll agree. Then let's run to the convenience store.
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0105"]
[OnName num="amane"]
"Let's do that.
[cpg cn=true]

We started to run into the rain together.
[cpg]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_ex_sz_t1_1.ui" time=1000]
;//【ＢＧ】通学路　午後　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、通常】


;//[ps se="se010"]
;//loop
[SE f="se006" loop=true]
;//【ＳＥ】雨の中走る





[OnName num="shinzi"]
"Wow, it's raining more than I thought!"
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0106"]
[OnName num="amane"]
"It's not that bad.
[cpg cn=true]

[OnName num="shinzi"]
"Really?
[cpg cn=true]

It was raining pretty hard for me, but Amane had a refreshing look on his face.
[cpg]

;//[ps se="se010"]

[SE f="se132"]
;//【ＳＥ】雨の中走る





[OnName num="shinzi"]
"Oh, that's ...... you.
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0107"]
[OnName num="amane"]
"What?
[cpg cn=true]

[OnName num="shinzi"]
"It's dangerous!
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0108"]
[OnName num="amane"]
"Oh, ......."
[cpg cn=true]

[SE f="se063"]
;//【ＳＥ】トラック走行


When I noticed a truck running at a high speed in the rain, I grabbed Amane 's arm and pulled him to me.
[cpg]

Amane This is a great way to make sure you are getting the most out of your vacation.
[cpg]

[OnName num="shinzi"]
".........."
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0109"]
[OnName num="amane"]
"I'm sorry.
[cpg cn=true]

[OnName num="shinzi"]
"No, no, no, no, no, no, no, no. ......
[cpg cn=true]

Amane In the event that you have any kind of questions regarding where and how to use the internet, you can contact us at our own web site.
[cpg]

This is a great way to get the most out of your business.
[cpg]

It's not a person,......, it's a fairy.
[cpg]

[OnName num="shinzi"]
"Did you feel any pain?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0110"]
[OnName num="amane"]
"I'm not,....... I'm Shinji here ......."
[cpg cn=true]

Amane You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll be happy to know that I'm not the only one.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0111"]
[OnName num="amane"]
"I'm glad ......
[cpg cn=true]

[OnName num="shinzi"]
"Convenience store, there ......
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0112"]
[OnName num="amane"]
"Oh, yes. ......
[cpg cn=true]

Amane In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//loop
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_ex_co_t1_0.ui" time=1000]
;//【ＢＧ】コンビニ　夕方　雨


[SE f="se012"]
;//【ＳＥ】コンビニドアの開閉チャイム


[OnName num="sales_clerk"]
"I'm sure you'll agree.
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

I knew what he was thinking and carefully brushed the water off my shoes, wiping as much as I could with the mat.
[cpg]

[OnName num="shinzi"]
"What do you eat?"
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0113"]
[OnName num="amane"]
"I m all ...... things."
[cpg cn=true]

I was a little curious as to what a girl like Amane would eat.
[cpg]

She is very thin and seems to eat only low calorie things like salads and somen noodles.
[cpg]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0114"]
[OnName num="amane"]
"What about Shinji ?"
[cpg cn=true]

[OnName num="shinzi"]
"I'm ......, yakiniku bento.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0115"]
[OnName num="amane"]
"You like meat?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah.
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0116"]
[OnName num="amane"]
"Well, I think I'll go with .......
[cpg cn=true]

[OnName num="shinzi"]
"Oh, my God, that?
[cpg cn=true]

What Amane had chosen was far beyond my imagination.
[cpg]

[OnName num="shinzi"]
"It's called a soy bar .......
[cpg cn=true]

A cookie bar with only calories, which is equivalent to emergency food.
[cpg]

It's not going to fill you up at all, either in size or in name.
[cpg]

[OnName num="shinzi"]
"Um, what else?"
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0117"]
[OnName num="amane"]
"Huh?　Just this one. ......"
[cpg cn=true]

[OnName num="shinzi"]
"That's all you got?
[cpg cn=true]

I'm afraid so.
[cpg]

Maybe girls are always on a diet, but I can't believe that's all they have.
[cpg]

[OnName num="shinzi"]
"Are you on a diet?
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0118"]
[OnName num="amane"]
"No, but ......
[cpg cn=true]

[OnName num="shinzi"]
"You're not hungry?
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0119"]
[OnName num="amane"]
"Not really. ......
[cpg cn=true]

I was so surprised that I asked a bunch of questions, and then I realized.
[cpg]

This is the same as Yoko .
[cpg]

[OnName num="shinzi"]
"I'm sorry, I was just so surprised. ......"
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0120"]
[OnName num="amane"]
"I'm not very attached to eating. ......"
[cpg cn=true]

Amane mumbles apologetically.
[cpg]

[OnName num="shinzi"]
"A few!　It's a good thing, then. But I'm worried that I won't be able to make it through the afternoon with just that.
[cpg cn=true]

Amane This is a great way to get the most out of your time and money.
[cpg]

[FG f="amane_p5_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0121"]
[OnName num="amane"]
"Thank you. But it's always like this.
[cpg cn=true]

[OnName num="shinzi"]
"So...yeah, ......."
[cpg cn=true]

More and more, Amane is looking more and more like a fairy.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="shinzi"]
"What about dessert?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0122"]
[OnName num="amane"]
"'Only if Shinji eats it.
[cpg cn=true]

[OnName num="shinzi"]
"Really?　Then let's buy some pastries.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0123"]
[OnName num="amane"]
"What?
[cpg cn=true]

[OnName num="shinzi"]
"What?"
[cpg cn=true]

This time, Amane is the one who raises his voice in surprise.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0124"]
[OnName num="amane"]
"Bread for ...... dessert?"
[cpg cn=true]

[OnName num="shinzi"]
"What, no ......?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0125"]
[OnName num="amane"]
"Because it's ...... bread.
[cpg cn=true]

[OnName num="shinzi"]
"But it's sweet. ......
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0126"]
[OnName num="amane"]
"It's sweet, but it's ...... bread.
[cpg cn=true]

[OnName num="shinzi"]
"What?　Is that weird?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0127"]
[OnName num="amane"]
"You're having dinner and bread is ...... dessert?
[cpg cn=true]

[OnName num="shinzi"]
"It's not like bread. It's sweet. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0128"]
[OnName num="amane"]
"It's ...................
[cpg cn=true]

[OnName num="shinzi"]
".................."
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0129"]
[OnName num="amane"]
"...... Pfft!
[cpg cn=true]

It was like we were going in circles, we were looking at each other and blowing up at the same time.
[cpg]

[OnName num="shinzi"]
"Hahahahahaha!"
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_2" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane0130"]
[OnName num="amane"]
" Shinji is still funny."
[cpg cn=true]

I'm sure you'll be pleased to know that I'm not the only one who has a problem with this. Amane says so, and puts the lunch box and pastries I had in my hand in the basket.
[cpg]

[OnName num="sales_clerk"]
"It's a great way to make sure you're getting the most out of your money.
[cpg cn=true]

[SE f="se066"]
;//【ＳＥ】バーコード読む


This is a great way to get the most out of your time and money.
[cpg]

[OnName num="sales_clerk"]
"Would you like to heat up your bento?
[cpg cn=true]

[OnName num="shinzi"]
"Oh, it's fine.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Amane0131"]
[OnName num="amane"]
"Is it good?
[cpg cn=true]

[OnName num="shinzi"]
"No. It's too much trouble. It's too much trouble.
[cpg cn=true]

[OnName num="sales_clerk"]
"Your bill will be 890 yen.
[cpg cn=true]

[OnName num="shinzi"]
"Oops. ......
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0132"]
[OnName num="amane"]
"Here.
[cpg cn=true]

I was too busy talking to take out my wallet, and Amane held something out to the clerk.
[cpg]

[OnName num="sales_clerk"]
"It's a great way to make sure you get the most out of your vacation.
[cpg cn=true]

[OnName num="shinzi"]
"I'm sorry.
[cpg cn=true]

[SE f="se066"]
;//【ＳＥ】ピッ


[FO pos="2/3" time=800]

[OnName num="sales_clerk"]
"Thank you very much.
[cpg cn=true]

[SE f="se064"]
;//【ＳＥ】ビニール袋（ガサッ）


[OnName num="shinzi"]
"Oh, thank you.
[cpg cn=true]

I hurriedly took the plastic bag and looked at Amane again.
[cpg]

[OnName num="shinzi"]
"Sorry, how much was it for me?
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0133"]
[OnName num="amane"]
"Oh, it's okay.
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

Amane This is a great way to get the most out of your time and money.
[cpg]

[OnName num="shinzi"]
"'Yes, good is ...... it?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0134"]
[OnName num="amane"]
"It's a great way to thank me for all the help I've given you.
[cpg cn=true]

[OnName num="shinzi"]
"No, you can't do that!
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0135"]
[OnName num="amane"]
"I'd have to do better than that, but .........
[cpg cn=true]

[OnName num="shinzi"]
"What are you talking about?
[cpg cn=true]

In the event that you're not sure what to do, you may want to check out the website.
[cpg]

In the event that you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

[OnName num="shinzi"]
"It's not good!
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0136"]
[OnName num="amane"]
"It's fine. ......
[cpg cn=true]

[OnName num="shinzi"]
"No!
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0137"]
[OnName num="amane"]
"Yeah, ......?
[cpg cn=true]

[OnName num="shinzi"]
"Yes!
[cpg cn=true]

I was in a hurry to get my wallet out and put all the change out on my hand. ......
[cpg]

[OnName num="shinzi"]
"It's not enough. ......
[cpg cn=true]

It's a great way to make sure you get the most out of your money.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll get it back next time.
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0138"]
[OnName num="amane"]
"Then ...... yes.
[cpg cn=true]

Amane In the event that you're not convinced that you're going to be able to do this, you'll be able to go back into the rain.
[cpg]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_ex_sz_t2_1.ui" time=1000]
;//【ＢＧ】通学路　夕方　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、通常】

;//loop
[SE f="se006" loop=true]
[WAIT time=1000]

[SE f="se131"]
;//【ＳＥ】雨



;//【ＳＥ】雨の中歩く





In the event that you're not sure what to do, you may want to check with your doctor.
[cpg]

[OnName num="shinzi"]
"You have a card, right?
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0139"]
[OnName num="amane"]
"Yeah.
[cpg cn=true]

[OnName num="shinzi"]
"That's awesome.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0140"]
[OnName num="amane"]
"Yeah, ......?
[cpg cn=true]

[OnName num="shinzi"]
"It's amazing.
[cpg cn=true]

Students usually have a credit card, like a loyalty card or a charge card at a convenience store.
[cpg]

But the one that Amane gave out earlier was a credit card.
[cpg]

I'm not sure if it's a good idea, but it's a good idea.
[cpg]

I'm not sure if he read my thoughts, but Amane muttered an excuse.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0141"]
[OnName num="amane"]
"I often get wet in the rain. ......
[cpg cn=true]

[OnName num="shinzi"]
"Does the bill get soggy?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0142"]
[OnName num="amane"]
"Yes, yes."
[cpg cn=true]

[OnName num="shinzi"]
"I see. ......"
[cpg cn=true]

It's a good idea to take a look at the web site and see what you can find.
[cpg]

In the event that you've got a lot of money to spend, you'll be able to use it for a lot of things.
[cpg]

[OnName num="shinzi"]
"Then, when I return the money, I'll use coins so that it won't get wet!
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0143"]
[OnName num="amane"]
"Eh?　Ah, ......, yes."
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]


[FG f="amane_p6_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0144"]
[OnName num="amane"]
"Couscous .......
[cpg cn=true]

[OnName num="shinzi"]
"Aah!
[cpg cn=true]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト


All of them are coins, but I borrowed a few hundred yen.
[cpg]

I'm not sure what to make of it.
[cpg]

What an idiot I am .......
[cpg]

I was ashamed of my shallowness, but it helped that Amane was laughing at me.
[cpg]

It's weird.
[cpg]

I don't know if I've ever been this ...... kind of character.
[cpg]

;//エフェクト

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_ex_sz_t3_1.ui" time=1000]
;//【ＢＧ】通学路　夜　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、通常】

;//loop
[SE f="se006" loop=true]
;//【ＳＥ】さっきより小降りの雨


[OnName num="shinzi"]
"It's getting a little late.
[cpg cn=true]

Now I'm on my way home in the light rain.
[cpg]

Amane It's a good idea to have a good idea of what you're looking for.
[cpg]

As you walk down the road to your home, all you can think about is what happened today... her.
[cpg]

[OnName num="shinzi"]
"Heh, ......."
[cpg cn=true]

It's a little uncool, but it makes me smile when I think about what happened today.
[cpg]

Amane It's a great way to make sure you're getting the most out of your vacation.
[cpg]

Tomorrow, we can meet again at the school. I'm not sure if it's a good idea, but it's a good idea.
[cpg]

;//エフェクト
;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//loop
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BGM f="healing"]

[BG f="b_si_d_t3_1.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　夜　雨
[WAIT time=1000]



[FG f="yukika_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yukika0001"]
[OnName num="yukika"]
"You're late!"
[cpg cn=true]

[OnName num="shinzi"]
"Huh?　 Yukika sister, you're here?
[cpg cn=true]

[FO pos="4/5" time=0]

[FG f="yukika_p5_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0002"]
[OnName num="yukika"]
"I'm not ...... here. Where did you stop off?"
[cpg cn=true]

[free time=800]
[FG f="yukika_p1_01_a.ui" method="change_1" pos="2/3" time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
When I got home, my cousin Yukika sister was there.
[cpg]


This is a great way to make sure you get the most out of your vacation.
[cpg]

[free time=800]
[FG f="yukika_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[BG f="b_si_d_t3_1.ui" time=800]
[WAIT time=1000]

[OnName num="shinzi"]
"Hey,.......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0003"]
[OnName num="yukika"]
"I made you a hamburger today. You're going to eat it, right?"
[cpg cn=true]

[OnName num="shinzi"]
"Eat it!
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0004"]
[OnName num="yukika"]
"Go wash your hands.
[cpg cn=true]

[OnName num="shinzi"]
"Okay.
[cpg cn=true]

[FO pos="2/3" time=800]
[BG f="black.ui" time=800]

I'm not sure if you'll be able to find the right one for you.
[cpg]

This is why Yukika sister sometimes cooks meals for us.
[cpg]

It's no exaggeration to say that I owe my growth to my Yukika sister, because she has been doing this for years.
[cpg]

[BG f="b_si_d_t3_1_up.ui" time=800]

[OnName num="shinzi"]
"I'll be back.
[cpg cn=true]

[FG f="yukika_p5_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yukika0005"]
[OnName num="yukika"]
"Yes, please eat ......, Shinji !　You've got wet socks!
[cpg cn=true]

[OnName num="shinzi"]
"Oh, shit. ......
[cpg cn=true]

Seeing the footprints on the floor, the Yukika sister raises a crazy voice.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0006"]
[OnName num="yukika"]
"What are you doing ......? Take it off.
[cpg cn=true]

[OnName num="shinzi"]
"I'm sorry.
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0007"]
[OnName num="yukika"]
"Oh, ...... you'll always be a child.
[cpg cn=true]

It's a good idea to have a good idea of what you're doing.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0008"]
[OnName num="yukika"]
"You're so dirty. ......
[cpg cn=true]

[OnName num="shinzi"]
"Sorry.
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0009"]
[OnName num="yukika"]
"It's okay, I'll run the washing machine and go home. I'll run the washing machine and come back, but you have to run the dryer yourself.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, okay. You're not eating with us?
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0010"]
[OnName num="yukika"]
"Um, ......, I don't know.
[cpg cn=true]

[OnName num="shinzi"]
"Let's eat.
[cpg cn=true]

[FG f="yukika_p5_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yukika0011"]
[OnName num="yukika"]
"Yeah, yeah!　I will. Shinji doesn't like to eat alone.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, yeah. It's always better to eat with someone else.
[cpg cn=true]

Yukika This is a great way to make sure you are getting the most out of your time with your family and friends.
[cpg]

And so, my Yukika sister and I are having a meal while having an idle conversation.
[cpg]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=900]
;//[BGM f="healing"]
[BG f="b_si_r_t4_2.ui" time=800]
;//【ＢＧ】慎二の家　慎二の部屋　夜　雨



[SE f="se059"]
;//【ＳＥ】ドサッ


When the meal is over and Yukika the sister leaves, it is just me in the house.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to do.
[cpg cn=true]

I'm not sure if it's because I did something I'm not used to, but I'm a little tired today. But this is a happy tiredness.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll agree.
[cpg cn=true]

Amane This is a great way to make sure you are getting the most out of your money.
[cpg]

Amane This is a great way to make sure you are getting the most out of your time with us.
[cpg]

[OnName num="shinzi"]
"I'm looking forward to..."
[cpg cn=true]

When I think about tomorrow when I can see her again I feel happy. I closed my eyes in a happy mood.
[cpg]

I'm not sure what to make of this, but I'm sure it's a good idea.
[cpg]

If I had gone on like this,.......
[cpg]


[jump storage="ep002.ks" target="*start"]
