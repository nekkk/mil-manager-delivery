*start

;#################################################
*Ep021|Amane Switch
;#################################################
[SCENE id=21]
[BGM f="rain"]
[BG f="b_a_mrb_t1_0.ui" time=1000]

[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/5"]
[FG f="yukika_p5_01_a.ui" method="change_7" pos="4/5"]

[OnName num="shinzi"]
"'Honestly, ......, it's disgusting.
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0163"]
[OnName num="yukika"]
"!"
[cpg cn=true]

I don't want to say this, but I was getting sick to my stomach just listening to what you just said.
[cpg]




[OnName num="shinzi"]
"'I mean, I've thought of you like my own sister since I was little, ...... and I'm shocked that you weren't, ...... and I can't believe that you saw me like that. ....... That's not right. It's weird!"
[cpg cn=true]

[FACE method="change_6" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0164"]
[OnName num="yukika"]
" Shinji ......, I love you, ......."
[cpg cn=true]

She murmured as she squeezed Yukika out with a bloodless face.
[cpg]

[OnName num="shinzi"]
"I loved you too. Until you told me what you just told me. ......"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0165"]
[OnName num="yukika"]
"Oh...oh ......, no ......."
[cpg cn=true]

[OnName num="shinzi"]
"Stay away from me. ......"
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_2" pos="2/5"]
[FG f="yukika_p5_01_a.ui" method="change_4" pos="4/5"]

She rejected Yukika her sister's trembling outstretched hand and hugged Amane her shoulder.
[cpg]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0934"]
[OnName num="amane"]
"'Please leave. Shinji chose me over an unhealthily twisted affection."
[cpg cn=true]




He had thought he would have the upper hand, but his position was the exact opposite.
[cpg]

A piercingly cold word from someone you hate.
[cpg]

[FACE method="change_3" pos="4/5"]

;//雪華は感情的になり、言わずにおこうとしていた『雨音の母親が原因で慎二の父親が死んだ事』
;//そして件の暴行事件の犯人が『雨音の父親』である事を暴露した。


Yukika became emotional and revealed that the perpetrator of the assault in question was ' Amane 's father.
[cpg]


[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0935"]
[OnName num="amane"]
"My father is ......?　The person in the earlier video ...... is my father!　No way, that's a lie. ...... That's my ......."
[cpg cn=true]

[OnName num="shinzi"]
" Amane , no!　Don't even think about it!
[cpg cn=true]

I'm not sure what to do, but I'm sure you'll be able to figure it out. Yukika As my sister's demise Amane began to take its toll, I finally denounced her.
[cpg]

[OnName num="shinzi"]
"Don't try to ruin my happiness and Amane 's any more!　Just leave me alone!　I care more about Amane than my sister!
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0166"]
[OnName num="yukika"]
"What?
[cpg cn=true]

[FG f="amane_p8_02_a.ui" method="change_7" pos="2/5" time=800]
[FG f="yukika_p5_01_a.ui" method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Amane0936"]
[OnName num="amane"]
"How come I never noticed ....... Did you forget what your father looked like?
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0937"]
[OnName num="amane"]
"Is it my father's blood, not my mother's, that makes me crazy?　Is it because your father is a pervert... or is it because you're crazy?
[cpg cn=true]

;//[FO pos="4/5" time=400]
;//[FO pos="2/5" time=400]

;//[FG f="amane_p7_02_a.ui" method="change_5" pos="2/" time=800]

[OnName num="shinzi"]
" Amane , I don't care about my parents!　Just look at me!"
[cpg cn=true]

[FO pos="2/5" time=800]

[FG f="amane_p9_02_a.ui" method="change_4" pos="2/3" time=800]
[FG f="yukika_p5_01_a.ui" method="change_4" pos="4/5"]
I hug Amane as tight as I can.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

;//[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0938"]
[OnName num="amane"]
"Mmmm, mmmm ......."
[cpg cn=true]

Amane 's body responded to my thoughts, and soon our tongues were entwined.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0939"]
[OnName num="amane"]
"Chu...mmmmm...haaa......"
[cpg cn=true]



[FO pos="4/5" time=800]

[SE f="se036"]
;//【ＳＥ】ドア閉まる



I'm not sure if our passionate embrace was desperate, but Yukika my sister left me alone without saying a word.
[cpg]

[OnName num="shinzi"]
" Yukika sis ......."
[cpg cn=true]

In the event that you've got a lot more than one of these, you'll be able to get a lot more.
[cpg]

[OnName num="shinzi"]
"Ugh ......"
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0940"]
[OnName num="amane"]
"Huh...hahaha ......"
[cpg cn=true]

In my arms, Amane began to chuckle.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0941"]
[OnName num="amane"]
"Everyone is ...... unhappy ....... Because of me, my mother died. My father went crazy,......, too. I'm still a pestilence ...... ahahahahahaha."
[cpg cn=true]



[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0942"]
[OnName num="amane"]
"Oh... it's true. It's your father ....... I didn't recognize him because he was so skinny ......."
[cpg cn=true]

Amane stares at the video on his phone that Yukika his sister left behind and looks like she's about to cry.
[cpg]

[OnName num="shinzi"]
"Don't look!"
[cpg cn=true]



[WAIT time=100]
[VOICE f="Amane0943"]
[OnName num="amane"]
"'That's horrible...you're such an animal. It's not surprising that I have the blood of a beast in my veins,......, but I don't want this kind of blood,.......
[cpg cn=true]


[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[SE f="se039"]
;//【ＳＥ】ダッシュ

[free time=1000]

[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト

[WAIT time=1000]



[OnName num="shinzi"]
" Amane !"
[cpg cn=true]

Amane This is a great way to make sure you are getting the most out of your time with your family.
[cpg]




[WAIT time=900]

[BG f="b_a_mr_t3_1.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夕方　雨

[WAIT time=1000]
[BGM f="danger"]



You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

[FG f="amane_p3_02_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0944"]
[OnName num="amane"]
"I wish all this blood ...... would flow away. I don't want any more of this blood!"
[cpg cn=true]

[OnName num="shinzi"]
" Amane Eeee!!!
[cpg cn=true]

[SE f="se043"]
;//【ＳＥ】ザクッ！

;//画面に飛ぶ鮮血
[free time=0]
[BG f="red.ui" time=0]
[WAIT time=2000]
[BG f="b_a_mr_t3_1.ui" time=1000]

[FG f="amane_p7_02_a.ui" method="change_4" pos="2/3" time=1500]

[WAIT time=3000]
[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Amane0945"]
[OnName num="amane"]
"What?
[cpg cn=true]

[OnName num="shinzi"]
"Unh...!
[cpg cn=true]

The knife had been snatched from my arm when I stopped Amane trying to cut myself.
[cpg]

Amane This is a great way to get the most out of your business.
[cpg]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0946"]
[OnName num="amane"]
" Shinji !　 Shinji ......!"
[cpg cn=true]

Buzzing and shaking his head and swinging his limbs in a mess, Amane went crazy.
[cpg]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0947"]
[OnName num="amane"]
"Noaaaaaahhh!"
[cpg cn=true]

Amane It's like a beast, and I'm upset about what to do.
[cpg]

Then I make a decision: ......
[cpg]

;//選択肢５（二択）
[switch]
[case "I hug Amane"]
	[swap]
	[jump target="*choise_31"]
[case "Pull Amane"]
	[swap]
	[jump target="*choise_32"]
[endswitch]


1. Hug Amane
2. Pull on Amane
*choise_32
[jump storage="ep023.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////


;//５-a　雨音を抱きしめる
*choise_31

[FG f="amane_p7_02_a.ui" method="change_3" pos="2/3" time=0]


[OnName num="shinzi"]
" Amane , Amane !"
[cpg cn=true]

Amane I'm not sure what to make of this.
[cpg]

[FG f="amane_p9_02_a.ui" method="change_3" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane0948"]
[OnName num="amane"]
"No!　No, no, no, no, no, no, no, no!
[cpg cn=true]

[OnName num="shinzi"]
"Please come to your senses!
[cpg cn=true]

I called out to her as hard as I could to soothe the screaming Amane .
[cpg]

[FACE method="change_4" pos="2/3"]
Then Amane reflexively reached out to latch onto my neck.
[cpg]

So I gently take the bloody knife from her and accept her embrace.
[cpg]

[STOPBGM]

[free time=1000]

[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト

[WAIT time=1000]

I can't hear the clock ticking in the room.
[cpg]

I don't know how much time has passed... but we've been doing this for a while.
[cpg]

Then she started to calm down.
[cpg]

[BG f="b_a_mr_t4_4_s.ui" time=2000]

[FG f="amane_p9_02_a.ui" method="change_4" pos="2/3" time=2000]

[WAIT time=4000]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0949"]
[OnName num="amane"]
"'I'm glad you're here .......'
[cpg cn=true]




Suddenly, she says something like that.
[cpg]

There is no more shadow of insanity in the enraptured Amane eyes.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[BGM f="rain"]

[OnName num="shinzi"]
She said, " Amane , you are pretty ....... I love that Amane you are smiling so quietly."
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0950"]
[OnName num="amane"]
"I'm sorry, Shinji . I ...... don't know what I'm going to do .......
[cpg cn=true]

[OnName num="shinzi"]
"It's okay. It's all over now. We'll start over tomorrow.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0951"]
[OnName num="amane"]
"Start over. ......?
[cpg cn=true]

[OnName num="shinzi"]
"We'll go to the hospital, we'll get some help, and we'll figure out how to have a good time together. We'll date, we'll study, we'll do everything together. ......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0952"]
[OnName num="amane"]
"Together ......."
[cpg cn=true]

The tears bled from Amane her eyes at the same time as the rain blew in through the window.
[cpg]



;//loop
[SE f="se004" loop=true]
;//【ＳＥ】雨風



[FO pos="2/3" time=800]

The Amane tears mingled with the rain and flowed away.
[cpg]

Oh, yes,.......
[cpg]

The rain of happiness always diluted her tears in this way.
[cpg]

When she cried, the rain fell; when it rained, she cried.
[cpg]

The rain would always be with her, like a mother who would always watch over Amane .
[cpg]

[OnName num="shinzi"]
"I love you. I love you. Amane ...... I'll always be with you. I'll be there for you..."
[cpg cn=true]




[FG f="amane_p7_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0953"]
[OnName num="amane"]
"Really?　Always?　Forever and ever?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, forever and ever and ever.
[cpg cn=true]

I've been through a lot.
[cpg]

And sometimes I even wanted to run away from Amane .
[cpg]

But I really liked Amane .
[cpg]

You can find a lot of things that you can do to make your life easier.
[cpg]

This will continue to be the case from now on.
[cpg]

So, I'll continue to hold her like this.
[cpg]

I don't need anyone.
[cpg]

I don't need anyone.
[cpg]

We can live with just the two of us.
[cpg]




[OnName num="shinzi"]
"Let's sleep ...... today.
[cpg cn=true]

[FG f="amane_p9_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0954"]
[OnName num="amane"]
"Yeah ....... I love you. Shinji ......
[cpg cn=true]

[OnName num="shinzi"]
"I love you too, ......."
[cpg cn=true]

I'm not sure what to say, but I'm not sure what to do.
[cpg]

I sank into a deep and gentle darkness, biting it deep in my heart. ......
[cpg]

[STOPBGM]

[free time=1000]

[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト

[WAIT time=1000]

;//loop
[stopse g=2]
[stopse g=6]

[jump storage="ep022.ks" target="*start"]
