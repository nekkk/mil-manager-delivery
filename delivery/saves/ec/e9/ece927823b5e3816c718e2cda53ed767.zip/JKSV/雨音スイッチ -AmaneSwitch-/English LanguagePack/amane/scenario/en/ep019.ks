*start



;#################################################
*Ep019|How did this happen?
;#################################################
[SCENE id=19]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト

[STOPBGM]


The next day, Sunday: ......
[cpg]



[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="rain"]
[BG f="b_k_co_t1_0.ui" time=1000]
;//【ＢＧ】木崎家　中庭　午後　小雨
;//木崎家　中庭
;//しとしと雨
;//loop
[SE f="se007" loop=true]


;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]



[OnName num="father_in_law"]
"Huh, huh... It's really hard to educate people, you know?
[cpg cn=true]

[FG f="izumi_p5_02_a.ui" method="change_4" pos="4/5" time=800]
[FG f="shizuku_p5_02_a.ui" method="change_4" pos="2/5" time=800]

[WAIT time=100]
[VOICE f="Izumi0194"]
[OnName num="izumi"]
"Ugh..."
[cpg cn=true]

[WAIT time=100]
[VOICE f="Shizuku0183"]
[OnName num="shizuku"]
"Gusu... gusu... gusu...
[cpg cn=true]

It's raining again today.
[cpg]

So my father-in-law stays home, and my beautiful sisters relieve his gloom.
[cpg]

[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0195"]
[OnName num="izumi"]
"Ugh, no. ......"
[cpg cn=true]

I hate the rain.
[cpg]

Every time it rains, it makes this man crazy.
[cpg]
[FACE method="change_3" pos="4/5"]

Izumi glared at his father-in-law with pointless resistance.
[cpg]

[OnName num="father_in_law"]
"What ...... are those eyes?
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0196"]
[OnName num="izumi"]
"'............
[cpg cn=true]

[OnName num="father_in_law"]
"'What's that look you're giving your father!
[cpg cn=true]

[SE f="se091"]
;//【ＳＥ】ギュゥゥゥ


[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0197"]
[OnName num="izumi"]
"Ugh!"
[cpg cn=true]

I was pressed down on my cheek with the sole of my shoe, and poof, I tasted a cut in my mouth.
[cpg]

As soon as I realized it was blood, something popped in Izumi my mouth.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0198"]
[OnName num="izumi"]
"You're not my father!
[cpg cn=true]

[OnName num="father_in_law"]
"What the hell ......?
[cpg cn=true]

[free time=800]

[FG f="izumi_p7_02_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0199"]
[OnName num="izumi"]
"We're not your daughters!　Your daughter is Amane !　Your daughter is Amane Satonaka , to whom you send so much money every month!
[cpg cn=true]

[OnName num="father_in_law"]
"What?
[cpg cn=true]


;//loop
[stopse g=2]
[stopse g=6]
[STOPBGM]

[SE f="se011"]
;//【ＳＥ】ゴト…ッ（酒瓶が芝生へ落ちる）

;//[free time=800]
;//[BG f="black.ui" time=800]
;//[WAIT time=1000]

;//[BG f="b_k_co_t1_0.ui" time=1000]
;//【ＢＧ】木崎家　中庭　午後　小雨



;// キャラクターの前面に雨を表示
;// 通常
;//[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]


;//【雨、大雨】
;//loop
[SE f="se006" loop=true]
;//【ＳＥ】雨



This is a great way to get the most out of your business.
[cpg]

[OnName num="father_in_law"]
"'Hey, how did you ...... get that?
[cpg cn=true]

[free time=800]

[FG f="izumi_p5_02_a.ui" method="change_3" pos="4/5" time=800]

[FG f="shizuku_p5_02_a.ui" method="change_3" pos="2/5" time=800]

[WAIT time=100]
[VOICE f="Izumi0200"]
[OnName num="izumi"]
"'Did you think we didn't know anything about it?　Osei-sama!"
[cpg cn=true]

Seeing the momentum of his sister, Shizuku also said here and there.
[cpg]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0184"]
[OnName num="shizuku"]
Amane "I'm not sure what to make of that.　It's really our money!
[cpg cn=true]

[OnName num="father_in_law"]
"What?
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0201"]
[OnName num="izumi"]
"Ba..."
[cpg cn=true]

The man's expression shifted from agitation to anger, and Izumi cursed his sister's low intelligence and shallowness.
[cpg]

Shizuku It's a good idea to have a good idea of what you're looking for.
[cpg]


[WAIT time=100]
[VOICE f="Shizuku0185"]
[OnName num="shizuku"]
"Didn't you know that Amane and we were students at the same school?　This is a great way to make sure that you get the most out of your time with us.
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0202"]
[OnName num="izumi"]
" Shizuku , shut the fuck up!
[cpg cn=true]

[OnName num="father_in_law"]
"You ......, what did you do to him ......?
[cpg cn=true]

[BGM f="danger"]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

This is a great way to make sure you are getting the most out of your money.
[cpg]

[OnName num="father_in_law"]
"I'm sure you'll agree.
[cpg cn=true]

[SE f="se040"]
;//【ＳＥ】ドカッ！

[free time=0]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="b_k_co_t1_0.ui" time=500]

[FG f="izumi_p5_02_a.ui" method="change_3" pos="4/5" time=500]

;//[FO pos="2/5" time=800]
[move from="2/5" to="1/8" ease="easeInOutSine" time=600]

;//[FG f="shizuku_p5_02_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shizuku0186"]
[OnName num="shizuku"]
"I'm sure you'll agree.
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0203"]
[OnName num="izumi"]
" Shizuku !"
[cpg cn=true]

Shizuku Shizuku In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

[free time=800]

[OnName num="father_in_law"]
"It's a great way to get the most out of your day.
[cpg cn=true]

This is a great way to get the most out of your day.
[cpg]

This is a great way to get the most out of your business.
[cpg]

In the event that you have any questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

I know I should take her in and raise her if I really wanted to.
[cpg]

However, after the birth of Amane , everything went wrong, and I was irritated with her because I did not like the bitter rain.
[cpg]

I don't know why I'm so irritated, and I hate myself for it, and I feel like I'm going crazy.
[cpg]

[OnName num="father_in_law"]
"I'm not sure what to make of it.
[cpg cn=true]

[FG f="izumi_p5_02_a.ui" method="change_3" pos="3/5" time=800]
[FG f="shizuku_p5_02_a.ui" method="change_4" pos="2/5" time=800]


[WAIT time=100]
[VOICE f="Shizuku0187"]
[OnName num="shizuku"]
"Ugh.........
[cpg cn=true]


[WAIT time=100]
[VOICE f="Izumi0204"]
[OnName num="izumi"]
"Stop!　 You can't touch Shizuku !
[cpg cn=true]

He is a foolish boy, but Shizuku is still a dear sister to Izumi .
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[OnName num="father_in_law"]
"You can find a lot of things that you can do to make your life easier.
[cpg cn=true]

;//loop
[stopse g=2]
[stopse g=6]

[SE f="se057"]
;//【ＳＥ】激しいビンタ

[free time=0]
[BG f="red.ui" time=0]
[WAIT time=1]
;//[BGM f="rain"]
[BG f="b_k_co_t1_0.ui" time=500]
;//【ＢＧ】木崎家　中庭　午後　小雨



;// キャラクターの前面に雨を表示
;// 通常
;//[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]



;//【雨、小雨】

;//loop
[SE f="se006" loop=true]
;//【ＳＥ】雨

;//[FO pos="4/5" time=800]
;//[move from="4/5" to="4/3" ease="easeInOutSine" time=600]

;//[FG f="izumi_p5_02_a.ui" method="change_1" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Izumi0205"]
[OnName num="izumi"]
"I'm not sure what to say.
[cpg cn=true]

[SE f="se024"]
;//【ＳＥ】ズシャーーッ！


Izumi This is a great way to get the most out of your business.
[cpg]

;//[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0188"]
[OnName num="shizuku"]
"It's a good idea to have a good idea of what you're doing.
[cpg cn=true]

;//[FO pos="2/5" time=800]

Shizuku In the event you're not sure what you're looking for, there are a few things you can do.
[cpg]

[FG f="izumi_p5_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0206"]
[OnName num="izumi"]
"You can find a lot more information on this website.
[cpg cn=true]

Izumi In the event that you've got a lot of money, you'll be able to make use of it for a lot of things.
[cpg]

[FG f="izumi_p7_02_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0207"]
[OnName num="izumi"]
"You can get a lot more information on the web.
[cpg cn=true]

[OnName num="father_in_law"]
"Shut up!
[cpg cn=true]

[SE f="se040"]
;//【ＳＥ】ドカッ！

[free time=0]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="b_k_co_t1_0.ui" time=500]

[FG f="izumi_p7_02_a.ui" method="change_4" pos="2/3" time=500]

;//[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0208"]
[OnName num="izumi"]
"Oh no!"
[cpg cn=true]

This is a great way to make sure that you are getting the most out of your vacation. In the event that you're not sure what you're looking for, you'll be able to find out more about it here.
[cpg]

The Izumi is full of inarticulate voices, and the body begins to shake with rattling.
[cpg]

[FACE method="change_4" pos="2/3"]
;//[FG f="izumi_p5_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0209"]
[OnName num="izumi"]
"Ah ...... ah ......."
[cpg cn=true]

[OnName num="father_in_law"]
"It seems that you guys need more... education!
[cpg cn=true]

;//[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0210"]
[OnName num="izumi"]
"No, no, no, no!
[cpg cn=true]

[SE f="se023"]
;//【ＳＥ】ドンッ！

[free time=0]
[BG f="black.ui" time=0]
[WAIT time=1]
[BG f="b_k_co_t1_0.ui" time=500]
;//【ＢＧ】木崎家　中庭　午後　小雨



;// キャラクターの前面に雨を表示
;// 通常
;//[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、小雨】
[FG f="izumi_p5_02_a.ui" method="change_4" pos="2/3" time=500]

[OnName num="father_in_law"]
"Oops. ......"
[cpg cn=true]

With all his strength, he pushed the man's body away and tried to escape Izumi by crawling.
[cpg]

[move from="2/3" to="4/5" ease="easeInOutSine" time=1000]

[SE f="se074"]
;//【ＳＥ】ビチャッ、ビチャッ


This is a great way to get the most out of your time and money.
[cpg]

But there was no way he could escape.
[cpg]

[OnName num="father_in_law"]
"I'm not going anywhere!
[cpg cn=true]
[FO pos="4/5" time=0]

[FG f="izumi_p5_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0211"]
[OnName num="izumi"]
"No!　Don't come!　Don't touch me!
[cpg cn=true]

[OnName num="father_in_law"]
"Shut the fuck up!
[cpg cn=true]

[SE f="se040"]
;//【ＳＥ】ドカッ！


[free time=0]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="b_k_co_t1_0.ui" time=500]

[FG f="izumi_p5_02_a.ui" method="change_4" pos="2/3" time=500]

;//[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0212"]
[OnName num="izumi"]
"Agh!
[cpg cn=true]

A pain like a sharp needle piercing the pubic bone runs up the spine, Izumi moaned in pain.
[cpg]

I'm going to get killed if I don't... From such an animalistic instinct, Izumi
[cpg]

[FG f="izumi_p7_02_a.ui" method="change_3" pos="2/3" time=800]

I'm sorry.
[cpg]

[OnName num="father_in_law"]
"Aah!"
[cpg cn=true]

He bit his father-in-law on the finger.
[cpg]

[OnName num="father_in_law"]
"You bitch!
[cpg cn=true]

[SE f="se023"]
;//【ＳＥ】ボグッ！



[free time=0]
[BG f="red.ui" time=0]
[WAIT time=1]

[BG f="b_k_co_t1_0.ui" time=500]
;//【ＢＧ】木崎家　中庭　午後　小雨


[FG f="izumi_p5_02_a.ui" method="change_4" pos="2/3" time=500]
[WAIT time=800]
[VOICE f="Izumi0213"]
[OnName num="izumi"]
"Goh...!"
[cpg cn=true]

A fist in the side, Izumi breathing stops.
[cpg]

In a position where the difference in power is overwhelming, it only clouds the situation even more. It's a great way to make sure you're getting the most out of your money.
[cpg]

;//[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0214"]
[OnName num="izumi"]
"I'm not sure what to say.　Forgive me already!!!"
[cpg cn=true]

Dominated by the intense pain that pierced her body, and her heart torn to shreds by despair, Izumi had no choice but to cry out.
[cpg]

[OnName num="father_in_law"]
"I'm not sure what to say.　Suck it up!"
[cpg cn=true]

Ever since he came here, the man has been looked down upon by his sisters as if they were looking at him as if he were a dirty thing.
[cpg]

This is the reason why I have been addicted to alcohol and cannot control my emotions like this.
[cpg]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0215"]
[OnName num="izumi"]
"Heee!"
[cpg cn=true]

[OnName num="father_in_law"]
"Think about it!　It's your fault!　It's your fault!
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0216"]
[OnName num="izumi"]
"Help me. ...... Shizuku ......
[cpg cn=true]

;//腰が抜けて動けない雫

[FO pos="2/3" time=800]

[FG f="shizuku_p3_02_a.ui" method="change_4" pos="1/4" time=800]
[WAIT time=100]
[VOICE f="Shizuku0189"]
[OnName num="shizuku"]
"Aww ...... aww ...... hiiii......"
[cpg cn=true]

He had barely gotten up Shizuku but he was sitting up at the sight of his sister.
[cpg]

The useless sister who is rattling her teeth and palling her face.
[cpg]

You could even escape while you're at it, but you're an incompetent sister who can't even think of that.
[cpg]

This is the moment when the hope of Izumi was cut off from the root.
[cpg]

[FO pos="1/4" time=800]

[OnName num="father_in_law"]
「へ...、ヘヘヘ......まだまだ、お楽しみはこれからだ」
[cpg cn=true]

In the stepfather's lowly laugh, Izumi gave up something.
[cpg]

[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_k_co_t1_0.ui" time=1000]
;//【ＢＧ】木崎家　中庭　午後　小雨

[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]
;//loop
[SE f="se006" loop=true]
;//【ＳＥ】雨

[FG f="izumi_p5_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0217"]
[OnName num="izumi"]
"U...g...... ah...ah......"
[cpg cn=true]

[OnName num="father_in_law"]
"Heh heh ......."
[cpg cn=true]

How much time has passed since then....
[cpg]

After a round of education that was more intense than ever before, Izumi sank into a deeper darkness ...... than it had ever experienced.
[cpg]

[SE f="se059"]
;//【ＳＥ】ドサッ

[FO pos="2/3" time=800]

;//[FG f="izumi_p1_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0218"]
[OnName num="izumi"]
"U ...... ugh ......."
[cpg cn=true]



I'm sure you'll be pleased to know that I'm not the only one who's had a bad experience.
[cpg]

[OnName num="father_in_law"]
"This time it's you.
[cpg cn=true]

[FG f="shizuku_p3_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0190"]
[OnName num="shizuku"]
"I'm not sure what to say.
[cpg cn=true]

I'm not sure what to do. It was a matter of course.
[cpg]


[FG f="shizuku_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0191"]
[OnName num="shizuku"]
"No, no, no, no, no, no, no, no, no, no, no, no, no, no, no, no, no, no, no, no, no, no, no, no, no, no.
[cpg cn=true]

[OnName num="father_in_law"]
"Don't be so hard on me. I'm trying to make you smart, too!
[cpg cn=true]

[FG f="shizuku_p7_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0192"]
[OnName num="shizuku"]
"Yaaaah!
[cpg cn=true]

Izumi Shizuku A lot of people are not aware of the fact that there are a lot of people who are in the same situation.
[cpg]



[SE f="se040"]
;//【ＳＥ】バグッ！

[free time=0]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="b_k_co_t1_0.ui" time=500]


[FG f="shizuku_p5_02_a.ui" method="change_4" pos="2/3" time=500]
[WAIT time=100]
[VOICE f="Shizuku0193"]
[OnName num="shizuku"]
"I'm not sure what to say.
[cpg cn=true]

A large fist flew into Shizuku 's face, causing his nose to bleed.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0194"]
[OnName num="shizuku"]
"Ida...yiyoo,...... uaaa."
[cpg cn=true]

[OnName num="father_in_law"]
"I'm not sure what to say. It's a good idea to have a good idea of what you're looking for.
[cpg cn=true]

Shizuku In the event that you have any questions concerning where and how to use the internet, you can call us at our own web site.
[cpg]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0195"]
[OnName num="shizuku"]
"Ehhh ...... ohhh~"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0196"]
[OnName num="shizuku"]
"Yaaaaaah!
[cpg cn=true]

[OnName num="father_in_law"]
"'Oh, you're so loud ....... My ears are aching ......."
[cpg cn=true]

The man hated the high-pitched voices of children.
[cpg]

The screaming voice of Shizuku was dubbed as the voice of Amane in the past.
[cpg]

"I'm not sure what to say.　Father!"
[cpg cn=true]

[OnName num="father_in_law"]
"Shut up, ....... It's so loud!
[cpg cn=true]


[FO pos="2/3" time=800]

The man who was upset by the auditory hallucination accompanied by a headache threw out his leg that was grabbing eagle.
[cpg]




[SE f="se059"]
;//【ＳＥ】ドサッ！


[free time=0]
[BG f="red.ui" time=0]
[WAIT time=1]

[BG f="b_k_co_t1_0.ui" time=500]
;//【ＢＧ】木崎家　中庭　午後　小雨



;// キャラクターの前面に雨を表示
;// 通常
;//[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]
;//loop
[SE f="se007" loop=true]
;//【雨、小雨】


[FG f="shizuku_p3_02_a.ui" method="change_7" pos="2/3" time=500]
[WAIT time=800]
[VOICE f="Shizuku0197"]
[OnName num="shizuku"]
"Ugh!"
[cpg cn=true]

Thinking that he was released, Shizuku crawled and tried to move away from his father-in-law, but it was not good.
[cpg]

[OnName num="father_in_law"]
"Don't you dare run away from me!
[cpg cn=true]

[FG f="shizuku_p7_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0198"]
[OnName num="shizuku"]
"Hiya!"
[cpg cn=true]

I'm not sure what to make of this.
[cpg]




[SE f="se040"]
;//【ＳＥ】バグッ！

[free time=0]
[BG f="red.ui" time=0]
[WAIT time=1]

[BG f="b_k_co_t1_0.ui" time=500]

[FG f="shizuku_p7_02_a.ui" method="change_7" pos="2/3" time=500]

[WAIT time=1000]

[SE f="se040"]
;//【ＳＥ】バグッ！

[free time=0]
[BG f="red.ui" time=0]
[WAIT time=1]

[BG f="b_k_co_t1_0.ui" time=500]

[FG f="shizuku_p1_02_a.ui" method="change_4" pos="2/3" time=800]

[OnName num="father_in_law"]
"I'm not sure what to do.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Shizuku0199"]
[OnName num="shizuku"]
"I'm not sure what to do.
[cpg cn=true]

[FO pos="2/3" time=800]

This is a great way to make sure you are getting the most out of your time with us.
[cpg]

The mouth opened wide enough for the jaw to come off, and a decisive demon was released.
[cpg]

[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]
[SE f="se004" loop=true]
;//【ＳＥ】土砂降り


;//雨、一層激しく


[OnName num="father_in_law"]
"''Hahahahahaha!
[cpg cn=true]

[FG f="shizuku_p5_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0200"]
[OnName num="shizuku"]
"''Hahiiiii!　No!　Oh no!
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0201"]
[OnName num="shizuku"]
"Sis...!　Help me!
[cpg cn=true]

;//[FG f="izumi_p5_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0219"]
[OnName num="izumi"]
"........................"
[cpg cn=true]

But the eyes of Izumi , who is looking at me with her knees and head resting on the ground, have already lost their light.
[cpg]

[FG f="shizuku_p7_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0202"]
[OnName num="shizuku"]
"I'm not sure what to say.　Mother!　I'm not sure what to do.
[cpg cn=true]

In the event that you've got a lot more than one, you'll be able to get a lot more.
[cpg]

However, in the barely raised face, Shizuku saw what ......
[cpg]

[FG f="shizuku_p7_02_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0203"]
[OnName num="shizuku"]
"I'm not sure what to say.
[cpg cn=true]

;//カーテンの隙間からボーッとこっちを見詰めている


Inside the house .......
[cpg]

I'm not sure what to make of it.
[cpg]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0204"]
[OnName num="shizuku"]
"I'm not sure what to say.　I'm not sure what to do.
[cpg cn=true]

I'm sure you'll be happy to know that I'm not the only one.
[cpg]

But ......
[cpg]

[OnName num="mother"]
"........................... ..."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="father_in_law"]
"It's a great way to make sure you're getting the most out of your vacation. It's always the same. All he cares about is that he doesn't want me to leave him."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0205"]
[OnName num="shizuku"]
"No, no, no, no!
[cpg cn=true]

He's crazy.
[cpg]

He's crazy. She's crazy.
[cpg]

I had no choice but to see it that way.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0206"]
[OnName num="shizuku"]
"Aaahhh!"
[cpg cn=true]

;//諦めたところで、体の内部をヤスリで擦られるような痛みは消えず、雫は叫び続ける。
When I gave up, the pain in my body would not go away, and Shizuku I kept screaming.
[cpg]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0207"]
[OnName num="shizuku"]
"It's a good idea to have a good idea of what you're doing.　Aaaaah! Aaahh!　Help me!"
[cpg cn=true]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye2"]
;//[BG f="b_k_co_t1_2.ui" time=1000]
;//【ＢＧ】木崎家　中庭　午後　大雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]

[SE f="se004" loop=true]
;//【ＳＥ】土砂降り
;//【雨、大雨】





At that time, there was someone watching the hellish scene from the shadows.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to say.
[cpg cn=true]

Shinji I'm sure you'll be able to understand why.
[cpg]

[OnName num="shinzi"]
".................."
[cpg cn=true]

If you want to help, you can.
[cpg]

But there was a reason why Shinji , who is supposed to have a strong sense of justice, did not do so.
[cpg]

That's what Kizaki Sisters did to Amane .
[cpg]




In order not to let him do such a thing anymore, he is going to make this thing a trump card.
[cpg]

He's already reached the point where he's willing to make threats.
[cpg]

It's all for the sake of his beloved Amane .
[cpg]

He doesn't care if his sisters have to sacrifice themselves to save Amane .
[cpg]

[OnName num="shinzi"]
"It's payback, ......."
[cpg cn=true]

It shouldn't be you guys who hurt Amane and make me suffer .......
[cpg]

It's not that I don't like it. Shinji twisted the nausea from his conscience with anger, and continued to shoot as long as memory allowed.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//[free time=400]

[BG f="black.ui" time=800]
;//ブラックアウト

[WAIT time=800]

[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]
[SE f="se004" loop=true]
;//【ＳＥ】土砂降り

[SE f="se059"]
;//【ＳＥ】ドサッ


[BG f="b_k_co_t1_2.ui" time=800]

[WAIT time=2000]

[SE f="se059"]
;//【ＳＥ】ドサッ

[WAIT time=500]

--After being exposed to overwhelming force, Shizuku weakens and falls to the ground.
[cpg]

[FG f="shizuku_p7_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0208"]
[OnName num="shizuku"]
"I'm not sure what to say.
[cpg cn=true]

Shizuku In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

While desperately vomiting, swimming gaze and face up, ......
[cpg]




;//母の姿がなくなっている窓

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
;//[BGM f="insecurity"]
;//[BG f="b_k_co_t1_2.ui" time=1000]
;//【ＢＧ】木崎家　中庭　午後　大雨



;//[FG f="shizuku_p5_01_a.ui" method="change_7" pos="2/3" time=800]

[STOPBGM]

The figure of my mother, who should certainly have been there, had disappeared from behind the window.
[cpg]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0209"]
[OnName num="shizuku"]
"'Ugh...eeee, ohhhhhhh...'
[cpg cn=true]

No one is going to help you .......
[cpg]

;//[FO pos="2/3" time=800]

Shizuku Izumi In the event that you have any questions concerning where and how to use the internet, you can call us at our own web site.
[cpg]

[OnName num="father_in_law"]
"Hah hah ...... hah ......."
[cpg cn=true]

Oh, that's right,......, the man realizes in the midst of his cooling emotions.
[cpg]

I've always wanted to do this,.......
[cpg]

He dominates with overwhelming power over women he doesn't like and even women he does like.
[cpg]

I used to get irritated every time I saw Amane one because I had the conscience to suppress these desires.
[cpg]



[BG f="b_ex_sk_t2_1.ui" time=1000]
[WAIT time=1000]



But ......, it's okay now.
[cpg]

Thus, you can be satisfied with compensatory acts.
[cpg]

Even if it is a stepdaughter, the existence of a "daughter" absorbs the desire for the real daughter.
[cpg]

Yes, ......
[cpg]

I'm fine now.
[cpg]

I'm sure I'm not afraid to see Amane anymore.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

;//0721発見
;//雨が降る度に湧き起こる性衝動も、きっともう大丈夫だ。


You can be sure that the urge that arises every time it rains is no longer a problem.
[cpg]

I'll see you soon .......
[cpg]

To my daughter .......
[cpg]

My Amane to .......
[cpg]

[OnName num="father_in_law"]
"Ha ......, ha ha ha ha ha ha ha!"
[cpg cn=true]

;//[FG f="izumi_p1_02_a.ui" method="change_4" pos="3/4" time=800]
;//[FG f="shizuku_p1_02_a.ui" method="change_4" pos="2/4" time=800]

[WAIT time=100]
[VOICE f="Shizuku0210"]
[OnName num="shizuku"]
"Uhhhhhhhh!"
[cpg cn=true]

[WAIT time=100]
[VOICE f="Izumi0220"]
[OnName num="izumi"]
"Uh...uh...uh."
[cpg cn=true]

The man's laughter, combined with the sisters' cries, ...... eventually swallowed them up in the downpour.
[cpg]



[transition target={true} rule="amamori2.png" color={0x000000ff} time=2000]
[WAIT time=2100]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]
[BG f="black.ui" time=500]

[transition target={false} color={0x000000ff} time=500]
[WAIT time=800]
[SE f="se004"]
;//【ＳＥ】高まる雨の音、やがてF.O

;//エフェクト


[WAIT time=3000]

;#############################################################


;#############################################################


;//loop
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye2"]
[BG f="b_si_d_t2_2.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　夕方　雨


[SE f="se036"]
;//【ＳＥ】ガタンガタン！

[OnName num="shinzi"]
"Haaaaah!　Hur ......!"
[cpg cn=true]

Having served my purpose, I ran Kizaki all the way back from the house.
[cpg]

[FG f="yukika_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yukika0122"]
[OnName num="yukika"]
"What's wrong with you?　You're so out of breath."
[cpg cn=true]

My Yukika sister was at home, and she seemed surprised by my odd appearance.
[cpg]

[OnName num="shinzi"]
"It's nothing. ......
[cpg cn=true]

[FO pos="4/5" time=800]

[FG f="yukika_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0123"]
[OnName num="yukika"]
"What's nothing ......? It's that girl again,......."
[cpg cn=true]

This is a great way to make sure that you get the most out of your vacation.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0124"]
[OnName num="yukika"]
"It's a good idea to have a good idea of what you're looking for.
[cpg cn=true]

[OnName num="shinzi"]
"I don't know much about it, so I'll leave it to my sister. ......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0125"]
[OnName num="yukika"]
"Oh, and by the way!　 Yoko is about to be released, okay?
[cpg cn=true]

[OnName num="shinzi"]
"What about ......?　How do you know about that?
[cpg cn=true]

I'm always nosy, but why would Yukika sister know what Yoko is up to with the police?
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0126"]
[OnName num="yukika"]
"Because I've been talking to her parents ever since.
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

I was astonished that she was even doing that.
[cpg]

At the same time, the fact that Yoko is coming back weighs heavily on my mind.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0127"]
[OnName num="yukika"]
"This is a great way to make sure you are getting the most out of your money. It's a minor, and you'll only be on probation for about a year.
[cpg cn=true]

[OnName num="shinzi"]
"Will ...... he be able to go to Shuei again?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0128"]
[OnName num="yukika"]
"Probably.
[cpg cn=true]

[OnName num="shinzi"]
"He came back to .......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0129"]
[OnName num="yukika"]
"What?
[cpg cn=true]

[OnName num="shinzi"]
"Even if he comes back, I'm not gonna forgive him. No, not just Yoko . ....... I'm gonna get rid of ...... anyone who degrades Amane .
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0130"]
[OnName num="yukika"]
"What are you talking about, Shinji ?
[cpg cn=true]

[OnName num="shinzi"]
"You don't know Yukika . You don't know what Yoko and Kizaki Sisters are like!　That's why I'm going to protect Amane . With this. ......
[cpg cn=true]




;//慎二が握っているスマホのアップ




[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0131"]
[OnName num="yukika"]
"The phone ......?　 Kizaki Sisters , the one that came to my aunt's funeral. ......
[cpg cn=true]

[OnName num="shinzi"]
"You should go home. And you don't have to come back tomorrow. ......
[cpg cn=true]




[SE f="se028"]
;//【ＳＥ】音を立てて歩く




[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0132"]
[OnName num="yukika"]
" Shinji ?　Where are you going ......?
[cpg cn=true]

[OnName num="shinzi"]
"To the bathroom.
[cpg cn=true]

[FO pos="2/3" time=800]

It's a good idea to have a good idea of what you're looking for.
[cpg]




;//エフェクト
;//loop
[stopse g=2]
[stopse g=6]

[SE f="se004"]
;//【ＳＥ】シャワー

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト





[OnName num="shinzi"]
".................."
[cpg cn=true]

I took a hot shower from my head and remembered the hellscape I had just seen.
[cpg]

I made sure to record that video.
[cpg]

Now all I had to do was show that to Kizaki Sisters and tell Amane to leave me alone.
[cpg]

We'll figure out Yoko what to do with ...... after that.
[cpg]

Right now, I just want to wash this nausea and guilt away.
[cpg]

That's all. ......
[cpg]

;//loop
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="h2"]
[BG f="b_si_d_t2_2.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　夕方　雨


[SE f="se035"]
;//【ＳＥ】静かにドア（ダイニングから脱衣所へ続く）が開く

[WAIT time=800]

[SE f="se004"]
;//【ＳＥ】風呂から聞こえるシャワー





[FG f="yukika_p7_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0133"]
[OnName num="yukika"]
"What ...... is on your phone?
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=800]
;//【ＢＧ】ブラックアウト


[SE f="se064"]
;//【ＳＥ】ガサゴソ

[WAIT time=800]

;//【ＳＥ】スマホの操作音


;//木崎姉妹のレイプシーン再生

;//[SE f="se150"]


[WAIT time=800]

;//※【ＳＥ】雪華の立ち絵のバックに悲鳴や義父の声が流れる

;//[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0134"]
[OnName num="yukika"]
"What ......?　It's .......
[cpg cn=true]

;//驚愕の表情から無表情になる雪華

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0135"]
[OnName num="yukika"]
"No, ...... Shinji . No .......
[cpg cn=true]

[SE f="se086"]
;//【ＳＥ】ブチッ（映像と音が切れる）


[WAIT time=100]
[VOICE f="Yukika0136"]
[OnName num="yukika"]
"........................
[cpg cn=true]

;//エフェクト

;//loop
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="rain"]
[BG f="b_s_en_t1_0.ui" time=1000]
;//【ＢＧ】学園　昇降口　午前　曇り

;//雨の降る昇降口で土下座する雨音


[SE f="se007"]
;//【ＳＥ】雨（中降り）




[FG f="amane_p1_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0898"]
[OnName num="amane"]
"I'm really sorry about this ....... I'm really sorry for this ....... I'm so sorry for your loss. ......
[cpg cn=true]

[OnName num="male_student"]
"What the hell ......?
[cpg cn=true]

[OnName num="female_student"]
"Are you crazy? ......?
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

The next day, I arrived at school and saw the figure of Amane at the entrance of the elevator, kneeling down to the students who came and went.
[cpg]

[SE f="se006"]
[SE f="se132"]
;//【ＳＥ】雨の中駆け寄る



[FO pos="2/3" time=800]

[OnName num="shinzi"]
" Amane , stop!
[cpg cn=true]

[FG f="izumi_p5_01_a.ui" method="change_3" pos="4/5" time=800]
[FG f="shizuku_p5_01_a.ui" method="change_3" pos="2/5" time=800]

[WAIT time=100]
[VOICE f="Izumi0221"]
[OnName num="izumi"]
"Don't stop."
[cpg cn=true]

Kizaki Sisters It's a great way to make sure you're getting the most out of your vacation.
[cpg]


[WAIT time=100]
[VOICE f="Shizuku0211"]
[OnName num="shizuku"]
Amane "I'm not sure what to make of this.
[cpg cn=true]

[OnName num="shinzi"]
"I'm not sure what to make of it.
[cpg cn=true]

Shizuku This is a great way to make sure you are getting the most out of your investment.
[cpg]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0212"]
[OnName num="shizuku"]
"You've got to apologize to everyone for what you've done, right?
[cpg cn=true]

[OnName num="shinzi"]
"I thought I repaid you!"
[cpg cn=true]

I don't know how you did it, but I'm furious that you would say such a thing when you framed Amane .
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0222"]
[OnName num="izumi"]
"I'm not sure what to make of it, but I'm sure it's worth it.　You owe it to Satonaka to keep apologizing until everyone forgives you. Well, I know it's hard to get people to forgive you. ......"
[cpg cn=true]

[free time=800]

[FG f="amane_p1_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0899"]
[OnName num="amane"]
"I'm really sorry about this ....... I'm very sorry about this. ......
[cpg cn=true]

[OnName num="shinzi"]
"Oh, Amane .......
[cpg cn=true]

Next to me and Kizaki Sisters , he rubbed his forehead on the wet ground and repeated Amane his apology.
[cpg]

[OnName num="male_student"]
"It's a good idea to have a good idea of what you're doing.　You thieving bitch!"
[cpg cn=true]

[SE f="se076"]
;//【ＳＥ】ガッ！
[free time=0]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="b_s_en_t1_0.ui" time=500]
[FG f="amane_p1_02_a.ui" method="change_7" pos="2/3" time=500]
[WAIT time=500]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0900"]
[OnName num="amane"]
"Ugh. ......
[cpg cn=true]

[OnName num="shinzi"]
"What the hell are you doing?
[cpg cn=true]

Someone threw a stone at Amane 's head, and a line of blood ran down her cheek.
[cpg]

[free time=800]

This is a great way to make sure you are getting the most out of your vacation.
[cpg]

[FG f="izumi_p5_01_a.ui" method="change_3" pos="3/4" time=800]
[WAIT time=100]
[VOICE f="Izumi0223"]
[OnName num="izumi"]
"Stop it, Mizushima !　If you do anything else, you'll be suspected of being an accomplice.
[cpg cn=true]

[OnName num="shinzi"]
"What ......?
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_3" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0901"]
[OnName num="amane"]
" Shinji has nothing to do with this!
[cpg cn=true]

[FACE method="change_1" pos="3/4"]

The expressionless Amane raises his head, stands up and clutches the leg of Izumi .
[cpg]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0902"]
[OnName num="amane"]
"Don't drag Shinji into this!　It's all my fault!　I'll do anything!　I will do whatever it takes!　Please!"
[cpg cn=true]

Amane , who seems to have given up on everything, is raising her voice for me.
[cpg]

This is a great way to make sure that you get the most out of your vacation.
[cpg]

[FACE method="change_7" pos="3/4"]

[WAIT time=100]
[VOICE f="Izumi0224"]
[OnName num="izumi"]
"What's ...... not?
[cpg cn=true]

The face of Izumi , which should be beautiful and innocent, distorted ugly.
[cpg]

[FG f="shizuku_p5_01_a.ui" method="change_3" pos="4/4" time=800]
[WAIT time=100]
[VOICE f="Shizuku0213"]
[OnName num="shizuku"]
"You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0903"]
[OnName num="amane"]
"What ......?"
[cpg cn=true]

[OnName num="shinzi"]
"Stop!"
[cpg cn=true]

I know what Shizuku means when they say that.
[cpg]

I knew that after the hell they had put me through, they would have stripped Amane naked and left me for all to see.
[cpg]

So I immediately took out a trump card from my pocket and countered.
[cpg]

[OnName num="shinzi"]
"Both of you, can you still say such a thing ...... after seeing this?"
[cpg cn=true]

[FACE method="change_3" pos="3/4"]

[WAIT time=100]
[VOICE f="Izumi0225"]
[OnName num="izumi"]
"What the ......
[cpg cn=true]

[FACE method="change_7" pos="4/4"]

[WAIT time=100]
[VOICE f="Shizuku0214"]
[OnName num="shizuku"]
"What's this?
[cpg cn=true]

[OnName num="shinzi"]
"Oh, ...... that ......?
[cpg cn=true]

[free time=800]

I tried to play the video, but for some reason there was no recorded video in the folder.
[cpg]

On the contrary, there was only one thing on the screen: .......
[cpg]

"SD card is not inserted.
[cpg]

But there was no recorded video in the folder.
[cpg]

[OnName num="shinzi"]
"What? Why?
[cpg cn=true]

[FG f="izumi_p5_01_a.ui" method="change_7" pos="3/4" time=800]
[FG f="shizuku_p5_01_a.ui" method="change_2" pos="4/4" time=800]

[WAIT time=100]
[VOICE f="Izumi0226"]
[OnName num="izumi"]
"Isn't it because you're dating someone like this that you've lost your mind?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0215"]
[OnName num="shizuku"]
" Amane Senpai, you should not only apologize, but also do community service, right?
[cpg cn=true]

[FACE method="change_2" pos="3/4"]

[WAIT time=100]
[VOICE f="Izumi0227"]
[OnName num="izumi"]
"Yeah. Why don't you do some shoeshine?　With your soaking wet shirt.
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0904"]
[OnName num="amane"]
"Yeah, I'll do that. ......
[cpg cn=true]

[OnName num="shinzi"]
"Oh, come on!
[cpg cn=true]

The sisters whispered a suggestion, and Amane who had no choice but to comply, crawled into the puddle and slid his body into the student's shoes.
[cpg]

[OnName num="male_student"]
"Whoa!　What the hell?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0905"]
[OnName num="amane"]
"'I'm really sorry about this, ....... We will at least be able to polish your shoes ......."
[cpg cn=true]

Amane In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

[OnName num="shinzi"]
"Stop it ....... Don't ......."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0906"]
[OnName num="amane"]
"'Never mind, Shinji ....... I'd rather do anything ...... than have you blame me. I can do anything. ......
[cpg cn=true]

[FACE method="change_1" pos="4/4"]

[WAIT time=100]
[VOICE f="Shizuku0216"]
[OnName num="shizuku"]
"Yeah, yeah. If you disobey us, you'll never see Mizushima again!
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0907"]
[OnName num="amane"]
"No, you can't do that!　I'll do anything!　I'll do whatever you say!　I don't want your money or your friends, just don't take away Shinji !"
[cpg cn=true]

I can't do this anymore .......
[cpg]

If we get into this situation, Amane will hurt ourselves again with stress.
[cpg]

If we can't get these people away from Amane at all costs, we'll never have peace.
[cpg]

[free time=800]

[OnName num="shinzi"]
"......k".
[cpg cn=true]

However, now I had no weapon whatsoever.
[cpg]

The final weapon that you should have had has disappeared before you knew it,.......
[cpg]

Why ......?
[cpg]

How did the footage that we had saved so well disappear?
[cpg]

Even the machine is disturbing our happiness ......?
[cpg]

[FG f="amane_p1_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0908"]
[OnName num="amane"]
"I'm really sorry about this ....... We are truly sorry for your loss. ......
[cpg cn=true]

[OnName num="shinzi"]
"...... Ugh."
[cpg cn=true]

I can't stand the sight of Amane like this.
[cpg]

It is not for an apology or for the sisters that she is on her knees, but for me.
[cpg]

I'm not sure what to make of this, but I'm sure it's a good idea.
[cpg]



[jump storage="ep020.ks" target="*start"]
