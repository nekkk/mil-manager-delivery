*start


;#################################################
*Ep008|Daily Perversion
;#################################################
[SCENE id=8]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_s_wl_t1_1.ui" time=1000]
;//【ＢＧ】学園　女子更衣室　午前　霧雨




[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="youko_p5_01_a.ui" method="change_2" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Youko0133"]
[OnName num="youko"]
"Have you made up your mind?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0563"]
[OnName num="amane"]
"............"
[cpg cn=true]

When Amane arrived at school that day, he found Yoko waiting for him in the locker room.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0134"]
[OnName num="youko"]
"I'm not sure what to do.　I'm not sure what to do.
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0564"]
[OnName num="amane"]
"I ......"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0135"]
[OnName num="youko"]
"Hmm?
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_3" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0565"]
[OnName num="amane"]
"You can't break up Shinji and ....... I'm not breaking up with you because Shinji you said you'd ...... always love me.
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0136"]
[OnName num="youko"]
"What?
[cpg cn=true]

I thought that Shinji was the one who really said that.
[cpg]

Yoko It's a great way to get the most out of your day.
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0137"]
[OnName num="youko"]
"That's what ...... you're supposed to say to a girl you're dating!　Can't you even understand social graces?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0566"]
[OnName num="amane"]
"Social graces ......?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0138"]
[OnName num="youko"]
"Yeah!　It's the best part of being a boyfriend and girlfriend, to say sweet things like that to each other. You want to say it even if you don't think it. I just wanted to say it!
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0567"]
[OnName num="amane"]
"That's not what ...... is for.
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0139"]
[OnName num="youko"]
"Okay. Okay, look at this.
[cpg cn=true]


[FG f="amane_p5_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0568"]
[OnName num="amane"]
"What...?
[cpg cn=true]

What Yoko took out of his bag was his junior high school graduation book.
[cpg]

He flipped through the pages and spread out his and Shinji 's class pages to show them.
[cpg]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0140"]
[OnName num="youko"]
"It's a great way to get to know a person's personality.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0569"]
[OnName num="amane"]
"Mizushima Shinji ......, favorite type ......, bright and active."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0141"]
[OnName num="youko"]
"Next, look!"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0570"]
[OnName num="amane"]
"I don't like... typ... ............"
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0142"]
[OnName num="youko"]
"What's your least favorite type?
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0571"]
[OnName num="amane"]
"I hate... ...... dark... people."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0143"]
[OnName num="youko"]
"Oh, I thought Shinji didn't like dark people.
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0572"]
[OnName num="amane"]
"..................
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0144"]
[OnName num="youko"]
"Which type are you, Amane Satonaka ?　Bright and lively?　Or are you a dark person?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0573"]
[OnName num="amane"]
"..................
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0145"]
[OnName num="youko"]
"Oh, your face is so dark.
[cpg cn=true]

At that time, both Amane and Yoko were remembering the past time.
[cpg]

That day in elementary school, ......
[cpg]

;//回想シーン（セピア）

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="sir"]
[BG f="b_ex_sk_t2_0.ui" time=1000]
;//【ＢＧ】抽象的な背景（色？　曇り空でもok）


;//水溜まりに転ぶ雨音（９歳）と、見下ろしている陽子とその他の子供達（９歳）


[WAIT time=100]
[VOICE f="Amane0574"]
[OnName num="amane"]
"Wha...wha.........
[cpg cn=true]

[WAIT time=100]
[VOICE f="Youko0146"]
[OnName num="youko"]
"If you like the rain, you'll like the puddles!
[cpg cn=true]

[WAIT time=100]
[VOICE f="Youko0147"]
[OnName num="youko"]
"That's where a girl like you belongs. Get out of here. It's gonna rain!
[cpg cn=true]

[OnName num="child"]
"No, no, no, no, rain girl!
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0575"]
[OnName num="amane"]
"I'm not a rain woman. ......
[cpg cn=true]

[OnName num="child"]
"I'm not a rain woman.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Youko0148"]
[OnName num="youko"]
"Your dad ran away because he didn't like the rain!　That's what my mom said.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0576"]
[OnName num="amane"]
"......!
[cpg cn=true]

[WAIT time=100]
[VOICE f="Youko0149"]
[OnName num="youko"]
"Your mother hated the rain so much she killed herself on a rainy day!
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0577"]
[OnName num="amane"]
"It's ....... It's .......
[cpg cn=true]

[OnName num="child"]
"No, no, no, your curse killed my mom.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0578"]
[OnName num="amane"]
"No, no, no, no, no, no, no, no!
[cpg cn=true]

[WAIT time=100]
[VOICE f="Youko0150"]
[OnName num="youko"]
"Don't come here, you filthy thing!
[cpg cn=true]

[SE f="se023"]
;//【ＳＥ】ドンッ！

[WAIT time=1000]
[SE f="se024"]
;//【ＳＥ】バシャッ！！


[WAIT time=100]
[VOICE f="Amane0579"]
[OnName num="amane"]
"Ugh. ......
[cpg cn=true]

[WAIT time=100]
[VOICE f="Youko0151"]
[OnName num="youko"]
"Guys, come on!　If I stay here with her, the rain will come. My name is Yoko and it's always sunny when I'm with you.
[cpg cn=true]

[OnName num="child"]
"Yay!　The sun Yoko !　 Yoko of the sun!
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0580"]
[OnName num="amane"]
"Ugh... ...... ohhhhhhh!
[cpg cn=true]

;//回想明け

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_wl_t1_1.ui" time=1000]
;//【ＢＧ】学園　女子更衣室　午前　霧雨


[FG f="youko_p5_01_a.ui" method="change_2" pos="4/5" time=800]
[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]

[WAIT time=100]
[VOICE f="Youko0152"]
[OnName num="youko"]
"No matter how hard you try, you'll lose your skin soon. Oh, poor Shinji , she's been deceived."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0581"]
[OnName num="amane"]
".................."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0153"]
[OnName num="youko"]
"Okay, I've made a copy of this page for you, so you can look at it over and over and think!　Bye!
[cpg cn=true]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_s_pa_t1_2.ui" time=1000]
;//【ＢＧ】学園　廊下　午前　霧雨


[OnName num="male_student1"]
"Hey, ......, did he ask you too?
[cpg cn=true]

[OnName num="male_student2"]
"They did. ......
[cpg cn=true]

[OnName num="female_student1"]
"What is it?　It's .......
[cpg cn=true]

[OnName num="female_student1"]
"That was a little out of the ordinary. ......
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

When I arrived at school, I overheard some students whispering about something as they passed me in the hallway.
[cpg]

The tone of the conversation was, "A ghost has appeared ......? The tone was somewhat frightening.
[cpg]

[OnName num="shinzi"]
"What?　What are you talking about?"
[cpg cn=true]

I asked, grabbing a boy I knew.
[cpg]

[OnName num="male_student"]
"That thing, ......, Satonaka ......."
[cpg cn=true]

[OnName num="shinzi"]
" Amane ......?"
[cpg cn=true]

In the direction he was pointing, there was Amane one.
[cpg]

;//画面切り替えエフェクト




[BG f="b_s_pa_t1_0_up.ui" time=1000]
;//【ＢＧ】学園　廊下　午前　霧雨

[WAIT time=2000]

[BGM f="rain"]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[FG f="amane_p1_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0582"]
[OnName num="amane"]
"Um, ...... excuse me ......."
[cpg cn=true]

[OnName num="female_student"]
"What?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0583"]
[OnName num="amane"]
"I'm ...... in the dark. ......
[cpg cn=true]

[OnName num="female_student"]
"Yeah,......, I don't,......, I don't know.
[cpg cn=true]



[free time=500]
[FG f="amane_p4_01_a.ui" method="change_7" pos="4/5" time=1500]
[WAIT time=100]
[VOICE f="Amane0584"]
[OnName num="amane"]
"Okay, ....... Excuse me, ....... ......
[cpg cn=true]

[OnName num="male_student"]
"Yeah, .......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0585"]
[OnName num="amane"]
"I'm ....... Is it dark in here? ......
[cpg cn=true]

[OnName num="male_student"]
"Yeah, I don't know. ......?
[cpg cn=true]

It seems that Amane asks the same question to everyone, and some of the students who noticed it ran away.
[cpg]



[free time=500]
[FG f="amane_p3_01_a.ui" method="change_1" pos="2/5" time=1500]
[WAIT time=100]
[VOICE f="Amane0586"]
[OnName num="amane"]
"'Well, ....... Um ...... excuse me ......"

[cpg cn=true]

[OnName num="shinzi"]
" Amane !　What are you doing!　What the hell is wrong with you?
[cpg cn=true]

[free time=800]
[FG f="amane_p5_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0587"]
[OnName num="amane"]
"Shh, Shinji , ......, Shinji !
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

Your voice went up an octave on the way to ......?
[cpg]

[FG f="amane_p6_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0588"]
[OnName num="amane"]
" Shinji !　Good morning!
[cpg cn=true]

[OnName num="shinzi"]
"Oh, good morning, .......
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0589"]
[OnName num="amane"]
"You have gym class today, right?　I love PE!
[cpg cn=true]

[OnName num="shinzi"]
"Is that ......?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0590"]
[OnName num="amane"]
"Yeah, yeah!　I can jump the vault!　I can run a marathon!　I love to move my body!
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, .......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0591"]
[OnName num="amane"]
"Ahahahahaha."
[cpg cn=true]

The face of Amane , who speaks in a bright voice, looked unnaturally distorted.
[cpg]

This is a great way to get the most out of your business.
[cpg]

[OnName num="shinzi"]
"What's wrong!　What's wrong!"
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0592"]
[OnName num="amane"]
"Nothing!　Nothing!　Don't say anything funny!
[cpg cn=true]

[OnName num="shinzi"]
".........?"
[cpg cn=true]

Noticing that the people around me were clearly whispering, I entered the classroom, trying to hide Amane .
[cpg]

It is obviously strange.
[cpg]

I wonder what ...... happened to Amane .
[cpg]

[SE f="se009"]
;//【ＳＥ】チャイム

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_sy_t1_1.ui" time=1000]
;//【ＢＧ】学園　校庭　午前　霧雨




;//霧雨


Physical education class began, and the entire class changed into their gym clothes and gathered in the schoolyard.
[cpg]

But no matter how long it takes, they don't Amane come out easily.
[cpg]

[OnName num="teacher"]
"It's raining a bit, but if it's this bad, we'll have class outside. Attendance number~"
[cpg cn=true]

[OnName num="male_student1"]
"One!"
[cpg cn=true]

[OnName num="male_student2"]
"Two!"
[cpg cn=true]

The fact that I couldn't see her even after the attendance check started made me nervous.
[cpg]

When the roll call moved to the girls, it was soon Amane their turn.
[cpg]

[OnName num="teacher"]
"'Yeah?　Who's not here?　I'm sure you'll be able to figure it out.　Satonaka, aren't you there?
[cpg cn=true]



[WAIT time=100]
[VOICE f="Amane0593"]
[OnName num="amane"]
"Yes, I'm ...... here."
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

[SE f="se053"]
;//【ＳＥ】ザワ…ッ


;//泥まみれの体育着を着ている雨音
[FG f="amane_p5_12_a.ui" method="change_1" pos="2/3" time=800]

[OnName num="teacher"]
"What the hell are you wearing?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0594"]
[OnName num="amane"]
"Sorry, .......
[cpg cn=true]

Amane This is a great way to make sure you are getting the most out of your vacation.
[cpg]

This is a great way to get the most out of your time with your family and friends.
[cpg]

[OnName num="shinzi"]
"What's wrong with you?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0595"]
[OnName num="amane"]
"I fell........."
[cpg cn=true]

[OnName num="teacher"]
"You fell!　Were you in a hurry because you were late?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0596"]
[OnName num="amane"]
"Yes, ....... Sorry. ......
[cpg cn=true]

[OnName num="teacher"]
"I can't help it. Ha-ha-ha.
[cpg cn=true]

[OnName num="shinzi"]
"..................
[cpg cn=true]

[OnName num="Students"]
".................."
[cpg cn=true]

The teacher laughed a silly laugh, but none of the students laughed.
[cpg]

The teacher laughed, but none of the students laughed, because they knew that the stain on Amane 's gym clothes was not from a fall.
[cpg]

Because it is, isn't it?
[cpg]

The gym clothes were covered in mud from all angles, front and back, shirt and pants.
[cpg]

In order to get dirty like that, you have to roll around in the mud.
[cpg]

No matter how spectacularly he fell, there was no way he could get that dirty.
[cpg]

[SE f="se053"]
;//【ＳＥ】ヒソヒソヒソ……


[OnName num="male_student"]
"Something must have ...... happened.
[cpg cn=true]

[OnName num="female_student"]
"It's not bullying. ......?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0597"]
[OnName num="amane"]
"Oh, ...... ah, ......."
[cpg cn=true]

Amane In the event that you have any kind of questions regarding where and how to use the internet, you can contact us at our own web site.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0598"]
[OnName num="amane"]
"This is a great way to make sure you are getting the most out of your money.　I'm sorry!　I'll clean it up right now!
[cpg cn=true]

[SE f="se010"]
;//【ＳＥ】ダッシュ

[FO pos="2/3" time=800]

[OnName num="shinzi"]
" Amane !"
[cpg cn=true]

Suddenly, the entire class was stunned by Amane running out.
[cpg]

Amane In the event that you're not sure what you're looking for, you may want to check out the following tips.
[cpg]

[SE f="se024"]
;//【ＳＥ】放水


[OnName num="shinzi"]
"What?"
[cpg cn=true]

Amane It's a great way to make sure you're getting the most out of your time at the gym.
[cpg]

[FG f="amane_p1_12_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0599"]
[OnName num="amane"]
"You'll be clean ...... in no time!"
[cpg cn=true]

Amane It's a great way to make sure you're getting the most out of your vacation.
[cpg]

As we stand there dumbfounded,.......
[cpg]

[SE f="se069"]
;//【ＳＥ】ポツポツ……ザーーーーッ！
;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

[WAIT time=5000]

;//loop
[SE f="se003" loop=true]

;//霧が粒に変わり、土砂降りになる


This is a great way to make sure you are getting the best value for your money.
[cpg]

[OnName num="teacher"]
"I'm not sure what to say.　You guys, hurry up and get inside!
[cpg cn=true]

[SE f="se053"]
;//【ＳＥ】阿鼻叫喚


The students rushed out like a spider scattering.
[cpg]

But only the Amane and me who stare at her stay in the same place on the spot.
[cpg]




[free time=800]
;**【ＣＧ】ev_26_0 ***********************
[CG id=9 index=0 time=1000]
;*****************************************





[WAIT time=100]
[VOICE f="Amane0600"]
[OnName num="amane"]
"I'm not sure what to do.　It's so beautiful, it's so beautiful~!　Ahahahahaha!"
[cpg cn=true]

[OnName num="shinzi"]
"Oh, Amane ............."
[cpg cn=true]

I threw the hose out, looked up at the sky in a big way, and rubbed my chest with my hands Amane to see ......
[cpg]

I was gripped by an unfathomable sense of emptiness.
[cpg]

I don't know ...... how to understand her.
[cpg]

;//教室の窓（２階）越しに、その光景を見ている悲痛な表情の雫


;//※この絵は入れて欲しいです


[free time=800]



[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BG f="b_s_sy_t1_1.ui" time=1000]
;//【ＢＧ】学園　校庭　午前　霧雨



[WAIT time=100]
[VOICE f="Shizuku0084"]
[OnName num="shizuku"]
"The Amane seniors ......?"
[cpg cn=true]

It was not only the people of 2-C who were watching the scene, which was taking place on the school ground.
[cpg]

From the window of the classroom on the second floor, Shizuku Kizaki follows her figure and actions with a sad expression in his eyes.
[cpg]

Her eyes never let go of the sight of Amane . No, they're glued to it.
[cpg]

Amane Satonaka This is a great way to make sure that you get the most out of your time and money.
[cpg]


[WAIT time=100]
[VOICE f="Shizuku0085"]
[OnName num="shizuku"]
"(Senior ...... what are you doing...?)
[cpg cn=true]

You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

If you can figure out what the hell is going on and what she's doing, you'll have no trouble.
[cpg]

In the event that it is raining, wouldn't you normally head for the eaves or someplace where you can take shelter from the rain?
[cpg]


[WAIT time=100]
[VOICE f="Shizuku0086"]
[OnName num="shizuku"]
"(Why are you smiling...?)"
[cpg cn=true]

He's happily getting drenched in the rain and cleaning the dirt off his gym clothes.
[cpg]

With that scene and the atmosphere emanating from the Amane person himself, she must have sensed... that something was wrong.
[cpg]

[OnName num="teacher"]
" Kizaki -?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0087"]
[OnName num="shizuku"]
"......"
[cpg cn=true]

[OnName num="teacher"]
"Hey, Kizaki . - ...... Shizuku Kizaki !
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0088"]
[OnName num="shizuku"]
"Uh... yes... yes... yes!
[cpg cn=true]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]



[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_s_2f_t1_0.ui" time=1000]
;//【ＢＧ】学園　２Ｆ教室（雫）　午前　霧雨


;//ガタッ。立ち上がる雫。

Shizuku In the event that you've got a lot of time, you'll be able to take a look at the following.
[cpg]

[FG f="shizuku_p5_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0089"]
[OnName num="shizuku"]
"I'm not sure what to say.
[cpg cn=true]

In the event that you've got a lot of money, you'll be able to use it for a lot of things.
[cpg]

[OnName num="teacher"]
"I'm not sure what to do.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0090"]
[OnName num="shizuku"]
"I'm sorry...
[cpg cn=true]

[OnName num="classmate"]
"Couscous..."
[cpg cn=true]

In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

Shizuku In the event that you've got a lot of money, you're going to need to be able to pay for it.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0091"]
[OnName num="shizuku"]
"( Amane seniors ......)"
[cpg cn=true]

It's also a great way to get the most out of your business.
[cpg]

Shizuku It's a good idea to have a good idea of what you're looking for.
[cpg]

This is a great way to make sure that you are getting the most out of your time with your family and friends.
[cpg]

Amane Satonaka I'm not sure what to say, but I'm going to say it.
[cpg]

[jump storage="ep009.ks" target="*start"]
