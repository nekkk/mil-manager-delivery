*start



;#################################################
*Ep010|evil hand.
;#################################################
[SCENE id=10]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_s_sr_t1_1.ui" time=1000]
;//【ＢＧ】学園　理科室　午前　霧雨




[FG f="amane_p5_01_a.ui" method="change_7" pos="2/5" time=1000]
[FG f="youko_p5_01_a.ui" method="change_7" pos="4/5" time=1000]
[WAIT time=100]
[VOICE f="Youko0154"]
[OnName num="youko"]
"You're a good girl, aren't you? After all, this is how you follow me."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0607"]
[OnName num="amane"]
".................."
[cpg cn=true]

The next day, Amane was called by Yoko in the science lab.
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0155"]
[OnName num="youko"]
"I'm not a demon either. If you have something to say, I'll listen.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0608"]
[OnName num="amane"]
"I ...... don't mind.
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0156"]
[OnName num="youko"]
"What?
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0609"]
[OnName num="amane"]
"I'm fine with it. I talked to Shinji a lot yesterday, and he said I could trust him. So I don't care what ...... or Yoko does to me.
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Youko0157"]
[OnName num="youko"]
"Hmmm, hmmm ...... so."
[cpg cn=true]

I was pissed.
[cpg]

In the elementary school, you were bullied and sore ......, Yoko thought looking at the current Amane .
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

The fact that this is due to his relationship with Shinji also makes him angry.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0158"]
[OnName num="youko"]
"But Shinji doesn't like rain girls, you know?"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0610"]
[OnName num="amane"]
" Shinji said she likes the rain. That's why we're friends.
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0159"]
[OnName num="youko"]
"What the hell, ......?
[cpg cn=true]

In fact, I've never heard of Shinji liking or disliking rain.
[cpg]

But I was annoyed that Amane knew something about Shinji that I didn't know.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0160"]
[OnName num="youko"]
"Do you know ............ this?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0611"]
[OnName num="amane"]
"......?"
[cpg cn=true]

Yoko pointed abruptly to a specimen.
[cpg]

It was a small round frog of an unusual color, soaked in formalin.
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0161"]
[OnName num="youko"]
"This is a very valuable specimen. Do you know what it's called?　It's called a Desert Rain Frog.
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0612"]
[OnName num="amane"]
"It's at ................
[cpg cn=true]

Why Yoko started to explain about the frog in this situation, Amane can not measure the true meaning.
[cpg]

However, Yoko continued to speak without regard to Amane .
[cpg]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0162"]
[OnName num="youko"]
"What do you think it means?　Desert rain frog. Is it a frog that uses rain as its dessert?　Oh, or does it mean ...... a rain frog for dessert?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0613"]
[OnName num="amane"]
"......?
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0163"]
[OnName num="youko"]
"If it's dessert, it must be good!　You should try it.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_5" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0614"]
[OnName num="amane"]
"What?
[cpg cn=true]

[move from="4/5" to="4/6" ease="easeInOutSine" time=100]

[SE f="se060"]
;//【ＳＥ】ガチャーン！
[WAIT time=100]

[move from="4/6" to="4/5" ease="easeInOutSine" time=100]

[FG f="amane_p6_01_a.ui" method="change_4" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0615"]
[OnName num="amane"]
"Yuck!
[cpg cn=true]

Yoko suddenly slammed the specimen on the floor.
[cpg]

This is a great way to get the most out of your time and money.
[cpg]

[SE f="se094"]
;//【ＳＥ】トング鳴らす（カチ…カチ…）

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0164"]
[OnName num="youko"]
Amane "This is a great way to make sure you get the most out of your time with your family.
[cpg cn=true]

Yoko In the event that you've got a lot of money, you'll be able to take advantage of the fact that you'll be able to get a lot more.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_5" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0616"]
[OnName num="amane"]
"What ...... are you doing?
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0165"]
[OnName num="youko"]
"Yes, let's eat!
[cpg cn=true]

[SE f="se085"]
;//【ＳＥ】びちゃ……っ

[move from="4/5" to="3/5" ease="easeInOutSine" time=800]



[WAIT time=100]
[VOICE f="Amane0617"]
[OnName num="amane"]
"I'm sorry.
[cpg cn=true]

The frog was shoved into his mouth, and Amane was astonished.
[cpg]

This is a great way to make sure that you don't end up with a lot of problems.
[cpg]

[move from="3/5" to="4/5" ease="easeInOutSine" time=800]
[FG f="amane_p6_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0618"]
[OnName num="amane"]
"Ew!　Ohhhh!"
[cpg cn=true]

I vomit from the pungent smell and disgustingness.
[cpg]


[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0166"]
[OnName num="youko"]
"I'm sure you'll be happy to hear that.
[cpg cn=true]

[SE f="se085"]
;//【ＳＥ】べちゃ…ぬちゃ…っ

[move from="4/5" to="3/5" ease="easeInOutSine" time=1000]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0619"]
[OnName num="amane"]
"No, no, no. ......!
[cpg cn=true]

The frog's carcass is pressed against your cheeks and lips.
[cpg]

[move from="3/5" to="4/5" ease="easeInOutSine" time=1000]
This is a great way to make sure that you get the most out of your vacation.
[cpg]

Then ......
[cpg]

[free time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="danger"]
[BG f="b_s_sr_t1_1.ui" time=1000]
;//【ＢＧ】学園　理科室　午前　霧雨
[WAIT time=1000]

[SE f="se008"]
;//【ＳＥ】横開きのドア開く


[FG f="youko_p5_01_a.ui" method="change_5" pos="2/3" time=800]
[FG f="amane_p5_01_a.ui" method="change_1" pos="1/3" time=800]

[FG f="shizuku_p5_01_a.ui" method="change_5" pos="4/3" time=800]
[WAIT time=100]
[VOICE f="Youko0167"]
[OnName num="youko"]
"What?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0620"]
[OnName num="amane"]
"!!!"
[cpg cn=true]

The door of the science room opened and someone came in.
[cpg]

Yoko thought, "Oh no! and Amane thought, "Thank God! But which of the two will win? ......
[cpg]


[move from="4/3" to="3/3" ease="easeInOutSine" time=800]

[WAIT time=100]
[VOICE f="Shizuku0133"]
[OnName num="shizuku"]
"............!"
[cpg cn=true]

[FACE method="change_2" pos="1/3"]

[WAIT time=100]
[VOICE f="Amane0621"]
[OnName num="amane"]
" Shizuku !"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0168"]
[OnName num="youko"]
"............!"
[cpg cn=true]

It was Shizuku that came to me.
[cpg]

This is a great way to make sure you are getting the most out of your time with us.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Amane0622"]
[OnName num="amane"]
" Shizuku , help .......
[cpg cn=true]

[FACE method="change_1" pos="3/3"]

[WAIT time=100]
[VOICE f="Shizuku0134"]
[OnName num="shizuku"]
".................."
[cpg cn=true]

Amane then saw the expression on Shizuku 's face and realized the despair .......
[cpg]

It was not upset, it was not astonished, Shizuku 's face was just expressionless.
[cpg]

I don't know why that is.
[cpg]

But I knew that he hated me.
[cpg]

The look on his face was enough to convince me that Shizuku was no longer on my side.
[cpg]

[BGM f="insecurity"]


[FG f="shizuku_p5_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0135"]
[OnName num="shizuku"]
".................."
[cpg cn=true]




[SE f="se093"]
;//【ＳＥ】スマホをプッシュする（カチカチカチ）





Then Shizuku silently takes out his old phone and starts to operate something.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0169"]
[OnName num="youko"]
"...... ha!"
[cpg cn=true]

Yoko saw that and the expression on Shizuku 's face, and knew that her luck had not run out.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0170"]
[OnName num="youko"]
"'Rain girl, look, there's still some left, okay?　I'm not sure what to do. Ahn."
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[move from="2/3" to="3/6" ease="easeInOutSine" time=1000]
[WAIT time=100]
[VOICE f="Amane0623"]
[OnName num="amane"]
"Mggghhh!　Oh, no!"
[cpg cn=true]

The frog's carcass is relentlessly pressed against my face, even when I turn my head away to get rid of it.
[cpg]

[FACE method="change_4" pos="1/3"]

[WAIT time=100]
[VOICE f="Amane0624"]
[OnName num="amane"]
"Oh, no!
[cpg cn=true]




[SE f="se010"]
;//【ＳＥ】ダッシュ





Amane In the event that you're not able to get a hold of one, you'll be able to get a hold of a lot more.
[cpg]




[SE f="se008"]
;//【ＳＥ】横開きのドア開く





[FG f="shizuku_p5_01_a.ui" method="change_1" pos="4/4" time=800]
[FG f="izumi_p5_01_a.ui" method="change_1" pos="3/4" time=800]
[FG f="youko_p5_01_a.ui" method="change_7" pos="2/4" time=800]
[FG f="amane_p5_01_a.ui" method="change_5" pos="1/4" time=800]

[WAIT time=100]
[VOICE f="Izumi0131"]
[OnName num="izumi"]
"....................."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0625"]
[OnName num="amane"]
"What?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0171"]
[OnName num="youko"]
"Student body president ......"
[cpg cn=true]

In a huff, Yoko looked at Shizuku , and the little underclassman trotted off and hid behind his sister.
[cpg]

Well, what's the ...... matter, Yoko breathed.
[cpg]

If Shizuku you are going to pretend to be calm and call your sister and tell her she is a bully, there is nothing left to do.
[cpg]

But ......
[cpg]

[FACE method="change_7" pos="3/4"]

[WAIT time=100]
[VOICE f="Izumi0132"]
[OnName num="izumi"]
"You are, I believe, a sophomore ......
[cpg cn=true]

[FACE method="change_1" pos="2/4"]

[WAIT time=100]
[VOICE f="Youko0172"]
[OnName num="youko"]
"I'm Yoko Minegishi . ......"
[cpg cn=true]

In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

[FACE method="change_1" pos="3/4"]

[WAIT time=100]
[VOICE f="Izumi0133"]
[OnName num="izumi"]
"I'm not sure what you're doing here, but I'd like to know what you're doing. ......
[cpg cn=true]

What do you mean "what"?
[cpg]

Yoko This is a great way to get the most out of your business.
[cpg]

[FACE method="change_7" pos="2/4"]

[WAIT time=100]
[VOICE f="Youko0173"]
[OnName num="youko"]
"I was trying to get him to eat because Amane he loves frogs.
[cpg cn=true]

[FACE method="change_7" pos="3/4"]

[WAIT time=100]
[VOICE f="Izumi0134"]
[OnName num="izumi"]
"'Desert Rainfrog ....... Oh, is that what you mean?"
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_4" pos="1/4" time=800]
[WAIT time=100]
[VOICE f="Amane0626"]
[OnName num="amane"]
"..................."
[cpg cn=true]

Oh ......, and a voice of disappointment leaked from my heart.
[cpg]

I was a fool for expecting help.
[cpg]

It's the same as when you were a child.
[cpg]

No one is going to help you.
[cpg]

Everyone who shows up is a part of the bullying.
[cpg]

There is no one on your side. ......
[cpg]

[FACE method="change_7" pos="1/4"]

[WAIT time=100]
[VOICE f="Amane0627"]
[OnName num="amane"]
" Shinji ... kun ......."
[cpg cn=true]

But I have Shinji .
[cpg]

I'm not sure what to make of it.
[cpg]

I'm not sure what to do.
[cpg]

So no matter what happens, if you go to him, you will be saved.
[cpg]

Amane decided to think only of the light Shinji in his heart.
[cpg]

[FACE method="change_1" pos="3/4"]

[WAIT time=100]
[VOICE f="Izumi0135"]
[OnName num="izumi"]
"' Minegishi , you are very kind, but formaldehyde is dangerous.
[cpg cn=true]

[FACE method="change_1" pos="2/4"]

[WAIT time=100]
[VOICE f="Youko0174"]
[OnName num="youko"]
The "is ......"
[cpg cn=true]

[FACE method="change_7" pos="3/4"]

[WAIT time=100]
[VOICE f="Izumi0136"]
[OnName num="izumi"]
"Look, Satonaka your face is already turning red. You poor thing.
[cpg cn=true]

[FACE method="change_7" pos="2/4"]

[WAIT time=100]
[VOICE f="Youko0175"]
[OnName num="youko"]
"I'm sorry. ......
[cpg cn=true]

The point of contention is not right, but Yoko is relieved to see that the student body president has no intention of blaming himself.
[cpg]

It's a good idea to have a good idea of what you're doing.
[cpg]

[FACE method="change_1" pos="3/4"]

[WAIT time=100]
[VOICE f="Izumi0137"]
[OnName num="izumi"]
" Shizuku , go wash poor Satonaka 's face.
[cpg cn=true]

[FACE method="change_7" pos="4/4"]

[WAIT time=100]
[VOICE f="Shizuku0136"]
[OnName num="shizuku"]
"Yeah, .......
[cpg cn=true]

[FACE method="change_7" pos="3/4"]

[WAIT time=100]
[VOICE f="Izumi0138"]
[OnName num="izumi"]
"There's a mop around here, isn't there?　If you use a rag, you'll get a rash on your hands.
[cpg cn=true]

[FACE method="change_1" pos="4/4"]

[WAIT time=100]
[VOICE f="Shizuku0137"]
[OnName num="shizuku"]
"Yes. ......
[cpg cn=true]

[SE f="se061"]
;//【ＳＥ】水道

[BGM f="danger"]

[free time=800]

Shizuku Amane In the event that you have any kind of questions regarding where and how to use the internet, you can contact us at our own web site.
[cpg]




[SE f="se085"]
;//【ＳＥ】ビチャ……

[FG f="shizuku_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[FG f="amane_p5_01_a.ui" method="change_4" pos="1/3" time=800]


[WAIT time=100]
[VOICE f="Amane0628"]
[OnName num="amane"]
"I'm not sure what to say.　 Shizuku I'm sure you'll be able to figure out what's going on.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0138"]
[OnName num="shizuku"]
".................."
[cpg cn=true]

[SE f="se085"]
;//【ＳＥ】ビチャッビチャッ

[FACE method="change_7" pos="2/3"]



[WAIT time=100]
[VOICE f="Shizuku0139"]
[OnName num="shizuku"]
"You... are... bad. ......
[cpg cn=true]

[move from="2/6" to="2/3" ease="easeInOutSine" time=800]
[FACE method="change_5" pos="1/3"]

[WAIT time=100]
[VOICE f="Amane0629"]
[OnName num="amane"]
"What?
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0140"]
[OnName num="shizuku"]
"It's your fault!　It's your fault!
[cpg cn=true]

[SE f="se085"]
;//【ＳＥ】ビチャッビチャッ！

[move from="2/3" to="3/6" ease="easeInOutSine" time=800]

[FACE method="change_4" pos="1/3"]

[WAIT time=100]
[VOICE f="Amane0630"]
[OnName num="amane"]
"Bub!　Pfft!
[cpg cn=true]

Shizuku In the event that you have any questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

Amane This is a great way to make sure that you don't end up in a situation where you're not the only one.
[cpg]




It's all ...... this guy's fault that I'm being kicked around!
[cpg]


[WAIT time=100]
[VOICE f="Shizuku0141"]
[OnName num="shizuku"]
"I'm not sure what to say.　This!
[cpg cn=true]


[BG f="b_s_sr_t1_1_up.ui" time=0]
[free time=0]

[FG f="izumi_p5_01_a.ui" method="change_2" pos="2/5" time=0]
[FG f="youko_p5_01_a.ui" method="change_5" pos="4/5" time=0]

[WAIT time=100]
[VOICE f="Izumi0139"]
[OnName num="izumi"]
".........ffffffffffff!"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0176"]
[OnName num="youko"]
"......!"
[cpg cn=true]

Yoko felt something strange in the transformation of the quiet Shizuku and the expression of the intelligent Izumi .
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

The friends who came to the place where I was tormenting Amane all took Yoko 's side and tormented Amane together.
[cpg]

It's the same now.
[cpg]

I'm sure they will continue to do so.
[cpg]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0177"]
[OnName num="youko"]
"I'm glad you got it cleaned up!　Rain girl."
[cpg cn=true]


[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Izumi0140"]
[OnName num="izumi"]
"Rain Girl?"
[cpg cn=true]


[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0178"]
[OnName num="youko"]
"That's her nickname. She loves the rain. It always rains when she's around.
[cpg cn=true]


[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Izumi0141"]
[OnName num="izumi"]
"Well, that's lovely. Her father doesn't like the rain because you're a rain girl, is that it?
[cpg cn=true]


;//[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Amane0631"]
[OnName num="amane"]
"What?
[cpg cn=true]

Amane was deeply surprised by the words of Izumi .
[cpg]

How does he know about his father, and how does he know that his father hates rain?
[cpg]

But there was no way Izumi was going to let him ask questions.
[cpg]


[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Izumi0142"]
[OnName num="izumi"]
"'It's raining outside, you know?　Why don't you go and have a bath like you always do?"
[cpg cn=true]

[free time=800]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_sr_t1_1.ui" time=1000]
;//【ＢＧ】学園　理科室　午前　霧雨

[WAIT time=1000]

[SE f="se014"]
;//【ＳＥ】スチールドア開け放つ

[WAIT time=1000]

;//loop
[SE f="se007" loop=true]
;//【ＳＥ】外の雨の音（ザー）

[FG f="amane_p5_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="shizuku_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[FG f="izumi_p5_01_a.ui" method="change_1" pos="5/6" time=800]
[FG f="youko_p5_01_a.ui" method="change_2" pos="6/6" time=800]


[WAIT time=100]
[VOICE f="Youko0179"]
[OnName num="youko"]
"You're the student body president!　Good idea.
[cpg cn=true]

The science room faced the schoolyard and had an escape door on the wall.
[cpg]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0142"]
[OnName num="shizuku"]
"If you go quickly ......
[cpg cn=true]

[SE f="se023"]
;//【ＳＥ】ドンッ！

[move from="2/3" to="2/5" ease="easeInOutSine" time=200]
[move from="1/3" to="1/8" ease="easeInOutSine" time=800]
[FO pos="1/8" time=800]


[WAIT time=100]
[VOICE f="Amane0632"]
[OnName num="amane"]
"Aaah!
[cpg cn=true]

This is a great way to get the most out of your time with your family and friends. Amane is pushed outside by Shizuku and left alone in the rain.
[cpg]


[free time=800]

;//loop
[stopse g=2]
[stopse g=6]

[SE f="se015"]
;//【ＳＥ】ドアに鍵



[FG f="izumi_p5_01_a.ui" method="change_7" pos="2/5" time=800]
[FG f="youko_p5_01_a.ui" method="change_1" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Youko0180"]
[OnName num="youko"]
"Um, Mr. Chairman,.......
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Izumi0143"]
[OnName num="izumi"]
"I'd like to have a long talk with you. ......
[cpg cn=true]



;//回想シーン（セピア）
[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="sir"]
[BG f="b_a_old_t1_0.ui" time=1000]
;//【ＢＧ】過去の雨音の家　リビング

;//家を出て行く父と、憔悴する母と幼い雨音


[OnName num="mother"]
"You!　Wait, don't go!
[cpg cn=true]

[OnName num="father"]
"Shut up!　I gave you the money!
[cpg cn=true]

[OnName num="mother"]
"I don't want your money! I want you to be a father to my child!
[cpg cn=true]

[OnName num="father"]
"Fuck you!　This goddamn thing is ruining my life!
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0633"]
[OnName num="amane"]
"Dad. ......
[cpg cn=true]

[OnName num="father"]
"It's your fault, .......... Amane . You make it rain all the time. I hate the rain!
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0634"]
[OnName num="amane"]
"You!
[cpg cn=true]

[OnName num="mother"]
"You!
[cpg cn=true]

[OnName num="father"]
"See you!
[cpg cn=true]

[SE f="se006"]
[SE f="se132"]
;//【ＳＥ】雨の中去っていく足音





[WAIT time=100]
[VOICE f="Amane0635"]
[OnName num="amane"]
"Mom, ....... Is it my fault ......?　You don't like the rain, either. ......?
[cpg cn=true]

[OnName num="mother"]
"Didn't I tell you ......?　She loves the rain. That's why she loves Amane you too. Don't cry, ....... ほら、お歌うたってあげる......♪あめあめふれふれ 母さんが......蛇の目でお迎え嬉しいな......」
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0636"]
[OnName num="amane"]
"Pitter-patter, chirp-chirp, run-run-run."
[cpg cn=true]

[OnName num="mother"]
" Amane , I love you, ....... Mom likes the rain. ......
[cpg cn=true]

;//回想明け

[stopse g=2]
[stopse g=6]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BG f="b_s_sy_t1_1.ui" time=1000]
;//【ＢＧ】学園　校庭　午前　霧雨


;//天を仰ぎ、雨に打たれる雨音


[FG f="amane_p8_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0637"]
[OnName num="amane"]
"♪ Pitch-pitch... chap-chap ...... run... run... run ......... ..."
[cpg cn=true]


[SE f="se069"]
;//【ＳＥ】雨


;//エフェクト

[free time=400]
[WAIT time=1400]
[BG f="black.ui" time=900]
[WAIT time=1900]
[BGM f="eye2"]
[BG f="b_s_3f_t1_2.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午前　雨

[stopse g=2]
[stopse g=6]

When the first period class started, there was no sign of Amane the classroom.
[cpg]

When the class started and a few minutes passed, it was thought to be absent ......
[cpg]

[OnName num="male_student"]
"Oh, hey, ...... that ...... thing."
[cpg cn=true]

[OnName num="female_student"]
"What are you doing ......?"
[cpg cn=true]

[SE f="se053"]
;//【ＳＥ】ザワザワ


The students by the window began to whisper, and soon it spread to the whole class.
[cpg]

[OnName num="shinzi"]
"What ......?　......?
[cpg cn=true]

;//両手を広げて校庭に立つ雨音


[free time=800]



In the rain-drenched schoolyard, the figure of Amane standing with his hands outstretched.
[cpg]

It's not just our class, but gradually students and teachers of various classes peeked out of the window and witnessed the scene.
[cpg]

[stopse g=2]
[stopse g=6]

;//[free time=900]
;//[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
;//[BG f="b_s_3f_t1_2.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午前　雨


[OnName num="teacher"]
"'Oh, you guys stay here!
[cpg cn=true]

[SE f="se008"]
;//【ＳＥ】ドア開く

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_s_pa_t1_1.ui" time=1000]
;//【ＢＧ】学園　廊下　午前　雨





[OnName num="shinzi"]
"'' Amane ......!　Why ......!"
[cpg cn=true]

Ignoring the teacher's unspoken words, I ran out of the classroom and headed for the schoolyard.
[cpg]

;//loop
[SE f="se006" loop=true]
;//【ＳＥ】雨の中を走る

[SE f="se132"]
;//【ＳＥ】ダッシュ




[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_s_sy_t1_0.ui" time=1000]
;//【ＢＧ】学園　校庭　午前　小雨

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]



[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]

[OnName num="shinzi"]
" Amane !
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0638"]
[OnName num="amane"]
" Shinji ku...n ......"
[cpg cn=true]

[OnName num="shinzi"]
"That face!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0639"]
[OnName num="amane"]
"What ......?"
[cpg cn=true]

Amane It's a good idea to have a good idea of what you're looking for.
[cpg]

I don't know how this happened!
[cpg]


[FG f="amane_p7_02_a.ui" method="change_7" pos="2/3" time=800]


[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Amane0640"]
[OnName num="amane"]
"Face ...... strange?　My face, strange!"
[cpg cn=true]

[OnName num="shinzi"]
"''Doesn't it hurt!
[cpg cn=true]

Her lips are also rough and red and ragged, but whether she doesn't feel pain or doesn't realize it, Amane she strokes her face with both hands and repeats the same words over and over.
[cpg]


[WAIT time=100]
[VOICE f="Amane0641"]
[OnName num="amane"]
"'What's wrong with my face!
[cpg cn=true]

[OnName num="shinzi"]
"Anyway, to the infirmary!"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0642"]
[OnName num="amane"]
" Shinji !　What's wrong with my face?　I've become the face you hate!　You don't like my face?
[cpg cn=true]

[OnName num="shinzi"]
"That's not what I said!　It hurts. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0643"]
[OnName num="amane"]
"I don't care if it hurts!　No, I'm asking you!　 I'm becoming the face that Shinji hates!　 Shinji is going to hate me!　 Shinji is going to leave me!　I'm gonna be dumped by Shinji ?
[cpg cn=true]

[OnName num="shinzi"]
"No!
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0644"]
[OnName num="amane"]
"No, no, no, no, no. ！！！！
[cpg cn=true]

Amane bobbed his head and arms and stomped his feet in a jittery frenzy.
[cpg]


[stopse g=2]
[stopse g=6]

[SE f="se074"]
;//【ＳＥ】バチャバチャバチャ！（水溜まり踏み鳴らす）

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="danger"]
[BG f="b_s_sy_t1_0.ui" time=1000]
;//【ＢＧ】学園　校庭　午前　雨


[OnName num="teacher1"]
"Calm down!
[cpg cn=true]

[OnName num="teacher2"]
"I'm sure you'll agree.
[cpg cn=true]

It's a great way to make sure you're getting the most out of your time with your family. It's a great way to make sure you're getting the most out of your vacation.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

[FG f="amane_p6_02_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0645"]
[OnName num="amane"]
"I'm not sure what to do.
[cpg cn=true]

It's a great way to make sure you're getting the most out of your day.
[cpg]

No, it could have been a shout or a yell.
[cpg]

[FG f="amane_p5_02_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0646"]
[OnName num="amane"]
"I'm talking to Shinji right now!　So don't interrupt me!
[cpg cn=true]

The rough words were released to the teachers who tried to stop them. Amane In the event you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

This is a great way to make sure that you are getting the most out of your money.
[cpg]

That's how abnormal the current Amane is.
[cpg]

[FG f="amane_p7_02_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0647"]
[OnName num="amane"]
"Hey, Shinji !　Answer me!　Please!"
[cpg cn=true]

[OnName num="shinzi"]
"So!　I don't hate you...
[cpg cn=true]

Amane You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0648"]
[OnName num="amane"]
"I'm not sure if you can hear me, Shinji .　I'm sure you can hear me.　It's not just the face, but the voice as well.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0649"]
[OnName num="amane"]
"You don't just hate my face, you hate my voice too!　I can't get Shinji to love me anymore?　There's nothing left to love about me!
[cpg cn=true]

Either he didn't hear me, or he didn't want to hear me... Amane rambled on.
[cpg]

This is a great way to get the most out of your business. I'm sure the teachers feel the same way.
[cpg]

[OnName num="shinzi"]
"No, no, no!　Why would you do that?　Are you listening to me right?
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0650"]
[OnName num="amane"]
" Shinji here!　Are you even listening to me?
[cpg cn=true]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0651"]
[OnName num="amane"]
"I'm sure you'll agree.　I'm listening!　 Shinji I'm not sure what to make of this, but I think it's a good idea.　Do you even want to hear my voice anymore?　I...
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0652"]
[OnName num="amane"]
"I'm... Shinji hates me!　He hates me?　I've been dumped by Shinji !"
[cpg cn=true]

Every time she speaks, she gets weirder and weirder. The content of what she was saying went from the progressive tense to the past tense before she knew it... and the conversation progressed on its own in Amane .
[cpg]

It's not a proper conversation. No, it's not even a conversation.
[cpg]

[OnName num="shinzi"]
" Amane ......"
[cpg cn=true]

I kept my mouth shut in such a situation.
[cpg]

In the event that you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

But if you don't deny it... it will be taken as an affirmation.
[cpg]

[FG f="amane_p5_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0653"]
[OnName num="amane"]
"'I knew it... I knew it!
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0654"]
[OnName num="amane"]
"' Shinji doesn't like me anymore!　You hated me!　You hated me!"
[cpg cn=true]

This is a great way to make sure you are getting the most out of your investment.
[cpg]

I'm sure... even if something else is interrupted in the middle, the destination is the same.
[cpg]

Amane You can find a lot of things that you can do to make your life easier.
[cpg]

[OnName num="shinzi"]
" Amane , fall..."
[cpg cn=true]

Anyway, I thought I had to appease Amane and tried to call her to calm down.
[cpg]

[FG f="amane_p1_02_a.ui" method="change_3" pos="2/3" time=800]


[OnName num="teacher1"]
"Just calm down!"
[cpg cn=true]

[OnName num="teacher2"]
"Yes, just calm down, okay?
[cpg cn=true]

But my words were drowned out by a louder voice before I could speak.
[cpg]

And that's not all...
[cpg]


[WAIT time=100]
[VOICE f="Amane0655"]
[OnName num="amane"]
"No, no, no, let me go!　Noaaaahhh!"
[cpg cn=true]

Unlike me, who can only push and shove for no reason, the adults forcefully went to hold Amane .
[cpg]

You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

[SE f="se074"]
;//【ＳＥ】バチャバチャバチャ！（水溜まり踏み鳴らす）


[OnName num="teacher3"]
"What's wrong with you?
[cpg cn=true]

[OnName num="teacher4"]
"Are you okay?
[cpg cn=true]

In addition, the teachers who were called in to help arrived and surrounded Amane .
[cpg]

Amane This is a great way to get the most out of your time with your family and friends.
[cpg]

Unlike me, who can do nothing, the teachers immediately tried to take her to the school building.
[cpg]

[FG f="amane_p2_02_a.ui" method="change_3" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane0656"]
[OnName num="amane"]
" Shinji !　 Shinji !　 Shinji kuuuuuuuunn!!!"
[cpg cn=true]

[OnName num="shinzi"]
"......"
[cpg cn=true]

In the event that you've got a lot of money, you're going to need to be able to pay for it. I'm not sure what to make of it.
[cpg]

I'm not sure what to make of this.
[cpg]

[FG f="amane_p1_02_a.ui" method="change_3" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane0657"]
[OnName num="amane"]
"Get off me!　Let me go! Let me go!　No, no, no, Shinji !　 Shinji oooooohhh!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0658"]
[OnName num="amane"]
"Please!　Let me stay with you!　 I want to be with Shinji !
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0659"]
[OnName num="amane"]
"I want to be with Shinji !　I don't want to leave you!　 I want to be with Shinji !
[cpg cn=true]

I could not answer her call.
[cpg]

And so Amane was taken to the infirmary by the teachers .......
[cpg]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_s_sy_t1_0.ui" time=1000]
;//【ＢＧ】学園　校庭　午前　雨


[OnName num="shinzi"]
"..................
[cpg cn=true]

[FG f="izumi_p5_01_a.ui" method="change_7" pos="2/5" time=800]
[FG f="shizuku_p5_01_a.ui" method="change_7" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Izumi0144"]
[OnName num="izumi"]
"I'm sorry to hear that.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Shizuku0143"]
[OnName num="shizuku"]
"..................
[cpg cn=true]

[OnName num="shinzi"]
" Izumi ......, Shizuku to ......."
[cpg cn=true]

I was stunned to see Izumi and for some reason Shizuku standing behind me.
[cpg]

I understand seniors.
[cpg]

They are the president of the student body, so they must have rushed to the unusual situation.
[cpg]

But why Shizuku ?
[cpg]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Izumi0145"]
[OnName num="izumi"]
"Didn't you figure it out already?
[cpg cn=true]

[OnName num="shinzi"]
"What?　Know what?
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Izumi0146"]
[OnName num="izumi"]
"That she shouldn't get involved with ...... and Satonaka .
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

At first I was surprised by what he said, but then I looked up and saw ......
[cpg]


[WAIT time=100]
[VOICE f="Izumi0147"]
[OnName num="izumi"]
".................."
[cpg cn=true]

Izumi In the event that you've got a lot of money, you'll be able to take advantage of the fact that you'll be able to get a lot more.
[cpg]

It was the most icy cold Izumi eyes I had ever seen.
[cpg]

[OnName num="shinzi"]
"What are you talking about ......? It's true that Amane you may have a fragile mental state, but it's not right to talk about it like that. Hey?　 Shizuku tea ......"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0144"]
[OnName num="shizuku"]
".................."
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

What's wrong with that?
[cpg]

Izumi Shizuku You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

[OnName num="shinzi"]
Shizuku "You can find a lot more information on the web.　 You've been good friends with Amane , right?　I'm sure you'll be able to find something that will help you.
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0145"]
[OnName num="shizuku"]
"We're not ...... good friends.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, .......
[cpg cn=true]

Shizuku This is a great way to make sure you are getting the most out of your investment.
[cpg]

What the heck is this? ......
[cpg]

What in the world is going on that I don't know about ......?
[cpg]




[jump storage="ep011.ks" target="*start"]
