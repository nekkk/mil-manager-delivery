*start

;┏━━━━━━━━━━━━━━━━━━━━━━━┓
;┃┏━━━━━━━━━━━━━━━━━━━━━┓┃
;┃┃　　          雨音スイッチ   　　     　　┃┃
;┃┗━━━━━━━━━━━━━━━━━━━━━┛┃
;┗━━━━━━━━━━━━━━━━━━━━━━━┛
[OnName num=""]
;#################################################
*Ep000|Amane
;#################################################
[SCENE id=0]


;//■過去の情景
[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[STOPBGM]
[BG f="b_ex_sz_t5_0.ui" time=1000]
;//【ＢＧ】通学路（セピア調）　夕方　雨


;//【雨、通常】

;//【ＳＥ】雨の音と踏切の音に電車の走行音～急ブレーキ
;//【ＳＥ】人々の悲鳴と怒号


;//loop
[SE f="se002" loop=true]
;//[SE f="se030"]
;//[SE f="se070"]
;//まとめて
[SE f="se130"]


;//muto G 
;//1 voice 
;//2 重複していいSE
;//3 重複させないSE

;//ゲームパッドはamane/project\src/scene/TitleScene.ksの
;//[answerUseGamepad]の::を!::にすると使える（コミットしないで）


;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

"There's a man jumping in!
[cpg cn=true]

"Call an ambulance!
[cpg cn=true]



;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[SE f="se013"]
;//【ＳＥ】救急車の音が近づいて遠退く


[transition target={true} rule="amamori2.png" color={0xff0000ff} time=2000]
[WAIT time=2100]
[BG f="red.ui" time=500]
[transition target={false} color={0xff0000ff} time=500]
[WAIT time=800]




[BG f="black.ui" time=1000]
[WAIT time=2000]
;//【ＢＧ】ブラックアウト


;//loop
[stopse g=2]
[stopse g=6]

;//■プロローグ■


;//[free time=800]
;//[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
[BG f="b_ex_sk_t1_0.ui" time=1000]
;//【ＢＧ】抽象的な背景（色？　曇り空でもok）

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

My name is Mizushima Shinji (Mizushima Shinji). I'm a second year student at Shuei Academy .
[cpg]

I'm not sure if you've heard of it or not.
[cpg]


It's what's called a "mother and child" household, but it's not uncommon nowadays.
[cpg]

It is not particularly difficult to make a living, and I have been able to live an ordinary student life.
[cpg]

Yeah, ....... I'm not sure what to make of it.
[cpg]

I'm not sure what to make of it, but I'm sure it's worth it. ......
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//オープニング


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye1"]
[BG f="b_s_en_t1_0_up.ui" time=1000]
;//【ＢＧ】学園　昇降口　午前　曇り


[OnName num="male_student"]
"Good morning!"
[cpg cn=true]

[OnName num="female_student"]
"Good morning!"
[cpg cn=true]

[SE f="se028"]
;//【ＳＥ】徒歩（革靴）


It's a great way to make sure you're getting the most out of your time at school.
[cpg]

It's a great way to make sure you're getting the most out of your time with your family.
[cpg]

[SE f="se020"]
;//【ＳＥ】徒歩


[OnName num="male_student"]
"Oh, Student Council President Kizaki !　Good morning!"
[cpg cn=true]

[OnName num="shinzi"]
"Hmm ......?"
[cpg cn=true]


[FG f="izumi_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0001"]
[OnName num="izumi"]
"Good morning."
[cpg cn=true]

In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]


[BG f="black.ui" time=800]

[FG f="izumi_p1_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=1000]
Kizaki Izumi You can find a lot of people who are interested in this type of product.
[cpg]

It's a great way to make sure you're getting the most out of your time on campus.
[cpg]

You will find a lot of things that you can do to make your life easier.
[cpg]
[BG f="b_s_en_t1_0_up.ui" time=800]
[FG f="izumi_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=1000]

[WAIT time=100]
[VOICE f="Izumi0002"]
[OnName num="izumi"]
"Good morning, Mizushima ."
[cpg cn=true]

[OnName num="shinzi"]
"Good morning, Izumi ."
[cpg cn=true]

The reason she remembers my name is because I'm a class president.
[cpg]

In Shuei Academy , there is a regular "class council meeting" where the student council officers and class council members from each class gather.
[cpg]

So, the famous Student Council President Kizaki remembered my name.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0003"]
[OnName num="izumi"]
"What's wrong with you?　You look like you're asleep.
[cpg cn=true]

[OnName num="shinzi"]
"Heh, I was up all night playing video games.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0004"]
[OnName num="izumi"]
"Don't be too hard on yourself, grades in the middle of the second year can really affect your career.
[cpg cn=true]

[OnName num="shinzi"]
"Yes, I'll be careful.
[cpg cn=true]

It was a casual conversation, but the guys around me, who had never met Izumi , were looking at it with envy.
[cpg]


This is a great way to make sure you are getting the most out of your money.
[cpg]


;//move
[SE f="se038"]
;//【ＳＥ】小走り

[FG f="shizuku_p5_01_a.ui" method="change_7" pos="1/8" time=800]
[WAIT time=10]

[move from="1/8" to="2/5" ease="easeInOutSine" time=800]
[move from="2/3" to="4/5" ease="easeInOutSine" time=800]


[WAIT time=100]
[VOICE f="Shizuku0001"]
[OnName num="shizuku"]
"I'm not sure what to make of it.
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0005"]
[OnName num="izumi"]
"You can find a lot more information on the web at Shizuku .
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

;//[FG f="shizuku_p1_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shizuku0002"]
[OnName num="shizuku"]
"The ribbon was not tied properly.
[cpg cn=true]


[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0006"]
[OnName num="izumi"]
"Don't talk so loud. People will laugh at you.　Give me that.
[cpg cn=true]

[FACE method="change_6" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0003"]
[OnName num="shizuku"]
"Yes. ......
[cpg cn=true]

[OnName num="shinzi"]
"Ha ha ha.
[cpg cn=true]

[free time=0]

[BG f="black.ui" time=800]

[FG f="shizuku_p1_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=1000]
The first-year student who came running after her was Shizuku Kizaki (Kizaki Shizuku).
[cpg]

It's the younger sister of Izumi , and she belongs to the theater club and is as cute as a little animal.
[cpg]

[BG f="b_s_en_t1_0_up.ui" time=800]

[FG f="shizuku_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=1000]
[WAIT time=100]
[VOICE f="Shizuku0004"]
[OnName num="shizuku"]
Mizushima "I'm not sure what to say, but I'll try.
[cpg cn=true]

[OnName num="shinzi"]
"Good morning.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0005"]
[OnName num="shizuku"]
"You just laughed at me, didn't you!　Oh, .......
[cpg cn=true]

[OnName num="shinzi"]
"I didn't laugh.
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0006"]
[OnName num="shizuku"]
"You did!　I was watching you!
[cpg cn=true]

[OnName num="shinzi"]
"Just a little. ......
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0007"]
[OnName num="shizuku"]
"There you go.
[cpg cn=true]

[FG f="izumi_p5_01_a.ui" method="change_1" pos="4/5" time=800]

;//move
[move from="2/3" to="2/5" ease="easeInOutSine" time=800]

;//[FG f="izumi_p1_01_a.ui" method="change_1" pos="4/5" time=800]
;//[FG f="shizuku_p1_01_a.ui" method="change_1" pos="2/5" time=800]

[WAIT time=100]
[VOICE f="Izumi0007"]
[OnName num="izumi"]
"There you go. How long have you been in school?　If you can't do it right, you'll have to get up earlier.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0008"]
[OnName num="shizuku"]
"Yes. ......
[cpg cn=true]

[OnName num="shinzi"]
"Ha-ha-ha.
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0009"]
[OnName num="shizuku"]
"Oh, my God!
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0008"]
[OnName num="izumi"]
"What's wrong with Shizuku ?　You're always acting like a child. Mizushima is laughing at you.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0010"]
[OnName num="shizuku"]
"Oh, my God, I'm being scolded again. I shouldn't have come after you for this. ......
[cpg cn=true]

[OnName num="1st_grade"]
"Good morning, Shizuku !
[cpg cn=true]

;//[FACE method="change_2" pos="2/5"]
[FG f="shizuku_p5_01_a.ui" method="change_2" pos="2/5" time=0]

[WAIT time=100]
[VOICE f="Shizuku0011"]
[OnName num="shizuku"]
"Good morning. Well, sis, I'm going to go first!　 Bye, Mizushima .
[cpg cn=true]

[OnName num="shinzi"]
"Bye. - Bye.
[cpg cn=true]

;//[FO pos="2/5" time=800]
[move from="2/5" to="4/3" ease="easeInOutSine" time=2000]



[SE f="se039"]
;//【ＳＥ】走り去る


[WAIT time=2000]

[move from="4/5" to="2/3" ease="easeInOutSine" time=1000]

[WAIT time=1000]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0009"]
[OnName num="izumi"]
"I'm sorry, Mizushima . I'm sorry I embarrassed you.
[cpg cn=true]

[OnName num="shinzi"]
"No, no, no. You're so cute, Shizuku . I'm jealous I don't have a brother or sister.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0010"]
[OnName num="izumi"]
"Really?　I'll lend you one if you want.
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0011"]
[OnName num="izumi"]
"No, I'm kidding. I mean, Shizuku is my sister. She's my best friend.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, my God, you were just lecturing me.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0012"]
[OnName num="izumi"]
"You were lecturing her because she's cute. She's a bit of a blabbermouth.
[cpg cn=true]

[OnName num="shinzi"]
"I mean, isn't she cute that way?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0013"]
[OnName num="izumi"]
"Mm-hmm.　Yeah.
[cpg cn=true]

Izumi I'm not sure if you've heard of this, but I'm sure you've heard of it.
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BG f="b_s_pa_t1_0.ui" time=1000]
;//【ＢＧ】学園　廊下　午前　曇り


[OnName num="shinzi"]
"Â"
[cpg cn=true]

After parting with Izumi , I looked so sloppy that I could tell myself.
[cpg]

All men would be happy to talk to a pretty, beautiful woman. You can't blame them because they are healthy male students too.
[cpg]

I've been lucky since this morning.
[cpg]

[BG f="b_s_pa_t1_0_up.ui" time=0]

[OnName num="male_student"]
"Hey, Mizushima."
[cpg cn=true]

[OnName num="shinzi"]
"Hey."
[cpg cn=true]

In the corridor on the way to the classroom, a male student from the same class came to talk to me.
[cpg]

[OnName num="male_student"]
"How's that game I lent you?"
[cpg cn=true]

He's the one who lent me the game I slept so badly playing last night.
[cpg]

[OnName num="shinzi"]
He lent me the game he had slept so poorly playing last night. "Oh, that's so funny! That thing!"
[cpg cn=true]

[OnName num="male_student"]
"Right?"
[cpg cn=true]

I opened the door to the classroom of 2C, talking about the game.
[cpg]

[SE f="se008"]
;//【ＳＥ】ガラッ

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BG f="b_s_3f_t1_0_deskup.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午前　曇り


[SE f="se053"]
;//【ＳＥ】ザワザワ


[FG f="youko_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0001"]
[OnName num="youko"]
"Good morning, Shinji !"
[cpg cn=true]

[OnName num="shinzi"]
"Why are you in my classroom? ......
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[FACE method="change_7" pos="2/3"]



[WAIT time=100]
[VOICE f="Youko0002"]
[OnName num="youko"]
"It's a great way to make sure you're getting the most out of your money. I'm not sure what to say.
[cpg cn=true]

[OnName num="shinzi"]
"..............."
[cpg cn=true]

[BG f="black.ui" time=800]

;//[BG f="b_s_3f_t1_0_up.ui" time=0]
[FG f="youko_p1_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=1000]
;//[FACE method="change_1" pos="2/3"]
This noisy woman is Yoko Minegishi (Minegishi Yoko) from Class 2A.
[cpg]

It's a bit of a pain in the ass to have to come to me for anything.
[cpg]

[BG f="b_s_3f_t1_0_deskup.ui" time=800]
[FG f="youko_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=1000]
[OnName num="male_student"]
"Oh, Shinji , is your wife here?
[cpg cn=true]

;//[FO pos="2/3" time=0]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Youko0003"]
[OnName num="youko"]
"Aha!
[cpg cn=true]

[OnName num="shinzi"]
"That's not my wife!　That's not an "aha!　Ha. ......
[cpg cn=true]

Yoko In the event that you have any questions concerning where and how to use the internet, you can contact us at the web site.
[cpg]

Yoko It's a simple personality mismatch, or perhaps I broke up with her because I still wanted to hang out with my friends and play games by myself rather than go out with men and women.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0004"]
[OnName num="youko"]
"Hey, hey, what are you going to do for lunch today?"
[cpg cn=true]

[OnName num="shinzi"]
"What do you mean?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0005"]
[OnName num="youko"]
"Did you bring your lunch?
[cpg cn=true]

[OnName num="shinzi"]
"No, I didn't. I'll get some bread or something from the store.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]


[WAIT time=100]
[VOICE f="Youko0006"]
[OnName num="youko"]
"I knew it. No!　That's not nutritious.
[cpg cn=true]

[OnName num="shinzi"]
"That's none of your business.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0007"]
[OnName num="youko"]
"Don't you think that Yukika is worried about you?
[cpg cn=true]

[OnName num="shinzi"]
"Why do you keep coming up with Yukika and ......?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0008"]
[OnName num="youko"]
"Ha-ha-ha.
[cpg cn=true]

[OnName num="shinzi"]
".........."
[cpg cn=true]

Yukika This is a great way to make sure you are getting the most out of your time with your family and friends.
[cpg]

This is a great way to make sure you are getting the most out of your time with your family and friends.
[cpg]

Yoko In the event that you have any questions regarding where and how to use the internet, you can contact us at the following web site: Yukika .
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0009"]
[OnName num="youko"]
"And also, did Shinji you bring an umbrella today?
[cpg cn=true]

[OnName num="shinzi"]
"No, I didn't bring an umbrella. It's not raining.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0010"]
[OnName num="youko"]
"Didn't you see the weather forecast?　It's gonna rain soon.
[cpg cn=true]

[OnName num="shinzi"]
"Is it?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0011"]
[OnName num="youko"]
"Well, if you'd brought one, I'd have asked you to put it in on the way home.
[cpg cn=true]

[OnName num="shinzi"]
"No, I mean, if you knew it was gonna rain, why didn't you bring it yourself?
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0012"]
[OnName num="youko"]
"Shut up!
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

Yoko , who was offended by my valid point, immediately changed the subject.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0013"]
[OnName num="youko"]
"Well, whatever!　I'm not sure if you've seen this before, but I'm sure you have. You can't go anywhere until I get here.
[cpg cn=true]

[OnName num="shinzi"]
"Okay, okay. Now, go back to your class.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0014"]
[OnName num="youko"]
"Okay, okay, okay.
[cpg cn=true]

[OnName num="shinzi"]
"Hun. ......"
[cpg cn=true]

[FO pos="2/3" time=800]
I'm sure you'll find a lot of people who'd like to know more about this kind of thing. Yoko mimics my mouth in a hateful way, and then leaves with his tongue hanging out.
[cpg]



This is the reason why it's so important for you to have a good idea of what you're looking for.
[cpg]

But maybe that's why I thought she was only a friend and we ended up breaking up.
[cpg]

[WAIT time=900]
[BG f="black.ui" time=900]

As I was thinking about this, the chime rang, announcing the time for homeroom.
[cpg]



[jump storage="ep001.ks" target="*start"]
