*start

;#################################################
*Ep009|Gear.
;#################################################
[SCENE id=9]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_s_cf_t2_1.ui" time=1000]
;//【ＢＧ】学園　会議室　午後　霧雨





On this day, a special committee meeting was held.
[cpg]

The gym teacher and a student in our class informed us of an unusual situation, and we had to discuss it.
[cpg]

The recent problem of bullying could be the school's Achilles heel.
[cpg]

Therefore, it is necessary to grasp the situation and solve it as soon as possible.
[cpg]

At this time, it seems that the staff meeting is also being held at the same time.
[cpg]

[OnName num="vice-president"]
"It seems to be a serious problem. ......
[cpg cn=true]

It's a great way to make sure you're getting the most out of your money.
[cpg]

Izumi It's a good idea to have a good idea of what you're doing.
[cpg]

[FG f="izumi_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0070"]
[OnName num="izumi"]
"I'm sure you'll be happy to hear that.　Has anyone interviewed him?
[cpg cn=true]

[OnName num="vice-president"]
"The school nurse did.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0071"]
[OnName num="izumi"]
"And?　Who was that ...... guy?
[cpg cn=true]

[OnName num="vice-president"]
"It's Amane Satonaka from 2C.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0072"]
[OnName num="izumi"]
"Oh, what did he say?
[cpg cn=true]

[OnName num="vice-president"]
"He fell down. .......
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0073"]
[OnName num="izumi"]
"Isn't that what happened?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, .......
[cpg cn=true]

For some reason, Izumi didn't seem to be interested in this topic at all.
[cpg]

In addition, if you were so upset when you met Amane , how is it possible that today you don't even remember your name?
[cpg]

What's more, there have been several incidents like this in the past, and each time, Izumi has tried to solve the problem with the whole student council.
[cpg]

Even if it was an attempt or a mistake, the student body president, Izumi , has taken all possible measures to eradicate bullying.
[cpg]

It's hard to see how he could be so indifferent to the "mud-slinging students" here.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0074"]
[OnName num="izumi"]
"There are reports of a student named Satonaka who was seen behaving strangely this morning. Does anyone know anything about it?"
[cpg cn=true]

[OnName num="female_student"]
"Oh, yes.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, hey!
[cpg cn=true]

The one who came forward was, of course, one of the class members of my class.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0075"]
[OnName num="izumi"]
"Report.
[cpg cn=true]

[OnName num="female_student"]
"I was wandering around, asking all the students, 'Am I dark? I was a little scared. It was kind of scary. ......"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0076"]
[OnName num="izumi"]
"You're in the same class as Satonaka , aren't you?　 Mizushima , is it true what you said?"
[cpg cn=true]

[OnName num="shinzi"]
"............, it's true..."
[cpg cn=true]

[SE f="se053"]
;//【ＳＥ】ザワザワ……

[BGM f="danger"]


A lot of people were actually watching Amane at the time.
[cpg]

It's frustrating ...... that I'm the only one who can lie and cover for her, but it makes no sense at all.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0077"]
[OnName num="izumi"]
"'There seems to be something wrong with her. Does anyone else know anything about her?"
[cpg cn=true]

[OnName num="male_student1"]
"'Oh, yes. I think it's probably her, but she comes to school without an umbrella, no matter how much it's raining.
[cpg cn=true]

[OnName num="male_student2"]
"I saw her too!　That's him!
[cpg cn=true]

[OnName num="shinzi"]
"That's him!
[cpg cn=true]

[SE f="se068"]
;//【ＳＥ】ガタンッ！


As I stood up, all eyes were on me at once, and the student council room fell silent as if it had been hit by water.
[cpg]

[OnName num="shinzi"]
"I don't like to put up umbrellas,......, and that's the kind of principle that she's .........
[cpg cn=true]

[OnName num="female_student"]
"Principles are ......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0078"]
[OnName num="izumi"]
"Oh, you mean Satonaka the student who is always soaking wet.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, .......
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0079"]
[OnName num="izumi"]
"I see. ....... I get it. Apparently, this is not bullying. It's just that the boy is an unusual ...... student with behavioral problems."
[cpg cn=true]

[OnName num="shinzi"]
"No, sir!"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0080"]
[OnName num="izumi"]
"So you have evidence of bullying?
[cpg cn=true]

[OnName num="shinzi"]
"No, no. ...... That's not ......
[cpg cn=true]

I had never felt so scared of the logical Izumi as I did at this moment.
[cpg]

This is a great way to make sure you are getting the most out of your time with your family and friends.
[cpg]

Is ...... Amane anyone bullying you in the first place?
[cpg]

And is it the kind of bizarre behavior ...... Izumi that caused her stress to explode in some way?
[cpg]

At that time, I still did not understand anything, nothing at all,.......
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0081"]
[OnName num="izumi"]
"I'm not sure what to say. I'm not sure what to say, but I'm sure you'll understand.
[cpg cn=true]

[SE f="se062"]
;//【ＳＥ】ガタガタガタ

[FO pos="2/3" time=800]
[BGM f="rain"]

In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

[FG f="izumi_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[OnName num="shinzi"]
" Izumi ......."
[cpg cn=true]

I stop Izumi in my seat and say.
[cpg]

[OnName num="shinzi"]
"What if it's bullying?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0082"]
[OnName num="izumi"]
"That's what ...... I'll figure out then.
[cpg cn=true]

[OnName num="shinzi"]
"..................
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0083"]
[OnName num="izumi"]
"Bye, bye."
[cpg cn=true]

[FO pos="2/3" time=800]

Surely, Izumi is right.
[cpg]

It is natural that you can not move without evidence.
[cpg]

However, I don't feel the same way.
[cpg]

There is something different about Izumi as the student body president with a sense of justice.
[cpg]

But I don't know what the cause of that feeling of discomfort is.
[cpg]

I don't know anything .......
[cpg]

;//エフェクト


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_k_ro_t2_1.ui" time=1000]
;//【ＢＧ】木崎家　姉妹の部屋　夜　雨

[FG f="shizuku_p5_01_a.ui" method="change_7" pos="2/5" time=800]
[FG f="izumi_p5_01_a.ui" method="change_1" pos="4/5" time=800]



[WAIT time=100]
[VOICE f="Shizuku0092"]
[OnName num="shizuku"]
"Sis, how was the committee ...... meeting?"
[cpg cn=true]

I've been waiting for Izumi to come back for a while, and Shizuku suddenly cut in.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0084"]
[OnName num="izumi"]
"What do you mean?
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0093"]
[OnName num="shizuku"]
"You talked about bullying, right?
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0085"]
[OnName num="izumi"]
"Yeah, that ...... thing.
[cpg cn=true]

Izumi I'm not sure what to make of this.
[cpg]

This is a great way to make sure you are getting the most out of your money.
[cpg]

Izumi It's also a great way to get the most out of your business.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0086"]
[OnName num="izumi"]
"It's nothing. It's not like she was being bullied.　You've got to do your homework ......."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0094"]
[OnName num="shizuku"]
"It's not bullying!
[cpg cn=true]

I tried to replace it with my usual quip, but it was useless.
[cpg]

You can find a lot of people who are looking for the best way to get the most out of their lives. Shizuku are desperately trying to find something to say, but they are staring at Izumi with their mouths tied shut.
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0087"]
[OnName num="izumi"]
"It's not that you don't ...... have it in you to use your words.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0095"]
[OnName num="shizuku"]
" Amane senior, you are being bullied!　I've seen it!
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0088"]
[OnName num="izumi"]
"You saw ......?
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0096"]
[OnName num="shizuku"]
"He grabbed me by the collar the other day and said something, and today my gym clothes were all messed up. ......
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0089"]
[OnName num="izumi"]
"Who grabbed you by the collar? ......
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0097"]
[OnName num="shizuku"]
"Someone ...... I don't know, but ....... It's a senior girl. ......
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0090"]
[OnName num="izumi"]
"Two years together?
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0098"]
[OnName num="shizuku"]
"Yeah. ......
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0091"]
[OnName num="izumi"]
"You're kidding, right?　Friends do that kind of thing all the time, don't they?
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0099"]
[OnName num="shizuku"]
"It's not like that!
[cpg cn=true]

I'm not sure what to do, but I'm sure it's a good idea.
[cpg]

Shizuku It's a great way to make sure you're getting the most out of your time with your family.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0092"]
[OnName num="izumi"]
" Satonaka Hey, I heard he's a weirdo with a lot of odd behavior.　I'm telling you, you shouldn't go out with that kind of person.
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0100"]
[OnName num="shizuku"]
"I'm not a freak!
[cpg cn=true]

The senior who cared about me and talked to me when no one paid attention to me.
[cpg]

The senior who can talk about his favorite play is Amane .
[cpg]

He is such a kind and wonderful person, so why doesn't anyone take his side?
[cpg]

Shizuku is alienated by her own powerlessness.
[cpg]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0101"]
[OnName num="shizuku"]
"You fool of a sister!"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0093"]
[OnName num="izumi"]
"You, ......, don't talk like a child.
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0102"]
[OnName num="shizuku"]
"Stupid!　Why don't you understand me?
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0094"]
[OnName num="izumi"]
"Oh, ......
[cpg cn=true]

Shizuku is really like a kindergartener, and Izumi sighs.
[cpg]

That's when ......
[cpg]

[SE f="se067"]
;//【ＳＥ】ドアノック

[BGM f="danger"]

[FACE method="change_5" pos="4/5"]
[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Izumi0095"]
[OnName num="izumi"]
"......!"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0103"]
[OnName num="shizuku"]
"......!"
[cpg cn=true]

[OnName num="unknown"]
"Hey, I'm coming in."
[cpg cn=true]

[SE f="se035"]
;//【ＳＥ】ドア開く


I'm not sure if it's a good idea, but it's a good idea.
[cpg]

[OnName num="father_in_law"]
"Are you in trouble?　I'm sorry.
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0096"]
[OnName num="izumi"]
"Excuse me. ......
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0104"]
[OnName num="shizuku"]
"It's .............
[cpg cn=true]

[OnName num="father_in_law"]
"Oh?　 Shizuku doesn't say sorry?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0105"]
[OnName num="shizuku"]
"............
[cpg cn=true]

[OnName num="father_in_law"]
"You're a bad boy. ......
[cpg cn=true]

Seeing the wrinkles between his father-in-law's eyebrows, Izumi immediately clamped down on Shizuku 's head and bowed deeply himself.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0097"]
[OnName num="izumi"]
"I'm sorry!　I'll be sure to give you a good talking to later!"
[cpg cn=true]

[OnName num="father_in_law"]
"No, no, no, that's the ...... parent's job. You can't do that with your sister yet. Discipline is. ......"
[cpg cn=true]

This is a great way to make sure you are getting the most out of your money.
[cpg]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0106"]
[OnName num="shizuku"]
"I'm sorry...I'm sorry..."
[cpg cn=true]

By that time, Shizuku 's body had already begun to shake and shake.
[cpg]

[OnName num="father_in_law"]
"It's too late. The timing of the apology is important. Come on, come on. Your father will discipline you ...... hahaha."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0098"]
[OnName num="izumi"]
"......."
[cpg cn=true]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

This is a great way to get the most out of your time and money.
[cpg]

[OnName num="father_in_law"]
"It's a great way to make sure you're getting the most out of your money.
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0107"]
[OnName num="shizuku"]
"Hee...!
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0099"]
[OnName num="izumi"]
" Shizuku !"
[cpg cn=true]

My father-in-law's hand grabbed the thin arm of Shizuku and dragged him along.
[cpg]

So Izumi couldn't help but follow .......
[cpg]




;//エフェクト




[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_k_co_t2_0.ui" time=1000]
;//【ＢＧ】木崎家　中庭　夜　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、中位】

;//loop
[SE f="se007" loop=true]
;//【ＳＥ】雨（中降りくらい）


[SE f="se001"]
;//【ＳＥ】ビンタ





[FG f="izumi_p5_02_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Izumi0100"]
[OnName num="izumi"]
"......k!"
[cpg cn=true]

[FG f="shizuku_p5_02_a.ui" method="change_5" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shizuku0108"]
[OnName num="shizuku"]
"Sis!"
[cpg cn=true]

The large courtyard of the mansion Kizaki house.
[cpg]

In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

[OnName num="father_in_law"]
"I'll tell you about it later. ......?
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】ビンタ

[move from="4/5" to="3/3" ease="easeInOutSine" time=100]
[WAIT time=100]
[move from="3/3" to="4/5" ease="easeInOutSine" time=100]


[WAIT time=100]
[VOICE f="Izumi0101"]
[OnName num="izumi"]
"Aaaaah!
[cpg cn=true]

[OnName num="father_in_law"]
"I'm not sure if you'll be able to find the right one for you.　Aah!
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】ビンタ


[move from="4/5" to="3/3" ease="easeInOutSine" time=100]
[WAIT time=100]
[move from="3/3" to="4/5" ease="easeInOutSine" time=100]


[WAIT time=100]
[VOICE f="Izumi0102"]
[OnName num="izumi"]
"Aah!
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0109"]
[OnName num="shizuku"]
"Stop it!　Don't hurt my sister!
[cpg cn=true]

[OnName num="father_in_law"]
"Hmm?　Yeah?　What do you say?　"Dad."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0110"]
[OnName num="shizuku"]
"......... ......"
[cpg cn=true]

[OnName num="father_in_law"]
"You can't say something that simple, you fucking retard!
[cpg cn=true]

[SE f="se040"]
;//【ＳＥ】ガスッ！

[free time=0]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="b_k_co_t2_0.ui" time=500]

[WAIT time=500]

[FG f="izumi_p5_02_a.ui" method="change_4" pos="4/5" time=500]
[FG f="shizuku_p5_02_a.ui" method="change_5" pos="2/5" time=500]

[move from="2/5" to="1/8" ease="easeInOutSine" time=800]
[FO pos="1/8" time=800]


[WAIT time=100]
[VOICE f="Shizuku0111"]
[OnName num="shizuku"]
"Gefa!"
[cpg cn=true]

[SE f="se024"]
;//【ＳＥ】ズシャーーッ！


[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0103"]
[OnName num="izumi"]
" Shizuku !"
[cpg cn=true]

The small Shizuku body, kicked off by a large man's leg, floated in the air for a moment and rolled on the rain-drenched lawn.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0104"]
[OnName num="izumi"]
"Please don't use violence!
[cpg cn=true]

[OnName num="father_in_law"]
"I'm not sure what you mean by violence, young lady. This is a discipline, you know. It's called the whip of love. Ha, ha, ha.
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0105"]
[OnName num="izumi"]
"What ...... is love?
[cpg cn=true]

Izumi This is a great way to make sure that you get the most out of your time with your family and friends.
[cpg]

But that was a big mistake .......
[cpg]




[OnName num="father_in_law"]
"It's a good idea to have a good idea of what you're doing. Okay, I'll give you more discipline.
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0106"]
[OnName num="izumi"]
"What?"
[cpg cn=true]

In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site. This is a great way to get the most out of your business.
[cpg]

[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0107"]
[OnName num="izumi"]
"I'm not going to do it.
[cpg cn=true]




[OnName num="father_in_law"]
"'Hey, shorty!　You come over here too!
[cpg cn=true]

[FG f="shizuku_p5_02_a.ui" method="change_4" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shizuku0112"]
[OnName num="shizuku"]
"No!
[cpg cn=true]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
[BG f="b_k_co_t2_0.ui" time=1000]
;//【ＢＧ】木崎家　中庭　夜　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、中くらい】


[SE f="se024"]
;//【ＳＥ】ズルーーッ…ズルーーッ！


Grabbed by the hair and literally dragged, Shizuku was pulled up in front of Izumi .
[cpg]

[OnName num="father_in_law"]
"Hmmm?　There's no booze. ...... Booze!
[cpg cn=true]

[SE f="se049"]
;//【ＳＥ】瓶が投げ出される


[OnName num="mother"]
"Yes ......."
[cpg cn=true]

As the father-in-law raised his voice, the mother appeared from inside the house with a new bottle of alcohol.
[cpg]

[FG f="shizuku_p5_02_a.ui" method="change_3" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shizuku0113"]
[OnName num="shizuku"]
"Mother, help me!　Mother!"
[cpg cn=true]

[OnName num="mother"]
"' Shizuku , listen to what your father says .......'
[cpg cn=true]

[FG f="shizuku_p5_02_a.ui" method="change_4" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shizuku0114"]
[OnName num="shizuku"]
"No!　Mother!　Don't go, Mother!
[cpg cn=true]

[FG f="izumi_p5_02_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Izumi0108"]
[OnName num="izumi"]
"Ugh ......."
[cpg cn=true]

Izumi In the event that you have any questions concerning where and how to use the internet, you can call us at our own website.
[cpg]

That is their own mother.
[cpg]

The person who invited this man into our home.
[cpg]

And yet, my sister still cries and cries for help from my mother.
[cpg]

I wonder how stupid she is .......
[cpg]

It's not like we have any help left.
[cpg]

[OnName num="father_in_law"]
"I'm not sure what to do.
[cpg cn=true]

This is a great way to make sure that you get the most out of your time with your family.
[cpg]

[OnName num="father_in_law"]
"I'm not sure if I'm going to be able to do that. I'm sure you'll agree.
[cpg cn=true]

I'm not sure if my throat has been moistened or not, but my tongue is smooth.
[cpg]



[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト





[OnName num="father_in_law"]
"I'm not sure what to do. It's a good idea to have a good idea of what you're doing.
[cpg cn=true]

I'm not sure how long it will take.
[cpg]

In the event that you're looking for the best way to get the most out of your wedding ceremony, you'll want to look at the following.
[cpg]

[FG f="izumi_p5_02_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Izumi0109"]
[OnName num="izumi"]
"'And that's enough!　Hahahaha...... go away!"
[cpg cn=true]

[OnName num="father_in_law"]
"Heck, you're not even cute ....... I knew I shouldn't have given up my own daughter. ......
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0110"]
[OnName num="izumi"]
"!"
[cpg cn=true]

In the end, the father-in-law said a word that should not be said and walked away.
[cpg]

If it weren't for that one word, maybe the light wouldn't have been closed in the future,.......
[cpg]

;#############################################################


;#############################################################

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_k_co_t2_0.ui" time=1000]
;//【ＢＧ】木崎家　中庭　夜　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、中くらい】


[FG f="shizuku_p5_02_a.ui" method="change_7" pos="2/5" time=800]
[FG f="izumi_p5_02_a.ui" method="change_4" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Shizuku0115"]
[OnName num="shizuku"]
"Sister ......, what is your own daughter?"
[cpg cn=true]

Izumi Shizuku It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0111"]
[OnName num="izumi"]
"I'm not sure what to say.
[cpg cn=true]




[SE f="se059"]
;//【ＳＥ】ドサッ





Izumi In the event that you've got a lot of time, you'll be able to take a look at the best way to get the most out of your home.
[cpg]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0116"]
[OnName num="shizuku"]
"Sis!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0112"]
[OnName num="izumi"]
"Don't touch me!
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】パチン！

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0117"]
[OnName num="shizuku"]
"!"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0113"]
[OnName num="izumi"]
"''U...ugh...''
[cpg cn=true]

Shizuku In the event that you have any questions regarding where and how to use the internet, you can contact us at Izumi .
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[FACE method="change_7" pos="4/5"]
[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Izumi0114"]
[OnName num="izumi"]
"That man has a true daughter who shares his ...... blood.
[cpg cn=true]

Enough .......
[cpg]

Why should I be the only one who has to endure and endure and endure and live?
[cpg]

Physical fatigue is linked to mental.
[cpg]

The mental strength that sustained Izumi you is now destroyed by the demon's work, and opens a strong gate for you to blurt it all out.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0115"]
[OnName num="izumi"]
"You will find a lot of things that you can do to make your life easier. That was when we were still in elementary school. But after paying alimony and child support to his former family, he was penniless, so Mom gave him money and he's been a pimp ever since. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0118"]
[OnName num="shizuku"]
"Mom ...... affair ......"
[cpg cn=true]

There was never a moment in Shizuku memory when a new dad arrived.
[cpg]

I only knew that my stepdad had been there at some point and that this situation had happened at some point, so I wondered why my sister was the only one who remembered anything about it.
[cpg]

[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0116"]
[OnName num="izumi"]
"'I still do, ....... He's doing it by transferring my mom's money to his real daughter!　That's why we live in this house and can't wear what we want or go where we want!"
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0119"]
[OnName num="shizuku"]
"Yeah, ......."
[cpg cn=true]

While inflicting violence on themselves, Kizaki they are cutting into the family fortune to send money to their own daughter.
[cpg]

What could be more unreasonable than that?
[cpg]

My sister and I are both considered rich kids, but we have to worry about what's in our wallets every time we're invited out to play. ......
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0117"]
[OnName num="izumi"]
"'His daughter is sucking up all our money!
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0120"]
[OnName num="shizuku"]
"That's not fair. ......"
[cpg cn=true]

The girl has free money, and besides, he's not around.
[cpg]

I'm sure you'll agree with me.
[cpg]

There is a boiling anger in Shizuku
[cpg]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0121"]
[OnName num="shizuku"]
"Why ....... Why is he doing this to us?　What did my mom or us do to him?"
[cpg cn=true]

Hmph, Izumi sniffs hatefully.
[cpg]

[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0118"]
[OnName num="izumi"]
"He's just an alcoholic. And ...... he hates the rain.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0122"]
[OnName num="shizuku"]
"Rain...?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0119"]
[OnName num="izumi"]
"He used to be a builder. But for some reason, it always rained when it was important, and the site was ruined, and the rain caused landslides and accidents, and I heard that he lost a lot of money because of the rain.
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0120"]
[OnName num="izumi"]
"That's why I get so angry and crazy every time it rains.
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0123"]
[OnName num="shizuku"]
"Oh, no!
[cpg cn=true]

All these things that are not our fault.
[cpg]

And yet we have to suffer so much damage so often.
[cpg]

Why?　Is this something we should put up with?
[cpg]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0124"]
[OnName num="shizuku"]
"Can't you just go to ......?　Why can't you help us?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0121"]
[OnName num="izumi"]
"I don't know, I don't know!
[cpg cn=true]

I don't know, I don't know!" Izumi shouted in the rain.
[cpg]

As a result of this, you can be sure that you'll be able to get the most out of your time with your family and friends. Izumi , who is only two years older than Shizuku , couldn't possibly understand the inner workings of a man and a woman.
[cpg]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0125"]
[OnName num="shizuku"]
"Don't yell at me, .........ugh...ugh."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0122"]
[OnName num="izumi"]
".................."
[cpg cn=true]

It is always the case that Shizuku cries, but that crying never hurts my temper more than today.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

Enough is enough .......
[cpg]

It's time to let Shizuku carry at least half of the hatred that I carry.
[cpg]

I'm sure you'll be happy to hear that. Izumi thought deep in his consciousness.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0123"]
[OnName num="izumi"]
"If that's the case, it's his daughter's fate ...... to bear all this. Don't you think so?　 Shizuku "
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0126"]
[OnName num="shizuku"]
"You can find a lot of things that you can do. I'm not sure what to say, but I'm sure you'll understand. It's a good idea to have a good idea of what you're looking for. It's not fair, that boy! You should have replaced us!
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0124"]
[OnName num="izumi"]
"That's right. ......
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0127"]
[OnName num="shizuku"]
"Where's that guy's daughter? !　She's the one who's gonna take him in!
[cpg cn=true]

[STOPBGM]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0125"]
[OnName num="izumi"]
"His real daughter is at Shizuku . Amane Satonaka .
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0128"]
[OnName num="shizuku"]
"..................."
[cpg cn=true]

It's a great way to make sure you're getting the most out of your money.
[cpg]

But that's ridiculous.
[cpg]

The timing is too strange for that name to come out.
[cpg]

It's a great way to get the most out of your business.　 Shizuku This is a great way to make sure that you get the most out of your time with us.
[cpg]

But then, as if to drive home the point, Izumi continued in an emotionless voice: "You know, I've never heard of anyone with a mother's name.
[cpg]

[BGM f="danger"]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0126"]
[OnName num="izumi"]
Amane Satonaka "I'm not sure what to make of this. Your favorite senior is the one who is responsible for making us like this!
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0129"]
[OnName num="shizuku"]
"No, no, no, no, no, no, no, no, no, no, no. ......
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0127"]
[OnName num="izumi"]
"I used to go through his study in junior high school. I found these ......1 family photos.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0130"]
[OnName num="shizuku"]
"But ......, just the childhood photos ......."
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0128"]
[OnName num="izumi"]
"They were together!　Right there!　A bank transfer card!　And in the name field it said Amane !　I never forgot for a second the face in that picture and the name Amane !
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0129"]
[OnName num="izumi"]
"That's why it's ......!　Do you know how surprised I was when I met her?　Do you have any idea how my gut churned?
[cpg cn=true]

[SE f="se040"]
;//【ＳＥ】ボスッ！ボスッ！


Izumi punched his fist repeatedly across the sodden lawn.
[cpg]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0131"]
[OnName num="shizuku"]
" Amane ... senior is ...... that guy's daughter ......."
[cpg cn=true]

Behind the kind face, that guy's daughter is a respected senior ...... who lives comfortably, sucking up our money and happiness.
[cpg]

The heart of Shizuku is no longer cut by the knife of zakzaky and heartless.
[cpg]



[WAIT time=100]
[VOICE f="Izumi0130"]
[OnName num="izumi"]
"It is unforgivable ....... I don't want to know if that girl was bullied ....... If she and her mother had been strong, he would not have been able to enter our house!
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0132"]
[OnName num="shizuku"]
"Because of the Amane seniors, our ...... house was ...... destroyed."
[cpg cn=true]

;//////////////////////////////////////////////////////////////////////////


;//※ここから田島の打ち込み分です


[SE f="se004"]
;//【ＳＥ】雨の音　高まる


Under the cloudy sky that dropped rain relentlessly, a heavy and dreadful thing spread ...... among the sisters.
[cpg]

;//エフェクト

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//loop
[stopse g=2]
[stopse g=6]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
[BG f="b_si_d_t3_1.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　夜　雨


;//asdse

;//☆新規シーン

;//着替えシーン（陽子）雨に濡れ主人公家にて着替えている所をバッタリ遭遇

[OnName num="shinzi"]
"I'm not sure what to say.
[cpg cn=true]

I'm not sure what to make of it.
[cpg]

[OnName num="shinzi"]
"It's a great way to get a good night's sleep.
[cpg cn=true]

There was no answer to my voice. She's probably out shopping or at work.
[cpg]


While I was at the committee meeting, Amane left, and I came home in the evening with a worried feeling.
[cpg]

[OnName num="shinzi"]
" Amane , are you alright ......?"
[cpg cn=true]




I can't stand worrying about her.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to do.
[cpg cn=true]

But now it is more important to change your clothes quickly or you will catch a cold.
[cpg]


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//ブラックアウト

In the event that you're not sure what you're looking for, you'll be able to find it on the web.
[cpg cn=true]
;//ドアを開ける



;//●ＣＧ（着替え）
[free time=800]
;**【ＣＧ】ev_102_0 ***********************
[CG id=28 index=0 time=1000]
;*****************************************
[BGM f="h1"]

[WAIT time=100]
[VOICE f="Youko0388"]
[OnName num="youko"]
"What?"
[cpg cn=true]

[OnName num="shinzi"]
"What?"
[cpg cn=true]

The moment I opened the door, I felt a kind of déjà vu.
[cpg]

But that didn't stop my hand from opening the door already.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[WAIT time=100]
[VOICE f="Youko0389"]
[OnName num="youko"]
"I'm not sure what to do.　What are you looking at?
[cpg cn=true]

[OnName num="shinzi"]
"I'm sorry!"
[cpg cn=true]

It's Yoko .
[cpg]

Why is this guy trying to strip in someone's house? Is he a pervert?
[cpg]

[WAIT time=100]
[VOICE f="Youko0390"]
[OnName num="youko"]
"I don't believe this!　Get the fuck out of my house!
[cpg cn=true]

[OnName num="shinzi"]
"No, I'm not trying to be a peeping tom, okay?
[cpg cn=true]

[WAIT time=100]
[VOICE f="Youko0391"]
[OnName num="youko"]
"Just go to ...... and get the fuck out!
[cpg cn=true]

[OnName num="shinzi"]
"Agh!
[cpg cn=true]

I got kicked out by Yoko , but I got to see some good stuff....
[cpg]

[OnName num="shinzi"]
"I'm not sure why you're changing clothes in my house.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Youko0392"]
[OnName num="youko"]
"It was raining and I was in a hurry to get home and I lost my keys and the lady let me in!
[cpg cn=true]

[OnName num="shinzi"]
"Oh, I see.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Youko0393"]
[OnName num="youko"]
"Forget about the ...... I just saw.
[cpg cn=true]

[OnName num="shinzi"]
"What do you think?
[cpg cn=true]

[WAIT time=100]
[VOICE f="Youko0394"]
[OnName num="youko"]
"Pervert!
[cpg cn=true]

He spoke lamely, as if forgetting his misgivings about Amane .
[cpg]

Besides... it's going to be Yoko fodder for teasing for a while.
[cpg]

;//ブラックアウト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_si_r_t4_2.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　夜　雨

[OnName num="shinzi"]
"Huh? ...I'm tired of it all.
[cpg cn=true]

I'm not sure if it's because of all the things that have been happening lately.
[cpg]

My head was always full of Amane .
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信


At that time, I hear a ringtone from my phone.
[cpg]


[OnName num="shinzi"]
"It's from Amane !"
[cpg cn=true]



However, the sender of the message I opened was not the name of the person I wanted.
[cpg]


;//メッセージ画面


" Yoko " I heard that?　 I've heard that Satonaka is being bullied?
[cpg]

Is Shinji okay?　I think it's best not to hang out with them too much, because that kind of thing can be caused by the person being bullied. I'm worried about Shinji ....
[cpg]


The contact was from Yoko .
[cpg]

He seemed to have something he wanted to talk about, but I felt awkward and forced him out.
[cpg]

I'm sure this is it.
[cpg]



[OnName num="shinzi"]
"What the hell ...... is that?"
[cpg cn=true]

To be honest, I was suspicious of Yoko , but the fact that they bothered to contact me like this makes me wonder if they are unrelated.
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





[OnName num="shinzi"]
"Oh ......, ...... again."
[cpg cn=true]

While I was in a daze with my eyes down on the message from Yoko , this time I got a call from Amane .
[cpg]




;//メッセージ画面


" Amane " I'm sorry about today.
[cpg]

I'm sorry I left before you without saying anything.
[cpg]

I fell and got dirty during gym and I just panicked because I didn't want Shinji to think I was dirty. Please don't think I'm crazy.
[cpg]




[OnName num="shinzi"]
"You're Amane overreacting again. ......
[cpg cn=true]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





[OnName num="shinzi"]
"Yeah, ......."
[cpg cn=true]




;//メッセージ画面


" Amane " I promised Shinji that I wouldn't take drugs!
[cpg]

Trust me!
[cpg]




[OnName num="shinzi"]
"I believe you. ......
[cpg cn=true]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





[OnName num="shinzi"]
"What?
[cpg cn=true]




;//メッセージ画面


" Amane " I'm not a rain woman!
[cpg]




[OnName num="shinzi"]
"What's ......?
[cpg cn=true]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





[OnName num="shinzi"]
"Wha...?
[cpg cn=true]




;//メッセージ画面


" Amane " Shinji , do you think I'm gloomy?
[cpg]

Don't get me wrong, I'm super bright, actually!
[cpg]




[OnName num="shinzi"]
"What's wrong with you, ......?"
[cpg cn=true]

Messages arrive one after another.
[cpg]




In addition, the topic is changing all the time, and it is hard to understand what Amane is trying to say.
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





;//メッセージ画面


Amane Izumi A lot of the time, it's a good idea to have a good idea of what you're looking for.
[cpg]

I'd like to have a face like that too!
[cpg]




[OnName num="shinzi"]
"Huh?"
[cpg cn=true]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





;//メッセージ画面


" Amane " Shinji , what are you doing now?
[cpg]

Why don't you answer me?
[cpg]

Are you with someone?
[cpg]

Who are you with?　Someone I know?
[cpg]

If you don't know him, introduce him to me. Maybe next time.
[cpg]

Next time is tomorrow. Definitely.
[cpg]




[OnName num="shinzi"]
"What?
[cpg cn=true]

I'm not sure how to reply to any of these, because they keep coming and the content is all over the place.
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





;//メッセージ画面


I'm not sure how to respond to any of them. " Amane " Shinji , what kind of girl do you like?
[cpg]

I'm going to be whatever Shinji you want me to be, so be honest with me.
[cpg]

I'm going to get a face-lift and lose weight to look the way Shinji likes.
[cpg]




[OnName num="shinzi"]
"".................."
[cpg cn=true]

That's funny.
[cpg]

Obviously, there's something wrong with Amane .
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信

[WAIT time=900]

[SE f="se031"]
;//【ＳＥ】メッセージ着信

[WAIT time=900]

[SE f="se031"]
;//【ＳＥ】メッセージ着信

[WAIT time=900]

[SE f="se031"]
;//【ＳＥ】メッセージ着信





[OnName num="shinzi"]
"No, don't do that. ......"
[cpg cn=true]

I got scared and held the phone down with my pillow.
[cpg]

However, the ring tone from under the pillow is muffled and repeated over and over again.
[cpg]

Over and over again ...... over and over again ......
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信

[WAIT time=900]

[SE f="se031"]
;//【ＳＥ】メッセージ着信

[WAIT time=900]

[SE f="se031"]
;//【ＳＥ】メッセージ着信

[WAIT time=900]

[SE f="se031"]
;//【ＳＥ】メッセージ着信





[OnName num="shinzi"]
"What should I do ......?
[cpg cn=true]

I was in trouble, so I called Amane anyway to get in touch with them.
[cpg]




[SE f="se021"]
;//【ＳＥ】呼び出し音

[WAIT time=3000]

[SE f="se022"]
;//【ＳＥ】電話繋がる





[WAIT time=100]
[VOICE f="Amane0601"]
[OnName num="amane"]
" Shinji ......"
[cpg cn=true]

[OnName num="shinzi"]
" Amane !　What's wrong?　What's wrong?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0602"]
[OnName num="amane"]
"No, I'm not.　What?
[cpg cn=true]

[OnName num="shinzi"]
"Why?"
[cpg cn=true]

Amane doesn't think he's doing anything strange, he's just talking in his normal voice.
[cpg]

[OnName num="shinzi"]
"Because there's a lot of messages on ......."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0603"]
[OnName num="amane"]
"Because I want to talk to Shinji a lot, okay?　No?"
[cpg cn=true]

[OnName num="shinzi"]
"No... not really. ...... This number is .......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0604"]
[OnName num="amane"]
"Can't I just want to contact someone I like?　 Because I like Shinji and I keep coming up with things I want to talk about. I'd love to ...... meet you. I like Shinji .
[cpg cn=true]

[OnName num="shinzi"]
"I like ......, too.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0605"]
[OnName num="amane"]
"Can I trust you?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0606"]
[OnName num="amane"]
"Why don't you come over to my place now?　Or do you want me to come over?
[cpg cn=true]

[OnName num="shinzi"]
"Oh, ......, but I've got three homework assignments today. ......
[cpg cn=true]

It's a good thing that you're not the only one.
[cpg]




But I'm kind of afraid to meet with Amane now.
[cpg]

It's a great way to make sure you get the most out of your time with your family and friends.
[cpg]

[OnName num="shinzi"]
"Are you okay ......?"
[cpg cn=true]


[jump storage="ep010.ks" target="*start"]
