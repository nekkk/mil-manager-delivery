*start

;#################################################
*Ep004|Your friend.
;#################################################
[SCENE id=4]

;//エフェクト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye1"]
[BG f="b_s_3f_t1_1.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午前　小雨





[OnName num="male_student"]
"Hi.
[cpg cn=true]

[OnName num="shinzi"]
"Good morning."
[cpg cn=true]

The next day, I went to school as usual, but to my surprise, ......
[cpg]

[OnName num="shinzi"]
" Amane !"
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0319"]
[OnName num="amane"]
"Good morning.
[cpg cn=true]

To my surprise, Amane was in his seat before me, even though it was yesterday.
[cpg]

[OnName num="shinzi"]
"Are you ready?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0320"]
[OnName num="amane"]
"Yeah. Totally.
[cpg cn=true]

[OnName num="shinzi"]
"I mean, don't put an umbrella ...... on me again.
[cpg cn=true]

After being sick ......, or perhaps not yet cured, Amane 's hair is wet again.
[cpg]

It's a good idea to take a look at the actual information on the web.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0321"]
[OnName num="amane"]
"I don't like umbrellas. Anyway, did you see my message from yesterday?
[cpg cn=true]

[OnName num="shinzi"]
"Yes, I did. I replied.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0322"]
[OnName num="amane"]
"Not the first one, the second one.
[cpg cn=true]

[OnName num="shinzi"]
"The second one?　Oh, yeah, .......
[cpg cn=true]

It was only when he told me that I realized that I had received a reply to my reply from Amane .
[cpg]

[OnName num="shinzi"]
"I'm sorry, I must have fallen asleep because I'm tired.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0323"]
[OnName num="amane"]
"'Oh yeah, ....... You're right, it's normal to be tired since I caused you trouble.　I'm sorry.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, no, no, no. I didn't mean it like that, it was my part-time job day.
[cpg cn=true]

Amane In the event that you have any questions regarding where by and how to use it, you can contact us at our own web site.
[cpg]

Then Amane said ......
[cpg]

;//[FACE method="change_1" pos="2/3"]
[FG f="amane_p6_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0324"]
[OnName num="amane"]
"A part-time job?　 Do you have a part-time job at Shinji ?　Where?"
[cpg cn=true]

[OnName num="shinzi"]
"'At a fast food place by the station.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0325"]
[OnName num="amane"]
"Oh, you're a waitress?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane0326"]
[OnName num="amane"]
"Can I come by sometime?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah?　Yeah, but I'm a little embarrassed.
[cpg cn=true]

I was happy that he was interested in me, but it was kind of embarrassing to see a different version of myself.
[cpg]

In the meantime, if Amane is coming, a strange desire to show a cool appearance of working hard has sprung up, and scratched his head politely.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0327"]
[OnName num="amane"]
"I'm not sure what to say. Today is the day of my first club activity.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, the literary club?　Good luck with that.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0328"]
[OnName num="amane"]
"Yes!
[cpg cn=true]

I said good luck, but I have no idea what kind of activities the literature club does.
[cpg]

That's why we didn't talk any further, and the day passed by without much thought.
[cpg]

;//エフェクト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="healing"]
[BG f="b_s_lp_t2_1.ui" time=1000]
;//【ＢＧ】学園　文芸部部室　午後　小雨


[OnName num="literary_club_Director"]
"Today, I'd like to introduce a new member of the club, sophomore Amane Satonaka ."
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0329"]
[OnName num="amane"]
"I look forward to working with you."
[cpg cn=true]

[SE f="se042"]
;//【ＳＥ】拍手


After school, Amane was alone in the club room of the literature club to greet.
[cpg]

[OnName num="literary_club_Director"]
"Can you briefly introduce yourself?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0330"]
[OnName num="amane"]
"Yes. I'm a book lover, so I joined the club. It would be great if you could tell me about any interesting novels."
[cpg cn=true]

[SE f="se042"]
;//【ＳＥ】拍手


There are many opportunities for new students to introduce themselves, so it's not hard to stand in front of people like this.
[cpg]

But ......
[cpg]

[OnName num="literary_club_Director"]
"Do you have any questions?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0331"]
[OnName num="amane"]
"In the event that you're not sure what to do, you can always ask for help.
[cpg cn=true]

In the event that you're not sure what to do, you can always try to find out more.
[cpg]

Amane It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="literary_club_Director"]
"Oh, there's a drama club in the mix today.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0332"]
[OnName num="amane"]
"Drama club?"
[cpg cn=true]

[OnName num="literary_club_Director"]
"'They're looking for a script for an upcoming performance. They're looking for a script for an upcoming performance, and they've asked our literature club to help out.
[cpg cn=true]

[OnName num="theater_tirector"]
"Well, to be honest, I was hoping you could help me write an original script.
[cpg cn=true]

[OnName num="literary_club_Director"]
"Don't make it easy for me. ......
[cpg cn=true]

[OnName num="theater_tirector"]
"If you can."
[cpg cn=true]


[FG f="amane_p6_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0333"]
[OnName num="amane"]
"............
[cpg cn=true]

That's one of the things ...... that makes me sigh.
[cpg]

You can read a book quietly if you want, but if you want to write a screenplay,......, Amane , you have to look down.
[cpg]

[OnName num="theater_tirector"]
"I'm sure you'll be able to understand why I'm here.　You know?　You'll be able to get a lot more than that.　I'm not sure what to say.
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

[FO pos="2/3" time=800]
However, among them, Amane caught the eye of one girl.
[cpg]

[FG f="shizuku_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0012"]
[OnName num="shizuku"]
Kizaki "You can find a lot of people who are interested in this kind of thing. It's nice to meet you ......."
[cpg cn=true]

It's a great way to get a feel for what's going on.
[cpg]

This is a great way to get the most out of your business.
[cpg]

[OnName num="theater_tirector"]
"I'm sure you'll agree.
[cpg cn=true]

[FG f="shizuku_p5_01_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0013"]
[OnName num="shizuku"]
"I'm sorry, ......."
[cpg cn=true]

[OnName num="theater_tirector"]
"You're so different from your sister, ....... Oh, my God!
[cpg cn=true]

[FG f="shizuku_p5_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0014"]
[OnName num="shizuku"]
"......
[cpg cn=true]

Does she have a sister ......?
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[FO pos="2/3" time=800]

[OnName num="literary_club_Director"]
"So, what should I do after ...... this?
[cpg cn=true]

[OnName num="theater_tirector"]
"In the event that you have any questions, please do not hesitate to contact us.
[cpg cn=true]

[OnName num="literary_club_Director"]
"That's not a good idea. ......
[cpg cn=true]

[OnName num="theater_tirector"]
"If you can't think of anything, write down an original story you can think of. Well, just start!
[cpg cn=true]

[OnName num="literary_club_Director"]
"Ahhhhh ...... So, everyone start .......
[cpg cn=true]

In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

Amane This is a great way to get the most out of your business.
[cpg]



[FG f="amane_p5_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Amane0334"]
[OnName num="amane"]
"That ......
[cpg cn=true]

[FG f="shizuku_p5_01_a.ui" method="change_5" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shizuku0015"]
[OnName num="shizuku"]
"I'm sure you'll agree.
[cpg cn=true]

In the event that you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0335"]
[OnName num="amane"]
"What's your bottom name, ......?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0016"]
[OnName num="shizuku"]
"' Shizuku .......'
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0336"]
[OnName num="amane"]
"'Shizuku ......-chan. That's a nice name.
[cpg cn=true]

[FACE method="change_6" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0017"]
[OnName num="shizuku"]
"Ah, thank you...thank you...yes...sir."
[cpg cn=true]

Shizuku In the event you're not sure what you're looking for, there are a few things you can do.
[cpg]

If it had been my sister's Izumi , I would have been able to gracefully reply, "Thank you, your name is lovely too.
[cpg]

It's a great way to get the most out of your time and money.
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0337"]
[OnName num="amane"]
"I'm sure we'll get along ...... with the rain and Shizuku because I wrote Amane as the sound of rain.
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0018"]
[OnName num="shizuku"]
"Yeah, ......."
[cpg cn=true]

For the first time, Shizuku finally looked up and saw the senior student's face from the front.
[cpg]

"This is a great way to make sure you are getting the most out of your money.
[cpg]

Izumi This is a great way to make sure you are getting the most out of your time with your family and friends.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_2" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Amane0338"]
[OnName num="amane"]
"It's a great way to get to know the people in your area. Shizuku , can you be my friend?"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0019"]
[OnName num="shizuku"]
"Yes, yes!　Oh, if you're okay with me .......
[cpg cn=true]

;//[FACE method="change_2" pos="4/5"]
[FG f="amane_p5_01_a.ui" method="change_2" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Amane0339"]
[OnName num="amane"]
"Nice to meet you.
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0020"]
[OnName num="shizuku"]
"I'd like to thank you as well!
[cpg cn=true]

The new student ....... It's a good idea to have a good idea of what you're looking for.
[cpg]

It will probably take some time ...... before you can compare yourself to your sister.
[cpg]

And that's what Shizuku I thought. Until this senior gets to know his sister, he will not be able to compare himself to her.
[cpg]

I love and respect my sister, but because I love her, I am cursed with my own unworthiness Shizuku of the same blood.
[cpg]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0021"]
[OnName num="shizuku"]
"Um,......, Satonaka senpai,......
[cpg cn=true]

;//[FACE method="change_2" pos="4/5"]
[FG f="amane_p6_01_a.ui" method="change_2" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Amane0340"]
[OnName num="amane"]
"Can you call me Amane ?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0022"]
[OnName num="shizuku"]
" Amane , senpai ......."
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Amane0341"]
[OnName num="amane"]
"Yes.
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0023"]
[OnName num="shizuku"]
"Aha..."
[cpg cn=true]

If you make it sound, the name sounds beautiful.
[cpg]

Shizuku somehow became fun and laughed, peeling the thin skin from the mask of shyness.
[cpg]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0024"]
[OnName num="shizuku"]
"'I'm shy, and ...... once I get used to it... I can talk more.'
[cpg cn=true]

That's a fact.
[cpg]

If you get used to it, you can talk cheerfully with your classmates and the seniors you know.
[cpg]

But I can't do it with people I don't know.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_7" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Amane0342"]
[OnName num="amane"]
"It's okay. I know exactly how you feel.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0025"]
[OnName num="shizuku"]
"So... is that what ...... is for?"
[cpg cn=true]

;//[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0343"]
[OnName num="amane"]
"Yes. I'm the same way. That's why it's so hard for me to make friends.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0026"]
[OnName num="shizuku"]
"But .........
[cpg cn=true]

Shizuku You can find a lot of things that you can do to make your life easier.
[cpg]

You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

If so, I'll try a little harder myself .......
[cpg]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0027"]
[OnName num="shizuku"]
"Oh, um!　 Do you Amane seniors also read ...... plays?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Amane0344"]
[OnName num="amane"]
"Shakespeare and other foreign works are quite ......
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0028"]
[OnName num="shizuku"]
"I like Shakespeare's ...... King Lear!
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0345"]
[OnName num="amane"]
"King Lear ....... If it was Shizuku , you'd play Cordelia, right?
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0029"]
[OnName num="shizuku"]
"Oh, no. ...... me.
[cpg cn=true]

In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

This is a great way to make sure you are getting the most out of your money.
[cpg]

;//[FACE method="change_1" pos="4/5"]
[FG f="amane_p6_01_a.ui" method="change_2" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Amane0346"]
[OnName num="amane"]
"You are in the theater club, so you like to act, right?
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0030"]
[OnName num="shizuku"]
"Yes, but also .......
[cpg cn=true]

I've always wanted to be an actress.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

It is also good at singing and dancing in front of your sister.
[cpg]

But it's a different story when it comes to the actual stage, where the audience is all strangers.
[cpg]

As a shy person, I don't think I can speak loudly in such a place.
[cpg]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0031"]
[OnName num="shizuku"]
".................."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0347"]
[OnName num="amane"]
"I am. ......
[cpg cn=true]

I'm not sure if he sensed something in Shizuku the way he turned his head again after laughing, but Amane started talking about other stories.
[cpg]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0348"]
[OnName num="amane"]
"In the event that you've got a lot of money, you'll be able to use it to buy a lot of things.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0032"]
[OnName num="shizuku"]
" Romeo and Juliet ......"
[cpg cn=true]

;//[FACE method="change_1" pos="4/5"]
[FG f="amane_p5_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Amane0349"]
[OnName num="amane"]
"Ordinary?"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0033"]
[OnName num="shizuku"]
"No, it's not!
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0350"]
[OnName num="amane"]
"I'd like to see it in the drama club. ......
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0034"]
[OnName num="shizuku"]
"Hmm. ...... There's only girls.
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0351"]
[OnName num="amane"]
"What?
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0035"]
[OnName num="shizuku"]
"I wonder if the director would be a Romeo. ......
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0352"]
[OnName num="amane"]
"Well, that's not really ......
[cpg cn=true]

In the event that you've got a lot of money, you'll be able to use it to get the most out of your money.
[cpg]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0036"]
[OnName num="shizuku"]
"...... pfft."
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0353"]
[OnName num="amane"]
"Couscous..."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0037"]
[OnName num="shizuku"]
"Ahahaha!"
[cpg cn=true]

[OnName num="theater_tirector"]
"I'm sorry.　Don't slack off!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0038"]
[OnName num="shizuku"]
"I'm sorry!　Ahahaha!
[cpg cn=true]

On this day, Amane got a friend from the underclassmen.
[cpg]

On that day, Shizuku got a friend from the underclassmen and got a friend from the upperclassmen.
[cpg]


[stopse g=2]
[stopse g=6]

;//ここまで

;//エフェクト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye1"]
[BG f="b_si_r_t4_1.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　夜　小雨


[SE f="se031"]
;//【ＳＥ】メッセージ着信





That day, while I was resting in my room, I received a message from Amane .
[cpg]




;//雨音と陽子は左から、慎二は右側から表示





" Amane " You've made a friend.
[cpg]

" Shinji " Heh, good for you!
[cpg]

" Amane " I met a girl from the drama club at club activities today. She's a very cute underclassman and I think we'll get along.
[cpg]

[OnName num="shinzi"]
"I'm so glad I did.　Why theater club?"
[cpg cn=true]

I had a few questions about the content of the message, and when I replied to it, I got another reply right away.
[cpg]

" Amane " It seems that the activities of the literature club include finding and writing scripts for plays. I didn't know that, so I was a little surprised!
[cpg]

[OnName num="shinzi"]
"'Hohoho ......?'
[cpg cn=true]

Amane I'm not sure what to make of this.
[cpg]

[SE f="se031"]
;//【ＳＥ】メッセージ着信


[OnName num="shinzi"]
"Huh?"
[cpg cn=true]

When I received the next message without replying, I thought it was from a different person, but it was also from Amane .
[cpg]

" Amane " Shinji also let me know if you have a favorite play or a favorite play! (^^)/
[cpg]




[OnName num="shinzi"]
"Ahaha, it's an emoticon.
[cpg cn=true]

Surprisingly, Amane used an emoticon.
[cpg]

Do you always really think like this, and just can't express it?
[cpg]

If that's the case, maybe he'll eventually act as cheerful as this emoticon.
[cpg]

" Shinji " 'A play, okay. I'm not sure what to make of it.
[cpg]

I'm not sure what to make of it.
[cpg]

[SE f="se031"]
;//【ＳＥ】メッセージ着信


" Amane " If you don't know, why did you say you understand?
[cpg]

I'm not sure what you mean by that.
[cpg]

[OnName num="shinzi"]
"That ......"
[cpg cn=true]

This time, there are no surprise marks or emoticons.
[cpg]

I'm not sure what to make of it, but I'm sure it's a good idea.
[cpg]

Shinji I'm sure you'll be able to find something that works for you.
[cpg]

[SE f="se031"]
;//【ＳＥ】メッセージ着信


" Amane " Was that so?　I didn't know that. I'm not a big fan of this kind of thing. I'm sorry m(>_<)m
[cpg]

[OnName num="shinzi"]
"Haha ......"
[cpg cn=true]

I'm not sure what to make of it, but I'm sure it's a good idea.
[cpg]

But how can you use emoticons if you don't do much ......?
[cpg]

A simple question came to my mind, but then I realized that if I typed in "sorry", the emoticons would be mixed in with the conversion list ......, and I thought that Amane had chosen them. It's a bit of fun again.
[cpg]

So I ended the day by communicating with Amane , not realizing that I had overlooked another message that arrived in the mix .......
[cpg]




;//メッセージ画面


" Yoko " Hey, are you alive? I'm not sure if you've heard of it or not.
[cpg]

I've been calling to see how you're doing.
[cpg]


I'm sure you'll be happy to know that I'm not the only one. I think I should try it too.
[cpg]


So, lend me the software for 1 and 2! Counting on ya! ☆
[cpg]




;//エフェクト





A few days later: ......
[cpg]



[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="healing"]
[BG f="b_s_3f_t1_1.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午前　小雨





Amane In the event that you have any questions concerning where and how to use the internet, please do not hesitate to contact us.
[cpg]

[OnName num="female_student"]
"I heard that the sweets there are the best.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0354"]
[OnName num="amane"]
"Is that so?　Well, I'd better go there.
[cpg cn=true]

I'm sure it's just social etiquette, but I'm a little jealous of Amane 's reply.
[cpg]

I'd hate it if it wasn't a social call. ......
[cpg]

I wonder if Amane will go with other guys like he ate Chocolate Sundae with me.
[cpg]

[OnName num="male_student"]
"If you go, I'll buy you a drink!
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0355"]
[OnName num="amane"]
"Huh?　That's .......
[cpg cn=true]

[OnName num="female_student"]
"You're doing great, you know that?
[cpg cn=true]

[OnName num="male_student"]
"I can't help it!　Satonaka's so cute.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0356"]
[OnName num="amane"]
"Hahaha.
[cpg cn=true]

Just like the impression I got from the message, Amane her true personality seems to have come out, and even those who were distant at first began to approach her.
[cpg]

Then, what do you think? She was repeatedly spoken to and answered, and gradually Amane her smile increased.
[cpg]

Now she's a popular girl.
[cpg]

She is now a popular figure, a beautiful woman with a beautiful smile.
[cpg]


;//move
[FACE method="change_1" pos="2/3"]

[move from="2/3" to="2/5" ease="easeInOutSine" time=800]

;//[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]

[WAIT time=100]
[VOICE f="Amane0357"]
[OnName num="amane"]
"Oh, come here.
[cpg cn=true]

[FG f="shizuku_p5_01_a.ui" method="change_6" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Shizuku0039"]
[OnName num="shizuku"]
"Oh, hi, I'm ......."
[cpg cn=true]

[OnName num="shinzi"]
" Shizuku ?　Why?
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0040"]
[OnName num="shizuku"]
"What?　 Mizushima ....... Oh, I see!
[cpg cn=true]

Shizuku came in, scurrying around, apparently forgetting I was in this class.
[cpg]

[OnName num="shinzi"]
"What do you want?
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0041"]
[OnName num="shizuku"]
"Not to Mizushima , but to Amane , my senior.
[cpg cn=true]

[OnName num="shinzi"]
"To Amane ?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0042"]
[OnName num="shizuku"]
"Hey!　Don't call me "senior"!
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

I'm an experienced senior as well, but Shizuku seemed to adore Amane quite a bit and came at me.
[cpg]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0358"]
[OnName num="amane"]
"It's okay, Shizuku ."
[cpg cn=true]

Amane It's a great way to make sure you get the most out of your time with your family and friends.
[cpg]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0043"]
[OnName num="shizuku"]
"You know what?　 There was a play recommended on Ymazon and I bought it. I read it and found it quite interesting, so I thought I'd lend it to my Amane senior."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0359"]
[OnName num="amane"]
"Is it good?　Thank you.
[cpg cn=true]

[OnName num="shinzi"]
"Hmm.
[cpg cn=true]

I wonder if the reason why Amane became brighter has something to do with Shizuku ?
[cpg]

If so, I'm really glad.
[cpg]

I smiled at the two of them as they chatted about the book.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0044"]
[OnName num="shizuku"]
"Hey, don't look at Mizushima ...... me."
[cpg cn=true]

[OnName num="shinzi"]
"It's a good idea to look at it. It's not going to reduce ......
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0045"]
[OnName num="shizuku"]
"Less!　 If Amane you lose your seniority, it's Mizushima your fault. Go away, Amane senior."
[cpg cn=true]

[OnName num="shinzi"]
"What the fuck?
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0360"]
[OnName num="amane"]
"I'm sorry, Shinji .
[cpg cn=true]

[OnName num="shinzi"]
"Mmm-hmm!
[cpg cn=true]


[free time=800]

This is a great way to make sure you are getting the most out of your time with your family.
[cpg]

Amane Shizuku This is a great way to make sure you are getting the most out of your time with your family and friends.
[cpg]

[FG f="youko_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0068"]
[OnName num="youko"]
"What ...... is that girl?"
[cpg cn=true]

[OnName num="shinzi"]
"What the heck?　What's Yoko ...... going on?
[cpg cn=true]

Yoko This is a great way to get the most out of your time at the gym.
[cpg]

This is a great way to get the most out of your business.
[cpg]

[OnName num="shinzi"]
"What is it? What is it? ......
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0069"]
[OnName num="youko"]
"You're even flirting with the boys in my class, sucking up .
[cpg cn=true]

[OnName num="shinzi"]
"That's not true.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0070"]
[OnName num="youko"]
"What?　 You're letting her Shinji get to you?
[cpg cn=true]

[OnName num="shinzi"]
"Don't be a prick. It sounds like you're being sarcastic.
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0071"]
[OnName num="youko"]
"What?　Why do I have to be jealous of her?
[cpg cn=true]

[OnName num="shinzi"]
"Maybe you're upset she's not as popular as you think.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0072"]
[OnName num="youko"]
"What ......?
[cpg cn=true]

Even with this, Yoko is popular with both men and women.
[cpg]

You can find a lot of people who are interested in this kind of thing.
[cpg]

But the downside is that ...... they are emotional and hysterical when they don't get their way.
[cpg]

He is probably angry with Amane the tennis club anyway.
[cpg]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0073"]
[OnName num="youko"]
"'Popular or not, you're an idiot!　I'm not a celebrity, I don't care about that!
[cpg cn=true]

[OnName num="shinzi"]
"So why don't you just leave it alone? Just leave her alone.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0074"]
[OnName num="youko"]
"I don't know!　I mean, Shinji come on, ...... when can I borrow your game?
[cpg cn=true]

[OnName num="shinzi"]
"Games?
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0075"]
[OnName num="youko"]
"The one and two of the three coming out soon! I sent you a message!
[cpg cn=true]

[OnName num="shinzi"]
"Did you?　Didn't you?
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0076"]
[OnName num="youko"]
"I did!　Let me see your phone!
[cpg cn=true]

[OnName num="shinzi"]
"Oh, my God, .......
[cpg cn=true]

Yoko quickly grabbed my phone off the desk and started up a message with a familiar hand.
[cpg]

[BGM f="eye2"]

[FG f="youko_p7_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0077"]
[OnName num="youko"]
"Hey ......."
[cpg cn=true]

But as soon as he saw the screen, Yoko froze.
[cpg]

[OnName num="shinzi"]
"?"
[cpg cn=true]

I'm sure you'll be able to understand why.
[cpg]

[FG f="youko_p5_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0078"]
[OnName num="youko"]
"I'm not sure what to say.　I'm not sure what to make of it.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, ......."
[cpg cn=true]

Yoko is furious that all of the messages displayed on the screen are from Amane Satonaka .
[cpg]

It is true that since the day I exchanged addresses with Amane , I have exchanged messages with them two or three times even on a few days.
[cpg]

;//[FACE method="change_5" pos="2/3"]
[FG f="youko_p7_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0079"]
[OnName num="youko"]
"What?　Girlfriend?　Are you guys dating?"
[cpg cn=true]

[OnName num="shinzi"]
"It's none of your business ......."
[cpg cn=true]

I was annoyed by Yoko 's attitude, as if he was cheating on me.
[cpg]

[OnName num="shinzi"]
"You have no right to be angry with me, no matter who I contact or how much I contact them.
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0080"]
[OnName num="youko"]
"I do!　You ignored my messages!　Look, here!　You're unread!"
[cpg cn=true]

[OnName num="shinzi"]
"Well, ....... I'm sorry about that. If it's a game, I'll bring it back tomorrow."
[cpg cn=true]

I checked the unread message and apologized to him.
[cpg]

But Yoko didn't even try to contain his anger. ......
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0081"]
[OnName num="youko"]
"Enough!　I don't play games!
[cpg cn=true]

[OnName num="shinzi"]
"What?　Then why are you ......
[cpg cn=true]

[FG f="youko_p5_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0082"]
[OnName num="youko"]
"Enough!"
[cpg cn=true]
[move from="2/3" to="4/3" ease="easeInOutSine" time=2000]
;//[FO pos="4/3" time=1600]

And then he walked out as if he was going to crush anyone who came near him.
[cpg]

[OnName num="shinzi"]
"What's that?　I'm so pissed off!
[cpg cn=true]

[OnName num="male_student"]
"Oh, are we having a lovers' quarrel?
[cpg cn=true]

[OnName num="shinzi"]
"Shut up!　I broke up with him a long time ago!　I broke up with her a long time ago! You guys talk like that every time something happens, it makes me crazy!
[cpg cn=true]

[OnName num="male_student"]
"Okay, okay. ...... I'm sorry.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_8" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0361"]
[OnName num="amane"]
"....................."
[cpg cn=true]

[FG f="shizuku_p5_01_a.ui" method="change_2" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shizuku0046"]
[OnName num="shizuku"]
"Okay?　Are you listening?
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_2" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0362"]
[OnName num="amane"]
"Yeah, I'm here. ......
[cpg cn=true]




;//雫に応対しながら、雫ごしに慎二を見詰める雨音


;//☆新規シーン

[free time=800]

[BGM f="healing"]
[BG f="black.ui" time=1000]
;//ブラックアウト

;//パンチラシーン（姉妹、木崎泉&雫）子猫を愛でている２人

On my way home from school, I saw a man.
[cpg]

[OnName num="shinzi"]
"That's...
[cpg cn=true]


;//切り替え

;//●ＣＧ（パンチラ）

[free time=800]
;**【ＣＧ】ev_103_0 ***********************
[CG id=29 index=0 time=1000]
;*****************************************

[WAIT time=100]
[VOICE f="Shizuku0228"]
[OnName num="shizuku"]
"She's pretty, Lisa.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Izumi0237"]
[OnName num="izumi"]
"Yeah, she is.
[cpg cn=true]

There she was, Kizaki Sisters .
[cpg]

They are peeking at something in the park.
[cpg]

Cat: "Meow?"
[cpg cn=true]

In the footsteps of the two, there was a cat. It seems that they are loving the stray cat.
[cpg]

[WAIT time=100]
[VOICE f="Izumi0238"]
[OnName num="izumi"]
"It's so friendly.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Shizuku0229"]
[OnName num="shizuku"]
"Yikes, that tickles."
[cpg cn=true]

While being petted by the sisters, the cat rubs up against them in a friendly manner.
[cpg]

You can take over there for a minute.
[cpg]

I know I shouldn't be looking at it, but I can't help but be drawn to it.
[cpg]

I'm not going to say what.
[cpg]

[WAIT time=100]
[VOICE f="Shizuku0230"]
[OnName num="shizuku"]
"Can't I keep it?"
[cpg cn=true]

[WAIT time=100]
[VOICE f="Izumi0239"]
[OnName num="izumi"]
"I'm sorry, but I can't keep it at home.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Shizuku0231"]
[OnName num="shizuku"]
"Oh, that's too bad.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Izumi0240"]
[OnName num="izumi"]
"Let's check on him once in a while.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Shizuku0232"]
[OnName num="shizuku"]
"Mm-hmm.
[cpg cn=true]

I know that Kizaki Sisters is a good friend of mine, but when I see it like this, it kind of heals my heart.
[cpg]

Izumi In the event that you have any questions regarding where and how to use the internet, you can contact us at the following web page.
[cpg]

With that in mind, I'm on my way home.
[cpg]

The feeling of annoyance from the incident with Yoko has eased a bit.
[cpg]





;//エフェクト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye1"]
[BG f="b_k_ro_t2_0.ui" time=1000]
;//【ＢＧ】木崎家　姉妹の部屋　夜　小雨





[FG f="izumi_p5_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Izumi0030"]
[OnName num="izumi"]
" Shizuku , you've been reading so much since you got home, did you finish your homework?"
[cpg cn=true]

When Izumi came home from school today, he was inwardly pleased to see that his sister was unusually at her study desk.
[cpg]

However, if you take a closer look, you will see that she is not studying, but reading a book.
[cpg]

Although she was quiet for a while, she continued to read silently for half an hour, when Izumi finally got fed up with her sister, she called out ......
[cpg]

[FG f="shizuku_p5_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shizuku0047"]
[OnName num="shizuku"]
"I'm sure you'll agree.
[cpg cn=true]

I'm not sure what to make of that.
[cpg]

This is a great way to get the most out of your time and money.
[cpg]

[FACE method="change_7" pos="4/5"]
[FG f="izumi_p5_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Izumi0031"]
[OnName num="izumi"]
"So ....... And?　What are you so eager to read?
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0048"]
[OnName num="shizuku"]
"This.
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0032"]
[OnName num="izumi"]
"Romeo and Juliet?
[cpg cn=true]

The book that Shizuku shows you has a famous title written on the cover, which is not uncommon.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0033"]
[OnName num="izumi"]
"'Haven't you read it many times already?　Why now?"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0049"]
[OnName num="shizuku"]
"Well, I forgot some parts, so I'll go over it. Because my senior said he liked it.
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0034"]
[OnName num="izumi"]
"Senior?"
[cpg cn=true]

It is also unusual ...... and Izumi thought.
[cpg]

It's not unusual for Shizuku to talk to Izumi about a particular senior student, let alone a classmate.
[cpg]

So suddenly interested, Izumi throws questions to the sister in rapid succession.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0035"]
[OnName num="izumi"]
"I'm not sure what to say.　Is it someone from the theater club?
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0050"]
[OnName num="shizuku"]
"No, no. No, no, he's in the literature club.
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0036"]
[OnName num="izumi"]
"The literature club?　Is there anyone there you'd be interested in?
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0051"]
[OnName num="shizuku"]
"Yes, there was.
[cpg cn=true]

I'm not sure what to make of this.
[cpg]

It's a good idea to have a good idea of what you're doing.
[cpg]

It's a good idea to get a good idea of what you're looking for.
[cpg]

Shizuku This is a great way to make sure that you are getting the most out of your time and money.
[cpg]

But what is the literary club?
[cpg]

The club is rather introverted,......, and to put it badly, it is a gathering place for dark-skinned people, and even if Shizuku you join, no one will care about you.
[cpg]

It's a great way to get to know the people in your area.
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0037"]
[OnName num="izumi"]
"Who is it?"
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0052"]
[OnName num="shizuku"]
" Amane Senior!
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0038"]
[OnName num="izumi"]
"Miss?
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0053"]
[OnName num="shizuku"]
"A sophomore named Amane Satonaka . Oh, he just moved in.
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0039"]
[OnName num="izumi"]
"Yeah, 2C, .......
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0054"]
[OnName num="shizuku"]
"Right.
[cpg cn=true]

I see, I finally understood the reason.
[cpg]

If you are a new student, you will be unafraid to interact with your sister Shizuku .
[cpg]

It's unfortunate, but other students tend to look at Shizuku as the "student body president's sister" and you can see a certain reserved or overly caring attitude.
[cpg]

It's also a problem for Izumi , as Shizuku dislikes such things and becomes more and more introverted.
[cpg]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0055"]
[OnName num="shizuku"]
" Amane He's a senior, he's amazing. He reads a lot of books, and it takes him less than a day to read one!
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0040"]
[OnName num="izumi"]
"Oh, yeah.
[cpg cn=true]

The content of the story itself was not so great, but Izumi was pleased that Shizuku voluntarily and happily told the story.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0041"]
[OnName num="izumi"]
"I'm sure the ...... Satonaka ?　He must be a good person, since you say so.
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0056"]
[OnName num="shizuku"]
"Yes, a very nice person!　He's nice, he's kind, and he's, um, ......
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0042"]
[OnName num="izumi"]
"Well, I'll have to say hello to him sometime. Do you want to introduce me?
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0057"]
[OnName num="shizuku"]
"Sure. ......
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0043"]
[OnName num="izumi"]
"But?"
[cpg cn=true]

Shizuku was a little nervous.
[cpg]

If she introduced her perfect sister to Amane , she, like many other students, would be so taken with her that she would stop caring about her.
[cpg]

But the smile on the face of the sister in front of her is something that even her own sister, Shizuku , cannot resist.
[cpg]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0058"]
[OnName num="shizuku"]
"I'll introduce you. I'll introduce you."
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0044"]
[OnName num="izumi"]
"Oh, you're so patronizing.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0059"]
[OnName num="shizuku"]
"Oh, no, I'm not.
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0045"]
[OnName num="izumi"]
"Is that so?　Mm-hmm.
[cpg cn=true]

[SE f="se067"]
;//【ＳＥ】ノック

[STOPBGM]

[FG f="izumi_p7_01_a.ui" method="change_5" pos="4/5" time=800]
[FG f="shizuku_p7_01_a.ui" method="change_5" pos="2/5" time=800]

[WAIT time=100]
[VOICE f="Izumi0046"]
[OnName num="izumi"]
"......!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0060"]
[OnName num="shizuku"]
"......!
[cpg cn=true]

The sisters were smiling and having a good time.
[cpg]

The only thing that broke the ice was a knock on the door.
[cpg]

In the event that you have any questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

[BGM f="danger"]

[FG f="izumi_p7_01_a.ui" method="change_5" pos="4/5" time=800]
[FG f="shizuku_p7_01_a.ui" method="change_7" pos="2/5" time=800]

[WAIT time=100]
[VOICE f="Shizuku0061"]
[OnName num="shizuku"]
"Oh, sis,......."
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0047"]
[OnName num="izumi"]
"Shh ......, what, what ......?"
[cpg cn=true]

It was my sister Izumi who called out to the knocker.
[cpg]

In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

[OnName num="father_in_law"]
"You look like you're having a great time. Why don't you join us, Dad?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Izumi0048"]
[OnName num="izumi"]
"'..................'
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0062"]
[OnName num="shizuku"]
".................."
[cpg cn=true]

Shizuku 's hand trembled as she gripped Izumi 's arm painfully.
[cpg]

Izumi put his hand on his sister's and gulped, searching for the next word.
[cpg]

[OnName num="father_in_law"]
"' Izumi ?　 Shizuku ?　What's wrong?"
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0049"]
[OnName num="izumi"]
"Nothing...nothing..."
[cpg cn=true]

The owner of the voice is the father of the two.
[cpg]

This is a great way to make sure you are getting the most out of your money.
[cpg]

Kizaki In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

[OnName num="father_in_law"]
"Shall I come in, ......?"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0050"]
[OnName num="izumi"]
"......!"
[cpg cn=true]

[SE f="se035"]
;//【ＳＥ】ドアがゆっくり開く


The moment the wooden door was opened, Shizuku beside Izumi a small ......
[cpg]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0063"]
[OnName num="shizuku"]
"Hee...!"
[cpg cn=true]

I'm sure you've heard of it.
[cpg]



;//エフェクト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="healing"]
[BG f="b_ex_ff_t2_1.ui" time=1000]
;//【ＢＧ】ファストフード店　夜　霧雨


[OnName num="shinzi"]
"Welcome,......!
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0363"]
[OnName num="amane"]
"Good evening.
[cpg cn=true]

[OnName num="shinzi"]
"Ah, Amane !
[cpg cn=true]

I was at work again today when Amane came to visit me.
[cpg]

[OnName num="shinzi"]
"What are you doing at ......?
[cpg cn=true]

You will find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

Since he came here, he must have come to buy a hamburger.
[cpg]

Or perhaps you've come to take a look at yourself working.
[cpg]

However, the reason for Amane 's visit was neither of these.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0364"]
[OnName num="amane"]
"I came to return the umbrella.
[cpg cn=true]

[OnName num="shinzi"]
"What, an umbrella?
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0365"]
[OnName num="amane"]
"You left it for me last time, didn't you?
[cpg cn=true]

[OnName num="shinzi"]
"That would have been nice. ......
[cpg cn=true]

The black umbrella that was presented to me was clean and dry, and I immediately understood that Amane had brought it to me after drying it.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll appreciate it. You're very disciplined.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0366"]
[OnName num="amane"]
"No, I'm not.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, I'm almost done, just wait. Do you want to order something?
[cpg cn=true]

I rubbed my hands and pointed to Amane the menu, suddenly feeling motivated, even though I wasn't going to make it myself.
[cpg]

But Amane is ......
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0367"]
[OnName num="amane"]
"Ummm ......, no, I'll wait outside."
[cpg cn=true]

I'll wait for you outside." He turned to leave the restaurant.
[cpg]

[OnName num="shinzi"]
"Oh, wait, ......."
[cpg cn=true]

In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

[OnName num="store_manager"]
"I'm not sure what to say.　You're a girlfriend?　If you want, you can sit in the empty seat.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0368"]
[OnName num="amane"]
"Yeah, but ......"
[cpg cn=true]

[OnName num="store_manager"]
"Wow, ......, she's beautiful!　I didn't know you had a thing for this guy.
[cpg cn=true]

[OnName num="shinzi"]
"No, no, I'm not his ...... girlfriend. ......
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0369"]
[OnName num="amane"]
"Sorry. Just a little .......
[cpg cn=true]

[OnName num="store_manager"]
"Come on in!
[cpg cn=true]

[OnName num="shinzi"]
"You're hurting me. ...... Manager, ay.
[cpg cn=true]

In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

It was a lot better than being annoying, but I was nervous about being asked this and that during my next shift.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0370"]
[OnName num="amane"]
"'Couscous......'
[cpg cn=true]

[OnName num="shinzi"]
"Hehehe......"
[cpg cn=true]

While observing my work, Amane is smiling at me.
[cpg]

[FO pos="2/3" time=800]

In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

[OnName num="part_time_job"]
"I'll take my turn.
[cpg cn=true]

[OnName num="shinzi"]
"Hi, nice to meet you!"
[cpg cn=true]

[OnName num="store_manager"]
"Wait, wait.
[cpg cn=true]

When it was time for my shift, I quickly took off my apron, and the manager came up to me again.
[cpg]

[OnName num="shinzi"]
"What is it?
[cpg cn=true]

[OnName num="store_manager"]
"Take this with you.
[cpg cn=true]

[SE f="se064"]
;//【ＳＥ】ガサッ


[OnName num="shinzi"]
"What?
[cpg cn=true]

What he offered me was the store's paper bag.
[cpg]

And it was a large handbag.
[cpg]

[OnName num="shinzi"]
"What is it?
[cpg cn=true]

[OnName num="store_manager"]
"Eat it with the two of you. It's a little gift from me.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, thank you very much.
[cpg cn=true]

The contents of the bag were a party pack, and judging from the fact that it was still warm, it wasn't unsold, but had been made in the back by the manager.
[cpg]

[OnName num="store_manager"]
"Good luck!
[cpg cn=true]

[SE f="se023"]
;//【ＳＥ】バシッ


[OnName num="shinzi"]
"Ah!"
[cpg cn=true]

After being sent off with a pat on the back, I showed Amane the paper bag in front of the store.
[cpg]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="rain"]
[BG f="b_ex_tw_t2_0.ui" time=1000]
;//【ＢＧ】街　夜　霧雨


[OnName num="shinzi"]
"He gave it to me and said we should eat it together.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0371"]
[OnName num="amane"]
"What?　That's bad .......
[cpg cn=true]

[OnName num="shinzi"]
"That's good, because that's why they pay me less.
[cpg cn=true]

I deliberately make hateful remarks so that Amane won't be bothered.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0372"]
[OnName num="amane"]
"So you want to eat at my place?
[cpg cn=true]

[OnName num="shinzi"]
"Are you sure?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0373"]
[OnName num="amane"]
"Sure. You're always welcome at Shinji .
[cpg cn=true]

[OnName num="shinzi"]
"Okay.
[cpg cn=true]

When Amane said that, I was thrilled inside.
[cpg]

The last time I did this was by force majeure, but today, Amane is inviting me in herself.
[cpg]

It's a good idea to have a little bit of goodwill when it comes to letting a girl into your room.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0374"]
[OnName num="amane"]
"So let's go.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, umbrella ......
[cpg cn=true]

It's raining again today.
[cpg]

It's a drizzle that doesn't bother you if you don't mind it, but you'll still get wet if you walk.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0375"]
[OnName num="amane"]
"Oh, ......, I've dried it off so well.
[cpg cn=true]

[OnName num="shinzi"]
"Don't worry about it, let's put it on.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0376"]
[OnName num="amane"]
"I don't need it. Shinji can use it.
[cpg cn=true]

[OnName num="shinzi"]
"I'll use .......
[cpg cn=true]

I've heard that the French don't use umbrellas even in heavy rain.
[cpg]

If you think about it, it's not so strange that Amane doesn't like umbrellas.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0377"]
[OnName num="amane"]
"I'm glad you like it.
[cpg cn=true]

[OnName num="shinzi"]
"So, is it?　I'm sorry.
[cpg cn=true]

Amane In the event that you have any questions concerning where and how to use the internet, you can contact us at the web site.
[cpg]



[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye1"]
[BG f="b_a_mr_t4_0.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夜　霧雨





In Amane 's room, we ate party packs and talked about many things.
[cpg]

We talked about school events, Amane club activities, and my part-time job.
[cpg]

These were all things that were not important in terms of content, but strangely enough, all of them were fun and enjoyable, and both Amane and I were smiling the whole time.
[cpg]

[free time=800]
;**【ＣＧ】ev_04_0 ***********************
[CG id=3 index=0 time=1000]
;*****************************************


[WAIT time=100]
[VOICE f="Amane0378"]
[OnName num="amane"]
"After all, it is delicious to eat with someone.
[cpg cn=true]

[OnName num="shinzi"]
"That's right!　I'm usually alone too, so it's super fun.
[cpg cn=true]

Especially when you eat with a cute girl, your appetite doubles.
[cpg]

I'll look up what this phenomenon is called on the Internet sometime.
[cpg]


[WAIT time=100]
[VOICE f="Amane0379"]
[OnName num="amane"]
"But Shinji has a mother, right?　Don't you eat with her?"
[cpg cn=true]

[OnName num="shinzi"]
"My mom is a nurse and works many nights. Well, my cousin sister is there, so sometimes it's just the two of us, sometimes it's the three of us, but most of the time it's just me and a convenience store lunch.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0380"]
[OnName num="amane"]
"Oh, so that's why you know so much about purchasing?
[cpg cn=true]

[OnName num="shinzi"]
"Well, there are days when my cousin makes my lunch, but it's not that often.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0381"]
[OnName num="amane"]
"Hmm. Oh, speaking of bento, the day I moved in, Minegishi was replaced by .......
[cpg cn=true]

[OnName num="shinzi"]
"Oh, that's .......
[cpg cn=true]

I knew it was going to be a bad story.
[cpg]

I didn't think Amane you remembered ...... that time.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll be pleased to know that I'm not the only one.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0382"]
[OnName num="amane"]
"Why?
[cpg cn=true]

[OnName num="shinzi"]
"Why?"
[cpg cn=true]

In the event that you have any questions regarding where and how to use the internet, you can contact us at Amane .
[cpg]

[free time=800]
;**【ＣＧ】ev_04_a ***********************
[CG id=3 index=1 time=1000]
;*****************************************


[WAIT time=100]
[VOICE f="Amane0383"]
[OnName num="amane"]
"I'm not sure what to say, but I'm going to say it.　 You can find a lot of people who are looking for the best way to get the most out of their lives. Minegishi and ...... are also Shinji 's girlfriends?
[cpg cn=true]

[OnName num="shinzi"]
"No, no, no!"
[cpg cn=true]

This is a great way to make sure that you are getting the most out of your money.
[cpg]


[WAIT time=100]
[VOICE f="Amane0384"]
[OnName num="amane"]
"You can find a lot more than just a few things to do.
[cpg cn=true]

[OnName num="shinzi"]
"I'm not sure what to make of that.　Aaa ...... you know what?
[cpg cn=true]

This is where I gave up.
[cpg]

If you're not sure what to say, you might hear a strange rumor or false information Amane by Yoko itself.
[cpg]

[OnName num="shinzi"]
"I've been in a relationship before, you know. With Yoko ."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0385"]
[OnName num="amane"]
"Oh, yeah. ......
[cpg cn=true]

[OnName num="shinzi"]
"Not anymore!　We broke up ...... a long time ago. We broke up a long time ago.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0386"]
[OnName num="amane"]
"What?
[cpg cn=true]

[OnName num="shinzi"]
"A personality conflict?　I mean, he's ...... hard, right?　I'm not good with that kind of thing. It's like he's coming on to me. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0387"]
[OnName num="amane"]
"Yeah, ......, yeah, ......, yeah.
[cpg cn=true]

Amane You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

[OnName num="shinzi"]
"So, even if you bring your own lunch, I don't eat it. It's also annoying when the guys in class make fun of you. Because don't you think so?　I'd be in trouble with a loving bento from a girl who isn't my girlfriend."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0388"]
[OnName num="amane"]
"So why don't you just say that, ......?"
[cpg cn=true]

Amane In the event that you've got a lot of money, you'll be able to use it to get the most out of your money.
[cpg]

[OnName num="shinzi"]
"What?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0389"]
[OnName num="amane"]
"Oh, no. I'm sure Minegishi still likes Shinji ."
[cpg cn=true]

[OnName num="shinzi"]
"Even if you say so, ......"
[cpg cn=true]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト


After that, the conversation stopped and I left Amane 's room feeling bewildered after the meal.
[cpg]

After all, Yoko seems to be a plague god for me.
[cpg]

I was having a great time with Amane , but as soon as we started talking about him, I sank.
[cpg]

[OnName num="shinzi"]
"Annyaroo ......".
[cpg cn=true]

;#############################################################


;#############################################################




[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="healing"]
[BG f="b_si_r_t4_0.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　夜　霧雨





I came home, took a quick bath and lay down in my room.
[cpg]

And before I knew it, I had received a message, and when I looked at the screen of my phone, I saw ......
[cpg]

[OnName num="shinzi"]
"It's Amane !"
[cpg cn=true]

To tell you the truth, I was going to contact her from me to apologize for the weird atmosphere earlier, but what did she say?
[cpg]




;//メッセージ画面


" Amane " Thanks for the dinner.
[cpg]

Thank you for the lovely dinner today.
[cpg]

It was nice to have dinner with you two (^^)
[cpg]




[OnName num="shinzi"]
"Thank you is good, but you're still very disciplined. I mean, you're such a good boy."
[cpg cn=true]

If you look at the fact that he is polite even though he doesn't have parents, you can guess that Amane 's upbringing wasn't that bad.
[cpg]

[OnName num="shinzi"]
You're welcome, and if it's something like that, I'll treat you anytime!" Reply ......."
[cpg cn=true]

In the event that you're a student and you're looking to buy a drink at any time, that's a cool thing to do, but it's also a good way to look good as a man.
[cpg]

Amane In addition to that, you will find a lot of other things that you can do to make your life easier.
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





[OnName num="shinzi"]
"I'm sure you'll agree.
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

In the event that you have any questions regarding where and how to use the internet, please do not hesitate to contact us.
[cpg]




;//メッセージ画面


" Amane " Shinji Te, is there any food you don't like?
[cpg]




[OnName num="shinzi"]
"Dislike?"
[cpg cn=true]

I'm sure it's not uncommon to ask the one you dislike from the start.
[cpg]

I'm not sure what to do. I'm not sure what to do with it.
[cpg]

I typed back.
[cpg]




[SE f="se031"]
;//【ＳＥ】メール送信





[OnName num="shinzi"]
"Dolly Dolly Dolly!"
[cpg cn=true]




;//メッセージ画面


" Amane " Broccoli understood.
[cpg]

I want to find out what I like by observing it slowly.
[cpg]

I'm going to be looking at it slowly to find out what I like.
[cpg]




[OnName num="shinzi"]
"If it's in there?"
[cpg cn=true]

"What if it's in what? Reply.
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





;//メッセージ画面


" Amane " Oh!　I forgot to tell you something important!
[cpg]

You know what, can I make you one?
[cpg]

Shinji 's lunch ...... (//)
[cpg]




[OnName num="shinzi"]
"Eeeeeeeeee!
[cpg cn=true]

Are you serious!
[cpg]

Amane is!　You're gonna make me a bento?
[cpg]

[OnName num="shinzi"]
"You're making me lunch!
[cpg cn=true]

[OnName num="mother"]
" Shinji , are you awake?　Be quiet.
[cpg cn=true]

[OnName num="shinzi"]
"Ha-ha-ha!
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

You're going to make me a lunch box?　Yay!　I'm not sure what to do.
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





;//メッセージ画面


" Amane " I'm not very good, but I'll try my best! (*^_^*)
[cpg]







[OnName num="shinzi"]
"Whoa, whoa, whoa. ......"
[cpg cn=true]

Yoko I'm not sure if I'm going to be able to do it.
[cpg]

Amane is me ......
[cpg]

Seriously?　I'm not sure what to say.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to say.
[cpg cn=true]

I'm not sure if this is a good idea, but it's a good idea.
[cpg]

I'm not sure if this is a flag for a new girlfriend or not.
[cpg]

Yay! It's a good thing.
[cpg]

I was so excited that I couldn't sleep for a while that day.
[cpg]




;//エフェクト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye1"]
[BG f="b_s_3f_t2_1.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午後　小雨


;//雨音のお弁当





[OnName num="shinzi"]
"Aaah~!"
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0390"]
[OnName num="amane"]
"Sorry ....... I went a little crazy. ......
[cpg cn=true]

[OnName num="shinzi"]
"That's not true!　Not at all.
[cpg cn=true]

In the next day's lunch break, when I saw the lunchbox that Amane had made for me as I had declared, I was so impressed that I almost jumped for joy.
[cpg]

This is a great way to get the most out of your day.
[cpg]

Yukika This is a great way to get the most out of your time and money.
[cpg]

[OnName num="shinzi"]
Octopus-shaped Sausage "I'm sure you'll be able to find something to suit your needs.
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0391"]
[OnName num="amane"]
"And if Shinji you ...... are embarrassed."
[cpg cn=true]

[OnName num="shinzi"]
"Oh, sorry, sorry.
[cpg cn=true]

[OnName num="male_student"]
"...... Jeez."
[cpg cn=true]

A few of the bastards gave me a cold stare, but I've already seen ...... it!　Please keep looking!　It's a great way to make sure you're getting the most out of your money.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll be happy to hear that.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0392"]
[OnName num="amane"]
"Uh, yeah, ......."
[cpg cn=true]

Amane In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]



[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="rain"]
[BG f="b_s_la_t2_1.ui" time=1000]
;//【ＢＧ】学園　階段、踊り場　午後　小雨


[SE f="se014"]
;//【ＳＥ】鉄扉開く

;//loop
[SE f="se006" loop=true]
;//【ＳＥ】小雨





[OnName num="shinzi"]
"Gee ......."
[cpg cn=true]

I'm not sure what to make of this.
[cpg]

Amane This is a great way to make sure you are getting the most out of your investment.
[cpg]

It's a little rainy, but eating while wet is not a good idea.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0393"]
[OnName num="amane"]
"Isn't ...... a good idea in the classroom?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, I guess so.
[cpg cn=true]


[FG f="youko_p5_01_a.ui" method="change_3" pos="1/4" time=800]
[move from="2/3" to="4/5" ease="easeInOutSine" time=800]
[move from="1/4" to="2/5" ease="easeInOutSine" time=800]

[WAIT time=100]
[VOICE f="Youko0083"]
[OnName num="youko"]
"What are you doing?
[cpg cn=true]

[OnName num="shinzi"]
" Yoko ?
[cpg cn=true]



In the event that you've got a lot of money, you're going to need to be able to pay for it.
[cpg]

Yoko Amane It's a great way to make sure you're getting the most out of your time with your family and friends.
[cpg]


[WAIT time=100]
[VOICE f="Youko0084"]
[OnName num="youko"]
"I took my lunch to class and he went to the roof,.......
[cpg cn=true]

[OnName num="shinzi"]
"...... Tsk."
[cpg cn=true]

It seems that I was an idiot for getting carried away, and my classmates told Yoko about it.
[cpg]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0085"]
[OnName num="youko"]
"What are you going to do about it?
[cpg cn=true]

[OnName num="shinzi"]
"What?"
[cpg cn=true]

In the hand of the Yoko that was thrust out, there was a familiar lunch bag.
[cpg]


;//[free time=800]
;//[BG f="black.ui" time=1000]
;//[WAIT time=100]
;//[BG f="b_s_la_t2_1.ui" time=1000]
;//【ＢＧ】学園　階段、踊り場　午後　小雨

;//[FACE method="change_1" pos="2/5"]

[OnName num="shinzi"]
"You can find a lot of people who are interested in this kind of thing.
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0086"]
[OnName num="youko"]
"So, did you ask the girl?
[cpg cn=true]

I'm not sure. Amane Yoko This is a great way to get the most out of your time and money.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0394"]
[OnName num="amane"]
"You can find a lot of things that you can do. I just made it on my own.
[cpg cn=true]

When Amane answers with a downcast look, Yoko 's anger explodes.
[cpg]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0087"]
[OnName num="youko"]
"I'm not sure what to do.
[cpg cn=true]


[move from="4/5" to="7/5" ease="easeInOutSine" time=800]
[move from="2/5" to="4/5" ease="easeInOutSine" time=600]
[SE f="se023"]
;//【ＳＥ】ドンッ！



;//[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0395"]
[OnName num="amane"]
"I'm not sure what to say.
[cpg cn=true]

[OnName num="shinzi"]
"Oh!"
[cpg cn=true]




;//loop
[SE f="se007" loop=true]
;//【ＳＥ】雨の音（さっきよりは大きく聞こえる）


Yoko poked him in the shoulder, and Amane was thrown out the door.
[cpg]

[OnName num="shinzi"]
"What are you doing?
[cpg cn=true]
;//[FO pos="4/5" time=800]
;//[FG f="youko_p5_01_a.ui" method="change_3" pos="3/5" time=800]

;//[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Youko0088"]
[OnName num="youko"]
"Shut up, Shinji .
[cpg cn=true]

[OnName num="shinzi"]
"What the fuck?
[cpg cn=true]

[FACE method="change_3" pos="3/5"]
[WAIT time=100]
[VOICE f="Youko0089"]
[OnName num="youko"]
"You know what?　It's a great way to get the most out of your time and money.
[cpg cn=true]

[OnName num="shinzi"]
"......?
[cpg cn=true]

Yoko In the event that you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

[FACE method="change_7" pos="3/5"]
[WAIT time=100]
[VOICE f="Youko0090"]
[OnName num="youko"]
"Do you Satonaka like Shinji me?"
[cpg cn=true]

[FO pos="4/5" time=0]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]

[BG f="b_s_ro_t1_1.ui" time=0]
[FG f="amane_p5_02_a.ui" method="change_8" pos="3/5" time=0]

;//[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Amane0396"]
[OnName num="amane"]
"Yeah, ......."
[cpg cn=true]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[FG f="youko_p5_01_a.ui" method="change_3" pos="3/5" time=0]
[BG f="b_s_la_t2_1.ui" time=0]

;//[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Youko0091"]
[OnName num="youko"]
"If it's just a whim, it's annoying, so can you please stop doing this?
[cpg cn=true]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]

[BG f="b_s_ro_t1_1.ui" time=0]
[FG f="amane_p5_02_a.ui" method="change_7" pos="3/5" time=0]

;//[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Amane0397"]
[OnName num="amane"]
"Sorry. I'm sorry. ......
[cpg cn=true]

[OnName num="shinzi"]
"Don't be sorry!
[cpg cn=true]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[FG f="youko_p5_01_a.ui" method="change_3" pos="3/5" time=0]
[BG f="b_s_la_t2_1.ui" time=0]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Youko0092"]
[OnName num="youko"]
"You may not know Satonaka , but I've known Shinji for a long time. Don't come in here and interrupt me!
[cpg cn=true]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]

[BG f="b_s_ro_t1_1.ui" time=0]
[FG f="amane_p5_02_a.ui" method="change_7" pos="3/5" time=0]

[WAIT time=100]
[VOICE f="Amane0398"]
[OnName num="amane"]
"I'm sorry, .......
[cpg cn=true]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[FG f="youko_p5_01_a.ui" method="change_3" pos="3/5" time=0]
[BG f="b_s_la_t2_1.ui" time=0]

[OnName num="shinzi"]
" Yoko !　Come on, ......!　 Amane , get back here. You're gonna get wet again!
[cpg cn=true]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]

[BG f="b_s_ro_t1_1.ui" time=0]
[FG f="amane_p5_02_a.ui" method="change_7" pos="3/5" time=0]

[WAIT time=100]
[VOICE f="Amane0399"]
[OnName num="amane"]
"It's okay. It's my fault ....... I'm sorry. ......
[cpg cn=true]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[BG f="b_s_la_t2_1.ui" time=0]
[FG f="youko_p5_01_a.ui" method="change_7" pos="3/5" time=0]
[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Youko0093"]
[OnName num="youko"]
"I'm sorry, I'm sorry!　............?"
[cpg cn=true]

The mouth of Yoko , which had been complaining like a machine gun, stopped immediately.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to say.
[cpg cn=true]

Yoko This is a great way to make sure you are getting the most out of your time with your family and friends.
[cpg]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Youko0094"]
[OnName num="youko"]
"I'm not sure what to say. Rain .........?"
[cpg cn=true]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]

[BG f="b_s_ro_t1_1.ui" time=0]
[FG f="amane_p5_02_a.ui" method="change_8" pos="3/5" time=0]

[WAIT time=100]
[VOICE f="Amane0400"]
[OnName num="amane"]
"I'm sorry,......."
[cpg cn=true]

;//loop
[stopse g=2]
[stopse g=6]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_s_la_t2_1.ui" time=1000]
;//【ＢＧ】学園　階段、踊り場　午後　小雨

;//@↑に変更
;//[BG f="b_s_ro_t1_1.ui" time=1000]
;//【ＢＧ】学園　屋上　午前　雨




[FG f="youko_p5_01_a.ui" method="change_7" pos="3/5" time=800]
[WAIT time=1000]

[WAIT time=100]
[VOICE f="Youko0095"]
[OnName num="youko"]
"........................"
[cpg cn=true]

[OnName num="shinzi"]
"Oh, hey, ......, what's going on? Amane , get over here.
[cpg cn=true]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]

[BG f="b_s_ro_t1_1.ui" time=0]
[FG f="amane_p5_02_a.ui" method="change_7" pos="3/5" time=0]
[WAIT time=100]
[VOICE f="Amane0401"]
[OnName num="amane"]
"........................
[cpg cn=true]

I pulled the door to the rooftop closed tightly, as the rain was getting stronger and wetter Amane .
[cpg]

[SE f="se037"]
;//【ＳＥ】鉄扉閉める
;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_s_la_t2_1.ui" time=1000]
;//【ＢＧ】学園　階段、踊り場　午後　小雨



[FG f="youko_p5_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0096"]
[OnName num="youko"]
"It's a good idea,....... I'll see you later."
[cpg cn=true]


[FO pos="2/3" time=800]

[SE f="se065"]
;//【ＳＥ】歩き去る


[OnName num="shinzi"]
"I'm not sure what to say.　Who the hell do you think you are ......?
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0402"]
[OnName num="amane"]
" Shinji ......, I'm fine. ......
[cpg cn=true]

[OnName num="shinzi"]
" Amane ?"
[cpg cn=true]

Whether it's because your body is cold or because you're afraid of Yoko , Amane 's body is shaking slightly.
[cpg]

At this time, I don't know why I didn't ask Yoko more ...... and Amane questions, and now I don't know why. .......
[cpg]

[OnName num="shinzi"]
" Amane , cheer up. Yeah, you should come to my house for dinner today!　My mom and cousin are here tonight, so we can have a nice dinner together!"
[cpg cn=true]

I just wanted to make Amane him smile, so I sang.
[cpg]

Then Amane asked ......
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0403"]
[OnName num="amane"]
" Shinji 's house?　Can I go to ......?"
[cpg cn=true]

[OnName num="shinzi"]
"Of course you can!　And besides, when I told my cousin about Amane the other day, she said, "Bring me. So, you know?　It's good, right?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0404"]
[OnName num="amane"]
"...... Yeah."
[cpg cn=true]

[OnName num="shinzi"]
"Yeah!　Okay, I'll call you. What do you want to eat?"
[cpg cn=true]

I forced myself to be cheerful and excited, and I tried to make Amane fun.
[cpg]

Amane This is a great way to make sure that you get the most out of your time with your family and friends.
[cpg]




[jump storage="ep005.ks" target="*start"]
