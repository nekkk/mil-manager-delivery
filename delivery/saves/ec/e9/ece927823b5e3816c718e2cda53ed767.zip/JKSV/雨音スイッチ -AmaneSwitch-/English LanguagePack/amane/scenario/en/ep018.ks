*start


;#################################################
*Ep018|The stone that rolled out
;#################################################
[SCENE id=18]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_k_ro_t3_0.ui" time=1000]
;//【ＢＧ】木崎家　姉妹の部屋　夜（電気ＯＦＦ）　小雨





[FG f="shizuku_p5_01_a.ui" method="change_7" pos="2/5" time=800]
[FG f="izumi_p5_01_a.ui" method="change_3" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Shizuku0163"]
[OnName num="shizuku"]
"Sister ......"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Izumi0177"]
[OnName num="izumi"]
".................."
[cpg cn=true]

After returning home, Shizuku summoned up the courage to call out to her sister, who had been silently biting her nails.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[free time=800]

[FG f="izumi_p7_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0178"]
[OnName num="izumi"]
".................."
[cpg cn=true]

The Izumi mind was full of today's big incident.
[cpg]

To be precise, it was filled with the fact that Yoko no longer existed.
[cpg]

Up until now, Izumi has been able to keep its head down by simply turning a blind eye to Yoko 's actions and covering them up, but now that Yoko is gone, who's going to When Amane is gone, who will sanction ?
[cpg]

[free time=800]

[FG f="shizuku_p5_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shizuku0164"]
[OnName num="shizuku"]
"Sister ......."
[cpg cn=true]

At that moment, Izumi realizes for the first time that a pitiful voice like the purr of a kitten is beside him.
[cpg]

[FG f="izumi_p5_01_a.ui" method="change_2" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Izumi0179"]
[OnName num="izumi"]
"' Shizuku ....... That's right ......."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0165"]
[OnName num="shizuku"]
"What!"
[cpg cn=true]

Delighted that her sister had turned around, she now rubbed up against Shizuku her like a puppy wagging its tail.
[cpg]

I'm not sure what to do.
[cpg]

Izumi It's a good idea to have a good time.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0180"]
[OnName num="izumi"]
" Shizuku , we're going to do it ...... now."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0166"]
[OnName num="shizuku"]
"Yeah, what?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0181"]
[OnName num="izumi"]
"That. ......
[cpg cn=true]

The more intelligent a person is, the more horrible it is when they are committed to evil.
[cpg]

It's even more frightening when their actions are backed by hatred.
[cpg]

The secret meeting of the sisters continued until late that ...... night.
[cpg]

;//エフェクト


;//※フローチャート０３　○病院　の追加Ｈシーンはカットします

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_3f_t1_0.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午前　曇り
[WAIT time=1000]

Three days later ......
[cpg]

[FG f="amane_p6_01_a.ui" method="change_1" pos="2/3" time=800]
After being discharged from the hospital, Amane he showed up in the classroom as if nothing had happened.
[cpg]

The students were still whispering, but since the perpetrator and the victim were clearly separated, they did not hear any criticism of Amane .
[cpg]

[OnName num="shinzi"]
"What about the wound?
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0844"]
[OnName num="amane"]
"I've got stitches, so I'm fine. I'm taking painkillers.
[cpg cn=true]

[OnName num="shinzi"]
"I see.
[cpg cn=true]

I was a little relieved to see that the bandages were less tight than when I was in the hospital.
[cpg]

[OnName num="shinzi"]
"But take it easy, okay?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0845"]
[OnName num="amane"]
"Yes. I'm going to attend some club activities today, but I'm in the literature club.
[cpg cn=true]

[OnName num="shinzi"]
"That's right.
[cpg cn=true]

If it's just a book club, it will be fine.
[cpg]

Perhaps because the trauma of Yoko has disappeared from the school, Amane looks very stable.
[cpg]

So I might have loosened up on her calmness.
[cpg]

Forgetting that there are still discontents .......
[cpg]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=900]
[BG f="b_s_lp_t2_0.ui" time=1000]
;//【ＢＧ】学園　文芸部部室　午後　曇り

[WAIT time=1000]

[OnName num="director"]
"''Today, in conjunction with the drama club, I would like to select the script written by the literary club members themselves, which we have been looking for for some time.''
[cpg cn=true]

[OnName num="theater_tirector"]
"Yay!"
[cpg cn=true]

I've been working on my own script for the theater club's performance.
[cpg]

In fact, Amane is no exception, and they have been working hard to write a script for this day.
[cpg]

[OnName num="director"]
"Let's start with the first-year students and read them aloud in order.
[cpg cn=true]

Under the direction of the head of the literature department, one by one, the students began to read their own plays.
[cpg]

[OnName num="member1"]
"'The culprit is you,' points to Fujiko Detective Bolongo and spotlights ......."
[cpg cn=true]

[OnName num="theater_tirector"]
"Oh, that's cool!　I love a good mystery!
[cpg cn=true]

[OnName num="director"]
"Don't interrupt me. I'll tell you what I think later.
[cpg cn=true]

[FG f="shizuku_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0167"]
[OnName num="shizuku"]
".................."
[cpg cn=true]

At what should be an exciting time, Shizuku is waiting for the moment, listening to the reading.
[cpg]

[FO pos="2/3" time=800]

[OnName num="director"]
"Now we move on to the second grade. Satonaka , please."
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0846"]
[OnName num="amane"]
"Yes."
[cpg cn=true]

Finally, it's Amane 's turn, and she stands up and starts reading her book.
[cpg]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0847"]
[OnName num="amane"]
She stands up and begins to read her book: "'You don't understand anything about me. Why is that ......?"
[cpg cn=true]

[FG f="shizuku_p5_01_a.ui" method="change_1" pos="9/9" time=800]
[WAIT time=100]
[VOICE f="Shizuku0168"]
[OnName num="shizuku"]
"I can't hear you.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0848"]
[OnName num="amane"]
"I'm sorry. .........
[cpg cn=true]

The fact that the complaint came from someone who doesn't usually speak out voluntarily, everyone's attention is focused on Shizuku .
[cpg]

[FO pos="9/9" time=800]

[OnName num="director"]
" Satonaka , ...... a little louder."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0849"]
[OnName num="amane"]
"Yes, ......."
[cpg cn=true]

It was a point that was not too far off the mark, and Amane was warned.
[cpg]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0850"]
[OnName num="amane"]
"I'm going to war. "I'm going to war." "What?"
[cpg cn=true]

[OnName num="theater_tirector"]
"Yeah, yeah, yeah, it makes me cry."
[cpg cn=true]

[OnName num="director"]
"Shut the fuck up. ......
[cpg cn=true]

[FG f="shizuku_p5_01_a.ui" method="change_1" pos="9/9" time=800]
[WAIT time=100]
[VOICE f="Shizuku0169"]
[OnName num="shizuku"]
"....................."
[cpg cn=true]

[FO pos="9/9" time=800]

The content of the script written by Amane is a tragic love story set in medieval Europe.
[cpg]

It wasn't particularly good or interesting, but neither were the other members of the club.
[cpg]

It was not particularly good or interesting, but it was the same for the other members of the club, which was natural since they were all still students.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0851"]
[OnName num="amane"]
"I'm waiting for you. Forever and ever ...... forever and ever ......' curtain."
[cpg cn=true]

Eventually, everyone finished their presentations, and each of us took a turn giving our impressions, and a variety of opinions came out.
[cpg]

[OnName num="theater_member"]
"'I thought Detective Borongo was a good genre that had never been done before.
[cpg cn=true]

[OnName num="literary_club_member"]
"Thank you."
[cpg cn=true]

Since the club was originally a friendly one, no one said anything that sounded like criticism.
[cpg]

In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

However, when it came to the turn of Amane 's script, the situation changed.
[cpg]

[BGM f="insecurity"]

[FG f="shizuku_p5_01_a.ui" method="change_1" pos="4/5" time=800]
[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]

[WAIT time=100]
[VOICE f="Shizuku0170"]
[OnName num="shizuku"]
"I thought Satonaka senior's story was like a ...... old girl's manga.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0852"]
[OnName num="amane"]
"Yeah,.......
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0171"]
[OnName num="shizuku"]
"It's honestly a poorly written story that you might have seen somewhere before. And there are a lot of wrong kanji, and above all, I don't think it's possible to have a war scene in the story.
[cpg cn=true]

[OnName num="theater_tirector"]
"Why?
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0172"]
[OnName num="shizuku"]
"Because there's no way you can have an army of allies and enemies, considering the number of people in the theater department.
[cpg cn=true]

[OnName num="theater_member"]
"That's true. ......
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0173"]
[OnName num="shizuku"]
Also, the first person of the characters was mixed up with "I" and "me", which was hard to understand. And the fact that the love scene was so important in a student drama made it seem sleazy and unpopular.
[cpg cn=true]

[OnName num="theater_tirector"]
"Oh well. ......"
[cpg cn=true]

[OnName num="literary_club_Director"]
"The board of directors might complain. ......
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0853"]
[OnName num="amane"]
"...............
[cpg cn=true]

It's time for Amane 's work to be dismissed by Shizuku in a competition where no one else has come in for criticism.
[cpg]

Amane In the event that you've got a lot of time, you'll be able to take a look at a few of the best ways to get the most out of your time.
[cpg]

[OnName num="theater_member"]
"If you ask me, it's ridiculous,.......
[cpg cn=true]

[OnName num="literary_club_member"]
"It's a bit of an overkill. ......
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0174"]
[OnName num="shizuku"]
"Satonaka, you're dreaming a little too much, aren't you?
[cpg cn=true]

[SE f="se090"]
;//【ＳＥ】笑い声


[OnName num="theater_member"]
"Ahaha!　I can't help it if I'm told by a first year.
[cpg cn=true]

[OnName num="literary_club_Director"]
" Satonaka , do you like shoujo manga?
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0854"]
[OnName num="amane"]
"No, .......
[cpg cn=true]

In the event that you are not expecting to be the target of ridicule in such a place, Amane will fall on your face in embarrassment.
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0175"]
[OnName num="shizuku"]
"It's a good idea to use yourself as a model instead of your imagination.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0855"]
[OnName num="amane"]
"Yes, ......."
[cpg cn=true]

In addition, Shizuku will not stop running wild.
[cpg]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0176"]
[OnName num="shizuku"]
"I think a theme about your parents' divorce or your experience of bullying will give you a sense of reality.
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0856"]
[OnName num="amane"]
"That's very deep.
[cpg cn=true]

[OnName num="member1"]
"That's so profound. ......
[cpg cn=true]

[OnName num="member2"]
"It's such an amazing experience, it could be a literary work.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0857"]
[OnName num="amane"]
"..................
[cpg cn=true]

The wounds of Amane are being gouged out by students who can't read the air.
[cpg]

[OnName num="member3"]
"What kind of bullying were you subjected to?
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0858"]
[OnName num="amane"]
"What kind of bullying did you ...... receive?
[cpg cn=true]

Memories of painful days flash back.
[cpg]

I felt dizzy and slumped into a pipe chair.
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0177"]
[OnName num="shizuku"]
"It's a good idea to have a good idea of what you're doing. Please tell me about it.
[cpg cn=true]

Shizuku You can find a lot more information on the web.
[cpg]

This action of hers was directed by Izumi in advance.
[cpg]

No matter what kind of script you've got, you've got to be able to point out and criticize only the bad parts.
[cpg]

In detail, Izumi had prepared the usual criticism words for various genres, such as suspenseful foreshadowing and tricks, romance is poor and smelly.
[cpg]

And don't forget to rub salt in the heartbreak of Amane with .......
[cpg]

Shizuku , the puppet of Izumi , did very well indeed.
[cpg]


[free time=800]

[SE f="se009"]
;//【ＳＥ】チャイム


[OnName num="director"]
"Ah, let's call it a day for now."
[cpg cn=true]

With the chime ringing for dismissal from school, Amane was finally released.
[cpg]

I noticed that under the bandage on my left hand, the stitched wound was throbbing.
[cpg]

At the same time, he felt the same tingle in his chest under his uniform, and he knew he had to get away from here as soon as possible.
[cpg]

But ......
[cpg]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="shizuku_p5_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shizuku0178"]
[OnName num="shizuku"]
" Amane seniors."
[cpg cn=true]

As he stood up, Shizuku spoke to him, and Amane his movements stopped.
[cpg]

[move from="4/5" to="3/5" ease="easeInOutSine" time=1000]
[WAIT time=100]
[VOICE f="Shizuku0179"]
[OnName num="shizuku"]
"This.
[cpg cn=true]

[move from="3/5" to="4/5" ease="easeInOutSine" time=1000]

[FACE method="change_7" pos="2/5"]


[WAIT time=100]
[VOICE f="Amane0859"]
[OnName num="amane"]
"What ......?"
[cpg cn=true]

A large brown envelope that Shizuku held out to you.
[cpg]

Amane It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0180"]
[OnName num="shizuku"]
"It's a great way to get a little bit of help from your friends and family.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0860"]
[OnName num="amane"]
"......?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0181"]
[OnName num="shizuku"]
"That's a promise.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0861"]
[OnName num="amane"]
"Okay, .......
[cpg cn=true]

What did Izumi do to you, ......?
[cpg]

The contents of the envelope are very curious, Amane , and he immediately returned to the classroom.
[cpg]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye2"]
[BG f="b_s_3f_t2_0.ui" time=800]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午後　曇り



When you return to 2C, you will find that there is no one there.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0862"]
[OnName num="amane"]
"What is it ......?"
[cpg cn=true]

So Amane decided to open the envelope that Shizuku had handed him there.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0863"]
[OnName num="amane"]
"What ......?"
[cpg cn=true]

When I pulled out the contents, I found that it was about 10,000 yen bills.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0864"]
[OnName num="amane"]
"What is this money ......?
[cpg cn=true]

I don't understand why Izumi sent me cash at all.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="female_student1"]
"So, you know what?
[cpg cn=true]

[OnName num="female_student1"]
"Oh, no. Isn't it bad?
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0865"]
[OnName num="amane"]
"......."
[cpg cn=true]

In the event that the other students came, Amane immediately put the envelope into the bag.
[cpg]

[FACE method="change_7" pos="2/3"]

What should I do ......?
[cpg]

I immediately called Shizuku 's phone, but I couldn't get through.
[cpg]

I'll have to find out why ...... tomorrow.
[cpg]

Amane thought, and went home.
[cpg]

;//エフェクト


The next day ......
[cpg]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=900]
[BGM f="rain"]
[BG f="b_s_gy_t1_0.ui" time=800]
;//【ＢＧ】学園　体育館　朝　曇り


[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]

[OnName num="shinzi"]
"How were the club activities yesterday?
[cpg cn=true]

In the gym before the morning assembly, I spoke to Amane .
[cpg]

;//[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0866"]
[OnName num="amane"]
"Yes,....... It was okay. ......
[cpg cn=true]

[OnName num="shinzi"]
"What?"
[cpg cn=true]

Amane This is a great way to get the most out of your time with your family and friends.
[cpg]

[OnName num="shinzi"]
"Is there something wrong?
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0867"]
[OnName num="amane"]
"No!　Nothing. It was fun as usual.
[cpg cn=true]

[OnName num="shinzi"]
"I hope so. ......
[cpg cn=true]

From now on, we have to make Amane become more and more cheerful.
[cpg]

In the event the rainy season is over, you can go out to various places and invite them to sports.
[cpg]

I had such a sweet dream.
[cpg]

[OnName num="shinzi"]
I was dreaming of such a sweet dream, "Yes, let's go to the bookstore together on the way home today. We can buy a guidebook.
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0868"]
[OnName num="amane"]
"A guidebook?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah. For date spots.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0869"]
[OnName num="amane"]
"What?　Oh, that's nice.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah?
[cpg cn=true]


[free time=800]

[transition target={true} rule="sita.jpg"  time=1000]
[WAIT time=1100]
[BG f="b_s_gy_t1_0_m_up.ui" time=0]
[FG f="izumi_p3_01_a.ui" method="change_1" pos="2/3" time=0]
[transition target={false} rule="sita.jpg" time=800]
[WAIT time=800]


;//壇上に泉

;//[BG f="b_s_gy_t1_0_m_up.ui" time=800]

[WAIT time=100]
[VOICE f="Izumi0182"]
[OnName num="izumi"]
"Good morning.
[cpg cn=true]

The morning assembly began, and the president of the student council began to greet the students on the stage, so the conversation between Amane and me was cut off.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0183"]
[OnName num="izumi"]
"Before the president's speech today, the student council has an announcement to make.
[cpg cn=true]

[OnName num="shinzi"]
"What is it? That's unusual ......."
[cpg cn=true]

Even if there is a contact from the student council, it is usually done after the teacher's speech.
[cpg]

This is a great way to get the most out of your business.
[cpg]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0184"]
[OnName num="izumi"]
"Yesterday, there was a theft incident in which the student council's reserve fund for the operation of the school festival was lost. It is a very important money for all students of the school, so if you know anything about it, please provide information.
[cpg cn=true]

[OnName num="shinzi"]
"Theft: ......?"
[cpg cn=true]

[SE f="se053"]
;//【ＳＥ】ザワザワ


[WAIT time=100]
[VOICE f="Shizuku0182"]
[OnName num="shizuku"]
"Isn't it on the security camera?
[cpg cn=true]

I heard such a voice from somewhere far away.
[cpg]

[OnName num="male_student1"]
"Yes, the security cameras!
[cpg cn=true]

[OnName num="male_student2"]
"That's what you get when you check them out.
[cpg cn=true]

[SE f="se053"]
;//【ＳＥ】ザワザワザワ


;//[FG f="izumi_p1_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0185"]
[OnName num="izumi"]
"We don't have the authority to look at the security camera footage. We need permission from the headmaster.
[cpg cn=true]

[OnName num="female_student"]
"Mr. President!　Let's check it out!
[cpg cn=true]

[OnName num="male_student"]
"Yeah, yeah, yeah!
[cpg cn=true]

[OnName num="School_principal"]
"Umm, umm ....... That's what the faculty will ...... later.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0186"]
[OnName num="izumi"]
"Mr. Principal, you can't let a case like this go unanswered.
[cpg cn=true]

[OnName num="Audiovisual_committee"]
"That's right!　Do you have any security camera footage you can upload right now?
[cpg cn=true]

[OnName num="male_student"]
"That's great, that's great!　Let's see it!
[cpg cn=true]

"Let's see it! Let's see it! The call of "Let's see it!" gets louder and louder, and the teachers are left and right.
[cpg]

Finally, the headmaster became silent, and several cables were connected to the monitors and terminals on the stage at the initiative of the students.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0187"]
[OnName num="izumi"]
"But the number of security cameras is enormous, so we can't watch them all here. We'll just have a quick look and leave the rest to the student council, okay?"
[cpg cn=true]

[OnName num="female_student"]
"Whatever, let's see it as soon as possible!"
[cpg cn=true]

In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

They are pestering Izumi and trying to get excited about it anyway.
[cpg]

[OnName num="Audiovisual_committee"]
"Then I'll just switch to yesterday's recording at random!
[cpg cn=true]

[FO pos="2/3" time=800]
[BG f="Camera_1.ui" time=800]
[WAIT time=1000]
;//スクリーンに現れる、各所の分割モノクロ映像


[OnName num="male_student"]
"Oh, my class!"
[cpg cn=true]

[OnName num="female_student"]
"Oh, my class!" "Oh, it's me!
[cpg cn=true]

The students stare at the monochrome screen as if they were watching TV.
[cpg]


;//[FG f="izumi_p1_01_a.ui" method="change_3" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Izumi0188"]
[OnName num="izumi"]
"Oh, what's that image on the right?　Can you enlarge it?
[cpg cn=true]

[OnName num="Audiovisual_committee"]
"Yes. It's, um, ......2C."
[cpg cn=true]

;//[FO pos="2/5" time=800]

The audio-visual committee member's voice echoed as he operated a movable terminal.
[cpg]

[BG f="Camera_2.ui" time=800]
[WAIT time=1000]

[OnName num="shinzi"]
"Our class is ......?"
[cpg cn=true]

[OnName num="male_student"]
"Oh, hey, .......
[cpg cn=true]

[OnName num="female_student"]
"Hey, ......."
[cpg cn=true]

;//[FG f="amane_p5_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Amane0870"]
[OnName num="amane"]
"What?
[cpg cn=true]


On the screen, there was an image of Amane alone in the classroom.
[cpg]

In black and white, she is pulling something out of an envelope in her hand to check it out.
[cpg]

[WAIT time=100]
[VOICE f="Izumi0189"]
[OnName num="izumi"]
"'Stop right there!　Try to zoom in ......."
[cpg cn=true]


[BG f="Camera_3.ui" time=800]
[WAIT time=1000]
;//封筒の現金を見ている雨音


[OnName num="shinzi"]
"...Wha...?"
[cpg cn=true]

A person's shadow, which is projected on the stopped screen, is Amane no matter how you look at it.
[cpg]

And in your hand is a bundle of money .......
[cpg]

[BG f="b_s_gy_t1_0_m.ui" time=0]
[FG f="amane_p5_01_a.ui" method="change_3" pos="2/3" time=0]
[WAIT time=100]
[VOICE f="Amane0871"]
[OnName num="amane"]
"I'm not sure what to do.　I'm sure you'll agree.
[cpg cn=true]

[SE f="se053"]
;//【ＳＥ】ザワザワザワ



Amane It's a great way to make sure you're getting the most out of your time at the gym.
[cpg]

[FO pos="2/3" time=400]
[BG f="b_s_gy_t1_0_m_up.ui" time=400]
[FG f="izumi_p3_01_a.ui" method="change_3" pos="2/3" time=400]
[WAIT time=100]
[VOICE f="Izumi0190"]
[OnName num="izumi"]
"Quiet!　I'm sure you'll be pleased to know that I'm not the only one who's interested in this.　Everyone, please remain calm."
[cpg cn=true]

[OnName num="female_student"]
"That's right. You're right, Mr. Chairman!　It's terrible to suddenly suspect him.
[cpg cn=true]

With the words of Izumi , everyone becomes calm.
[cpg]

However, only the audio-visual committee member was tapping on the keyboard with pride.
[cpg]

[OnName num="Audiovisual_committee"]
"You can also zoom in more?
[cpg cn=true]

;//数段階に分けて封筒がアップになっていき、封筒の表の文字『学園祭用学生会費』が読める大きさになる

[FO pos="2/3" time=800]

[BG f="Camera_4.ui" time=800]
[WAIT time=1800]
[BG f="Camera_5.ui" time=0]
[WAIT time=1000]
[BG f="Camera_6.ui" time=0]
[WAIT time=1000]

;//[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0191"]
[OnName num="izumi"]
"Ah!
[cpg cn=true]

It's a good idea to use a high resolution security camera to record even the letters on the envelope.
[cpg]

This is a great way to make sure you are getting the best value for your money.
[cpg]



[BG f="b_s_gy_t1_0_m.ui" time=0]
[FG f="amane_p5_01_a.ui" method="change_3" pos="2/3" time=0]
[WAIT time=100]
[VOICE f="Amane0872"]
[OnName num="amane"]
"That's a lie!　There was nothing written on that envelope!
[cpg cn=true]

[OnName num="shinzi"]
"What ......?"
[cpg cn=true]

[SE f="se053"]
;//【ＳＥ】ザワザワザワ

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0873"]
[OnName num="amane"]
"I don't know anything about this!　Believe me!
[cpg cn=true]

[OnName num="shinzi"]
"But this is .......
[cpg cn=true]

I didn't want to doubt it.
[cpg]

But as long as it was on video, I had to admit that Amane was telling the truth.
[cpg]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0874"]
[OnName num="amane"]
"I didn't steal any money!　That, that envelope is for me ......."
[cpg cn=true]

[OnName num="teacher"]
"Satonaka, come to the staff room for a minute. ......"
[cpg cn=true]

The teacher who approached interrupted Amane and grabbed her by the arm.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0875"]
[OnName num="amane"]
"I'm not sure what to say.　I did not do it!
[cpg cn=true]

[OnName num="shinzi"]
"Yes, you did!　After all, Amane is not in need of money!　There's no need to steal it!
[cpg cn=true]

I yelled, grabbing at the teacher.
[cpg]


I yelled at the teacher as I grabbed him, but Izumi said into the microphone from the podium.
[cpg]

;//[FO pos="2/3" time=400]
;//[BG f="b_s_gy_t1_0_m_up.ui" time=400]
;//[FG f="izumi_p1_01_a.ui" method="change_7" pos="2/3" time=400]
[WAIT time=100]
[VOICE f="Izumi0192"]
[OnName num="izumi"]
"I'm sorry, but stealing is a disease that doesn't depend on your financial status. When you see money, you reach for it, and that's stealing.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0876"]
[OnName num="amane"]
"I'm not a thief!　That envelope is yours ......!
[cpg cn=true]

[OnName num="teacher"]
"Just come here!"
[cpg cn=true]



[FACE method="change_4" pos="2/3"]
[move from="2/3" to="4/3" ease="easeInOutSine" time=1200]
[WAIT time=1200]


In rebuttal, Amane was taken away by several teachers .......
[cpg]
[FO pos="4/3" time=0]
;//視点、泉へ


[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye2"]
;//[BG f="b_s_gy_t1_0.ui" time=800]
[WAIT time=800]
;//【ＢＧ】学園　体育館　朝　曇り

[FG f="izumi_p7_01_a.ui" method="change_7" pos="2/3" time=1000]
[WAIT time=100]
[VOICE f="Izumi0193"]
[OnName num="izumi"]
"Huh. ....... I didn't expect this to happen ......."
[cpg cn=true]

The mumbling Izumi was smiling high in his heart.
[cpg]

I never thought that things could go so well.
[cpg]

It's a great way to make sure you're getting the most out of your time with your family.
[cpg]

This is why it was worth staying up all night.
[cpg]

It's worth the effort to hone your intelligence.
[cpg]

;//エフェクト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="insecurity"]
[BG f="b_s_3f_t1_0.ui" time=800]
[WAIT time=800]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午前　曇り


[OnName num="female_student"]
"I knew it. ....... Crazy people are crazy to no end. ......
[cpg cn=true]

[OnName num="male_student"]
"It's too disturbing to be in the same class with someone like that. ......
[cpg cn=true]

That day, the whole day was full of talk about Amane .
[cpg]

It's a good thing that the school's students are paying for their own student council fees, because all the students are angry at Amane and are having a good time anticipating the judgment that will be handed down for their crimes.
[cpg]

[OnName num="shinzi"]
"It's not true ....... There is no way Amane would steal from ......."
[cpg cn=true]

There is only one person I believe in .......
[cpg]

But even for me, I can't imagine that the images on Amane are CG.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]




;//エフェクト

[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_ex_ff_t1_0.ui" time=800]
[WAIT time=1000]
;//【ＢＧ】ファストフード店　夕方　曇り





After school that day, while I was working, I kept looking at my phone.
[cpg]

I'd already sent a message to Amane saying 'contact me soon', so I was going to rush over as soon as I heard from her.
[cpg]

[OnName num="store_manager"]
"'Hey, don't dawdle!
[cpg cn=true]

The manager shouts at me because I'm so absent-minded.
[cpg]

But even that didn't matter to me right now.
[cpg]

The only thing I'm waiting for is for Amane to contact me as soon as possible.
[cpg]




[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
[BG f="b_ex_tw_t2_1.ui" time=800]
[WAIT time=1000]
;//【ＢＧ】街　夜　雨


;//【雨】


;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]








[OnName num="shinzi"]
"What the heck is going on ......?
[cpg cn=true]

My phone didn't ring when I finished my part-time job at night.
[cpg]

Is he still at school?
[cpg]

Or has he been turned over to the police or ......?
[cpg]

No,......, even if I lose my mental equilibrium again and hurt myself,.......
[cpg]

With all the anxiety going around in my head, I couldn't stand still, so I headed to Amane 's apartment first.
[cpg]




;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[STOPBGM]

[BG f="black.ui" time=1000]
[WAIT time=1000]
;//【ＢＧ】ブラックアウト




;//[SE f="se003"]
;//【ＳＥ】雨風の吹き込む音



[OnName num="shinzi"]
" Amane ......?"
[cpg cn=true]


[SE f="se014"]
;//【ＳＥ】鉄扉開く

In the event that you have any questions regarding where and how to use the internet, please do not hesitate to contact us.
[cpg]

In the event that you have any kind of questions concerning where and how to use the internet, you can contact us at the web site.
[cpg]

[OnName num="shinzi"]
"?!"
[cpg cn=true]

;//瞬くネオンの薄明かりに照らされる、人形のバラバラになったパーツ。目玉、頭、腕、手、脚、足にわかれて１体ずつきちんと並べられた状態


;//[free time=800]

;**【ＣＧ】ev_55_0 ***********************
[CG id=18 index=0 time=1000]
;*****************************************
[WAIT time=1400]

[BGM f="h2"]

At first glance, I realized the madness.
[cpg]

It's a great way to make sure you don't end up in a situation where you can't get out of it.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll agree.
[cpg cn=true]

;//床に脚を投げ出して人形のように座り、壁にもたれた姿勢の雨音。その肘関節、手首、足首、膝関節から血が滴っている


;//[free time=800]


;**【ＣＧ】ev_55_a ***********************
[CG id=18 index=1 time=1000]
;*****************************************

[WAIT time=100]
[VOICE f="Amane0877"]
[OnName num="amane"]
"I want to be ...... in pieces ......."
[cpg cn=true]

[OnName num="shinzi"]
" Amane !!!"
[cpg cn=true]

He threw his legs on the floor and sat like a doll, Amane , bleeding from every joint.
[cpg]

[OnName num="shinzi"]
"Idiot!　You, ...... again!"
[cpg cn=true]

While hurriedly stopping the bleeding, he frantically called out to Amane .
[cpg]

There was a pair of bloodstained scissors lying next to him.
[cpg]

[OnName num="shinzi"]
"You tried to cut it out with this!
[cpg cn=true]

I'm a little relieved that the tool of choice was scissors.
[cpg]

He thought it would be impossible for a human joint to fall out of place even if he used scissors to cut paper.
[cpg]


[WAIT time=100]
[VOICE f="Amane0878"]
[OnName num="amane"]
"I'm not ......
[cpg cn=true]

[SE f="se092"]
;//【ＳＥ】ボロボロ…（錠剤が床にこぼれ落ちる）


[free time=800]

;**【ＣＧ】ev_55_b ***********************
[CG id=18 index=2 time=1000]
;*****************************************

[OnName num="shinzi"]
"What?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0879"]
[OnName num="amane"]
"If I could just ...... fall apart ...... like a doll... good ......"
[cpg cn=true]

[SE f="se092"]
;//【ＳＥ】ボロボロボロ！


[OnName num="shinzi"]
"Wha...?"
[cpg cn=true]

Every time Amane says a word, white grains spill onto the floor, raggedly from the gap between the lips.
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
[BG f="b_a_mr_t4_4_s.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夜　雨

[FG f="amane_p6_02_a.ui" method="change_4" pos="2/3" time=800]
If you look closely at your eyes, you will see that it is a pill that you have seen sometime .......
[cpg]

[OnName num="shinzi"]
"'Even the pills!　Don't drink it!　Spit it out!!!"
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_4" pos="2/3" time=800]
He held Amane his cheek and pried open his mouth, scraping out the round grains that were stuck inside.
[cpg]


[WAIT time=100]
[VOICE f="Amane0880"]
[OnName num="amane"]
"I'm not sure what to do.　I'm sorry.
[cpg cn=true]

[SE f="se092"]
;//【ＳＥ】バラバラバラッ！


[FO pos="2/3" time=800]

[OnName num="shinzi"]
"You promised you wouldn't take any more. ......!
[cpg cn=true]

Amane In the event that you've got a lot of money, you'll be able to take a look at the best way to get it.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to do. Why didn't you call me ......?"
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0881"]
[OnName num="amane"]
"The money .......
[cpg cn=true]

[OnName num="shinzi"]
"What...?"
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0882"]
[OnName num="amane"]
"I paid for it. ......
[cpg cn=true]

[OnName num="shinzi"]
"But you didn't steal Amane , did you?
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0883"]
[OnName num="amane"]
"Even if I told the truth, no one would believe me. ...... Dr. ...... says he'll forgive me if I give him his money back.
[cpg cn=true]

[OnName num="shinzi"]
"That video ......, that's ......
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0884"]
[OnName num="amane"]
"The envelope Izumi gave to ...... Shizuku said nothing on it... ...
[cpg cn=true]

[OnName num="shinzi"]
"What?"
[cpg cn=true]

When I heard what Amane had to say, I realized that this scheme was carried out by Kizaki Sisters .
[cpg]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0885"]
[OnName num="amane"]
"The money ...... is gone ......."
[cpg cn=true]

[OnName num="shinzi"]
"Missing?"
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0886"]
[OnName num="amane"]
"There was two million yen in an envelope. ......"
[cpg cn=true]

[OnName num="shinzi"]
"Two million?
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0887"]
[OnName num="amane"]
"When I saw it, there were only ...... about 10 of them. ...... They want it back. ......
[cpg cn=true]

[OnName num="shinzi"]
"You didn't ...... pay for that?
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0888"]
[OnName num="amane"]
"There's a bank near the school ...... Izumi and the teacher came along ....... Ahahahaha ...... I'm already ...... broke ......."
[cpg cn=true]

[OnName num="shinzi"]
"Hi ...... too much ......."
[cpg cn=true]

This is what my carelessness has caused.
[cpg]

It was unintentional that I hadn't thought about what they would do to Amane .
[cpg]

I knew better than anyone that those two were resentful of Amane .
[cpg]

[free time=800]

[BGM f="sir"]

[FG f="amane_p6_02_a.ui" method="change_7" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane0889"]
[OnName num="amane"]
"I ...... am so...yada ....... I want to go ...... to my mother."
[cpg cn=true]

[OnName num="shinzi"]
"No, no, no!　Don't even think about it!
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0890"]
[OnName num="amane"]
"I can't do this anymore. ...... I want to die. ...... Die with me. ...... Shinji ...... Ugh...ugh..."
[cpg cn=true]

He threw out his limbs and started crying Amane .
[cpg]

I'm not sure what to do, but I'm sure I'll be able to do it.
[cpg]

[OnName num="shinzi"]
"'I won't let you say you're going to die,....... I won't let you die!"
[cpg cn=true]




[SE f="se006"]
;//【ＳＥ】吹き込む雨風



The only thing on my side was the rain and wind blowing in through the open window.
[cpg]


[FG f="amane_p7_02_a.ui" method="change_4" pos="2/3" time=800]

The rain and wind pushed me back, and I hugged Amane fiercely.
[cpg]

[OnName num="shinzi"]
"I need Amane !　I need Amane !"
[cpg cn=true]

I bury my face in the cold neck, screaming as hard as I can. The body of Amane is as cold as ice.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0891"]
[OnName num="amane"]
"I want to die with you.
[cpg cn=true]

Amane I'm not sure what to make of this. I'm not sure what to make of that.
[cpg]

[OnName num="shinzi"]
"I'm going to get revenge. I'll definitely ...... them.
[cpg cn=true]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[OnName num="shinzi"]
"...... Amane , I love you."
[cpg cn=true]

If it's for you, I'll do anything... anything. I swear to you.
[cpg]



[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0892"]
[OnName num="amane"]
" Shinji ... loves me, ....... Only Shinji loves me ......."
[cpg cn=true]

As if some kind of switch was flipped, Amane 's emotions explode.
[cpg]


[WAIT time=100]
[VOICE f="Amane0893"]
[OnName num="amane"]
"Aaaaahhhh!"
[cpg cn=true]


[FO pos="2/3" time=800]

[OnName num="shinzi"]
"A lot more than that.
[cpg cn=true]




[SE f="se023"]
;//【ＳＥ】ドンッ！

[WAIT time=800]



[FG f="amane_p9_02_a.ui" method="change_3" pos="2/3" time=800]

Pouncing on me like a beast, Amane claws at my body, ripping teeth into my ears and neck.
[cpg]

[OnName num="shinzi"]
"Oh, Amane ...... ugh!"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0894"]
[OnName num="amane"]
"Ha!　Haaah!"
[cpg cn=true]

Her nails scratched my skin and made it bleed slightly.
[cpg]

I rubbed my own wrist against it Amane and mixed the red with the red.
[cpg]

[FG f="amane_p9_02_a.ui" method="change_6" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane0895"]
[OnName num="amane"]
"Oh...my blood and Shinji 's blood mix ...... together all the time now ......."
[cpg cn=true]

[OnName num="shinzi"]
"You don't have to do that, I'll be with you!"
[cpg cn=true]

[FO pos="2/3" time=800]

Amane I'm not sure if you've heard of this, but I'm sure you've heard of it.
[cpg]




[SE f="se004"]
;//【ＳＥ】雨風




[FG f="amane_p3_02_a.ui" method="change_6" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane0896"]
[OnName num="amane"]
"I'm not sure what to do.　It's raining. It's raining.
[cpg cn=true]

[OnName num="shinzi"]
"It's raining a lot!
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0897"]
[OnName num="amane"]
"More rain!
[cpg cn=true]

[FO pos="2/3" time=800]

Amane In the event that you have any kind of questions regarding where and how to use the internet, you can contact us at our own web site.
[cpg]

[OnName num="shinzi"]
" Amane !　Hey, Amane !"
[cpg cn=true]

I was surprised and hurriedly laid the body on the bed to check the heartbeat.
[cpg]

[OnName num="shinzi"]
"Did ...... you faint?"
[cpg cn=true]

[stopse g=2]
[stopse g=6]

[free time=400]
[BG f="black.ui" time=800]
[WAIT time=800]
[BGM f="eye2"]
[BG f="b_a_mr_t4_4_s.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夜　雨


I was so relieved to find that my soul was beating solidly, that I collapsed into a heap beside Amane .
[cpg]

;#############################################################


;#############################################################


;//////////////////////////////////////////////////////////////////////////


[SE f="se075"]
;//【ＳＥ】カラカラ……


[OnName num="shinzi"]
"Ugh ......."
[cpg cn=true]

The arm of the dismembered doll hit my hand, and I took another look at the devastation in the room.
[cpg]

[OnName num="shinzi"]
Amane "I'm not sure what to make of this.
[cpg cn=true]

It's a great way to get the most out of your day.
[cpg]

[OnName num="shinzi"]
"I'm not going to let you ...... mess with me anymore.
[cpg cn=true]

Amane Amane You will find a lot of people who are looking for the best way to get the most out of their lives.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

;//出会った頃の正常な（？）雨音の絵を数カット挿入


It's a quiet, innocent and gentle girl.
[cpg]

This is my one and only precious lover.
[cpg]

I have to get rid of the existence that transforms Amane like that.
[cpg]

It's the only thing I can do.
[cpg]

[OnName num="shinzi"]
"I'm going to get the soul of Amane back. ......
[cpg cn=true]



[jump storage="ep019.ks" target="*start"]
