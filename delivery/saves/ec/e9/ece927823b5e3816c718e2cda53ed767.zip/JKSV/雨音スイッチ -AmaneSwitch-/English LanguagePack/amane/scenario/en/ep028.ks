*start



;//a,　陽子を選ぶ
*choise_11

;#################################################
*Ep028|Relief.
;#################################################
[SCENE id=32]


[free time=0]

;//[BG f="black.ui" time=900]
;//[WAIT time=900]
;//[BGM f="healing"]
[BGM f="h1"]
[BG f="b_ex_ru_t1_1.ui" time=0]
;//【ＢＧ】廃墟　夜　霧雨

[FG f="youko_p7_01_a.ui" method="change_6" pos="2/3"]


[OnName num="shinzi"]
"'I'm sorry, Yoko . I'm sorry I pushed you so hard."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0303"]
[OnName num="youko"]
"What ......?
[cpg cn=true]

[OnName num="shinzi"]
"I like you, too, .......
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0304"]
[OnName num="youko"]
"Really?　Can I trust you?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, I'm done with Amane . I hope you can forgive me for what I've done.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0305"]
[OnName num="youko"]
"No, ......, of course I forgive you!
[cpg cn=true]

Yoko It's a great way to make sure you get the most out of your time with your family.
[cpg]

[OnName num="shinzi"]
"It's a great way to make sure you get the most out of your time with us. I promise."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0306"]
[OnName num="youko"]
"Yes!　Yes!
[cpg cn=true]




[OnName num="shinzi"]
"What ......?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0307"]
[OnName num="youko"]
"What's ......?
[cpg cn=true]

[OnName num="shinzi"]
"No, I just thought it was cute.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0308"]
[OnName num="youko"]
"What are you talking about?"
[cpg cn=true]

Yoko This is a great way to make sure you get the most out of your time with your family.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0309"]
[OnName num="youko"]
"Today's Shinji ...... weird.
[cpg cn=true]

[OnName num="shinzi"]
"Weird?
[cpg cn=true]

[FG f="youko_p7_01_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0310"]
[OnName num="youko"]
"I like it!
[cpg cn=true]

[OnName num="shinzi"]
"Which is ...... it?"
[cpg cn=true]

I'm not sure if I'm going to be able to do this, but I'm going to try. Yoko I've never seen her do this before.
[cpg]

[FG f="youko_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0311"]
[OnName num="youko"]
"It's raining ......."
[cpg cn=true]

[OnName num="shinzi"]
"Rain ......?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0312"]
[OnName num="youko"]
"It ...... stopped raining.
[cpg cn=true]




[OnName num="shinzi"]
"It's ......
[cpg cn=true]

It was as if the clouds had cleared from our minds, and before we knew it we could see the stars in the sky.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]


[FG f="youko_p7_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0313"]
[OnName num="youko"]
"I'll be with you from now on, okay?　The sun Yoko is."
[cpg cn=true]

[OnName num="shinzi"]
"The sun's Yoko ......?
[cpg cn=true]

I mouthed the nickname as I bit into it.
[cpg]



[free time=400]
[BG f="black.ui" time=900]
[WAIT time=2000]
[BGM f="healing"]
[BG f="b_ex_ru_t1_0.ui" time=2000]
;//【ＢＧ】廃墟　夜　霧雨


[WAIT time=2000]


[FG f="youko_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0314"]
[OnName num="youko"]
" Shinji ......, I'm ......."
[cpg cn=true]

[OnName num="shinzi"]
"Yeah?"
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0315"]
[OnName num="youko"]
"You're ......, Shinji 's girlfriend, right?
[cpg cn=true]

[OnName num="shinzi"]
"What are you talking about? Of course I'm .
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0316"]
[OnName num="youko"]
"Yeah.
[cpg cn=true]

I've made up my mind.
[cpg]

The only girlfriend I have is Yoko .
[cpg]

No matter what happens, no matter what happens, I will never change.
[cpg]

I'll say that to Amane as well.
[cpg]

I felt the warmth of Yoko all over my body and vowed to do so in the clear night sky.
[cpg]

;#############################################################


;#############################################################





;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_ex_sk_t2_1.ui" time=1000]

;//【ＢＧ】雨音のマンション　出入り口　昼　小雨

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

;//【雨、通常】



;//[FG f="youko_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0317"]
[OnName num="youko"]
"It's raining again .......
[cpg cn=true]

[OnName num="shinzi"]
"It's the rainy season, so it can't be helped.
[cpg cn=true]

The next day, Yoko and I arrived in front of Amane 's apartment.
[cpg]

The next day, Yoko and I arrived in front of 's apartment building. I told Amane that I was worried about him, so came along with me.
[cpg]

[OnName num="shinzi"]
"He said, "I'll be fine on my own from here.
[cpg cn=true]

;//[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0318"]
[OnName num="youko"]
"But I want to go with you."
[cpg cn=true]

[OnName num="shinzi"]
"No, no, no. If I do, Amane might get upset, and ...... that would be too much.
[cpg cn=true]

;//[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0319"]
[OnName num="youko"]
"You feel sorry for me?
[cpg cn=true]

[OnName num="shinzi"]
"...... Yeah.
[cpg cn=true]

;//[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0320"]
[OnName num="youko"]
"No!
[cpg cn=true]

I'm too nice, Yoko says.
[cpg]

I'm too nice, ...... he says, and that's why people take advantage of me.
[cpg]

;//[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0321"]
[OnName num="youko"]
"But that's the beauty of Shinji .
[cpg cn=true]

[OnName num="shinzi"]
"Is that what you love?
[cpg cn=true]

;//[FACE method="change_6" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0322"]
[OnName num="youko"]
"Say it!
[cpg cn=true]

[OnName num="shinzi"]
"Hahaha. ....... Okay, wait here. It might take a while.
[cpg cn=true]

;//[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0323"]
[OnName num="youko"]
"I'll be fine. I'll wait.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, ......."
[cpg cn=true]

I leave Yoko in front of the apartment and press the call button for Amane 's room by myself.
[cpg]

Soon after, Amane answers, and as soon as he sees that it's me, he unlocks the door.
[cpg]



[free time=800]
[BG f="black.ui" time=800]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[WAIT time=1000]
[BGM f="eye2"]
[BG f="b_a_mr_t2_0.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　昼　小雨

[WAIT time=1000]

[FG f="amane_p5_01_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1050"]
[OnName num="amane"]
" Shinji !　You're here!"
[cpg cn=true]

He held Amane with his hand and spoke in a quiet tone.
[cpg]

[OnName num="shinzi"]
"I came here today to talk to you.
[cpg cn=true]


[FG f="amane_p6_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1051"]
[OnName num="amane"]
"Yes, what is it?
[cpg cn=true]

Amane This is a great way to get the most out of your time and money.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to do.
[cpg cn=true]


[BGM f="h2"]

[FG f="amane_p5_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1052"]
[OnName num="amane"]
"What ......?"
[cpg cn=true]

[OnName num="shinzi"]
"Think of it as a declaration, not a proposal. I'm breaking up with you.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1053"]
[OnName num="amane"]
"Oh, my God. ...... What are you talking about?　We're doing great, aren't we?
[cpg cn=true]

[OnName num="shinzi"]
"No, we're not. You're the only one who thinks so.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1054"]
[OnName num="amane"]
"No, ....... You're lying. ...... You told me you liked me so much!
[cpg cn=true]

The voice of Amane is getting louder and ...... louder.
[cpg]

This is a great way to make sure that you are getting the most out of your money.
[cpg]

[OnName num="shinzi"]
"I still ...... want to break up with you.
[cpg cn=true]




;//以下どんどん加速して抑揚無く機関銃のように





[FG f="amane_p7_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1055"]
[OnName num="amane"]
"Why, why, why, why?
[cpg cn=true]

[FG f="amane_p8_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1056"]
[OnName num="amane"]
"Because my lunch is not good?　Because I'm dark?　Because I'm a rain woman?
[cpg cn=true]

[FG f="amane_p7_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1057"]
[OnName num="amane"]
"No... the rain falls to make me happy... so I'm not a rain woman. You like rain, don't you Shinji , rain?　What's wrong with the rain?　Why, why, why?
[cpg cn=true]

[OnName num="shinzi"]
"Calm down, Amane ."
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1058"]
[OnName num="amane"]
"Why, why, why?　 Do you hate me now, Shinji ?"
[cpg cn=true]

When he said this, Amane stopped talking.
[cpg]

If you want to say something, now is the time, but what should you say ......?
[cpg]




;//選択肢２（二択）


;//■選択肢
[switch]
[case "I don't like you anymore."]
	[swap]
	[jump target="*choise_51"]
[case "It's not."]
	[swap]
	[jump target="*choise_52"]
[endswitch]

One, I don't like it anymore.
Two, you don't.

*choise_52
[jump storage="ep029.ks" target="*start"]
;///////////////////////////////////////////////////////////////////


;//２-a　嫌いになった
*choise_51|Relief.
[SCENE id=32]

[OnName num="shinzi"]
"'Yes. I don't like Amane anymore."
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_3" pos="2/3"]

It was a word I wanted to avoid if possible.
[cpg]

But I thought this was the only way I could get through to Amane .
[cpg]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1059"]
[OnName num="amane"]
"Lie ...... why ...... why ...... why?
[cpg cn=true]

[OnName num="shinzi"]
"I've found someone else I like."
[cpg cn=true]

I try to be as emotionless as possible when I tell her.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1060"]
[OnName num="amane"]
"Who?"
[cpg cn=true]

[OnName num="shinzi"]
"I can't tell you that.
[cpg cn=true]

[FG f="amane_p7_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1061"]
[OnName num="amane"]
"Why not?
[cpg cn=true]

[OnName num="shinzi"]
"Because I don't have to.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1062"]
[OnName num="amane"]
".....................
[cpg cn=true]

[OnName num="shinzi"]
"Okay, that's all I'm gonna say. Sorry to bother you."
[cpg cn=true]

[FO pos="2/3" time=800]

I left the drooping Amane in my room and headed for the door.
[cpg]

I'm really sorry to hear that, but I couldn't carry all the Amane weight on my shoulders.
[cpg]

Let us quickly return to Yoko .
[cpg]


[WAIT time=100]
[VOICE f="Amane1063"]
[OnName num="amane"]
"I'll ...... do ...... at ......."
[cpg cn=true]

[OnName num="shinzi"]
"What?"
[cpg cn=true]

I heard a small voice muttering something and I couldn't help but turn around.
[cpg]

Then there was ......
[cpg]

;//ペティナイフを自身に向けて正気を失っている雨音

[BGM f="danger"]

[FG f="amane_p3_01_a.ui" method="change_8" pos="2/3" time=800]

[OnName num="shinzi"]
"No, no,.......
[cpg cn=true]

Amane This is a great way to get the most out of your business.
[cpg]

[FACE method="change_6" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1064"]
[OnName num="amane"]
"I'd rather die ...... than lose Shinji ."
[cpg cn=true]

The eyes were completely insane.
[cpg]

But no one dies after declaring that they will die, Yoko said.
[cpg]

That's right ......
[cpg]

If he really wanted to die, he would have done it after I walked away.
[cpg]

[OnName num="shinzi"]
"You don't really want to die, but don't try to get people's attention with that. If it wasn't for me, you'd have a boyfriend in no time if you fixed that personality."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1065"]
[OnName num="amane"]
"I only have Shinji !
[cpg cn=true]

[SE f="se043"]
;//【ＳＥ】サクッ！

[free time=0]
[BG f="red.ui" time=0]
[WAIT time=2000]



[OnName num="shinzi"]
"What ......?"
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

It was a red ...... blood.
[cpg]


;//[FO pos="2/3" time=800]

[free time=800]
;**【ＣＧ】ev_90_0 ***********************
[CG id=22 index=0 time=1000]
;*****************************************



[WAIT time=100]
[VOICE f="Amane1066"]
[OnName num="amane"]
"I only have Shinji one ...... I only have Shinji one ......."
[cpg cn=true]




[SE f="se043"]
;//【ＳＥ】サクッ！サクッ！
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_90_0.ui" time=800]
[WAIT time=800]

[SE f="se043"]
;//【ＳＥ】サクッ！サクッ！
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_90_0.ui" time=800]


;//雨音の顔がどんどん切れていく
[WAIT time=500]

[SE f="se044"]
;//【ＳＥ】ピチャッ！ピチャッ！


Amane It's a great way to make sure you're getting the most out of your time with your family and friends.
[cpg]

In the event that you've got a lot of money, you're going to need to be able to pay for it.
[cpg]


[WAIT time=100]
[VOICE f="Amane1067"]
[OnName num="amane"]
" Shinji ... love ... Shinji ... love ... love ... ..."
[cpg cn=true]

[OnName num="shinzi"]
"No, no, no, no. ......"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane1068"]
[OnName num="amane"]
" Shinji Shinji Shinji Shinji "
[cpg cn=true]

[SE f="se043"]
;//【ＳＥ】サクッ！サクッ！サクッ！

[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_90_0.ui" time=800]
[WAIT time=800]

[SE f="se043"]
;//【ＳＥ】サクッ！サクッ！サクッ！
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_90_0.ui" time=800]
[WAIT time=800]

[SE f="se043"]
;//【ＳＥ】サクッ！サクッ！サクッ！
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_90_0.ui" time=800]


;//雨音の顔がどんどん切れていく
[WAIT time=500]

[SE f="se044"]
;//【ＳＥ】ビシャッ！ビシャッ！ビシャッ！


[OnName num="shinzi"]
"Stop. Amane !　Stop it!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane1069"]
[OnName num="amane"]
"Be happy with Shinji . The rain gave me Shinji . So as long as it rains, Shinji is mine. Rain?　You're happy because it rains, right? See? Here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here, here!
[cpg cn=true]

[free time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

;//[BG f="b_a_mr_t2_0.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　昼　小雨


[SE f="se035"]
;//【ＳＥ】窓が勢い良く開く


[SE f="se004"]
;//【ＳＥ】吹き込んでくる豪雨

;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]

[BG f="b_ex_sk_t1_0.ui" time=1000]
;//【ＢＧ】抽象的な背景（色？　曇り空でもok）


[OnName num="shinzi"]
"!"
[cpg cn=true]

Shivering, weakly open the window Amane .
[cpg]

It's a good idea to have a good idea of what you're doing.
[cpg]

[OnName num="shinzi"]
"I'm not sure how long it's going to take.
[cpg cn=true]

I'm sure it wasn't raining that much when you came here, but it's raining hard outside.
[cpg]

Yoko is ......?
[cpg]

What's wrong with Yoko ?
[cpg]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[free time=800]
;**【ＣＧ】ev_90_a ***********************
[CG id=22 index=1 time=1000]
;*****************************************



[WAIT time=100]
[VOICE f="Amane1070"]
[OnName num="amane"]
"'Aren't you happy?　 Shinji "
[cpg cn=true]

When I looked at Amane in a hurry, I saw that the rain had blown on my bleeding cheeks, turning the whole thing red.
[cpg]

[OnName num="shinzi"]
"'Ugh, wow!
[cpg cn=true]

;//思わず後ずさりする俺に、同じだけ近寄る雨音。
;//[cpg]


[WAIT time=100]
[VOICE f="Amane1071"]
[OnName num="amane"]
"''Why are you running away?　I don't want you to go. Oh, ...... but you don t like me, do you, Shinji is ....... He hates me... and I'd rather die than be hated, right?　Yes, it's better to die, me ......."
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane1072"]
[OnName num="amane"]
"I'm gonna die!　I'm gonna die!
[cpg cn=true]

[SE f="se043"]
;//【ＳＥ】ズバッ！ズバッ！
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_90_a.ui" time=800]
[WAIT time=800]

[SE f="se043"]
;//【ＳＥ】ズバッ！ズバッ！
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_90_a.ui" time=800]
[WAIT time=800]
;//雨音の顔が切れる


[SE f="se044"]
;//【ＳＥ】ビュッ！ビシュッ！
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_90_a.ui" time=800]
[WAIT time=800]

[SE f="se044"]
;//【ＳＥ】ビュッ！ビシュッ！
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_90_a.ui" time=800]
[WAIT time=800]


[OnName num="shinzi"]
"Oh, my God.
[cpg cn=true]

Amane swung the knife at his own face and blood splattered on my face.
[cpg]

[transition target={true} rule="amamori2.png" color={0xff0000ff} time=2000]
[WAIT time=2100]
[BG f="red.ui" time=0]
[transition target={false} color={0xff0000ff} time=500]
[WAIT time=1000]

;//[free time=400]
;//[BG f="red.ui" time=900]
;//[WAIT time=900]

;//[BG f="b_a_mr_t2_0.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　昼　小雨



;//画面、上から赤が流れてやがて全体が真っ赤になる


You can't wipe the blood out of your eyes, and everything in your vision appears to be stained red.
[cpg]

[OnName num="shinzi"]
"''Aaah!　Ughhhh!"
[cpg cn=true]

I want to wash it!
[cpg]

I want to wash my eyes and get away from this abominable red!
[cpg]

With that one thought in mind, I reach out and find a water supply.
[cpg]

But the blurring red is making it harder and harder to see what's ahead.
[cpg]


[WAIT time=100]
[VOICE f="Amane1073"]
[OnName num="amane"]
"'It's raining. Shinji ...... The rain will make you happy, okay?
[cpg cn=true]

[OnName num="shinzi"]
"Ah...ah...ah........."
[cpg cn=true]

Yes, it's ...... rain.
[cpg]

The rain is going to help me. ......
[cpg]

[SE f="se005"]
;//【ＳＥ】豪雨


[OnName num="shinzi"]
"Oh... it's raining ...... ahaha!　It's raining ......."
[cpg cn=true]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

;//徐々に赤が消えて元の色に



[BG f="b_a_mr_t2_0.ui" time=1500]
[FG f="amane_p3_02_a.ui" method="change_6" pos="2/3" time=2000]
[WAIT time=100]
[VOICE f="Amane1074"]
[OnName num="amane"]
"Aren't you happy Shinji ...... rain is happy?"
[cpg cn=true]

[OnName num="shinzi"]
"Ahahahaha ...... rain is happiness ...... hahahahaha."
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1075"]
[OnName num="amane"]
"Ame Ame Fure Fure Mother is ...... happy to welcome you with snake eyes. ......"
[cpg cn=true]

[OnName num="shinzi"]
"♪ Phew phew phew ...... Good song ......
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1076"]
[OnName num="amane"]
"♪ Pitch, pitch, chop, chop ......
[cpg cn=true]

[OnName num="shinzi"]
"♪ Run... run... run ......
[cpg cn=true]

;#############################################################


;#############################################################

;//loop
[stopse g=2]
[stopse g=6]

[SE f="se014"]
;//【ＳＥ】鉄扉開く

[free time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="h2"]
[BG f="b_a_mr_t2_0.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　昼　小雨


[FG f="youko_p5_01_a.ui" method="change_5" pos="4/3" time=0]

[move from="4/3" to="4/5" ease="easeInOutSine" time=800]
[WAIT time=100]
[VOICE f="Youko0324"]
[OnName num="youko"]
" Shinji !　......?
[cpg cn=true]

[OnName num="shinzi"]
" Yoko ......
[cpg cn=true]

;//[FACE method="change_3" pos="2/3"]
[FG f="youko_p7_01_a.ui" method="change_3" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Youko0325"]
[OnName num="youko"]
"It was so late, I was worried. I asked the janitor to open it for me.　What's with all the blood?　Are you hurt?
[cpg cn=true]

[OnName num="shinzi"]
"No, I'm not. ......
[cpg cn=true]

;//[move from="2/3" to="4/5" ease="easeInOutSine" time=800]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane1077"]
[OnName num="amane"]
" Yoko , why are you here?
[cpg cn=true]


[FACE method="change_4" pos="4/5"]


[WAIT time=100]
[VOICE f="Youko0326"]
[OnName num="youko"]
" Amane ....... Oh, you're ...... that wound.
[cpg cn=true]

[FACE method="change_6" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane1078"]
[OnName num="amane"]
"I'm dying. I'm dying because Shinji says horrible things. That's why I'm dying. What?　You're dying?　Yeah, I'm dying. I'm dying, right?　Die ...... die. Die... die. Die... die... die... die... ......"
[cpg cn=true]

[FACE method="change_8" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0327"]
[OnName num="youko"]
"What?
[cpg cn=true]

[SE f="se043"]
;//【ＳＥ】ザシュッ！ザシュッ！
[BG f="red.ui" time=0]
[free time=0]
[WAIT time=1]
[FG f="youko_p7_01_a.ui" method="change_3" pos="4/5" time=800]
[FG f="amane_p5_02_a.ui" method="change_8" pos="2/5" time=800]
[BG f="b_a_mr_t2_0.ui" time=800]
[WAIT time=800]


;//雨音の顔、色んな方向から切れる
[WAIT time=500]


[SE f="se044"]
;//【ＳＥ】ビュッ！ビュッ！
[BG f="red.ui" time=0]
[free time=0]
[WAIT time=1]
[FG f="youko_p7_01_a.ui" method="change_3" pos="4/5" time=800]
[FG f="amane_p5_02_a.ui" method="change_6" pos="2/5" time=800]
[BG f="b_a_mr_t2_0.ui" time=800]
[WAIT time=800]


[OnName num="shinzi"]
"Whoaaaaa!　Whoaaaaa!
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0328"]
[OnName num="youko"]
" Shinji !　You rain bitch!　If you're gonna die, you're gonna die alone!
[cpg cn=true]

[FACE method="change_8" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane1079"]
[OnName num="amane"]
"No, you're not alone.　 Shinji is here. What?　But he's not here anymore?　Yes, I have ....... Shinji . You're always there for me, aren't you?　Is that weird?　Why do you miss me?　 Shinji Come here, come here. I'm lonely."
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_6" pos="2/5" time=1000]

When I saw Amane slowly approaching, mumbling, Yoko dragged me forcibly out of the room.
[cpg]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Youko0329"]
[OnName num="youko"]
"I'm not giving Shinji to you!　 I'm going to protect Shinji you!"
[cpg cn=true]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]

[FG f="amane_p9_02_a_mup.ui" method="change_6" pos="3/5" time=800]
[WAIT time=100]
[VOICE f="Amane1080"]
[OnName num="amane"]
" Shinji ......, see you tomorrow, ......."
[cpg cn=true]

[WAIT time=2000]
[SE f="se014"]
;//【ＳＥ】鉄扉閉まる

[STOPBGM]

[free time=0]
;//[BG f="black.ui" time=0]
;//【ＢＧ】ブラックアウト

[WAIT time=2000]



;//☆新エンディングへ分岐
[if exp={ isSystemFlagsEnabled( "end1", "end2", "end3", "end4", "end5", "end6", "end7") }]
	{ println("True end"); }
[jump storage="ep029.ks" target="*choise_60"]
[else]
	{ println("Normal end"); }
[jump target="*choise_61"]
[endif]

*choise_61


A short time later, I moved into another place from Shuei Academy with Yoko .
[cpg]

I don't know what happened to Amane , but I heard through the grapevine that he was taken away because his unconcealed self-mutilation and escalating eccentricities finally became a big problem.
[cpg]


[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="healing"]
[BG f="b_si_r_t3_0.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　午後　霧雨

[WAIT time=900]

[FG f="youko_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0330"]
[OnName num="youko"]
" Shinji , I bought you a cake. Let's eat together.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, I guess so."
[cpg cn=true]

Now that I'm spending some peaceful time with Yoko , I feel as if those days have vanished as a mere nightmare.
[cpg]

I think that the girl Amane never existed from the beginning.
[cpg]

I'm not sure what to make of it.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0331"]
[OnName num="youko"]
"I prefer Mont Blanc. What about Shinji ?"
[cpg cn=true]

[OnName num="shinzi"]
"I'm .......
[cpg cn=true]

[SE f="se006"]
;//【ＳＥ】窓の外から聞こえる雨の音

[BGM f="eye2"]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0332"]
[OnName num="youko"]
"Oh no, ......, the evening ......?
[cpg cn=true]

At the sound of rain coming from outside, Yoko opens the curtains.
[cpg]

It's a good idea to have a good idea of what you're doing.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0333"]
[OnName num="youko"]
"It's a great way to make sure you're getting the most out of your vacation. Hey, Shinji ?"
[cpg cn=true]

[OnName num="shinzi"]
"............ hahaha."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0334"]
[OnName num="youko"]
" Shinji ?"
[cpg cn=true]

I don't know why I can't control my emotions.
[cpg]

[FACE method="change_3" pos="3/3"]

[WAIT time=100]
[VOICE f="Youko0335"]
[OnName num="youko"]
"What's wrong with you?　What's wrong with ......?
[cpg cn=true]

[OnName num="shinzi"]
"I have to open the ...... window.
[cpg cn=true]

[FACE method="change_7" pos="3/3"]

[WAIT time=100]
[VOICE f="Youko0336"]
[OnName num="youko"]
"What? Why?
[cpg cn=true]

[OnName num="shinzi"]
"You gotta open the ......
[cpg cn=true]

[free time=800]





[SE f="se035"]
;//【ＳＥ】窓開ける

;//loop
[SE f="se007" loop=true]
;//【ＳＥ】吹き込む雨
[WAIT time=800]



[FG f="youko_p5_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Youko0337"]
[OnName num="youko"]
"Hey, Shinji !　Why are you doing that?　You're letting the rain in!
[cpg cn=true]

[OnName num="shinzi"]
"Ha-ha-ha ...... Pitch, pitch, chop, chop... run, run, run... ......
[cpg cn=true]

[FACE method="change_7" pos="3/3"]

[WAIT time=100]
[VOICE f="Youko0338"]
[OnName num="youko"]
"And Shinji ......
[cpg cn=true]

[OnName num="shinzi"]
"♪ pitch pitch...huff huff...chap chap ...... ahahaha ...... run...run run .... Yoko , rain is, you know, happy ...... See, we are happy ......"
[cpg cn=true]

[FACE method="change_4" pos="3/3"]

[WAIT time=100]
[VOICE f="Youko0339"]
[OnName num="youko"]
" Shinji ...i......"
[cpg cn=true]

[free time=800]
Yoko I'm not sure what to make of this.
[cpg]

Shizuku This is a great way to make sure you are getting the most out of your time with us.
[cpg]

It's a great way to get the most out of your day.
[cpg]

The rain is ...... happy .......
[cpg]


[STOPBGM]
[BG f="black.ui" time=2000]
[WAIT time=2000]
[system end6=true]
[SCENE id=35]

;//loop
[stopse g=2]
[stopse g=6]

;//[jump target="*jump_ending"]
[jump storage="epend.ks" target="*start"]
;#############################################################

;#############################################################
;//END『逃げ切った果てに……』
;//エンドロール

;**【ＥＮＤ】　陽子ルート　********************************

;**********************************************************
;//---------------------------------------------------------------------------------------
;//---------------------------------------------------------------------------------------

