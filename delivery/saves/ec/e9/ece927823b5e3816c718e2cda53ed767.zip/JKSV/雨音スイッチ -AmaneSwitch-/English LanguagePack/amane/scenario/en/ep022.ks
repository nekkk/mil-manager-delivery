*start



;#################################################
*Ep022|misspelling
;#################################################
[SCENE id=22]
[stopse g=2]
[stopse g=6]

[free time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
;//[BGM f="rain"]
[BG f="b_a_mr_t1_0.ui" time=3000]
;//【ＢＧ】雨音のマンション　雨音の部屋　午前　曇り

[WAIT time=3000]

;//ゆっくり視界が開けていく





[OnName num="shinzi"]
"No. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0955"]
[OnName num="amane"]
".................."
[cpg cn=true]

[BGM f="rain"]

When I woke up the next morning, Amane was still sleeping peacefully beside me.
[cpg]

It's a good idea to take a look at the website and see if you can find anything you like.
[cpg]

Today is the day of new beginnings for me and Amane .
[cpg]

Amane will heal his heart, and I will support him.
[cpg]

And one day, we will have a happy life where we don't have to be afraid of anyone.
[cpg]

[OnName num="shinzi"]
"I've got to hang in there." ......
[cpg cn=true]

I looked around the empty room and muttered to myself with renewed determination.
[cpg]

It's a good idea to get some furniture and daily necessities first.
[cpg]

I'm not sure if it's a good idea, but I'd rather have Amane live in my house.
[cpg]

Do you like Amane housework?
[cpg]

I think about the future on my own and laugh at myself for getting ahead of myself.
[cpg]

Don't panic.
[cpg]

You will find a lot of people who are looking for the best way to get the most out of their life.
[cpg]




[SE f="se071"]
;//【ＳＥ】ゆっくり開くカーテン

;//[free time=400]
;//[BG f="black.ui" time=900]
;//[WAIT time=900]
;//[BGM f="eye2"]
;//[BG f="b_a_mr_t1_1.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　午前　雨


[BG f="b_ex_sk_t1_0.ui" time=2000]

;//[SE f="se006"]
;//【ＳＥ】雨（わりと静かな感じで）





The sky is gray, and I sigh at the familiar sound of silence in my ears.
[cpg]

[OnName num="shinzi"]
"It's raining again,....... I'm sick of it,......."
[cpg cn=true]

[STOPBGM]

Amane In the event that you have any questions concerning where and how to use the internet, you can call us at our own web site.
[cpg]

;//[FG f="amane_p5_01_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0956"]
[OnName num="amane"]
"You can find a lot of people who are looking for the best way to get the most out of their lives.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah,......."
[cpg cn=true]

[BG f="b_a_mr_t1_1.ui" time=0]

[FG f="amane_p5_01_a.ui" method="change_8" pos="2/3" time=0]

;//[FACE method="change_6" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0957"]
[OnName num="amane"]
"Did you just ...... say ......?
[cpg cn=true]

[OnName num="shinzi"]
"No, no, ......."
[cpg cn=true]

When I saw Amane 's eyes widen, I realized I had misspoken.
[cpg]

But it was too late.
[cpg]

[BGM f="danger"]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0958"]
[OnName num="amane"]
"You Shinji ...... told me you liked the rain. Was that a lie ......?　It was a lie. ...... You said you liked the rain. ...... You said you liked the rain, yeah, yeah, yeah, yeah, yeah!"
[cpg cn=true]

[OnName num="shinzi"]
"!!!
[cpg cn=true]

;//[FG f="amane_p1_01_a.ui" method="change_3" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane0959"]
[OnName num="amane"]
"Aaaaahhhhh!
[cpg cn=true]

[move from="2/3" to="4/3" ease="easeInOutSine" time=1000]
;//[WAIT time=10]
;//[FO pos="4/3" time=800]

[SE f="se039"]
;//【ＳＥ】ダッシュ


[OnName num="shinzi"]
" Amane ? !"
[cpg cn=true]

[FO pos="4/3" time=0]

Caught up in the madness, Amane ran straight out of the room.
[cpg]

I wanted to chase after him immediately, but the clothes I took off yesterday were wet and I couldn't put them on easily.
[cpg]

[OnName num="shinzi"]
"Damn it!"
[cpg cn=true]



[free time=900]
[BG f="black.ui" time=900]
[WAIT time=900]

;//[BG f="b_ex_sk_t2_1.ui" time=1000]
;//【ＢＧ】雨音のマンション　出入り口　昼　雨

[WAIT time=900]
[BGM f="rain"]

I managed to put on my clothes while struggling, and by the time I left the apartment, I couldn't figure out which way Amane had gone.
[cpg]

;//エフェクト

;//loop
[SE f="se004" loop=true]
;//【ＳＥ】激しくなる雨


[SE f="se132"]
;//【ＳＥ】走る足音


;//[FG f="amane_p6_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0960"]
[OnName num="amane"]
"Ha, ha...ha...ha........."
[cpg cn=true]

In the rain, Amane was running, and suddenly stopped to catch his breath.
[cpg]

You will find a lot of things to consider before you decide to buy.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

;//[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0961"]
[OnName num="amane"]
"....................."
[cpg cn=true]




;//下から空を見上げるアングル

;//loop
[stopse g=2]
[stopse g=6]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
;//[BGM f="insecurity"]
[BG f="b_ex_sk_t2_1.ui" time=1000]
;//【ＢＧ】空　午前　雨


;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

;//loop
[SE f="se006" loop=true]
;//【ＳＥ】雨

Looking up at the sky, cold rain falls on the face of Amane .
[cpg]

You will find a lot of things that you can do to make your life easier.
[cpg]

Oh, yes.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

I am the only one who loves this rain.
[cpg]

Only I, and my mother, who loved me, loved the rain.
[cpg]

The ground crumbles and opens up a black hole right next to where you are standing.
[cpg]

The ground continues to crumble, leaving only Amane darkness in its wake.
[cpg]




;//透過して見える雨音の母の幻覚





[OnName num="mother"]
" Amane ......"
[cpg cn=true]

;//[FG f="amane_p1_02_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0962"]
[OnName num="amane"]
"Mother...hmm?"
[cpg cn=true]

Amane A lot of people are not aware of the fact that there are a lot of people who are in the same situation.
[cpg]

;[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0963"]
[OnName num="amane"]
"What's wrong?　Mother ....... Why are you here ......?"
[cpg cn=true]

You will find a lot of things that you can do to make your life easier.
[cpg]

[OnName num="mother"]
"'I've come for you, haven't I?　You."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0964"]
[OnName num="amane"]
"'What ......?
[cpg cn=true]

[OnName num="mother"]
"Because, you know, look at ....... It's raining today.
[cpg cn=true]

She held out her hand and I could see the raindrops being sucked in.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0965"]
[OnName num="amane"]
"I see. ....... Thank you, Mother.
[cpg cn=true]

[OnName num="mother"]
"Come on, let's go.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0966"]
[OnName num="amane"]
"Yes!　Hey, Mom.
[cpg cn=true]

[OnName num="mother"]
"What?　 Amane . You look so happy.
[cpg cn=true]


;//[FG f="amane_p6_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0967"]
[OnName num="amane"]
"I ate the sun, you know?
[cpg cn=true]

[OnName num="mother"]
"Oh, you ate sunshine?
[cpg cn=true]

;//[FG f="amane_p5_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0968"]
[OnName num="amane"]
"It was delicious.
[cpg cn=true]

[OnName num="mother"]
"That's great.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0969"]
[OnName num="amane"]
"It's called Chocolate Sundae .
[cpg cn=true]

[OnName num="mother"]
"Good for you, Amane .
[cpg cn=true]

;//[FG f="amane_p6_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0970"]
[OnName num="amane"]
"Yeah!　Mom.
[cpg cn=true]

[OnName num="mother"]
"But, Amane . Do you like sunshine or rain or ......?"
[cpg cn=true]

;//[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0971"]
[OnName num="amane"]
"Let's see. ...... That's .......
[cpg cn=true]

[OnName num="mother"]
"Rain, rain, rain, rain."
[cpg cn=true]

;//[FG f="amane_p5_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0972"]
[OnName num="amane"]
"...... snake's eye... welcomes you ...... with joy."
[cpg cn=true]

[SE f="se070"]
;//【ＳＥ】踏切


[free time=800]
;**【ＣＧ】ev_82_0 ***********************
[CG id=21 index=0 time=1000]
;*****************************************


[OnName num="shinzi"]
" Amane ?"
[cpg cn=true]

Amane It's a good idea to have a good idea of what you're looking for.
[cpg]

You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]


[WAIT time=100]
[VOICE f="Amane0973"]
[OnName num="amane"]
"The sunshine ...... was delicious...yo ......."
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0974"]
[OnName num="amane"]
"Pichichi...chap...chap ...... run...run...run ......"
[cpg cn=true]

[SE f="se130"]
;//【ＳＥ】特急電車通過


;//画面の最も手前（立ち絵の前）を電車が勢い良く通過する


[free time=800]
;**【ＣＧ】ev_82_a ***********************
[CG id=21 index=1 time=1000]
;*****************************************


[OnName num="shinzi"]
「 Amane ぇええええええーーーーーーーっ！！！！」
[cpg cn=true]

The body of the Amane who went into the crossing as if being sucked in was erased by the express train.
[cpg]

You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

[free time=800]
;**【ＣＧ】ev_82_b ***********************
[CG id=21 index=2 time=1000]
;*****************************************


The circuit breaker opened as if nothing had happened, and people were approaching fearfully, but I couldn't move from my spot.
[cpg]

What I hear is not the shouting of the station staff or the sirens of the emergency vehicles rushing to the scene, but only the ...... sound of rain.
[cpg]

;//[SE f="se004" loop=true]
;//【ＳＥ】激しい雨

[free time=400]

[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト

[WAIT time1000]

I'm not sure what to make of it.
[cpg]

Through the valleys, a small, high-pitched song can be heard: ......
[cpg]

Pitter patter, chirp chirp, run...run...run ......
[cpg]

Oh..., Amane ..., Amane ......
[cpg]

Why have you gone ......?
[cpg]

Did you miss the rainy season so much that it will soon be over?
[cpg]

Did you love your mother more than me?
[cpg]

Amane ..., Amane ......
[cpg]

I'm sure I'll be trapped in the rain just like you. ......
[cpg]

[OnName num="shinzi"]
"Pich... pich... chap... chap ...... run... run... run... ..."
[cpg cn=true]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//loop
[stopse g=2]
[stopse g=6]

;#############################################################


;#############################################################


;//冒頭の事故シーンと同じ物を挿入

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BG f="b_ex_sz_t5_0.ui" time=1000]
;//【ＢＧ】通学路（セピア調）　夕方　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、通常】


[SE f="se130"]
;//【ＳＥ】雨の音と踏切の音に電車の走行音～急ブレーキ

;//【ＳＥ】人々の悲鳴と怒号


"There's a man jumping in!
[cpg cn=true]

"Call an ambulance!
[cpg cn=true]

[SE f="se013"]
;//【ＳＥ】救急車の音が近づいて遠退く



[transition target={true} rule="amamori2.png" color={0xff0000ff} time=2000]
[WAIT time=2100]
[BG f="red.ui" time=500]
[transition target={false} color={0xff0000ff} time=500]
[WAIT time=800]


;//ゆっくりとフェイドアウト


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]



;//END『あめふり』
[STOPBGM]
[BG f="black.ui" time=2000]
[WAIT time=5000]
[system end1=true]
[SCENE id=23]

;//[jump target="*jump_ending"]

;//loop
[stopse g=2]
[stopse g=6]

[jump storage="epend.ks" target="*start"]

;**【ＥＮＤ】　雨音ルート　********************************

;**********************************************************
;//-----------------------------------------------------------------------------------------
;//-----------------------------------------------------------------------------------------

