*start

;//////////////////////////////////////////////////////////////////////////
;#################################################
*Ep017|Select
;#################################################
[SCENE id=17]

;//asd

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_ex_ff_t2_0.ui" time=1000]
;//【ＢＧ】ファストフード店　夜　曇り


[OnName num="shinzi"]
"Welcome to ....... Why?
[cpg cn=true]

That day, I hadn't been to work in a while, and I had a rare visitor.
[cpg]

[FG f="youko_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0240"]
[OnName num="youko"]
"I need to talk to you.
[cpg cn=true]

[OnName num="shinzi"]
"It's almost over, but ......
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0241"]
[OnName num="youko"]
"Yeah.
[cpg cn=true]

It's true that Yoko knew I worked here, but they'd never been here before.
[cpg]

In the event that you have any questions concerning where and how to use the internet, you can contact us at the following web page.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0242"]
[OnName num="youko"]
"Because I'm waiting for you at that abandoned building.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, ......, what?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0243"]
[OnName num="youko"]
"Come back when you're done."
[cpg cn=true]

[FO pos="2/3" time=800]

After saying that, Yoko left the shop.
[cpg]

That abandoned building ......?
[cpg]

As far as I know, the only abandoned building around here is the one that Amane took me to before .......
[cpg]

But why Yoko is ......?
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_ex_ru_t1_1.ui" time=1000]
;//【ＢＧ】廃墟　夜　霧雨


[OnName num="shinzi"]
"Why ......?"
[cpg cn=true]

[FG f="youko_p5_01_a.ui" method="change_1" pos="2/3" time=800]
When I came and saw it, I was sure that Yoko was there.
[cpg]

[OnName num="shinzi"]
"Did you know about this building?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0244"]
[OnName num="youko"]
"Yes, I knew .......
[cpg cn=true]

No, it's good that you knew.
[cpg]

This building has been here for a long time, so it's not surprising that someone knew about it.
[cpg]

The problem is that Yoko said 'that' abandoned building.
[cpg]

Not "that one", not "the one near it", but "that one".
[cpg]

It was a word that could only be used if there was something in common.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0245"]
[OnName num="youko"]
" Shinji , you know, ......."
[cpg cn=true]

But Yoko cuts to the chase before I can ask the question.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0246"]
[OnName num="youko"]
"I want you to be clear."
[cpg cn=true]

[OnName num="shinzi"]
"Clarify what?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[STOPBGM]

[WAIT time=100]
[VOICE f="Youko0247"]
[OnName num="youko"]
"Do you want me or do you want her?"
[cpg cn=true]



[OnName num="shinzi"]
"......!"
[cpg cn=true]

I'm speechless with surprise at the choice I'm suddenly forced to make.
[cpg]

It's not hard to see why Yoko would say that.
[cpg]


[BGM f="h2"]


[OnName num="shinzi"]
"I'm not sure what to say.
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0248"]
[OnName num="youko"]
"I'm not sure what to say.　I'm not sure what to say.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, .......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0249"]
[OnName num="youko"]
"I'm not sure what to say.　Did you just want to be comforted?
[cpg cn=true]

[OnName num="shinzi"]
"That's not true. ......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0250"]
[OnName num="youko"]
"If you stay with her, ...... Shinji , you're gonna ruin it, okay?　Don't you think you've already figured out that she's crazy?　If you don't, Shinji you'll go crazy!　Do you think that's what my aunt would want?
[cpg cn=true]

[OnName num="shinzi"]
"!"
[cpg cn=true]

The words of Yoko pierced my heart.
[cpg]

Mother .......
[cpg]

What would my mother say to me now?
[cpg]

"I'm sure you'll agree that it's a great idea.
[cpg]

Or would she ......
[cpg]

Would she say, "Go help the poor girl?"
[cpg]

[OnName num="shinzi"]
".................."
[cpg cn=true]


[FG f="youko_p7_01_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0251"]
[OnName num="youko"]
" Shinji , look at me. Just look at me. ......
[cpg cn=true]




[OnName num="shinzi"]
"......."
[cpg cn=true]

You say you still love me, Yoko .
[cpg]

The time had come for me to make a decision.
[cpg]

Now ......, what to do ......
[cpg]




;//選択肢１（二択）


;//■選択肢
[switch]
[case "Choose Yoko"]
	[swap]
	[jump target="*choise_11"]
[case "I have feelings for Amane"]
	[swap]
	[jump target="*choise_12"]
[endswitch]



1, choose Yoko
2, I have feelings for Amane


1, choose Yoko
*choise_11
[jump storage="ep028.ks" target="*start"]


;//b，雨音に想いがある	このまま進行
*choise_12|Choice.





[OnName num="shinzi"]
"Don't do this to me, Yoko ......"
[cpg cn=true]

[FG f="youko_p5_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0252"]
[OnName num="youko"]
"Yeah, .......
[cpg cn=true]

[OnName num="shinzi"]
"I'm trying to help Amane . So I can't help you with your feelings."
[cpg cn=true]

I told Yoko honestly how I was feeling.
[cpg]



[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0253"]
[OnName num="youko"]
"What are you talking about?"
[cpg cn=true]

[OnName num="shinzi"]
"I was out of my mind at the time, ....... I'm really sorry."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0254"]
[OnName num="youko"]
"I'm sorry. ...... Fuck you! I was so happy to see you, but ...... this is too much!
[cpg cn=true]

[OnName num="shinzi"]
"I'm sorry!
[cpg cn=true]




[SE f="se029"]
;//【ＳＥ】ザッ！




[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0255"]
[OnName num="youko"]
"What?
[cpg cn=true]

I didn't know what to say to Yoko , so I just got down on my knees and rubbed my forehead on the ground.
[cpg]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0256"]
[OnName num="youko"]
"I'm not sure what to say.　I don't know you anymore!"
[cpg cn=true]


[FO pos="2/3" time=800]


[SE f="se029"]
;//【ＳＥ】走り去る





[OnName num="shinzi"]
"''..................''
[cpg cn=true]

I'd be lying if I said I didn't have feelings for Yoko , but I couldn't stop thinking about Amane .
[cpg]

If my mom was still alive, she would have told me.
[cpg]

If she was alive, she would have said, "Please help her." ......
[cpg]

If I don't help, Amane will probably be swallowed up by the madness.
[cpg]

I knew I would regret it if I didn't help him before that happened.
[cpg]



[free time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト
[WAIT time=1000]



The next day ......
[cpg]


[stopse g=2]
[stopse g=6]

;//土砂降り
;//loop
[SE f="se004" loop=true]
;//【ＳＥ】土砂降り



[free time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_sy_t1_2.ui" time=1000]
;//【ＢＧ】学園　校庭　大雨

[WAIT time=1000]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]

;//loop
[SE f="se006" loop=true]
;//雨の音
;//【雨、大雨】



[FG f="amane_p5_02_a.ui" method="change_4" pos="2/5" time=800]
[FG f="youko_p5_02_a.ui" method="change_3" pos="4/5" time=800]

[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】ビンタ

[BG f="white.ui" time=0]

[free time=0]
[WAIT time=1]
[BG f="b_s_sy_t1_2.ui" time=500]
[FG f="amane_p5_02_a.ui" method="change_4" pos="2/5" time=500]
[FG f="youko_p5_02_a.ui" method="change_3" pos="4/5" time=800]

[move from="4/5" to="2/3" ease="easeInOutSine" time=100]
[move from="2/5" to="1/3" ease="easeInOutSine" time=100]
[WAIT time=110]
[move from="2/3" to="4/5" ease="easeInOutSine" time=100]
[WAIT time=1000]
[move from="1/3" to="2/5" ease="easeInOutSine" time=1000]
[WAIT time=1000]

[WAIT time=100]
[VOICE f="Amane0790"]
[OnName num="amane"]
".................."
[cpg cn=true]

When Amane was called by Yoko , he suddenly received a painful slap on the cheek.
[cpg]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0257"]
[OnName num="youko"]
"What do you think you're doing?
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0791"]
[OnName num="amane"]
"What are you talking about?
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0258"]
[OnName num="youko"]
"Don't you understand what I'm trying to say?　Don't you know you're crazy?
[cpg cn=true]

[FACE method="change_8" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0792"]
[OnName num="amane"]
"I'm not crazy.
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0259"]
[OnName num="youko"]
"Ugh!
[cpg cn=true]

I'm not crazy." Yoko 's anger grew at Amane 's attitude.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0260"]
[OnName num="youko"]
"I warned her, but she persists in following Shinji , and she thinks she's allowed to do that at her mother's funeral?
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0793"]
[OnName num="amane"]
"Why?　Why do you need Yoko to forgive you?
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0261"]
[OnName num="youko"]
"What?
[cpg cn=true]

In contrast to Yoko , whose face is red with anger, Amane has not changed his expression at all.
[cpg]

[FACE method="change_8" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0794"]
[OnName num="amane"]
"It's none of Yoko 's business, is it?
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0262"]
[OnName num="youko"]
"What the hell?
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】ビンタ

[BG f="white.ui" time=0]

[free time=0]
[WAIT time=1]
[BG f="b_s_sy_t1_2.ui" time=500]
[FG f="amane_p5_02_a.ui" method="change_4" pos="2/5" time=500]
[FG f="youko_p5_02_a.ui" method="change_5" pos="4/5" time=500]

[move from="2/5" to="1/3" ease="easeInOutSine" time=100]
[WAIT time=110]
[move from="1/3" to="2/5" ease="easeInOutSine" time=100]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0795"]
[OnName num="amane"]
"I'm not afraid of ............ violence, okay?　I am. Mmm-hmm.
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0263"]
[OnName num="youko"]
"What?
[cpg cn=true]

[FACE method="change_6" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0796"]
[OnName num="amane"]
"Because Shinji loves me. You can find a lot of things to say, but at the end of the day, he cares about me the most, you know?　I love that part of you that is boyish.
[cpg cn=true]

In addition to ridiculing himself, Amane is not even aware of it, and Yoko is blatantly upset by his words.
[cpg]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0264"]
[OnName num="youko"]
"I'm sure you'll agree.
[cpg cn=true]


In addition, the answer that Shinji gave after he tried his best to persuade him was "I want to help Amane ".
[cpg]

It's as if you're the only one spinning your wheels and getting in the middle of the couple.
[cpg]

I feel as if I've become Shinji 's affair partner, and my unnecessarily high pride is cracked.
[cpg]



[WAIT time=100]
[VOICE f="Youko0265"]
[OnName num="youko"]
"You're the daughter of a broken home!　I'm not sure what to do.
[cpg cn=true]

[move from="4/5" to="3/5" ease="easeInOutSine" time=100]

Gah!
[cpg]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0797"]
[OnName num="amane"]
"I'm not sure what to say.
[cpg cn=true]

This is a great way to make sure that you are getting the most out of your time with your family and friends. Yoko 's hands grabbed Amane 's long hair and pulled with force, causing a moan to escape Amane 's throat.
[cpg]

[SE f="se009"]
;//【ＳＥ】チャイム

[FACE method="change_8" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0798"]
[OnName num="amane"]
"Oh, ...... class has started. Shinji will be worried, so why don t we just leave it at that?"
[cpg cn=true]

With her hair still in her grasp, Amane looked into Yoko 's face.
[cpg]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0266"]
[OnName num="youko"]
"I'm not sure what to say.
[cpg cn=true]

This is a great way to get the most out of your business.
[cpg]

This is a great way to get the most out of your business.
[cpg]

[BGM f="danger"]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0267"]
[OnName num="youko"]
"I'm not sure what to do.　I'll never forgive you again!
[cpg cn=true]

[SE f="se024"]
;//【ＳＥ】ズシャァア！


[free time=800]

;**【ＣＧ】ev_52_0 ***********************
[CG id=15 index=0 time=1000]
;*****************************************


[WAIT time=100]
[VOICE f="Amane0799"]
[OnName num="amane"]
"''Aa......''
[cpg cn=true]

Yoko pulls Amane down with all her might, grabs her by the hair and drags her around.
[cpg]


[WAIT time=100]
[VOICE f="Amane0800"]
[OnName num="amane"]
"Bullying me isn't going to make Shinji like Yoko ...?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0268"]
[OnName num="youko"]
"Ooooooh!"
[cpg cn=true]

No matter what you say, it won't get through to this guy.
[cpg]

Yoko I'm not sure what to say.
[cpg]

This is because, yes, this woman is crazy.
[cpg]


[WAIT time=100]
[VOICE f="Youko0269"]
[OnName num="youko"]
"This is a great way to get the most out of your day.
[cpg cn=true]

Whether it's a dog or anything else, if you can't communicate with it, you have to beat it.
[cpg]

I'm not sure if it's wrong or not, but it doesn't matter.
[cpg]

[SE f="se024"]
;//【ＳＥ】ズシャァア！　ズシャァア！


;//[free time=800]
[BG f="black.ui" time=0]

;**【ＣＧ】ev_52_a ***********************
[CG id=15 index=1 time=500]
;*****************************************


[WAIT time=100]
[VOICE f="Amane0801"]
[OnName num="amane"]
"I'm not sure what to do.　I'm not sure what to do.
[cpg cn=true]

Amane In the event that you have any kind of questions regarding where and how to use the internet, you can contact us at our own web site.
[cpg]


[WAIT time=100]
[VOICE f="Amane0802"]
[OnName num="amane"]
"I'm not afraid of you anymore. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0270"]
[OnName num="youko"]
"What?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0803"]
[OnName num="amane"]
"I'm not afraid of the sun Yoko . I ...... ate the sun. Shinji and I ate the sun together, you know?　It was delicious. ...... hmm hmm hmm hmm..."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0271"]
[OnName num="youko"]
"Don't say something you don't understand!"
[cpg cn=true]

[SE f="se024"]
;//【ＳＥ】ズシャァア！　ズシャァア！

[BG f="black.ui" time=0]
[WAIT time=1]
[BG f="ev_52_a.ui" time=500]
[WAIT time=1000]

Even when his face is soaked in a puddle of coffee-colored water and scraped against the coarse, wet ground, Amane chuckles all the time.
[cpg]


[WAIT time=100]
[VOICE f="Youko0272"]
[OnName num="youko"]
"'You're disgusting!　Teme is aaaaah!"
[cpg cn=true]

Shaking off the empty horror with an angry voice, Yoko dragged Amane out into the schoolyard.
[cpg]


[WAIT time=100]
[VOICE f="Youko0273"]
[OnName num="youko"]
"I'm not sure what to say.　Get away from me and Shinji !"
[cpg cn=true]

[SE f="se040"]
;//【ＳＥ】ドカッ！ドカッ！
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_52_a.ui" time=500]
[WAIT time=1000]
[SE f="se040"]
;//【ＳＥ】ドカッ！ドカッ！
[BG f="red.ui" time=0]
[WAIT time=1]

;//[free time=800]

;**【ＣＧ】ev_52_b ***********************
[CG id=15 index=2 time=500]
;*****************************************
[WAIT time=1000]

[WAIT time=100]
[VOICE f="Amane0804"]
[OnName num="amane"]
"Eugh!　I'm not sure what to say.
[cpg cn=true]

Amane In the event that you have any questions regarding where and the best way to get in touch with us, you can contact us at Yoko .
[cpg]


[WAIT time=100]
[VOICE f="Youko0274"]
[OnName num="youko"]
"I'm sure you'll agree.　You don't like it!　 If you leave Shinji , you can have a peaceful life!　Do you understand?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0805"]
[OnName num="amane"]
" Yoko and ....... Come on, .......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0275"]
[OnName num="youko"]
"What?
[cpg cn=true]

Amane This is a great way to make sure that you get the most out of your vacation.
[cpg]

The long, wet hair makes the pale face of Amane look like a ghost, and it sends chills down the spine of Yoko .
[cpg]


[WAIT time=100]
[VOICE f="Amane0806"]
[OnName num="amane"]
"I really ...... like hurting ...... people from the old days...you know..."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0276"]
[OnName num="youko"]
"I don't really like that!　It's only for you!
[cpg cn=true]

The volume of Amane 's voice is not even half that of Yoko .
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//loop
[stopse g=2]
[stopse g=6]

[free time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_3f_t1_2.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午前　大雨
[WAIT time=1000]

[OnName num="shinzi"]
" Amane ......, where did you go ......?"
[cpg cn=true]

There is no Amane figure in the classroom, which should have been there until the previous class.
[cpg]

I'm not sure what to make of it.
[cpg]

In the event that you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

[OnName num="shinzi"]
"Oh, that's ......!
[cpg cn=true]

Amane and ...... Where is the other one?
[cpg]

[OnName num="shinzi"]
" Yoko !"
[cpg cn=true]

I'm sure that is going to be the same as .
[cpg]

I ran out of the classroom, thinking that Yoko was making some sort of accusation against Amane .
[cpg]

[SE f="se010"]
;//【ＳＥ】ダッシュ


[OnName num="male_student"]
"Oh, Mizushima!　The teacher is coming!
[cpg cn=true]

[OnName num="female_student"]
"Where did he go?
[cpg cn=true]

[OnName num="male_student"]
"I don't know. I think he was looking outside. ......
[cpg cn=true]

[OnName num="female_student"]
"Outside?
[cpg cn=true]

;//視点変更

;//loop
[stopse g=2]
[stopse g=6]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_s_sy_t1_2.ui" time=1000]
;//【ＢＧ】学園　校庭　大雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]
;//loop
[SE f="se006" loop=true]
;//雨の音
;//【雨、大雨】


[FG f="amane_p5_02_a.ui" method="change_6" pos="2/5" time=800]
[FG f="youko_p5_02_a.ui" method="change_4" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Amane0807"]
[OnName num="amane"]
"Oh, I see. ...... Yoko wants to see me get hurt... oh, my God, why didn't you just tell me? ...Kusukusuku..."
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0277"]
[OnName num="youko"]
"What? ......!　What are you laughing at?　Stop laughing!
[cpg cn=true]

But as Yoko understood, Amane would never hear Yoko 's words.
[cpg]

[STOPBGM]

[FACE method="change_8" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0808"]
[OnName num="amane"]
"Let me show you something, okay?　 Let me show you what Yoko wants to see."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0278"]
[OnName num="youko"]
"?
[cpg cn=true]


[free time=800]


[SE f="se045"]
;//【ＳＥ】カッター（カチカチカチカチ……）

;**【ＣＧ】ev_53_0 ***********************
[CG id=16 index=0 time=1000]
;*****************************************

In a slow motion, Amane took out a thing from the pocket of the skirt.
[cpg]

This is a great way to make sure you are getting the most out of your money.
[cpg]

This is a great way to make sure that you do not have to worry about your own health and wellness.
[cpg]

[BGM f="danger"]


[WAIT time=100]
[VOICE f="Youko0279"]
[OnName num="youko"]
"I'm not sure what to make of it.
[cpg cn=true]

It's a great way to make sure you're getting the most out of your money.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

I'm sure you'll be pleased to know that I'm not the only one who's had it. Yoko felt my legs begin to shake.
[cpg]


;**【ＣＧ】ev_53_a ***********************
[CG id=16 index=1 time=1000]
;*****************************************


[WAIT time=100]
[VOICE f="Amane0809"]
[OnName num="amane"]
"'I'll show you, but don't take Shinji it away from me!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0280"]
[OnName num="youko"]
"'Yes .............'
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0810"]
[OnName num="amane"]
"'Now...I'll show you...aaahhhh!'
[cpg cn=true]



With a scream, the blade of the cutter slides ...... down Amane 's left wrist.
[cpg]

;//loop
[stopse g=2]
[stopse g=6]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[SE f="se043"]
;//【ＳＥ】スパーーーッ！！
[BG f="white.ui" time=0]
[WAIT time=1000]

[SE f="se044"]
;//【ＳＥ】プシューーッ！！

[transition target={true} rule="amamori2.png" color={0xff0000ff} time=2000]
[WAIT time=2100]
[BG f="red.ui" time=500]
[transition target={false} color={0xff0000ff} time=500]
[WAIT time=800]


;**【ＣＧ】ev_53_b ***********************
[CG id=16 index=2 time=1000]
;*****************************************

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]
;//loop
[SE f="se006" loop=true]
;//雨の音
;//【雨、大雨】

[WAIT time=1000]

[WAIT time=100]
[VOICE f="Youko0281"]
[OnName num="youko"]
"Aaaaahhhh!"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0811"]
[OnName num="amane"]
"Ahahahahahahaha!"
[cpg cn=true]

In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

Yoko In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]


[WAIT time=100]
[VOICE f="Youko0282"]
[OnName num="youko"]
"I'm not sure what to say.　Aaaaaaah!"
[cpg cn=true]

All of his vision was dyed crimson as the blood entered his eyes, and Yoko he was screaming like a madman.
[cpg]


[WAIT time=100]
[VOICE f="Amane0812"]
[OnName num="amane"]
"'Satisfied?　Satisfied with this!　Ahahahahaha!"
[cpg cn=true]

With a high-pitched laugh, Amane raised the box cutter again.
[cpg]

"You're going to kill me!" That's what Yoko 's instincts told him.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]



[WAIT time=100]
[VOICE f="Youko0283"]
[OnName num="youko"]
"No, no, no, no!
[cpg cn=true]

[SE f="se040"]
;//【ＳＥ】ドカッ！！

[BG f="white.ui" time=0]
[WAIT time=500]


;**【ＣＧ】ev_71_0 ***********************
[CG id=19 index=0 time=500]
;*****************************************


Fear took over Yoko 's body and she jumped on Amane and took the weapon from him.
[cpg]


[WAIT time=100]
[VOICE f="Youko0284"]
[OnName num="youko"]
"It's a great way to make sure you don't end up in a situation where you can't get out of it.
[cpg cn=true]

Yoko Amane In the event that you've got a lot of money, you'll be able to take advantage of the fact that you'll be able to get a lot more.
[cpg]



[WAIT time=100]
[VOICE f="Youko0285"]
[OnName num="youko"]
"I'm not sure what to do.
[cpg cn=true]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[STOPBGM]

[SE f="se040"]
;//【ＳＥ】ドカッ！！

[BG f="white.ui" time=0]
[WAIT time=1000]


;//画面９０度回転


[SE f="se024"]
;//【ＳＥ】バシャーーン！！

[BG f="b_ex_sk_t2_1.ui" time=1000]
;//[BG f="b_s_sy_t1_2.ui" time=1000]
;//【ＢＧ】学園　校庭　大雨

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]

[WAIT time=1500]

;//loop
[SE f="se006" loop=true]
;//雨の音
;//【雨、大雨】



;//[FG f="youko_p7_02_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0286"]
[OnName num="youko"]
"What?
[cpg cn=true]

At the moment, ...... Yoko 's body received some kind of strong shock and was pushed down to the ground.
[cpg]

[BGM f="h2"]

[OnName num="police_officer1"]
"Police!
[cpg cn=true]

[OnName num="police_officer2"]
"Let go of the murder weapon!
[cpg cn=true]

[OnName num="police_officer3"]
"Suspect in custody!
[cpg cn=true]

[OnName num="police_officer4"]
"You're under arrest for attempted murder!
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0287"]
[OnName num="youko"]
"No, no!　I didn't do it!
[cpg cn=true]

[SE f="se024"]
;//【ＳＥ】バチャバチャ！！


[OnName num="police_officer1"]
"Don't go crazy!　Stay down!
[cpg cn=true]

Yoko In the event that you have any questions concerning where and the best way to get in touch with your loved ones, you can call us at the web site.
[cpg]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0288"]
[OnName num="youko"]
"I'm sorry.　I'm not sure what to say, but I'm sure you'll understand.
[cpg cn=true]

[OnName num="shinzi"]
" Amane !"
[cpg cn=true]

Yoko Amane Shinji In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

[OnName num="teacher"]
"Minegishi ...... you, what a thing ......."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0289"]
[OnName num="youko"]
"It's not the same!　No, no, no, no, no!
[cpg cn=true]


;//[FO pos="2/3" time=800]

[OnName num="police_officer2"]
"Get up!
[cpg cn=true]


;//画面元の角度に

[BG f="b_s_sy_t1_2.ui" time=1000]
;//【ＢＧ】学園　校庭　大雨

[FG f="amane_p7_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0813"]
[OnName num="amane"]
" Shinji You... ......
[cpg cn=true]

[OnName num="shinzi"]
" Amane , are you okay?
[cpg cn=true]

Amane In the event that you have any questions concerning where and how to use the internet, you can contact us at the web site.
[cpg]

[OnName num="shinzi"]
"'Was this ...... Yoko done by you!
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

;/[FG f="amane_p8_02_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0814"]
[OnName num="amane"]
"I'm fine, ...... me."
[cpg cn=true]

[OnName num="shinzi"]
"Did Yoko you do this?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0815"]
[OnName num="amane"]
"Uh-huh. ......"
[cpg cn=true]

[FO pos="2/3" time=800]

Amane passed out in my arms.
[cpg]

[OnName num="shinzi"]
"Ambulance!　Hurry!
[cpg cn=true]

[FG f="youko_p1_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0290"]
[OnName num="youko"]
" Shinji !　No!　I didn't do anything!　It wasn't me!　Trust me!
[cpg cn=true]

[OnName num="police_officer1"]
"I'll talk to you at the station!　You need to come with us!
[cpg cn=true]

[OnName num="teacher"]
"Yes, ....... Minegishi, ....... Your parents will be here later. ......
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0291"]
[OnName num="youko"]
"No!　It's not me!　It's not me!
[cpg cn=true]

[SE f="se013"]
;//【ＳＥ】パトカー＆救急車のサイレン

[FO pos="2/3" time=800]

Thus, Yoko was taken to the police and Amane was taken to the hospital .......
[cpg]

This is a great way to make sure that you are getting the most out of your time and money.
[cpg]

Therefore, it was naturally accepted that the assailant was the one holding the knife Yoko and the injured Amane was the victim, as if it were a fact.
[cpg]

Except for one person, Yoko , who was the party .......
[cpg]

The police were apparently called by a student who spotted the two in the schoolyard.
[cpg]

They saw that Amane , who had been repeatedly behaving strangely, was with someone and thought he was in danger at the moment .......
[cpg]

As a result, it was Yoko that was caught, but it can be said that the decision was successful.
[cpg]

If it had gone on like that, it would have been a much more tragic end. ......
[cpg]

;#############################################################


;#############################################################

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//エフェクト

[stopse g=2]
[stopse g=6]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=900]
[BG f="b_h_ro_t2_0.ui" time=1000]
;//【ＢＧ】病院　個室　夜　小雨
[WAIT time=1000]
[BGM f="insecurity"]

;//左手を包帯でグルグル巻きにされてベッドに横たわる雨音


[OnName num="shinzi"]
" Amane ......"
[cpg cn=true]

After receiving a blood transfusion and having to be hospitalized, Amane is lying on a bed in a private room.
[cpg]

The left wrist is wrapped around with a bandage, and the face is painfully bloodless.
[cpg]

It is my fault that things turned out this way.
[cpg]

If I had been able to explain to Yoko from the beginning, I might not have put Amane ...... him in this situation.
[cpg]

The fear of Amane that had begun to grow inside me had long since disappeared.
[cpg]

For now, I just hope that her wounds heal.
[cpg]


[WAIT time=100]
[VOICE f="Amane0816"]
[OnName num="amane"]
" Shinji ......"
[cpg cn=true]

My right hand twitches in my hand, and Amane my eyes slowly open.
[cpg]

[FG f="amane_p7_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0817"]
[OnName num="amane"]
"You've been ...... with me all this time, haven't you?
[cpg cn=true]

[OnName num="shinzi"]
"Oh, yes, ....... I'm sorry ...... Amane ."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0818"]
[OnName num="amane"]
"That's weird Shinji ....... Why do you apologize ......?"
[cpg cn=true]

He muttered in a muffled voice and gave me a fleeting Amane smile.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0819"]
[OnName num="amane"]
"I couldn't ...... die again, could I?
[cpg cn=true]

[OnName num="shinzi"]
"I'm not sure what to say, but don't say it like that. For God's sake, ......."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0820"]
[OnName num="amane"]
"I'd rather ...... die than be a nuisance to everyone... and be hated and avoided by ...... and Shinji . ......"
[cpg cn=true]

[OnName num="shinzi"]
"I would never avoid Amane ."
[cpg cn=true]

He pulls Amane 's hand to his cheek, which is cold despite his firm grip, and says firmly.
[cpg]

[OnName num="shinzi"]
"I was wrong. I'm not afraid of or avoiding Amane anymore. Never."
[cpg cn=true]

[FACE method="change_8" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0821"]
[OnName num="amane"]
".................."
[cpg cn=true]

[SE f="se012"]
;//【ＳＥ】ドア、スライド


[OnName num="nurse"]
"Excuse me. Did you notice that?
[cpg cn=true]

[OnName num="shinzi"]
"Oh, yes.
[cpg cn=true]

At that moment, a nurse came into the hospital room and confronted me with the grim reality of the situation.
[cpg]

[OnName num="nurse"]
"Can you get in touch with the guardian?　We'll call you at .......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0822"]
[OnName num="amane"]
"Oh, ......."
[cpg cn=true]

[OnName num="shinzi"]
"Oh!　I'll let them know. ....... ...... right away."
[cpg cn=true]

Amane In the event that you're looking for the best way to get the most out of your business, you'll want to take a look at the website.
[cpg]

[OnName num="nurse"]
"I'm sure you'll agree.　I'm sure you'll be pleased with the results.
[cpg cn=true]

[free time=800]
;**【ＣＧ】ev_100_0 **********************
[CG id=26 index=0 time=1000]
;*****************************************



[SE f="se012"]
;//【ＳＥ】ドア、スライド



[SE f="se020"]
;//【ＳＥ】歩き去る



[WAIT time=100]
[VOICE f="Amane0823"]
[OnName num="amane"]
"I'm sorry ......."
[cpg cn=true]

When the nurse had gone, Amane cast her eyes down sadly.
[cpg]

[OnName num="shinzi"]
"'Um, ....... But what do we do?　Do you want me to call your father?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0824"]
[OnName num="amane"]
"Yeah ......, you know ......?"
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, ....... Maybe .......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0825"]
[OnName num="amane"]
"Yeah, ......."
[cpg cn=true]

In that brief conversation, Amane probably realized that I understood the reality of my father's presence in Kizaki Sisters 's home.
[cpg]

You can find a lot more information on the web.
[cpg]


[WAIT time=100]
[VOICE f="Amane0826"]
[OnName num="amane"]
"My mom loved the rain,......, but my dad hated the rain,....... That's why he hated her and me more and more. ......
[cpg cn=true]

[OnName num="shinzi"]
".................."
[cpg cn=true]

I used to think that there was no such thing as a parent who hated their child.
[cpg]

However, Amane has a heartbreaking parent-child relationship that I never knew existed.
[cpg]


[WAIT time=100]
[VOICE f="Amane0827"]
[OnName num="amane"]
"After your father left, your mother has been consoling me and telling me how hard I've been working ...... and that rain is a wonderful thing and that you are a wonderful child ...... with a name like rain.
[cpg cn=true]

[OnName num="shinzi"]
" Amane , if you talk too much, it will hurt your ...... feelings."
[cpg cn=true]

Even when I interrupted, Amane continued to talk.
[cpg]

It's like pushing the mist out of yourself.
[cpg]

[free time=800]
;**【ＣＧ】ev_100_a **********************
[CG id=26 index=1 time=1000]
;*****************************************



[WAIT time=100]
[VOICE f="Amane0828"]
[OnName num="amane"]
"It's a great way to make sure you're getting the most out of your money. When it rained, she always came to pick me up with an umbrella, and I wished it would rain every day."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0829"]
[OnName num="amane"]
"But it seems that mom couldn't stand the fact that dad wasn't around anymore. ...... That day ......, mom came to pick me up from school, let go of our hands and umbrella, and left me alone on the train. ...... and headed for the train alone. ......"
[cpg cn=true]

[OnName num="shinzi"]
"!"
[cpg cn=true]

I don't know what to say.
[cpg]

On that day, Amane watched his mother commit suicide by his side.
[cpg]

You can't even imagine what it looked like in the eyes of a small child.
[cpg]


[WAIT time=100]
[VOICE f="Amane0830"]
[OnName num="amane"]
You can't imagine what it must have looked like in the eyes of a small child. "At my mom's funeral, I saw my dad for the first time in a long time. He was crying ....... There are many parts of the body that are missing, and he clutched the coffin with the lid still closed and cried .......
[cpg cn=true]

The Amane father I know was a devil who didn't have much of a human heart.
[cpg]

You will find a lot of people who are looking for the best way to get the most out of their lives.
[cpg]


[WAIT time=100]
[VOICE f="Amane0831"]
[OnName num="amane"]
And then he cried and said to me,......, "I'll make amends."
[cpg cn=true]

[OnName num="shinzi"]
"Amends ......?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0832"]
[OnName num="amane"]
"Money. ......
[cpg cn=true]

[OnName num="shinzi"]
"Oh, ......."
[cpg cn=true]

How much help did money give to Amane at that time?
[cpg]

I'm not sure what to make of this.
[cpg]

[OnName num="shinzi"]
"If your father was willing to make amends, why did Amane he go to an institution ......?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0833"]
[OnName num="amane"]
"Because ......, I'm not going to change the way he hates me. ......
[cpg cn=true]

[OnName num="shinzi"]
"No. ......
[cpg cn=true]

That's too much .......
[cpg]

You can't make amends by putting your own young daughter in an institution.
[cpg]


[WAIT time=100]
[VOICE f="Amane0834"]
[OnName num="amane"]
"But my dad paid a lot of money, and everyone at the shelter was nice to me. ......
[cpg cn=true]

[OnName num="shinzi"]
"Did he ever call you or write you?　Dad ......"
[cpg cn=true]

When I asked him, Amane laughed and shook his head.
[cpg]

[free time=800]
;**【ＣＧ】ev_100_b **********************
[CG id=26 index=2 time=1000]
;*****************************************



[WAIT time=100]
[VOICE f="Amane0835"]
[OnName num="amane"]
"You can't help it,....... I'm just grateful that he gave me money even though he hates me. Even if you don't like me, your father never bullied me. ......"
[cpg cn=true]

[OnName num="shinzi"]
"Dad... what?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0836"]
[OnName num="amane"]
"Your classmates at school will bully you if they don't like you. ......
[cpg cn=true]

[OnName num="shinzi"]
"You've been bullied. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0837"]
[OnName num="amane"]
" Yoko says ...... I'm a rainy day girl. Because I was so popular back then, Yoko everyone took my side and hated me for it. ......
[cpg cn=true]

[OnName num="shinzi"]
"Oh, ......."
[cpg cn=true]

Abandoned by her father, killed by her mother, and with no friends, Amane has been alone all this time.
[cpg]

So what ......?
[cpg]

I'm not sure what to say, but I'm going to say it.
[cpg]

Like a young child, the Amane unconscious wants to cling ...... to me.
[cpg]

[OnName num="shinzi"]
"It was hard,.......
[cpg cn=true]

Before I knew it, tears were pouring out of my eyes.
[cpg]

I wanted to hug my mother Amane if I could, when she was a little girl and she died in front of me, the only one who loved her and who loved me.
[cpg]


[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_h_ro_t2_0.ui" time=1000]
;//【ＢＧ】病院　個室　夜　小雨
[WAIT time=1000]

[FG f="amane_p7_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0838"]
[OnName num="amane"]
"Are you crying for me?　My mother killed Shinji your father. ......
[cpg cn=true]

[OnName num="shinzi"]
"No, ......."
[cpg cn=true]

It was an unfortunate coincidence.
[cpg]

If God is the one who set up that coincidence, I want to punch him.
[cpg]

[OnName num="shinzi"]
"It's not the fault of Amane 's mother or Amane . It's none of our business.
[cpg cn=true]

[FG f="yukika_p5_01_a.ui" method="change_3" pos="5/3" time=0]

[BGM f="eye2"]

[WAIT time=100]
[VOICE f="Yukika0107"]
[OnName num="yukika"]
"It's none of your business ......."
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

Before you know it, the door is open and Yukika your sister is standing there.
[cpg]

I'm sure that the school has contacted you.
[cpg]


[move from="5/3" to="4/5" ease="easeInOutSine" time=3000]

[FACE method="change_7" pos="4/5"]


[WAIT time=100]
[VOICE f="Yukika0108"]
[OnName num="yukika"]
"How Amane are you feeling, ......?"
[cpg cn=true]

Amane This is a great way to get the most out of your time with your family.
[cpg]

Amane This is a great way to make sure you are getting the most out of your investment.
[cpg]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0839"]
[OnName num="amane"]
"Oh, yes, ...... I'm fine.
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0109"]
[OnName num="yukika"]
" Shinji , ......."
[cpg cn=true]

[OnName num="shinzi"]
"..................."
[cpg cn=true]

The Yukika sister called me into the hallway without looking Amane any further.
[cpg]

[OnName num="shinzi"]
"Wait ....... Do you Amane want something to drink?　Are you thirsty?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
;//[FG f="amane_p5_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Amane0840"]
[OnName num="amane"]
"Yeah, ......."
[cpg cn=true]

[OnName num="shinzi"]
"I'll go to the store.
[cpg cn=true]

I tell Amane that and leave the room.
[cpg]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_h_wr_t1_0.ui" time=1000]
;//【ＢＧ】病院　待合室　夜　小雨

[FG f="yukika_p5_01_a.ui" method="change_1" pos="2/3" time=1000]

[WAIT time=1000]

[OnName num="shinzi"]
"What ......?
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0110"]
[OnName num="yukika"]
"That's enough, isn't it?
[cpg cn=true]

[OnName num="shinzi"]
"What ......?
[cpg cn=true]

I know what Yukika you are trying to say.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

And yet ......
[cpg]

[BGM f="h2"]
[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0111"]
[OnName num="yukika"]
"You've been good to her enough already. But now it's time to end it."
[cpg cn=true]

[OnName num="shinzi"]
"Why?　Why do you say that? Don't you feel sorry for him?　Don't you feel sorry for Amane after all those injuries?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0112"]
[OnName num="yukika"]
"Those injuries, they're ......
[cpg cn=true]

I'm sure you'll be able to understand what I mean. Yukika She grabbed my arm tightly and said gravely.
[cpg]

;//[FACE method="change_3" pos="2/3"]

[FG f="yukika_p7_01_a.ui" method="change_3" pos="2/3" time=1000]

[WAIT time=100]
[VOICE f="Yukika0113"]
[OnName num="yukika"]
"Do you Shinji really think Yoko is the kind of girl who would do something like that?
[cpg cn=true]

[OnName num="shinzi"]
"Yes ......."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0114"]
[OnName num="yukika"]
"Answer me. Are you sure Yoko did it?
[cpg cn=true]

[OnName num="shinzi"]
"No, that's because ...... the police.
[cpg cn=true]

I didn't want to believe that Yoko would go that far.
[cpg]

But isn't the fact that he was arrested the best proof ......?
[cpg]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0115"]
[OnName num="yukika"]
"I think Amane did it."
[cpg cn=true]

[OnName num="shinzi"]
"Why?
[cpg cn=true]

;//[FACE method="change_4" pos="2/3"]
[FG f="yukika_p5_01_a.ui" method="change_4" pos="2/3" time=1000]

[WAIT time=100]
[VOICE f="Yukika0116"]
[OnName num="yukika"]
"It's a genetic thing.
[cpg cn=true]

[OnName num="shinzi"]
"Genetic?　Is that what ...... is?
[cpg cn=true]

;//[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0117"]
[OnName num="yukika"]
"Psychosis. ......
[cpg cn=true]

[OnName num="shinzi"]
"It's .......
[cpg cn=true]

I couldn't believe my ears when I heard the words Yukika come out of my sister's mouth.
[cpg]

Yukika This is a great way to make sure you are getting the most out of your time with your family and friends.
[cpg]

[OnName num="shinzi"]
"There are some things you can say and some things you can't!　 Amane is not like that!　Even now, you were able to talk about it in a reasonable and calm manner!
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0118"]
[OnName num="yukika"]
"But she's crazy, you know. I think she's having a temper tantrum.
[cpg cn=true]

[OnName num="shinzi"]
"No, please!
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0119"]
[OnName num="yukika"]
"Please, Shinji . I'm worried about you, Lizzy. I'm worried about your uncle, and I'm worried about ...... your aunt. I don't want you to get involved with her anymore.
[cpg cn=true]

I'm not sure what to do, but I'm going to do it. Yukika Your sister's clinging eyes irritated me even more.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to say.　I don't care how you feel.　My parents and Amane 's parents have nothing to do with me and her!　We are who we are!
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0120"]
[OnName num="yukika"]
" Shinji !
[cpg cn=true]

[OnName num="shinzi"]
"Just go home!　Just go home!
[cpg cn=true]

[free time=800]
I shunned my Yukika sister and headed to the concession stand to buy a drink for Amane .
[cpg]


[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=2000]



;//[FG f="yukika_p1_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0121"]
[OnName num="yukika"]
"Why don't you understand ...... Shinji . I love you ...... more than anyone."
[cpg cn=true]




;//ドアの隙間から冷たい目で雪華を見ている雨音が、数段階に分けてアップになる





[free time=800]
;**【ＣＧ】ev_54_0 ***********************
[CG id=17 index=0 time=3000]
;*****************************************

;//[BGM f="h2"]



[WAIT time=100]
[VOICE f="Amane0841"]
[OnName num="amane"]
"........................."
[cpg cn=true]

[BG f="ev_54_0_up_3.ui" time=2000]


[WAIT time=100]
[VOICE f="Amane0842"]
[OnName num="amane"]
"........................ You're in my way..."
[cpg cn=true]



;//[free time=400]
;//[WAIT time=400]
;//[BG f="black.ui" time=900]
;//[WAIT time=900]
;//[BG f="b_h_ro_t2_0.ui" time=1000]
;//【ＢＧ】病院　個室　夜　小雨



[BG f="black.ui" time=6000]

[WAIT time=100]
[VOICE f="Amane0843"]
[OnName num="amane"]
"You're ............... in my way. ...... You're in my way. ...... You're in my way. ......... out of the way."
[cpg cn=true]


[jump storage="ep018.ks" target="*start"]
