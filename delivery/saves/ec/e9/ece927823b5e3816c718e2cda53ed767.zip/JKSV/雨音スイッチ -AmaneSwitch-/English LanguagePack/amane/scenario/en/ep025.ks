*start




;//ｂ,　むしろ嬉しい
*choise_22

;#################################################
*Ep025|My favorite sister.
;#################################################
[SCENE id=27]
[BGM f="rain"]
[BG f="b_a_mrb_t1_0.ui"]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/5"]
[FG f="yukika_p5_01_a.ui" method="change_4" pos="4/5"]



[OnName num="shinzi"]
"Honestly, I'm ...... glad."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane1010"]
[OnName num="amane"]
"What?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0167"]
[OnName num="yukika"]
"What ......?"
[cpg cn=true]

Perhaps my answer was unexpected, Amane and Yukika sister raised their voices at the same time.
[cpg]

But this was my honest intention.
[cpg]

[OnName num="shinzi"]
Yukika "You can find a lot of people who are looking for the best way to get the most out of their life. But I thought that I shouldn't like her because we are cousins and she is an adult. So I'm ...... very happy that you have feelings for me."
[cpg cn=true]

[FACE method="change_6" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0168"]
[OnName num="yukika"]
" Shinji ......, thank you ......."
[cpg cn=true]



[FACE method="change_3" pos="2/5"]


[WAIT time=100]
[VOICE f="Amane1011"]
[OnName num="amane"]
"No, that's ...... weird!　How can you not feel bad for a perverted woman with fantasies like that?
[cpg cn=true]

[OnName num="shinzi"]
"She's a pervert. ......
[cpg cn=true]

You will find that the temperature inside you will drop quickly with the words of Amane .
[cpg]

[OnName num="shinzi"]
"Don't talk about your sister like that,......."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane1012"]
[OnName num="amane"]
" Shinji !"
[cpg cn=true]

Amane It's a great way to get the most out of your time and money.
[cpg]

[OnName num="shinzi"]
Amane "It's not that I'm not a good person, but I'm not a good person.
[cpg cn=true]



[FACE method="change_6" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane1013"]
[OnName num="amane"]
"That's terrible!　Why!　You're joking about me being creepy, right?"
[cpg cn=true]

[OnName num="shinzi"]
"I don't want to hear it. ...... I'm sorry. I can't do this anymore. ......
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane1014"]
[OnName num="amane"]
"You can't?
[cpg cn=true]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

The actual heart of my own exhausted Amane is going to be the Yukika sister who cares for me.
[cpg]

[FG f="yukika_p7_01_a.ui" method="change_6" pos="4/5" time=800]
[FG f="amane_p5_02_a.ui" method="change_7" pos="2/5" time=800]

[OnName num="shinzi"]
"Sis, I'm sorry for everything I've ...... done.
[cpg cn=true]

[FACE method="change_2" pos="4/5"]


[WAIT time=100]
[VOICE f="Yukika0169"]
[OnName num="yukika"]
"It's okay. I'm just trying to protect Shinji ......
[cpg cn=true]

[OnName num="shinzi"]
"I'll do as you say. I've been disobeying you because I didn't understand why you were doing it, but now I understand how you feel. ......
[cpg cn=true]



Amane It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[free time=800]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]

[OnName num="shinzi"]
"I'm not going to be with you anymore, Amane . I've realized what's really important.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1015"]
[OnName num="amane"]
"What's that? ...... No!　Don't leave me!　Don't leave me alone!
[cpg cn=true]

[OnName num="shinzi"]
"I can't go on like this anymore. I can't keep up with what you're doing.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1016"]
[OnName num="amane"]
"I won't do it again!　I'm not gonna hurt myself. I'm not gonna take drugs!
[cpg cn=true]

[OnName num="shinzi"]
"I've heard that so many times.　But it didn't work. ......"
[cpg cn=true]

Clinging to me as I shake my head, Amane whimpers.
[cpg]

;//[FACE method="change_3" pos="2/3"]
[FG f="amane_p7_02_a.ui" method="change_3" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane1017"]
[OnName num="amane"]
"I'm not going to do it.　I'm not sure if I'll be able to do that.　I promise not to visit you in the middle of the night or do anything that Shinji you don't like!
[cpg cn=true]

[OnName num="shinzi"]
"Goodbye. Take care of yourself, .......
[cpg cn=true]


[FG f="amane_p3_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1018"]
[OnName num="amane"]
"No!　Don't go!　You lied!　You said you loved me!　You said you'd be with me forever!
[cpg cn=true]



I took the stunned Yukika sister's hand and left the Amane apartment, trying not to look at the Amane screaming on the floor.
[cpg]




;//エフェクト

[SE f="se014"]
;//【ＳＥ】鉄扉開く

[free time=1000]

[BG f="black.ui" time=1000]
[WAIT time=2000]


[BGM f="rain"]
;//[BG f="b_ex_pk_t1_0.ui" time=1000]
;//【ＢＧ】公園　夜　小雨

[BG f="b_ex_sk_t1_0.ui" time=1000]
;//空

[WAIT time=1000]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、大雨】


;//シトシト雨

;//loop
[SE f="se002" loop=true]
;//【ＳＥ】シトシト


[WAIT time=1000]
[SE f="se131"]
;//【ＳＥ】雨の中歩く

[WAIT time=3000]



;//[FG f="yukika_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0170"]
[OnName num="yukika"]
"You're going to ...... be like that, aren't you?"
[cpg cn=true]

Yukika In the event that you've got a lot of money, you'll be able to use it to get the most out of your money.
[cpg]

;//[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0171"]
[OnName num="yukika"]
"You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg cn=true]

[OnName num="shinzi"]
"That's right,.......
[cpg cn=true]

This is a great way to make sure you are getting the most out of your time with your family.
[cpg]

Amane is certainly not normal.
[cpg]

It's not her fault, but her mind is probably diseased.
[cpg]

And it was not something that I could fix.
[cpg]

;//[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0172"]
[OnName num="yukika"]
"I'm sorry to hear that. ...... Don't get involved.
[cpg cn=true]

[OnName num="shinzi"]
"I know. ......
[cpg cn=true]

;//[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0173"]
[OnName num="yukika"]
"I'm glad ...... I'm glad ...... you finally understand. ......
[cpg cn=true]

This is a great way to get the most out of your time with your family and friends. Yukika Your sister smiled gently as if she was truly relieved.
[cpg]

This is a great way to make sure that you get the most out of your vacation.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

It's a great way to make sure you don't get caught in the middle.
[cpg]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//loop
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=900]
[WAIT time=900]
[BG f="b_ex_pk_t1_0.ui" time=1000]
;//【ＢＧ】公園　夜　小雨

[WAIT time=1000]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]

;//loop
[SE f="se006" loop=true]
;//【雨、大雨】


;//loop
;//[SE f="se002" loop=true]


[OnName num="shinzi"]
"I'm not sure what to say, but I'm sure you'll understand.
[cpg cn=true]




;#############################################################


;#############################################################




;//[free time=800]
;//[BG f="black.ui" time=1000]
;//[WAIT time=100]
;//[BGM f="rain"]
;//[BG f="b_ex_pk_t1_0.ui" time=1000]
;//【ＢＧ】公園　夜　小雨


;//【雨、大雨】


[FG f="yukika_p5_01_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0174"]
[OnName num="yukika"]
"Thank you, .......... Shinji ......"
[cpg cn=true]

I'm not sure what to say.
[cpg]

This is a great way to make sure you are getting the most out of your time and money.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0175"]
[OnName num="yukika"]
"It was a good memory,.......
[cpg cn=true]

[OnName num="shinzi"]
What do you mean, "memories"?　What do you mean by that?
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0176"]
[OnName num="yukika"]
"Actually, I'm ...... being approached about a blind date.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, ......?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0177"]
[OnName num="yukika"]
"I'm glad I got to know you before I took the job. ......
[cpg cn=true]

[OnName num="shinzi"]
"Wait, wait, wait, ....... What's going to happen to me then?"
[cpg cn=true]

I naturally assumed that I would be able to Yukika be lovers with my sister.
[cpg]

But it seems that your sister was not ......
[cpg]


[FG f="yukika_p7_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0178"]
[OnName num="yukika"]
" Shinji ......, we are related by blood. Your father, mother and relatives will not approve of this kind of relationship. ......"
[cpg cn=true]

[OnName num="shinzi"]
".................."
[cpg cn=true]

Even though the law allows cousins to marry each other, in reality, it's just barely taboo.
[cpg]

It's a good thing that I'm not the only one.
[cpg]

[OnName num="shinzi"]
"I'm ......
[cpg cn=true]

When I heard the words of my sister, I thought it over and said my own thoughts,......
[cpg]




;//選択肢４（二択）


;//■選択肢
[switch]
[case "I Yukika follow my sister."]
	[swap]
	[jump target="*choise_41"]
[case "I don't want to do that."]
	[swap]
	[jump target="*choise_42"]
[endswitch]

;//４-a　雪華姉さんに従う
*choise_41
[jump storage="ep026.ks" target="*start"]

*choise_42
[jump storage="ep027.ks" target="*start"]



