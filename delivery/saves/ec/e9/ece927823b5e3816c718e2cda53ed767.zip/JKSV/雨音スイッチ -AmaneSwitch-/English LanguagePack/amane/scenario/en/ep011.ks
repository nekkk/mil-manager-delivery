*start


;#################################################
*Ep011|What I believe...
;#################################################
[SCENE id=11]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_si_d_t2_2.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　夕方　雨





[FG f="yukika_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0045"]
[OnName num="yukika"]
"Oh, welcome back.
[cpg cn=true]

[OnName num="shinzi"]
" Yukika sister......"
[cpg cn=true]

After that, when I asked the teacher what happened to Amane , she didn't have a clue, and when I called Amane 's phone, I couldn't get through, and I was on my way home, heartbroken.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0046"]
[OnName num="yukika"]
"What's wrong with you?　You look kind of pale. ......"
[cpg cn=true]

[OnName num="shinzi"]
"'Yeah ......'
[cpg cn=true]

I thought about asking my Yukika sister, who had come to make dinner, but I didn't even know where to begin or how to tell her.
[cpg]

So I sat down on the sofa in silence and tried to sort out a lot of things in my head. ......
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0047"]
[OnName num="yukika"]
"Hey, Shinji ......."
[cpg cn=true]

I'm not sure what to do, but I'm going to do it.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0048"]
[OnName num="yukika"]
"I've been thinking about it a lot. ......
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0049"]
[OnName num="yukika"]
"Yeah, ....... That girl, Amane ?　I don't know, I just don't think she fits in with Shinji .
[cpg cn=true]

[OnName num="shinzi"]
"What?　What the fuck are you talking about?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0050"]
[OnName num="yukika"]
"It's not like there's anything wrong with it.　It's just that ......, you know, Shinji has a lot on its mind, you know?　So I thought it would be better to go out with a girl who is more ...... positive.
[cpg cn=true]

[OnName num="shinzi"]
"I don't get it. ......
[cpg cn=true]

This is the first time that I have ever heard of such a thing, and I can't gauge the true meaning of it. Yukika
[cpg]

I'm not sure what to make of it, but I'm sure it's a good idea.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0051"]
[OnName num="yukika"]
"You're a lot more popular than you think you are, Shinji !　Why don't you take a broader view and choose who you want to go out with?"
[cpg cn=true]

[OnName num="shinzi"]
"I'm not popular and I'm not ......
[cpg cn=true]

It's a good idea to get up and go to your room to end this conversation as soon as possible.
[cpg]

But then ......
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0052"]
[OnName num="yukika"]
"There's a girl here today who likes Shinji me.
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

[SE f="se008"]
;//【ＳＥ】襖開く

;//move
[move from="2/3" to="2/5" ease="easeInOutSine" time=800]

[FG f="youko_p5_01_a.ui" method="change_2" pos="4/3" time=800]
[move from="4/3" to="4/5" ease="easeInOutSine" time=800]


[WAIT time=100]
[VOICE f="Youko0181"]
[OnName num="youko"]
"Oh!"
[cpg cn=true]

[OnName num="shinzi"]
" Yoko ?"
[cpg cn=true]

The sliding door between the Buddhist room and the dining room opened and Yoko unexpectedly appeared.
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0182"]
[OnName num="youko"]
Yukika "This is a great way to make sure you are getting the most out of your time with your family and friends.
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0053"]
[OnName num="yukika"]
"I thought I'd ask him to cook Shinji 's dinner with me today. Isn't that nice?"
[cpg cn=true]

[OnName num="shinzi"]
"What the hell, ......? You all do things without my knowledge. ...... What the hell is wrong with you?
[cpg cn=true]

You will find a lot of things that you can do to help yourself.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[OnName num="shinzi"]
"It's funny ......, everyone is crazy!
[cpg cn=true]

No one cares about my feelings?
[cpg]

No one cares about my feelings.
[cpg]


[free time=800]

[SE f="se031"]
;//【ＳＥ】メッセージ着信


At that time, my phone rang in my pants pocket.
[cpg]



[BGM f="danger"]
;//メッセージ画面


I'm sorry for all the trouble I've caused you, " Amane " Shinji .
[cpg]

If this continues, I'm sure Shinji I will be hated.
[cpg]

So I want to end up with the happy feeling I have now.
[cpg]

Shinji , please remember me now.
[cpg]

Don't forget your favorite Amane .
[cpg]

Goodbye.
[cpg]




[OnName num="shinzi"]
"......? !"
[cpg cn=true]

"I want to end." "Goodbye"?
[cpg]

My brain froze when I saw that sentence.
[cpg]

[FG f="yukika_p5_01_a.ui" method="change_7" pos="2/5" time=800]
[FG f="youko_p5_01_a.ui" method="change_7" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Yukika0054"]
[OnName num="yukika"]
"What's going on?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0183"]
[OnName num="youko"]
"'From who?'
[cpg cn=true]

My Yukika sister and Yoko took my phone, which had almost fallen out of my hands, and stared at the screen.
[cpg]

[FACE method="change_4" pos="2/5"]
[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0055"]
[OnName num="yukika"]
".................."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0184"]
[OnName num="youko"]
".................."
[cpg cn=true]

From their mouths, I expect to hear, "Oh my God!" "Oh my God!" I expected to hear.
[cpg]

On the contrary, ......
[cpg]

[BGM f="healing"]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0185"]
[OnName num="youko"]
"It's funny!"
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0056"]
[OnName num="yukika"]
"This is what puberty is all about, isn't it?"
[cpg cn=true]

And they don't even seem to care.
[cpg]

[OnName num="shinzi"]
"You ...... are crazy! You're crazy!　You're telling me I'm going to die!
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0186"]
[OnName num="youko"]
"People who are really dying don't send out messages like that.
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0057"]
[OnName num="yukika"]
"He's just trying to get your attention.
[cpg cn=true]

[OnName num="shinzi"]
"......, enough!
[cpg cn=true]




[SE f="se010"]
;//【ＳＥ】ダッシュ




[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0058"]
[OnName num="yukika"]
"No!　 Shinji !　No!　There's a typhoon tonight!
[cpg cn=true]

I got fed up with the two heartless people and immediately ran out of the house.
[cpg]



[free time=800]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_ex_sz_t3_1.ui" time=1000]
;//【ＢＧ】通学路　夜　雨
[WAIT time=1000]

;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


[SE f="se006"]
;//【ＳＥ】雨風


;//台風直前の風とまだ量は少ない雨降る夜道





There is no doubt that something has happened to Amane recently, so it is no wonder that she is being hunted down without my knowledge.
[cpg]

[OnName num="shinzi"]
"I'm coming, ......!"
[cpg cn=true]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]




;//エフェクト


[BG f="black.ui" time=900]
[WAIT time=1000]

[SE f="se014"]
;//【ＳＥ】鉄扉勢い良く開く

[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】バスルームからシャワーの音





I ran into Amane 's room and immediately noticed something strange in the room.
[cpg]




[free time=800]



[BGM f="danger"]

[SE f="se035"]
;//【ＳＥ】バスルームのドア開く


;**【ＣＧ】ev_33_0 ***********************
[CG id=11 index=0 time=1000]
;*****************************************


[OnName num="shinzi"]
"I'm sure you'll agree.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0660"]
[OnName num="amane"]
"...............
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0661"]
[OnName num="amane"]
"..................
[cpg cn=true]



[WAIT time=100]
[VOICE f="Amane0662"]
[OnName num="amane"]
"You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg cn=true]



[SE f="se043"]
;//【ＳＥ】ブシュッ

;//血が飛び散る

[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_33_0.ui" time=500]


[OnName num="shinzi"]
" Amane ohhh!"
[cpg cn=true]

There was a scene there that you often see in suspense dramas.
[cpg]

You will find a lot of things that you can do to make your life easier.
[cpg]

She Amane had slit her wrists... and tried to kill herself .......
[cpg]

[OnName num="shinzi"]
"What are you doing, Amane - ?"
[cpg cn=true]

This is because of the vigorous slashing of the wrists, blood is flowing drastically.
[cpg]


[WAIT time=100]
[VOICE f="Amane0663"]
[OnName num="amane"]
"This is a great way to get the most out of your day.　I'm not sure what to say.　 Shinji I'm not sure what to do.
[cpg cn=true]

Amane This is a great way to make sure you are getting the most out of your time with your family and friends.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to say.　 Amane !　I'm sure you'll be fine.　 Amane eeee!"
[cpg cn=true]

;//シャワーがザンザンと勢い良く後頭部を叩く。
;//俺は雨音のグニャリとした身体を抱いて、手首を浴槽から引き出すとバスルームから出た。


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト
[stopse g=2]
[stopse g=6]

I'm concerned about how deeply I cut myself.
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="h2"]
[BG f="b_a_mr_t4_4_s_up.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夜　雨

[FG f="amane_p7_02_a.ui" method="change_4" pos="2/3" time=1000]

[WAIT time=1000]

[OnName num="shinzi"]
"The wound is ......!
[cpg cn=true]

Numerous worm swellings could be seen on Amane 's left wrist.
[cpg]

In the midst of these hesitant wounds, there is one deep wound that has been cracked open, and blood is flowing out of it in a trickle.
[cpg]

[OnName num="shinzi"]
"...... stick!"
[cpg cn=true]

I quickly ripped the sheet off the bed and wiped the blood off my wrist.
[cpg]

In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

So I put a lot of pressure on the area, wrapped it tightly in a towel and slapped Amane his cheek.
[cpg]

[OnName num="shinzi"]
" Amane !　Open your eyes!"
[cpg cn=true]




[SE f="se001"]
;//【ＳＥ】ビンタ×２

[BG f="white.ui" time=0]

[free time=0]
[WAIT time=1]
[BG f="b_a_mr_t4_4_s_up.ui" time=500]
[FG f="amane_p7_02_a.ui" method="change_4" pos="2/3" time=500]
[WAIT time=1500]

[FG f="amane_p7_02_a.ui" method="change_7" pos="2/3" time=1500]
[WAIT time=1500]

[WAIT time=100]
[VOICE f="Amane0664"]
[OnName num="amane"]
" Shinji ....... You're here. ......
[cpg cn=true]

[OnName num="shinzi"]
"How could I not have come when I saw a message like that?
[cpg cn=true]

[FG f="amane_p9_02_a.ui" method="change_7" pos="2/3" time=500]

I yelled at the dazed Amane and hugged his body tightly.
[cpg]

Good .......
[cpg]

I'm really glad you're alive.
[cpg]

[OnName num="shinzi"]
"'Why the hell ...... Amane . Why do you hurt yourself so ......?"
[cpg cn=true]

[FG f="amane_p8_02_a.ui" method="change_4" pos="2/3" time=1000]
[WAIT time=100]
[VOICE f="Amane0665"]
[OnName num="amane"]
"I'm sorry ....... But I don't want ...... or Shinji to hate me. If they hate me, I want to ...... die before they do."
[cpg cn=true]

[OnName num="shinzi"]
"Idiot!"
[cpg cn=true]

[SE f="se057"]
;//【ＳＥ】強いビンタ
[BG f="white.ui" time=500]

[free time=500]
[WAIT time=500]
[BG f="b_a_mr_t4_4_s_up.ui" time=500]
[FG f="amane_p8_02_a.ui" method="change_4" pos="2/3" time=500]

I unintentionally slapped Amane on the cheek.
[cpg]

[OnName num="shinzi"]
"You can't just say that you're going to die!　You know that, don't you?　Didn't you cry when your mother died?　Didn't you cry?　Didn't you feel sad?
[cpg cn=true]

[OnName num="shinzi"]
"I cried, too!　So why are you trying to make me sad!　Why don't you think about how sad I'll be when you're dead?
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0666"]
[OnName num="amane"]
".........!"
[cpg cn=true]

At my heartfelt cry, Amane forgot to blink as if surprised.
[cpg]

And the next moment, a large number of tears overflowed from the eyes of the ......
[cpg]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0667"]
[OnName num="amane"]
"Oh my God!　I'm sorry!　 I'm sorry Shinji , I'm sorry!
[cpg cn=true]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[SE f="se004"]
;//【ＳＥ】窓から吹き込む暴風雨

[FO pos="2/3" time=800]

[OnName num="shinzi"]
"I'm sorry.
[cpg cn=true]

At that time, a great deal of rain and wind blew into the room, and for the first time I noticed that the window was open.
[cpg]

As I turn my head towards it in surprise, Amane stumbles to his feet and stands between me and the window.
[cpg]

[BG f="b_a_mr_t4_4_s.ui" time=0]
[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=0]
[WAIT time=100]
[VOICE f="Amane0668"]
[OnName num="amane"]
"It's okay. Keep it like this,......."
[cpg cn=true]

[OnName num="shinzi"]
"But there's a typhoon coming, you know. The room will be a mess.
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0669"]
[OnName num="amane"]
"I want it messed up!　My room will be ...... and I'll be ......."
[cpg cn=true]




[SE f="se005"]
;//【ＳＥ】暴風





I want to ruin everything, I want to destroy everything... I understand how Amane you feel, but only a little.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to make of it. I don't want Amane to catch a cold."
[cpg cn=true]

When I was trying to convince her to close the window somehow...
[cpg]



[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_a_mr_t4_2.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夜　雨　停電


[SE f="se059"]
;//【ＳＥ】ドサッ





[OnName num="shinzi"]
" Amane !"
[cpg cn=true]

Amane It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[OnName num="shinzi"]
"You can find a lot of people who are interested in this.
[cpg cn=true]

Amane This is a great way to get the most out of your time and money.
[cpg]

I closed the window tightly and wrapped the Amane body in a towel.
[cpg]

[OnName num="shinzi"]
"Why didn't you tell me sooner ......?"
[cpg cn=true]

It's a good idea to have a good idea of what you're going to do with the money you have.
[cpg]

[SE f="se036"]
;//【ＳＥ】ガタンガタン


[FG f="amane_p8_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0670"]
[OnName num="amane"]
"I'm sorry... ......"
[cpg cn=true]

[OnName num="shinzi"]
"It's okay!"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0671"]
[OnName num="amane"]
"'I'm sorry...nasa....... But...I...don't...want...to............
[cpg cn=true]

[OnName num="shinzi"]
"What are you talking about, ......?
[cpg cn=true]

You can't really hear what Amane you're mumbling, whether you're floating on heat or not.
[cpg]

In that moment, I still thought that she was trying to say something to me.
[cpg]

So I put my ear close to ...... it.
[cpg]


[WAIT time=100]
[VOICE f="Amane0672"]
[OnName num="amane"]
" Shinji ku...n...and ...... I want to......... sorry. ...na...sa..."
[cpg cn=true]

[OnName num="shinzi"]
"Are you there?　I'm with Amane , right?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0673"]
[OnName num="amane"]
"Huh...huh...huh............sun...of... Yoko ...cha...n...n... ......"
[cpg cn=true]

[OnName num="shinzi"]
"......... What?"
[cpg cn=true]

The sun?　 Yoko ?
[cpg]

After hearing that much, he realizes that this is a rant.
[cpg]

Amane You'll be able to get a lot more than just a few.
[cpg]


[WAIT time=100]
[VOICE f="Amane0674"]
[OnName num="amane"]
And ...... forgive me..." Izumi ...san... Shizuku cha...n. ...... sorry. ...I... Forgive me... forgive me. ......"
[cpg cn=true]

[OnName num="shinzi"]
"What the... ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0675"]
[OnName num="amane"]
"I'm sorry ......... I'm sorry .......
[cpg cn=true]

[OnName num="shinzi"]
"........................"
[cpg cn=true]

[FO pos="2/3" time=800]

I'm not sure if this is a good idea or not.
[cpg]

Yoko ......
[cpg]

Izumi ......
[cpg]

Shizuku ......
[cpg]

They've driven Amane ...... the girls to this point.
[cpg]

I recall each of their words and actions that I have seen and heard so far.
[cpg]

Were they the ones who bullied Amane ......?
[cpg]

Why?　Why?
[cpg]

Especially Shizuku , they must have adored Amane .
[cpg]

But ......
[cpg]


[WAIT time=100]
[VOICE f="Amane0676"]
[OnName num="amane"]
"I'm sorry... Shizuku I'm sorry... ...... I'm... ...bad...no."
[cpg cn=true]

If these words come out unconsciously, then something must have happened.
[cpg]

Without my knowledge, .......
[cpg]

I take the light red discolored towel that was wrapped around Amane my left wrist.
[cpg]

Underneath, there was a bright red line drawn in a straight line.
[cpg]

[OnName num="shinzi"]
"What happened was ...... this ...... thing."
[cpg cn=true]

I can't allow anyone to do this to Amane me.
[cpg]

[OnName num="shinzi"]
"No matter what, ......, I'm on Amane your side!"
[cpg cn=true]

;#############################################################


;#############################################################


;//エフェクト


;//回想（セピア）
[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="sir"]
[BG f="b_a_old_t1_0.ui" time=1000]
;//【ＢＧ】過去の雨音の家　リビング

;//母と幼い雨音






[WAIT time=100]
[VOICE f="Amane0677"]
[OnName num="amane"]
"Mom, when is your father coming back?
[cpg cn=true]

[OnName num="mother"]
"Your father, ......, is not coming back.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0678"]
[OnName num="amane"]
"What do you mean?　I want to see my father. ......
[cpg cn=true]

[OnName num="mother"]
"He's gone to ....... He's gone to another woman. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0679"]
[OnName num="amane"]
"Because it's raining ......?　Because I hate the rain. ......
[cpg cn=true]

[OnName num="mother"]
" Amane ......"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0680"]
[OnName num="amane"]
"Can your mother stay with Amane ?　Your mom likes the rain, so she'll stay with Amane , right?"
[cpg cn=true]

[OnName num="mother"]
"Yes, she is. When it rains, you always pick up Amane , don't you?　You always will.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0681"]
[OnName num="amane"]
"Yeah. When it rains, she comes!　She's always there when it rains!
[cpg cn=true]

[OnName num="mother"]
"She likes the rain.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0682"]
[OnName num="amane"]
" Amane likes the rain, too."
[cpg cn=true]

[OnName num="mother"]
"♪ Pitter-patter ♪
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0683"]
[OnName num="amane"]
"♪ Chirp-chirp ♪
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0684"]
[OnName num="amane_with_mother"]
"♪ Run, run, run ♪
[cpg cn=true]




;//エフェクト




[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_ro_t1_0.ui" time=1000]
;//【ＢＧ】学園　屋上　午前　曇り





[FG f="youko_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0187"]
[OnName num="youko"]
"Yoo-hoo, Shinji What's this for?
[cpg cn=true]

[OnName num="shinzi"]
".................."
[cpg cn=true]

The next day, I'm calling Yoko to the roof.
[cpg]

I hid my disgust at Yoko for running in a brainless manner and calmly questioned him.
[cpg]

[OnName num="shinzi"]
"What did you do to ...... and Amane ?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0188"]
[OnName num="youko"]
"What?"
[cpg cn=true]

[OnName num="shinzi"]
"Don't play dumb. I already know. You said something to Amane , didn't you?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0189"]
[OnName num="youko"]
"I didn't.
[cpg cn=true]

[OnName num="shinzi"]
"Bullshit!"
[cpg cn=true]

I yelled, and Yoko let out a big sigh and started talking.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0190"]
[OnName num="youko"]
"............ That girl, she doesn't get along with Shinji .
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0191"]
[OnName num="youko"]
"Because Shinji , you don't know anything about her, do you?
[cpg cn=true]

[OnName num="shinzi"]
"Then what the fuck do you know about her?
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0192"]
[OnName num="youko"]
"I know a lot of .......
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

Yoko This is a great way to make sure you are getting the most out of your investment.
[cpg]

Amane This is a great way to make sure you are getting the most out of your time with us.
[cpg]

This is a great way to make sure you are getting the most out of your time with your family.
[cpg]

But the next words that came out of Yoko 's mouth startled me to the core.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0193"]
[OnName num="youko"]
"I was classmates with that girl in elementary school.
[cpg cn=true]

[OnName num="shinzi"]
"What ......?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0194"]
[OnName num="youko"]
"Oh, you didn't hear that?
[cpg cn=true]

Yoko and Amane are childhood friends. ......?
[cpg]

That's exactly what I'm talking about.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0195"]
[OnName num="youko"]
"I'm not sure what to say. It's a great way to get to know the people in your area. Even among the adults in the neighborhood, it was a terrible rumor. I'm sure you've heard the rumors about her selling her body to different men every night.
[cpg cn=true]

[OnName num="shinzi"]
".................."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0196"]
[OnName num="youko"]
"So, maybe she was doing it when she was about that age too?　That kind of thing. ......
[cpg cn=true]

[OnName num="shinzi"]
"Fuck you!
[cpg cn=true]

Regardless of the parents, the story Yoko is telling is just a rumor.
[cpg]

To use that to discredit Amane is vile as hell.
[cpg]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0197"]
[OnName num="youko"]
"Do you know why your mother is not here?　She committed suicide?　I'm not sure what to make of it, but I think it's a good idea.
[cpg cn=true]

[OnName num="shinzi"]
"..................
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0198"]
[OnName num="youko"]
"You can't fight blood, you know?　If her mother was like that, she'd be like ....... Don't you think so?
[cpg cn=true]

[OnName num="shinzi"]
"No. ......
[cpg cn=true]

[FO pos="2/3" time=800]

Amane It's a good idea to have a good idea of what's going on in your life.
[cpg]

So I turned my head and couldn't say anything more back.
[cpg]





;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、小雨】

;//loop
[SE f="se003" loop=true]
;//【ＳＥ】小雨


;//小雨が降ってくる





[FG f="youko_p5_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0199"]
[OnName num="youko"]
" Shinji ......, you need to wake up. I'm not sure what to say, but I'm sure you'll understand.　 Shinji I'm sure you'll be happy to know that I'm not the only one.
[cpg cn=true]

[OnName num="shinzi"]
".................."
[cpg cn=true]

I'm not thinking about marriage or anything like that yet.
[cpg]

But I understand what Yoko is trying to say.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0200"]
[OnName num="youko"]
" Shinji ....... You know, Shinji has me, .......
[cpg cn=true]




Her hand reached out to stroke my cheek as she said: ......
[cpg]

[OnName num="shinzi"]
"Stop it!
[cpg cn=true]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="danger"]
[BG f="b_s_ro_t1_0.ui" time=1000]
;//【ＢＧ】学園　屋上　午前　曇り


[SE f="se023"]
;//【ＳＥ】ドンッ！


;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


[FG f="youko_p1_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0201"]
[OnName num="youko"]
"No!"
[cpg cn=true]

The next thing you know, I'm pushing Yoko away from you.
[cpg]

[FG f="youko_p5_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0202"]
[OnName num="youko"]
"What are you doing?
[cpg cn=true]

[OnName num="shinzi"]
"That's what I'm talking about!　Are you not ashamed of yourself?　You're not ashamed to bring up a person's past,......, and a parent's past that Amane you couldn't handle yourself.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0203"]
[OnName num="youko"]
"I'm trying to help Shinji !
[cpg cn=true]

[OnName num="shinzi"]
"It's none of your business!
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0204"]
[OnName num="youko"]
"Get off me!
[cpg cn=true]

[OnName num="shinzi"]
"Leave me alone!　 Leave Amane alone!　Do you have any idea how much Amane suffers because of you?　If it weren't for you, Amane would have a normal life!　I hate you!　Don't you ever show your face in front of me or Amane again!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0205"]
[OnName num="youko"]
" Shinji !"
[cpg cn=true]

[OnName num="shinzi"]
"Shut up!
[cpg cn=true]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト


[SE f="se010"]
;//【ＳＥ】ダッシュ


I left a flustered Yoko on the roof and ran off by myself.
[cpg]

You can find a lot of people who are looking for the best way to get the most out of their lives.
[cpg]

;#############################################################


;#############################################################
;//loop
[stopse g=2]
[stopse g=6]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_pa_t1_1.ui" time=1000]
;//【ＢＧ】学園　廊下　午前　雨


[OnName num="3rd_grade"]
" Kizaki ?　I've already left today.
[cpg cn=true]

[OnName num="shinzi"]
"Already?"
[cpg cn=true]

[OnName num="3rd_grade"]
"I think I got a call from home. I was with your sister earlier.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, yeah? .......
[cpg cn=true]

The Izumi had already gone home along with Shizuku .
[cpg]

However, I decided to go straight to my senior's home because I wanted to deal with the rage that was born inside me today.
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_ex_sz_t1_1.ui" time=1000]
;//【ＢＧ】通学路　午後　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]


;//【雨、大雨】


The house of Izumi was known to everyone without having to ask for the address again.
[cpg]

It's a big, beautiful house that's rumored to be the home of the student body president, and every Shuei Academy student has been there at least once as an onlooker.
[cpg]

[OnName num="shinzi"]
"But ......, why is it that seniors ......
[cpg cn=true]

Just like I didn't know the connection between Yoko and Amane , I didn't know the connection between Izumi or Shizuku and I wonder if there is something between Amane or and .
[cpg]

I proceeded to the Kizaki house while thinking about such things.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]



[jump storage="ep012.ks" target="*start"]
