*start

;#################################################
*Ep006|My relationship with Amane
;#################################################
[SCENE id=6]

;//////////////////////////////////////////////////////////////////////////

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye1"]
[BG f="b_s_3f_t2_1.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午後　小雨





After what happened with Amane , I somehow felt like I was stronger than ever.
[cpg]

Is this what it means to be an adult? It's a great way to make sure you're getting the most out of your vacation.
[cpg]

In the event that you're not sure what you're looking for, you'll be able to find it on the web.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0448"]
[OnName num="amane"]
" Shinji "
[cpg cn=true]

[OnName num="shinzi"]
"Hmm?
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0449"]
[OnName num="amane"]
"Huh.
[cpg cn=true]

[OnName num="shinzi"]
"What?"
[cpg cn=true]

Amane I'm not sure what to make of this.
[cpg]

I'm not sure what to say.
[cpg]

You can say that we are a couple who are not afraid of anyone.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0450"]
[OnName num="amane"]
"Today is Shinji a committee meeting, right?
[cpg cn=true]

[OnName num="shinzi"]
"Oh, I see. ....... I'd love to come home with you, but I'm sorry.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0451"]
[OnName num="amane"]
"No, I mean, ......, I was thinking of going to the committee meeting too.
[cpg cn=true]

[OnName num="shinzi"]
"What?　Why?
[cpg cn=true]

I was going to say that I couldn't do that, but Amane started talking before I could.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0452"]
[OnName num="amane"]
"I haven't joined the committee yet, so I thought I'd see what it's all about.
[cpg cn=true]

[OnName num="shinzi"]
"Hmmm ......, I don't know, it's ......
[cpg cn=true]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

But ......
[cpg]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0453"]
[OnName num="amane"]
"No?
[cpg cn=true]

[OnName num="shinzi"]
"I mean, I don't know if they'll let me. ......
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0454"]
[OnName num="amane"]
"I'll do it for you. Okay?　Okay?"
[cpg cn=true]

I don't like it when people smile at me.
[cpg]

[OnName num="shinzi"]
"Well, I'll just ask."
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0455"]
[OnName num="amane"]
"Yeah.
[cpg cn=true]

In this way, Amane somehow ended up attending the class committee meeting together with me.
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_cf_t3_0.ui" time=1000]
;//【ＢＧ】学園　会議室　夕方　小雨

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[OnName num="female_student"]
"Why is Satonaka there ......?"
[cpg cn=true]

[OnName num="shinzi"]
"Well, he's just visiting ......."
[cpg cn=true]

[OnName num="female_student"]
"What?"
[cpg cn=true]

The girl, one of the class members, asked me a valid question.
[cpg]

You will find a lot of people who are looking for the best way to get the most out of their lives.
[cpg]

[FO pos="2/3" time=800]

[OnName num="vice-president"]
"So, let's talk about the agenda ......, shall we?　Why are there three of us in Class 2C?"
[cpg cn=true]

However, even the vice-president blamed the existence of Amane , you have to give a proper explanation of the situation.
[cpg]

[OnName num="shinzi"]
"I'm sorry!　It's .......
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_1" pos="1/4" time=800]
[WAIT time=100]
[VOICE f="Amane0456"]
[OnName num="amane"]
"The other day, I was transferred to the city, my name is Satonaka. Mizushima In the event that you're not sure what to do, you'll be able to ask for help.
[cpg cn=true]

Amane In the event that you have any questions regarding where and how to use the internet, please do not hesitate to contact us.
[cpg]

[FG f="izumi_p5_01_a.ui" method="change_7" pos="4/4" time=800]
[WAIT time=100]
[VOICE f="Izumi0051"]
[OnName num="izumi"]
"Satonaka?"
[cpg cn=true]

[OnName num="shinzi"]
"Is it okay if I visit or something?
[cpg cn=true]

[OnName num="vice-president"]
"It's my first time ....... Chairman, what should we do?
[cpg cn=true]

[FACE method="change_7" pos="4/4"]

[WAIT time=100]
[VOICE f="Izumi0052"]
[OnName num="izumi"]
" Satonaka and ...... the literature club?
[cpg cn=true]

[FACE method="change_2" pos="1/4"]

[WAIT time=100]
[VOICE f="Amane0457"]
[OnName num="amane"]
"Yes, that's right.
[cpg cn=true]

[OnName num="shinzi"]
"You're the chairman, you already know all this?
[cpg cn=true]

I was impressed with Izumi 's quick hearing.
[cpg]

[FACE method="change_2" pos="4/4"]

[WAIT time=100]
[VOICE f="Izumi0053"]
[OnName num="izumi"]
"I've been talking to my sister Shizuku about it. She's been a great help to me.
[cpg cn=true]


[FG f="amane_p6_01_a.ui" method="change_1" pos="1/4" time=800]
[WAIT time=100]
[VOICE f="Amane0458"]
[OnName num="amane"]
"Oh, the ...... sister of Shizuku ?
[cpg cn=true]

[OnName num="shinzi"]
" Izumi is the student body president and the most popular girl at school."
[cpg cn=true]

I proudly explained Izumi to Amane .
[cpg]


[WAIT time=100]
[VOICE f="Amane0459"]
[OnName num="amane"]
"............"
[cpg cn=true]

[FACE method="change_7" pos="4/4"]

[WAIT time=100]
[VOICE f="Izumi0054"]
[OnName num="izumi"]
"Hmm, a tour of ....... What can I do for you?"
[cpg cn=true]

[free time=800]
[SE f="se028"]
;//【ＳＥ】ゆっくり歩く


At the arrival of the first visitor, Izumi slowly gets out of his seat and walks over to us, pondering.
[cpg]

[FG f="izumi_p5_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Izumi0055"]
[OnName num="izumi"]
".........?"
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]

This is a great way to make sure that you get the most out of your time and money.
[cpg]

It was a half-distance that didn't seem appropriate for a conversation, and I couldn't gauge Izumi 's true intentions.
[cpg]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0056"]
[OnName num="izumi"]
"Yes, ......."
[cpg cn=true]

[OnName num="shinzi"]
"What?"
[cpg cn=true]

Izumi looked at me and opened his eyes as if he was surprised by something.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0057"]
[OnName num="izumi"]
"Oh, you ......"
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0460"]
[OnName num="amane"]
"............?"
[cpg cn=true]

[OnName num="shinzi"]
" Izumi ?　 Amane ?"
[cpg cn=true]

The older man spoke to Amane in a scratchy voice, but Amane was puzzled.
[cpg]

Amane This is a great way to get the most out of your business.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0058"]
[OnName num="izumi"]
"Oh, that ......, Satonaka is .......
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0461"]
[OnName num="amane"]
"What's my last name?
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0059"]
[OnName num="izumi"]
"Last name ......, that's... that's... that's what .......
[cpg cn=true]

[OnName num="shinzi"]
"What do you mean?　What do you mean?　What are you talking about?
[cpg cn=true]

When you notice, Izumi 's face is pale and bloodless.
[cpg]

[OnName num="shinzi"]
"It's a good idea to have a good idea of what you're doing.
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0060"]
[OnName num="izumi"]
"I'm sorry, I'm just not in the ...... mood today. I'm going to leave early.
[cpg cn=true]

[OnName num="vice-president"]
"What?　Chairman!
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0061"]
[OnName num="izumi"]
"I'm sorry!　I'll take care of the rest. ......"
[cpg cn=true]

[SE f="se062"]
;//【ＳＥ】ガタンガタン

[move from="4/5" to="4/3" ease="easeInOutSine" time=800]
[free time=800]

Izumi was clearly upset and walked out of the student union room, hitting chairs and desks around the area.
[cpg]

[SE f="se053"]
;//【ＳＥ】ザワザワ

[BGM f="insecurity"]





[OnName num="vice-president"]
"Please do the rest. ......!　So, I'll start ...... for now.
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

In the end, the matter of Amane was left unanswered, and I was left there.
[cpg]

[OnName num="shinzi"]
"What's wrong with ...... Izumi ?"
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0462"]
[OnName num="amane"]
"What's bothering you so much?
[cpg cn=true]

[OnName num="shinzi"]
"I mean, he was so blue.
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0463"]
[OnName num="amane"]
"Why does it bother you that he's blue?
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

In the seat where the discussion began, Amane spoke to me in a whisper from the side, but there was something wrong with his tone.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0464"]
[OnName num="amane"]
"You said you were the number one at the school. You said she's the number one girl at school. She's so beautiful.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, yeah, she is."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0465"]
[OnName num="amane"]
"So, Shinji , do you like her too?
[cpg cn=true]

[OnName num="shinzi"]
"What?　I do. ......
[cpg cn=true]

It is true that you are longing for a talented, intelligent and beautiful senior.
[cpg]

This is a great way to make sure you are getting the most out of your money.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0466"]
[OnName num="amane"]
"In the event that you do not have one, you can enjoy talking with him and go home with him.
[cpg cn=true]

[OnName num="shinzi"]
"I've never done that. We're going in opposite directions.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0467"]
[OnName num="amane"]
"If you know it's the other way, then you know where he lives?　How do you know so much?　Did you check?　 Are you stalking him on Shinji ?
[cpg cn=true]

[OnName num="shinzi"]
"What are you talking about?
[cpg cn=true]

You can say that it is unreasonable to pursue Amane , and I involuntarily raised my voice.
[cpg]

[OnName num="vice-president"]
"There!　Quiet!
[cpg cn=true]

[OnName num="shinzi"]
"I'm sorry!
[cpg cn=true]

Izumi This is a great way to make sure that you get the most out of your time and money.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0468"]
[OnName num="amane"]
"That's what Shinji happens when you take your eyes off the ....... There are a lot of other girls I'm interested in,......."
[cpg cn=true]

[OnName num="shinzi"]
"Hey Amane , what are you ......
[cpg cn=true]



[WAIT time=100]
[VOICE f="Amane0469"]
[OnName num="amane"]
" Kizaki Izumi Mr. ......"
[cpg cn=true]

Amane stopped attacking me and started biting her nails while mumbling next to me.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0470"]
[OnName num="amane"]
"' Kizaki ... Kizaki ...... have you heard of it?　Maybe I have. ...... Where did I hear that..."
[cpg cn=true]

[OnName num="shinzi"]
"Come on, ......."
[cpg cn=true]

I couldn't help but regret bringing Amane to the committee today.
[cpg]

What the hell is wrong with you all of a sudden?
[cpg]

The senior and Amane are really strange today.
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_k_ro_t1_0.ui" time=1000]
;//【ＢＧ】木崎家　姉妹の部屋　夕方　小雨


At the same time, Kizaki at home, Shizuku was doing internet in his room.
[cpg]

[FG f="shizuku_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0064"]
[OnName num="shizuku"]
"Â™" Oh, I want to see this too.
[cpg cn=true]

He was looking for a good play to see soon on the ticket sales page of the theater.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0065"]
[OnName num="shizuku"]
"But I don't know if I have enough pocket money ......."
[cpg cn=true]

You can find a lot of people who are looking for the best way to get the most out of their money. Kizaki The house is a mansion that is well known in the neighborhood, and from that you would think that they would be quite rich.
[cpg]

However, in reality, the amount of money at the disposal of Shizuku and Izumi is very small, and it is no different from that of ordinary students.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0066"]
[OnName num="shizuku"]
"I hope you will go with me, Amane senior. I'm not sure if you'll be able to afford it,......, since you said you live alone.　I'm not sure if it's a good idea, but it's a good idea. ......
[cpg cn=true]

[SE f="se064"]
;//【ＳＥ】ガサゴソ


[FO pos="2/3" time=800]

Shizuku In the event that you've got a lot of money, you'll be able to use it to buy a lot of things.
[cpg]

[FG f="shizuku_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shizuku0067"]
[OnName num="shizuku"]
"Hmmm ......, I'm a little short ......."
[cpg cn=true]

I'm not sure how much fun it would be to go to a play with my favorite senior.
[cpg]

It's a great way to make sure you're getting the most out of your time with your family.
[cpg]

Such a wonderful dream was in Shizuku 's heart.
[cpg]

However, there is a lack of funds to do so.
[cpg]

If you are a normal student, you would ask your parents for help, but there are reasons why Shizuku you can't do that ......
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Shizuku0068"]
[OnName num="shizuku"]
"Huh ......."
[cpg cn=true]

I'm not sure what to make of it.
[cpg]

[FO pos="2/3" time=800]

There ......
[cpg]



[SE f="se035"]
;//【ＳＥ】急にドア開く


[FG f="shizuku_p5_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="izumi_p5_01_a.ui" method="change_7" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Shizuku0069"]
[OnName num="shizuku"]
"I'm not sure what to say.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Izumi0062"]
[OnName num="izumi"]
"..............."
[cpg cn=true]

The door of the room was opened violently, and the sister Izumi came in with a pale face.
[cpg]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0070"]
[OnName num="shizuku"]
"I'm not sure what to say.　What's wrong with you?　It's very early. What about the committee?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Izumi0063"]
[OnName num="izumi"]
"..............."
[cpg cn=true]

There is no reply from Izumi who sat on the bed without looking at you.
[cpg]

It's a good idea to have a good idea of what's going on in your life.
[cpg]

So Shizuku decides to talk about it, in order to change the atmosphere.
[cpg]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0071"]
[OnName num="shizuku"]
"I've got a little favor to ask you, sister. I'm not sure what to do, but I'm sure I'll be able to do it.　 Amane I want to go see a play with my seniors, but I don't have enough money."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0064"]
[OnName num="izumi"]
" Amane ......"
[cpg cn=true]

In the moment that the name came out of Shizuku 's mouth, Izumi 's shoulders twitched and reacted.
[cpg]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0072"]
[OnName num="shizuku"]
"......?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0065"]
[OnName num="izumi"]
"You can't get along with that girl!
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0073"]
[OnName num="shizuku"]
"What, what?
[cpg cn=true]

It was a sudden angry voice.
[cpg]

[FACE method="change_1" pos="4/5"]
It was too sudden and too abrupt.
[cpg]

Shizuku could not understand her sister's words and doubted her own ears.
[cpg]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0074"]
[OnName num="shizuku"]
"What did you just say?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Izumi0066"]
[OnName num="izumi"]
"Don't ever go out with this Amane Satonaka girl!"
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0075"]
[OnName num="shizuku"]
"What?　What? Why ......?
[cpg cn=true]



[WAIT time=100]
[VOICE f="Izumi0067"]
[OnName num="izumi"]
"Because I have to!
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0076"]
[OnName num="shizuku"]
"Why... why did you have to say that?　 Amane Did he do something to you?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Izumi0068"]
[OnName num="izumi"]
"..................
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0077"]
[OnName num="shizuku"]
"Sis!　Why?　You're my sister!
[cpg cn=true]

Shizuku This is a great way to get the most out of your time and money.
[cpg]

This is a great way to make sure you are getting the most out of your money.
[cpg]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0078"]
[OnName num="shizuku"]
"I'm not a delinquent, Amane you know.　It's not a bad idea.　It's a great way to make sure you're getting the most out of your money.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Izumi0069"]
[OnName num="izumi"]
".................."
[cpg cn=true]

Izumi In the event that you've got a lot more than one of these, you'll be able to get a lot more.
[cpg]

In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Shizuku0079"]
[OnName num="shizuku"]
"Big sister!　I'm not sure what to do.
[cpg cn=true]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_si_r_t4_1.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　夜　小雨


[OnName num="shinzi"]
"What the hell is this ......?"
[cpg cn=true]

When I got home, I was angry because I remembered the attitude of Amane today.
[cpg]

Izumi This is a great way to get the most out of your time and money.
[cpg]

It's the first day you've become lovers, and suddenly you've had a fight,.......
[cpg]

In the end, even after the committee meeting, I did not talk to Amane .
[cpg]

He Amane asked me to go home with him, but I ignored him and came home alone.
[cpg]

He wanted to show me how angry he was.
[cpg]

As was the case with Yoko , if you only listen to what the woman tells you, it will become second nature and you will end up being the butt of the woman.
[cpg]

This time, I will not make the same mistake.
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





[OnName num="shinzi"]
"......
[cpg cn=true]

I had expected this, but it was a message from Amane .
[cpg]




;//メッセージ画面


I'm sorry about earlier " Amane ".
[cpg]

I was jealous of Shinji for praising Kizaki so much.
[cpg]

Can you forgive me?
[cpg]




[OnName num="shinzi"]
"I'm not going to give you a ...... response!"
[cpg cn=true]

You should not be so easily broken here.
[cpg]

I'm not sure what to do, but I'm sure I'll be able to do it.
[cpg]

I put my phone aside and lay down on my bed and turn on my portable gaming device.
[cpg]

Come to think of it, I haven't played a game in a long time.
[cpg]

Today, I'm going to clear the game that I'm in the middle of conquering.
[cpg]

[SE f="se095"]
;//【ＳＥ】ゲーム音（ピコピコ）


[OnName num="shinzi"]
"I'm not sure what's going on here. What's going on ......?"
[cpg cn=true]

Soon after, I got stuck, and when I picked up my phone to look up the strategy, ......
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





[OnName num="shinzi"]
"Again, ......."
[cpg cn=true]

Amane contacted me.
[cpg]




;//メッセージ画面


" Amane " I'm so sorry.
[cpg]

I'm not going to say anything like that again, so please forgive me.
[cpg]



[OnName num="shinzi"]
"You're an emoticon. ......"
[cpg cn=true]

I close my phone and access the attack site.
[cpg]

I don't like it when people apologize with emoticons because it makes them look like they're joking.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to do. Can you understand this kind of Fufu!"
[cpg cn=true]

I concentrate on the game to shake off my bad mood.
[cpg]

But ......
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信


;//メッセージ画面





" Amane " Are you seeing my messages?
[cpg]

What are you doing right now?　I'm sorry.　Eating?
[cpg]

If you see it, please respond whenever you can.
[cpg]

I'm so sorry.
[cpg]




[SE f="se096"]
;//【ＳＥ】ゲーム音（エキサイト）





[OnName num="shinzi"]
"Oh, my God!　Holy shit!"
[cpg cn=true]

While I was playing the game, messages arrived on my phone one after another.
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





;//メッセージ画面





" Amane " Are you angry?
[cpg]

Are you so angry that you don't want to reply?
[cpg]

What can I do to make you forgive me?
[cpg]

I'll do anything, so please forgive me.
[cpg]




[SE f="se031"]
;//【ＳＥ】ゲーム音に被ってメール着信





;//メッセージ画面


" Amane " Please.
[cpg]

Please forgive me. Please.
[cpg]

I apologize from the bottom of my heart. So please.
[cpg]

Please reply to me.
[cpg]




[SE f="se031"]
;//【ＳＥ】ゲーム音に被ってメール着信





;//メッセージ画面


" Amane " I'm really sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm so sorry.
[cpg]




[SE f="se031"]
;//【ＳＥ】ゲーム音に被ってメール着信





[OnName num="shinzi"]
"Oh, my God!"
[cpg cn=true]

I was so close to defeating the boss character, but I failed because I was worried about the ringtone.
[cpg]

[OnName num="shinzi"]
"I'm so angry!"
[cpg cn=true]

It might be a matter of taking it out on me, but I was so frustrated that I had to take the time to get to the final stage again that I finally turned off my phone.
[cpg]

;//暗くなるスマホ画面


[OnName num="shinzi"]
"'Alright, I can concentrate now...'
[cpg cn=true]

At that moment, the game was the first thing on my mind, and I didn't think about how Amane was feeling.
[cpg]

And I thought it was normal for everyone to have small fights like this, and that we could make up for it quickly.
[cpg]

[SE f="se097"]
;//【ＳＥ】ゲーム音（クリア）


[OnName num="shinzi"]
"Yay!　I've cleared it up!"
[cpg cn=true]

The effort was worth it, and by the time I cleared the game, it was already 2am.
[cpg]

This is too much work on a weekday, no matter how much I try.
[cpg]

[OnName num="shinzi"]
"Let's go to bed ......."
[cpg cn=true]

I was so sleepy that I didn't turn on my phone and fell asleep.
[cpg]




[free time=800]

[BGM f="eye2"]
[BG f="black.ui" time=1000]
;//ブラックアウト


I wonder how much time has passed since I closed my eyes .......
[cpg]

[SE f="se017"]
;//【ＳＥ】玄関チャイム


[OnName num="shinzi"]
"..............."
[cpg cn=true]

[SE f="se017"]
;//【ＳＥ】玄関チャイム


A dream ......?
[cpg]

[SE f="se017"]
;//【ＳＥ】玄関チャイム


No,......
[cpg]

[OnName num="shinzi"]
"Not a dream. ......?
[cpg cn=true]

[SE f="se017"]
;//【ＳＥ】玄関チャイム


;//電気つける

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_si_r_t1_0.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　早朝　豪雨


[OnName num="shinzi"]
"What time ......4 is it?
[cpg cn=true]

It's still dark outside at four in the morning.
[cpg]

Who would ring the doorbell at this hour?
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

But while I was doing so, ......
[cpg]

[SE f="se025"]
;//【ＳＥ】玄関チャイム連打


[OnName num="shinzi"]
"I'm not sure what to say.　Who's that?"
[cpg cn=true]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//ブラックアウト


[SE f="se072"]
;//【ＳＥ】ドドドドド


In the event that you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

;//loop
[SE f="se005" loop=true]
;//【ＳＥ】激しい雨と風


[OnName num="shinzi"]
"I'm not sure what to do.
[cpg cn=true]

As soon as I opened the door, a heavy rain and wind blew at me.
[cpg]

This is a great way to make sure you are getting the most out of your vacation.
[cpg]

;//ビショ濡れ土下座の雨音


[free time=800]
;**【ＣＧ】ev_14_0 ***********************
[CG id=6 index=0 time=1000]
;*****************************************
;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

[WAIT time=100]
[VOICE f="Amane0471"]
[OnName num="amane"]
".................."
[cpg cn=true]

[OnName num="shinzi"]
"Oh, Amane !
[cpg cn=true]

What's more, Amane is on his knees in front of the entrance, soaking wet.
[cpg]

[OnName num="shinzi"]
"What are you doing ......?"
[cpg cn=true]

It's a good idea to have a good idea of what you're doing.
[cpg]

[OnName num="shinzi"]
"What are you doing at this hour?
[cpg cn=true]

Then, without looking at my face, Amane rubbed his head against the wet ...... ground.
[cpg]


[WAIT time=100]
[VOICE f="Amane0472"]
[OnName num="amane"]
"I'm sorry, please forgive me."
[cpg cn=true]

And then he muttered.
[cpg]

[OnName num="shinzi"]
"What...e...... eh...?"
[cpg cn=true]

My head was in turmoil.
[cpg]

This is a great way to make sure that you get the most out of your time and money.
[cpg]

There is no way it was because of that small fight.
[cpg]

People don't get down on their knees for things like that.
[cpg]

So my brain was confused.
[cpg]


[WAIT time=100]
[VOICE f="Amane0473"]
[OnName num="amane"]
"I'm sorry. Please forgive me."
[cpg cn=true]

[SE f="se029"]
;//【ＳＥ】ビチャッ！



[WAIT time=100]
[VOICE f="Amane0474"]
[OnName num="amane"]
"I'm sorry. Please forgive me."
[cpg cn=true]

[SE f="se029"]
;//【ＳＥ】ビチャッ！


[OnName num="shinzi"]
"Wait a minute. ......"
[cpg cn=true]

Every time Amane lowered his head, his forehead hit the soggy soil.
[cpg]


[WAIT time=100]
[VOICE f="Amane0475"]
[OnName num="amane"]
"I'm sorry, please forgive me.
[cpg cn=true]

[SE f="se029"]
;//【ＳＥ】ビチャッ！



[WAIT time=100]
[VOICE f="Amane0476"]
[OnName num="amane"]
"I'm sorry, please forgive me."
[cpg cn=true]

[SE f="se029"]
;//【ＳＥ】ビチャッ！


[OnName num="shinzi"]
"No, no. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0477"]
[OnName num="amane"]
"I'm sorry, please forgive me. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry.
[cpg cn=true]

[SE f="se029"]
;//【ＳＥ】ビチャッ！（連打）


[OnName num="shinzi"]
" Amane , stop!　I forgive you!　I forgive you!　No!
[cpg cn=true]

[free time=800]
;**【ＣＧ】ev_14_a ***********************
;*****************************************


[WAIT time=100]
[VOICE f="Amane0478"]
[OnName num="amane"]
"Really ......?"
[cpg cn=true]

Brown mud dripped from the forehead of Amane who raised his face.
[cpg]

It's a good idea to have a good idea of what you're doing.
[cpg]

[OnName num="shinzi"]
"I've already figured it out,.......
[cpg cn=true]





[WAIT time=100]
[VOICE f="Amane0479"]
[OnName num="amane"]
"I apologized to you in a message, but you didn't respond,......, so I'm really angry... I thought you hated me... but I didn't want you to hate me,....... I wanted you to forgive me ...... but I didn't know what to do... ......"
[cpg cn=true]

I'm not sure what to do. Amane
[cpg]

This is a great way to get the most out of your time and money.
[cpg]

[OnName num="shinzi"]
"And anyway, come inside!
[cpg cn=true]

Thankful that my mom was on night shift for today, I stood Amane up and invited her to come inside the house.
[cpg]

But ......
[cpg]

[free time=800]
;**【ＣＧ】ev_14_b ***********************
;*****************************************

[BGM f="h2"]

[WAIT time=100]
[VOICE f="Amane0480"]
[OnName num="amane"]
"I'm sorry, I can't do that!　I'm a bad person!　If I go in, I'll ruin Shinji your house!"
[cpg cn=true]

[OnName num="shinzi"]
"This is not the time to be talking like that!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0481"]
[OnName num="amane"]
"It's okay. Don't worry about me. I just want Shinji to forgive me!
[cpg cn=true]

[OnName num="shinzi"]
"That's enough!
[cpg cn=true]





[WAIT time=100]
[VOICE f="Amane0482"]
[OnName num="amane"]
"Forgive me, ....... Forgive me, .......
[cpg cn=true]

As if mumbling, Amane continues to apologize in the rain.
[cpg]

The scene is... The scene is bizarre. You can't help but feel...
[cpg]

This is a great way to make sure that you do not have to worry about your own personal safety.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]



[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト





After repeating the question of apology and forgiveness, Amane finally raised his head.
[cpg]

;//loop
[stopse g=2]
[stopse g=6]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
[BG f="b_ex_sk_t1_0.ui" time=1000]
;//【ＢＧ】空　早朝　豪雨

;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]



[OnName num="shinzi"]
"............"
[cpg cn=true]

Amane It's not that I don't like it, it's that I don't like it.
[cpg]

Now Amane is the same girl I know and love.
[cpg]

However, the Amane of a while ago is ......?
[cpg]

I'm not sure if Amane knows what I'm thinking or not, but she laughs as she brushes her wet hair out of her face.
[cpg]

;//[FG f="amane_p5_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0483"]
[OnName num="amane"]
"I'm glad. I'm glad you made up with Shinji ."
[cpg cn=true]

[OnName num="shinzi"]
"Yes, ....... Yes, ......."
[cpg cn=true]

The night had long since passed.
[cpg]

The rain is still ...... not going to let up.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


;#############################################################


;#############################################################





;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_3f_t2_1.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午後　小雨

[WAIT time=2000]

[BG f="b_s_3f_t1_0_deskup.ui" time=1000]

[WAIT time=1000]

[OnName num="shinzi"]
"Huh .......
[cpg cn=true]

In class, I was sleepy.
[cpg]

In addition to staying up late, the events of this morning had combined to create a peak of fatigue.
[cpg]

[OnName num="teacher"]
"This b squared is the a of adding, and this x is the .......
[cpg cn=true]

I can't really think of any math.
[cpg]




[SE f="se047"]
;//【ＳＥ】バイブ





[OnName num="shinzi"]
"Who the hell is ......?"
[cpg cn=true]

The message arrived in the middle of class, I wondered and checked my phone secretly.
[cpg]

[OnName num="shinzi"]
"......!"
[cpg cn=true]




;//メッセージ画面


" Amane " We can go home together today, right? (*^_^*)
[cpg]


[BG f="b_s_3f_t2_1_Lup.ui" time=1000]
[FG f="amane_p6_01_a.ui" method="change_2" pos="1/4" time=1000]

[OnName num="shinzi"]
"............!"
[cpg cn=true]

When I looked at Amane , he was smiling towards me.
[cpg]

I wonder why he is so cheerful .......
[cpg]

In addition to that, it is possible to laugh so carefree now this morning .......
[cpg]

It's a good idea to have a little bit of time to think about it. Sorry.
[cpg]

When I typed my reply and looked at Amane , she seemed to have received my message and stared at her phone.
[cpg]

[FACE method="change_7" pos="1/4"]

At that moment, her face became clearly cloudy, and her fingers moved busily.
[cpg]


[BG f="b_s_3f_t1_0_deskup.ui" time=0]


[FO pos="1/4" time=0]

[SE f="se047"]
;//【ＳＥ】バイブ





;//メッセージ画面


" Amane " Is that so?
[cpg]

Well then, it can't be helped.
[cpg]




[OnName num="shinzi"]
"...... Ho."
[cpg cn=true]

It should be a shame that we can't go home together, but for some reason I was relieved.
[cpg]

Why ...... do you like Amane me so much?
[cpg]

[OnName num="shinzi"]
"Ah...le......."
[cpg cn=true]

That's when I realized that I had a lot of unread messages on my phone.
[cpg]


[BGM f="danger"]


[OnName num="shinzi"]
"Gosh, 57!
[cpg cn=true]

Why so many?　Who the hell are they from ......?
[cpg]

I checked and found that it was a message from Amane that had arrived between midnight and dawn.
[cpg]

"I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry. I'm sorry.
[cpg]

[OnName num="shinzi"]
"It's .......
[cpg cn=true]

The content was filled with sorry.
[cpg]

I was stunned by the same string of letters, and then I looked at Amane and saw ......
[cpg]

[BG f="b_s_3f_t2_1_Lup.ui" time=0]

[FG f="amane_p6_01_a.ui" method="change_7" pos="1/4" time=0]
[WAIT time=100]
[VOICE f="Amane0484"]
[OnName num="amane"]
".........?"
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_2" pos="1/4" time=0]

She was still smiling at me.
[cpg]



[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト

[WAIT time=1000]



You've sent so many messages and not received a response, so you've come to that behavior .......
[cpg]

Was she that scared of me hating her?
[cpg]

In any case, it seems that you should reply properly from now on. ......
[cpg]



[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_ex_ff_t2_1.ui" time=1000]
;//【ＢＧ】ファストフード店　夜　雨





[OnName num="shinzi"]
"Welcome.
[cpg cn=true]

[OnName num="store_manager"]
"Hey, you don't look well."
[cpg cn=true]

[OnName num="shinzi"]
"Oh, I'm sorry. ......
[cpg cn=true]

That day, even at my part-time job, I was exhausted.
[cpg]

[OnName num="store_manager"]
"What's up?　Did she dump you?
[cpg cn=true]

[OnName num="shinzi"]
"No. ......
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0485"]
[OnName num="amane"]
" Shinji "
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

[OnName num="store_manager"]
"Oh, speak of the devil. Come in."
[cpg cn=true]

The manager greeted him with a cheerful voice, but I was astonished that Amane he had come.
[cpg]

I thought I had convinced him to refuse to go home with me,.......
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0486"]
[OnName num="amane"]
"I'd like to thank you for the lovely treat you gave me the other day. It was very delicious."
[cpg cn=true]

[OnName num="store_manager"]
"You can't really call it a treat, though. Thank you very much.
[cpg cn=true]

The manager is stretching the bottom of his nose to thank Amane properly.
[cpg]

In this way, the girlfriend is too good for me .......
[cpg]

[OnName num="shinzi"]
"What are you doing here?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0487"]
[OnName num="amane"]
"I thought I'd eat here.
[cpg cn=true]

[OnName num="shinzi"]
"I see.
[cpg cn=true]

It might be natural for Amane , who eats out all the time, to want to eat at a restaurant with me.
[cpg]

If I were her, I'm sure I would have done the same.
[cpg]

[OnName num="shinzi"]
"What should I get?"
[cpg cn=true]

I asked in a deliberately cheerful voice.
[cpg]

Then Amane smiled happily and ......
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0488"]
[OnName num="amane"]
"Party pack."
[cpg cn=true]

I said.
[cpg]

[OnName num="shinzi"]
"What?　You're going to eat that all by yourself?　No way."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0489"]
[OnName num="amane"]
"No, I'm gonna eat it with Shinji .
[cpg cn=true]

[OnName num="shinzi"]
"What?　I'm at work. ......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0490"]
[OnName num="amane"]
"I know. I'll wait for you. We'll go home and eat together.
[cpg cn=true]

[OnName num="shinzi"]
"But it's ...... until midnight. I think you should eat here and go home.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0491"]
[OnName num="amane"]
"Why?　Don't you want to eat with me?
[cpg cn=true]

[OnName num="shinzi"]
"No, but I'm starving. ......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0492"]
[OnName num="amane"]
"Don't worry. I'll wait for you.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah ......."
[cpg cn=true]


[FO pos="2/3" time=800]

Amane turned on his heel and sat down in an empty seat in the restaurant and continued to stare at me, smiling.
[cpg]

[OnName num="shinzi"]
"I don't know what to do. ......
[cpg cn=true]

[OnName num="customer"]
"Excuse me.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, yes!　Welcome!
[cpg cn=true]

However, because it was dinner time, more and more customers arrived, and it was no Amane longer enough.
[cpg]

And when the line of customers was finally dealt with, I looked at the seats and saw ......
[cpg]

[OnName num="shinzi"]
"Oh, is that ......?"
[cpg cn=true]

Amane was nowhere to be found.
[cpg]

I'm not sure if he gave up and went home because the restaurant was getting crowded.
[cpg]

[OnName num="shinzi"]
"If that's the case, why don't you buy one for ...... yourself?
[cpg cn=true]

Feeling bad for Amane for leaving without saying anything, I decided to call her after work.
[cpg]

[OnName num="store_manager"]
"One cheeseburger!"
[cpg cn=true]

[OnName num="shinzi"]
"Two, nuggets, please!"
[cpg cn=true]




;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
[BG f="b_ex_tw_t2_2.ui" time=1000]
;//【ＢＧ】街　夜　大雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]


;//【雨、大雨】


[SE f="se004"]
;//【ＳＥ】雨の音（わりと激しく）


;//鉄扉開く





[OnName num="shinzi"]
"'Ugh, I'm finally done ......'
[cpg cn=true]

By the time I left the restaurant, it was around eleven in the morning.
[cpg]

Exhaustion was the name of the game.
[cpg]

However, as I opened the door and held out my umbrella, I saw something outrageous jump into my eyes.
[cpg]




[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0493"]
[OnName num="amane"]
"It's .......
[cpg cn=true]

There was a figure of her standing there without an umbrella.
[cpg]

You can easily imagine that she must have been waiting for me for a long time, seeing as how she was wet.
[cpg]

[OnName num="shinzi"]
Amane "I'm not sure what to say. What are you doing without an umbrella?
[cpg cn=true]

I know that she likes the rain, but it came out of her mouth as a matter of course.
[cpg]

[FG f="amane_p6_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0494"]
[OnName num="amane"]
"I'm not a fan of umbrellas. But did you see my message from yesterday?
[cpg cn=true]

I wonder if the message is more important than the current situation.
[cpg]

Anyway, you can go somewhere to take shelter from the rain...
[cpg]

[OnName num="shinzi"]
"Anyway, you can't do that. You'll get cold.
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0495"]
[OnName num="amane"]
"Yeah, I'll stop if Shinji says so. So, ......?
[cpg cn=true]

[OnName num="shinzi"]
"What?　Where are you going?　 Amane ......?"
[cpg cn=true]

Amane grabs my hand and pulls me towards somewhere.
[cpg]

It's not my house, it's not her house, and it's not in the valley of the buildings,.......
[cpg]


;//loop
[stopse g=2]
[stopse g=6]

;//;#############################################################


;//;#############################################################

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="h1"]
[BG f="b_ex_ru_t1_1.ui" time=1000]
;//【ＢＧ】廃墟　夜　雨





[OnName num="shinzi"]
"It's ...... here."
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

It's a good idea to have a good idea of what you're doing. It is a place that outsiders should not enter, at least.
[cpg]

[FG f="amane_p7_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0496"]
[OnName num="amane"]
"Isn't it nice...?"
[cpg cn=true]

Amane In the event that you have any questions concerning where and how to use the internet, you can contact us at our own web site.
[cpg]

This is a great way to get the most out of your day.
[cpg]

I'm not sure what to make of it, but I'm sure it's worth it. I've been doing this for a while now, but I'm not sure I'm ready for it. Amane likes to touch people's skin like this.
[cpg]

This is a great way to make sure you are getting the most out of your time with your family.
[cpg]




;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_ex_tw_t2_1.ui" time=1000]
;//【ＢＧ】街　夜　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]


;//【雨、大雨】


;//傘を差して小走りの陽子


[SE f="se006"]
[SE f="se131"]
;//【ＳＥ】雨の中を小走り


[FG f="youko_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0097"]
[OnName num="youko"]
"I'm not sure what to do.
[cpg cn=true]

Yoko In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

It's a great way to get to know your family and friends.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0098"]
[OnName num="youko"]
"It's not good, it's not good. ...... Oh?"
[cpg cn=true]

[SE f="se032"]
;//【ＳＥ】子猫の鳴き声


That's when it happened.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0099"]
[OnName num="youko"]
"What's wrong with you ......? You should not be in this place.
[cpg cn=true]

You can't help but leave the kitten, which is soaking wet from the pouring rain, alone.
[cpg]

Yoko A lot of the time, you'll find a lot of people who are just looking for a way to make a living.
[cpg]

[SE f="se032"]
;//【ＳＥ】子猫の鳴き声


[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0100"]
[OnName num="youko"]
"I'm sure you'll be happy to hear that.　Is it Nora?　Where's your mommy?"
[cpg cn=true]

Try as he might, there was no answer, and Yoko he scanned the area.
[cpg]

I'm not sure what to make of that.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0101"]
[OnName num="youko"]
"There is no...? I'd like to take him home, but we have two doggies .......
[cpg cn=true]

Yoko In the event that you've got a lot more than one, you'll be able to take a look at a few of these.
[cpg]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0102"]
[OnName num="youko"]
"It's a good idea.　I'm not sure what to do.　Wait ......."
[cpg cn=true]

Yoko In the event that you have any questions concerning where and how to use the internet, you can contact us at the web site.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0103"]
[OnName num="youko"]
"To the roof,......, to the roof,......."
[cpg cn=true]

It's not just a sermon, it's a thunderstorm. ...... I sighed as I looked at my watch.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_ex_ru_t1_0.ui" time=1000]
;//【ＢＧ】廃墟　夜　雨



;// キャラクターの前面に雨を表示
;// 通常
;//[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]


;//【雨、大雨】



[SE f="se032"]
;//【ＳＥ】子猫の鳴き声


[FG f="youko_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0104"]
[OnName num="youko"]
"Where are you going?
[cpg cn=true]

This is a great way to get the most out of your time and money.
[cpg]

This is a great way to get the most out of your time and money.
[cpg]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0105"]
[OnName num="youko"]
"Oh, wait!
[cpg cn=true]

The ungrateful kitten did not even look back at Yoko , but quickly ran off somewhere.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0106"]
[OnName num="youko"]
"I can't believe it,....... Where are we ......?"
[cpg cn=true]

Yoko In the event that you have any questions regarding where by and how to use the internet, you can call us at our own web site.
[cpg]

There ......
[cpg]




;//エフェクト
;//前面に雨 停止
;//[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//主人公達の視点へ

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_ex_ru_t1_0.ui" time=1000]
;//【ＢＧ】廃墟　夜　雨



[FG f="amane_p5_02_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0497"]
[OnName num="amane"]
"I'm not sure what to say, but I'm going to say it.
[cpg cn=true]

[OnName num="shinzi"]
"I like...I like you, Amane ..."
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0498"]
[OnName num="amane"]
"I love you too!"
[cpg cn=true]

They hugged each other with full force and whispered their love to each other.
[cpg]

This is a great way to make sure you are getting the most out of your investment.
[cpg]

Amane You will find a lot of things that you can do to make your life easier.
[cpg]




So ......
[cpg]

I'm not sure if I'm going to be able to do that.
[cpg]

You can find a lot of things that you can do to make your life easier.
[cpg]

;#############################################################


;#############################################################


;//////////////////////////////////////////////////////////////////////////


[STOPBGM]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_ex_ru_t1_1.ui" time=1000]
;//【ＢＧ】廃墟　夜　雨





;//[FG f="youko_p1_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0107"]
[OnName num="youko"]
".................."
[cpg cn=true]



[jump storage="ep007.ks" target="*start"]
