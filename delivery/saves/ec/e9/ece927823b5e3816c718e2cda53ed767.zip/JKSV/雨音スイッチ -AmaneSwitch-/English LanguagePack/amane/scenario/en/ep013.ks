*start

;#################################################
*Ep013|Here we go.
;#################################################
[SCENE id=13]

;//エフェクト

[stopse g=2]
[stopse g=6]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
[BG f="b_si_d_t2_2.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　夕方　雨


[OnName num="shinzi"]
"I'm back!
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_2" pos="2/5" time=800]
[FG f="yukika_p5_01_a.ui" method="change_1" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Amane0685"]
[OnName num="amane"]
"Welcome home.
[cpg cn=true]

[OnName num="mother"]
"Welcome home.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0059"]
[OnName num="yukika"]
"Welcome home. ......
[cpg cn=true]

When I came home with a sinking feeling, I found my mother, Yukika sister, and Amane around the dining table.
[cpg]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0686"]
[OnName num="amane"]
"Where have you been?　I've been waiting for you."
[cpg cn=true]

[OnName num="shinzi"]
"Why ......?"
[cpg cn=true]

I just heard about Kizaki Sisters and I can t look Amane in the eye.
[cpg]

Is Amane siphoning off money from his father ......?
[cpg]

That's why he's able to live in such a luxurious apartment ......?
[cpg]

[OnName num="mother"]
"He came to visit you, so I invited him to dinner. I'm ready to go, so come on over.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, yeah. ......
[cpg cn=true]

Throughout the meal, my mother talked only to Amane , oblivious to my thoughts.
[cpg]

[OnName num="mother"]
"Are you feeling okay?　Don't ever do that again, okay?
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0687"]
[OnName num="amane"]
"Yes. I'm taking my medication as promised.
[cpg cn=true]

[OnName num="mother"]
"Yes. You don't want to hurt yourself. You'll regret it. If you're having a hard time, just come to me.
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0688"]
[OnName num="amane"]
"Thank you very much. When you say that, I feel like I'm getting better.
[cpg cn=true]

[OnName num="mother"]
"Ho ho ho!　Well, get better and better!　Eat this, too. Oh, and this!
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_2" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0689"]
[OnName num="amane"]
"Okay.
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0060"]
[OnName num="yukika"]
"..................
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0690"]
[OnName num="amane"]
"You're a very good cook, aren't you, Auntie?
[cpg cn=true]

[OnName num="mother"]
"Yes, she is!
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0691"]
[OnName num="amane"]
"Yes, she is. And she's so cheerful and kind, I envy Shinji .
[cpg cn=true]

[OnName num="mother"]
"What?　 Shinji
[cpg cn=true]

[OnName num="shinzi"]
"..................
[cpg cn=true]

That day, the dining table was the sole domain of my mom and Amane .
[cpg]

Yukika This is a great way to get the most out of your time with your family and friends.
[cpg]

And when the meal was over, the rain outside seemed to increase in intensity, and a loud noise could be heard in the house.
[cpg]


[SE f="se005"]
;//【ＳＥ】外の激しい雨


[OnName num="mother"]
"'Oh my God, it's raining so hard. ......
[cpg cn=true]

[OnName num="shinzi"]
"' Amane ......, I'm driving...'
[cpg cn=true]

[FG f="yukika_p5_01_a.ui" method="change_2" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yukika0061"]
[OnName num="yukika"]
"'Aunt, why don't you give her a lift?
[cpg cn=true]

I was about to call out to Amane , when suddenly Yukika sister suggested so.
[cpg]

[FG f="amane_p6_02_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0692"]
[OnName num="amane"]
"Yeah, but ......"
[cpg cn=true]

[OnName num="mother"]
"You're right, this rain is a bit much. I'll give you a ride home, Amane girl."
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0693"]
[OnName num="amane"]
"Excuse me.
[cpg cn=true]

[OnName num="shinzi"]
"Okay, I'll go with .......
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0062"]
[OnName num="yukika"]
" Shinji , I'm sorry, but you're gonna have to help me clean up.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, .......
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0063"]
[OnName num="yukika"]
"Please.
[cpg cn=true]

Yukika In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

[OnName num="mother"]
"It's okay, the car is only a few minutes away.
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_2" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0694"]
[OnName num="amane"]
"I'll see you tomorrow, Shinji .
[cpg cn=true]

[OnName num="shinzi"]
"Oh, yeah, ......, see you tomorrow.
[cpg cn=true]

[free time=800]

To tell the truth, I was a little relieved.
[cpg]

I don't know what I'd say if I were alone with Amane right now.
[cpg]

As my mom and Amane left the house, my Yukika sister grabbed my arm and sat me down on the couch. She sat down next to me and looked me in the eye and said.
[cpg]

[FG f="yukika_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0064"]
[OnName num="yukika"]
"I want you to Shinji listen to something.
[cpg cn=true]

[OnName num="shinzi"]
"What ......?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0065"]
[OnName num="yukika"]
"Uncle ......, the cause of your father's death. ......
[cpg cn=true]

[OnName num="shinzi"]
"It was an accident.　He was trying to save a woman at a railroad crossing. ......
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0066"]
[OnName num="yukika"]
"Yeah. But that woman is ...... Amane your mother.
[cpg cn=true]

[STOPBGM]

[OnName num="shinzi"]
"...............?
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to say.
[cpg cn=true]

[BGM f="rain"]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0067"]
[OnName num="yukika"]
"I realized this when I pulled over the documents from that time. This is a great way to make sure you are getting the most out of your vacation. So I went to .......
[cpg cn=true]

[OnName num="shinzi"]
"What the fuck was on there?
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0068"]
[OnName num="yukika"]
"The name on the obituary was Hirose Mizrahi. And her eldest daughter's name was ...... Amane . Maybe Hirose is her father's surname.
[cpg cn=true]

[OnName num="shinzi"]
"Then there is the possibility that it is another person .......
[cpg cn=true]

It's a good idea to have a good idea of what you're doing.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0069"]
[OnName num="yukika"]
Misuzu "In the event that you have any questions concerning where and how to use the internet, you can call us at our own web site.
[cpg cn=true]

[OnName num="shinzi"]
"No way...right ......?"
[cpg cn=true]

My dad's death was caused by Amane 's mother?
[cpg]

My dad died trying to save Amane my mom's ...... life?
[cpg]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0070"]
[OnName num="yukika"]
"I know it's hard for you. I'm sure you'll find a lot of people who'd like to know more about this.　I couldn't help but tell ...... and Shinji my aunt how I felt when that happened. ......"
[cpg cn=true]

[OnName num="shinzi"]
"My mother's ...... feelings ......
[cpg cn=true]

My mom has been raising me through gritted teeth since the day my dad died.
[cpg]

This is a great way to make sure you get the most out of your time with your family and friends.
[cpg]

Even if it was the end of the night shift, even if that day was the semi-night shift, even if it was raining, even if it was windy, he always ...... went.
[cpg]

This is because I loved him deeply, and if my mother knew that I was dating the daughter of the woman who caused his death,.......
[cpg]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0071"]
[OnName num="yukika"]
"Wouldn't you understand, ......?　 Mr. Amane and Shinji shouldn't be dating ......."
[cpg cn=true]

[OnName num="shinzi"]
".................."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0072"]
[OnName num="yukika"]
"It's hard now, but one day you'll be able to forget. I'll be there ...... for you."
[cpg cn=true]

[FG f="yukika_p7_01_a.ui" method="change_7" pos="2/3" time=800]

Saying that, Yukika my sister hugged me.
[cpg]

But ......
[cpg]

[OnName num="shinzi"]
"But ......, I can't tell ...... Amane that.
[cpg cn=true]

If you tell Amane that you're leaving ...... because your father died because of your mother, she'll probably try to kill herself again.
[cpg]

If she does, I'll be the one driving Amane her to her death.
[cpg]

;/[FACE method="change_2" pos="2/3"]
[FG f="yukika_p5_01_a.ui" method="change_2" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Yukika0073"]
[OnName num="yukika"]
"Don't worry. Don't worry. Amane understands. ......
[cpg cn=true]

[OnName num="shinzi"]
"................"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0074"]
[OnName num="yukika"]
"I had a little chat with her while she was cooking dinner.
[cpg cn=true]

[OnName num="shinzi"]
"You just told Amane that story on ......?　How could you do that without permission?
[cpg cn=true]

You will find a lot of things that you can do to make your life easier.
[cpg]

Amane You will be able to get a lot more than just a few of them.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0075"]
[OnName num="yukika"]
"This is a great way to make sure you are getting the most out of your money. I'm not sure what to make of it.
[cpg cn=true]

[OnName num="shinzi"]
"So what?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0076"]
[OnName num="yukika"]
"Get a grip, Shinji . You Amane listened to me without saying a word.
[cpg cn=true]

[OnName num="shinzi"]
"So, what did ...... you say?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0077"]
[OnName num="yukika"]
She said, "Give me some time. She seems smart, so she will probably break up with me soon. When she does, Shinji ......, just break up with her."
[cpg cn=true]

[OnName num="shinzi"]
".................."
[cpg cn=true]

I wonder what Amane was thinking when he replied that?
[cpg]

What did he think about the relationship between his mother and my father?
[cpg]

I'm not sure what to do.
[cpg]

That way, we could both think about the story she Yukika had told me.
[cpg]

Tomorrow ......, I'll talk to Amane .
[cpg]

And we'll think about the future together.
[cpg]

I was sure that tomorrow would be the same as today.
[cpg]

At this time, I was still ......
[cpg]




;//エフェクト

;//loop
[stopse g=2]
[stopse g=6]

;//慎二の母の車の中


[SE f="se098"]
;//【ＳＥ】自動車


[free time=800]
;**【ＣＧ】ev_40_0 ***********************
[CG id=12 index=0 time=1000]
;*****************************************

[BGM f="healing"]



With her son's girlfriend in the passenger seat, the Shinji mother felt itchy, embarrassed and happy.
[cpg]

Will my son marry this girl in the future?
[cpg]

No, no, no, that's too early to tell.
[cpg]

[OnName num="mother"]
"'Do you think about the future, Amane girl?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0695"]
[OnName num="amane"]
"Future ......."
[cpg cn=true]

[OnName num="mother"]
"You know, your dreams include work, marriage...
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0696"]
[OnName num="amane"]
"Marriage. ......
[cpg cn=true]

[OnName num="mother"]
"Oh, my God, that's a little too fast for you, Auntie.
[cpg cn=true]

[STOPBGM]

[WAIT time=100]
[VOICE f="Amane0697"]
[OnName num="amane"]
"Excuse me, Auntie. ......
[cpg cn=true]

[OnName num="mother"]
"What?　What's wrong?　Suddenly."
[cpg cn=true]

The cheerful mother of Shinji did not notice the darkness in Amane 's voice.
[cpg]

[BGM f="eye2"]

[WAIT time=100]
[VOICE f="Amane0698"]
[OnName num="amane"]
"I thought I ought to apologize to my aunt .......
[cpg cn=true]

[OnName num="mother"]
"Why are you apologizing to me, Amane ?　 Is it something about Shinji ?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0699"]
[OnName num="amane"]
"No, sir. It's not about Shinji . I owe my aunt an apology.
[cpg cn=true]

[OnName num="mother"]
"To me?　Oh, you mean for leaving dessert?　Then don't worry, you can have Shinji tomorrow's snack at ......."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0700"]
[OnName num="amane"]
"It's my mother's fault that ...... your aunt's husband died.
[cpg cn=true]

[OnName num="mother"]
"What ......?"
[cpg cn=true]

Here, for the first time, my hands trembled as I gripped the steering wheel.
[cpg]

There is something strange ...... about Amane .
[cpg]


[WAIT time=100]
[VOICE f="Amane0701"]
[OnName num="amane"]
"It was my mother who was at the crossing. Your husband died trying to save my mother. If it wasn't for my mother, your husband wouldn't have been hit by the train.
[cpg cn=true]

[OnName num="mother"]
"Wait, Amane you ......, where did you ...... get that?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0702"]
[OnName num="amane"]
"My mother was Hirose a water bell. Don't you remember me? The Hirose water bell was the annoying suicidal person who got your husband involved. I'm sorry about my mother. But thank you."
[cpg cn=true]

[OnName num="mother"]
"Yeah. ......"
[cpg cn=true]

The mother of Shinji is not even given time to notice that her head is becoming confused by Amane , who connects more and more words without exhaling.
[cpg]


[WAIT time=100]
[VOICE f="Amane0703"]
[OnName num="amane"]
"Thank you for trying to help my mother. I would like to express my sincere gratitude to your late husband. Thank you very much.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0704"]
[OnName num="amane"]
"But I'm sorry. I'm sorry that he died. It was my mother's fault, I'm sorry. I have no choice but to apologize on her behalf. I'm sorry, I'm sorry, I'm sorry."
[cpg cn=true]

[SE f="se084"]
;//【ＳＥ】ガスッガスッガスッ


While banging his head against the dashboard with gasps, Amane repeats his apology like a broken recorder.
[cpg]

The mother of Shinji was screaming with the brakes.
[cpg]

[OnName num="mother"]
"'Oh, Amane stop it, ...... stop it!　Stop it!"
[cpg cn=true]

[SE f="se050"]
;//【ＳＥ】急ブレーキ


[OnName num="mother"]
"I'm sorry, but ...... you have to get off here. ......"
[cpg cn=true]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_ex_tw_t2_2.ui" time=1000]
;//【ＢＧ】街　夜　大雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]


;//【雨、大雨】


[SE f="se015"]
;//【ＳＥ】ドアロック解除


[SE f="se004"]
;//【ＳＥ】土砂降り


After getting out of the car, Amane stood in the crazy rain and still kept bowing to Shinji her mother.
[cpg]

[FG f="amane_p5_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0705"]
[OnName num="amane"]
"I'm sorry, I'm sorry, I'm sorry..."
[cpg cn=true]

[OnName num="mother"]
".................."
[cpg cn=true]

Shinji In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

I think she just wanted to get away from that place.
[cpg]

That's how heavy the fact that was confronted was.
[cpg]

;#############################################################


;#############################################################

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[stopse g=2]
[stopse g=6]

[SE f="se101"]
;//【ＳＥ】アクセル

[free time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="sir"]
[BG f="b_ex_sk_t3_1.ui" time=1000]
;//【ＢＧ】空　夜　大雨

[WAIT time=1000]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]


;//【雨、大雨】


;//フロントガラスを拭うワイパー最高速


[SE f="se100"]
;//【ＳＥ】ワイパー


[OnName num="mother"]
"No way...no way ...... no way ...... no way ...... Shinji ."
[cpg cn=true]

I'm not sure what to do.
[cpg]

The daughter of that woman is the lover of her beloved son .......
[cpg]

I'm not sure if this is a trick of God or what.
[cpg]

Why is such a painful reality only given to me?
[cpg]

[OnName num="mother"]
".................."
[cpg cn=true]

The repetitive motion of the windshield wipers wiping away the rain that hits the windshield with a bang.
[cpg]

I'm not sure what to make of it.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

I told him that it was raining and that he should go back to .......
[cpg]

He went out and did not come back.
[cpg]

If only I had stopped him more forcefully. ......
[cpg]

I should have shouted at him more to stop him.
[cpg]

You should have left the suicidal person alone and let him die if he wanted to.
[cpg]

And yet, he died to save a woman who was about to die.
[cpg]

Shinji is a lot like that man.
[cpg]

It is a character that cannot leave a person in trouble alone.
[cpg]

That's why that girl was saved by Shinji .
[cpg]

You should not have invited him to your home as a hypocrite.
[cpg]

I should have opposed the relationship at the time of the suicide attempt.
[cpg]

I'm not sure what Shinji will go through this time ...... because of my error in judgment.
[cpg]

I wonder if Shinji will also die because of that girl .......
[cpg]

[OnName num="mother"]
"I hate ....... I hate ....... Oh no!
[cpg cn=true]

[free time=400]
[BG f="white.ui" time=1000]
;//【ＢＧ】ブラックアウト



[SE f="se051"]
;//【ＳＥ】衝突音

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[WAIT time=2000]

[BG f="black.ui" time=2000]
[WAIT time=2000]
[BGM f="insecurity"]
[BG f="b_si_d_t3_1.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　夜　大雨
[WAIT time=1000]



[OnName num="shinzi"]
".................."
[cpg cn=true]

[FG f="yukika_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0078"]
[OnName num="yukika"]
".................."
[cpg cn=true]

My Yukika sister and I have been silent and downcast ever since.
[cpg]

There is nothing more to say, nothing more to ask.
[cpg]


[WAIT time=100]
[VOICE f="Yukika0079"]
[OnName num="yukika"]
"It's ......... late.
[cpg cn=true]

Yukika The sister looked at the clock.
[cpg]

I'm sure it's raining and there's a traffic jam.
[cpg]

[SE f="se021"]
;//【ＳＥ】固定電話


[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0080"]
[OnName num="yukika"]
"Call ......."
[cpg cn=true]

[free time=1000]
Since I didn't show any sign of moving, Yukika my sister picked up the phone.
[cpg]

[SE f="se022"]
;//【ＳＥ】電話取る


;//[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0081"]
[OnName num="yukika"]
"Yes, yes, yes, yes. What?　I'm sorry, can you try ...... again?
[cpg cn=true]

[OnName num="shinzi"]
"......?"
[cpg cn=true]

This is a great way to make sure that you get the most out of your time with your family and friends. Yukika I sensed something unsettling in her tone, and when I turned around from the couch, she Yukika who was holding the phone was also looking back at me.
[cpg]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0082"]
[OnName num="yukika"]
"My aunt was in a ...... accident. ......
[cpg cn=true]

[OnName num="shinzi"]
"What ......?
[cpg cn=true]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="sir"]
[BG f="b_h_cor_t1_0.ui" time=1000]
;//【ＢＧ】病院　霊安室　夜　大雨


;//横たわる母の遺体


[OnName num="police_officer"]
"She ...... swerved and hit a pole. She was killed instantly. ......
[cpg cn=true]

[FG f="yukika_p5_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0083"]
[OnName num="yukika"]
"Aunt!　Aunt!
[cpg cn=true]

My mother's corpse with a white cloth over her face.
[cpg]

I'm not sure what to make of it.
[cpg]

[OnName num="shinzi"]
"This is a great way to make sure you are getting the most out of your money.
[cpg cn=true]

This is a great way to make sure you are getting the most out of your money.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[OnName num="shinzi"]
"What are you doing, ......? You were bragging about your gold license!　Why did you ...... make a driving mistake or something!"
[cpg cn=true]

[OnName num="police_officer"]
"Um, ......, this is the witness, .......
[cpg cn=true]

;//move
[move from="2/3" to="4/5" ease="easeInOutSine" time=800]

;//[FG f="yukika_p5_01_a.ui" method="change_1" pos="4/5" time=800]

[FG f="amane_p5_02_a.ui" method="change_4" pos="2/5" time=800]

[WAIT time=100]
[VOICE f="Amane0706"]
[OnName num="amane"]
"............
[cpg cn=true]


[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0084"]
[OnName num="yukika"]
"You ......
[cpg cn=true]

The cops brought her to Amane and she grabbed him.
[cpg]

[move from="4/5" to="3/4" ease="easeInOutSine" time=400]

[WAIT time=100]
[VOICE f="Yukika0085"]
[OnName num="yukika"]
"What did you do?　What did you do to my aunt?
[cpg cn=true]

[OnName num="police_officer"]
"Hey, hey, hey!"
[cpg cn=true]

The Amane was being Yukika shaken by her sister, and her body was being shaken.
[cpg]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0707"]
[OnName num="amane"]
"I ...... don't understand anything ....... After I got out of the car, the car suddenly started ...... running at a great speed... and then I heard a terrible noise..."
[cpg cn=true]

[OnName num="shinzi"]
"....................."
[cpg cn=true]

Seeing that Amane is unharmed, it seems that Mom really did cause the accident alone.
[cpg]

[OnName num="police_officer"]
"There is no doubt that the other drivers were watching the scene. ......
[cpg cn=true]

[FACE method="change_4" pos="3/4"]

[move from="3/4" to="4/5" ease="easeInOutSine" time=400]

[OnName num="shinzi"]
"So... ......
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

No matter what, your mother is dead .......
[cpg]

She will never ...... come back to life again.
[cpg]

[OnName num="shinzi"]
"Mom ......."
[cpg cn=true]

The tears overflow on their own.
[cpg]

They flow and flow and ...... overflow on their own.
[cpg]

;//[FACE method="change_1" pos="2/5"]
[FO pos="2/5" time=800]
[FG f="amane_p7_02_a.ui" method="change_7" pos="3/6" time=800]
[FG f="yukika_p5_01_a.ui" method="change_4" pos="4/5" time=0]

[WAIT time=100]
[VOICE f="Amane0708"]
[OnName num="amane"]
" Shinji ......, I'm so sorry ......."
[cpg cn=true]

Amane rubbed my back gently.
[cpg]

But right after ...... I heard some unbelievable words.
[cpg]

[FACE method="change_6" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0709"]
[OnName num="amane"]
"But now ...... and Shinji are also with me.
[cpg cn=true]

Ears ringing, empty ears ...... must be the case.
[cpg]

I'm not sure what to make of it.
[cpg]

I'm not sure.　 Together with Amane ?　What's that?　What do you mean ......?
[cpg]

[OnName num="police_officer"]
"I'm sorry to bother you at a time like this, but ......, we're going to perform an autopsy on the body. ......
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0086"]
[OnName num="yukika"]
"Autopsy?
[cpg cn=true]

[OnName num="police_officer"]
"The accident could have been caused by a brain hemorrhage or a heart attack. ......
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0087"]
[OnName num="yukika"]
"Wait a minute, my father will be here soon, and then we can talk ....... Shinji , you're out."
[cpg cn=true]


[FG f="amane_p8_02_a.ui" method="change_1" pos="3/6" time=800]
[FG f="yukika_p5_01_a.ui" method="change_4" pos="4/5" time=0]
[WAIT time=100]
[VOICE f="Amane0710"]
[OnName num="amane"]
"Well, Shinji ......"
[cpg cn=true]

I can't see ahead through my tears. Amane takes me out.
[cpg]

[free time=800]


[SE f="se014"]
;//【ＳＥ】鉄扉開く


;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト

[BGM f="insecurity"]

[SE f="se004"]
;//【ＳＥ】土砂降り





Amane pulls me outside and moves to the back alley. This is a great way to make sure you are getting the most out of your vacation.
[cpg]

[FG f="amane_p5_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0711"]
[OnName num="amane"]
"I'll make you forget."
[cpg cn=true]

But then I saw his face.
[cpg]

No, ...... I was sure of that.
[cpg]

Because the Amane looks happy. I'm not sure what to say.
[cpg]

It's a great way to make sure you're getting the most out of your time with your family.
[cpg]

[OnName num="shinzi"]
".................."
[cpg cn=true]

The words Yoko and Kizaki Sisters go round and round in my head.
[cpg]

And then the words of Yukika sister are also intertwined with it and it becomes incomprehensible.
[cpg]

Why do you look so happy ......?
[cpg]

Why do you do this at such a time ......?
[cpg]

[OnName num="shinzi"]
"What the hell is this ......?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0712"]
[OnName num="amane"]
"What?
[cpg cn=true]

[OnName num="shinzi"]
"What the hell!　What the hell is wrong with you?
[cpg cn=true]




;//////////////////////////////////////////////////////////////////////////


[stopse g=2]
[stopse g=6]

[free time=400]
;//[WAIT time=400]
;//[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト





What kind of woman is this ...... and I'm looking down on her from above in dismay.
[cpg]

Abnormal.
[cpg]

The two words popped into my head like a montage.
[cpg]

The Amane is abnormal.
[cpg]

This endless desire, repeated strange behavior, all are summed up in that word.
[cpg]

Amane doesn't care what I think, it does as it pleases.
[cpg]

No matter what I think ......
[cpg]

This Amane has nothing to do with .......
[cpg]

The Amane is ...... abnormal.
[cpg]

;//エフェクト


;#############################################################


;#############################################################

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=900]
[BGM f="sir"]
[BG f="b_ex_fu_t1_0.ui" time=800]
[WAIT time=900]
;//【ＢＧ】葬儀会場　昼　曇り


;//日中　中レベルの雨


[SE f="se054"]
;//【ＳＥ】読経


;//全員喪服


The day of my mother's funeral.
[cpg]

There was no end to the condolences of hospital personnel, relatives, and Shuei Academy students and teachers.
[cpg]

In such a situation,......
[cpg]

[FG f="youko_p6_03_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=800]
[WAIT time=100]
[VOICE f="Youko0206"]
[OnName num="youko"]
" Shinji ......"
[cpg cn=true]

[OnName num="shinzi"]
" Yoko ......, you've come ......."
[cpg cn=true]

Apart from the line of burning incense, Yoko came running to me.
[cpg]

Yoko In the event that you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

[WAIT time=100]
[VOICE f="Youko0207"]
[OnName num="youko"]
"You've had a tough time,....... No, it's going to continue to be tough ....... If there is anything I can do for you, please let me know. Really ...... anything."
[cpg cn=true]

[OnName num="shinzi"]
"Thank you, .......
[cpg cn=true]

[FO pos="2/3" time=800]
[WAIT time=800]

[FG f="izumi_p5_03_a.ui" method="change_7" pos="2/5" time=1000]
[FG f="shizuku_p5_03_a.ui" method="change_6" pos="4/5" time=1000]

[WAIT time=100]
[VOICE f="Izumi0161"]
[OnName num="izumi"]
" Mizushima ......, I'm so sorry for your loss. ......
[cpg cn=true]

[WAIT time=100]
[VOICE f="Shizuku0156"]
[OnName num="shizuku"]
"Senior ......, are you okay ......?"
[cpg cn=true]

Next to him came Izumi and Shizuku .
[cpg]

This is a great way to make sure you are getting the most out of your time with your family and friends. Izumi looks like it is in pain and Shizuku has red eyes.
[cpg]

I'm not sure if this is a good idea, but I'm sure it's a good idea.
[cpg]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Izumi0162"]
[OnName num="izumi"]
"You see,......, I don't know what to say, but please try not to break your body,....... I'm sure you'll be happy with the results. I can probably help you with make-up exams and whatnot. ......"
[cpg cn=true]

[OnName num="shinzi"]
"Excuse me. ......
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0157"]
[OnName num="shizuku"]
"Senior ...... this."
[cpg cn=true]

[FO pos="4/5" time=800]
[FG f="shizuku_p7_03_a.ui" method="change_7" pos="4/6" time=800]
[WAIT time=1000]
[FO pos="4/6" time=800]
[FG f="shizuku_p5_03_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=1000]

Shizuku You can find a lot of people who are interested in this kind of thing.
[cpg]

You can find a lot of people who have been in the business for a long time.
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Shizuku0158"]
[OnName num="shizuku"]
"You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg cn=true]



[OnName num="shinzi"]
"''Thank you ....... I'm sure my mother will be very happy ......!
[cpg cn=true]


[move from="4/5" to="5/5" ease="easeInOutSine" time=2000]
[move from="2/5" to="4/5" ease="easeInOutSine" time=2000]

[WAIT time=1000]

[FG f="youko_p8_03_a.ui" method="change_4" pos="1/5" time=1000]

[WAIT time=100]
[VOICE f="Youko0208"]
[OnName num="youko"]
" Shinji ......."
[cpg cn=true]

Yoko I'm not sure what to make of this.
[cpg]

[free time=1000]
[transition target={true} rule="sita.jpg"  time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BG f="b_s_gy_t1_0_m_up.ui" time=0]

[transition target={false} rule="sita.jpg"  time=10]

In the event that you're not sure what you're looking for, you'll be able to find out more about it here.
[cpg]



The hands are all warm and gentle,......, and my tears flow unstoppably.
[cpg]



It was then that ......
[cpg]

[SE f="se053"]
;//【ＳＥ】ザワザワ
[STOPBGM]

;//[BG f="b_ex_fu_t1_0.ui" time=0]
;//[transition target={false} rule="sita.jpg" time=800]
[WAIT time=800]

;//[FG f="yukika_p1_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0088"]
[OnName num="yukika"]
"What ......?"
[cpg cn=true]

It's a great way to make sure you get the most out of your time with your family and friends.
[cpg]

;//[FO pos="2/3" time=800]

This is a great way to make sure you are getting the most out of your money.
[cpg]

;//読経停止
[stopse g=2]
[stopse g=6]

[SE f="se053"]
;//【ＳＥ】ザワザワ

;//[FG f="youko_p6_03_a.ui" method="change_5" pos="1/3" time=800]
;//[FG f="izumi_p5_03_a.ui" method="change_5" pos="2/3" time=800]
;//[FG f="shizuku_p5_03_a.ui" method="change_5" pos="3/3" time=800]

[WAIT time=100]
[VOICE f="Youko0209"]
[OnName num="youko"]
"I'm not sure what to say.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Izumi0163"]
[OnName num="izumi"]
"What...?"
[cpg cn=true]

[WAIT time=100]
[VOICE f="Shizuku0159"]
[OnName num="shizuku"]
Amane "I'm sure you'll be able to figure out what's going on.
[cpg cn=true]

[OnName num="shinzi"]
"......?"
[cpg cn=true]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

;//ウェディングドレス姿（ブーケ有り）で笑顔の雨音が、喪服の弔問客の間を走って来る





;//[WAIT time=1000]



;//[BG f="black.ui" time=800]

;//[BG f="ev_44_0.ui" time=800]

[WAIT time=1000]

[WAIT time=100]
[VOICE f="Amane0713"]
[OnName num="amane"]
"I'm not sure what to say.
[cpg cn=true]


[BG f="ev_44_0_down.ui" time=3000]
[WAIT time=4500]
[BG f="ev_44_0_center.ui" time=1000]
[WAIT time=3500]
[BG f="ev_44_0_up.ui" time=1000]
[WAIT time=3500]

;**【ＣＧ】ev_44_0 ***********************
[CG id=13 index=0 time=1000]
;*****************************************
[WAIT time=2000]



[BGM f="danger"]

Amane In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]
[BG f="ev_44_0.ui" time=0]

Amane It's a great way to make sure you're getting the most out of your time with your family and friends.
[cpg]

[BG f="ev_44_0_up.ui" time=800]
[WAIT time=100]
[VOICE f="Amane0714"]
[OnName num="amane"]
"I am sorry for your loss, mother. But please leave Shinji the matter to me, and go to heaven in peace! I'm sure your husband will be waiting for you over there to bless us together! Today is the wedding of me and Shinji you know!"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0089"]
[OnName num="yukika"]
"Na...na ......"
[cpg cn=true]

[OnName num="shinzi"]
"Oh ...... oh .........
[cpg cn=true]

This is a great way to make sure you are getting the most out of your time with your family.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

It took me a good 10 seconds to get just that answer.
[cpg]

[BG f="ev_44_a_up.ui" time=0]
[WAIT time=100]
[VOICE f="Amane0715"]
[OnName num="amane"]
" Shinji !"
[cpg cn=true]

You can find a lot more information on the web. It's just the most beautiful smile.
[cpg]

In the short time I've known Amane , this may be the first time I've seen such a genuine smile.
[cpg]

[BG f="ev_44_a_up.ui" time=0]
[WAIT time=100]
[VOICE f="Amane0716"]
[OnName num="amane"]
"What's wrong with you, Shinji ?
[cpg cn=true]

[OnName num="shinzi"]
"Aaa ...... aaa ......... aaa ......?
[cpg cn=true]

This is a great way to make sure you are getting the most out of your vacation. You can find a lot of people who are looking for the very best in the marketplace.
[cpg]

Amane ...... What the hell ...... is wrong with you?
[cpg]

Why are you wearing a ...... wedding dress to your mother's funeral?
[cpg]

What the hell ...... are you talking about, a wedding?　We've only known each other for a short ...... time.
[cpg]


[WAIT time=100]
[VOICE f="Amane0717"]
[OnName num="amane"]
" Shinji , are you okay?　I know, it's sad that your mother died. I'm so sad that I can't even speak. ......
[cpg cn=true]

[BG f="ev_44_0_up.ui" time=800]
[WAIT time=100]
[VOICE f="Amane0718"]
[OnName num="amane"]
"But that's why you have to smile!　Show your mother how happy you are and reassure her!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0719"]
[OnName num="amane"]
"We're very happy, so don't worry, just watch over us from heaven. ......
[cpg cn=true]

Why ...... Amane ...why ...... why...why are you doing this to me? ......?
[cpg]

[OnName num="shinzi"]
"Oh ...... ah... ah ......... ah ......
[cpg cn=true]

Why... why ...... why ......!!!
[cpg]

[OnName num="shinzi"]
"......!
[cpg cn=true]

I was crying my eyes out as he mentioned my mom and my dad together.
[cpg]

My eyes can't see anything because of the tears, and I can't hear anything because of the screams coming out of my mouth.
[cpg]

Then I broke down crying and ......
[cpg]


;**【ＣＧ】ev_44_a ***********************
[CG id=13 index=1 time=1000]
;*****************************************


[WAIT time=100]
[VOICE f="Youko0210"]
[OnName num="youko"]
"What are you talking about?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Izumi0164"]
[OnName num="izumi"]
"You know your place!"
[cpg cn=true]

Yoko and Izumi jumped out and grabbed Amane to seize him.
[cpg]


[WAIT time=100]
[VOICE f="Shizuku0160"]
[OnName num="shizuku"]
" Mizushima , get a grip!"
[cpg cn=true]

Shizuku kept rubbing my back, desperately trying to keep me on my side.
[cpg]


[WAIT time=100]
[VOICE f="Amane0720"]
[OnName num="amane"]
"Get out of my way!　Crying doesn't mean anything!　You need to show your mother that Shinji is happy!　That's it!
[cpg cn=true]

;**【ＣＧ】ev_44_b ***********************
[CG id=13 index=2 time=1000]
;*****************************************



[WAIT time=100]
[VOICE f="Yukika0090"]
[OnName num="yukika"]
"Aah!
[cpg cn=true]

[SE f="se011"]
;//【ＳＥ】バシンッ！　バッターン！


The bouquet thrown by Amane hit and the picture on the altar fell over.
[cpg]


[WAIT time=100]
[VOICE f="Yukika0091"]
[OnName num="yukika"]
"What a mess!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0721"]
[OnName num="amane"]
"It's the bouquet of happiness!　So that your mother can be with her husband again in the afterlife!　It's a joint wedding!　Congratulations!　Congratulations!
[cpg cn=true]

[OnName num="shinzi"]
"..............."
[cpg cn=true]

I don't know what's going on anymore. How on earth did this happen and what went wrong ......?
[cpg]

What should I do now? ...... My mind has gone blank, and I can't think of anything.
[cpg]

I'm not sure what to do, but I'm not sure what to do.
[cpg]


;//CG終了

[BG f="b_ex_fu_t1_0.ui" time=1000]
[FG f="amane_p3_31_a.ui" method="change_2" pos="3/5" time=1000]
[WAIT time=1000]



[WAIT time=100]
[VOICE f="Amane0722"]
[OnName num="amane"]
"This is the end of the damp funeral. It's also the end of the sadness. And now the very, very, very happy beginning of our wedding ceremony!
[cpg cn=true]

[FACE method="change_6" pos="3/5"]
[move from="3/5" to="2/5" ease="easeInOutSine" time=3000]
[WAIT time=100]
[VOICE f="Amane0723"]
[OnName num="amane"]
"Thank you, everyone, for gathering here for the two of us!　We will be so happy!"
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[move from="2/5" to="4/5" ease="easeInOutSine" time=3000]
[WAIT time=100]
[VOICE f="Amane0724"]
[OnName num="amane"]
"Please, please... give us a warm round of applause!　Please give us a warm round of applause!
[cpg cn=true]

[move from="4/5" to="2/5" ease="easeInOutSine" time=3000]
It's natural... but no one is willing to take the action she wants.
[cpg]

[move from="2/5" to="3/5" ease="easeInOutSine" time=3000]
In the event that you have any kind of questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

Then Amane comes after me some more.
[cpg]

[FACE method="change_6" pos="3/5"]
[WAIT time=100]
[VOICE f="Amane0725"]
[OnName num="amane"]
"Come on, Shinji ... let's get started, shall we?　Our wedding...!
[cpg cn=true]

[FACE method="change_2" pos="3/5"]
[WAIT time=100]
[VOICE f="Amane0726"]
[OnName num="amane"]
"What should we do? ...... That's right. You can find a lot more than just a few things to do.
[cpg cn=true]

Amane In the event that you have any questions concerning where and how to use the internet, you can contact us at the web site.
[cpg]

I'm sure you'll be happy to know that I'm not the only one who's a bit of a jerk.
[cpg]


[WAIT time=100]
[VOICE f="Amane0727"]
[OnName num="amane"]
"'Now... kiss me with your vows: ......'
[cpg cn=true]

[FG f="amane_p5_31_a.ui" method="change_2" pos="3/5" time=1000]
Slowly, like in slow motion, her face... her lips come closer.
[cpg]

[FG f="amane_p7_31_a.ui" method="change_2" pos="3/5" time=1000]
It's not that I don't like it, it's not that I'm not happy about it, it's just that I'm watching it happen.
[cpg]

[FG f="amane_p9_31_a.ui" method="change_2" pos="3/5" time=1000]
ゆっくりゆっくり Amane の唇が近づいてきて俺の唇と重なる......という瞬間、
[cpg]

[move from="3/5" to="10/5" ease="easeInOutSine" time=1000]

[SE f="se011"]
;//【ＳＥ】ドンッ！



[WAIT time=100]
[VOICE f="Youko0211"]
[OnName num="youko"]
"Stop it!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0092"]
[OnName num="yukika"]
"You, what are you doing!!!!"
[cpg cn=true]

The moment our lips touched, Yoko and Yukika sister intervened between us.
[cpg]

The Yoko pushed Amane away with all his strength, and the Yukika sister grabbed his shoulder from behind and pulled him off.
[cpg]

[FG f="youko_p4_03_a.ui" method="change_3" pos="2/5" time=0]
[FG f="amane_p3_31_a.ui" method="change_4" pos="3/5" time=0]
[FG f="yukika_p3_02_a.ui" method="change_3" pos="4/5" time=0]
[WAIT time=100]
[VOICE f="Amane0728"]
[OnName num="amane"]
"I'm not sure what to say.　I'm sorry,......!"
[cpg cn=true]

The two of them have the most ...... angry expressions I've ever seen. It's not just the two of them, but the others as well.
[cpg]


[WAIT time=100]
[VOICE f="Youko0212"]
[OnName num="youko"]
"Screw you!　You... you've got to be kidding me!　You've got to be kidding me!
[cpg cn=true]

[FACE method="change_7" pos="3/5"]
[WAIT time=100]
[VOICE f="Amane0729"]
[OnName num="amane"]
"'Damn... why...?　Why are you angry?　Why aren't you congratulating me on my marriage to Shinji ?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0093"]
[OnName num="yukika"]
"No one, ...... no one, is going to bless us!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0213"]
[OnName num="youko"]
"You're really crazy!　No, you're crazy!
[cpg cn=true]

The three of them were so close to each other that they looked like they were about to start a fistfight.
[cpg]

[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[STOPBGM]

[WAIT time=100]
[VOICE f="Youko0214"]
[OnName num="youko"]
"Go home!　You god of pestilence!
[cpg cn=true]


[WAIT time=1000]

[BG f="b_ex_fu_t1_0.ui" time=800]
;//【ＢＧ】葬儀会場　昼　曇り

[WAIT time=1000]



;//[FG f="izumi_p1_03_a.ui" method="change_3" pos="1/3" time=1000]

[FG f="youko_p4_03_a.ui" method="change_3" pos="2/5" time=0]
[FG f="amane_p3_31_a.ui" method="change_4" pos="3/5" time=0]
[FG f="yukika_p3_02_a.ui" method="change_3" pos="4/5" time=0]
[WAIT time=100]
[VOICE f="Izumi0165"]
[OnName num="izumi"]
"What are you doing!　Everyone lend a hand!
[cpg cn=true]

[BGM f="eye2"]
The mourners who came to their senses at the senior's words hurriedly dragged Amane out.
[cpg]

[FACE method="change_3" pos="3/5"]
;//[FG f="amane_p3_31_a.ui" method="change_3" pos="3/5" time=800]
[WAIT time=100]
[VOICE f="Amane0730"]
[OnName num="amane"]
"I'm not sure what to say.　I'm not sure why you're interrupting me.　 I'm sorry for Shinji you!
[cpg cn=true]

In the event that you're not sure what you're looking for, you'll be able to find out more about it here.
[cpg]

Yoko Yukika In the event that you've got a lot more than one of these, you'll be able to get a lot more.
[cpg]

[OnName num="shinzi"]
"......... and ........."
[cpg cn=true]

After the arrival of the wedding dress Amane , the brain that was not working properly finally came up with one answer and emotion.
[cpg]

Maybe I've never had anger like that in my entire life... maybe never again... and it erupted from the depths of my body.
[cpg]

[FACE method="change_6" pos="3/5"]
;//[FG f="amane_p3_31_a.ui" method="change_6" pos="3/5" time=800]
[WAIT time=100]
[VOICE f="Amane0731"]
[OnName num="amane"]
"What the hell?　 Shinji ?　I'm sorry, these people are bothering me...I can't hear them well!"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
;//[FG f="youko_p4_01_a.ui" method="change_3" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Youko0215"]
[OnName num="youko"]
"''It's you who's bothering me, plague!　Go home!　Get out of here. ......
[cpg cn=true]

[OnName num="shinzi"]
"Get out of ....... ......, get out!
[cpg cn=true]

I don't want you to stay here, I don't want you to see Amane 's face...the way he looks.
[cpg]

;//[FO pos="2/5" time=800]

So I shouted with all my might. I'm not sure what to do.
[cpg]

[FACE method="change_5" pos="3/5"]
;//[FG f="amane_p3_31_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0732"]
[OnName num="amane"]
" Shinji ...?　 Shinji , why...?
[cpg cn=true]

;//[FG f="amane_p5_31_a.ui" method="change_1" pos="2/3" time=800]
[move from="4/5" to="6/5" ease="easeInOutSine" time=3000]
[WAIT time=1]
[move from="3/5" to="5/5" ease="easeInOutSine" time=3000]
[WAIT time=1]
[move from="2/5" to="4/5" ease="easeInOutSine" time=3000]




Then the people around him took Amane away.
[cpg]

In the event that you're being plucked out of the funeral home, Amane was shouting loudly.
[cpg]

[FACE method="change_3" pos="5/5"]
[move from="5/5" to="5/7" ease="easeInOutSine" time=3000]
[WAIT time=1]
[FACE method="change_3" pos="4/5"]
[move from="4/5" to="4/7" ease="easeInOutSine" time=3000]
[WAIT time=1]
[FACE method="change_3" pos="6/5"]
[move from="6/5" to="6/7" ease="easeInOutSine" time=3000]

;//[FG f="amane_p3_31_a.ui" method="change_3" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane0733"]
[OnName num="amane"]
"I'm the only one!　 I'm the only one on Shinji 's side!!!!"
[cpg cn=true]

;//[FO pos="2/3" time=800]
[move from="5/7" to="5/3" ease="easeInOutSine" time=2000]
[move from="4/7" to="4/3" ease="easeInOutSine" time=2000]
[move from="6/7" to="6/3" ease="easeInOutSine" time=2000]

She was shouting that so loudly that it echoed through the funeral home.
[cpg]

[free time=800]
[WAIT time=1000]

[FG f="youko_p8_03_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0216"]
[OnName num="youko"]
"' Shinji ......, don't let it bother you. That girl is crazy."
[cpg cn=true]

I kicked Amane out and Yoko came back and squatted down beside me and patted my head.
[cpg]

[OnName num="shinzi"]
" Yoko ......."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0217"]
[OnName num="youko"]
"I'll always be there for Shinji you. I don't care if you hate me. I'm here to help Shinji ......."
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, ......, I'm sorry I ever ...... you.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0218"]
[OnName num="youko"]
"What are you talking about? It's between you and me. I don't care about .......
[cpg cn=true]

[OnName num="shinzi"]
"I'm sorry ....... Sorry, .......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0219"]
[OnName num="youko"]
"Don't say anything else. Just think about yourself. ......"
[cpg cn=true]

Yoko was kind.
[cpg]

You can see that they are trying to soothe your current grief by letting go of your previous attitude.
[cpg]

I think Yoko might be a better guy than I thought .......
[cpg]

;//;#############################################################


;//;#############################################################

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=800]
[BGM f="insecurity"]
[BG f="b_si_d_t2_0.ui" time=800]
;//【ＢＧ】慎二の家　ダイニング　夕方　曇り

[WAIT time=800]

After the funeral, when I came back from the crematorium, Yoko was still there for me.
[cpg]

Yukika You can find a lot of things that you can do to make your life easier.
[cpg]

[FG f="youko_p6_03_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0220"]
[OnName num="youko"]
" Shinji ......, if you don't put some in your stomach, it will be poisonous to your body. ......"
[cpg cn=true]

You can find a lot more than just a few things to do.
[cpg]

This is a great way to make sure you get the most out of your time with your family.
[cpg]

[OnName num="shinzi"]
"It's okay,....... I'm sorry about that. I'm sorry I even got you wet in the rain,.......
[cpg cn=true]

It was raining when I saw him off and when I went back to my house, so I went out and got Yoko wet for some reason.
[cpg]

[FG f="youko_p6_03_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0221"]
[OnName num="youko"]
"It's also ....... You should stop worrying about other people at times like this.
[cpg cn=true]

[OnName num="shinzi"]
"You're right. ......
[cpg cn=true]

[move from="2/3" to="2/5" ease="easeInOutSine" time=800]

[FG f="yukika_p5_02_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yukika0094"]
[OnName num="yukika"]
" Shinji ......, your dad and I are going to go talk to the funeral home people and the insurance company people. ...... Are you okay?
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0222"]
[OnName num="youko"]
"Oh, I'll be right with you. ......
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0095"]
[OnName num="yukika"]
"Thank you. Well, ......, take care of ......."
[cpg cn=true]

Yukika In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

[free time=800]

[OnName num="unknown"]
"So, the thing that will be the legacy is ......
[cpg cn=true]

[OnName num="unknown"]
"Since it was a self-inflicted accident, the amount is ......
[cpg cn=true]

[OnName num="unknown"]
"The cost of the wake and the funeral was ......
[cpg cn=true]

[FG f="youko_p6_03_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0223"]
[OnName num="youko"]
" Shinji ......, let's go up to .......
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, ......."
[cpg cn=true]

Adults are amazing.
[cpg]

I'm not sure what to make of this.
[cpg]

I can't do that very well. ......
[cpg]


[jump storage="ep014.ks" target="*start"]
