*start



;//２-b　そうじゃない
*choise_52

;#################################################
*Ep029|Matomo.
;#################################################
[SCENE id=33]
[BG f="b_a_mr_t2_0.ui"]

[BGM f="sir"]

;//[FG f="amane_p7_01_a.ui" method="change_3" pos="2/3"]

[OnName num="shinzi"]
"No, it's not. Amane ......
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1081"]
[OnName num="amane"]
"What ......?"
[cpg cn=true]

[FG f="amane_p7_01_a.ui" method="change_8" pos="2/3" time=800]
I wrapped my hands around Amane her cold hands and turned to face her.
[cpg]

[OnName num="shinzi"]
"I ...... really care about you, and I care about you a lot. You understand that, don't you?"
[cpg cn=true]

[FG f="amane_p8_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1082"]
[OnName num="amane"]
"......... Yeah."
[cpg cn=true]

As I spoke slowly and calmly, Amane stared at me, and gradually regained his composure and listened to me.
[cpg]

[OnName num="shinzi"]
"But you can't go on as you are now. Do you know why?"
[cpg cn=true]

;//[FG f="amane_p5_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1083"]
[OnName num="amane"]
"I don ...... t understand. Why not?
[cpg cn=true]

[OnName num="shinzi"]
"Remember. Take your time. Amane has been through a lot, and it's hurting you, and it's making you sick, okay?
[cpg cn=true]

[FACE method="change_8" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1084"]
[OnName num="amane"]
"I'm ...... sick?
[cpg cn=true]

[OnName num="shinzi"]
"Of course it's not Amane 's fault. I understand that. You're just a victim who's been hurt by people around you.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1085"]
[OnName num="amane"]
"Oh, .......
[cpg cn=true]

[SE f="se099"]
;//【ＳＥ】フラッシュバック（絵が切り替わる毎に効果）

[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1500]
[BG f="fb_1.ui" time=800]
[WAIT time=2500]

[BG f="white.ui" time=1000]
[WAIT time=1500]
[BG f="fb_2.ui" time=800]
[WAIT time=2500]

[BG f="white.ui" time=1000]
[WAIT time=1500]
[BG f="fb_3.ui" time=800]
[WAIT time=2500]


;//フラッシュバックする、雨音の辛い記憶（どの絵を何枚出すかはお任せします）

[BG f="b_a_mr_t2_0.ui" time=2500]
[FG f="amane_p8_01_a.ui" method="change_4" pos="2/3" time=2500]
[WAIT time=2500]
[WAIT time=100]
[VOICE f="Amane1086"]
[OnName num="amane"]
"Oh, ......, I ......, I ......!
[cpg cn=true]

[OnName num="shinzi"]
"It's okay!　It's okay, ......."
[cpg cn=true]

I held Amane tightly to his body, which began to shake and rattle, and gently stroked his head to calm him down again.
[cpg]

[OnName num="shinzi"]
"I want Amane to cure my illness, you know. I want Amane to cure my ...... mental illness."
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1087"]
[OnName num="amane"]
"I ...... had a mental illness ......."
[cpg cn=true]

Slowly ruminating on my words, Amane let the tears fall.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1088"]
[OnName num="amane"]
"I'm sorry ...... Shinji ..."
[cpg cn=true]

I'm sure you'll understand. But I just couldn't stop myself....
[cpg]

Whenever I get emotional, I just can't control myself.
[cpg]

[OnName num="shinzi"]
"It's the disease. ....... I can't help it. It's not Amane my fault. It's just ......."
[cpg cn=true]

Keeping an eye on Amane , I cautiously cut to the chase.
[cpg]

[OnName num="shinzi"]
"Why don't you go to the hospital to get back to the real Amane ?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1089"]
[OnName num="amane"]
"Hospital ......."
[cpg cn=true]

[OnName num="shinzi"]
"If you go to the hospital, the doctors will cure you."
[cpg cn=true]


[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1090"]
[OnName num="amane"]
"If I go to the hospital, ...... will I be cured?　If I get better, I won't have to say goodbye to ...... Shinji ?
[cpg cn=true]

[OnName num="shinzi"]
"Yes. ......
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1091"]
[OnName num="amane"]
"Well, I ...... want to be cured. I want to be my true self and not be a burden to Shinji .
[cpg cn=true]

[OnName num="shinzi"]
"I see. You understand me. You're a good boy, Amane .
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1092"]
[OnName num="amane"]
"Wait for me at Shinji .......
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, ......."
[cpg cn=true]




;//エフェクト

[free time=800]
[BG f="black.ui" time=800]
[BG f="b_si_r_t3_0.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　午後　霧雨
[BGM f="healing"]
[WAIT time=900]



Thus, Amane went to the mental hospital of its own will.
[cpg]

In fact, the exchange was conceived in consultation with Yoko and was the best way to avoid provoking Amane .
[cpg]

[OnName num="shinzi"]
"But I told her that she didn't have to leave me or wait for me to get better. ......
[cpg cn=true]

[FG f="youko_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0340"]
[OnName num="youko"]
"I'm fine with that. It's a lie.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, but ......
[cpg cn=true]

In the end, it seems that Amane had some sort of serious illness and his father, his legal guardian, was called in to hospital.
[cpg]

In addition to the rumors on the street, Yoko researched the disease on the Internet and found that it is not something that can be cured completely, and is now in a state of virtual confinement.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0341"]
[OnName num="youko"]
I'm fine," he said. If he is released from the hospital, it means that his thinking has become normal, right?　Then you'll understand what kind of strange behavior you've done, and you'll be able to accept that Shinji 's words were just an excuse.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, I see!"
[cpg cn=true]

According to Yoko , my guilt seems to be unfounded and I am relieved.
[cpg]

[OnName num="shinzi"]
"Medical science is advancing, so hopefully one day we'll be able to treat it properly.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0342"]
[OnName num="youko"]
"Well, you know. I don't know how long I've been crazy, and I don't know when I've been sane!
[cpg cn=true]

Yoko said sarcastically, but I can not give up hope.
[cpg]

I'm not sure what to make of it.
[cpg]

So, there must be a time when Amane was a real girlfriend.
[cpg]

I'm sure you'll find some of that in the kindness and warmth you showed me.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0343"]
[OnName num="youko"]
" Shinji , what are you thinking about?"
[cpg cn=true]

[OnName num="shinzi"]
"Nothing.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0344"]
[OnName num="youko"]
"You're going to college at the same place, right?　You better get a grip.
[cpg cn=true]

[OnName num="shinzi"]
What do you mean, "get a grip"? You're worse than me.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0345"]
[OnName num="youko"]
"I want you to teach me how to be a good student!
[cpg cn=true]

[OnName num="shinzi"]
"Oh, my God. ......
[cpg cn=true]

Yoko I'm sure I'll be able to find a way to make it work for me.
[cpg]

I'm sure I'll be able to continue to work with this guy.
[cpg]

From now on...... forever......
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト


;//流すなら、ここでスタッフロール

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト
[BGM f="rain"]

;//雨音の姿は指定があるまで画面に見えない


I wonder how long I've been here since then.
[cpg]

As I recall, a little while ago, I was thinking that I should get well soon and go back to Shinji , but the doctor said that if I hurried, I would not get well, so I tried not to think about it as much as possible.
[cpg]

Because what Shinji wants is for me to get better.
[cpg]

I would never want to ruin Shinji 's hopes by getting in the way myself.
[cpg]

So I'm making an effort to follow the doctor's advice.
[cpg]

[OnName num="doctor"]
"You'll be fine now. No more self-harm, no more harm, no more strange behavior.
[cpg cn=true]

[OnName num="nurse"]
"But you, sir, you're going to have to go to ......
[cpg cn=true]

[OnName num="doctor"]
"You know you're stuck here, don't you?　We can't just leave someone out there like that.
[cpg cn=true]

[OnName num="nurse"]
"Hi, .......
[cpg cn=true]

[SE f="se014"]
;//【ＳＥ】鉄扉の鍵が開き、ドアも開く

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]


[BG f="b_h_ro_t1_0.ui" time=1000]
;//【ＢＧ】病院　個室　午後　曇り


[OnName num="doctor"]
"Good morning, Amane Satonaka .
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane1093"]
[OnName num="amane"]
"Good morning, sir.
[cpg cn=true]

[OnName num="doctor"]
"Congratulations. You're being discharged today.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane1094"]
[OnName num="amane"]
"Oh, my God!　Does that mean I'm cured?
[cpg cn=true]

[OnName num="doctor"]
"Yes, that's right. You'll be able to get on in society. You've worked very hard for a long time.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane1095"]
[OnName num="amane"]
"Thank you very much.
[cpg cn=true]

[OnName num="doctor"]
"Your parents have been notified, so once you're out of here, you'll be on your way.
[cpg cn=true]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_ex_tw_t1_0.ui" time=1000]
;//【ＢＧ】街　午後　曇り


The air I hadn't breathed in a long time was fresh, and my steps naturally became lighter.
[cpg]

It's a good idea to take a look at the website and see if you can find anything you like.
[cpg]

[FG f="amane_p6_32_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1096"]
[OnName num="amane"]
"Oh ......"
[cpg cn=true]

I found a sign of a nostalgic fast food restaurant, and I went inside.
[cpg]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_ex_ff_t1_0.ui" time=1000]
;//【ＢＧ】ファストフード店　午後　曇り


[OnName num="sales_clerk"]
"Welcome!
[cpg cn=true]

[FG f="amane_p5_32_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1097"]
[OnName num="amane"]
"Huh. ......"
[cpg cn=true]

I wonder if Shinji you still work here part-time.
[cpg]

What will he say when he sees me?
[cpg]

[OnName num="sales_clerk"]
"If you're ready to order, I'll be right with you.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1098"]
[OnName num="amane"]
"Oh, uh, ......, I'll have a burger and fries. Also, is there a waitress here named Mizushima ?"
[cpg cn=true]

When I asked, the waiter looked a little puzzled and answered quickly.
[cpg]

[OnName num="sales_clerk"]
"No, we don't have anyone with that name on staff.
[cpg cn=true]

[FG f="amane_p6_32_a.ui" method="change_7" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane1099"]
[OnName num="amane"]
"'I see. ......
[cpg cn=true]

[OnName num="store_manager"]
"What's up?"
[cpg cn=true]

[OnName num="sales_clerk"]
"Oh, it's the manager.
[cpg cn=true]

[OnName num="store_manager"]
"Can I help you?
[cpg cn=true]

The manager, who was smiling, did not look like the manager I knew.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1100"]
[OnName num="amane"]
"I'm not sure.　I think the manager here was a different person ......."
[cpg cn=true]

[OnName num="store_manager"]
"What?　I was assigned to this store five years ago, but you knew the previous manager?
[cpg cn=true]

[FG f="amane_p5_32_a.ui" method="change_5" pos="2/3" time=800]


[WAIT time=100]
[VOICE f="Amane1101"]
[OnName num="amane"]
"Five years ago?"
[cpg cn=true]

I was so surprised that I shouted out loud.
[cpg]

It had been five years since I had been hospitalized!
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1102"]
[OnName num="amane"]
"Well, then, what year is it now ......?"
[cpg cn=true]

I asked fearfully, and the manager answered a little doubtfully.
[cpg]

[OnName num="store_manager"]
"It's ...... now."
[cpg cn=true]

When I heard that answer, my mind slowly went blank. ......
[cpg]




;//エフェクト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye1"]
[BG f="b_si_d_t2_0.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　午後　曇り


;//１０年歳を取った慎二と陽子





[OnName num="children"]
"Papa!　Papa!"
[cpg cn=true]

[OnName num="shinzi"]
"No, no, no, no, don't run so fast.
[cpg cn=true]

[FG f="youko_p8_30_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0346"]
[OnName num="youko"]
"It's fine. You Shinji are being overprotective, aren't you?
[cpg cn=true]

[OnName num="shinzi"]
"I don't know. ......
[cpg cn=true]

[FG f="youko_p6_30_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0347"]
[OnName num="youko"]
"Shingo, come on!　Go play with your ball.
[cpg cn=true]

[OnName num="children"]
"Yes!
[cpg cn=true]

[SE f="se102"]
;//【ＳＥ】ゴムボールが弾む


[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0348"]
[OnName num="youko"]
"Ha ha!
[cpg cn=true]

[OnName num="shinzi"]
"Huh. ......"
[cpg cn=true]

The child that Yoko and I had is already five years old.
[cpg]

How quickly time flies.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0349"]
[OnName num="youko"]
"Hey, do you remember what day it is today?"
[cpg cn=true]

;//縁側に腰掛けた俺の横へ座り、顔を覗き込んでくる陽子。
[cpg]

He is as strong as ever, but he already has the face of an adult.
[cpg]

[OnName num="shinzi"]
"What was it? ......"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0350"]
[OnName num="youko"]
"It's your wedding anniversary!　You really forgot?
[cpg cn=true]

[OnName num="shinzi"]
"Oh, no. I remember. Let's go out to dinner tonight.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0351"]
[OnName num="youko"]
"You can't just go out for dinner, you know. After all, it's been 10 years!
[cpg cn=true]

[OnName num="shinzi"]
"All right, all right.
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0352"]
[OnName num="youko"]
"What a troublesome reply!
[cpg cn=true]

[OnName num="shinzi"]
"Heh.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0353"]
[OnName num="youko"]
"Moo!
[cpg cn=true]

[OnName num="shinzi"]
"Ha-ha-ha.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

It's been 10 years ...... since we got married.
[cpg]

Looking back, many things have happened.
[cpg]

College entrance exams, job hunting, small fights, big fights, marriage proposals, weddings ......
[cpg]

And pregnancy, childbirth ......
[cpg]

I'm not sure if I'm going to be able to do it, but I'm going to try.
[cpg]

[SE f="se006"]
;//【ＳＥ】小雨

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye2"]
;//[BG f="b_si_d_t1_0.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　午後　小雨

[BG f="b_ex_sk_t2_1.ui" time=1000]

;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

[WAIT time=1000]
;//小雨がポツポツ降り出す


;//[FG f="youko_p6_30_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0354"]
[OnName num="youko"]
"It's raining ....... I have to put the laundry in!
[cpg cn=true]

[OnName num="shinzi"]
"Hey, Shingo!　Let's go inside!
[cpg cn=true]

;//[FO pos="2/3" time=800]

I looked up and saw my son, Shingo, standing in a daze in front of the hedge.
[cpg]

[OnName num="children"]
"Who are you, auntie?　Why are you looking at Shingo's house?
[cpg cn=true]

[OnName num="shinzi"]
"Who are you talking to?　Excuse me, my son is ......."
[cpg cn=true]

Apparently, he was talking to someone outside the hedge, and I opened the gate to greet him. ......
[cpg]

[OnName num="shinzi"]
"What ......, you ......?
[cpg cn=true]

[free time=800]
;**【ＣＧ】ev_91_0 ***********************
[CG id=23 index=0 time=1000]
;*****************************************
[BGM f="danger"]


[WAIT time=100]
[VOICE f="Amane1103"]
[OnName num="amane"]
" Shinji ...... you ......."
[cpg cn=true]

[OnName num="shinzi"]
"No way. ...... No way. ......
[cpg cn=true]

It's a great way to get the most out of your day.
[cpg]

For a moment, I doubted my eyes, but it was the ...... Amane .
[cpg]

;**【ＣＧ】ev_91_a ***********************
[CG id=23 index=1 time=1000]
;*****************************************



[WAIT time=100]
[VOICE f="Amane1104"]
[OnName num="amane"]
"You lied ...... you lied ...... you said you were waiting ...... you said you were waiting for me ...... And yet..."
[cpg cn=true]

[OnName num="shinzi"]
"Oh, calm down, Amane !　I'll explain!"
[cpg cn=true]

This is a great way to make sure you are getting the most out of your money.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_ex_sz_t1_2.ui" time=1000]
;//【ＢＧ】通学路　午後　大雨


You can find a lot of people who are looking for a new way of life.
[cpg]

Amane You'll be able to find a lot more than just a few of these in the marketplace.
[cpg]


[WAIT time=100]
[VOICE f="Amane1105"]
[OnName num="amane"]
"You Shinji ...... said you wouldn't leave my Shinji ...... ..."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane1106"]
[OnName num="amane"]
"'I love ...... you... love you so much, love me... love me, don't you?　I love you... ......I love you...!"
[cpg cn=true]

[OnName num="shinzi"]
"Oooohhhh!"
[cpg cn=true]



;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//;#############################################################
;//;#############################################################


;//【ＢＧ】ブラックアウト
;//loop
[stopse g=2]
[stopse g=6]

[SE f="se007"]
;//【ＳＥ】雨の音、激しく高まってゆっくりF.O

[STOPBGM]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[WAIT time=1000]

;//END『治らずの病』
[system end7=true]
[SCENE id=34]

[stopse g=2]
[stopse g=6]

;//[jump target="*jump_ending"]
[jump storage="epend.ks" target="*start"]
;**【ＥＮＤ】　治らずの病ルート　**************************


;**********************************************************




;//=============================================================
;//=============================================================
;//=============================================================
;//=============================================================
;//=============================================================





;//全エンドコンプリート後、選択肢２の途中から分岐

;//選択肢２（二択）
;//■選択肢
;//１、嫌いになった
;//２、そうじゃない
;///////////////////////////////////////////////////////////////////
;//２-a　嫌いになった
;//それから暫くして、俺は陽子と共に修栄学園から別の所に転入した。
;//雨音がどうなったかはわからないが、隠せないほどの酷い自傷行為や、
;//エスカレートする奇行がついに大問題となり、どこかに引き取られていったと風の噂で耳にした。



;//ここから分岐して展開が変化
;//☆新エンディングへ分岐

*choise_60

;//選択肢EX（二択）


;//■選択肢
[switch]
[case "Let's forget Amane ever happened."]
	[swap]
	[jump target="*choise_61"]
[case "Amane was also a victim of..."]
	[swap]
	[jump target="*choise_62"]
[endswitch]


One, let's forget Amane ever happened.
2, Amane was a victim too...

*choise_61
[jump storage="ep028.ks" target="*choise_61"]
;///////////////////////////////////////////////////////////////////


;//１、雨音の事はもう忘れよう　　→元のルートへ
;//２、雨音も被害者だったのに…　→新エンドへ






*choise_62|Matomo.

;//新エンディング
;//『New Call Rain』

[STOPBGM]

.......
[cpg]

.............
[cpg]

...................
[cpg]

Some time has passed since then.
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





[OnName num="shinzi"]
"Ggh...ggh..."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0355"]
[OnName num="youko"]
"...come on."
[cpg cn=true]

[OnName num="shinzi"]
"Ggh... ggh..."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0356"]
[OnName num="youko"]
"Come on...
[cpg cn=true]




[BG f="b_si_r_t1_0.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　朝
[WAIT time=1000]

[BGM f="healing"]


[FG f="youko_p8_30_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0357"]
[OnName num="youko"]
"Hey!　Wake up, wake up, wake up, Shinji !
[cpg cn=true]

[OnName num="shinzi"]
"Huh?"
[cpg cn=true]

My body vibrates along with my vision, and I wake up from my reverie.
[cpg]



[FG f="youko_p6_30_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0358"]
[OnName num="youko"]
"Good morning.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, Yoko ...
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0359"]
[OnName num="youko"]
"Yeah, it's Yoko . What's wrong?
[cpg cn=true]

[OnName num="shinzi"]
"No, no, no. That's great. Thank you.
[cpg cn=true]

In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0360"]
[OnName num="youko"]
"I'm sure you'll be happy to hear that.
[cpg cn=true]

This is the reason why Yoko has been taking care of me.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0361"]
[OnName num="youko"]
"I'm sure you'll be happy to hear that.　If you take your time, you'll be late even though I woke you up.
[cpg cn=true]

[OnName num="shinzi"]
"Thank you.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0362"]
[OnName num="youko"]
"Hmm. Well, she's my girlfriend, so I don't mind.
[cpg cn=true]

I'm going out with Yoko again.
[cpg]

He is a good guy at heart, though he can be a bit harsh at times.
[cpg]

I'm not sure if I'm going to be able to do this, but I'm sure I'll be able to do it.
[cpg]

I am beginning to think that this is the most comfortable way for me.
[cpg]

I may just be spending my time convincing myself that this was the right thing to do.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0363"]
[OnName num="youko"]
"Breakfast is ready."
[cpg cn=true]

[OnName num="shinzi"]
"What?　Yours?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0364"]
[OnName num="youko"]
"...... Yukika 's?　What are you really trying to say after that?
[cpg cn=true]

[OnName num="shinzi"]
"No, I don't have anything to say.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0365"]
[OnName num="youko"]
"Okay.
[cpg cn=true]

I think I'm happy to be able to send this kind of message every day now.
[cpg]

And I think I've gotten a little more energetic.
[cpg]

Both me and her.
[cpg]




[free time=800]
[BG f="black.ui" time=800]
;//ブラックアウト
;//[BGM f="healing"]
;//[BG f="b_si_d_t1_0.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　朝


[WAIT time=2000]


[BG f="b_ex_sz_t1_0.ui" time=1000]
;//【ＢＧ】通学路　朝

[WAIT time=1000]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

;//loop
[SE f="se007" loop=true]
;//【ＳＥ】雨

We're living a boring, unremarkable life.
[cpg]

I wish I could have told myself that back then.
[cpg]

No, this doesn't mean that I'm dissatisfied with my current life.
[cpg]

Rather...
[cpg]

[FG f="youko_p8_30_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0366"]
[OnName num="youko"]
"So, you know, this new shop that opened in front of the station is really cute..."
[cpg cn=true]

[OnName num="shinzi"]
"Oh, yeah?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0367"]
[OnName num="youko"]
"Hey, you should listen to me."
[cpg cn=true]

[OnName num="shinzi"]
"Heh, heh."
[cpg cn=true]

This is normal, common, and happy.
[cpg]

I knew that well enough.
[cpg]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]
[stopse g=2]
[stopse g=6]

[BG f="white.ui" time=1000]
;//ホワイトアウト




[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye2"]
[BG f="b_si_d_t1_0.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　昼　雨





[OnName num="shinzi"]
"Rain...?
[cpg cn=true]

It was raining a little outside as I stared at it from inside.
[cpg]

It's a good idea to have a good idea of what you're doing.
[cpg]

It's not all bad memories.
[cpg]

That's the reason why I can't seem to get an answer.
[cpg]

[FG f="youko_p6_30_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0368"]
[OnName num="youko"]
"...... are you okay?"
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, oh, yeah!　It's nothing.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0369"]
[OnName num="youko"]
"......"
[cpg cn=true]

It's a good idea to take a look at your own personal life.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0370"]
[OnName num="youko"]
"I've got a part-time job today, so...
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, okay. Be careful.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0371"]
[OnName num="youko"]
"No, I mean, ......, ......, call me immediately if anything happens."
[cpg cn=true]

[OnName num="shinzi"]
"I know.
[cpg cn=true]

I think I know what Yoko is going to say.
[cpg]

There are no lectures at the university today, but I have a part-time job.
[cpg]

I'm hesitant to go out.
[cpg]

I think I'll just take the day off.
[cpg]

.......
[cpg]

.............
[cpg]

...................
[cpg]




[free time=800]
[BG f="black.ui" time=800]
[WAIT time=900]
;//ブラックアウト


[BG f="b_ex_sz_t3_1.ui" time=800]
;//【ＢＧ】通学路　夜　雨

[BGM f="rain"]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]
;//【雨、

;//loop
[SE f="se006" loop=true]
;//【ＳＥ】雨



[SE f="se131"]
;//【ＳＥ】雨の中歩く

[WAIT time=2000]

[OnName num="shinzi"]
"You can find a lot of people who are interested in this kind of thing.
[cpg cn=true]

It was still only a light downpour when the part-time job began, but when it ended, it was literally pouring rain.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="shinzi"]
"It's no use... let's hurry home.
[cpg cn=true]

With my feet bouncing around, I headed for home.
[cpg]

Then ......
[cpg]

[FG f="amane_p3_32_a_black.ui" pos="2/3" time=1000]
[WAIT time=1000]
[WAIT time=1000]

[OnName num="shinzi"]
"What?
[cpg cn=true]



In the event that you have any questions regarding where and how to use the internet, you can contact us at our own web site.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//一瞬昔の雨音の姿を表示　後ろ姿
[free time=400]
[FG f="amane_p3_02_a_black.ui" pos="2/3" time=400]
[BG f="black.ui" time=400]
[WAIT time=400]
[free time=400]
[BG f="b_ex_sz_t3_1.ui" time=800]
;//【ＢＧ】通学路　夜　雨

[FG f="amane_p3_32_a_black.ui" pos="2/3" time=800]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]
;//【雨、

[WAIT time=1000]



It's a good idea to have a good idea of what's going on in your life.
[cpg]

Did she forget her umbrella, or did someone take it by mistake?
[cpg]

I'm not sure what the reason is, but she's soaking wet from the rain.
[cpg]

[OnName num="shinzi"]
"......"
[cpg cn=true]



;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//一瞬昔の雨音の姿を表示　後ろ姿
[free time=400]
[FG f="amane_p3_02_a_black.ui" pos="2/3" time=400]
[BG f="black.ui" time=400]
[WAIT time=400]
[free time=400]
[BG f="b_ex_sz_t3_1.ui" time=800]
;//【ＢＧ】通学路　夜　雨

[FG f="amane_p3_32_a_black.ui" pos="2/3" time=800]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]
;//【雨、

[WAIT time=1000]



I'm sorry to hear that, but I only have one umbrella too.
[cpg]

I'm not sure what to do.
[cpg]

It's a very difficult decision to lend it to you.
[cpg]




;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//一瞬昔の雨音の姿を表示　後ろ姿
[free time=400]
[FG f="amane_p3_02_a_black.ui" pos="2/3" time=400]
[BG f="black.ui" time=400]
[WAIT time=400]
[free time=400]
[BG f="b_ex_sz_t3_1.ui" time=800]
;//【ＢＧ】通学路　夜　雨

[FG f="amane_p3_32_a_black.ui" pos="2/3" time=800]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]
;//【雨、

[WAIT time=1000]



However, can we pretend to ignore a woman who may be in trouble?
[cpg]

Wouldn't you be disillusioned if you told Yoko later that such a thing had happened?
[cpg]

You should at least lend her an umbrella!　You are a man with a small asshole!　What an asshole.
[cpg]

I'm sure you'll be happy to know that I'm not the only one.
[cpg]






;//ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1000]

[BG f="b_ex_tw_t2_1.ui" time=800]
;//【ＢＧ】街　夜　雨
[WAIT time=1000]




;//交差点か踏切あたりの絵



[FG f="amane_p5_32_a_black.ui" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1107"]
[OnName num="wet_woman"]
"......"
[cpg cn=true]

[OnName num="shinzi"]
"......"
[cpg cn=true]

Before I knew it, I was catching up with her.
[cpg]

It's funny.
[cpg]

When I saw her, the distance should have been a little farther.
[cpg]

This is a great way to get the most out of your time with your family and friends.
[cpg]

I'm not sure what to make of it.
[cpg]

[OnName num="shinzi"]
"(Oh, I see.)"
[cpg cn=true]

And I suddenly realize.
[cpg]

She hadn't moved from the intersection.
[cpg]

She had been standing there the whole time, whether the light turned red or green.
[cpg]

The signal had turned green.
[cpg]

But she didn't move from there. It's as if she's rooted.
[cpg]

And I can't move either.
[cpg]

If she doesn't move, I can't move either.
[cpg]

Because it becomes a form of overtaking her.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
;//ブラックアウト
[WAIT time=1000]








.......
[cpg]

.............
[cpg]

...................
[cpg]

Something that isn't rain is running down my cheek.
[cpg]

It's better to stay out of it. I know that in my head.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]





[WAIT time=900]
[BG f="b_ex_tw_t2_1.ui" time=1000]
;//【ＢＧ】街　夜　雨

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]
;//【雨、

;//loop
[SE f="se006" loop=true]
;//【ＳＥ】雨


[FG f="amane_p5_32_a_black.ui" method="change_1" pos="2/3" time=800]
[WAIT time=1000]

[OnName num="shinzi"]
"I'm not sure what to do.
[cpg cn=true]

;//[FG f="amane_p5_32_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1108"]
[OnName num="wet_woman"]
"...... What?"
[cpg cn=true]

[OnName num="shinzi"]
"It's raining so much and you don't even have an umbrella.
[cpg cn=true]

[OnName num="shinzi"]
"Is it possible that your umbrella was stolen?　You can use this umbrella if you want.
[cpg cn=true]

[OnName num="shinzi"]
"I'm close to home, so I'm fine. I'm sorry it's a cheap plastic umbrella, but..."
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

I'm not sure what I'm talking about.
[cpg]

I'm not sure what to say, but the words come out on their own rather than thinking with my brain. It's as if the other me is speaking.
[cpg]

You may be driven by such a sense of crisis that you can't think.
[cpg]




;//雨音のアップ　少し大人？になった雰囲気
[BG f="b_ex_tw_t2_1_up.ui" time=800]
;//【ＢＧ】街　夜　雨 アップ

[FG f="amane_p7_32_a.ui" method="change_1" pos="2/3" time=1000]

[WAIT time=2000]


I called out to her, and the woman who turned around was ...... Amane .
[cpg]

Immediately after, my brain stopped responding. The other me, the one who had been so talkative earlier, must have fled somewhere, leaving me behind.
[cpg]

[OnName num="shinzi"]
"......"
[cpg cn=true]

Oh, so it was you after all.
[cpg]

I'm not sure if it's the same person.
[cpg]

But it was still you who stood here, Amane , wasn't it?
[cpg]

It's also possible that the woman standing here in this situation is not you.
[cpg]

That's less likely.
[cpg]

[WAIT time=900]
[BG f="b_ex_tw_t2_1.ui" time=1000]

[FG f="amane_p5_32_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1109"]
[OnName num="amane"]
"Yes, I'm fine...
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

It was not a Amane kind of reply.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1110"]
[OnName num="amane"]
"I'm not sure what to say, but I'm sure you'll understand. I'm sorry for your concern.
[cpg cn=true]

[FG f="amane_p6_32_a.ui" method="change_2" pos="2/3" time=400]
[WAIT time=400]
[move from="2/3" to="4/3" ease="easeInOutSine" time=1000]

Amane I'm not sure what to make of this.
[cpg]

I don't know what the hell is going on here.
[cpg]

[OnName num="shinzi"]
"......"
[cpg cn=true]

What on earth is going on?
[cpg]

My emotions started to move like a roller coaster inside me.
[cpg]

Anxiety, doubt, surprise, curiosity.
[cpg]


[FG f="amane_p6_32_a.ui" method="change_1" pos="2/3" time=800]

It's a good idea to stop, but I'm going to call out to him again.
[cpg]



[OnName num="shinzi"]
"Um...I can take you home if you want."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1111"]
[OnName num="amane"]
"...... is fine.
[cpg cn=true]

[OnName num="shinzi"]
"But...
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane1112"]
[OnName num="amane"]
"No, thank you.
[cpg cn=true]

There was no way to get rid of it. So I said.
[cpg]

[OnName num="shinzi"]
"Are you ...... Amane ?"
[cpg cn=true]

I said her name.
[cpg]


[FG f="amane_p5_32_a.ui" method="change_1" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane1113"]
[OnName num="amane"]
".........."
[cpg cn=true]

[OnName num="shinzi"]
".........."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1114"]
[OnName num="amane"]
"............. And you are?"
[cpg cn=true]

The rain is still falling.
[cpg]



;//loop
[stopse g=2]
[stopse g=6]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[BG f="white.ui" time=1000]
;//ホワイトアウト





;//回想


[free time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_h_ro_t1_1.ui" time=800]
;//【ＢＧ】病院　個室天井　午後　曇り

[WAIT time=100]

;//病院の一室をセピアで表示



The doctor told me that the mental illness that Amane suffers from is difficult to cure completely.
[cpg]

No matter what she did, she couldn't control herself, and I and others around me were losing control.
[cpg]

She had to be hospitalized, and I had to keep my distance from Amane .
[cpg]

I thought that I would never see her again.
[cpg]




[BG f="white.ui" time=1000]
;//ホワイトアウト




[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_ex_tw_t2_1.ui" time=800]
;//【ＢＧ】街　夜　雨

;//loop
[SE f="se006" loop=true]
;//雨の音

;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]




[WAIT time=1000]



I dropped Amane off at the place where she used to live.
[cpg]

[OnName num="shinzi"]
"I'm sure this is the right place.
[cpg cn=true]

[FG f="amane_p5_32_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1115"]
[OnName num="amane"]
"''Yes, it should be.''
[cpg cn=true]

However, the manager of the apartment said that she had already cancelled her lease.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1116"]
[OnName num="amane"]
"I'm sorry you can't get into the house...
[cpg cn=true]

[OnName num="shinzi"]
"......"
[cpg cn=true]

I decided to call the police.
[cpg]






[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="rain"]
[BG f="b_ex_tw_t2_1.ui" time=1000]
;//【ＢＧ】街　夜　雨


[WAIT time=1000]


[OnName num="hospital_officials1"]
"Excuse me, are you the one who called me?"
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, yeah, I am.
[cpg cn=true]

[OnName num="hospital_officials"]
"I'm sorry for the trouble I've caused you.
[cpg cn=true]

[OnName num="shinzi"]
"No, no...
[cpg cn=true]

While bowing, I glanced sideways at Amane .
[cpg]

[OnName num="hospital_officials2"]
"Come on, Satonaka , let's go home.
[cpg cn=true]

[FG f="amane_p5_32_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1117"]
[OnName num="amane"]
"Why?　This is my house.
[cpg cn=true]

[OnName num="hospital_officials2"]
"It's not your house.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1118"]
[OnName num="amane"]
"Oh, really?　When did you move here?
[cpg cn=true]

I was having a strange conversation with someone from the hospital.
[cpg]

A hospital in another prefecture contacted us, and its officials are coming to pick up Amane us.
[cpg]

Apparently, she slipped out of the hospital and walked here.
[cpg]

[OnName num="shinzi"]
"Um... what's wrong with her?
[cpg cn=true]

[OnName num="hospital_officials1"]
"She's a patient with a rather difficult disease."
[cpg cn=true]

The hospital officials were not able to say so.
[cpg]

When was the last time you met Amane ?
[cpg]

You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

So I have never met them directly, and I don't know their current situation either.
[cpg]

It's not good to get involved any more. However, I was asking questions as if I were letting out a blur in my mind.
[cpg]

[OnName num="shinzi"]
"'Um...I know her...is her illness, is she cured?
[cpg cn=true]

[OnName num="hospital_officials1"]
"'You might be ...... ah, well... no, I'm afraid not.
[cpg cn=true]

I'm sure they heard about me from someone.
[cpg]

The hospital personnel seemed to be convinced of something.
[cpg]

[OnName num="hospital_officials1"]
"The situation is... not good.
[cpg cn=true]

Amane 's illness had not been cured. This situation, it is understandable.
[cpg]

But why does she not remember me, I wondered.
[cpg]

[OnName num="hospital_officials1"]
"'She's lost her memory,' he said. Or, more accurately, she lost them from herself."
[cpg cn=true]

It's said that when a person is continually under intense stress, their defence instincts kick in and they can lose their memory.
[cpg]

For Amane , Shinji was the very reason for living, but he couldn't see her every day, and he couldn't die himself in the hospital.
[cpg]

As a result, he says, he became the way he is now.
[cpg]

Since he lost his memory, he has been wandering around as if he were searching for something he lost.
[cpg]

[OnName num="hospital_officials1"]
"But that's not going to be easy anymore.
[cpg cn=true]

[OnName num="shinzi"]
"What do you mean?
[cpg cn=true]

The hospital is troubled by her frequent behavior, and if it is determined that further treatment is difficult, she will be placed in an appropriate facility.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]





;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[stopse g=2]
[stopse g=6]
;//ブラックアウト




[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="insecurity"]
[BG f="b_si_d_t1_0.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　昼

[WAIT time=1000]


[FG f="youko_p6_30_a.ui" method="change_1" pos="2/5" time=800]
[FG f="yukika_p5_01_a.ui" method="change_7" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Yukika0196"]
[OnName num="yukika"]
" Shinji ?　Are you listening?"
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, yeah, I'm here.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0372"]
[OnName num="youko"]
"What's the matter with you? You're in a daze.
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0197"]
[OnName num="yukika"]
"What's going on?
[cpg cn=true]

[OnName num="shinzi"]
"No, nothing's wrong.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0373"]
[OnName num="youko"]
"Well, that's good, because...
[cpg cn=true]

A few days had passed since then, but my mind was still in turmoil.
[cpg]

It's like I'm desperately trying to get out of a maze with no way out.
[cpg]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0198"]
[OnName num="yukika"]
"By the way, are you two doing well in college?
[cpg cn=true]

[OnName num="shinzi"]
"Hmm... yeah.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0374"]
[OnName num="youko"]
"Yes. It's a lot more work than I thought it would be, but it's tough.
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0199"]
[OnName num="yukika"]
"We're going to have a break soon, aren't we?　Maybe we can go out somewhere then.
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0375"]
[OnName num="youko"]
"That sounds great!　Where should we go?
[cpg cn=true]

It's a perfectly peaceful conversation, but it's hard to get into.
[cpg]





;//ブラックアウト


;//loop
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="h2"]
[BG f="b_si_r_t4_0.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　夜

[WAIT time=1000]



I had heard about the current state of Amane and was troubled by the thought.
[cpg]

You will find a lot of things that you can do to make your life easier.
[cpg]

But I know.
[cpg]

I know that Amane is one of the victims. It's too bad for her.
[cpg]



;//回想　昔の雨音

[BG f="black.ui" time=800]
[WAIT time=1000]

[FG f="amane_p5_01_a.ui" method="change_2" pos="3/5" time=800]
[WAIT time=100]
[VOICE f="Amane1119"]
[OnName num="amane"]
" Shinji ♪
[cpg cn=true]

[OnName num="shinzi"]
" Amane ......"
[cpg cn=true]

[STOPBGM]

;//[FG f="youko_p6_30_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Youko0376"]
[OnName num="youko"]
"What about ...............?"
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]






[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="sir"]
[BG f="b_si_r_t4_0.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　夜

[WAIT time=1000]



[FG f="youko_p6_30_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0377"]
[OnName num="youko"]
"Who was ...... you calling?"
[cpg cn=true]

Yoko 's voice was low and very sharp.
[cpg]

He hadn't noticed her come into the room before he knew it.
[cpg]

[OnName num="shinzi"]
"'No, no... that was ...... just me sleepwalking.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0378"]
[OnName num="youko"]
"......"
[cpg cn=true]

[OnName num="shinzi"]
"Well, in my dreams, ......"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0379"]
[OnName num="youko"]
"...... yeah."
[cpg cn=true]

And then Yoko came up to me and said.
[cpg]

[FG f="youko_p8_30_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0380"]
[OnName num="youko"]
"It's okay. It's okay, Shinji . She's not here anymore."
[cpg cn=true]

[OnName num="shinzi"]
"Yeah... yeah."
[cpg cn=true]

She hugged me gently and said this over and over again like she was nurturing a child.
[cpg]

What would your Yoko and Yukika sisters say if you told them that you had met Amane ?
[cpg]

What would she say if I told her I had a thought in the corner of my head?
[cpg]




[free time=1000]

[BG f="black.ui" time=1000]
;//ブラックアウト
[WAIT time=1000]
[STOPBGM]



.......
[cpg]

.............
[cpg]

...................
[cpg]

Then a few days later.
[cpg]




;//何かが割れる音





;//ブラックアウト




[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="danger"]
[BG f="b_si_d_t1_0.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　昼




[FG f="youko_p6_30_a.ui" method="change_5" pos="2/5" time=800]
[FG f="yukika_p5_01_a.ui" method="change_3" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Yukika0200"]
[OnName num="yukika"]
"What the hell ...... are you thinking?!!!?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0381"]
[OnName num="youko"]
"Yes, Shinji , what are you talking about?　Explain it to me!
[cpg cn=true]

[OnName num="shinzi"]
"......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0201"]
[OnName num="yukika"]
"Do you have any idea what you're talking about?
[cpg cn=true]

[OnName num="shinzi"]
"I know what I'm talking about. ......
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0382"]
[OnName num="youko"]
" Shinji , I'm sorry, that's... that's insane.
[cpg cn=true]

Yeah, I'm sure it is.
[cpg]

I proposed to them that they could live with Amane .
[cpg]

It's not a normal thing to accept.
[cpg]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0383"]
[OnName num="youko"]
"I told you not to mention that name again!　I told you, didn't I?　I don't want to hear it!"
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0202"]
[OnName num="yukika"]
" Yoko , calm down. First of all, explain it to me in order. What the fuck is going on?
[cpg cn=true]

[OnName num="shinzi"]
"It was .......
[cpg cn=true]

I explained the whole thing to both of them.
[cpg]




;//ブラックアウト




[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="insecurity"]
[BG f="b_si_d_t1_0.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　昼


[WAIT time=1000]


[FG f="yukika_p5_01_a.ui" method="change_7" pos="4/5" time=800]
[FG f="youko_p6_30_a.ui" method="change_7" pos="2/5" time=800]

[WAIT time=100]
[VOICE f="Yukika0203"]
[OnName num="yukika"]
"Okay..."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0204"]
[OnName num="yukika"]
"But you can't do what Shinji wants you to do.
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0384"]
[OnName num="youko"]
"No, you can't. That's why it's happening!
[cpg cn=true]

[OnName num="shinzi"]
"The Amane of today is not the Amane of then. That's why.
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0385"]
[OnName num="youko"]
"No, it's not!
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0205"]
[OnName num="yukika"]
"That's too much wishful thinking.
[cpg cn=true]

It was a bad idea from the start.
[cpg]

This is a great way to get the most out of your business.
[cpg]

Even so, I wanted to talk to them because we were the only ones who knew about the Amane situation.
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0206"]
[OnName num="yukika"]
I know you feel sorry for her," he said. I understand that you feel sorry for her, but it's not a problem that can be solved with such feelings.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Youko0386"]
[OnName num="youko"]
"That's right, Shinji . Forget it, okay?　That's what makes you happy.
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0207"]
[OnName num="yukika"]
"That's right. You have to think about your own happiness, not other people's. That's what your aunt would want.
[cpg cn=true]

[OnName num="shinzi"]
"......
[cpg cn=true]

[free time=800]

Mother. What would my mother say if she were alive?
[cpg]

The one that indirectly took my husband's life and my father's life.
[cpg]

What she did at my mother's funeral.
[cpg]

The list goes on and on, all of which were events that I couldn't even begin to meditate on.
[cpg]

Still, not all of them were ...... Amane bad.
[cpg]

[FG f="youko_p8_30_a.ui" method="change_3" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Youko0387"]
[OnName num="youko"]
"Hey Shinji , are you listening?　Don't think crazy!　Hey, answer me!　You have to promise me something!
[cpg cn=true]

[OnName num="shinzi"]
"........."
[cpg cn=true]

She's not going to be saved.
[cpg]

Only people who know her will be able to save her.
[cpg]

So her life will come to an end.
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
;//ブラックアウト


[WAIT time=1000]


If you meditate, look away, and forget, that's the end of one's life.
[cpg]

Instead, your life will be saved.
[cpg]

Yes, that's it.
[cpg]

It's happening all over the world.
[cpg]

There's no reason for me to feel responsible for it.
[cpg]



[BG f="black.ui" time=1000]
;//ブラックアウト
[STOPBGM]
[WAIT time=1000]

It's not my fault.
[cpg]


;//笑っている雨音


[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1120"]
[OnName num="amane"]
" Shinji "
[cpg cn=true]





[BG f="b_ex_as_1.ui" time=1000]

;//新居アパート
;//ぎらつく太陽から段々と視界がクリアになっていく



[FG f="amane_p5_32_a.ui" method="change_7" pos="2/3" time=1000]

[WAIT time=1000]
[WAIT time=1000]

[WAIT time=100]
[VOICE f="Amane1121"]
[OnName num="amane"]
"...... Are you okay?
[cpg cn=true]

[OnName num="shinzi"]
"Uh, yeah, uh...
[cpg cn=true]

She, Amane , was looking at me with concern.
[cpg]

[BGM f="insecurity"]

[OnName num="shinzi"]
"It's okay, the sun was a little strong today.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
;//[FG f="amane_p5_32_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1122"]
[OnName num="amane"]
"Yes..."
[cpg cn=true]

I've decided to live with Amane .
[cpg]

Naturally, the Yukika sister, Yoko and the hospital were vehemently opposed to the idea.
[cpg]

But I pushed through it and went ahead with the story.
[cpg]

[OnName num="shinzi"]
"Now, let's quickly take the luggage to the room.
[cpg cn=true]

[FG f="amane_p6_32_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1123"]
[OnName num="amane"]
"Yes."
[cpg cn=true]

[FO pos="2/3" time=800]

A small apartment with a small room.
[cpg]

This was where we were going to live.
[cpg]

It was the only one we could afford.
[cpg]

We both don't have much in the way of luggage.
[cpg]

[FG f="amane_p5_32_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1124"]
[OnName num="amane"]
"I'm not sure what to say. Thank you for getting us out of there. And for being my guardian."
[cpg cn=true]

[OnName num="shinzi"]
"No, thank you.
[cpg cn=true]

[FG f="amane_p6_32_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1125"]
[OnName num="amane"]
"Why are you doing this for me?
[cpg cn=true]

I was at a loss for an answer.
[cpg]

What is the right answer? In the first place, there is probably no right answer.
[cpg]

This choice itself may be a mistake.
[cpg]

[OnName num="shinzi"]
"Well, I'm sure we had a connection.
[cpg cn=true]

The answer Amane did not seem to be very satisfactory.
[cpg]

[FG f="amane_p5_32_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1126"]
[OnName num="amane"]
"I'm not sure I've introduced myself yet. I'm Amane ."
[cpg cn=true]

[OnName num="youhei"]
"I'm Yohei . Nice to meet you.
[cpg cn=true]

A new life begins in a small apartment.
[cpg]

I've told Amane that I'm her guardian, but we're married in the family register.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

In order not to stimulate the memory of Amane , I decided to change my name and start the relationship all over again.
[cpg]




[free time=800]
[BG f="black.ui" time=800]
;//ブラックアウト

[WAIT time=1000]



[OnName num="youhei"]
"Huh... that's exhausting."
[cpg cn=true]

As I walk up the stairs of my apartment, I think to myself.
[cpg]

Is what I'm doing to atone for my sins, or is it just self-satisfaction? Or is it both?
[cpg]

If I could, I'd like to continue my days in peace.
[cpg]

But in just a moment, everything could disappear.
[cpg]

The anxiety of living such days never goes away. I'm always frightened.
[cpg]



[BG f="b_ex_as_4.ui" time=1000]
[WAIT time=1000]
;//新居アパート　六畳一間



[FG f="amane_p5_32_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1127"]
[OnName num="amane"]
"Welcome home.
[cpg cn=true]

[OnName num="youhei"]
"Yeah, I'm back.
[cpg cn=true]

[FG f="amane_p6_32_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1128"]
[OnName num="amane"]
"Something wrong?
[cpg cn=true]

[OnName num="youhei"]
"No, nothing!　What?　Something smells good.
[cpg cn=true]

[FG f="amane_p5_32_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1129"]
[OnName num="amane"]
"I made you some dinner, if you want.
[cpg cn=true]

[OnName num="youhei"]
"Oh, really?　Oh, my God, that looks delicious!　I'll eat it!　I'll eat it!
[cpg cn=true]

[FG f="amane_p6_32_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1130"]
[OnName num="amane"]
"Cousin. Here you go."
[cpg cn=true]

When I returned to my small apartment, Amane greeted me and there was a hot dinner.
[cpg]

I felt a small happiness there.
[cpg]

The woman she is now is not the same as the woman she used to be.
[cpg]

Still, ...... she hoped that this would last as long as possible.
[cpg]

[FG f="amane_p5_32_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1131"]
[OnName num="amane"]
"Um, Mr. Yohei ."
[cpg cn=true]

[OnName num="youhei"]
"What's up?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1132"]
[OnName num="amane"]
"I think I'm going to work.
[cpg cn=true]

[OnName num="youhei"]
"...... What's going on?
[cpg cn=true]

[FG f="amane_p6_32_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1133"]
[OnName num="amane"]
"I can't just leave you in charge.
[cpg cn=true]

[OnName num="youhei"]
"You don't have to do this.
[cpg cn=true]

[FG f="amane_p5_32_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1134"]
[OnName num="amane"]
"It's not going to change anything. It's the same as when we were there.
[cpg cn=true]

Somewhere in the back of my mind, I'm worried.
[cpg]

Maybe that's what's keeping Amane me from doing anything.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1135"]
[OnName num="amane"]
"I want to experience normal.
[cpg cn=true]

[OnName num="youhei"]
"Normal..."
[cpg cn=true]

Knowing her before, I know how hard it is to do.
[cpg]

[OnName num="youhei"]
What do you mean, "I want to experience normal"?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1136"]
[OnName num="amane"]
"I can't remember. But... the last time I was here, I left something behind.
[cpg cn=true]

[OnName num="youhei"]
"What?
[cpg cn=true]

[FG f="amane_p6_32_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1137"]
[OnName num="amane"]
"I want to be normal. I want to be normal.
[cpg cn=true]

That's what she wrote in her notebook.
[cpg]

That was the last thing she wished for before she lost her memory. That's why she wanted to be normal.
[cpg]

Amane wanted to be normal. No, it could be said that they are adamant about it.
[cpg]

You will find a lot of people who are looking for the best way to get the best out of you.
[cpg]

[OnName num="youhei"]
"I'm sure you're right. I'm sure there are many different kinds of normal in the world, so let's try a few of them."
[cpg cn=true]

[FG f="amane_p5_32_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1138"]
[OnName num="amane"]
"Yes, please."
[cpg cn=true]

[OnName num="youhei"]
"Okay. Well, let's start with the job search that Amane wanted.
[cpg cn=true]

I thought about asking the company I work for, but Amane refused.
[cpg]

She said she wanted to be independent and would look for a job on her own.
[cpg]

I helped her out and after a few weeks...I managed to find a job.
[cpg]

After all that happened, I had a sneaking suspicion.
[cpg]

The Amane of today is not the same as before. Maybe it's just that ......
[cpg]




[free time=800]
[BG f="black.ui" time=800]
;//ブラックアウト
[WAIT time=900]




[BG f="b_ex_as_4.ui" time=1000]
[WAIT time=1000]
;//新居アパート　六畳一間





Our life is a lot more smooth sailing than before.
[cpg]

We're spending our days as normal and ordinary as she wanted us to be.
[cpg]

[FG f="amane_p5_32_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1139"]
[OnName num="amane"]
"Um... I have a question.
[cpg cn=true]

[OnName num="youhei"]
"'What's the matter?'
[cpg cn=true]

[FG f="amane_p6_32_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1140"]
[OnName num="amane"]
"'Should I be married?'
[cpg cn=true]

It was an unexpected question.
[cpg]

She had heard such talk from her colleagues and aunts at work.
[cpg]

[FG f="amane_p5_32_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1141"]
[OnName num="amane"]
"They said it was normal for someone my age.
[cpg cn=true]

[OnName num="youhei"]
"I see.
[cpg cn=true]

She wants to be normal, and she's troubled by that. That's true.
[cpg]

If you think of normal in the world, you get married, have children, and build a happy family.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1142"]
[OnName num="amane"]
"I'm not sure what to make of it.
[cpg cn=true]

Amane is a beautiful woman, so there will be many men who will woo her.
[cpg]

If she wants to, she should do so. That's what Yohei I thought.
[cpg]

Since you are married to yourself, you can get a divorce and you have to explain the situation to the other man properly.


If you're willing to be with her after that, ......
[cpg]

[OnName num="youhei"]
"What do you want Amane to do?　You need to take care of your own feelings rather than just saying you want to be normal.
[cpg cn=true]

She closed her mouth when she said that.
[cpg]




[free time=800]
[BG f="black.ui" time=800]
;//ブラックアウト



[WAIT time=1000]


After a while...
[cpg]



[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BG f="b_ex_tw_t1_0.ui" time=1000]
;//【ＢＧ】街　夕方

;//loop
[SE f="se007" loop=true]
;//雨の音

;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

[WAIT time=1000]
[BGM f="healing"]


The two of us went to the supermarket to buy dinner, on the way back.
[cpg]

[FG f="amane_p8_32_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1143"]
[OnName num="amane"]
"The other day...
[cpg cn=true]

Amane I'm not sure what to make of it.
[cpg]

I'm not sure what to make of it.
[cpg]

She cut me off on that.
[cpg]

[FG f="amane_p7_32_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1144"]
[OnName num="amane"]
"'I refused to talk about it the other day.
[cpg cn=true]

[OnName num="youhei"]
"You mean you turned down... marriage?"
[cpg cn=true]

Amane I'm not sure what to make of that.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1145"]
[OnName num="amane"]
"It's still in the dating stage, but I declined.
[cpg cn=true]

This is a great way to make sure you are getting the most out of your money.
[cpg]



[FG f="amane_p8_32_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1146"]
[OnName num="amane"]
"You can find a lot of people who are interested in this kind of thing. I want to live a normal life. But it should be with ...... Yohei ."
[cpg cn=true]

It was another unexpected answer.
[cpg]

The memory of Amane has not returned.
[cpg]

You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

[OnName num="youhei"]
" Amane ..."
[cpg cn=true]

[FG f="amane_p7_32_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1147"]
[OnName num="amane"]
"'How about Yohei ...?'
[cpg cn=true]

She was as pure as could be.
[cpg]

I was ready to do the same. Not out of guilt or pity.
[cpg]

[OnName num="youhei"]
"I've been thinking the same thing. For a long, long time..."
[cpg cn=true]

[FG f="amane_p7_32_a.ui" method="change_2" pos="2/3" time=800]

I'll fall in love with her again, fall in love with her again, and this time I'll walk the path that I couldn't walk before.
[cpg]


[free time=900]
[BG f="black.ui" time=1500]

;//loop
[stopse g=2]
[stopse g=6]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[WAIT time=2000]


{
	tf["flag2"] <- true;
}
[jump storage="epend.ks" target="*start"]


[free time=900]

*afterend2



[BG f="black.ui" time=1500]
[WAIT time=2000]
[STOPBGM]

[window target=true]

Long months passed since then.
[cpg]


[BG f="b_h_ro_t1_0.ui" time=3000]
;//【ＢＧ】病室　雨

[WAIT time=4000]

[BGM f="ed"]



[BG f="b_h_ro_t1_0_lup.ui" time=2000]
[WAIT time=3000]
[FG f="amane_p9_32_last_1.ui" pos="2/3" time=2000]
[WAIT time=3000]



She was in the hospital room.
[cpg]

[FO pos="2/3" time=2000]
[BG f="b_h_ro_t1_0_rup.ui" time=2000]
[WAIT time=3000]

It was raining again today.
[cpg]

[BG f="white.ui" time=2000]
[WAIT time=3000]


The room was full of cards addressed to someone.
[cpg]


[FG f="amane_p9_32_last_1.ui" pos="2/3" time=1000]

[WAIT time=2000]


[FG f="amane_p9_32_last_2.ui" pos="2/3" time=2000]

[WAIT time=3000]
[VOICE f="Amane1148"]
[OnName num="amane"]
"Thank you. ......-kun."
[cpg cn=true]

She fell into a long sleep, watched by a lot of rain.
[cpg]



;//[BG f="white.ui" time=1000]
[FO pos="2/3" time=3000]
;//ホワイトアウト
[WAIT time=3000]




[system end8=true]
[SCENE id=36]
;//END『New Call Rain』


*back_title
[BG f="black.ui" time=2000]
[WAIT time=2000]

;//何もなければタイトルへ戻る





