*start

;#################################################
*Ep014|A moment of peace.
;#################################################
[SCENE id=14]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[STOPBGM]
[BGM f="insecurity"]
[BG f="b_si_r_t3_0.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　夕方　曇り





[FG f="youko_p6_03_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0224"]
[OnName num="youko"]
"It's been a while. Shinji 's room ......"
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, ......"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0225"]
[OnName num="youko"]
"I've got the first seven days of the new year and everything, but ......, would you mind if I came back and helped out?
[cpg cn=true]

[OnName num="shinzi"]
"I want you to come to .......
[cpg cn=true]

[FG f="youko_p8_03_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0226"]
[OnName num="youko"]
"Yeah. ......
[cpg cn=true]

I buried my face in the Yoko body as if to cling to it.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0227"]
[OnName num="youko"]
"I'll come ....... I'll come Shinji on the first anniversary, the third anniversary, and ...... all the way until I'm well."
[cpg cn=true]

[OnName num="shinzi"]
"Yeah ......."
[cpg cn=true]

Yoko gently stroked my head as I clung to it.
[cpg]




Warm....
[cpg]

You can feel the warmth from Yoko that you can't feel from Amane .
[cpg]

Just by touching the gentle Yoko body, you will feel as if your evil heart is purified.
[cpg]

[transition target={true} rule="sita.jpg"  time=1200]
[BG f="black.ui" time=1200]
[WAIT time=1200]
[free time=0]
;//【ＢＧ】ブラックアウト

[WAIT time=1000]



And so, for a while, I hugged her like a child.
[cpg]

No, just like that. I literally spoiled Yoko her.
[cpg]

All the while, Yoko was stroking my head and accepting me without even a hint of reluctance.
[cpg]

[BG f="b_si_r_t3_0.ui" time=0]
;//【ＢＧ】慎二の家　慎二の部屋　夕方　曇り

[FG f="youko_p6_03_a.ui" method="change_2" pos="2/3" time=0]

[transition target={false} rule="sita.jpg"  time=1200]
[WAIT time=1000]

[OnName num="shinzi"]
"Thank you, ......."
[cpg cn=true]

[FG f="youko_p8_03_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0228"]
[OnName num="youko"]
"So ......, don't be like that. ......"
[cpg cn=true]

Yoko I'm not sure what to say, but I'm sure you'll understand.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

I'm sure you'll agree. Amane I'm not sure what to say, but I'm going to say it.
[cpg]

[OnName num="shinzi"]
" Yoko ......"
[cpg cn=true]

[transition target={true} rule="sita.jpg"  time=1200]
[BG f="black.ui" time=1200]
[WAIT time=1200]

Such a peace of mind is sincerely loved ...... I also hugged Yoko and fell asleep for a while.
[cpg]

[free time=0]
[transition target={false} rule="sita.jpg"  time=0]

[jump storage="ep015.ks" target="*start"]
