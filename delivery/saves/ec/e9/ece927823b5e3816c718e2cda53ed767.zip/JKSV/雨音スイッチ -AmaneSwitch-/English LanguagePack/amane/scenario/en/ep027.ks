*start



;//４-b　そんなの嫌だ
*choise_42

;#################################################
*Ep027|Free Will
;#################################################
[SCENE id=30]
[BG f="b_ex_pk_t1_0.ui"]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]
;//loop
[SE f="se006" loop=true]
;//【雨、大雨】
[BGM f="sir"]

[FG f="yukika_p7_01_a.ui" method="change_4" pos="2/3"]

[OnName num="shinzi"]
"'I don't want to do that!'
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

I said with all my strength.
[cpg]

[OnName num="shinzi"]
"I don't want this to be the end, even though we've come to understand each other's feelings!　I don't care if we're related by blood!　What about your parents and relatives?
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0181"]
[OnName num="yukika"]
"Shh. Shinji ......
[cpg cn=true]

[OnName num="shinzi"]
"I don't care if they disagree with me. I'm Yukika going to be with my sister!　I'm going to grow up and be able to provide for my sister!　So don't tell me this is the end. I love you!!!"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0182"]
[OnName num="yukika"]
"Are you serious .........?"
[cpg cn=true]

This is a great way to make sure you are getting the most out of your money.
[cpg]

[OnName num="shinzi"]
"You can get a lot more than that. You'll be able to't ever let go.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0183"]
[OnName num="yukika"]
"You can get a lot more information on the web. I also want to be with Shinji . I'm not going on a blind date. ......
[cpg cn=true]

[OnName num="shinzi"]
"Absolutely. ......
[cpg cn=true]

[FG f="yukika_p7_01_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0184"]
[OnName num="yukika"]
"I promise. ......
[cpg cn=true]

The secret act was put away in our chest with the secret promise.
[cpg]

From now on, I'm going to study a lot and become a great adult.
[cpg]

And then, Yukika I will become a man who will not embarrass my sister, and one day I will ask her to marry me.
[cpg]

That's what I decided ...... in my mind.
[cpg]

;//loop
[SE f="se006" loop=true]
;//【ＳＥ】雨


;//木陰から見ているずぶ濡れの雨音

[free time=400]

[BG f="black.ui" time=1000]
;//ブラックアウト
[WAIT time=1000]

;//[FG f="amane_p1_02_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1019"]
[OnName num="amane"]
" Shinji ... Shinji ...... will not forgive... will not forgive... will not forgive. ..."
[cpg cn=true]



;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_ex_sz_t3_3.ui" time=1000]
;//【ＢＧ】通学路　夜　豪雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]

;//【雨、大雨】

[WAIT time=2000]


;//土砂降り

;//loop
[stopse g=2]
[stopse g=6]

;//loop
[SE f="se006" loop=true]
;//【ＳＥ】土砂降り


[SE f="se131"]
;//【ＳＥ】迫り来る足音





;//[FG f="amane_p1_02_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1020"]
[OnName num="amane"]
" Shinji ... Shinji ... Shinji ... Shinji ......"
[cpg cn=true]

Late at night, when everything was quiet, Amane came alone to Shinji 's house.
[cpg]







No matter what happens, Shinji will come back to him.
[cpg]

He believed in it.
[cpg]

[FG f="amane_p5_02_a.ui" method="change_8" pos="2/3" time=2000]
[WAIT time=100]
[VOICE f="Amane1021"]
[OnName num="amane"]
" Shinji ... Shinji ... Shinji ... Shinji ......"
[cpg cn=true]

If you're not sure what you're looking for, you can always ask for help.
[cpg]




[SE f="se017"]
;//【ＳＥ】チャイム

[WAIT time=3000]



;//[FG f="youko_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0292"]
[OnName num="youko"]
"I knew you'd be here.
[cpg cn=true]

;//[FG f="amane_p5_02_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1022"]
[OnName num="amane"]
"I'm sorry.
[cpg cn=true]

;//[free time=800]

It's a good idea to have a good idea of what you're doing.
[cpg]


[move from="2/3" to="2/4" ease="easeInOutSine" time=3000]

[FG f="youko_p5_02_a.ui" method="change_3" pos="1/4" time=3000]
[FG f="shizuku_p5_02_a.ui" method="change_3" pos="3/4" time=3000]
[FG f="izumi_p5_02_a.ui" method="change_3" pos="4/4" time=3000]

[WAIT time=2000]

[WAIT time=100]
[VOICE f="Izumi0228"]
[OnName num="izumi"]
"Don't you think it's disturbing at this hour?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0217"]
[OnName num="shizuku"]
"Perverts. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0293"]
[OnName num="youko"]
"I figured if I waited here, he'd show up at some point, so I waited.
[cpg cn=true]

There were Yoko and Kizaki Sisters standing there, soaking wet, just like Amane .
[cpg]

[FG f="amane_p6_02_a.ui" method="change_5" pos="2/4" time=800]
[FG f="youko_p5_02_a.ui" method="change_3" pos="1/4" time=0]
[FG f="shizuku_p5_02_a.ui" method="change_3" pos="3/4" time=0]
[FG f="izumi_p5_02_a.ui" method="change_3" pos="4/4" time=0]
[WAIT time=100]
[VOICE f="Amane1023"]
[OnName num="amane"]
"Why ......?"
[cpg cn=true]

[FACE method="change_5" pos="1/4"]

[WAIT time=100]
[VOICE f="Youko0294"]
[OnName num="youko"]
"Why?　You've been expelled from school because of you!
[cpg cn=true]

;//[FACE method="change_4" pos="3/4"]

[WAIT time=100]
[VOICE f="Izumi0229"]
[OnName num="izumi"]
"We can't stay at the school anymore. ......
[cpg cn=true]

[FACE method="change_3" pos="4/4"]

[WAIT time=100]
[VOICE f="Shizuku0218"]
[OnName num="shizuku"]
"You did that video, didn't you?
[cpg cn=true]

[FACE method="change_7" pos="2/4"]
;//[FG f="amane_p6_02_a.ui" method="change_7" pos="2/4" time=800]

[WAIT time=100]
[VOICE f="Amane1024"]
[OnName num="amane"]
"The video ......?
[cpg cn=true]

But the voice of Amane does not reach the girls who are at the height of their anger.
[cpg]

;//[FACE method="change_7" pos="3/4"]

[WAIT time=100]
[VOICE f="Izumi0230"]
[OnName num="izumi"]
"You and your father are going to pay for what you did!
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/4" time=800]
[FG f="youko_p5_02_a.ui" method="change_3" pos="1/4" time=0]
[FG f="shizuku_p5_02_a.ui" method="change_3" pos="3/4" time=0]
[FG f="izumi_p5_02_a.ui" method="change_3" pos="4/4" time=0]

[WAIT time=100]
[VOICE f="Amane1025"]
[OnName num="amane"]
"My father ....... I had nothing to do with my father. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0219"]
[OnName num="shizuku"]
"Shut the fuck up!
[cpg cn=true]

[move from="3/4" to="3/5" ease="easeInOutSine" time=200]
[WAIT time=200]
[SE f="se001"]
;//【ＳＥ】ビンタ

[free time=0]
[BG f="white.ui" time=0]
[WAIT time=1]
[FG f="amane_p5_02_a.ui" method="change_4" pos="2/4" time=500]
[FG f="youko_p5_02_a.ui" method="change_3" pos="1/4" time=500]
[FG f="shizuku_p5_02_a.ui" method="change_3" pos="3/5" time=500]
[FG f="izumi_p5_02_a.ui" method="change_3" pos="4/4" time=500]
[WAIT time=1]
[move from="3/5" to="3/4" ease="easeInOutSine" time=200]
[WAIT time=500]

[BG f="b_ex_sz_t3_3.ui" time=500]




[WAIT time=100]
[VOICE f="Amane1026"]
[OnName num="amane"]
"Ugh!
[cpg cn=true]

The slap that Shizuku threw with all its might hit Amane on the cheek.
[cpg]


[WAIT time=100]
[VOICE f="Youko0295"]
[OnName num="youko"]
"You're ruining the lives of everyone around you just by being here!
[cpg cn=true]

[move from="1/4" to="2/6" ease="easeInOutSine" time=200]
[WAIT time=200]
[SE f="se040"]
;//【ＳＥ】バキッ！
[free time=0]
[BG f="red.ui" time=0]
[WAIT time=1]
[FG f="amane_p5_02_a.ui" method="change_4" pos="2/4" time=500]
[FG f="youko_p5_02_a.ui" method="change_3" pos="2/6" time=500]
[FG f="shizuku_p5_02_a.ui" method="change_3" pos="3/4" time=500]
[FG f="izumi_p5_02_a.ui" method="change_3" pos="4/4" time=500]
[WAIT time=1]
[move from="2/6" to="1/4" ease="easeInOutSine" time=200]
[WAIT time=500]

[BG f="b_ex_sz_t3_3.ui" time=500]

[WAIT time=100]
[VOICE f="Amane1027"]
[OnName num="amane"]
"Agh!"
[cpg cn=true]

[FO pos="2/4" time=1000]

[SE f="se024"]
;//【ＳＥ】ズシャーッ！


Yoko 's fist went into his face, and Amane dived bodily into the mud.
[cpg]


[WAIT time=100]
[VOICE f="Izumi0231"]
[OnName num="izumi"]
"Stand up.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0220"]
[OnName num="shizuku"]
"Get up!
[cpg cn=true]

[move from="3/4" to="3/5" ease="easeInOutSine" time=200]
[WAIT time=200]
[SE f="se023"]
;//【ＳＥ】ボスッ！

[free time=0]
[BG f="red.ui" time=0]
[WAIT time=1]
;//[FG f="amane_p5_02_a.ui" method="change_4" pos="2/4" time=500]
[FG f="youko_p5_02_a.ui" method="change_3" pos="1/4" time=500]
[FG f="shizuku_p5_02_a.ui" method="change_3" pos="3/5" time=500]
[FG f="izumi_p5_02_a.ui" method="change_3" pos="4/4" time=500]
[WAIT time=1]
[move from="3/5" to="3/4" ease="easeInOutSine" time=200]
[WAIT time=500]

[BG f="b_ex_sz_t3_3.ui" time=500]


;//[FG f="amane_p6_02_a.ui" method="change_4" pos="2/4" time=800]
[WAIT time=100]
[VOICE f="Amane1028"]
[OnName num="amane"]
"G...!
[cpg cn=true]

Shizuku 's little foot went into his groin, and he choked.
[cpg]

;//[FACE method="change_7" pos="3/4"]

[WAIT time=100]
[VOICE f="Shizuku0221"]
[OnName num="shizuku"]
"I've been kicked like this by your father!　Every time it rains, like this!　Like this!"
[cpg cn=true]

[move from="3/4" to="3/5" ease="easeInOutSine" time=200]
[WAIT time=200]
[SE f="se056"]
;//【ＳＥ】ボスッ！ボスッ！ボスッ！
[free time=0]
[BG f="red.ui" time=0]
[WAIT time=100]
;//[FG f="amane_p5_02_a.ui" method="change_4" pos="2/4" time=500]
[FG f="youko_p5_02_a.ui" method="change_3" pos="1/4" time=500]
[FG f="shizuku_p5_02_a.ui" method="change_3" pos="3/5" time=500]
[FG f="izumi_p5_02_a.ui" method="change_3" pos="4/4" time=500]
[move from="3/5" to="3/4" ease="easeInOutSine" time=200]
[BG f="b_ex_sz_t3_3.ui" time=500]
[WAIT time=500]


[move from="3/4" to="3/5" ease="easeInOutSine" time=200]
[WAIT time=200]
[SE f="se056"]
;//【ＳＥ】ボスッ！ボスッ！ボスッ！
[free time=0]
[BG f="red.ui" time=0]
[WAIT time=100]
;//[FG f="amane_p5_02_a.ui" method="change_4" pos="2/4" time=500]
[FG f="youko_p5_02_a.ui" method="change_3" pos="1/4" time=500]
[FG f="shizuku_p5_02_a.ui" method="change_3" pos="3/5" time=500]
[FG f="izumi_p5_02_a.ui" method="change_3" pos="4/4" time=500]
[move from="3/5" to="3/4" ease="easeInOutSine" time=200]
[BG f="b_ex_sz_t3_3.ui" time=500]
[WAIT time=500]

[move from="3/4" to="3/5" ease="easeInOutSine" time=200]
[WAIT time=200]
[SE f="se056"]
;//【ＳＥ】ボスッ！ボスッ！ボスッ！
[free time=0]
[BG f="red.ui" time=0]
[WAIT time=100]
;//[FG f="amane_p5_02_a.ui" method="change_4" pos="2/4" time=500]
[FG f="youko_p5_02_a.ui" method="change_3" pos="1/4" time=500]
[FG f="shizuku_p5_02_a.ui" method="change_3" pos="3/5" time=500]
[FG f="izumi_p5_02_a.ui" method="change_3" pos="4/4" time=500]
[move from="3/5" to="3/4" ease="easeInOutSine" time=200]
[BG f="b_ex_sz_t3_3.ui" time=500]
[WAIT time=500]


;//[FG f="amane_p5_02_a.ui" method="change_4" pos="1/4" time=800]
[WAIT time=100]
[VOICE f="Amane1029"]
[OnName num="amane"]
"Aagh!　Ow!　No, no, no, no, no...
[cpg cn=true]

You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

[FG f="amane_p6_02_a.ui" method="change_7" pos="2/4" time=2000]
[FG f="youko_p5_02_a.ui" method="change_3" pos="1/4" time=0]
[FG f="shizuku_p5_02_a.ui" method="change_3" pos="3/4" time=0]
[FG f="izumi_p5_02_a.ui" method="change_3" pos="4/4" time=0]
[WAIT time=100]
[VOICE f="Amane1030"]
[OnName num="amane"]
"You can find a lot more information on the web at .......
[cpg cn=true]

This is a great way to make sure you are getting the most out of your vacation.
[cpg]


[WAIT time=100]
[VOICE f="Amane1031"]
[OnName num="amane"]
" Shinji ku...n, help me ......."
[cpg cn=true]

[SE f="se025"]
;//【ＳＥ】チャイム連打


[FACE method="change_5" pos="1/4"]

[WAIT time=100]
[VOICE f="Youko0296"]
[OnName num="youko"]
"Stop!
[cpg cn=true]

[move from="1/4" to="2/7" ease="easeInOutSine" time=200]
[WAIT time=200]
[FG f="amane_p5_02_a.ui" method="change_5" pos="2/4" time=800]
[FG f="youko_p5_02_a.ui" method="change_3" pos="2/7" time=0]
[FG f="shizuku_p5_02_a.ui" method="change_3" pos="3/4" time=0]
[FG f="izumi_p5_02_a.ui" method="change_3" pos="4/4" time=0]
[WAIT time=100]
[VOICE f="Amane1032"]
[OnName num="amane"]
"No!"
[cpg cn=true]

He grabbed her by the hair, and just after Amane she was pulled down after ......
[cpg]

[SE f="se035"]
;//【ＳＥ】ドア開く

[WAIT time=2000]

[FACE method="change_2" pos="2/4"]

[WAIT time=100]
[VOICE f="Amane1033"]
[OnName num="amane"]
" Shinji and ......!"
[cpg cn=true]

The front door opened and I thought Shinji had come to my rescue.
[cpg]

But ......
[cpg]

[free time=800]

[FG f="yukika_p5_01_a.ui" method="change_4" pos="1/5" time=2000]
[WAIT time=100]
[VOICE f="Yukika0185"]
[OnName num="yukika"]
"Who ......?"
[cpg cn=true]

It wasn't Shinji but Yukika who had taken Shinji away from Amane .
[cpg]

[FG f="amane_p6_02_a.ui" method="change_3" pos="3/5" time=800]
[WAIT time=100]
[VOICE f="Amane1034"]
[OnName num="amane"]
"So ......, why are you in Shinji 's house at this hour?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0186"]
[OnName num="yukika"]
"You ......, yeah ...... Yoko to ...... Even Kizaki ."
[cpg cn=true]


[FG f="youko_p5_02_a.ui" method="change_3" pos="2/5" time=1000]
[FG f="shizuku_p5_02_a.ui" method="change_3" pos="4/5" time=1000]
[FG f="izumi_p5_02_a.ui" method="change_3" pos="5/5" time=1000]


It's a surreal sight to see four girls standing around soaking wet at such an insane hour.
[cpg]

But before anyone could answer Yukika 's question, a crazed Amane pounced on her.
[cpg]

[FG f="amane_p5_02_a.ui" method="change_3" pos="3/5" time=500]
[FG f="youko_p5_02_a.ui" method="change_3" pos="2/5" time=0]
[FG f="shizuku_p5_02_a.ui" method="change_3" pos="4/5" time=0]
[FG f="izumi_p5_02_a.ui" method="change_3" pos="5/5" time=0]
[WAIT time=100]
[VOICE f="Amane1035"]
[OnName num="amane"]
"Where's Shinji ?　I know you're there!　Call him!　 Shinji !　Come on out, Shinji !
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0187"]
[OnName num="yukika"]
"Hey... be quiet. You'll wake him up.
[cpg cn=true]

[SE f="se036"]
;//【ＳＥ】ドア締まる


[FACE method="change_5" pos="3/5"]

[WAIT time=100]
[VOICE f="Amane1036"]
[OnName num="amane"]
"!"
[cpg cn=true]

[free time=1000]
[BGM f="danger"]

Yukika closes the door behind him and says condescendingly to Amane .
[cpg]

;//[FACE method="change_3" pos="2/5"]
[FG f="yukika_p5_01_a.ui" method="change_3" pos="1/5" time=800]

[FG f="amane_p6_02_a.ui" method="change_5" pos="3/5" time=800]

[WAIT time=100]
[VOICE f="Yukika0188"]
[OnName num="yukika"]
"You've got to stop bothering people. Do you have any idea what Shinji has been through because of you?"
[cpg cn=true]


[FG f="youko_p5_02_a.ui" method="change_3" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Youko0297"]
[OnName num="youko"]
"Yes, I do!　You're a nuisance to Shinji just by being alive!
[cpg cn=true]


[FG f="izumi_p5_02_a.ui" method="change_3" pos="5/5" time=800]
[WAIT time=100]
[VOICE f="Izumi0232"]
[OnName num="izumi"]
"Get lost!
[cpg cn=true]


[FG f="shizuku_p5_02_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shizuku0222"]
[OnName num="shizuku"]
"Get lost!
[cpg cn=true]

[FACE method="change_3" pos="3/5"]
;//[FG f="amane_p5_02_a.ui" method="change_3" pos="3/5" time=800]
[WAIT time=100]
[VOICE f="Amane1037"]
[OnName num="amane"]
"No! No!　 I want to see Shinji !　Let me talk to him!　Please, please, please, please!
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0189"]
[OnName num="yukika"]
"Don't touch me!
[cpg cn=true]





;//【ＳＥ】バッ！


[SE f="se024"]
;//【ＳＥ】ズシャーーッ！！



[free time=800]

Yukika vigorously shook off the Amane who was coming at him with muddy hands.
[cpg]

[FG f="amane_p7_02_a.ui" method="change_4" pos="2/3" time=2000]
[WAIT time=100]
[VOICE f="Amane1038"]
[OnName num="amane"]
"Ohhhh ......"
[cpg cn=true]

Amane In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

;//[FG f="amane_p1_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1039"]
[OnName num="amane"]
" Shinji ... Shinji ..."
[cpg cn=true]




[free time=800]
;**【ＣＧ】ev_25_0 ***********************
[CG id=8 index=0 time=1000]
;*****************************************





[WAIT time=100]
[VOICE f="Youko0298"]
[OnName num="youko"]
"'Ki, you're disgusting!　You are!"
[cpg cn=true]




[SE f="se040"]
;//【ＳＥ】ドスッ！

[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_0.ui" time=500]
[WAIT time=500]


[WAIT time=100]
[VOICE f="Amane1040"]
[OnName num="amane"]
Gef...!"　 Shinji ... Shinji ... Shinji ... Shinji ......"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Izumi0233"]
[OnName num="izumi"]
"You're disgusting!
[cpg cn=true]




[SE f="se040"]
;//【ＳＥ】ドスッ！
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=500]

;//[free time=800]
;**【ＣＧ】ev_25_a ***********************
[CG id=8 index=1 time=0]
;*****************************************





[WAIT time=100]
[VOICE f="Amane1041"]
[OnName num="amane"]
"Gef...!　Hahahahahaha.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0223"]
[OnName num="shizuku"]
"What?
[cpg cn=true]

Amane , who had been kicked by Yoko and also by Izumi , started laughing loudly.
[cpg]








[WAIT time=100]
[VOICE f="Amane1042"]
[OnName num="amane"]
Shinji "It's a good idea to have a good idea of what you're looking for.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0190"]
[OnName num="yukika"]
"Hey ......!"
[cpg cn=true]







Amane 's words made the anger in everyone present more apparent.
[cpg]





[WAIT time=100]
[VOICE f="Amane1043"]
[OnName num="amane"]
"Because ........."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0191"]
[OnName num="yukika"]
"Stop it!"
[cpg cn=true]

Before she could continue, Yukika kicked Amane away.
[cpg]




[SE f="se023"]
;//【ＳＥ】ドンッ！

[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]


[WAIT time=500]

[SE f="se024"]
;//【ＳＥ】ズシャーーッ！！


[WAIT time=1500]



[WAIT time=100]
[VOICE f="Amane1044"]
[OnName num="amane"]
"Ahahaha!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0299"]
[OnName num="youko"]
"Fuck!
[cpg cn=true]







[SE f="se056"]
;//【ＳＥ】ドカッ！　ドカッドカッ！

[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=500]

[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=500]

[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=1000]


[WAIT time=100]
[VOICE f="Amane1045"]
[OnName num="amane"]
"Ew!　Agh!　Heh heh heh.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0224"]
[OnName num="shizuku"]
"Die, ....... You're gonna die!
[cpg cn=true]

[SE f="se056"]
;//【ＳＥ】ガスッ！ガスガスガス！

[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=500]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=500]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=1000]


[WAIT time=100]
[VOICE f="Yukika0192"]
[OnName num="yukika"]
"Yeah, ....... You have to die. I beg you, please die!
[cpg cn=true]

[SE f="se055"]
;//【ＳＥ】バキッ！　ドカドカドカ！

[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=500]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=500]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=500]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=500]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=1500]



[WAIT time=100]
[VOICE f="Amane1046"]
[OnName num="amane"]
"Gah...!　Gah... gah...!　Hee... hee... hee... hee...
[cpg cn=true]

The girls' anger was fueled by the synergistic effects of each other, spewing large amounts of dopamine into their brains.
[cpg]

There was no longer anyone to stop this assault, and they kicked Amane around with emotion.
[cpg]


[WAIT time=100]
[VOICE f="Youko0300"]
[OnName num="youko"]
"'Die!　Die!"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Izumi0234"]
[OnName num="izumi"]
"Die!　Die!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0225"]
[OnName num="shizuku"]
"Die!　Die!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0193"]
[OnName num="yukika"]
"Die!　Die! Die!　Die!
[cpg cn=true]

[SE f="se055"]
;//【ＳＥ】めちゃめちゃに蹴る

[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=500]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=500]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=500]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=500]
[BG f="red.ui" time=0]
[WAIT time=1]
[BG f="ev_25_a.ui" time=500]
[WAIT time=1500]

[WAIT time=100]
[VOICE f="Amane1047"]
[OnName num="amane"]
"Mwah...!　G...hmph!
[cpg cn=true]

I don't care if it's your face or your neck, I'm going to kick you.
[cpg]


;//陽子＆泉＆雫＆雪華

[WAIT time=100]
[VOICE f="Vex0001"]
[OnName num="4heroines"]
"Die, die, die, die, die, die, die, die!"
[cpg cn=true]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]



[SE f="se055"]
;//【ＳＥ】めちゃめちゃに蹴る


[transition target={true} rule="amamori2.png" color={0xff0000ff} time=2000]
[WAIT time=2100]
[BG f="red.ui" time=500]
[transition target={false} color={0xff0000ff} time=500]
[WAIT time=2900]


[BG f="b_ex_sz_t3_3.ui" time=1000]
;//【ＢＧ】通学路　夜　豪雨



;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

[WAIT time=1000]




;//[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane1048"]
[OnName num="amane"]
" Shinji ...ku......n......"
[cpg cn=true]

A high-pitched sound, like a hue, came from the throat of Amane , whose eyes and nose were gummed up with mud and blood, and she flopped down and stopped moving.
[cpg]

[FG f="youko_p5_02_a.ui" method="change_3" pos="1/4" time=800]
[FG f="yukika_p5_01_a.ui" method="change_3" pos="2/4" time=800]
[FG f="izumi_p5_02_a.ui" method="change_3" pos="3/4" time=800]
[FG f="shizuku_p5_02_a.ui" method="change_3" pos="4/4" time=800]


[WAIT time=100]
[VOICE f="Youko0301"]
[OnName num="youko"]
"'Huh, huh .......
[cpg cn=true]

[WAIT time=100]
[VOICE f="Izumi0235"]
[OnName num="izumi"]
"Haa...haa ......"
[cpg cn=true]

[WAIT time=100]
[VOICE f="Shizuku0226"]
[OnName num="shizuku"]
"Haah haha ...... haha ......"
[cpg cn=true]

[WAIT time=100]
[VOICE f="Yukika0194"]
[OnName num="yukika"]
"Huh...huh......"
[cpg cn=true]



;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]



[free time=1000]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト
[WAIT time=1000]

[SE f="se035"]
;//【ＳＥ】ドア開く


[OnName num="shinzi"]
"Who's there ......?"
[cpg cn=true]

I peeked out the front door, curious about the human voice I heard mixed in with the sound of the pouring rain.
[cpg]

Then there was ......
[cpg]

[OnName num="shinzi"]
"I'm sure you'll agree that this is a great way to get the most out of your vacation.　Is it ......?"
[cpg cn=true]

In the beginning, I thought the ground was heaped up, and I mistook it for sandbags or something.
[cpg]

But ......
[cpg]

[OnName num="shinzi"]
"What's that ......?
[cpg cn=true]

[free time=800]

If you look closely, you will see that it is a person covered in mud ......
[cpg]

[OnName num="shinzi"]
"Oh, Amane ?"
[cpg cn=true]

[SE f="se074"]
;//【ＳＥ】バチャバチャ駆け寄る

[free time=800]
;**【ＣＧ】ev_98_0 ***********************
[CG id=25 index=0 time=1000]
;*****************************************
[BGM f="h2"]

;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]



When you run up to it, it's Amane unmistakably ...... and you can't figure out what's going on.
[cpg]

[OnName num="shinzi"]
"What's going on?　What happened to you?　I'm not sure what to do.
[cpg cn=true]

You'll be able to find a lot more information on this website at ......
[cpg]


[WAIT time=100]
;//[VOICE f="Amane1049"]
[OnName num="amane"]
".................."
[cpg cn=true]

[OnName num="shinzi"]
"What's wrong?
[cpg cn=true]

I'm not sure what to say, but I'm sure you'll understand.
[cpg]




[OnName num="shinzi"]
"I'm not sure what to do.
[cpg cn=true]

When I looked up from my kneeling position in the mud, Yukika , I saw my sisters smiling with a very peaceful face.
[cpg]


[WAIT time=100]
[VOICE f="Yukika0195"]
[OnName num="yukika"]
"Oh ......, now I can finally feel safe ......."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Youko0302"]
[OnName num="youko"]
"No more worries, ...... Shinji ."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Izumi0236"]
[OnName num="izumi"]
"Everything's finally over. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Shizuku0227"]
[OnName num="shizuku"]
"I feel so much better now. ......
[cpg cn=true]

[OnName num="shinzi"]
"What the ......?"
[cpg cn=true]

This is a great way to get the most out of your business.
[cpg]

This is a great way to make sure you are getting the most out of your investment.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]



[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_ex_sk_t3_1.ui" time=1000]
;//【ＢＧ】空　夜　雨　空から落ちてくる雨（見上げるアングル）



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]


;//【雨、大雨】


[SE f="se004"]
;//【ＳＥ】土砂降り





The rain is pouring down.
[cpg]

Rain......
[cpg]

Rain ......
[cpg]

[OnName num="shinzi"]
" Amane ......"
[cpg cn=true]

;//雨音の顔や体の泥が雨に流されていく


;**【ＣＧ】ev_98_a ***********************
[CG id=25 index=1 time=1000]
;*****************************************


The pouring rain washes away the mud from Amane your face and body.
[cpg]

[OnName num="shinzi"]
" Amane ......"
[cpg cn=true]


But no matter how hard it rains, it doesn't make it all go away.
[cpg]

[OnName num="shinzi"]
"How could ...... this ...... happen?
[cpg cn=true]

For the first time, I wished the night would never end.
[cpg]

I wish it would just keep raining .......
[cpg]


[SE f="se004"]
;//【ＳＥ】激しい雨　高まる

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//loop
[stopse g=2]
[stopse g=6]

;//【ＢＧ】ブラックアウト
[STOPBGM]
[BG f="black.ui" time=2000]
[WAIT time=2000]
[system end5=true]
[SCENE id=31]

;//[jump target="*jump_ending"]
[jump storage="epend.ks" target="*start"]
;#############################################################

;#############################################################


;//END『暴行の果てに……』

;**【ＥＮＤ】　雨音死亡ルート　****************************

;**********************************************************
;//エンドロール
;//////////////////////////////////////////////////////////////////////////

