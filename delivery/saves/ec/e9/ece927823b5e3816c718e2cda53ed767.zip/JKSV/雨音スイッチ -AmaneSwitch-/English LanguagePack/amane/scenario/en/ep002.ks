*start

;#################################################
*Ep002|Happy times.
;#################################################
[SCENE id=2]

;//エフェクト


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
[STOPBGM]


From the next day, the rumor of the beautiful new student spread quickly, and curious students began to gather at Amane .
[cpg]

There are a lot of people who are trying to recruit for club activities, and she has to deal with them every single time.
[cpg]



[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye2"]
[BG f="b_s_3f_t1_0_Lup.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午前　曇り


[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]


[OnName num="male_student1"]
"What's your favorite food?　What's your favorite celebrity?
[cpg cn=true]

[OnName num="athletics_member"]
"Do you like to run?　Why don't you join the track and field club?
[cpg cn=true]

[OnName num="male_student2"]
"What are your hobbies?　What do you do on your days off?
[cpg cn=true]

[OnName num="softball_member"]
"Do you want to sweat your youth with me?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0145"]
[OnName num="amane"]
"Oh... um, ...... that ......
[cpg cn=true]

Amane In the event that you're looking for the best way to get the most out of your business, you'll want to take a look at the following.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="male_student3"]
"I'm not sure what to do.
[cpg cn=true]

[OnName num="soccer_member"]
"We need a manager, so come on in!
[cpg cn=true]

[OnName num="baseball_member"]
"I'll take you to Koshien!
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0146"]
[OnName num="amane"]
"Oh, my God. ......
[cpg cn=true]

[OnName num="shinzi"]
"You guys. ......
[cpg cn=true]



Just when I thought this was a bad idea, and I was about to step in ......
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=10]

;//move
[move from="2/3" to="2/5" ease="easeInOutSine" time=800]

;//[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="youko_p5_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Youko0028"]
[OnName num="youko"]
"Wait, wait, wait, wait!
[cpg cn=true]

[OnName num="shinzi"]
"And there it is, ......."
[cpg cn=true]

For some reason, Yoko jumped in front of Amane , cutting through the group of people in the shape of a dumpling.
[cpg]

Yoko In the event that you're not sure what you're looking for, you'll be able to find out more about it by visiting our website.
[cpg]

[FG f="youko_p5_01_a.ui" method="change_2" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Youko0029"]
[OnName num="youko"]
"Welcome to the tennis club!
[cpg cn=true]

[OnName num="shinzi"]
"Huh?
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0147"]
[OnName num="amane"]
"Tennis club...?"
[cpg cn=true]

Aha, Brutus ...... you too ......
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0030"]
[OnName num="youko"]
"You can get a lot more than that.　It's a great way to get the most out of your day. I'm sure you'll be happy to hear that.
[cpg cn=true]



[WAIT time=100]
[VOICE f="Amane0148"]
[OnName num="amane"]
"............"
[cpg cn=true]

[OnName num="shinzi"]
"I'm not sure what you mean by that.　What do you mean, "It's fun"?
[cpg cn=true]

Yoko Amane This is a great way to get the most out of your business.
[cpg]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0031"]
[OnName num="youko"]
"It's a good idea for new students to make friends first in order to blend in with their surroundings.　And the fastest way to make friends is through club activities!　So join the tennis club!
[cpg cn=true]

[OnName num="shinzi"]
"What's with the 'so'?
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0149"]
[OnName num="amane"]
"It's .......
[cpg cn=true]

When I was about to stand up and raise my voice, Amane whispered in a small voice: "I am , literature.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0150"]
[OnName num="amane"]
"I'm ...... thinking of joining the literary club.
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0032"]
[OnName num="youko"]
"What?
[cpg cn=true]

[OnName num="shinzi"]
"Literary club?"
[cpg cn=true]

[SE f="se053"]
;//【ＳＥ】ザワザワ


Yoko In the event that you're not sure what you're looking for, you'll be able to find out more about it here.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0033"]
[OnName num="youko"]
"I'm not sure what to make of that.　You don't even know where they operate or how many people are in the humble and dark ...... literature club!
[cpg cn=true]

[OnName num="shinzi"]
"Hey, what ...... are you talking about?
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0151"]
[OnName num="amane"]
"Yes, .......
[cpg cn=true]

A statement by Yoko that blatantly disparages a club that people want to join.
[cpg]

I thought I'd admonish him for that.
[cpg]

Amane I'm not sure what to make of that.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0152"]
[OnName num="amane"]
"You can find a lot of people who are looking for the best way to get the most out of their lives.
[cpg cn=true]

Amane This is a great way to get the most out of your time and money.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0153"]
[OnName num="amane"]
"This is a great way to make sure that you are getting the most out of your time and money.
[cpg cn=true]

[OnName num="shinzi"]
"Rain badmouthing ......?"
[cpg cn=true]

It is true that the activities of athletic clubs are affected by the weather, and they are always saying, "Damn, it's raining! I'm not sure if you're a fan of that ...... or not.
[cpg]

I was interested in what Amane had to say, but no one else, including Yoko , seemed to pay any attention to the reason.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0034"]
[OnName num="youko"]
"What a disappointment, a literary club!"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0154"]
[OnName num="amane"]
"Sorry, ......."
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0035"]
[OnName num="youko"]
"Will you reconsider?"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0155"]
[OnName num="amane"]
"..................
[cpg cn=true]

[OnName num="shinzi"]
"Come on, man. I said I don't like it.
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0036"]
[OnName num="youko"]
"I'm not saying I don't want to. I'm not saying I don't want to. I'm just saying, you know, you can do both.　See?　Let's think about it!
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0156"]
[OnName num="amane"]
"I'm sorry. ......
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0037"]
[OnName num="youko"]
"............ Oh, forget it!
[cpg cn=true]

[OnName num="shinzi"]
"Hey, Yoko !　Your attitude!
[cpg cn=true]

Yoko In the event that you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

Yoko In the event that you've got a lot of time, you'll be able to take a look at a few of the best ways to get the most out of your home.
[cpg]

[OnName num="shinzi"]
"You have to stop being like that. You have a bad personality."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0038"]
[OnName num="youko"]
"What? It's none of Shinji 's business.
[cpg cn=true]

[OnName num="shinzi"]
"Yes!　 Because Amane is a new student in our class. You and everyone else who doesn't belong here, get the fuck out!
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0039"]
[OnName num="youko"]
"What the hell?　Transfer student, transfer student. I was so kind to invite you, but you're so stupid!
[cpg cn=true]

[OnName num="shinzi"]
"You're the one with the ulterior motive!
[cpg cn=true]


[free time=800]
[SE f="se008"]
;//【ＳＥ】乱暴に扉を閉める


I force Yoko out of the classroom, close the door roughly, and return to my seat.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0157"]
[OnName num="amane"]
"'I'm Shinji ...... sorry. It's my fault we got into a fight."
[cpg cn=true]

[OnName num="shinzi"]
"It's okay, it's okay. It's not Amane your fault. It's not your fault. Yoko is always so pushy...
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0158"]
[OnName num="amane"]
" Yoko ......"
[cpg cn=true]

[OnName num="shinzi"]
"Hmm?
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0159"]
[OnName num="amane"]
"Oh, no, ....... I thought you didn't call him that.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, .......
[cpg cn=true]

You're right.
[cpg]

It might have been strange to call down a particular girl while saying that you have nothing to do with her.
[cpg]

When I realized this, I made a suggestion to Amane .
[cpg]

[OnName num="shinzi"]
"It's not that there's anything wrong with calling them out. If you want, you can call Amane -chan Amane ."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0160"]
[OnName num="amane"]
"What ......?"
[cpg cn=true]

[OnName num="shinzi"]
"......."
[cpg cn=true]

In the face of Amane 's scowl, I regretted that I had said something so familiar.
[cpg]

But ......
[cpg]

[FG f="amane_p6_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0161"]
[OnName num="amane"]
"So, ...... with that."
[cpg cn=true]

[OnName num="shinzi"]
"Huh?"
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0162"]
[OnName num="amane"]
"At Amane ......."
[cpg cn=true]

[OnName num="shinzi"]
"Uh-huh!"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

You can find a lot of things that you can do to make your life easier.
[cpg]

In the event that you're not sure what you're looking for, you'll be able to look up and see that Amane 's ears are slightly red.
[cpg]

I'm sure my ears are colored like that now.
[cpg]

[OnName num="shinzi"]
"But is it ...... Amane ?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0163"]
[OnName num="amane"]
"What ......?"
[cpg cn=true]

It's a good idea to keep your eyes on the bottom of your head and change the subject.
[cpg]

[OnName num="shinzi"]
"Did you come without an umbrella today?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0164"]
[OnName num="amane"]
"Yes, ....... I thought it would stop soon."
[cpg cn=true]

After yesterday, Amane is in the classroom in a wet state.
[cpg]

This is a great way to get the most out of your time and money.
[cpg]

[OnName num="shinzi"]
"I don't think you'll catch a cold.
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0165"]
[OnName num="amane"]
"I'm sure you'll be fine. ...... I guess I'm stronger than I thought.
[cpg cn=true]

[OnName num="shinzi"]
"Is that so?
[cpg cn=true]

The word "strong" does not overlap with the atmosphere that Amane exudes.
[cpg]

This is a great way to make sure you are getting the most out of your investment.
[cpg]

[FO pos="2/3" time=800]

[OnName num="female_student"]
" Mizushima , don't forget we have a committee meeting tomorrow after school, okay?"
[cpg cn=true]

I was about to continue talking when a classmate called out to me.
[cpg]

I was about to continue talking when one of my classmates called out to me, "Oh, by the way, ......," and I replied, thinking of the schedule in my head.
[cpg]

[OnName num="shinzi"]
"I know, I know. I'm sure you'll be able to tell me about it tomorrow.
[cpg cn=true]

I was annoyed that he had interrupted my conversation with Amane , but the content was about tomorrow.
[cpg]

[OnName num="female_student"]
"It's a good idea to have a good idea of what you're looking for.
[cpg cn=true]

[OnName num="shinzi"]
"Yes, yes, I'm sorry!"
[cpg cn=true]

Amane You'll be able to find a lot more than just a few of these in the marketplace.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_1" pos="2/7" time=800]
[WAIT time=100]
[VOICE f="Amane0166"]
[OnName num="amane"]
".................."
[cpg cn=true]

This is a great way to make sure you are getting the most out of your time with your family and friends.
[cpg]

[OnName num="shinzi"]
".................."
[cpg cn=true]

I looked at Amane and listened to the chime ring in the distance.
[cpg]


[stopse g=2]
[stopse g=6]

[SE f="se009"]
;//【ＳＥ】学校のチャイム


;//エフェクト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_s_3f_t3_0_Lup.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　夕方　曇り




After school, I reached over to Amane 's desk where he was getting ready to leave and ......
[cpg]

[SE f="se033"]
;//【ＳＥ】小銭を机に置く


I put down a few coins.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0167"]
[OnName num="amane"]
"?"
[cpg cn=true]

He stared at the coins curiously, then turned to face me. Amane
[cpg]

[OnName num="shinzi"]
"Yesterday."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0168"]
[OnName num="amane"]
"Yeah, ......, are you sure this is a good idea?
[cpg cn=true]

[SE f="se033"]
;//【ＳＥ】小銭押し返す（ザッ）


[OnName num="shinzi"]
"It's not good.
[cpg cn=true]

[SE f="se033"]
;//【ＳＥ】小銭押し返す


[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0169"]
[OnName num="amane"]
"I can't take it. ......
[cpg cn=true]

[SE f="se033"]
;//【ＳＥ】小銭押し返す


The coins are pushed and pulled across the desk like some kind of game.
[cpg]

[OnName num="shinzi"]
"You're more stubborn than I thought.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0170"]
[OnName num="amane"]
" Shinji is ......."
[cpg cn=true]

In the event that you're not sure what you're looking for, you'll be able to find out more about it here.
[cpg]

[OnName num="shinzi"]
"It's a good idea to have a good idea of what you're doing.
[cpg cn=true]

[SE f="se033"]
;//【ＳＥ】小銭押し返す


[FG f="amane_p6_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0171"]
[OnName num="amane"]
"It's not lending or borrowing, it's thanking. ......
[cpg cn=true]

[SE f="se033"]
;//【ＳＥ】小銭押し返す


[OnName num="shinzi"]
"Mmmm ......
[cpg cn=true]

The person of Amane does not seem to want to receive it by any means.
[cpg]

Now, I'm in trouble.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to do, but I'll do it.
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="shinzi"]
"As a thank you for treating me to lunch, I'll treat you to something today."
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0172"]
[OnName num="amane"]
"Huh...?"
[cpg cn=true]

Amane It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="shinzi"]
"You can find a lot more information on the web.
[cpg cn=true]

You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0173"]
[OnName num="amane"]
"I'm free .......
[cpg cn=true]

[OnName num="shinzi"]
"Then let's go somewhere to drop by. As a thank you for yesterday, I'll treat you to ice cream, anmitsu, or whatever you Amane want to eat."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0174"]
[OnName num="amane"]
"What? What?
[cpg cn=true]

Amane This is a great way to get the most out of your business.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0175"]
[OnName num="amane"]
Shinji "You can find a lot of people who are looking for the best way to get the most out of their lives.
[cpg cn=true]

[OnName num="shinzi"]
"It's not weird. Let's go!
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0176"]
[OnName num="amane"]
"What?
[cpg cn=true]

[OnName num="shinzi"]
"Okay, get up.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0177"]
[OnName num="amane"]
"Yes, yes, .......
[cpg cn=true]

[SE f="se068"]
;//【ＳＥ】椅子を引く


I let Amane stand and lead the way, knowing that thinking too much would do no good.
[cpg]

[OnName num="shinzi"]
"Where is the best place?
[cpg cn=true]

In fact, at this time, my heart is secretly in a floating state of mind.
[cpg]

It's a great way to get home with such a cute girl, and it's also a great way to take a detour .......
[cpg]

This is the first time I've ever felt this way, and even though I was confused by the change in me, I couldn't help but be excited.
[cpg]


[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_ex_sz_t2_0.ui" time=1000]
;//【ＢＧ】通学路　夕方　小雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、通常】


[SE f="se006"]
;//【ＳＥ】小雨


[FG f="amane_p7_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0178"]
[OnName num="amane"]
".................."
[cpg cn=true]

It's drizzling, and I walk over to Amane to offer her an umbrella.
[cpg]

It's a good idea to have a good idea of what's going on in your life.
[cpg]

[OnName num="shinzi"]
"Do you want something sweet?　Would you like something spicy?"
[cpg cn=true]

[FG f="amane_p7_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0179"]
[OnName num="amane"]
"What's ...... spicy?
[cpg cn=true]

[OnName num="shinzi"]
"Well, it's .......
[cpg cn=true]

It's not that I'm trying to make a joke, it's just that I didn't want to get in trouble if you didn't like sweets, so I asked, but when you ask me back so directly, I'm in trouble.
[cpg]

[OnName num="shinzi"]
"I'm not sure what it is. Oh, tantanmen or curry!
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0180"]
[OnName num="amane"]
"Oh, that kind of ......."
[cpg cn=true]

[OnName num="shinzi"]
"There's a restaurant near here that serves 100 times curry!
[cpg cn=true]

[FG f="amane_p8_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0181"]
[OnName num="amane"]
"Yeah, well, ......, that's a bit of a stretch.
[cpg cn=true]

[OnName num="shinzi"]
"That's right. ......
[cpg cn=true]

There was no 100x curry for girls .......
[cpg]

In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

And I don't want to see it.
[cpg]

[OnName num="shinzi"]
"What kind of places did you stop off at before?
[cpg cn=true]

I pondered and asked, but Amane answered smoothly.
[cpg]

[FG f="amane_p8_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0182"]
[OnName num="amane"]
"I've never taken a detour before.
[cpg cn=true]

[OnName num="shinzi"]
"What?　Have you ever gone out to eat with your friends?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0183"]
[OnName num="amane"]
"I've never had any friends. ......
[cpg cn=true]

[OnName num="shinzi"]
"Oh, ......."
[cpg cn=true]

Is it possible that she is a child of the transfer family?
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

If that's the case, I've asked something insensitive.
[cpg]

[OnName num="shinzi"]
"I'm sorry."
[cpg cn=true]

[FG f="amane_p7_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0184"]
[OnName num="amane"]
"Oh, that's ...... okay. I'm sorry too. I've never done anything like this before, so I didn't know what to do. ......
[cpg cn=true]

[OnName num="shinzi"]
"I see. You're right.
[cpg cn=true]

You will find a lot of people who are looking for a new way to live.
[cpg]

You can find a lot of people who are interested in this kind of.
[cpg]

This is a great way to make sure you are getting the most out of your vacation.
[cpg]

[OnName num="shinzi"]
"In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg cn=true]

[FG f="amane_p8_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0185"]
[OnName num="amane"]
"Wow. ......
[cpg cn=true]

[OnName num="shinzi"]
"Do you hate sweet ......?"
[cpg cn=true]

I'm not sure what to make of this.
[cpg]

In my imagination, when girls talk about sweets, they say, "Oh, really? "I want to go too!" Because I had the image that they would be interested in it.
[cpg]

But Amane was a little different.
[cpg]

[FG f="amane_p7_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0186"]
[OnName num="amane"]
"I don't hate it, but ......"
[cpg cn=true]

[OnName num="shinzi"]
"But ......?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0187"]
[OnName num="amane"]
"I've never really eaten ......."
[cpg cn=true]

[OnName num="shinzi"]
"Oh, really?
[cpg cn=true]

I had always thought that all girls devoured sweets.
[cpg]

Yoko Yukika It's a great way to make sure you're getting the most out of your vacation. ....
[cpg]

[FG f="amane_p8_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0188"]
[OnName num="amane"]
"So I don't know if I like it or not .......
[cpg cn=true]

[OnName num="shinzi"]
"Huh. ......"
[cpg cn=true]

Amane In the event that you're looking for the best way to get the most out of your business, you'll want to take a look at the following.
[cpg]

[FG f="amane_p7_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0189"]
[OnName num="amane"]
"It's weird ...... me.
[cpg cn=true]

[OnName num="shinzi"]
"You're not weird!
[cpg cn=true]

It's just a little weird .......
[cpg]

But it's not an unpleasant weirdness.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll have a great time.　It'll be fun to find out what you like.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0190"]
[OnName num="amane"]
"'Yeah, maybe ....... Well then, tell me all about it.
[cpg cn=true]

[OnName num="shinzi"]
"I'll leave it to you!
[cpg cn=true]

We became like a teacher and a student, and we walked together through the rainy downtown.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye1"]
[BG f="b_ex_tw_t1_0.ui" time=1000]
;//【ＢＧ】街　夕方　小雨


;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、通常】

;//loop
[SE f="se006" loop=true]
;//【ＳＥ】雨


[OnName num="shinzi"]
"I'm not sure what to say.　The girls in my class were talking about this store.
[cpg cn=true]

I stopped in front of a shop with pinkish-pink colors.
[cpg]

[FG f="amane_p7_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0191"]
[OnName num="amane"]
"'What kind of shop?'
[cpg cn=true]

Inevitably, Amane also stopped, looked up at the shop and asked.
[cpg]

[OnName num="shinzi"]
"I believe it was a crepe and parfait shop.
[cpg cn=true]

[FG f="amane_p8_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0192"]
[OnName num="amane"]
"'Heh, .......'
[cpg cn=true]

In the meantime, several groups of people in familiar uniforms are entering the store.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

Amane It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[OnName num="shinzi"]
"Would you like to come in here today?
[cpg cn=true]

[FG f="amane_p7_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0193"]
[OnName num="amane"]
"Yes, ....... If Shinji says so."
[cpg cn=true]

[OnName num="shinzi"]
"Okay."
[cpg cn=true]

I closed my umbrella in front of the store and stepped into the store with Amane .
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//loop
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_ex_pa_t1_0.ui" time=1000]
;//【ＢＧ】クレープとパフェの店　夕方　小雨


[OnName num="shinzi"]
"Oh, ......."
[cpg cn=true]

In the event that you have any kind of questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

[OnName num="sales_clerk"]
"I'm sure you'll like it.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0194"]
[OnName num="amane"]
"Kirei ......"
[cpg cn=true]

Amane It's a great way to make sure you're getting the most out of your vacation.
[cpg]

In fact, there were strawberries, whipped cream, chocolate and bananas, all artfully arranged in a sweet and magical scene.
[cpg]

[OnName num="shinzi"]
"Ask for anything you like.
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0195"]
[OnName num="amane"]
"You have so many ......
[cpg cn=true]

It's my first time in a restaurant like this. Amane stares at the samples with interest.
[cpg]

It's the same for me.
[cpg]

This is a great way to make sure you are getting the most out of your time with us.
[cpg]

If this is the case, I should have asked the pick-up guy in my class for a recommendation.
[cpg]

[OnName num="sales_clerk"]
"Our recommendation is Strawberry Berry Berry ."
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0196"]
[OnName num="amane"]
"Berry ......"
[cpg cn=true]

[OnName num="shinzi"]
"Berry Berry ......"
[cpg cn=true]

The first berry is good, but what are the other two ......?
[cpg]

This is a great way to make sure you are getting the best value for your money.
[cpg]

[OnName num="sales_clerk"]
"You can also add more berries as a topping?
[cpg cn=true]

[OnName num="shinzi"]
"Extra ......."
[cpg cn=true]

[OnName num="sales_clerk"]
"It'll be a Strawberry Berry Berry berry match thank you.
[cpg cn=true]

[OnName num="shinzi"]
"What kind of evolution is that, ......?
[cpg cn=true]

In the event that you are not able to order a simple coffee at a coffee shop these days, the clerk's explanation will not make any sense to you.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to make of it.
[cpg cn=true]

I scratched my head and asked shyly. The clerk must have thought I was an amateur, because he held up a sample and said.
[cpg]

[OnName num="sales_clerk"]
"If so, how about this one, Chocolate Sundae ?
[cpg cn=true]

[OnName num="shinzi"]
" Sundae ?　Not Sunday?
[cpg cn=true]

[OnName num="sales_clerk"]
"Yes, it's the same as a sundae, but it's original and made in the shape of the sun.
[cpg cn=true]

[OnName num="shinzi"]
"Wow.
[cpg cn=true]

I'm not sure what a sundae is, I only know the name of it, but the one he pointed out to me was definitely a banana or something that represented the jaggedness of sunlight well. I'm sure that the ice cream in the middle is the sun.
[cpg]

I guess the ice cream in the middle is supposed to be the sun.
[cpg]

[OnName num="shinzi"]
"It's funny!
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0197"]
[OnName num="amane"]
"............ Yeah."
[cpg cn=true]

I was simply amused and looked back at Amane , but to my surprise, her face looked cloudy.
[cpg]

[OnName num="shinzi"]
"Hey ......, you don't like chocolate?
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0198"]
[OnName num="amane"]
"No, I don't!　I think it's good ......."
[cpg cn=true]

Amane It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[OnName num="shinzi"]
"So, do you want this?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0199"]
[OnName num="amane"]
"I'm sure you'll have a great time. But you might not be able to ...... eat all of it.
[cpg cn=true]

[OnName num="shinzi"]
"But I'll take it anyway.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0200"]
[OnName num="amane"]
"Yeah, ......."
[cpg cn=true]

Anyway, the order was decided, and both me and the waiter were relieved.
[cpg]

[OnName num="sales_clerk"]
" Chocolate Sundae , I'm all set."
[cpg cn=true]


;//エフェクト

;//[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_ex_pa_t1_1.ui" time=1000]

;//【ＢＧ】席に向かい合って座る。テーブルにはチョコレート・サニーデーがひとつ



[OnName num="shinzi"]
"Wow, that's amazing.
[cpg cn=true]

[FG f="amane_p7_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0201"]
[OnName num="amane"]
"Really ......."
[cpg cn=true]

The Sundae that was brought to the table was as gorgeous as the costume of some great enka singer.
[cpg]

[OnName num="shinzi"]
"I don't know how they come up with these things,.......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0202"]
[OnName num="amane"]
"Really ......."
[cpg cn=true]

Me and Amane were so overwhelmed by Sundae that we forgot for a while that it was food.
[cpg]

[OnName num="shinzi"]
"Oh, go ahead, eat it."
[cpg cn=true]

[FG f="amane_p8_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0203"]
[OnName num="amane"]
"You're not going to eat it Shinji ?"
[cpg cn=true]

[OnName num="shinzi"]
"If Amane leaves some, I'll take it."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0204"]
[OnName num="amane"]
"Oh, my God, .......
[cpg cn=true]

[OnName num="shinzi"]
"You said you might not be able to eat it.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0205"]
[OnName num="amane"]
"Yeah, but .........
[cpg cn=true]

[OnName num="shinzi"]
"Go ahead, eat first.
[cpg cn=true]

[FG f="amane_p7_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0206"]
[OnName num="amane"]
"Well, ......, I'll take it first. ......
[cpg cn=true]

[OnName num="shinzi"]
"Yeah."
[cpg cn=true]

But Amane was confused, fork in hand.
[cpg]

You will be able to find a lot more than just a few things to do.
[cpg]

[FG f="amane_p8_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0207"]
[OnName num="amane"]
"Is it okay ......?"
[cpg cn=true]

Finally, the fork goes into one of the bananas standing in the ice cream, fearfully.
[cpg]

It's a bite-sized banana with whipped cream and ice cream on the bottom half.
[cpg]

[FG f="amane_p7_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0208"]
[OnName num="amane"]
"...... Am."
[cpg cn=true]

I put it in my mouth and took a bite, then another bite .......
[cpg]

[OnName num="shinzi"]
"I don't know.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0209"]
[OnName num="amane"]
"It's ...... sweet.
[cpg cn=true]

[OnName num="shinzi"]
"I knew it. ......"
[cpg cn=true]

With his eyes closed as if he had a toothache, Amane tasted the banana.
[cpg]

Surprisingly, however, his next impression was ......
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0210"]
[OnName num="amane"]
"But it's delicious. ......
[cpg cn=true]

The next impression was: "But it's delicious .
[cpg]

[OnName num="shinzi"]
"Yeah?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0211"]
[OnName num="amane"]
"Yeah ....... I thought it would be sweeter, but it's ...... delicious.
[cpg cn=true]

[OnName num="shinzi"]
"Keep eating!"
[cpg cn=true]

Amane In the event you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0212"]
[OnName num="amane"]
"I was a little nervous about the name, but ...... I think I like the taste. ......
[cpg cn=true]

[OnName num="shinzi"]
"I'm sure you'll love it. ......?
[cpg cn=true]

Chocolate Sundae ?
[cpg]

I'm not sure if this is a good idea or not.
[cpg]

This is a great way to get the most out of your time with your family and friends. Amane scoops up ice cream with a long, thin spoon while saying this.
[cpg]

[FG f="amane_p8_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0213"]
[OnName num="amane"]
"It's been a very long time since I've had ice cream,.......
[cpg cn=true]

[OnName num="shinzi"]
"I eat two of them every day in the summer.
[cpg cn=true]

[FG f="amane_p9_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0214"]
[OnName num="amane"]
"I'm ......
[cpg cn=true]

;//雨音の口元のアップ


[OnName num="shinzi"]
"..................
[cpg cn=true]

It sounds perverted to say this, but at that moment my eyes were focused on the mouth of Amane the ice cream.
[cpg]

The white cold ice cream melts between the lips of Amane .
[cpg]

This is a great way to make sure you are getting the best value for your money.
[cpg]

[SE f="se016"]
;//【ＳＥ】喉が鳴る


[OnName num="shinzi"]
"A.
[cpg cn=true]

[FG f="amane_p7_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0215"]
[OnName num="amane"]
"Ah."
[cpg cn=true]

My throat rumbled, and both of our voices came out at the same time.
[cpg]

My "ah" was shame for shooting her a perverted look, but Amane what?
[cpg]

The answer is immediately offered by her.
[cpg]

[FG f="amane_p8_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0216"]
[OnName num="amane"]
"'I'm sorry, it's just me.'
[cpg cn=true]

[OnName num="shinzi"]
"'No, no, no!　It's okay."
[cpg cn=true]

Apparently, the "a" in Amane was meant for me, which was a relief.
[cpg]

[FG f="amane_p7_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0217"]
[OnName num="amane"]
"Have some Shinji , too. I'll take another spoon. ......
[cpg cn=true]

[OnName num="shinzi"]
"No, I'm ......
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0218"]
[OnName num="amane"]
"Excuse me.
[cpg cn=true]

While hesitating, Amane had released his voice to the shopkeeper.
[cpg]

But ......
[cpg]


[WAIT time=100]
[VOICE f="Amane0219"]
[OnName num="amane"]
"Excuse me, ......."
[cpg cn=true]

Amane In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0220"]
[OnName num="amane"]
"Um, excuse me,......."
[cpg cn=true]

[OnName num="shinzi"]
"It's fine, here."
[cpg cn=true]

I took pity on the Amane who tried so hard to speak, I took the spoon from Amane 's hand and voluntarily scooped up the ice cream and brought it to my mouth.
[cpg]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0221"]
[OnName num="amane"]
"Ah ......"
[cpg cn=true]

[OnName num="shinzi"]
"Mmmm ...... that's delicious!"
[cpg cn=true]

It's just the right amount of sweetness and coolness to debauch on the tongue.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0222"]
[OnName num="amane"]
"..................
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

The expression of Amane at that time.
[cpg]

You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="shinzi"]
"I'm not sure what's wrong.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0223"]
[OnName num="amane"]
"What?
[cpg cn=true]

Amane This is a great way to make sure you are getting the most out of your time with us.
[cpg]

[OnName num="shinzi"]
"This is a great way to make sure you are getting the most out of your time.
[cpg cn=true]

[FG f="amane_p8_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0224"]
[OnName num="amane"]
"I'm not sure what to say.
[cpg cn=true]

I'm not sure what to make of that.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

[OnName num="shinzi"]
"I'm sorry!　On your own!　That's right!　I hate that!　Sorry, sorry, sorry!"
[cpg cn=true]

[FG f="amane_p7_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0225"]
[OnName num="amane"]
"What? What?"
[cpg cn=true]

[SE f="se088"]
;//【ＳＥ】紙ナプキンでスプーンをゴシゴシ擦る


I was too impatient and wiped the spoon I had in my mouth with a paper napkin.
[cpg]

To use a girl's spoon, that's ...... that's an indirect kiss!
[cpg]

He didn't want to do that, so Amane he was probably going to get a new spoon.
[cpg]

It was unwise .......
[cpg]

[FG f="amane_p7_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0226"]
[OnName num="amane"]
"No, no, no!"
[cpg cn=true]

[OnName num="shinzi"]
"What?　No?"
[cpg cn=true]

The spoon was almost bent as I rubbed it. Amane shook his head and said.
[cpg]

[FG f="amane_p8_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0227"]
[OnName num="amane"]
"I ......, I ......, Shinji ...... am not the spoon that I used. I ...... thought it was disgusting. ......"
[cpg cn=true]

[OnName num="shinzi"]
"What?"
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

In the event that you're in the market for a brand new pair of shoes or boots, then you're in luck.
[cpg]

[OnName num="shinzi"]
"It's not creepy at all. It's more like I'm creepy. ...... I'm sorry.
[cpg cn=true]

[FG f="amane_p7_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0228"]
[OnName num="amane"]
"No!　I'm not that ...... at all!
[cpg cn=true]

[OnName num="shinzi"]
"Really?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0229"]
[OnName num="amane"]
"Yeah.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, my God. Oh, my God.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0230"]
[OnName num="amane"]
"What?
[cpg cn=true]

[OnName num="shinzi"]
"I was afraid you were gonna call me a sexual harasser.
[cpg cn=true]

[FG f="amane_p8_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0231"]
[OnName num="amane"]
"That's not true. ......
[cpg cn=true]

We laughed a little at each other for clearing up our misunderstandings and went on to eat Chocolate Sundae in turn.
[cpg]

It's been raining for a while now, but my mind is clear as I eat Sundae .
[cpg]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="healing"]
[BG f="b_ex_tw_t1_0.ui" time=1000]
;//【ＢＧ】街　夕方　小雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、通常】

;//loop
[SE f="se006" loop=true]
;//【ＳＥ】雨

[FG f="amane_p7_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0232"]
[OnName num="amane"]
"I'm not sure if it's really a good idea to ...... have this as a treat.
[cpg cn=true]

[OnName num="shinzi"]
"It's a good thing that this is in return for yesterday.
[cpg cn=true]

After leaving the restaurant, I said with a dumbfounded look to Amane the first story again.
[cpg]

Then she bowed politely and ......
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0233"]
[OnName num="amane"]
"I'm sure you'll be pleased to hear that.
[cpg cn=true]

I'm not sure what to say.
[cpg]

[FG f="amane_p8_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0234"]
[OnName num="amane"]
"I'll return this thank you with ......100 times curry?　I'll pay you back."
[cpg cn=true]

[OnName num="shinzi"]
"You can thank me for this. And I don't want to eat 100x curry!
[cpg cn=true]

[FG f="amane_p7_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0235"]
[OnName num="amane"]
"But thank you so much for today. No way. ......
[cpg cn=true]

[OnName num="shinzi"]
"Hmm?"
[cpg cn=true]

Amane had a kind of languid expression at that time.
[cpg]

[FACE method="change_7" pos="2/3"]
;//[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0236"]
[OnName num="amane"]
"I never thought I would ...... eat the sun.
[cpg cn=true]

[OnName num="shinzi"]
"Ha ha ha."
[cpg cn=true]

I took that word very lightly.
[cpg]

I never dreamed that there was any deeper meaning to Amane .......
[cpg]

[OnName num="shinzi"]
" Amane , which way home?"
[cpg cn=true]

[FG f="amane_p8_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0237"]
[OnName num="amane"]
"Oh, I'm over ...... there."
[cpg cn=true]

She pointed in the opposite direction to my house.
[cpg]

I felt a little disappointed about that, so I made a little suggestion.
[cpg]

[OnName num="shinzi"]
"I'll give you a lift.
[cpg cn=true]

But ......
[cpg]

[FG f="amane_p7_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0238"]
[OnName num="amane"]
"No, ......, I'm fine on my own.
[cpg cn=true]

[OnName num="shinzi"]
"'Yes .......'
[cpg cn=true]

I was disappointed because I didn't have any ulterior motive to be a wolf in sheep's clothing, but I simply wanted to talk to Amane some more.
[cpg]

But you can't let that happen to your face.
[cpg]

It's just too uncool.
[cpg]

[OnName num="shinzi"]
"I'll see you tomorrow then.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
;//[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0239"]
[OnName num="amane"]
"Yeah, ....... See you ......."
[cpg cn=true]

After saying that, Amane turned his back on me and started walking.
[cpg]

[SE f="se028"]
;//【ＳＥ】歩く

[FO pos="2/3" time=800]

[BGM f="rain"]

[OnName num="shinzi"]
"..................."
[cpg cn=true]

Amane In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

[OnName num="shinzi"]
"Oh, umbrella ......."
[cpg cn=true]

But my voice didn't reach Amane anymore, and it wasn't raining enough to make me stick out my plastic umbrella until I chased after him, so I turned around and went home.
[cpg]

[OnName num="shinzi"]
"I hope ...... we can eat together again. ......
[cpg cn=true]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//loop
[stopse g=2]
[stopse g=6]

;//エフェクト
;//過去の情景を夢に見る

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BG f="b_ex_sz_t6_0.ui" time=1000]
;//【ＢＧ】通学路（事故現場／セピア調）　夕方　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、通常】


;//冒頭の物より数十分後の風景　踏切に救急車が停車して人集りが出来ている

;//loop
[SE f="se006" loop=true]
;//【ＳＥ】土砂降り


"Where are the injured!
[cpg cn=true]

"Is there any witnesses?
[cpg cn=true]

A scene I'm not supposed to know .......
[cpg]

I don't know, but I know the scene .......
[cpg]

Where am I ......?
[cpg]

What is this ......?
[cpg]

"The woman!　A woman!"
[cpg cn=true]

A woman ......?
[cpg]

"No!　A man!　It's a man!"
[cpg cn=true]

A man. ......?
[cpg]

"Back off!　Just back off!
[cpg cn=true]

Oh, ......
[cpg]

This is an accident. ......
[cpg]

There's been an accident at the railroad crossing. ......
[cpg]

Someone I know had an accident at a railroad crossing. ......
[cpg]

My ......
[cpg]

Someone I know ......?
[cpg]

That's ...... who?
[cpg]

;//loop
[stopse g=2]
[stopse g=6]

[SE f="se075"]
;//【ＳＥ】飛び起きる（ガバッ！）

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="sir"]
[BG f="b_si_r_t2_0.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　朝　雨


;//loop
[SE f="se006" loop=true]
;//【ＳＥ】雨


[OnName num="shinzi"]
"Huh...hah ......."
[cpg cn=true]

When I woke up in the morning, I was drenched in sweat.
[cpg]

I've had this dream many times before.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[OnName num="shinzi"]
"What the hell is this ...... shit?
[cpg cn=true]

[SE f="se071"]
;//【ＳＥ】カーテン開ける


[SE f="se007"]
;//【ＳＥ】少し大きくなる雨の音


[OnName num="shinzi"]
"It's raining again. ......
[cpg cn=true]

I hope that this great blessing of nature will wash away my bad dream.
[cpg]

I'm not sure what to make of it.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

This vague feeling of disgust is .......
[cpg]

;//エフェクト

;//loop
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye1"]
[BG f="b_s_3f_t1_2.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午前　雨


[SE f="se053"]
;//【ＳＥ】普通の朝の喧噪


[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0240"]
[OnName num="amane"]
"Good morning, Shinji ."
[cpg cn=true]

[OnName num="shinzi"]
"Oh...good morning."
[cpg cn=true]

When I entered the classroom and took my seat, Amane came up to me and gave me a morning greeting.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0241"]
[OnName num="amane"]
"You're not looking too good, ......, what's wrong?"
[cpg cn=true]

[OnName num="shinzi"]
"Oh ......, yeah ......."
[cpg cn=true]

I was so dejected that Amane looked into my face with concern.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0242"]
[OnName num="amane"]
"It's a good idea to have a good idea of what you're looking for. Even if you're in the mood ......."
[cpg cn=true]

[OnName num="shinzi"]
"It's not that. It's just that I'm having trouble dreaming.
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0243"]
[OnName num="amane"]
"Dreaming?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah. ......
[cpg cn=true]

In the morning of the day when I had the dream, the voices of my classmates were usually depressing.
[cpg]

But the voice of Amane is strangely pleasant to the ear, and it enters the chest easily like fresh water.
[cpg]

And strangely enough, it was not unpleasant at all.
[cpg]

[OnName num="shinzi"]
"Sometimes I have the same dream and have nightmares.
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0244"]
[OnName num="amane"]
"What kind of dreams?
[cpg cn=true]

[OnName num="shinzi"]
"I don't really remember it when I wake up. I just hate it so much. ......"
[cpg cn=true]

I guess I hate the frustration of trying to remember and not being able to.
[cpg]

I scratched my head and tried to shake off the discomfort.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0245"]
[OnName num="amane"]
"I have ...... something like that, too.
[cpg cn=true]

[OnName num="shinzi"]
"And Amane ?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0246"]
[OnName num="amane"]
"It's the same dream I've had over and over since I was little.
[cpg cn=true]

[OnName num="shinzi"]
"'I see. ...... Does everyone have that?　Does everyone have that?
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0247"]
[OnName num="amane"]
"Probably .......
[cpg cn=true]

[OnName num="shinzi"]
"Hmm. ......
[cpg cn=true]

When I thought that I was not the only one who had mysterious dreams, I felt a little better.
[cpg]

So I began to wonder about the recurring dreams of Amane .
[cpg]

[OnName num="shinzi"]
"What kind of dreams does Amane have?"
[cpg cn=true]

I casually asked.
[cpg]

[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0248"]
[OnName num="amane"]
"Mine's ......."
[cpg cn=true]


[move from="2/3" to="2/5" ease="easeInOutSine" time=800]

[FG f="youko_p5_01_a.ui" method="change_1" pos="4/5" time=800]

[WAIT time=400]

[WAIT time=100]
[VOICE f="Youko0040"]
[OnName num="youko"]
"What?　What are you talking about?
[cpg cn=true]

[OnName num="shinzi"]
"Oh, ......."
[cpg cn=true]

"It was Yoko who interrupted me with a voice so brainless that I couldn't be bothered to even say, "It's you again .......
[cpg]

[FG f="amane_p6_02_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0249"]
[OnName num="amane"]
"Good morning ....... Minegishi ."
[cpg cn=true]

When I respond to Amane 's greeting with a light chin lift, Yoko leans forward with both hands on my desk.
[cpg]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0041"]
[OnName num="youko"]
"'What were you two talking about?'
[cpg cn=true]

I hadn't really thought about it before, but when I'm in a mood like this, Yoko 's voice echoes in my head.
[cpg]

[OnName num="shinzi"]
"It's no big deal.
[cpg cn=true]

;//[FACE method="change_7" pos="4/5"]
[FG f="youko_p7_01_a.ui" method="change_2" pos="4/5" time=800]
[FG f="amane_p6_01_a.ui" method="change_1" pos="2/5" time=0]
[WAIT time=100]
[VOICE f="Youko0042"]
[OnName num="youko"]
"Come on, tell me, tell me.
[cpg cn=true]

[OnName num="shinzi"]
"You ......
[cpg cn=true]

Has this guy forgotten how he behaved yesterday?
[cpg]

Or is he deliberately acting like an idiot because he's in a bad mood?
[cpg]

Either way, it's hard to get high tension in the morning.
[cpg]

Perhaps sensing my grumpiness, Amane follows me aside from Yoko .
[cpg]


[FG f="amane_p5_02_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0250"]
[OnName num="amane"]
"You know, ......, Shinji had a nasty dream about ......."
[cpg cn=true]

;//[FACE method="change_1" pos="4/5"]
[FG f="youko_p5_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Youko0043"]
[OnName num="youko"]
"What?　A dream?　You're making such a big face because of that?　Oh, my God.
[cpg cn=true]

[OnName num="shinzi"]
"What the hell is ......? Huh, ......."
[cpg cn=true]

This is a great way to make sure you are getting the most out of your time with your family.
[cpg]

However, the energetic Yoko will say as if it is my fault.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0044"]
[OnName num="youko"]
"I'm sure you'll agree that dreams are just a way of organizing information.　It's silly to worry about such a task.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0251"]
[OnName num="amane"]
"Sorting out information?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0045"]
[OnName num="youko"]
"You know?　It's a process of sorting out the unimportant memories in your head and separating them into things to store and things to throw away. I heard a great guy on TV say that the other day.
[cpg cn=true]

[OnName num="shinzi"]
"What about the dream I'm having ......?
[cpg cn=true]

If the dream I'm having is an unimportant memory and I'm in the process of sorting it out, it's going to take too much time.
[cpg]

And if it's an unimportant memory, why do I keep seeing it over and over again?
[cpg]

As I was twisting my neck, Yoko came up with more stuff that I had heard.
[cpg]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0046"]
[OnName num="youko"]
"In addition, there is a theory that the brain foresees what is going to happen in the future and shows you stimulating dreams so that your mind can withstand the shock and gradually get used to it.
[cpg cn=true]

[OnName num="shinzi"]
"That's totally different!
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0047"]
[OnName num="youko"]
"I don't know. I don't know. That's what the great man said.
[cpg cn=true]

The "big people" referred to by Yoko have always been unreliable.
[cpg]

I'm sure you'll be able to understand why.
[cpg]

[OnName num="shinzi"]
"So, ......, does that mean something bad is going to happen to me now?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0048"]
[OnName num="youko"]
"You're not saying that!
[cpg cn=true]

[OnName num="shinzi"]
"Yes, you are.
[cpg cn=true]

It's true that if something several times as unpleasant as this were to happen, it might be better for the psyche than a sudden bang, but even so, it's too long.
[cpg]

I think you've been getting used to it too much since you were a kid.
[cpg]

What's going on with my brain, ......?
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0049"]
[OnName num="youko"]
"And?　What kind of dream is it? What's your dream?
[cpg cn=true]

[OnName num="shinzi"]
"I can't remember. ......
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0050"]
[OnName num="youko"]
"What?　If you can't remember it, why are you so worried about it?
[cpg cn=true]

[OnName num="shinzi"]
"It's ......."
[cpg cn=true]

When I tried to connect my words with a sigh, Amane followed up again.
[cpg]

[FG f="amane_p5_02_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0252"]
[OnName num="amane"]
"The only thing that seems to remain is a bad feeling,....... Dreams are usually ...... forgotten when you wake up, so ......
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0051"]
[OnName num="youko"]
"I remember."
[cpg cn=true]

Amane Yoko In the event that you're not sure what you're looking for, you'll be able to contact us at the following link.
[cpg]

[OnName num="shinzi"]
"It's a great way to make sure you get the most out of your time with your family.
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0052"]
[OnName num="youko"]
"You can.　I'm not sure what to say.　Three days ago!
[cpg cn=true]

Yoko I'm not sure if I'm going to be able to do that.
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0053"]
[OnName num="youko"]
"I'm a celebrity in New York City, and my friends are all amazing people.
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0054"]
[OnName num="youko"]
And over a stylish lunch, we talked about, "What are you doing tonight? And then at night, when we go out to the clubs, Hollywood stars and oil tycoons make fun of us and we have a gorgeous night!　Isn't that amazing?
[cpg cn=true]

[OnName num="shinzi"]
"..................
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0253"]
[OnName num="amane"]
"..................
[cpg cn=true]

[FG f="youko_p7_01_a.ui" method="change_3" pos="4/5" time=800]
[FG f="amane_p6_02_a.ui" method="change_1" pos="2/5" time=0]
[WAIT time=100]
[VOICE f="Youko0055"]
[OnName num="youko"]
"Isn't it great?
[cpg cn=true]

[OnName num="shinzi"]
"You're talking about the movie ......, aren't you?
[cpg cn=true]

[FG f="youko_p5_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Youko0056"]
[OnName num="youko"]
"Oh, my God, is that...?　Is that right?
[cpg cn=true]

It sounded like something I'd heard somewhere before, and I realized once again just how absurd Yoko was.
[cpg]

[OnName num="shinzi"]
"I shouldn't have asked.
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0057"]
[OnName num="youko"]
"What?
[cpg cn=true]

[OnName num="shinzi"]
"We were talking about nightmares, you and me.
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0058"]
[OnName num="youko"]
"I have nightmares, too!　I had one a while ago where I was trapped in a huge mansion and my friends and I were being torn apart, and then zombies came out, and I found out it was a conspiracy by a company that makes chemical weapons. ......
[cpg cn=true]

[OnName num="shinzi"]
"That's a movie!
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0059"]
[OnName num="youko"]
"Oh, yeah?　But look!　It's just information you don't need, so you sort it out in your dreams.
[cpg cn=true]

[OnName num="shinzi"]
"Mmm-hmm. ......?　Is that ......?
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0060"]
[OnName num="youko"]
"See, that's what I'm talking about.
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

It's a wonder that Yoko seems to be right because he talks so much.
[cpg]

You can find a lot of people who are interested in this kind of thing.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to make of ....... Amane I'm not sure if this is a good idea or not.
[cpg cn=true]

[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0061"]
[OnName num="youko"]
"I don't know...!
[cpg cn=true]

[FG f="amane_p5_02_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0254"]
[OnName num="amane"]
"First period.
[cpg cn=true]

[OnName num="shinzi"]
"I see. Thanks.
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0062"]
[OnName num="youko"]
"Hahaha. ......, what's that?　You two are getting along pretty well, huh?
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0255"]
[OnName num="amane"]
"What?
[cpg cn=true]

Yoko You can find a lot of people who are interested in this kind of thing.
[cpg]

It's a good idea to have a good idea of what you're doing.
[cpg]

[OnName num="shinzi"]
"What?
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0063"]
[OnName num="youko"]
"You just called me a name. You called me by my name.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, what ......?
[cpg cn=true]

That's what I thought, and I was a little taken aback by Yoko 's audacity.
[cpg]

I'm surprised that you would notice such a thing so quickly, given that you're so sketchy.
[cpg]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0064"]
[OnName num="youko"]
"What is it?
[cpg cn=true]

[OnName num="shinzi"]
"I'm not sure why. I call you by your name.
[cpg cn=true]

;//[FACE method="change_3" pos="4/5"]
[FG f="youko_p7_01_a.ui" method="change_3" pos="4/5" time=800]
[FG f="amane_p6_02_a.ui" method="change_1" pos="2/5" time=0]
[WAIT time=100]
[VOICE f="Youko0065"]
[OnName num="youko"]
"That's not the point, is it?
[cpg cn=true]

[OnName num="shinzi"]
"Well, what do you mean?
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Youko0066"]
[OnName num="youko"]
"............, enough!
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

He's always saying, "Enough!" That's it.
[cpg]


[cpg]

[OnName num="shinzi"]
"He's such a pain in the ass.
[cpg cn=true]

;//[FACE method="change_3" pos="4/5"]
[FG f="youko_p5_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Youko0067"]
[OnName num="youko"]
"That's enough!　I'm going home!
[cpg cn=true]

[SE f="se065"]
;//【ＳＥ】ドカドカと立ち去る

[move from="4/5" to="3/2" ease="easeInOutSine" time=800]

[OnName num="shinzi"]
"What's that ......
[cpg cn=true]

It's the same as always, but he's moody and annoying.
[cpg]

I want him to take care of me, the one being pushed around.
[cpg]

[FO pos="2/5" time=800]
[FG f="amane_p5_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0256"]
[OnName num="amane"]
"I'm sorry ....... If you get into a fight with Minegishi , you can call me by my last name or something."
[cpg cn=true]

[OnName num="shinzi"]
"No, no, no!　That's not right.
[cpg cn=true]

Why do I have to change the way I call my friends just to make Yoko feel better?
[cpg]

[OnName num="shinzi"]
"Don't worry about it. "Don't worry about it. I like to call Amane ' Amane '."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0257"]
[OnName num="amane"]
"..............."
[cpg cn=true]

At my words, Amane smiled a little.
[cpg]

I'm not sure what the difference is, even though they are the same woman.
[cpg]

It's a great way to make sure you're getting the most out of your time and money.
[cpg]

I'm afraid that if you add them up and divide by two, the Yoko portion will still win out.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0258"]
[OnName num="amane"]
"But Minegishi is amazing ....... I'm jealous you're able to make Shinji feel better."
[cpg cn=true]

Amane stared into the sky with distant eyes, seeming to sense Yoko 's words and actions.
[cpg]

[OnName num="shinzi"]
"It's not that I'm fine,......, it's that I'm almost 'angry',.......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0259"]
[OnName num="amane"]
"It's something I can't ...... do. I respect ...... you."
[cpg cn=true]

[OnName num="shinzi"]
"Huh. ......
[cpg cn=true]

I have a lot of respect for that kind of Amane .
[cpg]

This is a great way to make sure you are getting the most out of your time with your family.
[cpg]

What a good-natured girl.
[cpg]

[SE f="se009"]
;//【ＳＥ】チャイム


[OnName num="shinzi"]
"Ah ......"
[cpg cn=true]

The first bell rang.
[cpg]

But there are still five minutes before the main bell.
[cpg]

I thought I could still talk to Amane for five more minutes.
[cpg]

[OnName num="shinzi"]
"Continuing from where we left off, ........."
[cpg cn=true]

I wanted to hear about Amane 's dream, so I thought I would start over.
[cpg]

But then ......
[cpg]

[FO pos="2/3" time=800]

[OnName num="female_student"]
" Mizushima !　Don't forget, you have a committee meeting after school!
[cpg cn=true]

[OnName num="shinzi"]
"I heard about it yesterday!　I know, I know!
[cpg cn=true]

One half of the class committee gave the same reminder as yesterday, and in the meantime Amane returned to his seat quietly.
[cpg]

[OnName num="shinzi"]
"'Oh ......'.
[cpg cn=true]

The disappointment was surprisingly greater than I had expected, and I wondered why I was so disappointed.
[cpg]

It was just that the chit-chat was over .......
[cpg]

[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye2"]
[BG f="b_s_cf_t2_0.ui" time=1000]
;//【ＢＧ】学園　会議室　午後　雨


[OnName num="vice-president"]
"'On today's agenda is the division of roles for next month's school-wide cleanup,.......'
[cpg cn=true]

[OnName num="shinzi"]
"Wow ......."
[cpg cn=true]

It was after school and I was attending a class council meeting, I was looking outside, bored with the usual boredom in the air.
[cpg]

;//[SE f="se006"]
;//【ＳＥ】窓の外に聞こえる雨の音（サー……）


It's a good idea to have a good idea of what you're going to be doing and how you're going to do it.
[cpg]

It's a good thing that it's not a heavy rain that hits the window yet, but the gray landscape of this season has a sinking melancholy to it.
[cpg]

[FG f="izumi_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0014"]
[OnName num="izumi"]
" Mizushima , can you hear me?"
[cpg cn=true]

[OnName num="shinzi"]
"Whoa!　Ha, yes, I hear you!"
[cpg cn=true]

I was so startled by the attention of the student president, Izumi , that my buttocks lifted off my chair.
[cpg]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0015"]
[OnName num="izumi"]
"In the event that you have any questions concerning where and how to use the internet, you can contact us at ....... Is that kid going to be okay?"
[cpg cn=true]

[OnName num="shinzi"]
"What do you mean by ...... okay?"
[cpg cn=true]

The actual meaning of the word is not really understood, and asked back.
[cpg]

Izumi In the event that you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0016"]
[OnName num="izumi"]
"Do you think you'll fit in with the class?　I'm sure you're worried about coming to a place you don't know and being alone, so you need to make sure you take care of yourself.
[cpg cn=true]

[OnName num="shinzi"]
"Ah, yes!"
[cpg cn=true]

You are a kind person. .......
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

I was impressed by the kindness of Izumi again.
[cpg]

[OnName num="female_student"]
"You'll be fine, Satonaka . She is beautiful, quiet, and already has a reputation in other classes.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0017"]
[OnName num="izumi"]
"Is that so?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, well, ......
[cpg cn=true]

One of the classmates in my class spoke in such a way that Izumi seemed to be interested in Amane .
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0018"]
[OnName num="izumi"]
"If it's so well known, I might as well say hello at least once.
[cpg cn=true]

[OnName num="shinzi"]
"No, not at all. The chairman himself ......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0019"]
[OnName num="izumi"]
"No, not at all. Well, I'll see you soon.
[cpg cn=true]

It's a great way to get to know the people in your area.
[cpg]

This is a great way to make sure you are getting the most out of your time with your family.
[cpg]

I'm not very good at this kind of communication,.......
[cpg]

I'm sure this will hurt you in the job interview ...... that's coming up.
[cpg]

[OnName num="vice-president"]
"Can we get back to the agenda ......?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0020"]
[OnName num="izumi"]
"Yes, yes, I'm sorry. Go back, go back.
[cpg cn=true]

Izumi In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

This is a great way to get the most out of your business.
[cpg]

It's a great way to make sure you're getting the most out of your money. Izumi It's a great way to get the most out of your day.
[cpg]


[FO pos="2/3" time=800]

[SE f="se009"]
;//【ＳＥ】チャイム


[OnName num="vice-president"]
"Then, tomorrow, each of you will take this decision back to your class,......."
[cpg cn=true]

When the committee meeting is finally over, I approached Izumi myself.
[cpg]

[OnName num="shinzi"]
"I'd like to thank you for your time, senior.
[cpg cn=true]

[FG f="izumi_p5_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0021"]
[OnName num="izumi"]
"What?　What?
[cpg cn=true]

[OnName num="shinzi"]
"For taking care of the new student."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0022"]
[OnName num="izumi"]
"Oh, you mean that?　No, that's not it.
[cpg cn=true]

I'm not sure what to make of it, but I'm sure it's worth it.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0023"]
[OnName num="izumi"]
"It's just that my sister is that kind of girl, and I'm worried about her if she's that kind of girl too.
[cpg cn=true]

[OnName num="shinzi"]
"A girl like that ......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0024"]
[OnName num="izumi"]
"A shy and spoiled brat."
[cpg cn=true]

[OnName num="shinzi"]
"Huh.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0025"]
[OnName num="izumi"]
"Do you remember?　The first time you met Shizuku ?
[cpg cn=true]

[OnName num="shinzi"]
"I remember.
[cpg cn=true]

[FO pos="2/3" time=800]

It was a few months ago.
[cpg]

I was waiting Shizuku in the hallway for Izumi after a committee meeting.
[cpg]

The senior was trying to introduce her to me, but I kept looking down and picking at the senior's cuffs and moping .......
[cpg]

It was like a girl in kindergarten.
[cpg]

[OnName num="shinzi"]
"But it's normal once you get used to it.
[cpg cn=true]

[FG f="izumi_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Izumi0026"]
[OnName num="izumi"]
"It's hard to get used to.
[cpg cn=true]

It's true that it took a long time for Shizuku to get used to me.
[cpg]

In the beginning, he just bowed his head without even making eye contact.
[cpg]

In the middle of the game, he just mumbled, "Hello, ......," in a mosquito-like voice.
[cpg]

It took me as long as it took to tame the delicate Bambi. ......
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0027"]
[OnName num="izumi"]
"So, if the new student was like that, I would have wanted to be careful, but it looks like Mizushima you're fine.
[cpg cn=true]

[OnName num="shinzi"]
"What?　Why is it okay if I'm there?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0028"]
[OnName num="izumi"]
"I'm not sure what to do, but I'm not sure what to do. You must have already become rather close to her.　Otherwise, you wouldn't be thanking her for someone else's sake.
[cpg cn=true]

[OnName num="shinzi"]
"Ha~"
[cpg cn=true]

The intelligent president of the student body was making deductions like a great detective.
[cpg]

It was not out of line, and I was once again impressed with Izumi .
[cpg]

I guess that's what a smart person is.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Izumi0029"]
[OnName num="izumi"]
"I'll see you later. Have a good day."
[cpg cn=true]

[OnName num="shinzi"]
"Yes!　Excuse me."
[cpg cn=true]

That's so cool~ .......
[cpg]

[FO pos="2/3" time=800]

In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]


[jump storage="ep003.ks" target="*start"]
