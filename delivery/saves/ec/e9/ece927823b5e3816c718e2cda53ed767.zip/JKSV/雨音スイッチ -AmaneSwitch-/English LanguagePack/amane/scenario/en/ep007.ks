*start

;#################################################
*Ep007|full of holes
;#################################################
[SCENE id=7]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_ex_ex_t1_0.ui" time=1000]
;//【ＢＧ】薄明かりの部屋　夜　（絵があれば雪華の部屋。なければ適切などこか）


[FG f="yukika_p7_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0040"]
[OnName num="yukika"]
"'I knew it was ............'
[cpg cn=true]

That day, Yukika was alone, immersed in the work of checking a certain document.
[cpg]

A sheet of paper that was closed inside a thick file.
[cpg]

There was a sheet of paper closed in a thick file, and the item she was looking for was secretly written on it.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0041"]
[OnName num="yukika"]
"Victim, Satoru Mizushima ....... Same, Hirose water bell ......."
[cpg cn=true]

It details an accident involving Shinji 's father.
[cpg]

Yukika had been searching for information about it.
[cpg]

Shinji 's father was killed in an accident when Shinji was nine years old.
[cpg]

Yukika remembered the details of that time.
[cpg]

It was an accident that didn't have to happen. Shinji 's father was trying to help a woman who had walked into a railroad crossing.
[cpg]

;//回想シーン（セピア）


;//慎二の父の葬儀　棺桶に縋り付いて泣く９歳の慎二と、涙を堪えて押し止める慎二の母、それを見詰める若い頃の雪華

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="sir"]
[BG f="b_ex_sk_t2_0.ui" time=1000]
;//【ＢＧ】抽象的な背景（色？　曇り空でもok）


[OnName num="shinzi"]
"Dad!　Wake up!　Wake up!"
[cpg cn=true]

[OnName num="mother"]
" Shinji , quietly ......"
[cpg cn=true]

[OnName num="shinzi"]
"No!　You said we'd play catch!　You promised me!
[cpg cn=true]

[OnName num="mother"]
" Shinji ......, don't cry ....... Your father can't sleep. ......
[cpg cn=true]

[OnName num="shinzi"]
"Father!　I don't want to die!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0042"]
[OnName num="yukika"]
" Shinji ......, come here .......
[cpg cn=true]

[OnName num="shinzi"]
"Aaahhh!　Sis!　My father!　My dad!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0043"]
[OnName num="yukika"]
" Shinji ......"
[cpg cn=true]


;//回想明け
[BGM f="insecurity"]
[BG f="b_ex_ex_t1_0.ui" time=1000]



[FG f="yukika_p5_01_a.ui" method="change_1" pos="2/3" time=800]

The woman who tried to save him died together with him, and he could not complain to anyone. I remember how much pain and sorrow my aunt and Shinji suffered at that time, and my heart is still tightened.
[cpg]

At that time when I saw the young Shinji crying, Yukika swore.
[cpg]

"I will definitely make Shinji happy.
[cpg]

Since then, she has watched Shinji grow up and treated him with more love than a sister or brother.
[cpg]

That's why she can't just throw him away.
[cpg]

This situation ...... is now.
[cpg]

Now that I've noticed it, I have to stop it.
[cpg]

If I don't eliminate it, Shinji it will hurt me.
[cpg]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0044"]
[OnName num="yukika"]
"I have to ......."
[cpg cn=true]

I'm not sure what to do, but I'm sure I'll be able to do it. Yukika muttered to himself and closed the heavy file quickly.
[cpg]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_3f_t1_1.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午前　小雨


[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0499"]
[OnName num="amane"]
" Shinji ......, I'm sorry about yesterday, okay?"
[cpg cn=true]

[OnName num="shinzi"]
"Oh, oh ......."
[cpg cn=true]

The next day, when I arrived at school, a worried Amane greeted me.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0500"]
[OnName num="amane"]
"Are you okay?　My neck. ......
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, I'm fine. ......
[cpg cn=true]




Yesterday, when we embraced, Amane 's strength was too strong, and her nails accidentally caught my neck and left a mark.
[cpg]

She was worried about that.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0501"]
[OnName num="amane"]
"'Don t ...... hate me, please.
[cpg cn=true]

[OnName num="shinzi"]
"'I won't, but ......, if I could, I would ...... no longer do that sort of thing.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0502"]
[OnName num="amane"]
"I won't do it. I promise I won't. I'm out of my mind.
[cpg cn=true]

[OnName num="shinzi"]
"I hope you understand. ......
[cpg cn=true]

I try not to provoke Amane as much as I can.
[cpg]

But what does Amane feel like ......?
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]


;//move
[move from="2/3" to="2/5" ease="easeInOutSine" time=800]

[FG f="youko_p5_01_a.ui" method="change_1" pos="4/5" time=800]
;//[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]

[WAIT time=100]
[VOICE f="Youko0108"]
[OnName num="youko"]
" Satonaka , can I have a word with you?"
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0503"]
[OnName num="amane"]
"What?
[cpg cn=true]

[OnName num="shinzi"]
"What the hell, ......?
[cpg cn=true]

I feel like I haven't seen Yoko 's face in a while.
[cpg]

That's fine, but why did he come to our class with no discipline?
[cpg]

In addition, it is suspicious ...... that he has an errand for Amane .
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0109"]
[OnName num="youko"]
"Hey, I need to talk to you."
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0504"]
[OnName num="amane"]
"What ......?
[cpg cn=true]

[OnName num="shinzi"]
"If you want to talk, do it here.
[cpg cn=true]

It was obvious that he was going to make another false accusation, so I intervened between Yoko and Amane like a watchdog.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0110"]
[OnName num="youko"]
"It's a woman to woman thing.
[cpg cn=true]

[OnName num="shinzi"]
"I don't know.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0505"]
[OnName num="amane"]
" Shinji , I'm fine with it. ......
[cpg cn=true]

[OnName num="shinzi"]
"But ......
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0111"]
[OnName num="youko"]
"Will you come over here for a minute?
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0506"]
[OnName num="amane"]
"Yes, .......
[cpg cn=true]

As long as he said it was okay, I couldn't say anything, and Amane was taken out of the classroom by Yoko .
[cpg]

[OnName num="male_student"]
"It's a confrontation between the old and new wives.
[cpg cn=true]

[OnName num="shinzi"]
"Shut up!"
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

Yoko Amane You can find a lot of things that you can do to make your life easier.
[cpg]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_s_wl_t1_0.ui" time=1000]
;//【ＢＧ】学園　女子更衣室　午前　小雨


[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="youko_p5_01_a.ui" method="change_1" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Amane0507"]
[OnName num="amane"]
"'Um, ......, the story is ......?
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0112"]
[OnName num="youko"]
"Do you remember me?　Remember me?
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0508"]
[OnName num="amane"]
"Yeah, .......
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0113"]
[OnName num="youko"]
"You remember me, right?　I forgot about you.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0509"]
[OnName num="amane"]
"What are you... what are you talking about? ......
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0114"]
[OnName num="youko"]
"What?　That's weird. You said you remember.　The bullied one remembers more than the bullied one. You know?　Rain girl, Amane .
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0510"]
[OnName num="amane"]
".........!"
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0115"]
[OnName num="youko"]
"...... I knew it. We were in the same class in elementary school, right?
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0511"]
[OnName num="amane"]
"..............."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0116"]
[OnName num="youko"]
"What was my nickname?
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0512"]
[OnName num="amane"]
"............. ...... of the sun. Yoko ... ...
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0117"]
[OnName num="youko"]
"Yeah. Well said.
[cpg cn=true]

[SE f="se041"]
;//【ＳＥ】拍手

[BGM f="danger"]


Yoko was acquainted with Amane .
[cpg]

They were once classmates at Sugisawa 2 Elementary School.
[cpg]

It had been a long time since he had forgotten, but Yoko had already begun to dislike a girl named Amane .
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0118"]
[OnName num="youko"]
"Didn't she remind you of me when you met me here?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0513"]
[OnName num="amane"]
".................."
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0119"]
[OnName num="youko"]
"You wouldn't, would you?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0514"]
[OnName num="amane"]
"..................
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0120"]
[OnName num="youko"]
"But we're both adults now, so let's not talk about the past. Let's let bygones be bygones.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0515"]
[OnName num="amane"]
"...... Yeah.
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0121"]
[OnName num="youko"]
"So, ......, huh?　You're a rainy day girl, Amane . You should break up with Shinji .
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0516"]
[OnName num="amane"]
".................."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0122"]
[OnName num="youko"]
"Then I won't care about you anymore. It's a give and take.
[cpg cn=true]

Perhaps it was his forceful personality that made him do it, but Yoko didn't seem to care if he used the wrong words.
[cpg]

This is a great way to get the most out of your time with your family and friends. Amane cowered like a frog stared at by a snake, but muttered in a clearly audible voice.
[cpg]


[WAIT time=100]
[VOICE f="Amane0517"]
[OnName num="amane"]
"I can t ......... do it."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0123"]
[OnName num="youko"]
"What?　What?"
[cpg cn=true]

I'm sure you can hear me. Yoko emits a clear intimidation.
[cpg]

But Amane 's answer remained the same.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_3" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0518"]
[OnName num="amane"]
"You can't ...... do that."
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0124"]
[OnName num="youko"]
"You ......"
[cpg cn=true]

Yoko glared at Amane with burning eyes.
[cpg]

The idea that this woman is caging Shinji is so infuriating that I want to punch her in the face right now.
[cpg]


[WAIT time=100]
[VOICE f="Youko0125"]
[OnName num="youko"]
"Do you know what will happen if you say that!"
[cpg cn=true]

Unable to control his emotions, Yoko unintentionally grabbed Amane his collar and shouted angrily.
[cpg]

There ......
[cpg]

[SE f="se035"]
;//【ＳＥ】ドア開く

[FG f="shizuku_p5_01_a.ui" method="change_5" pos="5/4" time=800]
[WAIT time=20]
;//move
[move from="2/5" to="1/3" ease="easeInOutSine" time=800]
[move from="4/5" to="2/3" ease="easeInOutSine" time=800]
[move from="5/4" to="3/3" ease="easeInOutSine" time=800]

;//[FG f="amane_p5_01_a.ui" method="change_1" pos="1/3" time=800]
;//[FG f="youko_p5_01_a.ui" method="change_1" pos="2/3" time=800]
;//[FG f="shizuku_p5_01_a.ui" method="change_1" pos="3/3" time=800]

[WAIT time=100]
[VOICE f="Shizuku0080"]
[OnName num="shizuku"]
"Yeah ......."
[cpg cn=true]

By chance, an underclassman ...... and, of course, Shizuku entered the locker room.
[cpg]

[FACE method="change_5" pos="1/3"]

[WAIT time=100]
[VOICE f="Amane0519"]
[OnName num="amane"]
"Oh ......"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0126"]
[OnName num="youko"]
"What the ......
[cpg cn=true]

Because it was a freshman who came in, Yoko did not let go of Amane his collar.
[cpg]

On the contrary, he even appealed to Shizuku him with his eyes to get out.
[cpg]

[FACE method="change_7" pos="3/3"]

[WAIT time=100]
[VOICE f="Shizuku0081"]
[OnName num="shizuku"]
"'Oh, Amane senior ......
[cpg cn=true]

[FACE method="change_4" pos="1/3"]

[WAIT time=100]
[VOICE f="Amane0520"]
[OnName num="amane"]
" Shizuku ......."
[cpg cn=true]

If you have any questions regarding where and how to get the best results, you can contact us at Shizuku .
[cpg]

This is a great way to make sure you are getting the most out of your time with your family.
[cpg]

[FACE method="change_7" pos="3/3"]

[WAIT time=100]
[VOICE f="Shizuku0082"]
[OnName num="shizuku"]
"Ah...ah ......"
[cpg cn=true]

However, in the back of Shizuku 's mind, the words that her sister Izumi said, "Don't get along with that girl," stuck.
[cpg]

What should I do? Should I help her? Should I speak up?
[cpg]

The decision was too much for the indecisive Shizuku to begin with.
[cpg]

[FACE method="change_4" pos="3/3"]

[WAIT time=100]
[VOICE f="Shizuku0083"]
[OnName num="shizuku"]
"I'm sorry,......."
[cpg cn=true]

;//move
[move from="3/3" to="5/4" ease="easeInOutSine" time=800]

;//画面外に移動した立ち絵の削除
[FO pos="5/4" time=800]

Unable to help himself, and without even looking Amane in the eye, the weak Shizuku just chose to leave.
[cpg]

[SE f="se036"]
;//【ＳＥ】ドア閉まる


;//move
[move from="1/3" to="2/5" ease="easeInOutSine" time=800]
[move from="2/3" to="4/5" ease="easeInOutSine" time=800]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0127"]
[OnName num="youko"]
"Did you think you could help me?"
[cpg cn=true]


[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0521"]
[OnName num="amane"]
"..............."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0128"]
[OnName num="youko"]
"Hey, let me show you ...... this.
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0522"]
[OnName num="amane"]
"......?"
[cpg cn=true]

Yoko took her phone out of her skirt pocket, fiddled with it and then thrust the screen in front of Amane 's face.
[cpg]


[FG f="amane_p5_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0523"]
[OnName num="amane"]
".........?　.........!"
[cpg cn=true]

In the event that you've got a lot more than one, you'll be able to take a look at a lot more.
[cpg]

But the image on the phone that I could see was ......
[cpg]



[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0524"]
[OnName num="amane"]
"!!!
[cpg cn=true]

It was a picture of myself and Shinji hugging in an abandoned building in the rain last night.
[cpg]



[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0525"]
[OnName num="amane"]
"Turn it off!"
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0129"]
[OnName num="youko"]
"Dame. This is a last resort because Shinji is in the picture. If you really want to get rid of it, you can use it as an example.
[cpg cn=true]

Yoko smiled wickedly and put the phone in his pocket.
[cpg]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0526"]
[OnName num="amane"]
"If you do that, ......, Yoko , you're going to hate .......
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0130"]
[OnName num="youko"]
"Oops, that's what you get?　What do you think?　This is a great way to get the most out of your time and money.
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0527"]
[OnName num="amane"]
".................."
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0131"]
[OnName num="youko"]
"Before that, if you reveal your background, no one will believe you.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_5" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0528"]
[OnName num="amane"]
".........!
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Youko0132"]
[OnName num="youko"]
"Well, think about it, rain girl!
[cpg cn=true]

[SE f="se036"]
;//【ＳＥ】ドア開いて閉まる

[move from="4/5" to="5/4" ease="easeInOutSine" time=800]
[FO pos="5/4" time=800]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0529"]
[OnName num="amane"]
"Rainy... on... ......"
[cpg cn=true]

Even after Yoko had left, the word was still running through Amane 's head.
[cpg]


"A lot of the time, it's the same thing.
[cpg]

Ever since the day he first heard it, Amane has been trapped under its spell.
[cpg]

;//回想（セピア）

[FO pos="2/5" time=800]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="sir"]
[BG f="b_a_old_t1_0.ui" time=1000]
;//【ＢＧ】過去の雨音の家　リビング　昼　雨（セピア調）


;//中流の家　昼間から酒を飲む父と、部屋に洗濯物を干す母。５歳くらいの雨音。


[OnName num="father"]
"Damn, it's raining again!"
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0530"]
[OnName num="amane"]
"Pow, pow, pow."
[cpg cn=true]

[OnName num="father"]
"Shut up!
[cpg cn=true]

[OnName num="mother"]
" Amane , Daddy's tired, so don't bother, okay?
[cpg cn=true]

[OnName num="father"]
"Don't hang your laundry in the house!　You're making the house smell like shit!
[cpg cn=true]

[OnName num="mother"]
"Well, it's raining all the time. ......
[cpg cn=true]

[OnName num="father"]
"It keeps raining because you're a rain woman!　You always make it rain when you need it most.
[cpg cn=true]

[OnName num="mother"]
"............
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0531"]
[OnName num="amane"]
"Mom, what's a rain woman?
[cpg cn=true]

[OnName num="mother"]
"It's nothing.
[cpg cn=true]

[OnName num="father"]
"It's a bitter woman who makes it rain whenever she's around!　 Amane , you're a rain maiden born of her!　You're a bitter, sullen, rainbow-eyed bitch!
[cpg cn=true]

[OnName num="mother"]
"Please don't do that to the kids. ......
[cpg cn=true]

[OnName num="father"]
"Fuck!
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0532"]
[OnName num="amane"]
"I'm not ...... a rain woman. ......, Amane is not a rain woman. ......
[cpg cn=true]

[OnName num="mother"]
" Amane , don't cry. Mommy loves the rain.　♪ Pitter-patter, chirp-chirp, run-run-run ♪
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0533"]
[OnName num="amane"]
"Mommy, do you love the rain?
[cpg cn=true]

[OnName num="mother"]
"I love it!　Because Amane was born on a rainy day. To her, the sound of the rain is like the angels celebrating the birth of Amane .
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0534"]
[OnName num="amane"]
"Mommy ....... Amane also likes the rain ....... Because I love my mommy, Amane loves the rain, too!"
[cpg cn=true]

[OnName num="mother"]
"Oof, good boy. Amane ......."
[cpg cn=true]


;//回想明け
[STOPBGM]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_s_wl_t1_0.ui" time=1000]
;//【ＢＧ】学園　女子更衣室　午前　小雨


;//目がイッてる雨音


[FG f="amane_p5_01_a.ui" method="change_8" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0535"]
[OnName num="amane"]
"I'm not a ...... rain woman. ...... I'm not ...... a rain girl, and neither is my mommy ......."
[cpg cn=true]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_3f_t1_1.ui" time=1000]
;//【ＢＧ】学園　３Ｆ教室（２-Ｃ）　午前　小雨


[SE f="se009"]
;//【ＳＥ】チャイム


When recess ended and class began, Amane did not return.
[cpg]

Is she still talking to Yoko ?
[cpg]

[OnName num="shinzi"]
"No way. ......
[cpg cn=true]

[OnName num="teacher"]
"Then open your textbook to page 26, .......
[cpg cn=true]

[SE f="se047"]
;//【ＳＥ】バイブ


[OnName num="shinzi"]
"Hmm, ......?"
[cpg cn=true]




When I got the message and checked my phone, it was from Amane .
[cpg]




;//メッセージ画面


" Amane " I feel sick, so I'm leaving early, sorry.
[cpg]




[OnName num="shinzi"]
"Eh ......?"
[cpg cn=true]

What in the world is wrong with me?
[cpg]

Yoko I'm not sure if it's just me or if it's the other way around.
[cpg]

What's wrong?　 Yoko I'm not sure what to say.　Are you okay?
[cpg]

I replied and waited for 5 minutes.
[cpg]




[SE f="se047"]
;//【ＳＥ】バイブ





;//メッセージ画面


" Amane " It's fine. From It's noothing
[cpg]

[OnName num="shinzi"]
" It's noothing ......"
[cpg cn=true]

Normally, I would laugh it off as a typo, but I can't help but feel that Amane is upset about something.
[cpg]

"Honestly. I'll take care of Yoko for you.
[cpg]

Reply.
[cpg]

I never thought that waiting for a reply would be so frustrating.
[cpg]

I wonder if this is how Amane felt waiting to hear from me?
[cpg]




[SE f="se047"]
;//【ＳＥ】バイブ





;//メッセージ画面


" Amane " Don't wry abt it
[cpg]




[OnName num="shinzi"]
"'You should be worried ......!
[cpg cn=true]

I can't hide my impatience at the way the mistypes are getting worse and worse.
[cpg]

But after that, no matter how many messages I sent, I never received a reply.
[cpg]



[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_ex_tw_t1_0.ui" time=1000]
;//【ＢＧ】街　夕方　小雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、小雨】


[SE f="se132"]
;//【ＳＥ】ダッシュ





[OnName num="shinzi"]
"Hah hah hah ......"
[cpg cn=true]

Finally, after school, I ran to Amane 's apartment.
[cpg]

Yoko Amane You can find a lot of people who are looking for the best way to get the most out of their lives.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_a_me_t2_0.ui" time=1000]
;//【ＢＧ】雨音のマンション　出入り口　夕方　小雨


[SE f="se017"]
;//【ＳＥ】チャイム×２


[OnName num="shinzi"]
"Damn ...... why."
[cpg cn=true]

No matter how many times you press the room number and the call button, there is no response at all.
[cpg]

If you have any questions regarding where and how to start, you can contact us at the following address.
[cpg]

[OnName num="resident"]
"Can I come in?
[cpg cn=true]

[OnName num="shinzi"]
"Oh, I'm sorry. I forgot my key and had to leave.
[cpg cn=true]

[OnName num="resident"]
"Oh, my God. Come in.
[cpg cn=true]

[OnName num="shinzi"]
"Hi.
[cpg cn=true]

The unsuspecting good guy lets me into the entrance, and I get on the elevator with him.
[cpg]



[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト


[SE f="se014"]
;//【ＳＥ】鉄扉開く





[OnName num="shinzi"]
" Amane , you're here!
[cpg cn=true]

The door to the room was unlocked.
[cpg]

In the event that you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

Amane You will find a lot of things that you can do to make your life easier.
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="h2"]
[BG f="b_a_mr_t3_0.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夕方　小雨


[OnName num="shinzi"]
Amane "I'm sure you'll be pleased to know that I'm not the only one.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0536"]
[OnName num="amane"]
".................."
[cpg cn=true]




[free time=800]
;**【ＣＧ】ev_21_0 ***********************
[CG id=7 index=0 time=1000]
;*****************************************



[SE f="se082"]
;//【ＳＥ】ポリポリポリポリ（錠剤を噛む）


Amane This is a great way to make sure that you don't end up in a situation where you're going to have to pay a lot of money to get a job.
[cpg]

[OnName num="shinzi"]
"What are you doing, yo!"
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】バシッ！　バララララ！（叩いて薬が大量に散らばる）


He knocked a large amount of something off of the biting Amane hand.
[cpg]

[SE f="se029"]
;//【ＳＥ】ガサガサッ！


[OnName num="shinzi"]
".........!"
[cpg cn=true]

It's a good idea to have a good idea of what you're going to be doing and how you're going to do it.
[cpg]

[OnName num="shinzi"]
"What the ......?"
[cpg cn=true]

I picked up the bag of pills and looked inside to find a piece of paper with the names and descriptions of drugs I didn't know.
[cpg]

I'm not sure what to make of it.
[cpg]

[OnName num="shinzi"]
"Mental ......."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0537"]
[OnName num="amane"]
".................."
[cpg cn=true]

I'm not sure what kind of medicine it is, or even if it's ramune, but there's no way I could eat this much of it.
[cpg]

[OnName num="shinzi"]
" Amane !　I'm sorry.　Do you understand me?
[cpg cn=true]

Amane It's a great way to make sure you're getting the most out of your vacation.
[cpg]

Then ......
[cpg]

[free time=800]
;**【ＣＧ】ev_21_a ***********************
[CG id=7 index=1 time=1000]
;*****************************************


[WAIT time=100]
[VOICE f="Amane0538"]
[OnName num="amane"]
"I'm sorry.　 Shinji ku~n ...... you came to me ...... ahahaha."
[cpg cn=true]

[OnName num="shinzi"]
"......!"
[cpg cn=true]

The eyes were completely fixed.
[cpg]

This is a great way to make sure you are getting the most out of your money.
[cpg]

Amane This is a great way to make sure you are getting the most out of your money.
[cpg]

[OnName num="shinzi"]
Amane "I'm not sure what to do, but I'm going to do it.　You've been doing this since you got back!
[cpg cn=true]

[free time=800]
;**【ＣＧ】ev_21_b ***********************
[CG id=7 index=2 time=1000]
;*****************************************


[WAIT time=100]
[VOICE f="Amane0539"]
[OnName num="amane"]
"What?　I'm not sure what to do...　I'm going home. ............
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0540"]
[OnName num="amane"]
"Oh, my God!
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

Suddenly, Amane bends forward and vomits.
[cpg]

It's a good idea to have a good idea of what you're going to be doing and how you're going to do it.
[cpg]

[OnName num="shinzi"]
"You're okay?　Throw it all up!"
[cpg cn=true]

I rubbed his back and tried to get him to vomit it all out, but Amane he gagged and choked in pain several times and ......
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_a_mr_t3_0.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夕方　小雨


[SE f="se059"]
;//【ＳＥ】ドサッ


I'm not sure what to do, but I'm sure I'll be able to do it.
[cpg]

[OnName num="shinzi"]
"Hey!　 Amane !　Get up, Amane !
[cpg cn=true]



[WAIT time=100]
[VOICE f="Amane0541"]
[OnName num="amane"]
"........................"
[cpg cn=true]

In the event that you're not sure what to do, you'll be able to find a lot more information on the web.
[cpg]

It's not just a fever.
[cpg]

I thought I would die if I let it go.
[cpg]

;#############################################################


;#############################################################


[SE f="se013"]
;//【ＳＥ】救急車


;//赤いパトライト的な効果からエフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_h_cr_t2_0.ui" time=1000]
;//【ＢＧ】病院　診察室　夜　小雨


[OnName num="doctor"]
"Why did you have such a large supply of psychotropic drugs?
[cpg cn=true]

[OnName num="shinzi"]
"I don't know. ......
[cpg cn=true]

The doctor who treated Amane me yelled at me.
[cpg]

[OnName num="doctor"]
"Well, you did the right thing. ......"
[cpg cn=true]

He said I had brought the medication instructions with me when I got to the ambulance so he could give me the proper treatment.
[cpg]

[OnName num="doctor"]
"So?　Are you a friend?　I need to contact her parents.
[cpg cn=true]

[OnName num="shinzi"]
"Parents at ......."
[cpg cn=true]

The guardian of Amane was probably the person who was guarantor of the apartment, but I had no way of knowing who to contact.
[cpg]

[OnName num="nurse"]
"Don't get up yet!
[cpg cn=true]

Just then, I heard a woman shouting behind the curtain, and Amane came staggering over.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0542"]
[OnName num="amane"]
"Excuse me, ....... I'm sorry ...... for worrying you."
[cpg cn=true]

[OnName num="doctor"]
"You're awake already? It's not the first time you've overdosed."
[cpg cn=true]

The word was unfamiliar, but the doctor and Amane seemed to know what it was.
[cpg]

[OnName num="doctor"]
"No?　Have you called your parents?
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0543"]
[OnName num="amane"]
"I'll do it myself.
[cpg cn=true]

[OnName num="doctor"]
"Well, when they get here, you'll have to go to the reception and pay for the procedure.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0544"]
[OnName num="amane"]
"Yes, .......
[cpg cn=true]

[OnName num="shinzi"]
"What?　That's it?
[cpg cn=true]

[OnName num="doctor"]
"This is an emergency room. You'll have to go to a psychiatrist or something for the rest.
[cpg cn=true]

[OnName num="shinzi"]
"Hey, that's not .......
[cpg cn=true]

[OnName num="mother"]
" Shinji ......, come on.
[cpg cn=true]

[OnName num="shinzi"]
"Mom?
[cpg cn=true]

You will find a lot of things that you can do to make your life easier.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[OnName num="mother"]
"You, too, Amane should go outside ...... for now."
[cpg cn=true]

I'm sure you'll be able to understand why.
[cpg]

[stopse g=2]
[stopse g=6]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="healing"]
[BG f="b_h_wr_t1_0.ui" time=1000]
;//【ＢＧ】病院　待合室　夜　小雨


In the event that you've got a lot of money, you'll be able to use it for a lot of things.
[cpg]

Mom handed Amane a glass of juice and squatted down in front of her in a chair, telling her gently, "You know, you're not the only one.
[cpg]

[OnName num="mother"]
"Listen, Amane girl. You know what you did was wrong, don't you?"
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0545"]
[OnName num="amane"]
"Yes, ....... I'm sorry.
[cpg cn=true]

[OnName num="mother"]
"I don't want you to apologize, Auntie. She just wants you to know that there's a little more to it than that. I want you to know that Shinji will be very sad when you're gone.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0546"]
[OnName num="amane"]
".........!"
[cpg cn=true]

[OnName num="mother"]
"Do you know how sad it is to lose someone you care about?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0547"]
[OnName num="amane"]
"Yes, .......
[cpg cn=true]

[OnName num="mother"]
"You're not alone anymore, okay?　 You have Shinji and me.　I may be old, but I can still be your friend.
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0548"]
[OnName num="amane"]
"Uh...ugh. ......"
[cpg cn=true]

At Mom's words, Amane began to cry in a small voice.
[cpg]

[OnName num="mother"]
"You know what?　Don't you dare make us sad.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0549"]
[OnName num="amane"]
"Yes, ......."
[cpg cn=true]

[OnName num="mother"]
"Good!　Well then, Shinji , give her a lift.
[cpg cn=true]

[OnName num="shinzi"]
"Are you sure you're okay?
[cpg cn=true]

[OnName num="mother"]
"Your stomach's been cleaned, so don't worry. Well, if you feel a little queasy, that's your punishment.
[cpg cn=true]

[OnName num="shinzi"]
"Okay, ....... Okay, Amane . Let's go, .
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0550"]
[OnName num="amane"]
"Oh, ......, I'm so sorry.
[cpg cn=true]

[OnName num="mother"]
" Shinji , you're welcome to come over anytime. The girls who do this ...... are usually the ones who can't stand being lonely anymore."
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, ......."
[cpg cn=true]

I left the hospital with Amane my mother's kindness in my heart, so that Amane could not hear.
[cpg]



[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_ex_sz_t3_0.ui" time=1000]
;//【ＢＧ】通学路　夜　霧雨


;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


[SE f="se028"]
;//【ＳＥ】雨の中歩く（霧雨）




[FG f="amane_p8_01_a.ui" method="change_1" pos="2/3" time=800]

I'm not sure if this is a good idea or not.
[cpg]

It's a good thing that Amane doesn't try to get out from under my umbrella today.
[cpg]

[OnName num="shinzi"]
"I'm sure you've heard of Amane ......, but as my mom said earlier .......
[cpg cn=true]

[FG f="amane_p7_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0551"]
[OnName num="amane"]
"Yeah, ......."
[cpg cn=true]

[OnName num="shinzi"]
"Don't do this to me. ......
[cpg cn=true]

[FG f="amane_p8_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0552"]
[OnName num="amane"]
"Yeah. ......
[cpg cn=true]

[OnName num="shinzi"]
"Will you promise me?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0553"]
[OnName num="amane"]
"I want to ...... promise.
[cpg cn=true]

[OnName num="shinzi"]
"You want to ......?
[cpg cn=true]

[FG f="amane_p7_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0554"]
[OnName num="amane"]
"I promise I'll do Shinji a favor for you.
[cpg cn=true]

[OnName num="shinzi"]
"What favor?
[cpg cn=true]

I could have gotten angry and said I was in no position to do that.
[cpg]

But I didn't want to do that to Amane a lonely man who was so dependent on drugs.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0555"]
[OnName num="amane"]
"You can find a lot of people who are looking for the best way to get the most out of their lives. No matter what happens in the future, please do not hate ...... me.
[cpg cn=true]

[OnName num="shinzi"]
"That's not ...... true.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0556"]
[OnName num="amane"]
"If Shinji promises to stay in love with me, ...... I won't take any more pills.
[cpg cn=true]

[OnName num="shinzi"]
"I promise.
[cpg cn=true]

[FG f="amane_p8_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0557"]
[OnName num="amane"]
"You promise?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah. I'll never hate Amane . I'll always love you.
[cpg cn=true]

If no one else can protect such a weak Amane , then ...... I'll definitely protect him.
[cpg]

I thought so.
[cpg]

There's no one on Amane 's side.
[cpg]

There is no one to help.
[cpg]

I'm the only one.
[cpg]

[FG f="amane_p7_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0558"]
[OnName num="amane"]
"Yay!"
[cpg cn=true]

[SE f="se132"]
;//【ＳＥ】ダッシュ
[free time=1000]

[OnName num="shinzi"]
"What?
[cpg cn=true]

I'm not sure how happy I was, but Amane jumped out of my umbrella with great force.
[cpg]

In the event that you have any questions regarding where and the best way to get in touch with your loved ones, please do not hesitate to contact us.
[cpg]

The fantastic scene made passersby open the way quickly, and in my eyes, it was like a scene from a movie.
[cpg]

Oh, Amane is the goddess of rain,.......
[cpg]

I naturally felt that way.
[cpg]

The clothes of Amane gradually become damp.
[cpg]

It's a great way to get the most out of your time and money.
[cpg]

The situation was really like a fantasy movie.
[cpg]



;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_ex_sz_t3_0.ui" time=1000]
;//【ＢＧ】通学路　夜　霧雨

;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]




[OnName num="shinzi"]
"'' Amane ......, let's go ...... home.''
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0559"]
[OnName num="amane"]
"Yeah."
[cpg cn=true]



;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[stopse g=2]
[stopse g=6]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
[BG f="b_si_r_t4_0.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　夜　霧雨


[SE f="se059"]
;//【ＳＥ】ドサッ





[OnName num="shinzi"]
"Phew ......."
[cpg cn=true]

Amane It's a great way to get a good night's sleep.
[cpg]

This is a great way to make sure you are getting the most out of your vacation.
[cpg]

This is not allowed as a student, but I hope one day such a day will come .......
[cpg]

[FG f="amane_p7_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0560"]
[OnName num="amane"]
" Shinji , are you tired?"
[cpg cn=true]

[OnName num="shinzi"]
"Hmm, yeah.
[cpg cn=true]

[FG f="amane_p8_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0561"]
[OnName num="amane"]
"All I do is make Shinji tired.
[cpg cn=true]

[OnName num="shinzi"]
"No, you're not. Don't be so down on yourself.
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0562"]
[OnName num="amane"]
"Okay.
[cpg cn=true]

Amane raised her head and ruffled her wet hair.
[cpg]

I've never seen her long hair dry before.
[cpg]







She is always wet in the rain, no matter what time of day. That's the image I get.
[cpg]

I've heard that it's because she likes the rain. I'm not sure if this is a good idea, but I'm sure it's a good idea.
[cpg]

The more you know about her, the more you can learn about Amane .......
[cpg]

The more you know about her, the more anxious you will be for some reason.
[cpg]


[jump storage="ep008.ks" target="*start"]
