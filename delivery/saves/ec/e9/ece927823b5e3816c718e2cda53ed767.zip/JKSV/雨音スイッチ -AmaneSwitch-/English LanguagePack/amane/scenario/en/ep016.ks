*start


;//////////////////////////////////////////////////////////////////////////
;#################################################
*Ep016|Am I the only one who's crazy?
;#################################################
[SCENE id=16]

[stopse g=2]
[stopse g=6]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
[BG f="b_s_sy_t1_0.ui" time=1000]
;//【ＢＧ】学園　校庭　午前　小雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、小雨】


[SE f="se018"]
;//【ＳＥ】ホイッスル（ピッピ！　ピッピ！）





[OnName num="pe_teacher"]
"Three more laps!"
[cpg cn=true]

The next day's physical education class was a marathon, which everyone hated.
[cpg]

[OnName num="female_student"]
"Sensei, it's starting to rain!"
[cpg cn=true]

[OnName num="pe_teacher"]
"After three laps, we'll move to the gym, so run quickly!"
[cpg cn=true]

[OnName num="female_student"]
"Hee~n!
[cpg cn=true]




[SE f="se018"]
;//【ＳＥ】ホイッスル（ピッピ！　ピッピ！）





The gym teacher urged everyone to run in the light rain with their chins sticking out.
[cpg]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_s_sy_t1_0.ui" time=1000]
;//【ＢＧ】学園　校庭　午前　小雨



;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]




In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

[FG f="amane_p1_12_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0784"]
[OnName num="amane"]
"Ha...ha...ha...ha...ha........."
[cpg cn=true]

[OnName num="shinzi"]
" Amane ..."
[cpg cn=true]

A slender body. I know that Amane is not very good at exercise.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]


[WAIT time=100]
[VOICE f="Amane0785"]
[OnName num="amane"]
"Hah hah hah ......."
[cpg cn=true]

[OnName num="shinzi"]
"...... Are you okay?"
[cpg cn=true]

I'm not sure what to do, but I'm not sure what to do.
[cpg]

[OnName num="shinzi"]
"'Sir! Satonaka You don't look well, so I'm taking you to the infirmary!
[cpg cn=true]

[OnName num="pe_teacher"]
"Hmm? I'm sure you'll be fine. All right, come on.
[cpg cn=true]

[FG f="amane_p5_12_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0786"]
[OnName num="amane"]
" Shinji , what's ......
[cpg cn=true]

[OnName num="shinzi"]
"No, no, no. Don't talk. You're... you're not well.
[cpg cn=true]

I lend a shoulder to Amane and head to the infirmary instead of the gym.
[cpg]





;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]




[stopse g=2]
[stopse g=6]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="danger"]
[BG f="b_s_pa_t1_2.ui" time=1000]
;//【ＢＧ】学園　廊下　午前　霧雨





[FG f="youko_p5_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Youko0236"]
[OnName num="youko"]
".........?"
[cpg cn=true]

In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

Yoko In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0237"]
[OnName num="youko"]
"What...so......... Shinji
[cpg cn=true]

I can't believe what I'm seeing.
[cpg]

This is a great way to make sure you are getting the most out of your time with your family.
[cpg]

No, it can't be.
[cpg]

It can't be.
[cpg]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0238"]
[OnName num="youko"]
"That woman ......!"
[cpg cn=true]

It is said that the anger of a woman who has been cheated on by a man is directed not at her lover, but at the other woman.
[cpg]

Yoko It's a good idea to have a good idea of what you're looking for.
[cpg]

[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Youko0239"]
[OnName num="youko"]
"I'll never forgive you again ......, never ......."
[cpg cn=true]

If Shinji hadn't cared so much about Amane , Yoko 's hatred would never have risen to this level.
[cpg]

However, the wheels of their fate had already creaked and were irreparably damaged.
[cpg]



[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
[BG f="b_s_sy_t1_0.ui" time=1000]
;//【ＢＧ】学園　校庭　午前　小雨



;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]





[FG f="amane_p5_12_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0787"]
[OnName num="amane"]
"Thank you, .......
[cpg cn=true]

[OnName num="shinzi"]
"............"
[cpg cn=true]

What the hell do you want from me?
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0788"]
[OnName num="amane"]
"I like Shinji ...... you?"
[cpg cn=true]

[OnName num="shinzi"]
"Oh, yeah. ......"
[cpg cn=true]

When I see Amane smiling like this, I feel like a horrible person for trying to give up on him, and the feeling that I still love Amane shakes my heart.
[cpg]

What am I supposed to do ......?
[cpg]

What should I do now,......?
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0789"]
[OnName num="amane"]
" Shinji , Shinji ♪"
[cpg cn=true]

[OnName num="shinzi"]
".................."
[cpg cn=true]





;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]




;#############################################################

;#############################################################

[jump storage="ep017.ks" target="*start"]
