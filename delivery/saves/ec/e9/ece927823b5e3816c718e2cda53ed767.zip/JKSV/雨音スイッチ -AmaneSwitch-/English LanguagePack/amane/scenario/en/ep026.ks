*start




;//４-a　雪華姉さんに従う
*choise_41

;#################################################
*Ep026|constitution
;#################################################
[SCENE id=28]
[BG f="b_ex_pk_t1_0.ui"]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]
;//loop
[SE f="se006" loop=true]
;//【雨、大雨】
[BGM f="rain"]

[FG f="yukika_p7_01_a.ui" method="change_4" pos="2/3"]

[OnName num="shinzi"]
" Yukika I'll do what my sister says: ......"
[cpg cn=true]

She was always right.
[cpg]

I've just been reminded of this by the Amane case.
[cpg]

So I think you should respect Yukika your sister's opinion, no matter what you think.
[cpg]

[FG f="yukika_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0179"]
[OnName num="yukika"]
"I'm sorry ......."
[cpg cn=true]

[OnName num="shinzi"]
"Don't apologize. You have sacrificed yourself to take care of me all these years. From now on, I want you to live for yourself and be happy.
[cpg cn=true]

I'm so immature, I can't make my sister happy.
[cpg]

It's a bit sad, but you have to accept reality as reality.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0180"]
[OnName num="yukika"]
"There are many more good things waiting for you in Shinji your life.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, I know. I'll do my best, you'll see.
[cpg cn=true]

In this way, my sister and I put the last memories we made together in our hearts and started our own lives,.......
[cpg]


*jump005

;//エフェクト

;//loop
[stopse g=2]
[stopse g=6]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//学校や街の風景がクロスしていく

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="insecurity"]
[BG f="b_ex_sk_t2_0.ui" time=1000]
;//【ＢＧ】空
[WAIT time=1000]




Then ......
[cpg]

The very rumor Kizaki Sisters disappeared from the school, and at the same time Amane also disappeared.
[cpg]

With the disappearance of the people involved in the various incidents, the topic has somehow ceased to be mentioned by people, and everyone has forgotten about their existence.
[cpg]

And when the seasons changed several times and I became a university student and started a new life, ......
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト
[BGM f="eye1"]

[OnName num="friend"]
"Hey, Mizushima.
[cpg cn=true]

[OnName num="shinzi"]
"What is it?　Another notebook?　Here.
[cpg cn=true]

[SE f="se075"]
;//【ＳＥ】バサッ


[OnName num="friend"]
"No, no, no!　Actually, there's a girl I'd like you to meet.
[cpg cn=true]

[OnName num="shinzi"]
"Really?
[cpg cn=true]

[OnName num="friend"]
"Seriously. Hey, come here.
[cpg cn=true]

"Hello, .......
[cpg cn=true]

[free time=800]
;**【ＣＧ】ev_97_0 ***********************
[CG id=24 index=0 time=1000]
;*****************************************




[OnName num="shinzi"]
"Hello, .......
[cpg cn=true]

The girl my friend brought in was very pretty and seemed mature.
[cpg]

She said, "Hey, ......, I've been looking at Mizushima . Would you like to be my friend?"
[cpg cn=true]

[OnName num="shinzi"]
"Of course. I don't know if I'm good enough!
[cpg cn=true]

She was a very nice girl and I was incredibly embarrassed.
[cpg]

[OnName num="friend"]
"I'm not sure what to say.　I hate you!
[cpg cn=true]

[OnName num="shinzi"]
"Yuck!
[cpg cn=true]

[OnName num="friend"]
"Why don't you buy me a drink sometime?　I'll leave the rest to you two young guys.
[cpg cn=true]

My friend, who was a bit of a joker, took his leave, and the girl and I began to have a lively conversation.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll be happy to know that I'm not the only one who has a problem with this.
[cpg cn=true]

[free time=800]
;**【ＣＧ】ev_97_a ***********************
[CG id=24 index=1 time=1000]
;*****************************************




"Is that okay?　Wow, I'm so happy!
[cpg cn=true]

I'm so happy that she's happy with my address.
[cpg]

I was so excited at the prospect of finally having a girlfriend.
[cpg]

We both picked up our phones to exchange addresses.
[cpg]

[OnName num="shinzi"]
".........?"
[cpg cn=true]

Her hand holding the phone suddenly caught my eye.
[cpg]


It's a great way to make sure you're getting the most out of your vacation.
[cpg]

It's a mismatched substitute for feminine attire and feels uncomfortable.
[cpg]



[free time=800]
;**【ＣＧ】ev_97_b ***********************
[CG id=24 index=2 time=1000]
;*****************************************


"What's wrong?"
[cpg cn=true]

She noticed my gaze and asks me curiously.
[cpg]

[OnName num="shinzi"]
"I'm not sure if it's a good idea or not.
[cpg cn=true]

"Oh, this?　No, this is ......."
[cpg cn=true]

She slowly removes her wristband and turns to me.
[cpg]

[free time=800]
;**【ＣＧ】ev_97_c ***********************
[CG id=24 index=3 time=1000]
;*****************************************

[STOPBGM]
"She took off her wristband and said to me, "Hey, cut it off. ......
[cpg cn=true]

[OnName num="shinzi"]
"!
[cpg cn=true]


[BGM f="danger"]

There are numerous red scars ...... running down her left wrist.
[cpg]

"I promise I won't do it again now that Mizushima you've become my friend."
[cpg cn=true]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

Oh ......
[cpg]

I wonder if I've already got the constitution to attract this kind of girl .......
[cpg]

Amane ......
[cpg]

After getting involved with you, my life has been nothing but ...... rain.
[cpg]


[BG f="black.ui" time=2000]
[WAIT time=2000]
[system end4=true]
[SCENE id=29]

;//[jump target="*jump_ending"]
[jump storage="epend.ks" target="*start"]
;#############################################################

;#############################################################

;//END『　rainy　again　』

;**【ＥＮＤ】　rainy_againルート　*************************

;**********************************************************
;//エンドロール
;//---------------------------------------------------------------------------------------
;//---------------------------------------------------------------------------------------

