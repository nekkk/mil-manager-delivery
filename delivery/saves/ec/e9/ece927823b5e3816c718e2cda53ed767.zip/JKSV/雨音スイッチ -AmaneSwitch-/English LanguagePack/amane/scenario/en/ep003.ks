*start

;#################################################
*Ep003|Amane and rain
;#################################################
[SCENE id=3]

;//エフェクト
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye1"]
[BG f="b_ex_ff_t1_1.ui" time=1000]
;//【ＢＧ】ファストフード店　夕方　雨





[OnName num="shinzi"]
"'Would you like to be served inside?'
[cpg cn=true]

I'm not sure what to make of it, but I'm sure it'll help.
[cpg]

As a general rule, Shuei Academy prohibits part-time work, but the system only permits students with family ...... circumstances, such as mothers and children, to do so.
[cpg]

In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

[OnName num="shinzi"]
"Would you like some fries with your meal?
[cpg cn=true]

[OnName num="customer"]
"Hmm, I think I'll have some.
[cpg cn=true]

[OnName num="store_manager"]
"Mizushima, you can go now.
[cpg cn=true]

[OnName num="shinzi"]
"Yes, thank you.
[cpg cn=true]

[OnName num="store_manager"]
"Next month's shift is ready, so take it.
[cpg cn=true]

[OnName num="shinzi"]
"Okay.
[cpg cn=true]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト


[SE f="se064"]
;//【ＳＥ】クシャッ


As told by the manager, I put the paper with my shift written on it into my student bag and quickly leave the store.
[cpg]

It's my style to go home as soon as the work is done, because staying longer is not reflected in the hourly wage.
[cpg]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="rain"]
[BG f="b_ex_tw_t2_2.ui" time=1000]
;//【ＢＧ】街　夜　大雨

;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//loop
[SE f="se004" loop=true]
;//【ＳＥ】わりと激しい雨の音（ザーーーーッ）


[OnName num="shinzi"]
"Wow, it's really raining. ......"
[cpg cn=true]

As I left the store, I chuckled at the rain, which was worse than when I left school, and put up my umbrella.
[cpg]

[SE f="se015"]
;//【ＳＥ】ワンタッチ傘が広がる（バッ！）


[OnName num="shinzi"]
"I'm going to stop by a convenience store. ......
[cpg cn=true]

It's a great way to get to know the people in your area.
[cpg]

It's a great way to get to know the people in your area.
[cpg]

[SE f="se131"]
;//【ＳＥ】雨の中を歩く





[OnName num="shinzi"]
"Ugh, my shoes are ......"
[cpg cn=true]

The rainwater that relentlessly seeped into my leather shoes was cold.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye2"]
[BG f="b_ex_sz_t3_2.ui" time=1000]
;//【ＢＧ】通学路　夜　大雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]


;//【雨、大雨】


[SE f="se070"]
;//【ＳＥ】踏切（カンカンカン……）


[OnName num="shinzi"]
"A railroad crossing. ......"
[cpg cn=true]

It was when I was about to enter the convenience store.
[cpg]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

Then ......
[cpg]

[FG f="amane_p2_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0260"]
[OnName num="amane"]
"........................"
[cpg cn=true]

[OnName num="shinzi"]
"............!"
[cpg cn=true]

In front of the slowly descending circuit breaker, there is a familiar figure.
[cpg]

It was Amane , standing there in the rain without an umbrella.
[cpg]

While all of the people who are waiting for the train to pass through are naturally holding umbrellas, only she is struck straight by the rain with only her bag in her hand.
[cpg]

However, none of these people will offer Amane an umbrella, and they act as if she is not there.
[cpg]

Is the Amane now only in my eyes ......?
[cpg]




[SE f="se030"]
[SE f="se070"]
;//【ＳＥ】踏切＆電車（特急）通過
[BGM f="h2"]




[OnName num="shinzi"]
"...... Ha!"
[cpg cn=true]

In the roar of the express train running away, the time that had stopped began to move.
[cpg]

A moment ......
[cpg]

[FG f="amane_p1_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0261"]
[OnName num="amane"]
"........................"
[cpg cn=true]




[free time=800]
;**【ＣＧ】ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;*****************************************




[OnName num="shinzi"]
"A lot more than that.
[cpg cn=true]

Amane This is a great way to make sure you are getting the most out of your vacation.
[cpg]

The gesture is as slow as a slow-motion movie, but surprisingly smooth. ......
[cpg]

[OnName num="shinzi"]
" Amane ......?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0262"]
[OnName num="amane"]
"........................?"
[cpg cn=true]

I called her name without thinking, but her eyes did not catch me.
[cpg]

On the contrary, the doll-like, lightless gaze seems to reflect no other person or landscape.
[cpg]

Even though the distance between us is open, we are staring at each other head-on, yet we can't see each other.
[cpg]

Is there such a strange thing?
[cpg]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="rain"]
[BG f="b_ex_sz_t3_2.ui" time=1000]
;//【ＢＧ】通学路　夜　大雨

;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


[SE f="se053"]
;//【ＳＥ】歩いて行く人々


Before I knew it, the train had passed and the crossing had gone up.
[cpg]

The people who were waiting for it stepped over the tracks quickly and hurried to the other side.
[cpg]

I'm sure you'll find a lot of people who'd like to go back to their homes.
[cpg]

[FG f="amane_p2_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0263"]
[OnName num="amane"]
"........................"
[cpg cn=true]

However, Amane only ...... and Amane turn around and walk slowly forward at the same speed as when they turned to look at us.
[cpg]

[SE f="se131"]
;//【ＳＥ】雨の中をゆっくり歩く





It is not at all mindful of getting wet in the relentlessly pouring rain, and the appearance of it is as if it is not of this world .......
[cpg]

No one can see her .......
[cpg]

If I take my eyes off her, she'll disappear, transparent.
[cpg]

That's what I thought.
[cpg]

[OnName num="shinzi"]
"Oh, I have to ...... chase her."
[cpg cn=true]

I was looking away from the back of Amane in a daze, but I suddenly got scared and went after her.
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト


[SE f="se132"]
;//【ＳＥ】雨の中、走り出す


This is a great way to make sure you are getting the most out of your vacation.
[cpg]

It's a great way to make sure you don't get caught in the middle of the night.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]




;//loop
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_ex_tw_t2_2.ui" time=1000]
;//【ＢＧ】街　夜　大雨

;//loop
[SE f="se006" loop=true]
;//【ＳＥ】雨の音

;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]





[OnName num="shinzi"]
" Amane ......, where are you?　Where did you ...... go?"
[cpg cn=true]

Confused by the colorful umbrellas that blocked my view, I had lost sight of Amane .
[cpg]

Then ......
[cpg]

[OnName num="female"]
"What ...... is that girl?
[cpg cn=true]

[OnName num="male"]
"You're soaking wet,......."
[cpg cn=true]

It's a good idea to take a look at the website and see if you can find anything you like.
[cpg]

It's a good idea to have a good idea of what's going on in your life.
[cpg]

;//ＣＧ・０２


;//小声で歌っている


[free time=800]
;**【ＣＧ】ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;*****************************************


[WAIT time=100]
[VOICE f="Amane0264"]
[OnName num="amane"]
"I'm not sure what to make of it, but I think it's a good idea.
[cpg cn=true]

[OnName num="shinzi"]
".........!"
[cpg cn=true]

I saw the figure of Amane who was soaking wet and muttering something with a wry smile on his face.
[cpg]

People with umbrellas are avoiding Amane as they slowly walk forward.
[cpg]

Inevitably, the space between her and me was cleared of people, and my eyes caught Amane straight on.
[cpg]


[WAIT time=100]
[VOICE f="Amane0265"]
[OnName num="amane"]
"Pitch pitch ...... chap... chap ...... run... run... run... ..."
[cpg cn=true]

He was singing.
[cpg]

The Amane was humming the nursery rhyme in a tiny little voice.
[cpg]

It's a good idea to have a good idea of what's going on in your life.
[cpg]

[OnName num="shinzi"]
"Ah...rain...sound......"
[cpg cn=true]

[free time=800]
;**【ＣＧ】ev_02_a ***********************
[CG id=1 index=1 time=1000]
;*****************************************


[WAIT time=100]
[VOICE f="Amane0266"]
[OnName num="amane"]
"............ huff, huff."
[cpg cn=true]

As if you can see every single drop of rain falling in front of you, Amane is giggling and laughing happily.
[cpg]

This is a great way to make sure you are getting the most out of your time with your family and friends.
[cpg]

The cold rain is running down my body, running down my white legs and soaking into my socks.
[cpg]

In spite of such a state of affairs, I was dumbfounded as if even my soul had been taken out by that Amane .
[cpg]

Because I thought she was beautiful from the bottom of my heart, soaking wet .......
[cpg]

It's a great way to make sure you don't lose your mind.
[cpg]

It's not just a "wet girl in the rain" that's out there.
[cpg]

What exists in my eyes now is a rain fairy.
[cpg]

A beautiful creature that is not of this world.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]



;#############################################################


;#############################################################




[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="insecurity"]
[BG f="b_ex_tw_t2_2.ui" time=1000]
;//【ＢＧ】街　夜　大雨




;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]


;//【雨、大雨】

;//loop
[SE f="se004" loop=true]
;//【ＳＥ】わりと激しい雨の音（ザーーーッ）





[FG f="amane_p6_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0267"]
[OnName num="amane"]
" Shinji ......-kun?
[cpg cn=true]

[OnName num="shinzi"]
" Amane ...!
[cpg cn=true]

It was Amane that set time in motion.
[cpg]

[OnName num="shinzi"]
"What are you doing here?
[cpg cn=true]

Amane In the event you're not sure what you're looking for, there are a number of things you can do.
[cpg]

[FG f="amane_p7_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0268"]
[OnName num="amane"]
"Hey ......... Shinji ......."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0269"]
[OnName num="amane"]
"Do you like rain .........?"
[cpg cn=true]

I'm not sure if it's a good idea, but it's a good idea.
[cpg]
[FG f="amane_p9_02_a.ui" method="change_1" pos="2/3" time=800]
And then... she slowly fell into my arms, soaking wet and with a wry smile on her face.
[cpg]

[OnName num="shinzi"]
"' Amane , are you alright! I'm not sure what to do.　Why did you take the umbrella...?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0270"]
[OnName num="amane"]
"I'm fine. It's okay, my house is just... right... there."
[cpg cn=true]

The Amane says it's okay, but it doesn't look okay at all.
[cpg]

You can find a lot of people who are looking for the best way to get the most out of their life.
[cpg]

[OnName num="shinzi"]
"It's not okay!　Where is the house?
[cpg cn=true]

Amane It's a good idea to have a good idea of what you're looking for, but it's not always possible.
[cpg]

[FACE method="change_7" pos="2/3"]
;//[FG f="amane_p6_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0271"]
[OnName num="amane"]
"Bag ......."
[cpg cn=true]

[OnName num="shinzi"]
"'Forget it!　I'll take it to my room!"
[cpg cn=true]

What the hell am I mad about?
[cpg]

What am I mad about? At Amane for getting wet in the rain without thinking twice?
[cpg]

Or is it ...... at myself for admiring her like that?
[cpg]

;//エフェクト


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//loop
[stopse g=2]
[stopse g=6]

[free time=800]
[BG f="black.ui" time=800]

[WAIT time=1000]

[SE f="se014"]
;//【ＳＥ】マンションの鉄扉開く

[WAIT time=1000]

[SE f="se033"]
;//【ＳＥ】電気つける（蛍光灯）


[BGM f="eye2"]
[BG f="b_a_mr_t4_4.ui" time=800]
;//【ＢＧ】雨音のマンション　雨音の部屋　夜　大雨

[WAIT time=1000]

[OnName num="shinzi"]
"Wa ......"
[cpg cn=true]

You can find a lot of people who are looking for a great deal more than just a great deal more.
[cpg]

In the event you're not sure what you're looking for, there are a few things you can do.
[cpg]

[BG f="b_a_mr_t4_4_desk.ui" time=1000]

[WAIT time=1000]

[BG f="b_a_mr_t4_4_wall.ui" time=1000]

;//部屋の中スクロール


The cold concrete walls were all gray, and there was no brightly colored furniture, so the word "bleak" seemed to fit.
[cpg]

The only thing that caught my eye in the midst of all this was something that would be impossible in a man's room.
[cpg]

[BG f="b_a_mr_t4_4_up.ui" time=1000]

[OnName num="shinzi"]
"You have a lot of ......
[cpg cn=true]

It is several dolls lined up in a horizontal row on a wooden shelf.
[cpg]

It is not the stuffed animal of fluffy hair, but the French dolls clad in beautiful dresses.
[cpg]

In the event that you've got a lot of money, you'll be able to use it for a lot of things.
[cpg]

[FG f="amane_p5_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0272"]
[OnName num="amane"]
"I'm not sure what to do.
[cpg cn=true]




[free time=800]
;**【ＣＧ】ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;*****************************************




[SE f="se059"]
;//【ＳＥ】ドサッ


[OnName num="shinzi"]
" Amane ?"
[cpg cn=true]

Amane In the event that you're not sure what to do, you'll be able to find out what to do.
[cpg]

This is a great way to make sure you are getting the most out of your time and money.
[cpg]

But now is not the time for such impressions.
[cpg]

[OnName num="shinzi"]
"That's a hell of a fever,......."
[cpg cn=true]

The hand that was placed on the Amane forehead, immediately after feeling the coldness of the raindrops on the skin, realized the obvious abnormal body temperature.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to do.　No, before that, a towel!　 Amane , the towel!"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0273"]
[OnName num="amane"]
"...ugh ...... ugh ......."
[cpg cn=true]

No matter what words I uttered in my panic, they didn't seem to reach Amane now.
[cpg]

It's probably because of the fever that he's in a daze.
[cpg]

[OnName num="shinzi"]
"It's an emergency, so forgive me!"
[cpg cn=true]

[SE f="se077"]
;//【ＳＥ】ガタゴト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_a_mr_t4_4.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夜　大雨


I apologize to her, and then open the doors of the few furniture drawers and built-in storage shelves.
[cpg]

[OnName num="shinzi"]
"There it is: ......
[cpg cn=true]

I barely found a bath towel and a pair of pajamas.
[cpg]

I ran over to the bed with it in my hand and wiped Amane his wet face and hair first.
[cpg]

[OnName num="shinzi"]
"Do you ...... have a hair dryer?"
[cpg cn=true]

The Amane long hair became colder and colder, not knowing how to dry, no matter how much moisture was wiped off.
[cpg]

In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]


[WAIT time=100]
[VOICE f="Amane0274"]
[OnName num="amane"]
"Ooooh ......"
[cpg cn=true]

In the meantime, the body of the feverish Amane began to shake and shake.
[cpg]

[OnName num="shinzi"]
"This is not good .......
[cpg cn=true]

It's a good idea to have a good idea of what you're going to be doing.　It's not that I don't like it, but it's just that I don't like it.
[cpg]

[OnName num="shinzi"]
"Anyway, you have to warm up your body first,.......
[cpg cn=true]

But I know that I have to do something about it.
[cpg]

[free time=800]
;**【ＣＧ】ev_03_a ***********************
[CG id=2 index=1 time=1000]
;*****************************************

Amane In the event that you're not sure what you're looking for, you'll be able to find a lot more information on the web.
[cpg]

[OnName num="shinzi"]
"U~......."
[cpg cn=true]

Amane I'm not sure what to do, but I'm going to do it.
[cpg]

It seems that the rain is making them numb.
[cpg]




It's a good idea to have a good idea of what you're looking for.
[cpg]



[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト




[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="rain"]
[BG f="b_a_mr_t4_4.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夜　大雨





[OnName num="shinzi"]
"'Phew~......'
[cpg cn=true]

From the looks of Amane , she seems to have calmed down a bit, but... what else do I need to do ......?
[cpg]




[OnName num="shinzi"]
"Yes, medicine!"
[cpg cn=true]




[SE f="se043"]
;//【ＳＥ】ガタン！





This is a great way to make sure you are getting the most out of your time with your family.
[cpg]

This is a great way to get the most out of your time and money.
[cpg]

[OnName num="shinzi"]
"But ........."
[cpg cn=true]

If you look at it again, there is not even the bare necessities missing here.
[cpg]

You can find no tableware, cooking utensils, watches, audio equipment, or anything else that you would find in your home.
[cpg]

[OnName num="shinzi"]
"I mean, ......, my family is .......
[cpg cn=true]

The question comes out of my mouth when I see Amane lying on the bed.
[cpg]

Does she really live here?
[cpg]

Is this really her home?
[cpg]

;#############################################################


;#############################################################

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト
[BGM f="healing"]

[SE f="se080"]
;//【ＳＥ】小さな冷蔵庫を開ける


I opened the small, square refrigerator that was under the kitchen sink,......
[cpg]

[OnName num="shinzi"]
"'It's empty ......!'
[cpg cn=true]

There was not even a single yogurt or a bottle of water in it, which was probably provided by the apartment.
[cpg]

It's also a great way to get the most out of your home.
[cpg]

[OnName num="shinzi"]
"It's no good ....... Okay!"
[cpg cn=true]

I made up my mind and grabbed my wallet from my bag and ran for the door.
[cpg]

[SE f="se044"]
;//【ＳＥ】グシュウ…


This is a great way to get the most out of your time and money.
[cpg]

[OnName num="shinzi"]
"I'll get you some food and medicine, just you wait!"
[cpg cn=true]

[SE f="se014"]
;//【ＳＥ】鉄扉を開けて飛び出す


And so I returned to the rain and ran to the convenience store in front of the station.
[cpg]

;//視点切り替えエフェクト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_a_mr_t4_4_up.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夜　大雨


;//【--】ベッドに横たわったまま天井を見詰めている雨音


[FG f="amane_p7_21_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0275"]
[OnName num="amane"]
"........................"
[cpg cn=true]

;//視点切り替えエフェクト


;//エフェクト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye2"]
;//[BG f="b_a_me_t3_0.ui" time=1000]
[BG f="b_ex_sk_t3_1.ui" time=1000]
;//【ＢＧ】雨音のマンション　出入り口　夜　大雨


[SE f="se064"]
;//【ＳＥ】ビニール袋がガサガサ


[OnName num="shinzi"]
"Oh, ......, oops, .......
[cpg cn=true]

It's a good idea to have a good idea of what you're going to be doing.
[cpg]

[OnName num="shinzi"]
"It's an automatic lock,.......
[cpg cn=true]

Of course, I don't have a key.
[cpg]

Moreover, Amane is down in the room. How in the world are we going to open this place?
[cpg]

There is also the option of going home ......
[cpg]

[OnName num="shinzi"]
"I've bought so much stuff .......
[cpg cn=true]

I've got a heavy bag in my hand.
[cpg]

It's all bought for a sick Amane .
[cpg]

[OnName num="shinzi"]
"I'm not sure if it's ......405 or .......
[cpg cn=true]

I pushed the room number and pressed the call button.
[cpg]

[SE f="se026"]
;//【ＳＥ】ピンポ～ン×２


[OnName num="shinzi"]
"There's no way you can answer .......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0276"]
[OnName num="amane"]
"Yes, .......
[cpg cn=true]

[OnName num="shinzi"]
"Did you get it?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0277"]
[OnName num="amane"]
" Shinji ......?"
[cpg cn=true]

[OnName num="shinzi"]
"Oh, yeah, ......."
[cpg cn=true]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト

[WAIT time=1000]

[SE f="se033"]
;//【ＳＥ】ロック解除

[WAIT time=1000]

[SE f="se012"]
;//【ＳＥ】自動ドア開く

[WAIT time=400]

The lock was unlocked by Amane , who had surprisingly regained consciousness, and a heavy automatic door invited me inside.
[cpg]

I'm not sure if she's okay.
[cpg]

;//エフェクト

[free time=800]
[BG f="black.ui" time=800]

[SE f="se014"]
;//【ＳＥ】鉄扉開く


;//[BGM f="eye1"]
[BG f="b_a_mr_t4_4.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夜　大雨

[WAIT time=1000]

[FG f="amane_p5_21_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0278"]
[OnName num="amane"]
"'Welcome back.'
[cpg cn=true]

When I opened the door to room 405, Amane was standing there as if waiting for me.
[cpg]

There was no energy in his voice at all, but he still forced himself to smile when he saw me.
[cpg]

[OnName num="shinzi"]
"Are you okay?　How's your fever?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0279"]
[OnName num="amane"]
"I'm fine ......, about this .......
[cpg cn=true]

[OnName num="shinzi"]
"You have to stay warm!
[cpg cn=true]


[FO pos="2/3" time=800]

I led Amane her into the back room and wrapped her up in a blanket.
[cpg]

[SE f="se064"]
;//【ＳＥ】ガサゴソ


[OnName num="shinzi"]
"I've got some things for you to eat. I've got bananas, yogurt.　There's jelly, too, and a nutritional drink!　And after you eat, take this medicine.
[cpg cn=true]

As the food was taken out of the bag one after another, Amane rolled her eyes in amazement.
[cpg]

[FG f="amane_p5_21_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0280"]
[OnName num="amane"]
"Are these all ...... for me?"
[cpg cn=true]

[OnName num="shinzi"]
"Yes, they are. There's nothing in the fridge!　I mean, ......, do you have any family?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0281"]
[OnName num="amane"]
"I don't have a .......
[cpg cn=true]

[OnName num="shinzi"]
"Oh, you live alone?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0282"]
[OnName num="amane"]
"Yeah. ......
[cpg cn=true]

It was an answer I had expected from somewhere, but hearing it from his own mouth was a shocking fact.
[cpg]

[OnName num="shinzi"]
"How do you always eat?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0283"]
[OnName num="amane"]
"I just go to ......."
[cpg cn=true]

[OnName num="shinzi"]
"Randomly ......."
[cpg cn=true]

It's impossible to cook for yourself ...... properly here, no matter how you think about it.
[cpg]

It's easy to imagine that you've always eaten out or gone to a convenience store.
[cpg]

[OnName num="shinzi"]
"It's not a good idea.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0284"]
[OnName num="amane"]
"...... cussed."
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

Amane This is a great way to make sure you are getting the most out of your time with your family and friends.
[cpg]

;//[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0285"]
[OnName num="amane"]
"I've been scolded by Shinji for some reason.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, I'm sorry ......."
[cpg cn=true]

When you think about it, you are saying no good to Amane today.
[cpg]

However, she ...... felt instantly sorry for me, as if it was unnecessary care.
[cpg]

;//[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0286"]
[OnName num="amane"]
"No, thank you ......."
[cpg cn=true]

And then she bowed her head lightly.
[cpg]

[OnName num="shinzi"]
"It's okay. Now, eat what you can."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0287"]
[OnName num="amane"]
"Yeah, ....... I'll have a yogurt.
[cpg cn=true]

Amane He took the yogurt and scooped half of it onto a small plastic spoon and brought it to his mouth.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0288"]
[OnName num="amane"]
"It's ...... delicious.
[cpg cn=true]

[OnName num="shinzi"]
"Good. Have some hot lemon, too, okay?
[cpg cn=true]

;//[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0289"]
[OnName num="amane"]
"Yes."
[cpg cn=true]

As Amane ate slowly, little by little, I also ate a banana.
[cpg]

[OnName num="shinzi"]
"Did you find a hair dryer or something?　I couldn't find it.
[cpg cn=true]

This is because the hair of Amane was still wet as he moved his mouth, so the topic naturally came up.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0290"]
[OnName num="amane"]
"Oh, no, we don't have ...... one.
[cpg cn=true]

[OnName num="shinzi"]
"I'm not sure what to say.　You have such long hair.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0291"]
[OnName num="amane"]
"I've just moved to ......
[cpg cn=true]

[OnName num="shinzi"]
"Oh, I see. ......
[cpg cn=true]

That's right, Amane has just moved in.
[cpg]

It is only natural that they have just moved in.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="shinzi"]
"But why do you live alone?　Do your parents live far away?"
[cpg cn=true]

When I asked these questions, Amane put a half-eaten yogurt on the side table and said.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0292"]
[OnName num="amane"]
"I ...... don't have parents.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, ......."
[cpg cn=true]

;//[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0293"]
[OnName num="amane"]
"My mom died a long time ago, and my dad disappeared ...... long before that. So I'm all alone.
[cpg cn=true]

[OnName num="shinzi"]
"I'm sorry!
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0294"]
[OnName num="amane"]
"It's okay. You don't have to be sorry.
[cpg cn=true]

[OnName num="shinzi"]
"But ......
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0295"]
[OnName num="amane"]
"It's okay. Don't worry about it.
[cpg cn=true]

It was a casual question, something I didn't need to know.
[cpg]

In the event that you're not sure what to do, you'll be able to find out by yourself.
[cpg]

[OnName num="shinzi"]
"Oh, me too... well, I'm from a single mother family."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0296"]
[OnName num="amane"]
"Oh, ......?"
[cpg cn=true]

[OnName num="shinzi"]
"One mother, one child. My dad died when I was a kid, so I'm kind of like Amane . Oh ......!　Of course, it's a lot harder being Amane !"
[cpg cn=true]

It's also human nature to say unnecessary things in an attempt to console.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0297"]
[OnName num="amane"]
"You can find a lot more information on this at ....... You can also find Shinji and ....... So you live with your mother now?
[cpg cn=true]

[OnName num="shinzi"]
"Yes. But we live in a house, but it's a rundown house!　To be honest, I might be jealous of you living alone in such a nice apartment.
[cpg cn=true]

Wow!　That's ridiculous!　Stop talking!
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0298"]
[OnName num="amane"]
"The only money my parents left me was ....... Also, I was in an institution for a while, and the doctor acted as my guarantor, so I was able to sign a contract."
[cpg cn=true]

[OnName num="shinzi"]
"Is that so?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0299"]
[OnName num="amane"]
"Yeah ......."
[cpg cn=true]

It's not just me who asks what I think I shouldn't ask, but I was irresistibly happy that Amane answered it.
[cpg]

This is a great way to get the most out of your time and money.
[cpg]

[OnName num="shinzi"]
"It's a great way to make sure you don't get caught in the middle of the action.
[cpg cn=true]

;//[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0300"]
[OnName num="amane"]
"Like that?"
[cpg cn=true]

If you really don't understand what I'm saying, Amane nodded his head.
[cpg]

[OnName num="shinzi"]
"It's not even summer yet, no, it's not even summer yet, but you can't ...... get hit by that kind of heavy rain.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0301"]
[OnName num="amane"]
"Oh, .......
[cpg cn=true]

It was a thinly veiled response, as if to say, "What ......?
[cpg]

This is a great way to make sure you are getting the most out of your investment.
[cpg]

[OnName num="shinzi"]
"I'm not sure if it's the same thing, but it's ......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0302"]
[OnName num="amane"]
"You know, Shinji is ......."
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

[FACE method="change_8" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0303"]
[OnName num="amane"]
"You don't like ............ rain?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, ......?
[cpg cn=true]

Although quiet, the Amane question seemed to have a strange power to it.
[cpg]

So I may have naturally given her the answer she wanted.
[cpg]

[OnName num="shinzi"]
"It's not like that.　I don't hate you?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0304"]
[OnName num="amane"]
"Really ......?"
[cpg cn=true]

[OnName num="shinzi"]
"Yeah. It's called the rain of blessing!　I like it because it cleans the air.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0305"]
[OnName num="amane"]
"You like the rain ......?　I see. ...... I'm so happy!
[cpg cn=true]

[OnName num="shinzi"]
"Heh, heh, heh."
[cpg cn=true]

When I saw Amane laughing with real happiness, I was relieved that my answer was correct.
[cpg]

This is a great way to make sure you are getting the most out of your time with your family.
[cpg]

This is the reason why I am so happy.
[cpg]

[OnName num="shinzi"]
"Does Amane like the rain too?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0306"]
[OnName num="amane"]
"Yes!　It's the name your mother gave you because she loved the rain. Amane ."
[cpg cn=true]

[OnName num="shinzi"]
"Oh, I see. I see.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0307"]
[OnName num="amane"]
"My mom said that the first day she met my dad was in the rain. It also rained on their wedding day and the day I was born.
[cpg cn=true]

[OnName num="shinzi"]
"Ha-ha-ha. That's great.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0308"]
[OnName num="amane"]
"Wow.
[cpg cn=true]

In the event that you have any questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

This is a great way to make sure that you don't say anything negative about it .......
[cpg]

When you think about it, suddenly Amane coughs.
[cpg]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0309"]
[OnName num="amane"]
"I'm sure you'll be happy to hear that.
[cpg cn=true]

[OnName num="shinzi"]
"I'm sure you've been sick. Here, medicine ......."
[cpg cn=true]

I regretted letting him talk so much, and I opened the medicine box.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0310"]
[OnName num="amane"]
"Thank you ....... And here ......."
[cpg cn=true]

[OnName num="shinzi"]
"This?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0311"]
[OnName num="amane"]
" Shinji changed your clothes for you, didn't he?"
[cpg cn=true]

[OnName num="shinzi"]
"Aah!　No!　I didn't see anything!　I didn't see anything!
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0312"]
[OnName num="amane"]
What?　What's the matter?　Why are you so upset?
[cpg cn=true]

[OnName num="shinzi"]
"Because ......
[cpg cn=true]

Doesn't Amane feel anything ......?
[cpg]

You may be embarrassed or embarrassed ....... But then, that's good.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0313"]
[OnName num="amane"]
"Thank you so much for being here today. So ......, I have one more favor to ask.
[cpg cn=true]

As the matter of changing clothes was swept under the rug, I jumped to the next topic.
[cpg]

[OnName num="shinzi"]
"What's that?　Tell me anything!
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0314"]
[OnName num="amane"]
"You know, ......, can we exchange addresses ......?　On my phone.
[cpg cn=true]

[OnName num="shinzi"]
"Sure, sure!
[cpg cn=true]

I didn't think Amane 's request would be that simple, so I quickly accepted it and pulled out my phone.
[cpg]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0315"]
[OnName num="amane"]
"Glad ......."
[cpg cn=true]

Then, after exchanging addresses with Amane , I urged her to take her medicine properly and stood up.
[cpg]

[OnName num="shinzi"]
"So, that's it for today. Get a good night's rest, okay?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0316"]
[OnName num="amane"]
"Yeah, okay.
[cpg cn=true]

[OnName num="shinzi"]
"You promise?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0317"]
[OnName num="amane"]
"Yeah, I promise. ......
[cpg cn=true]

If you include a bite to Amane in the tone of voice that you would say to a child on purpose, she will point her little finger at you for finger cutting.
[cpg]

So I left her room with Amane and a finger cutting maneuver.
[cpg]

[OnName num="shinzi"]
"I'll leave you an umbrella!
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0318"]
[OnName num="amane"]
"Yeah, but Shinji will get wet. ......
[cpg cn=true]

[OnName num="shinzi"]
"Don't worry, there's a folded one in my bag!
[cpg cn=true]

;//エフェクト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="rain"]
[BG f="b_ex_sz_t3_2.ui" time=1000]
;//【ＢＧ】通学路　夜　大雨

;// キャラクターの前面に雨を表示;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]




I looked at my watch and it was past eight in the evening.
[cpg]

As I walk down the road to my house, all I can think about is what Amane I just saw.
[cpg]

With no parents, Amane is all alone in that gray room.
[cpg]

Isn't it lonely?
[cpg]

No, how can it not be lonely ......?
[cpg]

This is why they have dolls lined up like that before they buy anything else.
[cpg]

[OnName num="shinzi"]
"I feel sorry for you ......."
[cpg cn=true]

When uttered, pity can easily lead to insults.
[cpg]

I vowed never to let her see that emotion in my heart.
[cpg]

Amane is a good girl.
[cpg]

You can find a lot of things that you can do to make your life easier.
[cpg]

If such a good child can't be happy, then the world is wrong.
[cpg]

I thought to myself.
[cpg]

[OnName num="shinzi"]
"I wish I could help you. ......
[cpg cn=true]

;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//ブラックアウト

;//☆新規シーン

;//お風呂シーン（雪華）雨に濡れ主人公家にて入浴中、同じく主人公も入ろうとして…
[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="h1"]
[BG f="b_si_d_t3_1.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　夜　大雨

[OnName num="shinzi"]
"Ha, I'm all wet."
[cpg cn=true]

The rain was getting stronger and stronger, and even with an umbrella, I was soaking wet.
[cpg]

[OnName num="shinzi"]
"It's a good idea to have a good idea of what you're doing.
[cpg cn=true]

There is no reply to my voice. My mom must have gone shopping or something.
[cpg]

[OnName num="shinzi"]
"It's cold.
[cpg cn=true]

It's a good idea to change your clothes as soon as possible, or you'll catch a cold.
[cpg]

With that in mind, I headed towards the changing room to get a towel.
[cpg]


;//ドアを開ける

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//ブラックアウト

[OnName num="shinzi"]
"Oh, the bath is boiling. Lucky."
[cpg cn=true]

I took off my clothes to warm up my cold body and went into the bathroom.
[cpg]

;//ドアを開ける

;//●ＣＧ（お風呂）

[WAIT time=100]
[VOICE f="Yukika0208"]
[OnName num="yukika"]
"What?"
[cpg cn=true]


[free time=800]
;**【ＣＧ】ev_101_0 ***********************
[CG id=27 index=0 time=1000]
;*****************************************


[OnName num="shinzi"]
"What?"
[cpg cn=true]

For some reason, Yukika sister was in the bathroom.
[cpg]

[WAIT time=100]
[VOICE f="Yukika0209"]
[OnName num="yukika"]
"I'm not sure what to say. Sh, Shinji ... don't look so hard."
[cpg cn=true]

[OnName num="shinzi"]
"I'm sorry!
[cpg cn=true]

I'm not sure why Yukika you're here.
[cpg]

[OnName num="shinzi"]
"What are you doing here?
[cpg cn=true]

[WAIT time=100]
[VOICE f="Yukika0210"]
[OnName num="yukika"]
"I had to run an errand, but it rained on the way, so my aunt made me a bath.
[cpg cn=true]

[OnName num="shinzi"]
"Oh, I see.
[cpg cn=true]

I'm not sure what to make of it, but I'm sure it's a good idea.
[cpg]

Yukika My sister has always taken care of me, but today was not the right time.
[cpg]

[WAIT time=100]
[VOICE f="Yukika0211"]
[OnName num="yukika"]
" Shinji ...... did you see...?"
[cpg cn=true]

[OnName num="shinzi"]
"No!　Not at all!　I couldn't see a thing because of the steam, damn it!
[cpg cn=true]

[WAIT time=100]
[VOICE f="Yukika0212"]
[OnName num="yukika"]
"Well, if that's the case, that's fine.
[cpg cn=true]

After that, my Yukika sister and I had a rather awkward conversation for a while.
[cpg]


[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//ブラックアウト


[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="insecurity"]
[BG f="b_si_d_t3_1.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　夜　雨


[OnName num="shinzi"]
".................."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0012"]
[OnName num="yukika"]
" Shinji ?
[cpg cn=true]

[OnName num="shinzi"]
"What's more...?
[cpg cn=true]

Yukika This is a great way to make sure you are getting the most out of your investment.
[cpg]

[FG f="yukika_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0013"]
[OnName num="yukika"]
"You can find a lot of things that you can do to make your life easier.
[cpg cn=true]

[OnName num="shinzi"]
"No. ......
[cpg cn=true]

Yukika In the event that you have any questions regarding where and how to use the internet, you can call us at our own web site.
[cpg]

This is a great way to make sure you are getting the most out of your money.
[cpg]

[OnName num="shinzi"]
"......"
[cpg cn=true]

What I was thinking about was Amane .
[cpg]

I'm not sure what to do.
[cpg]


The other day, when I was having dinner with my Yukika sister, I said something like that. The words I said reminded me of Amane again.
[cpg]

I bought a lot of food.
[cpg]

She ate it alone, in that room, in solitude.
[cpg]

[OnName num="shinzi"]
"It's not that I'm troubled, but I'm a little ...... worried about a new student.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0014"]
[OnName num="yukika"]
"A new student arrived?　And?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah. ......
[cpg cn=true]

[FG f="yukika_p7_01_a.ui" method="change_1" pos="2/3" time=800]
Yukika You'll be able to get a lot more out of this.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

So nowadays, I've come to understand that it's better to spare myself the trouble of hiding things and just tell the truth from the start.
[cpg]

I'm going to tell you a story about a transfer student who had a bad background Yukika to her sister.
[cpg]

This is a great way to make sure you are getting the most out of your time and money.
[cpg]

[FG f="yukika_p5_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0015"]
[OnName num="yukika"]
"Yes, such a girl ....... I feel sorry for you,......."
[cpg cn=true]

[OnName num="shinzi"]
"Yeah,......."
[cpg cn=true]

It's a great way to make sure you get the most out of your time with your family.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0016"]
[OnName num="yukika"]
"You should be as kind as possible.
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, I will.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0017"]
[OnName num="yukika"]
"And?
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

;//[FACE method="change_2" pos="2/3"]
[FG f="yukika_p7_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0018"]
[OnName num="yukika"]
"Is this new guy cute?
[cpg cn=true]

[OnName num="shinzi"]
"What are you talking about, ......? He's cute. ......
[cpg cn=true]

;//[FACE method="change_2" pos="2/3"]
[FG f="yukika_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0019"]
[OnName num="yukika"]
"Ha-ha-ha. Shinji can't be too far behind.
[cpg cn=true]

[OnName num="shinzi"]
"Stop it!　You're being weird. ......
[cpg cn=true]

I felt my face heating up as my Yukika sister teased me.
[cpg]

I'm not interested in Amane because she's cute.
[cpg]

It's because she looks lonely. ......
[cpg]

I care about ...... her because she looks sad.
[cpg]

So I just want to ...... help her out.
[cpg]

This is my act of kindness,.......
[cpg]

For some reason, I excused myself to my heart, and I carelessly offered my empty teacup to Yukika my sister.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll agree.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0020"]
[OnName num="yukika"]
"I'm sure you've heard of it.
[cpg cn=true]

It's a great way to make sure you get the most out of your time with your family. Yukika
[cpg]

You're more like a mother than a mother!
[cpg]

;//エフェクト

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="eye2"]
[BG f="b_si_r_t4_3.ui" time=1000]
;//【ＢＧ】慎二の家　慎二の部屋　夜　大雨


[SE f="se059"]
;//【ＳＥ】ドサッ


[OnName num="shinzi"]
"There we go."
[cpg cn=true]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

[OnName num="shinzi"]
"I'm not sure what to make of it.
[cpg cn=true]

You can find a lot of things to do today, from getting a part-time job to nursing Amane and shopping.
[cpg]

I don't even feel like playing games tonight anymore.
[cpg]

Just as I closed my eyes to think about going to bed like this,......
[cpg]

[SE f="se031"]
;//【ＳＥ】メッセージ着信


[OnName num="shinzi"]
"N......"
[cpg cn=true]

There was an incoming call on my phone.
[cpg]

[OnName num="shinzi"]
"I don't know who it is,....... Ah."
[cpg cn=true]

It was from Amane , with whom I had just exchanged addresses a few hours ago.
[cpg]




;//以下、スマホの画面


;//雨音は左から、慎二は右から





" Amane " Thank you so much for today. I'm not sure what to do.
[cpg]

You can find a lot more information on the web. I'm not sure what to say, but I'm going to say it.
[cpg]

[OnName num="shinzi"]
"It's so polite of you to contact me.
[cpg cn=true]

I was a little moved by the thank you message from Amane and typed a short reply.
[cpg]

Shinji I'm not sure what to say, but I'm going to say it. I'm sure you'll be happy to hear that.
[cpg]

Good night.
[cpg]


[OnName num="shinzi"]
With "....... Huh~a ...... sleepy."
[cpg cn=true]

I'm not sure what to do, but I'm sure I'll be able to do it.
[cpg]




[SE f="se031"]
;//【ＳＥ】メッセージ着信





" Amane " I'm fine, I'm fine now, okay?
[cpg]

Good night, Shinji .
[cpg]



[jump storage="ep004.ks" target="*start"]
