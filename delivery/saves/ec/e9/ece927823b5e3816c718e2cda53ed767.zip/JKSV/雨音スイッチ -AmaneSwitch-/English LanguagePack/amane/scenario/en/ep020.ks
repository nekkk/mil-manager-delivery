*start



;#################################################
*Ep020|The Last Time
;#################################################
[SCENE id=20]

;//エフェクト

;//loop
[stopse g=2]
[stopse g=6]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_ex_ff_t1_1.ui" time=1000]
;//【ＢＧ】ファストフード店　夕方　雨




The treatment of Amane at the school was terrible.
[cpg]

If you walk down the hallway, you'll be yelled at as a "thief," and in the classroom, aggressive notes are passed around, and there's nowhere for her to go.
[cpg]

What am I supposed to do now? ......
[cpg]

Today, again, I'm upstairs at work.
[cpg]

;//店内に備え付けられた壁掛けTVのニュース映像

[BGM f="h2"]


[OnName num="news_caster"]
"This is a breaking story. A shocking video uploaded to an internet image posting site has led to his arrest.
[cpg cn=true]

In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

[OnName num="shinzi"]
"'...... eh?
[cpg cn=true]




[OnName num="news_caster"]
"'The man arrested is charged with assaulting his two daughters-in-law. In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg cn=true]

[OnName num="shinzi"]
"I'm not sure what to make of it.
[cpg cn=true]

Amane In the event that you have any questions regarding where and how to use the internet, you can call us at the web site.
[cpg]




[OnName num="shinzi"]
"I'm sure you'll agree.
[cpg cn=true]

For a few seconds, the assault video full of mosaic flowed.
[cpg]

I'm sure that's what I shot yesterday.
[cpg]

But why?
[cpg]

Who did it?　And for what purpose?
[cpg]

There's no way anyone else could have had the same goal as me.
[cpg]

[OnName num="store_manager"]
"There are terrible people out there. ......
[cpg cn=true]

This is a great way to make sure you are getting the most out of your time with your family.
[cpg]

Shuei Academy In the event that you've got a lot of money, you'll be able to use it to get the most out of your money.
[cpg]

[OnName num="female_student1"]
"I'm sure you'll agree.　Isn't this our uniform?
[cpg cn=true]

[OnName num="female_student1"]
"It really is!　I wonder who she is!
[cpg cn=true]

[OnName num="male_student1"]
"There's only so many ...... two sisters you can have.
[cpg cn=true]

[OnName num="male_student2"]
"Let's go home and search the Internet!"
[cpg cn=true]

They hurried out of the store with excited faces.
[cpg]

If someone saved it on the internet before it was deleted, it would be ...... out.
[cpg]

My heart was beating like a bell, and I felt like I had been a part of a great crime without even knowing it.
[cpg]

[OnName num="shinzi"]
"Who the hell ...... is on the internet?"
[cpg cn=true]

When I muttered it in my mouth, a possibility came to mind.
[cpg]

[OnName num="shinzi"]
"No way ...... Amane ."
[cpg cn=true]

She acts unpredictably, and before I know it, she's pulled the data from my phone and ......?
[cpg]

[OnName num="shinzi"]
"No ......, that would have been impossible ......."
[cpg cn=true]

There was no chance of that when we met this morning, and no skilled pickpocket could have done that.
[cpg]

[OnName num="shinzi"]
"Call ......."
[cpg cn=true]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_ex_ff_t1_1.ui" time=1000]
;//【ＢＧ】ファストフード店　夕方　雨


[SE f="se079"]
;//【ＳＥ】スマホ操作～コール音～留守番サービスへ転送


I called Amane right away, but he didn't pick up the call.
[cpg]

[OnName num="shinzi"]
"Damn it!
[cpg cn=true]

[SE f="se010"]
;//【ＳＥ】ダッシュ


[OnName num="store_manager"]
"Oh!　Hey!　I'll fire you!　I'm gonna fire you!
[cpg cn=true]

I can't shake my anxiety, I ran out of the store and headed straight for Amane 's apartment.
[cpg]

;#############################################################


;#############################################################





;//エフェクト





Just about that time ......
[cpg]



[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_a_mr_t3_1.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夕方　雨





[FG f="yukika_p5_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="amane_p5_01_a.ui" method="change_1" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Yukika0137"]
[OnName num="yukika"]
"I've taken away your pain.
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Amane0909"]
[OnName num="amane"]
"......?"
[cpg cn=true]

After visiting Amane 's room, Yukika slowly took out his phone and played the abominable video on it.
[cpg]





;//【ＳＥ】木崎姉妹の暴行時の悲鳴





[FACE method="change_5" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0910"]
[OnName num="amane"]
"This is ........."
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0138"]
[OnName num="yukika"]
"These people probably won't have time to care about you anymore. You've been through a lot, haven't you?　It's okay. I've put this movie on the Internet. It's gonna be a big deal."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0911"]
[OnName num="amane"]
Um, ......, I don't understand what you mean by "......."
[cpg cn=true]

It came as a surprise to Amane that Yukika had even come to visit him.
[cpg]

I don't understand how this person knows where I live or why Kizaki Sisters would want to help me.
[cpg]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0139"]
[OnName num="yukika"]
"You don't need Shinji to torment you anymore, do you?"
[cpg cn=true]


[FG f="amane_p6_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Amane0912"]
[OnName num="amane"]
"Yeah, .......
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0140"]
[OnName num="yukika"]
"I can't stand the thought of Shinji having to clean up your mess every time something happens to you. You and I have a history, and I don't approve of your relationship.
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0913"]
[OnName num="amane"]
"'Ah, .......'
[cpg cn=true]

Well, ...... and Amane got the point.
[cpg]

This person has done his research by pretending to be the protector of Shinji , and now he is trying to ingratiate himself by deleting Kizaki Sisters to get him to give in to his demands.
[cpg]

[FG f="amane_p5_01_a.ui" method="change_8" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Amane0914"]
[OnName num="amane"]
"'I won't leave Shinji even if you don't approve.'
[cpg cn=true]

He says crisply.
[cpg]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0141"]
[OnName num="yukika"]
"Don't ......."
[cpg cn=true]

The tone was so strong that Yukika was taken aback.
[cpg]

It's a good idea to take advantage of this, and Amane will continue with the words.
[cpg]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0915"]
[OnName num="amane"]
"In addition, Shinji you do not want to leave me.
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0142"]
[OnName num="yukika"]
"How can you say that?　She's annoyed with you.
[cpg cn=true]



[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Amane0916"]
[OnName num="amane"]
"'Even if he was, he's still crazy about me.
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0143"]
[OnName num="yukika"]
"!"
[cpg cn=true]

A confident reply. It's as if he's convinced that Shinji will never betray him.
[cpg]

Yukika In the event that you're not sure what to do, you'll be able to ask your doctor.
[cpg]

[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0144"]
[OnName num="yukika"]
"Ugh ......."
[cpg cn=true]

I'm not sure what to make of it.
[cpg]

It's a good idea to have a good idea of what you're looking for and how to get there.
[cpg]

Amane Yukika This is a great way to make sure that you get the most out of your time with your family and friends.
[cpg]




[FG f="amane_p6_01_a.ui" method="change_1" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Amane0917"]
[OnName num="amane"]
"You're the one who's dirty for trying to hide your feelings and stay by Shinji 's side."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0145"]
[OnName num="yukika"]
"What?
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_8" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Amane0918"]
[OnName num="amane"]
"You love Shinji , don't you?　Since when?　Since you were a kid?　We're blood-related, and it's disgusting.
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0146"]
[OnName num="yukika"]
"Aah!
[cpg cn=true]




[SE f="se001"]
;//【ＳＥ】ビンタ

[free time=0]
[BG f="white.ui" time=0]
[WAIT time=1000]

[free time=800]


;**【ＣＧ】ev_73_0 ***********************
[CG id=20 index=0 time=1000]
;*****************************************




[WAIT time=100]
[VOICE f="Amane0919"]
[OnName num="amane"]
"Aah!
[cpg cn=true]

Yukika raised his hand in emotion, pushed Amane down, and then put his hand on the thin neck.
[cpg]

It's a good idea to have a good idea of what's going on in your life.
[cpg]

If left unchecked, Amane will tell Shinji everything.
[cpg]

It should never happen.
[cpg]


[WAIT time=100]
[VOICE f="Yukika0147"]
[OnName num="yukika"]
"You plague!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0920"]
[OnName num="amane"]
"Let me go!
[cpg cn=true]


[free time=0]
[BG f="white.ui" time=0]
[SE f="se023"]
;//【ＳＥ】ドンッ！


;//[free time=900]
[WAIT time=500]

[BG f="b_a_mr_t3_1.ui" time=500]
;//【ＢＧ】雨音のマンション　雨音の部屋　夕方　雨
[WAIT time=500]



I did not want to be killed by Yukika .
[cpg]

If I'm going to die, I want to be killed by myself or by Shinji 's hands.
[cpg]

Amane Yukika In the event that you have any questions regarding where and the best way to get in touch with us, you can call us at our website.
[cpg]

[SE f="se007"]
;//【ＳＥ】雨風

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_a_mrb_t1_0.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋のベランダ　夕方　雨

[WAIT time=1000]

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]
;//loop
[SE f="se007" loop=true]

[FG f="yukika_p7_01_a.ui" method="change_3" pos="5/5" time=800]
[FG f="amane_p7_02_a.ui" method="change_7" pos="3/5" time=800]

[WAIT time=100]
[VOICE f="Yukika0148"]
[OnName num="yukika"]
"I won't let you go, ....... You're not good for Shinji ......."
[cpg cn=true]

[FACE method="change_3" pos="3/5"]
[move from="3/5" to="2/5" ease="easeInOutSine" time=1500]

[WAIT time=100]
[VOICE f="Amane0921"]
[OnName num="amane"]
"You're not doing Shinji anything for ....... You're doing it all for ...... yourself."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

[move from="5/5" to="4/5" ease="easeInOutSine" time=1500]

[WAIT time=100]
[VOICE f="Yukika0149"]
[OnName num="yukika"]
"Shut up!"
[cpg cn=true]

Yukika chases down the retreating Amane again with a devilish look.
[cpg]

[move from="4/5" to="3/5" ease="easeInOutSine" time=1500]



[WAIT time=100]
[VOICE f="Yukika0150"]
[OnName num="yukika"]
"You should die for Shinji !
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_4" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0922"]
[OnName num="amane"]
"Unh!"
[cpg cn=true]

Amane Yukika It's a good thing that you're not the only one who has a problem with this.
[cpg]

;//[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Yukika0151"]
[OnName num="yukika"]
"Plague gods ...... plague gods ......."
[cpg cn=true]

;//[FACE method="change_4" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0923"]
[OnName num="amane"]
"Ughhhh ........."
[cpg cn=true]

[SE f="se014"]
;//【ＳＥ】鉄扉開く

[WAIT time=2000]

[OnName num="shinzi"]
" Yukika Sister!　What the hell are you doing!
[cpg cn=true]

;//[FACE method="change_3" pos="3/5"]

[WAIT time=100]
[VOICE f="Yukika0152"]
[OnName num="yukika"]
"Get off me!　You have to do this!　You have to do this!
[cpg cn=true]

As soon as I entered Amane the room, I witnessed a ridiculous situation and I ripped Yukika my sister away from Amane me.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//loop
[stopse g=2]
[stopse g=6]

[free time=900]

[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
[BG f="b_a_mrb_t1_0.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋のベランダ　夕方　雨

;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]

;//loop
[SE f="se007" loop=true]

[FG f="yukika_p5_01_a.ui" method="change_4" pos="4/5" time=1000]
[FG f="amane_p5_02_a.ui" method="change_4" pos="2/5" time=1000]

[WAIT time=1000]



[OnName num="shinzi"]
"'Why!　Why are you doing this to me? !"
[cpg cn=true]

The fact that my Yukika sister was here was a mystery, but I was even more upset by her actions.
[cpg]

I can't believe that a kind Yukika sister could be so violent to another person.
[cpg]

[OnName num="shinzi"]
"'Explain it to me!　Get it all right!　What the hell happened to you?
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0924"]
[OnName num="amane"]
"That person is...well ......
[cpg cn=true]

I yell at him, and Amane says, holding his neck and trying to catch his breath.
[cpg]



;//[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0925"]
[OnName num="amane"]
"He put Kizaki 's movie on the Internet."
[cpg cn=true]

[OnName num="shinzi"]
"What? You?
[cpg cn=true]

The words "movie" and "internet" were enough for me to guess that it was about Kizaki Sisters .
[cpg]

It was Yukika my sister who took out my memory card.
[cpg]

In the event that you've got a lot of money, you'll be able to take advantage of the fact that you'll be able to get a lot more out of it.
[cpg]

[OnName num="shinzi"]
"'How could you!!!
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0153"]
[OnName num="yukika"]
"''Because I thought Shinji was going to ...... blackmail those girls with that video.
[cpg cn=true]

[OnName num="shinzi"]
"!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0154"]
[OnName num="yukika"]
"Blackmail is a crime, okay?　Do you think I'm gonna stand by and watch you get caught by the police?
[cpg cn=true]

[OnName num="shinzi"]
"Just because ......!　Why are you on the Internet?　That's a crime!
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0155"]
[OnName num="yukika"]
"I don't care about .......
[cpg cn=true]

[OnName num="shinzi"]
"What do you mean?
[cpg cn=true]

[FACE method="change_8" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0926"]
[OnName num="amane"]
"Because I love Shinji .
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0156"]
[OnName num="yukika"]
"Stop it!　That's not true, Shinji !　She's crazy!"
[cpg cn=true]

The Yukika sister, who was distraught by Amane 's words, reached out to grab her.
[cpg]

I'm going to hold her down and protect Amane her behind.
[cpg]

Then ......
[cpg]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0927"]
[OnName num="amane"]
"I've heard of it. At the hospital. When Shinji was at the concession stand, this guy was muttering that he loved Shinji ."
[cpg cn=true]

;//[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0157"]
[OnName num="yukika"]
"No! I just love Shinji like he's my brother. ......!"
[cpg cn=true]

[FACE method="change_8" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0928"]
[OnName num="amane"]
"Bullshit. You really think you do. You want Shinji to hold you like I do.
[cpg cn=true]

[OnName num="shinzi"]
"Hey, sis, ......?"
[cpg cn=true]

I looked into Yukika her face as she told me something that I could not believe.
[cpg]

[FACE method="change_3" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0158"]
[OnName num="yukika"]
"It's not!　It's not like that!
[cpg cn=true]


[FG f="amane_p6_02_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0929"]
[OnName num="amane"]
"You've always imagined yourself taking care of Shinji 　"I want to kiss you."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0159"]
[OnName num="yukika"]
"Stop it!　No! No!
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0930"]
[OnName num="amane"]
"Ever since you were a kid, every time you saw Shinji you wanted to do something nasty to him, but you held back, Yukika ..."
[cpg cn=true]

[OnName num="shinzi"]
"Oh, no. ......
[cpg cn=true]


[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0931"]
[OnName num="amane"]
"As I grew older and more masculine, my desire to be held grew..."
[cpg cn=true]

;//[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0160"]
[OnName num="yukika"]
"Uh...oh.........
[cpg cn=true]

In the mind of Yukika , the story fabricated by Amane is visualized.
[cpg]



[OnName num="shinzi"]
"Sis ....... Is it true what Amane said ......?"
[cpg cn=true]

I asked my Yukika sister, who was standing in front of me.
[cpg]

[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0161"]
[OnName num="yukika"]
"I'm not sure what to say.
[cpg cn=true]

You can find a lot of people who have been in the business for a long time.
[cpg]

Yukika This is a great way to make sure you are getting the most out of your money.
[cpg]

Yukika You can find a lot of things that you can do to make your life easier.
[cpg]

But I didn't realize that she had been looking at me that way for so long,.......
[cpg]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0932"]
[OnName num="amane"]
"I'm so sorry Shinji for your loss ....... It feels like you've been betrayed by the Yukika person you trusted, doesn't it?"
[cpg cn=true]

Amane hugs me in a gentle, comforting way.
[cpg]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0933"]
[OnName num="amane"]
"It's weird,....... Are you okay?"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0162"]
[OnName num="yukika"]
"It's a good idea to have a good idea of what you're doing. I'm sure you're not the only one. Shinji is also ...... so?　Do you think I'm ...... creepy too?"
[cpg cn=true]

[OnName num="shinzi"]
"Oh, I'm ......
[cpg cn=true]




;//選択肢３（二択）


;//a,　気持ち悪い　//このまま↓進行
[switch]
[case "Disgusting."]
	[swap]
	[jump target="*choise_21"]
[case "I'm rather glad."]
	[swap]
	[jump target="*choise_22"]
[endswitch]


1, disgusting.
;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]
*choise_21
[jump storage="ep021.ks" target="*start"]

2, I'm rather happy.
;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]
*choise_22
[jump storage="ep025.ks" target="*start"]





