*start

;#################################################
*Ep005|Invitation.
;#################################################
[SCENE id=5]

;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye1"]
[BG f="b_si_d_t2_1.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　夕方　小雨





[OnName num="mother"]
"Well, well, well!　Welcome. Welcome.
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0405"]
[OnName num="amane"]
"Good evening. My name is Amane Satonaka ."
[cpg cn=true]

When I returned home accompanied by Amane , I was greeted with an exaggerated welcome by the two people I had contacted.
[cpg]

[FG f="yukika_p5_01_a.ui" method="change_2" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yukika0021"]
[OnName num="yukika"]
"This is my cousin, Yukika . My cousin, Shinji , has always been a great help to .
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0406"]
[OnName num="amane"]
"Oh, thank you, thank you ......."
[cpg cn=true]

[OnName num="mother"]
" Amane , my child is insensitive, isn't she?　I'm sorry. I've been neglecting him. ......
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0407"]
[OnName num="amane"]
"No, not at all. ......
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0022"]
[OnName num="yukika"]
" Amane , you're gonna eat a lot of food today, okay?
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0408"]
[OnName num="amane"]
"Oh, yes, yes. ......
[cpg cn=true]

[OnName num="mother"]
" Amane , come and sit down.
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0023"]
[OnName num="yukika"]
"Oh, my aunt, this one's ......
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0409"]
[OnName num="amane"]
"Oh, yeah, yeah. ......
[cpg cn=true]

[OnName num="shinzi"]
"Calm down, both of you!　 Amane is in trouble!
[cpg cn=true]

When I quieted down the two of them who were capering around without any sense of age, ......
[cpg]

[OnName num="mother"]
"I'm sure you're not the only one.
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0024"]
[OnName num="yukika"]
"I'm sure you'll agree.
[cpg cn=true]

I'm not sure what to do.
[cpg]

[OnName num="shinzi"]
"I'm sure you'll agree.
[cpg cn=true]

[FACE method="change_2" pos="2/5"]

[WAIT time=100]
[VOICE f="Amane0410"]
[OnName num="amane"]
"Couscous ......
[cpg cn=true]

[FACE method="change_2" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0025"]
[OnName num="yukika"]
"It's just a joke. Don't get upset. Come on, the food is ready. Let's eat.
[cpg cn=true]

[OnName num="mother"]
"But first, ......, Amane , you're all wet, aren't you?
[cpg cn=true]

[FACE method="change_7" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0026"]
[OnName num="yukika"]
" Shinji , why don't you lend her a change of clothes?
[cpg cn=true]

[FG f="amane_p6_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0411"]
[OnName num="amane"]
"Oh, ......, it's okay. I'm sorry."
[cpg cn=true]

The unfamiliar mother and Yukika sister said, concerned about Amane 's condition.
[cpg]

But I know what Amane is, and I shut them out brilliantly.
[cpg]

[OnName num="shinzi"]
Amane "I'm not a fan of umbrellas. It's like the French, right?"
[cpg cn=true]

[OnName num="mother"]
"French?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

[WAIT time=100]
[VOICE f="Yukika0027"]
[OnName num="yukika"]
"Come to think of it, they don't use umbrellas much in England either. ......
[cpg cn=true]

[OnName num="mother"]
"Did you grow up abroad?
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Amane0412"]
[OnName num="amane"]
"Not exactly. ......
[cpg cn=true]

[OnName num="shinzi"]
"Don't pry!　Come on, let's eat!
[cpg cn=true]

Yukika Amane In the event that you're not sure what to do, you'll be able to find out how to do it.
[cpg]

Amane This is a great way to make sure you are getting the most out of your time with your family and friends.
[cpg]



[free time=800]
;**【ＣＧ】ev_07_0 ***********************
[CG id=4 index=0 time=1000]
;*****************************************
[BGM f="healing"]




[WAIT time=100]
[VOICE f="Amane0413"]
[OnName num="amane"]
"This ...... is very good.
[cpg cn=true]

[OnName num="mother"]
"Thank you. Thank you. I'm glad it suits your taste!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0028"]
[OnName num="yukika"]
"I made it myself.
[cpg cn=true]

[OnName num="mother"]
"Don't worry about the details!
[cpg cn=true]

[OnName num="shinzi"]
"Details. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0414"]
[OnName num="amane"]
"Couscous. ......
[cpg cn=true]

Then, Yukika 's sister casually asks Amane .
[cpg]


[WAIT time=100]
[VOICE f="Yukika0029"]
[OnName num="yukika"]
"Where did you go to elementary school, Amane ?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0415"]
[OnName num="amane"]
"Elementary ....... It's called Sugisawa Elementary School . ......
[cpg cn=true]

[OnName num="shinzi"]
"Hmm?　Sugisawa ......?　I heard that ...... somewhere.
[cpg cn=true]

I desperately tried to remember where I had heard the name of the elementary school, but I couldn't recall it at last.
[cpg]

[OnName num="mother"]
"I heard that you lost your parents early?
[cpg cn=true]

[OnName num="shinzi"]
"Wait, Mom!"
[cpg cn=true]

Suddenly, my mother brought up a rude topic, and I tried to interrupt her, but ......
[cpg]

;**【ＣＧ】ev_07_a ***********************
[CG id=4 index=1 time=1000]
;*****************************************


[WAIT time=100]
[VOICE f="Amane0416"]
[OnName num="amane"]
I tried to interrupt her, but she said, " Shinji , it's okay."
[cpg cn=true]

Amane I'm not sure what to make of it, but I'm sure it's a good idea.
[cpg]

[OnName num="mother"]
"It's a good idea to talk to each other so you can get to know each other better. We lost our father in an accident when he was nine years old.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0417"]
[OnName num="amane"]
"Accident. ......"
[cpg cn=true]

[OnName num="mother"]
"What about you?　Are your parents sick?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0418"]
[OnName num="amane"]
"My ...... father evaporated and then my mother had an accident. Car accident. ......
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0030"]
[OnName num="yukika"]
" Amane You had an ...... accident. How old were you?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0419"]
[OnName num="amane"]
"I was ......9 years old.
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0031"]
[OnName num="yukika"]
"Oh, my God. ......!
[cpg cn=true]

[OnName num="mother"]
"Oh, my God, ....... That must have been hard for you. I'm sure it was something that brought you to Shinji and to us.
[cpg cn=true]

[OnName num="mother"]
"I've been away a lot, so she's been lonely, but I'm glad she's gotten to know a girl like you!　You'll have to keep coming back to visit me as often as you like, won't you?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0420"]
[OnName num="amane"]
"Thank you, .........."
[cpg cn=true]

Thanks to my mother's brazenness, I found out that Amane and I had a lot in common.
[cpg]

I wouldn't have asked Amane this even if it had been a year.
[cpg]

Inwardly, I was thrilled to feel destiny in that mysterious sign. ......
[cpg]


[WAIT time=100]
[VOICE f="Yukika0032"]
[OnName num="yukika"]
"........................"
[cpg cn=true]

[OnName num="shinzi"]
" Yukika sister?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0033"]
[OnName num="yukika"]
"What?　Oh, I'm a little fuzzy. ......
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

I'm not sure what to make of this, but I think it's a good idea. Yukika Your sister seemed to be having completely different thoughts than I was at the time.
[cpg]


[WAIT time=100]
[VOICE f="Yukika0034"]
[OnName num="yukika"]
Amane "I'm sure you'll be able to understand why.　I know this is a weird thing to ask, but ......
[cpg cn=true]

;**【ＣＧ】ev_07_b ***********************
[CG id=4 index=2 time=1000]
;*****************************************


[WAIT time=100]
[VOICE f="Amane0421"]
[OnName num="amane"]
"Yes?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0035"]
[OnName num="yukika"]
"We've never met. ......?
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0422"]
[OnName num="amane"]
"Yeah, ......?
[cpg cn=true]

[OnName num="shinzi"]
"Huh?
[cpg cn=true]

My heart was pounding, wondering if there were more coincidences to come, but Yukika she stared at me and tilted her head, Amane
[cpg]


[WAIT time=100]
[VOICE f="Amane0423"]
[OnName num="amane"]
"No,......, I don't think so,.......
[cpg cn=true]

I'm not sure," he said.
[cpg]


[WAIT time=100]
[VOICE f="Yukika0036"]
[OnName num="yukika"]
"Yes,....... That's right!　Yeah, there's no way ......."
[cpg cn=true]

[OnName num="shinzi"]
"Weird sister.
[cpg cn=true]

[OnName num="mother"]
"I think it's time for dessert!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Yukika0037"]
[OnName num="yukika"]
"Yes, I made you some pudding.
[cpg cn=true]

In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

It's already getting late .......
[cpg]

;**【ＣＧ】ev_07_a ***********************
[CG id=4 index=1 time=1000]
;*****************************************


[WAIT time=100]
[VOICE f="Amane0424"]
[OnName num="amane"]
"I ...... should go.
[cpg cn=true]

[OnName num="mother"]
"You should stay the night.
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_si_d_t3_0.ui" time=1000]
;//【ＢＧ】慎二の家　ダイニング　夜　小雨


[FG f="yukika_p5_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yukika0038"]
[OnName num="yukika"]
"Wait, aunt!
[cpg cn=true]

[OnName num="mother"]
"I'd say ......, but it's too early for that, so Shinji !
[cpg cn=true]

[OnName num="shinzi"]
"Yes?
[cpg cn=true]

[OnName num="mother"]
"Take her home.
[cpg cn=true]

[OnName num="shinzi"]
"I know, I know.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Yukika0039"]
[OnName num="yukika"]
"Aunt ......, don't scare her.
[cpg cn=true]

[FO pos="2/3" time=800]
Yukika Like my sister, I was also surprised.
[cpg]

[FG f="amane_p6_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0425"]
[OnName num="amane"]
"I'm not sure what to say, but I'm going to say it. I'm sorry I didn't clean up after you."
[cpg cn=true]

[OnName num="mother"]
"It's okay! Please come back again!　I promise!
[cpg cn=true]

[FG f="amane_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0426"]
[OnName num="amane"]
"Yes!
[cpg cn=true]

[OnName num="shinzi"]
"Okay, let's go.
[cpg cn=true]

If we don't hurry, I don't know what my mother will say again.
[cpg]

I hurried Amane to her apartment, where I bowed my head again and again.
[cpg]

;//;#############################################################


;//;#############################################################




;//エフェクト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="eye2"]
[BG f="b_ex_tw_t2_1.ui" time=1000]
;//【ＢＧ】街　夜　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "normal" } } stretchalign=31]


;//【雨、中くらい】

;//loop
[SE f="se007" loop=true]
;//【ＳＥ】雨（中くらい）



[FG f="amane_p5_01_a.ui" method="change_1" pos="2/3" time=1000]

[WAIT time=900]

[OnName num="shinzi"]
"No, I'm sorry about something, my mom and sister are ......
[cpg cn=true]

I apologized for the rudeness of the two adulterous women along the way, and I waited expectantly for a quick Amane "No, it's not that," or "It's totally fine. I waited expectantly for the words "No, it's not!
[cpg]

I'm sure she'll reply as soon as she can.
[cpg]

But ......
[cpg]

[SE f="se131"]
;//【ＳＥ】雨の中歩く

[free time=3000]
[WAIT time=100]
[VOICE f="Amane0427"]
[OnName num="amane"]
"........................"
[cpg cn=true]

[OnName num="shinzi"]
"......?"
[cpg cn=true]

For some reason, Amane kept silent and walked further and further in front of me.
[cpg]

[OnName num="shinzi"]
" Amane ......?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0428"]
[OnName num="amane"]
"........................"
[cpg cn=true]

It's a good idea to take a look at the actual information on the web.
[cpg]

It's a good idea to take a look at the actual website to see if it's a good fit for you.
[cpg]

[OnName num="shinzi"]
Amane "I'm not sure what to say.　 Amane I'm not sure what to make of this.　Maybe you're offended?"
[cpg cn=true]

Although he was laughing at home, he was really pissed off, wasn't he?
[cpg]

If that's the case, I knew this was going to be tough.
[cpg]

If I got angry, I would have to apologize.
[cpg]

[OnName num="shinzi"]
" Amane !"
[cpg cn=true]




[free time=800]
;**【ＣＧ】ev_08_0 ***********************
[CG id=5 index=0 time=1000]
;*****************************************
;//loop
[SE f="se006" loop=true]

[SE f="se132"]
;//【ＳＥ】雨の中、駆け寄る

[BGM f="insecurity"]





[WAIT time=100]
[VOICE f="Amane0429"]
[OnName num="amane"]
"............ is... ugh."
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

Amane In the event that you have any kind of questions regarding where and how to use the internet, you can contact us at our own web site.
[cpg]

Amane This is a great way to make sure you are getting the most out of your investment.
[cpg]


[WAIT time=100]
[VOICE f="Amane0430"]
[OnName num="amane"]
"This is a great way to get the most out of your time and money.
[cpg cn=true]

[OnName num="shinzi"]
"What?　What's the difference?
[cpg cn=true]

Amane This is a great way to make sure you are getting the most out of your money.
[cpg]

This is a great way to make sure you are getting the most out of your time and money.
[cpg]

[OnName num="shinzi"]
"'Why are you crying?　What made you so sad?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0431"]
[OnName num="amane"]
"'I thought we were the same, ....... I thought you were... the same ...... lonely person as me... and yet... ......"
[cpg cn=true]

[OnName num="shinzi"]
"I thought you were ......?　I'm the same. I lost my parents when I was nine years old. ......
[cpg cn=true]

[free time=800]
;**【ＣＧ】ev_08_a ***********************
[CG id=5 index=1 time=1000]
;*****************************************


[WAIT time=100]
[VOICE f="Amane0432"]
[OnName num="amane"]
"That's not true!
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

I'm not sure if it was a lightning strike or not, but it was sudden and loud.
[cpg]

If you hadn't seen his mouth open, you would never have guessed that it came from Amane .
[cpg]

Then Amane starts to speak as if it were a dam.
[cpg]

[BGM f="rain"]

[WAIT time=100]
[VOICE f="Amane0433"]
[OnName num="amane"]
"No, no, no, not the same!　I've lost everything and you have everything!　I've been lonely and alone all my life, and you have your mother and sister!
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0434"]
[OnName num="amane"]
"Always, always a happy family! Not a warm table!　Liar! Liar!
[cpg cn=true]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]

;//loop
[stopse g=2]
[stopse g=6]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_ex_tw_t2_1.ui" time=1000]
;//【ＢＧ】街　夜　雨



;// キャラクターの前面に雨を表示
;// 通常
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "heavy" } } stretchalign=31]


;//【雨、大雨】
;//loop
[SE f="se006" loop=true]

[SE f="se011"]
;//【ＳＥ】ボスッボスッ！

[FG f="amane_p5_02_a.ui" method="change_3" pos="2/3" time=800]

[OnName num="shinzi"]
"Hey, Amane ?　Calm down!
[cpg cn=true]

Amane In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]


[WAIT time=100]
[VOICE f="Amane0435"]
[OnName num="amane"]
"I'm not sure what to do.　You laughed at me in your warm house when I was lonely!"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0436"]
[OnName num="amane"]
"I believed you, but you lied to me!　You're the one who lied to me too!　 Shinji and I are different... you're happy and you lied to me ...... and I'm different! I'm not like you at all!
[cpg cn=true]

[OnName num="shinzi"]
"Oh, Amane !"
[cpg cn=true]




[SE f="se011"]
;//【ＳＥ】グイッ





I grabbed my shoulders to hold down the buzzing, shaking Amane head.
[cpg]

[FG f="amane_p7_02_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0437"]
[OnName num="amane"]
"I'm not sure what to do.
[cpg cn=true]




[OnName num="shinzi"]
"!"
[cpg cn=true]

[FG f="amane_p6_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0438"]
[OnName num="amane"]
"Aaaaahhhhh!"
[cpg cn=true]

[OnName num="shinzi"]
" Amane ......!"
[cpg cn=true]

Seeing her shouting and waving her arms, I don't know what to do and my thoughts slow down.
[cpg]

I'm not sure what to do with it. But she's desperately appealing to me... and I can vaguely sense the meaning of her emotions...
[cpg]

At the same time, the chest is tightened.
[cpg]

[FG f="amane_p5_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0439"]
[OnName num="amane"]
"Ah...ggg...ugh."
[cpg cn=true]

I'm crying. It's hard to notice in the rain, but I'm crying. Amane You can find a lot of people who are interested in this kind of thing.
[cpg]

[OnName num="shinzi"]
" Amane ......!!!"
[cpg cn=true]

[FG f="amane_p9_02_a.ui" method="change_7" pos="2/3" time=800]

I hug the wet body of Amane tightly.
[cpg]

The heat that is certainly felt underneath the cold touch and the softness of the skin almost intoxicating.
[cpg]




[OnName num="shinzi"]
"It's a good idea to have a good idea of what you're looking for.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0440"]
[OnName num="amane"]
" Shinji ......"
[cpg cn=true]

This is a great way to make sure you are getting the most out of your time with your family.
[cpg]

Amane This is a great way to make sure you are getting the most out of your money. I'm not going to see Amane like this.
[cpg]

In other words, ...... I had fallen in love with Amane before I knew it....
[cpg]

[OnName num="shinzi"]
"I like Amane . So I'm staying with you. I'll always be with you... and I'll protect you."
[cpg cn=true]

Without even trying to get rid of the wet hair stuck to his face, Amane gives me a sensational look from below.
[cpg]

[FG f="amane_p9_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0441"]
[OnName num="amane"]
" Shinji ......
[cpg cn=true]

[OnName num="shinzi"]
" Amane !　I like it!　I like you!
[cpg cn=true]

[FG f="amane_p9_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0442"]
[OnName num="amane"]
"Me too!　I like Shinji , too!"
[cpg cn=true]

The voice is so sweet that it makes you feel faint.
[cpg]

Amane In the event that you have any questions regarding where and the best way to get in touch with us, please do not hesitate to contact us.
[cpg]

Then Amane put his hand on my back.
[cpg]

You will find a lot of things that you can do to make your life easier.
[cpg]


;//前面に雨 停止
[CRE id="IMG.MFG.rain" storage="rain.ui" anime={ { "type" = "playloop", method = "end" } } stretchalign=31]


;//loop
[stopse g=2]
[stopse g=6]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=1000]
;//【ＢＧ】ブラックアウト

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_a_mr_t4_1.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夜　小雨





It's a good idea to keep your eyes on the road and not get caught in the rain.
[cpg]

We moved to our room as soon as Amane we were settled.
[cpg]

[FG f="amane_p8_02_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0443"]
[OnName num="amane"]
" Shinji ......"
[cpg cn=true]

[OnName num="shinzi"]
"What?
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0444"]
[OnName num="amane"]
"You said you liked me, didn't you ......?
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, I did. ......
[cpg cn=true]

[FG f="amane_p8_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0445"]
[OnName num="amane"]
"Have you changed your mind about ......?
[cpg cn=true]

[OnName num="shinzi"]
"No, I didn't change my mind!　I like Amane .
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0446"]
[OnName num="amane"]
"Yeah!
[cpg cn=true]

[FG f="amane_p9_02_a.ui" method="change_2" pos="2/3" time=800]
Gyu......
[cpg]

Amane clings to me.
[cpg]

He's so cute .......
[cpg]

[OnName num="shinzi"]
"I'll take good care of you.
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane0447"]
[OnName num="amane"]
"Yeah!"
[cpg cn=true]

It's a very different Amane girl's face that smiles at you.
[cpg]

This is a great way to make sure you get the most out of your vacation.
[cpg]

;//loop
[stopse g=2]
[stopse g=6]


[jump storage="ep006.ks" target="*start"]
