*start



;#################################################
*Ep023|I was thinking for you.
;#################################################
[SCENE id=24]
[BGM f="danger"]
[BG f="b_a_mr_t3_1.ui"]

[FG f="amane_p7_02_a.ui" method="change_3" pos="2/3" time=0]


[OnName num="shinzi"]
"No, no, no, no, no!
[cpg cn=true]

[STOPBGM]

[SE f="se001"]
;//【ＳＥ】ビンタ
[free time=0]
[BG f="white.ui"]
[WAIT time=1]
[BG f="b_a_mr_t3_1.ui" time=500]

[FG f="amane_p7_02_a.ui" method="change_5" pos="2/3" time=500]
[WAIT time=100]
[VOICE f="Amane0975"]
[OnName num="amane"]
"......!!!"
[cpg cn=true]

[free time=1000]

I slapped Amane her cheek with all my strength, and she collapsed on the spot with so much exhaustion.
[cpg]

[BGM f="rain"]

[OnName num="shinzi"]
"I don't ...... like this anymore,....... I can't do it,......."
[cpg cn=true]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

The more blood you bleed, the more your energy seems to wane.
[cpg]

[FG f="amane_p7_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0976"]
[OnName num="amane"]
"'' Shinji ... ku... hm.''
[cpg cn=true]

The shock may have brought him to his senses, but Amane he drops to his knees beside me, stunned.
[cpg]

[FACE method="change_4" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0977"]
[OnName num="amane"]
"I'm sorry...I'm sorry ......, what did I do to you?　What have I done to you?"
[cpg cn=true]

I wonder if Amane will continue to live like this, paddling the waves of sanity and insanity.
[cpg]

In the event that you have any questions concerning where and how to use the internet, you can call us at the web site.
[cpg]

[OnName num="shinzi"]
"I'm tired of .......
[cpg cn=true]

I think that was a sigh from the bottom of my heart.
[cpg]

Amane It's a great way to make sure you're getting the most out of your time with your family.
[cpg]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0978"]
[OnName num="amane"]
"I'm not sure what to do, but I'm sure it's a good idea. It's my fault,......."
[cpg cn=true]

The same words are muttered over and over again, crying Amane .
[cpg]

This is a great way to make sure that you are getting the most out of your money.
[cpg]

[OnName num="shinzi"]
"If you apologize,......, if you know you're wrong,......, why do you do it,......?
[cpg cn=true]

[FG f="amane_p8_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0979"]
[OnName num="amane"]
"I don't know. I don't even know what I'm doing. I don't know what I'm doing and I don't know what to do. ...... I don't know why I'm ...... doing this. I don't know when ...... I started.
[cpg cn=true]

;//フラッシュバック（セピア）

[STOPBGM]

[free time=400]
[BG f="white.ui" time=900]
[WAIT time=900]


;//母の自殺風景　発狂する雨音


"Don't look, little girl!
[cpg]

"Are you okay?　Stay with me!
[cpg]

[WAIT time=100]
[VOICE f="Amane0980"]
[OnName num="amane"]
"Aha!　It's raining, Mother!　It's raining bright red, Mother!　Ha-ha-ha-ha!
[cpg cn=true]

;//母の葬儀　発狂する雨音
[WAIT time=900]

[BG f="b_a_old_t1_0.ui" time=1000]
;//【ＢＧ】過去の雨音の家　リビング


"Poor thing. ......
[cpg]

"Poor thing. ......
[cpg]

[WAIT time=100]
[VOICE f="Amane0981"]
[OnName num="amane"]
"Mom, it's raining, okay?　Come and get me. Hey, hey!　Ha-ha-ha-ha-ha!
[cpg cn=true]

[OnName num="father"]
"Oh, Amane ...... you.
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0982"]
[OnName num="amane"]
"Oh, Dad!　Look at you, you're falling apart.　You look like a doll!　Ha-ha-ha-ha-ha!
[cpg cn=true]

"You can't take her in. ......
[cpg cn=true]

"You have to put her in a proper institution. ......
[cpg cn=true]

[OnName num="father"]
"Oh, no. ......, it's my fault. ......
[cpg cn=true]

[WAIT time=100]
[VOICE f="Amane0983"]
[OnName num="amane"]
"AHAHAHAHAHAHAHAHAHA!
[cpg cn=true]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="rain"]
[BG f="b_h_cr_t1_1.ui" time=1000]
;//【ＢＧ】病院　診察室　午後　曇り

;//[FG f="amane_p5_02_a.ui" method="change_1" pos="2/3" time=800]

[OnName num="doctor"]
"Your illness is not something that can be cured, you know. You just have to try to stay calm, okay?
[cpg cn=true]

;//[FG f="amane_p6_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0984"]
[OnName num="amane"]
"Calm...
[cpg cn=true]

[OnName num="doctor"]
"Don't let it get to you. Okay?
[cpg cn=true]

;//戻る


;//////////////////////////////////////////////////////////////////////////



[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]
[BGM f="sir"]
[BG f="b_a_mr_t3_1.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夕方　雨





[FG f="amane_p7_02_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0985"]
[OnName num="amane"]
"Oh, my God. ...... I can't do that.
[cpg cn=true]

[OnName num="shinzi"]
"......
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0986"]
[OnName num="amane"]
"There's only so much painful stuff you can remember, and you can't not remember it.
[cpg cn=true]

[FG f="amane_p8_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0987"]
[OnName num="amane"]
"I can't fix this I'm gonna be this way for as long as I live ...... and I'm gonna make you suffer.
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0988"]
[OnName num="amane"]
"I'm sick of it. ...... Kill me. Shinji , please!　Please ...... kill me."
[cpg cn=true]

Amane pleaded and pointed the handle of the knife at me.
[cpg]

When I saw it, I no longer had the strength left in my normal mind to refuse.
[cpg]

This is the way to go.
[cpg]

Even if we didn't exchange words, she... would have sensed it. I'm not sure if that's the reason, but it's the reason why I'm asking questions about this world.
[cpg]

[FG f="amane_p8_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0989"]
[OnName num="amane"]
"Hey, Shinji ......."
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0990"]
[OnName num="amane"]
"What is a happy ending?"
[cpg cn=true]

;//[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0991"]
[OnName num="amane"]
"What is happiness...?"
[cpg cn=true]

No one can give you the answer to what happiness is.
[cpg]

[FG f="amane_p8_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0992"]
[OnName num="amane"]
"You can find a lot of people who are looking for the best way to get the best results.
[cpg cn=true]

[OnName num="shinzi"]
"That's not true.
[cpg cn=true]

[FG f="amane_p7_02_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0993"]
[OnName num="amane"]
"What...?
[cpg cn=true]

[OnName num="shinzi"]
"I think. I think that happiness is not just a general thing.
[cpg cn=true]

[OnName num="shinzi"]
"I think there are as many forms of happiness as there are people.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0994"]
[OnName num="amane"]
"There are as many... ......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0995"]
[OnName num="amane"]
"That's very... nice...
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane0996"]
[OnName num="amane"]
"Then... what does our happiness look like...?"
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="shinzi"]
" Amane ...... Good. We'll die together."
[cpg cn=true]

[FG f="amane_p8_02_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Amane0997"]
[OnName num="amane"]
"Together ......?"
[cpg cn=true]

[OnName num="shinzi"]
"Yeah, ...... together.
[cpg cn=true]

[FG f="amane_p9_02_a.ui" method="change_4" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Amane0998"]
[OnName num="amane"]
" Shinji ......"
[cpg cn=true]

We were crying.
[cpg]

We don't raise our voices, we don't wipe our tears, we just cry while staring at each other's faces getting wet from crying.
[cpg]

The road left behind may be generally unhappy. But for us, it is .......
[cpg]

At some point, my hands were rubbing Amane my body, and Amane my hands were also caressing my body.
[cpg]



It's a great way to make sure you're getting the most out of your vacation.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="shinzi"]
"This is the last time. ......
[cpg cn=true]

I'm not sure what to say. It's a great way to keep your body warm and to remember the feeling.
[cpg]

[FACE method="change_2" pos="2/3"]

;//[FG f="amane_p9_02_a.ui" method="change_2" pos="2/3" time=0]
[WAIT time=100]
[VOICE f="Amane0999"]
[OnName num="amane"]
"Yeah ......."
[cpg cn=true]

It's a good idea to have a good idea of what you're looking for.
[cpg]

This is a great way to make sure you are getting the most out of your money.
[cpg]

Amane This is a great way to make sure that you get the most out of your time and money.
[cpg]

The poor girl .......
[cpg]

She was lonely and alone all the time, and sad Amane that even she could not accept herself.
[cpg]

A sense of fulfillment as the touch of a loved one fills my heart.
[cpg]

At the end of the day, we finally got that joy.
[cpg]


[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1000"]
[OnName num="amane"]
" Shinji , are you being me ...... now?"
[cpg cn=true]

It was a strange question, but I knew what it meant.
[cpg]

[OnName num="shinzi"]
"Yeah, you're Amane ......."
[cpg cn=true]

;//[FG f="amane_p9_02_a.ui" method="change_2" pos="2/3" time=0]
[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1001"]
[OnName num="amane"]
"Good ......."
[cpg cn=true]

That wasn't the real Amane until now.
[cpg]

But at this moment, Amane in my arms was the real innocent herself.
[cpg]

[OnName num="shinzi"]
"I've always wanted to hold Amane you in my arms. ......
[cpg cn=true]

This is a great way to make sure you are getting the most out of your money.
[cpg]

;//[FG f="amane_p9_02_a.ui" method="change_2" pos="2/3" time=0]
[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1002"]
[OnName num="amane"]
"I want to do this forever and ever.
[cpg cn=true]

[OnName num="shinzi"]
"So do I. ......
[cpg cn=true]

But everything that has a beginning has an end.
[cpg]

It was a sad reality that could not be changed.
[cpg]

[OnName num="shinzi"]
" Amane ......"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1003"]
[OnName num="amane"]
"What ......
[cpg cn=true]

[OnName num="shinzi"]
"I loved you. ......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[WAIT time=100]
[VOICE f="Amane1004"]
[OnName num="amane"]
"Yeah ....... Yeah!"
[cpg cn=true]

At this time, my feelings were already solidified.
[cpg]

Because I love Amane , I have to do it.
[cpg]

I'm the only one who can free this sad girl.
[cpg]

[OnName num="shinzi"]
"I'm going ......."
[cpg cn=true]

That was the signal for the two of them.
[cpg]




[free time=800]
;**【ＣＧ】ev_28_0 ***********************
[CG id=10 index=0 time=1000]
;*****************************************


[OnName num="shinzi"]
" Amane ......."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane1005"]
[OnName num="amane"]
"I'm not sure what to say.
[cpg cn=true]

I use both hands to strangle Amane 's thin neck.
[cpg]

Gyuuu ......
[cpg]

I'm sorry.



[WAIT time=100]
[VOICE f="Amane1006"]
[OnName num="amane"]
"I'm not sure what to do.
[cpg cn=true]

Amane This is a great way to make sure you are getting the most out of your investment.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

Amane In the event that you have any kind of questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

[OnName num="shinzi"]
"I'm Amane ...... sorry."
[cpg cn=true]


[WAIT time=100]
[VOICE f="Amane1007"]
[OnName num="amane"]
"Sh......n...ji......k...n."
[cpg cn=true]

At the last moment ......
[cpg]

Amane 's lips moved.
[cpg]


[WAIT time=100]
[VOICE f="Amane1008"]
[OnName num="amane"]
The last moment ...... ...... of her lips moved, "Thank you ...... me."
[cpg cn=true]

The face was the cute smile of Amane that I loved the most.
[cpg]

[OnName num="shinzi"]
"Ah! Oh! ...me too, me ...... me too, me too ......."
[cpg cn=true]




[OnName num="shinzi"]
" Amane ......"
[cpg cn=true]


[WAIT time=100]
;//[VOICE f="Amane1009"]
[OnName num="amane"]
"........................"
[cpg cn=true]

Amane doesn't work anymore.
[cpg]

No more talking. No more laughing.
[cpg]

It's all over.
[cpg]

I made it all go away.
[cpg]

[OnName num="shinzi"]
" Amane ...... thank you ........."
[cpg cn=true]

[free time=800]
[BG f="black.ui" time=800]
[WAIT time=1000]

[BG f="b_a_mr_t4_4_s.ui" time=1000]
;//【ＢＧ】雨音のマンション　雨音の部屋　夜　雨


In the blurred vision of tears flowing incessantly, I managed to find the thing I was looking for and gripped it in my right hand.
[cpg]

Amane It's a great way to make sure you're getting the most out of your time with your family and friends.
[cpg]

I'm not sure how long I'll be able to stay with this sad little girl. ......
[cpg]

;//loop
[SE f="se007" loop=true]
;//【ＳＥ】雨風


Before you know it... the window is open...
[cpg]

The rain blew in through it with the wind.
[cpg]

It seems as if it were her mother who had come to Amane meet her.
[cpg]

[OnName num="shinzi"]
"'Nice to meet you, mother. And goodbye ......."
[cpg cn=true]

I bowed lightly to the gentle rain, placed the knife on my wrist and slid it as far as I could.
[cpg]

[BG f="white.ui" time=500]

Swoosh!
[cpg]

;//loop
[stopse g=2]
[stopse g=6]


[SE f="se044"]
;//【ＳＥ】血しぶき


;//[BG f="red.ui" time=1000]
;//[WAIT time=1000]

[transition target={true} rule="amamori2.png" color={0xff0000ff} time=2000]
[WAIT time=2100]
[BG f="red.ui" time=500]
[transition target={false}  color={0xff0000ff} time=500]
[WAIT time=800]


;//画面に赤い物が飛び散り、滴り落ちていく

I can see the color of my life splattering and dripping down the stream.
[cpg]

I can no longer hear the sound of the rain.
[cpg]

I can't even hear my heartbeat.
[cpg]

[OnName num="shinzi"]
" Amane ......."
[cpg cn=true]

I lay myself down beside Amane and close my eyes, rubbing the tip of my nose against her cheek.
[cpg]

I'm not sure if I'm going to be able to do it.
[cpg]

[OnName num="shinzi"]
"Let's go ...... together..."
[cpg cn=true]


*jump001


And so, under the gently pouring rain, me and Amane left for a world of just the two of us.
[cpg]


[STOPBGM]
[BG f="black.ui" time=2000]
[WAIT time=2000]
[system end2=true]
;#############################################################


;#############################################################

;//エンドロール
;//END『涙雨』


;//☆追加エピソードへ分岐
[if exp={ isSystemFlagsEnabled( "end1") }]
[jump target="*afterend2"]
[endif]

[if exp={ isSystemFlagsEnabled( "end4") }]
[jump target="*afterend2"]
[endif]

[if exp={ isSystemFlagsEnabled( "end5") }]
[jump target="*afterend2"]
[endif]

[if exp={ isSystemFlagsEnabled( "end6") }]
[jump target="*afterend2"]
[endif]

[if exp={ isSystemFlagsEnabled( "end7") }]
[jump target="*afterend2"]
[endif]


;//条件を満たしていなければエンドで終わり
;//[jump target="*jump_ending"]
[jump storage="epend.ks" target="*start"]

;//条件達成で追加あり
*afterend2
{
	tf["flag1"] <- true;
}

;//[jump target="*jump_ending"]
[jump storage="epend.ks" target="*start"]

;**【ＥＮＤ】　コンプルート　******************************


;**********************************************************

