*start



*afterend1


;#################################################
*Ep024|Tears and Rain
;#################################################
[SCENE id=25]

;//徐々に開ける視界

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="sir"]
[BG f="b_h_rot_t1_0.ui" time=1000]
;//【ＢＧ】病院　個室天井　午後　曇り


;//以下、語っている人物が誰かは解らない（立ち絵など一切なし）]

[window target=true]



White .......
[cpg]

Heavenly ......?
[cpg]

No. Where are we ......?
[cpg]

[OnName num="doctor"]
"Have you noticed?"
[cpg cn=true]

Who ......?
[cpg]

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]

[BG f="b_h_ro_t1_0.ui" time=1000]
;//【ＢＧ】病院　個室　午後　曇り


A man in white clothes is saying something.
[cpg]

In my dazed consciousness, I thought hard.
[cpg]

But I couldn't figure out why I was here for the life of me.
[cpg]

[OnName num="doctor"]
"I was in danger. It's a miracle that my life was saved.
[cpg cn=true]

Miracle ......?
[cpg]

What do you mean, "saved"?
[cpg]

[OnName num="doctor"]
"Unfortunately, the other one is dead, but you have to be strong to survive, okay?
[cpg cn=true]

The other... person .......
[cpg]

Oh,......, that's right.
[cpg]

I think he had a heart attack .......
[cpg]

[OnName num="doctor"]
"We're going to work hard together to heal you.
[cpg cn=true]

Heal ......?
[cpg]

I hate ...... that.
[cpg]

If you wanted to die, why are you still alive?
[cpg]

Where am I?
[cpg]

I don't want to be in this place.
[cpg]

;//視界、グルグル動くが、壁も天井も真っ白

[free time=400]
[WAIT time=400]
[BG f="black.ui" time=900]
[WAIT time=900]
[BGM f="rain"]
[BG f="white.ui" time=1000]
;//【ＢＧ】ホワイトアウト


[OnName num="doctor"]
"The man in white smiled and walked away.
[cpg cn=true]

The man in white smiled and walked away.
[cpg]

Wait!
[cpg]

There are still some things I want to ask you ......
[cpg]

When you are about to say that, that heavy sound echoed.
[cpg]

[SE f="se014"]
;//【ＳＥ】鉄扉締まり、重厚な鍵がかけられる


A hospital ......?
[cpg]

But why lock the door?
[cpg]

"Oh,.........."
[cpg cn=true]

The next thing I knew, my hands and feet were shackled to the bed.
[cpg]

"Ugh......?"
[cpg cn=true]

And for some reason, something had been chewed into my mouth as well, so I couldn't even speak.
[cpg]

Why?
[cpg]

Why do I have to go through all this to be kept alive?
[cpg]

I was supposed to die and be happy.
[cpg]

The two of us should have been happy together.
[cpg]

At that time, a question ran through my thoughts.
[cpg]

"Two ......... people?"
[cpg cn=true]

The other one is ...... who?
[cpg]

I am ...... who?
[cpg]

"Aha......ahahaha......"
[cpg cn=true]

This is a great way to get the most out of your business.
[cpg]

It's a good idea to have a good idea of what you're doing.
[cpg]

It's a great way to make sure you get the most out of your vacation.
[cpg]

For some reason, tears flowed down my face and I continued to laugh .......
[cpg]

[SE f="se002"]
;//【ＳＥ】窓の外から雨の音


You can hear the sound of rain in your ears.
[cpg]

It is a gentle sound of rain that is neither intense nor annoying.
[cpg]

The rain ...... rain ...... rain .......
[cpg]

Only the rain felt like it knew everything.
[cpg]

[stopse g=2]
[stopse g=6]

;//END『涙雨』
[STOPBGM]
[BG f="black.ui" time=2000]
[WAIT time=2000]
[system end3=true]
[SCENE id=26]

[jump target="*back_title"]
;**【ＥＮＤ】　コンプルート　******************************


;**********************************************************

*back_title
[BG f="black.ui" time=2000]
[WAIT time=2000]

;//何もなければタイトルへ戻る



