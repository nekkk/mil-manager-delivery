*start|Make the Goddess Mine

;#################################################
*Ep004|Make the Goddess Mine
;#################################################

[SCENE id=4]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


The next morning I decided to visit Aika at her home.
[cpg]

I couldn't give them any time to relax or think.
[cpg]

I have to watch over them all the time.
[cpg]

I can't loosen my grip on any of them.
[cpg]

With this in mind, I headed for her house.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（昼）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Aika067"]
[OnName num="aika"]
"......You're here again....I don't know what I expected......"
[cpg cn=true]

[OnName num="satoru"]
"I'm glad you understand. You're happy to see me, aren't you?"
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Aika068"]
[OnName num="aika"]
"If that's what you think, fine. If my husband finds out about this, he will......"
[cpg cn=true]

Even now, her thoughts went to her husband.
[cpg]

It's so frustrating, that concern should be directed at me.
[cpg]

[OnName num="satoru"]
"Give me your phone number, I wouldn't want to run into him unexpectedly."
[cpg cn=true]

[OnName num="satoru"]
"I'm sure I'll have to call you to come over sometime, too."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Aika069"]
[OnName num="aika"]
"I understand......If that's what you want me to do."
[cpg cn=true]

She keeps emphasizing that she was only obeying my orders.
[cpg]

;//========================================
;//●ＣＧエロ（床にうずくまってるようなヒロイン。）ev_11
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の家＿リビング
;//時間　：昼
;//========================================

;//[FADEOUTBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています


;//ブラックアウト

It's not like I was threatening her right now.
[cpg]

But I felt a little fulfilment in seeing how she seemed to care about not offending me.
[cpg]


[VOICE f="Aika107"]
[OnName num="aika"]
"Why are you so obsessed with me......?"
[cpg cn=true]

[OnName num="satoru"]
"Because you're a goddess and I want to you mine."
[cpg cn=true]

I don't think I was eloquent enough to convey how I really felt about her. Oh well.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


The sun starts to set as I walk home.
[cpg]

It was getting late, but I had one more stop to make.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
;//ＢＫ



[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』


I ring the doorbell. After a little while, she opens the door.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kazumi120"]
[OnName num="kazumi"]
"Is that you......Satoru?"
[cpg cn=true]

[OnName num="satoru"]
;//「嫌そうな顔ですね。俺ともうしたくないんですか？」
"You don't seem happy to see me. Do you hate me now?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kazumi121"]
[OnName num="kazumi"]
"......We should talk. Come in."
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="sKazumi010"]
[OnName num="kazumi"]
"I can't do this if you're going to be violent. We should just end this relationship......"
[cpg cn=true]

[OnName num="satoru"]
"End it? But we're just getting started. I know where you live."
[cpg cn=true]

[OnName num="satoru"]
"And if you try to run away, I'll find you."
[cpg cn=true]

[OnName num="satoru"]
"And when I find you, I will beat you harder than your ex-husband. Is that what you want?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kazumi123"]
[OnName num="kazumi"]
"......Why are you saying all this? Is it fun to terrify me?"
[cpg cn=true]

[OnName num="satoru"]
"Not at all. I'm just doing what I need to ensure that you're mine. I just want to keep you to myself."
[cpg cn=true]


;//ＢＫ
;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[SE f="se011"]
;//【ＳＥ】『携帯電話の発信音』


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


That Saturday, I called Ms. Sakura, figuring that she'd have the day off.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[OnName num="satoru"]
"Hey, it's Satoru. Let's meet up."
[cpg cn=true]

;//[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura075"]
[OnName num="sakura"]
"You have to give me more time, I can't leave Akito alone and besides......"
[cpg cn=true]

[OnName num="satoru"]
"Akito's a big boy, I'm sure he'll be fine. Come quickly or I'll have to spread that video around."
[cpg cn=true]

;//[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sakura076"]
[OnName num="sakura"]
"......Fine."
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（昼）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="sSakura004"]
[OnName num="sakura"]
"......What do you want?"
[cpg cn=true]

[OnName num="satoru"]
"I'm glad to see you're being obedient. It's very flattering."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sakura078"]
[OnName num="sakura"]
"What choice do I have? This is...what you want, right?"
[cpg cn=true]

[OnName num="satoru"]
"You know me so well."
[cpg cn=true]


[SE f="se001"]
;//【ＳＥ】『歩く』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I pull her into the bushes, just out of sight.
[cpg]

It would be a problem if someone saw us. At the very least, my blackmail would lose some of its effect.
[cpg]


;//========================================
;//●ＣＧエロ（背後からヒロインを抱きしめる主人公。ヒロインは木に手を突いている。背景が変わっています）ev_14
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：公園の茂み
;//時間　：昼
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

Ms. Sakura was very obedient and did everything I asked her to do.
[cpg]

It was empowering. I wanted more.
[cpg]

[VOICE f="sSakura005"]
[OnName num="sakura"]
"......Please, just stop this......."
[cpg cn=true]


I want to feel closer to her.
[cpg]

That's what I've been thinking all day.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[OnName num="satoru"]
"This was a lot of fun."
[cpg cn=true]

There was no reply. She stares at the ground.
[cpg]

[OnName num="satoru"]
"Come on, say something. I don't like feeling ignored."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sSakura006"]
[OnName num="sakura"]
"......"
[cpg cn=true]


She maintains her sullen silence, but I felt giddy that this older woman was at my beck and call.
[cpg]

I felt fulfilled. Her love was finally aimed towards me.
[cpg]

Or perhaps it's more accurate to say that I'd pushed her until she had no choice.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


So. What should I do next?
[cpg]

Aika, Kazumi, and Ms. Sakura. With a bit of effort, I could make any of them mine.
[cpg]

And each of them has their own unique charm.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


Sunday morning.
[cpg]

I was thinking about who to visit next......
[cpg]


;//■選択肢
[switch]
[case "Aika"]
	[swap]
	[jump target="*select02_1"]
[case "Kazumi"]
	[swap]
	[jump target="*select02_2"]
[case "Ms. Sakura"]
	[swap]
	[jump target="*select02_3"]
[endswitch]



1. Aika
2. Kazumi
3. Ms. Sakura


;//※ルート分岐。選んだヒロインのルートへと進む


*select02_1|Aika, the Origin of my Obsessions
[jump storage="ep005.ks" target="*select02_1"]

*select02_2|Kazumi, the Catalyst
[jump storage="ep008.ks" target="*select02_2"]

*select02_3|Troubling Ms. Sakura
[jump storage="ep011.ks" target="*select02_3"]
