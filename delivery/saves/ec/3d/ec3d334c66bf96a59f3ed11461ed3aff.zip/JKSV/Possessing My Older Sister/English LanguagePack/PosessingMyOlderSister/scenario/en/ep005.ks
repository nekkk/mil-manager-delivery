;//==============================
;//１、愛華

*start|Aika, the Origin of my Obsessions

;#################################################
*Ep005|Aika, the Origin of my Obsessions
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

*select02_1|Aika, the Origin of my Obsessions

[SCENE id=5]

It had to be Aika, she'd started all this.
[cpg]

I bet her husband was home. I wanted to see what he looked like.
[cpg]


[SE f="se011"]
;//【ＳＥ】『携帯電話の発信音』


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


I called her.
[cpg]

[OnName num="satoru"]
"Hello, is your husband around right now?"
[cpg cn=true]


[VOICE f="Aika108"]
[OnName num="aika"]
"He's.........umm.........right now."
[cpg cn=true]

She stammers. That made sense, because if her husband were right there, he'd be wondering who's calling.
[cpg]

And even if he wasn't there, that would still be tough to answer.
[cpg]

If she said he wasn't there, she'd risk me barging into her home.
[cpg]


[VOICE f="Aika109"]
[OnName num="aika"]
"......He's here. But does it matter?"
[cpg cn=true]

[OnName num="satoru"]
"No, it's nothing."
[cpg cn=true]

Through the phone, I hear a man's voice. Aika's husband, probably.
[cpg]

[OnName num="aika_husband"]
"Who is it?"
[cpg cn=true]


[VOICE f="Aika110"]
[OnName num="aika"]
"It's nobody, don't worry about it......I'm hanging up now."
[cpg cn=true]


[SE f="se035"]
;//【ＳＥ】『携帯電話の通話終了音』

[free time=1000]


The line goes dead. Did she forget who was in control already?
[cpg]

......But since her husband was around, it might be interesting to go pay them a visit.
[cpg]

How would Aika approach the situation? Maybe I should give it a try.
[cpg]

When her husband asks me what kind of relationship we have, what will I say?
[cpg]

Hmm. I'd bet she'll be quick to come up with an excuse.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


I made my way to Aika's home.
[cpg]


[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

[WAIT time=2000]

[SE f="se019"]
;//【ＳＥ】『ドア開く』


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Aika111"]
[OnName num="aika"]
"Yes, who is it?......Satoru......!"
[cpg cn=true]

[OnName num="satoru"]
"It's me. Sorry to intrude, I hope that's alright."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aika112"]
[OnName num="aika"]
"Of course it's not! My husband is here......."
[cpg cn=true]

Precisely. That's why I'm here.
[cpg]

I'd already met Ms. Sakura's son. I knew exactly whom her affections were directed at.
[cpg]

But I couldn't say the same for Aika.
[cpg]

[OnName num="satoru"]
"Aren't you going to invite me in? Or have you forgotten who holds the leash already?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Aika113"]
[OnName num="aika"]
"But, but......"
[cpg cn=true]

[OnName num="satoru"]
"Get out of my way."
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿リビング』（昼）******************************************************


[OnName num="satoru"]
"Sorry to bother you."
[cpg cn=true]

[OnName num="aika_husband"]
"......Uh?......Err, who's our guest?"
[cpg cn=true]

Aika desperately tries to make up an explanation.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Aika114"]
[OnName num="aika"]
"This is my cousin. I happened to see him on the street the other day."
[cpg cn=true]

What were the odds?
[cpg]

And why would her cousin be this much younger than her?
[cpg]

[OnName num="aika_husband"]
"I see......"
[cpg cn=true]

He didn't seem particularly friendly, but at least he wasn't intimidating.
[cpg]

If anything, he looked somewhat frail.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Aika115"]
[OnName num="aika"]
"Well......let me go put the kettle on."
[cpg cn=true]

[OnName num="satoru"]
"Oh yes, I'm sure we have a lot to talk about."
[cpg cn=true]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


After that, her husband immediately went to another room.
[cpg]

I don't know if he was trying to be considerate, but he doesn't seem to be good at socializing.
[cpg]

I'm not going to allow such a person to monopolize Aika's love.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（夕方）******************************************************


[OnName num="satoru"]
"I'm sorry to have disturbed you then. I'll come back again."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Aika116"]
[OnName num="aika"]
"......Please don't come when my husband is here. I can't fool him."
[cpg cn=true]

[OnName num="satoru"]
"Sure, I'll think about it."
[cpg cn=true]

In the end, I decided to return that day without doing anything.
[cpg]

Even I could tell it was risky to try anything while her husband was around.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


I invited Aika to my apartment on a weekday.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aika117"]
[OnName num="aika"]
"......So this is your room......."
[cpg cn=true]

She didn't greet me or anything. I guess that makes sense.
[cpg]

[OnName num="satoru"]
;//「ええ。存分にしましょう、愛華さん。色々としたいこともあるんです」
"Yeah, and we won't have to worry about anybody seeing us here. Come on, there's a lot of things I'd like to do."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Aika118"]
[OnName num="aika"]
"......Fine."
[cpg cn=true]

It was easy since I had the pictures to threaten her.
[cpg]

Then again, she might be the type who's never known the urge to resist or rebel.
[cpg]

When I first met her, she was as kind as a goddess. My impression of her hasn't changed much since that day.
[cpg]


;//ＢＫ

;//========================================
;//●ＣＧエロ（背後からヒロインに迫る主人公）ev_15
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_15_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="satoru"]
"Turn around and get down on your hands."
[cpg cn=true]


She listens to anything I say.
[cpg]

I wonder if she realizes that by doing this, she's only giving me more material to blackmail her with.
[cpg]

[VOICE f="sAika002"]
[OnName num="aika"]
"......Like this?"
[cpg cn=true]


[OnName num="satoru"]
"Yes. It's perfect."
[cpg cn=true]


She truly was beautiful. I couldn't sully her with my touch.
[cpg]


;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


It was getting late, I guess that was all I could do today.
[cpg]

[OnName num="satoru"]
"Well then, that's enough for today. If you don't go home soon, your husband will get suspicious."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Aika156"]
[OnName num="aika"]
"......I understand......"
[cpg cn=true]


[SE f="se019"]
;//【ＳＥ】『ドア開く』

[free time=1000]

Aika left without even looking at me.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


What should I do now?
[cpg]

I still want to go to her house.　
[cpg]

I want to make sure I know who I'm snatching her away from.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


The following weekend I head to Aika's home.
[cpg]


[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』


I ring the doorbell. I'd told her in advance that I was coming over, and she confirmed that her husband was going to be there too.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア開く』


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
;//[VOICE f="Aika157"]
[VOICE f="sAika003"]
[OnName num="aika"]
"You actually came, Satoru......"
[cpg cn=true]

[OnName num="satoru"]
"Of course. Can I come in?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aika158"]
[OnName num="aika"]
"......Yes."
[cpg cn=true]

She replied unenthusiastically, but I could tell that my control over her was only getting stronger.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（昼）******************************************************


[OnName num="satoru"]
"Hello again. I'm sorry to bother you."
[cpg cn=true]

[OnName num="aika_husband"]
"Oh......hi."
[cpg cn=true]

Her husband tried to go to the other room again.
[cpg]

But I stopped him before he left.
[cpg]

[OnName num="satoru"]
"Hold on, I'm very interested in what kind of person that Aika married."
[cpg cn=true]

[OnName num="aika_husband"]
"I'm afraid there's not much to say. You can poke and prod, but I doubt you'll learn anything interesting about me."
[cpg cn=true]

He doesn't hide his discomfort around me.
[cpg]

It seems my impression of him was more or less correct.
[cpg]

[OnName num="satoru"]
"I'd like to know what kind of life you're leading with Aika."
[cpg cn=true]

[OnName num="satoru"]
"I just want to make sure that Aika is happy."
[cpg cn=true]

[OnName num="aika_husband"]
"......Very well."
[cpg cn=true]

He returns to the room. Aika seemed very nervous the whole time.
[cpg]

Eventually the three of us ended up talking.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（昼）******************************************************


After a little while, he gradually started to open up and they both became more talkative.
[cpg]

[OnName num="aika_husband"]
"Aika's really too good for me. She's the perfect wife."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Aika159"]
[OnName num="aika"]
"Oh please. Don't say that."
[cpg cn=true]

[OnName num="aika_husband"]
"No, it's true. I can't live without you, Aika."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Aika160"]
[OnName num="aika"]
"I feel the same way......I can't imagine my life without you."
[cpg cn=true]

I noticed that Aika always seemed very polite to her husband.
[cpg]

But it was a little unexpected that they'd flirt so boldly in front of company.
[cpg]

[OnName num="aika_husband"]
"Come to think of it, it's taken us a long time to recover...it's been about four years now, hasn't it?"
[cpg cn=true]

[OnName num="satoru"]
"Four years ago? What are you talking about?"
[cpg cn=true]

[OnName num="aika_husband"]
"......You're Aika's cousin, right? Didn't you hear?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Aika161"]
[OnName num="aika"]
"I......I didn't tell him."
[cpg cn=true]

Aika plays dumb. What were they talking about?
[cpg]

[OnName num="satoru"]
"If it's not too much trouble, could you tell me about it?"
[cpg cn=true]

They went silent for a while. Eventually, her husband starts to speak.
[cpg]

[OnName num="aika_husband"]
"It was a hot, summer day like this......about four years ago. That's when we lost our child in an accident."
[cpg cn=true]

[OnName num="satoru"]
"Oh......I'm sorry, I didn't know."
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『公園』（夕方）******************************************************


That was all we talked about that day.
[cpg]

Aika and her husband were bound together more tightly than I'd thought.  And to think that she'd lost her child in an accident four years ago.
[cpg]

It was quite surprising, but at least I knew why they didn't have a child.
[cpg]

And after such a traumatic event, they might not even want another child.
[cpg]


[SE f="se011"]
;//【ＳＥ】『携帯電話の発信音』


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


Later that day, I called Aika again.
[cpg]


[VOICE f="Aika162"]
[OnName num="aika"]
"What is it......? Didn't you just come here a while ago?"
[cpg cn=true]

[OnName num="satoru"]
"Can you come to the park now?"
[cpg cn=true]


[VOICE f="Aika163"]
[OnName num="aika"]
"What am I going to say to my husband?"
[cpg cn=true]

[OnName num="satoru"]
"Figure it out, I'll see you soon."
[cpg cn=true]

I hang up the phone. Let's see if she shows up.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夕方）******************************************************


After a while, Aika approaches me.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Aika164"]
[OnName num="aika"]
"......What is it? Why did you call me out of the blue."
[cpg cn=true]

[OnName num="satoru"]
"What did you tell your husband to get out of the house?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aika165"]
[OnName num="aika"]
"I said that I got a call from an old friend. I can't stay too long."
[cpg cn=true]

[OnName num="satoru"]
"I see. Well, that's not my problem."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

Saying that, I pulled Aika by the hand.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


We reach my room and I tell Aika what I wanted her to do.
[cpg]


[VOICE f="Aika167"]
[OnName num="aika"]
"You want me to wear this? But......"
[cpg cn=true]

[OnName num="satoru"]
"Just put it on. Or have you forgotten who's holding the leash right now?"
[cpg cn=true]

I had her wear a school uniform.
[cpg]


;//========================================
;//●ＣＧエロ（制服姿のヒロイン。恥じらっている）ev_17
;//人物１：ヒロイン１
;//服装１：制服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="satoru"]
"It looks good on you."
[cpg cn=true]


She looked embarrassed.
[cpg]

Ahhh, she's so cute. I can't help but stare.
[cpg]

;**【ＣＧ】 ev_17_a ***********************
[CG id=10 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="sAika004"]
[OnName num="aika"]
".......Stop staring at me."
[cpg cn=true]


Of course, that only makes me want to see more.
[cpg]


;//移植のためシーンをカットしています
;//ＢＫ


[OnName num="satoru"]
"Aika, don't you want to have children?"
[cpg cn=true]

;**【ＣＧ】 ev_17_0 ***********************
[CG id=10 index=0 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Aika185"]
[OnName num="aika"]
"......At the very least, I can't have a child with you, Satoru."
[cpg cn=true]

[OnName num="satoru"]
"Then what about your husband?"
[cpg cn=true]


[VOICE f="Aika186"]
[OnName num="aika"]
"I can't.......I'm too afraid."
[cpg cn=true]

Rather than not being able to have a baby, she decided not to have a baby. She's long since made up her mind.
[cpg]

The fear of losing another child must be very strong.
[cpg]

;//========================================
;//●ＣＧエロ（主人公がヒロインに覆い被さる）ev_18
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;**【ＣＧ】 ev_18_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


After that, I stayed by her side for a while.
[cpg]

Aika couldn't completely refuse me.
[cpg]

Sure, I was blackmailing her......
[cpg]

But it takes a certain kind of personality to succumb to blackmail like this.
[cpg]


[VOICE f="Aika206"]
[OnName num="aika"]
"Please......don't call me anymore. I can't hide it from my husband any longer."
[cpg cn=true]

[OnName num="satoru"]
"Why should I care about that?"
[cpg cn=true]

Aika goes quiet.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


I don't know what I want to do with Aika.
[cpg]

Do I want to keep the way things are? Don't I want to make her suffer more?
[cpg]

After thinking about it, I came to a conclusion.
[cpg]

[stflag Cha1flg = 0]

[if exp={getFlagValue("Cha1flg") == 1 }]
[jump target="*select03_1"]
[endif]

;//■選択肢
[switch]
[case "I'll stay with her, like this."]
	[swap]
	[jump target="*select03_1"]
[case "I'll kidnap Aika."]
	[swap]
	[jump target="*select03_2"]
[endswitch]


1. I'll stay with her, like this.
2. I'll kidnap Aika.

;//（最初の選択肢で１を選んでいた場合、この選択肢は発生せず１を選んだことになる）

*select03_1|All that remained was a phone number
[jump storage="ep006.ks" target="*select03_1"]

*select03_2|Sharing Solitude
[jump storage="ep007.ks" target="*select03_2"]


