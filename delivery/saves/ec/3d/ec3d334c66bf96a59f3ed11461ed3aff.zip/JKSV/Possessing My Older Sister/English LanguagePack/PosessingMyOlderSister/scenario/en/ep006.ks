
;//==============================
;//１、このまま愛華さんと一緒に居る


;#################################################
*Ep006|All that remained was a phone number
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


*select03_1|All that remained was a phone number

[SCENE id=6]


......This was enough for me.
[cpg]

It's not my goal to make her suffer. That's not why I'm doing this.
[cpg]

I want her to focus only on me, but there are many ways to accomplish that.
[cpg]


;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************

After that, I kept inviting Aika to my house.
[cpg]

Gradually, Aika's expression was getting softer......
[cpg]

I think that she is beginning to understand that I wouldn't do anything to harm her.
[cpg]


;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


The sun was setting, so I decided to let Aika go home.
[cpg]

[OnName num="satoru"]
"Well then. I think I'll go to your place next time."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Aika250"]
[OnName num="aika"]
"......Okay, just let me know ahead of time. I can tell you when my husband isn't around."
[cpg cn=true]

Aika was becoming more cooperative. That was a good sign.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Night falls. Without her, I would wasted my entire summer vacation.
[cpg]

Meeting her was the best thing that had ever happened to me.
[cpg]

I can't go on without her. I hope she feels the same about me.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


The next morning I was on my way to visit Aika.
[cpg]

I'd called her beforehand to confirm that her husband was out of the house.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（昼）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[OnName num="satoru"]
"I didn't expect you to invite me over. That makes me very happy."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sAika005"]
[OnName num="aika"]
"Please don't say that, I'm......embarrassed."
[cpg cn=true]


I tried to keep our relationship as straightforward as possible.
[cpg]

It must have paid off because she was acting much more responsive to my advances.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


All while keeping us a secret from her husband.
[cpg]

I was fine with that. Eventually, she'd fall in love with me.
[cpg]

She was supposed to love only me, but......
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


The situation had changed.
[cpg]

I knew this would happen. It was bound to happen eventually.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[SE f="se013"]
;//【ＳＥ】『携帯電話の振動音』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[SE f="se034"]
;//【ＳＥ】『携帯電話に出る』

[OnName num="satoru"]
"What is it, Aika?"
[cpg cn=true]


[VOICE f="Aika272"]
[OnName num="aika"]
"I want to......um......talk to you about......"
[cpg cn=true]

It takes her a while to get to the point. Could it be.....
[cpg]


[VOICE f="Aika273"]
[OnName num="aika"]
"I'm pregnant."
[cpg cn=true]

So it finally happened. I thought long and hard about our situation.
[cpg]

[OnName num="satoru"]
"Please get an abortion."
[cpg cn=true]

[VOICE f="Aika274"]
[OnName num="aika"]
"I can't......do that. I don't want to lose another child."
[cpg cn=true]

[OnName num="satoru"]
"Then, why don't you have the baby?"
[cpg cn=true]

[VOICE f="sAika006"]
[OnName num="aika"]
"......My husband will find out."
[cpg cn=true]

[OnName num="satoru"]
"What does it matter?"
[cpg cn=true]

[VOICE f="Aika276"]
[OnName num="aika"]
"Because you'll lose your leverage. This only happened because I wanted to keep it secret from my husband."
[cpg cn=true]

......What? Wait, she had a point.
[cpg]

[OnName num="satoru"]
"Are you serious? Don't you love me?"
[cpg cn=true]


[VOICE f="sAika007"]
[OnName num="aika"]
"......I can't do this anymore."
[cpg cn=true]


[VOICE f="Aika278"]
[OnName num="aika"]
"I never wanted any of this in the first place......."
[cpg cn=true]


[VOICE f="Aika279"]
[OnName num="aika"]
"If you show your face around me again, I'll call the police."
[cpg cn=true]

[OnName num="satoru"]
"......Then the reason you called me here today was to say...goodbye?"
[cpg cn=true]


[VOICE f="Aika280"]
[OnName num="aika"]
"......I'm sorry."
[cpg cn=true]


[SE f="se035"]
;//【ＳＥ】『携帯電話の通話終了音』

[free time=1000]



The line goes dead.
[cpg]

No. No. Where did I go wrong? She was supposed to be mine.
[cpg]

I'm having trouble sorting my thoughts. If she were to have the baby, how would she raise it?
[cpg]

She can't raise it with her current husband, could she? It's not his child.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]


I went to her house the very next day.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（昼）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Aika281"]
[OnName num="aika"]
"......I have nothing more to say to you."
[cpg cn=true]

[OnName num="satoru"]
"But I do. Aika, I love you."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sAika008"]
[OnName num="aika"]
"......I don't know how I feel about you......"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="sAika009"]
[OnName num="aika"]
"It's partly my fault, I should have rejected you more clearly."
[cpg cn=true]


......Where did I go wrong?
[cpg]

She'd been so warm and tender. Now all I felt from her was cold rejection.
[cpg]

Perhaps I shouldn't have brought up abortion.
[cpg]

[OnName num="satoru"]
"......I'm not letting you go, Aika!"
[cpg cn=true]


I forced myself on to her, but it seems she'd been prepared. She called the police without any hesitation.
[cpg]

What could I do but run away? I couldn't go near her if the police were involved.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


It felt like the curtains had dropped on my life. Then again, it always felt like that.
[cpg]

I guess this was how things always had to be.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


Time flies. The years pass in the blink of an eye.
[cpg]

It's not surprising. Once I lost Aika, nothing in my life held meaning anymore.
[cpg]

Life just went back to the way it was. Before all this.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（昼）******************************************************


I visit that park again, perhaps out of nostalgia. I've long lost my purpose in life.
[cpg]

Aika had moved some time ago.
[cpg]

All I had to remember her by was her phone number. I wonder if she would answer if I called her.
[cpg]

I'm too afraid to find out. If it wasn't her number anymore, then I'd lose that last connection to her.
[cpg]

I don't think I'll ever dial that number. I sit on the bench, spacing out......
[cpg]

For a moment, I thought I was hallucinating.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Aika301"]
[OnName num="aika"]
"Oh don't run so fast, you'll might fall."
[cpg cn=true]

It was Aika. She had a child with her...it had to be mine.
[cpg]

Was she still married? Or was she raising the child alone?
[cpg]

Perhaps she still had some sliver of affection for me? I could only hope so.
[cpg]

It seems I'd succeeded in stealing her heart.
[cpg]

[OnName num="satoru"]
"......Haha."
[cpg cn=true]

I'm sure our child would grow up to look like me. Aika will always carry my shadow.
[cpg]

I couldn't help but laugh.
[cpg]



;//ＢＫ
;//ＥＮＤ：ヒロイン１ルート１

[SCENE id=13]

[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


