*start|Selfish Love

;#################################################
*Ep002|Selfish Love
;#################################################

[SCENE id=2]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


As expected, I woke up around noon.
[cpg]

It was about time for me to head out and look for her...my goddess.
[cpg]

I have no intention of giving up. I'm going to keep looking and looking, until I find her.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


It's been about a week since I started looking for her.
[cpg]

Honestly I was about to give up.......when I saw a familiar face.
[cpg]

[OnName num="satoru"]
"Oh......."
[cpg cn=true]


;//ここから愛華の立ち絵を表示してください
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

I found her. It's her.
[cpg]

I go after her. I'm going to follow her no matter what it takes.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************



;//このシーンからも愛華の名前を「？？？」と隠してください


[FACE method="change_1" pos="2/3"]
[VOICE f="Aika009"]
[OnName num="unknown"]
"I'm home!"
[cpg cn=true]

I see her approach a house and enter it.
[cpg]

[free time=1000]
There is no doubt in my mind, this is where she lives......
[cpg]

Then, I see a shadow of a man at the front door.
[cpg]

Was that her husband? If so, I need to find out when he's not there.
[cpg]

......So, she's married.
[cpg]

She's giving her affections to someone other than me. I won't stand for it.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


I couldn't make a move yet so I decided to retreat for now.
[cpg]

On my way home, I ran into Kazumi.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kazumi059"]
[OnName num="kazumi"]
"Ah, Satoru.......Good evening."
[cpg cn=true]

[OnName num="satoru"]
"Good evening."
[cpg cn=true]

She is acting kind of nervous. Is it because of what happened the other day?
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kazumi060"]
[OnName num="kazumi"]
"Well.......how about tonight? You know I'm free anytime."
[cpg cn=true]

She sure got straight to the point. I had no reason to say refuse her offer.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************



[SE f="se000"]
;//【ＳＥ】『食器の音』


Kazumi cooks for us again.
[cpg]

But I wasn't as nervous as before. I was calm enough to realize that she was a great cook.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kazumi061"]
[OnName num="kazumi"]
"Oof, I think I ate too much......Do you want to watch TV for a bit?"
[cpg cn=true]

[OnName num="satoru"]
"I don't watch much TV. I think it's ridiculous."
[cpg cn=true]

I say so, but I also don't have a TV.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kazumi062"]
[OnName num="kazumi"]
"Why not? There's plenty of amusing programs on TV these days."
[cpg cn=true]

Kazumi turns on the TV and starts watching some quiz show. She gets excited as the contestants struggle with the questions.
[cpg]

She seemed somehow...younger and girlish. I guess it shows that she doesn't have children or a husband.
[cpg]


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

And as the night goes on......
[cpg]


;//========================================
;//●ＣＧエロ（ベッドの上のヒロイン。拘束されていない）ev_06
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_06_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sKazumi006"]
[OnName num="kazumi"]
"......Don't you want to stay over a little longer?"
[cpg cn=true]


Kazumi asks me.
[cpg]

I wondered what I should say......
[cpg]

[OnName num="satoru"]
"Not tonight."
[cpg cn=true]


That was all I could manage for now.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=1500]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************


[OnName num="satoru"]
"I'm going back home today......."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kazumi083"]
[OnName num="kazumi"]
"Why? I'm sure you won't be in trouble if you stay the night."
[cpg cn=true]

[OnName num="satoru"]
"We're not lovers yet, right?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kazumi084"]
[OnName num="kazumi"]
"......Alright, I understand. Maybe next time."
[cpg cn=true]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I go back to my room.
[cpg]

My daily routine was gradually changing.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



;//愛華の名前を「？？？」と隠してください


In the morning I get up early and head to her house.
[cpg]

My goddess. I don't even know her name.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Aika010"]
[OnName num="unknown"]
"See you tonight, darling."
[cpg cn=true]

I watch as she sees her husband off to work. Would she be alone now?
[cpg]

I didn't see children with her that time. She didn't come out to send a child off to daycare or school either...
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


I stuck around until noon to make sure. There was little chance that her husband would be back during the day.
[cpg]

Her husband was wearing a suit. The average office worker would not be back anytime soon.
[cpg]

And then she came out of the house and began tending to the garden.
[cpg]

I decided to approach her, feigning coincidence.
[cpg]

Of course, I didn't have much of a plan. It's just that I couldn't help but talk to her when I saw her face.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Aika011"]
[OnName num="unknown"]
"Oh......? Aren't you the boy from the other day?"
[cpg cn=true]

[OnName num="satoru"]
"Yes, it's quite a coincidence, isn't it?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Aika012"]
[OnName num="unknown"]
"Do you live around here? It really is such a coincidence......"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Aika013"]
[OnName num="unknown"]
"Then again, I suppose it's not so strange since we first met nearby."
[cpg cn=true]

She seems to have convinced herself. I decided to ask her name.
[cpg]

[OnName num="satoru"]
"I'm sorry, I should probably introduce myself, shouldn't I?"
[cpg cn=true]


;//ここから愛華の名前を隠さないでください


[FACE method="bow_1" pos="2/3"]
[VOICE f="Aika014"]
[OnName num="aika"]
"Oh of course, I'm Aika Ichikawa. And you?"
[cpg cn=true]

[OnName num="satoru"]
"It's Satoru. Satoru Murakami......"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Aika015"]
[OnName num="aika"]
"Oh what a beautiful name. I hope I can give my child such a fitting name someday......"
[cpg cn=true]

It seems that she didn't have children...yet. Then she's alone during the day.
[cpg]

Or perhaps there's extended family living with them? Should I probe a little further?
[cpg]

[OnName num="satoru"]
"If it's not too much of a bother, I'd like to stop by again. I really must thank you for saving me."
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Aika016"]
[OnName num="aika"]
"Oh, it was no trouble, really."
[cpg cn=true]

[OnName num="satoru"]
"Please, I insist. I'll drop by again soon."
[cpg cn=true]

I waved and headed off.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Aika017"]
[OnName num="aika"]
"Oh.....well, alright."
[cpg cn=true]

She waved back. I'd managed to come up with a semblance of a plan while we were chatting.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


It was simple. If I came back under the pretext of bringing her a gift, she'd feel obligated to spend a little more time with me.
[cpg]

She might even invite me in. The chances were good.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


The next day I went to Aika's place again.
[cpg]

[OnName num="satoru"]
"Hi again. I brought you a little token of my appreciation for what you did for me."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Aika018"]
[OnName num="aika"]
"Oh, but I just can't accept it......"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aika019"]
[OnName num="aika"]
"I'm sure anybody else would have done the same. You really don't need to thank me."
[cpg cn=true]

[OnName num="satoru"]
"It's how I feel. It would be wrong of me to leave before you accept it."
[cpg cn=true]

I'm holding a paper gift bag. As for its contents......well, she'll find out soon enough.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Aika020"]
[OnName num="aika"]
".......I understand, why don't you come in."
[cpg cn=true]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（昼）******************************************************


[FACE method="shake_2" pos="2/3"]
[VOICE f="Aika021"]
[OnName num="aika"]
"I'm afraid I can't offer you much in the way of hospitality."
[cpg cn=true]

She pours me a cup of tea and I graciously accept.
[cpg]

[OnName num="satoru"]
"Please open the bag. It's just a token of my gratitude."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Aika022"]
[OnName num="aika"]
"Oh alright......"
[cpg cn=true]

Aika takes my gift to her out of the bag.
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Aika023"]
[OnName num="aika"]
"Oh, what's this......."
[cpg cn=true]

What was inside were handcuffs. Of course, they weren't the real deal.
[cpg]

It was just a toy, but it was fairly sturdy and needed a key to open.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aika024"]
[OnName num="aika"]
"What is this? I mean, what do you want......?"
[cpg cn=true]

[OnName num="satoru"]
"Here's the thing."
[cpg cn=true]

[free time=300]
[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
I then forcefully grabbed both of her hands and handcuffed them.
[cpg]


;//移植のためシーンをカットしています

She seemed to freeze in surprise.
[cpg]

[OnName num="satoru"]
"I've always cared about you, I want you to be mine."
[cpg cn=true]


Confused, she shook her head and backed away.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="sAika001"]
[OnName num="aika"]
"What are you talking about......?!"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
She seemed confused, so I get closer to her and forcefully kiss her.
[cpg]

Then I took a picture of it with my phone.
[cpg]

[OnName num="satoru"]
"I just sent this to my computer. If I don't touch that computer for a few days, it'll send that image all over the web."
[cpg cn=true]

[OnName num="satoru"]
"It probably won't take long before your husband sees it."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Aika044"]
[OnName num="aika"]
"Wha-What? Why? That's impossible..."
[cpg cn=true]

It probably was. I mean, I don't know that much about computers but it didn't look like she did, either.
[cpg]

It's all a bluff, but it will work.
[cpg]

[OnName num="satoru"]
"If you really think so, you're welcome to try resisting me. Come on, just try calling for help."
[cpg cn=true]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Aika045"]
[OnName num="aika"]
"......Why are you doing this?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aika046"]
[OnName num="aika"]
"Are you trying to say that I shouldn't have helped you......?"
[cpg cn=true]

[OnName num="satoru"]
"No, I really appreciated it. It made me very, very happy."
[cpg cn=true]


;//移植のためシーンをカットしています

I figured pictures of us kissing wouldn't amount to much, so I got a little closer to her.
[cpg]

I had to take more...incriminating pictures......
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（夕方）******************************************************

But her resistance proved troublesome and it didn't go very well.
[cpg]

But I think I was able to take a few pictures that she wouldn't spread around.
[cpg]

I noticed that the sun was setting. I'd better leave soon.
[cpg]


[SE f="se000"]
;//【ＳＥ】『手錠外れる　カチャッ』


I unlocked her handcuffs and picked up my phone.
[cpg]

[OnName num="satoru"]
"I'll see you around. If you're thinking of resisting next time...you really should reconsider."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Aika066"]
[OnName num="aika"]
"......"
[cpg cn=true]

Aika didn't say anything. That was fine.
[cpg]

I'll make it so that she has no choice but to love me. Only me.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I felt good. I'd accomplished something today. But this wasn't the end.
[cpg]

Her affections had to be entirely directed at me. I'm a jealous man and I wasn't interested in sharing.
[cpg]

She has a husband. I can't stand it. The thought of them together. It should be me.
[cpg]

I went to sleep feeling frustrated.
[cpg]



[jump storage="ep003.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

