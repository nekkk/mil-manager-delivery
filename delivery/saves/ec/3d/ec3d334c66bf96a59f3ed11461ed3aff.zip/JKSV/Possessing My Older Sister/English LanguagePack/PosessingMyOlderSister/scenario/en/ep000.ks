
*start

;//俺は熟女狂愛主義　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//愛華　　私服
;//一美　　私服
;//桜　　　私服　作業着
;//以下音声なし
;//悟 子供の声 女性の声 男の子 彰人 愛華の夫 警官 桜の仕事仲間 男 忠司


;#################################################
*Ep000|An Older Goddesses
;#################################################

[SCENE id=0]


[stflag Cha1flg = 0]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Somewhere along the line, my sense of time had become blurred.
[cpg]

[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『公園』（朝）******************************************************


I can't remember much about my elementary and middle school years.
[cpg]

It's dark. Maybe I was so depressed that my brain wasn't working.
[cpg]

[OnName num="child_voice"]
"Look what I made! Mom I made this!"
[cpg cn=true]

My parents died in a car accident when I was very young.
[cpg]

It was a gruesome scene. I still remember the view of the bloody interior of the car very well.
[cpg]

The sight is burned into my memory. It's the one thing I'll probably never forget.
[cpg]

The twisted wreckage, the conversations my relatives had at the funeral...my young brain must have made up some memories to fill the void.
[cpg]

[OnName num="female_voice"]
"Wow, it's so pretty. Are you giving it to me?"
[cpg cn=true]

[OnName num="child_voice"]
"Yeah, I made it for you, Mom!"
[cpg cn=true]

Under the summer sun, I can hear the innocent voices of a parents and their child. I find myself wishing they'd get into an accident too.
[cpg]

I sit idly on a park bench, wishing for such a thing.
[cpg]

I wasn't in despair. I just didn't have the motivation for anything.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


Satoru Murakami. I'm a university student now, not that it made any difference whether I go or not.
[cpg]

I was surrounded by idiots, but I guess I was one of them too. It's the result of not having made any effort.
[cpg]

The atmosphere of the university is bright and flirtatious, a stark contrast to the solemn darkness I embraced.
[cpg]

It's nothing new. I've never made an effort in anything. That's why I'm in this situation.
[cpg]

Now I am surrounded by people who don't like to study but don't mind hard work.
[cpg]

It was bright. It seemed too bright to me who had never been touched by human kindness.
[cpg]

Campus life wasn't for me. Summer vacation had begun, but that didn't mean I'd enjoy having free time either.
[cpg]

I didn't join a club and I didn't have the energy to start a part-time job.
[cpg]

Clearly, there was nothing to attract women to me. Naturally, I wasn't interested in love either.
[cpg]

I don't have a family home to go back to over the break and visiting my relatives would be awkward.
[cpg]

At least the money my relatives send me keeps me fed.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


But there wasn't anything to do, so I don't do anything.
[cpg]

I think I remember hearing that staying still and closing your eyes just reminds you of unpleasant things.
[cpg]

So I made it a routine to go to the arcade.
[cpg]

On the way home, after spending money and time for absolutely nothing......
[cpg]

[FADEOUTBGM]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I felt faint. It's not like I'd been out under the sun, but I guess this was what they call a heat stroke.
[cpg]

Some arcade games can be pretty physically demanding, I guess.
[cpg]

At least if I die here, I can finally see my parents.
[cpg]


;//========================================
;//●ＣＧ非エロ（倒れこむ主人公を抱えるヒロイン１。主人公目線で主人公は映り込んでいない）ev_01
;//人物１：ヒロイン１
;//服装１：私服
;//場所　：街
;//時間　：昼
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_sa"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]
;//ここから暫く愛華の名前を？？？と隠してください



[VOICE f="Aika001"]
[OnName num="unknown"]
"Are you all right......? I saw you almost falling over just now."
[cpg cn=true]

[OnName num="satoru"]
"......Umm......"
[cpg cn=true]

Someone grabbed me and kept me from falling.
[cpg]


[VOICE f="Aika002"]
[OnName num="unknown"]
"Oh......you're so pale, it must be heat stroke."
[cpg cn=true]


[VOICE f="Aika003"]
[OnName num="unknown"]
"Let's get you somewhere cooler so you can rest......"
[cpg cn=true]


[VOICE f="Aika004"]
[OnName num="unknown"]
"Can you walk? You can hold on to me......"
[cpg cn=true]

[OnName num="satoru"]
"No, no. I'm fine, I can manage to walk."
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


Then, I was treated very kindly by this person.
[cpg]

I heard something about hydration and electrolytes and was given a sports drink.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aika005"]
[OnName num="unknown"]
"Maybe you should see a doctor......it's not like I know all that much about heat stroke."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Aika006"]
[OnName num="unknown"]
"There's a hospital nearby, so when you're feeling a little better, we can walk there."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Aika007"]
[OnName num="unknown"]
"If you can't walk, I'll have to call an ambulance......"
[cpg cn=true]

I thought I said I was fine. Why get so worked up?
[cpg]



;//ＢＫ
;//[window target=false]
;//[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
;//[BG f="b_02_2.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

But that incident remained in my memory.
[cpg]

The moment she embraced me, I thought I had met a goddess.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Aika008"]
[OnName num="unknown"]
"Well, I'll leave you to it then. I'm sorry for being such a worrywart."
[cpg cn=true]

We parted after she took me to the hospital......
[cpg]

I took a strong interest in her. I regretted that I didn't ask her name.
[cpg]

I would have asked for her address if I could, but I guess that would be a bit much.......
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




I went home alone and went deep into thought.
[cpg]

I'm hated by women my age. I don't have any proof, but I'm pretty sure I'm right about that.
[cpg]

But if it was someone was older...maybe around my late mother's age...
[cpg]

I thought that might be what I needed to ease this feeling of solitude.
[cpg]



;//ＢＫ
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



;//ここから暫く一美の名前を？？？と隠してください


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kazumi001"]
[OnName num="unknown"]
"Ah, Satoru. Were you at the arcade again today?"
[cpg cn=true]

[OnName num="satoru"]
"Why do you care?"
[cpg cn=true]

Kazumi Yamazaki. We live in the same apartment complex.
[cpg]


;//ここから一美の名前を表示してください


[FACE method="bow_2" pos="2/3"]
[VOICE f="Kazumi002"]
[OnName num="kazumi"]
"We really do see each other a lot, don't we? I wonder if our lifestyle is similar."
[cpg cn=true]

She seems to be an office worker and I often see her on her way to work.
[cpg]

If anything, it's so frequent that I wonder if she's waiting for me on purpose.
[cpg]

Normally, I'd leave the house right away......
[cpg]

But yesterday's events weighed heavily on my mind.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kazumi003"]
[OnName num="kazumi"]
"What's up? Do I have something on my face?"
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Kazumi004"]
[OnName num="kazumi"]
"Or maybe you finally noticed my good looks? Ahaha."
[cpg cn=true]

[OnName num="satoru"]
"......"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kazumi005"]
[OnName num="kazumi"]
"......Well don't go quiet all of a sudden, I'll sound unhinged."
[cpg cn=true]

[OnName num="satoru"]
"Sorry......I do think you are a beautiful person."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kazumi006"]
[OnName num="kazumi"]
"Well that's a first. Come closer, I'll let you take a better look."
[cpg cn=true]

[free time=300]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

She brings her face close to mine as she says so. I can almost feel her breath on my face."
[cpg]

[free time=300]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sKazumi001"]
[OnName num="kazumi"]
"Did I already mention that I'm single now?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kazumi008"]
[OnName num="kazumi"]
"I was married once, but......well, domestic violence, you know? And it didn't work out."
[cpg cn=true]

[OnName num="satoru"]
"......I see."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kazumi009"]
[OnName num="kazumi"]
"Yeah. Well, give me a holler any time you want to do it with me."
[cpg cn=true]

That wasn't what I expected to hear. I was taken aback and walked away quickly.
[cpg]


;//========================================
;//●ＣＧ非エロ（マンションを出てすぐあたりの道で、主人公に手を振るヒロイン２）ev_02
;//人物１：ヒロイン２
;//服装１：私服
;//場所　：街
;//時間　：朝
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="Kazumi010"]
[OnName num="kazumi"]
"Okay, see you around. I hope you didn't forget anything for school."
[cpg cn=true]

[OnName num="satoru"]
"I haven't. I'm also not a child."
[cpg cn=true]


[VOICE f="Kazumi011"]
[OnName num="kazumi"]
"Really? I don't know about that."
[cpg cn=true]


[VOICE f="Kazumi012"]
[OnName num="kazumi"]
"Oh darn I've got to get going or I'll be late. See you!"
[cpg cn=true]

[OnName num="satoru"]
"Sure......."
[cpg cn=true]

She's so cheerful that I can't believe she was divorced. I guess she is trying to find a new happiness.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

;//[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_hu"]
;//[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


I couldn't help but think about Kazumi......
[cpg]

She is an attractive woman in her own right. With that in mind, I walk my usual path to school.
[cpg]

I pass girls my own age, but I wasn't interested in them at all.
[cpg]

They probably think I'm dark and creepy.
[cpg]

But then again, I'm also prejudiced against them......
[cpg]

I wasn't interested in childish women. That was a definite fact.
[cpg]


;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


Is it because I'm childish that I think that?
[cpg]

Whatever. I'm just aware that I'm not interested in girls from my generation.
[cpg]


;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『公園』（昼）******************************************************


Another day, Sunday. You lose track of the days of the week when you're on summer vacation.
[cpg]

It doesn't help that the only thing you can do in an arcade is play games.
[cpg]

I guess people-watching was an option, but the arcade was a little too noisy for that.
[cpg]

That's why I naturally found myself in a park.
[cpg]

[OnName num="child_voice"]
"So, what do you want to play next?"
[cpg cn=true]

[OnName num="child_voice"]
"What about him? Should we just leave him alone?"
[cpg cn=true]

[OnName num="child_voice"]
"It's okay. He doesn't have a dad."
[cpg cn=true]

Among the children gathered there, one of them was clearly being excluded.
[cpg]

I stared at the child, feeling a strong connection with him.
[cpg]

The child is staring at something on the ground with a serious and a dark look.
[cpg]

Apparently, he was observing a line of ants. I felt even closer to him.
[cpg]

[OnName num="boy"]
"What is it mister?
[cpg cn=true]

[OnName num="satoru"]
"It's nothing. You having fun?"
[cpg cn=true]

[OnName num="boy"]
"It's not fun. But I don't have any friends."
[cpg cn=true]

[OnName num="boy"]
"Mister, will you play with me?"
[cpg cn=true]

[OnName num="satoru"]
"Uhhh......."
[cpg cn=true]

In this day and age, you never know what people will say if you play with kids, even if they are boys.
[cpg]

But he seemed to open up around me so I chatted with him for a bit.
[cpg]

He told me that his family was poor and that he has no father.
[cpg]

We sit next to each other on the bench and I start to tell him about how I don't have any parents.
[cpg]

I know he was just a child, but I felt strangely soothed when chatting with him.
[cpg]

After a bit, a woman approached us.
[cpg]


;//彰人の読みは「あきと」です
;//ここから暫く桜の名前を？？？と隠してください


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura001"]
[OnName num="unknown"]
"Oh Akito. Were you playing with the nice man?"
[cpg cn=true]

She was quite a beauty. I found it hard to keep my eyes off of her.
[cpg]

I see. So this kid's name was Akito. He's lucky he still has a mother.
[cpg]

[OnName num="akito"]
"Yes. He was playing with me."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakura002"]
[OnName num="unknown"]
"Sorry to bother you, he's alone a lot......"
[cpg cn=true]

The mother apologizes to me.
[cpg]

[OnName num="satoru"]
"It's okay. I'm always alone too."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sakura003"]
[OnName num="unknown"]
"Really? You're a student, right?"
[cpg cn=true]

[OnName num="satoru"]
"Yes, I have been alone quite a lot since my parents died when I was very young."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Sakura004"]
[OnName num="unknown"]
"......Oh."
[cpg cn=true]

It seemed like she sympathized with me. The boy mentioned that he didn't have a father.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sakura005"]
[OnName num="unknown"]
"I guess you are somewhat like my son......"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Sakura006"]
[OnName num="unknown"]
"Thanks for playing with him. Come on you have to thank him, Akito."
[cpg cn=true]

[OnName num="akito"]
"Thanks mister."
[cpg cn=true]

[OnName num="satoru"]
"......No problem......"
[cpg cn=true]

I felt awkward, but at least I'd met another beautiful woman.
[cpg]

[OnName num="satoru"]
"I come to this park a lot, so uhh......would you mind if I asked what your name was?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sakura007"]
[OnName num="unknown"]
"Huh......? Oh, I don't see a problem with that......."
[cpg cn=true]

She seemed taken aback. It was sudden, sure, but I wasn't making the same mistake twice.
[cpg]


;//ここから桜の名前を表示してください


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sakura008"]
[OnName num="sakura"]
"Hijikata. My name is Sakura Hijikata......and this is Akito."
[cpg cn=true]

[OnName num="satoru"]
"I'm Satoru Murakami. If we ever meet again, then umm......."
[cpg cn=true]

I don't know what to say next. I didn't know if it was weird to say, "then please say hi".
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sakura009"]
[OnName num="sakura"]
"Sure. I hope you get to play with Akito again."
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Kazumi Yamazaki. Sakura Hijikata. And one more person, the woman who cared for me.
[cpg]

I wonder if they have boyfriends.
[cpg]

Kazumi might be single...she'd already come on to me once.
[cpg]

Unless she acted like that around everyone. Well, I could just make her mine and mine alone.......
[cpg]

Ms. Sakura wasn't married, but there was no guarantee that she was single...
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


I couldn't sleep for some reason thinking about it.
[cpg]

I know that I'm the jealous type.
[cpg]

I was starting to feel envy towards Akito. How dare he hog Ms. Sakura's affections.
[cpg]

I'd never known a mother's love, but I want to make Ms. Sakura mine.
[cpg]

But in reality I didn't know how. There's nothing I can do about it......
[cpg]



[jump storage="ep001.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

