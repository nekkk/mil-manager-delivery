*start|The Woman Whose Name I Don't Know

;#################################################
*Ep001|The Woman Whose Name I Don't Know
;#################################################

[SCENE id=1]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[FACE method="bow_2" pos="2/3"]
[VOICE f="Kazumi013"]
[OnName num="kazumi"]
"Good morning, Satoru. You look as gloomy as ever."
[cpg cn=true]

[OnName num="satoru"]
"Ms. Kazumi, you look cheerful as ever......"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kazumi014"]
[OnName num="kazumi"]
"Yes, that's about all I've got going for me right now. So, have you considered my offer?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kazumi015"]
[OnName num="kazumi"]
"I'll be waiting for you anytime. You know where I live, right?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kazumi016"]
[OnName num="kazumi"]
"If you ring my doorbell, well......I'm usually available at night."
[cpg cn=true]
[FACE method="bow_1" pos="2/3"]
[VOICE f="Kazumi017"]
[OnName num="kazumi"]
"I hope I see you later. It would be nice to see you when I have a little more free time."
[cpg cn=true]

She sure was laying it on thick today. Was it really okay to take her up on that offer?
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


Today I went to the arcade again. On my way home, I decided to take a detour for a change of pace.
[cpg]

Unexpectedly, I bumped into Ms. Sakura.
[cpg]


;//========================================
;//●ＣＧ非エロ（建設現場で働くヒロイン。タオルで汗をぬぐってるような感じ）ev_03
;//人物１：ヒロイン３
;//服装１：作業着
;//場所　：建設現場
;//時間　：昼
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]


She was working as a civil worker at a construction site. I was shocked to see a woman doing such hard physical labor.
[cpg]

I was shocked, but I realized that she almost definitely didn't have any leeway for romance in her mind.
[cpg]

Of course, she doesn't have a husband. I already know that.
[cpg]

There must be a reason why she's doing this kind of work......
[cpg]


[VOICE f="Sakura010"]
[OnName num="sakura"]
"Whew......I'm tired......but this is just the beginning."
[cpg cn=true]


[VOICE f="Sakura011"]
[OnName num="sakura"]
"I can't think right now about how many more years I can work."
[cpg cn=true]

She seems to be talking to herself, but I couldn't hear her from my position.
[cpg]

I walked past her. It's not a good idea to go up to her and talk to her right now.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


Then at night. I bumped into Kazumi on my way home.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kazumi018"]
[OnName num="kazumi"]
"Hey Satoru, you take this way back too?"
[cpg cn=true]

[OnName num="satoru"]
"Well...I don't really have many hobbies besides going for walks......."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kazumi019"]
[OnName num="kazumi"]
"What about the arcade? I saw you playing a few times."
[cpg cn=true]

Of course she knows. I'm pretty sure I told her about it too.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kazumi020"]
[OnName num="kazumi"]
"But more importantly, did you think about what I said this morning?"
[cpg cn=true]

Of course I thought about it. It was hard not to.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="sKazumi002"]
[OnName num="kazumi"]
"Hey, can we be friends? I like younger boys."
[cpg cn=true]

[OnName num="satoru"]
"......"
[cpg cn=true]

I thought I was ready for it. But when it came down to it, I had trouble deciding.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kazumi022"]
[OnName num="kazumi"]
;//「初心だなー。こういう時はすぐ答えなきゃだめ」
"In a situation like this, you need to be able to answer right away."
[cpg cn=true]

[OnName num="satoru"]
"But, but......"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sKazumi003"]
[OnName num="kazumi"]
"You shouldn't think too much about what I'm saying."
[cpg cn=true]

I nodded my head. That was the beginning of it all.
[cpg]

The beginning of dating an older woman......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************


[FACE method="shake_2" pos="2/3"]
[VOICE f="Kazumi024"]
[OnName num="kazumi"]
"Sorry about the mess. Hope you don't mind."
[cpg cn=true]

I don't care, since it doesn't look that messy.
[cpg]

[OnName num="satoru"]
"It's clean though......my room is way messier."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kazumi025"]
[OnName num="kazumi"]
"That's cause you're a guy. Don't put me in the same category as you."
[cpg cn=true]

I guess. But it's certainly the first time I've been in a woman's room.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Kazumi026"]
[OnName num="kazumi"]
"Well, let's eat first. You must be hungry, right?"
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


And so I was served Kazumi's home-cooked meal.
[cpg]

I wasn't really sure what to make of the taste, it seemed clear that she'd definitely been married at one point.
[cpg]

I think it was delicious.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************



After that, I stayed in her room for a while.
[cpg]

She asked if we could be friends, but I don't think she would let me into her home for just that reason.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="sKazumi004"]
[OnName num="kazumi"]
".....Hey, do you want to stay over?"
[cpg cn=true]


She asked, and she looked not only bold but also prepared for something.
[cpg]


;//========================================
;//●ＣＧエロ（ベッドの上、主人公を誘うヒロイン）ev_04
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_04_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]

Kazumi, lying on the bed, was beautiful.
[cpg]

But that doesn't mean I'm going to do anything about it.
[cpg]

[VOICE f="sKazumi005"]
[OnName num="kazumi"]
"......Satoru, stop clamming up and come over here."
[cpg cn=true]


Her voice sounded lonely. I decided to comply.
[cpg]

That night I stayed over in Kazumi's room.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************


There was nothing wrong with that. Kazumi and I are both single, and I was still a student.
[cpg]

[OnName num="satoru"]
"......How many people have you dragged into your bed like this?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kazumi052"]
[OnName num="kazumi"]
"Just you. What makes you think otherwise?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kazumi053"]
[OnName num="kazumi"]
"I invited you over because I like you. You know that, don't you?"
[cpg cn=true]

[OnName num="satoru"]
"You say that to everyone, don't you?"
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kazumi054"]
[OnName num="kazumi"]
"You're such a worrier."
[cpg cn=true]

I'm not a worrier. I'm just jealous. I know.
[cpg]

I'm not going to tolerate it if she's doing this with other guys too.
[cpg]

......What should I do?
[cpg]

It's not just Kazumi. What do I want to do with Mr. Sakura or that person whose name I don't even know?
[cpg]

What did I really want?
[cpg]


;//■選択肢
[switch]
[case "I want love."]
	[swap]
	[jump target="*select01_1"]
[case "I want control."]
	[swap]
	[jump target="*select01_2"]
[endswitch]


1. I want love.
2. I want control.



;//選択により、分岐後の選択肢に影響



;//==============================
;//１、恋愛がしたい
;//ヒロイン１ルートで選択肢が発生
*select01_1|The Woman Whose Name I Don't Know
[stflag Cha1flg = 1]


......I want to be in love. Girls my age wouldn't even look at me.
[cpg]

I fell asleep with this thought in my head.
[cpg]

[jump target="*select01_3"]
;//==============================
;//２、支配したい
;//ヒロイン２ルートで選択肢が発生
*select01_2|The Woman Whose Name I Don't Know
[stflag Cha1flg = 2]


......This feeling was almost too strong to control.
[cpg]

I'd realized my true nature.
[cpg]


;//==============================
*select01_3|The Woman Whose Name I Don't Know


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（朝）******************************************************


The morning comes.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kazumi055"]
[OnName num="kazumi"]
"I've got to go to work today so you can head out first."
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kazumi056"]
[OnName num="kazumi"]
"Sorry, I can't give you a key yet. You'll just have to be patient."
[cpg cn=true]

It seems like there was a misunderstanding. I wasn't expecting her to give me a key.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[FACE method="bow_1" pos="2/3"]
[VOICE f="Kazumi057"]
[OnName num="kazumi"]
"I'm off then. Be careful."
[cpg cn=true]

There was nothing to be careful about. It's not like I was going to do anything.
[cpg]

[OnName num="satoru"]
"Be careful of what?"
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kazumi058"]
[OnName num="kazumi"]
"I don't know...a car accident or something? See you later."
[cpg cn=true]

The words "car accident" cause a dark emotion to well up from the very core of my being.
[cpg]

Something terrible had happened to me. That's why it was okay if I dumped all of this negative energy onto someone else...right?
[cpg]


;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


I wanted to make the other women mine. As twisted as it was, at least I had a goal in life now.
[cpg]

[OnName num="satoru"]
"......This is pointless......."
[cpg cn=true]

I was looking for the woman who had helped me the other day. But I had nothing to go off of so I simply wandered around the area I'd collapsed.
[cpg]

I think it was around this time.
[cpg]

I'd suffered from heat stroke, so it couldn't have been during the evening.
[cpg]

That said, there was no guarantee she'd pass through here often.
[cpg]

In fact, it wasn't unlikely that she'd only come this way once and wouldn't show up here ever again.
[cpg]

But I had nothing but time on my hands. How I chose to waste it was nobody's business.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夕方）******************************************************


Of course I couldn't find her. I didn't expect to, either. At least not yet.
[cpg]

I felt like I'd wasted the day, but then again it wasn't like I'd ever done anything productive with my time either.
[cpg]

I spaced out on a bench and suddenly remembered Ms. Sakura.
[cpg]

I know where she works...I could tail her as she heads home.
[cpg]

I'll look for the other woman later, I decided to find out more about Ms. Sakura first.
[cpg]


;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


It didn't take long to find her...
[cpg]

I wait for her shift to end, I had to be discreet about following her.
[cpg]

Rushing from shadow to shadow would be too obvious. I wander around a bit like I had business in the area.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura012"]
[OnName num="sakura"]
"See you tomorrow!"
[cpg cn=true]


[free time=800]

Ms. Sakura exits the construction site...only to get into a car!?
[cpg]

There wasn't any way I was going to be able to follow her like this......I think hard to come up with an idea.
[cpg]

Even if it's civil engineering work, there must be an office. I look at the name.
[cpg]

......I should be able to find out more if I look it up. She probably heads there to finish her work before going home.
[cpg]

I'll be able to follow her home from there.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[OnName num="satoru"]
"Here it is......!"
[cpg cn=true]

I found the office, it wasn't that far away. Now that I think about it, we did meet at that park.
[cpg]

That's probably her path home so I decided to ambush her there.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


So, during the day, I looked for the woman whose name I didn't know. And in the evening, I decided to look for Ms. Sakura.
[cpg]

I didn't find anyone who looked like her today either. I don't expect to find her on the second day, but it sure is boring.
[cpg]

Should I try setting up a surveillance camera? No, I might get in trouble with the police......
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


After my stake-out, I head to the office where Ms. Sakura works.
[cpg]

I saw a car drive in. After a little bit, Ms. Sakura comes out......!
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura013"]
[OnName num="sakura"]
"Phew, I'm tired......!"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakura014"]
[OnName num="sakura"]
"Oof, everything hurts but I still have to work tomorrow."
[cpg cn=true]

She seems to be talking to herself, but I can't make out what she's saying. Of course, I couldn't get any closer without her seeing me.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』


After tailing her for a while, I saw Ms. Sakura entering an apartment.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakura015"]
[OnName num="sakura"]
"I'm home, Akito. Have you been a good boy?"
[cpg cn=true]

[OnName num="akito"]
"Yeah. I'm hungry."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sakura016"]
[OnName num="sakura"]
"Wait for a bit. I'll make you something."
[cpg cn=true]

[free time=1000]

I memorize her room number. I've finally learned where she lives.
[cpg]

The question is what do I do now?
[cpg]

I can't just barge in on them now, she's got a kid...
[cpg]

After thinking about it......I decided to wait until her son was asleep.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


After killing some time, I ring the doorbell.
[cpg]


[SE f="se010"]
;//【ＳＥ】『玄関チャイム』

[WAIT time=1000]

I was getting nervous. Did she even remember who I was?
[cpg]


[VOICE f="Sakura017"]
[OnName num="sakura"]
"Yes......who is it? Oh......umm......Satoru, right?"
[cpg cn=true]

A normal reaction. I don't know what I expected.
[cpg]

But at least she remembered me.
[cpg]

[OnName num="satoru"]
"Can we talk?"
[cpg cn=true]


[VOICE f="Sakura018"]
[OnName num="sakura"]
"......What is it? Can it wait?"
[cpg cn=true]

[OnName num="satoru"]
"It's a little urgent."
[cpg cn=true]

I don't know what she imagined.
[cpg]

She might have thought that it was going to be something about her husband. Of course there was no reason for me to know anything about that......
[cpg]


[VOICE f="Sakura019"]
[OnName num="sakura"]
"Alright, give me a moment."
[cpg cn=true]

She let me inside.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夜）******************************************************


She had changed from her pajamas into her daily clothes. She didn't have to do that.
[cpg]

I guess that's why she made me wait.
[cpg]

I could hear her son breathing in his sleep. It was almost tomorrow.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sakura020"]
[OnName num="sakura"]
"What can I do for you,......? It's late, so please be brief."
[cpg cn=true]

[OnName num="satoru"]
"Okay, I'll be brief."
[cpg cn=true]

[free time=300]
[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/3" time=800]

Saying that, I took Ms. Sakura's hand.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Sakura021"]
[OnName num="sakura"]
"......What is this? If you try anything funny, I'll scream."
[cpg cn=true]

[OnName num="satoru"]
"That's fine, but we wouldn't want to wake up your son, would we?"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Sakura022"]
[OnName num="sakura"]
"That's......hey......!?"
[cpg cn=true]

[OnName num="satoru"]
"I thought you were beautiful from the first moment I laid eyes on you. I can't get you out of my mind."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="sSakura001"]
[OnName num="sakura"]
"What are you talking about? How did you even find out where I live...get off of me!"
[cpg cn=true]

Sakura seems irritated, I hadn't prepared thoroughly enough.
[cpg]

If I had something to threaten her with, this might have gone more smoothly.
[cpg]

[OnName num="satoru"]
"Please don't make a fuss."
[cpg cn=true]


;//========================================
;//●ＣＧエロ（ヒロインに迫る主人公。背中を向けているヒロイン）ev_05
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夜
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_05_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sSakura002"]
[OnName num="sakura"]
"Please......are you doing this because you want to?"
[cpg cn=true]


[OnName num="satoru"]
"Yes, isn't it obvious?"
[cpg cn=true]


I said but I had to ask myself the same question.
[cpg]

I wondered if there was any point in doing this. She certainly didn't seem to be enjoying herself.
[cpg]

I inadvertently loosen my grip.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[free time=1000]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『アパート居間（ヒロイン３の部屋）』（夜）******************************************************

She shook me off and turned to face me.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Sakura044"]
[OnName num="sakura"]
"......Please go home. Now."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sakura045"]
[OnName num="sakura"]
"I'll pretend this never happened. But if you come again, I won't hesitate to call the police."
[cpg cn=true]

She looked serious.
[cpg]

I hadn't given up, but I decided to keep my distance for a little bit.
[cpg]

She might actually call the police. I should have spent more time preparing.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


By the time I left the room it was quite late.
[cpg]

I won't be able to get up early tomorrow morning. Thinking so, I headed home.
[cpg]




[jump storage="ep002.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

