
;//==============================
;//２、一美
*start|Kazumi, the Catalyst

;#################################################
*Ep008|Kazumi, the Catalyst
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


*select02_2|Kazumi, the Catalyst


[SCENE id=8]


It had to be Kazumi, she'd been the catalyst that triggered this chain of events.
[cpg]

But now the power balance had shifted in my favor.
[cpg]

Threaten her with a little bit of violence and she was putty in my hands. It was also convenient that she lived so close.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（昼）******************************************************


I spent some time in the park, thinking about her.
[cpg]

Unlike Aika, Kazumi and Sakura were busy with work.
[cpg]

That meant I had to wait until the evening to make my move.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[BGM f="bg_h1"]
[WAIT time=100]

That night I went to Kazumi's place.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア開け』

[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kazumi144"]
[OnName num="kazumi"]
"Satoru......."
[cpg cn=true]

She felt something for me, thought I don't know what it was.
[cpg]

Maybe she's scared of me now that I've changed.
[cpg]

[OnName num="satoru"]
"I've been waiting for you, Kazumi. Let's spend the rest of the day together."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kazumi146"]
[OnName num="kazumi"]
"You do you know what you are saying right? Are you thinking of marrying me?"
[cpg cn=true]

[OnName num="satoru"]
"That depends on how devoted you are. If you give me all of your attention, then I'll gladly marry you."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kazumi147"]
[OnName num="kazumi"]
"......You really are crazy, Satoru."
[cpg cn=true]

I'm aware of that. I've never thought of myself as normal.
[cpg]


;//========================================
;//●ＣＧエロ（ヒロインに迫る主人公。目隠しはしていない）ev_27
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="satoru"]
"......You're so beautiful, Kazumi."
[cpg cn=true]


[VOICE f="sKazumi011"]
[OnName num="kazumi"]
"Don't say that......."
[cpg cn=true]


These words would have probably made her happy...before all of this.
[cpg]

But there was no going back now.
[cpg]

Kazumi and I both knew this.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************


[OnName num="satoru"]
"I'll see you later. If you try any funny, you know what I'll have to do to you."
[cpg cn=true]

The threat of violence was enough to keep her under my thumb.
[cpg]

Kazumi couldn't resist me any more.
[cpg]

[OnName num="satoru"]
"I'm sure you understand, but don't even think about getting romantically involved with any other men."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kazumi165"]
[OnName num="kazumi"]
"I never did......why do you keep thinking I would do something like that?"
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I go back to my room and gloat to myself.
[cpg]

I feel fulfilled. It's nice to play lover with her, but it's better still when I've got all the power.
[cpg]

That way I get the feeling that she is mine and mine alone.
[cpg]

I have a feeling that when she eventually breaks down, she'll only have me to turn to.
[cpg]

Everything is going well. If things continue as they are, that's all that matters.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


That morning, I thought I'd see Kazumi off to work.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kazumi166"]
[OnName num="kazumi"]
"Are you going to follow me......?"
[cpg cn=true]

[OnName num="satoru"]
"Yes. I don't have anything to do, so I thought it would be a good way to pass the time."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kazumi167"]
[OnName num="kazumi"]
"It's just my morning commute, there's not much to see......."
[cpg cn=true]

To think she used to be so cheerful and outgoing.
[cpg]



[SE f="se020"]
;//【ＳＥ】『電車に揺られる』

;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


I saw Kazumi off to her workplace and headed home.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kazumi168"]
[OnName num="kazumi"]
".....So you really only wanted to follow me?"
[cpg cn=true]

[OnName num="satoru"]
"Of course, that's what I said, right? I'll see you tonight."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Kazumi169"]
[OnName num="kazumi"]
"I don't understand what you're thinking."
[cpg cn=true]

[OnName num="satoru"]
"I get that a lot."
[cpg cn=true]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


On the way home, I bumped into Ms. Sakura.
[cpg]

It seemed like she was taking a break, so I called out to her.
[cpg]

[FG f="CHA03_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sakura097"]
[OnName num="sakura"]
"Huh......!? S-Satoru?"
[cpg cn=true]

[OnName num="satoru"]
"Hi, Ms. Sakura. How's work?"
[cpg cn=true]

[OnName num="sakura_co-worker"]
"Friend of yours?"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Sakura098"]
[OnName num="sakura"]
"Something like that......"
[cpg cn=true]

[OnName num="satoru"]
"You don't have to be so scared. I've decided to give up on you."
[cpg cn=true]

There is no point in chasing two hares. I had come to tell her that.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sakura099"]
[OnName num="sakura"]
"Why are you suddenly saying that......?"
[cpg cn=true]

[OnName num="satoru"]
"Does it matter? Goodbye then."
[cpg cn=true]

My sights were set on Kazumi now. She was the only one for me.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『公園』（夕方）******************************************************


I space out in the park, vaguely aware of the children playing nearby.
[cpg]

At this time of the day, the park was often filled with mothers and their children.
[cpg]

Just seeing them irritates me to no end, but at least I had Kazumi to vent my frustrations on.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


She's like my own personal sandbag, but much more interesting.
[cpg]

After all, she's a living, breathing human being and she doesn't complain.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************


[OnName num="satoru"]
"Oh there you are. Come over here, Kazumi."
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kazumi170"]
[OnName num="kazumi"]
"......What do you want? Why did you call me here?"
[cpg cn=true]

[OnName num="satoru"]
"Come on, I know you missed me as much as I missed you."
[cpg cn=true]


I say so and love Kazumi today as well.
[cpg]

There was something reassuring about having a partner who couldn't disobey you.
[cpg]


;//移植のためシーンをカットしています

;//[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I saw Kazumi home.
[cpg]

We lived in the same complex, so I'm sure she expected it.
[cpg]

The bright and cheery Kazumi was no more, but that was fine.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


I wake up in the morning. Similar days repeat themselves.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


Time passes, and night falls. I was on my way to Kazumi's room.
[cpg]

I passed by a man...he'd just come out of her room.
[cpg]

[OnName num="satoru"]
"What?"
[cpg cn=true]

[OnName num="man"]
"......."
[cpg cn=true]

He was taller than me and seemed about Kazumi's age.
[cpg]

I froze in my surprise. I should have followed him to get a better look at him and gather information.
[cpg]

He just came out of Kazumi's room, didn't he?
[cpg]

What does that mean? Was she cheating on me?
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kazumi190"]
[OnName num="kazumi"]
"......Oh, Satoru, you're here."
[cpg cn=true]

[OnName num="satoru"]
"Who was that just now?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Kazumi191"]
[OnName num="kazumi"]
"Who? You mean Tadashi?"
[cpg cn=true]

Who's Tadashi? Was she close with him?
[cpg]

It was possible, after all she did invite him in...
[cpg]

[OnName num="satoru"]
"Are you cheating on me?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kazumi192"]
[OnName num="kazumi"]
"No, no. Tadashi and I aren't like that..."
[cpg cn=true]

[SE f="se029"]
;//【ＳＥ】『衣擦れ』

[free time=300]
[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
I saw red. Before I knew it, I'd forced Kazumi down and held her there.
[cpg]

[OnName num="satoru"]
"......I don't want you around other people like that. You have to understand that I'm the only person you need."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kazumi193"]
[OnName num="kazumi"]
"Stop......don't hit me."
[cpg cn=true]

[OnName num="satoru"]
"I won't hit you unless you force me to, Kazumi."
[cpg cn=true]


;//ブラックアウト
;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************


I release her and try to make it clear that I wasn't going to accept any more betrayals.
[cpg]

[OnName num="satoru"]
"I don't want to see any other men in your room."
[cpg cn=true]

[OnName num="satoru"]
"You need to promise me that you won't get close to any men besides me."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]

She nods and I slowly lower my tightly-clenched fist.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Kazumi213"]
[OnName num="kazumi"]
"I understand......I won't let anyone up to my house anymore......."
[cpg cn=true]

That wasn't enough for me.
[cpg]

I need her. All of her. She has to be mine and mine alone. What could I do?
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I can't come up with a good idea. I don't know what to do.
[cpg]

But I can't do nothing.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


When I wake up in the morning, I'm still thinking about Kazumi.
[cpg]

To be specific I was actually thinking about the man who came out of Kazumi's room:......
[cpg]

He seemed like a colleague of hers.
[cpg]

How dare he. Who did he think he was? Kazumi was mine.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


I headed to where she works.
[cpg]

......I don't think building security would let me in.
[cpg]

What should I do? Just because it's lunchtime doesn't mean that he's going to come out.
[cpg]

I don't know. Could you eat lunch inside the office?
[cpg]

Was it normal to bring your own lunch......?
[cpg]

I wandered around in front of the building, trying to come up with a plan around baseless assumptions about their lunch break.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]


[SE f="se001"]
;//【ＳＥ】『歩く』


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[OnName num="satoru"]
"......What am I doing?"
[cpg cn=true]

What's the point of doing this? Kazumi and that guy don't seem to be coming out of the office.
[cpg]

I had all this time, why not use it to do something else?
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


So I called Kazumi.
[cpg]

[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

Was it still lunchtime? I wondered if she'd pick up.
[cpg]

;//========================================
;//●ＣＧエロ（トイレで電話に出るヒロイン）ev_30
;//人物１：ヒロイン２
;//服装１：スーツ
;//場所　：会社＿女子トイレ個室
;//時間　：昼
;//========================================

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//[VOICE f="Kazumi214"]
[VOICE f="sKazumi012"]
[OnName num="kazumi"]
"......Wh-what is it?"
[cpg cn=true]

[OnName num="satoru"]
"You're on lunch break, right? Since you picked up, that means you're not at your desk."
[cpg cn=true]


[VOICE f="sKazumi013"]
[OnName num="kazumi"]
"Yeah......."
[cpg cn=true]


Maybe she answered the phone in the bathroom or somewhere.
[cpg]

She could have just ignored it, but I guess she was too scared of me.
[cpg]


[SE f="se035"]
;//【ＳＥ】『携帯電話の通話終了音』

;//移植のためシーンをカットしています
;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


I found myself without anything to say.
[cpg]

She answered my call obediently, which deserves a reward.
[cpg]

Maybe I'll wait for her and walk her home.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


I waited outside for her to get off work.
[cpg]

Eventually, I saw Kazumi leave the building, but......
[cpg]

Tadashi was with her.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[VOICE f="Kazumi235"]
[OnName num="kazumi"]
"Satoru......."
[cpg cn=true]

[OnName num="tadashi"]
"......I see, so that's him, huh?"
[cpg cn=true]

It seems he'd heard of me. What did he know?
[cpg]

My mind races. Who was he to her?
[cpg]

[OnName num="tadashi"]
"This is the first time we're meeting, I guess? My name is Tadashi, I'm Kazumi's boyfriend."
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Kazumi236"]
[OnName num="kazumi"]
"No! Don't say that!"
[cpg cn=true]

[OnName num="tadashi"]
"I've heard all about you. It seems you like hitting women, huh?"
[cpg cn=true]

She told him everything! The love that should have been directed only toward me is now directed toward him......
[cpg]

[FACE method="shock_4" pos="2/5"]
[VOICE f="Kazumi237"]
[OnName num="kazumi"]
"Tadashi, it's okay! I can bear it."
[cpg cn=true]

[OnName num="tadashi"]
"Kazumi may not want to get the police involved, but if you try anything ever again, I'll call them immediately."
[cpg cn=true]

[OnName num="tadashi"]
"We'll see how tough you are when there aren't any helpless women for you to push around."
[cpg cn=true]

This was bad. A very bad feeling spreads through my body.
[cpg]

What was happening? I couldn't have Kazumi all to myself and now someone was trying to steal her from me?
[cpg]

I can't get my thoughts...my emotions...everything's all mixed up. All I can feel is anger and it desperately searches for an outlet.
[cpg]

[FACE method="change_5" pos="2/5"]

Before I knew it, I'd clenched my fists and leaped towards Tadashi.
[cpg]


[SE f="se031"]
;//【ＳＥ】『殴る』

[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=1]
[WAIT time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/5" time=1500]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]

But before my fists found their mark, I stumbled backwards.
[cpg]

A sharp pain radiates from my chest to my extremities and I buckled over. He hit me...?
[cpg]

[OnName num="tadashi"]
"If violence is the only language you understand, then I'll beat every word into you."
[cpg cn=true]

[OnName num="tadashi"]
"You're going to promise that you'll never show your snivelling face around Kazumi ever again. Got it?"
[cpg cn=true]

[OnName num="satoru"]
"I...I......ugh...."
[cpg cn=true]

[free time=1000]

I couldn't manage a response, I could barely breathe. They left me there and headed back together.
[cpg]

I lay there, overcome by pain and a feeling of powerlessness.
[cpg]

I found myself crying. He was stronger than me.
[cpg]

Or rather, he was older than me and a working adult.
[cpg]

Even if we were romantic rivals, I clearly didn't stand a chance.
[cpg]

What should I do? What do I want to do?
[cpg]

[stflag Cha1flg = 0]

[if exp={getFlagValue("Cha1flg") == 2 }]
[jump target="*select04_2"]
[endif]

;//■選択肢
[switch]
[case "I can't monopolize Kazumi."]
	[swap]
	[jump target="*select04_1"]
[case "I have to monopolize Kazumi."]
	[swap]
	[jump target="*select04_2"]
[endswitch]


1. I can't monopolize Kazumi.
2. I have to monopolize Kazumi.



;//（最初の選択肢で２を選んでいた場合、この選択肢は発生せず２を選んだことになる）



*select04_1|Picture Perfect
[jump storage="ep009.ks" target="*select04_1"]

*select04_2|Cursed Souls
[jump storage="ep010.ks" target="*select04_2"]




