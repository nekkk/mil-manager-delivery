
;//==============================
;//２、一美さんを独り占めしたい

*start|Cursed Souls

;#################################################
*Ep010|Cursed Souls
;#################################################



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


*select04_2|Cursed Souls


[SCENE id=10]

The answer was clear. Kazumi had to be mine. Only mine.
[cpg]

But I didn't have a chance as things were now. I need to come up with a plan.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I come to a conclusion. I had to physically separate her from everyone else.
[cpg]

I'd have to kidnap and confine her. What would happen if I invited her to my room?
[cpg]

I think she'd come over if I asked.
[cpg]

Then I could drug her with something, restrain her......would this really work?
[cpg]

Instead of wasting my time worrying, I'd be better off making preparations.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I began looking into how to confine her.
[cpg]

Of course, it's not like I could keep her around for long.
[cpg]

People would notice if she didn't show up at work. People like Tadashi...
[cpg]

If I was going to make a move, it had to be on Friday evening so I could keep her with me through the weekend.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


That Friday, I was ready to make my move.....
[cpg]

I approached Kazumi under the pretext of wanting to apologize and invite her to my room.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kazumi326"]
[OnName num="kazumi"]
"......I'm glad you've come to your senses. We can get over this together."
[cpg cn=true]

Kazumi even smiles a little. She doesn't suspect a thing.
[cpg]

[OnName num="satoru"]
"I've prepared something for you...a little token of my appreciation."
[cpg cn=true]

[OnName num="satoru"]
"Can I ask you to close your eyes for a moment?"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kazumi327"]
[OnName num="kazumi"]
"What......? Well, okay."
[cpg cn=true]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I move behind her and press a drug-soaked handkerchief over her mouth.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


The drugs worked a little better than I'd thought. It was already noon and she was still asleep.
[cpg]

Of course, I'd restrained her while she was unconscious. I'd decided to nap for a bit in order to save my strength for later......
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[free time=1000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=3000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=3000]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1500]
[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』******************************************************
;//【ＢＧ】『街』（夕方）


It took a little while for her to wake up.
[cpg]

She looked quite confused, but I didn't care.
[cpg]

Kazumi was probably getting hungry, so I decided to go out shopping.
[cpg]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）

;//その間、一美さんは手足を縛っておいた。何もできない筈。
I bound her legs before I left. I couldn't risk her getting free.
[cpg]

There was a lot to buy. I had to enjoy what limited time I had with her before the police arrived.
[cpg]

The question was how far I could go before it all came crashing down.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


But for now, I had more pressing matters to attend to. I buy something to eat and bring it back to feed Kazumi.
[cpg]

[OnName num="satoru"]
"Here you go, darling."
[cpg cn=true]

Kazumi obeys me. If she doesn't, she would die.
[cpg]

I was satisfied with that. I felt like I was in complete control.
[cpg]


;//ＢＫ
;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]

Eventually, the morning comes.
[cpg]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


It was Saturday, and I was going to spend the whole day with her.
[cpg]

Sunday was fine, and maybe I could keep her through Monday too.
[cpg]

I didn't think it would be that unusual to miss work on a Monday...
[cpg]

But people would definitely come looking for her by Tuesday.
[cpg]

I tried to come up with a plan as I spent what precious time I had left with Kazumi.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


I also had to keep her fed and watered while she was in my care.
[cpg]

I couldn't have her catching a cold, so I bought her a sports drink or something like that.
[cpg]

Then, by some coincidence, I bumped into Aika.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Aika404"]
[OnName num="aika"]
"Oh......"
[cpg cn=true]

[OnName num="satoru"]
"It's been a while."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Aika405"]
[OnName num="aika"]
"Yes, yes........umm......"
[cpg cn=true]

[OnName num="satoru"]
"Don't worry, I won't do anything to you anymore. I found a more interesting toy."
[cpg cn=true]

I guess it was okay to tell her that.
[cpg]

Then I headed back home.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


Kazumi was clearly getting weaker.
[cpg]

I'm changing the way I bind her every so often to reduce the strain on her body, but it was hard to tell if it was having an effect.
[cpg]

But I couldn't have her recovering fully, because she might overpower me and escape......it's a difficult balance.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kazumi367"]
[OnName num="kazumi"]
"......Ugh......uhhh."
[cpg cn=true]

She's breathing slowly. It must be difficult for her when I leave her alone for so long.
[cpg]

More than boredom, she probably feels like she's going crazy.
[cpg]

She probably wonders how much longer she has to suffer like this.
[cpg]

Maybe she's holding out for Tadashi to come and save her.
[cpg]

[OnName num="satoru"]
"Kazumi. Have you finally forgotten about him?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kazumi368"]
[OnName num="kazumi"]
"Him...? What are you talking about?"
[cpg cn=true]

He wasn't the first person to come to mind. That's good.
[cpg]

If she isn't thinking of him all the time, then I'd at least achieved part of my goals.
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト

[OnName num="satoru"]
"Kazumi......do you resent getting involved with me?"
[cpg cn=true]

[FACE method="shake_5" pos="2/3"]
[VOICE f="Kazumi388"]
[OnName num="kazumi"]
"......that's......"
[cpg cn=true]

She hesitates to answer, I guess some part of her does.
[cpg]

Of course, she can't say it outright. She'd started all of this to begin with.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kazumi389"]
[OnName num="kazumi"]
"Maybe......I'm starting to wonder if it's my fault that this happened."
[cpg cn=true]

[OnName num="satoru"]
"I see."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[OnName num="satoru"]
"Goodnight, Kazumi."
[cpg cn=true]

There was no reply from Kazumi. I went back to sleep.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


The morning comes. If only time would stop...
[cpg]

There's not much I can do, so I'm just trying to make the most of the time that I have.
[cpg]

Kazumi is still sleeping. I decided to go shopping before she wakes up.
[cpg]



;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


;//[SE f="se000"]
;//【ＳＥ】『喧噪』


I had a feeling that this wasn't going to last for long.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


When I got back to my room, Kazumi wakes up and looks over at me.
[cpg]

I guess some part of her still had feelings for me.
[cpg]

After all, she's the one who made a move on me first.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


That evening, Kazumi and I had our first real conversation in a while.
[cpg]

It started with a sudden question.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="sKazumi020"]
[OnName num="kazumi"]
"Satoru, why did you decide to kidnap me?"
[cpg cn=true]

[OnName num="satoru"]
".....Well, it's a bit of a long story."
[cpg cn=true]

I'd have to go back to the beginning...my family. I wasn't comfortable digging all that up again.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kazumi413"]
[OnName num="kazumi"]
"It's not like we don't have time......there's probably a lot of things you haven't told me."
[cpg cn=true]

[OnName num="satoru"]
"It really is a long story, are you sure you want to hear it all?"
[cpg cn=true]

So I told her everything.
[cpg]

[OnName num="satoru"]
"I lost my parents in an accident when I was very young."
[cpg cn=true]

[OnName num="satoru"]
"I grew up never knowing love or kindness or even basic human decency. That's why I ended up like this."
[cpg cn=true]

[OnName num="satoru"]
"I'm gloomy, aren't I? I mean, even I think of myself that way......I can't imagine what normal people think of me."
[cpg cn=true]

Kazumi did not deny it. Nor did she seem particularly disappointed in me.
[cpg]

[OnName num="satoru"]
"I'm sure that something inside of me is chasing after my mother's shadow."
[cpg cn=true]

[OnName num="satoru"]
"Perhaps I am looking to you to compensate for the love I didn't get from my mother."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="sKazumi021"]
[OnName num="kazumi"]
"......I see."
[cpg cn=true]

Kazumi looked at me strangely. But I that was expected.
[cpg]

[OnName num="satoru"]
"My very soul is cursed. If I had a child, it would end up just like me......."
[cpg cn=true]

[OnName num="satoru"]
"It would probably lose its parents in an unfortunate accident. Just like me..."
[cpg cn=true]

But there was no use thinking about the fate of a child that would never be born.
[cpg]

Yet, some part of me couldn't stop thinking about it.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


I felt like I was going to go crazy, staying at home all day.
[cpg]

Sometimes I leave the house. That was part of the routine I had before I locked Kazumi up.
[cpg]

......Naturally, I can't let Kazumi out of the house.
[cpg]

She must be far more emotionally damaged than I am.
[cpg]

And yet, Kazumi is still strong enough not to lose her sanity.
[cpg]

She might be able to accept my love in its entirety.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I head back to my room. Kazumi had silently waited for me to return.
[cpg]

Not that she had much of a choice......I just got the impression that she had been waiting for me.
[cpg]

;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

We have a late dinner. This wasn't love, Kazumi just feels responsible for the situation.
[cpg]

It was a very one-sided relationship, but I was fine with that.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ


The days blend into each other.
[cpg]

I'd go out shopping whenever we needed something.
[cpg]

This couldn't go on forever, but at least I was happy.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


Monday and Tuesday passed without incident. It was finally Wednesday.
[cpg]

It was about time......and just as I'd let that thought flit through my mind......
[cpg]


[SE f="se024"]
;//【ＳＥ】『ドアを叩く』
[WAIT time=1000]

I hear someone pounding on the door. I half-expected them to break it down.
[cpg]

[OnName num="policeman"]
"It's the police! Open up!"
[cpg cn=true]

As I thought, the police were finally here. This was the end.
[cpg]

There's nowhere to run or hide, not that there was much point in other.
[cpg]

After all, where would I go without Kazumi? I only did this to be with her.
[cpg]

Taking her with me wasn't an option.
[cpg]

This was the end of the line, so I decided to comply and open the door.
[cpg]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


And so I was taken into custody.
[cpg]

How long would they put me away? I was fairly sure I'd never be a free man again.
[cpg]

But the reality was a little different from what I'd expected.
[cpg]

[OnName num="satoru"]
"......What's going on?"
[cpg cn=true]

I was released within a matter of days.
[cpg]

Not that I'd heard it from her directly, but apparently Kazumi had come to my defense.
[cpg]

She'd made up a story that we were simply trying to spice up our love life.
[cpg]

And that's why most of the charges against me were dropped......but I don't really know the truth.
[cpg]

I'd have to ask her myself. However......
[cpg]


;//[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_sa"]
;//[WAIT time=100]
;//【ＢＧ】『公園』（昼）******************************************************


I was too afraid to call her.
[cpg]

What would she say? Would she tell me to forget about what I'd done?
[cpg]

Or would she tell me to pretend that our relationship had never happened?
[cpg]

If so, I'd probably end up kidnapping her again. Then I'd be going away for good.
[cpg]

Time passes as I feel a sort of paralysis. I couldn't do anything.
[cpg]


[SE f="se000"]
;//【ＳＥ】『カラスの鳴き声』


[window target=false]
[free time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夕方）******************************************************


I lost track of time.
[cpg]

The sun was setting. How long had I been here?
[cpg]

My sense of time has been strange ever since that fateful day when I lost my parents......
[cpg]


[SE f="se013"]
;//【ＳＥ】『携帯電話の振動音』


The vibration of my phone brings me back to reality.
[cpg]

I looked at the screen. It's Kazumi. Shakily, I bring the phone to my ear.
[cpg]

[SE f="se034"]
;//【ＳＥ】『携帯電話に出る』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[OnName num="satoru"]
"......It's Satoru."
[cpg cn=true]


[VOICE f="Kazumi429"]
[OnName num="kazumi"]
"......Oh good, I wasn't sure you'd pick up."
[cpg cn=true]


;//ＢＫ


Kazumi had a lot to say.
[cpg]

It seems she was pregnant.
[cpg]


[VOICE f="Kazumi430"]
[OnName num="kazumi"]
"......What should I do? Should I have the baby?"
[cpg cn=true]

Naturally, it was my child. I wasn't sure what to say.
[cpg]

But, as my child, it would almost certainly be born cursed. Was this really the right thing to do?
[cpg]

After giving it some thought, I gave her my answer.
[cpg]

[OnName num="satoru"]
"Yes, you should......I want you to have my child."
[cpg cn=true]

She'd considered abortion, but it seems there was still some part of her that had affection for me.
[cpg]

Kazumi kept me from going to jail and even says she'll have my baby.
[cpg]

......There's something wrong with her.
[cpg]

Complex feelings well up from deep inside me. What was this?
[cpg]

I realized that these were probably feelings of love for Kazumi.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************


While we were talking, the sun had completely set.
[cpg]

[OnName num="satoru"]
"See you......."
[cpg cn=true]

[SE f="se021"]
;//【ＳＥ】『携帯電話の通話終了』
[free time=1000]
[WAIT time=1000]

Stunned, I hung up the phone.
[cpg]

So I'm going to be a father.
[cpg]

......Could I become a father?
[cpg]

Impossible. I'm cursed. My child will bear this curse for the rest of their life too.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


Kazumi raised our child alone.
[cpg]

Tadashi left her because she'd given birth to someone else's child.
[cpg]

I didn't get involve either. I didn't think I was qualified to raise a child.
[cpg]

I was still a student, so I didn't feel like I could support her either.
[cpg]

Still, I might propose to her once I graduate from college.
[cpg]

......Would that even be allowed?
[cpg]

The seasons pass without us crossing paths......
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


One day, I saw a familiar name in the news.
[cpg]

A story about a single mother who had passed away.
[cpg]

She'd died in a car accident, just like my parents.
[cpg]

I was surprised to find that I didn't feel any different.
[cpg]

Somewhere along the way, I seemed to have accepted that this was destiny.
[cpg]

Kazumi's child, my child, had no parents.
[cpg]

Just like me. What was this, if not fate?
[cpg]

I could have accepted Kazumi's wishes and raised our child in her stead......
[cpg]

But I didn't do that since I'd probably just die in a car accident too.
[cpg]

......I'm cursed. I'm sure of it.
[cpg]

It felt guilty for getting Kazumi mixed up in my misfortune...
[cpg]

That too, seemed inevitable.
[cpg]

How would our child grow up? Would they accept their misfortune? Would they try to resist it?
[cpg]

......I didn't really want to know, so I simply returned to my normal day-to-day life.
[cpg]


;//ＥＮＤ：ヒロイン２ルート２

[SCENE id=16]

[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

