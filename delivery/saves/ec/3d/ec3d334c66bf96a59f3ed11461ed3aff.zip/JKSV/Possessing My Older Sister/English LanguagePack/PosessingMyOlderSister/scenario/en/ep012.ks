
;//==========================================================
;//==========================================================
;//選択肢　恋愛がしたい　を選択した場合


*start|The only connection with Mr. Sakura

;#################################################
*Ep012|The only connection with Mr. Sakura
;#################################################

*select05_2|The only connection with Mr. Sakura

[SCENE id=12]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


I stand in front of the door and call her on my phone.
[cpg]

The walls of the tattered apartment were so thin that you could easily hear sounds from the inside.
[cpg]


[SE f="se011"]
;//【ＳＥ】『携帯着信音』音小さめ

I let it ring for a while, but she doesn't pick up.
[cpg]

Instead, the door slowly opened.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア開く』

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1000]
[WAIT time=1000]


;//【ＢＧ】『アパート居間（ヒロイン３の部屋）』（夜）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Sakura208"]
[OnName num="sakura"]
"......Satoru."
[cpg cn=true]

[OnName num="satoru"]
"Why didn't you answer the phone?"
[cpg cn=true]

I'm smiling, but Ms. Sakura's brow is furrowed.
[cpg]

She doesn't seem very welcoming.
[cpg]

[OnName num="satoru"]
"Good evening."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Sakura209"]
[OnName num="sakura"]
"......."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakura210"]
[OnName num="sakura"]
"Just come in."
[cpg cn=true]

[OnName num="satoru"]
"Why so grumpy? I went out of my way to come and see you."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Sakura211"]
[OnName num="sakura"]
"Just hurry up, I don't want anybody to see you here..."
[cpg cn=true]

[OnName num="satoru"]
"Good evening, Ms. Sakura."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Sakura212"]
[OnName num="sakura"]
"......Good evening."
[cpg cn=true]

[OnName num="satoru"]
"Is now a good time?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Sakura213"]
[OnName num="sakura"]
"It's fine....."
[cpg cn=true]

She responded with a resigned expression, ignoring the words.
[cpg]

If only she'd obeyed me from the very beginning.
[cpg]

Coming here today was the right choice.
[cpg]

How many times have I visited her house like this?
[cpg]

Yet, her attitude has yet to change.
[cpg]

It seems that Ms. Sakura doesn't seem to fully understand her position yet.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[OnName num="satoru"]
"You could try decorating a little bit."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Sakura214"]
[OnName num="sakura"]
"That's none of your business."
[cpg cn=true]

[OnName num="satoru"]
"Is Akito sleeping?"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Sakura215"]
[OnName num="sakura"]
"What? Yes, he's sleeping peacefully in the back room."
[cpg cn=true]

[OnName num="satoru"]
"Good, I'll go check in on him."
[cpg cn=true]

As I take a step forward...
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Sakura216"]
[OnName num="sakura"]
"......Leave him out of this."
[cpg cn=true]

She stands between me and the door.
[cpg]

Her voice was quiet, but it carried more weight that I'd expected.
[cpg]

So this was the line. Any further and there's no telling what she'd do.
[cpg]

;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


I kept going to Ms. Sakura's place.
[cpg]

It's not like I wanted to be with her all of the time.......
[cpg]

But I did want her to be mine.
[cpg]


;//[SE f="se011"]
;//【ＳＥ】『扉閉まる』


;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

—— Time passes....
[cpg]

[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1500]
[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『アパート居間（ヒロイン３の部屋）』（昼）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Sakura267"]
[OnName num="sakura"]
"(.....I'm a little late this month.)"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Sakura268"]
[OnName num="sakura"]
"No way....."
[cpg cn=true]

After a while......I noticed that my period hadn't come. I could feel the blood rush from my head.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Sakura269"]
[OnName num="sakura"]
"It's just a little late. There's nothing to worry about."
[cpg cn=true]

;//ブラックアウト
;//移植のためシーンをカットしています
;//ＢＫ
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『アパート居間（ヒロイン３の部屋）』（夕方）******************************************************


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sakura298"]
[OnName num="sakura"]
"Come on in."
[cpg cn=true]

[OnName num="satoru"]
"Hello."
[cpg cn=true]

Something's changed......Her attitude? Compared to before, she seems almost at ease.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sakura299"]
[OnName num="sakura"]
"You're late."
[cpg cn=true]

[OnName num="satoru"]
"What?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Sakura300"]
[OnName num="sakura"]
"The time. You took a lot longer than I thought you would."
[cpg cn=true]

[OnName num="satoru"]
"Oh, uhh, I had errands to run."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakura301"]
[OnName num="sakura"]
"Okay, well I have an early morning tomorrow so let's just get this over with."
[cpg cn=true]

[OnName num="satoru"]
;//「あ、する前に…」
"Hold on......"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakura302"]
[OnName num="sakura"]
"What is it? I'll put on a kettle."
[cpg cn=true]

......I had an idea of what was going on.

[OnName num="satoru"]
"Are you pregnant?"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="sSakura008"]
[OnName num="sakura"]
"Yes."
[cpg cn=true]

My hunch was right.
[cpg]

[OnName num="satoru"]
"......Are you going to keep it? Never mind, of course you aren't."
[cpg cn=true]


[SE f="se009"]
;//【ＳＥ】『ビンタ』
[free time=300]
[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

My vision flickered for a moment and I found myself on the floor. What just happened?
[cpg]

My cheek stung, leading me to understand that I'd just been slapped.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Sakura308"]
[OnName num="sakura"]
"Don't even joke about things like that."
[cpg cn=true]

[OnName num="satoru"]
"What?"
[cpg cn=true]

I couldn't make sense of what she was saying.
[cpg]

She'd been so submissive, why the sudden change?
[cpg]

She wasn't exactly in a position to disobey me, why risk it?
[cpg]

But she was clearly angry. What was she angry about?
[cpg]

I'm having difficulty understanding the situation.
[cpg]

She is pregnant with my child. The child of the person who trampled on her dignity.
[cpg]

Normally you'd want to get rid of it...right?
[cpg]

[OnName num="satoru"]
"You're going to have it? Are you serious?"
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Sakura309"]
[OnName num="sakura"]
"......Yes, I'm going to have it."
[cpg cn=true]

Madness. Not that I was really in a position to say anything, but it seemed crazy to me.
[cpg]

[OnName num="satoru"]
"Why.....?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sakura310"]
[OnName num="sakura"]
"The child is innocent. I can't just pretend that the life that was given to me didn't happen....."
[cpg cn=true]

This is not what I expected.
[cpg]

[free time=300]
[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sakura311"]
[OnName num="sakura"]
"I got my first child later in life as well."
[cpg cn=true]

She looks toward Akito's bedroom.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sSakura009"]
[OnName num="sakura"]
"Being loved as a woman, my child.....It was the first time I was really happy."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sakura313"]
[OnName num="sakura"]
"But now my child is all that I have left."
[cpg cn=true]

[OnName num="satoru"]
"Then......"
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Sakura314"]
[OnName num="sakura"]
"It's the same with this child. It's my happiness....that's why I'm going to have it."
[cpg cn=true]

She was determined to have it, and nothing I said would change that.
[cpg]

I'd thought I'd had her under my control, but it was just an illusion.
[cpg]

From the very beginning, she'd only been thinking of her son. And now she was moving out of my reach.
[cpg]

Women are tough. Far tougher than men. But mothers were in another league of their own.
[cpg]

My resolve wavered in the face of her unyielding determination.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sSakura010"]
[OnName num="sakura"]
"Don't worry, I'm not expecting you to step up or anything. Our relationship will stay the same."
[cpg cn=true]

Where does she get the strength to sacrifice herself like this?
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakura320"]
[OnName num="sakura"]
"I should probably mention that I took on more work. I'll be pretty busy for a while."
[cpg cn=true]

[OnName num="satoru"]
"What? Why?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sakura321"]
[OnName num="sakura"]
"Well, I'm going to need the money, of course. I won't have a lot of free time, so if you need something you'll have to tell me well ahead of time."
[cpg cn=true]

She's decided to work even harder and save up as much money as possible before she has to give birth.
[cpg]

There was nothing I could say to change her mind.
[cpg]

She rushes to get me out of the apartment.
[cpg]

But that's all I remember.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

......My life changed completely after that.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


The world that was supposed to revolve around me now revolves around Ms. Sakura.
[cpg]

Like she said, she'd only meet me when I contacted her ahead of time.
[cpg]

Why do I have to listen to her? I'm in charge here, she should just do as I say.
[cpg]

I decided to visit her without calling ahead of time.
[cpg]

But her reaction wasn't what I expected.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura322"]
[OnName num="sakura"]
"Satoru? Why are you here?"
[cpg cn=true]

[OnName num="satoru"]
"I wanted to surprise you."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Sakura323"]
[OnName num="sakura"]
"I told you to call me in advance."
[cpg cn=true]

There isn't much emotion in her voice. She stares at me with disdain, but there is no anger or fear in her eyes.
[cpg]

[OnName num="satoru"]
"(Why do I have to do as she says?)"
[cpg cn=true]

But I found myself intimidated. Why? What happened to me?
[cpg]

I can't articulate it, but something was different.
[cpg]


;//移植のためシーンをカットしています
;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


My relationship with her hasn't changed. The power relationship should still be in my favor.
[cpg]

I want things to go back to the way they were, but nothing I do seems to work.
[cpg]

It's like she's a doll......she treats me as if I don't exist.
[cpg]

[OnName num="satoru"]
"Damnit! Damnit! Damnit!!"
[cpg cn=true]

What should I do? What can I do.....
[cpg]

;//少しウェイト入れて下さい
;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1500]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


I avoided her for a while.
[cpg]

The more I talked to her, the more miserable I felt.
[cpg]

Why? Why do I feel like this?
[cpg]

Eventually, I came to a unexpected realization.
[cpg]

Why am I so obsessed with her?
[cpg]

......I'd never even given thought to why I'd grown so fixated on her.
[cpg]

Why?
[cpg]

.....Why was that?
[cpg]

The answer is simple.
[cpg]

It has to be her.
[cpg]

That's right. Why did I choose her over the other women I had under my thumb?
[cpg]

Some part of me recognized that no other woman could replace her.
[cpg]

I didn't even realize it.
[cpg]

Or maybe I was just trying my hardest not to notice.
[cpg]

Because she didn't pay me any attention.
[cpg]

Because I wanted her to care about me.
[cpg]

Because I knew she'd never be mine.
[cpg]

I thought that this was my first and last chance.
[cpg]

So I just...wanted her all for myself.
[cpg]

Because I love her......
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


[SE f="se036"]
;//【ＳＥ】『メール着信音』

[WAIT time=2000]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sakura344"]
[OnName num="sakura"]
"A text?"
[cpg cn=true]


;//メール文章
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


"Can I come over tonight?"
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************
;//【ＢＧ】『アパート居間（ヒロイン３の部屋）』（夜）


[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakura345"]
[OnName num="sakura"]
"Good evening."
[cpg cn=true]

[OnName num="satoru"]
"Hi......."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sakura346"]
[OnName num="sakura"]
What's up? Aren't you coming up?"
[cpg cn=true]

She invites me in. Up until now I'd just barged in whenever it suited me.
[cpg]

But now I feel like I need her permission.
[cpg]

I find myself caring about how she feels.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakura348"]
[OnName num="sakura"]
"Did something happen? You're acting awfully reserved today."
[cpg cn=true]

[OnName num="satoru"]
"......."
[cpg cn=true]

I couldn't answer her question. I could only remain silent.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//========================================
;//●ＣＧエロ（恋人繋ぎでキスをする）ev_49
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋（アパートの居間）
;//時間　：夜
;//========================================

;//[FADEOUTBGM]
;//[free time=1000]
;//[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_49_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

I'd only ever interacted with her from a position of power.
[cpg]

It was so hard to say...to admit that I loved her.
[cpg]

[OnName num="satoru"]
"......"
[cpg cn=true]


[VOICE f="sSakura011"]
[OnName num="sakura"]
"What's wrong?"
[cpg cn=true]


[OnName num="satoru"]
"......I love you."
[cpg cn=true]


The words just slipped out of my mouth.
[cpg]

She lets out an exasperated laugh. I'll never forget the look on her face.
[cpg]


;//移植のためシーンをカットしています
;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]

Time passes......
[cpg]

[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

We were having a little get together with our neighbors.
[cpg]

[OnName num="neighbor_wife"]
"What a wonderful husband you have. You must be so happy?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakura368"]
[OnName num="sakura"]
"Oh, no, no. He's nothing special, really."
[cpg cn=true]

[OnName num="neighbor_wife"]
"You don't have to be so modest."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Sakura369"]
[OnName num="sakura"]
"Ahah. If only."
[cpg cn=true]

[OnName num="satoru"]
"......."
[cpg cn=true]

[OnName num="neighbor_wife"]
;//「聞いたわよ。毎日お盛んなんでしょ」
"I hear you two are so passionately in love that you're flirting practically every day."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakura370"]
[OnName num="sakura"]
"Oh, I'm just doing what he tells me. I really don't have much of a choice."
[cpg cn=true]

[OnName num="neighbor_wife"]
"Please, you're going to put all of us to shame. I wish my husband loved me as much as yours."
[cpg cn=true]

It was just small talk.
[cpg]

I wanted to go far away...at least far enough that I couldn't hear them.
[cpg]

On the surface I may appear to be a model husband.
[cpg]

But my relationship with Sakura will never change.
[cpg]

She will never love me.
[cpg]

Marrying her and acting like a good husband...it's all just a desperate attempt to make up for my sins.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//移植のためシーンをカットしています

I was surprised at how far you can get with the right motivation. I ended up getting a job at a big company.

I work hard to earn as much money as possible to provide for my family.
[cpg]

Somewhere along the way, my children became my whole world. They're the only connection I have to her.
[cpg]

I tell myself over and over that they were born out of love.
[cpg]

[OnName num="satoru"]
"I love you, Sakura......"
[cpg cn=true]

But no matter what I do or say, she won't open her heart to me.
[cpg]

She never will.
[cpg]

[VOICE f="Sakura371"]
[OnName num="sakura"]
"——— Well, I don't love you."
[cpg cn=true]

;//ＥＮＤ：ヒロイン３ルート２

[SCENE id=18]

[jump storage="epend.ks" target="*start"]

;//==========================================================
;//==========================================================


