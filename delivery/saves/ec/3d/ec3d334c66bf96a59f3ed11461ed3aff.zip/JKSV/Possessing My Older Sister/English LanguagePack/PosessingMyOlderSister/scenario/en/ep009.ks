
;//==============================
;//１、一美さんを独占するのは諦める

*start|Picture Perfect

;#################################################
*Ep009|Picture Perfect
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

*select04_1|Picture Perfect

[SCENE id=9]


Maybe I couldn't have her to myself, but I could still have her.
[cpg]

......All I had to do was get Tadashi on my side.
[cpg]

Kazumi still have lingering feelings for me. She had to.
[cpg]

And even if he was still around, she wouldn't forget the fear I'd put in her...I'm sure she'd hear me out.
[cpg]

[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I rang the doorbell and the front door opens.
[cpg]

But I found myself face to face with him...
[cpg]

[SE f="se019"]
;//【ＳＥ】『ドア開け』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************


[OnName num="tadashi"]
"I'm pretty sure I told you not to show your face around her anymore."
[cpg cn=true]

Kazumi was silent and stares at the ground......
[cpg]

[OnName num="satoru"]
"I have a proposal. Kazumi, let's go back to our original relationship."
[cpg cn=true]

[FACE method="shock_5" pos="2/5"]
[VOICE f="Kazumi238"]
[OnName num="kazumi"]
"What......? What are you saying, I'm with Tadashi now."
[cpg cn=true]

[OnName num="satoru"]
"I'm fine with being your second choice. I promise I won't do anything bad to you anymore."
[cpg cn=true]

[FACE method="shake_4" pos="2/5"]
[VOICE f="Kazumi239"]
[OnName num="kazumi"]
"......What should we do, Tadashi?"
[cpg cn=true]

[OnName num="tadashi"]
"I can't say I like the idea of him being around you. Plus, if we're dating, he's just going to get in the way."
[cpg cn=true]

Despite his words, Kazumi still seemed to be thinking about it.
[cpg]

[FACE method="change_7" pos="2/5"]
[VOICE f="sKazumi014"]
[OnName num="kazumi"]
"I can't make a decision.......This isn't right."
[cpg cn=true]

[OnName num="satoru"]
"I regret what I did, Kazumi. If you don't have any lingering feelings for me, then turn me down."
[cpg cn=true]

[FACE method="shake_4" pos="2/5"]
[VOICE f="Kazumi241"]
[OnName num="kazumi"]
"That's......"
[cpg cn=true]

[FACE method="bow_3" pos="2/5"]
[VOICE f="sKazumi015"]
[OnName num="kazumi"]
".......Okay, let's just go back to being friends."
[cpg cn=true]

......I knew it.
[cpg]

[OnName num="tadashi"]
"Kazumi.....!? You can't be serious, remember what he did to you!"
[cpg cn=true]

[OnName num="tadashi"]
"Am I not enough for you!?"
[cpg cn=true]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Kazumi243"]
[OnName num="kazumi"]
"I'm sorry, it's just that it's my fault that Satoru ended up like this......."
[cpg cn=true]

;//そうは言ってるが、本当は欲求不満で未練があるんだろ。
;//[cpg]

[OnName num="tadashi"]
"How can you say that....."
[cpg cn=true]

[OnName num="tadashi"]
"......If that's what you really want, I won't say anything else. I just want you to be happy."
[cpg cn=true]

It seems Tadashi couldn't assert himself as strongly when it was Kazumi's choice.
[cpg]

Although it may take some time, I should be able to turn him against her.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


We started this crazy relationship.
[cpg]

It had been twisted and bent out of shape, but things would go back to normal soon.
[cpg]

I don't mean to say that things would go back to how they were before, but rather that the twist itself would be resolved.
[cpg]

There was something about Kazumi that ignites a man's sadistic tendencies.
[cpg]

All Tadashi needed was a little push and he'd go spiralling over the edge. He'd end up just like me.
[cpg]


;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）
;//【ＢＧ】『街』（昼）******************************************************


I head to her room on the weekend.
[cpg]

I'd been thinking about my next move.
[cpg]

It all revolved around Tadashi. I needed him to recognize his hidden desires.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************


[OnName num="satoru"]
"Hey. Is Tadashi here yet?"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kazumi261"]
[OnName num="kazumi"]
"He hasn't come yet......"
[cpg cn=true]

Things were a little awkward when it was just the two of us. It makes sense, she'd rejected me once already.
[cpg]

But I wasn't about to give up just yet.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

After a little while, he finally arrives.
[cpg]


;//移植のためシーンをカットしています


[FO pos="4/7" time=1000]
[WAIT time=1000]

;//【ＢＧ】『ヒロイン２の部屋』（昼）


[OnName num="satoru"]
"Tadashi. Let me tell you something important about your girlfriend."
[cpg cn=true]

[OnName num="satoru"]
"She likes being bullied. Isn't that right, Kazumi?"
[cpg cn=true]

Saying this, I got closer to her.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="sKazumi016"]
[OnName num="kazumi"]
"What are you saying......? Nobody wants to be abused."
[cpg cn=true]


Even though she said this, she looked as if she could not reject me.
[cpg]

[OnName num="tadashi"]
"......."
[cpg cn=true]

[OnName num="satoru"]
"Doesn't it turn you on? As a man, don't you want to torment her?"
[cpg cn=true]

He didn't reply right away. But I had already decided what I was going to do.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

The three of us had lunch together. Kazumi cooked lunch.
[cpg]

The atmosphere remained tense.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=3000]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1500]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************


Afterwards, I turned to Kazumi. Of course, in front of him.
[cpg]


;//========================================
;//●ＣＧエロ（ヒロインに迫る主人公）ev_33
;//人物１：ヒロイン２
;//服装１：裸
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sKazumi017"]
[OnName num="kazumi"]
".....What are you doing?"
[cpg cn=true]


[OnName num="satoru"]
"Does it matter? All you have to do is obey me."
[cpg cn=true]


I pulled my hand back as if to slap her.
[cpg]

[VOICE f="sKazumi018"]
[OnName num="kazumi"]
"No, don't!"
[cpg cn=true]


She flinches, closing her eyes.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1500]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************


[OnName num="satoru"]
"See? That's all it takes."
[cpg cn=true]

[OnName num="satoru"]
"Can you feel your blood boiling when you see her like that?"
[cpg cn=true]

[OnName num="tadashi"]
"......I'm going home, I need time to think."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kazumi302"]
[OnName num="kazumi"]
"Go home......Satoru, if you're going to start this again, I don't want you around anymore."
[cpg cn=true]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I wasn't allowed to be around Kazumi when Tadashi wasn't around.
[cpg]

But after that day, our relationship had changed.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Kazumi303"]
[OnName num="kazumi"]
"Lately you've been acting strange Tadashi......"
[cpg cn=true]

[OnName num="tadashi"]
"......Have I?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sKazumi019"]
[OnName num="kazumi"]
"You used to be so kind to me, but lately it's almost like......"
[cpg cn=true]

He glares at Kazumi.
[cpg]

[OnName num="tadashi"]
"Shut up. All you had to do was obey me and everything would have been fine."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Kazumi305"]
[OnName num="kazumi"]
"Ah!......."
[cpg cn=true]

Tadashi swings his fist down upon her, but stops just before hitting her.
[cpg]

That alone was enough to revive Kazumi's trauma.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kazumi306"]
[OnName num="kazumi"]
"I'm sorry.......I'm sorry......."
[cpg cn=true]

;//移植のためシーンをカットしています


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


She'd chosen someone, but that someone wasn't me. I wasn't about to forgive her for that.
[cpg]

It was all her fault. She shouldn't have approached me without thinking about the consequences.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


One weekend, Tadashi and I were chatting.
[cpg]

[OnName num="tadashi"]
"I never thought we would have this kind of relationship. I don't think I had it in me."
[cpg cn=true]

[OnName num="satoru"]
"Really? I think most men have that desire, but only a few get the opportunity."
[cpg cn=true]

[OnName num="tadashi"]
"Maybe so...I wouldn't have considered it if you hadn't shown up."
[cpg cn=true]

Tadashi and I had come to an understanding.
[cpg]

He'd mentioned that he was going to go see Kazumi and offered me the opportunity to tag along.
[cpg]

So much for her knight in shining armor.
[cpg]


[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』


He rings her doorbell.
[cpg]

A frightened looking Kazumi opens the door.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kazumi325"]
[OnName num="kazumi"]
"......Oh."
[cpg cn=true]

The look on her face would have made a great picture.
[cpg]

She's grown thin and has dark circles under her eyes. I guess she hasn't been sleeping well these days.
[cpg]

But I'd learned my lesson. She'd never escape my grasp ever again.
[cpg]


;//ＥＮＤ：ヒロイン２ルート１

[SCENE id=15]

[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


