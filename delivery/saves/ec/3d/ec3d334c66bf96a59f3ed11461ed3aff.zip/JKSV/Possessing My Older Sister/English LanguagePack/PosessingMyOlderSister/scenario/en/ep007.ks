
;//==============================
;//２、愛華さんを誘拐する

;#################################################
*Ep007|Sharing Solitude
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



*select03_2|Sharing Solitude

[SCENE id=7]


......I've decided to kidnap her.
[cpg]

All of this started because I wanted her all to myself.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


On my way home, I bumped into Kazumi.
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="Kazumi142"]
[OnName num="kazumi"]
"Oh......Satoru."
[cpg cn=true]

[OnName num="satoru"]
"......"
[cpg cn=true]

Strangely, I didn't find her very attractive anymore.
[cpg]

Of course, you could say that she'd started me down this path.
[cpg]

But my attention was entirely focused on Aika at this point.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kazumi143"]
[OnName num="kazumi"]
"G-Good evening......"
[cpg cn=true]

[OnName num="satoru"]
"Good evening. There's no reason to be so frightened of me."
[cpg cn=true]

I went to my room.
[cpg]



;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


I had to prepare for what was to come.
[cpg]

I needed restraints and sleeping pills.
[cpg]

Once everything was ready, I called her over.
[cpg]


;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d2"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


Even though I was going to kidnap her, I couldn't be too reckless.
[cpg]

I couldn't force her into a car in broad daylight. I didn't have a driver's license to begin with.
[cpg]

It was more like confinement than kidnapping. Well, it doesn't matter.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Aika302"]
[OnName num="aika"]
"What is it......? Is it something a little different from the usual?"
[cpg cn=true]

[OnName num="satoru"]
"You could say that."
[cpg cn=true]

[SE f="se029"]
;//【ＳＥ】『衣擦れ』

[free time=300]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]

I quickly put a drug-soaked handkerchief over her mouth.
[cpg]


;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_hu"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


It was night when she finally awoke. I'd made sure she'd been restrained and gotten rid of her phone.
[cpg]

To ensure she couldn't escape, I'd bound both her hands and feet.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Aika303"]
[OnName num="aika"]
"Hmmm......What? Where am I......."
[cpg cn=true]

[OnName num="satoru"]
"You slept well. How are you feeling?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aika304"]
[OnName num="aika"]
"......What do you mean? What's going on....."
[cpg cn=true]


;//========================================
;//●ＣＧエロ（縛られていて、動けないヒロイン）ev_19
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="satoru"]
"You're finally mine."
[cpg cn=true]


[VOICE f="sAika010"]
[OnName num="aika"]
"What are you saying......?"
[cpg cn=true]


[OnName num="satoru"]
"Now we can live happily ever after."
[cpg cn=true]


Aika gradually began to understand the situation.
[cpg]

She turned pale, but she can't back away.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


We spend all of our time together now.
[cpg]

I rarely left my room, I had to take care of her.
[cpg]

Sometimes I removed the restraints on her legs, but I couldn't let her use her hands. I was responsible for keeping her fed and watered.
[cpg]

[OnName num="satoru"]
"Come on, open your mouth."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Aika321"]
[OnName num="aika"]
"I'm not hungry......."
[cpg cn=true]

[OnName num="satoru"]
"Don't be like that. You haven't eaten anything since yesterday."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Aika322"]
[OnName num="aika"]
"......I'd rather starve to death......."
[cpg cn=true]

[OnName num="satoru"]
"Hahaha, I don't think it'll take long for you to change your mind."
[cpg cn=true]

I took care of her while being amused.
[cpg]

;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


Aika stopped saying much.
[cpg]

[OnName num="satoru"]
"I'm going to go shopping, is there anything you want to eat?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aika343"]
[OnName num="aika"]
"......."
[cpg cn=true]

Sometimes she doesn't respond to anything I say...
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Aika344"]
[OnName num="aika"]
"I don't want this, I don't want this, I want to go home, I want to go home."
[cpg cn=true]

She sometimes begs and pleads like a child. It's adorable.
[cpg]

Of course, I don't feel sorry for her. If anything, it bolsters my resolve.
[cpg]

I feel as if I've finally dragged her down to my level.
[cpg]



[SE f="se019"]
;//【ＳＥ】『ドア閉じる』

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[OnName num="satoru"]
"I'm home. Have you been a good girl?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Aika346"]
[OnName num="aika"]
"......I want to go home......"
[cpg cn=true]

She keeps saying the same thing. Well, that's okay.
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト

She was so weak that there was no need to restrain her anymore.
[cpg]

I still thought she was cute.
[cpg]


;//========================================
;//●ＣＧエロ（弱っているヒロイン）ev_22
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_21_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="satoru"]
"I need you to keep falling until you're finally in the same place as me."
[cpg cn=true]


I wonder if she can still hear me.
[cpg]

Even if she could, I doubt she'd understand.
[cpg]

[VOICE f="sAika011"]
[OnName num="aika"]
"I can't......"
[cpg cn=true]


I felt a sense of fulfillment. She'd grown so weak.
[cpg]


;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


These days it seems like she's given up. Her reactions have fallen into a predictable pattern.
[cpg]

There's something so entertaining about watching someone's mind crumble.
[cpg]

[OnName num="satoru"]
"It's getting late. Let's go to bed, Aika."
[cpg cn=true]

Aika doesn't answer. I was fine with that.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


It was the early morning.
[cpg]

;//俺は食料やら何やら、色々買いに行くため外へ出ていた。
I decided to go out to buy food and toiletries.
[cpg]

Of course, I had to restrain Aika during that time. I've come this far, I wasn't going to make a silly mistake.
[cpg]

[OnName num="satoru"]
"Be back soon."
[cpg cn=true]

Aika doesn't say a word. I've come to adore her sullen silence.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Aika385"]
[OnName num="aika"]
"......Just kill me already."
[cpg cn=true]

[OnName num="satoru"]
"Why on earth would I do that......?"
[cpg cn=true]


[SE f="se019"]
;//【ＳＥ】『ドア閉じる』

[window target=false]
[free time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


Aika grows weaker with every passing day, but it's not enough.
[cpg]

I go out to buy lunch.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[OnName num="satoru"]
"I'm home, Aika. Let's eat."
[cpg cn=true]

I bring a bento near her and feed her.
[cpg]

No matter how she tries to resist, the body is honest. She opens her mouth when I bring food near her face.
[cpg]

She hadn't weakened to the point that she could no longer eat, but it did seem like she had trouble chewing.
[cpg]

[OnName num="satoru"]
"Do you want some water? Just let me know whenever you're thirsty."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Aika386"]
[OnName num="aika"]
"......Please......."
[cpg cn=true]

I pour water from a bottle into her mouth.
[cpg]

Of course, no matter how carefully I poured it, some would spill out of her mouth.
[cpg]


;//========================================
;//●ＣＧエロ（拘束されているヒロイン）ev_40
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_40_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]



Perhaps my methods of showing my love for her were twisted. Perhaps they were wrong. But I loved her nonetheless.
[cpg]

I don't mind if she doesn't reciprocate. Loving her was enough for me.
[cpg]

I was fine with this. Aside from her resistance, everything was perfect.
[cpg]

I was happy. If only this could last forever.
[cpg]


Aika grows weaker and weaker, but I don't care.
[cpg]

Someone who cared about their prisoner wouldn't lock them up in the first place.
[cpg]

I seem to have lost my sanity long ago. All I had left was this unsuppressable urge to drag Aika down, down...until she could finally see. See me.
[cpg]

;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se000"]
;//【ＳＥ】『パトカーのサイレン』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
;//[WAIT time=1000]
;//[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_01_1.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//
;//[BGM f="bg_op"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


Days pass without much change until one morning, a certain sound awoke me.
[cpg]


A police siren. So they've finally come for me.
[cpg]


[SE f="se024"]
;//【ＳＥ】『ドア乱暴に叩く』


[OnName num="policeman"]
"Open up! If you don't then....."
[cpg cn=true]

The officer was yelling through the door, but I didn't really pay much attention to what they were saying.
[cpg]

Resistance was futile, so I opened the door.
[cpg]

[SE f="se019"]
;//【ＳＥ】『ドア開ける』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I was quickly subdued.
[cpg]

The charged brought against me were considerable. I guess that's to be expected since I'd kidnapped and confined a woman.
[cpg]

I didn't think about it much as I waited for the consequences of my actions to come crashing down upon me.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


But for some reason, she defended me.
[cpg]

After some time, I was released. Perhaps she told them that I hadn't done anything to her.
[cpg]

I don't know why.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


Then, a relative came to pick me up.
[cpg]

We didn't talk. I guess they didn't want to either, which was convenient.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


Some time passes.
[cpg]

I went online to find out what happened to her. It didn't take long to find that her case had been all over the news.
[cpg]

I was surprised to find that the mass media doesn't treat victims like victims these days.
[cpg]

As I expected, Aika had gotten pregnant.
[cpg]

Apparently my child was being raised by her relatives.
[cpg]

I guess she couldn't abort it since she'd already lost one child.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（昼）******************************************************


I was in a daze at the park.
[cpg]

I didn't mind......
[cpg]

Aika's child would grow up without parents.
[cpg]

I was able to create someone who would experience the same solitude I did.
[cpg]

I don't know if our child is a boy or a girl, but they'll grow up feeling the same darkness that I do.
[cpg]


That was enough for me. It's not that I'd lost my love for Aika but......
[cpg]

It saved me, just a little bit.
[cpg]


;//ＢＫ



;//ＥＮＤ：ヒロイン１ルート２

[SCENE id=14]

[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


