*start|Twisted Motivation

;#################################################
*Ep003|Twisted Motivation
;#################################################

[SCENE id=3]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


It was the weekend, but since it was still summer vacation for me, that didn't really mean much.
[cpg]

[OnName num="satoru"]
"I wonder what Kazumi is doing......."
[cpg cn=true]

I was suddenly overcome by curiosity and decided to leave my room.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア開く』

[window target=false]
[free time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


I wonder how she spends her weekends. I couldn't imagine she stayed at home all the time.
[cpg]

Maybe she was sleeping in. I decided to ring the doorbell and see for myself.
[cpg]

[SE f="se000"]
;//【ＳＥ】『玄関チャイム』
[WAIT time=2000]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kazumi085"]
[OnName num="kazumi"]
"Huh......Satoru......? Is that you?"
[cpg cn=true]

As expected, a sleepy-looking Kazumi answered the door.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="sKazumi007"]
[OnName num="kazumi"]
"It's still pretty early, what's up? Did you come to see me or something?"
[cpg cn=true]

[OnName num="satoru"]
"......Pretty much....."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kazumi087"]
[OnName num="kazumi"]
"Cool. Just give me a minute, I was sleeping."
[cpg cn=true]

[free time=1000]
Kazumi returned to her room.
[cpg]

Was she the sloppy type? Maybe she made me wait so she could clean up her room?
[cpg]

I don't know......you can never truly know someone.
[cpg]

That's why I don't expect anybody to ever understand me, either.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

;//[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kazumi088"]
[OnName num="kazumi"]
"Come on in. Did you already have breakfast?"
[cpg cn=true]

[OnName num="satoru"]
"I did......."
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の部屋』（朝）******************************************************

Kazumi was eating toast.
[cpg]

Something about her feels so familiar.
[cpg]

I think she's being kind to me. That's why I want to make her obey me.
[cpg]

She is probably kind to everyone, but that's the problem. I need her to only have eyes for me.
[cpg]

Kazumi looks as if she is interested in the trivial news on TV.
[cpg]

I sit across from her, sipping at the coffee she made for me.
[cpg]

This is not the kind of relationship I'm looking for.
[cpg]

I want something more. I need something...more.
[cpg]

I was finally about to cross the line.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kazumi090"]
[OnName num="kazumi"]
"What's up, Satoru? You look so serious."
[cpg cn=true]

[OnName num="satoru"]
"Kazumi, do you have any intentions of getting remarried?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sKazumi008"]
[OnName num="kazumi"]
"Umm......You mean if I will get married to you?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kazumi092"]
[OnName num="kazumi"]
"You're still a college student, right? If I could ask you the same thing after you get a job, I might consider it."
[cpg cn=true]

She was talking to me as if I were her lover. That's not what I want.
[cpg]

[OnName num="satoru"]
"What would you do if I forced myself on you?"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kazumi094"]
[OnName num="kazumi"]
"I'd scream or call the police. Don't do that kind of thing."
[cpg cn=true]

[FADEOUTBGM]

[free time=300]
[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
I grabbed Kazumi's arm, hard.
[cpg]

[BGM f="bg_h2"]

From there, I push her down and get on top of her.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Kazumi095"]
[OnName num="kazumi"]
"......I'm going to scream, are you sure you want to do this?"
[cpg cn=true]

This was a big gamble, I had no idea if it would pay off.
[cpg]

She'd mentioned that her ex-husband had been abusive. I figured she'd be weak to violence.
[cpg]


[SE f="se009"]
;//【ＳＥ】『ビンタ』

[FACE method="shock_5" pos="2/3"]
[WAIT time=1000]


I slapped her on the cheek. I didn't have the courage to hit her.
[cpg]

But it was enough to shock Kazumi.
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="Kazumi096"]
[OnName num="kazumi"]
"S......Satoru?"
[cpg cn=true]

[OnName num="satoru"]
"All you have to do is obey me."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kazumi097"]
[OnName num="kazumi"]
"Why......what...? No!"
[cpg cn=true]


[SE f="se009"]
;//【ＳＥ】『ビンタ』
[FACE method="shock_5" pos="2/3"]
[WAIT time=1500]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kazumi098"]
[OnName num="kazumi"]
"Ahh! I'm sorry! I'm sorry!"
[cpg cn=true]

It was a lot more effective than I'd expected. As I thought, she'd been traumatized by physical violence.
[cpg]


;//========================================
;//●ＣＧエロ（背後からヒロインに近づく主人公）ev_09
;//人物１：ヒロイン２
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：ヒロイン２の部屋
;//時間　：昼
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_09_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


I felt that this was the best way to control her.
[cpg]

[VOICE f="sKazumi009"]
[OnName num="kazumi"]
"I'm sorry......Please don't hurt me."
[cpg cn=true]


I can tell that she's closed off her heart, but that was convenient.
[cpg]

I was satisfied and backed away from her.
[cpg]

She didn't get angry at me for hitting her.
[cpg]


;//移植のためシーンをカットしています
;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


All that was left was to sink my claws into Ms. Sakura. Aika and Kazumi were practically mine.
[cpg]

Ms. Sakura was the first woman I tried to dominate.
[cpg]

I already know where she lives. She probably doesn't finish work until nighttime, and her son is probably still awake.
[cpg]

I need to find out what time she'll be the only one awake.
[cpg]

I just need to threaten her in person and from there I can call her out whenever I want.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


I killed time until night fell.
[cpg]

I came to Ms. Sakura's place. I failed the other night, but this time I had an idea.
[cpg]

I needed to take a video. It's the same method as with Aika, but since she doesn't have a husband, it's would be a weaker threat.
[cpg]

But on the other hand, she has a child and a job. I decided to take advantage of that.
[cpg]

......Come to think of it, I wonder why her husband isn't around.
[cpg]

She didn't mention a divorce, but I figured there had to be a reason she was working such a rough job.
[cpg]

[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
;//ＢＫ


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sakura046"]
[OnName num="sakura"]
"......You again."
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『アパート居間（ヒロイン３の部屋）』（夜）******************************************************


Ms. Sakura-san lets me into the house. Well that was lucky.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakura047"]
[OnName num="sakura"]
"If you try anything again, I'm calling the police."
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Sakura048"]
[OnName num="sakura"]
"It's not a threat, it's a fact......"
[cpg cn=true]

[OnName num="satoru"]
"What happened to your husband? Did you get divorced?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakura049"]
[OnName num="sakura"]
"That's none of your business."
[cpg cn=true]

[OnName num="satoru"]
"Please, I really want to hear all about it."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sakura050"]
[OnName num="sakura"]
"He left me with a lot of debt. That's why I'm doing that job."
[cpg cn=true]

I knew it.
[cpg]

[OnName num="satoru"]
"I'm sure your son must be very precious to you."
[cpg cn=true]

[OnName num="satoru"]
"It would be such a pity if you had to leave your current job."
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Sakura051"]
[OnName num="sakura"]
"What are you talking about? Hey, stop it......"
[cpg cn=true]

;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


Then I restrained her and took a picture of her, just like I did with Aika.
[cpg]

Something that would make it difficult to stay if sent to her workplace.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『アパート居間（ヒロイン３の部屋）』（夜）******************************************************


[OnName num="satoru"]
"Don't try to report me or we'll both have a problem on our hands."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakura070"]
[OnName num="sakura"]
"......You're depraved......."
[cpg cn=true]

I'm inclined to agree.
[cpg]

[OnName num="satoru"]
"You must really love your son. I honestly didn't think you'd obey me so willingly."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sakura071"]
[OnName num="sakura"]
"Nothing's more important than him......I'll do anything to protect him."
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="sSakura003"]
[OnName num="sakura"]
"If I have to obey you for that, I'll put up with it."
[cpg cn=true]

[OnName num="satoru"]
"I'm glad you understand. So, do you have a cell phone?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sakura073"]
[OnName num="sakura"]
"Of course I do."
[cpg cn=true]

[OnName num="satoru"]
"Great, let's exchange numbers. I wouldn't want to drop in while your son's awake."
[cpg cn=true]

[OnName num="satoru"]
"It's a lot more convenient to be able to talk without him knowing."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Sakura074"]
[OnName num="sakura"]
"......Fine."
[cpg cn=true]

It seems that she's finally giving in. I register her as a contact.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


I walked back to my house, feeling rather good about myself.
[cpg]

I've got all of these women under my control.
[cpg]

Or rather, I've got leverage over them now.
[cpg]

Now it's just a matter of how far I can go before something breaks.
[cpg]


[jump storage="ep004.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

