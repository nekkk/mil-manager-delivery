

;//ヒロイン３ルート

;//==========================================================
;//==========================================================
;//選択肢　桜　を選択した場合
*select02_3|Troubling Ms. Sakura

[stflag Cha1flg = 0]

[if exp={getFlagValue("Cha1flg") == 1 }]
[jump target="*select05_2"]
[endif]
[jump target="*select05_1"]


*select05_2|Troubling Ms. Sakura
[jump storage="ep012.ks" target="*select05_2"]


*start|Troubling Ms. Sakura

;#################################################
*Ep011|Troubling Ms. Sakura
;#################################################

*select05_1|Troubling Ms. Sakura


[SCENE id=11]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

Today, I decided to visit Ms. Sakura at her office.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_5"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[FACE method="shock_5" pos="2/3"]
[VOICE f="Sakura100"]
[OnName num="sakura"]
"What......Satoru!? Why are you here..."
[cpg cn=true]

[OnName num="satoru"]
"I thought I'd visit you."
[cpg cn=true]

She seemed surprised to see me and naturally, she didn't seem very happy.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakura101"]
[OnName num="sakura"]
"I asked you not to come here."
[cpg cn=true]


I'd expected this, but it was a little sad to hear her say it to my face.
[cpg]

It made me want to cause trouble for her
[cpg]

[OnName num="boss"]
"Hmm? Who's that?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Sakura102"]
[OnName num="sakura"]
"Oh....no one.......I'm sorry, excuse me for a minute."
[cpg cn=true]

[OnName num="boss"]
"Alright......"
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Sakura103"]
[OnName num="sakura"]
"Come here."
[cpg cn=true]


[OnName num="satoru"]
"Wait..."
[cpg cn=true]

She pulls me by the hand and brings me to an isolated place.
[cpg]

She didn't have to act so blatantly unhappy......I wonder if she doesn't want to be seen with me.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

;//ＢＫ
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

It turned out that she took her employment seriously and was truly unamused by my showing up at her work.
[cpg]

In the end, I had to wait for her until the next day.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura147"]
[OnName num="sakura"]
"Huff.....huff."
[cpg cn=true]

[OnName num="satoru"]
"You're late, Ms. Sakura!"
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Sakura148"]
[OnName num="sakura"]
"You could have given me more time to get here......"
[cpg cn=true]

[OnName num="satoru"]
"Well, you didn't want me coming to get you at work."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sakura149"]
[OnName num="sakura"]
"This isn't going to work. I can't take time off of work that often."
[cpg cn=true]

[OnName num="satoru"]
"What did you tell them?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Sakura150"]
[OnName num="sakura"]
"......I said that Akito has a fever and I had to look in on him."
[cpg cn=true]

[OnName num="satoru"]
"So you used your own child as an excuse?"
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Sakura151"]
[OnName num="sakura"]
"What choice did I have!?.......It's all your fault....."
[cpg cn=true]

Yeah, she had a point.
[cpg]


;//ブラックアウト

[OnName num="satoru"]
"Well, why don't you start by making up for being late?"
[cpg cn=true]

;//========================================
;//●ＣＧエロ（ヒロインが主人公に近づく。脅されている）ev_43
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_43_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]


She no longer resisted me.
[cpg]

She's willing to do anything for me.
[cpg]

[VOICE f="sSakura007"]
[OnName num="sakura"]
"Please......don't ruin this job for me."
[cpg cn=true]


I had no reason to do as she asked.
[cpg]

If anything, it only made me want to cause more trouble for her.
[cpg]


;//移植のためシーンをカットしています

;//エンディング【結】

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]


Time passed. Many times, I would call her out just to amuse myself.
[cpg]

[window target=false]
[free time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=1500]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[OnName num="satoru"]
"Welcome, you're right on time."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Sakura196"]
[OnName num="sakura"]
"That's because I don't know what you'll do if I'm late......"
[cpg cn=true]

[OnName num="satoru"]
"Are you sure that's all?"
[cpg cn=true]

[FACE method="shock_7" pos="2/3"]
[VOICE f="Sakura197"]
[OnName num="sakura"]
"What?"
[cpg cn=true]

[OnName num="satoru"]
"I think you're here because you wanted to be here. Am I wrong?"
[cpg cn=true]

;//移植のためシーンをカットしています
;//ブラックアウト


[FACE method="change_4" pos="2/3"]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

She goes quiet, unable to confirm or deny my accusation.
[cpg]

There was no getting back to normal for either of us.
[cpg]

But this too, is just another form of love.
[cpg]

;//ＥＮＤ：ヒロイン３ルート１

[SCENE id=17]

[jump storage="epend.ks" target="*start"]
