

;//==============================
;//５、渚沙

;#################################################
*Ep012|Experienced Nagisa-san
;#################################################


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]


;//選択肢のジャンプ先
*select00_5|Experienced Nagisa-san

[SCENE id=12]

;//ルートフラグ
[stflag ChaRoute = 5]

I immediately thought of Nagisa.
[cpg]


In a situation like this, it is Nagisa who is the most reliable. Hazuki is still active, but Nagisa is the one with the most experience.
[cpg]


[SE f="se007"]
;//【ＳＥ】『道走る』


;//ブラックアウト

[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************



I headed toward the shrine, out of breath.
[cpg]


Something was still chasing after me.
[cpg]


And even during my escape, there were things unnaturally falling down and blocking my way.
[cpg]


If it can do this from a distance. I don't know what would happen if it caught up with me.
[cpg]


[OnName num="zen"]
“if only Nagisa were here...."
[cpg cn=true]

[SE f="se007"]
;//【ＳＥ】『道走る』


[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『神社の境内』（夕方）******************************************************

And then I reach the shrine.
[cpg]


[OnName num="zen"]
“Nagisa! Are you here?”
[cpg cn=true]


I call out loudly while running.
[cpg]


But by the time Nagisa appeared, I was…..
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nagisa058"]
[OnName num="nagisa"]
“What's wrong, Zen? You look pale……."
[cpg cn=true]


When she appeared, the thing was no longer coming after me.
[cpg]


[OnName num="zen"]
"Oh, that ...... is strange."
[cpg cn=true]


Is it because I am in the precincts of a shrine? I told Nagisa what had happened to me.
[cpg]


Nagisa listened to my story without doubting me. And then,
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Nagisa059"]
[OnName num="nagisa"]
“I can’t believe that happened to you. It doesn't seem to be just a curse.”
[cpg cn=true]


She said the same thing I was thinking.
[cpg]


[OnName num="zen"]
“Yes. I really wonder what it was.”
[cpg cn=true]



[SE f="se004"]
;//【ＳＥ】『道歩く』

And then Hazuki came in. I turned to the direction of the footsteps.
[cpg]

[free time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/5" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Hazuki165"]
[OnName num="hazuki"]
“Zen...... Did something happen?”
[cpg cn=true]


[OnName num="zen"]
“Well. I was being chased by something like a curse or a Yokai or something.”
[cpg cn=true]



;//ブラックアウト


We got Hazuki involved and the three of us talked about it together.
[cpg]

[FACE method="change_3" pos="4/5"]

But in the end, no conclusion was reached as to what it was.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

[OnName num="zen"]
“I'm home.……"
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane213"]
[OnName num="takane"]
“Welcome back! You're back home late. I was worried.”
[cpg cn=true]


[OnName num="zen"]
“It was a disaster. I'm tired from running.”
[cpg cn=true]


I'd better tell Takane all about it. I was tired, but decided to do so.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

The next morning. I knew I had a problem if something like that was on the loose, but I couldn't do anything about it.
[cpg]


I had a life of my own, and I couldn't just leave the store.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Midori168"]
[OnName num="midori"]
"What a strange creature. I want to investigate too.”
[cpg cn=true]


Midori came to the store. I told her as much as I could about what had happened that day, but I wondered how much she understood.
[cpg]


[OnName num="zen"]
“You should not go after it. I feel a danger.”
[cpg cn=true]


[FACE method="shake_3" pos="4/5"]
[VOICE f="Midori169"]
[OnName num="midori"]
“But if that's the case, I can't leave it alone.”
[cpg cn=true]


That was a good argument. But I didn't want Midori to get involved.
[cpg]


[OnName num="zen"]
“In any case, it is better not to look for it while you do not know what to do when you encounter it.”
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Midori170"]
[OnName num="midori"]
“I doubt that.……"
[cpg cn=true]


[FACE method="bow_3" pos="2/5"]
[VOICE f="Takane214"]
[OnName num="takane"]
“I think so too. If something happens to you Midori, I think my master would be very sad."
[cpg cn=true]


Midori seemed to have finally given up after being told by Takane .
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

Then, in the evening. After Midori left.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_02_a.ui" method="change_6"  pos="4/5" time=800]
[VOICE f="Nagisa060"]
[OnName num="nagisa"]
“Good evening."
[cpg cn=true]


An unexpected visitor. Nagisa came to visit the store.
[cpg]


[OnName num="zen"]
"What's wrong ......?"
[cpg cn=true]


I asked her, but I felt something had changed in Nagisa.
[cpg]


She is more sexy than usual…. though I shouldn't think this way about Hazuki's mother.
[cpg]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Takane215"]
[OnName num="takane"]
“Nagisa. What’s going on?”
[cpg cn=true]


Takane doesn't seem to have noticed the change.
[cpg]


Or was that not the case? Was I the one seeing things differently?
[cpg]


[FACE method="bow_6" pos="4/5"]
[VOICE f="Nagisa061"]
[OnName num="nagisa"]
“Do you have time Zen."
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p5_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

I asked Takane to watch the store. I'm alone with Nagisa in my room.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagisa062"]
[OnName num="nagisa"]
"I wonder if you've noticed. I seem to be under a curse.”
[cpg cn=true]


[OnName num="zen"]
"Indeed, ...... you look somewhat different from usual."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Nagisa063"]
[OnName num="nagisa"]
“Takane didn’t notice right? I already know the reason.”
[cpg cn=true]


According to her, Nagisa was under a curse that affects someone other than the person herself.
[cpg]


The curse was attracting the men around her.
[cpg]


[OnName num="zen"]
“Is there such a thing?”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagisa064"]
[OnName num="nagisa"]
“I think you already know. You told me that I was different from usual. Although I don't feel anything.”
[cpg cn=true]


So that's what it is. I knew I was seeing things differently.
[cpg]


But if that's the case, even if it doesn't directly affect Nagisa, it's still a dangerous curse.
[cpg]


[OnName num="zen"]
“Why did you come to me?”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nagisa065"]
[OnName num="nagisa"]
“I thought you were the safest choice. If you knew that I was Hazuki's mother, you won't do anything reckless.”
[cpg cn=true]


I see. Even if the other Onmyoji may exorcise it with blood, that doesn't necessarily mean that they won't do anything to her.
[cpg]


Right now, Takane is not here. It would be better to make this quick.
[cpg]


[OnName num="zen"]
“….. I understand.”
[cpg cn=true]


;//選択肢のジャンプ先
*select05_2_0|Experienced Nagisa-san

;//■選択肢

[switch]
[case "Kiss her lips"]
	[swap]
	[jump target="*select05_2_1"]
[case "I kiss her neck."]
	[swap]
	[jump target="*select05_2_2"]
[endswitch]

1. Kiss her lips
2. Kiss her neck

;//==============================
;//１、唇に口づける

;//選択肢のジャンプ先
*select05_2_1|Experienced Nagisa-san

[OnName num="zen"]
“I don't know the reason behind this curse, but ...... so far, it's been effective close to the head."
[cpg cn=true]

Saying this, I move closer to her.
[cpg]


;//ブラックアウト
;//========================================
;//●ＣＧ（キスを待っているヒロイン）ev_47
;//人物１：ヒロイン５　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：夕方
;//時間　：主人公の部屋
;//備考　：ぶっかけであることを強調するために、可能であれば射精後飲み込むまでは口を開いている感じにしてください
;//備考　：オリジナル特典10.jpgのシーンです
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_47_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Nagisa066"]
[OnName num="nagisa"]
“I'll leave it up to you to decide what to do. Do what you want to do, Zen.”
[cpg cn=true]


I can't do nothing when she says that to me.
[cpg]

I move so close to her that I can feel her breath on me as she waits for me to kiss her on the mouth.
[cpg]


;**【ＣＧ】 ev_47_a ***********************
[CG id=15 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Nagisa067"]
[OnName num="nagisa"]
“Do it……”
[cpg cn=true]


She closed her eyes and waited for me to do something.
[cpg]

And I respond to break the curse.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p5_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



But it seems that the curse has not been lifted.
[cpg]

Is it because of the effect it has on others?
[cpg]

;//この選択肢を除いて、もう一度同じ分岐へ戻る

;//■選択肢

[stflag Cha5flg = -1]

[switch]
[case "Kiss her neck"]
	[swap]
	[jump target="*select05_2_2"]
[endswitch]

[jump target="*select05_2_0"]

;//==============================
;//２、頬に口づける

;//選択肢のジャンプ先
*select05_2_2|Experienced Nagisa-san


[OnName num="zen"]
"I heard that in foreign countries there is a word called ‘pheromone’."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagisa068"]
[OnName num="nagisa"]
“Pheromone? What does it mean?”
[cpg cn=true]


[OnName num="zen"]
"They say it's used to deceive the opposite sex, but if it's overdeveloped..."
[cpg cn=true]


[OnName num="zen"]
“If it's overdeveloped, then there could be a curse nestled in the place where it's produced......"
[cpg cn=true]


It's quite a drastic logic, but Nagisa seemed convinced.
[cpg]


[OnName num="zen"]
「汗を掻く場所……例えば首筋とか、そんな場所になってくると思います」
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nagisa069"]
[OnName num="nagisa"]
“Yes, good. If only this curse could be broken."
[cpg cn=true]


She seemed to accept, so I nodded.
[cpg]


;//移植のためシーンをカットしています

Then I kissed her neck.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p5_02_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

In the end, the curse seemed to be properly lifted, and we had an awkward time after that.
[cpg]


Neither of us could say anything. It was that kind of time.
[cpg]



;//分岐ループから抜ける
;//[jump target="*select05_2_4"]

;//==============================

;//選択肢のジャンプ先
*select05_2_4|The experienced Nagisa

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/5" time=1]
[FG f="CHA05_p3_02_a.ui" method="change_6"  pos="4/5" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

[FACE method="bow_4" pos="2/5"]
[VOICE f="Takane216"]
[OnName num="takane"]
“Ah, you two ...... um, welcome back."
[cpg cn=true]


Takane acts strange.
[cpg]


Nagisa is also silent. It's not that the attitude is strange.
[cpg]


The reason is that even though it was to break the curse, I did this with Hazuki's mother again.
[cpg]


......It may be difficult to remain friends with Hazuki from now on.
[cpg]



;//ブラックアウト



But still, I was attracted to Nagisa.
[cpg]


I know it's not a normal love affair.
[cpg]


I went to Hazuki's house many times to see Nagisa.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿居間』（昼）******************************************************

[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p5_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Hazuki166"]
[OnName num="hazuki"]
“You've been coming to our house a lot lately, haven't you?”
[cpg cn=true]


[OnName num="zen"]
“Yeah, well..."
[cpg cn=true]


I tried not to tell her the truth.
[cpg]


I did not want to break the friendship. But that doesn't stop me from having feelings for ...... Nagisa.
[cpg]


[FACE method="change_2" pos="4/5"]
[VOICE f="Nagisa070"]
[OnName num="nagisa"]
“It's good to have you here to brighten Hazuki's mood.”
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Hazuki167"]
[OnName num="hazuki"]
“Well, that’s normal since we're close friends.”
[cpg cn=true]


If Hazuki had a liking for me.
[cpg]


Thinking that made me feel bitter. But in the end, I couldn't say anything.
[cpg]



;//ジャンプ先指定
;//総合ルートへ
;//[jump target="*select00_0"]

[jump storage="ep013.ks" target="*select00_0"]
