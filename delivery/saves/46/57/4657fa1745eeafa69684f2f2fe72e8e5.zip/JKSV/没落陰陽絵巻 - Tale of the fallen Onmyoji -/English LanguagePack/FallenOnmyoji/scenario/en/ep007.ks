

*start

;#################################################
*Ep007|The harbinger of a great battle
;#################################################

[SCENE id=7]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

With the new method, the curse was gradually suppressed.
[cpg]


Now if someone close to me is under a new curse, I can exorcise it with blood, not my saliva......
[cpg]


[FG f="CHA01_p5_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Hazuki112"]
[OnName num="hazuki"]
“Hello. You look kind of pale."
[cpg cn=true]


[OnName num="zen"]
"Oh, ...... Hazuki."
[cpg cn=true]


It was thought that blood could be used to exorcise the curse, but found out I did not have enough blood in my veins.
[cpg]


[OnName num="zen"]
“I tried a new way to break the curse, but it didn't work.”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Hazuki113"]
[OnName num="hazuki"]
“Really? I'm fine with the old way.”
[cpg cn=true]


She says things that makes me wonder what she means.
[cpg]


But I was in such an anemic state that I couldn't even think well.
[cpg]


If something happened to someone close to me from now on, I would have to kiss that person......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

There had been a considerable change in myself. Not so much my body, but my situation.
[cpg]


I am finally in a position where I can express my opinion. I couldn't before, so it's a big change.
[cpg]


However, my days are passing as usual.
[cpg]


I receive consultations about Yokai and curses, I solve them, and get paid for my work. I make my daily living by repeating this process.
[cpg]


And it is not that everything is the same as before ......, there are of course some differences.
[cpg]

[FG f="CHA02_p5_02_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="onmyoji_A"]
"It is strange that the bloodline of the Onmyoji is strong against curses."
[cpg cn=true]


[OnName num="onmyoji_B"]
“Did they become so by necessity?”
[cpg cn=true]


[OnName num="zen"]
“It may be that those with a strong constitution against curses chose the path of Onmyoji.”
[cpg cn=true]


I receive advice from my colleagues. I noticed that there were more and more people gathered around me.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Midori100"]
[OnName num="midori"]
“It could be the other way around. Maybe people with a constitution susceptible to curses, in other words, who may become a Yokai, gave up on being an Onmyoji."
[cpg cn=true]


Of course, Hazuki and Midori often visit the store.
[cpg]


Little by little, I sensed that the ingredients for getting the results were coming together.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************

[SE f="se004"]
;//【ＳＥ】『道歩く』

I also started visiting the shrine office, where they are working out countermeasures for the curse.
[cpg]


Of course, I don't work for free. In fact ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ri"]
[WAIT time=100]
;//【ＢＧ】『社務所室内』（夕方）******************************************************

[OnName num="chief_priest"]
“The money is for you, from the boss. Please accept it."
[cpg cn=true]


[OnName num="zen"]
"Oh no...... I didn’t do ...... anything."
[cpg cn=true]


Apparently, there was a reward for being the one who found a way to break the curse.
[cpg]


It's not a lot of money, but it's a good amount of money for me.
[cpg]


[OnName num="chief_priest"]
“No, it's not even that much.”
[cpg cn=true]


[OnName num="zen"]
“I wonder if that's true.”
[cpg cn=true]


But I did feel a sense of satisfaction. I was sure that I would be able to continue with this.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


The next day, a day off.
[cpg]


I didn’t think it was right to just save up this money or use it only for myself.
[cpg]


I was going to invite Hazuki, Midori, and Sakuya to dinner.
[cpg]


[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町外れ』（夕方）******************************************************

[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakuya049"]
[OnName num="sakuya"]
“What? What do you want?"
[cpg cn=true]


[OnName num="zen"]
“Well. I wanted to pay you back for helping me investigate the curse.”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakuya050"]
[OnName num="sakuya"]
“I didn't do anything though.”
[cpg cn=true]


Sakuya rejects, but as for me, I wanted her to come.
[cpg]


[OnName num="zen"]
“It's a celebration, so I'd like you to come if you can.……"
[cpg cn=true]


[FACE method="shock_2" pos="2/3"]
[VOICE f="Sakuya051"]
[OnName num="sakuya"]
"Will there be alcohol? If so, I'll come.”
[cpg cn=true]


She is a simple person. But it was very like her.
[cpg]


[OnName num="zen"]
"Yes. If I do, will you come?”
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
She smiled and nodded. Okay, that's everyone.
[cpg]



[SE f="se004"]
;//【ＳＥ】『道歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

I was back in the store with my guests.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Takane144"]
[OnName num="takane"]
“Welcome back, master."
[cpg cn=true]


Takane is serving the food. Hazuki is cooking for us in the kitchen.
[cpg]


Hazuki is a good cook, which was unexpected.
[cpg]


[OnName num="zen"]
“I’m sorry for making you cook, although you’re my guest.”
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Hazuki114"]
[OnName num="hazuki"]
“No worries. I want to do it.”
[cpg cn=true]


I said nothing more.
[cpg]


I was more concerned about the fact that Midori was acting different than usual.
[cpg]


[OnName num="zen"]
“Midori, you seem kind of grumpy."
[cpg cn=true]

[free time=1000]
[FG f="CHA02_p5_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Midori101"]
[OnName num="midori"]
“No, not really.”
[cpg cn=true]


She is not a good cook.
[cpg]


She seemed like she was not able to contribute to anything.
[cpg]

[free time=1000]
[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Sakuya052"]
[OnName num="sakuya"]
“Am I allowed to eat, too?"
[cpg cn=true]


Sakuya has already been drinking. She was saying something about how an empty stomach makes you drunk faster.
[cpg]


[OnName num="zen"]
“Yes. That's why I invited you.”
[cpg cn=true]


Sakuya is always smiling, but today she seemed to be at ease from the bottom of her heart.
[cpg]


Everyone is an important friend to me. I want to treat them all equally.
[cpg]


I don't know if they feel the same way, but I will find out.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


And so the celebration began.
[cpg]


[BG f="b_09_4.ui" time=1000]
[WAIT time=2000]

;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

[OnName num="zen"]
“Bon appétit!”
[cpg cn=true]


The small celebration began. Sakuya ate the most and Midori the least.
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Hazuki115"]
[OnName num="hazuki"]
“..... What's wrong? You're not eating."
[cpg cn=true]


Hazuki looked at Midori and then she looked away.
[cpg]


[FACE method="shake_3" pos="4/5"]
[VOICE f="Midori102"]
[OnName num="midori"]
“You made it. I won't eat it.”
[cpg cn=true]


Midori is being hostile to Hazuki, but it was not like that the other way around.
[cpg]

[free time=1000]

[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Takane145"]
[OnName num="takane"]
“I made it too. Please eat it before it gets cold.”
[cpg cn=true]


Takane pushed her to eat and Midori gave up.
[cpg]

[free time=1000]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Midori103"]
[OnName num="midori"]
“….. I guess.”
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[WAIT time=1000]
[FACE method="bow_7" pos="4/5"]
[WAIT time=1000]
[FACE method="bow_2" pos="2/5"]
I feel that Hazuki and Midori, who were on bad terms, are changing little by little.
[cpg]

[free time=1000]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Takane146"]
[OnName num="takane"]
“By the way, those ears, are they real?”
[cpg cn=true]


Takane is talking to Sakuya. Sakuya seems to be very drunk already.
[cpg]


[FACE method="change_2" pos="4/5"]
[VOICE f="Sakuya053"]
[OnName num="sakuya"]
“You are also a Shikigami and you doubt that? If you want, you can touch it.”
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
[WAIT time=1000]
[FACE method="bow_1" pos="2/5"]
[WAIT time=1000]
[FACE method="change_2" pos="2/5"]
The two seem to hit it off because they are Yokai & Shikigami.
[cpg]


[free time=1000]
[OnName num="zen"]
“But about the rat that possessed the curse the other day ……"
[cpg cn=true]


[OnName num="zen"]
“I don't know what I'll do now. I feel sorry if we leave it as a Yokai."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]

When we were talking about this, Takane said, "Why don't you turn it into a Shikigami?”
[cpg]



[OnName num="zen"]
If you made him a ...... Yokai, then you can make him a shikigami. We can even use him as a helper."
[cpg cn=true]

[free time=1000]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="4/5" time=800]

“Takane is a senior shikigami, isn't she?”, Sakuya jokes.
[cpg]

[FACE method="shake_7" pos="2/5"]
[FACE method="bow_2" pos="4/5"]

It's kind of a peaceful time. I naturally smiled.
[cpg]

[FACE method="bow_2" pos="2/5"]

Without a doubt, the results of my efforts are bearing fruit.
[cpg]

[free time=1000]
[WAIT time=1000]

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p3_02_a.ui" method="change_5"  pos="4/5" time=800]


Not that I'm dating anyone, I don't know how long these days will last.......
[cpg]

[FACE method="change_2" pos="2/5"]
[FACE method="shake_1" pos="4/5"]


They may all have different personalities, but they are all attractive women. I suddenly thought of that.
[cpg]


;//妙鐘と佐久夜も参加
[free time=1000]
If I make it as a Onmyoji, I want to have a family next .......
[cpg]

I don't think it's something I should be thinking about at a time like this. I was chatting with everyone while thinking this.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[free time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=1000]




After the party was over, everyone except for Takane went back to their homes.
[cpg]


I have to open the store again tomorrow. So I decided to take the rest of the day off.
[cpg]



[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大通り』（昼）******************************************************

And then... Kinoto's condition changed little by little.
[cpg]


Even though the curse did not decrease visibly, a solution was found.
[cpg]


It seemed that once the curse was gone, Kinoto would go back to the old Kinoto again .......
[cpg]


But that didn't mean that everything would resolve itself.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ri"]
[WAIT time=100]
;//【ＢＧ】『社務所室内』（昼）******************************************************



[OnName num="onmyoji_A"]
“......What is it with that rat?"
[cpg cn=true]


[OnName num="zen"]
“It's a Shikigami. It can at least carry tea for you.”
[cpg cn=true]


[OnName num="onmyoji_B"]
“A rat Shikigami. How strange. Or perhaps you are strange from the start.”
[cpg cn=true]


I was a little proud of it. I wanted to show everyone the proof that my experiment had been a success.
[cpg]


[OnName num="chief_priest"]
“Let's get back to the main topic. We're not talking about Shikinami now.”
[cpg cn=true]


[OnName num="zen"]
“Yes, I know. It is a new curse, isn't it?”
[cpg cn=true]


“New” might not be the right word.
[cpg]


Something different in nature from the previous curses had been confirmed. At the meeting that day, I learned about it for the first time.
[cpg]


[OnName num="chief_priest"]
“I don't even know if we can call it a curse,  since it works so differently. Maybe it's a new kind of monster.”
[cpg cn=true]


[OnName num="onmyoji_B"]
“We’re in trouble. We had just found the solution.”
[cpg cn=true]


[OnName num="onmyoji_A"]
“The fact that the effects are different suggests that the method of extermination is also completely different.”
[cpg cn=true]


In the past, most of the curses had been love related symptoms.
[cpg]


However, this time it is completely different. What the curse brought to human beings was death.
[cpg]


I listened to the story in silence. ....
[cpg]


[OnName num="onmyoji_A"]
“I can't think of anything we can do about it.”
[cpg cn=true]


[OnName num="chief_priest"]
“But if we don't exterminate them, the number of victims will increase.”
[cpg cn=true]


[OnName num="zen"]
“It's not peaceful.”
[cpg cn=true]


[OnName num="onmyoji_A"]
“We don't know all the details, but the death toll is already high.”
[cpg cn=true]


[OnName num="onmyoji_B"]
“We are not sure yet. We don't even know what caused it.”
[cpg cn=true]


[OnName num="onmyoji_A"]
“It's as if it's been confirmed. Things close to you fall unnaturally, fires starting suddenly......"
[cpg cn=true]


As he said, many of the conditions seem to be accidental deaths.
[cpg]


However, when you narrow down the location, it is not a coincidence. It is happening too frequently in close proximity.
[cpg]



;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


I have more things to deal with.
[cpg]


I was trying to calm down, even though I was feeling a bit uneasy.
[cpg]


However, a new curse ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『神社の境内』（夕方）******************************************************

[OnName num="zen"]
"Have you heard about this ...... from Nagisa?”
[cpg cn=true]


I immediately asked Hazuki, but she didn't seem to know.
[cpg]



[FACE method="shake_1" pos="2/3"]
[VOICE f="Hazuki116"]
[OnName num="hazuki"]
“No. This is the first time I've heard of it."
[cpg cn=true]


Nagisa probably doesn’t want to make her daughter worry.
[cpg]


We are facing such a dangerous monster. She is aware of that.
[cpg]


If that's the case, I must have been a little careless as a friend.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hazuki117"]
[OnName num="hazuki"]
“I'm sure it's not something a human being can do. If that's the case, then ……"
[cpg cn=true]


This is also the work of a curse or a Yokai. It is my role to investigate.
[cpg]


The Onmyoji and priests who were at the meeting were all people of high rank. So, I should be the one to do it.
[cpg]


[SE f="se004"]
;//【ＳＥ】「道を歩く」


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************

I headed out to investigate immediately. I didn't dare bring Hazuki along.
[cpg]


If I am going to confront a dangerous entity, it is better to minimize the victims as much as possible.
[cpg]


If it's true, it would be better to prepare for danger with a large number of people.....
[cpg]


I didn't want to put Hazuki in danger.
[cpg]




[window target=false]
[BG f="b_10_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『路地裏』（夕方）******************************************************

Based on the victim's testimony, I headed where the phenomenon occurred.
[cpg]


A back alley that could be anywhere. But there have been a number of accidents near here.
[cpg]

[FADEOUTBGM]

[OnName num="zen"]
"......?"
[cpg cn=true]


And there it was. I found it much more easily than I had imagined.
[cpg]





[SE f="se019"]
;//【ＳＥ】『呪い現れる　低いシンセ系の音』

There's something around the corner. It's here.
[cpg]


If it was a curse, it would be strange to say it was there. Still, I could vaguely see the figure.
[cpg]


However, the body is not so clearly recognizable as a Yokai.
[cpg]


A black figure, or a smoke ……? It was approaching me.
[cpg]


[OnName num="zen"]
"Is this a bad ……?"
[cpg cn=true]


It brings death. No one knows how.
[cpg]


Even though I knew I should investigate, I somehow had a hunch that the opponent was hostile.
[cpg]


Maybe it realizes that I am trying to investigate.
[cpg]


I quickly turn around and run away.
[cpg]

[BGM f="bg_ba"]

[SE f="se007"]
;//【ＳＥ】『道走る』

I run. I run as fast as I can.
[cpg]


I didn't look back, but the distance between this thing doesn't seem to be widening at all.
[cpg]


If it's like a curse, does it ever get tired? If so, I can't keep running like this.
[cpg]


[SE f="se020"]
;//【ＳＥ】『重い物が倒れる』

And I couldn't shake it off by just running straight forward.
[cpg]


[OnName num="zen"]
"What is it……!? I used this road when I came here."
[cpg cn=true]


On the way to escape, things fell from high places, and the way out was unnaturally blocked......
[cpg]


No matter how I think, the things happening were being done by something that was chasing me.
[cpg]


It was as if they were manipulating my misfortune. It's hard to put into words, but that's what was happening.
[cpg]



[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大通り』（夕方）******************************************************

I thought that if I went out to the main street, it wouldn't chase me, but it did.
[cpg]


It was chasing only me. I guess it thinks I’m trying to investigate them.
[cpg]

I could tell it was trying to crush me thoroughly. Even if other people pass by, it only comes after me.
[cpg]


In addition, it's almost night and not many people are on the street. Even if there were some, I don't think an average person would be able to compete with them.
[cpg]


If I don't get help from someone, I'm going to be outgunned. If someone were to help me, who would it be?
[cpg]


Hazuki and Nagisa are shrine Miko, and Midori is a Onmyoji, so they would be able to help.
[cpg]


Sakuya and Takane are also Yokai and I could probably rely on them.
[cpg]


I quickly thought about who to go to for help and came up with an answer.
[cpg]


;//※　ヒロイン１以外の選択肢は、一度で呪いを解けていない場合選択肢に出てこない
;//■選択肢
;//五人
[if exp={getFlagValue("Cha2flg") == 2 }]
[if exp={getFlagValue("Cha3flg") == 2 }]
[if exp={getFlagValue("Cha4flg") == 2 }]
[if exp={getFlagValue("Cha5flg") == 2 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Midori"]
	[swap]
	[jump target="*select00_2"]
[case "Sakuya"]
	[swap]
	[jump target="*select00_3"]
[case "Takane"]
	[swap]
	[jump target="*select00_4"]
[case "Nagisa"]
	[swap]
	[jump target="*select00_5"]
[endswitch]
[endif]
[endif]
[endif]
[endif]
;//四人
;//１、２、３、４
[if exp={getFlagValue("Cha2flg") == 2 }]
[if exp={getFlagValue("Cha3flg") == 2 }]
[if exp={getFlagValue("Cha4flg") == 2 }]
[if exp={getFlagValue("Cha5flg") == 1 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Midori"]
	[swap]
	[jump target="*select00_2"]
[case "Sakuya"]
	[swap]
	[jump target="*select00_3"]
[case "Takane"]
	[swap]
	[jump target="*select00_4"]
[endswitch]
[endif]
[endif]
[endif]
[endif]

;//１、２、３、５
[if exp={getFlagValue("Cha2flg") == 2 }]
[if exp={getFlagValue("Cha3flg") == 2 }]
[if exp={getFlagValue("Cha4flg") == 1 }]
[if exp={getFlagValue("Cha5flg") == 2 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Midori"]
	[swap]
	[jump target="*select00_2"]
[case "Sakuya"]
	[swap]
	[jump target="*select00_3"]
[case "Nagisa"]
	[swap]
	[jump target="*select00_5"]
[endswitch]
[endif]
[endif]
[endif]
[endif]
;//１、２、４、５
[if exp={getFlagValue("Cha2flg") == 2 }]
[if exp={getFlagValue("Cha3flg") == 1 }]
[if exp={getFlagValue("Cha4flg") == 2 }]
[if exp={getFlagValue("Cha5flg") == 2 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Midori"]
	[swap]
	[jump target="*select00_2"]
[case "Takane"]
	[swap]
	[jump target="*select00_4"]
[case "Nagisa"]
	[swap]
	[jump target="*select00_5"]
[endswitch]
[endif]
[endif]
[endif]
[endif]
;//１、３、４、５
[if exp={getFlagValue("Cha2flg") == 2 }]
[if exp={getFlagValue("Cha3flg") == 1 }]
[if exp={getFlagValue("Cha4flg") == 2 }]
[if exp={getFlagValue("Cha5flg") == 2 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Sakuya"]
	[swap]
	[jump target="*select00_3"]
[case "Takane"]
	[swap]
	[jump target="*select00_4"]
[case "Nagisa"]
	[swap]
	[jump target="*select00_5"]
[endswitch]
[endif]
[endif]
[endif]
[endif]
;//三人
;//１、２、３
[if exp={getFlagValue("Cha2flg") == 2 }]
[if exp={getFlagValue("Cha3flg") == 2 }]
[if exp={getFlagValue("Cha4flg") == 1 }]
[if exp={getFlagValue("Cha5flg") == 1 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Midori"]
	[swap]
	[jump target="*select00_2"]
[case "Sakuya"]
	[swap]
	[jump target="*select00_3"]
[endswitch]
[endif]
[endif]
[endif]
[endif]
;//１、２、４
[if exp={getFlagValue("Cha2flg") == 2 }]
[if exp={getFlagValue("Cha3flg") == 1 }]
[if exp={getFlagValue("Cha4flg") == 2 }]
[if exp={getFlagValue("Cha5flg") == 1 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Midori"]
	[swap]
	[jump target="*select00_2"]
[case "Takane"]
	[swap]
	[jump target="*select00_4"]
[endswitch]
[endif]
[endif]
[endif]
[endif]
;//１、２、５
[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 0 }]
[if exp={getFlagValue("Cha4flg") == 0 }]
[if exp={getFlagValue("Cha5flg") == 1 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Midori"]
	[swap]
	[jump target="*select00_2"]
[case "Nagisa"]
	[swap]
	[jump target="*select00_5"]
[endswitch]
[endif]
[endif]
[endif]
[endif]

;//１、３、４
[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 2 }]
[if exp={getFlagValue("Cha4flg") == 2 }]
[if exp={getFlagValue("Cha5flg") == 1 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Sakuya"]
	[swap]
	[jump target="*select00_3"]
[case "Takane"]
	[swap]
	[jump target="*select00_4"]
[endswitch]
[endif]
[endif]
[endif]
[endif]
;//１、３、５
[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 2 }]
[if exp={getFlagValue("Cha4flg") == 1 }]
[if exp={getFlagValue("Cha5flg") == 2 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Sakuya"]
	[swap]
	[jump target="*select00_3"]
[case "Nagisa"]
	[swap]
	[jump target="*select00_5"]
[endswitch]
[endif]
[endif]
[endif]
[endif]

;//１、４、５
[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 1 }]
[if exp={getFlagValue("Cha4flg") == 2 }]
[if exp={getFlagValue("Cha5flg") == 2 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Takane"]
	[swap]
	[jump target="*select00_4"]
[case "Nagisa"]
	[swap]
	[jump target="*select00_5"]
[endswitch]
[endif]
[endif]
[endif]
[endif]

;//二人
;//１、２
[if exp={getFlagValue("Cha2flg") == 2 }]
[if exp={getFlagValue("Cha3flg") == 1 }]
[if exp={getFlagValue("Cha4flg") == 1 }]
[if exp={getFlagValue("Cha5flg") == 1 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Midori"]
	[swap]
	[jump target="*select00_2"]
[endswitch]
[endif]
[endif]
[endif]
[endif]
;//１、３
[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 2 }]
[if exp={getFlagValue("Cha4flg") == 1 }]
[if exp={getFlagValue("Cha5flg") == 1 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Sakuya"]
	[swap]
	[jump target="*select00_3"]
[endswitch]
[endif]
[endif]
[endif]
[endif]
;//１、４
[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 1 }]
[if exp={getFlagValue("Cha4flg") == 2 }]
[if exp={getFlagValue("Cha5flg") == 1 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Takane"]
	[swap]
	[jump target="*select00_4"]
[endswitch]
[endif]
[endif]
[endif]
[endif]
;//１、５


[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 1 }]
[if exp={getFlagValue("Cha4flg") == 1 }]
[if exp={getFlagValue("Cha5flg") == 2 }]
[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[case "Nagisa"]
	[swap]
	[jump target="*select00_5"]
[endswitch]
[endif]
[endif]
[endif]
[endif]


[switch]
[case "Hazuki"]
	[swap]
	[jump target="*select00_1"]
[endswitch]




1, Hazuki
2, Midori
3, Sakuya
4, Takane
5. Nagisa



*select00_1|A harbinger of a great battle.
[jump storage="ep008.ks" target="*select00_1"]

*select00_2|A harbinger of a great battle.
[jump storage="ep009.ks" target="*select00_2"]

*select00_3|A harbinger of a great battle.
[jump storage="ep010.ks" target="*select00_3"]

*select00_4|A harbinger of a great battle.
[jump storage="ep011.ks" target="*select00_4"]

*select00_5|A harbinger of a great battle.
[jump storage="ep012.ks" target="*select00_5"]
