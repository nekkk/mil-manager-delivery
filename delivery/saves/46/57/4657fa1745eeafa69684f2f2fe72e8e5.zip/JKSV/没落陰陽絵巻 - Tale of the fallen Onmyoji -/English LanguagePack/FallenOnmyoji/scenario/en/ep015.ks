
;//二回目のお祓いを、一度で成功させていた場合下記のシナリオを追加

;#################################################
*Ep015|Two of a Kind
;#################################################


;//選択肢のジャンプ先
*select01_1|Two of a Kind

[SCENE id=15]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuru.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuru.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大通り』（昼）******************************************************

A few more years passed. Not an easy thing to say......
[cpg]


But compared to the time of the plague fiasco, the daily difficulties were nothing.
[cpg]


And I guess that confidence gave me a boost, and I rose in status as a Onmyoji.
[cpg]


[OnName num="zen"]
“I never thought I would be in a position ...... to be asked to teach….. I was nervous.”
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki192"]
[OnName num="hazuki"]
“I think it was good though. It's nice to see your skill is spreading.”
[cpg cn=true]


Earlier, I had just given a course to young Onmyoji.
[cpg]


Hazuki is still in my life. And ......
[cpg]


[OnName num="zen"]
“I don't know. There are many parts of my skill that even I can't explain."
[cpg cn=true]


My skill has become a kind of mix of ideas that are not logical.
[cpg]


Without understanding their principles, I incorporate mysterious things such as feng shui and the Japanese calendar's six labels.
[cpg]


I had lost my resistance to things that would have been unthinkable in the past.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Hazuki193"]
[OnName num="hazuki"]
“I wonder, what kind of change of heart it was that made you believe the irrational.”
[cpg cn=true]


Hazuki said, perhaps seeing through me.
[cpg]


[OnName num="zen"]
“You know what I mean. I'm the one who learned all those things from you.”
[cpg cn=true]


I was thinking back to the days when I was still a no one, arguing with Hazuki.
[cpg]


It is obvious that I am the person I am today because of that day.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Hazuki194"]
[OnName num="hazuki"]
“I don’t know. I think my way of being a priestess has changed, too.”
[cpg cn=true]


Thinking about it, I feel that Hazuki is also changing into a more rational person.
[cpg]


This may be the reason that two people who are attracted to each other go out.
[cpg]


It's because we are independent of each other that we are able to lean in and get closer to one another.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿居間』（昼）******************************************************

We had a relationship that even those around us recognized.
[cpg]


Or rather, Hazuki had more ability and status than me, so I was the one who was recognized.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Nagisa073"]
[OnName num="nagisa"]
“Hazuki and Zen, you've both look great. I'm so happy.”
[cpg cn=true]


I was no longer modest as I used to be.
[cpg]


Now I was confident enough to think that I was ...... worthy of Hazuki.
[cpg]


[OnName num="zen"]
“Thank you. But I still want to improve myself.”
[cpg cn=true]


Hazuki looked at me and smiled a little.
[cpg]


[FACE method="change_1" pos="2/5"]
[VOICE f="Hazuki195"]
[OnName num="hazuki"]
“I wonder if we've become more admirable. I feel that neither him nor I have changed since the beginning.”
[cpg cn=true]


And yet, Hazuki says this. I'm sure she is not saying this out of modesty.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Nagisa074"]
[OnName num="nagisa"]
“Perhaps. I had a feeling the two of you would end up like this someday."
[cpg cn=true]


Nagisa looks deeply moved. But it's not the same as just being happy.
[cpg]


[FACE method="change_7" pos="4/5"]
[VOICE f="Nagisa075"]
[OnName num="nagisa"]
"You two are going to grow up, aren't you? I'm going to become an old lady.”
[cpg cn=true]


[OnName num="zen"]
“I don't think so. Nagisa you’re still young.”
[cpg cn=true]


[FACE method="change_2" pos="4/5"]
[VOICE f="Nagisa076"]
[OnName num="nagisa"]
“Heh. Thanks."
[cpg cn=true]


Nagisa looked a little sad, but she also looked happy.
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=1000]
[window target=true]


It was getting late. The two of us snuggled up together and fell asleep.
[cpg]


In the past, I might have wished this night would never end. But not now.
[cpg]



[SE f="se015"]
;//【ＳＥ】『鳥の鳴き声』
[window target=false]
[free time=1000]
[BG f="b_11_1.ui" time=1000]
[WAIT time=1000]
[window target=true]

I wanted morning to come. I had accepted the passing of time.
[cpg]



[window target=false]
[BG f="b_01_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿居間』（朝）******************************************************


[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Hazuki196"]
[OnName num="hazuki"]
“…… Good morning Zen."
[cpg cn=true]


I am sure Hazuki feels the same way. Or perhaps she had arrived at this state of mind earlier.
[cpg]


[OnName num="zen"]
“Hmm, ah ...... good morning.”
[cpg cn=true]


I was still half asleep. I rub my eyes and Hazuki smiles at me.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Hazuki197"]
[OnName num="hazuki"]
“That was a cute sleeping face. But I don't feel like you’re a child anymore.”
[cpg cn=true]


[OnName num="zen"]
“Maybe you're right. It would be weird if I was still like that.”
[cpg cn=true]


Becoming an adult isn't always a bad thing.
[cpg]


We both became adults. We now stand on our own two feet.
[cpg]


And even though we could live on our own, we chose each other.
[cpg]



;//ブラックアウト


;//END
[SCENE id=24]
[jump storage="epend.ks" target="*start"]

;//==============================

;//ヒロイン１エンド
