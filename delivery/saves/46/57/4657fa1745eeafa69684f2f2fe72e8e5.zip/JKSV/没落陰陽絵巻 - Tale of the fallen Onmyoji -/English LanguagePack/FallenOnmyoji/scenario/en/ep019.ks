

;//==============================
;//二回目のお祓いを、一度で成功させていた場合下記のシナリオを追加
;#################################################
*Ep019|Memories of the Past
;#################################################


;//選択肢のジャンプ先
*select03_1|Memories of the Past

[SCENE id=19]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町外れ』（昼）******************************************************

Months and days passed. Since then, no great specters like the Plague God have appeared in Kinoto.
[cpg]


Still, consulatations about Yokai and curses were constant. The days are busy and not peaceful.
[cpg]


In parallel with my work as an Onmyoji, I also conducted my own research.
[cpg]


The contents of my research were the nature of curses. The reason why people become Yokai.
[cpg]


And, in other words, whether it is possible to turn a Yokai back into a human being.
[cpg]


Of course, it was necessary for my work, but it was all for the sake of Sakuya.
[cpg]


I want to fulfill her wishes. That was the only reason behind it.
[cpg]


At first, it was for my own success, but before I knew it, the purpose had changed.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『主人公の部屋』（夜）******************************************************

Then one day, I finally found out.
[cpg]


As I continued my research, I only found out that a Yokai cannot turn back into a person, but that is only the physical part.
[cpg]


I had revealed that even if it was impossible to restore their appearance, there was a way to regain their memories.
[cpg]


[OnName num="zen"]
“...... Now I can bring back Sakuya's memories.”
[cpg cn=true]


Theoretically, it is possible. And I thought I should be the one believing this theory.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『汎用民家』（朝）******************************************************

But I didn't want to use Sakuya as an experiment in an unstable technique.
[cpg]


I had no choice but to tell her everything. That it was something that had never been done before, and that there were risks.
[cpg]


Sakuya said it was fine with her. I guess it was not only for her sake.
[cpg]


She was thinking of me as well. If I can establish this method, I will be the first to do so.
[cpg]


[OnName num="zen"]
"I'm going to start......Please lie down."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『汎用民家』（昼）******************************************************

It's a complicated charm, and there is a lot to prepare. And I don't know how long the preparation will take.
[cpg]



;//ブラックアウト
[free time=1000]
[BG f="b_11_2.ui" time=1000]
[WAIT time=2000]

[BG f="b_11_3.ui" time=1000]
[WAIT time=2000]

早朝から始めて、術を発動させられたのは夕方になってからだった。
[cpg]

[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_08_2.ui" time=1000]
[WAIT time=1000]

[OnName num="zen"]
“How are you doing? Do you remember anything?”
[cpg cn=true]


After completing the charm, Sakuya got up.
[cpg]


She raised her upper body and put one hand on her head.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakuya130"]
[OnName num="sakuya"]
“..... I feel wobbly.”
[cpg cn=true]


Her voice and the way she spoke were still the same, and I was relieved about that for the time being.
[cpg]


I knew that as long as I was dealing with memories, I couldn't afford to have anything happen to them.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakuya131"]
[OnName num="sakuya"]
“But I remembered. I remembered my parents and my childhood.”
[cpg cn=true]


[OnName num="zen"]
"I see. That's good.”
[cpg cn=true]


I looked at Sakuya, who was on the verge of tears, thinking that I had made the discovery of the century.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『汎用民家』（夕方）******************************************************

From there, I started to hear a little more of what she remembered.
[cpg]


From this point on, I was listening not learn about the research or the charm, but purely to learn more about Sakuya.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Sakuya132"]
[OnName num="sakuya"]
“I became possessed by a curse and became a Yokai...... and I couldn't recognize my parents as my parents anymore."
[cpg cn=true]


[OnName num="zen"]
“I knew it ...... That is what happened.”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Sakuya133"]
[OnName num="sakuya"]
“My appearance changed too..... and we didn't recognize each other anymore.”
[cpg cn=true]


Sakuya wiped away her spilled tears and continued.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Sakuya134"]
[OnName num="sakuya"]
“It thought that they had abandoned me, but they were very kind parents.”
[cpg cn=true]


I think she had been worried for a long time. If she had been abandoned. If that was all she remembered.
[cpg]


But in reality, it wasn’t like that. So I guess these tears are tears of relief.
[cpg]


[OnName num="zen"]
“..... I thought that would be the case. They raised you to be the person you are now."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sakuya135"]
[OnName num="sakuya"]
“Heh. I guess so."
[cpg cn=true]


She laughed, although she was still on the verge of tears.
[cpg]

;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『汎用民家』（夕方）******************************************************


[VOICE f="Sakuya136"]
[OnName num="sakuya"]
“Zen, I want to meet my parents.”
[cpg cn=true]


Sakuya said so. I think it's only natural, and I also wanted her too.
[cpg]


[OnName num="zen"]
"Yeah, I think that's a good idea.”
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
Sakuya looked a little surprised at my words and said to me,
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sakuya137"]
[OnName num="sakuya"]
“You’re not a stranger to this. You have to come too because you're going to be my husband.”
[cpg cn=true]


Oh right….I guess I was a being a little irresponsible.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sakuya138"]
[OnName num="sakuya"]
“It's a long way, but it might turn into a nice trip.”
[cpg cn=true]


[OnName num="zen"]
“…… that's..."
[cpg cn=true]


I should ask her how far away it is, but should I make a decision right now?
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakuya139"]
[OnName num="sakuya"]
“Why are you hesitating? I'll take you there even if I have to force you.”
[cpg cn=true]


And before I could reply, Sakuya had already decided what to do.
[cpg]


[OnName num="zen"]
“I knew you would say that.”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
Whenever I'm with Sakuya, I always feel like I'm being pushed around. But I didn't dislike that.
[cpg]


That's right. I’m her future husband. There is no reason for me to reject her for saying so.
[cpg]



;//ブラックアウト
[free time=1000]
[BG f="b_11_3.ui" time=1000]
[WAIT time=1000]


I couldn't introduce her to my parents, but I hope they are watching over me in heaven.
[cpg]


......There is a clear difference between this world and heaven, but I was able to bridge the gap between human and Yokai.
[cpg]


The fact that Sakuya and I were able to love each other was proof of that.
[cpg]


;//END
[SCENE id=26]
[jump storage="epend.ks" target="*start"]



;//==============================

;//ヒロイン３エンド
