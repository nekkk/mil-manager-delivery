


;//==============================
;//二回目のお祓いを、成功させていた場合下記のシナリオを追加

;#################################################
*Ep023|Even if the relationship will end someday
;#################################################


;//選択肢のジャンプ先
*select05_1|Even if the relationship will end someday

[SCENE id=23]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大通り』（昼）******************************************************

From then on, Nagisa was fully supportive of my relationship with Hazuki.
[cpg]


I guess she really wanted me to like Hazuki.
[cpg]


But I didn't. I like Hazuki, but more than that, I am in love with Nagisa.
[cpg]


And of course, I can't tell Hazuki that ......
[cpg]


I wouldn't reveal it until the end. I was prepared for that.
[cpg]


I know it's a bad relationship, but I couldn't stop even though I knew it.
[cpg]


Then one day. In the area of the shrine.
[cpg]

;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『神社の境内』（昼）******************************************************

I had been going to Hazuki's place for days without telling her how I really felt, and she said to me,
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hazuki199"]
[OnName num="hazuki"]
“Hey, Zen. It's about my mother."
[cpg cn=true]


[OnName num="zen"]
“What?"
[cpg cn=true]


I couldn't help but say that. Even though I knew it was an overreaction, I couldn't help it.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hazuki200"]
[OnName num="hazuki"]
“What do you mean? She is extremly supportive of us, isn’t she? Why is that?”
[cpg cn=true]


Why? It's obvious, Nagisa wants to turn my love for her towards Hazuki.
[cpg]


...... Hazuki is somehow acting like she's aware of what's going on with me and Nagisa.
[cpg]


Hazuki may have thought that it was better to keep quiet. There was no sadness in her smile.
[cpg]


[OnName num="zen"]
“I wonder why ......."
[cpg cn=true]


I pretended I didn't know anything.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

Having a secret is nerve-wracking.
[cpg]


Whether I was outside or in the store, I spent more time thinking about it.
[cpg]


Takane sees me like this and is worried about me. She knows that Hazuki and I are dating.
[cpg]


But she might have also realized that I really like Nagisa.
[cpg]




[window target=false]
[free time=1000]
[BG f="b_09_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Takane253"]
[OnName num="takane"]
“Welcome......oh, Nagisa.”
[cpg cn=true]



[FACE method="bow_1" pos="4/5"]
[VOICE f="Nagisa082"]
[OnName num="nagisa"]
“Good evening. Is Zen here?"
[cpg cn=true]


[OnName num="zen"]
"Yes, is it just you today? “
[cpg cn=true]


Nagisa is trying to hide the relationship, but sometimes she shows boldness like this.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p5_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

The relationship between me and Hazuki. From the outside, we are a Miko and a Onmyoji, we are close in age, and we look good together……
[cpg]


Behind the scenes, our love affair continued to teeter on the edge.
[cpg]


The feeling grew to an extent that we couldn't handle it any longer.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagisa083"]
[OnName num="nagisa"]
“I wonder if Takane is also aware of it.”
[cpg cn=true]


I think she is aware of it. But I can't say for sure.
[cpg]


[OnName num="zen"]
“I don't know. She has good instincts."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Nagisa084"]
[OnName num="nagisa"]
“It's a dangerous situation. Our relationship is, and always will be.”
[cpg cn=true]


[OnName num="zen"]
"......Yes."
[cpg cn=true]


Still, we have no choice but to seek each other out. That is the path we have chosen for each other.
[cpg]


We have to love each other. No matter what else we might have to trade in for it.
[cpg]



;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[BG f="b_11_4.ui" time=1000]
[WAIT time=2000]

I think vaguely. I wonder when this relationship will break down.
[cpg]


If Hazuki, who would be most hurt if she finds out, is aware of it, is there any chance of that happening?
[cpg]


But if someone else finds out that I am in love with Hazuki's mother, ......
[cpg]


They will at least think that I am not sane. Even Nagisa's and Hazuki's positions might be in jeopardy.
[cpg]


If that's the case, I guess I'll just have to keep it hidden.
[cpg]


[FADEOUTBGM]
[BG f="b_11_1.ui" time=1000]
[WAIT time=2000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


[SE f="se015"]
;//【ＳＥ】「道を歩く」

[FG f="CHA05_p5_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nagisa085"]
[OnName num="nagisa"]
“......Zen, it's morning."
[cpg cn=true]


I wake up to Nagisa’s gentle voice. She was smiling.
[cpg]


[OnName num="zen"]
“.....Oh, it is.”
[cpg cn=true]


I looked up at her while getting up. She was stroking my head.
[cpg]


Not only had I fallen asleep with nothing on, but I had fallen asleep with Nagisa.
[cpg]


It's like I've already told Takane everything ...... I can only hope that she hasn't woken up yet.
[cpg]


But the fact that Nagisa is doing this, is probably because she knows that Takane is asleep.
[cpg]


The more I think about it, the more I realize there are too many things I have to hide.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Nagisa086"]
[OnName num="nagisa"]
“I really think this is a dangerous relationship. I don't think it can go on like this.”
[cpg cn=true]


But everything being held in a dangerous equilibrium, is similar to when the Plague God was vanquished.
[cpg]


If all the elements are intertwined by chance and have been established, then this current relationship can stay unbroken.
[cpg]


I had such an unfounded confidence.
[cpg]

;//END
[SCENE id=28]
[jump storage="epend.ks" target="*start"]


;//==============================

;//ヒロイン５エンド

;//==============================
