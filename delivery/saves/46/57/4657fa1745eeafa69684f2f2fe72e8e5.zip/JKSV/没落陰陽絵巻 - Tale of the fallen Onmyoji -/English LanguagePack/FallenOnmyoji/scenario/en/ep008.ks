

;//==============================
;//１、葉月

;#################################################
*Ep008|Trustworthy Hazuki.
;#################################################

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]

;//選択肢のジャンプ先
*select00_1|Trustworthy Hazuki.

[SCENE id=8]

;//ルートフラグ
[stflag ChaRoute = 1]

Hazuki. She can face a monster like this.
[cpg]


I thought that Hazuki was the most trustworthy partner, so I ran.
[cpg]


[SE f="se007"]
;//【ＳＥ】「道を走る」



[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『神社の境内』（夕方）******************************************************

It was late in the evening, but she should still be at the shrine.
[cpg]


I headed for the shrine, thinking that if it was two against one, I might be able to fight it.
[cpg]



[SE f="se021"]
;//【ＳＥ】『転ぶ』

As I stepped into the shrine grounds, I slipped.
[cpg]


[OnName num="zen"]
“Damn!"
[cpg cn=true]


It was coming at me pretty fast. I had to do something.
[cpg]


With that thought, I turned around and looked up at the figure of something.
[cpg]


It was looking at me. It had no eyes or anything, but I could tell.
[cpg]

[FADEOUTBGM]
[WAIT time=1000]
[OnName num="zen"]
"What the ......?"
[cpg cn=true]


I wonder what it's going to do to me, but it just backs away.
[cpg]


[OnName num="zen"]
“Can't it get into the precincts?”
[cpg cn=true]


It couldn't seem to get through the gate. After all, it means that it was a Yokai or a curse.
[cpg]


It can't enter the sacred place. I saw it leave as it withdrew.
[cpg]


I thought about going after it, but it would be dangerous to do so without any preparation.
[cpg]


[BGM f="bg_c1"]

I took a breath, thinking my life was spared. Then......
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hazuki118"]
[OnName num="hazuki"]
“Zen? Why are you here?”
[cpg cn=true]


After a few moments, Hazuki came toward me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hazuki119"]
[OnName num="hazuki"]
“What was that? You look pale."
[cpg cn=true]


[OnName num="zen"]
“No, no, ...... something came after me.”
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
Something? Hazuki was looking around.
[cpg]


[OnName num="zen"]
“It wasn't a curse or a Yokai. What was it?”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki120"]
[OnName num="hazuki"]
“I'd like to ask you the same thing. I didn't see anything, and I haven't heard what happened yet.”
[cpg cn=true]


She was right. I tried to calm down, aware that my pulse was still racing.
[cpg]


[OnName num="zen"]
“…… Right. I'll tell you."
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p5_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



I told Hazuki about that something.
[cpg]


She listened intently and gave me her opinion.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Hazuki121"]
[OnName num="hazuki"]
“You couldn't see it clearly? That means, according to your theory, it's not a Yokai, right?”
[cpg cn=true]


That's true. Yokai are based on living creatures, but they had no substance.
[cpg]


[OnName num="zen"]
“Yea, it wasn't neither a human or an animal. What was that ......?"
[cpg cn=true]


No matter how much we talked we could not understand, and the conversation just kept going in circles.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

[OnName num="zen"]
"......I'm home. I've had a rough time.”
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Takane147"]
[OnName num="takane"]
“Welcome back. What's wrong?"
[cpg cn=true]


When I returned to the store Midori seemed to be there, so I told her what had happened.
[cpg]


[FACE method="change_7" pos="4/5"]

[VOICE f="Midori104"]
[OnName num="midori"]
“That is strange. I wonder if it has something to do with the curse I've been under.”
[cpg cn=true]


I wonder. I can't give her an immediate answer based on the information I have now.
[cpg]


[OnName num="zen"]
“We don't know that either. All I know is that we can’t just leave it.”
[cpg cn=true]


But it was, how should I put it, a "strong" monster.
[cpg]


I really thought it could kill me. I had never encountered anything with that kind of power and will before.
[cpg]


If I went there again, I might die. There was nothing I could do but take precautions.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大通り』（昼）******************************************************

In the end, even after all the discussions with Midori and Takane, we had no particular decision.
[cpg]


I could not figure out what it was or what to do about it.
[cpg]


[BG f="b_11_3.ui" time=1000]
[WAIT time=2000]

[SE f=se004]
;//【ＳＥ】『歩く』

[BG f="b_06_3.ui" time=1000]
[WAIT time=2000]

After all, I wanted to hear more of Hazuki's thoughts.
[cpg]


I thought so because I trust her, and also because I genuinely ......
[cpg]


I had a life-threatening situation and she was the one I wanted to see.
[cpg]


I guess I realized my own feelings at this point.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『神社の境内』（夕方）******************************************************

I arrived at the shrine where she was supposed to be working, but she wasn't there.
[cpg]


[OnName num="zen"]
“Where is she?"
[cpg cn=true]


As I was looking for her, Nagisa came over to me.
[cpg]


[FG f="CHA05_p5_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nagisa044"]
[OnName num="nagisa"]
“Zen. I'm so glad you came.”
[cpg cn=true]


She looked a little serious. It was as if something bad had happened.
[cpg]


[OnName num="zen"]
“Did something happen? Hazuki doesn't seem to be here.”
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Nagisa045"]
[OnName num="nagisa"]
“Yes, Could come over to the house?”
[cpg cn=true]


Nagisa’s expression was clouded. I felt something was going on and headed over.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿居間』（夕方）******************************************************

There was the usual Hazuki. No.......
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hazuki122"]
[OnName num="hazuki"]
"......"
[cpg cn=true]


[OnName num="zen"]
"Hazuki ......"
[cpg cn=true]


She was wearing a Miko costume and had depressed eyes. It was different from the curse the other day.
[cpg]

[free time=1000]

[FG f="CHA05_p5_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nagisa046"]
[OnName num="nagisa"]
“It started around noon today. She was doing her job as a Miko and suddenly this happened……"
[cpg cn=true]


That's why she's dressed like this. It's her day job, it suits her well.
[cpg]


[OnName num="zen"]
“I wonder what kind of curse it is. I think she sees me."
[cpg cn=true]


Her eyes are looking right at me...... no.
[cpg]


Her eyes are on me, but she don't seem to be focused.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Nagisa047"]
[OnName num="nagisa"]
“She'll even answer you. But she just responds in a way that doesn’t make any sense.”
[cpg cn=true]


[OnName num="zen"]
“Then, is she in a kind of hypnotic state?”
[cpg cn=true]


That's how it looks to me. I'll have to talk to her a lot though.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Nagisa048"]
[OnName num="nagisa"]
"Hey, Zen. I wonder if you could break the curse for her.”
[cpg cn=true]


[OnName num="zen"]
“Nagisa.....I can't draw blood.”
[cpg cn=true]


I'm sure Nagisa knows this, but I refused.
[cpg]


[OnName num="zen"]
“My blood can't break the curse like the other Onmyoji’s.”
[cpg cn=true]



[FACE method="bow_3" pos="2/3"]
[VOICE f="Nagisa049"]
[OnName num="nagisa"]
“I know. But you'd do it for Hazuki.”
[cpg cn=true]


It has been approved by Nagisa. Is it okay to make such an important decision in a place like this?
[cpg]


[OnName num="zen"]
“I never thought you would say such a thing."
[cpg cn=true]


I take another step back, but Nagisa won't let me go.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Nagisa050"]
[OnName num="nagisa"]
“I've long since made up my mind. Zen, you are the only one for Hazuki.”
[cpg cn=true]


[OnName num="zen"]
“I’m……honored.”
[cpg cn=true]


Being told so, I can't back down even if I wanted to.
[cpg]



;//ブラックアウト
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_01_3.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]

I took Hazuki to her room. Come to think of it, I hadn't been in this room since I was a child.
[cpg]


There was no time to be lost in deep emotion. I have to get the original Hazuki back.
[cpg]


[OnName num="zen"]
“Hazuki. Can you see me?”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki123"]
[OnName num="hazuki"]
"Yeah......"
[cpg cn=true]


Her reply is different from usual. It's as if she's looking at me but looking somewhere else. She is in a hypnotic state.
[cpg]


[OnName num="zen"]
“Raise your right hand, please.”
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
She didn't nod her head and just did as she was told.
[cpg]


She was in a very dangerous state. It's fine while she’s at home with Nagisa, but ......
[cpg]


I don't think she can talk to someone else. It would be a disaster if she was kidnapped or something.
[cpg]


[OnName num="zen"]
“……"
[cpg cn=true]


Looking at her in this state, a different desire was growing inside me.
[cpg]


“Now I can ask her something I normally can't ask, or do something I normally can't do.”
[cpg]


[OnName num="zen"]
“Stand up. Hazuki."
[cpg cn=true]


I swallowed and helped her get on her feet.
[cpg]


;//========================================
;//●ＣＧ（催眠状態で、立っているヒロイン）ev_22
;//人物１：ヒロイン１　服装１：巫女服
;//人物ex：主人公　　　服装ex：私服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_22_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

Her eyes were still vacant, not looking anywhere.
[cpg]

I told her I would do something to break the curse.
[cpg]


I took a deep breath to calm myself. Then, as calmly as I could, I said,
[cpg]


[OnName num="zen"]
"...... Don't worry, Hazuki. I won't do anything."
[cpg cn=true]


Even if I said I would do nothing, the curse would not be lifted if I really did nothing at all.
[cpg]


I have decided.
[cpg]




;//選択肢のジャンプ先
*select01_2_0|Trustworthy Hazuki.

;//■選択肢

[switch]
[case "I kiss her on the lips."]
	[swap]
	[jump target="*select01_2_1"]
[case "I kiss her on the cheek"]
	[swap]
	[jump target="*select01_2_2"]
[endswitch]



Kiss her cheek
1. Kiss her lips

;//==============================
;//１、唇に口づけする

;//選択肢のジャンプ先
*select01_2_1|2. Kiss her cheek

[OnName num="zen"]
“...... Hazuki. Look at me.”
[cpg cn=true]


Hazuki nods. She can't refuse.
[cpg]

;//========================================
;//●ＣＧ（催眠状態のヒロイン）ev_24
;//人物１：ヒロイン１　服装１：巫女服
;//人物ex：主人公　　　服装ex：私服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//備考　：オリジナル特典02.jpgのシーンです
;//========================================
;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_24_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[wait time=1000]


But I don't want to do anything to take advantage of that.
[cpg]


The expression on Hazuki's face makes it hard to tell what's going on......
[cpg]


Still, I managed to calm myself down and brought my lips to hers.
[cpg]

[VOICE f="Hazuki124"]
[OnName num="hazuki"]
“Mm……."
[cpg cn=true]


She raises her voice a little. Normally she might not even make such a sound.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト



;//分岐ループから抜ける
[jump target="*select01_2_4"]

;//==============================
;//２、頬に口づけする

;//選択肢のジャンプ先
*select01_2_2|Trustworthy Hazuki.


If things had been the same, a kiss on the cheek would have broken the curse.
[cpg]

I try to do the same thing, remembering that.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;**【ＣＧ】 ev_22_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]
But when I tried, nothing changed.
[cpg]

To my surprise, I realized that I needed another method.
[cpg]

I don't know if the curse is getting stronger or what is happening ......
[cpg]


;//■選択肢

[stflag Cha1flg = -1]

[switch]
[case "Kiss her lips"]
	[swap]
	[jump target="*select01_2_1"]
[endswitch]

;//もう一度同じ分岐へ戻る
[jump target="*select01_2_0"]

;//==============================

;//選択肢のジャンプ先
*select01_2_4|Trustworthy Hazuki

;//ブラックアウト[FADEOUTBGM]
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_c1"]
[WAIT time=100]
Inside Hazuki's room. She came to her senses and we spent an awkward time together.
[cpg]


As for me, I want to explain, but I can't think of the right words.
[cpg]


And since this is Hazuki's room, it would be strange for her to leave.
[cpg]


So I should leave.
[cpg]


[OnName num="zen"]
“I'm sorry,…….for doing this again.”
[cpg cn=true]


Hazuki spoke, looking at me while not really looking at me.
[cpg]



[FACE method="shake_1" pos="2/3"]
[VOICE f="Hazuki125"]
[OnName num="hazuki"]
“Umm, thank you.…”
[cpg cn=true]


That word of gratitude should be taken simply even though it makes me want to explore the meaning behind it.......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p3_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿居間』（夜）******************************************************

The two of us returned to the living room. Nagisa was pleased to see Hazuki regain her sanity.
[cpg]



[FACE method="bow_2" pos="4/5"]
[VOICE f="Nagisa051"]
[OnName num="nagisa"]
“Thank you, Zen. It looks like Hazuki's curse has been lifted.”
[cpg cn=true]



[FACE method="bow_1" pos="2/5"]
[VOICE f="Hazuki126"]
[OnName num="hazuki"]
“Yes. You called him right? Thank you."
[cpg cn=true]


I was about to leave, because I felt like I couldn't stand being there any longer.
[cpg]


[OnName num="zen"]
“Well, then. We've already settled the matter, so I'll leave.”
[cpg cn=true]


I heard Nagisa's voice stop me, but I didn't turn around and left.
[cpg]

;//
[SE f="se008"]
;//【ＳＥ】「床を歩く」

;//[SE f="se000"]
;//【ＳＥ】『戸閉まる』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大通り』（夜）******************************************************

It was hard to stay. Nagisa knows what Hazuki and I did.
[cpg]


On top of that, Nagisa didn't say anything about it, but ...... it was awkward.
[cpg]


[OnName num="zen"]
"But……."
[cpg cn=true]


Now that I think about it, it seemed like a waste as well.
[cpg]


She was in a hypnotic state. A state in which she could not hide anything from me.
[cpg]


The memory is not continuous. If that's the case, then ......
[cpg]


I could have asked her if she liked me.
[cpg]


[OnName num="zen"]
“No way I can do it……"
[cpg cn=true]


I couldn't do it even if I thought of it. I'm sure she doesn’t think of me as just a friend.
[cpg]


And if I was going to confide my love, I wanted it to come from me.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『神社境内』（昼）******************************************************

The next day off. I went to Hazuki's place again.
[cpg]


I think I was able to sort out what happened the other day in my mind.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki127"]
[OnName num="hazuki"]
"Zen ...... hello."
[cpg cn=true]


[OnName num="zen"]
“Oh, hello. How's the curse?”
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Hazuki128"]
[OnName num="hazuki"]
“I'm fine now. You…..did something like before, didn't you?”
[cpg cn=true]


Nagisa must have told her. She looks embarrassed.
[cpg]


[OnName num="zen"]
“I'm sorry. I can't exorcise it with blood."
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
I apologize but Hazuki shakes her head.
[cpg]


Her cheeks are red and she looks away from me.
[cpg]


I have some idea why she is acting like this.
[cpg]


Things have accumulated. A childhood friend who had always been close had crossed the line because of a curse.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hazuki129"]
[OnName num="hazuki"]
“You don't need to apologize. Rather, I want to apologize to you.”
[cpg cn=true]


[OnName num="zen"]
“It’s okay. Don’t suddenly become so nice, I want to see the usual Hazuki."
[cpg cn=true]


"I want to see the usual Hazuki." The words came out naturally. I was aware of the feelings inside me.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Hazuki130"]
[OnName num="hazuki"]
“What do you mean? What is the usual me?"
[cpg cn=true]


Hazuki says something that makes me gasp. It's not that her consciousness is clouded by the curse.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Hazuki131"]
[OnName num="hazuki"]
“I feel like the me who is always hard on you is not the real me either.”
[cpg cn=true]


Hazuki is trying to say something.
[cpg]


This isn't good. I'm pushing her too hard.
[cpg]


[OnName num="zen"]
I see.
[cpg cn=true]


On the other hand, I'm in a state where I can't muster up the courage to say anything meaningful.
[cpg]


Hazuki's face is red. I'm probably the same.
[cpg]


[FADEOUTBGM]

[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki132"]
[OnName num="hazuki"]
“Hey. Zen."
[cpg cn=true]


I can feel her voice, which is just calling my name, awfully close to me.
[cpg]


I can feel the distance between our hearts getting closer, just like our bodies.
[cpg]


[BGM f="bg_h2"]
[WAIT time=100]

[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki133"]
[OnName num="hazuki"]
“I ...... haven't thought for a long time that this feeling has meaning. Remember, I told you before that I have no desire?”
[cpg cn=true]


I know what she means by “this feeling”.
[cpg]


But I won't ask her. I couldn't make her say it.
[cpg]


[OnName num="zen"]
“Really? I can't imagine that.”
[cpg cn=true]


I had no choice but to change the subject a little. But Hazuki did not allow me.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Hazuki134"]
[OnName num="hazuki"]
“Don't you care? About this feeling inside me.”
[cpg cn=true]


[OnName num="zen"]
"...... No. I'm sorry."
[cpg cn=true]


We come closer to the point of no return. Her voice sounds closer than before.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Hazuki135"]
[OnName num="hazuki"]
“I think the curse is still on me. My head is foggy.”
[cpg cn=true]


[OnName num="zen"]
“...... What does that mean?"
[cpg cn=true]


Hazuki looks at me again, at a loss for words.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Hazuki136"]
[OnName num="hazuki"]
“Even now......if you ask me what I feel, I'll answer anything.”
[cpg cn=true]


She is not only grateful that I had saved her twice, but she has actual feeling for me.
[cpg]


But that is all she can say.
[cpg]


She is always harsh, but now she revealed so much to me. I have to respond.
[cpg]


[OnName num="zen"]
“I see. Then I want to ask you something....... No, let me say it.”
[cpg cn=true]


If there is such a thing as the most important moment in one's life, it might be wrapped in this kind of nervousness.
[cpg]


[OnName num="zen"]
“I like you Hazuki."
[cpg cn=true]


It was her smile that broke that tension.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Hazuki137"]
[OnName num="hazuki"]
"Yes. Me too."
[cpg cn=true]


She said. I must have had a similar look on my face.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『神社境内』（夕方）******************************************************

We talked about many things. In particular, we talked about why we fell in love with each other.
[cpg]


However, we felt that our conversation was too uplifting, we were talking at a halting pace.
[cpg]


Hazuki seemed to like my researcher-like attitude and kept talking about her memories of me.
[cpg]


I was embarrassed and only "thank you" came out of my mouth, but couldn't look away.
[cpg]



[FACE method="shake_1" pos="2/3"]
[VOICE f="Hazuki138"]
[OnName num="hazuki"]
“I never thought I would have a boyfriend. I know I'm the kind of person who keeps people away.”
[cpg cn=true]


I wonder. Did Hazuki think that?
[cpg]


[OnName num="zen"]
“Really? You don't seem like that.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki139"]
[OnName num="hazuki"]
“I am. My words are growing thorns as I get older.”
[cpg cn=true]


But I guess that's to be expected.
[cpg]


She has a promising future as a priestess. I can imagine that many people would come to her because of that.
[cpg]


She may have gone through a lot of things behind me. I could not easily deny it.
[cpg]


[OnName num="zen"]
"I see.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hazuki140"]
[OnName num="hazuki"]
“I want to know. Why did you fall in love with me?”
[cpg cn=true]


I face my own heart. I can't explain in a few words why I fell in love with Hazuki.
[cpg]


[OnName num="zen"]
“Because you were the one who knew me best. Maybe because you were the one who understood me."
[cpg cn=true]


I search for words that fit me. Not the words that fit Hazuki.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Hazuki141"]
[OnName num="hazuki"]
“Do you fall in love with someone just because of that?”
[cpg cn=true]


[OnName num="zen"]
“I do. I was a dropout who was ostracized by society.”
[cpg cn=true]


These words are certain to some extent. Hazuki knew me when I was a smoldering mess.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Hazuki142"]
[OnName num="hazuki"]
“If someone else pretended to know you, you might have fallen for her?”
[cpg cn=true]


[OnName num="zen"]
“No way. I didn't say you pretend to understand, I said you understand me.”
[cpg cn=true]


Hazuki did not seem too convinced.
[cpg]


But for me, there's no other way to put it. There is no other word for it.
[cpg]


The thing that made me the happiest and that made me love her was that she understood me.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************


[OnName num="zen"]
“We're a mismatched pair, aren't we?”
[cpg cn=true]


I couldn't help but say it. We are too different in nature.
[cpg]


But still, I felt that we were united.
[cpg]


If we were scales, I'm the one tilting heavier than her. That's why I have to restrain myself.......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

After returning to the store, Takane immediately noticed something was different about me, but I couldn't tell her honestly.
[cpg]


But Takane seemed to have guessed.
[cpg]



[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane148"]
[OnName num="takane"]
“Congratulations."
[cpg cn=true]


I may have been talking about Hazuki for a long time.
[cpg]


[OnName num="zen"]
“Thank you......."
[cpg cn=true]


Takane chuckled at my answer.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



I can't sleep. I'm in a state of unexplainable excitement.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

I'm not going to be able to work if I don't sleep, but I'd like to enjoy this feeling.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane149"]
[OnName num="takane"]
“You have dark circles under your eyes. Are you all right?”
[cpg cn=true]


[OnName num="zen"]
“Don't worry. I will become a strong man.”
[cpg cn=true]


My words was not as usual. Hearing this, Takane laughed again.
[cpg]


This is probably the most disgraceful thing about me, but it can't be helped. I'll change, including that part.
[cpg]


;//ブラックアウト


I can't meet Hazuki whenever I want.
[cpg]


We both have jobs, so it has been frustrating for a while.
[cpg]


I want to adjust our holidays as much as possible, but I feel as if I am not satisfied with the frequency of us spending time together.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

One day, when I was feeling that the day was awfully long.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Takane150"]
[OnName num="takane"]
"Oh, Hazuki! You're here."
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Hazuki143"]
[OnName num="hazuki"]
"Yes. Hello.”
[cpg cn=true]


Hazuki had come to the store.
[cpg]


I think it's unusual, considering her personality.
[cpg]


[OnName num="zen"]
“It's nice to see you come to see me.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki144"]
[OnName num="hazuki"]
“Maybe you're right. I kind of couldn't wait to see you.”
[cpg cn=true]


I'm glad she thinks that. I'd like to respond to that.
[cpg]


[OnName num="zen"]
“Do you want to relax here? Or should we go out somewhere?”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Hazuki145"]
[OnName num="hazuki"]
"Yeah. Yes……."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大通り』（昼）******************************************************

Takane saw us off as we left for town.
[cpg]


She would usually say that she would come with us.
[cpg]


But she's aware of our relationship.
[cpg]



[SE f="se004"]
;//【ＳＥ】『道歩く』


;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


Hazuki took me to a select shop. It's the kind of store I would never go into on my own.
[cpg]


Even when I was with Hazuki, we had never been to this kind of store before.
[cpg]


Little by little, I realized that I was seeing a side of Hazuki that I had never seen before.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************

The lovely time passed so quickly which was frustrating.
[cpg]


[VOICE f="Hazuki146"]
[OnName num="hazuki"]
“It's already evening. Do you want to go somewhere Zen?”
[cpg cn=true]


[OnName num="zen"]
"No, not really.”
[cpg cn=true]


I thought about how to answer this question, but I really couldn't think of anything.
[cpg]


[OnName num="zen"]
“I want to go wherever you want to go.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki147"]
[OnName num="hazuki"]
“So ...... then, I guess.”
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

[VOICE f="Takane151"]
[OnName num="takane"]
"Welcome back, both of you."
[cpg cn=true]


The two of us were back at the store. I couldn't look straight at Takane's face for some reason.
[cpg]


[FACE method="change_2" pos="4/5"]
[VOICE f="Hazuki148"]
[OnName num="hazuki"]
“Takane, may I borrow your kitchen?"
[cpg cn=true]


We had bought some ingredients. Hazuki was going to cook for us.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Takane152"]
[OnName num="takane"]
“Yes, of course. Shall I help you?”
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Hazuki149"]
[OnName num="hazuki"]
“Thank you, but that’s okay.”
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Takane153"]
[OnName num="takane"]
"No problem. I believe you will make him happy.”
[cpg cn=true]


Takane's smile looked a little complicated. It hurts my heart, but I have to go beyond these feelings.
[cpg]



;//ブラックアウト


Hazuki and I were spending our days like that.
[cpg]


I have a lot of feelings inside of me, but I wanted to enjoy everything.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿居間』（夜）******************************************************

Another day. This time I was invited to Hazuki's house.
[cpg]


[OnName num="zen"]
“...... Where is Nagisa?”
[cpg cn=true]



[VOICE f="Hazuki150"]
[OnName num="hazuki"]
“She's at the shrine office talking about the curse.”
[cpg cn=true]


[OnName num="zen"]
“What? I wasn't invited.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hazuki151"]
[OnName num="hazuki"]
“I asked for it. Otherwise, we wouldn't be alone."
[cpg cn=true]


It took me a moment to understand the meaning of Hazuki's words. Then I asked her.
[cpg]


[OnName num="zen"]
“Are you sure....... I can't believe you would say that.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Hazuki152"]
[OnName num="hazuki"]
“I'm sure it's fine. Let's stay together tonight.
[cpg cn=true]



;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



And I was invited to Hazuki's room. I realized that I was in a relationship that I had always wanted.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

I was happy. I felt more fulfilled than ever.
[cpg]


Of course, there are things that cast a shadow over our lives. The curse of killing people.
[cpg]


We really need to solve that. Hazuki and I share the same intention.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

I was thinking about it while I was working at the store.
[cpg]


[FG f="CHA02_p5_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Midori105"]
[OnName num="midori"]
“You seem like you’re not here, Zen.”
[cpg cn=true]


Midori says and I realized that I had been deep in thought.
[cpg]


[OnName num="zen"]
“Well. I was just thinking.”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Midori106"]
[OnName num="midori"]
“You seem like a different person. Is something wrong?”
[cpg cn=true]


Midori was sharp, though not as sharp as Takane.
[cpg]


[OnName num="zen"]
“Midori, how is work? You come to my place often, don't you?”
[cpg cn=true]


[VOICE f="Midori107"]
[OnName num="midori"]
“See. You never used to dodge the subject.”
[cpg cn=true]


Was it too obvious? I look to Takane for help, but she looks at me with a wry smile.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Midori108"]
[OnName num="midori"]
“If there is something wrong, please let me know. Or is it something you can't tell me?”
[cpg cn=true]


Is there any point in hiding it any longer? Midori will be depressed.
[cpg]


[OnName num="zen"]
“I've been dating Hazuki since ...... a little while ago.”
[cpg cn=true]

[FADEOUTBGM]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Midori109"]
[OnName num="midori"]
“Huh……"
[cpg cn=true]


Midori makes a voice I've never heard before. She backs away, wincing and shaking.
[cpg]

[BGM f="bg_c1"]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Midori110"]
[OnName num="midori"]
“What..... after all...... It’s always her.”
[cpg cn=true]


Midori has always had a rivalry with Hazuki. I can't bear to think about it.
[cpg]


I'm not certain if she liked me or not, but I guess she has a hard time accepting this.
[cpg]

[free time=1000]

[SE f="se010"]
;//【ＳＥ】「走り去る」

[WAIT time=1100]

[OnName num="zen"]
“Oh, hey."
[cpg cn=true]


Midori ran away. I was stunned.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Takane154"]
[OnName num="takane"]
“What are you doing? Aren't you going after her?”
[cpg cn=true]


I realized what was going on when Takane told me. That's right.
[cpg]


[OnName num="zen"]
“Oh, yeah. Right.”
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p5_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『路地裏』（昼）******************************************************

I went after her and found her crying in a back alley.
[cpg]


[OnName num="zen"]
“I can't say anything but….."
[cpg cn=true]



[FACE method="shake_4" pos="2/3"]
[VOICE f="Midori111"]
[OnName num="midori"]
“You don't have to say anything. I know. I've known all along.”
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Midori112"]
[OnName num="midori"]
“I can’t win against her. I didn't want to remember, but I remembered.”
[cpg cn=true]


Midori tearfully confessed.
[cpg]


I think the words "I can't beat Hazuki," rather than the fact that she liked me, probably says it all.
[cpg]


It was her inferiority complex. I shouldn’t have went there.
[cpg]


I can't be nice to her and if I shun her, that will be the end of it.
[cpg]


[OnName num="zen"]
“I'm sure you can understand that you are important to me as well. It's hard for me to see you cry.”
[cpg cn=true]



[FACE method="shake_7" pos="2/3"]
[VOICE f="Midori113"]
[OnName num="midori"]
“Are you a player….. or am I too sensitive?”
[cpg cn=true]


Player. I'm pretty sure that's not true, but Midori seems to think so.
[cpg]


;//ブラックアウト


I stayed there for a while without saying a word. Midori seemed to sense this and wiped away her tears.
[cpg]



[FACE method="bow_6" pos="2/3"]
[VOICE f="Midori114"]
[OnName num="midori"]
“I’m okay now. I'm sure things will be as usual again.”
[cpg cn=true]


I can’t say "sorry" or "thank you" here. Even I knew it. I just nodded back.
[cpg]


I didn't want to play with Midori's feelings.
[cpg]


But it's also difficult to pretend to be a terrible guy. It's a bit of a mess, but if things are back to normal, I guess that's all that matters .......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町外れ』（夕方）******************************************************

[SE f="se001"]
;//【ＳＥ】『戸開く』

Then I visited Sakuya. I had something to do in this area, so I went along the way.
[cpg]


I suddenly found myself talking to her about Hazuki and Midori.
[cpg]


Strangely enough, I had no resistance to telling this to Sakuya......
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakuya054"]
[OnName num="sakuya"]
“I'm sure it's a difficult subject. Although I want to congratulate you.”
[cpg cn=true]


Sakuya was unconcerned.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sakuya055"]
[OnName num="sakuya"]
“I think it's just that to be happy, you'll have to hurt someone.”
[cpg cn=true]


[VOICE f="Sakuya056"]
[OnName num="sakuya"]
“But you just have to think that time will come when you can give happiness back to that person.”
[cpg cn=true]


[OnName num="zen"]
“...... Is that how it is?”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sakuya057"]
[OnName num="sakuya"]
“That's usually the way it is. You're a detective, shouldn’t you be the one consulting me?”
[cpg cn=true]


[OnName num="zen"]
“Well, true……."
[cpg cn=true]


She was right. I’m not sure what kind of consultations I will have to give so I have to stay focused.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

After returning home, I also had a short talk with Takane.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane155"]
[OnName num="takane"]
“I can understand Midori's feelings a little. I can understand why she is jealous.”
[cpg cn=true]


[OnName num="zen"]
"Do you feel the same way, too?”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Takane156"]
[OnName num="takane"]
“Oh, no, as for myself, I want you to be happy with Hazuki.”
[cpg cn=true]


However, after prefaced by that, Takane said with a serious face.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Takane157"]
[OnName num="takane"]
“But you chose Hazuki, didn't you? I don't think it would be good for Hazuki to hesitate."
[cpg cn=true]


[OnName num="zen"]
“You’re absolutely right."
[cpg cn=true]


Takane's words seemed to wake me up.
[cpg]


I love Hazuki and this is what happened as a result of being tied to her. Now it seemed like everything was fine.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

And then, just before closing time.
[cpg]


[FG f="CHA01_p5_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Hazuki153"]
[OnName num="hazuki"]
“Good evening."
[cpg cn=true]


Hazuki came in. Just seeing her, I naturally felt relieved.
[cpg]


[OnName num="zen"]
"Ah. You came, good evening.”
[cpg cn=true]


Takane was not with me at that time.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki154"]
[OnName num="hazuki"]
“I don't think I need to worry about it since Takane is here, but I thought I'd cook dinner."
[cpg cn=true]


[OnName num="zen"]
“Thank you. That makes me happy.”
[cpg cn=true]



;//ブラックアウト
[free time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="4/5" time=800]


[VOICE f="Takane158"]
[OnName num="takane"]
"Oh, Hazuki. You are like a commuting wife.”
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Hazuki155"]
[OnName num="hazuki"]
“I won't ...... deny it."
[cpg cn=true]


The smile on Takane's face didn't seem sarcastic.
[cpg]


And then the meal for the three of us was ready.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="zen"]
“Whew......I'm full.”
[cpg cn=true]


I've had a bath, and now all I have to do is go to bed.
[cpg]


Hazuki said she was going to stay the night, but I guessed she was going to sleep in Takane's room.
[cpg]


I was trying to feel as saintly as possible, because I was afraid that if I had any strange expectations, I would end up acting on them.
[cpg]

;//移植のためシーンをカットしています


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[SE f="se015"]
;//【ＳＥ】『鳥の鳴き声』

[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Takane159"]
[OnName num="takane"]
“Good morning. Master, Hazuki."
[cpg cn=true]

[FG f="CHA01_p3_02_a.ui" method="change_5"  pos="4/5" time=800]
[VOICE f="Hazuki156"]
[OnName num="hazuki"]
“Mmhhh…..what?”
[cpg cn=true]


Takane woke me up and I rubbed my eyes.
[cpg]



[FACE method="shake_7" pos="2/5"]
[VOICE f="Takane160"]
[OnName num="takane"]
“I think I'm like Midori. I wish you would hide it a little more.”
[cpg cn=true]



[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p5_02_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

The fact is that..... Hazuki had visited my room last night just before I went to bed.
[cpg]

She wanted to do something that was more couple-like, so we decided to chat until we fell asleep.
[cpg]

However, we found ourselves falling asleep together .......
[cpg]

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA01_p3_02_a.ui" method="change_5"  pos="4/5" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


One of us should have woken up before Takane.
[cpg]


[OnName num="zen"]
“Sorry......."
[cpg cn=true]


There were no words to explain, but Takane smiled in dismay.
[cpg]


[FACE method="shake_2" pos="2/5"]
[VOICE f="Takane161"]
[OnName num="takane"]
“No need to apologize. I was actually awake when Hazuki left the room."
[cpg cn=true]


Hazuki and I looked at each other.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

Considering Takane's state of mind, I had done a terrible thing.
[cpg]


Then we didn't have much conversation, but we had to do our ordinary work.
[cpg]


[OnName num="customer"]
“I heard there's a new curse out there. I heard that it can kill people."
[cpg cn=true]


[OnName num="zen"]
“That's right.”
[cpg cn=true]


[OnName num="customer"]
“There was an incident near my place, please do something about it.”
[cpg cn=true]


[OnName num="zen"]
“Yes……. Shall we go investigate?”
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Takane162"]
[OnName num="takane"]
"You're a little too relaxed, sir. You have to be more focused.”
[cpg cn=true]


[OnName num="zen"]
“Oh, yeah. You’re right.”
[cpg cn=true]


It's not that I didn't sleep well, but I have a lot on my mind.
[cpg]


Work is work. I have to detach it from my personal life.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


As I researched, I was amazed at the power of the new curse.
[cpg]


What used to be a bad thing in the human body has now become a completely supernatural phenomenon.
[cpg]



[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿居間』（夕方）******************************************************

It was something I wanted to discuss with Nagisa, so I visited her house.
[cpg]


[FG f="CHA05_p5_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nagisa052"]
[OnName num="nagisa"]
"I'm happy for you two. I was worried because she had always said she wasn't interested in love."
[cpg cn=true]


[OnName num="zen"]
“.... Yeah. She might have said so.”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Nagisa053"]
[OnName num="nagisa"]
“Hazuki has a boyfriend. I thought if anyone, it would be you Zen.”
[cpg cn=true]


[OnName num="zen"]
"Well...... Nagisa, I'm here to talk about the curse.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Nagisa054"]
[OnName num="nagisa"]
“I know, but I can't help talking about it.”
[cpg cn=true]


I look around. Hazuki seems to be away doing her job as a Miko.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nagisa055"]
[OnName num="nagisa"]
“I'll tell you what, why don't you stay the night? Although I can't offer you any proper hospitality."
[cpg cn=true]


[OnName num="zen"]
“Umm….."
[cpg cn=true]


It's better to do certain things with Takane not being here.
[cpg]


I wondered if it would be better if I stayed over today, even if it was too sudden.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p3_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿居間』（夜）******************************************************

On a different day, the three of us, Hazuki, Nagisa and I got together.
[cpg]


I knew Nagisa was sincerely congratulating me, but it was still awkward.
[cpg]


We mainly talked about casual things. Still, ......
[cpg]


I could see Nagisa's intention in every word, as if she was expecting Hazuki to get married.
[cpg]


Of course, if you ask me if I intend to marry her, I would like to. But it doesn’t feel real yet.
[cpg]


What about Hazuki? I wonder if she is ready to be with me, to be a family.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//移植のためシーンをカットしています

That night, Hazuki visited me again.
[cpg]


;//========================================
;//●ＣＧ（主人公に迫るヒロイン）ev_29
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン１の部屋
;//時間　：夜
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_29_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[wait time=1000]

[OnName num="zen"]
“Hazuki, you’re surprisingly aggressive.”
[cpg cn=true]


[VOICE f="Hazuki157"]
[OnName num="hazuki"]
“I'm doing it because I think you want it. Is that weird?”
[cpg cn=true]


She's not ashamed of it. I'm sure she's thinking about me to a certain extent.
[cpg]

I was just happy that she was near me.
[cpg]

[OnName num="zen"]
“I want you to be near me more.”
[cpg cn=true]


If we get any closer, our bodies will touch.
[cpg]

Still, Hazuki approached me.
[cpg]


;//移植のためシーンをカットしています

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1100]

;//そして二人、寄り添って寝た……と言えたらいいんだけど。
そして二人、寄り添って寝た……
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿居間』（朝）******************************************************

We woke up early in the morning given our past mistakes.
[cpg]


We slept apart after changing in our nightgowns.
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Nagisa056"]
[OnName num="nagisa"]
“Good morning, you two. Did you sleep well?"
[cpg cn=true]


Nagisa was smiling, but I wondered if we were smiling.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Hazuki158"]
[OnName num="hazuki"]
“Yes, of course.”
[cpg cn=true]


Hazuki's smile seemed a little unnatural.
[cpg]


I'm probably like that too.
[cpg]



[FACE method="change_1" pos="4/5"]
[VOICE f="Nagisa057"]
[OnName num="nagisa"]
“I made breakfast. If you want, you should have some too, Zen.”
[cpg cn=true]


[OnName num="zen"]
“Thank you."
[cpg cn=true]


;//ブラックアウト

[FACE method="change_2" pos="2/5"]
[FACE method="change_2" pos="4/5"]

The three of us, Hazuki, Nagisa and I, were happy together at the dining table.
[cpg]

[FACE method="bows_1" pos="4/5"]

A brief peaceful moment within the turbulent days. Looking back, many things have happened.
[cpg]

[FACE method="shake_1" pos="2/5"]

After the curse fiasco began, I broke Hazuki's second curse.
[cpg]

[FACE method="bow_2" pos="2/5"]

The Onmyoji blood proved effective, and overall the curse is decreasing. But there was one thing I had always been concerned about.
[cpg]

[FACE method="bow_2" pos="4/5"]

It was the unidentified entity. It is neither a curse nor a Yokai.
[cpg]


[FACE method="change_2" pos="2/5"]
[FACE method="change_2" pos="4/5"]


I knew that I could not live quietly with Hazuki without solving it.
[cpg]


;//ジャンプ先指定
;//総合ルートへ
;//[jump target="*select00_0"]


[jump storage="ep013.ks" target="*select00_0"]
