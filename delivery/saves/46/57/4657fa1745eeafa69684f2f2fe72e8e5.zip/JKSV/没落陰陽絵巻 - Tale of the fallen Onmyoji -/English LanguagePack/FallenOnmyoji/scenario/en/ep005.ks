
*start

;#################################################
*Ep005|A new collaborator
;#################################################

[SCENE id=5]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

I did a lot of research in between consulting with my clients.
[cpg]


Since it would be absurd to say that the saliva of an Onmyoji is effective against curses, I decided to come up with a good reason.
[cpg]


Otherwise, it wouldn't prove that I was the one who came up with the idea in the first place.
[cpg]


[OnName num="zen"]
“I better call Midori... She's the one who spread the word.”
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane127"]
[OnName num="takane"]
“Shall I go get her? Or shall I take care of the store?"
[cpg cn=true]


[OnName num="zen"]
“I'd like you to go get her, please.”
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[WAIT time=2100]
[free time=1000]

Takane replied cheerfully and left the store.
[cpg]


She did not seem to be bothered by what had happened the other day. Or is she trying to act that way?
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

;//[SE f="se004"]
;//【ＳＥ】『道歩く』

I asked Takane to call Midori for me. I thought she was busy, but she came to me.
[cpg]




[FACE method="bow_1" pos="4/5"]
[VOICE f="Midori078"]
[OnName num="midori"]
“In the Onmyoji community, the word has spread that I was one of the first to come up with the idea.”
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Midori079"]
[OnName num="midori"]
“So, if I say that I learned it from you, then that would be enough to prove it.”
[cpg cn=true]


Midori seemed to be very optimistic. Or perhaps she doesn't really understand my position.
[cpg]


[OnName num="zen"]
“It's not going to work out that way. I don't have the status or the trust to do that.”
[cpg cn=true]


Midori crosses her arms and thinks. I may have gone a little overboard, but it's close to the truth.
[cpg]


[OnName num="zen"]
“Come to think of it, I've seen a number of people who've been cursed, and I'm not even affected myself.”
[cpg cn=true]


I've been thinking about this for a while. That Onmyoji might be less susceptible to curses.
[cpg]


[OnName num="zen"]
“Statistically, there are very few cases of Onmyoji practitioners turning into Yokai right?”
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Midori080"]
[OnName num="midori"]
“Is that so?"
[cpg cn=true]


[OnName num="zen"]
“Yes. If the data we have at home is correct.”
[cpg cn=true]


I think it is a result of the fact that saliva from Onmyoji is effective against curses.
[cpg]


The Onmyoji is a profession that has been developed by people who are not susceptible to curses in the first place.
[cpg]


If Onmyoji is inherited through DNA, it would not be surprising if Onmyoji's family members are becoming more and more resistant to curses.
[cpg]


When I told them about this, Takane asked me.
[cpg]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Takane128"]
[OnName num="takane"]
“But, Midori was under a curse, wasn't she?"
[cpg cn=true]


[OnName num="zen"]
“Certainly….."
[cpg cn=true]


Then I wondered if this hypothesis was incorrect, and Midori said,
[cpg]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Midori081"]
[OnName num="midori"]
“I don't come from a family of Onmyoji. I am a Miko.”
[cpg cn=true]


[OnName num="zen"]
“Oh, that's right. Did you learn the art of Onmyoji on your own?”
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Midori082"]
[OnName num="midori"]
“Not so much, but I acquired it through my training.”
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Takane129"]
[OnName num="takane"]
“I see...... That would explain why you got affected by the curse.”
[cpg cn=true]


My hypothesis was becoming more and more realistic. I'd like to confirm it a little more and make it something I can share with others.
[cpg]


[SE f="se001"]
;//【ＳＥ】「戸を開ける」

Then a visitor came in.
[cpg]


[OnName num="customer"]
“What's going on? There are so many people here today.”
[cpg cn=true]


[OnName num="zen"]
“Welcome. Yes, I have a guest ……"
[cpg cn=true]


I wondered if I should say "a guest" when a real customer was coming. I decided to serve them.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

[OnName num="customer"]
“It's a dangerous world we live in, isn't it, with all the curses and such?”
[cpg cn=true]


[OnName num="zen"]
“Yes, well, although I see a solution.”
[cpg cn=true]


[OnName num="customer"]
“I see your place is thriving. That seems about right.”
[cpg cn=true]


The elderly man was a regular customer, or rather a neighbor and the talk about Yokai was merely gossip.
[cpg]


He paid me for the consultation, so I had nothing to complain about.
[cpg]


[OnName num="customer"]
“Well, isn't it almost the annual celebration of your store?”
[cpg cn=true]


[OnName num="zen"]
“How do you know? It’s in three days from now.”
[cpg cn=true]


[OnName num="customer"]
“I'm going to pay you a little more for today's consultation. Consider it a celebration gift.”
[cpg cn=true]


[OnName num="zen"]
“Oh, are you sure ......?"
[cpg cn=true]



[SE f="se012"]
;//【ＳＥ】『歩き去る』

After such a conversation he left.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Midori083"]
[OnName num="midori"]
“I see your opening day is coming up.”
[cpg cn=true]


[OnName num="zen"]
“Yes. It's hard to celebrate an anniversary when you haven't achieved anything.”
[cpg cn=true]



[FACE method="shake_2" pos="2/5"]
[VOICE f="Takane130"]
[OnName num="takane"]
“Don't be modest, your’re doing a fine job.”
[cpg cn=true]


Takane is saying that in her usual tone, all-affirmative, but Midori seems to be thinking about something.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I wonder if she is going to give me something to celebrate, too.
[cpg]


If so, it is very different from her initial attitude. I think she even considered me an enemy to begin with.
[cpg]


I wonder if she still feels that way about Hazuki.
[cpg]


Imagining such things, I waited for the opening day.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************


[FACE method="change_1" pos="2/5"]
[FACE method="bow_2" pos="4/5"]
[VOICE f="Midori084"]
[OnName num="midori"]
“Congratulations! Today is the opening day.”
[cpg cn=true]


[OnName num="zen"]
“Yes, it is. Thank you very much.”
[cpg cn=true]


[FACE method="change_1" pos="2/5"]
[VOICE f="Takane131"]
[OnName num="takane"]
“Midori, what is that box…….?”
[cpg cn=true]


Takane asked what I had been wondering about before I did.
[cpg]


She is holding something that looks like a wooden box. And she looked somewhat embarrassed.
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Midori085"]
[OnName num="midori"]
“It's small, but it's a gift of congratulations.
[cpg cn=true]


[OnName num="zen"]
“You didn’t have to. It looks expensive.”
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Midori086"]
[OnName num="midori"]
“Well. I'm also indebted to you……”
[cpg cn=true]


Midori was having a hard time saying it, and even Takane seemed to be nervous seeing it.
[cpg]


[OnName num="zen"]
“May I open it?"
[cpg cn=true]


Another visitor arrived at the door.
[cpg]


[free time=1000]
[FG f="CHA01_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Hazuki099"]
[OnName num="hazuki"]
“Hello. I thought you said the opening day of this place was today.”
[cpg cn=true]


Hazuki came in, saying something similar to what I had heard earlier.
[cpg]

[free time=1000]

[FG f="CHA02_p3_02_a.ui" method="change_5"  pos="4/5" time=800]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/5" time=800]

[FACE method="shock_5" pos="4/5"]

[VOICE f="Midori087"]
[OnName num="midori"]
“Oh, ......!
[cpg cn=true]


Midori turned to Hazuki. She and Hazuki made eye contact.
[cpg]


[FACE method="change_7" pos="2/5"]
[VOICE f="Hazuki100"]
[OnName num="hazuki"]
“You are ...... of the Suzumiya family, it's been a while.”
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
Midori looked surprised at first, but soon she was glaring at Hazuki.
[cpg]



[VOICE f="Midori088"]
[OnName num="midori"]
"Why are you here?"
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Hazuki101"]
[OnName num="hazuki"]
“I'm here to congratulate Zen. Was it better if I hadn’t come?”
[cpg cn=true]

[free time=1000]

[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Takane132"]
[OnName num="takane"]
“No, no, no, no.”
[cpg cn=true]


Takane tries to intervene, but Midori glares at Hazuki.
[cpg]

[free time=1000]

[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p3_02_a.ui" method="change_3"  pos="4/5" time=800]
[VOICE f="Midori089"]
[OnName num="midori"]
“Well my gift is priceless compared to what you might have bought.”
[cpg cn=true]


She is showing her feeling of rivalry. I wonder why Midori is like this about Hazuki.
[cpg]


[FACE method="change_1" pos="2/5"]
[VOICE f="Hazuki102"]
[OnName num="hazuki"]
“My gift is not bought, it’s something I made.”
[cpg cn=true]


[FACE method="shock_4" pos="4/5"]
[VOICE f="Midori090"]
[OnName num="midori"]
“ ......."
[cpg cn=true]


Hazuki has a sharp personality to begin with, but regardless of that, Midori flinched.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Midori091"]
[OnName num="midori"]
“Please open it. You'll love it."
[cpg cn=true]


[OnName num="zen"]
Yes.
[cpg cn=true]


I opened the box, thinking it was refreshing to see Midori like this.
[cpg]


[OnName num="zen"]
“What are these?”
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Midori092"]
[OnName num="midori"]
“They are shoes, imported footwear.”
[cpg cn=true]


I had heard of them. I had heard that they were mainstream footwear outside of this country, and that they were a rational product.
[cpg]


However, I guessed that luxury goods are also luxury goods. I could tell that much just by looking at them.
[cpg]


[OnName num="zen"]
“I can’t accept. They must have been expensive.”
[cpg cn=true]


So Midori must be making a lot of money......I feel a difference in class.
[cpg]


Or maybe it means that she really feels indebted to me.
[cpg]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Midori093"]
[OnName num="midori"]
“It's okay. I wanted to give it to you. Besides, I took a really long time to choose, so please accept it.”
[cpg cn=true]


I glanced at Hazuki as she spoke. Takane looked uncomfortable but laughed.
[cpg]


[OnName num="zen"]
“It is indeed a very Midori-like gift. Well then, we’ll be accepting it.”
[cpg cn=true]


I can somehow understand Midori's admiration for Western things.
[cpg]


I gratefully received it, and we both looked at Hazuki.
[cpg]


[FACE method="shake_5" pos="2/5"]
[VOICE f="Hazuki103"]
[OnName num="hazuki"]
“If you look at me like that it’s hard to bring out the present. It’s not something that unusual.”
[cpg cn=true]


[OnName num="zen"]
“I'm not expecting anything unusual either.”
[cpg cn=true]


“Really?”, she said, and seemed rather unconcerned. Then she got out ......
[cpg]

[free time=1000]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane133"]
[OnName num="takane"]
“An amulet?”
[cpg cn=true]

[free time=1000]

[FG f="CHA01_p3_02_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Hazuki104"]
[OnName num="hazuki"]
“Yes.”
[cpg cn=true]


Well, it is certainly not something anyone can make.
[cpg]


It is likely to be effective if it is a talisman made by a venerable priestess' family and a Miko who is still active in the priesthood.
[cpg]


[FACE method="change_7" pos="4/5"]
[VOICE f="Midori094"]
[OnName num="midori"]
“Even if it is an anumlet, it's just handsom rihghtt?”
[cpg cn=true]


Midori says so with rivalry on her face, but Hazuki is not like that.
[cpg]


[FACE method="change_1" pos="2/5"]
[VOICE f="Hazuki105"]
[OnName num="hazuki"]
“Well, there isn't any amulet that wasn't made by a person.”
[cpg cn=true]


Rather than Hazuki, Midori is different from usual. She wasn't the kind of girl who would say something like this.
[cpg]


Takane looks like she wants to say something, but she seems to be swallowing her words.
[cpg]


[OnName num="zen"]
“Hazuki thank you too. I'll take good care of it.”
[cpg cn=true]


Midori also seemed to want to say something. But,
[cpg]


[FACE method="change_7" pos="4/5"]
[VOICE f="Midori095"]
[OnName num="midori"]
"Which gift makes you happier, ……Zen?",
[cpg cn=true]


She asked. I knew the intent of the question to some extent by the fact that I had trouble answering.
[cpg]


[OnName num="zen"]
“I am happy with both.”
[cpg cn=true]


I was not being indecisive, but I dared to answer that way.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Hazuki106"]
[OnName num="hazuki"]
"You are so kind. But that's a little unfair.”
[cpg cn=true]


But when she said that, I scratched my head. Knowing Hazuki, who is always so bitter, I wanted to know what she was thinking.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]

And so, the special day of the opening anniversary was about to pass just like any other day.
[cpg]


The dinner Takane cooked for us that day was more luxurious than usual. Not in the sense of the ingredients, but in the sense of the time and effort that went into it.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Takane134"]
[OnName num="takane"]
“This is a gift in my own way. Even if I buy something for you, it is still our money.”
[cpg cn=true]


She's really thoughtful, or rather, she knows me well.
[cpg]


That's probably why she looked so awkward when Midori was competing with Hazuki.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I find myself in a somewhat blessed environment.
[cpg]


If it wasn't for my connection with Hazuki, I wouldn't have had the opportunity to do all of this. When Midori moved here, my store almost went out of business.
[cpg]


Midori herself is now in a cooperative relationship with me. Needless to say, Takane is too and I am gaining more allies.
[cpg]


And another new ally was about to join.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大通り』（朝）******************************************************

That person visited my house the day after the anniversary of the opening of the restaurant.
[cpg]


[OnName num="zen"]
“You've been drinking a lot....... You must be a little woozy.”
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakuya029"]
[OnName num="sakuya"]
“I am drinking, but ...... that's not the reason why I'm like this.”
[cpg cn=true]


It is unusual for her to visit me here. Although the opposite was very common.
[cpg]



[OnName num="zen"]
“Perhaps you, too, Sakuya?”
[cpg cn=true]


She nodded. I knew it was that kind of thing, she’s under a curse.
[cpg]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Sakuya030"]
[OnName num="sakuya"]
“I'm under a curse. I can't believe this is happening to me, even though I'm a Yokai.”
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sakuya031"]
[OnName num="sakuya"]
“Or is it possible that I am cursed because I am a Yokai?
[cpg cn=true]


[OnName num="zen"]
“I don't know. We don't have the statistics yet.”
[cpg cn=true]


[OnName num="zen"]
“Anyway, I will examine whether it is a curse or not, and depending on the case, I will do the ...... procedure.”
[cpg cn=true]


Sakuya's face was reddening as she heard me stammering.
[cpg]


It did not seem to be due to the curse, nor was it due to the alcohol.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Sakuya032"]
[OnName num="sakuya"]
“I wonder if it would make you happier if I were under a curse.”
[cpg cn=true]


[OnName num="zen"]
“Why do you say that?”
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Sakuya033"]
[OnName num="sakuya"]
“Because there's a rumor going around about how to break it.”
[cpg cn=true]


[OnName num="zen"]
......
[cpg cn=true]


That makes sense. I told Midori to spread the rumor. I should not have said that I would take care of it.
[cpg]


[OnName num="zen"]
“Anyway, come in. You're too weak to just here and talk.”
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakuya034"]
[OnName num="sakuya"]
“Is there any other way? There’s not right?”
[cpg cn=true]


[OnName num="zen"]
“It's more like we don't know if there is……"
[cpg cn=true]


I knew she wouldn't refuse, given her personality. But I think it's a natural reaction.
[cpg]


I've been in this situation so many times that maybe I'm losing my mind.
[cpg]


[OnName num="zen"]
“I wouldn't say I'm forcing it either. But it's not like the person treating me is just anyone......."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Sakuya035"]
[OnName num="sakuya"]
“I hear that. That's why I'm here."
[cpg cn=true]


Takane brings out the tea, but Sakuya seems to have no time for it.
[cpg]


[OnName num="zen"]
“What kind of curse is it? If have to ask or I won't know if I'm cured or not.”
[cpg cn=true]


Besides, you should consider the location depending on the symptoms. I didn't tell him that, though.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sakuya036"]
[OnName num="sakuya"]
“I miss ...... people. To the point where it's not normal.”
[cpg cn=true]


Then, it's the same curse that Hazuki and the others had.
[cpg]


I'll have to think of something that won't add too much of a burden to her.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Sakuya037"]
[OnName num="sakuya"]
“I don’t know what else to do. Can you fix it?”
[cpg cn=true]


[OnName num="zen"]
“Yes.”
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

My store doesn't have a lot of rooms.
[cpg]


I had to be in a place where I wouldn't be seen, and my room was the perfect for that.
[cpg]


[OnName num="zen"]
“Are you ready……?"
[cpg cn=true]



[FACE method="bow_6" pos="2/3"]
[VOICE f="Sakuya038"]
[OnName num="sakuya"]
“I'm ready. I don't want to be pushed around all the time.
[cpg cn=true]


She was challenging me. I was glad that she had that kind of spirit.
[cpg]


Now, how do I break the curse?
[cpg]



;//選択肢のジャンプ先
*select03_1_0|A new collaborator

;//■選択肢

[switch]
[case "A kiss on the cheek"]
	[swap]
	[jump target="*select03_1_1"]
[case "Kiss the foot"]
	[swap]
	[jump target="*select03_1_2"]
[endswitch]


1. Kiss the cheek
2. Kiss the foot


;//==============================
;//１、頬に口づける

;//選択肢のジャンプ先
*select03_1_1|A new collaborator

I decided to use a method that has been very effective so far.
[cpg]

[OnName num="zen"]
“I will kiss you on the cheek. May I?"
[cpg cn=true]


I asked, and for some reason she stood up.
[cpg]


;//ブラックアウト
;//========================================
;//●ＣＧ（立っているヒロイン。見上げるようなアングル）ev_16
;//人物１：ヒロイン３　服装１：裸
;//人物ex：主人公　　　服装ex：裸
;//場所　：主人公の部屋
;//時間　：昼
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
;//[BGM f="bg_h1"]
[WAIT time=1000]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

[VOICE f="Sakuya039"]
[OnName num="sakuya"]
“......You really are going to do it, aren't you?”
[cpg cn=true]


[OnName num="zen"]
“Why are you getting up?”
[cpg cn=true]


[VOICE f="Sakuya040"]
[OnName num="sakuya"]
“Does it matter? While we’re at it I want you to hold me.”
[cpg cn=true]


She was honest. I wonder if Hazuki and Midori also had these feelings.
[cpg]

But even if she wanted me to, I was not able to respond. Hugging her probably has nothing to do with breaking the curse.
[cpg]


;**【ＣＧ】 ev_16_a ***********************
[CG id=4 index=1 time=1]
;***************************************
[WAIT time=1]



I get up and move closer to her. Then she closes her eyes......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

[FG f="CHA03_p5_01_a.ui" method="change_6"  pos="2/3" time=800]


[OnName num="zen"]
"How do you feel ......? Is the curse lifted?"
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
She nods. Rather than looking embarrassed, she looked somewhat satisfied.
[cpg]



[jump target="*select03_1_4"]

;//==============================
;//２、足に口づける

;//選択肢のジャンプ先
*select03_1_2|A new collaborator.

[OnName num="zen"]
“I'd like a place that's not weird."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sakuya041"]
[OnName num="sakuya"]
“......? What do you mean?"
[cpg cn=true]


;//========================================
;//●ＣＧ（ヒロイン足にキスをする主人公）ev_17
;//人物１：ヒロイン３　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
;//[BGM f="bg_h1"]
[WAIT time=1000]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

I decided to kiss her foot and told her.
[cpg]

[VOICE f="Sakuya042"]
[OnName num="sakuya"]
“..... Why on my feet?"
[cpg cn=true]


That, of course, is exactly what I said earlier.
[cpg]

I'm not as intimate with her as I am with Hazuki. Then, it's better not to kiss her somewhere strange.
[cpg]

If you can kiss a place like this and break the curse, there's nothing better than that......
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



I thought, but it didn't work out that way.
[cpg]

The curse of Sakuya had slowed down a bit, but it was still not broken.
[cpg]

I can't let her go home like this. What should I do now?
[cpg]

;//この選択肢を除いて、もう一度同じ分岐へ戻る

;//■選択肢

[stflag Cha3flg = -1]

[switch]
[case "Kiss the cheek"]
	[swap]
	[jump target="*select03_1_1"]
[endswitch]



[jump target="*select03_1_0"]

;//==============================

;//選択肢のジャンプ先
*select03_1_4|A new collaborator

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="4/5" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

[FACE method="shake_5" pos="4/5"]
[VOICE f="Sakuya043"]
[OnName num="sakuya"]
“Amazing ...... You’ve really cured me.”
[cpg cn=true]


[OnName num="zen"]
“It's something I've verified many times. If there is a chance it won't heal, I can't suggest this."
[cpg cn=true]


“Indeed”, she said, and Sakuya looked as he usually does. She pretends like nothing ever happened.
[cpg]


I was also somewhat concerned about it, and I was acting a little disturbed.
[cpg]


I'm not as close as Hazuki and Takane. I was similar to Midori’s case, but even so, it was not something I could get used to.
[cpg]


[FACE method="change_2" pos="4/5"]
[VOICE f="Sakuya044"]
[OnName num="sakuya"]
“I think you can solve other problems. For example, who I am.”
[cpg cn=true]


[OnName num="zen"]
“Do you want to know ……?"
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Sakuya045"]
[OnName num="sakuya"]
“Of course.”
[cpg cn=true]


She seemed to want to know who she was. I would like to know that too, but...
[cpg]


[OnName num="zen"]
“I can't do it on my own. It's something you won't know unless I do a research with a lot of people.”
[cpg cn=true]


[FACE method="shake_6" pos="4/5"]
[VOICE f="Sakuya046"]
[OnName num="sakuya"]
“You’re right. Forget it."
[cpg cn=true]


Sakuya looked a little sad.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Sakuya047"]
[OnName num="sakuya"]
“I'm grateful for your help. I'm going to return the favor in some way. If you ever need a fox's hand, just let me know."
[cpg cn=true]


A fox's hand. Maybe when I get busy.
[cpg]


[OnName num="zen"]
“Thank you.”
[cpg cn=true]


[FACE method="change_2" pos="4/5"]
[VOICE f="Sakuya048"]
[OnName num="sakuya"]
“Bye.”
[cpg cn=true]


[FACE method="change_2" pos="2/5"]
[VOICE f="Takane135"]
[OnName num="takane"]
“Thank you very much."
[cpg cn=true]


[SE f="se012"]
;//【ＳＥ】「歩き去る」

[FO pos="4/5" time=1000]
[FACE method="bow_2" pos="2/5"]
Takane bowed to Sakuya as she left.
[cpg]

[free time=1000]

[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
It's kind of like a doctor's job, but it's not right to say, "Take care of yourself.” or “Please come back again.” …….
[cpg]


[OnName num="zen"]
“...... I haven't been doing anything detective-like lately.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane136"]
[OnName num="takane"]
“That's fine. You're solving mysterious cases, so you're a detective.”
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************

[OnName num="zen"]
“……”
[cpg cn=true]


I've been thinking about Sakuya’s words ever since.
[cpg]


Who she is. It is the question of many people, but in her case, they are even more poignant.
[cpg]


What does it feel like to really not be able to trace your memories?
[cpg]


I wanted again to help her understand. In order to do so, I can't remain in my current position.
[cpg]


[OnName num="zen"]
"I have to do things in order. First, I have to prove the relationship between curse and Yokai."
[cpg cn=true]



[SE f="se004"]
;//【ＳＥ】『道歩く』

I start to talk to myself. I felt as if I couldn't stand still, so I just kept walking.
[cpg]



;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


And as I walked, I had a flash of inspiration.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Takane137"]
[OnName num="takane"]
“Cultivation of the curse…..?"
[cpg cn=true]


[OnName num="zen"]
“Yes. Artificially increase the number of curses and create Yokai.”
[cpg cn=true]


Takane didn't seem to understand.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Takane138"]
[OnName num="takane"]
“Why would you do that? Isn't it just dangerous?”
[cpg cn=true]


[OnName num="zen"]
“I'm trying to prove that my theory is correct.”
[cpg cn=true]


[OnName num="zen"]
“If I can do this, then I can reveal what a Yokai is and what a curse is.”
[cpg cn=true]


It's hard to explain everything, but I'll have to ask Takane to help me. I'll just have to say it.
[cpg]



;//ブラックアウト


In other words, it's like when humans first discovered something called a germ.
[cpg]


I explained that it would be like trying to recreate the same thing.
[cpg]

[FACE method="shake_7" pos="2/3"]

Takane didn't seem to understand what I was talking about, but from that day on, I began to think about how to cultivate it.
[cpg]


Of course, it would not be done overnight.
[cpg]


I would need to read up on records of people who have tried something similar, but I had already done that.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

After all, curses are microscopic creatures.
[cpg]


If this is the case, it would be possible to use the entire apparatus for scientific experiments.
[cpg]


There have been people who have tried to do so, but it hasn't worked.
[cpg]


The reason is simple. The original curse of the Yokai has not been as prevalent and easily available as it is now.
[cpg]


So the time to experiment was now.
[cpg]




[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

Then, day and night, I began to cultivate the curse.
[cpg]


I am still getting calls from people who say they have been cursed, so I have no trouble collecting the curses.
[cpg]


The problem is where in the human body the curse is, and how to increase it in a state detached from the human body.
[cpg]


As I repeated the process, I gradually understood.
[cpg]


After all, a curse cannot live long when it is detached from the human body. Or rather, there is no way to do it because it is invisible.
[cpg]


So a completely different approach would be needed. So I came up with the idea of animal experiments.
[cpg]



[window target=false]
[free time=1000]
[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『神社の境内』（昼）******************************************************

[OnName num="zen"]
“I’ll do an experiment. I will create Yokai from animals.”
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki107"]
[OnName num="hazuki"]
「妖怪を式神にするならよくある話だけど、その元になる妖怪さえ自分で作ろうって話よね？」
[cpg cn=true]


[OnName num="zen"]
"Yes. I think this is unprecedented.”
[cpg cn=true]


Yes, Hazuki says and becomes thoughtful.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Hazuki108"]
[OnName num="hazuki"]
“If you are an ordinary Onmyoji, you would not even try this because you think it is a fool's errand.”
[cpg cn=true]


[OnName num="zen"]
“But I'm still going to do it. If I don't do it, there will be no further progress.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Hazuki109"]
[OnName num="hazuki"]
“I agree. This is what you were was born for.”
[cpg cn=true]


Hazuki agreed. If it comes to this, I'll just do it.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki110"]
[OnName num="hazuki"]
“So what exactly are you going to do?”
[cpg cn=true]


[OnName num="zen"]
“I'm going to have a rat kept in the immediate vicinity of a person who is cursed.”
[cpg cn=true]


The rat that becomes a Yokai which I will call an iron rat. Rats have been an animal close to Yokai since ancient times.
[cpg]


[OnName num="zen"]
“It’s not like the Yokai will own the rat. If it is a curse that wants to find a home, it may possess the rat.”
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Hazuki111"]
[OnName num="hazuki"]
“But if a human being is cursed, he is still a human being. I think it is the same for rats.”
[cpg cn=true]


It is certainly possible, but there is no other way.
[cpg]


[OnName num="zen"]
“There are still many things we don't know about that.”
[cpg cn=true]


[OnName num="zen"]
“But it is true that there are more Yokai based on animals than those based on humans.”
[cpg cn=true]


We exchanged our opinions as we built our experiment.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************


[VOICE f="Midori096"]
[OnName num="midori"]
“…… I think it's an interesting experiment, but what do you do with the animals after you turn them into Yokai?"
[cpg cn=true]


[OnName num="zen"]
“Since we're at this point, I'm thinking of turning them into Shikigami.”
[cpg cn=true]


It is easier to turn a Yokai into a Shikigami than to turn an animal into a Yokai.
[cpg]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Takane139"]
[OnName num="takane"]
“In any case, it would be better to look at past examples to see how to make it work.”
[cpg cn=true]


[OnName num="zen"]
“I'm trying to do that. I think it will work.”
[cpg cn=true]


Then, when the next consultant comes along, I'll ask him for a favor.
[cpg]


Instead of charging a fee to break the curse, it should be in the form of ...... something like that.
[cpg]



[SE f="se004"]
;//【ＳＥ】『道歩く』

[OnName num="customer"]
“I'm sorry, I need to consult with you ......."
[cpg cn=true]


In the meantime, a female customer came in.
[cpg]


[OnName num="zen"]
“Welcome. Please wait a moment.”
[cpg cn=true]


I folded up the materials about the experiment and went to the customer.
[cpg]



;//ブラックアウト
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


As I listened to what she had to say, it seemed that she, too, was under a curse.
[cpg]


Thinking it was a godsend, I quickly negotiated with her.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

[OnName num="zen"]
“If you don't mind, I'd like you to accompany me for a little experiment. I can't lift the curse right away, but you won’t have to pay.”
[cpg cn=true]

[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
While I was negotiating, Takane tugged at the hem of my kimono.
[cpg]


[OnName num="zen"]
“What?"
[cpg cn=true]


I turned around and whispered back. Takane turned around and whispered back too.
[cpg]



[FACE method="shake_7" pos="2/3"]
[VOICE f="Takane140"]
[OnName num="takane"]
“You shouldn't do this today, sir.”
[cpg cn=true]


[OnName num="zen"]
“Why?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Takane141"]
[OnName num="takane"]
“Why? Because it's the sixth day of Buddha's death.”
[cpg cn=true]


[OnName num="zen"]
"...... As an Onmyoji, I would say the sixth brightness."
[cpg cn=true]


Takane believes in the six brightnesses. I've known this for a while, but I can't believe she would say it at a time like this.
[cpg]

[free time=1000]
I don't mind, I turn back to the customer and negotiate with her to cooperate with the experiment.
[cpg]


[OnName num="zen"]
“I want you to keep this rat as your pet. I might change your condition.”
[cpg cn=true]


[OnName num="customer"]
“What? If it's for free.……"
[cpg cn=true]


The customer seemed a little worried, and Takane tried to stop me, but things went on.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『汎用室内』（夕方）******************************************************

I'll definitely break the curse, and I'll even pay for taking part in the experiment.
[cpg]


After negotiating with them, the clients cooperated. After a week had passed.
[cpg]


[OnName num="zen"]
"I knew it....... their fur is changing."
[cpg cn=true]


The rat was showing signs of changing into a Yokai. It was good to have Midori as a witness.
[cpg]


[FG f="CHA02_p5_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Midori097"]
[OnName num="midori"]
“It's a great discovery. It seems that curses really are the smallest unit of Yokai.”
[cpg cn=true]


[OnName num="customer"]
“Oh, umm... The method of having the curse lifted……."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[OnName num="zen"]
“Of course, I haven't forgotten about it. I'll take care of it right away, um......."
[cpg cn=true]



[SE f="se008"]
;//【ＳＥ】「廊下を歩く」

[free time=1000]


When I gave Midori a look, she quickly left the room.
[cpg]


But this was not the main part. I was thinking about what I was going to do next, feeling that I was getting a good response.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************

I had the results of my research communicated to the government's Onmyoji through Midori.
[cpg]


I knew they would not ignore me. That's how much I did.
[cpg]


Possibly, I may be approached directly by a high ranking Onmyoji.
[cpg]


I am the one who created the method to break the curse. And one of the first to create a Yokai from a curse.
[cpg]


There is no way they would leave me alone, either way.
[cpg]



;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


Of course, since there are many people who have been cursed, these things may have happened by chance.
[cpg]


But I must have been the first to intentionally cause it.
[cpg]


Because I am the only one who thinks there is a relationship between curses and Yokai.
[cpg]


The turning point came early as I waited dreaming.
[cpg]


[jump storage="ep006.ks" target="*start"]

;////////////////////////////////////////////////////////////////
