
;//==============================
;//１、ヒロイン１を選んでいた場合

;#################################################
*Ep014|The Road to Hazuki
;#################################################

[stflag Cha1flg=0]
[stflag Cha2flg=0]
[stflag Cha3flg=0]
[stflag Cha4flg=0]
[stflag Cha5flg=0]


;//選択肢のジャンプ先
*select01_0|The Road to Hazuki

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[SCENE id=14]

Then, I knew where I was going.
[cpg]


A familiar path. The road to the shrine where Hazuki works.
[cpg]


I had always been curious about her. After all, she was the one who was possessed by the god of plague.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『神社の境内』（昼）******************************************************

She stood smiling at the meeting place.
[cpg]


[OnName num="zen"]
“How is your body since? Is everything all right?”
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki177"]
[OnName num="hazuki"]
"Yes, I'm fine. My body is fine.”
[cpg cn=true]


[OnName num="zen"]
“What do you mean ‘your body’?”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Hazuki178"]
[OnName num="hazuki"]
“I still can't remember what happened when I was possessed by ...... that thing.”
[cpg cn=true]


It was different from a curse, after all. Which is only natural since it had the ability to possess a body.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Hazuki179"]
[OnName num="hazuki"]
“But I do remember the moment when I was taken over and I was scared.”
[cpg cn=true]


[OnName num="zen"]
“I'm sure you were. I'm really glad I was able to defeat it.”
[cpg cn=true]


Hazuki nodded and looked somewhere far away.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki180"]
[OnName num="hazuki"]
“I don't remember anything, so it was like time jumped, but I am glad to see you again.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Hazuki181"]
[OnName num="hazuki"]
“I'm glad we can talk like this again. It's thanks to you Zen.”
[cpg cn=true]


[OnName num="zen"]
“No way. There's only so much I can do.”
[cpg cn=true]


It was not just a humble remark.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大通り』（夜）******************************************************

I am still at the bottom. The Kinoto curse fiasco is over and I am now recognized as a Onmyoji but......
[cpg]


In the end, the people decided that Hazuki was the most significant person in that incident, and I believed so too.
[cpg]


So Hazuki has become a Miko of an even higher status, and the gap between me and her is far away from closing.
[cpg]


I'm still going to be chasing after her. But I think that's fine too.
[cpg]


[OnName num="zen"]
“The difference in status turns men on…..”
[cpg cn=true]


I mutter to myself on the way home. Somewhere, I want Hazuki to stay unreachable.
[cpg]


I won't stop chasing after her, of course, but I also don't want to see Hazuki in taking the position for granted.
[cpg]


This kind of distance may be a good fit for us.
[cpg]


Thinking back, I've been chasing her for a long time.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_09_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane230"]
[OnName num="takane"]
“Welcome back, master."
[cpg cn=true]


Takane is waiting for me to come home again today. I had mixed feelings.
[cpg]


[OnName num="zen"]
"I'm sorry I'm late.”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Takane231"]
[OnName num="takane"]
“No, no. Don't worry about me. I knew this would happen one day."
[cpg cn=true]


Considering Takane's feelings, I could not talk too much about it.
[cpg]


I should keep this overflowing feeling inside of me.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

Yes. I shouldn’t mind being alone.
[cpg]


I didn't think that solitary time was worth it before, but after I told Hazuki how I felt about her, I thought differently.
[cpg]


I really wanted to be worthy of her.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

The store suddenly became crowded. Even so, since people are still reluctant of coming to my place it must be even more crowded for Midori.
[cpg]


The town was so afraid of the Plague God that they thought I would never be able to exterminate it.
[cpg]


Maybe it was an accomplishment I was not worthy of. So I had to be more worthy.
[cpg]


That's what I thought, considering that I was Hazuki's lover.
[cpg]


[window target=false]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大通り』（昼）******************************************************

It's getting harder for both Hazuki and me to make time for each other, but that doesn't change the fact that I still want to see her.
[cpg]


I've been looking forward to the day we can meet since the night before. Hm……
[cpg]


We are like children, but it's the first time for both of us.
[cpg]


I guess it's not wrong to say that we are like children when it comes to love.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿居間』（昼）******************************************************

[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hazuki182"]
[OnName num="hazuki"]
“Are you looking forward to it that much? I'm sorry, but I'm the same as always."
[cpg cn=true]


She's as cold as ever, but that’s why I'm attracted to her.
[cpg]


[OnName num="zen"]
“You’re right. There is still difference in status and I'm not enough to sway you yet.”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Hazuki183"]
[OnName num="hazuki"]
"Different status? I’m not sure about that. My mother approves of you.”
[cpg cn=true]


[OnName num="zen"]
“Are you sure? Even if she does, others don't.”
[cpg cn=true]


I'm pretty sure we're dating publicly, but I don't think we'll be husband and wife for a little while yet.
[cpg]


[OnName num="zen"]
“Well, please wait a little while longer. I'll catch up with you soon enough.”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Hazuki184"]
[OnName num="hazuki"]
“That's not what you said earlier.”, she chuckles.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki185"]
[OnName num="hazuki"]
“First you're vain, and then you're mean. That’s very likely of you.”
[cpg cn=true]


She says something that makes me want to deny it. But she was right.
[cpg]


The reason I came to think that way was because of that one incident...... extermination of the Plague God.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hazuki186"]
[OnName num="hazuki"]
“I was scared for a long time. I was afraid that as my mom’s daughter, I wasn't good enough.”
[cpg cn=true]


[OnName num="zen"]
“You thought that?”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki187"]
[OnName num="hazuki"]
“Well, you know, I was protected by my position, and I kept wondering if that was okay."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Hazuki188"]
[OnName num="hazuki"]
“But this one incident has given me a little confidence. Of course, it’s also thanks to you.”
[cpg cn=true]


[OnName num="zen"]
“I'm the same way. If it weren't for you Hatsuki, it would have escaped.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki189"]
[OnName num="hazuki"]
“It's strange when you think about it. Maybe your idea alone, or my idea alone, could not have defeated it."
[cpg cn=true]


I guess this is the importance of people with different principles encountering each other.
[cpg]


Somehow, I feel like I was being tested by a curse or the Plague God.
[cpg]


Of course, it's not like that, and it's all unrelated, but when I'm with Hazuki, it all seems to make sense.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Hazuki190"]
[OnName num="hazuki"]
“It's embarrassing to say that …….we were meant to be.”
[cpg cn=true]


[OnName num="zen"]
“Well. I feel the same way.”
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿居間』（夕方）******************************************************

Nagisa seems to have been busy since that incident.
[cpg]


She is retired, but she was involved in that case and played a part in the successful extermination.
[cpg]


I guess that’s why she is busy but it was good for us that she was coming home late.
[cpg]

We can be together without having to think of others……
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿居間』（夜）******************************************************

I had to return home before Nagisa came back.
[cpg]


We're just lovers. We are supposedly in a healthy relationship.
[cpg]


[FG f="CHA01_p5_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Hazuki191"]
[OnName num="hazuki"]
“Well then, ...... see you soon. Come by anytime.”
[cpg cn=true]


[OnName num="zen"]
"Yea. See you.”
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大通り』（夜）******************************************************

On my way home, I had a strange feeling.
[cpg]


My personality and Hazuki's personality are completely different. Even if you only look at it in terms of rationality and irrationality.
[cpg]


I still don't know why we were attracted to each other. I don't think it was just because I was around her when we were children.
[cpg]


But as a result of our encounter, we have conquered the Plague God.
[cpg]


There must be a reason. And that role is probably not over yet.
[cpg]


I returned home, still feeling a sense of mission.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[free time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=1000]



There must still be something that I have to do.
[cpg]


I must not just keep following after her. Someday, I must catch up.
[cpg]


[if exp={getFlagValue("Cha1flg") == 2 }]
;//ジャンプ先指定
;//[jump target="*select01_1"]
[jump storage="ep015.ks" target="*select01_1"]
[endif]

;//END
;//ブラックアウト

[jump storage="epend.ks" target="*start"]


;//==============================
