
*start

;#################################################
*Ep002|A New Onmyoji
;#################################################

[SCENE id=2]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************

In the end, we never found out how the curse of Hazuki was lifted.
[cpg]


Even now, the curse is spreading in various forms in Kinoto.
[cpg]


Even if superficially the same as before, the number of people suffering from the curse must be increasing.
[cpg]


After all, we still don't know the solution. It may increase, but it will not decrease.
[cpg]


Then, what I know would be quite beneficial.......
[cpg]


Even if I think so, I can't take any action. There are too many undetermined things.
[cpg]



;//下記のセリフ、翠の名前欄を「謎の少女」と置き換えてください


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Midori001"]
[OnName num="mysterious_girl"]
“Umm. You're Zen Kamono, aren't you?”
[cpg cn=true]


As I was thinking this, I was suddenly approached by a strange girl.
[cpg]


[OnName num="zen"]
“What? Ah, yes.”
[cpg cn=true]


She was very beautiful, but her face was somewhat emotionless. She looked like a doll.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Midori002"]
[OnName num="midori"]
“I heard that you were an Onmyoji. I'm Midori Suzumiya, and I just moved to this neighborhood.”
[cpg cn=true]


She greeted me in a polite tone, but without bowing her head. I was a little uncomfortable, but I answered.
[cpg]


[OnName num="zen"]
"It's nice to meet you……."
[cpg cn=true]


I didn't know about someone moving in until now, although it seems like it should have been a rumor.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Midori003"]
[OnName num="midori"]
“I'm also an Onmyoji. So you and I are business rivals.”
[cpg cn=true]


I was a little caught by the word "business rival," but the point is that we were in the same community.
[cpg]


[OnName num="zen"]
“Is that so? I am glad to have a fellow Onmyoji so close to me.”
[cpg cn=true]


The person, who introduced herself as Midori, looked a little grim.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Midori004"]
[OnName num="midori"]
“Don't get me wrong. I am not speaking to you to build a connection. This is a declaration of war."
[cpg cn=true]


Hearing these ruthless words, I asked her.
[cpg]


[OnName num="zen"]
“What? It sounded like you said ‘a declaration of war’.”
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Midori005"]
[OnName num="midori"]
“Yes, you didn’t mishear it. That's how I said it.”
[cpg cn=true]


She seems to see me as an enemy. But I have no reason to be resented.
[cpg]


If there is an Onmyoji nearby and have trouble working, just live in a different place.......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『神社の境内』（夕方）******************************************************

In general, I had the impression that she was a mysterious girl. I was talking to Hazuki about it.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hazuki075"]
[OnName num="hazuki"]
"Midori...... that's a name I've heard before."
[cpg cn=true]


It seemed like Hazuki knew her.
[cpg]


[OnName num="zen"]
“Do you know her?”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki076"]
[OnName num="hazuki"]
“I think the girl from Suzumiya was also named Midori.”
[cpg cn=true]


[OnName num="zen"]
“….. Oh."
[cpg cn=true]


Suzumiya. I've heard of it, it's a family of priests. I think it was a family that was hostile to Hazuki's family.
[cpg]


It wasn’t because of the faction, it's that Suzumiya used both Miko and Onmyoji techniques, so they were treated like outsiders.
[cpg]


[OnName num="zen"]
“I kind of remember her….. she might have looked like that.”
[cpg cn=true]


[OnName num="zen"]
“My memory's a little fuzzy too, but she hadn't forgotten me.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki077"]
[OnName num="hazuki"]
“My mother might know more about it. Should we ask her?"
[cpg cn=true]


I nodded and Hazuki went to call Nagisa.
[cpg]

[SE f="se004"]
;//【ＳＥ】『道歩く』

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p3_02_a.ui" method="change_2"  pos="4/5" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『神社の境内』（夕方）******************************************************

[FACE method="bow_2" pos="4/5"]
[VOICE f="Nagisa016"]
[OnName num="nagisa"]
“Midori is here? It's going to be lively, I wonder how old she is now.”
[cpg cn=true]


Nagisa, of course, remembered. She knew more about it than we did.
[cpg]


[OnName num="zen"]
“She was very hostile toward me. She even declared war on me.”
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Nagisa017"]
[OnName num="nagisa"]
"That may be so, since she was often compared to Hazuki.”
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Hazuki078"]
[OnName num="hazuki"]
"...... was that so? I don't remember.”
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Nagisa018"]
[OnName num="nagisa"]
"You don't remember? Maybe she thinks that you took Zen away from her.”
[cpg cn=true]


Hazuki looks surprised. This topic could make her feel embarrassed or uneasy.
[cpg]


But Hazuki is not averse to the topic and is silent.
[cpg]


[OnName num="zen"]
“What do you mean......?"
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
Somehow I didn't like the silence, so I spoke up. Nagisa chuckles.
[cpg]


I knew that Nagisa was trying to get us together.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『大通り』（夜）******************************************************


But anyway, Midori. I don't know that there was such a girl. It was when I was a kid, so I’d forgotten the story.
[cpg]


After all, I've been too busy to look back on the past, so no wonder I've forgotten about it.
[cpg]



[window target=false]
[free time=1000]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_09_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="Takane067"]
[OnName num="takane"]
"Midori, is it ......? I vaguely remember whether I had heard that name or not.”
[cpg cn=true]


[OnName num="zen"]
“I know. It was when we were a kid."
[cpg cn=true]


Takane doesn't remember it either. Maybe she has never met her in person.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Takane068"]
[OnName num="takane"]
"But if Nagisa said that, then maybe she was in love with you master."
[cpg cn=true]


[OnName num="zen"]
“What? I don't even remember dumping her.”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Takane069"]
[OnName num="takane"]
“I don't know. You might be an unconscious lover boy.”
[cpg cn=true]


She sometimes makes fun of me. There is a side of her that seems to have blind faith in me.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Takane070"]
[OnName num="takane"]
“More importantly, you have to think about how to break the curse.”
[cpg cn=true]


[OnName num="zen"]
“Yes, that's right. They say a new curse is spreading.”
[cpg cn=true]


And if curses are spreading, work is going to be a lot busier......
[cpg]



;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]

But in fact, that was not the case. It had to do with another factor.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

[OnName num="zen"]
“….. I'm sleepy.”
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane071"]
[OnName num="takane"]
“Well..... I'm going to go clean up. Would you like to help? It might get you to awake.”
[cpg cn=true]

[free time=1000]
[WAIT time=1100]

Our work was visibly reduced. Midori sees Hazuki as an enemy and I'm getting involved.
[cpg]


Specifically, she was even taking all the nearby customers at once.
[cpg]


This is because, while I am from a family that has fallen, Midori's family is at least venerable in the priesthood.
[cpg]


She calls herself a Onmyoji without a degree, but I guess that means Midori is more trustworthy than me who doesn’t have a solid background.
[cpg]


[OnName num="zen"]
“At this rate, my savings will run out soon ......."
[cpg cn=true]


I mumbled to myself after checking that Takane had gone away to clean up.
[cpg]


Do I have to find another job now? Is the research as a Onmyoji something I can only do in my free time…..?
[cpg]


But I'm close to figured out how to break the curse.
[cpg]


I don't want to back out. But the days went by and I couldn't do anything.
[cpg]



;//ブラックアウト


I don't have that many people I can rely on. If Hazuki is busy, it's Takane, and if I can't solve the problem by talking to Takane......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[SE f="se004"]
;//【ＳＥ】『道歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町外れ』（昼）******************************************************



Being desperate I went to visit Sakuya.
[cpg]


She was trying to fix the same umbrella again. I guess it broke again.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakuya006"]
[OnName num="sakuya"]
"Oh, it's been a long time. Is there something that you want?"
[cpg cn=true]


[OnName num="zen"]
“Yes."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sakuya007"]
[OnName num="sakuya"]
“I can't entertain you, but come on in. I'm bored, just like you.”
[cpg cn=true]


Was it written on my face? No, it would look that way if I came here in the middle of the day.
[cpg]


[OnName num="zen"]
“I'll fix your umbrella. It's broken the same way as before.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sakuya008"]
[OnName num="sakuya"]
"Yes, that's probably true. I often seem to break this kind of workmanship.”
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『戸を開ける』


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『汎用室内』（昼）******************************************************


[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakuya009"]
[OnName num="sakuya"]
"Hmmm, I didn't know that.”
[cpg cn=true]


[OnName num="zen"]
“That's a big deal to me. It's a business matter.”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sakuya010"]
[OnName num="sakuya"]
“Don't worry. I know there's a curse going around town.”
[cpg cn=true]


[OnName num="zen"]
“Well, it's going to bring in more business. Unless someone takes it all away……"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sakuya011"]
[OnName num="sakuya"]
“Maybe it's not that simple..…if this Midori girl gets cursed, it'll all be over, won't it?"
[cpg cn=true]


I hadn't thought of that possibility...
[cpg]


[OnName num="zen"]
“What are the odds that it would happen. I’m not a sorcerer.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sakuya012"]
[OnName num="sakuya"]
“You’re not? If you're a Onmyoji, it's similar.”
[cpg cn=true]


[OnName num="zen"]
“Not at all.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sakuya013"]
[OnName num="sakuya"]
“Why don't you study sorcery now? You might be able to make a living.”
[cpg cn=true]


Sakuya is a light-hearted person. The conversation never gets serious. But that is emotionally helpful right now.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町外れ』（夕方）******************************************************

But since I can't talk about it in depth, I can't come up with a solution either.
[cpg]


In the end, I left her house without getting any new information about the curse.
[cpg]




[window target=false]
[BG f="b_09_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

I came back to the store again. Takane greeted me.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane072"]
[OnName num="takane"]
"How was it? Did she know anything about the curse?
[cpg cn=true]


[OnName num="zen"]
“No."
[cpg cn=true]


Just because she is a Yokai doesn't mean she knows much about curses.
[cpg]


So we can assume that Yokai are not in control of curses.
[cpg]


Of course, not every Yokai but I feel there is a clue there.
[cpg]


It's a strange way of getting a clue out of the blue.
[cpg]


[OnName num="zen"]
“Hm......?"
[cpg cn=true]


As I was thinking this, I looked in the corner of the room and saw a cut out piece of paper moving by itself.
[cpg]


It was a paper doll. Something only a Onmyoiji like me could do.
[cpg]


[OnName num="zen"]
“Takane. There's a paper doll in there."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Takane073"]
[OnName num="takane"]
“What? Oh, I was concentrating on cleaning I didn't recognize it.”
[cpg cn=true]

If she was cleaning, she might have been able to find it, but if it was moving so as not to be found, it would be a very advanced technique.
[cpg]

[free time=1000]
;//[BG f="b_09_3.ui" time=1000]

[OnName num="zen"]
“If it was Midori, what was she ...... doing there? Did she come here to steal my research?”
[cpg cn=true]


[VOICE f="Takane074"]
[OnName num="takane"]
“Aah!"
[cpg cn=true]


Takane shouts loudly from outside the store, and I head over to see what's going on.
[cpg]



;//ブラックアウト
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=1000]


[FG f="CHA04_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Takane075"]
[OnName num="takane"]
“Look, our sign has been rewritten! The kanji has changed!”
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Takane076"]
[OnName num="takane"]
"This one, too! The grammar is wrong.”
[cpg cn=true]


I guess she is not trying to steal information. Just a childish prank.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Takane077"]
[OnName num="takane"]
“The letters on the board are also erased!”
[cpg cn=true]


[OnName num="zen"]
“The words are reversed!”
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Takane078"]
[OnName num="takane"]
“Who did this terrible ...... thing! Was it the paper doll that did it?”
[cpg cn=true]


The paper dolls need to be close to the ones who know the craft. If so, there will be no doubt that it was Midori.
[cpg]


But the fact that she did that means that she thinks of me as the enemy.
[cpg]




[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

It was already night when I was fixing all the rewritten letters.
[cpg]


I sat at my desk trying to summarize what I had been thinking about.
[cpg]


It was almost time to close the store.
[cpg]


[FG f="CHA02_p5_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Midori006"]
[OnName num="midori"]
“Good evening.”
[cpg cn=true]


Midori came in. She came directly to me, her business rival.
[cpg]


[OnName num="zen"]
“You did a lot to me today. You sent that paper doll, didn't you?”
[cpg cn=true]



[FACE method="shake_2" pos="2/3"]
[VOICE f="Midori007"]
[OnName num="midori"]
“I don't know what you’re talking about.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Midori008"]
[OnName num="midori"]
“Seems you're trying hard... Even though most of your customers come to me.”
[cpg cn=true]


She didn't seem to be satisfied with my reaction. I guess she thought I was going to make a scene right away.
[cpg]


[OnName num="zen"]
“ I also have my own willpower, and I can't let the family lineage of Onmyoji that has been going on for a long time die out.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Midori009"]
[OnName num="midori"]
“……"
[cpg cn=true]


She looked like she wanted to say something. And Takane is about to make tea. She doesn't know it was Midori, does she?
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Midori010"]
[OnName num="midori"]
“I also have pride. I am going to take down Hauzuki no matter what.”
[cpg cn=true]


Hazuki didn't seem to remember it properly, but I guess the person who holds a grudge remembers it well.
[cpg]


As I was thinking that, Takane offered a cup of tea.
[cpg]

[free time=1000]
[FG f="CHA02_p3_02_a.ui" method="change_3"  pos="4/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Takane079"]
[OnName num="takane"]
“Please have a seat.”
[cpg cn=true]


[FACE method="shake_3" pos="4/5"]
[VOICE f="Midori011"]
[OnName num="midori"]
“No, thank you.”
[cpg cn=true]


[FACE method="shock_5" pos="2/5"]
[VOICE f="Takane080"]
[OnName num="takane"]
“What? You don't want any?”
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Midori012"]
[OnName num="midori"]
“No....... It's probably poisoned.”
[cpg cn=true]


[SE f="se012"]
;//【ＳＥ】『歩き去る』


[FO pos="4/5" time=1000]
[FACE method="change_7" pos="2/5"]
After saying that, Midori immediately left.
[cpg]


It seemed as if she was hostile to Hazuki, me, and even Takane, and she seemed to imagine that we were being hostile to her as well.
[cpg]




[free time=1000]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane081"]
[OnName num="takane"]
“It was ...... like she had feelings for you.”
[cpg cn=true]


[OnName num="zen"]
“Don't make fun of me."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

Midori took my clients and my business was not up and running. But the situation was resolved unexpectedly.
[cpg]


[OnName num="customer_A"]
“My daughter seems to have been cursed…… I need you to examine her.”
[cpg cn=true]


[OnName num="customer_B"]
“Please. I have no one else to rely on.”
[cpg cn=true]


[OnName num="zen"]
"...... Excuse me for asking, but what about Midori?"
[cpg cn=true]


[OnName num="customer_A"]
“Oh, yeah. She's apparently cursed or something……."
[cpg cn=true]


[OnName num="zen"]
“Oh, ......is that so?”
[cpg cn=true]


[OnName num="customer_B"]
“Yes, she’s closed now. "
[cpg cn=true]


It was just as Sakuya had said. I didn't expect customers to come back like this.
[cpg]


In any case, I have to take care of my customers.
[cpg]


[OnName num="zen"]
“Understood. Let's take a look."
[cpg cn=true]


[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大通り』（朝）******************************************************

On the way, I tried to find out what the curse was, but I couldn't get it out of her.
[cpg]


It might be something that is embarrassing. But still, it is a Onmyoji who deals with such things.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『汎用室内』（朝）******************************************************

Of course, I can't try what I did to Hazuki with someone I don't know.
[cpg]


I tried to offer some things that are said to be effective in dispelling evil spirits in general, such as wooden plates or medicine, but I don't know what would happen.
[cpg]


It may calm them down a little. But if it could be cured by such things, Hazuki would have cured herself.
[cpg]


[OnName num="customer_A"]
“How did it go? Will my daughter be cured?”
[cpg cn=true]


[OnName num="zen"]
“I did everything I could. Let's see how it goes.”
[cpg cn=true]


I guess it would only make it uneasy to be told this by an unknown Onmyoji like me.
[cpg]


Still, it's better than saying nothing.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大通り』（昼）******************************************************

[OnName num="zen"]
"...I wonder if Midori is facing the same thing."
[cpg cn=true]


If it's a curse that makes you fall in love with someone like Hazuki..... it's going to be hard with a personality like hers.
[cpg]


[OnName num="zen"]
“No, no. What am I thinking?"
[cpg cn=true]


I knew that Takane could not hear me talking to myself like this. Shaking my head, I let go of my unnecessary thoughts.
[cpg]


I walked down the main street again and returned to the store.
[cpg]



[SE f="se004"]
;//【ＳＥ】『道歩く』

If Midori has been cursed, I feel it's a good idea to cooperate with her now.
[cpg]


I can't keep confronting her forever. My savings are dwindling.
[cpg]


We can't go on like this fighting over customers.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

I went back to the store, and in the evening, I had a visitor.
[cpg]


[SE f="se001"]
;//【ＳＥ】『戸が開く』

[WAIT time=1100]

[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Midori013"]
[OnName num="midori"]
"......Can I talk to you for a minute?"
[cpg cn=true]


[OnName num="zen"]
“Midori. Is something wrong?”
[cpg cn=true]


Midori had arrived. I was surprised to see her.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Takane082"]
[OnName num="takane"]
“Welcome. May I offer you some tea?”
[cpg cn=true]


[FACE method="shock_3" pos="4/5"]
[VOICE f="Midori014"]
[OnName num="midori"]
“No, thank you, I don't need it.”
[cpg cn=true]


She says, but she didn't talk about the poison this time.
[cpg]


;//移植のためシーンをカットしています

[free time=1000]


[FG f="CHA02_p5_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Midori015"]
[OnName num="midori"]
“I'd like to discuss a few things with you.”
[cpg cn=true]


Her cheeks were red. Could it be……?
[cpg]

[OnName num="zen"]
“What's wrong? Is it the curse?”
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
She nodded and looked at me with puppy dog eyes.
[cpg]


[OnName num="zen"]
“I'm sure you came to me because you wanted me to cure you, right?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Midori016"]
[OnName num="midori"]
;//「……こんなものが、キノトで流行ってるって知ってたら、来なかったのに」
「……こんなものが、流行ってるって知ってたら、来なかったのに」
[cpg cn=true]


I don't know what to do. I know of a way that might work.
[cpg]


But unlike with Hazuki, she's not getting on to me and she doesn't like me.
[cpg]


[OnName num="zen"]
“In fact, I once broke a curse of a female friend."
[cpg cn=true]


I used the term ‘friend’, but she seemed interested.
[cpg]



[FACE method="shock_5" pos="2/3"]
[VOICE f="Midori017"]
[OnName num="midori"]
“Really? How did you break the curse?”
[cpg cn=true]


I guess I told the story in the wrong order.
[cpg]


I should have said first that it was a rather unorthodox ...... or an insane way of doing it.
[cpg]


[OnName num="zen"]
“I can't go into details here, since it’s something no one would like.”
[cpg cn=true]

[free time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane083"]
[OnName num="takane"]
“What? Did you just say something?”
[cpg cn=true]


Takane looked back, even though I had only whispered those words.
[cpg]


[OnName num="zen"]
“Anyway, there is a method that might be able to cure you. I'll leave it to you to decide whether you want to try it or not.”
[cpg cn=true]

[free time=1000]
[FG f="CHA02_p5_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Midori018"]
[OnName num="midori"]
“If you can solve it, I'd like you to do it.”
[cpg cn=true]


Midori showed no sign of hesitation. She must be in a lot of trouble.
[cpg]


[OnName num="zen"]
“I understand. Takane, don't you peek.”
[cpg cn=true]

[free time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane084"]
[OnName num="takane"]
"Yes, yes…… I guess it's a way that you don't want to be seen.”
[cpg cn=true]


Takane was dumbfounded, but she seemed like she didn’t know what was going on.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『戸が閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p5_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



[OnName num="zen"]
“So, the way to do it......"
[cpg cn=true]


I chose my words carefully and summarized what I had done to Hazuki.
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Midori019"]
[OnName num="midori"]
“I can't believe that that would cure me.”
[cpg cn=true]


[OnName num="zen"]
「彼女の思い込みとは思えないほど、かなりの変化がありました。何か作用があったんだと思います」
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Midori020"]
[OnName num="midori"]
“So ...... you can do that for me too? Even though I have been harassing you?”
[cpg cn=true]


Midori's reaction was somewhat unexpected.
[cpg]


Is it because she little resistance towards such things, or is it because the curse is weakening her?
[cpg]


Probably the latter. I thought about what I was going to do.
[cpg]


[OnName num="zen"]
“Yes. It is natural for a Onmyoji to help those in need.”
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Midori021"]
[OnName num="midori"]
“I wonder if it has something to do with the place of where you kiss me. Maybe just the way you did it to your female friend?”
[cpg cn=true]


I didn't tell her until the end that the ‘friend’ was Hazuki.
[cpg]


For some reason I didn’t want Midori to find out about everything. It felt dangerous.
[cpg]


I might be able to fix it, but if there is a conflict in such a place, she won’t be able to get the help she needs.
[cpg]


[OnName num="zen"]
“I don't know. I'll try to find a way.”
[cpg cn=true]


But now Midori was willing to try. I'll do what I can do.
[cpg]

*select02_1_0|A New Onmyoji


[switch]
[case "He kisses her forehead."]
	[swap]
	[jump target="*select02_1_1"]
[case "Kiss the thigh"]
	[swap]
	[jump target="*select02_1_2"]
[endswitch]


1. Kiss the forehead
2. Kiss the thigh

;//==============================
;//１、額に口づける

;//選択肢のジャンプ先
*select02_1_1|A New Onmyoji



I thought about it and decided to kiss her forehead.
[cpg]

I thought about her fingertips, but if I she were becoming infatuated, then that meant that something was happening inside her head.
[cpg]

If so, I thought, it would be better somewhere close to it.
[cpg]

[OnName num="zen"]
“I will do it now. Are you ready?”
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
She nodded graciously and moved closer to me.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
;//ブラックアウト

;//移植のためシーンをカットしています

Then I kissed her on the forehead, holding her hair with my hands.
[cpg]

She looked embarrassed, but only for a moment.
[cpg]


;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p5_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[OnName num="zen"]
“How do you feel? Do you feel any different?”
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Midori022"]
[OnName num="midori"]
“Well……I was feeling light-headed for a long time.”
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Midori023"]
[OnName num="midori"]
“Now I don't feel that way. Maybe it's getting better......."
[cpg cn=true]


Midori herself began to wonder. It's like she's really healed.
[cpg]


[OnName num="zen"]
“I'm glad. I can't do something like this and expect nothing to come out of it.”
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Midori024"]
[OnName num="midori"]
“Why? It was me who asked for it.…"
[cpg cn=true]


She says, but Midori's cheeks were a little tinted.
[cpg]



;//分岐ループから抜ける
[jump target="*select02_1_4"]

;//==============================
;//２、ふとももに口づける


;//選択肢のジャンプ先
*select02_1_2|A New Onmyoji

[OnName num="zen"]
“..... would you turn your back to me, please? I have something I want to try."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
She turned her back to me just as she was told, without a hint of alarm.
[cpg]


;//========================================
;//●ＣＧ（ふとももに口づけるため、後ろを向いているヒロイン）ev_12
;//人物１：ヒロイン２　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
;//[BGM f="bg_h2"]
[WAIT time=100]
;**【ＣＧ】 ev_11_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Midori025"]
[OnName num="midori"]
“Um,...... what are you going to do?”
[cpg cn=true]


[OnName num="zen"]
“I want to see if kissing your feet will work.”
[cpg cn=true]


This also related to the fact that I am a researcher.
[cpg]

But she looked at me in surprise.
[cpg]


;**【ＣＧ】 ev_11_a ***********************
[CG id=1 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Midori026"]
[OnName num="midori"]
“I sense some kind of devious intention.……"
[cpg cn=true]


Even though she said that, I couldn't give up on my research mind.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p5_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


As a result, the curse could not be broken. I need to rethink it again. ......
[cpg]

Nevertheless, it is something that I could not have known if I had not tried.
[cpg]


;//移植のためシーンをカットしています



;//この選択肢を除いて、もう一度同じ分岐へ戻る

[stflag Cha2flg = -1]

[switch]
[case "Kiss her forehead."]
	[swap]
	[jump target="*select02_1_1"]
[endswitch]

[jump target="*select02_1_0"]


;//==============================

*select02_1_4|A New Onmyoji

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="4/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/5" time=800]
[VOICE f="Takane085"]
[OnName num="takane"]
“Ah, you two! How did it go?”
[cpg cn=true]


Takane comes up to me. She doesn't know the details, and awkwardly averts her gaze.
[cpg]


[OnName num="zen"]
“It’s gone..... It worked.”
[cpg cn=true]


Takane’s face lit up. I couldn't help but look away from her. Midori was probably in a similar situation.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Takane086"]
[OnName num="takane"]
;//「すごいですっ！　これでキノト中の呪いを解けますねっ、ご主人も大出世間違いなしです」
“It's amazing! Now we can break the curse all over Kinoto, and you will surely get a big promotion.”
[cpg cn=true]


I haven't told her the whole story yet. It's only natural that she would react so innocently.
[cpg]


[FACE method="change_1" pos="2/5"]
[VOICE f="Takane087"]
[OnName num="takane"]
“So how did you break it?”
[cpg cn=true]


And I know she's pleased. I'd like to be in sync with her, but I can't.
[cpg]


[OnName num="zen"]
“It's ......."
[cpg cn=true]


Midori interrupted me as I was stammering.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Midori027"]
[OnName num="midori"]
“Thank you very much. Zen, I am indebted to you.”
[cpg cn=true]


She seemed to have calmed down to some extent, but also seemed a little flustered.
[cpg]


[OnName num="zen"]
“Well. Thank you for your cooperation. Now I can see that this way of doing things is not wrong.”
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Takane088"]
[OnName num="takane"]
“What? How did you solve it? Please answer me.”
[cpg cn=true]


Takane didn't seem to have sensed the delicate atmosphere yet.
[cpg]


I don't think she has the personality to be blunt about such things, but the way I broke the curse was so out of the blue......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I went back to my room and thought a bit about what I was going to do.
[cpg]


[OnName num="zen"]
“Now what shall I do?"
[cpg cn=true]


As a result, Midori's curse was lifted. Finally, it comes down to the fact that my saliva is something special.
[cpg]

Does it mean that it can be anyone's saliva, or does it mean that it is the saliva of a Onmyoji, or just my own?
[cpg]


Either way, if the people of Kinoto are suffering from the same curse, I should spread the solution. However.
[cpg]


If I told them directly that they would be cured with a kiss, my status would be further degraded.
[cpg]


After thinking about it, I decided that I should ask for someone's help.
[cpg]


[OnName num="zen"]
"...... Midori or ...... Someone higher in rank than me.”
[cpg cn=true]


I need Midori's help here. It would be best to have her spread the word.
[cpg]


[jump storage="ep003.ks" target="*start"]

;////////////////////////////////////////////////////////////////
