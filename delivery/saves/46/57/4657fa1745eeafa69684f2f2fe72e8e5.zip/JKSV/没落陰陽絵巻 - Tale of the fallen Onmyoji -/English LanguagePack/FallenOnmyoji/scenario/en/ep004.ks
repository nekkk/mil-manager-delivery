
*start

;#################################################
*Ep004|A New Curse
;#################################################

[SCENE id=4]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『神社の境内』（朝）******************************************************

[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hazuki095"]
[OnName num="hazuki"]
;//「また、別の呪いがキノトで流行ってるようだわ」
「また、別の呪いが流行ってるようだわ」
[cpg cn=true]


[OnName num="zen"]
“One after another...... Is it something man-made, or is the curse just growing?”
[cpg cn=true]


Is it a little hard to imagine that someone is tampering with something? I can't find any intention.
[cpg]



[FACE method="shake_1" pos="2/3"]
[VOICE f="Hazuki096"]
[OnName num="hazuki"]
“I don't know. Either way, there's nothing we can do to prevent it.”
[cpg cn=true]


[OnName num="zen"]
“Even if you know the solution, there is no way to prevent it. I'd like to find it…… or, better yet, eradicate it.”
[cpg cn=true]


Even if you know that kissing works, it's not something you can just do in secret.
[cpg]

The way to break the curse is to find a solution. We will have to find a way to break the curse by ourselves.
[cpg]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki097"]
[OnName num="hazuki"]
“Anyway, be careful. Tell Takane to be careful too.”
[cpg cn=true]


[OnName num="zen"]
“Takane won't be affected. She’s a Shikigami which means she's a Yokai……but…..”
[cpg cn=true]


It is difficult to be influenced by the curse if you are a Yokai. That's something we've been able to confirm, but.
[cpg]


[OnName num="zen"]
"...... We've been getting advice on curses for a long time. I'm a guy, so it won’t affect me, but if you're close to someone who has it you could get it.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Hazuki098"]
[OnName num="hazuki"]
“I don't think it's likely to happen to you, but you have to be careful.”
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

[OnName num="zen"]
"That's what I'm talking about. Hazuki was worried about you.”
[cpg cn=true]



[FACE method="shake_1" pos="2/3"]
[VOICE f="Takane112"]
[OnName num="takane"]
“Hmm. I'm a Shikigami, so I think I'll be fine.”
[cpg cn=true]


She is optimistic, but only because she knows it is harder for her to get infected by it.
[cpg]


I think it's more the possibility of being cursed, i.e. the number of clients who come to me for advice.
[cpg]


[OnName num="zen"]
“In any case, you can't be too careful.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane113"]
[OnName num="takane"]
“Shall we put up a spirit protector in the bedroom?"
[cpg cn=true]


Takane says jokingly, but I really think we should do that.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/3" time=1]
[WAIT time=1100]
[window target=true]

And what I feared came true.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane114"]
[OnName num="takane"]
“Oh, um, master……"
[cpg cn=true]


[OnName num="zen"]
“What's wrong?"
[cpg cn=true]


My hunch was right, but Takane was fidgety and seemed to want to say something to me.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Takane115"]
[OnName num="takane"]
“I want to ask you about the type of curse.”
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Takane116"]
[OnName num="takane"]
“Is there such a thing ...... as a curse that makes it impossible to take off one's clothes?”
[cpg cn=true]


She seems embarrassed, but she has said it out loud.
[cpg]


[OnName num="zen"]
“There might be. You can no longer take off your clothes?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
Takane nodded. I was just about to go to bed, but sure.
[cpg]


If that were true, she wouldn't be able to take a bath. If she got sick, I'd be in trouble too.
[cpg]


[OnName num="zen"]
“I hadn’t even figured out how the curse could be lifted until now.”
[cpg cn=true]


I guess I need to take this opportunity to determine everything.
[cpg]



[FACE method="shake_4" pos="2/3"]
[VOICE f="Takane117"]
[OnName num="takane"]
“What is it ...... I feel uncomfortable when you stare at me so seriously.”
[cpg cn=true]


[OnName num="zen"]
“I'll say it again. The way to break the curse that I have devised is ……"
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA04_p5_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Takane listened to my words with a red face the whole time.
[cpg]


There is nothing to hide now. After all was said and done, Takane nodded.
[cpg]


;//妙鐘はしばらく黙っていた。何か言いたそうで、でも言えないような状態だった。
;//[cpg]

[FO pos="4/7" time=1000]
[WAIT time=2100]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Takane118"]
[OnName num="takane"]
“I understand. Please do it. If it's you, it's all right."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane119"]
[OnName num="takane"]
“Well, also, I think there is no one else but you…..”
[cpg cn=true]


In the end, she told me that and seemed to be prepared.
[cpg]


[OnName num="zen"]
“…… I see.”
[cpg cn=true]


The expression on Takane's face was something I had never seen before.
[cpg]


I had never really been aware of Takane as the opposite sex, and I was kind of nervous.
[cpg]


That being said, I need to figure out where to kiss her. The fact that you can't take your clothes off means......
[cpg]





;//選択肢のジャンプ先
*select04_1_0|A New Curse

;//■選択肢
[switch]
[case "Kissing the thigh"]
	[swap]
	[jump target="*select04_1_1"]
[case "Kissing a hand"]
	[swap]
	[jump target="*select04_1_2"]
[endswitch]


1. Kiss the thighs
2. Kiss the hand

;//==============================
;//１、ふとももに口づけをする

;//選択肢のジャンプ先
*select04_1_1|A New Curse

[OnName num="zen"]
“…… Let's give it a try, then."
[cpg cn=true]


Takane responded, though I wondered how many times I would be able to try it out on her.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Takane120"]
[OnName num="takane"]
“Yes. Do it, master."
[cpg cn=true]



;//ブラックアウト

;//========================================
;//●ＣＧ（お尻を突き出しているヒロイン）ev_13
;//人物１：ヒロイン４　服装１：下着
;//人物ex：主人公　　　服装ex：着衣
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
;//[BGM f="bg_h1"]
[WAIT time=1000]
;**【ＣＧ】 ev_13_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

I turned her around and tried to kiss her thigh.
[cpg]

It was something I would not normally do, and she seemed nervous about it.
[cpg]

But it was so out of the ordinary that she didn't seem embarrassed.
[cpg]

It didn't become a burden for me.
[cpg]





Then I put my lips on her thigh.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I asked her if she could take off her clothes, but I didn't seem to have broken the spell yet.
[cpg]

I must have been in the wrong place. I thought so, but it was not something I could try only once.
[cpg]


I asked Takane if I could continue, and tried to break the curse again.
[cpg]



;//この選択肢を除いて、もう一度同じ分岐へ戻る


[stflag Cha4flg = -1]

;//■選択肢
[switch]
[case "Kiss the hand"]
	[swap]
	[jump target="*select04_1_2"]
[endswitch]


[jump target="*select04_1_0"]

;//==============================
;//２、手に口づけをする

;//選択肢のジャンプ先
*select04_1_2|A New Curse

[OnName num="zen"]
“Okay, could you give me your hand?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Takane121"]
[OnName num="takane"]
“What……? Okay, but what are you going to do?"
[cpg cn=true]


Clothes are just cloth. If that's the case, if anything is happening, it's in the hand.
[cpg]



;//========================================
;//●ＣＧ（片手を上げているヒロイン）ev_14
;//人物１：ヒロイン４　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
;//[BGM f="bg_h1"]
[WAIT time=1000]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

I ask her to lift one hand and investigate it.
[cpg]

A curse is something that has no shape or form, but ......
[cpg]

Is there something around the fingertips rather than at the base of the arm?
[cpg]


;**【ＣＧ】 ev_14_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Takane122"]
[OnName num="takane"]
“Don't stare at it too much."
[cpg cn=true]


She tells me that, but I can't help but look.
[cpg]

It's a valuable experience. If I don't observe it properly here, the next time may not go so well.
[cpg]

[OnName num="zen"]
“...... Okay. Here we go."
[cpg cn=true]


I hear her swallow. And then......
[cpg]

;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I kissed her fingertips.
[cpg]

As a result, the curse was lifted. Takane was happy to see that it was quickly resolved.
[cpg]


It was a little too easily, and it left me a little unsatisfied……
[cpg]


But seeing her smile, made me forget about that.
[cpg]


;//分岐ループから抜ける
;//[jump target="*select04_1_4"]

;//==============================

;//選択肢のジャンプ先
*select04_1_4|A New Curse


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[OnName num="zen"]
“How have you been since then? Have you been able to take it off?”
[cpg cn=true]



[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane123"]
[OnName num="takane"]
“Yes, it's perfect! No one could have done it except you master!”
[cpg cn=true]


She replies in a very cheerful manner. She was acting the same as before, that it almost seemed to be on purpose.
[cpg]


[OnName num="zen"]
“No, it's not because it's me, but because it's what I've been doing.”
[cpg cn=true]


Having said that, I would be happy if I could help Takane.
[cpg]


She is always the one helping me, so maybe it's good to do something like this once in a while.
[cpg]


[OnName num="zen"]
"...... even so. No one knows that I figured out how to break this curse, right?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane124"]
[OnName num="takane"]
“Oh, that's for sure...... because Midori spread the word.”
[cpg cn=true]


Should I still say that it was me who figured it out?
[cpg]


However, it may look like I'm just saying I came up with the idea after the word spread.
[cpg]


[OnName num="zen"]
"I think I failed in my strategy a little in that area.”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Takane125"]
[OnName num="takane"]
“No, I think it was good. I think the number of people suffering from the curse has definitely decreased.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane126"]
[OnName num="takane"]
“If I hadn't been able to take off my clothes like that, I would have had to take a bath and do my laundry together."
[cpg cn=true]


Seeing Takane laughing while making jokes, gave me relief, but I still think ......
[cpg]


[OnName num="zen"]
“I'm sure there's something to be said for the method I've devised……."
[cpg cn=true]


Unlike medicine, we can't make it in our house and keep the profits to ourselves.
[cpg]


Even if we didn't, if we tried to monopolize it, would there then be fewer people to break the curse?
[cpg]


[jump storage="ep005.ks" target="*start"]

;////////////////////////////////////////////////////////////////
