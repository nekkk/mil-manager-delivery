
;//==============================
;//４、ヒロイン４を選んでいた場合

;#################################################
*Ep020|A love of different classes
;#################################################

[stflag Cha1flg=0]
[stflag Cha2flg=0]
[stflag Cha3flg=0]
[stflag Cha4flg=0]
[stflag Cha5flg=0]


;//選択肢のジャンプ先
*select04_0|A love of different classes

[SCENE id=20]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane238"]
[OnName num="takane"]
“Welcome home, master.”
[cpg cn=true]


Takane still adores me, and thanks to her, I was able to exterminate the Plague God.
[cpg]


[OnName num="zen"]
“Thank you. If it weren't for you Takane, we wouldn't have won if we hadn't exterminated the Plague God on the auspicious day.”
[cpg cn=true]


Takane laughed unreservedly at my words.
[cpg]


[FACE method="shock_2" pos="2/3"]
[VOICE f="Takane239"]
[OnName num="takane"]
“Haha. It was just a coincidence.”
[cpg cn=true]


Yes, a coincidence. I should have laughed it off like this. But I had been turning away from it for a long time.
[cpg]


[OnName num="zen"]
“But it was a great experience. To know that there is such a mysterious existence.”
[cpg cn=true]


[OnName num="zen"]
“The relationship between curses and Yokai means that there are still many things we don't know about them.”
[cpg cn=true]


Takane kept smiling while looking at my serious expression.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane240"]
[OnName num="takane"]
“You will be able to solve all of them.”
[cpg cn=true]


I felt like I had been waiting for those words. I was hoping to get an affirmation when I told Takane.
[cpg]


As usual, she continues to do her best to encourage me. Then, I suddenly thought.
[cpg]


[OnName num="zen"]
“Hey. If I could unravel the relationship between curse and Yokai and get a result…….."
[cpg cn=true]


[OnName num="zen"]
“If you could become human, do you want to turn back as a human again?"
[cpg cn=true]


Takane crossed her arms and thought about it. However, it looks a little like she is acting.
[cpg]


Is she pretending to think?
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Takane241"]
[OnName num="takane"]
“I'd be happy if I could be like you, but I don't think I want to get my memory back or anything like that.”
[cpg cn=true]


It was a somewhat unexpected reply. I was a little dismayed because I didn't expect her to say it like that.
[cpg]


[OnName num="zen"]
“Really? Don't you miss your parents?”
[cpg cn=true]


I think I said something that would have made her hesitate, but even so, Takane nodded.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane242"]
[OnName num="takane"]
“I'm happy right now.”
[cpg cn=true]


[OnName num="zen"]
“……"
[cpg cn=true]


Essentially, there is an absolute power relationship between a Shikigami and its master. In other words, it is a love affair between people of a different status.
[cpg]


It's not common for them to be in love with each other, but if that were the case, we would be the first to be in love like that.
[cpg]


There is nothing to hesitate about this relationship. I want to care for Takane more than anyone else.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

The peace that came for a short time after the extermination of the Plague God.
[cpg]


We do not know what calamity will come next. But we did not waste this time.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane243"]
[OnName num="takane"]
"Are you sleeping, master ......?"
[cpg cn=true]


[OnName num="zen"]
“No."
[cpg cn=true]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[WAIT time=1000]

俺がそう答えると、彼女は俺の布団に潜り込んできた。
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Takane244"]
[OnName num="takane"]
“Heh, heh."
[cpg cn=true]


Seeing her looking so happy made me happy too.
[cpg]


;//ブラックアウト


I can always be natural in front of her.
[cpg]

I find myself being swept away by Takane.
[cpg]


The only person I can act like this is with Takane.
[cpg]


Maybe I have been relying on her all this time.
[cpg]


Then next, I must become an Onmyoji that Takane can rely on.
[cpg]


[if exp={getFlagValue("Cha4flg") == 2 }]
;//ジャンプ先指定
;//[jump target="*select04_1"]
[jump storage="ep021.ks" target="*select04_1"]
[endif]

;//END
[jump storage="epend.ks" target="*start"]

