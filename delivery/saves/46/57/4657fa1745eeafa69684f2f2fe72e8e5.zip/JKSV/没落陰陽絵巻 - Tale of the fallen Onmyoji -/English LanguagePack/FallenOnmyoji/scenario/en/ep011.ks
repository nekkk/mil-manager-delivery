

;//==============================
;//４、妙鐘

;#################################################
*Ep011|Takane that were always with us.
;#################################################

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]


;//選択肢のジャンプ先
*select00_4|Takane that were always with us.

[SCENE id=11]

;//ルートフラグ
[stflag ChaRoute = 4]

I decided to go back to my store. If I go back there, Takane will be there.
[cpg]


At least it's better than being on my own, and if the building breaks down, it will only be my loss.
[cpg]



;//ブラックアウト

[SE f="se004"]
;//【ＳＥ】『道走る』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************


[VOICE f="Takane184"]
[OnName num="takane"]
“What’s the matter? You look pale.”
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[OnName num="zen"]
“Give me an amulet! To ward it off, now!”
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
I asked Takane, out of breath.
[cpg]


[SE f="se023"]
;//ＳＥ「廊下を走る」
[free time=1000]
I was tired from running, but Takane was not, so she moved quickly.
[cpg]


[SE f="se023"]
;//ＳＥ「廊下を走る」
[WAIT time=500]
[FG f="CHA04_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Takane185"]
[OnName num="takane"]
“Something is coming after you. I hope it won’t enter the store.”
[cpg cn=true]


Her quick understanding helped.
[cpg]

[FACE method="bows_3" pos="2/3"]
While I was limping from my run, she put up a talisman in front of the store.
[cpg]


;//ブラックアウト

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA04_p5_01_a.ui" method="change_3"  pos="2/3" time=1]
[WAIT time=1000]

[SE f="se024"]
;//【ＳＥ】『戸が揺れる』

The presence of something was quite close, but it didn't seem to be able to enter the store.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Takane186"]
[OnName num="takane"]
“I think something is coming this way. Is it after you?"
[cpg cn=true]


I nodded and watched the situation unfold.
[cpg]


In times like this, it is reassuring to be with Takane who doesn't look worried.
[cpg]


I was the one who was looking worried.
[cpg]


While I was thinking that, eventually it went away. .....
[cpg]

[FADEOUTBGM]
[WAIT time=2000]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Takane187"]
[OnName num="takane"]
“What happened, master?”
[cpg cn=true]


I was relieved and decided to tell Takane what had happened.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************


[VOICE f="Takane188"]
[OnName num="takane"]
“It was a close call, wasn't it? What was that all about?”
[cpg cn=true]


[OnName num="zen"]
“Well….. I don't know exactly what it was.”
[cpg cn=true]


I could get an idea, but nothing more.
[cpg]


I have no proof. I've never encountered anything like that before.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

It's not so easy to come to a conclusion. And I was tired from the suddenness of it all, so I went to bed early.
[cpg]


The next morning. I knew it would be a big problem if something like that was lurking around town, but I couldn't carelessly go near it.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Takane189"]
[OnName num="takane"]
“Good morning, sir.”
[cpg cn=true]


Still, the days go by as usual. I have a life, too.
[cpg]


I knew it was dangerous, but I had to think about running the store for now.
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="b_11_2.ui" time=1000]
[WAIT time=2000]

People came for consultations today. Some were about curses, some were not.
[cpg]


No matter what happens, I have my normal work. Sometimes that helps me feel normal, but ......
[cpg]


I always felt like I had my hands full.
[cpg]


And the incidents, or rather anomalies, that happen to us don't stop there.
[cpg]


[FADEOUTBGM]
[window target=false]
[BG f="b_11_3.ui" time=1000]
[WAIT time=2000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=2000]
[FG f="CHA04_p5_01_a.ui" method="change_4"  pos="2/3" time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[FACE method="shake_4" pos="2/3"]
[VOICE f="Takane190"]
[OnName num="takane"]
“Well then ...... good night."
[cpg cn=true]


For a few days now, Takane has been acting strangely. She has been fidgety.
[cpg]


I've had seen her like this from before, but today I can't ignore it.
[cpg]


[OnName num="zen"]
"What's wrong ......? You seem to be hiding something all day."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Takane191"]
[OnName num="takane"]
“No, no. I'm fine.”
[cpg cn=true]


I took it as; something was going on, but I didn't need to worry about it.
[cpg]


[OnName num="zen"]
“Curses. It happened once, it could happen a second time.”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

Takane stopped evading the question and slumped.
[cpg]


;//ブラックアウト


[OnName num="zen"]
“What's wrong? If you don't tell me what's going on, I can't deal with it.”
[cpg cn=true]


She didn't answer immediately, but seemed to be searching for words.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Takane192"]
[OnName num="takane"]
"...... actually ...... that, my chest, I'm in pain ……."
[cpg cn=true]


It seems that she had been cursed again. I've been making her endure it.
[cpg]

I need to fix her right away. That's what I thought.
[cpg]



[switch]
[case "Kiss her cheek"]
	[swap]
	[jump target="*select04_2_1"]
[case "Kiss her neck"]
	[swap]
	[jump target="*select04_2_2"]
[endswitch]

1. Kiss her cheek
2. Kiss her neck

;//==============================
;//１、頬に口づけをする

;//選択肢のジャンプ先
*select04_2_1|Takane that were always with us.


I tried to break her curse with a kiss, as I had always done.
[cpg]

However, it seemed to be different from the previous one and ...... didn't work immediately.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_4"  pos="2/3" time=1]

[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

In the end, her curse could not be broken with a kiss on the cheek.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Takane193"]
[OnName num="takane"]
“Huh......what shall we do?”
[cpg cn=true]


Seeing her in pain makes me suffer too.
[cpg]

While I realized what this feeling was, I did not say it out loud now and concentrated on breaking the curse.
[cpg]


;//ブラックアウト

;//この選択肢を除いて、もう一度同じ分岐へ戻る

[stflag Cha4flg = -1]

[switch]
[case "Kiss her neck"]
	[swap]
	[jump target="*select04_2_2"]
[endswitch]


[jump target="*select04_2_0"]

;//==============================
;//２、首筋に口づけをする

;//選択肢のジャンプ先
*select04_2_2|Takane that were always with us.

She said that her chest was in pain. So maybe it is better to kiss close to where her chest is.
[cpg]

It sounds a little perverted, but I can't help it. I decided to kiss her neck.
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Takane194"]
[OnName num="takane"]
“Hey..... what are you doing?”
[cpg cn=true]


[OnName num="zen"]
“I’m sorry. Please endure this.”
[cpg cn=true]


I said, and brought my lips to hers.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト

;//分岐ループから抜ける
;//[jump target="*select04_2_4"]

;//==============================

;//選択肢のジャンプ先
*select04_2_4|Takane who is always there with me.

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

As a result, that broke her curse. And then ......
[cpg]

After that, my relationship with Takane deepened.
[cpg]


There were some strained feelings, but I was sure that it was different from before.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane195"]
[OnName num="takane"]
“Do you remember …… when you took me into your home?”
[cpg cn=true]


We were reminiscing and talking about the time we met. Of course, there was no way I could forget.
[cpg]


Takane was not able to be a part of a group and not able to live independently.....
[cpg]


She was a stray Yokai. She didn't have any special power, so she was on the street.
[cpg]


[OnName num="zen"]
“I still remember when I turned you into a Shikigami.”
[cpg cn=true]


She looked nostalgic and a little embarrassed.
[cpg]


[OnName num="zen"]
“It was my father's suggestion. I was still in the process of being an apprentice Onmyoji.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Takane196"]
[OnName num="takane"]
“Your dad…..?"
[cpg cn=true]


I don't think I'm saying anything strange, but Takane looked far away.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Takane197"]
[OnName num="takane"]
"Do you think I had a father and a mother too?”
[cpg cn=true]


I couldn't dismiss the slightly sad expression on her face.
[cpg]


[OnName num="zen"]
“If my theory is correct, then yes. A Yokai can't be born out of nothing."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane198"]
[OnName num="takane"]
“You’re right. That's what you’ve been saying all along.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane199"]
[OnName num="takane"]
“I know very well that you wouldn't say such a thing just to ease my mind.”
[cpg cn=true]


A subtle silence fell. It was a frustrating time that went too slow.
[cpg]


But there was nothing I could say.
[cpg]


[FACE method="change_1" pos="2/3"]
[OnName num="customer"]
"Hey, someone please answer me! Is there anyone in this store?”
[cpg cn=true]


[OnName num="zen"]
“I'm sorry, I'm home.”
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

No matter what happens to our relationship, time will always pass.
[cpg]


I have work to do, so if we ever have time to talk to each other properly, it will be after the store closes.
[cpg]


I wanted to treasure the delicate feelings I was having until then.
[cpg]



[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_09_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d2"]
;//[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

[FG f="CHA04_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Takane200"]
[OnName num="takane"]
“Umm…..master….”
[cpg cn=true]


After the store closed, Takane immediately started talking to me. It was as if to say, "I can't wait.”
[cpg]


[OnName num="zen"]
"What is it? You look so formal.”
[cpg cn=true]


[FACE method="bow_13" pos="2/3"]
[VOICE f="Takane201"]
[OnName num="takane"]
“Yes, I want to talk to you about something. Something serious.”
[cpg cn=true]


[VOICE f="Takane202"]
[OnName num="takane"]
“After your exorcism, I've been thinking about something else.”
[cpg cn=true]


She searched for words, but did not seem to hesitate.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Takane203"]
[OnName num="takane"]
“I've always had feelings for you, and we haven't confirmed them with each other yet, but my wish came true in the form of an exorcism.”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Takane204"]
[OnName num="takane"]
“I thought it would be the only time, so I kept quiet about it, but ...... I can't take it anymore."
[cpg cn=true]


[OnName num="zen"]
"...... ah, ......."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Takane205"]
[OnName num="takane"]
"If I tell you this, you may not like me anymore……"
[cpg cn=true]


She says. And then.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Takane206"]
[OnName num="takane"]
“I love you. I can't lie to myself anymore.”
[cpg cn=true]


She said this with a slightly red face, but with a certain degree of calmness.
[cpg]


It would not be good for Takane to remain silent for a long time. I have no hesitations.
[cpg]


[OnName num="zen"]
“I love you too. I'm sorry I didn't tell you.”
[cpg cn=true]


[BGM f="bg_c1"]
[WAIT time=100]

[FACE method="bow_1" pos="2/3"]
Takane looked more like she was reassured than relieved.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Takane207"]
[OnName num="takane"]
“I was a little nervous. If by any chance you hate me, then I won't be able to go back to the way things were.”
[cpg cn=true]


[OnName num="zen"]
“No, I've always had a special place in my heart for you . You are not just a Shikinami or helper.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane208"]
[OnName num="takane"]
“I see. You are not just a master to me either.”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
We were both smiling at the same time. Takane's relieved face made me happy just by looking at it.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

That night, after we ate dinner and took a bath, we cuddled together and went to sleep.
[cpg]


We had a long talk, not necessarily about serious things.
[cpg]


We talked about when we first met, and how we grew and became aware of each other.
[cpg]


[OnName num="zen"]
“We couldn't be kids all the time, could we?”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane209"]
[OnName num="takane"]
"Giggle. That's true for everyone, isn't it?”
[cpg cn=true]


[OnName num="zen"]
“No, I felt that way about you in particular. Some part of me thought that I could not always be a child.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane210"]
[OnName num="takane"]
“I guess that's true. I myself am still childish in some ways.”
[cpg cn=true]


How can I talk about others? I think I am more childish than anyone else.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大通り』（昼）******************************************************

Some days and nights passed from then on.
[cpg]


My relationship with Takane continued to deepen. We went shopping together, and on our days off we would take walks together casually.
[cpg]


Nothing has changed in terms of our irreplaceable days.
[cpg]


And yet, I wonder why. Just by expressing our feelings to each other, it changes so much.
[cpg]


There was a long period of time when I couldn't help but be aware of it.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_11_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Then, one night ......
[cpg]

;//========================================
;//●ＣＧ（仰向けで寝ているヒロイン）ev_46
;//人物１：ヒロイン４　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：主人公の部屋
;//時間　：夜
;//備考　：オリジナル特典09.jpgのシーンです
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
[BGM f="bg_h2"]
[WAIT time=100]
;**【ＣＧ】 ev_46_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

It wasn't that either of us said anything, but it was a time when we couldn't stay away from each other.
[cpg]

I was going to stay by her side until she went to bed.
[cpg]

[VOICE f="Takane211"]
[OnName num="takane"]
“You make me nervous when you look at me like that.”
[cpg cn=true]


The uncontrollable love is about to go out of control.
[cpg]

But I can't. I want to cherish her more than anyone else.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[BG f="b_04_4.ui" time=1000]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（夜）

And just like that, we both fell asleep.
[cpg]


We didn't wake up for quite a long time until the next morning ......
[cpg]

[SE f="se015"]
;//【ＳＥ】『鳥の鳴き声』

[window target=false]
[BG f="b_04_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

;//[FG f="CHA02_p5_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Midori164"]
[OnName num="midori"]
“I'm sorry. Is anyone here?”
[cpg cn=true]


[OnName num="zen"]
"Yes,......."
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Takane212"]
[OnName num="takane"]
“Oh, the sun is already out, master.”
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p3_02_a.ui" method="change_5"  pos="4/5" time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

We rushed out of the same room, putting on our kimonos.
[cpg]

[FACE method="shock_5" pos="2/3"]
Midori saw us there. She looked quite shocked.
[cpg]


[FACE method="change_5" pos="4/5"]
[VOICE f="Midori165"]
[OnName num="midori"]
“I didn’t know you guys had a relationship like that.”
[cpg cn=true]


[OnName num="zen"]
“Oh right.… I didn't tell you.”
[cpg cn=true]


I pretended that we've been like this for a long time. There is no particular meaning to it.
[cpg]


It's just a quick lie, but it didn't help me get through this situation.
[cpg]


[FACE method="change_7" pos="4/5"]
[VOICE f="Midori166"]
[OnName num="midori"]
“I see, Takane..... That was a blind spot……"
[cpg cn=true]


Midori is blatantly disappointed. And Takane had a look on her face like she had done something wrong.
[cpg]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Midori167"]
[OnName num="midori"]
“Well. Then, I'd like to congratulate you."
[cpg cn=true]


[OnName num="zen"]
“Thank you.......
[cpg cn=true]


I'm kind of having trouble getting the words out. I guess I'm more confused than I think.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『神社の境内』（昼）******************************************************

The relationship between me and Takane became known through rumor.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hazuki162"]
[OnName num="hazuki"]
“I heard about it. You are dating Takane?”
[cpg cn=true]


[OnName num="zen"]
"Did you hear it from Midori……?”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hazuki163"]
[OnName num="hazuki"]
“I wish you had told me. Then I wouldn’t have had to feel this half ripe feeling.”
[cpg cn=true]


......Hazuki says she liked me in a roundabout way. I felt sorry.
[cpg]


[OnName num="zen"]
“I'm sorry. I'll make sure to be happy.”
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Hazuki164"]
[OnName num="hazuki"]
“You better. You don't have to say it though.”
[cpg cn=true]


Hazuki was disappointed and angry, but I sensed that behind her words she was congratulating me.
[cpg]



;//ブラックアウト



;//ジャンプ先指定
;//総合ルートへ
;//[jump target="*select00_0"]



[jump storage="ep013.ks" target="*select00_0"]
