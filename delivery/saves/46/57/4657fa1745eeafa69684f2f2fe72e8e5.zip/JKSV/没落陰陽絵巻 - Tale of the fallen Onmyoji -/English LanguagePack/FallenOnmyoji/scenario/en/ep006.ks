

*start

;#################################################
*Ep006|The Solution to a Curse
;#################################################

[SCENE id=6]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

Someone who wasn't a customer has visited my store this morning.
[cpg]


[OnName num="high_ranking_onmyoji"]
“You must be Zen Kamono. I’ve heard rumors about you.”
[cpg cn=true]


I had imagined it, but I was still nervous when it became a reality.
[cpg]


[OnName num="zen"]
“Umm, nice to meet you…….”
[cpg cn=true]


When I asked him about his status, he told me that he was the head of an organization under the direct control of the government that was in charge of dealing with the curse.
[cpg]


Such a person suddenly came to visit me. I had an opportunity to move up in the world.
[cpg]


[OnName num="high_ranking_onmyoji"]
“I'm in a bit of a quandary when it comes to dealing with the curse. I hear you're doing some unconventional experiments, and I'd like to hear your opinion.”
[cpg cn=true]


He spoke bluntly, but I got the sense that he approved of me.
[cpg]


[OnName num="zen"]
“Please wait for a moment, I'll go change my clothes."
[cpg cn=true]


I was dressed so poorly, as usual, that I decided to change.
[cpg]


[OnName num="high_ranking_onmyoji"]
“If you want to, go ahead. I don't mind, but some might.”
[cpg cn=true]


I was nervous about these words, but I tried not to panic.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

[OnName num="zen"]
“I'm going to go Takane….."
[cpg cn=true]



[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane142"]
[OnName num="takane"]
“Yes, master. Good luck.”
[cpg cn=true]


I don’t know if ‘good luck’ is the right word...... but I understand what Takane wants to say.
[cpg]

[free time=1000]

[OnName num="high_ranking_onmyoji"]
"Shall we go then?”
[cpg cn=true]


[OnName num="zen"]
"...... Yes."
[cpg cn=true]


From here on out, it's gonna be a battle for me. Perhaps the most important time of my life.
[cpg]


Or even if it's not important right now, it will be part of the result.
[cpg]



[SE f="se004"]
;//【ＳＥ】『道歩く』


[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大通り』（朝）******************************************************

I walked straightening my back and I felt taller than ever.
[cpg]


And the place I went to was ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ri"]
[WAIT time=100]
;//【ＢＧ】『社務所室内』（朝）******************************************************

A large shrine office. There were both priests and Onmyoji there. And there was a familiar face.
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nagisa027"]
[OnName num="nagisa"]
......"
[cpg cn=true]


Nagisa. Although she is retired, she is someone who has made quite a name for herself.
[cpg]


No wonder she is here. I felt I could understand why Nagisa is here and not Hazuki, who is still active.
[cpg]

[free time=1000]

[OnName num="chief_priest"]
“Here he is ......."
[cpg cn=true]


[OnName num="onmyoji_A"]
“Yes. It's quite unconventional, but he seems to be doing a lot of research on curses.”
[cpg cn=true]


[OnName num="zen"]
......"
[cpg cn=true]


I thought it best not to say anything else until they asked me something, so I kept my mouth shut.
[cpg]


[OnName num="onmyoji_A"]
“Is it true that you are the one who developed the method to break the curse?”
[cpg cn=true]


I'm sure Midori told him this story. I nodded, thinking there was no wrong way to answer this.
[cpg]


[OnName num="zen"]
“Yes. I asked Midori to tell you.”
[cpg cn=true]


The people around me were in an uproar. Then I heard these words.
[cpg]


[OnName num="chief_priest"]
“I'm surprised. Such a young man ...... or only a young man would have thought of it.”
[cpg cn=true]


I guess they at least know how to solve it. That’s how they sounded.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nagisa028"]
[OnName num="nagisa"]
“I can vouch for his ability.”
[cpg cn=true]


[OnName num="onmyoji_B"]
“You say that, but it hasn't been fully verified yet.”
[cpg cn=true]


Verification. Thats where it came to.
[cpg]


This is where I opened my mouth for the first time. I knew that I could not let a lack of trust be the end of my journey.
[cpg]


[OnName num="zen"]
“…… Hazuki, or Midori's words aren't enough?"
[cpg cn=true]


[OnName num="chief_priest"]
“It might be a lie to make you famous. We don't know if we can convince the officials even if we believe you.”
[cpg cn=true]


Hazuki, Midori and I are still young. I was pondering what to do. Then I heard a voice saying,
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nagisa029"]
[OnName num="nagisa"]
"Shall I be your test subject?”
[cpg cn=true]


[OnName num="zen"]
“What?”
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Nagisa030"]
[OnName num="nagisa"]
“I have been cursed for a long time. If Zen can cure me, would you all trust him?”
[cpg cn=true]


[OnName num="onmyoji_A"]
“Well….."
[cpg cn=true]


[OnName num="onmyoji_B"]
“It's not your place to say anything, Tsunashi-sama. Please reconsider.”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Nagisa031"]
[OnName num="nagisa"]
“If you don't trust me, I have no choice.”
[cpg cn=true]


[OnName num="chief_priest"]
“Even so, since there is no way to detect the curse, it doesn't prove anything.”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Nagisa032"]
[OnName num="nagisa"]
“If you say that, isn't everything so? If my word will convince you, then ......"
[cpg cn=true]


[OnName num="chief_priest"]
“……"
[cpg cn=true]


Everyone was silent. I felt saved, but I didn't think I would have to do the same thing to Nagisa as I had done before.
[cpg]


I was thinking that it would be a terrible mistake, not that I didn't want to do it.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Nagisa033"]
[OnName num="nagisa"]
“So, Zen, can you help me?”
[cpg cn=true]



I was so overwhelmed that I nodded my head.
[cpg]


I should have thought more deeply about what those words meant and what I was going to do......
[cpg]



;//ブラックアウト

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=1]

Is that really such a good idea? I thought, but I can't go back now.
[cpg]


If there was no other way to persuade them, was this really the right thing to do? ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『汎用室内』（昼）******************************************************

In another room. I was to attempt an exorcism.
[cpg]


I'm wearing my formal attire as a Onmyoji. It's that important.
[cpg]


[OnName num="zen"]
“..... Are you sure you're under a curse? Are you lying for me so that they will trust me......?"
[cpg cn=true]



[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagisa034"]
[OnName num="nagisa"]
“No. I'm really cursed.”
[cpg cn=true]


I said this, but it seemed to be true.
[cpg]


[OnName num="zen"]
“You’re Hazuki’s mom. I don’t think this is right.”
[cpg cn=true]


[OnName num="zen"]
“I'm sure you don’t want to do this either.”
[cpg cn=true]


[VOICE f="Nagisa035"]
[OnName num="nagisa"]
“It’s okay. My curse is probably ......loving someone other than my husband.”
[cpg cn=true]


Nagisa’s husband, Hazuki's father, had passed away some time ago.
[cpg]


Does she have such feelings now? It didn't sound like a lie.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Nagisa036"]
[OnName num="nagisa"]
“You know how she cherishes the idea of the witching hour? That has something to do with my husband's death.”
[cpg cn=true]


[OnName num="zen"]
“…… Really?"
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Nagisa037"]
[OnName num="nagisa"]
“It was right around the time of that day, he was attacked by a Yokai.”
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Nagisa038"]
[OnName num="nagisa"]
“Of course, it is now vanquished. But I think it also inspired my daughter to become a Miko.”
[cpg cn=true]


[OnName num="zen"]
“But Yokai always appears. It is not logical that they appear at the witching hour.”
[cpg cn=true]



[FACE method="bow_2" pos="2/3"]
[VOICE f="Nagisa039"]
[OnName num="nagisa"]
“If you say so, you have to prove it. You have to prove that you can solve misfortunes and curses with logic.”
[cpg cn=true]


Indeed, this is the first step.
[cpg]


If it is accepted by other Onmyojis and the priesthood, ...... the theory I advocate may be accepted.
[cpg]


[OnName num="zen"]
"I understand ....... Don't tell me to stop halfway through."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
Nagisa nodded. I really have to break her curse. How do I break it......
[cpg]

[FACE method="change_1" pos="2/3"]

;//選択肢のジャンプ先
*select05_1_0|The Solution to a Curse

;//■選択肢

[switch]
[case "Kiss her on the cheek"]
	[swap]
	[jump target="*select05_1_1"]
[case "Kiss her neck"]
	[swap]
	[jump target="*select05_1_2"]
[endswitch]


1. Kiss her cheek
2. Kiss her neck

;//==============================
;//１、頬に口づける

;//選択肢のジャンプ先
*select05_1_1|The Solution to a Curse


[OnName num="zen"]
“Falling in love with someone, is something that is happening in your head, so ……"
[cpg cn=true]


[OnName num="zen"]
“I think I need to kiss near it."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nagisa040"]
[OnName num="nagisa"]
“Yes. Try it Zen."
[cpg cn=true]



;//========================================
;//●ＣＧ（主人公の顔をのぞき込む感じのヒロイン）ev_20
;//人物１：ヒロイン５　服装１：私服
;//人物ex：主人公　　　服装ex：陰陽師の正装
;//場所　：汎用室内
;//時間　：昼
;//備考　：オリジナル特典07.jpgのシーンです
;//========================================
;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[wait time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_20_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[wait time=1000]

;//移植のためシーンをカットしています

She moves her face closer to mine. I think she's peeking at me.
[cpg]

I'm sure it's because of the curse that she's being so aggressive.
[cpg]

If that is the case, I need to break the curse immediately.
[cpg]

Her being Hazuki's mother, there was no way ...... I could do this, but I had a purpose.
[cpg]

[OnName num="zen"]
“Okay.…now…”
[cpg cn=true]


;**【ＣＧ】 ev_20_a ***********************
[CG id=6 index=1 time=1]
;***************************************
[wait time=1]


She nodded and closed her eyes.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


When my lips touched her, there was an indescribable sense of immorality.
[cpg]

[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『汎用民家』（昼）******************************************************

[OnName num="zen"]
“Is the curse ...... gone?”
[cpg cn=true]



[FACE method="bow_2" pos="2/3"]
[VOICE f="Nagisa041"]
[OnName num="nagisa"]
“Yes. I feel as if the fog has lifted.”
[cpg cn=true]



;//分岐ループから抜ける
[jump target="*select05_1_4"]

;//==============================
;//２、首筋に口づける

;//選択肢のジャンプ先
*select05_1_2|The Solution to a Curse

[OnName num="zen"]
“Okay……let’s move on.”
[cpg cn=true]


I asked Nagisa to begin the exorcism.
[cpg]


;//ブラックアウト

When I told her I was going to kiss her neck, she brushed her hair back.
[cpg]

;//========================================
;//●ＣＧエロ（座っている主人公。ヒロインも座っていて、髪を巻き付けて手でしごく）ev_21
;//人物１：ヒロイン５　服装１：私服
;//人物ex：主人公　　　服装ex：陰陽師の正装
;//場所　：汎用室内
;//時間　：昼
;//========================================
;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
;//[BGM f="bg_h1"]
[WAIT time=100]
;**【ＣＧ】 ev_21_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]

The reason I chose her neck is because she is Hazuki's mother.
[cpg]

If I touched her lips, for example, it would feel extremely immoral.
[cpg]

It's not that the neck was a good place either, but it was better.
[cpg]

[VOICE f="Nagisa042"]
[OnName num="nagisa"]
“What's wrong? Are you going to do it?”
[cpg cn=true]


I awkwardly pressed my lips to her neck as she said so.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『汎用民家』（昼）******************************************************

Nagisa's curse was not easily broken.
[cpg]


I don't know if she is telling the truth or not. But she wouldn't ask me to do this for no reason.
[cpg]


I try to exorcise the curse again and again, trying and failing on the spot.
[cpg]



;//この選択肢を除いて、もう一度同じ分岐へ戻る

;//■選択肢
[stflag Cha5flg = -1]

[switch]
[case "Kiss her cheek"]
	[swap]
	[jump target="*select05_1_1"]
[endswitch]

[jump target="*select05_1_0"]

;//==============================

;//選択肢のジャンプ先
*select05_1_4|The Solution to a Curse

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ri"]
[WAIT time=100]
;//【ＢＧ】『社務所室内』（夕方）******************************************************


Then I headed back to the gathering to get the acknowledgement that the curse had been lifted.
[cpg]


Nagisa helped me with this. There should be progress.
[cpg]


I don't know what high-rank people think, but Nagisa is a high-rank person too.
[cpg]


[OnName num="chief_priest"]
"....... If you insist, we have to accept it”
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Nagisa043"]
[OnName num="nagisa"]
“Don’t talk like that. You should be more welcoming."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
For my sake, Nagisa is saying such things.
[cpg]


[OnName num="onmyoji_B"]
“But such a young man ……"
[cpg cn=true]


Still, it is not so easy to be accepted. I guess that means I'm a newcomer.
[cpg]


[OnName num="onmyoji_A"]
“Well well, let’s do him the favor. He doesn't seem to be a reckless person.
[cpg cn=true]


Do I seem reckless? Maybe so, after all the exorcisms I had concocted.
[cpg]


[OnName num="onmyoji_B"]
“I guess I don't have ...... a choice."
[cpg cn=true]


Not all Onmyoji or priest was present at that moment.
[cpg]

[FACE method="change_1" pos="2/3"]

Still, it seems that Nagisa saying that the curse has indeed disappeared helped me gain trust.
[cpg]

;//[free time=1000]

[OnName num="chief_priest"]
“But what shall I do? I can't perform an exorcism kissing every civilian.”
[cpg cn=true]


[OnName num="onmyoji_A"]
“That is also what I wanted to ask you. Is there anything else?”
[cpg cn=true]


[OnName num="zen"]
“I have a few things that I know about ....... May I tell you?”
[cpg cn=true]


People around me seemed to want to hear what I had to say, so I told them.
[cpg]


The Onmyoji is a profession, or rather a lineage, that is resistant to curses.
[cpg]


The proof is that Onmyoji are not susceptible to curses. Therefore, their saliva has the power to ward off curses.
[cpg]


[OnName num="zen"]
“I once removed a curse from a woman who was a Yokai.”
[cpg cn=true]


[OnName num="onmyoji_C"]
“That's absurd. Can a Yokai be cursed?”
[cpg cn=true]


[OnName num="zen"]
“Yes, they do. Even though the curses occur from Yokai.”
[cpg cn=true]


The relationship is like a pathogen in the body that affects the skin.
[cpg]


The skin itself cannot be cured by medicine. So the saliva of the Onmyoji does not turn a Yokai back into a human being.
[cpg]


Likewise, whatever condition the skin is in, it is subject to pathogens.
[cpg]


[OnName num="onmyoji_B"]
“Has this been tested out? I somehow feel that it sounds like a lot of rubbish.”
[cpg cn=true]


[OnName num="zen"]
“There may be some discrepancies or exceptions in that area. What is certain is that Onmyoji saliva is effective against curses."
[cpg cn=true]


[OnName num="chief_priest"]
“I see. Then, can't we substitute the blood of the Onmyoji?”
[cpg cn=true]


With this question, I suddenly realized,
[cpg]


[OnName num="zen"]
"......That's ......."
[cpg cn=true]


[OnName num="chief_priest"]
“Perhaps you have never tried it? Why ……?"
[cpg cn=true]


I was suddenly embarrassed by what he said, but he was right.
[cpg]



;//ブラックアウト
[free time=1000]
[BG f="b_11_3.ui" time=1000]
[WAIT time=2000]


I guess I was just being stubborn. Or maybe I am driven by desire more than I know.
[cpg]


As a result, the most effective substitute was an Onmyoji's blood.
[cpg]


Since Onmyojis have inherited a constitution that is resistant to curses from generation to generation, they have the power to resist curses even after they leave their bodies.
[cpg]


Of course, it didn't take that much blood.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="4/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

That night, Midori had come to the store and I told her what had happened.
[cpg]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Midori098"]
[OnName num="midori"]
“...... I see. If it works with blood, it would have been the first thing one would have thought of."
[cpg cn=true]


I couldn't answer Midori's question about what had happened with Hazuki at first.
[cpg]


[FACE method="change_7" pos="2/5"]
[VOICE f="Takane143"]
[OnName num="takane"]
“Well, well, that can happen. It's just a coincidence."
[cpg cn=true]


I felt as if I was regretting my past, but Takane was right. Such things do happen.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Midori099"]
[OnName num="midori"]
“In any case, we should try to see if we can exorcise it with blood.”
[cpg cn=true]


[OnName num="zen"]
“I intend to do so. When the next customer comes, I'll give it a try.”
[cpg cn=true]

[jump storage="ep007.ks" target="*start"]

;////////////////////////////////////////////////////////////////
