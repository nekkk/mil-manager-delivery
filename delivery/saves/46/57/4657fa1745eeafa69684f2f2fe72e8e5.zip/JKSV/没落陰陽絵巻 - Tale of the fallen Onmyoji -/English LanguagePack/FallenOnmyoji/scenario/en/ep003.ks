
*start

;#################################################
*Ep003|Reconciliation with Midori
;#################################################

[SCENE id=3]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大通り』（朝）******************************************************

Then the next morning, I went to Midori's place to negotiate in person.
[cpg]


[FG f="CHA02_p5_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Midori028"]
[OnName num="midori"]
“Thank you for the other day. Thanks to you, ...... I'm cured.”
[cpg cn=true]


[OnName num="zen"]
“I'm glad to hear that.”
[cpg cn=true]


I remember and look away.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Midori029"]
[OnName num="midori"]
“But my feelings haven’t changed.I have not forgotten about Hazuki.”
[cpg cn=true]


[OnName num="zen"]
“Hazuki? Why are you bringing her up?”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Midori030"]
[OnName num="midori"]
“Well…….Aren’t you good friends with her? You guys recognize each other's abilities.”
[cpg cn=true]


The way she talked about Hazuki seemed a bit off.
[cpg]


[OnName num="zen"]
“What? Thats not really the case.”
[cpg cn=true]


I said that because I thought Hazuki didn't recognize me yet. However, Midori's reaction was dramatic.
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Midori031"]
[OnName num="midori"]
“Is that so?"
[cpg cn=true]


She asked as her eyes widened.
[cpg]


I somehow guessed that she must have felt quite inferior to Hazuki.
[cpg]


I understood that me being Hazuki’s friend, made me in a way superior as well.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Midori032"]
[OnName num="midori"]
“Then, why was I being harassed?”
[cpg cn=true]


Of course, it's not that Hazuki and I have nothing to do with each other. But ...... I guess I should keep that quiet for now.
[cpg]


[OnName num="zen"]
“As for the harassment, I don't care about it anymore.”
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Midori033"]
[OnName num="midori"]
“..... Sorry about that. I remembered you, so I couldn't do anything else ......."
[cpg cn=true]


I guess this happened because she was thinking something about me. This time it just happened to turn out badly.
[cpg]


I'm not going to pursue this any further.
[cpg]


[OnName num="zen"]
“I'd like to ask you for a favor.”
[cpg cn=true]


I forced my way back to the first topic. I would tell her everything I was going to ask of her.
[cpg]


From her point of view, she owed me a favor, so she would listen to me.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Midori034"]
[OnName num="midori"]
“Okay…… Should I tell my colleagues about it?"
[cpg cn=true]


[OnName num="zen"]
“Yes, please. It should be a win-win situation for Midori.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Midori035"]
[OnName num="midori"]
“Yes. If I am one of the first to develop this method, I will be well known.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Midori036"]
[OnName num="midori"]
“So far, it seems that the overwhelming majority of people who are under the curse are women...... something that might give out a negative idea……."
[cpg cn=true]


Midori looks overwhelmed. She is a girl, and she is the one who also broke the curse.
[cpg]


[OnName num="zen"]
“You should also choose to a certain extent which Onmyoji you are going to tell. There's no guarantee he won't do something insolent to a woman."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Midori037"]
[OnName num="midori"]
“I wonder. Isn't the method itself insolent?”
[cpg cn=true]


[OnName num="zen"]
“Well.....I feel bad about that.”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Midori038"]
[OnName num="midori"]
“I mean, I myself don't mind.”
[cpg cn=true]


In the midst of subtle differences, I made a promise anyway.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町外れ』（昼）******************************************************

I found myself in a very cooperative relationship with Midori, even though we had been enemies at first.
[cpg]


For her I have turned from an enemy to her savior.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakuya014"]
[OnName num="sakuya"]
“Good for you.”
[cpg cn=true]


[OnName num="zen"]
“I wonder ...... if we'll end up fighting over customers.”
[cpg cn=true]


Now I was at Sakuya's house. I had something I wanted to talk to her about.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakuya015"]
[OnName num="sakuya"]
“Either way you are such a lovers boy. I'm sure she's cute, too.”
[cpg cn=true]


[OnName num="zen"]
“Don't make fun of me. I'm just trying to get to the point. Are there any stories of Yokai being cursed?"
[cpg cn=true]


Sakuya shrugged. And thens she answered.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Sakuya016"]
[OnName num="sakuya"]
“I don't hear much about it. It seems like it should be possible, since there are a lot of female Yokai.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sakuya017"]
[OnName num="sakuya"]
“Or is it because we are not human?”
[cpg cn=true]


[OnName num="zen"]
"I see…..”
[cpg cn=true]


I can think of one reason. Of course there are exceptions, but it is possible that Yokai are already under a curse.
[cpg]


We need to verify that. I think I can confirm this with Sakuya and Takane.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

That is a different story. Since then, Midori came to visit my house from time to time.
[cpg]


[SE f="se001"]
;//【ＳＥ】『戸を開ける』


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[WAIT time=1100]

[FACE method="bow_1" pos="4/5"]
[VOICE f="Midori039"]
[OnName num="midori"]
“Hello, Zen.”
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Takane089"]
[OnName num="takane"]
“Oh, Midori! Welcome.”
[cpg cn=true]


Midori shook her head when Takane tried to make her some tea.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Midori040"]
[OnName num="midori"]
“I don't want tea......”
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Takane090"]
[OnName num="takane"]
“Why? Do you still think it's poisoned?”
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Midori041"]
[OnName num="midori"]
“No umm…that time..... I thought you and Hazuki were good friends.”
[cpg cn=true]


She’s being honest. I wonder if this was for me to hear.
[cpg]


[FACE method="shock_3" pos="4/5"]
[VOICE f="Midori042"]
[OnName num="midori"]
“I mean, I don’t want anything to happen.”
[cpg cn=true]

[FACE method="bow_6" pos="4/5"]
And she corrects herself. She looked at me a little embarrassed. The curse must have left quite a bit of impression on her.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************


Then Midori seemed to want to know the logic behind why I thought saliva was effective and asked me a lot of questions.
[cpg]


Of course, I couldn't just tell her what had happened with Hazuki. I have to keep a lot of things under wraps.......
[cpg]


I generously told Midori what I had cultivated so far.
[cpg]


She showed me her gratitude. I knew she wouldn't tell anyone about this without thinking.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="4/5" time=800]

[OnName num="zen"]
“The curses that are popular now are like the elements of a Yokai.”
[cpg cn=true]


[OnName num="zen"]
“Maybe, things in this world can be made more than they appear to the eye...... if they can be cut up to where they can't be separated any more.”
[cpg cn=true]


[OnName num="zen"]
“They would probably be so fine that we couldn't even see them. All matter is made up from a collection of such elements.”
[cpg cn=true]


The idea for this area was inspired by a foreign book. And then.
[cpg]


[OnName num="zen"]
"And I believe that the cause of what we call Yokai, the core element, is a curse.”
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Midori043"]
[OnName num="midori"]
“I don't understand ....... What do you mean?"
[cpg cn=true]


No Onmyoji is advocating the same thing in this area.
[cpg]


[OnName num="zen"]
“People seem to think that anything that grows to the size of an animal or a person is a Yokai, but that’s not the case.”
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Midori044"]
[OnName num="midori"]
“If so, what is it?”
[cpg cn=true]


[OnName num="zen"]
“Curses are also Yokai. When a curse possesses an animal or a person, it becomes what is commonly called a Yokai.”
[cpg cn=true]


[OnName num="zen"]
“So, in a way, curses and Yokai are like the relationship between a disease and a sick person.”
[cpg cn=true]


Midori's expression was half dubious and half intrigued.
[cpg]


[FACE method="shake_4" pos="4/5"]
[VOICE f="Midori045"]
[OnName num="midori"]
“It's funny, isn't it? Then they should be treated together like a disease and a sick person.”
[cpg cn=true]


[OnName num="zen"]
“I guess it's because Yokai are so different in appearance from humans……That’s why they are often thought of as separate from each other.”
[cpg cn=true]


Midori seems like she wants to hear more. And in the end, I'm drinking tea brewed by Takane.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Takane091"]
[OnName num="takane"]
“But the curse that is so prevalent these days is that humans are possessed as humans.”
[cpg cn=true]


[OnName num="zen"]
“It must be an evolutionary process. Just like pathogens."
[cpg cn=true]


[FACE method="shock_5" pos="2/5"]
[VOICE f="Takane092"]
[OnName num="takane"]
“Pathogens……? I've never heard of that story. What do you mean, master?”
[cpg cn=true]


[OnName num="zen"]
“It’s just one perspective. A highly virulent disease cannot survive for long, right? Because the main body would die.”
[cpg cn=true]


[OnName num="zen"]
“Not only that, if it is highly toxic, there is even a possibility that it will be eradicated from humans.”
[cpg cn=true]


This is something I had not even told Takane. I decided to talk to Midori and Takane collectively.
[cpg]


[OnName num="zen"]
“The disease also wants to coexist with us. That's why the latest curses possess humans without turning them into Yokai.”
[cpg cn=true]


In other words, from a global perspective, they are to be exterminated, so it is not surprising that curses are changing to prevent that.
[cpg]


That's my theory. Of course, in Hinomoto they are trying to coexist, but that is irrelevant for the Yokai and the cursor.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Midori046"]
[OnName num="midori"]
“Are you thinking about all those things all by yourself?"
[cpg cn=true]


Midori said after a long pause.
[cpg]


[OnName num="zen"]
“Embarrassingly. But I have some degree of certainty."
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Midori047"]
[OnName num="midori"]
“….. I'm sure you do. When you put it that way, I can only assume so."
[cpg cn=true]


Looking at Midori's impressed demeanor, I was glad I had told her.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

After that, we continued to exchange opinions.
[cpg]


[OnName num="zen"]
“There is an idea that all things are made up of a combination of yin and yang and the five elements, isn't there?”
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Midori048"]
[OnName num="midori"]
“Yes. But that idea has been denied in recent years, hasn't it?”
[cpg cn=true]


[OnName num="zen"]
“I don't think it's wrong at all.”
[cpg cn=true]


[OnName num="zen"]
“If you chop an object into smaller pieces, you might get to that conclusion.”
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Midori049"]
[OnName num="midori"]
“But ...... there can't be only seven when there are so many different things.”
[cpg cn=true]


[OnName num="zen"]
“I wonder. Even if there were a hundred elements, what if we chopped them up further?”
[cpg cn=true]


I am speculating here. But, Midori seemed impressed.
[cpg]


We talked for a long time. I wondered if she had to get back to work.
[cpg]


But I was happy to see her in awe, because it was rare to see someone react that way.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Takane093"]
[OnName num="takane"]
“Your eyes are sparkling. You must be very happy.”
[cpg cn=true]


[OnName num="zen"]
“What? Is that so?”
[cpg cn=true]


I realized I was smiling when Takane pointed it out to me.
[cpg]


It's kind of embarrassing. It's as if I'm suddenly coming back to myself.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Takane094"]
[OnName num="takane"]
“I'm happy too. Hmmm..."
[cpg cn=true]


Takane did not look jealous, but seemed to be happy that Midori and I had come to understand each other.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『神社の境内』（夜）******************************************************


Once the exchange of opinions with Midori was over. Midori seemed satisfied, which was good for me.
[cpg]


I had already talked to Hazuki about the origins of Yokai.
[cpg]


She was not as surprised as Midori, but she seemed interested in what I had to say.
[cpg]


It’s partly because she is someone I have talked to many times.
[cpg]


[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hazuki079"]
[OnName num="hazuki"]
“Sakuya, was it? If a Yokai like her is less susceptible to curses that means….”
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki080"]
[OnName num="hazuki"]
“I suppose it's because she's already under the curse.”
[cpg cn=true]


[OnName num="zen"]
"Oh. Of course, if she hasn't become a full Yokai yet, there may be some complications.”
[cpg cn=true]


In other words, it means that Sakuya might also get influenced by the curse. Although I didn't tell her that.
[cpg]


[FACE method="shakee_7" pos="2/3"]
[VOICE f="Hazuki081"]
[OnName num="hazuki"]
“But then again, what makes women susceptible to the curse?”
[cpg cn=true]


[OnName num="zen"]
“It's normal for men and women to be susceptible to different diseases. Besides, I have a feeling it has something to do with the way the curse is broken.”
[cpg cn=true]


I still don't know exactly about that area. I decided not to talk about that.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Hazuki082"]
[OnName num="hazuki"]
“I guess you’re still not clear on that. That's another thing that's typical of you.”
[cpg cn=true]


She is still a little bitter. Still, she acknowledged me.
[cpg]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki083"]
[OnName num="hazuki"]
“I'm also happy to see you get ahead. I can't wait for you to catch up with me.”
[cpg cn=true]


It's complicated. It is true that Hazuki is by far in a better position than me.
[cpg]


Of course I intend to catch up, but I feel bad if I'm making her, my childhood friend, wait.
[cpg]


[OnName num="zen"]
“Of course. I won't keep you waiting that long.”
[cpg cn=true]



[FACE method="bow_2" pos="2/3"]
[VOICE f="Hazuki084"]
[OnName num="hazuki"]
“Promise? Don't lie to me. I've been waiting for you for a long time.”
[cpg cn=true]


I'll be waiting for you. It sounded meaningful, but I didn't dig deeper into it.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大通り』（夜）******************************************************

I went back to the store and thought about what I was going to do.
[cpg]


It would be good to have Midori spread the word about my theory. I felt it would be the fastest way.
[cpg]


Midori's words would be more persuasive than my own.
[cpg]


It is regrettable, but her status as an Onmyoji is higher than mine. She is also well trained.
[cpg]


And, unlike me, she comes from a family that has history.
[cpg]


This is not something I can do anything about with my own efforts. That is why I think it is a good idea to spread the word through Midori.
[cpg]


People who can relate Midori's words will also relate my words.
[cpg]


If that happens, we may be able to see a breakthrough from there.......
[cpg]



[window target=false]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

It is really helpful to have Midori's cooperation nonetheless, even though I’m leaving everything up to her.
[cpg]


It is necessary to keep the curse that infests Kinoto in check.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]

[OnName num="zen"]
“So if you don’t mind, I'd like you to tell your fellow Onmyoji."
[cpg cn=true]


[OnName num="zen"]
“Not only about how to break the curse, but also about how I think curses and Yokai are formed. Can you do that for me?”
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]

[VOICE f="Midori050"]
[OnName num="midori"]
“Of course. I've been wanting to talk about it too. I think there are a lot of people who would be interested.”
[cpg cn=true]


Midori willingly agreed. I had a feeling she wanted to talk about it, too.
[cpg]


[FACE method="bow_2" pos="2/5"]

[VOICE f="Takane095"]
[OnName num="takane"]
“I'm glad to hear that master. If anyone is interested in what you have to say, Can I invite them directly here?”
[cpg cn=true]


[OnName num="zen"]
“I feel bad asking you to go that far."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[FACE method="shake_1" pos="4/5"]
[VOICE f="Midori051"]
[OnName num="midori"]
“No, I don't mind. I would like to help spread this idea, even if it’s only a little.”
[cpg cn=true]


Midori is very kind to me. I did not understand why, so I asked her.
[cpg]


[OnName num="zen"]
“Why are you doing this for me?”
[cpg cn=true]


She doesn't answer right away. It's not that she's not sure about the answer, but she looks as if she's not sure whether to say it or not.
[cpg]


[FACE method="change_7" pos="4/5"]
[VOICE f="Midori052"]
[OnName num="midori"]
“People would always call me ‘doll’. I didn't have much facial expression.”
[cpg cn=true]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Midori053"]
[OnName num="midori"]
“Not only that, but I also had no principle as an Onmyoji until now.”
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Midori054"]
[OnName num="midori"]
“Even though I did the training, I just learned what I was told.”
[cpg cn=true]


[OnName num="zen"]
“No, that's not true.……"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
I immediately deny it, but she just shakes her head.
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Midori055"]
[OnName num="midori"]
“No wonder they called me a doll. I don't have a self.”
[cpg cn=true]


[OnName num="zen"]
......"
[cpg cn=true]


She laughed a little when she saw me speechless.
[cpg]


[FACE method="change_2" pos="2/5"]
[VOICE f="Midori056"]
[OnName num="midori"]
“The reason that I find your stories interesting is because they are more human than doll.”
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Midori057"]
[OnName num="midori"]
“I guess it's because you broke my curse.”
[cpg cn=true]


Midori told me that much. I felt a little embarrassed and scratched my head.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Takane096"]
[OnName num="takane"]
"I'm glad to hear that master.”
[cpg cn=true]


Takane looked as happy as if it were herself.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

Midori then stopped keeping the customers to herself.
[cpg]


On the contrary, she started to have clients far away from this town, probably out of consideration for us.
[cpg]


We were able to earn enough to eat, about the same as before Midori's arrival.
[cpg]


Midori seemed to be talking about me to her Onmyoji friends and telling me about their reactions.
[cpg]


I feel a good wind is starting to blow, but in the midst of all this.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_09_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

[SE f="se016"]
;//【ＳＥ】『戸をたたく音』
[WAIT time=1100]

[OnName num="zen"]
“..... What? We’re closed ......."
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『戸を開ける』
[WAIT time=1100]

I hear a knock at my door in the middle of the night. When I open the door, there stands a man who seems to be a colleague of mine.
[cpg]


[OnName num="onmyoji"]
“It's you, isn't it? You're the one who's been telling Suzumiya strange things.”
[cpg cn=true]


He was talking about Midori.
[cpg]


[OnName num="zen"]
“Uh...... what can I do for you?”
[cpg cn=true]


[OnName num="onmyoji"]
“Don't get involved with her any further. She is a rare person who can use both Miko and Onmyoji skills.”
[cpg cn=true]


[OnName num="zen"]
......"
[cpg cn=true]


I was a little ticked off when he told me not to get involved without giving a reason.
[cpg]


[OnName num="zen"]
“Is there a problem with that? Is there something wrong with what I told her?”
[cpg cn=true]


[OnName num="onmyoji"]
“There is. You say that all Yokai are originally animals or humans.”
[cpg cn=true]


[OnName num="onmyoji"]
“How do you explain the Yokai who were Yokai from the beginning?”
[cpg cn=true]


[OnName num="zen"]
“That's ......."
[cpg cn=true]


I couldn't say anything back right away. It is certainly a blind spot and I'm in the middle of research.
[cpg]


[OnName num="onmyoji"]
"Stay away from Suzumiya. This is your only warning."
[cpg cn=true]


Apparently, he came here just to tell me that. Midori is a beautiful woman, so it's no wonder.......
[cpg]



;//ブラックアウト


But he does have a point. I should not let Midori talk without unraveling that part.
[cpg]


I don't want her to be mistaken for being immature in her logic.
[cpg]


As for the origin of a born Yokai, its a part where there is room to think.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

In fact, there are Yokai who have been monsters from the beginning.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Takane097"]
[OnName num="takane"]
“I don't have any memories of when I was a human either. You were the same way, weren't you, Sakuya?”
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Midori058"]
[OnName num="midori"]
“Rather than a curse, what becomes a Yokai must be a living thing by itself….."
[cpg cn=true]


I suppose there is such an idea, but I doubt it.
[cpg]


[OnName num="zen"]
“I think it's a hard thing to think about. There are Yokai that are too close to humans or too close to animals for that."
[cpg cn=true]


Midori crossed her arms and thought about it. But I was thinking something completely different.
[cpg]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Takane098"]
[OnName num="takane"]
“I don't remember anything. Shall we go to Sakuya's again?”
[cpg cn=true]


[OnName num="zen"]
“I might be able to find out something by asking her directly.”
[cpg cn=true]



Midori was nodding her head at the name, which was new to her, so I explained who Sakuya was.
[cpg]


A carefree Yokai. And yet, she is one of the few people who might be able to help me.
[cpg]


And when it comes to a Yokai who is not a Shikigami, it's a very rare relationship for me.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町外れ』（昼）******************************************************

Midori is a busy person, so I didn't ask her to accompany me.
[cpg]


It would be a great inconvenience to her work. I don't want her to go that far to do something for me.
[cpg]



[SE f="se001"]
;//【ＳＥ】『戸が開く』

[WAIT time=1500]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FACE method="change_1" pos="4/5"]
[VOICE f="Sakuya018"]
[OnName num="sakuya"]
“Oh, I see you're back again. This time with a Shikigami. What do you want with?”
[cpg cn=true]


[OnName num="zen"]
“I wanted to ask you something. May I?”
[cpg cn=true]


[FACE method="change_2" pos="4/5"]
[VOICE f="Sakuya019"]
[OnName num="sakuya"]
“Sure. Come on in.”
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『汎用室内』（昼）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

I'm glad that Sakuya has an easy-going personality.
[cpg]


[OnName num="zen"]
“I don't get many chances to talk to Yokai, so I'm glad.”
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Sakuya020"]
[OnName num="sakuya"]
“What an unusual way to put it. Heh."
[cpg cn=true]


It may be true. They are usually discriminated.
[cpg]



[FACE method="shake_1" pos="4/5"]
[VOICE f="Sakuya021"]
[OnName num="sakuya"]
“But I don't really feel like I’m a Yokai.”
[cpg cn=true]


[OnName num="zen"]
“I'd like to ask you about your memory.... Is it true that you don't remember your parents?”
[cpg cn=true]


Sakuya's smile is smaller now, but she doesn't look angry.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Sakuya022"]
[OnName num="sakuya"]
“Of course. Why would I lie?”
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Takane099"]
[OnName num="takane"]
"...... I guess that means you were a Yokai from the beginning. Am I ...... the same?"
[cpg cn=true]


Even Takane looks a little gloomy. But I don’t give up here.
[cpg]


[OnName num="zen"]
"I think, but isn't it just that you forgot?"
[cpg cn=true]


Something I have been thinking about for a while. What if the curse, the element of the Yokai, affects the appearance.
[cpg]


Even the brain could be affected. It could even result in memory loss.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Sakuya023"]
[OnName num="sakuya"]
“......It sounds like you really want to think that I used to be human.”
[cpg cn=true]


[OnName num="zen"]
“It's not so much that I want to, but that’s the only thing that makes sense. You’re almost like a human.”
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]

Sakuya is scratching her head. She is no longer smiling.
[cpg]


Of course no Yokai wants to dig deep into the secret of their birth. But I cannot give up just now.
[cpg]


[FACE method="change_7" pos="4/5"]
[VOICE f="Sakuya024"]
[OnName num="sakuya"]
“I know you're adamant about it, but I don't want you to suddenly tell me that I might be human. I've been treated like Yokai ever since we were born.”
[cpg cn=true]


[OnName num="zen"]
“Well, whether you were a Yokai since you were born is a matter of uncertainty.……"
[cpg cn=true]


[FACE method="shock_7" pos="2/5"]
[VOICE f="Takane100"]
[OnName num="takane"]
“You’re going overboard. I am a Shikigami myself, so I understand how she feels.”
[cpg cn=true]


I was stopped by Takane, thinking that I had said too much, so I kept silent.
[cpg]


A little silence. Then I apologized.
[cpg]


[OnName num="zen"]
“I'm sorry, ....... I got carried away in order to investigate the true nature of the curse.”
[cpg cn=true]


Sakuya looked a little tired and replied to me.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Sakuya025"]
[OnName num="sakuya"]
“I understand. I'm not mad at you, and that's your job, too.”
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Sakuya026"]
[OnName num="sakuya"]
“Don't be too hard on yourself. You're too logical and a little dangerous.”
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『町外れ』（昼）******************************************************

[OnName num="zen"]
“Thank you for today. I will use this information to stop the curse.”
[cpg cn=true]


Sakuya folded her arms and tilted her head slightly.
[cpg]


[FACE method="change_7" pos="4/5"]
[VOICE f="Sakuya027"]
[OnName num="sakuya"]
“You say it's easy to stop the curse. Do you really think you can do that?”
[cpg cn=true]


[OnName num="zen"]
“I can't say that it can't be stopped. Even you would be troubled if the curse became popular.”
[cpg cn=true]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Sakuya028"]
[OnName num="sakuya"]
“I don't care. Whether a human, a Yokai, or even a popular curse will reign over Hiromoto.”
[cpg cn=true]


I wonder how serious she is about this. Is it that, as a Yokai, she is not afraid of curses?
[cpg]


Or does it seem strange to try to resist something? ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

[OnName num="zen"]
“Sakuya is a mysterious person, isn't she?”
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane101"]
[OnName num="takane"]
“Yes. She’s rather a mysterious Yokai.”
[cpg cn=true]


It feels obvious to say that she is a mysterious Yokai.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Takane102"]
[OnName num="takane"]
“But if I didn't serve you, I might have lived freely like Sakuya”
[cpg cn=true]


That may be how it is. Takane was originally a Yokai.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Takane103"]
[OnName num="takane"]
“I wonder if I was once a human too. Did I have a father or mother?”
[cpg cn=true]


She said this a little uneasily. She didn’t mean that she'd be happy if she were human.
[cpg]

[OnName num="zen"]
“If my theory is correct, then yes."
[cpg cn=true]


Takane looked confused. After all, it was a sensitive subject. I felt awkward and tried to brighten the mood.
[cpg]


[OnName num="zen"]
“There may be things in this world that are better left unexplained. I know that.”
[cpg cn=true]


[OnName num="zen"]
“But you know my nature…..right Takane?”
[cpg cn=true]


Takane laughed, and then nodded.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane104"]
[OnName num="takane"]
“Yes. I don't think that what you’re doing is wrong.”
[cpg cn=true]


[VOICE f="Takane105"]
[OnName num="takane"]
“Without someone with a personality like you, we would know less about this world.”
[cpg cn=true]


I knew Takane would give me full affirmation. I wondered if I was making her do that, but she was still a source of emotional support for me.
[cpg]



;//ブラックアウト


For example, Hazuki does not accept everything about me. In fact, she can be rather harsh.
[cpg]


Midori seems to be impressed with my logic, but it is different from affirmation.
[cpg]


I went to sleep that day, thinking that Takane was the only one who could help me.
[cpg]


Then, another day.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『神社の境内』（朝）******************************************************

[FG f="CHA05_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nagisa019"]
[OnName num="nagisa"]
"Oh, Zen."
[cpg cn=true]


I was on my way to the shrine where Hazuki worked. It was to share information again, but Hazuki was not there.
[cpg]


[OnName num="zen"]
“Nagisa. Um, where's Hazuki?”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Nagisa020"]
[OnName num="nagisa"]
“You came to see her again? That is so romantic.”
[cpg cn=true]


[OnName num="zen"]
“This again ......."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Nagisa021"]
[OnName num="nagisa"]
“She doesn’t have work so she’s home for the day. Would you like to come in?”
[cpg cn=true]


[OnName num="zen"]
"Is that okay? I won't hesitate.”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Nagisa022"]
[OnName num="nagisa"]
“You don’t have to. I’m sure Hazuki will be happy to see you.”
[cpg cn=true]


So, after a long time, I decided to visit Hazuki and Nagisa’s house.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿居間』（朝）******************************************************

[FACE method="bow_2" pos="2/3"]
[VOICE f="Hazuki085"]
[OnName num="hazuki"]
“Good morning. It's very unusual for you to come to the house.”
[cpg cn=true]


Hazuki looked refreshed after waking up from sleep. I was kind of hoping to see her in a waking state.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki086"]
[OnName num="hazuki"]
“I'm glad I cleaned up properly.”
[cpg cn=true]


[OnName num="zen"]
“Being tidy is part of your character isn't it?”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki087"]
[OnName num="hazuki"]
“Yea. But I thought you might refrain from coming in.”
[cpg cn=true]


[OnName num="zen"]
“Nagisa asked me..…”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki088"]
[OnName num="hazuki"]
“Hmmm. Well, you used to come here all the time back in the day.”
[cpg cn=true]


The actuality is that the childhood and the present are different. It would be rude to visit here all the time now.
[cpg]


Since it was about work, I wanted to talk at one of our workplaces.
[cpg]


[OnName num="zen"]
“But it's a fine house...... I can feel the difference."
[cpg cn=true]


I look around. It's still different from the impression I had as a child.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hazuki089"]
[OnName num="hazuki"]
“Difference? You're going to become successful aren't you?”
[cpg cn=true]


[OnName num="zen"]
“I haven't given up. I'm just genuinely jealous. I’d love to just tag along.”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Hazuki090"]
[OnName num="hazuki"]
“What do you mean? I hear that Onmyoji don't ask for help from the gods, but I wonder if you are different.”
[cpg cn=true]


...... Indeed. I said something that wasn't like me.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki091"]
[OnName num="hazuki"]
“I'm sure you'll talk to me about it today. I know a lot of information about curses now.”
[cpg cn=true]


[OnName num="zen"]
"I know. I want to share as much as I can.”
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿居間』（昼）******************************************************



So, as we talked together, we found out.
[cpg]


I know that curses have many different symptoms.
[cpg]


We can confirm that much, but if you are a Yokai from the beginning, you are less likely to receive a curse.
[cpg]


Men are less susceptible than women. This may just be the nature of the situation.
[cpg]


Since men and women are susceptible to different diseases, it can be assumed that it is the same with curses.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

Nagisa joined in from the middle of the conversation, and we began to speculate about what might be the case.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[FACE method="change_2" pos="2/3"]
[VOICE f="Nagisa023"]
[OnName num="nagisa"]
“Your story is interesting. It really sounds like you don't believe in God or Buddha.”
[cpg cn=true]


I think Nagisa doesn't believe in Buddha either. She's a shrine person.
[cpg]


[OnName num="zen"]
“I'm honored. But I really believe it.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nagisa024"]
[OnName num="nagisa"]
“I'm deeply moved. Hazuki and Zen, you two have grown up.”
[cpg cn=true]


It was when Hazuki was standing up from her seat. Nagisa began to talk about her.
[cpg]


[OnName num="zen"]
“If you put it that way, then so is Hazuki.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Nagisa025"]
[OnName num="nagisa"]
“Really. She has grown up to be a fine daughter. She might be the one to save Hinomoto.”
[cpg cn=true]


She seemed to be speaking from her heart, even though she was mumbling the words.
[cpg]


[OnName num="zen"]
“I think Hazuki is an amazing Miko. I don't even know if I'm allowed to talk to her.”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Nagisa026"]
[OnName num="nagisa"]
“What are you talking about? If it weren’t for you she might have not been this serious about the case.”
[cpg cn=true]


As we were talking, I felt her presence.
[cpg]


[SE f="se001"]
;//【ＳＥ】『戸が開く』

[free time=1000]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Hazuki092"]
[OnName num="hazuki"]
“What? Are you guys talking about me?”
[cpg cn=true]


[OnName num="zen"]
“Oh. Welcome back.”
[cpg cn=true]


[FACE method="change_2" pos="2/5"]
[VOICE f="Hazuki093"]
[OnName num="hazuki"]
“I haven't sneezed in ages. I thought someone was gossiping.”
[cpg cn=true]


[OnName num="zen"]
“I didn’t know that you say things that aren't logical, Hazuki.”
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Hazuki094"]
[OnName num="hazuki"]
“I knew you would say that. You don't let me tell even one joke, you stone head."
[cpg cn=true]

[FACE method="bow_2" pos="4/5"]

Nagisa laughed at our exchange.
[cpg]



;//ブラックアウト


[SE f="se004"]
;//【ＳＥ】『道歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

I left Hazuki's house and returned immediately, as I had decided to open the store for lunch.
[cpg]


[BG f="b_09_2.ui" time=1000]
[WAIT time=2000]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Takane106"]
[OnName num="takane"]
“Welcome back, master."
[cpg cn=true]


Midori was there. She's not busy either.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Midori059"]
[OnName num="midori"]
“Welcome back ......."
[cpg cn=true]


After a moment's hesitation, she says so with a tinge of embarrassment on her cheeks. I began to feel embarrassed too.
[cpg]


[OnName num="zen"]
“How's your work?”
[cpg cn=true]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Midori060"]
[OnName num="midori"]
“It’s no problem. I'm just fed up with dealing with customers who are not logical.”
[cpg cn=true]


She too, was talking about logic. I must have influenced her.
[cpg]


[OnName num="zen"]
"Takane, did we have any customers ...... while I was away?"
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Takane107"]
[OnName num="takane"]
“No one came. I'm sorry, but you can talk to Midori, can't you?”
[cpg cn=true]


Takane anticipated and answered all of my questions. She seems to know everything about me.
[cpg]


[OnName num="zen"]
“I guess so. Well then, Midori."
[cpg cn=true]


Midori leaned forward as I continued with my usual conversation.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Midori061"]
[OnName num="midori"]
“Can you tell me another story?”
[cpg cn=true]


[OnName num="zen"]
“Okay. I'm sure it's going to be logical.”
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Takane108"]
[OnName num="takane"]
“Of course. I think Midori expects you to be logical too.”
[cpg cn=true]


I'm embarrassed. Well, but if you're expecting this of me, that's fine too.......
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************


I talk to Midori about this and that. It's not so much about ideas as it is about principles.
[cpg]


I'm trying to explain everything in a logical way, where the priesthood or Onmyoji is ambiguous.
[cpg]


Another principle is that there is no such thing as the supernatural in this world.
[cpg]

[FO pos="4/7" time=1000]
[WAIT time=1100]

[OnName num="zen"]
“Spells and prayers are called magic abroad, right? It's just not science either, so they all have a logic to them."
[cpg cn=true]

[FACE method="shake_5" pos="4/5"]
[VOICE f="Midori062"]
[OnName num="midori"]
“......I've never met an Onmyoji who would say such a thing."
[cpg cn=true]


[OnName num="zen"]
“It's not common. There is even a thought that it is rather cursed and punitive to approach the truth.”
[cpg cn=true]


That is why other Onmyojis may reject my ideas.
[cpg]


It means that there are other barriers besides whether or not they can sympathize.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Midori063"]
[OnName num="midori"]
“You sound like a scholar, Zen"
[cpg cn=true]


Midori looked impressed and said so with a sigh.
[cpg]


[OnName num="zen"]
“A..... scholar.”
[cpg cn=true]


It felt right. I had never thought of that before.
[cpg]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Takane109"]
[OnName num="takane"]
“If I were to describe you in a nutshell, you are neither an Onmyoji nor a detective, but a scholar.”
[cpg cn=true]


It makes me feel good. But I mustn't be complacent.
[cpg]


[OnName num="zen"]
“I want to be someone worthy of being called that.”
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Midori064"]
[OnName num="midori"]
“I'm not exaggerating. I really mean it.”
[cpg cn=true]


Midori, Takane and I smiled at each other. It's not a relationship where we just support each other to comfort each other.
[cpg]


...... No, we don't know that yet, do we? I can't know without getting results.
[cpg]


I was feeling extraordinarily determined to leave some kind of result.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Takane110"]
[OnName num="takane"]
“From now on, perhaps it would be better to call you teacher instead of master.”
[cpg cn=true]


[OnName num="zen"]
“No, don't do that.……"
[cpg cn=true]



;//ブラックアウト


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p5_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


After that, I asked Midori to come to my room to read some literature in my house.
[cpg]


That's when it happened. I found something unfamiliar.
[cpg]


[OnName num="zen"]
“….. what's that?”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Midori065"]
[OnName num="midori"]
“It's a pocket watch. Abroad, they have these things."
[cpg cn=true]


A watch. It must be an imported item.
[cpg]


Generally speaking, a watch is not so big that you can’t carry it.
[cpg]


[OnName num="zen"]
“Are you sure the time is correct?”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Midori066"]
[OnName num="midori"]
“Yes, it seems to be correct. It's a wonder, isn't it?”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Midori067"]
[OnName num="midori"]
“It's my treasure. I feel like this watch is protecting me.”
[cpg cn=true]


Indeed, it looks like a luxury item. But what she began to say was a bit out of the ordinary.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Midori068"]
[OnName num="midori"]
“For example, getting up at exactly six o'clock, or eating breakfast at exactly seven o'clock.……"
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Midori069"]
[OnName num="midori"]
“I thought that if I was on time, the clock would encourage me to be more regular.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Midori070"]
[OnName num="midori"]
“I think that something ...... good will happen.”
[cpg cn=true]


[OnName num="zen"]
“I'm sure you like that watch very much. Although I don’t know if something good will happen.”
[cpg cn=true]


[OnName num="zen"]
“It's good to be regular, but there is no relation between being on time and good things happening.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Midori071"]
[OnName num="midori"]
“I don't know if that's true.”
[cpg cn=true]


[OnName num="zen"]
“People tend to make wishes, but if they are determined by them,......it's a waste of time and energy.”
[cpg cn=true]



[FACE method="shake_1" pos="2/3"]
[VOICE f="Midori072"]
[OnName num="midori"]
“But don't you feel that the dreams you have that day, or the weather in the morning, can determine how good or bad your day will be?”
[cpg cn=true]


[OnName num="zen"]
“I understand, but it's better to eliminate everything inside you that you can't explain.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Midori073"]
[OnName num="midori"]
“……"
[cpg cn=true]


We didn't argue much further. I put it on hold and went back to reading.
[cpg]


However much she was interested in me, I wondered if I had said too much.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p5_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[SE f="se018"]
;//【ＳＥ】『本開く』


[FACE method="change_1" pos="2/3"]
[VOICE f="Midori074"]
[OnName num="midori"]
“That's a valuable piece of literature……you must have been in the Onmyoji family for quite a long time.”
[cpg cn=true]


Midori looked at the literature with interest. She handled it carefully, even though it was already quite torn.
[cpg]


[OnName num="zen"]
“Yes, well. We’ve fallen into disrepair since about the last generation or so.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Midori075"]
[OnName num="midori"]
“It seems like your ancestors thought the same thing. These are all records of their experiments.”
[cpg cn=true]


[OnName num="zen"]
“I wonder if it is a bloodline thing. It seems that they wanted to explain the art of Onmyoji with logic."
[cpg cn=true]


Time flies when I am getting deep in conversation with Midori. I noticed that it was already late in the evening.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************



[FACE method="bow_2" pos="4/5"]
[VOICE f="Midori076"]
[OnName num="midori"]
“Thank you very much for today.”
[cpg cn=true]


She looked at her watch. Is she trying to leave on time?
[cpg]


[OnName num="zen"]
“I'm glad I got to see you, too. Please come back anytime.”
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Midori077"]
[OnName num="midori"]
"Yes, I will. See you later.”
[cpg cn=true]



[SE f="se012"]
;//【ＳＥ】『戸が閉まる』

[free time=1000]


After Midori left, Takane tilted her head.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane111"]
[OnName num="takane"]
“I wonder why she kept looking at his watch. Did she have plans?”
[cpg cn=true]


She was also curious.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Midori no longer interferes with my business. It was as if her initial attitude was not real.
[cpg]


On the contrary, she seemed to be talking about me to her business associates.
[cpg]


Hazuki is also on my side, just like before.
[cpg]


With the help of various people, my name became known little by little.
[cpg]


Of course, this is partly because I figured out how to break the curse.
[cpg]


[jump storage="ep004.ks" target="*start"]

;////////////////////////////////////////////////////////////////
