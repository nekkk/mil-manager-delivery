
;//==============================
;//５、ヒロイン５を選んでいた場合

;#################################################
*Ep022|Dangerous Love
;#################################################

[stflag Cha1flg=0]
[stflag Cha2flg=0]
[stflag Cha3flg=0]
[stflag Cha4flg=0]
[stflag Cha5flg=0]

;//選択肢のジャンプ先
*select05_0|Dangerous Love

[SCENE id=22]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p5_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿居間』（昼）******************************************************

Nagisa was the first person I thought of, and I went to her place.
[cpg]


Fortunately, it seemed that Hazuki was not there at the moment.
[cpg]

I confided my feelings to Nagisa once again.
[cpg]


It was a long confession. And after I finished, Nagisa looked troubled.
[cpg]



[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagisa077"]
[OnName num="nagisa"]
“What are you going to do when ...... Hazuki comes back? She can’t hear about this.”
[cpg cn=true]


[OnName num="zen"]
“I think she should.”
[cpg cn=true]


[VOICE f="Nagisa078"]
[OnName num="nagisa"]
“It's not that easy. Besides, ……"
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Nagisa079"]
[OnName num="nagisa"]
“If you really love me, then you should like Hazuki.”
[cpg cn=true]


Nagisa said. I was fine with that.
[cpg]


[OnName num="zen"]
“Are you fine with that Nagisa? If you let me stay by your side, I would.”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
Nagisa's expression became even more troubled. But she might be thinking that I wouldn't be able to do it anyway.
[cpg]


I will. I'm not afraid to fake my own love in order to be with Nagisa.
[cpg]


I was ready to be with Hazuki for her.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA05_p5_01_a.ui" method="change_4"  pos="2/3" time=1]

I had made up my mind. I will do whatever it takes to fulfill this illogical love.
[cpg]


Even if it meant betraying Hazuki's feelings and deceiving her.
[cpg]


I had fallen in love with someone with whom I would not be able to be together otherwise. I don't think about backing down anymore.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿居間』（夕方）******************************************************

Then Hazuki came back. I confessed to Hazuki, since Nagisa wanted me to.
[cpg]


[FG f="CHA01_p5_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Hazuki198"]
[OnName num="hazuki"]
“...... Really, really? I'm so happy. It's like a dream."
[cpg cn=true]


Hazuki was happy, spilling tears, but it was rather painful.
[cpg]


[OnName num="zen"]
“Don't cry. Because ......"
[cpg cn=true]


Because what I'm really looking for is ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿居間』（夜）******************************************************

[FG f="CHA05_p5_01_a.ui" method="change_4"  pos="2/3" time=800]

Undeniably, it's Nagisa. Without Hazuki noticing I talked with Nagisa.
[cpg]


In the form of the conditions she told me. I've been going out with Hazuki without apparent problems.
[cpg]


[OnName num="zen"]
“Do you now know that I am serious about you?”
[cpg cn=true]


Nagisa seemed lost. She didn’t think that I would go this far.
[cpg]


;//ブラックアウト


I tricked Hazuki. I lied to her. All because I wanted to be by Nagisa’s side.
[cpg]


;//========================================
;//●ＣＧ（抱き合う二人。服を着ている）ev_05
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：屋内
;//時間　：夜
;//備考　：オリジナル特典15.jpgのシーンです
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_05_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

[VOICE f="Nagisa080"]
[OnName num="nagisa"]
“I wonder what will happen if she finds out that ...... you are in love with me.”
[cpg cn=true]


She would say things like that, but I couldn't answer her.
[cpg]


It's also a bit tantalizing to think that Hazuki doesn't know the truth at all, but ......
[cpg]


I couldn't fool myself about my feelings.
[cpg]


The relationship I really wanted was right here, right now.
[cpg]


Maybe secret relationships are meant to fall apart at some point.
[cpg]

Every secret will eventually fall apart.
[cpg]


But ...... with all that danger, I thought it had all turned out the way I wanted it to.
[cpg]


[OnName num="zen"]
“You are really beautiful, Nagisa.”
[cpg cn=true]


Nagisa hesitated a little before responding.
[cpg]


;**【ＣＧ】 ev_05_a ***********************
[CG id=19 index=1 time=1]
;***************************************
[WAIT time=1]


;//[FG f="CHA05_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nagisa081"]
[OnName num="nagisa"]
“I love you....... Zen. That much is true."
[cpg cn=true]


Even Nagisa, who had refused so much, said so in the end.
[cpg]


Just hearing that one word made me feel good.
[cpg]


I felt as if everything I did was rewarded.......
[cpg]



;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[OnName num="zen"]
“I love you too. I love you more than anyone else.”
[cpg cn=true]


I replied. Then I heard a sound.
[cpg]


It felt as if ...... someone was eavesdropping.
[cpg]


[if exp={getFlagValue("Cha5flg") == 2 }]
;//ジャンプ先指定
;//[jump target="*select05_1"]
[jump storage="ep023.ks" target="*select05_1"]
[endif]

;//END

[jump storage="epend.ks" target="*start"]

