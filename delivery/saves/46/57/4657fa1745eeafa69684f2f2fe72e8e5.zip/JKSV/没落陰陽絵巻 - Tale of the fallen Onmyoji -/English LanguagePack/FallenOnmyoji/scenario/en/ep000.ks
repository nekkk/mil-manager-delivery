
*start
;//陰陽師もの　シナリオ

;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり

;//葉月　　　　私服　巫女服
;//翠　　　　　私服　陰陽師服
;//佐久夜　　　私服
;//妙鐘　　　　私服
;//渚沙　　　　私服　巫女服



;//上記以外のキャラクターには音声がありません

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//葉月　　　　一人称「私（わたし）」　翠呼び「翠さん」　佐久夜呼び「佐久夜さん」
;//　　　　　　妙鐘呼び「妙鐘さん」　渚沙呼び「お母様」　善呼び「善」
;//翠　　　　　一人称「あたし」　葉月呼び「葉月さん」　佐久夜呼び「佐久夜さん」
;//　　　　　　妙鐘呼び「妙鐘さん」　渚沙呼び「渚沙さん」　善呼び「善さん」
;//佐久夜　　　一人称「ウチ」　葉月呼び「葉月」　翠呼び「翠」
;//　　　　　　妙鐘呼び「妙鐘」　渚沙呼び「渚沙さん」　善呼び「善」
;//妙鐘　　　　一人称「私（わたし）」　葉月呼び「葉月さん」　翠呼び「翠さん」
;//　　　　　　佐久夜呼び「佐久夜さん」　渚沙呼び「渚沙さん」　善呼び「ご主人」→「善さん」
;//渚沙　　　　一人称「私（わたし）」　葉月呼び「葉月」　翠呼び「翠ちゃん」
;//　　　　　　佐久夜呼び「佐久夜ちゃん」　妙鐘呼び「妙鐘ちゃん」　善呼び「善くん」

;//善　　　　　一人称「俺」　葉月呼び「葉月」　翠呼び「翠さん」
;//　　　　　　佐久夜呼び「佐久夜さん」　妙鐘呼び「妙鐘」　渚沙呼び「渚沙さん」
;//　　　　　　翠、佐久夜に関してはエンディングで呼び捨てになる

;//////////////////////////////////////
;///////////////以下本編///////////////
;//////////////////////////////////////


;//フラグ生成
;//ルートフラグ
[stflag Cha1flg = 2]
[stflag Cha2flg = 2]
[stflag Cha3flg = 2]
[stflag Cha4flg = 2]
[stflag Cha5flg = 2]




;#################################################
*Ep000|The Work of the Onmyoji
;#################################################

[SCENE id=0]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************


In every age, people are always afraid of the unknown.
[cpg]



Epidemics, natural disasters, the economy, and ...... things like ghosts and Yokai (monsters).
[cpg]


[BG f="b_09_2.ui" time=1000]
[WAIT time=2000]



[OnName num="customer"]
”What do you think? Am I cursed by a Yokai or something?” 
[cpg cn=true]


I saw a customer in front of me. He was pale and occasionally coughed.
[cpg]


And he was waiting for me, the Onmyoji, to say something.
[cpg]


[OnName num="zen"]
"Yes......according to my observations."
[cpg cn=true]


[OnName num="customer"]
He swallows.
[cpg cn=true]


[OnName num="zen"]
“Fever. Pain in joints. Cough and sore throat. That's what you said.”
[cpg cn=true]


[OnName num="customer"]
“It's a Yokai after all! Am I going to be possessed and die?”
[cpg cn=true]


[OnName num="zen"]
“Can't you tell from the symptoms I've described? It's just a cold.”
[cpg cn=true]


[OnName num="customer"]
“No way! There are Yokai’s like that! Even if it's a common cold, isn't it because of Yokai?”
[cpg cn=true]


[OnName num="zen"]
“Either way, if it's a cold, I can't cure it! Please go to the doctor.”
[cpg cn=true]


[OnName num="customer"]
“Don't shout so loud!”
[cpg cn=true]


Was I the first one to shout? I don't know, but his voice was louder than mine.
[cpg]


[OnName num="customer"]
“I'm a sick man, and you treat me like one.”
[cpg cn=true]


[OnName num="zen"]
“You are the one calling yourself a sick man.”
[cpg cn=true]


[OnName num="customer"]
“Enough! I'll go to the another Onmyoji!”, he coughed.　
[cpg cn=true]


[SE f="se012"]
;//【ＳＥ】「歩き去る」

I am Zen Kamono. I am a mere part of a family that are the fallen Onmyoji.
[cpg]


It's not that I'm lamenting my circumstances and responding in this way.
[cpg]


If anything, it is because of this circumstance that I receive consultations that are clearly not Yokai related, not even normal incidents.
[cpg]


[OnName num="zen"]
”...... Take care."
[cpg cn=true]


The customer got angry and left. Will our reputation, which is not good to begin with, be further damaged?
[cpg]


But I don't have the patience to give him ordinary medicine and say, "This is medicine for curing the Yokai.”
[cpg]


I don't even know what kind of medicine would work if it were a cold, so I don't stock those……
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大通り』（昼）******************************************************


The words "Yokai" and "demon" are very different in terms from what we imagine.
[cpg]


“Demons” seem to be bad guys that can't be handled by human hands, but “Yokai” are not so bad.
[cpg]


At times they are there to even help people. That’s the difference.
[cpg]


But countries that call a Yokai “demon” are at odds with this idea.
[cpg]


This country, Hinomoto, is different. We call monsters "Yokai," not “demon”, and have chosen to coexist with them.
[cpg]



[window target=false]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『大通り』（夕方）******************************************************

In Kinoto, one of the largest cities in Hinomoto, there are many Yokai gathered together with the main government agencies, bustling towns, and numerous humans.
[cpg]


Of course, not all Yokai are docile and do good deeds.
[cpg]


Just as humans are punished for misbehavior, there is an entity here to solve cases involving Yokai.
[cpg]


In other words, “Onmyoji". They are indispensable to Kinoto.
[cpg]


If you have a high rank, you can be a highly paid government official, or you can be an Onmyoji who deals with small-scale cases like me.
[cpg]



[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_09_3.ui" time=1000]
[WAIT time=2000]
[window target=true]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

My store is called “The Yokai Investigation Agency”.
[cpg]


“Investigator?" “Does that mean that you are not an Onmyoji” “When did you change your occupation?”, are things that I get told…..
[cpg]


People around me laughed at this, but I had no choice but to name it this way.
[cpg]


After all, I would die in a ditch if I stopped getting any work. I wanted to lower the threshold as much as possible.
[cpg]


Of course, if I lowered the threshold too much, I would get clients like the one I just had......
[cpg]


But this life is not a solitary one. It is not because of my clients.
[cpg]


[OnName num="zen"]
“Takane. Could you make me a cup of tea?"
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane001"]
[OnName num="takane"]
“Yes! I'm here.”
[cpg cn=true]

[free time=1000]
She is a Shikigami named Takane. That means that she is a Yokai who serves humans.
[cpg]


[OnName num="zen"]
“It's already late in the evening,......and today's sales are going to be tough.”
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]
[FACE method="bow_2" pos="2/3"]

[VOICE f="Takane002"]
[OnName num="takane"]
“Well. Here you go."
[cpg cn=true]


The tea she brews is diluted. This is not Takane's decision, I tell her to do so.
[cpg]


[OnName num="zen"]
“This month looks bad. I may not be able to make a living as an Onmyoji alone.”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Takane003"]
[OnName num="takane"]
;//「大丈夫ですよ！　うちの評判も良くなってきてるじゃないですか！　キノトで一番の陰陽師だって評判ですよ」
「大丈夫ですよ！　うちの評判も良くなってきてるじゃないですか！　一番の陰陽師だって評判ですよ」
[cpg cn=true]


Takane is honest and energetic. In addition, she knows how to encourage me.
[cpg]


[OnName num="zen"]
“I'm glad to hear that, even if ...... it's a lie. Thank you."
[cpg cn=true]

;//asd↑

[FACE method="shock_3" pos="2/3"]
[VOICE f="Takane004"]
[OnName num="takane"]
“I'm not lying! If there was an Onmyouji ranking system, you would be in the first maegashira!”
[cpg cn=true]


The first maegashira. She didn't know much about sumo, but I guess it's a compliment.
[cpg]


[OnName num="zen"]
“You look like someone who is in the top.”
[cpg cn=true]


If it weren't for her, I'd probably have given up on the path of an Onmyouji by now......
[cpg]


But even though she is a Shikigami, it’s not like she eats air. I have to earn enough money to feed at least two people.
[cpg]


[OnName num="customer"]
“I'm sorry. Zen, are you there?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane005"]
[OnName num="takane"]
“Welcome! You want to talk to us?
[cpg cn=true]


It was a regular customer who came to me. It might be said that a regular customer in an Onmyoji's place is a person who attracts monsters, but that is not the case.
[cpg]


[OnName num="customer"]
”Do you have some time? I'm here to talk about Yokai.”
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=1000]


[OnName num="customer"]
“It's a Yokai. Really, only if it's about Yokai”
[cpg cn=true]


[OnName num="zen"]
"Yes. Well, maybe so.”
[cpg cn=true]


[OnName num="customer"]
“It seems like there is a second affair. Why are men always like this?”
[cpg cn=true]


The Yokai is her husband, and she calls him a Yokai even though he is a human being.
[cpg]


Maybe she thinks it's wrong to talk to me about it if she doesn’t call him that, but for me it doesn't make much of a difference.
[cpg]


[OnName num="customer"]
“Why is that man always like that……”
[cpg cn=true]


[OnName num="zen"]
“Did you just say that man?”
[cpg cn=true]


[OnName num="customer"]
“Oh, no, I meant Yokai. To me, he is a Yokai.”
[cpg cn=true]


[OnName num="customer"]
“He is a Yokai, but I...... like him. I still like him.”
[cpg cn=true]


In this case, "Yokai" is a metaphor. It’s complicated since there are actual Yokai here in Kinoto.
[cpg]


She is misusing the word, I don't know how to respond to that.
[cpg]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

[OnName num="customer"]
“Thank you. You are a great Onmyoji, and you seem to be used to dealing with Yokai.”
[cpg cn=true]


[OnName num="zen"]
“……Yes, well.”
[cpg cn=true]


[SE f="se012"]
;//【ＳＥ】「歩き去る」

I don't want to think of my customer as a Yokai either, but umm........
[cpg]


I watch her leave and look at the consultation fee.
[cpg]


I would think it would be nice if I could get paid, but I also feel like I'm doing it for the money.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane006"]
[OnName num="takane"]
“What a long day! Shall we have dinner?"
[cpg cn=true]


[OnName num="zen"]
“You've waited a long time. I’m sorry about that.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane007"]
[OnName num="takane"]
“Thanks to you, today's dinner is going to be gorgeous!”
[cpg cn=true]


I'm sure there aren't enough ingredients to make it luxurious, but I can't say such a thing when I see the smile on Takane's face.
[cpg]


...... I'm also on the low end of the Onmyoji family that lives in Kinoto. Maybe I will get a request for a solution to a big case.
[cpg]


I've been thinking about that for a long time now, but no such request has come.
[cpg]


Is it because I come from a family that has fallen, or is it because of my lack of ability or lack of a good reputation?
[cpg]


Even though I call myself an investigation agency, I am like a general contractor. Of course, all I get are small cases.
[cpg]


Like before, there are also consultations that are not even cases and clearly have nothing to do with Yokai.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

Dinner is just the two of us. I am an only child, and my parents died early in life.
[cpg]


However, I have a reassuring ally; Takane. She supported me until I managed to become independent.
[cpg]


Even now, I don't feel lonely because I have her. But……
[cpg]


[OnName num="zen"]
“Thank you for dinner.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane008"]
[OnName num="takane"]
“You’re welcome. Is something worrying you?"
[cpg cn=true]


[OnName num="zen"]
“Why? Did it seem like I did?"
[cpg cn=true]


[FACE method="bows_3" pos="2/3"]
[VOICE f="Takane009"]
[OnName num="takane"]
“Yes, yes. You looked like a Yokai.”
[cpg cn=true]


[OnName num="zen"]
“Says the Yokai?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane010"]
[OnName num="takane"]
"Hmmm. You look a lot better now.”
[cpg cn=true]


I try to soften the mood, but I’ve been thinking about it for a long time.
[cpg]


If I die like this without becoming anything, I will have no face to see my parents in the afterlife.
[cpg]


[SE f="se008"]
;//【ＳＥ】「廊下を歩く」

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

Or, in that case, the devil would not let me see my parents.
[cpg]


Speaking of worries, the truth is that there are many things that never cease.
[cpg]


Still, I have to open the store early again tomorrow. So I go to sleep.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="umezamee.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大通り』（朝）******************************************************

The next day, I have work early in the morning.
[cpg]


The work of an Onmyoji is varied, but when it comes to exterminating Yokai, it requires a lot of physical strength.
[cpg]


It is basic brain work, but it is also physical work, even if you are an Onmyoji ......
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『大通り』（昼）******************************************************

[OnName num="carpenter"]
“I'm so thankful for your help! We didn't have enough baggage carriers.”
[cpg cn=true]


[OnName num="zen"]
“Well, I can do it. I can do the heavy lifting, too.”
[cpg cn=true]


[OnName num="carpenter"]
“You seem like you have got a lot of physical strength. You are indeed an Onmyoji.”
[cpg cn=true]


Do they all think that they can praise me because I am a Onmyoji?
[cpg]


Maybe they do. In fact, that one word of praise makes me happy.
[cpg]


[OnName num="carpenter"]
“By the way, where is that Shikigami of yours?”
[cpg cn=true]


[OnName num="zen"]
“Well...... I’ve asked her to take care of the store. I told her to come here if she needs anything.”
[cpg cn=true]



[SE f="se007"]
;//【ＳＥ】『小走り』

As I was saying that, Takane came in.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane011"]
[OnName num="takane"]
"Oh, oh, master, we're in trouble.”
[cpg cn=true]


[OnName num="zen"]
“What is it? Is it a request from a Yokai?”
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Takane012"]
[OnName num="takane"]
“There is a special sale! You must come too, master.”
[cpg cn=true]


[OnName num="zen"]
“...... Do I have to come?"
[cpg cn=true]


[FACE method="bows_3" pos="2/3"]
[VOICE f="Takane013"]
[OnName num="takane"]
"Only one per person! It's a limited edition!”
[cpg cn=true]


I guess those business tactics existed. I headed for the store, dragging my tired body from carrying my luggage.
[cpg]


[SE f="se007"]
;//【ＳＥ】「走る」

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『大通り』（夕方）


[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane014"]
[OnName num="takane"]
“Oh, we made it just in time! I'm glad you came right away, you are indeed a great Onmyoji."
[cpg cn=true]


[OnName num="zen"]
“Do you realize what that means.……"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Takane015"]
[OnName num="takane"]
“This miso costs a lot if you buy it at a normal price. I'm glad I got it.”
[cpg cn=true]


[OnName num="zen"]
"Well, I’m glad if you are.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Takane016"]
[OnName num="takane"]
“What are you talking about? It's going to be your dinner too.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane017"]
[OnName num="takane"]
“It's because we live a simple life that we need luxuries like this.”
[cpg cn=true]


[OnName num="zen"]
' "......"
[cpg cn=true]


Takane is a thrifty girl. I am naturally guilty of dragging her into this state.
[cpg]


[OnName num="zen"]
“Thank you very much. I'm glad.”
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=1000]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大通り』（朝）******************************************************

[SE f="se002"]
;//【ＳＥ】『喧噪』

The days were not passing by in a hurry, but there was a sense of urgency in the air.
[cpg]


The main street is full of people today, too.
[cpg]


[OnName num="zen"]
“I envy you ......."
[cpg cn=true]


I couldn't help but notice that all of these passersby seemed to be adults with prosseional jobs.
[cpg]


I was on my way to someone's place because the store was closed today.
[cpg]


[SE f="se004"]
;//【ＳＥ】「道を歩く」

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=1000]

;//【ＢＧ】『神社の境内』（昼）******************************************************

The destination was a certain shrine. You may say, "What kind of Onmyoji goes to a shrine?”……
[cpg]


She was waiting for me at the shrine, when she saw me she waved her hand.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

Her name is Hazuki Tsunashi. It is difficult for me to get involved with this person.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki001"]
[OnName num="hazuki"]
“Hello, you look as poor as ever.”
[cpg cn=true]


[OnName num="zen"]
“Greetings....... Leave me alone.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Hazuki002"]
[OnName num="hazuki"]
“How's the store doing since then?"
[cpg cn=true]


I wonder how this is connected to my physique. In any case, she said something I didn't really want to hear, so I decided pour some tea.
[cpg]


[OnName num="zen"]
"...... It is just fine, I guess. I can eat just fine.”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Hazuki003"]
[OnName num="hazuki"]
“You look so thin for that.”
[cpg cn=true]


[OnName num="zen"]
“I eat a lot. The other day, Takane bought me some expensive miso and ……"
[cpg cn=true]



[SE f="se003"]
;//【ＳＥ】『お腹の鳴る音』

[WAIT time=1000]

After I said that, my stomach rumbled. She’s going to find out that the miso soup was our only side dish.
[cpg]



[FACE method="bow_2" pos="2/3"]
[VOICE f="Hazuki004"]
[OnName num="hazuki"]
“So you have enough to eat. Hmm…I see…”
[cpg cn=true]


[OnName num="zen"]
"...... Even if a samurai does not have money to eat, he has to pretend that he has by having a toothpick in his mouth.”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Hazuki005"]
[OnName num="hazuki"]
“You're not a samurai, you're an Onmyoji. Can't you show some weakness in front of me?”
[cpg cn=true]


Hazuki and I are able to talk about these things with each other. Her mother, Nagisa, was good friends with my father.
[cpg]


So you could say that Hazuki and I were childhood friends. Of course, as we grew up, we came to realize the difference in our status.
[cpg]


Hazuki comes from a very respectable family and is essentially a high ranking official. A suspicious person like me is not allowed to approach her.
[cpg]


[OnName num="zen"]
“I am like a samurai at heart. That's how much pride I have.”
[cpg cn=true]


But we still talk like this, and not just because we are childhood friends.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Hazuki006"]
[OnName num="hazuki"]
“Your heart is a warrior.....and I want you to be proud being an Onmyoji as well.”
[cpg cn=true]


[OnName num="zen"]
“Don't be so blunt……….Anyways we have to talk about the Yokai.”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Hazuki007"]
[OnName num="hazuki"]
“You’re steering away from the conversation. You have to eat properly. I'm really worried about you.”
[cpg cn=true]


She really did seem concerned with the way she said it, but I forced her to change the subject.
[cpg]


[OnName num="zen"]
“I didn’t! A Miko and an Onmyoji have only one thing to talk about.”
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki008"]
[OnName num="hazuki"]
“You’re right. I know that things have been strange lately.”
[cpg cn=true]


She's a Miko, and I know a lot of things that I can tell her.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Hazuki009"]
[OnName num="hazuki"]
“There's something going on, something that's neither Yokai nor human. Do you know anything about it Zen?”
[cpg cn=true]


[OnName num="zen"]
“I knew it. I've heard rumors, but I haven't been asked about it yet.”
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Hazuki010"]
[OnName num="hazuki"]
“If you’ve heard rumors, then that's good enough for me. I heard a rumor of a rumor.”
[cpg cn=true]


[OnName num="zen"]
“……Isn't that still a rumor?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki011"]
[OnName num="hazuki"]
“I don't know. Either way, it's paranormal.”
[cpg cn=true]


We didn't just exchange information. She seemed to be interested in my way of thinking.
[cpg]


As an Onmyoji, my way of thinking is fundamentally different from that of a Miko.
[cpg]


"Onmyodo" originally started from astronomy and is a theoretical study. On the other hand, the priesthood has many elements that treat bizarre phenomena simply as a bizarre phenomena.
[cpg]


In a world like this, it is tempting to believe in the power of something completely beyond human control. If it is the priesthood that follows the power, it is the Onmyoji who is neutral.
[cpg]


And among them, I was in a position to go against the grain.
[cpg]


[OnName num="zen"]
“There is no such thing as the supernatural in this world. The only thing that exists is the human mind that believes in it.”
[cpg cn=true]


We were supposed to be at opposite ends of the spectrum, but strangely enough, I wanted to talk to him.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Hazuki012"]
[OnName num="hazuki"]
“This again. How dare you talk to me like that, a priestess?”
[cpg cn=true]


[OnName num="zen"]
“I know how you feel. There are Yokai who practice strange arts here in Hinomoto, and things happen that we still can't explain logically.”
[cpg cn=true]


But that doesn't mean that we should assume that everything is a mysterious phenomenon and that there is no logic to it.
[cpg]


[OnName num="zen"]
“But one day we will figure it out. It's not disorderly, it’s just that there is a logic at work that we can't see."
[cpg cn=true]


Only Hazuki and Takane would take me serious.
[cpg]


Takane agrees with everything that I say, but Hazuki properly returns her thoughts to me.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki013"]
[OnName num="hazuki"]
“You, an Onmyoji, are going to say such a thing? It's normal to believe in something that doesn't exist.”
[cpg cn=true]


I can understand why she would want to say that. But it's not true.
[cpg]


[OnName num="zen"]
“No. Rather, it is the opposite. The more I learn about Yin and Yang, the more I want to solve everything.
[cpg cn=true]


Of course, it's not about who is right, Hazuki, Takane, or I, but both perspectives are necessary for me, and that's why I like to talk about this.
[cpg]


I can tell from the serious expression on her face that Hazuki is thinking something similar.
[cpg]


[OnName num="zen"]
“It's a difference in position, isn't it? If you, a Miko, were to agree with me you would be in trouble.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki014"]
[OnName num="hazuki"]
“You’re right. If there is no God or Buddha, then a priestess has no one to serve.”
[cpg cn=true]


[OnName num="zen"]
“Even Buddha? Then you would not be a Miko but a monk.”
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Hazuki015"]
[OnName num="hazuki"]
"Shut up. Don't get me started.”
[cpg cn=true]


[OnName num="zen"]
“Personally, I would want you to remain a Miko.”
[cpg cn=true]


[FACE method="change_7" p
os="2/3"][VOICE f="Hazuki016"]
[OnName num="hazuki"]
“Is it the kimono? Or the hair?”
[cpg cn=true]


[OnName num="zen"]
“Why do you say that? I have no ulterior motive.”
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
Here in Hinomoto, there is no monotheistic religion believed in.
[cpg]

[FACE method="change_2" pos="2/3"]
But there was faith nonetheless. It might not be religious but definitely full of faith, our country was like that.
[cpg]


And in the midst of this conversation, I heard another voice.
[cpg]



[VOICE f="Nagisa001"]
[OnName num="nagisa"]
“Oh, Zen. You're here."
[cpg cn=true]


[free time=1000]
[FG f="CHA05_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1500]
I turned in the direction of the voice and saw Nagisa.
[cpg]

[free time=1000]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_02_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Hazuki017"]
[OnName num="hazuki"]
“You too, mother. You came.”
[cpg cn=true]


Nagisa is also a Miko of considerable status. Even now that she has retired, she may still be more powerful than Hazuki when it comes to fighting Yokai.
[cpg]


The number of great Yokai she has vanquished is innumerable. I think she is someone Hazuki respects as well.
[cpg]


[OnName num="zen"]
“Nagisa, I'm sorry to bother you.”
[cpg cn=true]


When I bow my head, Nagisa laughs in a way I've heard before.
[cpg]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Nagisa002"]
[OnName num="nagisa"]
"Hmmm. You don't have to be so formal. Just think of this as your home."
[cpg cn=true]


[OnName num="zen"]
“No, no......I can't think of a shrine as a home.”
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Nagisa003"]
[OnName num="nagisa"]
“Really? I think of it as my home.”
[cpg cn=true]


The way Nagisa and Hazuki speak is very similar. You can tell that they are related.
[cpg]


Family, family…… I am not familiar with such a thing.
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Nagisa004"]
[OnName num="nagisa"]
"What's wrong? Why do you seem so sad?”
[cpg cn=true]


[OnName num="zen"]
“Nothing. It’s just that I don't have anyone I can call family anymore.”
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
Nagisa looked a little sad, but Hazuki was nonchalant.
[cpg]


[FACE method="change_7" pos="2/5"]
[VOICE f="Hazuki018"]
[OnName num="hazuki"]
“Really? You mean Takane isn’t family?”
[cpg cn=true]


She asks. I was shocked.
[cpg]


Hazuki is a character who does not speak in a roundabout way and sometimes says harsh things easily.
[cpg]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Hazuki019"]
[OnName num="hazuki"]
“If you can't even trust your Shikigami, you're a lowly Onmyoji.”
[cpg cn=true]


[FACE method="change_3" pos="2/5"]
[VOICE f="Hazuki020"]
[OnName num="hazuki"]
“I feel sorry for Takane. Maybe I should tell her.”
[cpg cn=true]


[OnName num="zen"]
“Aren't you being a little too harsh ……?"
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Nagisa005"]
[OnName num="nagisa"]
"Yes, you're right. She probably wants to get to know you even better.”
[cpg cn=true]


Nagisa says so, but I doubt it. Even if she thinks so, Hazuki won't say so.
[cpg]


[FACE method="shake_4" pos="2/5"]
[VOICE f="Hazuki021"]
[OnName num="hazuki"]
“…. Don't complicate the conversation, mother.”
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
Hazuki looked a little troubled. I wonder if she wants to get closer to me even a little.
[cpg]


[OnName num="zen"]
“Whatever the case, I envy you for being Nagisa's child."
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Hazuki022"]
[OnName num="hazuki"]
“What's that? Are you jealous of my family tree?”
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Hazuki023"]
[OnName num="hazuki"]
“I'm sure you're a descendant of Abe no Seimei, too, then?”
[cpg cn=true]


[OnName num="zen"]
"What's that?”
[cpg cn=true]


It's a lineage of Onmyoji, but no matter where I look, I won’t find it within me.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Nagisa006"]
[OnName num="nagisa"]
“You said it's in the family name.”
[cpg cn=true]


[OnName num="zen"]
“If it was passed down in the family name, I wouldn't be called ‘Kamono’.”
[cpg cn=true]


[FACE method="change_2" pos="2/5"]
[VOICE f="Hazuki024"]
[OnName num="hazuki"]
“You said that since it has "no" in it, one third of his blood is in the family.”
[cpg cn=true]


[OnName num="zen"]
“That was when I was a kid! Don't remind me of something I'm ashamed of.”
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Hazuki025"]
[OnName num="hazuki"]
“What's it with being one-third, instead one-half or one-quarter?"
[cpg cn=true]


Indeed. Because human beings are only born between a man and a woman.
[cpg]


[OnName num="zen"]
“How do you remember that?”
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Hazuki026"]
[OnName num="hazuki"]
“Of course I remember. I remember everything about you.”
[cpg cn=true]


......Hazuki is normally a cold person, but sometimes she says things like this.
[cpg]


I wonder what her intentions are? It's kind of out of tune.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『神社の境内』（夕方）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_02_a.ui" method="change_1"  pos="4/5" time=800]

Then we were talking about the "Witching hour" story. Again, our opinions differ.
[cpg]


[OnName num="zen"]
“For example, an Onmyoji of a higher rank than me chooses the time of day for exterminating Yokai.”
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

Hazuki looked at me strangely.
[cpg]


It is not as if it is strange to care about the time of day.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Hazuki027"]
[OnName num="hazuki"]
“Is there something strange about that? I believe it too, you know the story about the monsters thriving at the time of the "Witching hour”.
[cpg cn=true]


[OnName num="zen"]
“I don't deny it outright either. I'm sure there are things here in Hinomoto that we can't see.”
[cpg cn=true]


Either way, I thought the Onmyoji should be more rational in the way they do things.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『神社の境内』（夕方）******************************************************

And then, after a brief conversation. I went back home.
[cpg]


[FG f="CHA05_p5_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nagisa007"]
[OnName num="nagisa"]
"Come again. She lights up when she talks to you.”
[cpg cn=true]


[OnName num="zen"]
“I don't know. I have a lot to gain, but I don't know if she thinks so too ......."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Nagisa008"]
[OnName num="nagisa"]
“You care about that? If she didn't think so, she'd be even colder."
[cpg cn=true]


That's certainly true. At least, she is not the type to be charming.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nagisa009"]
[OnName num="nagisa"]
“She's a little too bright, to the point that she isolates herself from others.”
[cpg cn=true]


It's not that I'm an idiot, but that's definitely the case. She seemed like Nagisa’s daughter.
[cpg]


[OnName num="zen"]
"...... You’re definitely right."
[cpg cn=true]


But if she's too talented and isolated, and if she can loosen up by talking to me, that's fine too.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nagisa010"]
[OnName num="nagisa"]
“So please come back again soon.”
[cpg cn=true]


[OnName num="zen"]
"Yes, thank you. Thank you very much.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nagisa011"]
[OnName num="nagisa"]
“Either way, there is still nothing going on between you two?”
[cpg cn=true]


[OnName num="zen"]
“What do you mean?”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Nagisa012"]
[OnName num="nagisa"]
"Oh, you pretend you don't know. You're so cute.”
[cpg cn=true]


[OnName num="zen"]
“What! There is nothing going on! Of course. I don't want to lose my precious friend."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Nagisa013"]
[OnName num="nagisa"]
“Really? Shall I set you up?”
[cpg cn=true]


[OnName num="zen"]
“No, please!”
[cpg cn=true]



[FACE method="shake_2" pos="2/3"]
[VOICE f="Nagisa014"]
[OnName num="nagisa"]
“I really can you know!”
[cpg cn=true]


[OnName num="zen"]
“She's your daughter! How can you say such a thing?”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Nagisa015"]
[OnName num="nagisa"]
"That's how much I trust you.”
[cpg cn=true]


I don't know. ...... I think she was just teasing me.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大通り』（夜）******************************************************

[SE f="se004"]
;//【ＳＥ】『道歩く』

After that exchange, I was on my way home again.
[cpg]


Even though it's called a vacation, it doesn't mean I don't have to do anything. Even just now, I was exchanging information with Hazuki.
[cpg]


I couldn't just sit idly by because there were no customers coming in.
[cpg]


[OnName num="zen"]
“Or is it the other way around?”
[cpg cn=true]


I was talking to myself. If there are no customers coming, I can't just sit here idly......
[cpg]


[SE f="se001"]
;//【ＳＥ】『戸を開ける』


[FADEOUTBGM]
[BG f="b_09_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane018"]
[OnName num="takane"]
“Welcome home, master. Would you like to eat or take a bath?”
[cpg cn=true]


[OnName num="zen"]
"We don't have a bath in our house, though……"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
There is no way that Takane doesn't know that I go to the public bathhouse. She knew and was joking.
[cpg]


[OnName num="zen"]
“I’ll eat later. I want to finish this while my head is still clear.”
[cpg cn=true]


I go to my room at the back of the house without even properly saying goodbye.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane019"]
[OnName num="takane"]
“I'll make you some tea. Please try not to be too hard on yourself.”
[cpg cn=true]


[OnName num="zen"]
“I know. I'll do it in moderation.”
[cpg cn=true]


[SE f="se008"]
;//【ＳＥ】「廊下を歩く」

[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

But the essence of an Onmyoji is research. Consulting and dealing with people is more of a way to earn money.
[cpg]


Of course it is not good to overdo it and collapse, but I have to take it seriously.
[cpg]


I don't have the facilities or tools to conduct experiments. I have to combine the information I got from Hazuki and the books that have been handed down in this house.
[cpg]



[SE f="se001"]
;//【ＳＥ】『ふすま開く』

[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane020"]
[OnName num="takane"]
”The tea is ready. Would you like some……?"
[cpg cn=true]


[OnName num="zen"]
"I'm about to get some inspiration.... I feel like I'm almost there.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Takane021"]
[OnName num="takane"]
“Please eat the rice only a bit at a time. If you collapse, I will collapse too."
[cpg cn=true]


[OnName num="zen"]
“I know. Just hold on a little longer.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane022"]
[OnName num="takane"]
“I see. I am sure you will figure it out.”
[cpg cn=true]


She says motivating things like this, while also making sure to minimize unnecessary conversation.
[cpg]


Takane and I have known each other for a long time, and as for Takane, I can see that she wants to support me more, but she is holding back.
[cpg]


[OnName num="zen"]
“Thank you. I really appreciate it.”
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
I heard Takane chuckle. I thought to myself, "I have to live up to her expectations" and turned to face my desk again.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[SE f="se015"]
;//【ＳＥ】『鳥の鳴き声』

And as it gets bright outside.
[cpg]


[OnName num="zen"]
“If this is true...... it's a rare breakthrough.”
[cpg cn=true]


I said out loud.
[cpg]


“If it's true, if it's true.” Saying this has become a habit of mine.
[cpg]


To confirm whether or not it is actually true, needs to be verified by a much larger group of people.
[cpg]


And that has not happened. I can't tell you how many times I've been laughed at and told that my thoughts were just an empty theory.
[cpg]


And yet, with each new case I worked on, I was convinced that my theory was correct.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『大通り』（昼）******************************************************



After an all-nighter, I fell asleep exhausted.
[cpg]


I can't sleep deeply because I have to open the store on time tomorrow, but it doesn't hurt because I had gained something.......
[cpg]


[free time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=1100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************


And the next day. When noon turned into evening.
[cpg]


Not at my store, not at Hazuki's shrine, but somewhere else.
[cpg]


[OnName num="onmyoji"]
“What are you here to sell this time. You don’t give up don’t you?”
[cpg cn=true]


I had gone to sell my theory to a certain Onmyoji.
[cpg]


[OnName num="zen"]
"Yes. I'll come again and again.”
[cpg cn=true]


I have to talk to someone of a higher rank than myself. Even if you get cooperation from someone who is of your same level, nothing will develop from there.
[cpg]


[OnName num="zen"]
“I hate to admit it, but I'm a self-proclaimed expert now. I'll be happy to help you.”
[cpg cn=true]


[OnName num="onmyoji"]
“You mean people call you an amateur.”
[cpg cn=true]


He was being harsh, but I was used to this kind of thing.
[cpg]


[OnName num="onmyoji"]
“No matter how many times I've been told, I don't believe this kind of thing. Even if I did, who do you want me to report it to?”
[cpg cn=true]


[OnName num="zen"]
“What do you mean by ‘who’..... maybe someone higher up ......?"
[cpg cn=true]


He snickered at me. I know what he's trying to say.
[cpg]


[OnName num="onmyoji"]
“Telling a story like this to someone higher than me? It's a matter of my own credibility.”
[cpg cn=true]


I had nowhere to escape now. And of course I knew why he would say that.
[cpg]


It's such a leap of faith compared to the currently popular mindset.
[cpg]


[OnName num="zen"]
“If you spread the word and you turn out to be right, your credibility will rise.”
[cpg cn=true]


[OnName num="onmyoji"]
“Don't try to trick me! You don't want to make me right, you want to make yourself right.”
[cpg cn=true]


[OnName num="onmyoji"]
“Get out! Don't come back here, you pest!”
[cpg cn=true]


[OnName num="zen"]
“It’s not right to treat a human as a pest.”
[cpg cn=true]



;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]



In the end, I was kicked out of his house, and salt was sprinkled on me.
[cpg]


[OnName num="zen"]
“It is not reasonable to throw salt on a human being.”
[cpg cn=true]


From the mansion, I heard, "Shut up!”. I heard it from the mansion. I have a tendency to speak without thinking.
[cpg]


[SE f="se004"]
;//【ＳＥ】「道歩く」

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

I was not able to accumulate enough cards in my hand to make my opponent think, "Oh, wow!” But I couldn’t wait and wanted to tell someone right away, which is also a bad habit of mine.
[cpg]


If I had been able to consolidate all my efforts into one, things would have been different.
[cpg]


But it's in my nature to not be able to do so, so I guess I'll just have to accept it.......
[cpg]


[OnName num="zen"]
“I'm home……."
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane023"]
[OnName num="takane"]
“Welcome back, master. How was it ......?"
[cpg cn=true]


[OnName num="zen"]
“Not good. I didn't even feel like he was listening to me.”
[cpg cn=true]


It was frustrating to see that even Takane get depressed.
[cpg]


[OnName num="zen"]
“My idea is correct…….”
[cpg cn=true]


But I couldn't get ahead in life. Should I give up now?
[cpg]


Should I think about another job to reassure Takane? But if I did that, I would not be able to face my parents at all.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane024"]
[OnName num="takane"]
“Don't worry. Everything you had thought of will be recognized one day! After all, you are a descendant of Abe no Seimei.”
[cpg cn=true]


[OnName num="zen"]
“You remember that story, too?”
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

Aside from that, the next day was a business day. I was depressed, but I went to sleep to get my strength back.......
[cpg]


I don't even know what I'm going to use the energy for, but I’d collapse if I stayed awake.
[cpg]


[free time=1000]
[BG f="b_09_1.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************


Then the next morning. As I was still cleaning up the store, a customer came in.
[cpg]


[OnName num="customer"]
“Hey!…..hey.”
[cpg cn=true]


That seemed a bit rude but I was at a level to be treated like that.
[cpg]


[OnName num="zen"]
"Yes, sir. What is it?”
[cpg cn=true]


[OnName num="customer"]
“A Yokai broke a bowl! Many of them!”
[cpg cn=true]


The fact that many bowls were broken does not necessarily mean that a Yokai was responsible. It is more likely to be an animal.
[cpg]


[OnName num="zen"]
“Anyway, can you show us the scene?”
[cpg cn=true]


I already know I'm being treated like a handyman, and I also said I'm an investigator.
[cpg]


I convinced myself that I might get an unexpected inspiration from such a customer.
[cpg]


[SE f="se004"]
;//【ＳＥ】「道歩く」

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


[OnName num="customer"]
"Was it a normal cat...... not a haunted cat?"
[cpg cn=true]


[OnName num="zen"]
“I don't know. What would you do if it was a haunted cat?”
[cpg cn=true]


[OnName num="customer"]
“I’d want it to pay me back.”
[cpg cn=true]


[OnName num="zen"]
“Even if it were a haunted cat, their intelligence is not much different from that of a normal cat.”
[cpg cn=true]


[OnName num="customer"]
"Damn it......I have no choice but to catch it and turn it into a Japanese guitar. I wonder how it will sound like.”
[cpg cn=true]


How cruel ...... I did not say that I thought that the sound would be the same.
[cpg]


He also paid the fees, so I have no complaints about it as one of my jobs.
[cpg]



;//朝を徐々に透明化して昼に遷移できないか
[free time=1000]
[BG f="b_09_2.ui" time=1000]
[WAIT time=1000]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

Then another, aged man.
[cpg]


[OnName num="customer"]
"Is there such a thing as a Yokai that rusts sickles?"
[cpg cn=true]


[OnName num="zen"]
“I think you will find out if you sharpen it. If a Yokai is involved, it would be rusty inside.”
[cpg cn=true]


[OnName num="customer"]
“No, I have never sharpened a sickle.”
[cpg cn=true]


[OnName num="zen"]
“Then it is natural for it to be rusty.”
[cpg cn=true]


He had a sickle even if he never sharpened it? What kind of situation is that?
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane025"]
[OnName num="takane"]
“Do you mean you have one even though you never use it?”
[cpg cn=true]


[OnName num="customer"]
“Yes. It is said to reap sickness, and be a good omen so I put it on display.
[cpg cn=true]


[OnName num="zen"]
' "......"
[cpg cn=true]


Takane is smiling, but I can't accept this kind of story.
[cpg]


I can’t stand it, when I see people believing in irrational things.
[cpg]


I guess they are all influenced by the mysterious existence of Yokai......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大通り』（昼）******************************************************

[SE f="se002"]
;//【ＳＥ】『喧噪』

There are many different kinds of Yokai. There are Yokai that simply do bad things and there are Yokai that have no malicious intent themselves, but influence those around them.
[cpg]


Although they choose to coexist, it is not good to be unable to explain the principle of Yokai.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_10_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『路地裏』（昼）******************************************************

It is not so much that they prefer the shade.
[cpg]


Of course, they are a minority compared to humans. Here in Hinomoto, where the majority of them show off, they sometimes naturally go for the shade.......
[cpg]


The opposite is also true. It really depends on the character of each one.
[cpg]


...... Yes. There are personalities. They are like humans because they think and act in their own way. But if you ask how they differ from humans, it is difficult to answer.
[cpg]


;//ブラックアウト


For example, some Yokai use strange techniques, but that is not so different from an Onmyoji having techniques to seal up a Yokai.
[cpg]


What is the difference between humans and Yokai? When we explore this, the origin of Yokai becomes more clear.
[cpg]


I am not the only one. Onmyoji are probably wondering why Yokai become Yokai.
[cpg]


Sometimes humans become Yokai, sometimes animals become Yokai, sometimes humans disappear and a Yokai suddenly appears.
[cpg]


I used to think the principle was the same for all of them.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

[OnName num="customer"]
“There are more and more weird Yokai’s lately.”
[cpg cn=true]


[OnName num="zen"]
”The ‘yo’ of ‘Yokai’ and the kanji for ‘weird’ are the same.”
[cpg cn=true]


[OnName num="customer"]
”You mean the word ‘mysterious’?”
[cpg cn=true]


It's the same either way. It's a weird, mysterious thing.
[cpg]


[OnName num="customer"]
“It seems that Yokai have been on the rise lately, but you don't know why they're on the rise."
[cpg cn=true]


[OnName num="zen"]
“......Yes, well. That's what most Onmyoji’s would say.”
[cpg cn=true]


The customer laughed at what I said.
[cpg]


[OnName num="customer"]
“You think you're different from an Onmyoji of the streets? At least tell me when you're as good as them.”
[cpg cn=true]


Still, I really meant it. I was so surprised that it came out of my mouth.
[cpg]


[OnName num="customer"]
“If you could figure out how a Yokai becomes a Yokai, you would receive a great amount of reward. In any case, you can't do it."
[cpg cn=true]


[OnName num="zen"]
' "......"
[cpg cn=true]


I'm not very good at this whole silent smirking thing.
[cpg]



[SE f="se012"]
;//【ＳＥ】「歩き去る」

And after the customer left, I complained to Takane.
[cpg]


[OnName num="zen"]
“I've already figured this whole area of study……."
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Takane026"]
[OnName num="takane"]
“Yes! I'm sure the world will recognize your research.”
[cpg cn=true]


On the contrary to me, Takane was smiling and listening to my complaint, which she must be tired of hearing.
[cpg]


[OnName num="zen"]
“I don't know. I wonder if you would nod if I told you that crows are white.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane027"]
[OnName num="takane"]
“Of course. I won't hurt you until you realizes it’s a mistake.”
[cpg cn=true]


[OnName num="zen"]
“...... You’re so direct.”
[cpg cn=true]


But I'm grateful for her presence. If it weren't for her, I would have been broken long ago.
[cpg]


Of course, even Hazuki would agree without question.
[cpg]


I guess it's just a difference in personality, but I'm glad that it’s Takane who is close to me.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『神社の境内』（昼）******************************************************


On another day off, I was talking with Hazuki as usual.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Hazuki028"]
[OnName num="hazuki"]
“Just like always, you have an extraordinary hypothesis. I wonder for a moment if you are a genius.”
[cpg cn=true]


[OnName num="zen"]
"Do you believe me, Hazuki?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki029"]
[OnName num="hazuki"]
“Whether I do or not, if you could prove it, it would turn the world upside down, wouldn't it?”
[cpg cn=true]


She was still interested in my story.
[cpg]


[OnName num="zen"]
“Yea……definitely…….”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Hazuki030"]
[OnName num="hazuki"]
“Don't look at me like you've succeeded. You’re too easy.”
[cpg cn=true]


She doesn’t accept it, but she doesn't deny it either.
[cpg]


Having friends and associates like this, makes me wonder if I have a point.
[cpg]


But when I told other Onmyoji, he said it was not possible, so I was stumped.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hazuki031"]
[OnName num="hazuki"]
“That's your bad habit, you try to complete everything in your head.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki032"]
[OnName num="hazuki"]
“You know, you have to invent a way to market your breakthrough.”
[cpg cn=true]


She had a point. It's a difficult thing to do.
[cpg]


[OnName num="zen"]
"I don't know if I can do such a skillful thing.”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Hazuki033"]
[OnName num="hazuki"]
“What happened to your confidence that you had just a few minutes ago?”
[cpg cn=true]


Hazuki's words were harsh, but they were meant for me.
[cpg]


Just knowing that, helped me keep my eyes on the prize.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Hazuki034"]
[OnName num="hazuki"]
“When you’re confident, you’re good-looking.”
[cpg cn=true]


[OnName num="zen"]
“What? Did you say something?”
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]

Hazuki shakes her head. I feel like she said something that should really bother me.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大通り』（昼）******************************************************


I'm going to hold her words close to my heart as I go about my work.
[cpg]


You never know where an opportunity will lead you. So I have to start selling my name even in the slightest way.
[cpg]


[OnName num="customer"]
“Thank you for consulting with me. Here is my consultation fee.”
[cpg cn=true]


[OnName num="zen"]
"Yes, thank you.”
[cpg cn=true]


Today, I was dealing with a regular customer who came to me with her problems about her husband.
[cpg]


[OnName num="customer"]
“Oh, and ......this is about something else besides my husband.”
[cpg cn=true]


[OnName num="zen"]
“What is it?"
[cpg cn=true]


[OnName num="customer"]
"There is a story about a nine-tailed fox that haunts a place on the outskirts of town.”
[cpg cn=true]


[OnName num="zen"]
“…… Please tell me that first. We are Onmyoji, you know.”
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大通り』（昼）******************************************************

So technically, it’s still young so it only has seven tails, and it’s not a nine-tail-fox ......
[cpg]


Generally speaking, when a fox has nine tails, it becomes a great Yokai.
[cpg]


There are stories that it is apparently bewitching people on the street, so if it is going to do something bad, now is the time to deal with it.
[cpg]


[SE f="se004"]
;//【ＳＥ】『道歩く』

[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町外れ』（昼）******************************************************


We came to the outskirts of town. It is said to live in a house around here.
[cpg]


Even though it is a Yokai, it still needs a place to live. A strong Yokai does not need to have a home, but for most of them that’s not the case.
[cpg]


Like humans, they are weak creatures compared to wild animals.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane028"]
[OnName num="takane"]
“I'm a little nervous. What if it had eight tails instead of seven?”
[cpg cn=true]


[OnName num="zen"]
“We'll stick together...... and it could be six-tailed, if you put it that way.”
[cpg cn=true]


It could be a big catch. I had brought Takane with me today.
[cpg]


[OnName num="zen"]
“Excuse me is anyone home…..?”
[cpg cn=true]


[SE f="se001"]
;//【ＳＥ】『ふすま開く』
;//ブラックアウト
[FADEOUTBGM]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]


That Yokai did not refuse visitors.
[cpg]


I can't tell from what I saw if it was welcoming or not, but its appearance was ......
[cpg]




[window target=false]
[BG f="b_08_2.ui" time=1000]
[WAIT time=2100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『汎用室内』（昼）******************************************************

;//しばらく佐久夜の名前を「七尾の狐」と隠してください


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="4/5" time=800]

[VOICE f="Sakuya001"]
[OnName num="seven_tailed_fox"]
“Me bewitching people? How?"
[cpg cn=true]


She was a beautiful woman. She took my breath away.
[cpg]


[OnName num="zen"]
"Are you saying it's not true that you bewitch people?"
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Sakuya002"]
[OnName num="seven_tailed_fox"]
“Please call me Sakuya.”
[cpg cn=true]


She was trying to fix a broken umbrella, not paying attention to us.
[cpg]


She seems to have a very casual personality, but we can’t let our guard down.
[cpg]


[OnName num="zen"]
“So Sakuya, do you know that people get lost around here quite often?”
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Sakuya003"]
[OnName num="sakuya"]
“Yes, I've heard. I'm sure there aren't an increasing number of people with no sense of direction, even though it's just a straight road with nothing on it.”
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Takane029"]
[OnName num="takane"]
“Who do you think is responsible?”
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Sakuya004"]
[OnName num="sakuya"]
“I don't know. Who would teach one how to haunt people when one doesn't have parents?”
[cpg cn=true]


She says she is a Yokai born without knowing how to bewitch people.
[cpg]


[FACE method="change_7" pos="4/5"]
[VOICE f="Sakuya005"]
[OnName num="sakuya"]
“Anyway, don’t just stare at me and help me fix this umbrella.”
[cpg cn=true]


I had indeed been wondering about it for a while. It was as if her hands were breaking it rather than fixing it.
[cpg]


[OnName num="zen"]
“Could you give it to me?”
[cpg cn=true]


Thinking she was clumsy, I decided to help. ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『町外れ』（昼）******************************************************

In the end, we never got to the bottom of it. It was as if I had come here to fix her umbrella.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane030"]
[OnName num="takane"]
“Do you believe her story?”
[cpg cn=true]


[OnName num="zen"]
It didn't feel like she was lying.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
In the end, I didn't get many clues, but I knew it was unlikely to be the work of the Yokai, Sakuya.
[cpg]


We had no choice but to continue our investigation. The fact that people got lost out of nowhere made it more likely that a Yokai was involved.
[cpg]


Then, did this mean that Sakuya was lying?
[cpg]


I thought about this and that, but the conclusion was not so easy to come to.
[cpg]


[SE f="se004"]
;//【ＳＥ】『道歩く』

;//ブラックアウト

[FADEOUTBGM]
[WAIT time=1000]

[OnName num="zen"]
“What……”
[cpg cn=true]


And then, when I was about to return to the usual main street.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_ri"]
[WAIT time=100]
;//【ＢＧ】『町外れ』（昼）******************************************************

[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane031"]
[OnName num="takane"]
“It's this road again."
[cpg cn=true]


Something is haunting us. As a Onmyoji, I am used to this kind of thing.
[cpg]


It's not that Takane or I are the type to attract such things, but I often run into them when I head out to investigate.
[cpg]


[OnName num="zen"]
“A Yokai related to roads……If it's not a raccoon or fox, is it a bird?”
[cpg cn=true]


Well, what do we do now? If it were so, then it is a marsupial that has been transformed into a Yokai.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Takane032"]
[OnName num="takane"]
“What shall we do?”
[cpg cn=true]


[OnName num="zen"]
“We can't go home. We'll catch it here.”
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Takane033"]
[OnName num="takane"]
“I understand. Can I borrow your wooden tag?”
[cpg cn=true]


Compared to the humanoid ones, it is easier to get rid of them. Fortunately, there are enough charms to ward off evil spirits.
[cpg]


The problem is, where is the spirit……?
[cpg]



;//ブラックアウト

[SE f="se004"]
;//【ＳＥ】『道歩く』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[FADEOUTBGM]

[BGM f="bg_ba"]
[WAIT time=100]
;//【ＢＧ】『町外れ』（昼）******************************************************

If they are circling the same place, would the Yokai be observing them at the center of their rotation?
[cpg]


The fact that they keep influencing the magic means that they must not be more than a certain distance away.
[cpg]


However, it is a Yokai that is distorting our sense of direction. We don't know in which direction they are turning.
[cpg]


I am glad there are two of us today. As long as we feel we are going straight, there is no opponent in front of us.
[cpg]


[OnName num="zen"]
“Takane. Can you handle the right side?”
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Takane034"]
[OnName num="takane"]
“Understood!”
[cpg cn=true]


We exchanged a few words and immediately turned at right angles.
[cpg]

[SE f="se007"]
;//【ＳＥ】『道走る』

[window target=false]
[transition target={true} rule="migi3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『路地裏』（昼）******************************************************

As we entered the alleyway, it seemed that I, not Takane, was the one who took the lead.
[cpg]


[OnName num="zen"]
“I knew it. It's an animal-turned-Yokai.”
[cpg cn=true]


It was a Yokai transformed from an animal that was not standing upright nor flying.
[cpg]


I held up my tag. I am used to this kind of thing.
[cpg]


I have to consider the fact that my opponent is agile. If it is just a piece of paper, there is no way to throw it and make it fly faster.
[cpg]


It is not possible for a piece of paper to fly straight with the power of magic, so I have to be creative.
[cpg]


[SE f="se030"]
;//【ＳＥ】「木札を投げる」
[WAIT time=1100]

[OnName num="zen"]
“Don't run away!”
[cpg cn=true]


Even this piece of paper I just threw is not a mere tag. It is not made of paper, but of wood.
[cpg]


It is a wooden tag, something that has been around for a long time. In some cases, they are even made of metal.
[cpg]


And you don't have to hit it directly. It's just for stopping them.
[cpg]



[SE f="se009"]
;//【ＳＥ】呪文

;//画面少し白く
[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1000]
[BG f="b_10_2.ui" time=1000]
[WAIT time=1000]


[OnName num="zen"]
“Okay, ......, now, accept your fate.”
[cpg cn=true]


It's called a ward, and if you are a poor Yokai, you can't go on with just this.
[cpg]


I'm sure this Yokai won't do anything bad anymore just because of this experience, but still, just in case.
[cpg]


I chant a mantra to the Yokai.
[cpg]


A mantra is used to ward off evil spirits, and its origin is outside of the sea. It is a kind of magic that permeates Buddhism as well.
[cpg]


If this is a Yokai that operates on a relatively simple mechanism, that is, a Yokai that is based on an animal, this is enough to stop it from doing bad things.
[cpg]



;//ブラックアウト


It's not a big deal to me.
[cpg]


The big deal is that I can't get any recognition for my research.
[cpg]


[OnName num="zen"]
“Phew……”
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『路地裏』（昼）******************************************************


After getting rid of the bad spirit, I met up with Takane again.
[cpg]


The path was different from before, it was back to normal path where we wouldn’t get lost.
[cpg]


Or rather, the path was the same as before. It was just that my sense of direction had gone wrong.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Takane035"]
[OnName num="takane"]
“How was it? Was it a dangerous Yokai?”
[cpg cn=true]


[OnName num="zen"]
“No, it was a quiet one. I think even you could have handled it.”
[cpg cn=true]


When I said this, for some reason, Takane became unhappy.
[cpg]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Takane036"]
[OnName num="takane"]
“What do you mean, even I? I am a full-fledged Shikigami myself.”
[cpg cn=true]


[OnName num="zen"]
“But I'm only a practicing Onmyoji.”
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Takane037"]
[OnName num="takane"]
“That's not true!”
[cpg cn=true]


Takane is not always acceptant. I think there is a bit of stubbornness in her.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町外れ』（夕方）******************************************************

[OnName num="customer"]
"Are you saying that the cause of this was not because of the fox Yokai?"
[cpg cn=true]


[OnName num="zen"]
“I think so. I guess people are not what they appear to be.”
[cpg cn=true]


[OnName num="customer"]
“But she’s not a person. She’s a Yokai.”, Takane chuckled.
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane038"]
[OnName num="takane"]
' "......"
[cpg cn=true]


I am not really acquainted with Sakuya, but her words caught my attention a little.
[cpg]


Even so, it seems better not to say things that will hurt her. After all, my own life depends on this.
[cpg]


For example, even Takane is a kind of Yokai. Even though Hinomoto has chosen to coexist with Yokai, there is still a lot of prejudice against them.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

It's not that the previous guest was particularly rude, but this is just the way it is in general.
[cpg]


Some people even hate Yokai without any reason.
[cpg]


In fact, since this is a store for dealing with Yokai, there are many people who think this way.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane039"]
[OnName num="takane"]
“After all, it is a difficult world for Yokai to live in.”
[cpg cn=true]


It was sad to hear Takane say that.
[cpg]


[OnName num="zen"]
“I guess so. Don't worry, I will make this country a comfortable place for you to live.”
[cpg cn=true]


I'm getting ready for a bath, but I think it's doable.
[cpg]


[OnName num="zen"]
“People are scared because they don't know.”
[cpg cn=true]


[OnName num="zen"]
“I'm going to figure out everything they don't know, spread the word, and create true coexistence.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Takane040"]
[OnName num="takane"]
“...... Master, that is amazing.'
[cpg cn=true]


Takane is awfully cute when she smiles at me at times like this. It's a smile that isn't just to compliment me.
[cpg]


We are very dependent on each other, but it also motivates me.
[cpg]





;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大通り』（昼）******************************************************

A peaceful time passed for a while in Hinomoto.
[cpg]


Of course, when I say peaceful, I mean peaceful coexisting with Yokai. It is not as if nothing strange happens at all.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_09_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

But that peace was changing little by little.
[cpg]

[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="zen"]
“Curse? The kanji that consists of ‘mouth’ and ‘brother’?”
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane041"]
[OnName num="takane"]
“Yes. I’ve never heard someone say that before though.”
[cpg cn=true]


But either way. 
[cpg]


I know the concept of curse. But I don't think it means what it says.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Takane042"]
[OnName num="takane"]
“I've heard that curses have been seen in many places recently. They are different from Yokai.”
[cpg cn=true]


[OnName num="zen"]
“I didn’t know. Who told you about it?”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane043"]
[OnName num="takane"]
“A customer. It happened when the husband was away.”
[cpg cn=true]


I asked Takane for more details.
[cpg]


Apparently it was different from Yokai. It is an independent phenomenon called “curse".
[cpg]


It is said that those who are possessed by a curse do not transform into a Yokai, but remain human......
[cpg]


It has a negative effect that interferes with one's life.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************

[OnName num="townspeople_A"]
“Curse? The kanji that means ‘show’ and ‘brother’?”
[cpg cn=true]


[OnName num="townspeople_B"]
“No, that is ‘celebration’.”
[cpg cn=true]


[OnName num="townspeople_A"]
"Oh, I see. ...... but I've never heard of a curse.”
[cpg cn=true]


[OnName num="townspeople_B"]
"You have never heard of it? I guess it's just starting to catch on, so I guess it's understandable.”
[cpg cn=true]


It's not that I started asking around. And yet, when I walk around town, I hear such stories.
[cpg]


While I am in the store, I am waiting for customers, so perhaps it is easier to gather information this way.
[cpg]


But of course, I can't get deeper information. There is of course a possibility that the consultation about the curse will also come to our place.
[cpg]



[window target=false]
[BG f="b_05_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『神社の境内』（夕方）******************************************************

Because we can't say that it has nothing to do with Onmyoji. If it's not a disease, it's not a doctor's job.
[cpg]


I decided to exchange information with Hazuki again, hoping to have a rough idea before welcoming such customers.
[cpg]


But when I met her in the precincts of the shrine, she was somehow different from usual.
[cpg]


[FG f="CHA01_p5_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Hazuki035"]
[OnName num="hazuki"]
"...... Good evening."
[cpg cn=true]


[OnName num="zen"]
“Hazuki, what's wrong? You look a little pale.”
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Hazuki036"]
[OnName num="hazuki"]
“Are you sure? It's because the sun is setting.”
[cpg cn=true]


[OnName num="zen"]
“Well, your face looks rather red than pale.”
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Hazuki037"]
[OnName num="hazuki"]
“If so, it's because of the sunset.”
[cpg cn=true]


She doesn’t make any sense. She seems like she is trying to hide something.
[cpg]


[OnName num="zen"]
“I hope it's nothing.……"
[cpg cn=true]


And so we began talking about the curse.
[cpg]


[OnName num="zen"]
"Hazuki, do you know about the curse that seems to be popular these days?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki038"]
[OnName num="hazuki"]
“I do. Many people come to us for advice.”
[cpg cn=true]


[OnName num="zen"]
“I knew it. But ...... I still don't know what it is.”
[cpg cn=true]


[OnName num="zen"]
“What about you Hazuki? Do you know what happens when you are under a curse?”
[cpg cn=true]


[FACE method="shock_7" pos="2/3"]
[VOICE f="Hazuki039"]
[OnName num="hazuki"]
"...... that's ……"
[cpg cn=true]


[OnName num="zen"]
"Or is it something embarrassing that no one wants to talk about what's inside?”
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Hazuki040"]
[OnName num="hazuki"]
"......You know all that and you don't even realize it."
[cpg cn=true]


[OnName num="zen"]
“What? What did you say?”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Hazuki041"]
[OnName num="hazuki"]
“Nothing. I don't know much either.”
[cpg cn=true]


She looked aways. It looked like she was lying.
[cpg]


[OnName num="zen"]
“Are you sure you're all right? It's not the sunset. I think you might have fever.”
[cpg cn=true]


When I asked her, she didn't deny it.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hazuki042"]
[OnName num="hazuki"]
“There’s something that I wanted to talk to you about. Actually well whatever…….”
[cpg cn=true]


She said. It was somewhat suggestive, and Hazuki seemed strangely attractive today.
[cpg]


[OnName num="zen"]
“You could have told me anything."
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Hazuki043"]
[OnName num="hazuki"]
“I can't say it. I can only say it to you, but I can't say it because it's you."
[cpg cn=true]


What..... what does that mean?
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

[OnName num="zen"]
“That’s what happened. What do you think?”
[cpg cn=true]



[FACE method="shake_7" pos="2/3"]
[VOICE f="Takane044"]
[OnName num="takane"]
"Hmmm. Hazuki, might have feelings for you.”
[cpg cn=true]


I wonder if Takane is teasing me. But we don’t have that sort of a relationship.
[cpg]


[OnName num="zen"]
“I don't think so. There is no reason.”
[cpg cn=true]


Are you sure, she said and got deep into thought.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Takane045"]
[OnName num="takane"]
“For me, it's complicated."
[cpg cn=true]


[OnName num="zen"]
“Complicated? What is?”
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Takane046"]
[OnName num="takane"]
“I guess you treat her like that as well. I can imagine.”
[cpg cn=true]


I know she is teasing me, but I don't understand what she means.
[cpg]


[OnName num="zen"]
“Anyway, if there's something going on, I can't leave it alone. No, maybe it's ......"
[cpg cn=true]


Maybe she's under a curse herself?
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I think as I lie in my room.
[cpg]


I'm not the type of person who would give someone a mixed message. But she still seemed reluctant to confide something to me.
[cpg]


It is possible that there is something that she is ashamed to tell me.
[cpg]


And we still don't know how the curses function.
[cpg]


I only know enough to know that it's something that interferes with my life too. ......
[cpg]


I had a feeling there was a reason why the details were not very public.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

The next morning, I decided to probe further.
[cpg]


[OnName num="female_customer"]
“I don't know much either. I just ......"
[cpg cn=true]


……Something that is hard to say. I wonder what that would be.
[cpg]

But that would explain what is happening to Hazuki, or rather the reason for her attitude.
[cpg]


[OnName num="female_customer"]
“The Onmyoji of all Hinomoto is being gathered to counteract the curse, apparently. It's that big of a deal."
[cpg cn=true]


[OnName num="zen"]
"What?”
[cpg cn=true]


[OnName num="female_customer"]
"You don't know? Were you not invited? Or maybe they don't see you as a Onmyoji.”
[cpg cn=true]


[OnName num="zen"]
“No way. I'm sure you are Hinomoto's Onmyoji.”
[cpg cn=true]


I'm sure I'll be approached as well. If so, this would be a good time for me to present my long-preserved theory about Yokai.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1100]

It would be a challenge to gather all the Onmyoji in Hinomoto. So maybe not everyone was actually invited.
[cpg]


It would be a considerable number of people, so it is possible that only the best would be called upon.
[cpg]


But this is Kinoto. It is basically the headquarters of Onmyoji.
[cpg]


That means I can be invited too, and I can reveal everything from my unique perspective.......
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I had planned to do that, but I was never invited in the first place.
[cpg]


[OnName num="zen"]
“No one is interested in what I'm thinking, right? ……"
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Takane047"]
[OnName num="takane"]
“That’s not true! I know how great you are.”
[cpg cn=true]


[OnName num="zen"]
“You're getting tired of trying to cheer me up, too."
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Takane048"]
[OnName num="takane"]
“No way! I'll keep on praising you until you stop dragging yourself down.”
[cpg cn=true]


I don't know whether she is strict or gentle. No, endlessly kind.
[cpg]


Takane is always positive. She is so carefree that I am at a loss for words.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Takane049"]
[OnName num="takane"]
“This must be a mistake. There must be a reason.”
[cpg cn=true]


Maybe it's not a mistake, maybe it's nothing. Maybe I'm not being recognized as an Onmyoji.
[cpg]


Or maybe only higher-ranked Onmyoji are being gathered.
[cpg]


[OnName num="zen"]
“You are kind, Takane.”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Takane050"]
[OnName num="takane"]
“I am not, I just know how great you are.”
[cpg cn=true]


I really wonder how she can be so confident to support me.
[cpg]


But right now, I was grateful to have her affirmation.
[cpg]


[OnName num="zen"]
“Thank you. I'm going to go to bed for a bit."
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Takane051"]
[OnName num="takane"]
“Oh. Did I say something wrong?”
[cpg cn=true]


[OnName num="zen"]
“No. I'm just going to bed because I'm sleepy, not because I'm depressed.”
[cpg cn=true]



In fact, I am sulking, but I didn't dare to say that.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

But nothing will change if I go to bed like this. If I'm not called, I'll make sure to be good enough to get called.
[cpg]


If they're gathering to counter the curse, I just have to figure out how to counter it ahead of them.
[cpg]


If I can sell that method to a high ranking Onmyoji and get him to approve it, I can......
[cpg]


[OnName num="zen"]
“…..But how?”
[cpg cn=true]


The only thing I had figured out was the principle of how a Yokai becomes a Yokai.
[cpg]


I still don't know how to prevent the curse.
[cpg]

[jump storage="ep001.ks" target="*start"]

;////////////////////////////////////////////////////////////////
