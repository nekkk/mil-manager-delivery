

;//==============================
;//３、佐久夜

;#################################################
*Ep010|Dependable Sakuya
;#################################################

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]


;//選択肢のジャンプ先
*select00_3|Dependable Sakuya


[SCENE id=10]

;//ルートフラグ
[stflag ChaRoute = 3]



[OnName num="zen"]
“Sakuya......!"
[cpg cn=true]


I headed towards Sakuya’s place. I knew that Sakuya, who was supposed to be the furthest away from me in terms of distance, would be the most dependable.
[cpg]


[SE f="se007"]
;//【ＳＥ】『道走る』

;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]




I kept running. Until I reached Sakuya's place, I knew something was approaching me.
[cpg]


I couldn't look back. I just kept on running.
[cpg]



[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『町外れ』（夕方）******************************************************

When I was getting tired and out of breath, I saw Sakuya in the distance.
[cpg]


[OnName num="zen"]
"Sakuya, hey……!"
[cpg cn=true]


I couldn't think of any simple words to explain the situation.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sakuya066"]
[OnName num="sakuya"]
"What's the matter, you look pale……?”
[cpg cn=true]


[OnName num="zen"]
“Something's coming! I think it's some kind of curse.……!"
[cpg cn=true]


Sakuya flinched and looked at the alcohol in her hand for some reason.
[cpg]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakuya067"]
[OnName num="sakuya"]
“A curse ......? Well then."
[cpg cn=true]


She also seemed to see that something that was chasing me.
[cpg]


[SE f="se022"]
;//【ＳＥ】「水まき」
[FACE method="shock_1" pos="2/3"]
And in the direction from which I had fled, she suddenly sprinkled the alcohol.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sakuya068"]
[OnName num="sakuya"]
“It's a drink to ward off evil. If it's a curse or something, it should work.”
[cpg cn=true]


Of course, it's not something that can be eradicated. If it did, it would have prevented the curse from the beginning.
[cpg]


I turned and looked at the thing that was following me.
[cpg]


[OnName num="zen"]
“Is it weakening?”
[cpg cn=true]


[SE f="se022"]
;//【ＳＥ】「水まき」
[FACE method="shock_1" pos="2/3"]
Sakuya sprayed her drink once more. The curse that had been chasing me changed its direction and disappeared from my sight.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sakuya069"]
[OnName num="sakuya"]
“Phew. Is….. this it?”
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『汎用室内』（夕方）******************************************************

After that, Sakuya invited me to her home.
[cpg]


[OnName num="zen"]
“Thank you ....... If I had been alone, I would have probably died."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sakuya070"]
[OnName num="sakuya"]
“It’s okay. I had the curse exorcised too, so it's mutual.”
[cpg cn=true]


But I never thought that the alcohol used to ward off the curse would come in handy in this way.
[cpg]


[OnName num="zen"]
“If we ever have to hunt it down, it might come in handy.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakuya071"]
[OnName num="sakuya"]
“Maybe. Well, you should take a break now. You're still a little out of breath."
[cpg cn=true]


[OnName num="zen"]
“Sorry......."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『町外れ』（夜）******************************************************

By the time we went outside, it was night time. Takane seemed to be worried about me.
[cpg]


I quickly walked back to the store.
[cpg]


[SE f="se004"]
;//【ＳＥ】「道を歩く」

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


When I got back, she was not only worried but also angry.
[cpg]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Takane175"]
[OnName num="takane"]
“After what you said the other day, I was really worried about you! If you're going to go investigate, please take me with you.”
[cpg cn=true]


I could see the worry, now the anger, and then the relief at my return.
[cpg]


[OnName num="zen"]
“I'm sorry ....... I'll tell you next time."
[cpg cn=true]


Realizing the gravity of the situation, I was thinking about how I was going to investigate.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

It is dangerous to confront that thing without a plan of action.
[cpg]


So I decided to stay in the store for the rest of the day.
[cpg]


If I have to hunt it down, it will be after I come up with an effective strategy.......
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/5" time=800]
[VOICE f="Takane176"]
[OnName num="takane"]
“Welcome, oh….”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Sakuya072"]
[OnName num="sakuya"]
"......"
[cpg cn=true]


I was tending to the store and there came Sakuya.
[cpg]


I thought she came here to walkabout yesterday, but that was not the case.
[cpg]


Her face was red, as if she had caught a cold.
[cpg]


[OnName num="zen"]
“What's wrong?"
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]
[VOICE f="Sakuya073"]
[OnName num="sakuya"]
“I feel like……. I've been cursed again.”
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Takane177"]
[OnName num="takane"]
“Is that so? I'll bring you some tea.”
[cpg cn=true]



;//ブラックアウト


The curse. The fact that she brought it to me means that I will exorcise it not with blood but with saliva.
[cpg]


She knows this, and that is why she is here. Takane reading the room excused herself.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

[OnName num="zen"]
“What kind of curse is it? Please tell me as much as you can.”
[cpg cn=true]



[FACE method="bow_7" pos="2/3"]
[VOICE f="Sakuya074"]
[OnName num="sakuya"]
“It's just that ...... my body feels as if someone is touching me.”
[cpg cn=true]


Is there such a curse? It's hard to imagine.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sakuya075"]
[OnName num="sakuya"]
“At first I thought it was just my imagination, but it's getting stronger.”
[cpg cn=true]


She was embarrassed, but told me.
[cpg]


[OnName num="zen"]
...... I see."
[cpg cn=true]


There is no conflict of interest between me and her. We don't owe each other anything for what happened the other day.
[cpg]


If anything, since she is a Yokai, you never know when she will turn against me.
[cpg]


But even so, we are not completely unrelated. She is the person who saved me from a crisis.
[cpg]


[OnName num="zen"]
“I understand. But you know how I break curses, don't you?”
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Sakuya076"]
[OnName num="sakuya"]
“I do. I'm offering it to you because I think you're the right person for the job, so don't make me say it...”
[cpg cn=true]


I can't just do nothing after being told that much.
[cpg]


I can’t just humiliate her. I thought for a moment about how to break the curse.
[cpg]



;//選択肢のジャンプ先
*select03_2_0|The ever-reliable Sakuya.


;//■選択肢

[switch]
[case "Kiss her lips"]
	[swap]
	[jump target="*select03_2_1"]
[case "Kiss her cheek"]
	[swap]
	[jump target="*select03_2_2"]
[endswitch]

1. Kiss her lips
2. Kiss her cheek

;//==============================
;//１、唇に口づける

;//選択肢のジャンプ先
*select03_2_1|Dependable Sakuya

;//選択肢のジャンプ先



[OnName num="zen"]
“I still feel like someone is touching me, which means the curse is probably near my head.”
[cpg cn=true]


[OnName num="zen"]
“So I think ...... lips or something like that would work, what do you think?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sakuya077"]
[OnName num="sakuya"]
“Why are you asking me? I believe in what you believe in.”
[cpg cn=true]



;//ブラックアウト


If she says so, then that's great. I have no hesitation anymore.
[cpg]

I approach her. And our lips touch. ......
[cpg]




;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

Then her curse seemed to be lifted. I was relieved to see that I had successfully exorcised it.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sakuya078"]
[OnName num="sakuya"]
“How do you know the solution for the curse?”
[cpg cn=true]



[OnName num="zen"]
“Well, that's ...... what I do for a living.”
[cpg cn=true]


I'm not saying that, but it's not something I've done too many times.
[cpg]


Call it intuition, but it worked, so that was good.
[cpg]

;//分岐ループから抜ける
[jump target="*select03_2_4"]

;//==============================
;//２、頬に口づける

;//選択肢のジャンプ先
*select03_2_2|Dependable Sakuya

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************

I brought her into my room and I said to her.
[cpg]


[OnName num="zen"]
"...... Are you sure you want to do this?”
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakuya079"]
[OnName num="sakuya"]
“Yes, I'm sure. I want you to do it.”
[cpg cn=true]


If she said that much, I couldn't back down even if I wanted to.
[cpg]



;//ブラックアウト
[FACE method="change_2" pos="2/3"]

We look at each other. I felt like there was a meaning to the way she was looking at me.
[cpg]



;//========================================
;//●ＣＧ（主人公に寄り添うヒロイン）ev_41
;//人物１：ヒロイン３　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================
;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
;//[BGM f="bg_h2"]

[WAIT time=1000]
;**【ＣＧ】 ev_41_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]

In the past, it was often the case that a kiss on the cheek would break the curse.
[cpg]

俺は今までに倣って、彼女の頬に口づけをする……
[cpg]

[VOICE f="Sakuya080"]
[OnName num="sakuya"]
“Mmh......"
[cpg cn=true]


I thought she looked kind of happy.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sakuya081"]
[OnName num="sakuya"]
“Now I guess I've solved it. It kind of ...... still feels weird, though.”
[cpg cn=true]


Sakuya says so. I might have kissed her in the wrong place.
[cpg]

But then, it's only until I do it again.
[cpg]



[OnName num="zen"]
“Please stay with me a little longer. I will break the curse at any cost.”
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakuya082"]
[OnName num="sakuya"]
“Yes, I'll need you to break the curse.”
[cpg cn=true]


;//この選択肢を除いて、もう一度同じ分岐へ戻る

[stflag Cha3flg = -1]

[switch]
[case "Kiss her lips."]
	[swap]
	[jump target="*select03_2_1"]
[endswitch]

[jump target="*select03_2_0"]

;//==============================

;//選択肢のジャンプ先
*select03_2_4|Dependable Sakuya

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************


[FACE method="change_7" pos="2/5"]
[VOICE f="Takane178"]
[OnName num="takane"]
“Oh, um, sir.……"
[cpg cn=true]


After we were done, Takane came to check on us.
[cpg]


[OnName num="zen"]
“It went well. The curse was properly lifted.”
[cpg cn=true]



[FACE method="bow_2" pos="4/5"]
[VOICE f="Sakuya083"]
[OnName num="sakuya"]
“Thank you. I'm fine now.”
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Takane179"]
[OnName num="takane"]
“Well. I'm glad to hear that….."
[cpg cn=true]


Takane looks embarrassed. Takane knows what happened between us.
[cpg]


Not only did she blush, but she also had an embarrassed look on her face.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大通り』（夕方）******************************************************

[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakuya084"]
[OnName num="sakuya"]
“Thank you so much. Come over to my house next time. I'll thank you."
[cpg cn=true]


[OnName num="zen"]
"You don't need ...... to thank me. You already paid me.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sakuya085"]
[OnName num="sakuya"]
“No problem. It's a promise.”
[cpg cn=true]


I was looking at her back, puzzled by her one-sided promise.
[cpg]


I don't know how she feels. I can't even imagine what she meant by “I’ll thank you”.
[cpg]


But I don't know. I had a feeling that I was expecting something unexpected.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



A few days passed with such expectations.
[cpg]


It was a different day from the day when the curse was lifted. It was the day on which Sakuya had said she would thank me.
[cpg]

[SE f="se004"]
;//【ＳＥ】「道を歩く」

[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]

;//【ＢＧ】『町外れ』（夜）******************************************************

I had to work during the day, so I went to her place at night.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakuya086"]
[OnName num="sakuya"]
“Come on in.”
[cpg cn=true]


[OnName num="zen"]
“I'm sorry it's so late. Is it all right?”
[cpg cn=true]



[FACE method="shake_2" pos="2/3"]
[VOICE f="Sakuya087"]
[OnName num="sakuya"]
“Yes, it's fine. You don't have to be so formal.”
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『汎用室内』（夜）******************************************************

It's been a long time since I've been in Sakuya's room.
[cpg]


Sakuya said she would thank me, but she had a serious look on his face.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sakuya088"]
[OnName num="sakuya"]
“You know, I don't remember my parents' faces.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sakuya089"]
[OnName num="sakuya"]
“I thought I was originally a Yokai, born out of thin air.”
[cpg cn=true]


[OnName num="zen"]
“......Right."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakuya090"]
[OnName num="sakuya"]
“But according to your theory, you can't be born out of nothing, can you?”
[cpg cn=true]


This is an important story concerning her birth. I can't say anything vague or uncertain.
[cpg]


[OnName num="zen"]
“It should be so. There is a strong possibility that you were a human."
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Sakuya091"]
[OnName num="sakuya"]
“If ..... that's the case, then……"
[cpg cn=true]


She hesitated for a moment, then spoke up.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Sakuya092"]
[OnName num="sakuya"]
“I'd like to meet my parents."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
After she said this, she looked sad.
[cpg]


She must have been alone ever since she became a Yokai. It is easy to imagine.
[cpg]


Part of me didn't want her to have that look on her face, but more than that, I genuinely wanted to help her.
[cpg]


[OnName num="zen"]
“I might even be able to make that happen."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[WAIT time=1500]
[FACE method="bow_2" pos="2/3"]
Sakuya was surprised for a moment and then laughed a little.
[cpg]


[FACE method="change_1" pos="2/3"]
;//どうしてそこまでしてくれるのか、そう言いたげに俺を見ている。
;//[cpg]

[VOICE f="Sakuya093"]
[OnName num="sakuya"]
;//正
“You said it. Why are you doing this for me?”
;//誤　ボイス
;//「言ったね？　どうして私にそこまでしてくれるのさ」
;//
[cpg cn=true]


Why? Why, of course.
[cpg]


It was the same reason why I unconsciously chose to go to her when I was attacked by that curse.
[cpg]


[OnName num="zen"]
"It's because I'm attracted to ...... you.”
[cpg cn=true]


Here. I said it.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sakuya094"]
[OnName num="sakuya"]
"......"
[cpg cn=true]


Sakuya was looking at me with a serious expression, something she doesn't show very often.
[cpg]


[OnName num="zen"]
“There is also the fact that you have a personality that is not common, and above all…”
[cpg cn=true]


[OnName num="zen"]
“I'm aware of the insecurity you have inside of you. I want to do something about it.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sakuya095"]
[OnName num="sakuya"]
"Hmmm. Don't say that so lightly.”
[cpg cn=true]


Sakuya smiled while saying that.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Sakuya096"]
[OnName num="sakuya"]
“I can't reply right now. I'm sorry.
[cpg cn=true]


I think about the meaning of her words. Was this a bit too early?
[cpg]


[window target=false]
[BG f="b_11_4.ui" time=1000]
[WAIT time=2000]
[window target=true]


But I had no regrets, I said what I wanted to say. I'm glad I did.
[cpg]


;//彼女とは付き合ったわけじゃない。明確に言葉にはしてない。
;//[cpg]


[SE f="se015"]
;//【ＳＥ】『鳥の鳴き声』

[window target=false]
[BG f="b_11_1.ui" time=1000]
[WAIT time=2000]
[window target=true]



;//ブラックアウト

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[BG f="b_09_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

;//しかし、店に帰るのは翌朝になってしまった。
After that, it was already late at night, so she graciously let me stay at her house. So I didn't return to the store until the next morning.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane180"]
[OnName num="takane"]
“Welcome home. You stayed at Sakuya’s place, didn't you?”
[cpg cn=true]


[OnName num="zen"]
“Oh, yeah. What's that ......?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Takane181"]
[OnName num="takane"]
“Hmmm. You don't have to tell everyone.”
[cpg cn=true]


At least she figured out what happened. It seems that Hazuki and Midori might also hear rumors about it.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

Midori had also come to the store that day, and I was nervous that Takane might tell Midori.
[cpg]


Although I can’t take back what happened. And when I came back.....
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="4/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[VOICE f="Midori162"]
[OnName num="midori"]
"...... is that so...... Sakuya?”
[cpg cn=true]


[FACE method="change_5" pos="2/5"]
[VOICE f="Takane182"]
[OnName num="takane"]
"I, too, have not been able to confirm it yet...... oh.”
[cpg cn=true]


[OnName num="zen"]
“What were you talking about?”
[cpg cn=true]


I knew, but I asked on purpose.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Takane183"]
[OnName num="takane"]
"Oh, uh..... nothing."
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Midori163"]
[OnName num="midori"]
"I was just thinking that you can't be left in the corner either.”
[cpg cn=true]


Takane is trying to veer away from the situation, but Midori is not so sure.
[cpg]


There is a difference in personality, but in any case, it can't be helped that it's been caught.
[cpg]


[OnName num="zen"]
“…… I see."
[cpg cn=true]


I scratched my head as I replied.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『町外れ』（夕方）******************************************************

If I can't hide it from them, I have no hesitation in going to Sakuya.
[cpg]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakuya097"]
[OnName num="sakuya"]
“I’m glad you're here. Come on in."
[cpg cn=true]


We are not yet lovers. Even so, Sakuya did not mind me visiting her.
[cpg]


We were practically dating, but we didn't say so in words.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sakuya098"]
[OnName num="sakuya"]
“It's already evening, isn't it? Do you want to have dinner?”
[cpg cn=true]


[OnName num="zen"]
“Can I? I've never had a home-cooked meal from you before.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sakuya099"]
[OnName num="sakuya"]
“Leave it to me. I don't often eat with other people.”
[cpg cn=true]


It seemed that Sakuya was also enjoying this current distance.
[cpg]


If that's the case, then I'll do the same, and I didn't speak further about the relationship.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『汎用室内』（夜）******************************************************

Sakuya's cooking was good. It was somewhat surprising, but I didn't say so.
[cpg]


[OnName num="zen"]
“Thank you for the food.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakuya100"]
[OnName num="sakuya"]
“So…..why did you some here today?”
[cpg cn=true]


[OnName num="zen"]
“What? I don’t know how to answer that.”
[cpg cn=true]


I didn’t have any reason. But if I tell her that, she will officially be my lover.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sakuya101"]
[OnName num="sakuya"]
“Hmmm, even if you came to my place for nothing, I'm glad you did.”
[cpg cn=true]


We continue our conversation.
[cpg]


Just a few days ago, there was a new curse or Yokai that I don't know what it is, and I was almost attacked by it.
[cpg]


I wanted to cherish this kind of leisurely time.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Sakuya102"]
[OnName num="sakuya"]
“Do you want to stay over. I’d like it if you did.”
[cpg cn=true]


[OnName num="zen"]
“……Okay then.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sakuya103"]
[OnName num="sakuya"]
"It's decided.”
[cpg cn=true]


She was so aggressive. I loved her so much that I couldn't say no to her.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se015"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『汎用室内』（朝）******************************************************



[OnName num="zen"]
“It’s morning...”
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakuya104"]
[OnName num="sakuya"]
“Yes….…”
[cpg cn=true]


We take our time getting up.
[cpg]


It's impossible to say that we're not lovers when we were sleeping cuddled up like this.
[cpg]


Knowingly, I didn't name this relationship.
[cpg]


And it's the same with Sakuya. I sensed that she wanted to keep it ambiguous, but not ambiguous.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町外れ』（朝）******************************************************

[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Sakuya105"]
[OnName num="sakuya"]
“See you later. Good luck with your work.”
[cpg cn=true]


[OnName num="zen"]
“Yes. See you later.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
I waved back. Sakuya looked a little sad.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Sakuya106"]
[OnName num="sakuya"]
“I'll see you soon, right?”
[cpg cn=true]


[OnName num="zen"]
“Of course. I'll be back.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
After exchanging such conversation, I headed home.
[cpg]



[SE f="se004"]
;//【ＳＥ】『道歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大通り』（朝）******************************************************

This is the way I want our relationship to be. But because I feel so happy with our relationship, I have some concerns.
[cpg]


What was that thing that attacked me? What was it all about?
[cpg]


If I can't solve that, the happy future for me and Sakuya may be threatened.
[cpg]


I've been targeted once. Even if that is not the case, there is a good chance that it will spread like a curse.
[cpg]




;//ジャンプ先指定
;//総合ルートへ
;//[jump target="*select00_0"]


[jump storage="ep013.ks" target="*select00_0"]
