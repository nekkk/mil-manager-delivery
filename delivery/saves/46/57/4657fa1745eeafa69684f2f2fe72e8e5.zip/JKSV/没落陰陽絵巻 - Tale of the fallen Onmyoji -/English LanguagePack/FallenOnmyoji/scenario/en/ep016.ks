
;//==============================
;//２、ヒロイン２を選んでいた場合

;#################################################
*Ep016|Clean Footwear
;#################################################


[stflag Cha1flg=0]
[stflag Cha2flg=0]
[stflag Cha3flg=0]
[stflag Cha4flg=0]
[stflag Cha5flg=0]

;//選択肢のジャンプ先
*select02_0|Clean Footwear

[SCENE id=16]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Midori188"]
[OnName num="midori"]
”Hello. Zen."
[cpg cn=true]


When she came in, Takane greeted her.
[cpg]



[FACE method="bow_1" pos="2/5"]
[VOICE f="Takane232"]
[OnName num="takane"]
“Welcome, Midori. How has your work been going?"
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Midori189"]
[OnName num="midori"]
“Thanks to the extermination of the Plague God, the business has been growing. I've been busy.”
[cpg cn=true]


That makes sense. Unlike me, Midori probably doesn't have a bad reputation.
[cpg]


But she did visit me, even though she said she was busy.
[cpg]


[OnName num="zen"]
“I'm glad you're busy.”
[cpg cn=true]


I look at the two of them chatting. The clock seems to have been fixed and is pointing to the correct time.
[cpg]


I wonder if she fixed it herself. So I decided to ask her something that I wanted to ask for a long time.
[cpg]


[OnName num="zen"]
“When did you decide to start acting exactly on time on the clock?"
[cpg cn=true]

[FACE method="shock_5" pos="4/5"]
Midori was a little surprised by the sudden question. Then, as if reminiscing about the old days, she began to talk.
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Midori190"]
[OnName num="midori"]
“It started ...... a long time ago.”
[cpg cn=true]


[FACE method="change_2" pos="4/5"]
[VOICE f="Midori191"]
[OnName num="midori"]
;//「修行時代に、まだキノトに居なかった頃の事ですけど、仲の良い女の子が居たんですよね」
「修行時代に、仲の良い女の子が居たんですよね」
[cpg cn=true]


I listened in silence. I wanted to know more about Midori's past.
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Midori192"]
[OnName num="midori"]
“She was from a wealthy family and the watch was a gift from her.”
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Midori193"]
[OnName num="midori"]
“I felt like I could live in the same time zone as her by following this clock."
[cpg cn=true]


……I was surprised. This story was not something I had expected.
[cpg]


[OnName num="zen"]
“So it has nothing to do with the Plague God.”
[cpg cn=true]


But it did help in the moment of extermination.
[cpg]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Takane233"]
[OnName num="takane"]
“The world is full of wonders, isn't it? You never know what will happen.”
[cpg cn=true]


[OnName num="zen"]
“Yea. You’re right.”
[cpg cn=true]


When the wind blows, the bucket shop makes money. Sometimes cause and effect seem unrelated, even if they are.
[cpg]


It's a way of thinking outside of Hinomoto, but there is an idea that if a butterfly flaps its wings, a storm is bound to happen.
[cpg]


Somehow remembering that, I thought that a life like this must be built on miracles.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p5_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


As Midori was leaving, she said.
[cpg]


[VOICE f="Midori194"]
[OnName num="midori"]
“Um, Zen. Would you like to come to my house sometime?”
[cpg cn=true]


[OnName num="zen"]
“I'd love to. When are you open?”
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************

So I was on my way to Midori's house on my day off.
[cpg]


[FG f="CHA02_p5_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Midori195"]
[OnName num="midori"]
“Good evening. Zen, I see you are wearing the shoes ...... I gave you for your birthday."
[cpg cn=true]


Midori noticed it too. I think this is the first time.
[cpg]


[OnName num="zen"]
“Yes.”
[cpg cn=true]


The shoes have a unique form, so most people usually take a double look the they pass by me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Midori196"]
[OnName num="midori"]
“Giving footwear to someone on their birthday means a lot to me.”
[cpg cn=true]


[OnName num="zen"]
“Is that so?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Midori197"]
[OnName num="midori"]
“I'm sure you don't want to get them dirty if they are beautiful shoes. I thought you would spend a little more time by my side.”
[cpg cn=true]


[OnName num="zen"]
“You have a reason for everything….”
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
They are inherently irrelevant, but Midori's beliefs helped me when I exterminated the Plague God.
[cpg]

[free time=1000]
I guess I need to incorporate irrational things into my life.
[cpg]


While I was thinking about this and that, Midori disappeared from next to me.
[cpg]


While I was walking, she seemed to have stopped. I turned around.
[cpg]


[OnName num="zen"]
“What's wrong? You look blank.”
[cpg cn=true]


[FG f="CHA02_p5_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Midori198"]
[OnName num="midori"]
“You just called my name….…”
[cpg cn=true]


What? What a thing to say. It's nothing more important than a butterfly fluttering its wings.
[cpg]


[OnName num="zen"]
“Do you feel more comfortable? We don't have to be polite to have a good relationship.”
[cpg cn=true]


For her, it was a big deal. I knew that too.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Midori199"]
[OnName num="midori"]
“Please do so. I want you to do so. I want you to call me more casually.”
[cpg cn=true]


She was unusually passionate in her speech. I smiled at her because she was cute.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//ブラックアウト
;//移植のためシーンをカットしています
;//========================================
;//●ＣＧ（仰向けで寝ているヒロイン。元の絵とは違って目を閉じているようにしてください）ev_02
;//人物１：ヒロイン２　服装１：裸
;//人物ex：主人公　　　服装ex：裸
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//備考　：オリジナル特典05.jpgのシーンです
;//========================================


[BGM f="bg_h2"]
[WAIT time=100]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]



It had been some time since I had been with her.
[cpg]


Midori was attracted to rationality and I was helped by her irrationality.
[cpg]


I thought that I would never be separated from her again.
[cpg]



[VOICE f="Midori200"]
[OnName num="midori"]
“Mmh..... Zen….."
[cpg cn=true]


It is morning. In the futon, Midori is calling me while dreaming.
[cpg]


I wanted to stroke her head, but if I do that, will she wake up?
[cpg]


Even the time I spent thinking about that, was a treasure to me.
[cpg]


[if exp={getFlagValue("Cha2flg") == 2 }]
;//ジャンプ先指定
;//[jump target="*select02_1"]
[jump storage="ep017.ks" target="*select02_1"]
[endif]

;//END
;//ブラックアウト
[jump storage="epend.ks" target="*start"]

