
;//==============================
;//二回目のお祓いを、一度で成功させていた場合下記のシナリオを追加

;#################################################
*Ep021|Takane’s Wish
;#################################################


;//選択肢のジャンプ先
*select04_1|Takane’s Wish

[SCENE id=21]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

The next day. During the opening preparations, Takane asked me;
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane245"]
[OnName num="takane"]
“I am a Shikigami, but can I have a human child?”
[cpg cn=true]


......This is a story that generally does not exist. First of all we have a different status, but I've never heard of it.
[cpg]


[OnName num="zen"]
“I don't know. I'll have to get more information, but if I can't, I'll figure it out.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane246"]
[OnName num="takane"]
"Hmmm. You've solved a lot of things, Zen, so I'm sure you'll be able to.”
[cpg cn=true]


Until now, I have stubbornly refused to accept unexplainable paranormal phenomena.
[cpg]


But due to the influence of Takane, my thinking has become much more flexible... I think.
[cpg]


I had a tendency to not proceed with any research unless everything made sense, but I was able to accept ambiguity.
[cpg]


[OnName num="zen"]
“By the way, Takane. You don't call me ‘master’ anymore, do you?”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Takane247"]
[OnName num="takane"]
“Well. I'm not sure what to do either."
[cpg cn=true]


She is very attentive to strange things. But that's a part of her.
[cpg]


[OnName num="zen"]
“Maybe ‘Zen’ might be better. I feel like we're getting closer.”
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]


There have been cases in which a child is born between a Yokai and a human. But it is not as easy as between two humans, or between Yokai’s.
[cpg]


But then, I will create a way to solve this problem.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_c1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

Takane is always by my side.
[cpg]


I think that we have reached the most natural form for both of us, even though we have been through a lot.
[cpg]


Even now, she is sleeping next to me. I watched her peaceful sleeping face.
[cpg]


She even wants to have my child. I'm glad that she wants to......
[cpg]


I also genuinely wanted to fulfill her wish.
[cpg]


There would be more research to do than ever before, but I was still glad.
[cpg]


I treasure everything when I think it's for the sake of Takane.
[cpg]


When I am with her, there is no such thing as wasted effort.......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


......Since then.
[cpg]


The way to make a child between a Shikigami, or Yokai, and a human being.
[cpg]


I even established that. From the outside it may have looked like I was just a research enthusiast, but in fact I was not.
[cpg]


If you think about it, everything I did was for the sake to a secure future with Takane.
[cpg]



;//========================================
;//●ＣＧ非エロ（座っているヒロイン。膨らんだお腹をさすっていて幸せそう）ev_70
;//人物１：ヒロイン４　服装１：私服
;//場所　：妖怪探偵問屋
;//時間　：昼
;//備考　：ヒロインは妊娠六ヶ月くらいです
;//========================================

[BGM f="bg_d1"]

[WAIT time=100]
;**【ＣＧ】 ev_70_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Takane248"]
[OnName num="takane"]
"......I think the baby may have kicked ......"
[cpg cn=true]


[OnName num="zen"]
“Really?"
[cpg cn=true]


Her belly was becoming big. About six months had passed since she was pregnant.
[cpg]



[VOICE f="Takane249"]
[OnName num="takane"]
“Heh heh. I'm really going to be a mother.”
[cpg cn=true]


She rubbed her belly as she said this. I sensed motherhood in her expression.
[cpg]


[OnName num="zen"]
“I have to think of a name. Have you decided on a name yet?”
[cpg cn=true]


I asked her, and she nodded with her hands on her stomach.
[cpg]



[VOICE f="Takane250"]
[OnName num="takane"]
“Of course. A lot. I wrote it all down.”
[cpg cn=true]


She pulls a folded piece of paper out of a drawer.
[cpg]


[OnName num="zen"]
"Let me see."
[cpg cn=true]


She showed me many names on the paper that I could not read. I would never have come up with such names.
[cpg]


But I love it when I think that we have such differences in thought. The future we ended up with was filled with such happiness.
[cpg]



[VOICE f="Takane251"]
[OnName num="takane"]
“I want to know the name that you came up with, too.”
[cpg cn=true]


[OnName num="zen"]
“Oh. It's too ordinary  compared to your ideas.”
[cpg cn=true]



[VOICE f="Takane252"]
[OnName num="takane"]
“It's fine. It's who you are, Zen.”
[cpg cn=true]


Her acceptance of me fulfills me.
[cpg]


I think I was attracted to Takane because of that, and she seems to take pleasure in it.
[cpg]


There is nothing more to say. It was that kind of an afternoon.
[cpg]


;//END
[SCENE id=27]
[jump storage="epend.ks" target="*start"]



;//==============================

;//ヒロイン４エンド
