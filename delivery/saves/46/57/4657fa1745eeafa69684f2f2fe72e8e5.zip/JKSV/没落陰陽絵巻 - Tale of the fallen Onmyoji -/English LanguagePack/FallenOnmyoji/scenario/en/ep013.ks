


;//==============================
;//総合ルート


;#################################################
*Ep013|Battling the Curse
;#################################################


;//選択肢のジャンプ先
*select00_0|Battling the Curse

[SCENE id=13]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


And so, a certain amount of peaceful time had passed.
[cpg]


[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大通り』（昼）******************************************************

Still, a shadow is creeping into my ordinary life.
[cpg]


The thing that once attacked me seems to be attacking people indiscriminately, and is clearly different in nature from the curse.
[cpg]


At a gathering about that something. Before the meeting, I had proposed the following story.
[cpg]


[FG f="CHA02_p5_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Midori171"]
[OnName num="midori"]
“Me ...... going to such an important meeting?"
[cpg cn=true]


[OnName num="zen"]
"Yes. I'm going to recommend you.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Midori172"]
[OnName num="midori"]
“Wouldn't such a meeting be better with fewer people?”
[cpg cn=true]


[OnName num="zen"]
“I don't think so. I want as many viewpoints as possible. Will you join us?”
[cpg cn=true]


Midori seemed to be hesitating, but in the end, I convinced her to attend the meeting.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ri"]
[WAIT time=100]
;//【ＢＧ】『社務所室内』（昼）******************************************************

At the next meeting. The topic of discussion was about the that something that attacked me.
[cpg]


Of course, it was a topic of conversation here too. I had heard about it, so I was able to deal with it.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Midori173"]
[OnName num="midori"]
“I guess it's different from a curse, isn't it?
[cpg cn=true]


Midori had joined us and was magnificent. She was someone that Nagisa and I had recommended.
[cpg]


Since she's trained properly, she seemed more qualified than me to be here.
[cpg]


[OnName num="onmyoji_A"]
“Hm. I can't say for sure that it's irrelevant because of the overlap in time."
[cpg cn=true]


She was looking at me when the room fell silent.
[cpg]


[OnName num="zen"]
“I believe it is identical. I consider to be more evolved."
[cpg cn=true]


[OnName num="onmyoji_B"]
“Indeed, it does not have the substance of a Yokai.”
[cpg cn=true]


There are Yokai that can become invisible or float.
[cpg]


But, that thing is ……
[cpg]


[OnName num="zen"]
"It doesn't seem to have any creatureliness. I don't think it had."
[cpg cn=true]


There are few people who have seen it firsthand, and I'm the only one who has survived an attack.
[cpg]


[OnName num="zen"]
“Until now, the curse would have possessed animals and humans.”
[cpg cn=true]


[OnName num="zen"]
“Maybe it has evolved from there. A curse so strong that it has power on its own and can be seen ......."
[cpg cn=true]


People around me don't take what I'm saying as a joke.
[cpg]


[OnName num="onmyoji_B"]
"How do you perceive the significance of its nature being completely different? That thing isn't trying to keep people alive.”
[cpg cn=true]


[OnName num="zen"]
“The curses you've seen so far have been about love. It was trying to spread itself.”
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Midori174"]
[OnName num="midori"]
“Oh, so it was  trying to thrive with the human beings.”
[cpg cn=true]


I nodded, then went on a bit further.
[cpg]


[OnName num="zen"]
“If it were to exist on its own, it would have to fight for a place to live.”
[cpg cn=true]


[OnName num="zen"]
“The same is true of pre-evolutionary curses, those that are inconvenient to humans. Even in its natural state, it could be exterminated."
[cpg cn=true]


[OnName num="onmyoji_B"]
“So ...... they'd rather attack us."
[cpg cn=true]


It's a horrible thing, but that’s the only way that this makes sense.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Midori175"]
[OnName num="midori"]
“I have a simple question……May I?”
[cpg cn=true]


[OnName num="onmyoji_B"]
“What is it?”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Midori176"]
[OnName num="midori"]
“How did such a thing come to be? Is it because it would be exterminated if it stayed the way it is now?”
[cpg cn=true]


[OnName num="zen"]
“It probably had this form in mind from the very beginning. The first state was a transitional one."
[cpg cn=true]


[OnName num="chief_priest"]
“It was established on its own, and it surpassed the animals. And when it is about to be exterminated, it will fight back......"
[cpg cn=true]


The more we talk about it, the more it seems like a single organism.
[cpg]


[OnName num="zen"]
“If left alone, it may be humans who perish.”
[cpg cn=true]


We all know the gravity of the matter. So they don't take what I say as pessimism.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

The discussion went on for days. We were also dealing with the curse that had existed before.
[cpg]


Even on my days off, I would invite Hazuki and Midori to my store and we would discuss about it.
[cpg]


[OnName num="zen"]
“The curse up until now had possessed animals and humans, and now they were moving independently. But ……"
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane217"]
[OnName num="takane"]
“This time, the curse is a living entity that stands alone, right?”
[cpg cn=true]

[free time=1000]

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Midori177"]
[OnName num="midori"]
“We should name it. We can't just keep calling it a curse this time.”
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Hazuki168"]
[OnName num="hazuki"]
“We can't decide that on our own, but maybe we can at least decide on a name that we can propose.”
[cpg cn=true]


Hazuki is not directly involved in the meeting, but she is taking it seriously.
[cpg]


[OnName num="zen"]
“I'm sorry, Hazuki.”
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Hazuki169"]
[OnName num="hazuki"]
“No worries. I'm sure they'll call me when it is time to exterminate them.”
[cpg cn=true]


That is certainly true. In Hazuki's case, she is also very busy. I am even more sorry now for dragging her into this.
[cpg]

[free time=1000]

[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane218"]
[OnName num="takane"]
“A name……I don't want to give him a name that is cool……."
[cpg cn=true]

[free time=1000]

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Midori178"]
[OnName num="midori"]
“We can’t change it once it’s decided. Let’s not give it a name that is hard to call.”
[cpg cn=true]


[OnName num="zen"]
“Plague God......."
[cpg cn=true]



;//えきじん　と読みます

I just said it in a huff, but Hazuki picked up on it.
[cpg]


[FACE method="shake_2" pos="2/5"]
[VOICE f="Hazuki170"]
[OnName num="hazuki"]
“I think that’s good. Without a name, it's hard to discuss about it. I think it's a good name because it's easy to imagine.”
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ri"]
[WAIT time=100]
;//【ＢＧ】『社務所室内』（昼）******************************************************

What we know has increased a lot.
[cpg]


I had thought out that the curse itself acted like an animal, but now I had confirmation.
[cpg]


[OnName num="onmyoji_B"]
“It's an individual. Unlike before, it is a living thing.”
[cpg cn=true]


[OnName num="zen"]
"Does that mean it can't grow by itself?”
[cpg cn=true]


[OnName num="onmyoji_B"]
“It could be the result of its growth, or it might acquire skills to grow.”
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Midori179"]
[OnName num="midori"]
“In any case, if we are going to do this, we'd better do it soon.”
[cpg cn=true]


If the curse itself is behaving like an animal….
[cpg]


If it is only one, the measures to take are simple.
[cpg]


The analogy is that it's like having a vicious street demon, and it doesn't spread like the disease has so far.
[cpg]


[OnName num="zen"]
“I came up with a name for the ...... phenomenon, if you don't mind."
[cpg cn=true]



;//ブラックアウト


[OnName num="chief_priest"]
“The Plague God……?"
[cpg cn=true]


[OnName num="onmyoji_A"]
“It seems to fit. The word "pestilence" might not be enough.”
[cpg cn=true]


[OnName num="onmyoji_B"]
“I don't disagree. I think that's good.”
[cpg cn=true]


The name is unimportant.
[cpg]


It wasn't just me. I was happy that Hazuki, Midori, and Takane had weighed in on the idea.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『路地裏』（昼）******************************************************

The selection of the location for the exorcism of the Plague God began.
[cpg]


[OnName num="onmyoji_A"]
“A place where the Plague God has been seen….. I don't know if we can hunt it down at the same place……."
[cpg cn=true]

[OnName num="onmyoji_B"]
“We will have to hunt it down. What's the use of being so timid now?”
[cpg cn=true]


Midori and I also had our say in the selection of the location.
[cpg]


[OnName num="zen"]
“They don't seem to go near places like shrines or sanctuaries. We have to take that into consideration as well.”
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Midori180"]
[OnName num="midori"]
“Rather than a small path, I think it would go somewhere to like a private home ...... Let’s go somewhere where we can prepare for an exorcism.”
[cpg cn=true]


[OnName num="onmyoji_B"]
“I know. Don't be so obvious.”
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『奥座敷』（昼）******************************************************

"Many people voluntarily evacuated from this area because they were told that the Plague God would appear.”
[cpg]


For this reason, many of the houses were deserted, and we had to choose one of them.
[cpg]


[OnName num="chief_priest"]
“Would this place have a feng shui problem?”
[cpg cn=true]


[OnName num="onmyoji_A"]
“No. I think it’s good.”
[cpg cn=true]


At that time, I was impressed by the Onmyoji’s concern about feng shui.
[cpg]


I was watching the discussion from a distance.
[cpg]


[OnName num="zen"]
“Can’t beleive so many Onmyoji believe in feng shui for exterminating Yokai……"
[cpg cn=true]


I muttered to myself. Midori heard that and said,
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Midori181"]
[OnName num="midori"]
“I think that's how it is. It is rare to find an Onmyoji who thinks that the art of Onmyoji and feng shui are unrelated.”
[cpg cn=true]


I replied. I listened to their discussion, unconvinced.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


At least at the moment of extermination, feng shui has nothing to do with it. Yet so many Onmyoji believe in it.
[cpg]


I felt uncomfortable, but I kept my mouth shut.
[cpg]


[OnName num="onmyoji_A"]
"But do you think can we conveniently hunt down the Plague God here?”
[cpg cn=true]


[OnName num="onmyoji_B"]
“We'll have to hunt it down with a considerable number of people. We'll need to call in every Onmyoji in Kinoto.”
[cpg cn=true]


[OnName num="chief_priest"]
“We will join you. We may believe in different things, but we all wish for a peaceful world.”
[cpg cn=true]


[OnName num="zen"]
“In that case, I’ll contact some people.”
[cpg cn=true]


The plan was to surround them with a large number of people. It was better to have more people.
[cpg]


Hazuki and Midori, of course, but also Sakuya and Takane...
[cpg]


I'm sure Nagisa will be there, even though she's retired.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane219"]
[OnName num="takane"]
“Welcome back master. Have you decided on a strategy?”
[cpg cn=true]


[OnName num="zen"]
“Yes, it's decided. But we haven't decided on the day to execute it yet.”
[cpg cn=true]


“Is that so?”
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Takane220"]
[OnName num="takane"]
“Then, it would be better to do it on an auspicious day.”
[cpg cn=true]


[OnName num="zen"]
“That again ……"
[cpg cn=true]


However, it is not something that can be ignored. The opinion of the Onmyoji was divided because of this.
[cpg]


Some said it should be as soon as possible, and others said it should be on an auspicious day. When I told this to Takane, she said,
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Takane221"]
[OnName num="takane"]
“Really? If it were me, I would have chosen the auspicious day without hesitation.”
[cpg cn=true]


[OnName num="zen"]
"Are you serious......?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Takane222"]
[OnName num="takane"]
“If you're going to be at the meeting to decide the day again, you'll have to take my opinion into consideration.”
[cpg cn=true]


[OnName num="zen"]
"Yeah, I know, I know……"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane223"]
[OnName num="takane"]
“You said it twice. Promise?”
[cpg cn=true]


Takane pushes me. I can't ignore her if he says that much.
[cpg]



;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]


In the end, there were many Onmyoji whose opinions were very similar to that of Takane.
[cpg]


Everyone believes in the Japanese calendar's six labels. Even though there is no basis for such a thing.
[cpg]


I remained unconvinced, but in any case, the day of the decisive battle was set.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『奥座敷』（昼）******************************************************

[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hazuki171"]
[OnName num="hazuki"]
“About the time when we attack ...... How about the witching hour?”
[cpg cn=true]


[OnName num="onmyoji_A"]
“That's the time of day when the supernatural is most likely to appear, isn't it?”
[cpg cn=true]


[OnName num="onmyoji_B"]
“Yes, it may be more like ghosts rather than Yokai.”
[cpg cn=true]


Hazuki was also talking about that. And everyone agrees with it.
[cpg]


...... Of course, I know how she feels. The Yokai that once killed her father also appeared at the witching hour.
[cpg]


When I think about it, I know it's an important time in Hazuki's life, but it did not have any reason basis.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『奥座敷』（夕方）******************************************************

Preparations are steadily underway. For the decisive battle, I had gathered everyone I knew to this place.
[cpg]


It seems that other Onmyoji did the same, and many Onmyoji and priests were also gathered at this private house where the final battle was to take place.
[cpg]


Of course, there will be more who are participating in this operation. There must be twice or three times this number.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
;//[t_move pos=L 下礼]
[VOICE f="Hazuki172"]
[OnName num="hazuki"]
“I'm getting nervous. I'm sure we'll be fine with this many people.”
[cpg cn=true]


[FACE method="shake_3" pos="4/5"]
[VOICE f="Sakuya107"]
[OnName num="sakuya"]
“You can never be too careful. The opponent is very powerful.”
[cpg cn=true]


I don't often see these two talking.
[cpg]


They did talk once when we got together, but they didn't look as they do now.
[cpg]


I went out the room, feeling somewhat strange.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『路地裏』（夕方）******************************************************

[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Takane224"]
[OnName num="takane"]
"Oh, master. Are you ready?”
[cpg cn=true]


[OnName num="zen"]
“I think we can win with this number of people, but if we lose ...... on the other hand, we won't be able to get away with it.”
[cpg cn=true]


If that's how much damage they can do, it's best to lookout.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Midori182"]
[OnName num="midori"]
“I understand how you feel but it's not a thing to say.”
[cpg cn=true]

[free time=1000]

[FG f="CHA05_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nagisa071"]
[OnName num="nagisa"]
“I'm sure it's all right. You are all first class Onmyoji.”
[cpg cn=true]


The night of the mission was approaching.
[cpg]

[free time=1000]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Takane225"]
[OnName num="takane"]
“I believe in you. I am sure you will be able to overcome this crisis.”
[cpg cn=true]


Takane said something unusually timid. She must have seen the serious looks on everyone's faces.
[cpg]


[OnName num="zen"]
“Oh, yes, of course.”
[cpg cn=true]


If that's the case, then I have to stay strong at least.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『奥座敷』（夜）******************************************************

[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Midori183"]
[OnName num="midori"]
“I wonder if my pocket watch...... is broken.”
[cpg cn=true]


It’s almost time. But Midori was looking at her pocket watch saying so.
[cpg]


[OnName num="zen"]
"I'm sure we don't have to start on time. It's okay if it's broken.”
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Midori184"]
[OnName num="midori"]
"But I've always trusted this pocket watch.”
[cpg cn=true]


Come to think of it, she did talk about that.
[cpg]

[free time=1000]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Sakuya108"]
[OnName num="sakuya"]
“A pocket watch? Such a watch.”
[cpg cn=true]


[FACE method="change_1" pos="2/5"]
[VOICE f="Midori185"]
[OnName num="midori"]
“Oh……Sakuya.”
[cpg cn=true]


[FACE method="change_2" pos="4/5"]
[VOICE f="Sakuya109"]
[OnName num="sakuya"]
“I'll fix it for you. Give it to me.”
[cpg cn=true]


Sakuya was trying to fix Midori's pocket watch in a violent manner.
[cpg]

[FACE method="bow_2" pos="4/5"]
[WAIT time=1000]
[FACE method="bow_1" pos="4/5"]
[WAIT time=1000]
[FACE method="shock_7" pos="4/5"]
[WAIT time=1000]
[FACE method="shock_3" pos="4/5"]
But her fingers would slip and she seemed drunk.
[cpg]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Sakuya110"]
[OnName num="sakuya"]
“How about this ...... here?”
[cpg cn=true]


It must be an elaborate machine, and I don't think Sakuya has the knowledge to fix it. She was the kind of person who would break an umbrella.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Sakuya111"]
[OnName num="sakuya"]
“Here, it's fixed.”
[cpg cn=true]


[FACE method="change_2" pos="2/5"]
[VOICE f="Midori186"]
[OnName num="midori"]
“Thank you! How did you fix it?”
[cpg cn=true]


Sakuya seemed proud, but the needle seems to be moving slower than it did a moment ago.
[cpg]


[OnName num="zen"]
“.....Well, that's okay."
[cpg cn=true]


Even if the watch isn't moving, you can still tell the approximate time.
[cpg]


It's the same for everyone. When we get in trouble, we turn to something other than logic.
[cpg]


I was the only one who didn't.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[SE f="se025"]
;//ＳＥ「時計の針」
[BG f="b_11_4.ui" time=1000]
[WAIT time=2000]

[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/5" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="4/5" time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]


[VOICE f="Midori187"]
[OnName num="midori"]
“It's time. Shall we start the operation?”
[cpg cn=true]


Midori's watch pointed the witching hour.
[cpg]


[OnName num="zen"]
“Yes. Let's go to ……."
[cpg cn=true]


Everyone nodded. Everyone seems quiet.
[cpg]


I've been wondering....... I've been thinking.
[cpg]


Some things cannot be explained by the logic of this world. I want to explain it all with logic.
[cpg]


But I wonder if my beliefs are really correct.
[cpg]


If I'm trying to do the impossible from the start, then ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]
;//【ＢＧ】『路地裏』（夜）******************************************************

[OnName num="onmyoji_A"]
"There it is! Over here!"
[cpg cn=true]


[OnName num="onmyoji_B"]
“Hunt it down! Don't let it get away!”
[cpg cn=true]


[OnName num="onmyoji_C"]
“It went that way! Lure it to that house!
[cpg cn=true]


The final stage is approaching. This is going to be my biggest job as an Onmyoji.
[cpg]


[SE f="se007"]
;//【ＳＥ】「道を走る」

[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『奥座敷』（夜）******************************************************

The Plague God has been cornered in a house. Where many priests and Onmyoji are there.
[cpg]


[OnName num="high_ranking_onmyoji"]
“Shall we begin then?”
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hazuki173"]
[OnName num="hazuki"]
"Yes, I am ready.”
[cpg cn=true]



[SE f="se026"]
;//【ＳＥ】『地響きのような音』

[FACE method="change_3" pos="2/3"]

[WAIT time=1000]

All the doors are closed. It is probably impossible to escape.
[cpg]


But it is also an unknown entity. We do not know what it can do.
[cpg]


Many Onmyoji are chanting the charm to the Plague God which is cornered in the back room.
[cpg]


[OnName num="onmyoji_A"]
“It is resisting at the last minute..... It is trying to escape.”
[cpg cn=true]


[OnName num="onmyoji_B"]
“We have to hold it down...... but I don't know if we can do it."
[cpg cn=true]



[SE f="se026"]
;//【ＳＥ】『地響きのような音』

As a priestess, Hazuki was at the forefront. She is closing her eyes and chanting.
[cpg]


I was part of it, and I was feeling a bewitching power that was tingling on my skin.
[cpg]



[SE f="se027"]
;//【ＳＥ】『花瓶割れる』

The ground was shaking and things were falling over.
[cpg]


Still, the Plague God seems to be weakening little by little.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Hazuki174"]
[OnName num="hazuki"]
"It's getting a lot weaker...... if it keeps going like this..…”
[cpg cn=true]


[VOICE f="Nagisa072"]
[OnName num="nagisa"]
“No.....there's something wrong."
[cpg cn=true]


Nagisa said and then we realized. The Plague God is moving but not resisting.
[cpg]


It does not mean that it will run away. This is ......
[cpg]

[FG f="CHA01_p5_01_a.ui" method="change_5"  pos="2/3" time=800]

[OnName num="zen"]
“Hazuki!"
[cpg cn=true]



[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『奥座敷』（夜）******************************************************


[FACE method="shock_3" pos="2/3"]
[VOICE f="Hazuki175"]
[OnName num="hazuki"]
"What the......!"
[cpg cn=true]

[free time=1000]


[SE f="se021"]
;//【ＳＥ】「転ぶ」

In the front line, Hazuki fell down.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
Hazuki quickly gets up and tries to run before the others understand what's happening.
[cpg]



The Plague God had possessed her. If it was originally a curse transformed, it could easily possess a human being.
[cpg]


With human legs, the Plague God was trying to escape.
[cpg]


[free time=1000]
[SE f="se007"]
;//【ＳＥ】『走る』

[OnName num="onmyoji_A"]
“Stop her! Don't let it escape at any cost!"
[cpg cn=true]


We chased after it. But the Plague God, caught by surprise, had quickly broken the spell of each and every one of them.
[cpg]


[OnName num="onmyoji_B"]
"Whoa!"
[cpg cn=true]


And the Plague God fled with Hazuki's body to the entrance.
[cpg]


If it escapes, there was nothing more we could do. The Plague God would be more vigilant than ever.
[cpg]


There was a possibility that Hazuki might disappear too.
[cpg]


If that happened, there would be no way to recover. Even though I thought so, I could not think of a countermeasure.
[cpg]


But for now, I just followed her, believing that some miracle was going to happen.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



I chase after her, but it seems that Hazuki's physical ability is beyond what it should be.
[cpg]


I can't reach her. No one can reach it.
[cpg]


The situation is the opposite of the other day. If only I could block its path like it did to me.
[cpg]


There's a piece of wood standing right in front of where I'm going. If it falls down just in time, I'll be able to get to it......
[cpg]


No, it's not like me to ask for help from God. I'll just go after it.
[cpg]



[SE f="se028"]
;//【ＳＥ】『地震』

[OnName num="zen"]
“What?”
[cpg cn=true]


At that moment, the ground shook, and that startled the Plague God.
[cpg]


It wasn't the Plague God's doing.
[cpg]


[OnName num="zen"]
“An earthquake.......!"
[cpg cn=true]



[SE f="se020"]
;//【ＳＥ】『木材倒れる』

The wood fell down and blocked its way.
[cpg]


...... Is this a coincidence? How could this happen at such a convenient time?
[cpg]


[OnName num="zen"]
“I'm not going to let you get away ......!"
[cpg cn=true]


Before I could think about that, I remembered what I had to do.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/5" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="4/5" time=800]
The earthquake soon subsided, and we all hunted down the Plague God which was unable to escape.
[cpg]



[FACE method="bow_3" pos="2/5"]
[VOICE f="Takane226"]
[OnName num="takane"]
“Master! Please kill it!”
[cpg cn=true]


At last we had it cornered. If we did not defeat it here, we might not get another chance.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『路地裏』（夜）******************************************************

So we did everything we could. It was really and truly an all-out battle.
[cpg]


Before I knew it, the night was about to turn into morning.......
[cpg]


[BG f="b_11_4.ui" time=1000]
[WAIT time=2000]
[BG f="b_11_1.ui" time=1000]
[WAIT time=2000]

[window target=false]

[BG f="b_10_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『路地裏』（朝）******************************************************



[SE f="se015"]
;//【ＳＥ】「朝のスズメ」

[OnName num="zen"]
"Did we ...... win?"
[cpg cn=true]


By the time it was over, everyone was already exhausted, and there was no discussion about who had accomplished what.
[cpg]


The Plague God had been vanquished. It was just good to see that it had been accomplished.
[cpg]


[OnName num="onmyoji_A"]
“Huh ...... my legs are shaking."
[cpg cn=true]


[OnName num="onmyoji_B"]
“What an opponent. I'm glad we were able to stall it.”
[cpg cn=true]


Midori, Takane, and I were all exhausted. But Hazuki had the most difficult time.
[cpg]


[OnName num="zen"]
“..... Are you all right? Hazuki."
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hazuki176"]
[OnName num="hazuki"]
“Yes, I'm fine……."
[cpg cn=true]


She said so but she was wobbly. I lent her my shoulder and walked her home.
[cpg]


;//ブラックアウト


Everyone was too exhausted to say that the case was closed.
[cpg]


I went back to my place, slept, and woke up in the evening.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[SE f="se029"]
;//【ＳＥ】『からすの鳴き声』

[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Takane227"]
[OnName num="takane"]
“Good morning, master.”
[cpg cn=true]


Takane had woken up before I did.
[cpg]


She woke me up, and I thought, "We really got rid of it.”
[cpg]


[OnName num="zen"]
"Good morning......."
[cpg cn=true]


I answered even though I knew it was not time to say good morning.
[cpg]


I was feeling awfully hungry. I had been on my toes all day yesterday and hadn't had proper breakfast or lunch.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


The dinner that Takane cooked for me was so delicious that it almost brought tears to my eyes.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『神社境内』（夕方）******************************************************

And then, after the extermination of the Plague God was over, we all gathered at the shrine office.
[cpg]



[FADEOUTBGM]
[window target=false]
[BG f="b_03_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ri"]
[WAIT time=100]
;//【ＢＧ】『社務所』（夕方）******************************************************

[OnName num="onmyoji_A"]
“But ...... it was strange at the end. How did you stall it......?"
[cpg cn=true]


[OnName num="onmyoji_B"]
“It's too good to be a coincidence. Maybe they had foreseen it.”
[cpg cn=true]


The measures that the girls took.
[cpg]


If Takane had not chosen the auspicious day, and if Hazuki had not chosen the witching hour…..
[cpg]


If Midori's pocket watch had not been there, and if Sakuya had not broken the watch.
[cpg]


[OnName num="zen"]
“I'm still confused about how such a coincidence could have happened.……"
[cpg cn=true]


[OnName num="onmyoji_A"]
“Maybe it's the irrationality of the supernatural.”
[cpg cn=true]


I know. I'm sure that's true.
[cpg]


There must be something that exists in this world, even though it is irrational.
[cpg]


I must change my way of thinking that everything unexplainable should be eliminated.
[cpg]


This incident seemed to me to be something that I really needed in my life.
[cpg]


[OnName num="onmyoji_B"]
"So, about the distribution of the reward entrusted to you by the superiors……"
[cpg cn=true]


It's about money. It was important. But I couldn't think about that right now.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************

I left the office and went back to my house. There were many things to think about.
[cpg]


There are things in this world that cannot be explained and are not logical.
[cpg]


When I think about it, the love in me is the most unexplainable thing.
[cpg]


I feel that denying it is not worth it…….
[cpg]


It is like denying that I am me. Human beings and creatures are a mass of irrationality.
[cpg]


That's why I sometimes yearn for logic, but I'm sure that's not enough to get around.
[cpg]



[window target=false]
[BG f="b_09_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

[OnName num="zen"]
“I'm home.”
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane228"]
[OnName num="takane"]
"Welcome home, master. How was the meeting?”
[cpg cn=true]


[OnName num="zen"]
"Well, at the end they were talking about rewards and who got credit for what.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane229"]
[OnName num="takane"]
“It's a good thing, isn't it? Now you will be recognized as a Onmyoji, won't you?”
[cpg cn=true]


[OnName num="zen"]
"...... Oh."
[cpg cn=true]


Yes. I feel like that's been the most important thing up until now. But somehow my heart thinks otherwise.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

Then my status as a Onmyoji went up.
[cpg]


I became busy, and the store, which had become like a consultation center for everything, became difficult to continue.
[cpg]


Still, I keep it open since it represents my starting point. Talking about my starting point…… there is one more thing I have to focus on.
[cpg]


It was love.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]



[stflag ChaRoute = 0]


;//条件分岐
;//ヒロイン１を選んでいた場合
[if exp={getFlagValue("ChaRoute") == 1 }]
;//ジャンプ先指定
[jump target="*select01_0"]
[endif]

;//ヒロイン２を選んでいた場合
[if exp={getFlagValue("ChaRoute") == 2 }]
;//ジャンプ先指定
[jump target="*select02_0"]
[endif]

;//ヒロイン３を選んでいた場合
[if exp={getFlagValue("ChaRoute") == 3 }]
;//ジャンプ先指定
[jump target="*select03_0"]
[endif]

;//ヒロイン４を選んでいた場合
[if exp={getFlagValue("ChaRoute") == 4 }]
;//ジャンプ先指定
[jump target="*select04_0"]
[endif]

;//ヒロイン５を選んでいた場合
[if exp={getFlagValue("ChaRoute") == 5 }]
;//ジャンプ先指定
[jump target="*select05_0"]
[endif]



*select01_0
[jump storage="ep014.ks" target="*select01_0"]

*select02_0
[jump storage="ep016.ks" target="*select02_0"]

*select03_0
[jump storage="ep018.ks" target="*select03_0"]

*select04_0
[jump storage="ep020.ks" target="*select04_0"]

*select05_0
[jump storage="ep022.ks" target="*select05_0"]
