
*start

;#################################################
*Ep001|A curse that looms close at hand
;#################################################

[SCENE id=1]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『神社の境内』（昼）******************************************************

The days pass by mercilessly. Having no connection to the curse, it's hard to investigate.
[cpg]


Hazuki, the only one who I can ask for information about the curse, is still acting strangely.
[cpg]


[OnName num="zen"]
“Hey, has something changed lately? Is something going on with you?”
[cpg cn=true]


I go a little further and ask, but she shakes her head.
[cpg]


[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hazuki044"]
[OnName num="hazuki"]
“……Nothing. Everything is peaceful as usual.”
[cpg cn=true]


[OnName num="zen"]
“Really? Your face still seems red.”
[cpg cn=true]


[OnName num="zen"]
“If you are under a curse, I might be able to find a solution.''
[cpg cn=true]


I tell her concerned, but she seems a little angry.
[cpg]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Hazuki045"]
[OnName num="hazuki"]
“I told you it's nothing! Don't pry."
[cpg cn=true]


That means that she is hiding that she is under a curse. However.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Hazuki046"]
[OnName num="hazuki"]
"...... Even now, my heart aches. What am I supposed to do with this feeling?"
[cpg cn=true]


[OnName num="zen"]
What?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Hazuki047"]
[OnName num="hazuki"]
“Why are you always deaf at the most critical moment?”
[cpg cn=true]


[OnName num="zen"]
“I didn’t mean to be like that. You said it in a whisper. Hazuki, say it properly.”
[cpg cn=true]


However, depending on the nature of the curse, it is best not to ask a direct question.
[cpg]


I've never talked about love life with Hazuki, and if it's that kind of curse, it's understandable that she refuses to do so excessively.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Hazuki048"]
[OnName num="hazuki"]
“I'm sorry. Please go home. I can't talk normally anymore......"
[cpg cn=true]


She seemed like she was about to cry.
[cpg]


This was the first time I had seen her like this, and rather than getting excited about it, I wanted to be at her service.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p5_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『神社の境内』（昼）


;//ここから葉月視点　三人称

Hazuki, being left at the shrine……
[cpg]


I regretted it. I just couldn't be honest with Zen.
[cpg]


Hazuki had always been self-conscious about her position. She has been suppressing her feelings.
[cpg]


Through our long relationship, I know that Zen is the only one who can accept my feelings.
[cpg]


I can tell Zen anything. Even harsh words. It is not just about venting repressed feelings.
[cpg]


He is the only person I can be myself with. That is why this relationship cannot be broken.
[cpg]

I can't be known that I have a feeling that I never had before because of...... the curse.
[cpg]


I can't be honest. I want to be honest. But I can't do that now.
[cpg]


;//ここから善視点　一人称

;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大通り』（昼）******************************************************

[OnName num="townspeople_A"]
"I heard that the curse is popular. Do you know about it?”
[cpg cn=true]


[OnName num="townspeople_B"]
"Yes, I know. They say it makes you more infatuated……"
[cpg cn=true]


[OnName num="townspeople_C"]
“Is that so? Then it’s not that big of a deal.”
[cpg cn=true]


[OnName num="townspeople_B"]
“If it weren’t, it wouldn’t be called ‘a curse’”
[cpg cn=true]


[OnName num="townspeople_A"]
“That's right, and only women are affected by the curse.”
[cpg cn=true]


[OnName num="townspeople_B"]
“If men were affected, it would be a different story.”
[cpg cn=true]


[OnName num="zen"]
“……hmm"
[cpg cn=true]


If I can't ask directly, I can get information from eavesdropping.
[cpg]


After that, by listening to people's rumors and sometimes asking them directly, I began to get a general idea of what the curse was.
[cpg]


[OnName num="townspeople_A"]
“probably the reason why Onmyoji doesn't take action is that many Onmyoji is men.”
[cpg cn=true]


[OnName num="townspeople_B"]
“It's possible. The day when all the men in Hinomoto can be popular may be coming soon.”
[cpg cn=true]




[window target=false]
[free time=1000]
[BG f="b_09_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane052"]
[OnName num="takane"]
“I see. I was not expecting that kind of curse.”
[cpg cn=true]


[OnName num="zen"]
“Indeed. I thought it would be something more different.”
[cpg cn=true]


Takane blushed as she listened to me. She is a little inexperienced.
[cpg]


[OnName num="zen"]
“But I am sure of it. Everyone is talking about it.”
[cpg cn=true]


It's more like they become infatuated, rather than constantly being in love with someone.
[cpg]


If Hazuki suffers from that, it's a big deal. She was never interested in romance or anything like that.
[cpg]


[OnName num="zen"]
“I think Hazuki is under a curse. I want to do something about it…….What do you think?”
[cpg cn=true]


[VOICE f="Takane053"]
[OnName num="takane"]
“If it were that kind of a curse, I think it would be hard to confide as a girl. At least I wouldn't be able to.”
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Takane054"]
[OnName num="takane"]
“However if it’s you…… I don't know.”
[cpg cn=true]


[OnName num="zen"]
“What?”
[cpg cn=true]


Somehow people around me have a habit of whispering the important stuff. Or are my ears just weak?
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Takane055"]
[OnName num="takane"]
“It's nothing. I'm just saying, if you want to get the message out, you have to be creative.”
[cpg cn=true]


[OnName num="zen"]
"Yes, I know.”
[cpg cn=true]


But how….… If I asked her in a roundabout way, she would dodge my question as she had done before.
[cpg]


The only way is to ask directly, but even if I did that, I have to think of using the right words.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『神社の境内』（昼）******************************************************

[OnName num="zen"]
“Hazuki. About the curse, have you learned anything new?”
[cpg cn=true]


It was just like last time, but there's no other way.
[cpg]


[VOICE f="Hazuki049"]
[OnName num="hazuki"]
"...... Not really. I heard it's a very serious curse, but I don't know the details.”
[cpg cn=true]


Hazuki is being even more brusque than usual. I know why.
[cpg]


[OnName num="zen"]
“I heard that all the Onmyoji in Hinomoto is gathering for the curse.”
[cpg cn=true]


[OnName num="zen"]
“That means the curse itself is spread over a very wide area. If I can find a solution to this curse, I can make a name for myself.”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Hazuki050"]
[OnName num="hazuki"]
“What are you trying to say? Are you more concerned about your career than me?”
[cpg cn=true]


[OnName num="zen"]
“Well while we’re at it, I'd also like to break your curse.”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Hazuki051"]
[OnName num="hazuki"]
“I am not...... under a curse.”
[cpg cn=true]


[OnName num="zen"]
“I'm also looking into the curse. And I know what it is. Please don't be shy.”
[cpg cn=true]


As I spoke in the spur of the moment, I ended up not being able to choose my words very carefully.
[cpg]


But I couldn't turn my back on her.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki052"]
[OnName num="hazuki"]
“You’re right. I can't stay silent forever. I might have been stubborn."
[cpg cn=true]


Hazuki sighed and told me everything.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Hazuki053"]
[OnName num="hazuki"]
“Have you ever fallen in love Zen?”
[cpg cn=true]


[OnName num="zen"]
“What? Why?”
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Hazuki054"]
[OnName num="hazuki"]
“You told me not to be shy. I don't want to talk about it either.”
[cpg cn=true]


After being told that, I focused on the conversation as serious as possible without embarrassment and with a cool head.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Hazuki055"]
[OnName num="hazuki"]
“I feel as if I don't know my own feeling.”
[cpg cn=true]

I wondered if my face was getting red. I was worried about that.
[cpg]


[OnName num="zen"]
“I can fix it. I will find a way.”
[cpg cn=true]



[FACE method="bow_6" pos="2/3"]
[VOICE f="Hazuki056"]
[OnName num="hazuki"]
“Thank you. I've been in trouble for a long time because I couldn't tell anyone.”
[cpg cn=true]


I think it's because of Hazuki's personality. Probably only Nagisa knows about this story.
[cpg]


[OnName num="zen"]
“I'd like to try a few things. Maybe something like medicine could cure the curse."
[cpg cn=true]


[OnName num="zen"]
“It sounds rough ……but I’d like to try something on you. Will you help me?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

Hazuki nodded. She was no longer in a position to choose.
[cpg]



[FACE method="change_6" pos="2/3"]
[VOICE f="Hazuki057"]
[OnName num="hazuki"]
“It’s fine. If it's okay with it being me, do what you want."
[cpg cn=true]


I was puzzled by her acceptant words.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Hazuki058"]
[OnName num="hazuki"]
"I didn't mean it in a weird way. You can use me as an experiment. Don’t get me wrong."
[cpg cn=true]


Hazuki added. I felt like I was at her mercy.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


So that day, I tried the methods that I could think of right away.
[cpg]


I wondered if useful mantras would work on Yokai, or if medicines that are supposed to ward off evil would work......
[cpg]


Also, id spells and spirit charms would work, I tried them all.
[cpg]


But Hazuki had already tried several of them.
[cpg]


Even if not, other Onmyoji’s would have already tried these simple ideas.
[cpg]


So this is not the way to do it.
[cpg]




[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I went to my room and read through the old research. I wondered if there had ever been such a thing as a curse in the past.
[cpg]


No matter how much I searched, I couldn't find anything. What I can find in these documents is something that someone else could have noticed.
[cpg]


I need to do it in a way that only I can do it.
[cpg]


Yet it has to be something that anyone can do, so it's tough.
[cpg]


[FADEOUTBGM]
[window target=false]
[BG f="b_04_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

[SE f="se015"]
;//【ＳＥ】『鳥の鳴き声』
[WAIT time=1100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Takane056"]
[OnName num="takane"]
“Master......you should get some rest. It's almost morning.”
[cpg cn=true]


[OnName num="zen"]
“Hmm? Oh, yeah........"
[cpg cn=true]


I rub my eyes and close the books on my desk.
[cpg]


I also have to do the usual duties for the Yokai Detective business. Too much for one body.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

This time around, I realized that I care about Hazuki more than I thought I did.
[cpg]


[OnName num="customer"]
“I saw a Yokai. It tricked me and took my wallet.”
[cpg cn=true]


[OnName num="customer"]
“Everything turned into leaves. So it must have been a Yokai of a raccoon dog.”
[cpg cn=true]


[OnName num="customer"]
“Or a fox? The leaves are usually….. Hey, are you listening to me?”
[cpg cn=true]


[OnName num="zen"]
“I'm sorry, I haven't slept in a while…..”
[cpg cn=true]


[OnName num="customer"]
“Oh, for God's sake. This is a real big deal for me.”
[cpg cn=true]


I need to concentrate on my work, but when it has nothing to do with the curse, I get distracted.
[cpg]


Even though it is irrelevant to the curse, there is a part of me that wonders if it really is.
[cpg]


It is something beyond human knowledge that is happening here in Hinomoto.
[cpg]


In that light, this current work is also about getting clues.
[cpg]


[OnName num="zen"]
“Where did you get tricked? Can you show me?”
[cpg cn=true]


[OnName num="customer"]
“Yes, follow me.”
[cpg cn=true]

[SE f="se004"]
;//【ＳＥ】『道を歩く』


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『路地裏』（昼）******************************************************


There are many Yokai that are transformed from animals. This case of the wallet was no exception.
[cpg]


A Yokai transformed from a raven has a penchant for shiny things.
[cpg]


It had evolved and developed intelligence to the point where it can figure that there are shiny things inside wallets.
[cpg]


[OnName num="zen"]
“The nest is likely to be somewhere around here ......."
[cpg cn=true]


[OnName num="customer"]
“How can you tell? How do you know?"
[cpg cn=true]


I answer calmly, without flattery.
[cpg]


[OnName num="zen"]
“Intuition and experience. These Yokai’s have simple habits.”
[cpg cn=true]


In many cases, Yokai that look similar to humans don't do bad things. They know what will happen if they do something bad.
[cpg]


When you think about it, it is conceivable that Yokai were originally different creatures.
[cpg]


I wonder if curses are something of an extension of that....... 
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『路地裏』（昼）******************************************************


[SE f="se011"]
;//【ＳＥ】『小銭の音』

[OnName num="zen"]
“There it is. Is it definitely yours?”
[cpg cn=true]


[OnName num="customer"]
“Yes. Thank you ...... It’s a bit much, so you can keep the rest.”
[cpg cn=true]


[OnName num="zen"]
“Okay. I'll hold on to it and wait for a similar consulatation.”
[cpg cn=true]


[OnName num="customer"]
“You're so honest, you know that? Are you like that way with your girlfriend too?”
[cpg cn=true]


Being told that, I remember Hazuki. Well, she is not a lover.
[cpg]


[OnName num="customer"]
“And yet, I can't believe how quickly we found it."
[cpg cn=true]


It's business as usual. But I had a different discovery, or rather, an idea.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************


The relationship between curses and Yokai. I had an idea about it, so I made a hypothesis and put it together.
[cpg]


It made sense. It fits with the theory I have been advocating.
[cpg]


I could be fundamentally wrong, but now I just had to trust myself.
[cpg]


If I could break Hazuki's curse, I could sell this theory as well.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane057"]
[OnName num="takane"]
“Here you go."
[cpg cn=true]


As I was holding my breath, Takane called out to me.
[cpg]


[OnName num="zen"]
“Thank you....... That is very thoughtful."
[cpg cn=true]


When she offers me a cup of tea, my thoughts calm down a bit. I can't be too aggressive.
[cpg]


I have to do things one by one. So I sipped my tea.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Takane058"]
[OnName num="takane"]
“Look, there are three tea pillars.”
[cpg cn=true]


[OnName num="zen"]
“Tell me before I drink it....... it's in my mouth."
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『神社の境内』（夜）******************************************************

That night. I was supposed to meet up with Hazuki and find a way to break the curse.
[cpg]


[OnName num="zen"]
“She’s not here……”
[cpg cn=true]


Hazuki was not there.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]

After waiting for a while, she arrived quite late, but......
[cpg]

The curse seemed to be worse than yesterday.
[cpg]

She looks shy. She doesn't usually look like that.
[cpg]


Besides, she is the kind of person who never does anything that she would be embarrassed about. She is always so confident, it was hard to look at her.
[cpg]



[FACE method="bow_4" pos="2/3"]
[VOICE f="Hazuki059"]
[OnName num="hazuki"]
“Zen. Don't you......."
[cpg cn=true]


Saying that, Hazuki looks at me. She looks somewhat enraptured.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Hazuki060"]
[OnName num="hazuki"]
“Don’t you feel anything about my state?”
[cpg cn=true]


If she were her usual self, she would never say such a thing. She’s like this because of the curse.
[cpg]


[OnName num="zen"]
......"
[cpg cn=true]


I couldn't answer her easily. It's not that I don't have that feeling.
[cpg]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Hazuki061"]
[OnName num="hazuki"]
“Doesn’t the curse affect men? It's not fair that I'm the only one who has to feel this way."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Hazuki062"]
[OnName num="hazuki"]
“You don't want to hug me or kiss me?”
[cpg cn=true]


[OnName num="zen"]
“I certainly haven't ...... tried those things.”
[cpg cn=true]


I'm going to take the conversation in that direction. I suggest it as a way to break the curse.
[cpg]


[OnName num="zen"]
“Even in the old times, saliva has been used for curses…..It might interfere with something."
[cpg cn=true]


Hazuki doesn't look disgusted. On the contrary.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Hazuki063"]
[OnName num="hazuki"]
“Yes. I don't care what it takes to get rid of this pain. Do whatever you want.”
[cpg cn=true]


Hazuki takes another step closer to me. I can't stop her when she says, "Do whatever you want.”
[cpg]


[OnName num="zen"]
"Let me check....... You don’t mind me doing this?”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Hazuki064"]
[OnName num="hazuki"]
“Don’t make me say it. I won't say this to anyone but you.”
[cpg cn=true]


I have no choice. I think hard.
[cpg]


[FACE method="change_7" pos="2/3"]
I don't know if the curse can be broken, but in this case, what might be a way to break it?
[cpg]



;//■選択肢
[switch]
[case "Kiss her hand."]
	[swap]
	[jump target="*select01_1_1"]
[case "Kiss her cheek"]
	[swap]
	[jump target="*select01_1_2"]
[endswitch]

1. Kiss her hand.
2. Kiss her cheek

;//==============================
;//１、手に口づける

;//選択肢のジャンプ先
*select01_1_1|A curse that looms close at hand

;//移植のためシーンをカットしています

After all, I can't kiss her mouth without a good reason.
[cpg]

I thought so, and took her hand.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Hazuki065"]
[OnName num="hazuki"]
“..... What are you doing?”
[cpg cn=true]


I was silent for a moment and then put my lips to her hand.
[cpg]

She knew what I was doing and didn't say anything further.
[cpg]


;//[FADEOUTBGM]
;//ブラックアウト

[FACE method="shake_4" pos="2/3"]
[VOICE f="Hazuki066"]
[OnName num="hazuki"]
"Ah."
[cpg cn=true]


Then I touched her hand. At that moment, she made a sound as if she was thrilled.
[cpg]



;//選択肢フラグ
[jump target="*select01_1_4"]

;//==============================
;//２、頬に口づける

;//選択肢のジャンプ先
*select01_1_2|A curse that looms close at hand

I kiss her. But not on the lips.
[cpg]

She would be surprised if I did that out of the blue.
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（キスするために近づいているヒロイン）ev_07
;//人物１：ヒロイン１　服装１：私服（はだけ）
;//人物ex：主人公　　　服装ex：私服
;//場所　：神社の境内
;//時間　：夜
;//備考　：オリジナル特典01.jpgのシーンです
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1100]
;//[BGM f="bg_h1"]
[WAIT time=100]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]

Hazuki is so close to me.
[cpg]

That alone is enough to make me feel irresistible, but it's not the end.
[cpg]

;**【ＣＧ】 ev_07_a ***********************
[CG id=0 index=1 time=1]
;***************************************
[WAIT time=1]

And then, Hazuki's face changes as if she has made up her mind.
[cpg]

I put my lips to her cheek.
[cpg]

[VOICE f="Hazuki067"]
[OnName num="hazuki"]
“……"
[cpg cn=true]


She doesn't make a sound. But she looked as if she sensed something.
[cpg]


;//移植のためシーンをカットしています

;//選択肢フラグ
;//[jump target="*select01_1_4"]
;//==============================

;//選択肢のジャンプ先
*select01_1_4|A curse that looms close by.

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="bg_c1"]
[WAIT time=100]

Then, little by little, I talked with Hazuki.
[cpg]


Both of us were at a loss for words. I said I would find a way to break the curse, but I don't remember what I said, I just wanted to break the silence.
[cpg]


I felt awkward and wanted to leave, but I couldn't be so heartless as to leave immediately.
[cpg]



[window target=false]
[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『神社の境内』（夜）******************************************************

We both calmed down, and finally Hazuki said ......
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Hazuki068"]
[OnName num="hazuki"]
“Anyway. See you later.”
[cpg cn=true]


At least she did not say “good bye”.
[cpg]


And she did not say about forgetting today or not.
[cpg]


[OnName num="zen"]
“Yea...... See you."
[cpg cn=true]


I waved and left the shrine. It's not that I have no regrets.
[cpg]


But the regret was only half of it. The rest was a sense of fulfillment that I was able to respond to her suffering.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


Will I be able to act normally in front of Hazuki again tomorrow?
[cpg]


I could do so with Hazuki, but what about Takane? I fell asleep with such thoughts in my mind.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[FG f="CHA04_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[FACE method="shake_1" pos="2/3"]
[VOICE f="Takane059"]
[OnName num="takane"]
“Master, please wake up. We're already open.”
[cpg cn=true]


[OnName num="zen"]
"What...... oh, right……"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Takane060"]
[OnName num="takane"]
“Are you all right? You look like you haven't had enough sleep.”
[cpg cn=true]


[OnName num="zen"]
“I'm fine. It’s nothing”
[cpg cn=true]


[VOICE f="Takane061"]
[OnName num="takane"]
"......?"
[cpg cn=true]


I got up while having such a conversation with her. Takane doesn't seem to have noticed anything yet.
[cpg]


Which was expected. Even if my attitude is different from usual, she can't tell what had happened.
[cpg]


What happened this time is so out of the ordinary.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

It was the same from Takane's point of view, and from mine as well.
[cpg]


What happened yesterday must have been a dream. I can't help but think so.
[cpg]


While I was in such a mood, I received an unexpected visitor.
[cpg]


[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hazuki069"]
[OnName num="hazuki"]
“Good morning. Takane, it's been a long time.”
[cpg cn=true]


The most awkward person to meet right now. Hazuki had arrived.
[cpg]


[OnName num="zen"]
“Good morning……”
[cpg cn=true]


I was so nervous that my voice became quiet. But I don't think Hazuki would say that in front of Takane.
[cpg]

[free time=1000]

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Takane062"]
[OnName num="takane"]
“Welcome! It's been a while, have you lost some weight?”
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Hazuki070"]
[OnName num="hazuki"]
“I've been through a lot.”
[cpg cn=true]


Hazuki and Takane know each other to some extent. They are my childhood friend and Shikigami.
[cpg]


They get along well, but it seemed that she came here for me, not Takane. She looked at me and seemed to want to say something.
[cpg]


[OnName num="zen"]
“Umm….so……… Has anything changed since then?”
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Takane063"]
[OnName num="takane"]
“…….? What’s wrong, master? You've been acting like a marionette.”
[cpg cn=true]


Seeing that I was flustered, Takane was surprised.
[cpg]


But Hazuki, on the other hand, looked serious.
[cpg]


[FACE method="bow_3" pos="4/5"]
[VOICE f="Hazuki071"]
[OnName num="hazuki"]
“Yeah, I need to talk to you about that.”
[cpg cn=true]


[FACE method="change_1" pos="2/5"]
[VOICE f="Takane064"]
[OnName num="takane"]
“Is it about the marionette?"
[cpg cn=true]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Hazuki072"]
[OnName num="hazuki"]
“No, it's not that....... Anyway, could I talk to her alone for a moment.”
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p5_02_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[FACE method="bow_3" pos="2/3"]

I asked Takane to leave the table and Hazuki told me what had happened.
[cpg]

[FACE method="shake_4" pos="2/3"]

The curse that had been plaguing her was now completely gone.
[cpg]

[FACE method="change_1" pos="2/3"]

I was amazed because I was still wondering how I could break the curse.......
[cpg]



[FO pos="4/7" time=1000]
[WAIT time=1000]

;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

[OnName num="zen"]
“Are you sure…….? Could it be because of yesterday?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Hazuki073"]
[OnName num="hazuki"]
“I don't know. If so, it's a great discovery, but either way, I have to thank you.”
[cpg cn=true]


The fact that she was not honest in her words of gratitude was typical of her.
[cpg]


[OnName num="zen"]
“I'm glad to hear that. Thank you for telling me, maybe it will give me a clue.”
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Hazuki074"]
[OnName num="hazuki"]
“I'm sure you wouldn't do the same thing to someone else, would you? It's a matter of your credibility.”
[cpg cn=true]


That's exactly right. I wasn’t going to do it either.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

Hazuki didn't stay too long. I think it's because of the awkwardness of the situation.
[cpg]


If the Hazuki we just saw is the same Hazuki as before the curse, it is natural to think so.
[cpg]


[OnName num="zen"]
“But…… why ......"
[cpg cn=true]


As I was muttering, Takane asked me.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Takane065"]
[OnName num="takane"]
“You seem to talk to yourself a lot. I'll listen if you want to talk.”
[cpg cn=true]


[OnName num="zen"]
“No. I can't tell you.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Takane066"]
[OnName num="takane"]
“Oh really? When you say that, I feel like I want to eavesdrop.”
[cpg cn=true]


[OnName num="zen"]
"I'm sorry, ....... I won't say it again.”
[cpg cn=true]

[FACE method="bows_2" pos="2/3"]
Takane chuckles. It is usual for her to tease me.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_11_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


But still, I still don't know what caused the curse to be lifted.
[cpg]


I did what I did to calm Hazuki down when she was cursed. That was the trigger that made it disappear.
[cpg]


What could be the reason? Could it have something to do with my saliva?
[cpg]


I shook my head. Recalled that it couldn't be, and turned once more to my books.
[cpg]


But no matter how much I looked back in the books, there was no mention of a curse anywhere.
[cpg]


Even if it was something created by a Yokai, it was unprecedented in the past.
[cpg]

[jump storage="ep002.ks" target="*start"]

;////////////////////////////////////////////////////////////////
