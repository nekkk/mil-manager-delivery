
;//==============================
;//３、ヒロイン３を選んでいた場合

;#################################################
*Ep018|A future with Sakuya
;#################################################

[stflag Cha1flg=0]
[stflag Cha2flg=0]
[stflag Cha3flg=0]
[stflag Cha4flg=0]
[stflag Cha5flg=0]

;//選択肢のジャンプ先
*select03_0|A future with Sakuya

[SCENE id=18]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『町外れ』（昼）******************************************************

[SE f="se004"]
;//【ＳＥ】『道歩く』

I walked toward Sakuya's place. This road was familiar to me.
[cpg]


I had just reached the street in front of her house. Sakuya called out to me.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakuya112"]
[OnName num="sakuya"]
“Zen? What's wrong?”
[cpg cn=true]


[OnName num="zen"]
“I can smell the ...... liquor."
[cpg cn=true]


It’s not something I wanted to say at first but I can feel that she has been drinking too much.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sakuya113"]
[OnName num="sakuya"]
“Yea. It's sunny today."
[cpg cn=true]


I don't know what the sunny weather has to do with it, but she seems to be drinking again today.
[cpg]


I thought it would be bad for her health, but I couldn't give her any more cautions.
[cpg]


[OnName num="zen"]
"You should moderate the amount.”
[cpg cn=true]


If it weren't for her personality, if she hadn't broken the clock, I wouldn't have been able to exterminate the Plague God. So I couldn't deny it strongly.
[cpg]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakuya114"]
[OnName num="sakuya"]
“Come on in. Your formal manner of speaking is not appropriate for the relationship between us, is it?”
[cpg cn=true]


...... Indeed, Sakuya has always spoken in an informal manner. Ever since we met.
[cpg]


[OnName num="zen"]
“Indeed you’re right.”
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Sakuya115"]
[OnName num="sakuya"]
“You see, you’re still being formal.”
[cpg cn=true]


I was getting uncomfortable to be told that much. I scratched my head and replied.
[cpg]


[OnName num="zen"]
“"I understand. I'll come in to your home.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
Sakuya nodded in satisfaction. She looked as if our distance had shortened a little again.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『汎用民家』（昼）******************************************************

Neither of us was going to confess. There was no need for such words anymore.
[cpg]


But we had already formed a bond that could be called a romantic relationship.
[cpg]



[FACE method="shake_1" pos="2/3"]
[VOICE f="Sakuya116"]
[OnName num="sakuya"]
“I wonder since when it's been like this. My feelings were the same from the beginning.”
[cpg cn=true]


[OnName num="zen"]
“I was hoping to live a life as innocent as yours.”
[cpg cn=true]


Sakuya was taken aback by my words. I don't think I said anything inappropriate.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sakuya117"]
[OnName num="sakuya"]
“Innocence? What is that?”
[cpg cn=true]


I thought she didn't seem to understand the meaning of the word itself.
[cpg]


[OnName num="zen"]
“It’s ike purity.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sakuya118"]
[OnName num="sakuya"]
“Really? But you can't be that while you use words like that.”
[cpg cn=true]


......That's true too. Besides, if I live my life the way I want to live it too, I'm not sure I'll ever be able to get out of it.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sakuya119"]
[OnName num="sakuya"]
;//「それより、疫神退治の時に居た、翠って子。ウチらの関係に気づいてたよ」
「それより、翠って子。ウチらの関係に気づいてたよ」
[cpg cn=true]


[OnName num="zen"]
“Midori ……? Oh…. It didn't look that way to me.”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sakuya120"]
[OnName num="sakuya"]
“You wouldn't understand, but I do.”
[cpg cn=true]


We were having a peaceful time, talking like that.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『汎用民家』（夕方）******************************************************
;//移植のためシーンをカットしています



The time I spent with her was the loveliest of all. I wish it would go on forever.
[cpg]


But time is finite. You get hungry and you have to work as well.
[cpg]


Sakuya is not the type of person who is reluctant to say goodbye, but I was.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakuya121"]
[OnName num="sakuya"]
“Anyways. See you next time.”
[cpg cn=true]


[OnName num="zen"]
“Yea.”
[cpg cn=true]


I always didn't know how to say goodbye to her.
[cpg]


She smiled and waved at me. I smiled back, thinking that I would see her again soon.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

Then another day. This time it was when Sakuya was at my store.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[WAIT time=1100]

[OnName num="zen"]
“What do you want again today?”
[cpg cn=true]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Sakuya122"]
[OnName num="sakuya"]
“You're a detective, aren't you? Can you to find out about my birth.”
[cpg cn=true]


The reason was following.
[cpg]


If my theory was correct, Sakuya was originally human and had parents.
[cpg]


[FACE method="change_4" pos="4/5"]
[VOICE f="Sakuya123"]
[OnName num="sakuya"]
“I was wondering if there was any way I could find them and meet them.”
[cpg cn=true]


I think about it. This was my beloved, so I couldn't answer in a careless way.
[cpg]


[OnName num="zen"]
“If you have lost your memory due to the effects of becoming a Yokai, and if we can get rid of the Yokai part then you might be able to ......”
[cpg cn=true]


I answered, though I could not be sure of this yet.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Sakuya124"]
[OnName num="sakuya"]
“It's a crazy story. I've never heard of such a thing.”
[cpg cn=true]


[OnName num="zen"]
“Look, I don't know either. It's something that is said to be impossible.……”
[cpg cn=true]


I say and Sakuya interrupts me.
[cpg]


[FACE method="change_2" pos="4/5"]
[VOICE f="Sakuya125"]
[OnName num="sakuya"]
“But you might be able to make it possible.”
[cpg cn=true]


Sakuya laughed. Seeing this Takane asks.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Takane237"]
[OnName num="takane"]
“...... since when did you start calling her Sakuya?”,
[cpg cn=true]


Takane asked.
[cpg]


I had wondered how I would explain this to Takane.
[cpg]


Even if she had somehow guessed it, I would have to tell her properly at some point.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

She was not aware of this, or perhaps she was, but Sakuya said she was going to stay in my room.
[cpg]


I told her to consider Takane’s feelings, but Takane on the contrary, was very considerate.
[cpg]


[OnName num="zen"]
“...... Look, Takane is also an important person to me."
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Sakuya126"]
[OnName num="sakuya"]
“I’m sorry. I really am.”
[cpg cn=true]


I wondered if it was true, but I still ......
[cpg]



;//ブラックアウト
;//========================================
;//●ＣＧエロ（脇射。こすりつけながら自分でしごいている主人公。ヒロインは寝ていて片手上げている）ev_03
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：正装
;//場所　：主人公の部屋
;//時間　：夜
;//備考　：オリジナル特典12.jpgのシーンです
;//========================================
;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]
;//移植のためシーンをカットしています

The two of us decided to cuddle up and go to bed.
[cpg]

[VOICE f="Sakuya127"]
[OnName num="sakuya"]
“I feel at home with you.”
[cpg cn=true]


Seeing Sakuya say that, makes my heart pound.
[cpg]

But ...... I can't be forceful right now.
[cpg]

;**【ＣＧ】 ev_03_a ***********************
[CG id=17 index=1 time=1]
;***************************************
[WAIT time=1]

Sakuya looked at me being lost and laughed a little.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I exchange sweet words with Sakuya. I already know the words she want to hear.
[cpg]


I want to fulfill whatever she wishes. If possible, I would also like to find her parents.
[cpg]


I never wondered if I could do them or not.
[cpg]


I could do anything with Sakuya. I felt that way. ......
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sakuya128"]
[OnName num="sakuya"]
“What's wrong, you're smiling.”
[cpg cn=true]


[OnName num="zen"]
“I'm just happy."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sakuya129"]
[OnName num="sakuya"]
“I see. If you're happy, I'm happy.”
[cpg cn=true]


I guess the feeling was mutual. I guess my wish is her wish.
[cpg]



;//ブラックアウト
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=1]
[WAIT time=1000]

I don't want it to be just a wish. Even though I thought so, the fatigue came to me.
[cpg]


When I woke up, Sakuya would still be next to me. I went to sleep imagining such a future.
[cpg]




[if exp={getFlagValue("Cha3flg") == 2 }]
;//ジャンプ先指定
;//[jump target="*select03_1"]
[jump storage="ep019.ks" target="*select03_1"]
[endif]
;//END

[jump storage="epend.ks" target="*start"]

