

;//==============================
;//２、翠

;#################################################
*Ep009|Midori adores me
;#################################################

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ba"]
[WAIT time=100]

;//選択肢のジャンプ先
*select00_2|Midori adores me

[SCENE id=9]

;//ルートフラグ
[stflag ChaRoute = 2]

I immediately thought of Midori. If I go back home, Takane will definitely be there, but she may not be forceful enough.
[cpg]


On the other hand, Midori is an Onmyoji, so she will definitely add strength. Even if she can't exterminate them, she might be able to get rid of them.
[cpg]


Of course, I know where she is. In the beginning, we had to fight over customers because she was near our house.
[cpg]


I never thought she would be useful in this way. With this thought in mind, I headed back home.
[cpg]

[SE f="se007"]
;//【ＳＥ】『走る』

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************



Running. Even if I just ran, my path would be blocked. It would get blocked in an unnatural way.
[cpg]


The road should be familiar, but I couldn't go straight ahead because of things falling down and of the fallen roof tiles.
[cpg]


I was entering an unfamiliar path, and I didn't even know which way I was headed now.
[cpg]


I know that something is close by. If I get caught, it's going to be trouble.
[cpg]



[SE f="se007"]
;//【ＳＥ】『走る』

I was getting closer to the house where Midori lives, instead of my store.
[cpg]


But if I can't open the door to her house, I'll be trapped there.
[cpg]


I already know that whoever is chasing me can get ahead of me and block my way.
[cpg]


So it is not at all surprising that something like this would happen.
[cpg]


So what should I do? It's obvious.
[cpg]


[OnName num="zen"]
“Midori!”
[cpg cn=true]


I don't know if this voice can be heard or not. If not, then this will be the end of everything.
[cpg]


People on the street were looking this way, but no one could go against it.
[cpg]


I was running and arrived at the very front of Midori's house.
[cpg]


I heard a door trying to open from the inside, but it wouldn't open. This couldn’t be happening.
[cpg]


I turned my back to the door. I still couldn't see it clearly.
[cpg]


I am not one to ask for help from God at times like this, but I was praying for something.
[cpg]


[OnName num="zen"]
“I knew it...... it won't come near me......"
[cpg cn=true]


It was probably because Midori had put a talisman on the house. She deals with curses and Yokai, too, and she must have taken precautions against the dangers of such things.
[cpg]


And this is her house, not a store like mine.
[cpg]



[OnName num="zen"]
“Apparently, I've got one over on it.”
[cpg cn=true]

[FADEOUTBGM]

Somehow, it realized that it couldn't get any closer and moved away.
[cpg]


I'm not stupid enough to chase after it. If I leave this ward, even my life might be in danger.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************

Later, Midori seemed to have fixed the door and came out.
[cpg]


The two of us talked. We talked about what had just happened and our imaginations about what it was.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Midori115"]
[OnName num="midori"]
“...... What was it? You saw its figure, right?”
[cpg cn=true]


[OnName num="zen"]
“Yes. The door didn't open, and it was probably because of that.”
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Midori116"]
[OnName num="midori"]
“Oh no, you don't mean that it's something completely different from a curse? Shouldn't it only affect the human body?”
[cpg cn=true]


[OnName num="zen"]
“I don't know. It's strange that you can't see them, if they were a Yokai.”
[cpg cn=true]


In any case, we have to talk about it. I just can't leave it alone.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Midori117"]
[OnName num="midori"]
“It's not like the curses we've seen in the past. It's not so much that it haunts people and does things, but that it has the power to move things……."
[cpg cn=true]


[OnName num="zen"]
”Yes……”
[cpg cn=true]


Some Yokai are difficult to recognize. Or perhaps it would be more correct to say that they are made that way by jutsu.
[cpg]


Some are originally animals or humans, but are made to look that way by a power beyond human knowledge.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Midori118"]
[OnName num="midori"]
“Is that a Yokai, too?”
[cpg cn=true]


But even so, there was something definite in my mind.
[cpg]


[OnName num="zen"]
“I don't think so. It is too indiscriminate. Whether people attack people or animals attack people, there must be a reason.”
[cpg cn=true]


It seems indiscriminate that Yokai, which are transformed from animals, attack people. But it is not true.
[cpg]


There was no information that the bodies of the people attacked by them were eaten. If that is the case, predation is not the goal.
[cpg]



;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA02_p5_01_a.ui" method="change_3"  pos="2/3" time=1]

In the end, no conclusion was reached in our discussions.
[cpg]


It was a frustrating situation where we had to take measures without knowing.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大通り』（朝）******************************************************

Apart from that, there was also a curse that was very similar to the one that had existed until now.
[cpg]


It's nice that more customers are coming, but it's better to be free of the problem.
[cpg]


Even though we know that we need the blood of an Onmyoji, or someone who is strong against curses, we still don't know to what extent it is effective.
[cpg]


That's why there are shady people and scammers now apparently.
[cpg]


I'm glad that the information that is publicly spreading is that blood is effective. Even when the symptoms don't improve, the damage is minimal.
[cpg]


The hypothesis that was there in the beginning was just a rumor. I am glad that I kept it as a rumor.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

There are a number of customers. Some of them wanted me to break the curse, but I can't do it with blood.
[cpg]


I can only do it with saliva. It would be problematic to make it public.
[cpg]


So I try to deal with them individually as much as possible.
[cpg]


[OnName num="customer"]
“My wife seems to have been cursed, and ...... an Onmyoji would be able to exorcise it, right?”
[cpg cn=true]


[OnName num="zen"]
“Yeah, yeah ...... but ......."
[cpg cn=true]


It is often women who are cursed. There is no problem there.
[cpg]


But the fact that married women are under the curse is a problem.
[cpg]


Should I tell the truth, or should I just flatly refuse?
[cpg]


[OnName num="zen"]
“I can't exorcise it with blood. Instead, ......"
[cpg cn=true]


Takane is hesitant. Yet I have no choice but to tell him.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[free time=1000]
[BG f="b_11_3.ui" time=1000]
[WAIT time=2000]

[OnName num="customer"]
“I'll never come back! You son of a…….”
[cpg cn=true]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

[FG f="CHA04_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Takane163"]
[OnName num="takane"]
“..... Master, please don't be discouraged.”
[cpg cn=true]


[OnName num="zen"]
“I'm fine. At least he didn't hit me.”
[cpg cn=true]


In the middle of the conversation.
[cpg]


[OnName num="zen"]
“What? Midori?"
[cpg cn=true]


[SE f="se004"]
;//【ＳＥ】「道を歩く」


Midori staggered over to me. Something was not right.
[cpg]


[free time=1000]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="4/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/5" time=800]
[VOICE f="Midori119"]
[OnName num="midori"]
......Zen.
[cpg cn=true]


[OnName num="zen"]
“What's wrong? You look pale.”
[cpg cn=true]



[VOICE f="Midori120"]
[OnName num="midori"]
“It seems I've fallen victim to the ...... curse again.”
[cpg cn=true]


She looked quite desperate, but I couldn't tell what was going on just by looking at her.
[cpg]


[FACE method="change_7" pos="2/5"]
[VOICE f="Takane164"]
[OnName num="takane"]
“What are the symptoms? Are they like before……?”
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Midori121"]
[OnName num="midori"]
“No... I can't stand the slightest pain anymore.”
[cpg cn=true]


[OnName num="zen"]
“You mean you're sensitive to pain?"
[cpg cn=true]

[FACE method="bow_7" pos="4/5"]
Midori nodded. I don't know how sensitive she is, but it must be extreme.
[cpg]


[FACE method="change_4" pos="4/5"]
[VOICE f="Midori122"]
[OnName num="midori"]
“I can't live properly with this. So, please......"
[cpg cn=true]


I could imagine the words that would follow. But that was strange to me.
[cpg]


[OnName num="zen"]
“But, are you okay with asking me? I'm sure other Onmyoji’s can exorcise it with blood.”
[cpg cn=true]


[FACE method="change_3" pos="2/5"]
[VOICE f="Takane165"]
[OnName num="takane"]
“Master. That's a bit ......"
[cpg cn=true]


After I said it, I realized. She knows that and that’s why she's here.
[cpg]


Midori is blushing. On top of that, she said this.
[cpg]


[FACE method="shake_4" pos="4/5"]
[VOICE f="Midori123"]
[OnName num="midori"]
It's so painful to touch my body by myself. Please understand.
[cpg cn=true]


I guess she meant what she said. It would be a problem when she would take a bath.
[cpg]


[OnName num="zen"]
“I understand."
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p5_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[BGM f="bg_c1"]

Midori and I were on our way to her house.
[cpg]


I could have stayed in my room, but I was confused and wanted to consider Takane’s feelings.
[cpg]


I was more aware of Midori than I had expected…….
[cpg]


;//選択肢のジャンプ先
*select02_2_0|Midori adoring me.

;//■選択肢
[switch]
[case "Kiss her lips"]
	[swap]
	[jump target="*select02_2_1"]
[case "1. Kiss her fingers"]
	[swap]
	[jump target="*select02_2_2"]
[endswitch]

2. Kiss her lips
Kiss her lips.

;//==============================
;//１、指に口づけをする

;//選択肢のジャンプ先
*select02_2_1|Midori adoring me.

[OnName num="zen"]
“You said it hurts when you touch something. That means it might be caused by your fingers."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Midori124"]
[OnName num="midori"]
“Huh? But it doesn't feel like my fingers hurt.”
[cpg cn=true]


[OnName num="zen"]
“A curse is an unidentified thing.”
[cpg cn=true]


[OnName num="zen"]
“It may be that your finger is the cause of the curse, and yet the place where you are touched hurts.”
[cpg cn=true]



;//移植のためシーンをカットしています
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[window target=true]
;//ブラックアウト

I said that and decided to kiss her fingers.
[cpg]

I was used to this. She wasn't that nervous either.
[cpg]

[OnName num="zen"]
“How do you like it? Touch it yourself.”
[cpg cn=true]

;//[window target=false]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_04_4.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//
;//[BGM f="bg_c1"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[FACE method="bow_4" pos="2/3"]
[VOICE f="Midori125"]
[OnName num="midori"]
Yes……
[cpg cn=true]


She touched her skin, but it didn't seem to hurt.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Midori126"]
[OnName num="midori"]
“I think it's healed. Good ......"
[cpg cn=true]


Seeing her smile made me happy too.
[cpg]


;//分岐ループから抜ける

[jump target="*select02_2_4"]

;//==============================
;//２、唇に口づけをする

;//選択肢のジャンプ先
*select02_2_2|Midori adores me


After thinking about it, I came to a conclusion.
[cpg]

;//========================================
;//●ＣＧ（仰向けのヒロイン。キスを待っている）ev_31
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
;//[BGM f="bg_h1"]
[WAIT time=1000]
;**【ＣＧ】 ev_32_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]

I said I would kiss her on the mouth and she waited for it.
[cpg]

She had an indescribable expression on her face. I couldn't look at her face like that.
[cpg]

Then I brought my lips to hers. She swallowed.
[cpg]

[VOICE f="Midori127"]
[OnName num="midori"]
“Please. Please come closer.”
[cpg cn=true]


She ended up having to say that. I couldn't keep her waiting.
[cpg]

;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I kissed her on the mouth and then checked to see if the curse had been lifted.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Midori128"]
[OnName num="midori"]
“No,..... it's not broken yet.”
[cpg cn=true]


There was no time to dwell on the aftermath. I thought about it again.
[cpg]

[stflag Cha2flg = -1]

[switch]
[case "Kiss her fingers"]
	[swap]
	[jump target="*select02_2_1"]
[endswitch]


;//この選択肢を除いて、もう一度同じ分岐へ戻る
[jump target="*select02_2_0"]
;//==============================

;//選択肢のジャンプ先
*select02_2_4|Midori adores me

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

And when I returned to the store, Takane greeted me.
[cpg]


[FACE method="change_7" pos="2/5"]
[VOICE f="Takane166"]
[OnName num="takane"]
“How did it go? Did it heal properly?”
[cpg cn=true]


[OnName num="zen"]
“Yes, I'm cured.”
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Midori129"]
[OnName num="midori"]
"......"
[cpg cn=true]


Midori seemed to be unable to look at Takane.
[cpg]


I could understand that. I'm sure she also thinks that Takane is jealous of her.
[cpg]


[OnName num="zen"]
“I'll see you off, Midori.”
[cpg cn=true]


I said this in consideration of her. Midori seemed to relax a little.
[cpg]


[FACE method="bow_6" pos="4/5"]
[VOICE f="Midori130"]
[OnName num="midori"]
“Thank you very much…….”
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大通り』（夜）******************************************************

Midori and I are on the road at night. There is an awkward atmosphere, but we both remain silent.
[cpg]


Even though it is a main street, it is at night, so there are only a few pedestrians.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Midori131"]
[OnName num="midori"]
...... Um, Zen. I have something a little important to tell you.
[cpg cn=true]


The one who broke the silence was Midori. What a strange thing to say, "a little important”.
[cpg]


[OnName num="zen"]
What is it?”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Midori132"]
[OnName num="midori"]
“Thank you for breaking my curse this time.”
[cpg cn=true]


Midori chooses her words. I guess this is not important.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Midori133"]
[OnName num="midori"]
“I know that you found out all of this. If it weren't for you, I don't know what I would be doing now.”
[cpg cn=true]


[OnName num="zen"]
“Who are you to say that. It is you who has always been a great help. “
[cpg cn=true]


The conversation stops there again.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Midori134"]
[OnName num="midori"]
So...... um.........
[cpg cn=true]


[OnName num="zen"]
“What do you mean by 'important talk'?"
[cpg cn=true]


[VOICE f="Midori135"]
[OnName num="midori"]
“I think that without someone as logical as you, there would be no development of academia. So."
[cpg cn=true]


She repeats, "So, so, so," and her voice gets quiet.
[cpg]


It seemed as if she was trying to hold herself back somehow.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Midori136"]
[OnName num="midori"]
“I think you are a great person. I respect you Zen. So I don't want to break our relationship. I hope we can continue to be friends."
[cpg cn=true]


......It didn't seem that important after all. I guess the main topic is something else.
[cpg]


[OnName num="zen"]
“Thank you very much. I'm glad."
[cpg cn=true]


I'm aware of that. I'm still trying to get her to say it.
[cpg]


There's only one reason why the words "I don't want to ruin the relationship" would come out.
[cpg]


But I didn't have the courage to say it.
[cpg]



;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=1]

In the end, neither of us could say anything. But in this case words were not necessary.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

It was not for either one of us to confess. But Midori came to our store more often.
[cpg]


I think we are in a healthy relationship. No, we are not even dating yet.
[cpg]


I wondered which of us would be the first to lose control of our feelings. Somehow I thought it would be Midori first.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Takane167"]
[OnName num="takane"]
“It's lively when you are here Midori. Besides, we can rely on you.”
[cpg cn=true]



[FACE method="shock_5" pos="4/5"]
[VOICE f="Midori137"]
[OnName num="midori"]
“Oh, no. I am not a great Onmyoji.”
[cpg cn=true]


Midori was being modest, but I was grateful that she was spending her valuable time with us.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

It only takes one person to answer customers. When I'm away, Takane is there.
[cpg]


But it wasn't about that. I was happy to spend time with the one I loved.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Takane168"]
[OnName num="takane"]
“Let’s eat lunch. How about you, Midori?”
[cpg cn=true]


Takane seemed to support us as she cooked a meal for the three of us.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


[FACE method="shake_5" pos="4/5"]
[VOICE f="Midori138"]
[OnName num="midori"]
“Takane you're a good cook….. I need to learn how to cook too.”
[cpg cn=true]


Come to think of it, Midori couldn't cook at the celebration party sometime ago.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Takane169"]
[OnName num="takane"]
“It's easy. I can teach you."
[cpg cn=true]


I'm glad these two are getting to know each other.
[cpg]


I can envision a happy future. Now if we can just do something about that something that attacked us.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="4/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夜）******************************************************

It's a simple story, and the time passes slowly. And yet it is short in terms of experience.
[cpg]


The first to yawn was Takane. Midori and I were engrossed in each other's conversation.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Takane170"]
[OnName num="takane"]
“Huh...... Oh, I'm sorry.”
[cpg cn=true]


[OnName num="zen"]
“Well, it's already late.”
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Takane171"]
[OnName num="takane"]
“You’re right. Midori, would you like to stay the night?”
[cpg cn=true]

[FACE method="shock_5" pos="4/5"]
Midori made a surprised face and shook her head.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Midori139"]
[OnName num="midori"]
“I’d feel bad to be a burden.”
[cpg cn=true]


[FACE method="shake_2" pos="2/5"]
[VOICE f="Takane172"]
[OnName num="takane"]
“You don't have to worry about it. I'm sure you two are in a relationship.”
[cpg cn=true]


We both raised our voices.
[cpg]


Takane usually makes fun of me, but it doesn't seem like that's the intention.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Takane173"]
[OnName num="takane"]
“I'm not saying I won’t be sad, but I'm not going to tear two lovers apart.”
[cpg cn=true]


She looked a little sad, but she was smiling.
[cpg]


[FACE method="change_7" pos="4/5"]
[VOICE f="Midori140"]
[OnName num="midori"]
“……”
[cpg cn=true]


Midori looked at me, unable to say anything. I nodded back at her.
[cpg]


[OnName num="zen"]
“Takane is okay with it ...... please stay the night.”
[cpg cn=true]


I guess she wasn't prepared for this. She was blushing.
[cpg]


Well, I might be similar to her.......
[cpg]


;//ブラックアウト


I didn't think anyone other than me and Midori would help develop this love.
[cpg]


Takane's personality has saved my life many times, but I never thought she would support me again here.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[SE f="se015"]
;//【ＳＥ】『鳥の鳴き声』

Me and Midori fell asleep in the same room. And then a bird's chirping woke us up.
[cpg]


[FG f="CHA02_p5_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Midori141"]
[OnName num="midori"]
...... Morning, already .......
[cpg cn=true]


[OnName num="zen"]
“Let’s get up, Midori.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Midori142"]
[OnName num="midori"]
“Let's stay together just a little longer."
[cpg cn=true]


She seemed to be trying to prolong this feeling.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

This day Midori went back to her house but she might live here someday.
[cpg]


I was thinking of such a future and lingered on that thought.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Takane174"]
[OnName num="takane"]
“You must be very happy. You are smiling again.”
[cpg cn=true]


[OnName num="zen"]
“Oh.....? Right.”
[cpg cn=true]


From Takane's point of view, it must be complicated. We can't confirm with each other that there were no romantic feelings at all.
[cpg]


Not necessarily because of that, but I thought I had to be properly happy.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p5_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大通り』（昼）******************************************************

Then, one holiday afternoon, Midori invited me.
[cpg]



[FACE method="shake_7" pos="2/3"]
[VOICE f="Midori143"]
[OnName num="midori"]
“I've never done anything like this before and I'm ...... nervous.”
[cpg cn=true]


We met on the main street in town and went shopping.
[cpg]


Rather than wanting to buy something we just wanted to spend time together.
[cpg]


[OnName num="zen"]
“Shall we go?”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
I still get a stiff feeling from Midori. But it seems like she is trying to smile as much as she can.
[cpg]



[SE f="se004"]
;//【ＳＥ】『道を歩く』

And even though we were shopping, it was a bit awkward because she seemed to be concerned about the way I was looking at her.
[cpg]


I guess she is more concerned about others than herself.
[cpg]


Or should I say that she is conscious of herself seen by others?
[cpg]


Her personality is different from Hazuki and Takane. But I found that endearing.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『大通り』（夕方）******************************************************

After shopping, the sun was about to set.
[cpg]


[FG f="CHA02_p5_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Midori144"]
[OnName num="midori"]
“Um...... Zen. Will you come to my house?
[cpg cn=true]


It took a lot of courage for Midori to say that. I nodded.
[cpg]


[OnName num="zen"]
“Okay. I've told Takane that I might be staying out longer.”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
Her face lit up. I was happy just to see that.
[cpg]


There was something about Midori's smile that made me smile too.
[cpg]


[SE f="se004"]
;//【ＳＥ】『道を歩く』

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p5_02_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


We headed for her house. I wondered if she had planned to invite me over since her place was very tidy.
[cpg]


Midori cooked dinner for me, and it was probably the first time I had ever had a home-cooked meal from her.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Midori145"]
[OnName num="midori"]
“Oh, um. What do you think?”
[cpg cn=true]


Midori asked while I was still eating.
[cpg]


[OnName num="zen"]
“It's delicious.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Midori146"]
[OnName num="midori"]
“I’m glad. I’ve been practicing for a long time.”
[cpg cn=true]


If you look closely, you can see a small scratch on her fingertip.
[cpg]


She is really cute. I was getting overwhelmed with strong feelings.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Midori147"]
[OnName num="midori"]
“I would like you to stay with me if it’s only with you.”
[cpg cn=true]


I was sure that this time it would be just the two of us. Midori was hoping for that to happen.
[cpg]


;//移植のためシーンをカットしています


[OnName num="zen"]
“Midori, you have changed a lot.”
[cpg cn=true]


I looked at her and thought so.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Midori148"]
[OnName num="midori"]
Is that so ......?
[cpg cn=true]


[OnName num="zen"]
“Yes. I think you have become more expressive.”
[cpg cn=true]


I also think that in the beginning, she was probably hostile toward me, but there was more to it than that.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Midori149"]
[OnName num="midori"]
”You might be right. I've always been told I looked like a doll, and I thought I was like that too.”
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Midori150"]
[OnName num="midori"]
“But ...... I think I'm finally becoming more human. I never thought I had this kind of feeling inside of me.”
[cpg cn=true]


She said and showed a smile that I had never seen before.
[cpg]


It was as if the tension of the day had finally been released. As if the intensity that had been in her life was unwinding.
[cpg]


I couldn't resist it any longer and hugged her.
[cpg]


Midori doesn't mind either. We are fulfilling each other.
[cpg]


Becoming more human ...... I feel like that too. I've been in love with Midori for the first time since I met her.
[cpg]


I've never been in love like this before in my life.
[cpg]

;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（朝）******************************************************

The next morning after that happened.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Sakuya058"]
[OnName num="sakuya"]
“I heard from Takane. You are going out with her?”
[cpg cn=true]


[OnName num="zen"]
“Yeah……"
[cpg cn=true]


That day, Sakuya had come to the store.
[cpg]


[FACE method="change_7" pos="4/5"]
[VOICE f="Sakuya059"]
[OnName num="sakuya"]
“Who is this Midori? I might have met her but I don’t really know her.”
[cpg cn=true]


That may be so. They had only met breifly at a celebration party some time ago.
[cpg]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Sakuya060"]
[OnName num="sakuya"]
“I don't need to ask you, do I? All I have to do is listen to your idle talk.”
[cpg cn=true]


[OnName num="zen"]
“Well, I don’t know….”
[cpg cn=true]

[FACE method="bows_2" pos="2/5"]
Takane chuckled at my dismay.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Sakuya061"]
[OnName num="sakuya"]
“I'm happy for you anyway. I’ll have to bring you something to celebrate.”
[cpg cn=true]


[OnName num="zen"]
“Thank you..... for being so congratulatory. I'm sure Midori will be delighted."
[cpg cn=true]


;//ブラックアウト


And that kind of talk didn't stop there. There is another person who is close to me.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="4/5" time=800]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（夕方）******************************************************

On another day, Hazuki came over and said something similar.
[cpg]



[FACE method="change_1" pos="4/5"]
[VOICE f="Hazuki159"]
[OnName num="hazuki"]
“I heard you decided to go out with Midori."
[cpg cn=true]


This is a bit different from Sakuya. I've been childhood friends with Hazuki for a long time, and I still am in contact with her.
[cpg]


[OnName num="zen"]
“……Yes."
[cpg cn=true]


It is no longer strange to hear this from anyone. Perhaps it's the culture of the country of Hinomoto that gossip spreads fast.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Hazuki160"]
[OnName num="hazuki"]
“Congratulations. I can't believe Zen has a girlfriend.”
[cpg cn=true]


She is congratulating her verbally. She seems to be smiling.
[cpg]


But her face was somewhat sad.
[cpg]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Hazuki161"]
[OnName num="hazuki"]
“I am happy that your love has blossomed. I guess this feeling is something I have to share with someone now.”
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
Hazuki looks at Takane and says so in a meaningful way.
[cpg]


Hazuki was fine from the beginning, but I wonder if Takane has something on her mind.
[cpg]


But that doesn't change the fact that I love Midori.
[cpg]


It would be strange to thank her here, but I can't say anything thought-provoking either.
[cpg]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大通り』（夜）******************************************************

I felt again that my life is not mine alone.
[cpg]


Recently, I have been heading to Midori's place more often after closing the store.
[cpg]


[OnName num="zen"]
Huh....?
[cpg cn=true]


Midori's house can be seen in the distance. Midori and someone else are talking in front of it.
[cpg]


As I got closer, I recognized the figure.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Sakuya062"]
[OnName num="sakuya"]
“I'm going to give you this sake to celebrate. Or maybe you don't drink?”
[cpg cn=true]


[FACE method="shock_4" pos="2/5"]
[VOICE f="Midori151"]
[OnName num="midori"]
“Oh, I….."
[cpg cn=true]


It's Sakuya. I guess she found out where she lived on her own.
[cpg]


[OnName num="zen"]
“Why don't you have it?”
[cpg cn=true]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Midori152"]
[OnName num="midori"]
“But I don't drink alcohol...... Do you drink Zen?”
[cpg cn=true]


Midori certainly doesn't seem like she drinks much alcohol, and it seems like it's true.
[cpg]


[OnName num="zen"]
“I'm not very strong, but I can drink.”
[cpg cn=true]


[FACE method="change_2" pos="4/5"]
[VOICE f="Sakuya063"]
[OnName num="sakuya"]
“Then it's decided. Please take this. I'd like to have a drink with you two, but I’d be intruding.”
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Midori153"]
[OnName num="midori"]
“No, no, no, no. I'm not going to let you leave right away after receiving such an expensive gift.”
[cpg cn=true]


Sakuya seemed to be genuinely congratulating us as she was smiling.
[cpg]


;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[WAIT time=2000]

And for a while, the three of us talked about various things.
[cpg]

[FACE method="bows_2" pos="4/5"]

It seems that Sakuya is interested in us dating, so we mainly answered her questions together.
[cpg]

[FACE method="shake_6" pos="2/5"]

And Sakuya talked more than usual. She was surprisingly interested in other people's love lives.
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Sakuya064"]
[OnName num="sakuya"]
“How many children do you want? I'd like to know for reference.”
[cpg cn=true]


I was puzzled, wondering what reference it was for.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Midori154"]
[OnName num="midori"]
“Well, ...... about five ……."
[cpg cn=true]


Midori answered without hesitation, and I felt like I had seen an unexpected side of her.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大通り』（夜）******************************************************

;//[SE f="se001"]
;//【ＳＥ】『戸開く』


[FACE method="bow_2" pos="4/5"]
[VOICE f="Sakuya065"]
[OnName num="sakuya"]
“I wish you both the best of luck. Good bye."
[cpg cn=true]

[FACE method="bow_2" pos="2/5"]
[VOICE f="Midori155"]
[OnName num="midori"]
...... Yeah. Thank you so much for today.
[cpg cn=true]

[free time=1000]
Sakuya waved her hand and left.
[cpg]


[FADEOUTBGM]

[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Midori156"]
[OnName num="midori"]
“Do you want to go back home Zen……? Or….”
[cpg cn=true]


I feel like I knew what she was implying.
[cpg]


[OnName num="zen"]
“Yes, I would like to stay with you a little longer.”
[cpg cn=true]


;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=1]


What I found out when I started dating her is that Midori is a romantic by nature.
[cpg]

She was opposite to Hazuki, who was only like that with a curse.
[cpg]


;//移植のためシーンをカットしています
;//========================================
;//●ＣＧ（仰向けのヒロイン）ev_38
;//人物１：ヒロイン２　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
[WAIT time=100]
;**【ＣＧ】 ev_37_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

We were alone in her room. I was staring at her.
[cpg]

[VOICE f="Midori157"]
[OnName num="midori"]
“......Zen, by the way, ......."
[cpg cn=true]


[VOICE f="Midori158"]
[OnName num="midori"]
“We have never kissed, besides the curse."
[cpg cn=true]


When she said that, I knew what she was asking for.
[cpg]

I moved closer to her without saying anything.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

It was an inexpressibly happy time. We were both first time lovers.
[cpg]


We were sharing our feelings for the first time with each other......
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大通り』（朝）******************************************************

The next morning. When I left her house, we talked a little.
[cpg]


It is because we are happy now that we have to talk about it.
[cpg]


[OnName num="zen"]
“..... Midori, what do you think about that thing that chased after me?”
[cpg cn=true]



[FACE method="shake_7" pos="2/3"]
[VOICE f="Midori159"]
[OnName num="midori"]
“Well…. I don't know what it is either.”
[cpg cn=true]


Yes. It is unknown to both of us.
[cpg]


[OnName num="zen"]
“I don't know either. But if we leave it, there might be more injuries and deaths.”
[cpg cn=true]


[OnName num="zen"]
“It's also an important opportunity for me to advance my career as an Onmyoji. I want to find out what it is and, if possible, exterminate it.”
[cpg cn=true]


I have to say these things. My body, or rather my life, is not mine alone anymore.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Midori160"]
[OnName num="midori"]
“Well…..I’m ......."
[cpg cn=true]


She seemed lost for words. And then.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Midori161"]
[OnName num="midori"]
“I don't want that. I don't want you to put yourself in danger."
[cpg cn=true]


She was clearly trying to hold me back.
[cpg]


Midori is trying to stay safe with her current happiness. I understand how she feels.
[cpg]


But I also knew that I couldn't stop here and now.
[cpg]


I knew that eliminating that something here and now would lead to the future of the two of us.
[cpg]



;//ブラックアウト


;//ジャンプ先指定
;//総合ルートへ
;//[jump target="*select00_0"]


[jump storage="ep013.ks" target="*select00_0"]
