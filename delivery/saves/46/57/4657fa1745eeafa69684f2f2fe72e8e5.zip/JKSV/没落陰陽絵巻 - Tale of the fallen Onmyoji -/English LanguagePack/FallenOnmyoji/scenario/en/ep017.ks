

;//==============================
;//二回目のお祓いを、一度で成功させていた場合下記のシナリオを追加

;#################################################
*Ep017|Looking at the Irrational
;#################################################



;//選択肢のジャンプ先
*select02_1|Looking at the Irrational


[SCENE id=17]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『妖怪探偵問屋』（昼）******************************************************

More time passes. The days pass leisurely and warmly.
[cpg]


After that, it is not enough to say that we became busy. Midori and I both became even more active as Onmyoji’s.
[cpg]


But that doesn't mean that we are facing big incidents like the Plague God or tremendous monsters.
[cpg]


Compared to that, I don't think there is any ordeal that we can't overcome.
[cpg]


And Midori still has the habit of acting according to the clock. But I don't blame her for being irrational.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Takane234"]
[OnName num="takane"]
“The more I think about it, the more I realize that we are perfect for each other.”
[cpg cn=true]


[OnName num="zen"]
"Maybe so."
[cpg cn=true]


Midori's cheeks flush and she looks down when Takane says this to her.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Midori201"]
[OnName num="midori"]
“I don't think we're a good match. I wish I could live a rational life like you Zen……"
[cpg cn=true]


Rational. What is rational, and am I really rational?
[cpg]


I don't think it is rational from the very beginning to try to solve an exceptional incident, such as exterminating Yokai.
[cpg]


But there was more to that thought.
[cpg]


[OnName num="zen"]
“If there were two people like me, irrational miracles might not happen anymore.”
[cpg cn=true]


[OnName num="zen"]
“It's what you need for you to be you. It's the most important thing."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
Takane was even more surprised than Midori. Then she chuckled.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Takane235"]
[OnName num="takane"]
“I can't believe you would say such a thing. Midori's influence is really great.”
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Midori202"]
[OnName num="midori"]
“I'm still somewhat embarrassed after all.”
[cpg cn=true]


Midori blushes. I'm probably blushing too, but I don't know as long as I don’t see my face.
[cpg]


[OnName num="customer"]
“I've been calling for a while now, but no one's answering.”
[cpg cn=true]


[FACE method="change_5" pos="2/5"]
[VOICE f="Takane236"]
[OnName num="takane"]
“Oh, yes, I'm here.”
[cpg cn=true]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//移植のためシーンをカットしています

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p5_02_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


After work, Midori and I are alone.
[cpg]

The distance between us is such that even if neither of us says anything, we know we love each other.
[cpg]

Midori looked at me, and leaned closer,
[cpg]

And put her lips to mine. It's not about breaking the curse anymore.
[cpg]


;//[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Midori203"]
[OnName num="midori"]
We kissed.
[cpg cn=true]


If I think about it, since I met Midori, I started to pay attention to irrational things.
[cpg]


The most irrational thing is surely to feel love. It's not about procreation or anything like that.
[cpg]


Even kissing is not for the purpose of having children, nor does it have any meaning other than an expression of affection.
[cpg]


But I want to do it. It was Midori who made me realize this.
[cpg]



;//ブラックアウト
[free time=1000]
[BG f="b_11_3.ui" time=1000]
[WAIT time=1000]


The meaning of life, happiness, destiny, and so on, all of these things may be better left unsaid.
[cpg]


With this thought, I hugged my beloved once more, who to me is a symbol of irrationality.
[cpg]

;//END
[SCENE id=25]
[jump storage="epend.ks" target="*start"]


;//==============================

;//ヒロイン２エンド
