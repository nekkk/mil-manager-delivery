
*start

;#################################################
*Ep006|An excellent blacksmith.
;#################################################

[SCENE id=6]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『村』（朝）******************************************************



I went to sleep with these thoughts in mind, and the next morning.
[cpg]




[OnName num="kurto"]
I'm going to visit Katharina. I'm going to get some more for the amulet.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca165"]
[OnName num="bianca"]
I'm going to get some more for the amulet. I'm going to town ahead of you.
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中の集落』（昼）******************************************************


[FACE method="change_1" pos="2/3"]
[VOICE f="Catalina085"]
[OnName num="catalina"]
I see. You used to be a nobleman.
[cpg cn=true]


[OnName num="kurto"]
Yes, well, ...... I am ashamed to say.
[cpg cn=true]


I was told where I had learned about this Yuhka person, and in the end I told them everything.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Catalina086"]
[OnName num="catalina"]
I'm not much of an aristocrat.
[cpg cn=true]


That's harsh ......, but I'm aware of it. Maybe that's why I was kicked out.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Catalina087"]
[OnName num="catalina"]
But as a merchant, I think you should use what you can get your hands on.
[cpg cn=true]


[OnName num="kurto"]
Do you agree, Katharina?
[cpg cn=true]


I'm not going to be timid here after all. I've made up my mind.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夕方）******************************************************




I've made up my mind, I've made up my mind, but I'm still at a loss when I see ...... it in front of me.
[cpg]


[OnName num="kurto"]
"That's a fine store. ...... I wonder when they built a store like this."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Bianca166"]
[OnName num="bianca"]
I'm sure it was." But even the manager of this place is ...... better than Mr. Yuika."
[cpg cn=true]


I'm sure that's true. It means Mr. Yuika is in a higher position.
[cpg]


I regret that I should have behaved better when I was an aristocrat, but it's too late now.
[cpg]


But looking at it like this, you can clearly sense the size of the ...... store and the size of the Chamber of Commerce behind it.
[cpg]


[OnName num="kurto"]
I think I'll go home after all.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Bianca167"]
[OnName num="bianca"]
What are you talking about? What are you talking about?
[cpg cn=true]


[OnName num="kurto"]
No, but I'm not ready. And even if I came here now, Yuika would not even talk to me.
[cpg cn=true]

[free time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/5" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Yuika010"]
[OnName num="yuika"]
Is that Yuika you're talking about me?
[cpg cn=true]


[OnName num="kurto"]
The actuality is that you can't just go out and buy a new one.　I'm sure you're right.
[cpg cn=true]


[FACE method="change_2" pos="4/5"]
[VOICE f="Yuika011"]
[OnName num="yuika"]
I think you are the youngest child of the Rammertz family ....... I've heard about your house.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

It seemed that Yuika-san remembered me.
[cpg]


I don't have to explain to you that I've heard the story of the house. I don't feel comfortable telling her that I was disowned or something like that.
[cpg]


[OnName num="kurto"]
"Hello, hello, ......, it's been a long time.
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Yuika012"]
[OnName num="yuika"]
Long time no see. She was a maid over there, wasn't she? I wonder if she followed him."
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Bianca168"]
[OnName num="bianca"]
"Long time no see. You remembered me, didn't you?
[cpg cn=true]

[FACE method="bow_1" pos="4/5"]
Yes, well," she says, and Yuika-san has an unreadable expression on her face.
[cpg]

[FACE method="change_1" pos="2/5"]
She doesn't seem indifferent. I wonder if she knows me to some extent.
[cpg]


[OnName num="kurto"]
......Ah, um, I'd like to talk to you about something. I'd like to talk to you about something.
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Yuika013"]
[OnName num="yuika"]
I've been a merchant since then. I heard you've been working as a merchant since then, and I heard you're making something interesting.
[cpg cn=true]


I heard you're making something interesting. That's a quick story then.
[cpg]


[OnName num="kurto"]
I'm looking for a blacksmith. I'm looking for a blacksmith who can take on ...... a variety of jobs.
[cpg cn=true]


What should I do? I should probably tell him, but he's heard about what I'm making, right ......?
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Yuika014"]
[OnName num="yuika"]
The blacksmith, huh? Have you been to the dwarven settlement yet?
[cpg cn=true]


[OnName num="kurto"]
I did, but none of them accepted me.
[cpg cn=true]


Yuika puts her hand over her mouth. There is a unique air about me, or perhaps I feel pressured by even the slightest gesture.
[cpg]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Yuika015"]
[OnName num="yuika"]
It's strange," she said. I wonder what on earth he requested.'
[cpg cn=true]


......I see. Yuhka, you don't know what kind of business I'm in yet.
[cpg]


I look at Bianca, wondering what I should do here.
[cpg]

[FACE method="change_7" pos="2/5"]
Bianca, too, looked at me uneasily.
[cpg]


[OnName num="kurto"]
She said, "Don't you know someone who is ...... still an unknown blacksmith or something like that?"
[cpg cn=true]


Yooka-san gestures as if she is thinking a little.
[cpg]


I didn't tell her the important part. No matter how it would not be possible without my Mischief-making Magic, ......
[cpg]


I might be able to reproduce it by another mechanism. If I give them the whole idea of the product, they might steal it.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Yuika016"]
[OnName num="yuika"]
I have an idea. But I'm going to charge you a referral fee.
[cpg cn=true]


Okay. Maybe this is good. ...... I can't do any better than this right now.
[cpg]


[OnName num="kurto"]
Thank you."
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]




I paid Yuhka an introduction fee from what little money I had saved.
[cpg]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika017"]
[OnName num="yuika"]
I'm still a nobody, but I've got what's known as a powerful skill set, and I'm sure I've got the skills. He is still unknown, but he has a great skill.
[cpg cn=true]


After that, I was told where to find the craftsman.
[cpg]


His name is Edith Ahrens, I was told. Wondering what he was like,...... the next day we went to the place we were introduced to.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



;//背景と別の場所なので、上下に黒帯を入れるなどしてください



Bianca and I walk up to the front of the house.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="4/5" time=800]

[VOICE f="Edith001"]
[OnName num="edith"]
"......Yes, and ......."
[cpg cn=true]


I was surprised when I saw what she looked like. He looked so young that he still looked young.
[cpg]


[OnName num="kurto"]
He said, "You must be Mr. Edith, right?　I have a job offer for you.
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Edith002"]
[OnName num="edith"]
"You're talking about making ...... something for work ......?"
[cpg cn=true]


[OnName num="kurto"]
Yes, I have a job offer. I think it's something only Ms. Edith could do.
[cpg cn=true]


The skill she possesses of great skill is the skill of being able to exert more strength than her actual muscles.
[cpg]


I only looked around a little bit, but the house was clean and tidy. I guess they take good care of their tools in the workshop.
[cpg]


According to Yuika, he is a skilled craftsman, but his skills are inferior to those of master craftsmen.
[cpg]


Imagining that it must be a tough world ......, I showed him the blueprints.
[cpg]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Bianca169"]
[OnName num="bianca"]
I show him the blueprints and say, "I want you to make this. What do you think?
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Edith003"]
[OnName num="edith"]
He said, "I can make it ....... I think so, but for what?
[cpg cn=true]


[OnName num="kurto"]
"It's ......."
[cpg cn=true]

Well, here we are. I'll see if I can get them interested here.
[cpg]

;//[lbox off]



;//ブラックアウト

There is no such thing as a massage machine in this world.
[cpg]

So, it is natural to be wary of whether or not it will sell. ......
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="4/5" time=800]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



;//背景と別の場所なので、上下に黒帯を入れるなどしてください



[OnName num="kurto"]
How about ......?"
[cpg cn=true]



Mr. Edito was silent.
[cpg]


I thought it was still no good,......, but I decided to persuade him patiently.
[cpg]


[OnName num="kurto"]
We are just starting out as merchants," he said. That's why we haven't asked any other blacksmiths for help."
[cpg cn=true]


[OnName num="kurto"]
Conversely, if this works out, I think we can ask Mr. Edith to work for us on a steady basis."
[cpg cn=true]


Mr. Edith's face is downcast, as if he is lost or just embarrassed.
[cpg]


[FACE method="change_4" pos="4/5"]
[VOICE f="Edith004"]
[OnName num="edith"]
I'm ......."
[cpg cn=true]


He opened his mouth. And then he said, "I am still a craftsman, too.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Edith005"]
[OnName num="edith"]
I'm just starting out ...... as a craftsman, so I'm a lot like you.
[cpg cn=true]


It is true that we may be in a similar situation where we are not recognized by the people around us.
[cpg]


I hope that gives you a boost. ...... I don't know.
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Edith006"]
[OnName num="edith"]
The blueprints are interesting, too. I've never made anything like this before, and I'd love to, but ......"
[cpg cn=true]


Apparently, they are willing to accept my request.
[cpg]


[FACE method="shake_4" pos="4/5"]
[VOICE f="sEdith001"]
[OnName num="edith"]
"But, but ......, will it really sell?"
[cpg cn=true]


I knew it. I guess he's still a little unsure.
[cpg]


I was lacking that final push. I thought of my next move.
[cpg]


[OnName num="kurto"]
"Yes, that's right. I'd like to take a look at your workshop.
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Edith008"]
[OnName num="edith"]
My workshop?　Nothing, that's fine. ......"
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I asked Edith to show me her workshop.
[cpg]


There were elaborate swords and spears, not only metal but also woodwork and other decorations.
[cpg]



[FACE method="change_1" pos="2/5"]
[VOICE f="Bianca170"]
[OnName num="bianca"]
'Wow,...... awesome.'
[cpg cn=true]


[OnName num="kurto"]
Really, it's amazing ...... that something this elaborate could be done at this cultural level."
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Edith009"]
[OnName num="edith"]
What do you mean by this cultural level ......?"
[cpg cn=true]


Edith seemed to be slightly caught up in my words, but she looked embarrassed.
[cpg]


In fact, I was quite shocked. After all, there are craftsmen in every world.
[cpg]


I had no choice but to ask her. I felt like I had no choice but to ask her.
[cpg]


[OnName num="kurto"]
We need your skills. No one else can make it.
[cpg cn=true]


[FACE method="shake_6" pos="4/5"]
[VOICE f="Edith010"]
[OnName num="edith"]
I can make something like this even if I don't do it myself.
[cpg cn=true]


I took her hand and said, "It has to be you.
[cpg]


[OnName num="kurto"]
I took her hand and said, "It has to be you. I've made up my mind, I'm not going to ask anyone else but you.
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Edith011"]
[OnName num="edith"]
So ...... it's not that big of a deal."
[cpg cn=true]


I was so embarrassed that Mr. Edith didn't even look at me.
[cpg]


[FACE method="shock_4" pos="4/5"]
[VOICE f="Edith012"]
[OnName num="edith"]
"Ugh,......, it's hard to say no,.......
[cpg cn=true]


If it's hard for you to say no, that's fine. I want you to accept my request.
[cpg]


[OnName num="kurto"]
I'm asking for your help. Can you help me?"
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
Edith nodded her head without saying a word.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



With that, we were ready to build a sturdy metal massager.
[cpg]


As I was about to strike a gut-punching pose, a voice called out to me from behind.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Yuika018"]
[OnName num="yuika"]
How did it go?
[cpg cn=true]


[OnName num="kurto"]
'Eh...... ah, Yuika-san.'
[cpg cn=true]


I was just passing by by chance, and there she was, Yuika.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Bianca171"]
[OnName num="bianca"]
She was there. Thank you very much, Ms. Yuhka.
[cpg cn=true]


Bianca bowed deeply. I bowed, too.
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Yuika019"]
[OnName num="yuika"]
You don't have to call me "sir.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]


I said so, but I could feel the aura of being on guard. Could it be that you have come to find out what Mr. Edith asked you to do for him? ......?
[cpg]


No, that's thinking too much. I don't think Mr. Edith's character would talk.
[cpg]


[FACE method="change_2" pos="4/5"]
[VOICE f="Yuika020"]
[OnName num="yuika"]
I want things to work out for you guys. I hope you guys can work things out, and I'd be happy to join forces in the end.
[cpg cn=true]


[OnName num="kurto"]
"I'll do my best at ......."
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Yuika021"]
[OnName num="yuika"]
I'll do my best. I'm looking better than I did when I was an aristocrat.
[cpg cn=true]


When Yuika said that to me, I thought that might indeed be true.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『村』（夜）******************************************************



[FACE method="bow_2" pos="2/3"]
[VOICE f="sBianca012"]
[OnName num="bianca"]
You did it. You can make a new product.
[cpg cn=true]


[OnName num="kurto"]
But the unit price might be high. ......
[cpg cn=true]


It's no wonder in this world that we have to make each product one by one.
[cpg]


It is difficult to mass produce ......, but that is why they are rare.
[cpg]


[OnName num="kurto"]
It's like, "Well, here we are, finally.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca173"]
[OnName num="bianca"]
But, then, we've made a start, haven't we?
[cpg cn=true]


That's right. We'll go as far as we can go from here.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『村』（朝）******************************************************


And for a while we kept selling massage machines and amulets at our stall.
[cpg]


Sales are slower than before, but we are developing new products.
[cpg]



;//ブラックアウト
[window target=false]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



Then we head back to Edith's workshop.
[cpg]


I wonder if they are ready by now. But it seems like I'm rushing him to check every time I go to his workshop. ......
[cpg]


But I couldn't stand still. I eventually made my way to her place.
[cpg]



;//背景と別の場所なので、上下に黒帯を入れるなどしてください


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[OnName num="kurto"]
She's not there. ......
[cpg cn=true]


When I went to the workshop, she was not there.
[cpg]


It's unlocked, I guess it's just that she's out for a bit.
[cpg]


[OnName num="kurto"]
I wondered if I could go up to .......
[cpg cn=true]


I remembered the swords and workmanship I had once seen in the workshop.
[cpg]


I silently went up and admired the elaborately crafted swords.
[cpg]


[OnName num="kurto"]
'Truly awesome ...... weapons are so romantic, aren't they?'
[cpg cn=true]


I think to myself. Perhaps the sword is too ornate to actually use.
[cpg]


It's cool for that. It's aesthetically pleasing too, I think to myself.
[cpg]



[SE f="se014"]
;//【ＳＥ】『足音』



Oh no. She's back. If she finds out that I went up there without permission, she will be furious, right?
[cpg]


I hid as quickly as I could, but it didn't matter that I hid.
[cpg]


I was afraid that she would find me in the end.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Edith013"]
[OnName num="edith"]
......"
[cpg cn=true]


She looked as if she was hiding some kind of determination.
[cpg]

I guess Mr. Edit has been suffering from his own anguish up to now.
[cpg]

The feeling of wanting to look back at those around her is the same as mine. ......
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



After a while, she left the workshop.
[cpg]


I then unlocked the door from the inside and left. ......
[cpg]


I'd have to leave the door unlocked, but I had no choice. I can't lock the door from the outside.
[cpg]


Then I go back to the stall.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（朝）******************************************************




And after a while, on a day when the ...... stall was also closed, we decided to head to Edith's again.
[cpg]
It should be finished by now. It means we don't have to hide anymore.
[cpg]


[SE f="se014"]
;//【ＳＥ】『歩く』

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



[OnName num="kurto"]
Hello, Mr. Edito. Hello, Mr. Edito.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Edith039"]
[OnName num="edith"]
Hello ......, it's already done."
[cpg cn=true]


;//背景と別の場所なので、上下に黒帯を入れるなどしてください

[free time=1000]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


And I went up to the house. I receive an item from Mr. Edito.
[cpg]


[OnName num="kurto"]
"I see ...... that this is ......."
[cpg cn=true]


It looks different from the one I was using the other day. I was relieved and thought that he must have made some improvements since then.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Edith040"]
[OnName num="edith"]
The innermost part is filled with magic stone,......, covered with metal, and the outermost part is made of wood.
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Bianca176"]
[OnName num="bianca"]
It's amazing technology ...... to be able to make such a curve."
[cpg cn=true]


Bianca and Mr. Edith seem embarrassed as they say.
[cpg]


[OnName num="kurto"]
Bianca and Edith are embarrassed.
[cpg cn=true]


Bianca and Mr. Edito nodded. But I think the demand will outweigh that.
[cpg]


[OnName num="kurto"]
'After all, no one else in the world is making them, so I guess we can go ...... upscale. But ......."
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Bianca177"]
[OnName num="bianca"]
I agree. I think it will spread more if we sell it cheaply at first."
[cpg cn=true]


Mr. Edito nodded. For now, we need to establish this in the other world.
[cpg]



;//背景と同じ場所なので、黒帯などの演出を外してください


;//[lbox off]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夕方）******************************************************



So, I set a lower price.
[cpg]


There are already a certain number of fans of what I make. I expect it will sell for sure. ......
[cpg]


Still, I was nervous at first. There is always the possibility that people will not pay any attention to my work.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



Still, the first batch I made sold in an instant.
[cpg]

[window target=false]

;//ここから、ウィンドウの枠を別の形にするか、色を変えてください


[FG f="ci_money.ui" method="window_in_0" layer=20 pos="4/7" time=1]
[WAIT time=1000]

[SE f="se011"]
;//【ＳＥ】『お金増減』
[stflag Tai_sil = 1000]


[FG f="ci_money.ui" method="cal_p1000_0" layer=20 pos="4/7" time=1]
[WAIT time=1000]

[window target=true]

I got 1000sil!
[cpg]

sil is the currency in this world. You can use it for whatever you want. ......
[cpg]

If you use it without looking over there too much, you might get into trouble.
[cpg]




;//ウィンドウの枠を元に戻してください
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落』（昼）******************************************************



Reputation is spreading, I think. At this rate, the price could be pushed up a bit more.
[cpg]


In fact, even though the price seemed a little high, there was no end to the number of people who wanted one.
[cpg]


[OnName num="kurto"]
So, how about one for you?
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Catalina088"]
[OnName num="catalina"]
"I'd like one. ...... You know what? Am I not a tester?
[cpg cn=true]


[OnName num="kurto"]
It's already been sold to some extent. What should I do?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Catalina089"]
[OnName num="catalina"]
I don't have a choice. ......
[cpg cn=true]


I think that Katharina would be a fan of mine, too.
[cpg]


Without showing any signs of distress, Ms. Katharina bought one for me.
[cpg]


[OnName num="kurto"]
Thank you very much.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Catalina090"]
[OnName num="catalina"]
It's a good business, isn't it? I'm sure you'll buy one of these.
[cpg cn=true]


[OnName num="kurto"]
I'm glad to hear you say so.
[cpg cn=true]


She's completely hooked on what we make.
[cpg]


It is true that I am happy. I hope we will have more fans like her.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『村』（夜）******************************************************



I also have to thank Mr. Edito.
[cpg]


He takes care of this kind of thing, and also everyone is satisfied with the result.
[cpg]


And I can't thank Bianca enough for .......
[cpg]


With these thoughts in my mind, I made my way back home.
[cpg]



[SE f="se002"]
;//【ＳＥ】『ドア開く』
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]


[OnName num="kurto"]
I'm home.
[cpg cn=true]




;//ブラックアウト



[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Bianca178"]
[OnName num="bianca"]
Welcome home. Master."
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



Bianca no longer works at the bar.
[cpg]


Bianca no longer works at the bar, because she has a certain amount of income. It seems like she's come a long way.
[cpg]


[OnName num="kurto"]
I've been working at ...... Bianca. You've really worked hard.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Bianca179"]
[OnName num="bianca"]
What are you talking about? It's all thanks to the master.
[cpg cn=true]


Bianca stands up for me no matter what I say.
[cpg]


I really don't know what to say. I don't know what to do with this feeling.
[cpg]


[OnName num="kurto"]
I'm going to be a bigger merchant. Bianca, stay with me until then.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Bianca180"]
[OnName num="bianca"]
Yes. Of course. ...... I'll be your personal maid.
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



A few days pass. Our lives have become a little more stable.
[cpg]


Greed begins to take over. Since we are merchants, we want to open a store.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kurto"]
"...... I want a store, don't you? Bianca.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca181"]
[OnName num="bianca"]
Yes, we do. I might be able to at least rent a store now.
[cpg cn=true]


I'll see what I can do. The benefits would be enough to pay the rent.
[cpg]


We were about to take the next step.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



We had saved up enough money and decided to finally set up store.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kurto"]
We decided to go to ....... It's a nice place," he said. It's not the kind of thing you sell on the main street.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca182"]
[OnName num="bianca"]
Yes, this will be the first store. This will be the first store, right?
[cpg cn=true]


[OnName num="kurto"]
Yes. Of course, if it works out, I won't be the only one doing it.
[cpg cn=true]


Of course, if it works out, I'm not going to do it alone.
[cpg]


A little further into town, we're going to be based there.
[cpg]


Now people won't be coming to my house to buy. They will come here.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夕方）******************************************************



[OnName num="kurto"]
"Phew. But renting a ...... store is a lot of work, isn't it?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Bianca183"]
[OnName num="bianca"]
Yes, it's a lot of work just to clean up.
[cpg cn=true]


But it's an investment for the future. We can't spare the time and effort.
[cpg]


[OnName num="kurto"]
I want to make the opening a big deal. I want to do some publicity in advance.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca184"]
[OnName num="bianca"]
"Hmmm. Master, your eyes are shining. You look like a child.
[cpg cn=true]


[OnName num="kurto"]
"Oh, yeah?"
[cpg cn=true]


While we were talking, ...... we got ready to open the store.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



We thought about advertising methods.
[cpg]


In the world I lived in, handing out tissues was the way to go.
[cpg]


But in this world, paper is much more precious. We thought we needed a different method, so we came up with ......
[cpg]


I thought of another way, and that was to advertise at the inn. In addition, of course, I would let people who come to my stall know that I would be open.
[cpg]


The day of the opening came and went, with the thought that I needed to get some people to come to .......
[cpg]




[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



It wasn't a huge turnout, but there were quite a few people there.
[cpg]


[OnName num="kurto"]
I said, "I'm sorry, we're sold out. ......
[cpg cn=true]


[OnName num="male_customer_A"]
I'm sorry to hear that. But I'm glad it's busy.
[cpg cn=true]


[OnName num="male_customer_B"]
I'd hate to see this place go away. It would be a problem if this restaurant were to disappear.
[cpg cn=true]


I was happy too. I felt like I had just sailed out to sea.
[cpg]


I used to just sell to them, but after I set up the store, people started coming to buy from me because they heard the rumors.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夕方）******************************************************



[OnName num="man_on_the_street_A"]
"Hey, that guy is ......."
[cpg cn=true]


[OnName num="man_on_the_street_B"]
"Oh, yeah. The guy from that store.
[cpg cn=true]


[OnName num="kurto"]
......, I can feel your eyes on me.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Bianca185"]
[OnName num="bianca"]
Yeah. Maybe he's famous.
[cpg cn=true]


[OnName num="man_on_the_street_B"]
You're famous now, aren't you?
[cpg cn=true]


[OnName num="man_on_the_street_A"]
Yeah. Yeah. You're an invention evangelist, right?
[cpg cn=true]


I felt good about that. I have been called the "preacher of invention" for some time now.
[cpg]


I couldn't decide whether to feel honored or not, but I knew I didn't feel bad about it.
[cpg]


[OnName num="kurto"]
I feel like I finally have my own power.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca186"]
[OnName num="bianca"]
'Yes. Without the master's ideas and skills, we could not have come this far.
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中の集落』（夕方）******************************************************



It was good to have a store. It was good to have a shop, because you could always sell something, and because it was indoors, it was ideal for making something by hand.
[cpg]


Still, it did not mean that he was in the store 24 hours a day.
[cpg]


On days off, I would go to Katharina's place like this.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sCatalina005"]
[OnName num="catalina"]
I still see a lot of potential here," he said. You must have another invention in mind.
[cpg cn=true]


[OnName num="kurto"]
Yes, well.
[cpg cn=true]


I'm just pulling from my memory.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="sCatalina006"]
[OnName num="catalina"]
By the way, ......, aren't you good at regular massage?
[cpg cn=true]


[OnName num="kurto"]
What do you mean?"
[cpg cn=true]



[FACE method="shake_1" pos="2/3"]
[VOICE f="sCatalina007"]
[OnName num="catalina"]
I'm saying I'll let you. It might be useful for product development.
[cpg cn=true]


......I know it sounds pushy, but it's a chance to return the favor.
[cpg]

That's what I thought and decided to accept it.
[cpg]



;//ブラックアウト
;//========================================
;//●ＣＧ（仰向けに寝ているヒロインに、マッサージをする主人公）ev_10
;//人物１：ヒロイン５　服装１：着衣
;//場所　：ヒロイン５の部屋
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bgm_09"]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//[SE f="se010"]
;//【ＳＥ】『バイブの振動音』


;//移植のためシーンをカットしています

Like Katharina, Arlaune is physically weak.
[cpg]

It's just like when I was there, the type of people who tend to have stiff shoulders and little muscle mass.
[cpg]

[VOICE f="sCatalina008"]
[OnName num="catalina"]
'Oh, that ...... feels good right there.'
[cpg cn=true]


I massaged her, pulling from my memories of my previous life.
[cpg]


;//ブラックアウト
;**【ＣＧ】 ev_10_a ***********************
[CG id=2 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="sCatalina009"]
[OnName num="catalina"]
You're good at massaging.
[cpg cn=true]


[VOICE f="sCatalina010"]
[OnName num="catalina"]
I'm not from this era," she said.
[cpg cn=true]


You have good intuition ....... You're almost always right.
[cpg]


[jump storage="ep007.ks" target="*start"]


;//=============================================================================
