
*start

;#################################################
*Ep004|Spreading the word about your invention
;#################################################

[SCENE id=4]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[FACE method="change_1" pos="2/3"]
[VOICE f="Bianca113"]
[OnName num="bianca"]
Good morning. Good morning, Master."
[cpg cn=true]


[OnName num="kurto"]
"...... Oh, good morning."
[cpg cn=true]


In the end I was too hungry to sleep well. But I had time to think.
[cpg]


I had an epiphany.
[cpg]


[OnName num="kurto"]
Bianca. "Bianca, let's try selling somewhere else today. I have a plan.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca114"]
[OnName num="bianca"]
"Hmmm. You're so positive. You're like a different person than your old master.
[cpg cn=true]


[OnName num="kurto"]
"Really?"
[cpg cn=true]


I thought, "Maybe," and decided to take the next plunge.
[cpg]




;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bgm_03"]
;//[WAIT time=100]
;//【ＢＧ】『街＿異世界』（朝）******************************************************



I had to think about how to sell. This is the basis of business, and the simpler the stall, the harder it is to make a profit.
[cpg]


I had to think about who would buy such an invention that did not exist at this level of civilization, and where it should be located.
[cpg]

I thought about what kind of place it should be and came to one conclusion.
[cpg]


Early in the morning, I would come out to the city. And the place I sold it to was ......
[cpg]



;//背景と別の場所なので、上下に黒帯を入れるなどしてください

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]



[OnName num="shop_owner"]
"Massage machines?　Never heard of it."
[cpg cn=true]


An inn on the outskirts of town that sells baths.
[cpg]


[OnName num="shop_owner"]
All they have are customers who want to relieve their fatigue, but ...... you want me to sell to those guys?"
[cpg cn=true]


[OnName num="kurto"]
Please. I really want to spread my name.
[cpg cn=true]



;//ブラックアウト


Negotiations were difficult, but the inn agreed to let us put the baths on their shelves and share most of the profits with us.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************


If we were to sell them in a storefront, there would be resistance from people who don't know what they are, but in a place like this, there would be less resistance to buying them.
[cpg]

We waited to see if we could make a profit, and sold steadily at the stalls as well.
[cpg]

[FADEOUTBGM]
[window target=false]
[BG f="b_04_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夕方）******************************************************



It took a long time for our efforts to bear fruit.
[cpg]


It took a long time, but the name "massage machine" began to spread in the neighborhood.
[cpg]


[OnName num="male_customer"]
"Here," he said, "is this it? It's just like a fledgling merchant. ......
[cpg cn=true]


[OnName num="kurto"]
"Welcome. Please take a look.
[cpg cn=true]


I was pleased to hear the words, "Here? It means that they heard where it was sold and came to buy it.
[cpg]


[window target=false]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************



Making them is hard work. It's also hard to sell them, but they are starting to sell little by little.
[cpg]


[OnName num="male_customer_A"]
It would be nice if the vibration lasted longer.
[cpg cn=true]


[OnName num="male_customer_B"]
They say it would be better if the outside was made of a softer material. Can you improve it?
[cpg cn=true]


[OnName num="kurto"]
Of course. Of course. We'll keep improving it.
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="kurto"]
Oh, I'm so tired. ...... It's not easy being in the customer service business.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sBianca009"]
[OnName num="bianca"]
I'm sure you sell quite well. Should I stop working at the bar too and concentrate on making machines?
[cpg cn=true]


[OnName num="kurto"]
"Hmmm......... I don't know."
[cpg cn=true]


It is still too early to say that business will take off.
[cpg]


Bianca's steady income has helped me a lot.
[cpg]


[OnName num="kurto"]
I'll try to do it on my own for a while. I'll try to do it on my own for a while, and when it gets going, I'll ask her to help me out again.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca118"]
[OnName num="bianca"]
I understand. Good luck, master.
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



[OnName num="female_customer"]
"Yes, I see you have improved a lot. You've improved a lot.
[cpg cn=true]


[OnName num="kurto"]
Yes, thanks to you.
[cpg cn=true]


Since the outer shell is made of soft wood, it seems ...... to be more comfortable to use.
[cpg]


[OnName num="female_customer"]
This kind of product will be a big seller among the Arlaune people now.
[cpg cn=true]


[OnName num="kurto"]
Arlaune?　Arlaune?
[cpg cn=true]


[OnName num="female_customer"]
"Don't you know them?　They are a species close to plants.
[cpg cn=true]


The more I listened to him, the more I learned that there was a tribe called the Arlaune nearby.
[cpg]


[OnName num="female_customer"]
They are weak compared to humans. They probably suffer from muscle pain.
[cpg cn=true]


[OnName num="kurto"]
......
[cpg cn=true]


I smell money. I was gradually acquiring that sense of smell as well.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************



In the evening, I met up with Bianca after she finished her work.
[cpg]


[OnName num="kurto"]
I'm sure you know that the Arlaune people suffer from stiff shoulders,.......
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca119"]
[OnName num="bianca"]
You know it well, don't you? Yes, I do."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sBianca010"]
[OnName num="bianca"]
They are a race that manipulates ivy, so their muscle structure seems to be different from that of humans.
[cpg cn=true]


We also get information from Bianca. We have to pull out the information we can use, even from our own people.
[cpg]


[OnName num="kurto"]
I see. Good."
[cpg cn=true]


I had already decided to make my move. It wouldn't do to become famous only in this town.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_12_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]

[SE f="se016"]
;//【ＳＥ】『茂み歩く』


So, I headed to the village of the Arlaune tribe.
[cpg]


[OnName num="kurto"]
"...... isn't that a beast road? ...... Can you really sell things in a place like this?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca123"]
[OnName num="bianca"]
They say they use the same currency."
[cpg cn=true]


Is that so? I'm surprised.
[cpg]


[OnName num="kurto"]
Do they do any shopping?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca124"]
[OnName num="bianca"]
I don't think you can live in Arlaune without eating anything.
[cpg cn=true]


[OnName num="kurto"]
Come to think of it, I wonder if Arlaune sometimes comes to town to buy groceries.
[cpg cn=true]


Arlaune is a very conspicuous person.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中の集落』（昼）******************************************************



In the meantime, he came out into a little open space.
[cpg]


[OnName num="kurto"]
Bianca. I might look suspicious if I'm the only one.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca126"]
[OnName num="bianca"]
Yes, I will. Okay."
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落』（夕方）******************************************************



And a moment later, ...... Bianca came back with a smile on her face.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sBianca011"]
[OnName num="bianca"]
She said, "It's sold. Some people in town have bought it.
[cpg cn=true]


[OnName num="kurto"]
I see. I knew it was the right thing to do, selling at that kind of inn."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Bianca128"]
[OnName num="bianca"]
I think we can sell a little more here. Let's come back again.
[cpg cn=true]


[OnName num="kurto"]
"Yeah, I can't do anything about it, but it's itching. It's a shame I can't do anything about it.
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//下記セリフの名前欄を？？？と隠してください



;//カタリーナの立ち絵を表示してください



[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Catalina001"]
[OnName num="unknown"]
"......"
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『村』（夜）******************************************************



Finally, I'm starting to sell a little more.
[cpg]


Of course, I don't know what will happen from here. We may find ourselves in an untenable predicament.
[cpg]


But I was beginning to feel confident that I could make it to some extent.
[cpg]


[OnName num="kurto"]
Someday, I would like to have my own store.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca129"]
[OnName num="bianca"]
That sounds good. I'll follow you wherever you go.
[cpg cn=true]


[OnName num="kurto"]
Thank you. You've always been so honest and devoted to me. I'm glad.
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『村』（朝）******************************************************



It's going well. I think it's going well, but I also have regrets.
[cpg]


I feel like we've crossed a threshold that we shouldn't have crossed.
[cpg]


I was worried about the business, but I was also afraid that I would lose my relationship with Bianca.
[cpg]


I was comfortable with the distance between us.
[cpg]


[OnName num="kurto"]
Well, ......, let's go sell again today, shall we?
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca131"]
[OnName num="bianca"]
Yes. I have work to do at the bar,......, so good luck, master.
[cpg cn=true]


Bianca is going to work today. But I'm going to have to work hard enough to quit that job.
[cpg]


;//ブラックアウト



With that determination, she heads off to the village of Arlaune.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中の集落』（昼）******************************************************


Then I heard a woman's voice from somewhere.
[cpg]



;//ここからしばらく、カタリーナの名前欄を「アルラウネの女性」と置き換えてください



;//ブラックアウト

;//========================================
;//●ＣＧ（ストレッチをしているヒロイン）ev_07
;//人物１：ヒロイン５　服装１：着衣
;//場所　：ヒロイン５の部屋
;//時間　：昼
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bgm_10"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//[SE f="se010"]
;//【ＳＥ】『ローターの振動音』

[VOICE f="sCatalina001"]
[OnName num="lady_of_alraune"]
"Hmmm,......I knew it wouldn't get better,......."
[cpg cn=true]


This woman was also suffering from stiff shoulders, or perhaps she was stretching like a modern-day yoga practitioner.
[cpg]

The fact that there are different ailments or traits depending on the species is something that does not exist in the modern world.
[cpg]

But I sensed a business opportunity there.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落』（夕方）******************************************************



I'll be selling there for a while, but it's still going well.
[cpg]


[OnName num="kurto"]
"Okay, ......, we're selling pretty well today, too."
[cpg cn=true]


The day may soon come when Bianca will no longer have to work in a bar.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（夜）******************************************************



[OnName num="kurto"]
"Bianca. You just got home?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca132"]
[OnName num="bianca"]
Yes, sir. Yes. Is the master home now, too?
[cpg cn=true]


Bianca and I talked about this as we returned home.
[cpg]


I was not living on the edge as before, and I had a little bit of leeway.
[cpg]


That alone made me happy and gave me some confidence.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



This time, I came back to town and opened a stall in the same place.
[cpg]


There were not many customers, but there were clearly more people than before.
[cpg]


I also set the price slightly higher. But people still bought.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Catalina027"]
[OnName num="lady_of_alraune"]
"......"
[cpg cn=true]


[OnName num="kurto"]
Welcome to .......
[cpg cn=true]


Then, a woman from Arlaune comes to me. I greet her.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="sCatalina002"]
[OnName num="lady_of_alraune"]
"Are you the one who is selling the massager?
[cpg cn=true]


[OnName num="kurto"]
Yes, well, I'm .......
[cpg cn=true]


Do I know you from somewhere? I wonder if I've met you before.
[cpg]



;//下記セリフからカタリーナの名前を隠さないでください



[FACE method="bow_7" pos="2/3"]
[VOICE f="Catalina029"]
[OnName num="catalina"]
I am Katharina. I'm Katharina, and I speak on behalf of Arlaune.
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Catalina030"]
[OnName num="catalina"]
Don't do this kind of business. If you are going to make something, please make it better.
[cpg cn=true]


[OnName num="kurto"]
I mean ......?"
[cpg cn=true]


I was a little defensive. I thought I should have apologized right away instead of saying, "I mean.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="sCatalina003"]
[OnName num="catalina"]
My sister and her friends are all the rage. Is it the ...... massager you made?"
[cpg cn=true]


That's a good thing. I continued to listen, thinking, "It's a good thing, isn't it?
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Catalina032"]
[OnName num="catalina"]
Some people use it so much that they break it and get hurt. It can't be this fragile.
[cpg cn=true]


[OnName num="kurto"]
I'm sorry ......, but we'll keep trying to improve it.
[cpg cn=true]


If you make it too strong, the vibration will be weak.
[cpg]


I've been doing some research on this, but I have to be careful if I get this kind of feedback.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Catalina033"]
[OnName num="catalina"]
If you say so, I hope you will take your customers' opinions into consideration.
[cpg cn=true]


The person, who introduced herself as Katharina, did not stop talking.
[cpg]


As she spoke more and more, her true identity became a little clearer.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Catalina034"]
[OnName num="catalina"]
I'm a magician, but why do you have to go through all that trouble to get the ...... magic stone into the room?
[cpg cn=true]


[OnName num="kurto"]
I mean, magic stones are only powerful when they are shattered, right?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Catalina035"]
[OnName num="catalina"]
No, it's not. No. They are a high quality material, but they work in a completely different way.
[cpg cn=true]


[OnName num="kurto"]
Is that so?
[cpg cn=true]


It would be better not to deal with this as a mere complainer.
[cpg]


He called himself a magician, and he might be able to give us a helpful opinion.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Catalina036"]
[OnName num="catalina"]
'There's also a type of magic stone that revives built-in magic when you put magic into it.
[cpg cn=true]


[OnName num="kurto"]
That's new to me. ...... Can you tell me a little more about it?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
Ms.Katharina, who is also a magician, gave accurate advice about the products.
[cpg]

[FACE method="change_1" pos="2/3"]
With the current system, you use it once and that's it. That's definitely true, and it requires a lot of time and effort to crush.
[cpg]


It is better to use a magic stone that can revive the built-in magic if you put magic power into it without having to do that,.......
[cpg]


[OnName num="kurto"]
But not everyone has magic power, right?
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Catalina037"]
[OnName num="catalina"]
That's why you can use a different magic stone. This one is disposable, but there are alternatives that inject magic power from the outside.
[cpg cn=true]


[OnName num="kurto"]
Hmmm.
[cpg cn=true]


That's helpful. Not that I know much about magic, but it's simply something I don't know.
[cpg]


[OnName num="kurto"]
If you make it with that system, you can use it for a long time if you are a magician,......, and even if you are not a magician, you can put a magic stone for injecting magic power,.......
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Catalina038"]
[OnName num="catalina"]
I'm sure it will sell. I think it's more efficient than creating a product from scratch.
[cpg cn=true]


[OnName num="kurto"]
I see. It's like a battery.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Catalina039"]
[OnName num="catalina"]
"A battery ......?　What does that mean?
[cpg cn=true]


I see. There are no batteries in this world? Well, that's okay.
[cpg]


[OnName num="kurto"]
I understand. Thank you for your valuable input.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
This wasn't a social call, it was really helpful.
[cpg]


I'm sure Bianca will be able to tell you what kind of place to find such a stone.
[cpg]


...... even so. I'm sure you know a lot about massagers, Katharina.
[cpg]


I was wondering if it was not her sisters and friends who were injured, but herself,.......
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Catalina040"]
[OnName num="catalina"]
What is it? What's that face?
[cpg cn=true]


[OnName num="kurto"]
No, no. Nothing.
[cpg cn=true]


I didn't point it out.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]

I walked back from the city to my house. I was used to walking this way.
[cpg]



[SE f="se014"]
;//【ＳＥ】『歩く』



It was a long way, but I had gained enough to make up for it.
[cpg]





[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="kurto"]
Bianca. Do you have such a stone?
[cpg cn=true]



[VOICE f="Bianca133"]
[OnName num="bianca"]
......I don't know much about them either. I don't know much about it. I'm not very good at magic.
[cpg cn=true]


[OnName num="kurto"]
Then, it would be better to get help from someone named Katharina.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca134"]
[OnName num="bianca"]
I'm sure you're right. The master's magic is going to be sold, so I think we need the advice of a magician.
[cpg cn=true]


Her name is Katharina.
[cpg]


We could go directly to her house. Then I can test the new product.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落』（昼）******************************************************



I had found Katharina's whereabouts by asking Arlaune in the village.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Catalina041"]
[OnName num="catalina"]
She said, "...... Oh. You even came to my house.
[cpg cn=true]


He looks a little sluggish, but it makes me smile to think that he is actually captivated by my product.
[cpg]


[OnName num="kurto"]
I wanted to thank you for the advice you gave me, Katharina.
[cpg cn=true]


[OnName num="kurto"]
"Would you be a tester for my new product?"
[cpg cn=true]


[FACE method="shake_5" pos="2/3"]
[VOICE f="Catalina042"]
[OnName num="catalina"]
Tester?　Me?
[cpg cn=true]


[OnName num="kurto"]
"Yes. I think you'd like to try it, too.
[cpg cn=true]


I went a little further and said so.
[cpg]


Katharina pretended to think about it for a moment, but I knew she wouldn't refuse.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sCatalina004"]
[OnName num="catalina"]
I had no choice but to give it a try.
[cpg cn=true]



;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『村』（夕方）******************************************************


With that, I walk back to the village.
[cpg]

Bianca was probably still working.
[cpg]


I still felt bad for Bianca.
[cpg]


She is so honest. I don't know why she is so devoted to me.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




Bianca came home at night. After a simple dinner, I invited her to my room.
[cpg]


[OnName num="kurto"]
She said, "...... you are too honest, aren't you?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca137"]
[OnName num="bianca"]
'Because I am the master's servant. What are you talking about now?
[cpg cn=true]


I was wondering why Bianca was so devoted to me.
[cpg]


I don't even know how she became a follower.
[cpg]


[OnName num="kurto"]
I don't even know how she came to be my squire. Why did you decide to serve me?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca138"]
[OnName num="bianca"]
It's a ...... long story. Do you mind?
[cpg cn=true]


[OnName num="kurto"]
I don't mind. I want to know more about Bianca.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Bianca139"]
[OnName num="bianca"]
I'll tell you more at ....... Then, I'll tell you.
[cpg cn=true]


From there, Bianca began to tell her story a little at a time.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Bianca140"]
[OnName num="bianca"]
My family has been in the service of the master's family, the Lammerzes, for generations.
[cpg cn=true]


[OnName num="kurto"]
I know that. But that doesn't make sense.
[cpg cn=true]


[OnName num="kurto"]
'Trying out something I've developed or ...... that reason alone doesn't explain it.
[cpg cn=true]


It's not surprising that they ran away from me when they fell out in the first place.
[cpg]


I wonder why they haven't given up on me.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca141"]
[OnName num="bianca"]
I have a younger brother.
[cpg cn=true]


[OnName num="kurto"]
What?　That's new news to me.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca142"]
[OnName num="bianca"]
If it were true, he would have been happy too.
[cpg cn=true]


[OnName num="kurto"]
I was ......, that's ......."
[cpg cn=true]


I choose my words carefully as I listen to what she has to say.
[cpg]


I heard that Bianca's brother was, of course, supposed to serve in the Lammerz family.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Bianca143"]
[OnName num="bianca"]
But he was too weak. And the skill he received at his baptismal ceremony was ...... surveying.
[cpg cn=true]


[OnName num="kurto"]
Surveying?　That's a skill I've never heard of.
[cpg cn=true]


Bianca looks a little pained. Throughout this entire conversation.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca144"]
[OnName num="bianca"]
'It's the skill of measuring things. It might be a good skill if you're going to be a craftsman,...... but I bet your parents thought you couldn't use it."
[cpg cn=true]


Just like me. I thought that much and didn't dare to say anything.
[cpg]


[OnName num="kurto"]
"...... so that's how it was?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Bianca145"]
[OnName num="bianca"]
"My brother, who was shunned by my parents and suffered for it, became ...... weaker and weaker, and in his last days he became ...... ill."
[cpg cn=true]


Bianca was on the verge of tears.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Bianca146"]
[OnName num="bianca"]
I'm sure you can already tell that I'm ...... seeing her image in my master's eyes.
[cpg cn=true]


Bianca was an honest follower. She never kept anything from me. She never hid anything from me.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca147"]
[OnName num="bianca"]
She said, "Master is what I want. For me, it's for her sake that I serve the master.
[cpg cn=true]


[OnName num="kurto"]
I didn't know. Thank you for telling me.
[cpg cn=true]


I have to do my best for Bianca's brother. I can't believe I'm hearing this. ......
[cpg]


[OnName num="kurto"]
I'm going to make it. I'm going to make it big."
[cpg cn=true]



[FACE method="bow_2" pos="2/3"]
;//ブラックアウト



I was determined to sell again tomorrow for Bianca and for Bianca's brother.
[cpg]


Not just for me anymore. It has to be successful for everyone but me.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************


I would set up a stall in town and sell steadily, and at the same time, I would negotiate with inns and other places to have them put my products on their shelves.
[cpg]

Of course, it was not that easy. The more expensive places tended to turn me down.
[cpg]


However, it seemed that the reputation of the first inn that placed the book was spreading to other inns.
[cpg]


We decided that even if we had to go a little farther, it would be worth the effort to have them place the books there, so we began to sell them on the idea.
[cpg]




;//ブラックアウト
[window target=false]
[BG f="b_09_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中の集落』（夕方）******************************************************



[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

He also talked with another collaborator, ...... Katharina.
[cpg]


I see her sitting on a chair outdoors, reading.
[cpg]


[OnName num="kurto"]
'Why are you reading here?　Your book looks like it might get sunburned."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Catalina075"]
[OnName num="catalina"]
She said, "This is a combination of sunbathing and reading. Sunlight is very important to the Arlaune people.
[cpg cn=true]


I can't decide if they are animals or plants. But still, ......
[cpg]


I feel like I can turn the pages so fast. I wonder if it is possible to read so quickly.
[cpg]


[OnName num="kurto"]
I wonder if it is possible to read so quickly.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Catalina076"]
[OnName num="catalina"]
I make my living by researching magic. It's only natural.
[cpg cn=true]


She was reading a book and responding to my questions.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Catalina077"]
[OnName num="catalina"]
I was given the skill of speed reading," she said. That's how I got into reading grimoires.
[cpg cn=true]


[OnName num="kurto"]
I see.
[cpg cn=true]


I understood. She was doing what she was doing for a good reason.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Catalina078"]
[OnName num="catalina"]
As a researcher, I can't overlook your magic and your products. It's really interesting.
[cpg cn=true]



[SE f="se000"]
;//【ＳＥ】『本閉じる』



[FACE method="bow_1" pos="2/3"]

Katharina slammed the book shut and complimented me.
[cpg]


Of course, I didn't feel bad. But ......
[cpg]


[OnName num="kurto"]
'No, then you know about ...... my skills, don't you?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Catalina079"]
[OnName num="catalina"]
'I don't know about your skills. I haven't even asked you what kind of skills you have."
[cpg cn=true]


[OnName num="kurto"]
I'm sure you've heard of Mischief-making Magic."
[cpg cn=true]


I wanted to make the skills that should not be available to use into something that is available. The reason for this is that I asked Katharina.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Catalina080"]
[OnName num="catalina"]
I asked her for that reason. If you want me to research it, I'll help you.
[cpg cn=true]


[OnName num="kurto"]
Please!"
[cpg cn=true]


I took Katharina's hand. She looked away for a moment.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



With that in mind, I asked Katharina-san to cooperate with me.
[cpg]


This time, it's not about developing a product, but about helping me figure out my skills.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="kurto"]
I can't overlook the power of the one who flips ...... skirts, can I?"
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Bianca148"]
[OnName num="bianca"]
I remember that power.
[cpg cn=true]


[OnName num="kurto"]
But this is a problem when it comes to being able to use it on someone in particular,......."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
Bianca doesn't seem to get it, so I go on to explain.
[cpg]


[OnName num="kurto"]
'When it comes to being able to see the panties of someone you like, you're not just selling something disreputable.'
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Bianca149"]
[OnName num="bianca"]
'...... sure, it could be abused.
[cpg cn=true]


[OnName num="kurto"]
"If it's bad, they could even put us out of business. ...... No, they could be punished right away.
[cpg cn=true]


We have to be very careful in this area. We will also need the cooperation of Ms. Katharina.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



When I talked to Katharina about it, she replied.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Catalina081"]
[OnName num="catalina"]
If it is a magic stone that has no effect on anyone in particular, there are only a limited number of places where it can be collected.
[cpg cn=true]


[OnName num="kurto"]
What do you mean by limited?
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Catalina082"]
[OnName num="catalina"]
It's a little hard to say,......, but yes.
[cpg cn=true]



[jump storage="ep005.ks" target="*start"]

;//=============================================================================
