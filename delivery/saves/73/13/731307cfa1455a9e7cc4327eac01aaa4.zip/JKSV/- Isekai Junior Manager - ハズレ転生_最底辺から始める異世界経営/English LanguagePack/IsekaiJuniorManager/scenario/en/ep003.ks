
*start

;#################################################
*Ep003|World's Best in Inventions
;#################################################

[SCENE id=3]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca059"]
[OnName num="bianca"]
Good morning. Master."
[cpg cn=true]


[OnName num="kurto"]
Good morning. "
[cpg cn=true]


I had made up my mind. I couldn't just stand by and do nothing.
[cpg]


[FACE method="change_1" pos="2/3"]

[OnName num="kurto"]
"Look, Bianca," I said, "I've made up my mind. I've made up my mind.
[cpg cn=true]


[OnName num="kurto"]
I'm going to make a purer invention. I'm going to be the best in the world at it.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sBianca002"]
[OnName num="bianca"]
But, but ......
[cpg cn=true]


[OnName num="kurto"]
"There were things in the world before my reincarnation. Various things.
[cpg cn=true]


The first thing that comes to mind is a massage machine.
[cpg]

I've always wondered if I could use my skills to make one.
[cpg]

Not only could I flip skirts, but I could make objects tremble, which is a bonus.
[cpg]

[OnName num="kurto"]
I can do it. ...... can do it."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]

I was soaring. Bianca was looking at me with an indescribable look on her face.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



Later that evening, after we both finished work, we talked again. After we both finished work, we talked again.
[cpg]



[OnName num="kurto"]
There was a massage machine. Some people used them in strange ways.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Bianca065"]
[OnName num="bianca"]
"Haa......"
[cpg cn=true]


Mechanical civilization is next to nonexistent. The only limit is to make clocks.
[cpg]


But can't we use magic as a driving force? My skills only make objects tremble. ......
[cpg]


[OnName num="kurto"]
I can't contain my magic in something, like paper or stone. Paper, stone..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Bianca066"]
[OnName num="bianca"]
I can't do that," he said. It's something that can contain the power of your skills.
[cpg cn=true]


[OnName num="kurto"]
I knew it. Then we can make it.
[cpg cn=true]


The power to vibrate an object is contained in a magic stone.
[cpg]


The outer shell should be made of wood or something else. We can't hit the stone directly, can we?
[cpg]


[OnName num="kurto"]
Does a magic stone have the power of ...... skill in it?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Bianca067"]
[OnName num="bianca"]
It depends. It is common for the power to be activated when the stone is shattered.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca068"]
[OnName num="bianca"]
I'm sure you can find it using my collecting skills, though. ......
[cpg cn=true]


Bianca is very reliable.
[cpg]


[OnName num="kurto"]
Then let's go look for it right away.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Bianca069"]
[OnName num="bianca"]
'Well,...... if the master says so, I can help you.
[cpg cn=true]


Bianca didn't seem too keen on the idea. I don't think my inspiration was fully conveyed.
[cpg]


I think she was not really impressed with the finished product to begin with.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_12_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



So, it was nighttime. Bianca was off tomorrow, so we came to look for the magic stone.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Bianca070"]
[OnName num="bianca"]
...... there's a sign of a vein of ore coming from this direction.
[cpg cn=true]


[OnName num="kurto"]
'That's a hell of a skill to have. You could make a lot of money just doing this.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca071"]
[OnName num="bianca"]
No way. This kind of magic stone can be found anywhere.
[cpg cn=true]


It is even more helpful. There is no shortage of materials.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



The next day. I immediately tried to make the first prototype, but ...... however.
[cpg]


[OnName num="kurto"]
"Chipping wood is harder than I thought it would be.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca072"]
[OnName num="bianca"]
I guess so. That's enough to make a job out of it.
[cpg cn=true]


Bianca is talking about crafts. I'm not trying to make something like that, but ......
[cpg]


[OnName num="kurto"]
I think I've got it in shape now. But ......"
[cpg cn=true]


I made the outside, but how do I confine the magic stone?
[cpg]


I have to put the crushed magic stone inside. So it has to be a system that can be covered with this outer shell and immediately trapped.
[cpg]


[OnName num="kurto"]
I know there is something like ...... glue in this world."
[cpg cn=true]


I think there are things similar to glue, even if they are not as effective as glue.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="sBianca003"]
[OnName num="bianca"]
You mean something that holds things together?　But ......"
[cpg cn=true]


[OnName num="kurto"]
What's the matter? You got something to say, say it.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="sBianca004"]
[OnName num="bianca"]
If you're going to put it against someone's skin, I think a material that sticks together easily is a bad idea.
[cpg cn=true]


I see. It would be a problem to wait until it sticks to the skin.
[cpg]


[OnName num="kurto"]
What kind of structure should I make ......?"
[cpg cn=true]


I stumbled on the first step. I had to think about it before building the outer shell.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



The ideas I needed to get from there were more than just memories of a previous life.
[cpg]


I really felt like an inventor. It's hard to come up with something like this.
[cpg]


I was in the middle of thinking, "If anything, being a chef is a shorter way to .......
[cpg]


[OnName num="kurto"]
"...... Oh, screws."
[cpg cn=true]


I had an epiphany. I thought it would be a good idea to separate the upper and lower shells and make them fit together when twisted.
[cpg]



[FACE method="change_7" pos="2/3"]
[VOICE f="Bianca075"]
[OnName num="bianca"]
I see. ...... that might be a good idea, but it would require a lot of precision.
[cpg cn=true]


You are absolutely right. But we have to do it.
[cpg]


[OnName num="kurto"]
There is no other way. It's easy to say I can't make it, but I can't give up.
[cpg cn=true]


Saying that, I looked at Bianca.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca076"]
[OnName num="bianca"]
'Somehow, you seem to have a twinkle in your master's eye.
[cpg cn=true]


Bianca laughed a little. Did she understand even a little bit of what I'm aiming for?
[cpg]


Or did she really just laugh in anticipation ...... I don't know about that.
[cpg]




;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bgm_05"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



From there I went on to make it, even while I slept.
[cpg]


I used a magic stone whose power is activated when it is shattered, and covered the outside with wood.
[cpg]


I used materials found by Bianca's gathering skills. This way, they could make a large quantity.
[cpg]


At first, I cursed my lack of dexterity, because just making the outer shell was a big job, but....
[cpg]

[free time=800]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kurto"]
"It's done. ......
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca077"]
[OnName num="bianca"]
Yes. If I put a magic stone inside of this, is it complete?
[cpg cn=true]


[OnName num="kurto"]
In theory, yes. Let's give it a try.
[cpg cn=true]


First of all, I put my skill into the magic stone. This can be done with a simple thought, just like when I activate my skills.
[cpg]


I crushed the magic stone into a small outer shell.
[cpg]



[SE f="se013"]
;//【ＳＥ】『振動音』
[WAIT time=1000]


[OnName num="kurto"]
...... something, the vibrations are weak."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Bianca078"]
[OnName num="bianca"]
Is that so?
[cpg cn=true]


Is the magic stone too small? Or the outer shell is too thick.
[cpg]


[OnName num="kurto"]
Maybe the vibration wasn't this weak,...... it's the size of the stone."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca079"]
[OnName num="bianca"]
Come on,...... because I've never seen one."
[cpg cn=true]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



I thought this was not good enough, so I cut it down further.
[cpg]


[FACE method="shake_5" pos="2/3"]
When I made the outer shell as thin as possible, this time there was a happening that the outer shell would shatter.
[cpg]


[FACE method="change_7" pos="2/3"]
It took a long time to find the right thickness.
[cpg]




;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bgm_03"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



But finally, our efforts were about to pay off.
[cpg]


I could put a magic stone inside. And it wouldn't shatter. The first practical one was ready.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="sBianca005"]
[OnName num="bianca"]
I said, "Well, if it's in stick form, it could be used on your back. ...... But why did you paint it gray?"
[cpg cn=true]


[OnName num="kurto"]
No, it's just something ...... like that."
[cpg cn=true]


I was saying that, but I was happy that it was finished.
[cpg]


And with the joy of completion comes another emotion.
[cpg]


[OnName num="kurto"]
But will you really feel good using it?
[cpg cn=true]


[OnName num="kurto"]
'It feels like it would work for my back and stuff, but I wonder if other people would think the same .......'
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sBianca006"]
[OnName num="bianca"]
If you want to ......, I can be your test subject.
[cpg cn=true]


[OnName num="kurto"]
Is that okay?"
[cpg cn=true]




;//ブラックアウト


[FACE method="bow_1" pos="2/3"]

She nods to my question and lies down on the bed.
[cpg]


;//========================================
;//●ＣＧ（ベッドの上に寝転がるヒロイン）ev_01
;//人物１：ヒロイン４　服装１：着衣
;//場所　：主人公の部屋
;//時間　：夜
;//備考　：ローターにはひもがついていません。また、ピンク色をしています
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bgm_09"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//[SE f="se010"]
;//【ＳＥ】『ローターの振動音』

[VOICE f="sBianca007"]
[OnName num="bianca"]
Bianca was still not quite sure what kind of posture she was supposed to use.
[cpg cn=true]


Bianca doesn't seem to understand yet, so she puts on this outfit.
[cpg]

This changes the meaning when it comes to using the massager. ......
[cpg]

[OnName num="kurto"]
Bianca: "Just sit like a normal person, with your back to me."
[cpg cn=true]


[VOICE f="sBianca008"]
[OnName num="bianca"]
Ha, yes."
[cpg cn=true]



;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


What a trouble. ......
[cpg]


We got it to the stage where we could put it out as a product. Now all I have to do is ......
[cpg]



[OnName num="kurto"]
I think it's ...... a thing once it's done. But will it sell?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca109"]
[OnName num="bianca"]
It will sell. I didn't think it would feel that good either."
[cpg cn=true]


With Bianca's encouragement, I made up my mind.
[cpg]


There is no way this will not sell. Each one is handmade and takes a lot of time and effort, but ...... there is definitely a demand for them.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_11_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



So, the next day.
[cpg]


[window target=false]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]

The next day, I went to a stall.
[cpg]


So I tried to sell them at a stall,......, but.
[cpg]


[OnName num="male_customer"]
What is this?　I've never seen this before.
[cpg cn=true]


[OnName num="kurto"]
"Yes, it's called a massage machine. ......
[cpg cn=true]


[OnName num="male_customer"]
"A massage machine. That's a strange name.
[cpg cn=true]


[OnName num="kurto"]
You put a magic stone inside and it vibrates.
[cpg cn=true]


[OnName num="male_customer"]
......?　What do you use that for?
[cpg cn=true]


[OnName num="kurto"]
"It's for stiff shoulders."
[cpg cn=true]


The customer's expression became dubious.
[cpg]


[OnName num="male_customer"]
...... that's fishy."
[cpg cn=true]


Customers come up to me with curiosity, but as soon as I ask them how they use it, they leave.
[cpg]


In the end, while I was tending to the store, the sales were slight but meager.
[cpg]


I was only charging a low price to spread my name, so it wasn't very profitable.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Bianca112"]
[OnName num="bianca"]
'So that's all the sales I've made .......'
[cpg cn=true]


[OnName num="kurto"]
"Oh well,...... what shall we do for dinner today?"
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="kurto"]
'......I'm hungry.'
[cpg cn=true]


I have enough money from Bianca's work at the saloon.
[cpg]


But as long as I'm going to be a businessman, I can't be in another business.
[cpg]


I can't help it. I can't help it, but I'm hungry.
[cpg]


Bianca is probably hungry too. I don't want her to live like this for too long.
[cpg]

[jump storage="ep004.ks" target="*start"]


;//=============================================================================
