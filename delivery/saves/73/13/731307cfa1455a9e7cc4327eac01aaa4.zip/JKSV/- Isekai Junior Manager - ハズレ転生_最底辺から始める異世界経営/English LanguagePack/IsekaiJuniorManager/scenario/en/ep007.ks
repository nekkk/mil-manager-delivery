
*start

;#################################################
*Ep007|Pioneering New Products
;#################################################

[SCENE id=7]


[stflag Tai_sil = 0]

[if exp={getFlagValue("Tai_sil") == 0 }]
[stflag Tai_sil = 1000]
[endif]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



Days pass. They seemed to make sense, not just to ramble on.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Edith041"]
[OnName num="edith"]
"Ugh, how are sales ...... going?"
[cpg cn=true]


[OnName num="kurto"]
I told you before. It's going too well.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Edith042"]
[OnName num="edith"]
I'm glad ...... that what I made is selling, too.
[cpg cn=true]


Mr. Edith seemed really happy.
[cpg]


It's as if the joy is propagating the joy.
[cpg]


After receiving my share of this week's sales, I headed back to the store.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



And then, a few days passed.
[cpg]


I had a wide assortment of inventions, and I was also dabbling in the field of medicine.
[cpg]

With medicines, if I could hide the part where I obtained the ingredients, it would be difficult for others to imitate me.
[cpg]

I was trying to make a medicine from my hazy knowledge when I received an order from .......
[cpg]


[OnName num="kurto"]
I was trying to make a medicine from my hazy knowledge when I received an order like this: "Fertility medicine ......?　It's a quirk, but I don't think we can handle it ......."
[cpg cn=true]


The client was a man who said to me, "Why don't you try to make it once? The client was a man who said so.
[cpg]


The last name he gave was ...... Hering.
[cpg]


[OnName num="kurto"]
He said, "Herring ......?　which means, aristocrat?"
[cpg cn=true]


He nodded. Then I decided to ask a little more.
[cpg]


[OnName num="kurto"]
"Is Arma's father ...... by any chance?"
[cpg cn=true]


[OnName num="alma's_father"]
He nodded. Are you acquainted with Arma?
[cpg cn=true]


[OnName num="kurto"]
"......."
[cpg cn=true]


What a coincidence, I thought, but also a curious request.
[cpg]


[OnName num="kurto"]
I thought, "Arma is your daughter, isn't she?　What do you mean by fertility treatment?
[cpg cn=true]


[OnName num="alma's_father"]
I don't know if this is something I need to go into too much detail about, but you're not her ...... real father, are you?
[cpg cn=true]


I see. That is indeed a complicated story.
[cpg]


As I listened further, I learned that Arma was apparently an adopted daughter and that he was not her biological parent either.
[cpg]


I was told that she was adopted because of her skills as a military commander.
[cpg]


[OnName num="kurto"]
"Arma's father, ......, do you remember me?"
[cpg cn=true]


[OnName num="alma's_father"]
I was told, "...... No. I'm sorry, did you meet him somewhere? I'm sorry, do I know you?
[cpg cn=true]


It was as if she didn't remember me. It was okay.
[cpg]


It is not that I have nothing to do with Mr. Arma. I would like to cooperate if I can.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


It was closing time, and I was feeling like I couldn't hold it alone.
[cpg]


Somehow, I found my way to Mr. Edith's place.
[cpg]



[free time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



[FACE method="shake_7" pos="2/3"]
[VOICE f="Edith043"]
[OnName num="edith"]
"......So, such a thing ......happened."
[cpg cn=true]


[OnName num="kurto"]
I know that's true,......, but I don't have any knowledge of pharmacology.
[cpg cn=true]


I couldn't make a fertility drug at any price. I couldn't even imagine the ingredients.
[cpg]


[OnName num="kurto"]
 "I don't know about the common infertility treatment in this world."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Edith044"]
[OnName num="edith"]
......What do you mean, in this world?"
[cpg cn=true]


I guess I haven't told Mr. Edit yet. Oh well.
[cpg]


[OnName num="kurto"]
For example,......, there is the timing method, isn't there? It's called fertility treatment.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sEdith002"]
[OnName num="edith"]
I've told my ...... client, who's never heard of it.
[cpg cn=true]


I see. Is that much knowledge not in this world?
[cpg]


It could be possible. Because medical care is not developed at all in the first place.
[cpg]


It would be a world where statistics are hard to come by. I think the knowledge that is common knowledge in my world may be surprisingly useful.
[cpg]


[OnName num="kurto"]
I'll talk to him next time. I'll talk to them next time.
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



So I gathered all the knowledge I could remember and gave all the advice I could.
[cpg]


[OnName num="kurto"]
I've heard that eating a diet mainly of vegetables is rather bad," he said. You should take vitamin E, or zinc if you are a man..."
[cpg cn=true]


[OnName num="alma's_father"]
"Is ......zionc a ......?"
[cpg cn=true]


Is there a vitamin, or at least a vitamin, in this world? I don't know, but they have to try everything now.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_08"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



[OnName num="kurto"]
I wonder if ...... will work.
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]
[VOICE f="sBianca013"]
;//[VOICE f="Bianca225"]
[OnName num="bianca"]
I don't know. It is quite possible that what is common knowledge in the world where the master lived is inventive in this world.
[cpg cn=true]


Bianca is no longer in doubt about that.
[cpg]


[OnName num="kurto"]
I think that's true. Otherwise, this business wouldn't be doing so well.
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Catalina127"]
[OnName num="catalina"]
I know," she said. Your ideas always surprise me.
[cpg cn=true]


Today, Katharina was also at the store. She is a regular customer.
[cpg]


[OnName num="kurto"]
She is a regular customer. You come here without shopping.
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Catalina128"]
[OnName num="catalina"]
It doesn't matter. A researcher is all about a flash of inspiration.
[cpg cn=true]


But I don't think that's a good reason to skip work.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



Even so, Ms.Arma... I didn't think I'd be able to make contact after coming here.
[cpg]


I haven't seen her for a long time. I'm sure she doesn't remember me either. ......
[cpg]


[SE f="se022"]
;//【ＳＥ】『入店音』
[WAIT time=1000]

[OnName num="kurto"]
I was thinking, "What ......?"
[cpg cn=true]


But then the person showed up.
[cpg]



[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1000]
[VOICE f="Alma011"]
[OnName num="alma"]
"......."
[cpg cn=true]


She looks awkward and embarrassed. I guess that's because that's the kind of restaurant this is.
[cpg]

[free time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Bianca226"]
[OnName num="bianca"]
"It's been a while, Arma-sama.
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Alma012"]
[OnName num="alma"]
Yes, it's been a long time. ...... Bianca, was it?
[cpg cn=true]


[OnName num="kurto"]
What brings you here?
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Alma013"]
[OnName num="alma"]
I've heard rumors, Kurth. I heard you've been living as a merchant since you were kicked out of the Lammerz family.
[cpg cn=true]


[OnName num="kurto"]
Yes, yes. Yes, yes.
[cpg cn=true]


I really wonder why she came here. I don't think her father would dare to say.
[cpg]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Alma014"]
[OnName num="alma"]
I'm sure you deal in medicines as well. I have a favor to ask you."
[cpg cn=true]


And so, as I listened to the conversation, ...... it seemed that it was a bit of a misunderstanding, or rather, that both parents and children were thinking the same thing.
[cpg]


[FACE method="shake_4" pos="2/5"]
[VOICE f="Alma015"]
[OnName num="alma"]
My parents are worried about not being able to have children. I've always wanted to do something to help. ......
[cpg cn=true]


[OnName num="kurto"]
......"
[cpg cn=true]


It's like being told the same story twice. Such a coincidence, isn't it?
[cpg]


I guess it's more of a coincidence that parent and child are still parent and child, even if they are not blood related.
[cpg]


[OnName num="kurto"]
I'll leave it to you. Or rather, I have already received a request from your father.
[cpg cn=true]


[FACE method="change_5" pos="2/5"]
[VOICE f="Alma016"]
[OnName num="alma"]
What?　I see.
[cpg cn=true]


The first time I spoke to her in a long time, she somehow hadn't changed much.
[cpg]


Is there a point where it is because they are elves? Is there a point where life expectancy is different?
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



Anyway, I gave her what advice I could.
[cpg]


If this doesn't help, you'll need a doctor. ......
[cpg]


Since there is no such thing as infertility treatment in this world, I might be able to do something with just my idea.
[cpg]


I thought it was an optimistic imagination, but....
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



[OnName num="kurto"]
"Welcome to ...... ah, Arma-san."
[cpg cn=true]


I somehow understood by Arma's expression. She must have had a child, I thought.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=1000]
Approaching me, she took my hand.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Alma017"]
[OnName num="alma"]
She said, "Thank you so much for ....... My mother is expecting a child.
[cpg cn=true]


[OnName num="kurto"]
She said, "Oh, I see. That's good...... that my advice was worth it.
[cpg cn=true]


My knowledge has been put to good use. It's not about the invention, but I'm genuinely happy.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Alma018"]
[OnName num="alma"]
Kurth, you might want to ...... become a doctor.
[cpg cn=true]


I don't know about that. I don't think I can do it, but I know I'm appreciated.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Alma019"]
[OnName num="alma"]
I don't know how I can repay this favor. I'd still like to give something back.
[cpg cn=true]


[OnName num="kurto"]
"......"
[cpg cn=true]


It's a good thing I'm not asking for anything. I'm in the right place at the right time.
[cpg]

[free time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Bianca227"]
[OnName num="bianca"]
Master, I think it would be best if you ...... cooperate here," Bianca says.
[cpg cn=true]


Bianca said. I felt exactly the same way.
[cpg]


[OnName num="kurto"]
Arma, you know what kind of business ...... I'm in, don't you?
[cpg cn=true]


I asked Arma again. How could I not know?
[cpg]


[FACE method="change_7" pos="2/5"]
[VOICE f="Alma020"]
[OnName num="alma"]
I know ...... that you sell that kind of thing.
[cpg cn=true]


That doesn't explain anything, but he seems to understand.
[cpg]


[OnName num="kurto"]
I'd like you to help me with my business, if you would.
[cpg cn=true]


I wondered if Arma would take me up on the offer. I wonder if he would go that far, no matter how much he owes me. ......
[cpg]


[FACE method="bow_3" pos="2/5"]
[VOICE f="Alma021"]
[OnName num="alma"]
I'm sure he'd be willing to go that far. I'll do whatever I can to help.
[cpg cn=true]


[OnName num="kurto"]
I see. ...... Good.
[cpg cn=true]


Good. Now you've got the most powerful ally you could ever have.
[cpg]


Finally, we even have the help of the nobility. How should we develop our business from here?
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Arma seemed to have a lot of contacts in various places.
[cpg]


She had contacts in stores and inns located a bit far away.
[cpg]


There were stores that accepted my products. A portion of the profits would go to us.
[cpg]


[OnName num="kurto"]
It's like a dream ...... that it could work out this way."
[cpg cn=true]


With the help of the nobility, the scale of our business is growing.
[cpg]


From here, we're going to have to mass produce.
[cpg]


Maybe it's time to return the favor to the people who have helped me .......
[cpg]


I went to sleep thinking about this.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



So, what should I do today? It's not enough to just keep doing the same thing I've been doing.
[cpg]


On the other hand, is it one way to seek stability?
[cpg]


I thought about this and that, and then I thought about what I was going to do.
[cpg]


[FG f="ci_money.ui" method="window_in_1000" layer=20 pos="4/7" time=1]
[WAIT time=1000]


With the money, I will develop various new products and make my business successful!
[cpg]

Click on the icon with the key to spend money (sil) to develop new products!
[cpg]

;//開発をすれば商品の性能テストと言って女の子とエッチな事が出来るかも！？
If you develop a product, you may have an event with a girl to test the performance of the product!
[cpg]

However, money is very important for merchants.
[cpg]

If you run out of money, you might be in trouble...!
[cpg]

When you are low on money, we recommend 【FREE】, which does not cost you anything.
[cpg]

Become a big merchant and turn your life around!
[cpg]



;//silがマイナス、あるいはゼロになったときは、シナリオ末のゲームオーバーイベントに飛びます
;//本来の分岐先へは進みません


;//■選択肢
;//[SetSelGra 1]

[switch]
[case "Work steadily in business【FREE】."]
	[swap]
	[jump target="*select01_1"]
[case "Develop medicines for beasts【600sil】."]
	[swap]
	[jump target="*select01_2"]
[case "Mass-produce goods【FREE】."]
	[swap]
	[jump target="*select01_3"]
[endswitch]


1、Developing medicine for beastmen【600sil】 Developing medicine for beastmen【600sil
;//※アイコンは主人公の店の背景の画像
2、Develop medicines for beastmen（600sil consumed)
;//※アイコンはev_11の画像
3、Produce goods in large quantities (no sil consumption)
;//※アイコンは街の背景にヒロイン３の立ち絵を重ねた画像

;//==============================
;//１、商売を地道に頑張る（sil消費なし）
*select01_1|Developing new products


Right. After all, in this kind of thing, it is important to accumulate.
[cpg]


Creating new products is not the only way to do business.
[cpg]


Rather, what is important is how to sell the existing products.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



I've been struggling with how to successfully sell my existing products.
[cpg]


With the help of Bianca and Edith, things were going smoothly.
[cpg]


There are many ways to display products.
[cpg]



;//ブラックアウト



There is plenty of room to think. I am reminded that business is really very deep. ......
[cpg]


Customers are people, of course, so you can't just make things and put them on display.
[cpg]


I began to think more than ever about what they wanted.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落』（夕方）******************************************************



And after a while. I was on my way to Katharina's place.
[cpg]


[jump target="*select01_4"]

;//==============================
;//２、獣人用の薬を開発する（600sil消費）
*select01_2|Exploring new products.

;//ヒロイン４変数+1
[stflag Cha_Flg4 = 1]


Consume 600sil!
[cpg]


[SE f="se011"]
;//【ＳＥ】『お金増減』

[stflag Tai_sil = -600]


[FG f="ci_money.ui" method="cal_m600_1000" layer=20 pos="4/7" time=1]
[WAIT time=2000]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



[OnName num="kurto"]
'...... an electric massage machine, an amulet that lets you see the punching bag...... and then there's medicine.'
[cpg cn=true]


[OnName num="kurto"]
But don't we at least have medicine in this world?"
[cpg cn=true]



I asked Bianca. She thought for a moment and then said.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Bianca188"]
[OnName num="bianca"]
"There are some,......, but there are also,......."
[cpg cn=true]


[OnName num="kurto"]
What is it?　What is it?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca189"]
[OnName num="bianca"]
There is a tree that when a ...... beastie like me smells it, it puts me into a trance.
[cpg cn=true]


Heh, that's new to me. That's new to me. ......
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca190"]
[OnName num="bianca"]
It seems that if you boil it down, you can make an aphrodisiac for beastmen. ......
[cpg cn=true]


[OnName num="kurto"]
Is that so?　I'd love to have it in my store. Does it take skill or expertise to make it?"
[cpg cn=true]


Bianca ponders, saying, "I don't know.
[cpg]


Katharina might know a lot about this area. After all, it's Arlaune, I have a feeling she knows plants.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_04"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落』（昼）******************************************************



[FACE method="bow_1" pos="2/3"]
[VOICE f="sCatalina022"]
;//[VOICE f="Catalina123"]
[OnName num="catalina"]
Yes. I do, but do you want to make an aphrodisiac?　I can give you a tour.
;//「ええ。あるけど、媚薬を作りたいの？」
[cpg cn=true]


;//[VOICE f="Catalina124"]
;//「……私には全然効かないから、なんとも言えないけど……でも、案内するだけするわ」
;//[cpg cn=true]

[free time=1000]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="4/5" time=800]

[VOICE f="Bianca191"]
[OnName num="bianca"]
Wow, can I wait here at ......?
[cpg cn=true]


[OnName num="kurto"]
Why not?　Why don't you come too, Bianca?
[cpg cn=true]


Bianca shook her head. Maybe she knows the effects of that aphrodisiac.
[cpg]


[FACE method="shock_5" pos="4/5"]
[VOICE f="Bianca192"]
[OnName num="bianca"]
No, really, here. I don't mind."
[cpg cn=true]


[OnName num="kurto"]
'...... I see.'
[cpg cn=true]


I don't think I'm going to force her to go with me if she says that much.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



[FACE method="bow_2" pos="2/3"]
[VOICE f="Catalina125"]
[OnName num="catalina"]
'This is the tree. You'll recognize it because it has white flowers like these."
[cpg cn=true]


[OnName num="kurto"]
I was imagining something more dazzling than that.
[cpg cn=true]


I mean, I don't smell anything. I wonder if it really has the power to put you in a trance.
[cpg]


[OnName num="kurto"]
I mean, is this the right tree?　I don't smell anything.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Catalina126"]
[OnName num="catalina"]
Yes, it is. It is said to have a particularly strong effect on the berries, but if ...... you want, go ahead and pick some.
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中の集落』（昼）******************************************************




[VOICE f="Bianca193"]
[OnName num="bianca"]
"Ugh...... this smell......"
[cpg cn=true]


And then back to Bianca's again. It wasn't that he was harassing her, he was bringing back the fruit.
[cpg]


I just showed her what I had wrapped in a bag and I didn't think they smelled ......
[cpg]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Bianca194"]
[OnName num="bianca"]
Don't ...... let me near you."
[cpg cn=true]


It seemed to work so well that Bianca's respectful tone was peeled off.
[cpg]


[OnName num="kurto"]
'It's such a strong aphrodisiac. My bad."
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Bianca195"]
[OnName num="bianca"]
I'm sorry. I really can't."
[cpg cn=true]


Bianca's eyes were moist. I don't know what kind of effect it has, but I do know that it does something.
[cpg]


But I know it works in some way.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



Normally, I would be sorry, and I meant what I said when I said I was sorry.
[cpg]


But I thought Bianca's reaction made it all the more worthwhile.
[cpg]


[OnName num="male_customer"]
'An aphrodisiac for beastmen, or ...... I know someone who knows a lot about that.
[cpg cn=true]


[OnName num="kurto"]
Really?　I'd love to learn how to make it.
[cpg cn=true]


[OnName num="male_customer"]
But I don't think he'd teach me for free.
[cpg cn=true]


[OnName num="kurto"]
I don't mind. I want to make this one for sure.
[cpg cn=true]


While listening to these stories, I was also working on developing an aphrodisiac.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I tried it out in my room. Eventually, it began to take shape.
[cpg]


It was so good that I could call it a finished product, and I called out to Bianca.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kurto"]
"Oh, Bianca. It's finished.
[cpg cn=true]


[FACE method="shake_5" pos="2/3"]
[VOICE f="Bianca196"]
[OnName num="bianca"]
"Finished?
[cpg cn=true]


[OnName num="kurto"]
This is it. I thought about it a lot, but I made it into a powder," she said.
[cpg cn=true]


He opened the lid of the bottle. She was getting redder and redder.
[cpg]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Bianca197"]
[OnName num="bianca"]
"No, don't ...... close the lid, please."
[cpg cn=true]


[OnName num="kurto"]
She said, "Well, don't say that. Don't say that. Just tell me if it's working.
[cpg cn=true]


Bianca fell into a heap as she said, "It's working, it's working.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Bianca198"]
[OnName num="bianca"]
It's working, it's working. Really, stop."
[cpg cn=true]


[OnName num="kurto"]
I said, "Okay, that's good then. ...... is that Bianca?"
[cpg cn=true]


Bianca's eyes were funny. I was pushed down to the floor.
[cpg]



[FG f="CHA04_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Bianca199"]
[OnName num="bianca"]
'Master ...... hah, hah, master!'
[cpg cn=true]


;//ブラックアウト

;//========================================
;//●ＣＧ（主人公に襲いかかりそうになるヒロイン）ev_11
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bgm_09"]
;**【ＣＧ】 ev_11_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


The color of her eyes is different. I may have gone a little overboard.
[cpg]

I've been looking for something like this for a long time. This is what I've been looking for all along.
[cpg]

She is about to kiss me. Maybe this is the ending I've been looking for.
[cpg]

And then ...... our lips touch.
[cpg]

At that moment, I felt like I had finally come this far.
[cpg]


;//移植のためシーンをカットしています




;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


After our lips parted, she came to herself just a little and said
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Bianca223"]
[OnName num="bianca"]
'...... forget it. It's wrong for me, your squire, to do this."
[cpg cn=true]


I couldn't respond. I could not respond.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



No matter what happened, no matter what I did, the next day would come.
[cpg]


I had to sell the aphrodisiac as long as I made it.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Bianca224"]
[OnName num="bianca"]
I said, "Good morning, ....... Master."
[cpg cn=true]


[OnName num="kurto"]
"Oh, good morning."
[cpg cn=true]


Bianca looks awkward. That's right. ......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



The store is thriving. Still, I couldn't get yesterday out of my head.
[cpg]


What was the right thing to do? That's all I can think about.
[cpg]


I was somewhat resentful that the aphrodisiac for beasts was selling well.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中の集落』（夕方）******************************************************

After a while, I went to see Katharina. I was on my way to Katharina's place.
[cpg]


[jump target="*select01_4"]


;//==============================
;//３、商品を大量生産する（sil消費なし）
*select01_3|Exploring new products


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



The days were hectic. However, it seemed to be a good thing.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

When I went to Edith's place, there was a change in her, too.
[cpg]


In short, it was no longer possible for Edith to run the business on her own.
[cpg]


She took on apprentices and began to share the responsibility of making things.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Edith047"]
[OnName num="edith"]
I ...... have never done so much work.
[cpg cn=true]


[OnName num="kurto"]
I'm sorry to bother you. I'm sorry to bother you, but I'll pay you well.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Edith048"]
[OnName num="edith"]
She said, "I don't mean to be a nuisance. I can't thank you enough. I can't thank you enough.
[cpg cn=true]


It seemed that Ms. Edith was becoming more and more fond of me.
[cpg]


She seemed to be taking a special interest in me. ......
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Edith049"]
[OnName num="edith"]
I want to do anything you say. I want you to tell me you love me."
[cpg cn=true]


It seems that Edith is not a good talker. He says it frankly.
[cpg]


[OnName num="kurto"]
......"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Edith050"]
[OnName num="edith"]
Bianca isn't here today,......, and she did that on purpose.
[cpg cn=true]


I didn't intend to do that, I just asked Bianca to look after the store.
[cpg]

[FG f="CHA03_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
But Ms. Edit approached me.
[cpg]


And I close my eyes. I wasn't sure what to do.
[cpg]


How do I feel about Mr. Edith? I think it is important to know what kind of action to take.
[cpg]


I shouldn't approach her if I don't like her. But she's probably waiting for a kiss.
[cpg]


......I couldn't push her away here and now.
[cpg]



[FACE method="change_2" pos="2/3"]
[VOICE f="Edith051"]
[OnName num="edith"]
"Mmmm......... chu-chu..."
[cpg cn=true]


The traffic. The first thing you need to do is to make sure that you have the right tools and the right people to help you.
[cpg]


But I didn't care. I wanted to do what Ms. Edit wanted.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Edith052"]
[OnName num="edith"]
The first time I kissed him, it was for the first time. Ah, for the first time, I kissed him.
[cpg cn=true]


[OnName num="kurto"]
"......, was that so?"
[cpg cn=true]


The first kiss was stolen from Edith.
[cpg]


It was with a bit of regret and a feeling of fulfillment that was incomparable to that.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落』（夕方）******************************************************



[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Catalina129"]
[OnName num="catalina"]
I was so happy to see that ...... had happened. No wonder you're so flirtatious."
[cpg cn=true]


Katharina questioned me, and I told her a glimpse of what had happened with Mr. Edith.
[cpg]


She looked indescribable. I thought for a minute that maybe she was jealous.
[cpg]


;//==============================
*select01_4|Exploring new products



[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Catalina132"]
[OnName num="catalina"]
'So, about the magic stone, ...... we've found a new vein of ore.
[cpg cn=true]


[OnName num="kurto"]
She said, "Really? That's good to hear, because we're going to need more and more of them.
[cpg cn=true]


As for the collection of magic stones, Katharina-san and the Arlaune tribe began to help us.
[cpg]


The village of the Arlaune tribe, where Katharina lives, was a poor village with no financial resources of its own.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Catalina133"]
[OnName num="catalina"]
Bianca helped us," she said. I think it was her collecting skills that came in handy. It's very useful.
[cpg cn=true]


[OnName num="kurto"]
I'm sure it is. But it was good for the village.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Catalina134"]
[OnName num="catalina"]
Yes. Yes, your business is making us all feel better. Thank you.
[cpg cn=true]


Katharina seemed to be expressing her honest gratitude.
[cpg]


I am also grateful to her. Everything is going well. ......
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



Bad things tend to overlap. Good things happen sparsely.
[cpg]


I've always been a pretty big believer in that, but recently there's been a lot of good news.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[OnName num="kurto"]
I asked, "What's the new material ......?　What is it?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Alma022"]
[OnName num="alma"]
I heard it's called ...... resin, and it's supposed to be soft and unbreakable.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]

[OnName num="kurto"]
Really?
[cpg cn=true]


I unintentionally shouted out loud to Arma.
[cpg]


The resin is that resin, right? If that's the case, then ......
[cpg]

[free time=1000]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Bianca228"]
[OnName num="bianca"]
I asked, "Um, what's wrong?　Master."
[cpg cn=true]


[OnName num="kurto"]
'What timing, it's like a discovery for me.
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Bianca229"]
[OnName num="bianca"]
Are you familiar with the resin thing, Master?"
[cpg cn=true]


Bianca asked and I nodded.
[cpg]


The processing technology may not be developed yet, but I know how to use it in any number of ways.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



I was visiting Edith's place again.
[cpg]


Arma had given me a certain amount of a material called resin. At times like this, it is strong to have a connection with the nobility.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Edith055"]
[OnName num="edith"]
Resin. It is certainly an interesting material. I have never handled it before.
[cpg cn=true]


Mr. Edith seemed to be fascinated by the new material.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Edith056"]
[OnName num="edith"]
'So ...... what should I make this time?
[cpg cn=true]


[OnName num="kurto"]
......, yes.
[cpg cn=true]

To some extent, I had an idea of something made of resin. But.
[cpg]

[OnName num="kurto"]
I thought, "Can't you make it in the shape of a ring? Can you make it in the shape of a ring, so it can expand and contract?
[cpg cn=true]


The first thing I was trying to make was a rubber band.
[cpg]

In this world, there is nothing similar to rubber bands. There is definitely a demand for it.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="sEdith003"]
[OnName num="edith"]
I'm going to go to ...... and call some people I know, and I'd like to hear more about it."
[cpg cn=true]


I say "acquaintance," but in essence she is my apprentice. She didn't seem to want to be called an apprentice.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



Some days and nights pass again.
[cpg]


In the meantime, there is still a certain amount of sales of past inventions and medicines.
[cpg]


In fact, since they were sold in places other than where they were usually sold, the number of fans kept on growing.
[cpg]


[jump storage="ep008.ks" target="*start"]

;//=============================================================================


