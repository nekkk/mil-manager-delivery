
*start

;//異世界で俺はエロ経営のトップになる！　シナリオ



;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり



;//アルマ　　　　　着衣
;//ユイカ　　　　　着衣
;//エーディト　　　着衣
;//ビアンカ　　　　着衣
;//カタリーナ　　　着衣



;//上記以外のキャラクターには音声がありません



;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//アルマ　　　　　一人称「私（わたし）」　ユイカ呼び「ユイカさん」　エーディト呼び「エーディトさん」
;//　　　　　　　　ビアンカ呼び「ビアンカさん」　カタリーナ呼び「カタリーナさん」　クルト呼び「クルトさん」
;//ユイカ　　　　　一人称「私（わたし）」　アルマ呼び「アルマ」　エーディト呼び「エーディト」
;//　　　　　　　　ビアンカ呼び「ビアンカ」　カタリーナ呼び「カタリーナ」　クルト呼び「クルト」
;//エーディト　　　一人称「あたし」　アルマ呼び「アルマさん」　ユイカ呼び「ユイカさん」
;//　　　　　　　　ビアンカ呼び「ビアンカさん」　カタリーナ呼び「カタリーナさん」　クルト呼び「クルトさん」
;//ビアンカ　　　　一人称「私（わたし）」　アルマ呼び「アルマ様」　ユイカ呼び「ユイカ様」
;//　　　　　　　　エーディト呼び「エーディト様」　カタリーナ呼び「カタリーナ様」　クルト呼び「クルト様」→「ご主人様」
;//カタリーナ　　　一人称「私（わたし）」　アルマ呼び「アルマさん」　ユイカ呼び「ユイカさん」
;//　　　　　　　　エーディト呼び「エーディトさん」　ビアンカ呼び「ビアンカさん」　クルト呼び「クルトさん」
;//クルト　　　　　一人称「俺」　アルマ呼び「アルマさん」　ユイカ呼び「ユイカさん」
;//　　　　　　　　エーディト呼び「エーディトさん」　ビアンカ呼び「ビアンカ」　カタリーナ呼び「カタリーナさん」
;//　　　　　　　　ただし、各キャラルート分岐後に呼び捨てになる場合もある


;//以下、残したCGを列挙します
;//アルマ      16 18 21 22 31
;//ユイカ      12 32 38 46 70
;//エーディト  33 62 64 66 69
;//ビアンカ    01 11 13 34 54
;//カタリーナ  07 10 56 57 63

;//	       01 07 10 11 12
;//	       13 16 18 21 22
;//	       31 38 32 46 70
;//	       34 54 56 57 63
;//	       62 64 33 66


;#################################################
*Ep000|I feel like I have a happy future.
;#################################################

[SCENE id=0]


[stflag Select5 = 0]


;//////////////////////////////////////
;///////////////以下本編///////////////
;//////////////////////////////////////



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[stflag Tai_sil = 0]

[stflag Cha_Flg1 = 0]
[stflag Cha_Flg2 = 0]
[stflag Cha_Flg3 = 0]
[stflag Cha_Flg4 = 0]
[stflag Cha_Flg5 = 0]


It all started with that incident.
[cpg]




;//回想なので、色調をセピアにしてください



[FADEOUTBGM]
[window target=false]

[BG f="b_05_5.ui" time=1000]
[WAIT time=2000]
[CHANGEWIN target=0]
[window target=true]
[WAIT time=100]

[BGM f="bgm_07"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（過去）******************************************************
;//【ＢＧ】『街＿現代』（夕方）


I am a temporary worker with no special characteristics. If I lived modestly, I would have no trouble making a living.
[cpg]

I was now wondering about something. It was ...... whether or not to throw away the memento of my girlfriend.
[cpg]

After much hesitation, I decided that day to stop being tied down by the past.
[cpg]


Throw away the things of the past, throw away the unfinished business. Something good will surely happen to me today.
[cpg]

I went to work feeling like a reborn person, but I didn't think I was really going to be reborn at that moment.
[cpg]



[SE f="se005"]
;//【ＳＥ】『急ブレーキ』



I think I was obeying the traffic rules. But I heard the brakes.
[cpg]


It's not often that you get hit by a car. That one time could have been the end of my life.
[cpg]




;//ブラックアウト

[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

I was ready to get a fresh start and get on with my work today, but it was too much.
[cpg]

I am not a religious person. I don't really believe in heaven or hell.
[cpg]

But I was still disappointed. I couldn't accept the end quietly in the pitch dark.
[cpg]

Is this the end?　Really?　Are you kidding me?
[cpg]

I screamed in the darkness. If I was going to die, I wanted to start my life over.
[cpg]

But even though I screamed, I couldn't hear my own voice.
[cpg]

Besides, if I were to start over, where would I start from?　I can't go back in time and pretend my life never happened.
[cpg]

If that's the case, I'd rather be reborn somewhere else, somewhere not in ...... this world!
[cpg]


;//画面徐々に白く
[FADEOUTBGM]
[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1000]
;//ホワイトアウト



And gradually, my eyes light up. There I heard something joyful and celebratory.
[cpg]


I understand. Sight and hearing gradually become clearer.
[cpg]


I knew that I was a baby, while I could not speak anything.
[cpg]


While I was not clear, I knew that I was not in Japan.
[cpg]

...... It's really the second time around in my life. If I were to be reincarnated in another world, I feel like I could even be a Musou.
[cpg]

I feel like there would be a happy future this time.
[cpg]



;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト



I told my ex-girlfriend. I feel like there will be a happy future.
[cpg]

Looking back, I think that kind of naive thinking was at the root of everything.
[cpg]






[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『屋敷＿室内』（朝）******************************************************



The months passed from there.
[cpg]


[OnName num="kurto"]
Kurth , ....... Kurth Lammertz is my name.
[cpg cn=true]


It doesn't feel right. I think I had another name.
[cpg]



But for the life of me, I can't remember it.
[cpg]

The name Schwende, the name of this world, also somehow doesn't fit in my consciousness.
[cpg]

Something in the past, like I had a different life ......
[cpg]



;//下記セリフの名前を？？？と隠してください



[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Bianca001"]
[OnName num="unknown"]
'Dear Kurth,...... you look troubled again.
[cpg cn=true]


[OnName num="kurto"]
"Oh ...... Bianca. There you are."
[cpg cn=true]


She is Bianca. She's one of the maids, and she's been taking especially good care of me.
[cpg]


[OnName num="kurto"]
I'm trying to remember something. What is this memory?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Bianca002"]
[OnName num="bianca"]
I don't know. ...... Maybe it's a memory of a past life or something?"
[cpg cn=true]


[OnName num="kurto"]
I know there are religions that believe in that, but is there really such a thing as reincarnation?
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca003"]
[OnName num="bianca"]
I would like to serve Kurth again if I am reincarnated.
[cpg cn=true]


Bianca answered with a big smile.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



Kurth Lammertz. Kurth is his first name and Lammertz is his last name.
[cpg]


He is the third son of the Lammertz family. I am the youngest of three brothers.
[cpg]


The first son is Emil. The second son is Joseph. All of them have the image of a mean older brother.
[cpg]


If I had to say, I would say that Joseph was a little bit kinder to me. But we didn't cooperate with each other.
[cpg]


When you are an aristocrat and have male siblings, you can't help but think about the struggle for power.
[cpg]


[OnName num="emile"]
I never thought you would come of age," he said. I thought that day would never come.
[cpg cn=true]


[OnName num="kurto"]
"What do you mean, ......?"
[cpg cn=true]


[OnName num="josef"]
You didn't think you'd ever reach that age. Hey, brother.
[cpg cn=true]


[OnName num="emile"]
Kurth's always been a child. I don't get the impression that he's coming of age."
[cpg cn=true]


I was obviously being made fun of, but I believed in a reversal of fortune. Today was the long awaited baptismal ceremony.
[cpg]


It's a ceremony where God gives you one skill when you come of age.
[cpg]


You never know what you will get. Some say it depends on your life, deeds, and faith up to that point, while others say it is completely innate.
[cpg]


As the youngest child, I was in a weak position as the heir to the family, and I had neither sword skills nor magical talents.
[cpg]


It is a sad story that I can say it myself, but I will change it from here.
[cpg]


[SE f="se014"]
;//【ＳＥ】『歩く』


As I walked along, I arrived at the front of the church. I swallowed a mouthful of saliva.
[cpg]


My father and mother are following me. But I was the only one going into the church.
[cpg]


[OnName num="kurto's_father"]
Come on in," he said. I wish you good luck.
[cpg cn=true]


[OnName num="kurto's_mother"]
I feel the same way. Go ahead.
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tobira2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//ブラックアウト



So I go into the church and I'm baptized.
[cpg]


Please, I want a skill that I can use, even if it's not a sword or magic ....... I greeted the ceremony with a wish.
[cpg]


The ceremony was witnessed by a few priests, but it was a truly sacred ceremony and no strangers, even family members, were allowed in.
[cpg]


I kneeled down and prayed. I don't really believe in God that much, but ......
[cpg]


I heard something. I heard something, but it wasn't a voice. Only the meaning of the words entered my head.
[cpg]

What entered my head was the sentence, "I give you the skill of Mischief-making Magic.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_04"]
[WAIT time=1000]
;//【ＢＧ】『屋敷＿室内』（昼）******************************************************


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca004"]
[OnName num="bianca"]
You completed your baptism!　What skills did they give you?"
[cpg cn=true]



[OnName num="kurto"]
It's a skill called "...... Mischief-making Magic."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca005"]
[OnName num="bianca"]
Mischief-making Magic?　I have never heard of this skill.
[cpg cn=true]



[FACE method="change_1" pos="2/3"]


[OnName num="kurto's_father"]
I have never heard of it.　If it's a limited magic, then it can be used if you think about it.
[cpg cn=true]


[OnName num="kurto"]
I'll give ...... a try.
[cpg cn=true]


For example, if the skill is to be good at magic in general, you need to study about magic.
[cpg]


That the skills I was given may not be like that.
[cpg]


If I'm just given magic that I don't know what it can be used for ......, it might be easy to invoke it.
[cpg]



[OnName num="kurto"]
"......."
[cpg cn=true]


I'm going to remind myself. I want something miraculous to happen. Something that doesn't seem to be worthy of the name "Mischief-making Magic. ......
[cpg]



[SE f="se008"]
;//【ＳＥ】『風』
[WAIT time=1000]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Bianca006"]
[OnName num="bianca"]
Kyah!"
[cpg cn=true]


Really, wishes at times like this never come true.
[cpg]


Bianca's skirt flipped up. She held her skirt and blushed a little.
[cpg]


The brothers looked either stunned or relieved.
[cpg]


[OnName num="kurto's_mother"]
'...... it's okay. There must be some other use for it."
[cpg cn=true]


Mom follows up. But I know that she is also a calculating person.
[cpg]


If she knew that she couldn't use me, she would take an appropriate attitude even though I was her own child.
[cpg]




;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『屋敷＿室内』（夕方）******************************************************



After that, I worked hard on my Mischief-making Magic.
[cpg]


If I had the power to make the wind blow, so be it. Since I was good at wind magic, I might be able to stand on the battlefield with that alone.
[cpg]


I thought so and tried using it in various places, but the ...... effect was limited.
[cpg]

The wind that my magic creates is very little, and to a certain extent, it only makes young women's skirts flare up. ......
[cpg]



[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『屋敷＿室内』（夜）******************************************************



It's just awful. It's not a life-enhancing skill.
[cpg]


I tried to think of something else, but all I could do was ......
[cpg]


I've been trying to think of something else, but all I've been able to do is make the object I'm thinking of tremble.
[cpg]


I really don't understand this one. It's not even a trick, what am I supposed to use it for?
[cpg]


For example, a stone or a book, when I remind it, it shakes in detail, but ...... it doesn't help.
[cpg]


My father and mother are not discouraged, but rather they are sympathetic to me.
[cpg]


That, in turn, made me feel sorry for them. Mom stopped saying, "There must be a use for it.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（朝）******************************************************


[OnName num="josef"]
She was there. Kurth, get back to the house as soon as you can.
[cpg cn=true]


Time was flying by, and I was turning 20 this year.
[cpg]


[OnName num="josef"]
I told you the Haring would be at our house today. If you're not there, you're in trouble.
[cpg cn=true]


The Haring. High elves are considered to be one of the higher ranks of the elf race. ......
[cpg]


They are a noble family on par with ours, or maybe a little less so.
[cpg]

If we can make a connection here, we may be able to reverse our current position.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『屋敷＿室内』（昼）******************************************************



The eldest daughter of the Haring family. I have heard that her name is Arma.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Alma001"]
[OnName num="alma"]
'Nice to meet you. You are the son of the Lammerz family. ...... My name is Arma. Nice to meet you.
[cpg cn=true]


[OnName num="emile"]
Yes, my name is Emil. I am Emil. This is my brother Joseph, and Kurth ......."
[cpg cn=true]


I bow my head. The person named Arma is so beautiful that it's almost depressing.
[cpg]


I've heard that there are many beautiful women among elves to begin with,.......
[cpg]


Add to that the gracefulness of his movements, and it was almost dazzling.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Alma002"]
[OnName num="alma"]
I've heard about you, Joseph. I hear you have the same military command skills as I do.
[cpg cn=true]


[OnName num="josef"]
You know me well, don't you? Do you also have military command skills?
[cpg cn=true]


Military command. It is one of the most useful skills for an aristocrat.
[cpg]


Brother Joseph is good at getting around even if he is not. I guess that's what they say, "Heaven gives two gifts," right?
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Alma003"]
[OnName num="alma"]
Yes. I don't want to be on the battlefield if I can help it.
[cpg cn=true]


[OnName num="emile"]
Of course. But even in a peaceful world, it is necessary to be skilled in battle.
[cpg cn=true]


Emil is skilled in swordsmanship.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Alma004"]
[OnName num="alma"]
Yes, ...... it may be necessary in terms of deterrence."
[cpg cn=true]


[OnName num="josef"]
'Military command skills are interesting, aren't they? It's interesting to learn the skills of military command, because even if you read a book on the Art of War, it's easy to get into your head.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Alma005"]
[OnName num="alma"]
Yes, I have that experience. I've had that experience, too, where I didn't know what it said until the day before I got the skill.
[cpg cn=true]


[OnName num="kurto"]
......"
[cpg cn=true]


All this time I kept quiet. She knew that brother Joseph had the military command skill.


So of course she knew about my Mischief-making Magic skills .......
[cpg]


I was so ashamed and embarrassed that I couldn't say anything.
[cpg]


[OnName num="josef"]
It's interesting to learn about history," he said. Even if you can't see people's intentions, you can at least understand the logic behind the military's actions.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Alma006"]
[OnName num="alma"]
Yes, military command is a rare skill. Military command is a rare skill that I don't talk about with many people, but with ...... Joseph, I can talk about it.
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夕方）******************************************************

 While I was doing that, it was time for Ms.Arma to go home.
[cpg]

I talked to him a little before then. I asked her what her hobbies were, what her favorite food was, and so on.
[cpg]

Arma replied. She said, "Horseback riding" and "sweets. I had no experience in horseback riding, nor did I know much about sweets.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Alma007"]
[OnName num="alma"]
I was happy to see you today. I had a good time today.
[cpg cn=true]


[OnName num="emile"]
Yes. Well then.
[cpg cn=true]


It was just hard for me to see my brothers and Arma having fun.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_07"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************


Somehow I couldn't stay at home, so I was out there.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Bianca007"]
[OnName num="bianca"]
"Mr. Kurth,......, what are you doing here at this time of night?"
[cpg cn=true]


[OnName num="kurto"]
I just want to be alone. I just want to be alone.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Bianca008"]
[OnName num="bianca"]
You'll catch a cold. It's already quite cold.
[cpg cn=true]


[OnName num="kurto"]
...... Bianca is so sweet. How can you be so good to me?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Bianca009"]
[OnName num="bianca"]
Don't be so mean. I think Kurth is a person who understands people's feelings better than anyone else.
[cpg cn=true]


I'm not aware of that, and I probably don't. Bianca must be forcing herself to compliment me.
[cpg]



[OnName num="kurto"]
Bianca. Am I going to end up as a useless piece of baggage?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca010"]
[OnName num="bianca"]
"Don't worry, ....... I'm here for you.
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『屋敷＿室内』（昼）******************************************************


[OnName num="kurto"]
"...... customer?　And you're a merchant?
[cpg cn=true]


[OnName num="emile"]
"Oh, yes. He is a wealthy merchant from the far east. His name is Yuika Hinamiya.
[cpg cn=true]


[OnName num="kurto"]
Never heard of him.
[cpg cn=true]


[OnName num="emile"]
You've at least heard of a trading company called "Toho-kimonroku."
[cpg cn=true]


[OnName num="kurto"]
...... No, I've never heard of it.
[cpg cn=true]


[OnName num="emile"]
How could you not have heard of it? I'm amazed at your carefree attitude. You don't even know you're a nobleman.
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『屋敷＿室内』（昼）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yuika001"]
[OnName num="yuika"]
How do you do? I have heard a lot about you, that you are a master of swordsmanship.
[cpg cn=true]


As soon as he arrived, he started talking about his skills. I think I had a bitter look on my face.
[cpg]


[OnName num="emile"]
He said, "Yes, well. I don't deny it.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika002"]
[OnName num="yuika"]
'I like the idea of swordsmanship,' he said. It will definitely help you.
[cpg cn=true]


This time, he seemed to be on the same page as his brother Aemir.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Yuika003"]
[OnName num="yuika"]
It is important to have the power to be recognized by everyone.
[cpg cn=true]


No, it's not so much that they are on the same page, but rather that they are trying to flatter each other without being obvious. ......?
[cpg]

I felt something unfathomable from the person called Yuika.
[cpg]


I wasn't sure how to behave. Maybe it was the difference in the skills I had acquired, but I was only talking to brother Emil.
[cpg]


If Yuika-san likes me here, I might have a chance to do something.
[cpg]


[OnName num="josef"]
I heard that you are from the East.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika004"]
[OnName num="yuika"]
Yes, I am. Yes, it's a nice place in the countryside. It is an island nation, so it has evolved in its own way.
[cpg cn=true]


[OnName num="kurto"]
Your name is also ......, a name you don't hear around here.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika005"]
[OnName num="yuika"]
Yes, it is. It means "the only flower.
[cpg cn=true]


[OnName num="kurto"]
"Oh, ......."
[cpg cn=true]


...... is no good. It was impossible to get excited about the topic of the name.
[cpg]


[OnName num="kurto"]
I heard that you are a merchant. ......What is the interesting part of your business?
[cpg cn=true]


I tried to talk about a topic that he seemed to be interested in, but that I didn't really understand. Then he said.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuika006"]
[OnName num="yuika"]
"Oops, you ask that? Are you interested in business?
[cpg cn=true]


[OnName num="kurto"]
And he said, "Well, yeah. Well..."
[cpg cn=true]


I go along with the conversation as I see fit. Yuika-san looks a little enthusiastic and says, "You know the recently conceived concept of ?
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Yuika007"]
[OnName num="yuika"]
Do you know the word "bounciness," which is a recently invented concept?
[cpg cn=true]


[OnName num="kurto"]
Does elasticity mean the ability to bounce?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuika008"]
[OnName num="yuika"]
I see that you are not familiar with ....... It's a term that is closely related to taxes, etc."
[cpg cn=true]


[OnName num="josef"]
......
[cpg cn=true]


Brother Joseph looks at me for a moment.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika009"]
[OnName num="yuika"]
"Dependency, if I may be so bold as to call it that, is what we call taxation. ......
[cpg cn=true]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



We ended up talking about management, but I couldn't get excited about something I didn't understand.
[cpg]


After he greeted us, he and my dad soon got to talking one-on-one.
[cpg]


It seems that the man named Yuika originally ran a business in another fiefdom.
[cpg]


He came to us because he wanted us to arrange business in the territory where my father ruled. ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『屋敷＿室内』（夕方）******************************************************



I couldn't even take it up with Yuika. No, I thought, next time, but when is the next time?
[cpg]


I was at a disadvantage because of my skill level to begin with.
[cpg]


Maybe the brothers don't care about me. ......
[cpg]


[OnName num="kurto"]
Hey, Bianca.
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca011"]
[OnName num="bianca"]
Yes, sir. What is it, Kurth?
[cpg cn=true]


[OnName num="kurto"]
I don't know what to do. Bianca is all I have left.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca012"]
[OnName num="bianca"]
I don't think that's true. I think Arma-sama and Yuika-sama have been concerned about you.
[cpg cn=true]


[OnName num="kurto"]
I don't think so. You don't have to be so concerned about it.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca013"]
[OnName num="bianca"]
The day will come when you will be recognized, Kurth-sama. You might even find some use for your skills.
[cpg cn=true]


[OnName num="kurto"]
That is an exaggeration. There is no use for my skills.
[cpg cn=true]


[OnName num="kurto"]
Well, I'm sure I won't be kicked out of this house anytime soon.
[cpg cn=true]


Bianca was not going to say anything more, but then she said something unexpected.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Bianca014"]
[OnName num="bianca"]
Bianca said, "Be careful with Mr. Emil and Mr. Joseph. They seem to be up to something.
[cpg cn=true]


[OnName num="kurto"]
What do you mean, ......?　Me?"
[cpg cn=true]


Bianca nodded. I don't understand.
[cpg]


[OnName num="kurto"]
I think you're overthinking this. If they had time for me, they'd be doing something else.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="sBianca001"]
;//[VOICE f="Bianca015"]
[OnName num="bianca"]
...... Anyway, take care of yourself."
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bgm_03"]
;//[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************

Here, I guess I'm at fault for not thinking anything of Bianca's words.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_04"]
[WAIT time=100]
;//【ＢＧ】『屋敷＿室内』（昼）******************************************************



It happened abruptly. I had no idea what was happening.
[cpg]


The main character of the incident was a clock. An antique, highly crafted, rather expensive one.
[cpg]


It was the kind of watch that my father really liked and, if I had my way, he probably cherished it more than me.
[cpg]


[OnName num="maid"]
Kurth," he said, "I am betraying you. I know I'm betraying you, but please don't hold it against me.
[cpg cn=true]


The maid of honor said, and then she took the watch from ......
[cpg]



[SE f="se015"]
;//【ＳＥ】『時計倒れる　ガシャン』
[WAIT time=2000]


[OnName num="kurto"]
What?"
[cpg cn=true]


The clock was broken.
[cpg]


[OnName num="emile"]
"What was that sound ......?"
[cpg cn=true]


[OnName num="maid"]
"Just now ...... Kurth-sama's magic agitated my skirt, and I broke it in the spur of the moment."
[cpg cn=true]


[OnName num="emile"]
'I see. I'm sorry, but it's not your fault."
[cpg cn=true]


[OnName num="kurto"]
'Yes, no,...... what are you talking about?　I didn't do anything.
[cpg cn=true]


[OnName num="josef"]
I'm sorry, Kurth. It was all your brother's idea.
[cpg cn=true]


I was watching the play between Brother Emil and the maid of honor, and I was dumbstruck.
[cpg]


Emil is arrogant and Joseph is cunning.
[cpg]


I guess they thought it would be better to have fewer obstacles in their way as they vie for the succession, and they had already made their move.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Bianca016"]
[OnName num="bianca"]
What's going on,......, Master Kurth, what's going on?"
[cpg cn=true]


[OnName num="kurto"]
"Bi, Bianca,......, you didn't see that, did you?
[cpg cn=true]


He used Mischief-making Magic on the maid of honor, and the maid of honor was so startled by it that she fell down.
[cpg]


[FACE method="change_7" pos="2/3"]

In her fall, she broke her father's cherished clock,.......
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_06"]
[WAIT time=100]
;//【ＢＧ】『屋敷＿室内』（昼）******************************************************



[OnName num="kurto"]
I didn't use my skills.　I didn't use my skills."
[cpg cn=true]


[OnName num="kurto's_father"]
I'm sorry, Kurth. I thought you'd be more discreet."
[cpg cn=true]


I wonder how much Dad really means what he says. He seems angry, but I think he sees through your brothers' scheming, too.
[cpg]


Or does he think I'm unreliable if I fall for such schemes?
[cpg]


[OnName num="kurto's_father"]
The maid of honor will be dismissed, of course. You've ruined her life, too.
[cpg cn=true]


Of course she would be fired. She knew it, and she broke it, so he must have given her something in return.
[cpg]


[OnName num="kurto"]
Really, I didn't use it."
[cpg cn=true]


[OnName num="josef"]
You're bound to say that, aren't you? I saw it.
[cpg cn=true]


Brother Joseph was relentless this time.
[cpg]


I know you are following brother Emil, but maybe it was brother Joseph who thought of this whole plan.
[cpg]


[OnName num="kurto's_mother"]
......It's a pity, really.
[cpg cn=true]


Even Mom was not on my side. I was at a loss.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_07"]
[WAIT time=100]
;//【ＢＧ】『屋敷＿室内』（夕方）******************************************************



And it wasn't long after that. Really, it was only a matter of a few days before they decided what to do with me.
[cpg]


My parents had been shunning me because of my skill set to begin with. I'm aware of that much.
[cpg]


My father mentioned the name of a place I'd never heard of. It had been decided that I would be sent away.
[cpg]


[OnName num="kurto's_father"]
He said, "Hurry up and get ready. Why don't you take this opportunity to go out on your own?
[cpg cn=true]


He said that, but I knew that wasn't what he really meant.
[cpg]


In short, if you can't use it, you don't need to be around it.
[cpg]



[FACE method="shake_3" pos="2/3"]
[VOICE f="Bianca017"]
[OnName num="bianca"]
I don't think Kurth would do such a thing. I can't believe he would use his skills in a place where, just in case, he might break a watch."
[cpg cn=true]


Bianca followed me to the end. But it doesn't make sense as long as Dad might know the truth.
[cpg]


[OnName num="kurto"]
I said, "All right, Dad. Dad."
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Bianca018"]
[OnName num="bianca"]
Kurth-sama!"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

I felt a sense of despair, but at the same time, I also thought that maybe that's how aristocrats are.
[cpg]


In any case, father, mother, and brothers are not ogres.
[cpg]


I would have no trouble surviving. I would forever lose my chance for success, but I was happy about that.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_07"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（朝）******************************************************



[OnName num="kurto"]
......
[cpg cn=true]


This is goodbye to the mansion I've lived in for so many years.
[cpg]


I felt like I couldn't look back. I felt terribly tired.
[cpg]


I felt like I was tired, both of my brother Emil, who kept his guard up in these situations, and my brother Joseph, who tried to get around.
[cpg]


Even my father and mother seemed to live in a world that ...... I couldn't understand.
[cpg]


[OnName num="kurto"]
......See you later."
[cpg cn=true]


I said that to my family. I couldn't say goodbye.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_11_2.ui" time=1500]
[WAIT time=3000]
;//ブラックアウト

[BG f="b_11_3.ui" time=1500]
[WAIT time=3000]
[window target=true]

And then I came to the unspeakable countryside.
[cpg]


I had lived in the city all my life, so it was questionable whether I would fit in.
[cpg]


[jump storage="ep001.ks" target="*start"]


;//=============================================================================
