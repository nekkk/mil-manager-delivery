

;//１、アルマ


;#################################################
*Ep010|Calm and Core Arma
;#################################################

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]



*select07_1|Gentle and core Arma


[SCENE id=10]


It was Arma I thought of.
[cpg]


She is calm, yet has a core, and I think she is an attractive person. I have known her since we were children.
[cpg]


But when I ...... considered her as an object of romantic interest, I felt somewhat embarrassed.
[cpg]


Even if I like her, what about the other side?
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



Holiday. I was spending a quiet afternoon.
[cpg]


I was thinking that even if my feelings for Arma-san became clear, there would be no sudden progress.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Bianca285"]
[OnName num="bianca"]
I said, "Master. Arma-sama is here."
[cpg cn=true]


[OnName num="kurto"]
She said, "Oh. I'm on my way.
[cpg cn=true]


A sign of a bug, you say? I had a feeling that Arma was coming.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



[OnName num="kurto"]
"Somehow, I knew she would come."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Alma138"]
[OnName num="alma"]
"Hmmm. I was sure she would know everything about me.
[cpg cn=true]


But I still don't know much about Arma's life.
[cpg]


I don't even know how she came to be my adopted daughter.
[cpg]


[OnName num="kurto"]
What can I do for you today?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Alma139"]
[OnName num="alma"]
No, nothing much. Nothing important, I just wanted to talk to Kurth.
[cpg cn=true]


He said something like that, too. I think it's not that I don't think about it.
[cpg]


[OnName num="kurto"]
I see,...... then, I have something to tell you, okay?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
Arma nodded. I bowed to her.
[cpg]


[OnName num="kurto"]
I bowed to her and said, "Once again, thank you. It's thanks to you that I've made it this far.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Alma140"]
[OnName num="alma"]
I don't believe it. I didn't do anything.
[cpg cn=true]


[OnName num="kurto"]
"Am I useful to you, Arma?　It's always been on my mind.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Alma141"]
[OnName num="alma"]
"Hmm. You saved my parents.
[cpg cn=true]


There was silence for a while. Then I broached another subject.
[cpg]


[OnName num="kurto"]
"Do you have any regrets about your life so far, Arma-san?
[cpg cn=true]


I asked her about her past in a roundabout way.
[cpg]


[OnName num="kurto"]
I have some," he said. You may not believe me, but I really did have a life before my reincarnation.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Alma142"]
[OnName num="alma"]
I believe you. I don't believe you would lie about that.
[cpg cn=true]


From Arma's point of view, she understands my situation to some extent.
[cpg]


But I don't know Arma's situation. I didn't even know why I left my real parents.
[cpg]


[OnName num="kurto"]
I think I've told you most of my life story, and nothing complicated has happened that you don't know about.
[cpg cn=true]


[OnName num="kurto"]
......I'd like to know what kind of life you've led, Arma-san."
[cpg cn=true]


I wasn't sure whether to ask or not, but since it was the right time, I decided to ask.
[cpg]


Arma's expression clouded over a little. I knew I shouldn't have asked.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Alma143"]
[OnName num="alma"]
It's not an interesting story. I hope you don't mind.
[cpg cn=true]


[OnName num="kurto"]
Yes. I want to know as much as I can about you.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
Arma took a breath and then spoke.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Alma144"]
[OnName num="alma"]
I was ...... originally just a slightly wealthy commoner," she said. But at my baptism, I was given the skills to command an army.
[cpg cn=true]


Arma's current parents had never been able to have children until now.
[cpg]


When they decided to adopt a child, they chose Arma because she has one of the strongest skills.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Alma145"]
[OnName num="alma"]
I think that's a good thing," she said. But I'm not exactly an orphan. ......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Alma146"]
[OnName num="alma"]
I had original parents," she said. I had original parents, but they were blinded by money and gave me away .......
[cpg cn=true]


It must be very complicated. Just listening to the story, it seems unbearable for a child to hear.
[cpg]


[OnName num="kurto"]
"So that's how it was with ......?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Alma147"]
[OnName num="alma"]
Yes, but I love both my parents. But I love both my parents.
[cpg cn=true]


Arma expressed her mixed feelings.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Alma148"]
[OnName num="alma"]
I guess in the end, one unfortunate thing is that two people who want to have children can't have children.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Alma149"]
[OnName num="alma"]
That's why I'd like you to spread the word about ...... fertility treatment.
[cpg cn=true]


[OnName num="kurto"]
I'm going to do what I can to help. I'll do what I can to help.
[cpg cn=true]

[FADEOUTBGM]

I thought, now is the time.
[cpg]


But I couldn't stop my feelings. I couldn't hold back.
[cpg]


[OnName num="kurto"]
The person I want to make the happiest is you, Arma.
[cpg cn=true]


It was a roundabout way of saying it. But it was a confession.
[cpg]


Then, Arma-san's eyes filled with tears.
[cpg]

[BGM f="bgm_09"]
[WAIT time=100]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Alma150"]
[OnName num="alma"]
She said, "Thank you for ....... Am I okay with that?"
[cpg cn=true]


She shed the tears that had pooled in her eyes and was pleased.
[cpg]


[free time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="4/5" time=800]
[VOICE f="Bianca286"]
[OnName num="bianca"]
'The tea's in, ...... and, uh...'
[cpg cn=true]


[OnName num="kurto"]
Oh, ...... Bianca ......."
[cpg cn=true]


[FACE method="shock_6" pos="4/5"]
[VOICE f="Bianca287"]
[OnName num="bianca"]
Oh, yes!　I have to get the store ready."
[cpg cn=true]


I didn't stop him. Normally I would have, but right now I wanted to be alone with Arma.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



The two of us were alone after we had calmed down a bit. With the way she was feeling, Bianca wouldn't be back anytime soon.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Alma151"]
[OnName num="alma"]
'...... I've never been in a relationship with a man before.
[cpg cn=true]


[OnName num="kurto"]
Is that so?"　I'm sure if you're as pretty as Arma, men won't leave you alone.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Alma152"]
[OnName num="alma"]
I'm sure that's what it means to be an aristocrat. I am a nobleman, after all. I cannot have a free love life.
[cpg cn=true]



Arma blushed as she said this.
[cpg]


[OnName num="kurto"]
Are you sure?
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Alma154"]
[OnName num="alma"]
Yes, I'm sure. Please love me a lot, a lot.
[cpg cn=true]


This was such a sudden turn of events that I was having a hard time keeping up. I was having a hard time keeping up.
[cpg]


[OnName num="kurto"]
「……俺は、平民ですよ。貴族のアルマさんとは、釣り合わないかも」
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Alma155"]
[OnName num="alma"]
Don't worry about it. I love you, so it doesn't matter.
[cpg cn=true]


I was driven by a sense of mission to make my business even bigger.
[cpg]


I didn't want Arma to worry about me. There is also such a thing as public appearance.
[cpg]


I have to rise to the top in order to love her without any worries. ......
[cpg]


[OnName num="kurto"]
"Mr. Arma. I will become a bigger businessman.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Alma156"]
[OnName num="alma"]
I'll look forward to it. I look forward to it.
[cpg cn=true]


I will become a great merchant. I renewed my determination.
[cpg]



;//ブラックアウト

;//【ＢＧ】『主人公の部屋』（昼）



;//========================================
;//●ＣＧ（ヒロインに迫る主人公。抱き合っている）ev_21
;//人物１：ヒロイン１　服装１：裸
;//人物ex：主人公　　　服装ex：裸
;//場所　：主人公の部屋
;//時間　：昼
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bgm_09"]
;**【ＣＧ】 ev_21_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています

Arma and I cuddled for a while.
[cpg]


Feeling her body heat, we whispered words of love to each other.
[cpg]


[OnName num="kurto"]
"I love ....... Arma-san.
[cpg cn=true]


;**【ＣＧ】 ev_21_a ***********************
[CG id=8 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Alma181"]
[OnName num="alma"]
'Me too. I like you, Kurth. ......
[cpg cn=true]


I couldn't do more than that today because I couldn't read the time before Bianca got back.
[cpg]


But it's more than enough,...... so I thought and had a peaceful time.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



For a while, I was in the air. I didn't get much done at work.
[cpg]


No matter what I do, I think of Arma.
[cpg]


I guess it must be a happy thing, but I don't want to get too much work done. ......
[cpg]




;//ブラックアウト
[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/5" time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=1000]

Katharina was here today. And three others including Bianca and me.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Catalina182"]
[OnName num="catalina"]
"What's up, Kurth,......?"
[cpg cn=true]


[OnName num="kurto"]
"Well, um,...... on the contrary, what's wrong?"
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Catalina183"]
[OnName num="catalina"]
I looked like I had a new boyfriend or girlfriend.
[cpg cn=true]


Katharina is sharp. But Bianca was even sharper and ......
[cpg]


Before she could say anything, she was looking at me in a somewhat jealous way.
[cpg]


[free time=1000]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Bianca288"]
[OnName num="bianca"]
She said, "......"
[cpg cn=true]


That said, I don't feel like I'm jealous from the bottom of my heart.
[cpg]


I sensed an atmosphere of wanting to congratulate her, but not from the bottom of my heart.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************



The restaurant was doing well. In the midst of all this, Arma had arrived.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Alma182"]
[OnName num="alma"]
Good evening, ...... Kurth-san."
[cpg cn=true]


There were two other people in the restaurant, but Arma only called me.
[cpg]


Bianca didn't react to that, but greeted me with a smile.
[cpg]

[free time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Bianca289"]
[OnName num="bianca"]
Bianca was not responding, but greeted me with a smile. What can I do for you at this hour, Miss Arma?
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Alma183"]
[OnName num="alma"]
I'm here to see Kurth... ......
[cpg cn=true]


Arma looks at me. Bianca doesn't try to stop me, but I think she must be in a delicate state of mind.
[cpg]


[OnName num="kurto"]
Bianca doesn't try to stop me, but I think she must be in a delicate state of mind. Yes?"
[cpg cn=true]


[FACE method="change_1" pos="2/5"]
[VOICE f="Alma184"]
[OnName num="alma"]
My parents want to talk to you, Kurth. I think it's about fertility treatment.
[cpg cn=true]


[OnName num="kurto"]
"Oh, ......, okay. Okay, I'm on my way.
[cpg cn=true]


Katharina-san smiled at me, as if she had guessed something.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Catalina184"]
[OnName num="catalina"]
I'm sure that's what this is about," she said. That's why you're acting the way you are today.
[cpg cn=true]


[OnName num="kurto"]
What is it, ......?
[cpg cn=true]


I was a bit contrary, but I couldn't deny it outright either.
[cpg]


In fact, it is true. I am in love with Arma.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************



Then I went to Arma's house alone.
[cpg]


It was a big house. With bated breath, I entered the house. ......
[cpg]


[OnName num="kurto"]
"Excuse me for disturbing you."
[cpg cn=true]




;//ブラックアウト



[SE f="se002"]
;//【ＳＥ】『大きな扉開く』

;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１のお屋敷＿広間』（夜）******************************************************






[OnName num="kurto"]
"......, no one's home."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Alma185"]
[OnName num="alma"]
Yes, it is. Yes, it is. Both my parents are out today.
[cpg cn=true]


[OnName num="kurto"]
Is that ......?
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Alma186"]
[OnName num="alma"]
I'm sorry. I couldn't take you away from them in that place.
[cpg cn=true]


I guessed. I guessed. She was inviting me in her own way.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Alma187"]
[OnName num="alma"]
The maids of honor are there, but it's not like they're going to tell my parents.
[cpg cn=true]


[OnName num="kurto"]
...... I see."
[cpg cn=true]


I had come this far, and I didn't want to back down.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



I made my way to Arma's room. It was beautiful, feminine, and above all, spacious.
[cpg]


[OnName num="kurto"]
I asked her, "Arma, are you sure you want me to do this? Are you sure you are okay with me?
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Alma188"]
[OnName num="alma"]
I would like to say it myself. I wonder if I can keep someone as attractive as you all to myself.
[cpg cn=true]


[OnName num="kurto"]
I'm sure it's fine with ......."
[cpg cn=true]


;//移植のためシーンをカットしています


;//ブラックアウト
;//[stse]

[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



We never went back to my place that day.
[cpg]


I felt bad for Bianca. But I wanted to be with Arma.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



The next morning, I returned to ...... the house where Bianca was waiting for me.
[cpg]


[OnName num="kurto"]
I'm home......."
[cpg cn=true]


Bianca looked terrified.
[cpg]



[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca290"]
[OnName num="bianca"]
Welcome home, master. Breakfast is ready.
[cpg cn=true]


She smiled rather carefree.
[cpg]


[OnName num="kurto"]
I was surprised she didn't get angry with me. You didn't come home yesterday.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Bianca291"]
[OnName num="bianca"]
I'm happy because Master's happiness is my happiness."
[cpg cn=true]


When he said that much, I just felt sorry.
[cpg]


[OnName num="kurto"]
Thank you."
[cpg cn=true]


But I didn't say sorry or anything like that.
[cpg]


All I have to say here is thank you. All along, Bianca has been supportive: ......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（朝）******************************************************



I think about it, it's not just Bianca. I've had some sort of connection or relationship with other people.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="kurto"]
I've had some sort of connection or relationship with others. How's that new product you asked for?"
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Edith138"]
[OnName num="edith"]
Ummm, yes. "Good.
[cpg cn=true]


I think that Edith might have feelings for me, too.
[cpg]


I can't say that nothing happened. But I chose Arma.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Edith139"]
[OnName num="edith"]
...... Kurth.
[cpg cn=true]


[OnName num="kurto"]
What is it?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Edith140"]
[OnName num="edith"]
"Be happy ...... with Miss Arma."
[cpg cn=true]


[OnName num="kurto"]
"......"
[cpg cn=true]


You shouldn't say, for example, "Who told you that?" or "I'm sorry I was so thoughtful."
[cpg]


[OnName num="kurto"]
Thank you. I will be happy."
[cpg cn=true]


I knew these were the words I should say.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



For a while, I steadily expanded my business.
[cpg]



I was aiming to become a big merchant to match Arma. And Arma is helping me with that.
[cpg]


However, ...... here came a little problem.
[cpg]



The East Review is a business association run by Yuhka. I belong to it.
[cpg]


I'm also a member of the Merkur Chamber of Commerce, which is a different kind of business association.
[cpg]


;//[lbox off]
[free time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1000]
[WAIT time=1100]

[OnName num="merchant"]
Anyway, we don't want business that disturbs public safety. It will damage the image of us merchants as a whole.
[cpg cn=true]


[OnName num="kurto"]
But the government officials are also keeping a close eye on us.
[cpg cn=true]


[OnName num="merchant"]
The government officials and the customers are completely different. And it's not the same with the eyes of our competitors, either.
[cpg cn=true]


[OnName num="kurto"]
......, I agree.
[cpg cn=true]


I could sense that this was going to be a problem.
[cpg]


I was going to keep my business going as long as I could to avoid as many corners as possible,.......
[cpg]


[OnName num="merchant"]
Anyway, if you continue that kind of business, I have an idea.
[cpg cn=true]



[SE f="se004"]
;//【ＳＥ】『扉閉まる』



[free time=1000]

Saying that, the Merkur Trading Company man left.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Bianca292"]
[OnName num="bianca"]
'...... I wonder what it is?'
[cpg cn=true]


[OnName num="kurto"]
I wonder. I don't want to be disturbed right now,......."
[cpg cn=true]




[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（昼）******************************************************



[OnName num="kurto"]
'And well, that's what happened.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Alma215"]
[OnName num="alma"]
'That's ...... a big deal. I wonder if it will be a conflict between the chamber of commerce.
[cpg cn=true]


[OnName num="kurto"]
I hope it won't be that big a deal.
[cpg cn=true]


 I would like to keep it to the extent of me and the company, rather than between the companies.
[cpg]


 I'm sorry if it ends up involving Yuika.
[cpg]


 On the other hand, if she comes out, it might be resolved in an instant.
[cpg]


It is a difficult question. Of course I'd like to solve it myself.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Alma216"]
[OnName num="alma"]
So ...... where am I going to be taken?"
[cpg cn=true]


[OnName num="kurto"]
Hey, I need your help with something."
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中の集落』（昼）******************************************************



And here we are.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Alma217"]
[OnName num="alma"]
This is ...... the settlement of Arlaune, isn't it?
[cpg cn=true]


[OnName num="kurto"]
Yes. Yes. I need your help, Arma.
[cpg cn=true]


[OnName num="kurto"]
She says there's a forest up ahead where tentacle creatures are said to come out.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Alma218"]
[OnName num="alma"]
...... You're not going there, are you?　Why?
[cpg cn=true]


[OnName num="kurto"]
I heard that no one goes there. They say no one goes there. They think there might be magic stones or other rare materials there.
[cpg cn=true]


Arma was wary of me as I explained the situation to her.
[cpg]

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


And as expected, this is what happened.
[cpg]

[SE f="se020"]
;//【ＳＥ】『触手伸びる』


;//========================================
;//●ＣＧ（触手に縛られるヒロイン）ev_22
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：触手生物　　服装ex：なし
;//場所　：昼
;//時間　：森の中
;//========================================

[WAIT time=1000]
[BGM f="bgm_09"]
;**【ＣＧ】 ev_22_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sAlma003"]
[OnName num="alma"]
Kyaaaah!"
[cpg cn=true]



Arma was bound by the tentacle creature and couldn't move.
[cpg]

[VOICE f="sAlma004"]
[OnName num="alma"]
What should I do ......?
[cpg cn=true]


[OnName num="kurto"]
"It's all right. I brought a demon repellent for just such an occasion.
[cpg cn=true]


;**【ＣＧ】 ev_22_a ***********************
[CG id=9 index=1 time=1]
;***************************************
[WAIT time=1000]

[VOICE f="sAlma005"]
[OnName num="alma"]
Please use it from the beginning!
[cpg cn=true]


I was apologizing to Arma, who protested, "I'm sorry.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

By the time we passed through the forest, while collecting materials, we were at ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中の集落』（夕方）******************************************************



It was already late in the evening.
[cpg]

We stayed longer than we expected.
[cpg]

However, we gathered a lot of materials. Now we can make new products again.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



How can I do the best research? There are days when I can't sleep because I'm thinking about it.
[cpg]


But it was also pleasant. I enjoyed being troubled.
[cpg]


My life and Arma's life still have a long way to go.
[cpg]


[OnName num="kurto"]
...... Okay."
[cpg cn=true]


After a sleepless night, I got up from bed.
[cpg]


The ideas were endless. I was no longer satisfied with just making things that existed in the world I used to live in.
[cpg]

It is no longer a question of my previous life that makes me wonder if there is anything that can only be made in this world.
[cpg]


I was sure that I was suited for this job. I was convinced of that.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



The store's scale kept getting bigger and bigger. However, there are few advantages to having one large store.
[cpg]


I took the form of establishing branches in various regions and countries.
[cpg]


Yuika is also helping me. No, not only Yuika.
[cpg]


Everyone around me seemed to be on my side. Just a little while ago, I was thinking the opposite.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Bianca293"]
[OnName num="bianca"]
I was thinking, "Good work again today. Master, the tea is ready.
[cpg cn=true]


[OnName num="kurto"]
"Oh, thank you. Thank you.
[cpg cn=true]


Bianca is helping me a lot. She knows I'm dating Arma. ......
[cpg]




[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1100]
;//ブラックアウト



I'm not in charge of the store for long periods of time anymore.
[cpg]


It was becoming more important for me to gather the information I needed to run the business.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夕方）******************************************************



There are things that are pending. You know, the Merkur Trading Company.
[cpg]


[OnName num="kurto"]
It looks exactly like that.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Bianca294"]
[OnName num="bianca"]
Yes,...... really.
[cpg cn=true]


Only I have the magic of mischief. So it would be difficult to reproduce the massager.
[cpg]

However, the rubber goods were not something that I could try to imitate.
[cpg]


The Merkur Chamber of Commerce has a large number of people belonging to it in this area.
[cpg]


This means that they must have a lot of craftsmen.
[cpg]


The fact that they can allocate staff to molding also means that they can easily make imitations like this. ......
[cpg]


[OnName num="merchant"]
Oh, it's you. Oh, it's you.
[cpg cn=true]


The merchant who came all the way to my store to visit me once had set up store.
[cpg]


I wonder if he is doing this by quitting the restaurant he used to be in charge of.
[cpg]


I feel something like an obsession when I think about it, but I guess it's the will of the Chamber of Commerce.
[cpg]


[OnName num="merchant"]
You sound like you want to say something.
[cpg cn=true]


[OnName num="kurto"]
No, I don't. Nothing.
[cpg cn=true]


I tried to be as non-confrontational as possible.
[cpg]


It is not so bad to be making something that will be imitated.
[cpg]


Then, I just have to create something that will never be imitated.
[cpg]


I had to think of various ways to achieve this.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



I was on my way home, thinking about it.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
On my way home, I met Arma.
[cpg]


[OnName num="kurto"]
She said, "Good evening. Arma-san.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Alma271"]
[OnName num="alma"]
"Yes, good evening. You look like you're thinking about something.
[cpg cn=true]


[OnName num="kurto"]
Yes, I am. Well, a little bit.
[cpg cn=true]


I tell Arma what happened. Then he said.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Alma272"]
[OnName num="alma"]
You have become a great merchant, too. You are equal or even superior to the nobility.
[cpg cn=true]


She took it positively.
[cpg]


[OnName num="kurto"]
I guess so. It seems like it took me a long time to get here.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Alma273"]
[OnName num="alma"]
You feel the same way, don't you? But it's an extraordinary rise to the top.
[cpg cn=true]


I was happy to hear Arma say that.
[cpg]


[OnName num="kurto"]
I'm glad you call me a ...... great merchant. When Arma-san says it, it makes it even more so."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Alma274"]
[OnName num="alma"]
I am glad to hear you call me a great merchant. I am also glad that your business is doing well,......."
[cpg cn=true]


Arma's words had other connotations besides the literal meaning of the words.
[cpg]


It means ...... that you are in a good enough position to marry Arma-san.
[cpg]


Arma-san must be expecting it. It is difficult for a mere merchant to marry Arma-san, a nobleman.
[cpg]


But I am different. I was not only happy about that, but also proud of it.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="4/5" time=800]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



Bianca had always been a very thoughtful person, but recently she had been especially so.
[cpg]


When I bring Arma home, even if I don't intend to do anything particularly sinister,......
[cpg]


[FACE method="shock_6" pos="4/5"]
[VOICE f="Bianca295"]
[OnName num="bianca"]
I had some shopping to do. Enjoy yourselves, you two!"
[cpg cn=true]

[free time=1000]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1000]

She seemed more embarrassed than jealous.
[cpg]


Seeing Bianca like that, Arma-san looked a little apologetic.
[cpg]

;//移植のためシーンをカットしています


;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


It was just the two of us, me and Arma.
[cpg]

While we were talking, the evening came.
[cpg]


[OnName num="kurto"]
I said, "...... Arma. No, Arma ......."
[cpg cn=true]


I called her and took her hand. Arma laughed.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Alma330"]
[OnName num="alma"]
She smiled, "Hmph. What is it?"
[cpg cn=true]


[OnName num="kurto"]
I'm going to be a merchant that even the Mercure Chamber of Commerce won't be able to imitate one day. So, you know.
[cpg cn=true]


[OnName num="kurto"]
'If I become the best merchant in the country, will you marry me?
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Alma331"]
[OnName num="alma"]
If it's ......, we'll be married soon.
[cpg cn=true]


Arma pushed me back, saying.
[cpg]



;//ここからクルトとアルマはお互いを呼び捨てになり、アルマに対してクルトは丁寧語ではなくなります



[FACE method="change_2" pos="2/3"]
[VOICE f="Alma332"]
[OnName num="alma"]
Kurth. I'm always on your side.
[cpg cn=true]


[OnName num="kurto"]
Thank you for ....... I'll make you happy, too.
[cpg cn=true]



;//ブラックアウト

[FACE method="bow_2" pos="2/3"]
[WAIT time=1100]


I can't stop now. No matter if I'm at odds with the authorities or the Chamber of Commerce, nothing can stop me.
[cpg]


Arma is all I have. I will do whatever it takes to be with her.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



With this in mind, I tried to develop new products while running the store.
[cpg]


The small tentacles are selling well, but not well enough.
[cpg]


I can't make something that will be imitated. Then ......
[cpg]


In addition to the means to seize the materials first, there was one more thing I could do. I could use my Mischief-making Magic.
[cpg]


If I used this as a driving force, it would certainly be something that only I could make.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="sCatalina012"]
[OnName num="catalina"]
It's an interesting skill, really.
[cpg cn=true]


I had the help of Katharina, a magician, in this regard.
[cpg]


[OnName num="kurto"]
So, ......, do you think you can find any other uses for it?
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Catalina186"]
[OnName num="catalina"]
I think so. It seems that I also have the power to generate electricity.
[cpg cn=true]


Electricity?　I asked back. I still don't know how to use this. ......
[cpg]


[OnName num="kurto"]
I guess I'll hold off on that for now. I wonder what it can be used for.
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Catalina187"]
[OnName num="catalina"]
I said, "Let me know if you come up with something else. I'll work my magic on the magic stone in my own way."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_07"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夕方）******************************************************



Various things are going on at the same time. They also conducted a kind of reconnaissance against the Mercoure Chamber of Commerce.
[cpg]


However, they did not do anything blatantly evil. At most, they would make similar products.
[cpg]


If they did something that violated the law, they would have strangled themselves.
[cpg]


[OnName num="merchant"]
You're here again. No matter what you say, we won't back down.
[cpg cn=true]


I'm not going to say anything, no matter what you say.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Catalina188"]
[OnName num="catalina"]
I was not going to say anything. "You, aren't you ashamed to be in business like this?
[cpg cn=true]


But Katharina, who was accompanying me, seemed unable to say anything.
[cpg]


[OnName num="kurto"]
She was not going to say anything.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Catalina190"]
[OnName num="catalina"]
But ......"
[cpg cn=true]


[OnName num="merchant"]
But . The owner is a coward.
[cpg cn=true]


I feel the confrontation is deepening. That's why I couldn't help but create a new product.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************



[FACE method="shake_7" pos="4/5"]
[VOICE f="Catalina191"]
[OnName num="catalina"]
It happened. It's terrible, isn't it?
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Alma333"]
[OnName num="alma"]
'Yes, ...... it's unforgivable, but what can I do about it?
[cpg cn=true]


[OnName num="kurto"]
I don't need to be able to do anything right now. We just need to make a product that can't be imitated."
[cpg cn=true]


Arma looked frustrated, but she seemed to understand.
[cpg]


[OnName num="kurto"]
'Well, I guess it's time to close. ......
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Catalina192"]
[OnName num="catalina"]
I guess so. Well, I'd better be on my way.
[cpg cn=true]


[OnName num="kurto"]
Yes. Thank you again for today.
[cpg cn=true]


[FO pos="4/5" time=1000]

Katharina bowed her head and then left the store.
[cpg]


Turning over the sign in front of the door, Arma and I look at each other for a moment.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植のためシーンをカットしています

However, I can't stay home forever, so I go back to my house. Arma also goes home.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I think about the future. I want to establish as friendly a relationship as possible with the Mercure Trading Company.
[cpg]


Otherwise, we will have to overwhelm them to the point where they cannot intervene. But that seems a bit difficult.
[cpg]


No matter how much I increase the scale of my business, it is inconceivable that the Mercoure Chamber of Commerce will not make any attempt to interfere.
[cpg]


As long as there is conflict, it means there is more or less loss.
[cpg]


I thought about ...... to see if I could do something about it, but no good ideas came to mind.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Bianca297"]
[OnName num="bianca"]
'Good morning. Master."
[cpg cn=true]


[OnName num="kurto"]
'Oh, good morning.'
[cpg cn=true]


It is Bianca, not Arma, who wakes me up.
[cpg]


[free time=1000]

Arma and I are dating, but we are not married.
[cpg]


I am not married to Bianca because I don't think I can be a man worthy of her.
[cpg]


Yes, business is no longer just for me.
[cpg]


I knew I couldn't stand still. I renewed my resolve.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



I will work hard to develop new products. Not just something that would sell, but something that could not be imitated.
[cpg]


If I thought someone would imitate me, I would take steps to make sure they couldn't. I would use materials that I had a monopoly on.
[cpg]


I'll use materials that I have a monopoly on, in short, that kind of thing. ......
[cpg]



;//ブラックアウト
;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_07_2.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//
;//[BGM f="bgm_02"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Catalina193"]
[OnName num="catalina"]
So, have you come up with a way to use the current?"
[cpg cn=true]


[OnName num="kurto"]
"Well, ...... something, I don't know if I have."
[cpg cn=true]


Things like machines, for example, can't be made at this world's level of civilization.
[cpg]

No, wait. Yes, there is. Something that works with a simple structure.
[cpg]



[OnName num="kurto"]
"...... There was such a thing in a massage machine. It's called a low-frequency therapy machine.
[cpg cn=true]



[FACE method="shake_7" pos="2/3"]
[VOICE f="Catalina194"]
[OnName num="catalina"]
What's the end product?　What is it?
[cpg cn=true]


I explained to Katharina from the beginning.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Catalina195"]
[OnName num="catalina"]
"It sounds painful just listening to .......
[cpg cn=true]


[OnName num="kurto"]
I think so too.
[cpg cn=true]


[OnName num="kurto"]
But if my magic has such a use, I'll try to make it.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Catalina196"]
[OnName num="catalina"]
I'll see what I can do. I'll see if I can figure out a way to embed it in a magic stone.
[cpg cn=true]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト




Through trial and error, they create a product that will become a commodity.
[cpg]


The process was both familiar and enjoyable.
[cpg]


[OnName num="kurto"]
The current is too strong as it is now, isn't it?
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Catalina197"]
[OnName num="catalina"]
I don't know. I think it has to hurt, otherwise it won't do any good.
[cpg cn=true]


[OnName num="kurto"]
Then, would you like to try it on Katharina?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Catalina198"]
[OnName num="catalina"]
No, I don't think so.
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************



A few days passed from there. A few days later, I completed a so-called low-frequency therapy device, a development of the massaging machine.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Alma410"]
[OnName num="alma"]
"You want to try it on ...... me, ......?"
[cpg cn=true]


[OnName num="kurto"]
I don't know. I don't know."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Alma411"]
[OnName num="alma"]
"Okay, but ...... it doesn't hurt, does it?"
[cpg cn=true]


[OnName num="kurto"]
It's just so-so painful. Otherwise it wouldn't work.
[cpg cn=true]


Arma is scared. I don't blame her.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
;//ブラックアウト

;//移植のためシーンをカットしています



I asked Arma what she thought after she tried it, and she said it was great.
[cpg]


I had a good feeling that this would work.
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=2000]



After returning home, I rested and headed back to the store.
[cpg]


This kind of daily routine is all for the sake of being with Arma.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yuika113"]
[OnName num="yuika"]
Hello," she said. How are sales going, Kurth?
[cpg cn=true]


In the middle of all this, Yuika-san came to the store.
[cpg]


[OnName num="kurto"]
'It's back up to where it was before the Mercure Trading Company came to interfere.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika114"]
[OnName num="yuika"]
'That's good. I think it's genuinely difficult to make something that can't be imitated in order to avoid being imitated.'
[cpg cn=true]


Yuika praised me. I scratch my head.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika115"]
[OnName num="yuika"]
In fact,...... our trading company and Merkur Trading Company are also competing with each other in other fields.
[cpg cn=true]


[OnName num="kurto"]
Is that so?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Yuika116"]
[OnName num="yuika"]
Clothes, ceramics, etc., made in my country. Sometimes they copied things from my country.
[cpg cn=true]


[OnName num="kurto"]
You don't think that's ......?
[cpg cn=true]


You don't think it's my fault?　
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuika117"]
[OnName num="yuika"]
No," he said. It's been that way for a while, so it has nothing to do with Kurth. In the first place, the Merkur Chamber of Commerce has a way of doing things."
[cpg cn=true]


[OnName num="kurto"]
'I see. In any case, it's not good that they interfere with us.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika118"]
[OnName num="yuika"]
Well, you know. You might be the bridge.
[cpg cn=true]


[OnName num="kurto"]
You're being overbearing.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika119"]
[OnName num="yuika"]
It's a fair assessment. If you can't imitate them because of the way they are made, it's hard to get in their way. I'm sure they will eventually move to cooperate.
[cpg cn=true]


I doubt it. The guy from the Merkur Trading Company one day seemed pretty aggressive.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************



[OnName num="kurto"]
'Yuika said something about .......'
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Alma437"]
[OnName num="alma"]
'I see. If it's true, it's a tailwind.
[cpg cn=true]


[OnName num="kurto"]
'I doubt it.　Do you really think the Merkur Chamber of Commerce is going to fold?
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Bianca298"]
[OnName num="bianca"]
'I only hear about it in stories,......, but I wouldn't be surprised if they do.
[cpg cn=true]


It's something I don't really feel.
[cpg]


You're saying that you might join hands with the Merkur Trading Company, which has been clashing so much with us?
[cpg]


[OnName num="kurto"]
Am I doing something that great?
[cpg cn=true]


What a thing to say, like a hero who has been reincarnated in another world.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Alma438"]
[OnName num="alma"]
I'm doing it. You just need to be more confident."
[cpg cn=true]


Bianca takes a step back. It's as if she's letting Arma tell her what's important.
[cpg]


I felt somewhat sorry for her, but she seemed to value her relationship with Arma.
[cpg]


[FACE method="shake_6" pos="2/5"]
[VOICE f="Alma439"]
[OnName num="alma"]
'Hey ...... Kurth. Would you like to come over to my place today?"
[cpg cn=true]


[OnName num="kurto"]
'I don't know about ......, Bianca.'
[cpg cn=true]


[FACE method="shake_6" pos="4/5"]
[VOICE f="sBianca020"]
[OnName num="bianca"]
'Oh no, you don't have to ask me.
[cpg cn=true]


Really, I'm sorry. But I wanted to spend time with Arma.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１のお屋敷＿広間』（夜）******************************************************



Arma's father and mother did not seem to be there.
[cpg]


It seemed like they were only coming to see me at times like this, but I guess it was Arma who was calling me.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Alma440"]
[OnName num="alma"]
"...... Kurth. Let's spend the whole day together."
[cpg cn=true]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]

I snuggled up to her.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

[FACE method="change_2" pos="2/3"]

Arma and I have a lot to talk about. I don't even mind that I have to work again tomorrow.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（朝）******************************************************



I went to the store, trying to resist sleepiness.
[cpg]


I should not use this as an excuse to neglect my work because I deserved it.
[cpg]


I also stopped by the Merkur Trading Company store. Then I went to ......
[cpg]


[OnName num="kurto"]
Hmm?
[cpg cn=true]


The store that used to sell something similar to my invention was under renovation.
[cpg]


I wondered at the time if they were going to make another move.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



But the truth was quite the opposite.
[cpg]


[OnName num="merchant"]
I'm sorry for interrupting your ...... until now.
[cpg cn=true]


Not the other way around, or in terms of advancing one move, you're right.
[cpg]


[OnName num="kurto"]
What do you mean?"
[cpg cn=true]


The merchant who had been opposing my store and probably a bigwig from the Mercure Chamber of Commerce had come to my store.
[cpg]


[OnName num="company_executive"]
Hey, you can't apologize like that," he said. That's no way to apologize."
[cpg cn=true]


[OnName num="merchant"]
'...... sorry about that.'
[cpg cn=true]


It seemed that things were going to turn out just as Yuika had said.
[cpg]


[OnName num="company_executive"]
Let me apologize to you as well. I am sorry that someone from our trading company has interfered with you."
[cpg cn=true]


I listened to him, thinking that that was the way he was going to put it.
[cpg]


It was only to say that an individual had interfered on his own and that he was trying to build a cooperative relationship with me.
[cpg]


For what it's worth, I'm sure the production system was such that it wouldn't have been possible without the Chamber of Commerce behind it. ......
[cpg]


[OnName num="kurto"]
No," he said. I think I was the one who was rude."
[cpg cn=true]


But let's be as smart as possible here. I don't want to bump into each other again here.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
[FADEOUTBGM]
;//ブラックアウト



I was thinking that it would have been easier if Yuika had been there, but I managed to talk things over with her on my own.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_08"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika120"]
[OnName num="yuika"]
It didn't take long. It's a nice flip-flop, isn't it?
[cpg cn=true]


[OnName num="kurto"]
No,...... I'm relieved.
[cpg cn=true]


I went to talk to Yuika about what had happened.
[cpg]


So as not to get into trouble with the Mercure Group of Commerce, but still maintain a cooperative relationship with Yuika's company.
[cpg]


What a bugger, but the result is that we are now in a situation where we have no more enemies in the creation of our inventions.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuika121"]
[OnName num="yuika"]
I hope that this time we can cooperate with the Mercure Chamber of Commerce.
[cpg cn=true]


[OnName num="kurto"]
If there is anything I can do, I will do it.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika122"]
[OnName num="yuika"]
'I'll do everything I can, too. I will do everything I can, including asking for your help.
[cpg cn=true]


After saying this, Yuhka-san giggles.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika123"]
[OnName num="yuika"]
I really want Arma and Kurth to be happy. I guess their status as commoners is getting in the way."
[cpg cn=true]


[OnName num="kurto"]
...... such."
[cpg cn=true]


I felt somewhat happy, embarrassed, and delicate.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夕方）******************************************************



The first person I should talk to is Yuika. This is something that should not be done in the wrong order.
[cpg]


But the next person I went to talk to was, of course, Arma.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Alma488"]
[OnName num="alma"]
She said, "I'm glad you're ....... I don't really feel it, though.
[cpg cn=true]


[OnName num="kurto"]
I don't either," she said. You really have become a merchant with no enemies in this country,......."
[cpg cn=true]


As far as inventions go, I can say that I'm the sole owner.
[cpg]


I have reached my goal. What am I going to do now?
[cpg]


Oh my God, I've already decided what I'm going to do. I'm going to be happy with Arma.
[cpg]


[OnName num="kurto"]
"Arma. I think I've become a great merchant without question.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Alma489"]
[OnName num="alma"]
"Yes. Yes, you are.
[cpg cn=true]


Let's get married. I wish I could say that one word.
[cpg]


[OnName num="kurto"]
We'll be together forever. Arma."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

What came out of my mouth were those words. Arma seemed to see through that and laughed a little.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Then came another busy day.
[cpg]


I don't have much time to spend with Arma.
[cpg]


But on my days off, I wanted to be with Arma as much as possible.
[cpg]





[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１のお屋敷＿広間』（夜）******************************************************



When I was with Arma, we talked about many things.
[cpg]


About the future, the past, and the present.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Alma490"]
[OnName num="alma"]
She told me that she was going to have a baby brother or sister soon.
[cpg cn=true]


It was very medieval that we didn't know the sex of the baby.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Alma491"]
[OnName num="alma"]
Yes. Yes, that means it's a real child from my parents' point of view.
[cpg cn=true]


Arma looked happy and a little sad at the same time.
[cpg]


[OnName num="kurto"]
Maybe Arma is a real child, too.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Alma492"]
[OnName num="alma"]
......I'm sure you'll say that."
[cpg cn=true]


Arma must have gone through a lot in her life.
[cpg]


To go out with her is to go out with all those things.
[cpg]


I'm sure Arma feels the same way about me.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Alma493"]
[OnName num="alma"]
"Hey, Kurth. If we had a child, how would it grow up?
[cpg cn=true]


[OnName num="kurto"]
I don't want him to take over this job, but I'd be happy if he wants to be a merchant.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Alma494"]
[OnName num="alma"]
"Hmmm. I'm sure he would.
[cpg cn=true]



;//ブラックアウト
;//========================================
;//●ＣＧ（ヒロインと朝を迎える）ev_31
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン１の部屋
;//時間　：夜
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bgm_09"]
;**【ＣＧ】 ev_31_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています



[VOICE f="Alma514"]
[OnName num="alma"]
"Hmm,...... is it morning already?"
[cpg cn=true]


[OnName num="kurto"]
Oh, good morning, ...... Arma.
[cpg cn=true]



[VOICE f="Alma515"]
[OnName num="alma"]
Time seems to be flying by lately.
[cpg cn=true]


[OnName num="kurto"]
Well, they say good times go by fast.
[cpg cn=true]



[VOICE f="Alma516"]
[OnName num="alma"]
Maybe that's what it is."
[cpg cn=true]


The two of us greet the morning together, rubbing our eyes.
[cpg]


[OnName num="kurto"]
I'm having a lot of fun with Arma, too.
[cpg cn=true]


;**【ＣＧ】 ev_36_a ***********************
[CG id=10 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Alma517"]
[OnName num="alma"]
"I'm always happy to be with Arma. I'm glad.
[cpg cn=true]


Morning. The beginning of the day. I felt as if the dawn had dawned for us.
[cpg]


Looking back, I felt like I had been drifting through the night all my life.
[cpg]


It was Arma who showed me the sun.
[cpg]


[OnName num="kurto"]
I don't think I've ever seen such a dazzling sun.
[cpg cn=true]



[VOICE f="Alma520"]
[OnName num="alma"]
What do you mean?　What do you mean?
[cpg cn=true]


[OnName num="kurto"]
It's the dawn for us," Arma said. This is where it all starts.
[cpg cn=true]



[VOICE f="Alma521"]
[OnName num="alma"]
It's a difficult thing to say. But if ...... morning has come, we have to get up.
[cpg cn=true]


[OnName num="kurto"]
I know. ......
[cpg cn=true]


Somewhere along the way, I've distanced myself from hope.
[cpg]


When I finally confronted it, I felt strangely tired or sleepy.
[cpg]


[OnName num="kurto"]
I knew I should get some more sleep.
[cpg cn=true]



[VOICE f="Alma522"]
[OnName num="alma"]
No, you don't. Come on, let's get up. Come on, let's get up.
[cpg cn=true]


I think Arma is the one who pulls me through.
[cpg]


She's the one who gave me hope. She's like this glaring sun.
[cpg]


My life has been drifting through the night. But with Arma, I can greet mornings like this.
[cpg]




;//ブラックアウト

[SCENE id=15]

[jump storage="epend.ks" target="*start"]

;//ＥＮＤ　ヒロイン１ルート
;//==============================
