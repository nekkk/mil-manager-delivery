
*start

;//５、カタリーナ


;#################################################
*Ep013|The Mysterious Katharina
;#################################################

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]


*select07_5|The Mysterious Katharina

[SCENE id=13]


I found myself thinking about Katharina.
[cpg]


She has a mysterious charm. Mysterious, yet honest in her desires.
[cpg]


I think she is second only to me in terms of her love for her inventions.
[cpg]


I had been attracted to her for some time.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



Thinking about Katharina, I'm working as a store keeper again today.
[cpg]



[SE f="se002"]
;//【ＳＥ】『ドア開く』

[WAIT time=1100]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Catalina212"]
[OnName num="catalina"]
Hello, Kurth and Bianca. Kurth, Bianca.
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Bianca535"]
[OnName num="bianca"]
Hello!　You came to help us today too?
[cpg cn=true]

I continued to talk with Katharina for a while. The conversation was about the invention.
[cpg]

[OnName num="kurto"]
She was talking about her inventions. You must have more ideas than I do.
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Catalina216"]
[OnName num="catalina"]
I don't think so. I can't compete with your passion.
[cpg cn=true]


Bianca was very attentive at that moment.
[cpg]


[free time=1000]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Bianca536"]
[OnName num="bianca"]
I've got some business to take care of.　I have some business to attend to.
[cpg cn=true]


[OnName num="kurto"]
"Oh, ......, yes."
[cpg cn=true]


I wonder if she had such an errand to run. Maybe not, but I can be alone with Katharina.
[cpg]


[free time=1000]


[SE f="se004"]
;//【ＳＥ】『ドア閉まる』
[WAIT time=1100]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Catalina217"]
[OnName num="catalina"]
"...... Mr. Kurth. Do you have a dream?"
[cpg cn=true]


[OnName num="kurto"]
I have a dream. I want to become a world-class merchant.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Catalina218"]
[OnName num="catalina"]
That's a wonderful dream. It's a wonderful dream.
[cpg cn=true]


I know that Katharina is also interested in me.
[cpg]


The time was lovely. The indescribable distance between us was comfortable.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************



Still, I didn't confess my feelings that day.
[cpg]



[SE f="se002"]
;//【ＳＥ】『ドア開く』



By the time Bianca came back, Katharina was gone.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Bianca537"]
[OnName num="bianca"]
She said, "Well, ...... how did it go with Lady Katharina?"
[cpg cn=true]


She must have guessed a lot and said so, but I shook my head.
[cpg]


Bianca looked both disappointed and relieved.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca538"]
[OnName num="bianca"]
She shook her head. I think that Katharina-sama probably likes her master.
[cpg cn=true]


[OnName num="kurto"]
'Do you think so ......?'
[cpg cn=true]


I said, but I agree with him. I just don't have the courage.
[cpg]



[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I close up store for the day. I turn the sign over and lock the door.
[cpg]


On the way home, all the way home, I've been wondering.
[cpg]


Bianca would probably be depressed if I went out with Katharina.
[cpg]


At this indescribable distance, I felt as if I would be happy not dating anyone.
[cpg]




[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



Back at home, I wondered once again if that would be enough.
[cpg]


Katharina wouldn't wait for me forever.
[cpg]


I knew I had to try to change.
[cpg]


But I still don't have the courage. It's not that I'm afraid of being rejected, but rather I'm afraid of the change of environment.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



As I was worrying about this and that, the morning came without much sleep.
[cpg]


I rubbed my sleepy eyes and got up. Even though it is a holiday, I don't feel like going back to sleep.
[cpg]


I felt that my eyes were that bright.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中の集落』（昼）******************************************************



Somehow I couldn't sit still at home, so I went to Katharina's house.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Catalina220"]
[OnName num="catalina"]
Hello," she said, "what are you doing here? What can I do for you?
[cpg cn=true]


[OnName num="kurto"]
...... I see you're reading outside today, too."
[cpg cn=true]


As in the past, she was reading a book. She was reading, too, at a very fast pace.
[cpg]


She's got speed-reading skills, right? I'm remembering ......
[cpg]


[OnName num="kurto"]
'You're very studious, aren't you?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="sCatalina014"]
[OnName num="catalina"]
'That must be the same for you. I don't know anyone as dedicated to invention as you are."
[cpg cn=true]


[OnName num="kurto"]
If that's the case, we may be very much alike.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Catalina222"]
[OnName num="catalina"]
Yes, we are. If I were a man, if I were a man, I might have a life like yours.
[cpg cn=true]


[OnName num="kurto"]
If I were a woman in Arlaune, would I be like Katharina?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Catalina223"]
[OnName num="catalina"]
If I were ......, I'd be like ......."
[cpg cn=true]

[FADEOUTBGM]

After saying that much, she fell silent. We both have the same thing to say.
[cpg]


[OnName num="kurto"]
I have something important to say to you. I have something important to tell you.
[cpg cn=true]


I finally decided to start the conversation. I was in no mood.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Catalina224"]
[OnName num="catalina"]
What is it?
[cpg cn=true]


I think it's important to confess your feelings in a special situation and on a special day.
[cpg]


But rather, I have a desire to blend into the everyday life she spends with me.
[cpg]


I think Katharina understands this, somehow.
[cpg]


[OnName num="kurto"]
I have someone I've always loved.
[cpg cn=true]


Katharina stopped flipping through her book and turned to me. Then she turned her head toward me.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Catalina225"]
[OnName num="catalina"]
I have someone too. Shall we say it now?
[cpg cn=true]


She seemed to be in a state of anxious anticipation.
[cpg]


[OnName num="kurto"]
No," she said, "let me do the talking. Let me say it first.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
Katharina looked at me and said, "Okay.
[cpg]


We were in the forest. The sun was shining through the trees. She looked even more beautiful in the sunlight.
[cpg]

[BGM f="bgm_09"]

[OnName num="kurto"]
I love you, Katharina-san. I love you.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Catalina226"]
[OnName num="catalina"]
Thank you. I thought you liked Bianca.
[cpg cn=true]


I thought you liked Bianca," Katharina said, but she seemed relatively unconcerned.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Catalina227"]
[OnName num="catalina"]
"Am I good enough for you?　I'm sure there are more people who would make a pass at you."
[cpg cn=true]


She said that because she knew I was in love with Katharina.
[cpg]


Thinking it was somewhat unfair, I said again.
[cpg]


[OnName num="kurto"]
'It's not that I'm being courted by anyone, it's just that I like you, Katharina-san.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Catalina228"]
[OnName num="catalina"]
'I bet you do. I kind of can't believe it."
[cpg cn=true]


Katharina closed the book and stood up. Then she went toward the house.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Catalina229"]
[OnName num="catalina"]
She stood up and went toward the house. Let's talk some more.
[cpg cn=true]


[OnName num="kurto"]
"......Yes."
[cpg cn=true]




;//ブラックアウト

Of course. I had a feeling that it was going to be more than just talking. I had a feeling.
[cpg]


;//========================================
;//●ＣＧ（ベッドに仰向けになっているヒロイン）ev_56
;//人物１：ヒロイン５　服装１：裸
;//人物ex：主人公　　　服装ex：裸
;//場所　：ヒロイン５の部屋
;//時間　：夕方
;//========================================
;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bgm_09"]
;**【ＣＧ】 ev_56_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

When I am in Katharina's presence, I sometimes lose my composure.
[cpg]

Does Arlaune have that kind of power?　I heard that she can control people with pheromones. ......
[cpg]

Even if that was the case, I was fine with it.
[cpg]


[VOICE f="sCatalina015"]
[OnName num="catalina"]
......"
[cpg cn=true]


I hugged her as she closed her eyes.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落』（夕方）******************************************************



I realized that it was evening. I had talked to her more than I had imagined.
[cpg]


[OnName num="kurto"]
Well, I'm going back now.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Catalina253"]
[OnName num="catalina"]
"Okay. See you later, Kurth.
[cpg cn=true]


I waved goodbye to Katharina.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="kurto"]
......"
[cpg cn=true]


I couldn't help but smile. I was in such a mood.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Bianca539"]
[OnName num="bianca"]
Master, did something good happen to you?
[cpg cn=true]


[OnName num="kurto"]
'Oh ...... well.'
[cpg cn=true]


Bianca didn't pursue it deeply. I'm sure you've already noticed that.
[cpg]


Me and Ms. Katharina became lovers.
[cpg]


I don't feel indebted to anyone anymore. I have a clear idea of who is important to me.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

After that, I started visiting Katharina's place.
[cpg]


;//========================================
;//●ＣＧ（主人公に寄り添うヒロイン）ev_57
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン５の部屋
;//時間　：夕方
;//========================================
;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bgm_09"]
;**【ＣＧ】 ev_57_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています


[VOICE f="sCatalina016"]
[OnName num="catalina"]
I feel at home when I am by your side like this.
[cpg cn=true]


Even she said that to me.
[cpg]

I thought it was a true feeling.
[cpg]

I want to stay by your side forever. For that reason, I want to make my business more successful. ......
[cpg]

If I need money just to survive, I will need more if I want to support her.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中の集落』（夜）******************************************************



While I was thinking about this, Katharina broached another subject.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Catalina281"]
[OnName num="catalina"]
She said, "...... Hey, Kurth.
[cpg cn=true]


[OnName num="kurto"]
What is it?　You look serious.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Catalina282"]
[OnName num="catalina"]
I don't know. I don't think so, but it is serious.
[cpg cn=true]


Katharina took a piece of paper from the shelf and unfolded it.
[cpg]


[OnName num="kurto"]
It is .......
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Catalina283"]
[OnName num="catalina"]
It's still in its infancy, but it's called summoning magic. It is a magic that creates living creatures.
[cpg cn=true]


[OnName num="kurto"]
Why do you have this?
[cpg cn=true]


I was about to say, "Why this?
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="sCatalina017"]
[OnName num="catalina"]
I was about to say, "How did you come up with this? This is something that will completely change that.
[cpg cn=true]


It saves time and ...... effort. No, on the contrary, it means that you can create creatures in accordance with your intentions.
[cpg]


[OnName num="kurto"]
Is that possible?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Catalina285"]
[OnName num="catalina"]
"Did you ever wonder about your mischievous magic?"
[cpg cn=true]


[OnName num="kurto"]
"I wonder ......, that's true, but..."
[cpg cn=true]


I don't know what you're talking about, but I'm going to reply.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="sCatalina018"]
[OnName num="catalina"]
The power to make wishes come true associated with inventions. Roughly speaking, that's what your skills are.
[cpg cn=true]


I still don't understand why he is saying that now.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Catalina287"]
[OnName num="catalina"]
Let me put it plainly. If you combine your skills with my knowledge, you can create living things.
[cpg cn=true]


It was something that seemed like such an absurd ...... thing to say.
[cpg]


The first thing you need to do is to find out what you are looking for.
[cpg]


[OnName num="kurto"]
If I could ...... do such a thing, my business wouldn't need any capital at all, would it?
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Catalina288"]
[OnName num="catalina"]
Yes. Yes, it's a terrible thing. It's a scary thing, and I'm willing to take on the challenge.
[cpg cn=true]


;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中の集落』（夜）******************************************************



Then, as he was leaving, he said.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sCatalina019"]
[OnName num="catalina"]
"You can call me Katharina-san ...... now, can't you?"
[cpg cn=true]


[OnName num="kurto"]
What?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Catalina313"]
[OnName num="catalina"]
"No. I'll tell you what, Kurth. No. I'll tell you what, Kurth.
[cpg cn=true]


Katharina-san called me "Ms. Katharina". That's what you mean.
[cpg]


[OnName num="kurto"]
"...... Katharina."
[cpg cn=true]


I blushed a little and looked away, even though she was the one who said it.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Catalina314"]
[OnName num="catalina"]
I'm a little embarrassed after all. I don't mind saying it myself.
[cpg cn=true]


[OnName num="kurto"]
I'm not embarrassed to say ...... or to have it said to me. Katharina.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Catalina315"]
[OnName num="catalina"]
I'm not ashamed to say it. You're calling me by my name with emphasis.
[cpg cn=true]


[OnName num="kurto"]
"No, I'm not."
[cpg cn=true]


I thought I saw an unexpected aspect. She was shy in this respect.
[cpg]



;//ブラックアウト


[FACE method="bow_1" pos="2/3"]
[VOICE f="Catalina316"]
[OnName num="catalina"]
See you later.
[cpg cn=true]


[OnName num="kurto"]
I'll be back. I'll be back.
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I went back to my house and thought about this and that.
[cpg]


Katharina is trying to create a demon with summoning magic.
[cpg]


If it is really possible, what could be more convenient than that?
[cpg]


Our business would make even greater strides. ......
[cpg]


Of course, there can't be no obstacles, or can there? I was sure it would be a dangerous magic.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_04"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



The next day, while I was tending to the store and planning future business strategies.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yuika488"]
[OnName num="yuika"]
He said, "Hello. I heard you went out with Katharina?"
[cpg cn=true]


[OnName num="kurto"]
What?
[cpg cn=true]


Bianca was standing next to me. I turned to Bianca, expecting her to be surprised, too.
[cpg]


[free time=1000]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Bianca540"]
[OnName num="bianca"]
I turned to Bianca, expecting her to be surprised as well.
[cpg cn=true]


I turned to Bianca, expecting her to be surprised as well, and for some reason, she showed a calm reaction.
[cpg]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Yuika489"]
[OnName num="yuika"]
What is there to be surprised about?　I heard it from Catherina herself.
[cpg cn=true]


[OnName num="kurto"]
'I didn't know that. ...... You're a chatty one, aren't you?'
[cpg cn=true]


I was a little surprised, but I was still surprised.
[cpg]


The actual "I'm not a fan of the way you look at it, but I'm not a fan of the way you look at it either.
[cpg]



[SE f="se002"]
;//【ＳＥ】『扉開く』



[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Catalina317"]
[OnName num="catalina"]
Oh, I see you're here too,......," she said.
[cpg cn=true]


Then, Katharina herself appears.
[cpg]

[FACE method="change_1" pos="2/5"]
[OnName num="kurto"]
I'm not going to tell her that we're dating. Don't tell people you're dating ...... too much.
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Catalina318"]
[OnName num="catalina"]
I'm not lying.　I'm not lying.
[cpg cn=true]


She may be quite possessive.
[cpg]


I was glad in a way that she thought so.
[cpg]


[FACE method="change_2" pos="2/5"]
[VOICE f="Yuika490"]
[OnName num="yuika"]
She was hot," he said. I shouldn't stay too long.
[cpg cn=true]


[OnName num="kurto"]
No, no, that's not ......."
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************





From there, Yuika and Katharina, in turn, asked me what I wanted to do.
[cpg]


Yuika talked about how she was going to increase the number of stores in the future.
[cpg]


She said she would give me her full cooperation. It's hard to imagine me following someone ......
[cpg]


And what was Katharina's story?
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Catalina319"]
[OnName num="catalina"]
She said, "The summoning magic, you know. I've completed it.
[cpg cn=true]


[OnName num="kurto"]
What?　That was so easy.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sCatalina020"]
[OnName num="catalina"]
I'm surprised too. I really need the magic stone ...... that contains your magic.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Catalina321"]
[OnName num="catalina"]
I am surprised at how easy it was to complete.
[cpg cn=true]


Katharina-san must have made the great discovery of the century, but her face was not cheerful.
[cpg]


[OnName num="kurto"]
Let's give it a try right away. What kind of demons can we summon?
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Catalina322"]
[OnName num="catalina"]
Yes, I think so. ......
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



From there, I was about to go to Katharina's place, but she had something else in mind.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Catalina323"]
[OnName num="catalina"]
I want to go to your house. Is that a bad idea?
[cpg cn=true]


[OnName num="kurto"]
I don't think so," she said.
[cpg cn=true]


[free time=1000]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

I looked at Bianca, who was standing next to me. She didn't look jealous, but maybe she was trying her best to hold it together.
[cpg]


But they may be holding out hard. Even if it is Katharina's wish, it is ......
[cpg]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Bianca541"]
[OnName num="bianca"]
'If it were me, I wouldn't mind. I would like to be friends with Lady Katharina as well."
[cpg cn=true]


[OnName num="kurto"]
...... I see."
[cpg cn=true]


I decided to take Bianca at her word.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Bianca cooked the meal for the three of us.
[cpg]


Katharina also helped from the middle of the meal. She was not a bad cook either.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Then, in the middle of the night, ...... I couldn't summon the slime in my room, so I came to the forest a little ways away.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Catalina324"]
[OnName num="catalina"]
With this I should be able to summon ...... them."
[cpg cn=true]


I spread out a large piece of paper with a magic circle drawn on it. Then I place some small magic stones.
[cpg]


I put a few small magic stones on the paper, probably with my Mischief-making Magic in them.
[cpg]



[SE f="se018"]
;//【ＳＥ】『魔法　パッド系の音』



;//画面白く

[free time=1000]
[BG f="white.ui" time=1000]
;//ホワイトアウト


The magic circle emits a light that makes it impossible to stare at the magic stones.
[cpg]



;//画面徐々に黒く


[free time=1000]
[BG f="b_12_4.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



And when the light is gone, ......
[cpg]


[OnName num="kurto"]
'Wow ...... I can really summon it.'
[cpg cn=true]


The slime was there. It was not attacking us, and it was quiet.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Catalina325"]
[OnName num="catalina"]
It is a slime that listens to human commands, which I have created after much adjustment.
[cpg cn=true]

It is true that this slime is a viable product.
[cpg]


;//移植のためシーンをカットしています



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_12_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



The slime she had created could easily be erased by another magic circle.
[cpg]


It's a slime that listens to you in the first place, assuming the slime is on that magic circle.
[cpg]


Convenient is good. It's good, but isn't ...... too convenient?
[cpg]


I had a rather unpleasant imagination.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落』（夕方）******************************************************



The next day. It was a holiday, so I visited Katharina's place.
[cpg]


[OnName num="kurto"]
"Hi, Katharina. Katharina.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Catalina351"]
[OnName num="catalina"]
Hello. You came to see me.
[cpg cn=true]


[OnName num="kurto"]
Yeah, well, partly because ...... I want to see Katharina.
[cpg cn=true]


[OnName num="kurto"]
You know, the summoning spell. Is it really that dangerous?
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Catalina352"]
[OnName num="catalina"]
...... I think so, don't you?
[cpg cn=true]


Only Katharina knows how summoning magic works.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Catalina353"]
[OnName num="catalina"]
I don't know how much you can imagine. ......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Catalina354"]
[OnName num="catalina"]
If I announce that I have perfected summoning magic, I might be called the best wizard in the country.
[cpg cn=true]


[OnName num="kurto"]
"...... I know, right? I knew it."
[cpg cn=true]


[OnName num="kurto"]
But you have your reasons for not doing so, don't you?
[cpg cn=true]


[FACE method="cbow_1" pos="2/3"]
[VOICE f="Catalina355"]
[OnName num="catalina"]
'Yes. I invented it. I'm the one who knows best the dangers of this magic.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Catalina356"]
[OnName num="catalina"]
"Any powerful person would think so. If there is a demon that listens to you, you want to use it as a pawn.
[cpg cn=true]


In other words, it is something that could be used for military purposes.
[cpg]


If so, Katharina's life could be in danger.
[cpg]


[OnName num="kurto"]
Katharina said, "Katharina, I want to talk to you about something. I'd like to talk to you about something, okay?
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Catalina357"]
[OnName num="catalina"]
Yes. I can't keep this secret ...... to myself either.
[cpg cn=true]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中の集落』（夜）******************************************************



After that, Katharina and I talked for a while.
[cpg]


After all, we can't afford not to make this slime into a product.
[cpg]


But that doesn't mean we can't say we made up the summoning magic. It's a difficult point.
[cpg]

We talk and talk, but we can't come to a conclusion.
[cpg]

This was a problem that researchers in the world I was originally from might also be having.
[cpg]


As we discussed it, we came to the conclusion that summoning magic is not something that can be done openly.
[cpg]


I'll have to think about how to sell it. But ......
[cpg]


[OnName num="kurto"]
Let's not think about that right now, let's stay together.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Catalina385"]
[OnName num="catalina"]
I'm not thinking about that now, but let's stay together. That's okay, though. ......
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



And after a while.
[cpg]


We ended up hiding the fact that we had summoned them and started selling them as if we had taken them from somewhere.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



The sales were good. Thanks to Katharina.
[cpg]


Unfortunately, though, no one will ever know what Katharina has done. ......
[cpg]


But it seemed better than being in a situation where I couldn't use it for anything.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Edith153"]
[OnName num="edith"]
'Oh, hello .......'
[cpg cn=true]


[OnName num="kurto"]
'Oh, hello, I see you've got the goods for this week.'
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Edith154"]
[OnName num="edith"]
'Yeah ...... um, what's this?"
[cpg cn=true]


Seeing the slime in the jar, Mr. Edith was also curious.
[cpg]


[OnName num="kurto"]
It's slime. Would you like to buy some?
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Edith155"]
[OnName num="edith"]
No, I'm good.
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************



As it turned out, I was wrong. The peaceful moment did not last long.
[cpg]



[BGM f="bgm_06"]

[FACE method="shock_5" pos="2/3"]

[OnName num="soldier"]
"This is the place! This is the place to be!
[cpg cn=true]


A guard kicked in the door and entered the store.
[cpg]


[OnName num="kurto"]
What? What's going on?
[cpg cn=true]


[OnName num="soldier"]
We received a report that there is a witch here who is trying to destroy the country with her shady experiments.
[cpg cn=true]


Katharina and I immediately knew what it was.
[cpg]


It was about summoning magic. It was difficult to keep it hidden, after all.
[cpg]


[OnName num="kurto"]
What the hell is that? That's a false accusation!
[cpg cn=true]


[OnName num="soldier"]
Shut up! That subhuman woman there! It's you! Get her out of here!
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Catalina390"]
[OnName num="catalina"]
Fuck...
[cpg cn=true]


[OnName num="kurto"]
Stop it! Don't touch her!
[cpg cn=true]


[OnName num="soldier"]
What? You're one of them! Get him!
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Catalina391"]
[OnName num="catalina"]
Stop it, Kurth. Stop it, Kurth. I'll be quiet... just leave him alone.
[cpg cn=true]


[OnName num="kurto"]
What are you talking about?
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Catalina392"]
[OnName num="catalina"]
I'll be fine.
[cpg cn=true]


She gets caught developing dangerous magic.
[cpg]


I was only sheltered and couldn't help her.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_07"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************



I go to see Katharina.
[cpg]


[OnName num="kurto"]
Are you okay?
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Catalina393"]
[OnName num="catalina"]
Yeah, I'm fine.
[cpg cn=true]


[OnName num="government_official"]
I hear you have something to say. I'm busy, so make it quick.
[cpg cn=true]


I managed to get her to tell me that she was not a danger to herself.
[cpg]


I managed to explain to the official that she was not making this up as she went along.
[cpg]


[OnName num="government_official"]
"Can you believe such a story?
[cpg cn=true]


[OnName num="kurto"]
Believe me! It's true!
[cpg cn=true]


But the official would not listen to me.
[cpg]


[OnName num="kurto"]
What in the world am I supposed to do?
[cpg cn=true]



[SE f="se026"]
;//【ＳＥ】『地震』

[FADEOUTBGM]
[FO pos="2/3" time=1000]
[WAIT time=1100]


[OnName num="government_official"]
What the hell is this tremor?
[cpg cn=true]


[BGM f="bgm_06"]

[OnName num="soldier"]
Excuse me! Oh, my God! Demons have invaded!
[cpg cn=true]


One after another, problems occurred.
[cpg]


Nothing needs to come at a time like this.
[cpg]


But the surroundings are in turmoil. We should be able to escape while we still can.
[cpg]


Thinking so, Katharina-san tugged at the hem of my clothes.
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Catalina394"]
[OnName num="catalina"]
"Kurth-san!
[cpg cn=true]


[OnName num="kurto"]
Katharina-san! While we still can..."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
But she shakes her head at my suggestion.
[cpg]


[OnName num="kurto"]
"This...?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Catalina395"]
[OnName num="catalina"]
I'll leave it with you.
[cpg cn=true]


In the midst of the confusion, Katharina handed me a note.
[cpg]


The note was about summoning magic.
[cpg]


[OnName num="kurto"]
What are you talking about? Let's get out of here while we still can.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Catalina396"]
[OnName num="catalina"]
If we run away, we won't be able to prove our innocence. So...please help me."
[cpg cn=true]


He was right. If I run away now, I will be admitting my guilt.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Catalina397"]
[OnName num="catalina"]
Please... can you do that?
[cpg cn=true]


[OnName num="kurto"]
"All right. Leave it to me.
[cpg cn=true]





;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



[SE f="se023"]
;//【ＳＥ】『走る』



The summoning magic entrusted to me. I'm going to use it to get rid of the demons.
[cpg]


But I can't use this summoning magic. ......
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Alma539"]
[OnName num="alma"]
Kya!
[cpg cn=true]


[OnName num="kurto"]
"Oh, I'm sorry, Arma-san..."
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Alma540"]
[OnName num="alma"]
Mr. Kurth!
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Alma541"]
[OnName num="alma"]
What are you doing? The demons are coming at us. We have to get out of here.
[cpg cn=true]


[OnName num="kurto"]
I'm not running away. We have to stop this pack of demons.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Alma542"]
[OnName num="alma"]
It's too dangerous!
[cpg cn=true]


[OnName num="kurto"]
I want to save Katharina .......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Alma543"]
[OnName num="alma"]
Catherina?
[cpg cn=true]


[OnName num="kurto"]
There is a way. But it has to be someone who can use magic... can you help me, Arma?
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Alma544"]
[OnName num="alma"]
Yes, if you ask me!
[cpg cn=true]





;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_08"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



[SE f="se000"]
;//【ＳＥ】『喧騒』




After one night, the town was at peace.
[cpg]


With Arma's help, I recreated the summoning magic that Katharina had taught me.
[cpg]


I summoned a slime and hurled it at the demons that had invaded the country.
[cpg]


In this way, I succeeded in driving the demons away.
[cpg]


She was released safely, saying that this time it was Katharina's achievement.
[cpg]

;//[lbox off]
[free time=1000]
[WAIT time=1000]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="kurto"]
For a while I wondered what was going to happen, but... thank goodness.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Catalina398"]
[OnName num="catalina"]
Thank you. Thank you.
[cpg cn=true]


[OnName num="kurto"]
I can't believe it... you have a lot of heart, Katharina-san.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Catalina399"]
[OnName num="catalina"]
"Oh, no, you're not. You were very good looking. My husband.
[cpg cn=true]





;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************



[OnName num="kurto"]
Thank you very much.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Catalina400"]
[OnName num="catalina"]
Well... we have more guests.
[cpg cn=true]


[OnName num="kurto"]
Yes.
[cpg cn=true]


Despite the uproar, Katharina-san became a famous magician as a hero who saved the city.
[cpg]


My business is thriving because of it, and it's all good as a result.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//========================================
;//●ＣＧ（ベッドに横たわるヒロイン）ev_63
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_63_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[VOICE f="Catalina426"]
[OnName num="catalina"]
Not so long ago, I would never have thought of a future like this.
[cpg cn=true]


[OnName num="kurto"]
I'm glad I met you.
[cpg cn=true]



[VOICE f="Catalina427"]
[OnName num="catalina"]
I'm really glad I met you.
[cpg cn=true]


I'm going to keep this happiness and this store.
[cpg]

This happiness is something I couldn't have had if I hadn't met Katharina.
[cpg]



;//ブラックアウト

[SCENE id=18]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ　ヒロイン５ルート
;//==============================
