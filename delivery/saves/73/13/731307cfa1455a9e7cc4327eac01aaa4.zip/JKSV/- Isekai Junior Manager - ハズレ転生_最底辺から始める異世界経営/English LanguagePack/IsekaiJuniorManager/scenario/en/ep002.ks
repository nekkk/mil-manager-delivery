

*start

;#################################################
*Ep002|Culinary Knowledge
;#################################################

[SCENE id=2]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


I had some knowledge of cooking, although it was just barely usable or not.
[cpg]


For example, I have never seen noodles in this world, but I think I can make them as an ingredient.
[cpg]


[OnName num="kurto"]
What do you think of ......?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca037"]
[OnName num="bianca"]
If you ask me what I think of ...... my previous life, I don't know."
[cpg cn=true]


Bianca looked indescribable. The most important thing to remember is that you can't just take a look at the information you're given.
[cpg]


I don't believe it, but I don't believe it either. She didn't seem to think I was crazy.
[cpg]


[OnName num="kurto"]
There's this thing called noodles. I'm sure you can make that with the right ingredients.
[cpg cn=true]


Bianca knew more about cooking than I did. I could tell her the shape and most of the ingredients and ask her to imagine how to make it.
[cpg]


No, before that, ...... noodles are also called beating. I need to share my knowledge of this area too.
[cpg]


[OnName num="kurto"]
'First you make them into dumplings, then you stretch them out from there. Then you flatten it and cut it."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca038"]
[OnName num="bianca"]
It sounds like a lot of work,...... but if you could do it, it might be a never-before-seen dish."
[cpg cn=true]


That's right. With the proviso that if it could be done.
[cpg]


No, wait. Come to think of it, ......
[cpg]


[OnName num="kurto"]
What were Bianca's skills at ......?　Was it cooking, or housework?"
[cpg cn=true]


Bianca looks a bit dumbfounded, then says
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Bianca039"]
[OnName num="bianca"]
Bianca looked a little taken aback, and then said, "It's a skill for collecting. It's not useful as a maid of honor, though.
[cpg cn=true]


[OnName num="kurto"]
Bianca looked a little puzzled and then said, "It's not really useful as a maid of honor, though.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca040"]
[OnName num="bianca"]
The first thing to do is to find the right materials and the right place to find them. Yes, it's the skill of knowing what kind of materials can be found in what kind of places.
[cpg cn=true]


Bianca looked very proud of herself. The actuality that you can't remember is also a real concern, but it's also a skill that he's proud of.
[cpg]


[OnName num="kurto"]
Bianca is proud of her skills, though she seems to really mean it when she says that she's stunned that I can't remember. If I tell you what I'm going to make, will you know the ingredients?
[cpg cn=true]


[FACE method="shake_5" pos="2/3"]
[VOICE f="Bianca041"]
[OnName num="bianca"]
No, I can't go that far. ...... That's a superpower, isn't it?
[cpg cn=true]


From the world I was in in my previous life, both seem to be psychic powers.
[cpg]

[FACE method="change_1" pos="2/3"]

[OnName num="kurto"]
Anyway, all you need is flour, or eggs?"
[cpg cn=true]


What about the eggs? I think I'm going to need them.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca042"]
[OnName num="bianca"]
I don't know what it is, so I can't say for sure, but I think I can get by with the skill of collecting ...... eggs.
[cpg cn=true]


[OnName num="kurto"]
I guess so. The most important thing to remember is that you can't just buy flour. I'll try a few things for now.
[cpg cn=true]




;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]




So, for now, I started by making pasta.
[cpg]


It will be a revolutionary dish in this world, I feel. It's definitely something that's trendy.
[cpg]


[OnName num="kurto"]
I'm wondering, is the dough ...... too watered down?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca043"]
[OnName num="bianca"]
I don't know. I've never seen this dish before.
[cpg cn=true]


Even if you manage to make something that looks like dough, it's a lot of work from there.
[cpg]


[OnName num="kurto"]
I cut this into thin strips and boil them.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Bianca044"]
[OnName num="bianca"]
The more I hear about it, the stranger the dish is. The more I hear about it, the stranger it is.
[cpg cn=true]



[SE f="se000"]
;//【ＳＥ】『鍋煮える』



I followed his example and made it. After several failed attempts, it was finally taking shape.
[cpg]


[OnName num="kurto"]
I was about to make it into a shape when I heard, "When you boil it, it expands a lot. It's too thick.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Bianca045"]
[OnName num="bianca"]
Is that so ......?　It looks good just the way it is.
[cpg cn=true]




;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bgm_03"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[OnName num="kurto"]
"It's ...... done."
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca046"]
[OnName num="bianca"]
I think it's ...... pasta, right?
[cpg cn=true]


[OnName num="kurto"]
No, I don't know exactly what it is. I think it's called spaghetti.
[cpg cn=true]


I don't know if it's called spaghetti or spaghetti. Well, it's okay. ......
[cpg]


Even with my hazy knowledge, I was able to make a dish that I had never seen before in this world.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca047"]
[OnName num="bianca"]
Can I try it right away?　It's a dish that probably won't taste good after a while, right?
[cpg cn=true]


[OnName num="kurto"]
Oh," he said, "I'll have some. I'll take it.
[cpg cn=true]


For the sauce, I decided to use tomato sauce.
[cpg]


Tomatoes are grown by farmers in this area, so they are a stable source of ingredients.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca048"]
[OnName num="bianca"]
I thought to myself, "This is a strange food. It's not so much delicious as it is strange ......."
[cpg cn=true]


[OnName num="kurto"]
'No,...... it still doesn't have the right texture. I wonder what's different."
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Bianca049"]
[OnName num="bianca"]
'Yea!　It's not that it doesn't taste good."
[cpg cn=true]


Bianca is always there to help me out.
[cpg]


Anyway, I'm almost done. I struggled to make a pasta that was closer to the original.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



It took about a month until I was satisfied with the result. Then, I decided to go to the market.
[cpg]




;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bgm_02"]
;//[WAIT time=100]
;//【ＢＧ】『街＿異世界』（朝）******************************************************



And I went out to the city a little bit. The town was not so urban compared to the town where I used to live.
[cpg]


[OnName num="kurto"]
How about this place?
[cpg cn=true]


A typical restaurant. I chose a less expensive place.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Bianca050"]
[OnName num="bianca"]
It will be busy from noon. But maybe they are busy preparing for lunch.
[cpg cn=true]


[OnName num="kurto"]
Let's just go in. Let's sell as much as we can.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca051"]
[OnName num="bianca"]
"Master, you have become much more positive, haven't you? I'm glad.
[cpg cn=true]


I have to be positive. With that thought in mind, I opened the door to the dining room.
[cpg]



[SE f="se022"]
;//【ＳＥ】『入店音』

[free time=1000]


;//背景と別の場所なので、上下に黒帯を入れるなどしてください


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[OnName num="shop_owner"]
What is it?　We haven't opened yet.
[cpg cn=true]


[OnName num="kurto"]
Excuse me, may I? Let's see, ......."
[cpg cn=true]


I wondered how to sell it. I mean, Bianca and I could rent a kitchen and cook for them.
[cpg]


[OnName num="kurto"]
I've been learning to cook ...... some exotic dishes. I have a recipe I'd like you to take a look at."
[cpg cn=true]


I'm not wrong. It's not exotic, it's otherworldly.
[cpg]


[OnName num="shop_owner"]
"You're not a guest, you're a cook ......?　We have enough people.
[cpg cn=true]


[OnName num="kurto"]
"Would you just look at it?"
[cpg cn=true]


[OnName num="shop_owner"]
'Only if it's something you're willing to give up your precious time to see. You say it's exotic, but what kind of food is it?
[cpg cn=true]


You're eating some. Okay.
[cpg]


[OnName num="kurto"]
Pasta, or spaghetti?　It's called "spaghetti. If you let me use your kitchen, I can make it right now."
[cpg cn=true]


[OnName num="shop_owner"]
"......, I agree. Cooking is always in need of new ideas. If you say you come from a foreign country, let's see what you can do.
[cpg cn=true]


It is probably rare for a chef to come directly to a restaurant to sell his wares.
[cpg]


Bianca and I were allowed to use the kitchen for a short time.
[cpg]



;//[SE f="se014"]
;//【ＳＥ】『包丁が生地を切る』

;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bgm_03"]
;//[WAIT time=100]
;//【ＢＧ】『街＿異世界』（朝）******************************************************



;//背景と別の場所なので、上下に黒帯を入れるなどしてください


[OnName num="shop_owner"]
"You make ...... some pretty weird stuff. ...... It's got a big impact on the way it looks.
[cpg cn=true]


Let's consider it a compliment. It must be eccentric.
[cpg]


Not only the owner, but also the other cooks and waitstaff look at it as if it were a rarity.
[cpg]


[OnName num="shop_owner"]
'How am I supposed to eat this?'
[cpg cn=true]


It's probably right to roll it with a fork. When I told him that, the owner looked at me strangely again.
[cpg]


[OnName num="shop_owner"]
I told him that, and he looked at me curiously again, "Well, I can't eat them one at a time.
[cpg cn=true]


He seemed puzzled by the motion itself. In a world without pasta, I guess.
[cpg]

[FACE method="change_3" pos="2/3"]
Tasting. Bianca and I watched with bated breath.
[cpg]


[OnName num="kurto"]
"How about ......?
[cpg cn=true]


[OnName num="shop_owner"]
This is .......
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Bianca052"]
[OnName num="bianca"]
What do you think?
[cpg cn=true]


Bianca reiterated what I had said.
[cpg]


[OnName num="shop_owner"]
'There's room for improvement in the sauce,...... or rather, what sauce goes with it?　It's supposed to be a staple food. ......"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

The owner started mumbling.
[cpg]


[OnName num="shop_owner"]
Hey," he said, "what did you  say your name was? What did you ...... say your name was?"
[cpg cn=true]


[OnName num="kurto"]
Kurth. Kurth Rummeltz.
[cpg cn=true]


[OnName num="shop_owner"]
Kurth. "Kurth, I'm going to be frank with you, you are a gifted cook.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

Bianca and I looked at each other. I've done it.
[cpg]


[FACE method="change_1" pos="2/3"]
[OnName num="shop_owner"]
Your skills are amateurish, and you don't seem to be very sharp when it comes to flavor, but ...... your ideas are bizarre."
[cpg cn=true]


[OnName num="kurto"]
So ......
[cpg cn=true]


[OnName num="shop_owner"]
"Come work for us. I don't want to give your ideas to anyone else.
[cpg cn=true]



;//ブラックアウト



And so I finally found a job. I finally found a job, as a chef.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_08"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="kurto"]
I did it ......, Bianca. My memories of my past life are finally coming alive.
[cpg cn=true]


Night. I was going to have a toast with Bianca, but ......
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Bianca053"]
[OnName num="bianca"]
"Yeah. Yes.
[cpg cn=true]


Bianca is a little low.
[cpg]


[OnName num="kurto"]
What's wrong?　If I become the cook, Bianca will have less to do.
[cpg cn=true]


[OnName num="kurto"]
'I feel like I could even be the best in the world right now, if I had this memory.
[cpg cn=true]


Bianca didn't look too happy to hear that much.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca054"]
[OnName num="bianca"]
'But ...... I cook too, but I'm not that sweet.
[cpg cn=true]


[OnName num="kurto"]
You could be more pleased."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca055"]
[OnName num="bianca"]
'I don't think ideas alone make you a chef. I don't know how hard it is.
[cpg cn=true]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



Looking back, Bianca's words were a warning. I did not notice it, and Bianca's words were more of a warning.
[cpg]


I didn't realize it and tried to do Bianca's share of the work.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夕方）******************************************************



I was in high spirits, if that's the right word.
[cpg]


As the manager said, I was not very good at what I was doing. My taste buds are not sharp. All I had was the memory of a dish that had been popular in a previous life.
[cpg]


[OnName num="shop_owner"]
I remember a dish that was popular in a previous life: "...... you invented, was it pasta?
[cpg cn=true]


Between lunch and dinner time, when I have a little free time. So I talked to the manager.
[cpg]


[OnName num="kurto"]
"Yeah, it went viral.
[cpg cn=true]


[OnName num="shop_owner"]
Too much of a fad, you might say. There's not a restaurant in town that doesn't serve pasta now.
[cpg cn=true]


[OnName num="kurto"]
"......, yeah.
[cpg cn=true]


[OnName num="shop_owner"]
Every restaurant has improved on what you made. I'm trying, but I can't keep up.
[cpg cn=true]


[OnName num="shop_owner"]
As bizarre as the idea is, you have to know when to put it out there. If it's not close to perfection, it will be copied.
[cpg cn=true]


[OnName num="kurto"]
......
[cpg cn=true]


I can't say anything back. The next time, we must definitely do it right.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_06"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************



I made a variety of dishes. The first thing to do is to make sure that you have a good idea of what you're doing.
[cpg]


But ...... in the end, I realized that cooking is all about skill.
[cpg]


[OnName num="shop_owner"]
I was so excited that I decided to try it out.
[cpg cn=true]


The manager's efforts were in vain, and he could not make something that no one else could copy.
[cpg]


In no time at all, the recipe was stolen, other stores copied it, and sales dropped.
[cpg]


And eventually, ......
[cpg]




;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bgm_07"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FACE method="bow_7" pos="2/3"]
[VOICE f="Bianca056"]
[OnName num="bianca"]
"Welcome back, master. ...... is there something wrong?"
[cpg cn=true]


[OnName num="kurto"]
"Oh, ...... the store where I worked, it's going to close."
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Bianca057"]
[OnName num="bianca"]
What?　What happened?
[cpg cn=true]


[OnName num="kurto"]
"I heard he had a grudge against the place he stole the recipe from,......, and got into an altercation with a colleague.
[cpg cn=true]


In the end, I ended up ruining his life.
[cpg]


I'm sorry for what I did. It would have been a better outcome if I had been the only one to finish the job.
[cpg]


[OnName num="kurto"]
Food resentment is a terrible thing. ......
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca058"]
[OnName num="bianca"]
"It's more like a grudge of invention. ...... Ideas are things that people fight over.
[cpg cn=true]


I guess you need contacts, connections, backers, etc.
[cpg]


And above all, you need to know a lot about what you are inventing.
[cpg]


If he wanted to compete in the culinary arts, he would have had to make a more steady effort.
[cpg]



[free time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



For some reason, the erudite protagonist who remembers every detail of how to make everything is a thing in anime and manga.
[cpg]


They know it, but they usually don't know how it's actually made. At least I do.
[cpg]


I really need to invent something that no one can imitate. ......
[cpg]


On a hard futon, I have a hard time falling asleep and thinking.
[cpg]


The knowledge I have...... it is, after all, inevitable.
[cpg]


[OnName num="kurto"]
It's an invention,......."
[cpg cn=true]


I whisper to myself. The best way to do this is to use the best of the best. I want something that no one else can imitate.
[cpg]


[jump storage="ep003.ks" target="*start"]



;//=============================================================================
