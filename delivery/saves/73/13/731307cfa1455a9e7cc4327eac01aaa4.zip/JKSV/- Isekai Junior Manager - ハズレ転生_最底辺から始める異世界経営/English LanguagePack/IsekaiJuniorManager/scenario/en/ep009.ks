

*start

;#################################################
*Ep009|With whom do you wish to be happy?
;#################################################

[stflag Tai_sil = 0]
[stflag Cha_Flg1 = 0]
[stflag Cha_Flg2 = 0]
[stflag Cha_Flg3 = 0]
[stflag Cha_Flg4 = 0]
[stflag Cha_Flg5 = 0]

[if exp={getFlagValue("Tai_sil") == 0 }]
[stflag Tai_sil = 2000]
[endif]

[SCENE id=9]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="4/5" time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_07"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（朝）******************************************************



As I expanded my business, something unexpected happened.
[cpg]

[SE f="se022"]
;//【ＳＥ】『入店音』
[WAIT time=1000]

[OnName num="josef"]
Hey, long time no see."
[cpg cn=true]


[OnName num="emile"]
"......"
[cpg cn=true]


[OnName num="kurto"]
"My brother ......!"
[cpg cn=true]


Bianca and Arma were there too.
[cpg]

[FACE method="change_4" pos="2/5"]
[FACE method="change_4" pos="4/5"]

That's why I froze. Bianca and Arma couldn't say anything.
[cpg]


[OnName num="emile"]
Bianca and Arma couldn't say anything. Hey.
[cpg cn=true]


[OnName num="josef"]
I see you've made it big. Kurth, why don't you come back to my place?"
[cpg cn=true]


Brother Joseph laughed. It was unbelievable.
[cpg]


How could he laugh at me after he had tricked me? Brother Aamir did not seem to be pleased, but I could still understand his attitude.
[cpg]


[OnName num="josef"]
I underestimated Kurth. I apologize for that.
[cpg cn=true]


Brother Joseph's attitude was always light. I was annoyed inside, but he said, "Oh, you can't apologize for that.
[cpg]


[FACE method="shock_3" pos="4/5"]
[VOICE f="Bianca264"]
[OnName num="bianca"]
"Oh, you can't apologize like that!
[cpg cn=true]


[OnName num="kurto"]
Bianca ......
[cpg cn=true]


Before I could get angry, Bianca was getting angry.
[cpg]


[FACE method="shake_3" pos="4/5"]
[VOICE f="Bianca265"]
[OnName num="bianca"]
I was so angry that Bianca started to get angry before I could get mad at her.　You're being selfish!
[cpg cn=true]


[OnName num="josef"]
It's not up to you, the maid of honor, to interfere.
[cpg cn=true]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Alma032"]
[OnName num="alma"]
I agree with you. What do you think, Kurth?
[cpg cn=true]


Arma-san talks me out of it, and I think.
[cpg]


I know what you mean about the brothers accepting me now.
[cpg]


I guess I've got enough wealth ...... from the aristocrats to keep them on board.
[cpg]


[OnName num="kurto"]
I have no intention of going back home. I have nothing to do with you.
[cpg cn=true]


[OnName num="josef"]
I'm not going to cooperate with my brothers. Look, I'm fine, but I'm afraid you're going to make my brother angry.
[cpg cn=true]


[OnName num="kurto"]
I'm the one who's angry. I'm the one who's angry. Whatever you do, I'm going to beat it out of you," he said.
[cpg cn=true]


I expressed my anger to my brothers in the quietest tone possible.
[cpg]


[OnName num="josef"]
I said to them, "I see. You'll regret it."
[cpg cn=true]


As we were leaving, they were having this conversation.
[cpg]


[OnName num="emile"]
There was no room for negotiation from the beginning," I told them. He's a stubborn man.
[cpg cn=true]


[OnName num="josef"]
But he's still an idiot. A mere merchant should not be able to defy a nobleman.
[cpg cn=true]


I had a bad feeling about this.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



[FACE method="shake_7" pos="2/5"]
[VOICE f="Alma033"]
[OnName num="alma"]
Just remembering ...... makes me sick.
[cpg cn=true]


Arma's words somehow calmed me down.
[cpg]


[OnName num="kurto"]
She must be so angry with me. Thank you.
[cpg cn=true]


[FACE method="bow_3" pos="2/5"]
[VOICE f="Alma034"]
[OnName num="alma"]
Of course I am. I've heard what happened to Kurth.
[cpg cn=true]


Arma must be a kind person.
[cpg]


Moreover, she is also an adopted daughter. She must be angry at the idea of approaching someone she disowned of her own volition.
[cpg]


[OnName num="kurto"]
But I think I may have gotten myself into a bit of trouble. From now on, those two might harass me.
[cpg cn=true]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Bianca266"]
[OnName num="bianca"]
I don't care if they harass me.
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
Bianca was angry along with me.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



[FACE method="bow_7" pos="2/3"]
[VOICE f="Yuika064"]
[OnName num="yuika"]
I was so happy to see her. I'm sorry that happened to you.
[cpg cn=true]


[OnName num="kurto"]
I don't understand. I don't understand how you can take me as an ally after all this time.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Yuika065"]
[OnName num="yuika"]
"Really?　I understand it rather well. He was afraid that you would remain his enemy.
[cpg cn=true]


......That's one way of looking at it. But in the end, we became enemies.
[cpg]


[OnName num="kurto"]
"......Well, come to think of it, our new products are selling well. It's thanks to you, Yuika."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuika066"]
[OnName num="yuika"]
The first thing that comes to mind is that the two sides are enemies. But if you've made enemies of the nobility, you'd better not let your guard down.
[cpg cn=true]


That is definitely true. You never know what will happen in the future.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夕方）******************************************************


We can't just focus on the main store and product development. I also visit the second store from time to time to see how it is doing.
[cpg]


That is, of course, something that I should do as a manager, but ......
[cpg]


But I was also worried about what my brothers might have done.
[cpg]


[OnName num="employee_A"]
I was also concerned about whether my brothers were doing anything. But so far nothing has happened.'
[cpg cn=true]


[OnName num="employee_B"]
'Yes, that's right. Nothing in particular has been disturbed .......'
[cpg cn=true]


[OnName num="kurto"]
I see. That's fine then, thank you.
[cpg cn=true]


I'm in the position of asking you to do a job for me. I almost feel like I'm being polite, but I have to maintain my dignity.
[cpg]


[OnName num="employee_A"]
I didn't know the owner was a former aristocrat. I didn't know that."
[cpg cn=true]


[OnName num="kurto"]
Oh, yes. I didn't tell you.
[cpg cn=true]


I have it that my name is "the owner.
[cpg]


The store manager is the same as the store manager of this store, and I don't think there is any other suitable name.
[cpg]


On the other hand, it is somewhat embarrassing to be called "owner" by someone who is already a good friend of mine.
[cpg]


[OnName num="kurto"]
I don't care if you call me "aristocrat," because I'm not one anymore.
[cpg cn=true]


[OnName num="employee_B"]
Yes!
[cpg cn=true]


I'm a little unsure about that when you respond so cheerfully, but then again, I led you on, didn't I?
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

After leaving the second restaurant, I had a few thoughts.
[cpg]

I wondered what would happen if my brothers interfered in some way and made it impossible for the store to continue.
[cpg]

They would all lose their jobs too. It's not just me I have to protect anymore.
[cpg]

A normal person might have to just protect their own family.
[cpg]

Or, to protect only yourself is also a good answer.
[cpg]

But I wanted to protect the people who work for me.
[cpg]

Maybe management is made up of love. What a ...... thing to think for yourself, isn't it?
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************



[OnName num="kurto"]
......
[cpg cn=true]



Still, I'm strangely concerned about all my employees.
[cpg]


I came to this town where the second store is located with Arma, but ......
[cpg]


I didn't want to bother explaining what kind of relationship we had, so I was on my way to the second store by myself.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Alma035"]
[OnName num="alma"]
'I know it must be hard for you to care, but that's part of being a business owner.
[cpg cn=true]


[OnName num="kurto"]
'Well,...... it's getting pretty late, I think I'll stay here today.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Alma036"]
[OnName num="alma"]
I'm sure you'll be very happy to hear that.　Then, you know,......."
[cpg cn=true]


Arma-san is squirming. I wonder what's wrong.
[cpg]


[OnName num="kurto"]
What's wrong?　Your face is red.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Alma037"]
[OnName num="alma"]
No,......, I'm sure we've got some new products in stock. It's not for beastmen, it's an aphrodisiac ......."
[cpg cn=true]


Oh. Oh, I remember something like that.
[cpg]


[OnName num="kurto"]
It's not for any particular species, you know. It doesn't seem to work very well.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Alma038"]
[OnName num="alma"]
Then why don't you try it on me?"
[cpg cn=true]


Arma said this with a determined look on her face.
[cpg]


I thought to myself, "Oh, so that's what this is about.
[cpg]


She wants to do something like Bianca and Katharina, too. ......
[cpg]


It's not just those two. If you think about it, even Ms. Edith and Ms. Yuika.
[cpg]


It is also a situation where only Arma is left out of the group.
[cpg]


[OnName num="kurto"]
It's fine to say "......."
[cpg cn=true]


Is there any way to say, "Okay"?
[cpg]


[OnName num="kurto"]
Thank you very much. Then, may I try it?
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Alma039"]
[OnName num="alma"]
He said, "Yes. ......, please."
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



And we went into the inn.
[cpg]



[FACE method="change_1" pos="2/3"]
[VOICE f="Alma040"]
[OnName num="alma"]
'It's ...... liquid, isn't it? I wonder if I should drink it.
[cpg cn=true]


[OnName num="kurto"]
Yes, it is. It's an aphrodisiac that's not that strong. ......
[cpg cn=true]


Arma seemed nervous.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Alma041"]
[OnName num="alma"]
She was very ...... nervous.
[cpg cn=true]


There was no immediate effect on her body.
[cpg]


But even if it didn't have any effect,......
[cpg]


;//移植のためシーンをカットしています


;//========================================
;//●ＣＧ（媚薬に翻弄されているヒロイン。キャップ等は外してください）ev_16
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：宿の一室
;//時間　：夜
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bgm_09"]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]

Trying an aphrodisiac in front of me is one thing in itself.
[cpg]

If she was wary of me, she wouldn't have done this.
[cpg]


[VOICE f="Alma042"]
[OnName num="alma"]
'Hah, ¡®I¡¯ve got a hot body!'
[cpg cn=true]


That has nothing to do with the effect of the aphrodisiac anymore. What hubris.
[cpg]


She comes closer to me. And ...... our lips were about to touch.
[cpg]


;//移植のためシーンをカットしています



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]

[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************



It's just that I tried the product.
[cpg]


That was the excuse I could make to myself and what Arma was saying.
[cpg]


We can't be brave enough for each other, or we can't be ready for each other. ......
[cpg]


I guess that part is inevitable.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



[OnName num="kurto"]
I think that's what I'm saying. ......"
[cpg cn=true]


It's cheating, I think.
[cpg]


There was a question of whether this was the right thing to do. Aren't we playing with these women by calling it product development?
[cpg]


With that thought in mind, I headed to Mr. Edith's place.
[cpg]


Today, he was on his way to have another new invention made.
[cpg]


;//移植のためシーンをカットしています



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



;//背景と別の場所なので、上下に黒帯を入れるなどしてください



[OnName num="kurto"]
She said, "Thank you so much, Mr. Edito. You work so fast."
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="sEdith004"]
[OnName num="edith"]
"Don't worry about it,......, I like the work you bring me too."
[cpg cn=true]


[OnName num="kurto"]
I see. ......"
[cpg cn=true]


The words were no longer anything but affection.
[cpg]


[OnName num="kurto"]
I'm going to go back to the store. Bye.
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]

I knew it was love, but I could not accept it honestly.
[cpg]


My mind was occupied with the question of whom I should choose.
[cpg]


But I guess this is a happy problem.
[cpg]



;//[lbox off]
[FADEOUTBGM]
[free time=1000]
[BG f="b_11_2.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



While I was having a dreamy time, a conspiracy was going on behind my back.
[cpg]


The brothers were already putting pressure on me.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se022"]
;//【ＳＥ】『入店音』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_07"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca268"]
[OnName num="bianca"]
Welcome.
[cpg cn=true]


[OnName num="government_official"]
'Hmmm. Indeed, you are just as they say.
[cpg cn=true]


;//[free time=1000]
[FACE method="change_7" pos="2/3"]

"Indeed, it is true to the rumors. That word would normally be a compliment, but the man had a grim look on his face.
[cpg]


Moreover, is he a government official or ...... in this attire?　A few more people enter from behind.
[cpg]


[OnName num="kurto"]
"Um, what can I do for you?"
[cpg cn=true]


[OnName num="government_official"]
'Nothing, nothing for you. I suppose you're selling something I've never seen before."
[cpg cn=true]


[OnName num="kurto"]
'...... this is in demand, and I'm selling something you need.'
[cpg cn=true]


[OnName num="government_official"]
'These are things that disturb the public morals. This kind of business is unacceptable.
[cpg cn=true]


I was inwardly distraught and tried to remain as calm as possible.
[cpg]


[OnName num="kurto"]
I was so distraught inside that I tried to stay as calm as I could. It's not dangerous. ......
[cpg cn=true]


[OnName num="government_official"]
I can't listen to his excuses. In any case, I can't allow you to sell them here.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Bianca269"]
[OnName num="bianca"]
Oh, no. ......!
[cpg cn=true]


I knew my brothers were doing something.
[cpg]


If this happens, we have no choice but to sell our products in a place where the brothers can't see us, but ......
[cpg]


That alone was a huge blow to us.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

The older brothers must be desperate to protect their position.
[cpg]

I only understood this when I had my own store and employees working for me.
[cpg]

Maybe every human being is a business owner if he or she is still alive.
[cpg]

I can say that my brothers also had people who worked for them and took action to protect them.
[cpg]

In other words, if you're going to make me your enemy, you'd better be thorough.
[cpg]

It is the same in business. When a business enemy appears, there is only one way to take it in, win, or lose.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="3/5" time=800]
[FG f="CHA05_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="1/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="5/5" time=800]


Arma and Yuhka soon learned that they could no longer sell their products in this store.
[cpg]


Edith and Katharina were also there. Thinking back, I think this is the first time all of us have gathered together.
[cpg]


[FACE method="shake_7" pos="3/5"]
[VOICE f="Alma099"]
[OnName num="alma"]
They are not pretending to be anything else, are they?
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Yuika067"]
[OnName num="yuika"]
Yes, they are. But as for me, I don't want to miss out on this business opportunity.
[cpg cn=true]


They were talking. And then they say.
[cpg]


[FACE method="bow_7" pos="1/5"]
[VOICE f="Edith096"]
[OnName num="edith"]
"Oh, I don't want ...... to be unable to sell what we've made, either.
[cpg cn=true]


[FACE method="bow_3" pos="2/5"]
[VOICE f="Catalina172"]
[OnName num="catalina"]
I feel the same way. I feel the same way. We've found a vein of magic stone and we're just getting started.
[cpg cn=true]


Edith and Katharina seemed to feel the same way.
[cpg]


[FACE method="bow_2" pos="5/5"]
[VOICE f="Bianca270"]
[OnName num="bianca"]
We can't afford to lose. Master.
[cpg cn=true]


Bianca looked me in the eye and said.
[cpg]


[FACE method="bow_1" pos="3/5"]
[VOICE f="Alma100"]
[OnName num="alma"]
I don't have a plan either. I don't have a plan either, but I will do whatever I can to help.
[cpg cn=true]


Everyone is looking at me. They are cheering me on.
[cpg]


[FACE method="shake_3" pos="5/5"]
[VOICE f="Bianca271"]
[OnName num="bianca"]
If you don't give up, you will have a chance. There is nothing to worry about.
[cpg cn=true]


Everything I have built up until now has been destroyed. I know that they are supporting me in my anxiety. ......
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="kurto"]
...... huh."
[cpg cn=true]


I know, but I can't sleep. It's like quicksand.
[cpg]


Even the officials have moved on. Can a situation like this be reversed so easily?
[cpg]


But if we don't do anything, the situation will only get worse.
[cpg]



;//■選択肢
;//[SetSelGra 3]
[if exp={getFlagValue("Tai_sil") == 2000 }]
[FG f="ci_money.ui" method="window_in_2000" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 1500 }]
[FG f="ci_money.ui" method="window_in_1500" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 1400 }]
[FG f="ci_money.ui" method="window_in_1400" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 900 }]
[FG f="ci_money.ui" method="window_in_900" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]


[switch]
[case "Doing business through the eyes of the bureaucrats [FREE]"]
	[swap]
	[jump target="*select04_1"]
[case "Ask Yuika to export your goods [600sil]."]
	[swap]
	[jump target="*select04_2"]
[case "Ask Katharina to spread the word [FREE]."]
	[swap]
	[jump target="*select04_3"]
[endswitch]


1,Doing business through the eyes of officials (no sil consumption)
;//※アイコンは主人公の店の背景の画像
2, Ask Yuika to export your goods (600sil consumption)
;//※アイコンは街の背景にヒロイン２の立ち絵を重ねた画像
3,Ask Katharina to spread the word (no sil consumption)
;//※アイコンは街の背景にヒロイン５の立ち絵を重ねた画像





;//==============================
;//１、役人の目をくぐり抜けて商売をする（sil消費なし）
*select04_1|Who do you want to be happy with?



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="3/5" time=800]
[FG f="CHA05_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="1/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="5/5" time=800]


I have no choice but to continue doing business under the eyes of the government officials after all.
[cpg]

I can't sell my inventions openly at the store I usually set up.
[cpg]

We got together and had a strategy meeting.
[cpg]

No one came up with an idea. I tried hard to come up with an idea, but it was difficult.
[cpg]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Yuika075"]
[OnName num="yuika"]
Well, it will be much later that the aristocrats will be able to reach other countries. We won't be in trouble for a while, but ......
[cpg cn=true]


[FACE method="shake_7" pos="3/5"]
[VOICE f="Alma101"]
[OnName num="alma"]
Not being able to sell here would be like losing your home base, and we don't want that.
[cpg cn=true]


Yes. Not being able to make, sell, and try things in this store would be a big blow.
[cpg]


On the other hand, if we do business in the same way, we might get caught this time.
[cpg]


In the midst of all this, Mr. Edith raises her hand.
[cpg]


[OnName num="kurto"]
Do you have an opinion?"
[cpg cn=true]


[FACE method="shake_7" pos="1/5"]
[VOICE f="Edith097"]
[OnName num="edith"]
He said, "Well, what if we sell the ...... magic stone and the outer case in a separate ...... assembled form?"
[cpg cn=true]


[FACE method="bow_2" pos="5/5"]
[VOICE f="Bianca272"]
[OnName num="bianca"]
I see,...... then both would sell well. Edito, that's a nice idea.
[cpg cn=true]


Katharina and I looked at each other. It seems that we are thinking the same thing.
[cpg]


[OnName num="kurto"]
It may seem like a good way to go, but ...... it's just not possible."
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Catalina180"]
[OnName num="catalina"]
I don't know, I just feel like it's dangerous.
[cpg cn=true]


[OnName num="kurto"]
It's like selling tools to grow banned drugs. It will be regulated one day.
[cpg cn=true]


Mr. Edith was shrugging, but I had no choice but to use this kind of knowledge as well.
[cpg]


This was something that had happened in the past in modern times. Remembering these examples, I thought about how to get around the pressure.
[cpg]




;//ブラックアウト


[jump target="*select04_4"]

;//==============================
;//２、ユイカに頼んで商品を輸出する（600sil消費）
*select04_2|Who do you want to be happy with?



I consume 600sil!
[cpg]

[window target=false]


[SE f="se011"]
;//【ＳＥ】『お金増減』


[if exp={getFlagValue("Tai_sil") == 2000 }]
[FG f="ci_money.ui" method="cal_m600_2000" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 1500 }]
[FG f="ci_money.ui" method="cal_m600_1500" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 1400 }]
[FG f="ci_money.ui" method="cal_m600_1400" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 900 }]
[FG f="ci_money.ui" method="cal_m600_900" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]

[FO pos="4/7" time=1000]

[stflag Tai_sil = -600]

[window target=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



I visited Yuika's place.
[cpg]


It was quite a distance, but I somehow thought that Yuika was still awake.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yuika068"]
[OnName num="yuika"]
"Can't sleep?"
[cpg cn=true]


[OnName num="kurto"]
......Yuica-san."
[cpg cn=true]


Yuika was in front of my store.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika069"]
[OnName num="yuika"]
I can't sleep either, thinking that I will have to compare wits with the aristocrats from now on.
[cpg cn=true]


[OnName num="kurto"]
After all, are you as scared ...... as I am?"
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Yuika070"]
[OnName num="yuika"]
I'm afraid of the opposite. This kind of situation is very exciting.
[cpg cn=true]


He is really a dependable person. I envy him for being able to say this much.
[cpg]


[OnName num="kurto"]
I'm sure you'll be able to find a way to get the job done. Yuika, you are a strong person.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuika071"]
[OnName num="yuika"]
I don't think you are weak. You have to appreciate yourself more before you can start.
[cpg cn=true]


[OnName num="kurto"]
I don't have ...... confidence in myself. I can't believe I'm going head-to-head with my brothers."
[cpg cn=true]


Those two are different types of people, but neither of them are people I want to make enemies with.
[cpg]


I was a coward even before I started fighting.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Yuika072"]
[OnName num="yuika"]
It's not like that. You've made it this far, haven't you?"
[cpg cn=true]


[OnName num="kurto"]
"...... Yes."
[cpg cn=true]


Yuika-san smiled at me.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika073"]
[OnName num="yuika"]
You should laugh too. It would be a waste if you don't enjoy yourself at the time of the biggest crisis in your life.
[cpg cn=true]


[OnName num="kurto"]
......You really are strong, aren't you?
[cpg cn=true]


Youka looks very confident.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika074"]
[OnName num="yuika"]
The actuality is that the actuality is that the actuality is not really a good thing. It is right to say that they have become strong.
[cpg cn=true]


But even Yooka-san says this.
[cpg]


I might be able to believe her words.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

I asked Yuika to help me and decided to focus on exports.
[cpg]

Even though it was cracked down on in this country, it was not so in other countries.
[cpg]

Of course I had to pay something in return, but it was cheap.
[cpg]

More than that, I made an effort to make sure that this business would not end here.
[cpg]

;//ヒロイン２変数+1
[stflag Cha_Flg2 = 1]

[jump target="*select04_4"]
;//==============================
;//３、カタリーナに口コミを広げてもらう（sil消費なし）
*select04_3|With whom do you want to be happy?



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『森の中の集落』（夜）******************************************************



I decided to go to Katharina's place.
[cpg]


She had been there for me since the very beginning.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Catalina173"]
[OnName num="catalina"]
She had been there for me pretty much from the beginning.　That's not like you.
[cpg cn=true]


[OnName num="kurto"]
What do you mean?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Catalina174"]
[OnName num="catalina"]
What do you mean? I thought you were a more positive person.
[cpg cn=true]


I thought you were a more positive person," Katharina said. I'm not.
[cpg]


[OnName num="kurto"]
I'm not positive.　I'm not a positive person.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Catalina175"]
[OnName num="catalina"]
'I think you have bright roots, and I think you're right.
[cpg cn=true]


[OnName num="kurto"]
I wonder if that's true.
[cpg cn=true]


I pondered. I wonder if it is because I have experienced rock bottom once before.
[cpg]


[OnName num="kurto"]
What do you think, Katharina?　Do you think I can get through this?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Catalina176"]
[OnName num="catalina"]
You don't have to ask me, it's obvious. You are positive, but you have no confidence.
[cpg cn=true]


That, I thought, was a simple description of me.
[cpg]


[OnName num="kurto"]
'...... positive, but you lack self-confidence.'
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Catalina177"]
[OnName num="catalina"]
'You have the power to do a lot of things, so I'm pretty sure you're positive.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Catalina178"]
[OnName num="catalina"]
'Still, I don't know why I don't believe in myself. I envy you your energy.
[cpg cn=true]


[OnName num="kurto"]
I don't know. I guess you're right.
[cpg cn=true]


Katharina laughed a little when she heard my words.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Catalina179"]
[OnName num="catalina"]
You're a good girl," she said. I know you have overcome worse adversities in your life.
[cpg cn=true]


I had no choice but to look forward. I had to look forward.
[cpg]



;//ブラックアウト

I would ask Katharina to spread the word. She said there was still a way for us to make a move.
[cpg]

Nothing has been decided yet, but I've even asked her to tell me that there will soon be a new product that will evade the government's scrutiny.
[cpg]

I haven't come up with anything like that. But I did it to push myself.
[cpg]


;//ヒロイン５変数+1
[stflag Cha_Flg5 = 1]


;//==============================

*select04_4|Who do I want to be happy with?

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]



Day in and day out, we all get together to discuss ideas.
[cpg]

However, it didn't mean that we came up with excellent ideas right away.
[cpg]

We would think about the future of the restaurant, asking ourselves what we should do and what we shouldn't do.
[cpg]



;//お金を元手に色々なエログッズを開発して商売を成功させていこう！
;//[cpg]

;//鍵の付いたアイコンをクリックすれば、お金（sil）を消費して商品開発！
;//[cpg]

;//開発をすれば商品の性能テストと言って女の子とエッチな事が出来るかも！？
;//[cpg]

;//しかし、商人とってお金はとても大事なもの。
;//[cpg]

;//お金が無くなったら大変な事になってしまうかも…！？
;//[cpg]

;//お金が少ない時は費用が掛からない【FREE】がオススメです。
;//[cpg]

;//大商人になって人生一発逆転を目指しましょう！
;//[cpg]


;//エロ経営用特殊選択肢は６択で起動。３ヶ所を選ぶ
;//■選択肢
;//[SetSelGra 4]
[if exp={getFlagValue("Tai_sil") == 2000 }]
[FG f="ci_money.ui" method="window_in_2000" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 1500 }]
[FG f="ci_money.ui" method="window_in_1500" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 1400 }]
[FG f="ci_money.ui" method="window_in_1400" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 900 }]
[FG f="ci_money.ui" method="window_in_900" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 800 }]
[FG f="ci_money.ui" method="window_in_800" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 300 }]
[FG f="ci_money.ui" method="window_in_300" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]

[switch]
[case "Thinking of new products that won't be policed "FREE"."]
	[swap]
	[jump target="*select05_1"]
[case "Developing new products with Yuika "700sil"."]
	[swap]
	[jump target="*select05_2"]
[case "Developing new products with Edito "700sil"."]
	[swap]
	[jump target="*select05_3"]
[endswitch]

1, Think of a new product that will not be policed (no sil consumption).
;//※アイコンは主人公の店の背景の画像
2、Develop a new product with Yuika (700sil consumed)
;//※アイコンはev_19の画像
3, Develop a new product with Edith (700sil consumption)
;//※アイコンはev_20の画像


;//==============================
;//１、取り締まられないような新商品を考える（sil消費なし）
*select05_1|With whom do you want to be happy?

[stflag Select5 = 1]

A product that will not be policed. That would be the best.
[cpg]

But I can't think of such a thing right away, and if there were such a thing, I would have already made it.
[cpg]


[OnName num="kurto"]
Ah."
[cpg cn=true]


As I was thinking about it, I thought of ...... something inventive.
[cpg]


[OnName num="kurto"]
I wondered if they already made shoes made of rubber.
[cpg cn=true]


In the modern world, they are used in factories. Even in this world, there would be a demand for them in mining sites.
[cpg]

And if it's shoes, there should be no problem selling them.
[cpg]



[jump target="*select05_4"]

;//==============================
;//２、ユイカと新商品を開発する（700sil消費）
*select05_2|Who do you want to be happy with?


;//[ActivExWin]



I'll spend 700sil!
[cpg]

[window target=false]

;//[NonActivExWin]

[SE f="se011"]
;//【ＳＥ】『お金増減』


[if exp={getFlagValue("Tai_sil") == 2000 }]
[FG f="ci_money.ui" method="cal_m700_2000" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 1500 }]
[FG f="ci_money.ui" method="cal_m700_1500" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 1400 }]
[FG f="ci_money.ui" method="cal_m700_1400" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 900 }]
[FG f="ci_money.ui" method="cal_m700_900" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 800 }]
[FG f="ci_money.ui" method="cal_m700_800" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 300 }]
[FG f="ci_money.ui" method="cal_m700_300" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]


[FO pos="4/7" time=1000]
[stflag Tai_sil = -700]
[WAIT time=1000]

[window target=true]

I decided to make various prototypes with Yuika for now.
[cpg]

Then we came up with one idea. It was rubber shoes.
[cpg]

The kind of shoes used in factories today. Even in this world, there would be demand for them in mining areas.
[cpg]

And if it's shoes, there should be no problem to sell them.
[cpg]

;//ヒロイン２変数+1
[stflag Cha_Flg2 = 1]

[jump target="*select05_4"]

;//==============================
;//３、エーディトと新商品を開発する（700sil消費）
*select05_3|Who do you want to be happy with?




I'll spend 700sil!
[cpg]


[window target=false]

[SE f="se011"]
;//【ＳＥ】『お金増減』

[if exp={getFlagValue("Tai_sil") == 2000 }]
[FG f="ci_money.ui" method="cal_m700_2000" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 1500 }]
[FG f="ci_money.ui" method="cal_m700_1500" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 1400 }]
[FG f="ci_money.ui" method="cal_m700_1400" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 900 }]
[FG f="ci_money.ui" method="cal_m700_900" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 800 }]
[FG f="ci_money.ui" method="cal_m700_800" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 300 }]
[FG f="ci_money.ui" method="cal_m700_300" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]

[FO pos="4/7" time=1000]
[stflag Tai_sil = -700]
[WAIT time=1000]

[window target=true]


I decided to make a variety of prototypes with Mr. Edith, whose products can take shape quickly.
[cpg]

Then we came up with one idea. It was rubber shoes.
[cpg]

The kind of shoes used in factories today. Even in this world, there would be a demand for them in mining areas.
[cpg]

And if it's shoes, there should be no problem selling them.
[cpg]

;//ヒロイン３変数+1
[stflag Cha_Flg3 = 1]


;//==============================
*select05_4|Who do you want to be happy with?

;//いずれの選択肢を選んでも、暫く同じシナリオが続く
;//暫くしたあと、選択肢の影響が出る

[free time=1000]


[OnName num="kurto"]
What do you think? Yuhka.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sYuika004"]
[OnName num="yuika"]
'Yes, I think it's not bad. I don't think they would want to shut down all the other shoe shops either.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika077"]
[OnName num="yuika"]
A simple strategy, but it's going to be harder to crack down on this than it used to be.
[cpg cn=true]


[free time=1000]


[OnName num="kurto"]
"Okay, can you try making ......, Mr. Edith?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Edith098"]
[OnName num="edith"]
"......, got it."
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************



[SE f="se014"]
;//【ＳＥ】『歩く』



What awaited me was a much busier life than before.
[cpg]


I had to keep an eye on the rest of the world.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Alma103"]
[OnName num="alma"]
I'm sorry you're tired. You look very tired, but I hope you're all right.
[cpg cn=true]


[OnName num="kurto"]
I hope you're all right. I don't think I'm going to make it home today.
[cpg cn=true]


I've been walking around so much, my legs feel like sticks.
[cpg]


Limited mobility is a problem on this cultural level.
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="sAlma002"]
[OnName num="alma"]
"I'd like to help ...... you heal a little. Can I stay by your side?"
[cpg cn=true]


They would say things like that. I couldn't push her away.
[cpg]

If it weren't for her, I would have given up long ago.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[SE f="se004"]
;//【ＳＥ】『ドア閉まる』


And then we headed for the inn.
[cpg]


Arma was already expecting me. ......
[cpg]


;//========================================
;//●ＣＧ（キスをする二人。マッサージ機は消してください）ev_18
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：宿の一室
;//時間　：夜
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bgm_10"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


I will not cross the line with Arma-san.
[cpg]

I only ask her to stay by my side. Even if we may kiss at least. ......
[cpg]

We were not yet in a state where we could afford to be so absorbed in our love affair.
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



It may be a situation where both parties are killing each other alive.
[cpg]


;//移植のためシーンをカットしています


;//ゲームオーバーチェック
[if exp={getFlagValue("Tai_sil") <= 0 }]
[jump target="*gameover"]
[endif]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************



...... In this way, the rubber-strengthened shoes were nearing completion.
[cpg]


We have brought it to the point where we can already sell them, but there are still concerns.
[cpg]


If they say this is another product they've never seen before and should be cracked down on, there's nothing more we can do.
[cpg]


I can't believe ....... That's just what happens when you think there's nothing to do.
[cpg]



We can't give up yet. We've come this far, there's no way we can give up.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



On the day of the sale, we didn't advertise much.
[cpg]


We didn't advertise much. The fans understood what was happening in our store.
[cpg]


[OnName num="male_customer_A"]
I said, "That was a disaster the other day. I heard you got caught doing something."
[cpg cn=true]


[OnName num="kurto"]
'No, no, not that far ......
[cpg cn=true]


[OnName num="male_customer_B"]
Is it true that you were almost executed?
[cpg cn=true]


There is some kind of rumor going around that never happened. It helped, too, that the store was selling well enough without any publicity.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



The officials must have known that the store would be open today.
[cpg]


Still, no government officials came to my store today.
[cpg]


[OnName num="kurto"]
I still can't say, "...... we won."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca274"]
[OnName num="bianca"]
I'm afraid so. Sales are down to less than half of what they used to be.
[cpg cn=true]


We can't say we're happy to be back in business.
[cpg]


My brother must think I've done enough.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************





[OnName num="kurto"]
"Well," he said.
[cpg cn=true]


I managed to get through today without anything happening. But I feel bad thinking about the fear of having to face the eyes of the government officials from now on.
[cpg]


I had no intention of letting it sink in.
[cpg]


I had no choice but to do something that the government officials would have to approve of.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca275"]
[OnName num="bianca"]
The shortest way to do that would be to contribute to society or something like that.
[cpg cn=true]


Bianca's words gave me an idea.
[cpg]


[OnName num="kurto"]
Bianca said to me, "......, social contribution, huh? I see.
[cpg cn=true]


Something stuck with me. I think we're forgetting an important invention.
[cpg]


Since resin has been invented, the scope is expanding. As I walked home, I turned my head.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]



[SE f="se004"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



It wasn't until I was back at home, dozing off, that I finally came up with the idea.
[cpg]


[OnName num="kurto"]
Yes!
[cpg cn=true]


I jumped up and shouted.
[cpg]


Rubber gloves. I knew I was missing something.
[cpg]



[SE f="se002"]
;//【ＳＥ】『ドア開く』
[free time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[WAIT time=1000]

[VOICE f="Bianca276"]
[OnName num="bianca"]
"How can I help you?"
[cpg cn=true]


Bianca had come to my room, probably startled by my loud voice.
[cpg]


[OnName num="kurto"]
I'm good. I can do this, Bianca.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Bianca277"]
[OnName num="bianca"]
"Did you have an idea?　Or did you remember something?
[cpg cn=true]


[OnName num="kurto"]
I remembered. We're going to make gloves.
[cpg cn=true]


I'm going to need these for sure. It will help prevent infection.
[cpg]


[OnName num="kurto"]
It's from the world I used to live in, it's a thin layer of resin. How do I explain it?"
[cpg cn=true]


Bianca had a look on her face that was neither dubious nor expectant.
[cpg]


I guess my tension is higher than I thought it would be.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



It took me the rest of the night to cool down. Still, I was so excited that I didn't sleep much at night.
[cpg]


I thought to myself, this is a one-shot deal. What would Bianca think?
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kurto"]
I'm a necessity where I'm from. There's at least some infection in this world."
[cpg cn=true]


Searching for the right words, I tried my best to explain to Bianca.
[cpg]


The best person to explain this to would be Edith, but I wanted to say it.
[cpg]


I wanted to hear her opinion on whether it was useful or not.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sBianca019"]
[OnName num="bianca"]
I see. It seems to be more hygienic than cloth.
[cpg cn=true]


Bianca complimented me. Even in my old world, rubber gloves are sold in pharmacies.
[cpg]


My business was considered problematic because it was disruptive to begin with.
[cpg]


[OnName num="kurto"]
But with these, rather than being disruptive, it's the opposite.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca279"]
[OnName num="bianca"]
It sells, I think. Besides, this should be impossible to crack down on. ......
[cpg cn=true]


[OnName num="kurto"]
I can't stay like this. Let's go ask Mr. Edith for help.
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（朝）******************************************************



;//背景と別の場所なので、上下に黒帯を入れるなどしてください



[FACE method="change_7" pos="2/3"]
[VOICE f="Edith131"]
[OnName num="edith"]
What are these new blueprints ...... for?
[cpg cn=true]


Mr. Edith is essentially a blacksmith. But now, he leaves various processes to others.
[cpg]


Some may be skilled in handling the resin, and some may be able to do it themselves.
[cpg]


[OnName num="kurto"]
Rubber gloves.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sEdith005"]
[OnName num="edith"]
Never heard of ......."
[cpg cn=true]


Mr. Edith's reaction is not surprising.
[cpg]


[OnName num="kurto"]
I'd better tell you what they're for first. Let's see, ......."
[cpg cn=true]


I explained to Mr. Edith. He was listening with interest.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Edith133"]
[OnName num="edith"]
'Mr. Kurth,...... where do you come up with such an invention?
[cpg cn=true]


[OnName num="kurto"]
'I'm not coming up with it, I'm just remembering it.
[cpg cn=true]


I've already told Bianca about this. No, it's more than that.
[cpg]


[OnName num="kurto"]
I've already told Bianca about it. Can you make it?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Edith134"]
[OnName num="edith"]
"It might take some time. We'll have to think about the convenience of stretching and blending.
[cpg cn=true]


But Mr. Edith was dependable. He did not say it was impossible.
[cpg]





[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************


Once he left the business itself to his employees, he stayed with Mr. Edito to help him develop the product.
[cpg]


That said, Mr. Edito was more expert in devising ways to bring the product closer to perfection.
[cpg]


[FADEOUTBGM]
[window target=false]
[BG f="b_04_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夕方）******************************************************


Thanks to the sales of the shoes, the company was never so strapped for cash that it could not eat.
[cpg]


However, he was on the verge of having to close his second store.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Edith137"]
[OnName num="edith"]
I think I could have ...... done it."
[cpg cn=true]


It was at this point in time that the rubber gloves were completed.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************


I had a feeling that these things, once invented, would become indispensable.
[cpg]

Not only would they help prevent infections, but they would also be useful in medicine. If they became as popular as they are today, there would be no stopping them.
[cpg]


The day before the launch, we put them on display. Arma and Katharina helped me.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Alma133"]
[OnName num="alma"]
I hope ...... will sell well.
[cpg cn=true]

[FACE method="bow_7" pos="4/5"]
[VOICE f="Catalina181"]
[OnName num="catalina"]
I have no doubt it will sell. However, it may take some time before the effect is proven.
[cpg cn=true]


That's certainly the way to look at it. It's something that hasn't taken hold in this world.
[cpg]


But I had a feeling that there would be more demand than that.
[cpg]


[OnName num="kurto"]
I was not going to let my anxiety get in the way. We have no choice but to sell.
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



I think there is a certain point that they don't fit in with the world.
[cpg]


In fact, those who bought it seemed to be skeptical, but...
[cpg]


[OnName num="male_customer"]
How can you come up with something like this when ...... resin hasn't even been invented yet?"
[cpg cn=true]


The gloves sold like hotcakes. The response was different this time around.
[cpg]


The aristocrats are pressuring me, and this is how well they are selling.
[cpg]


Bianca and I nodded in agreement.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************



[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca281"]
[OnName num="bianca"]
It's selling very well. Master, it's great after all.
[cpg cn=true]


[OnName num="kurto"]
I guess so. I think we can be honestly happy about it this time.
[cpg cn=true]


I wonder if they will try to crack down on even this. The brothers might do it.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



For a while, we were keeping our fingers crossed. Still, the profit was steadily increasing.
[cpg]


[OnName num="kurto"]
I can't sell tomorrow's goods today,......, and that's the hard part.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca282"]
[OnName num="bianca"]
I agree. If you don't sell a certain amount of products consistently, you won't be able to spread the word.
[cpg cn=true]


We were thinking this way and that, planning our strategy, but in a hasty manner.
[cpg]


It was like hitting a stone bridge, but at the same time it was like running through it.
[cpg]


If we didn't have that kind of mindset, we might not be able to rise to the surface.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************




[VOICE f="Yuika107"]
[OnName num="yuika"]
You're really good at business," he said. You really have business acumen.
[cpg cn=true]


[OnName num="kurto"]
Is that so ......?"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Yuika108"]
[OnName num="yuika"]
I was also surprised. Besides, it is wonderful that you are doing so well after being spotted by the aristocrats.
[cpg cn=true]


I wonder if that is so. No, it seems to me that they probably are.
[cpg]


[OnName num="kurto"]
'I hope they continue to sell other products as well.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika109"]
[OnName num="yuika"]
'I think they will in the near future. The opinions of the aristocrats are changing.
[cpg cn=true]


A good invention is one that can't be stopped from spreading, Yuika muttered.
[cpg]


If it can prevent diseases, then my business may be allowed to a certain extent, ...... might be the way to look at it.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



My hunch was right. It seemed that the older brothers could no longer ignore the opinions of the aristocrats around them.
[cpg]


The officials who used to come frequently stopped coming, and our business was getting tacit approval.
[cpg]


[OnName num="kurto"]
No, we have become ......?　Should I be sure about this?
[cpg cn=true]



[FACE method="shake_1" pos="2/5"]
[VOICE f="Alma134"]
[OnName num="alma"]
You don't have to check, I know what's going on to some extent.
[cpg cn=true]


In times like this, Arma's presence is really helpful.
[cpg]


They can find out what's going on with the nobles from the inside, which I can't know on my own.
[cpg]


[FACE method="change_2" pos="2/5"]
[VOICE f="Alma135"]
[OnName num="alma"]
Kurth's brothers, it seems, are no longer allowed to interfere.
[cpg cn=true]


[OnName num="kurto"]
Is the information reliable?
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Alma136"]
[OnName num="alma"]
To some extent. I haven't heard directly from them.
[cpg cn=true]


[OnName num="kurto"]
Is it really true?　If so, we need to change our products.
[cpg cn=true]


[OnName num="kurto"]
No, but I wonder if it's a bait. I don't want them to complain about it after the fact.
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Bianca283"]
[OnName num="bianca"]
"Well, since ...... Arma says so, I'm sure it's all right. Master."
[cpg cn=true]


I agree. But it is still a business that was stopped once.
[cpg]


I've been thinking about this and that, but I had some inventory. I put it on the store shelves. ......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



[OnName num="male_customer"]
I've started to sell them again. I wonder if the aristocrats have started to overlook it.
[cpg cn=true]


[OnName num="kurto"]
Yes, yes. Well, ......"
[cpg cn=true]


I'm in a cold sweat inside. No matter how much Arma-san said, it is not a sure thing.
[cpg]


However, it is not possible to start missing the timing or being excessively timid.
[cpg]


You wonder when the officials will come, but you also think that they shouldn't be cracking down as hard as they have been. ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************



I found myself making more sales than ever before, including on products I'd been selling.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Yuika110"]
[OnName num="yuika"]
I said, "Good evening. I guess we're closed."
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Alma137"]
[OnName num="alma"]
'Ah, Yuika-san. Yes, it's about time to ......"
[cpg cn=true]


Yuika looked around the store and then turned to me.
[cpg]


[OnName num="kurto"]
What is it, ......?"
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Yuika111"]
[OnName num="yuika"]
'I met Kurth's brothers the other day. The other day, I met with Kurth's brothers and they said, 'Do what you want.
[cpg cn=true]


[OnName num="kurto"]
"Yeah, ......."
[cpg cn=true]


It seemed like a virtual admission of defeat.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Yuika112"]
[OnName num="yuika"]
I've fought well," he said. You have won this war. You should be proud.
[cpg cn=true]


I felt as if my strength had been drained from my body.
[cpg]


Finally, the enemy was gone. But at the same time, I was wondering what I was going to do now.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Bianca284"]
[OnName num="bianca"]
"Good for you, Master!"
[cpg cn=true]


Bianca took my hand.
[cpg]


[OnName num="kurto"]
I was in a kind of a state of free fall.
[cpg cn=true]




;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



I was in a kind of a state of lethargy. Of course I feel happy, but I also feel ......
[cpg]


I had no one to share my joy with.
[cpg]


No, it's not that I don't have anyone at all. They are all my friends who help me with my business. But that's all.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



In my bedroom. I think to myself, "I've come so far.
[cpg]


I've come so far. I wanted to drink a toast today, but there was no one next to me.
[cpg]


This made me feel lonely. I think people are creatures who make their wishes come true one by one.
[cpg]


I had already fulfilled my wish, my dream, I guess.
[cpg]


Then, something I had been looking away from for a long time came into my face.
[cpg]


[OnName num="kurto"]
......I'm going to miss you, after all.
[cpg cn=true]


As a merchant, I'm safe for a while. But still, if you don't keep making new things, you'll get tired of it someday.
[cpg]


That has never and will never change. But then, ......
[cpg]


What do I want to do? I don't just want to be rich.
[cpg]


Ultimately, I want to be happy. When I thought about that......
[cpg]


I turned around and thought about who I ultimately want to be happy with.
[cpg]



;//※ここまでの選択肢で変数が２になっているヒロインのみ選択肢に出てくる
;//※ヒロイン１には変数がなく、必ず選択肢に残る
;//※ヒロイン１しか残っていない場合、選択肢は発生せずヒロイン１ルートへ


[if exp={getFlagValue("Cha_Flg2") >= 1 }]
[if exp={getFlagValue("Cha_Flg3") >= 1 }]
[if exp={getFlagValue("Cha_Flg4") >= 1 }]
[if exp={getFlagValue("Cha_Flg5") >= 1 }]
[jump target="*sel_12345"]
[endif]
[endif]
[endif]
[endif]

[if exp={getFlagValue("Cha_Flg2") >= 1 }]
[if exp={getFlagValue("Cha_Flg3") >= 1 }]
[if exp={getFlagValue("Cha_Flg4") >= 1 }]
[jump target="*sel_1234"]
[endif]
[endif]
[endif]

[if exp={getFlagValue("Cha_Flg2") >= 1 }]
[if exp={getFlagValue("Cha_Flg3") >= 1 }]
[if exp={getFlagValue("Cha_Flg5") >= 1 }]
[jump target="*sel_1235"]
[endif]
[endif]
[endif]

[if exp={getFlagValue("Cha_Flg2") >= 1 }]
[if exp={getFlagValue("Cha_Flg4") >= 1 }]
[if exp={getFlagValue("Cha_Flg5") >= 1 }]
[jump target="*sel_1245"]
[endif]
[endif]
[endif]

[if exp={getFlagValue("Cha_Flg3") >= 1 }]
[if exp={getFlagValue("Cha_Flg4") >= 1 }]
[if exp={getFlagValue("Cha_Flg5") >= 1 }]
[jump target="*sel_1345"]
[endif]
[endif]
[endif]



[if exp={getFlagValue("Cha_Flg2") >= 1 }]
[if exp={getFlagValue("Cha_Flg3") >= 1 }]
[jump target="*sel_123"]
[endif]
[endif]

[if exp={getFlagValue("Cha_Flg2") >= 1 }]
[if exp={getFlagValue("Cha_Flg4") >= 1 }]
[jump target="*sel_124"]
[endif]
[endif]

[if exp={getFlagValue("Cha_Flg3") >= 1 }]
[if exp={getFlagValue("Cha_Flg4") >= 1 }]
[jump target="*sel_134"]
[endif]
[endif]


[if exp={getFlagValue("Cha_Flg2") >= 1 }]
[if exp={getFlagValue("Cha_Flg5") >= 1 }]
[jump target="*sel_125"]
[endif]
[endif]


[if exp={getFlagValue("Cha_Flg3") >= 1 }]
[if exp={getFlagValue("Cha_Flg5") >= 1 }]
[jump target="*sel_135"]
[endif]
[endif]


[if exp={getFlagValue("Cha_Flg4") >= 1 }]
[if exp={getFlagValue("Cha_Flg5") >= 1 }]
[jump target="*sel_145"]
[endif]
[endif]


[if exp={getFlagValue("Cha_Flg2") >= 1 }]
[jump target="*sel_12"]
[endif]


[if exp={getFlagValue("Cha_Flg3") >= 1 }]
[jump target="*sel_13"]
[endif]


[if exp={getFlagValue("Cha_Flg4") >= 1 }]
[jump target="*sel_14"]
[endif]


[if exp={getFlagValue("Cha_Flg5") >= 1 }]
[jump target="*sel_15"]
[endif]


;//選択肢が無ければアルマルートへ
[jump target="*select07_1"]


*sel_12
[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[switch]
[case "YUICA"]
	[jump target="*select07_2"]
[endswitch]

*sel_13
[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[case "Edito"]
	[swap]
	[jump target="*select07_3"]
[endswitch]

*sel_14
[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[case "Bianca"]
	[swap]
	[jump target="*select07_4"]
[endswitch]

*sel_15
[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[case "Katharina"]
	[swap]
	[jump target="*select07_5"]
[endswitch]


*sel_123

[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[case "Yuika"]
	[swap]
	[jump target="*select07_2"]
[case "Edith"]
	[swap]
	[jump target="*select07_3"]
[endswitch]


*sel_124

[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[case "Yuika"]
	[swap]
	[jump target="*select07_2"]
[case "Bianca"]
	[swap]
	[jump target="*select07_4"]
[endswitch]


*sel_134

[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[case "Edith"]
	[swap]
	[jump target="*select07_3"]
[case "Bianca"]
	[swap]
	[jump target="*select07_4"]
[endswitch]



*sel_125

[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[case "Yuika"]
	[swap]
	[jump target="*select07_2"]
[case "Katharina"]
	[swap]
	[jump target="*select07_5"]
[endswitch]


*sel_135

[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[case "Edith"]
	[swap]
	[jump target="*select07_3"]
[case "Katharina"]
	[swap]
	[jump target="*select07_5"]
[endswitch]

*sel_145

[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[case "Bianca"]
	[swap]
	[jump target="*select07_4"]
[case "Catherina"]
	[swap]
	[jump target="*select07_5"]
[endswitch]


*sel_1234

[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[case "Yuika"]
	[swap]
	[jump target="*select07_2"]
[case "Edith"]
	[swap]
	[jump target="*select07_3"]
[case "Bianca"]
	[swap]
	[jump target="*select07_4"]
[endswitch]

*sel_1235

[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[case "Yuika"]
	[swap]
	[jump target="*select07_2"]
[case "Edith"]
	[swap]
	[jump target="*select07_3"]
[case "Katharina"]
	[swap]
	[jump target="*select07_5"]
[endswitch]

*sel_1245

[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[case "Yuika"]
	[swap]
	[jump target="*select07_2"]
[case "Bianca"]
	[swap]
	[jump target="*select07_4"]
[case "Katharina"]
	[swap]
	[jump target="*select07_5"]
[endswitch]


*sel_1345

[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[case "Edith"]
	[swap]
	[jump target="*select07_3"]
[case "Bianca"]
	[swap]
	[jump target="*select07_4"]
[case "Katharina"]
	[swap]
	[jump target="*select07_5"]
[endswitch]


*sel_12345

[switch]
[case "Arma"]
	[swap]
	[jump target="*select07_1"]
[case "Yuika"]
	[swap]
	[jump target="*select07_2"]
[case "Edith"]
	[swap]
	[jump target="*select07_3"]
[case "Bianca"]
	[swap]
	[jump target="*select07_4"]
[case "Katharina"]
	[swap]
	[jump target="*select07_5"]
[endswitch]


1, Arma
2, Yuika
3, Edith
4, Bianca
5, Katharina


*select07_1|
[jump storage="ep010.ks" target="*select07_1"]
*select07_2|
[jump storage="ep011.ks" target="*select07_2"]
*select07_3|
[jump storage="ep014.ks" target="*select07_3"]
*select07_4|
[jump storage="ep012.ks" target="*select07_4"]
*select07_5|
[jump storage="ep013.ks" target="*select07_5"]

;//==============================



;//==============================
;//ゲームオーバーイベント
*gameover|Game Over


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_07"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

...... I got carried away and spent all my money.
[cpg]

I even had to dip into the money to produce goods and hire employees.
[cpg]

At first I managed to get out of debt, but I had to back out on the sly and ......
[cpg]

As a result, I was driven out of business.
[cpg]

[OnName num="kurto"]
"You've ...... overdone it. ......
[cpg cn=true]

I reverted back to my old life. But I thought I would get another chance to float again someday, so I started relying on Bianca's earnings again.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="morble1.webp" color={0xff0000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="red.ui" time=1]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0xff0000ff} time=1]
[WAIT time=1000]
[window target=true]

[OnName num="kurto"]
"Ugh ......!"
[cpg cn=true]

At that moment, I suddenly felt a pain around my heart.
[cpg]

I was remembering. When my memories before my reincarnation came back to me.
[cpg]

When I couldn't continue my business, it was time for me to die, or something like that. ......
[cpg]

I didn't really believe in such a curse, but I was naive.
[cpg]


[SE f="se009"]
;//【ＳＥ】『倒れ込む』

I collapsed in my room. Bianca was at work now and didn't even see me collapse.
[cpg]

Oh ...... I wish I had been more careful with my money.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="awa2.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="awa2.webp" color={0xffffffff} time=1]
[WAIT time=1000]



[jump storage="epend.ks" target="*back_title"]

;//ゲームオーバー
;//==============================
