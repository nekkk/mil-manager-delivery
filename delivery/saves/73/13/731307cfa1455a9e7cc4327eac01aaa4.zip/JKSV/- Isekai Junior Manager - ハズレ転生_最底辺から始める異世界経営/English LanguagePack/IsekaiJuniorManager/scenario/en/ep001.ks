

*start

;#################################################
*Ep001|Memories of a previous life
;#################################################

[SCENE id=1]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『村』（夕方）******************************************************



[OnName num="kurto"]
"It's very rural. ...... The road we came on was also a plain as far as the eye could see."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca019"]
[OnName num="bianca"]
I agree,...... oh, but it could be more peaceful than the city!"
[cpg cn=true]


Bianca tells me. Even though we were driven far away, she was there for us.
[cpg]


[OnName num="kurto"]
'I don't need comfort. I'm glad you care."
[cpg cn=true]


And then I look up at the house we will be living in. But it is not big enough to look up at.
[cpg]


It is little more than a private house. It's nothing compared to the house we've been living in.
[cpg]




;//ブラックアウト
;/[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bgm_03"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



[OnName num="kurto"]
...... Huh."
[cpg cn=true]


I don't really want to sigh. But it can't be helped because it comes out.
[cpg]


At the very least, they will be sent enough support to survive, I was told.
[cpg]


But it was a place where you would be on the street if it was gone.
[cpg]


Before that, I had always been a nobleman, so I didn't have the means to earn money on my own.
[cpg]



[OnName num="kurto"]
Well, you wouldn't cut off support from quicksand, would you ......?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca020"]
[OnName num="bianca"]
Yes, I would!　It's an idyllic place, and maybe it's good for a quiet life."
[cpg cn=true]


I had to put my trust in Bianca's words, but I was really naive to think that was the unshakable truth.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1]

[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_07"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I held the letter in my hand, shaking.
[cpg]


[OnName num="kurto"]
When you say you're cutting off support,...... Dad, are you serious,......?"
[cpg cn=true]


The support only lasted for a month, really. A grace period, perhaps, would have been a better word.
[cpg]


There were words along the lines of "termination of support," "going off on your own," and so on, but in the end, I was disowned.
[cpg]


[FACE method="shake_5" pos="2/3"]
[VOICE f="Bianca021"]
[OnName num="bianca"]
He said, "Hey, there must be some kind of mistake. You should read it carefully."
[cpg cn=true]


I did read it. But no matter how many times I read it, the words were the same.
[cpg]


[free time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



Sleepless nights followed. I thought he was not a demon, but was he really a demon?
[cpg]





[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『村』（朝）******************************************************



The support was actually terminated. Some part of me wanted to believe that the letter was a mistake.
[cpg]


But I was really in a situation where I was not sure if I would be able to eat today's meal. What a cruel way to treat me, I thought.
[cpg]


[OnName num="kurto"]
'Haha ...... I guess it was rather a bit of a backslide that the assistance was there until now.'
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Bianca022"]
[OnName num="bianca"]
It's all right, it's all right.
[cpg cn=true]


I'll starve to death if I don't do something about it. I am not particularly strong, and I cursed again.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca023"]
[OnName num="bianca"]
I'm sure you'll be fine. I'm still a maid of honor, so I can cook and ...... even feed the master.
[cpg cn=true]


[OnName num="kurto"]
Even the master is ......?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca024"]
[OnName num="bianca"]
Yes, I am. Kurth is the master for me now.
[cpg cn=true]


That doesn't suit me. I don't deserve to be called that.
[cpg]




;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bgm_03"]
;//[WAIT time=100]
;//【ＢＧ】『村』（夕方）******************************************************



The actuality that Bianca was a really talented lady-in-waiting. That was true even when she was at the mansion.
[cpg]


She started working at a bar a little further into town.
[cpg]


I can't do anything, I have to let Bianca earn money for a while,......, even.
[cpg]


[OnName num="kurto"]
I'm pathetic ......."
[cpg cn=true]


I have no more words. I have no words.
[cpg]


I've taken Bianca all the way to the countryside like this. And I'm being fed and she's still working. ......
[cpg]


But what kind of job would I get?　It's hard to even keep up with what she makes, isn't it?
[cpg]


I've never washed dishes. I can't cook. I have no physical strength to begin with, so I don't think I could stand the idea of working for a large part of the day.
[cpg]


What a shame, I've given up on myself, so there's really no help for me. ......
[cpg]


The next thing I know, I'm feeling guilty. I'm nothing more than a distraction.
[cpg]


[OnName num="kurto"]
I'm really ...... pathetic."
[cpg cn=true]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



I walk up to the cliff behind the house and stare at the end of the cliff. I wondered if Bianca would be free if she jumped off the cliff.
[cpg]


It's over. It's been an unenjoyable life, but now I have no choice but to bet on the next life.
[cpg]


......I feel like I had a similar thought sometime ago. I wonder why.
[cpg]


As I was pondering it like that, I thought to myself.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Bianca025"]
[OnName num="bianca"]
No!　No! Don't die!
[cpg cn=true]


Bianca hugged me from behind.
[cpg]


[OnName num="kurto"]
Bianca!　Let go of me!"
[cpg cn=true]


I wasn't going to jump. I wasn't really ready to do that.
[cpg]



[FO pos="2/3" time=1000]

[SE f="se009"]
;//【ＳＥ】『地面に倒れ込む』



But Bianca held me back, and I took the opportunity to fall backwards. I hit my head hard.
[cpg]



;//画面白く
;//ホワイトアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=1]
[WAIT time=1]
[window target=true]


I think it was the shock of hitting my head.
[cpg]


I saw what looked like a running light. Or rather, this is ......
[cpg]





[window target=false]
[transition target={true} rule="ue.webp" color={0xffffffff} time=1]
[WAIT time=1]
[BG f="b_05_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_06"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（昼）******************************************************



I understood that it was a memory of my previous life.
[cpg]


I understood it. There was no wonder that I had no questions as to how this could be.
[cpg]


I felt as if all the pieces were connected.
[cpg]


I have such a shabby skill set. And the way to crawl out of this, it's all in ......
[cpg]


It's in my previous life.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



And at the same time, a phenomenon similar to the baptismal ceremony occurred.
[cpg]

The words are written directly into my head. The content of this is: ......
[cpg]

'You, who have regained the memory of your previous life, must continue your business.
[cpg]

When you can no longer do so, I have placed a curse on you that will end your life." ......
[cpg]

In short, it would be the price for regaining the memory of your previous life.
[cpg]

But once I had decided to die, it wasn't a big deal to me.
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_10_3.ui" time=1000]
[WAIT time=2000]

[OnName num="kurto"]
I just had to ...... stay there."
[cpg cn=true]


I had once lived in a country called Japan. I used to live at a higher cultural level.
[cpg]


I remembered everything, but the hopelessness of my situation remained the same. I got up and looked at Bianca.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Bianca026"]
[OnName num="bianca"]
Please don't kill yourself. ...... I can't live without you.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Bianca027"]
[OnName num="bianca"]
I've served you all my life. Don't give up on your own potential.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Bianca028"]
[OnName num="bianca"]
I entrusted you with my dreams ...... and I want you to live."
[cpg cn=true]


Bianca was crying. I felt bad, but I could see just a few ways to get up from here.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FACE method="change_7" pos="2/3"]
[VOICE f="Bianca029"]
[OnName num="bianca"]
'Master ...... that ...... hurt you?
[cpg cn=true]


[OnName num="kurto"]
I'm fine. I'm fine."
[cpg cn=true]


Bianca calls me "master" instead of calling me by name.
[cpg]


I was certainly Bianca's master in this situation.
[cpg]


[OnName num="kurto"]
I know. I can't give up on you yet.
[cpg cn=true]


To respond to her feelings, I decided to look forward again.
[cpg]


[OnName num="kurto"]
Bianca. You told me you had a dream for me.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca030"]
[OnName num="bianca"]
'......Yes. And that feeling is true.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca031"]
[OnName num="bianca"]
I'm happy for you, because your joy is my joy. So I don't say ...... don't give up lightly.
[cpg cn=true]


She is on the verge of crying again. I mustn't make her cry again.
[cpg]


[OnName num="kurto"]
It's okay. I'm okay now.
[cpg cn=true]


This is also something I can't say lightly. But for Bianca's sake, I can't be discouraged.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『村』（昼）******************************************************



And then... Bianca worked at a bar and I helped out at a nearby farmhouse for a while.
[cpg]


It was physical work, and I couldn't help for very long, but ...... it was a small way to earn some money.
[cpg]



[OnName num="kurto"]
I was able to make a little money, though it was only ...... a little.
[cpg cn=true]


At noon, I took a short break.
[cpg]


When I was an aristocrat, I never thought about this.
[cpg]


I never thought about this when I was an aristocrat, but now that I have experienced it, I am more thankful to be alive. Now that I am experiencing it, I feel more alive than before.
[cpg]


Looking back, I think I lost that part of myself in my previous life.
[cpg]


I didn't feel alive because I lost appreciation for ordinary life.
[cpg]


I can't help thinking about ....... That was an accident.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『村』（夕方）******************************************************



The more positive I became, the faster the days went by.
[cpg]


It's something you don't realize in the dark. Or maybe Bianca made me realize it.
[cpg]


So I should at least ...... return the favor.
[cpg]



[free time=1000]
[BG f="b_11_3.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Bianca032"]
[OnName num="bianca"]
Thanks for the food.
[cpg cn=true]


[OnName num="kurto"]
Thanks for the food."
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



Save money for food as much as possible. I use as much of the necessities of life as I can.
[cpg]


I learned to do housework little by little. I'm not going to make it hard for Bianca all the time," he said.
[cpg]


...... I still don't want Bianca to be the one to suffer the wrinkles of this unreasonable treatment.
[cpg]


I don't want her to continue living in poverty. I was about to do what I had been thinking about for a long time.
[cpg]


I was going to use technology and inventions from the world I used to live in.
[cpg]


The easy way is to make and sell something that exists today but not in this world.
[cpg]


The word "modern" is also a bit of a complicated one, but I guess you could call it the modern era of the ...... previous world.
[cpg]


In any case, there is definitely a demand for shampoo, for example, and there should be......
[cpg]


The other thing is cooking, right? But there's a serious problem.
[cpg]


I know, but I can't ...... make it.
[cpg]


[OnName num="kurto"]
Bianca, do you know what shampoo is?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Bianca033"]
[OnName num="bianca"]
Shampoo ...... what is it?"
[cpg cn=true]


[OnName num="kurto"]
No. No. You don't know. It's a word that doesn't exist in this world.
[cpg cn=true]


Bianca seemed to be a little uncomfortable with the phrase "in this world.
[cpg]


[OnName num="kurto"]
Shampoo is ...... a soap that cleanses your hair?　No. What are the ingredients?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca034"]
[OnName num="bianca"]
'Um ...... master, what are you talking about?'
[cpg cn=true]


That's the kind of reaction you're going to get. Bianca will have to explain it all to me sooner or later.
[cpg]


[OnName num="kurto"]
Don't be surprised, Bianca.
[cpg cn=true]


Bianca looks mysterious. You may not be surprised to hear what I've heard now.
[cpg]


[OnName num="kurto"]
I've just had a memory from a previous life come back to me.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Bianca035"]
[OnName num="bianca"]
'...... Really?'
[cpg cn=true]


I had a feeling that the word "I see" was chosen after much thought.
[cpg]


[OnName num="kurto"]
'I told you not to be surprised, but you can believe me .......
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Bianca036"]
[OnName num="bianca"]
'Yes, no. I believe you. I don't believe that the master would lie like this.
[cpg cn=true]


But he didn't seem to believe it much.
[cpg]


[OnName num="kurto"]
It was a more civilized world ...... where there were no skills or magic or anything like that."
[cpg cn=true]


Bianca would not have been able to pinpoint it. But I have to prove that this knowledge is real.
[cpg]


I was the only one with knowledge that no one else had. I had no choice but to use it.
[cpg]


[jump storage="ep002.ks" target="*start"]

;//=============================================================================
