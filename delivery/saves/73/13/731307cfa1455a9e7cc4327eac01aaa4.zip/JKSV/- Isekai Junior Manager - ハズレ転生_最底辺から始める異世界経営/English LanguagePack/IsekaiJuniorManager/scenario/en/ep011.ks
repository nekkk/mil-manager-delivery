
*start

;//２、ユイカ


;#################################################
*Ep011|Undisputed Yuica
;#################################################

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]

*select07_2|Everyone recognizes Yuika

[SCENE id=11]

The first thing that came to my mind was Yuika.
[cpg]


A big businessman that everyone recognizes. The one who was ahead of me on the path I was walking.
[cpg]


If Bianca was standing at the start, Yuhka is standing at the goal.
[cpg]


She is also a very shrewd person. I strongly wished to be united with her.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************



When I started to be aware of her, I felt a kind of fidgety feeling.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Edith141"]
[OnName num="edith"]
"Let's see, ......, I've got the goods for this week: ......."
[cpg cn=true]


[OnName num="kurto"]
Oh, I'll bring it in, just leave it there."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Edith142"]
[OnName num="edith"]
He said, "Kurth, what's wrong with ......?　It looks like the sky above us.
[cpg cn=true]


Oh, yeah. You're not fidgeting, you're just up in the air. ......
[cpg]


[OnName num="kurto"]
"Do I look like that?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Edith143"]
[OnName num="edith"]
"Yeah,...... it's like I've got someone I like."
[cpg cn=true]


They see through it all. Am I that easy to understand?
[cpg]


If Yuika herself saw me, she would find out all about it.
[cpg]



[SE f="se002"]
;//【ＳＥ】『ドア開く』


[free time=1000]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[WAIT time=1000]
[OnName num="kurto"]
The first thing that you need to do is to make sure that you have a good time.
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Yuika124"]
[OnName num="yuika"]
"Good evening. I was in the neighborhood, so I came by on my way. How are sales going?
[cpg cn=true]


[OnName num="kurto"]
Sales are relatively good, thanks to you. It's thanks to you.
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Yuika125"]
[OnName num="yuika"]
That's not true. Kurth's efforts must have paid off.
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Edith144"]
[OnName num="edith"]
Kurth, you should be more magnanimous.
[cpg cn=true]


Mr. Edith's words were nuanced.
[cpg]


It seems as if he is encouraging me to be a little more humble in front of Yuika, the man of my heart,.......
[cpg]


How could I be thinking too much? I was thinking that.
[cpg]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Edith145"]
[OnName num="edith"]
I've got some business to attend to,......, so the two of us will be on our own.
[cpg cn=true]


[OnName num="kurto"]
Oh, yeah. Oh, yeah, thanks.
[cpg cn=true]



[SE f="se004"]
;//【ＳＥ】『ドア閉まる』


[free time=1000]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[WAIT time=1000]

After Mr. Edith left, it was just the two of us, me and Yuika.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Yuika126"]
[OnName num="yuika"]
What's the matter? You seem strangely nervous today.
[cpg cn=true]


I wondered if I was fidgety or not. Which is it?
[cpg]


[OnName num="kurto"]
No, ...... it's nothing.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuika127"]
[OnName num="yuika"]
"Nothing at all, is that so?"
[cpg cn=true]


I wonder if Yuika is waiting for me to say something.
[cpg]


I can't read their mind. I want to know Yuhka-san's mind just now, even if it is a normal thing.
[cpg]

[FADEOUTBGM]

[OnName num="kurto"]
Oh, I ...... about Yuika-san.
[cpg cn=true]


I don't think now is the right time to confess.
[cpg]


And in my store. But maybe the fact that it's just the two of us is a good thing.
[cpg]


[OnName num="kurto"]
I like you.
[cpg cn=true]


Unrelenting, or hasty, would be the words to describe me.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika128"]
[OnName num="yuika"]
I'm glad. I had a feeling. Thank you.
[cpg cn=true]


That's why I'm so impatient with such a reply.
[cpg]


I couldn't wait to hear what he would say after "thank you.
[cpg]

[BGM f="bgm_07"]
[WAIT time=100]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuika129"]
[OnName num="yuika"]
But I can't respond to Kurth's wish.
[cpg cn=true]


Yuika-san said so and looked a little apologetic.
[cpg]


[OnName num="kurto"]
'Why ......'
[cpg cn=true]


What a dumb word.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika130"]
[OnName num="yuika"]
I come from a family of merchants. I come from a family of merchants, and there is such a thing as a political marriage.
[cpg cn=true]


Hearing those words, I felt my heart tighten.
[cpg]


Yuika is married ...... to someone other than me?　With someone other than me?
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuika131"]
[OnName num="yuika"]
It is my father's will. He won't allow me to marry a commoner.
[cpg cn=true]


[OnName num="kurto"]
Oh, no.
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Yuika132"]
[OnName num="yuika"]
I don't think so either. But my permitted marriage is to a nobleman. I guess he thinks it's better for me to do well as a merchant.
[cpg cn=true]


 I had no choice but to accept the reality, even though I thought that this was not the case.
[cpg]


The person I love can only be a nobleman. And I am not an aristocrat. ......
[cpg]


Even if I once was, I am now a disowned person.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika133"]
[OnName num="yuika"]
As for my personal feelings, Kurth, I like you."
[cpg cn=true]


[OnName num="kurto"]
......"
[cpg cn=true]


Her follow-up pierces my heart.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuika134"]
[OnName num="yuika"]
I'm sorry. It's something I can't handle on my own."
[cpg cn=true]


Yuika finally apologized.
[cpg]


Do I have to give up here? No, I still have to ......
[cpg]


I can't give up yet. This doesn't mean that all roads have been cut off.
[cpg]


[OnName num="kurto"]
Please don't apologize. I'm not giving up yet.
[cpg cn=true]


[OnName num="kurto"]
If you say you can only be an aristocrat, then I'll be an aristocrat.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika135"]
[OnName num="yuika"]
"I like ....... You have a good heart. If you are going to be my husband, you have to be that good.
[cpg cn=true]


Yuika packed me in a little and continued to ......
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Yuika136"]
[OnName num="yuika"]
"Ssshhhh."
[cpg cn=true]


I was so happy to see her. The soft touch touched me.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています



[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Yuika161"]
[OnName num="yuika"]
'...... I know it's frustrating for me too. I'm sorry that I can't tie you up, but I'm also sorry that I'm keeping you at a distance."
[cpg cn=true]


[OnName num="kurto"]
I'm not. I'm happy for you.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuika162"]
[OnName num="yuika"]
I'm not. I feel guilty.
[cpg cn=true]


I guess the problem is that I am not an aristocrat.
[cpg]


Or should I build up enough wealth to rival that of a nobleman?
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



Without knowing, morning came and went again, and then noon. The days passed by at a dizzying pace.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Alma523"]
[OnName num="alma"]
......You don't look so happy, Kurth.
[cpg cn=true]


At that time, Arma and Bianca were there.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Bianca300"]
[OnName num="bianca"]
'Master, is something wrong?
[cpg cn=true]


[OnName num="kurto"]
'Nope. Nothing."
[cpg cn=true]


I acted as if nothing was wrong as much as I could.
[cpg]


If I was depressed, I would be even further from my goal.
[cpg]


In other words, to become a merchant comparable to a nobleman. ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yuika163"]
[OnName num="yuika"]
Hi. Hello."
[cpg cn=true]


[OnName num="kurto"]
Hello. Yuika-san."
[cpg cn=true]


I felt happy just to see her.
[cpg]


I knew that these feelings would later turn into something painful, but I couldn't suppress them.
[cpg]

[free time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Alma524"]
[OnName num="alma"]
"Yuika-san, is your work going well?"
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Yuika164"]
[OnName num="yuika"]
Well, I guess. Arma is the one who is not busy being an aristocrat."
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Alma525"]
[OnName num="alma"]
I owe a debt of gratitude to ...... Kurth.
[cpg cn=true]


The two of them were talking about that. I was looking at ......
[cpg]


The first thing to do is to make sure that you have a good time with your family.
[cpg]


She is resolute and yet dashing. I'm just fascinated by Yuika.
[cpg]


[free time=1000]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Bianca301"]
[OnName num="bianca"]
"......Master. The source of your troubles, perhaps?"
[cpg cn=true]


[OnName num="kurto"]
Eh?　Oh, no.
[cpg cn=true]


I quickly try to cover it up, but Bianca might have seen right through me.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



After that, Bianca was very considerate and went home first.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

It was just me and Yuika. It was nice to be just the two of us in that restaurant again, but ......
[cpg]


Today, I was invited to Yuika's room. But of course, it's not my parents' house or anything.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Yuika165"]
[OnName num="yuika"]
I don't often live in one place. Even if it's my room, it's not much.
[cpg cn=true]


[OnName num="kurto"]
No, I've been curious about it for a while. I've always wondered about the architecture.
[cpg cn=true]


Her house had a look like no other.
[cpg]


But I think it is probably a common construction in Yuika's hometown.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuika166"]
[OnName num="yuika"]
Well, ...... my hometown is an island country, so we have a lot of our own culture."
[cpg cn=true]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



The place where I was taken while talking like that was indeed a unique room.
[cpg]


Or rather, this ...... is like old Japan. I remembered it from before my reincarnation.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika167"]
[OnName num="yuika"]
This is called tatami. Do you know what is called "Igusa"?
[cpg cn=true]


[OnName num="kurto"]
Yes, well. I know what tatami is.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuika168"]
[OnName num="yuika"]
Is that so?　I think it is unique to this country.
[cpg cn=true]

;//移植のためシーンをカットしています



;//ブラックアウト
;//========================================
;//●ＣＧ（畳に触れるヒロイン。振り返って主人公と話す）ev_38
;//人物１：ヒロイン２　服装１：裸
;//人物ex：主人公　　　服装ex：裸
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_38_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sYuika005"]
[OnName num="yuika"]
Try to touch it. Tatami has a good touch.
[cpg cn=true]


Yuhka turned her back to me after saying that.
[cpg]

[VOICE f="sYuika006"]
[OnName num="yuika"]
She turned her back to me and said, "What's wrong with ......?　Shut up.
[cpg cn=true]


Then Yuika and I touched each other for a while.
[cpg]


[OnName num="kurto"]
Yuika," he said, "I'm going to be a  nobleman someday. I will be a merchant who can compete with the ...... aristocrats one day.
[cpg cn=true]


My love for her is only getting stronger, I say. But
[cpg]


;**【ＣＧ】 ev_38_a ***********************
[CG id=11 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Yuika196"]
[OnName num="yuika"]
I said, "That's all well and good. I wonder if my father would be satisfied with such a thing."
[cpg cn=true]


Yuika's reply was something like that.
[cpg]


[VOICE f="Yuika197"]
[OnName num="yuika"]
I just don't like my ...... permitted marriage or anything."
[cpg cn=true]


[VOICE f="sYuika007"]
[OnName num="yuika"]
I don't think I want to devote myself to my current marriage."
[cpg cn=true]


Saying that, Yuika looked at me.
[cpg]

;//移植のためシーンをカットしています


;//ブラックアウト


Time passes mercilessly. If I stay idle, my marriage to my fiancee will be soon.
[cpg]


So, I can't be lazy.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************




[FACE method="change_1" pos="2/3"]
[OnName num="kurto"]
Then ...... see you later."
[cpg cn=true]


Yooka-san walked me home.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika222"]
[OnName num="yuika"]
She said, "Yes, I'm busy with work for a while. I'm busy with work for a while, but stay strong.
[cpg cn=true]


I don't get to see Yuika whenever I want.
[cpg]


I can't see her. I can't even think of it as hard.
[cpg]


If you minimize your responsibilities, you will have more time to meet with Yooka.
[cpg]


But as much as I ...... think about it, I couldn't do just that.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



I can't live a makeshift life. I'm not going to be able to live a makeshift life.
[cpg]


I did everything I could.
[cpg]


I thought of new products and new ways to sell them.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca302"]
[OnName num="bianca"]
'...... master, are you not getting enough sleep?'
[cpg cn=true]


[OnName num="kurto"]
No, I'm not. Thank you for worrying about me.
[cpg cn=true]


I rub my sleepy eyes and go about my work today.
[cpg]


[free time=1000]
[SE f=se022]
;//【ＳＥ】『入店音』
[WAIT time=1100]

[OnName num="kurto"]
Welcome.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Catalina199"]
[OnName num="catalina"]
Good evening. You look like you haven't slept enough.
[cpg cn=true]


Katharina said the same thing to me.
[cpg]


She must look very sleepy, which is not good for my work. ......
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Bianca303"]
[OnName num="bianca"]
I think you should get some rest. I'll take care of the store tomorrow.
[cpg cn=true]


[OnName num="kurto"]
No, that's not how it works. ...... I really need to become a big businessman.
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Catalina200"]
[OnName num="catalina"]
You're being stubborn. You must have a reason to work so hard.
[cpg cn=true]


Of course there is. Everything is for a happy future with Yuika.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yuika223"]
[OnName num="yuika"]
"Hey, Kurth. Long time no see.
[cpg cn=true]


[OnName num="kurto"]
Yes, it's been a while. I've developed a new product again.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sYuika008"]
[OnName num="yuika"]
What's up with ......?　You look pale.
[cpg cn=true]


I didn't notice when he said that. When I stood up, I felt a little lightheaded.
[cpg]

From there, my memory went a little off.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[VOICE f="Yuika244"]
[OnName num="yuika"]
Kurth!"
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p5_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]

;//移植のためシーンをカットしています



The next time I woke up, I was in Yuika's room.
[cpg]


[OnName num="kurto"]
I was in ......'s room.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuika245"]
[OnName num="yuika"]
I was so glad to see you. I was wondering what I was going to do when you suddenly collapsed.
[cpg cn=true]


[OnName num="kurto"]
I was wondering what I was going to do. It looks like it's already noon, .......
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika246"]
[OnName num="yuika"]
I've been sleeping. You should take it easy.
[cpg cn=true]


[OnName num="kurto"]
Were you next door?　Yuika's work is at ......"
[cpg cn=true]


Yuika shook her head. Then she said.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuika247"]
[OnName num="yuika"]
'Don't worry about it. It's fine if you work hard, but if you collapse, I'll worry about you.'
[cpg cn=true]


[OnName num="kurto"]
'...... sorry.'
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夕方）******************************************************



By the time we left her house, it was completely evening.
[cpg]


Maybe Bianca has managed to get the store or something ......
[cpg]


but I would consider it a waste of time.
[cpg]


I know I'm rushing myself.
[cpg]


But I was still aware that the time limit was approaching.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



[FACE method="change_7" pos="4/5"]
[VOICE f="Bianca304"]
[OnName num="bianca"]
'Master ......, are you feeling better already?
[cpg cn=true]


[OnName num="kurto"]
I'm sorry for worrying you. I'm sorry for worrying you.
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Bianca305"]
[OnName num="bianca"]
I'm sorry for worrying you. I'm sorry for worrying you.
[cpg cn=true]


[OnName num="kurto"]
"Even if you say so,.......
[cpg cn=true]


I can't stop trying. I know I'm being a little stubborn.
[cpg]


[OnName num="kurto"]
I can't not work hard. I, I have my dreams."
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Alma526"]
[OnName num="alma"]
'Dreams and all, it's all for naught if I destroy my own body.
[cpg cn=true]


Arma-san comes out from the backyard. She's come to help, too, hasn't she?
[cpg]


[OnName num="kurto"]
That's true, but ...... also.
[cpg cn=true]


[FACE method="change_1" pos="2/5"]
[VOICE f="Alma527"]
[OnName num="alma"]
If you don't do it efficiently, your dream won't come true.
[cpg cn=true]


Arma seemed to know what my dream was.
[cpg]


I want to be united with Yuika,...... I wonder if she knows that feeling and is supporting me.
[cpg]


;//ブラックアウト
;//移植のためシーンをカットしています

;//移植のためシーンをカットしています



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



I shouldn't be in too much of a hurry, but I needed to hurry.
[cpg]


I keep developing new products. Something that doesn't exist in this world, and something that can only exist in this world.
[cpg]


I have one goal. I have no choice but to become the kind of man who can marry Yuika and be chosen in comparison to the nobleman's permitted marriages.
[cpg]


I have no choice but to become such a man. If her father does not approve, there is no other way.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Edith146"]
[OnName num="edith"]
"Mr. Kurth, ......, this week's item of the week."
[cpg cn=true]


[OnName num="kurto"]
Thank you for everything. You've improved your skills again, Mr. Edith.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Edith147"]
[OnName num="edith"]
No, I haven't. I'm just motivated by your interesting blueprints. ......
[cpg cn=true]


Mr. Edito is praising me, but I can't be proud. I can't be proud of it.
[cpg]


I needed to aim higher.
[cpg]


If he remains a mere merchant, he will never be able to connect with Yuika.
[cpg]


If this is true, I must hurry up. Such a feeling was rising in me.
[cpg]


Of course, if it becomes impatience, the nature becomes the opposite. Someday I'll get my feet wet. ......
[cpg]


I was inclined to push myself somewhat, even if I had to.
[cpg]
[FACE method="shake_4" pos="2/3"]
[VOICE f="Edith148"]
[OnName num="edith"]
"...... Kurth. Don't take that ...... too hard."
[cpg cn=true]


Do I look like I'm in bad shape? I feel like this has happened before.
[cpg]


[OnName num="kurto"]
I'm fine. Thank you for your concern.
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



I left the afternoon store duty to the clerk I hired, and started thinking of new products again.
[cpg]



So I had a meeting with someone ......
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yuika297"]
[OnName num="yuika"]
'Hello. Kurth,...... I can leave now."
[cpg cn=true]


[OnName num="kurto"]
Kurth: "Yes. Shall we go then?"
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_12_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[SE f="se014"]
;//【ＳＥ】『歩く』



I walk a little farther with Yuika.
[cpg]


The time we spent alone together was irreplaceable, a time of almost unbearable happiness.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuika298"]
[OnName num="yuika"]
You've come up in the world, haven't you? I can say that you have already become a big businessman that everyone recognizes.
[cpg cn=true]


[OnName num="kurto"]
No, I'm not. I'm not there yet.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika299"]
[OnName num="yuika"]
Too much modesty is a form of condescension. If you are recognized by everyone, it means that you have to recognize it yourself.
[cpg cn=true]


[OnName num="kurto"]
...... I see. We've come a long way.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Yuika300"]
[OnName num="yuika"]
"At this rate, my father might ...... agree."
[cpg cn=true]


The "may" was followed by the "may. Of course, I couldn't be complacent.
[cpg]


Still, my heart pulsed with a thump.
[cpg]


[OnName num="kurto"]
Yuika," he said, "I'm not a man worthy of you. I will become a man worthy of you.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika301"]
[OnName num="yuika"]
I already am. But whether my father will approve of it or not is another matter.
[cpg cn=true]


There are things that please me and things that do not. At any given time, there is no such thing as just one or the other.
[cpg]


It's up to each person to decide which one to focus on, but I wanted to be happy, even for a moment.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落』（昼）******************************************************


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Catalina208"]
[OnName num="catalina"]
"Hey, is that ......?　Kurth, and Yuika, too."
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Yuika302"]
[OnName num="yuika"]
Oh, ......, does Katharina live here?
[cpg cn=true]


[OnName num="kurto"]
Hello. I just thought I'd do a little sampling.
[cpg cn=true]


[FACE method="shake_1" pos="4/5"]
[VOICE f="sCatalina013"]
[OnName num="catalina"]
Is that so?　But there are demons ahead and it's dangerous. Shall I follow you?"
[cpg cn=true]


[OnName num="kurto"]
No, no, ...... it's, you know..."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
 I wanted to be alone with Yuika.
[cpg]


I thought that Ms. Katharina's presence would be awkward .......
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Catalina210"]
[OnName num="catalina"]
Well, don't let them get back at you."
[cpg cn=true]


[OnName num="kurto"]
"......Yes."
[cpg cn=true]


Ms. Katharina was very attentive. She also understands the relationship between me and Yuika.
[cpg]



;//背景と別の場所なので、上下に黒帯を入れるなどしてください

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

And then we went into the forest.
[cpg]
The actuality that you can find a lot of people who are not able to get the same thing.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sYuika009"]
[OnName num="yuika"]
So, what's ahead?
[cpg cn=true]


[OnName num="kurto"]
It has been confirmed that there are magic stones. We have confirmed that there are magic stones, and we may be able to get some other rare materials.
[cpg cn=true]


The reason for this was that no one would go near the place because of the presence of demons.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[VOICE f="sYuika010"]
[OnName num="yuika"]
Pssst!"
[cpg cn=true]


;//========================================
;//●ＣＧエロ（公式サイト　右上のＣＧ　触手）ev_32
;//人物１：ヒロイン２　服装１：裸
;//人物ex：主人公　　　服装ex：着衣
;//場所　：森の中
;//時間　：昼
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bgm_09"]
;**【ＣＧ】 ev_32_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]


Because we are stepping into such a place, things like this happen.
[cpg]

[VOICE f="sYuika011"]
[OnName num="yuika"]
Kurth ......, help me.
[cpg cn=true]


[OnName num="kurto"]
I know. I'm going to use a demon repellent.
[cpg cn=true]


[VOICE f="sYuika012"]
[OnName num="yuika"]
You knew ...... this was going to happen and you didn't use it."
[cpg cn=true]


I was able to help her out by playing dumb.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落』（夕方）******************************************************




[VOICE f="Yuika350"]
[OnName num="yuika"]
Hey, Kurth," she said, "you're still being polite. How long are you going to be polite?
[cpg cn=true]


[OnName num="kurto"]
"Well, ......, that's..."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Yuika351"]
[OnName num="yuika"]
You can call me that, too. We're not just business partners, are we?
[cpg cn=true]


[OnName num="kurto"]
I'm not just a business partner. No, that's right.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika352"]
[OnName num="yuika"]
'That's fine, Kurth. I'll talk to you the same way I've always talked to you.
[cpg cn=true]


[OnName num="kurto"]
"Yeah. I'll keep in touch with you.
[cpg cn=true]



;//ここからクルトはユイカを呼び捨てになり、ユイカに対してクルトは丁寧語ではなくなります



Me and Yuika are getting closer and closer to each other.
[cpg]


But it is also true that they are about to be pulled away from me.
[cpg]


I'm not going to let it go like this. I had to talk to Yuika's father once.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



The new product was taking off. We had acquired considerable wealth.
[cpg]


That's about as much as an aristocrat.
[cpg]


I felt that now was the time to cut the cards. Yuhka had told him that.
[cpg]


[FACE method="bow_1" pos="2/3"]
;//[VOICE f="Yuika353"]
[VOICE f="sYuika013"]
[OnName num="yuika"]
;//「父さんが、ちょうどこの街近くに来てる。私に会いたがるのが自然だと思うよ」
'My father is just coming near the city. I think it's natural he'd want to see me."
[cpg cn=true]


[OnName num="kurto"]
'......Oh. I guess my first impression of you will be made here, too.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuika354"]
[OnName num="yuika"]
'Well then, let's go. I don't care how nervous you are, I don't think you can be too careful.
[cpg cn=true]


That's how I headed to Yuika's house.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I was so nervous that I had never been so nervous in my life.
[cpg]


;//背景と別の場所なので、上下に黒帯を入れるなどしてください



[OnName num="yuika's_father"]
I was so nervous that I had never been so nervous in my life. I've heard rumors about you for a long time.
[cpg cn=true]


Yooka's father was a man who looked just like Yooka's father.
[cpg]


The way he talks is very similar to her father. He also has the same face and looks like him.
[cpg]



[OnName num="kurto"]
I owe it all to the cooperation of ...... Yuhka.
[cpg cn=true]


[OnName num="yuika's_father"]
What, it's your own talent. There is no need to be downhearted about it.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]

The basic philosophy is similar to Yuika's. However, there are some fundamental differences between the two.
[cpg]


However, there were some fundamental differences. ......
[cpg]


[OnName num="yuika's_father"]
But my family has been a merchant for generations. It's been going on for 500 years.
[cpg cn=true]


[OnName num="yuika's_father"]
I'm not thinking of marrying my daughter to anyone other than an aristocrat. I'll tell you that before you cut me off.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuika355"]
[OnName num="yuika"]
Father ......, are you thinking of my feelings?
[cpg cn=true]


[OnName num="yuika's_father"]
'You'd better think about it later, Yuika. Yuika should really be aware of that."
[cpg cn=true]


Yuika's father was her father, of course, but he was her father by all means.
[cpg]


[OnName num="yuika's_father"]
Of course, if Kurth-kun were to become an aristocrat or something, that would be a different story, but is that possible?
[cpg cn=true]


He seemed to place the highest priority on his daughter being able to lead a stable life and be happy.
[cpg]


The fact that he was by no means a tyrannical person rather drove me to the edge.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夕方）******************************************************



[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuika356"]
[OnName num="yuika"]
'It would be a different story if we were to ...... elope, but I don't think we'll be able to do business anymore.'
[cpg cn=true]


[OnName num="kurto"]
'You don't have to do that. Yuika, you want to be a great merchant, too."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuika357"]
[OnName num="yuika"]
But if you keep chasing this dream, you'll never get together with Kurth.
[cpg cn=true]


Yuhka can't go against the will of her own family. And I remained a commoner, no matter how big a merchant I became.
[cpg]


I can't help but think about it once more. I think back.
[cpg]


[OnName num="kurto"]
How about going back to my parents' house and ...... asking them again for the offer I once turned down?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika358"]
[OnName num="yuika"]
"Did you mean you turned me down once?"
[cpg cn=true]


[OnName num="kurto"]
"Yes, it happened. My brothers came to this city. ......
[cpg cn=true]


The actuality is that if you become an aristocrat once more, you can be on more than equal footing with Yuhka's marriage partner.
[cpg]


 Naturally, since they broke up once, there will be some animosity between them.
[cpg]


But ...... there is no other way.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************





[VOICE f="Bianca306"]
[OnName num="bianca"]
The first thing that comes to mind is the fact that the two are not only inseparable, but also inseparable. How did you ...... feel?"
[cpg cn=true]


I shook my head, which was not the right thing to do, so I kept quiet.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Yuika359"]
[OnName num="yuika"]
'I didn't think my father could be that stubborn. He seems to think I'm pretty cute."
[cpg cn=true]


But Yuika had said so.
[cpg]


Yes, I know it's difficult if you think about it calmly.
[cpg]


[FACE method="bow_4" pos="2/5"]
[VOICE f="Bianca307"]
[OnName num="bianca"]
'...... I see.'
[cpg cn=true]


Bianca has a complicated expression on her face. I know she likes me, too.
[cpg]


But I don't think I would ever wish for it not to work out with Yuika.
[cpg]


[OnName num="kurto"]
Bianca. I'm going to go to my parents' house again. I want to negotiate with them to see if I can be made a noble.
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Yuika360"]
[OnName num="yuika"]
Do you want me to go with you?　What do you say, Kurth?
[cpg cn=true]


[OnName num="kurto"]
No, it's my problem. I don't need Yuika to help me.
[cpg cn=true]


Even if that is the reason why I am finally tied to Yuika.
[cpg]


 I wanted to settle this by myself.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************



I decided to leave the town where I am now and head to the former residence of the Lammertz family.
[cpg]


The Lammerz family. The former hateful enemies who disowned me. ......
[cpg]


I think back. I know they have done terrible things to me, and I can hate them.
[cpg]


But now I have to cooperate. I now have a purpose beyond hating them.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_12_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



[SE f="se000"]
;//【ＳＥ】『馬車』



The carriage swung me along and I headed off.
[cpg]


Bianca will be tending to the store, and Yuika will be working.
[cpg]


It's really just me. I felt like this was a total test to see how far I could go on my own.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『屋敷＿室内』（昼）******************************************************



[OnName num="josef"]
"Hey," she said, "thanks for coming back. Thanks for coming back.
[cpg cn=true]


[OnName num="emile"]
......"
[cpg cn=true]


I had a feeling that Brother Joseph would have this attitude.
[cpg]


He is a man who sees overall profit everywhere. He would not treat me badly for no good reason.
[cpg]


But the problem is with brother Aamir and father ......
[cpg]


I think that Aamir, in particular, is more of an emotional type of person.
[cpg]


[OnName num="kurto's_father"]
I'm not going to go back to being a nobleman. You have no intention of returning to the nobility, do you?
[cpg cn=true]


[OnName num="kurto"]
No. Just the opposite, father. Just the opposite, father.
[cpg cn=true]


[OnName num="emile"]
What do you mean?　You're rehashing a story you already told me you don't want.
[cpg cn=true]


[OnName num="kurto"]
Yes. I want you to let me back into the Lammertz family. I'm sorry I've been so rude to you.
[cpg cn=true]


I bowed my head. First of all, I had to tell him everything frankly.
[cpg]


[OnName num="emile"]
If you're going to be like that, why didn't you accept me in the first place?
[cpg cn=true]


[OnName num="josef"]
"Well, well, well. You know how I feel, and if you're going to be like that, why didn't you just disown me?
[cpg cn=true]


[OnName num="kurto's_father"]
But you know what? ......
[cpg cn=true]


[OnName num="kurto"]
I'll stay here until you admit that. I have powers now that I didn't have before.
[cpg cn=true]


[OnName num="kurto"]
Dad, brother. I may be able to help you in some way. If you want, you can tell me all about it."
[cpg cn=true]


[OnName num="emile"]
"......," he said, "that's not what I want to hear.
[cpg cn=true]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『屋敷＿室内』（夕方）******************************************************



Dad said he had some business to attend to and left.
[cpg]


I'm sure he didn't want to spend too much time talking to me, the person who disowned him. I didn't go after him either.
[cpg]


I didn't go after him either. As I talked to them, I began to see a breakthrough.
[cpg]


[OnName num="josef"]
I said, "You can talk about it. "The mine story."
[cpg cn=true]


[OnName num="emile"]
Joseph, that's not something you talk to Kurth about.
[cpg cn=true]


[OnName num="josef"]
Rather, you have to talk to Kurth. It's about business.
[cpg cn=true]


It was almost as if brother Joseph had prepared it for me. I can't thank him enough. ......
[cpg]


[OnName num="kurto"]
'What's up with the mine?　Come to think of it, we owned the mine."
[cpg cn=true]


[OnName num="emile"]
'...... yeah. The mine that the Rammeltz family owned was the one that ......"
[cpg cn=true]


[OnName num="josef"]
We're running out of steam. We need new technology or another vein."
[cpg cn=true]


[OnName num="kurto"]
What kind of vein?　Metal or something?
[cpg cn=true]


[OnName num="emile"]
No. Magic stone.
[cpg cn=true]


[OnName num="kurto"]
......!
[cpg cn=true]


Oh, my God. Here we are, talking about that.
[cpg]


Digging up veins of magic stone is my area of expertise.
[cpg]


And to top it off, I can even enlist Katharina's help. I'm sure she has knowledge in this area.
[cpg]


[OnName num="kurto"]
If I can re-establish that vein of ore, ......
[cpg cn=true]


[OnName num="josef"]
I'm sure you'll agree.
[cpg cn=true]


It was as if Joseph had the answer ready from the beginning.
[cpg]


I feel like I'll never be able to get my head around him again. Or maybe he will ask for some kind of deal.
[cpg]


[OnName num="kurto"]
Thank you for ....... Thank you, Brother Joseph.
[cpg cn=true]


[OnName num="josef"]
No," he said. I've always felt guilty about it. He's my only brother.
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『屋敷＿室内』（夜）******************************************************



Toward the end of the night, I told him everything.
[cpg]


I could run the business again. I was very clear about this.
[cpg]


He wouldn't be convinced if I said I might be able to do it.
[cpg]


[OnName num="kurto"]
I know I'm going to say the same thing one more time,......, but let me tell you something.
[cpg cn=true]


[OnName num="kurto"]
"Dad, I want to be a family with you again. I want to be a family again.
[cpg cn=true]


[OnName num="kurto's_father"]
"...... but ......
[cpg cn=true]


[OnName num="kurto"]
I'm not doing this for nothing.
[cpg cn=true]


[OnName num="kurto"]
Maybe I can show your grandkids' faces."
[cpg cn=true]


I didn't like the way he said it, or the way he did it, but it might work.
[cpg]


I think they must have noticed it somehow. I think they must have realized that it wasn't just about expanding their business.
[cpg]


[OnName num="kurto's_father"]
I already have grandchildren," he said. Aamir is already married.
[cpg cn=true]


[OnName num="kurto"]
"Really, brother?　Is that so, brother?
[cpg cn=true]


[OnName num="emile"]
But ...... father. I'm telling you this much.
[cpg cn=true]


[OnName num="kurto's_father"]
Yes, I am. I guess I was being a little too stubborn.
[cpg cn=true]


[OnName num="kurto's_father"]
When Kurth apologized, I didn't know what to do. But now I do.
[cpg cn=true]


[OnName num="kurto's_father"]
I'm sorry. I had to do what I had to do.
[cpg cn=true]


I don't think that's what he meant when he said he was sorry. But still, ......
[cpg]


I was thinking, "I've done it.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



The next day, I returned to the town where Yuika was waiting for me.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika361"]
[OnName num="yuika"]
I came back to the town where Yuika was waiting for me the next day. How was it?
[cpg cn=true]


[OnName num="kurto"]
I said, "Oh, it seems to be going well. It seems to be going well, Yuika.
[cpg cn=true]


I was happy to be able to give Yuika a good report.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Yuika362"]
[OnName num="yuika"]
"Well, ......, that's good. Now we're going to ......
[cpg cn=true]


[OnName num="kurto"]
"Let's stay together forever. I'll be with you forever, Yuhka. We don't have to worry about anything anymore."
[cpg cn=true]


Yuika smiled at me. The first thing to do is to make sure that you have the right tools and the right people to help you.
[cpg]


I thought, ...... that's me. I couldn't see her face properly anymore.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Yuika363"]
[OnName num="yuika"]
I'm not going to cry. You must be happy.
[cpg cn=true]


[OnName num="kurto"]
She said, "Oh, I'm not crying. I'm not crying.
[cpg cn=true]



;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



;//背景と別の場所なので、上下に黒帯を入れるなどしてください



And the next time Yuika's father came.
[cpg]


I couldn't fail here either, but I still felt much better.
[cpg]


I felt that I could handle any difficult task that he might ask of me here.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="yuika's_father"]
Yuhka told me what happened. You used to be an aristocrat, didn't you?
[cpg cn=true]


[OnName num="kurto"]
Yes, I was. I'm sorry for hiding it from you.
[cpg cn=true]


[OnName num="yuika's_father"]
I didn't make a promise, but I also said that if I ever became a nobleman, I would.
[cpg cn=true]


[OnName num="yuika's_father"]
...... And, more importantly, Yuika seems to be quite fond of you.
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]

I guess Yuika has done a lot behind my back. I can understand that somehow.
[cpg]


When I think about it, it's all things that I couldn't reach with my own strength.
[cpg]


Bianca, Katharina, and Edith. Katharina, Edith, Arma, ......
[cpg]


If one of them had been left out, I might not be able to be with Yuika like this now.
[cpg]


[OnName num="yuika's_father"]
I'm not going to ask you to give me your daughter," she said. I don't want to hear the common words, "Give me your daughter.
[cpg cn=true]


[OnName num="yuika's_father"]
You've already done more than that.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Yuika387"]
[OnName num="yuika"]
Then go to .......
[cpg cn=true]


[OnName num="yuika's_father"]
Do what you want, Yuika. I won't interrupt you anymore.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]

After all, it was a somewhat roundabout way of putting it. But that's good enough for us.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_08"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



[OnName num="kurto"]
So, that ......."
[cpg cn=true]



When I returned to the restaurant, Bianca was fine, but for some reason Arma was there.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Alma528"]
[OnName num="alma"]
Why do you look so apologetic?　It's supposed to make you happy."
[cpg cn=true]


[OnName num="kurto"]
'It is, but ......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Yuika388"]
[OnName num="yuika"]
What kind of attitude is that? I don't want you to say that you owe me anything now that you're going to be with me."
[cpg cn=true]


That is true. But it became awkward to be in the position of being congratulated.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Bianca308"]
[OnName num="bianca"]
Congratulations. You are getting married to Yuika."
[cpg cn=true]


[OnName num="kurto"]
"No!　That's too soon.
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Yuika389"]
[OnName num="yuika"]
'So ...... what does that mean? I intend to.
[cpg cn=true]


Yuhka did not seem to intend to just go out with him.
[cpg]


For me, I thought it would be a problem before dating if I had a forgiven wife, so I thought I'd just start dating now, but ......
[cpg]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Yuika390"]
[OnName num="yuika"]
I've been so masculine, and now you've ruined it. Well, I like Kurth that way, too."
[cpg cn=true]


Bianca and Arma both looked at me with eyes that saw something smiling.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Bianca309"]
[OnName num="bianca"]
'We're celebrating today, aren't we? Shall we have a party at my place?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Alma529"]
[OnName num="alma"]
Bianca and Arma were both smiling at me. Kurth, you don't seem to be aware of it.
[cpg cn=true]


I had been told that much. I wonder if it's that much. ......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



Then we had a small pre-party celebration at my place.
[cpg]


I don't know if it was a pre-ceremony celebration or not, but since I'm going to tie the knot with Mr. Yuika, it was a normal celebration ......
[cpg]


Arma brought Edith and Katharina, too.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Bianca310"]
[OnName num="bianca"]
'With six of us, this house is so small.
[cpg cn=true]


[OnName num="kurto"]
'Really. ......
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Catalina211"]
[OnName num="catalina"]
What's with that tone of voice? Do you think I shouldn't have come?
[cpg cn=true]


[OnName num="kurto"]
No, no. No, no, I don't think so.
[cpg cn=true]


I don't know," said Katharina.
[cpg]


But when I think about it, this situation is unusual.
[cpg]


They are all people who helped me. I understand that if you want to celebrate, these are the members of the group.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[VOICE f="Edith149"]
[OnName num="edith"]
When is the wedding ......?"
[cpg cn=true]


Even Mr. Edith is talking about it. I hadn't thought about it yet.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Yuika391"]
[OnName num="yuika"]
I'll wait. Until Kurth is ready.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Alma530"]
[OnName num="alma"]
You're so mature, Yuika. I wonder if she won Kurth over with that kind of reserve.
[cpg cn=true]


The party was going on with such conversation, mainly with the members other than me.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I was so tired at night that I fell asleep right away.
[cpg]


But I didn't feel frustrated that I couldn't do what I should have done before.
[cpg]


From now on, I could live my life thinking only about Yuika.
[cpg]


I was happy to think so.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



I could concentrate on my work because I didn't have to worry about anything else.
[cpg]


And because I could focus on my work, I also had a little more time off.
[cpg]


This meant that I could spend more time with Yuika.
[cpg]


I enjoy my work even more and get more done.
[cpg]


I feel that a good loop has been created. I think we are on the right track.
[cpg]




[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夕方）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yuika392"]
[OnName num="yuika"]
"Hey, Kurth. Did I keep you waiting, Kurth?
[cpg cn=true]


[OnName num="kurto"]
"No. I just got here. I just got here.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika393"]
[OnName num="yuika"]
Good, then. You haven't had dinner yet, right?
[cpg cn=true]


[OnName num="kurto"]
No. Shall we eat somewhere?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika394"]
[OnName num="yuika"]
"Yes, I think so. I'm tired this week too, so I want to eat something delicious.
[cpg cn=true]


Yuika said so, and we headed for a restaurant that was once out of reach.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



I was so happy that I felt like I was going to burst.
[cpg]


I was so happy to be so close to Yuika. That was all I really needed.
[cpg]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



Then, another day.
[cpg]


There was a carriage coming to pick me up. It was a very aristocratic one, with excessive decoration.
[cpg]


[OnName num="kurto"]
I was nervous.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuika443"]
[OnName num="yuika"]
Nervous?　You're just going back to your parents' house.
[cpg cn=true]


[OnName num="kurto"]
I've been through a lot with my father and brother.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika444"]
[OnName num="yuika"]
'Maybe so, but it's kind of sad that you're nervous about going back to your own home.
[cpg cn=true]


That's for sure. I'm not going to be nervous forever.
[cpg]



[free time=1000]
[BG f="b_12_2.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se000"]
;//【ＳＥ】『馬車移動する』



Me and Yuika were about to head to my parents' house ...... the Lammertz family.
[cpg]


As long as we are bound together as nobles, this kind of thing is necessary.
[cpg]




[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『屋敷＿室内』（昼）******************************************************



But still, I still had a delicate feeling.
[cpg]


I'm not completely at peace with my brother Aamir and my father.
[cpg]


[OnName num="josef"]
I'm not too ...... beautiful, you know. Kurth, how did you manage to win him over?
[cpg cn=true]


[OnName num="kurto"]
No, no,...... well, I think she's beautiful.
[cpg cn=true]


It is helpful to have brother Joseph to intercede at times like this.
[cpg]


I hope the conversation will proceed peacefully.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika445"]
[OnName num="yuika"]
I am Yuhka Hinamiya. I am the head of the Chamber of Commerce.
[cpg cn=true]


[OnName num="emile"]
Nice to meet you at ......."
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『屋敷＿室内』（夕方）******************************************************



From that point on, Yuika was on her feet perfectly.
[cpg]


She kept a certain distance from Emil and father, but was friendly with Joseph.
[cpg]


She also talked well with Mom, after all. From her point of view, she would be my mother-in-law. ......
[cpg]


It's something I can't even imagine. If we have kids, my dad and mom will have grandkids.
[cpg]


I mean, am I a father before that?　Is that even possible ......?
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『屋敷＿室内』（夜）******************************************************



After all that happened, Yuika and I stayed over together.
[cpg]


It had been a long time since I slept over at my parents' house.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
[BGM f="bgm_05"]
;//ブラックアウト



My room after a long time. I guess they had a maid do it, but it was cleaned up nicely.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yuika446"]
[OnName num="yuika"]
Kurth, are you still awake? Are you still awake?
[cpg cn=true]


[OnName num="kurto"]
"Yes, I'm awake. Yeah, I'm up.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika447"]
[OnName num="yuika"]
I'm happy. Not only am I happy that I'm going to be with you.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika448"]
[OnName num="yuika"]
I'm happy that you and your brother are back together again.
[cpg cn=true]


[OnName num="kurto"]
You didn't have to worry about that."
[cpg cn=true]


I said that, but Yuika didn't seem to think so.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuika449"]
[OnName num="yuika"]
Business has the power to change everything. It can be a frightening thing.
[cpg cn=true]


[OnName num="kurto"]
Yuika: ......
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika450"]
[OnName num="yuika"]
But I think we can use that power to our advantage. I feel like we can.
[cpg cn=true]


Yuika has always been a positive person, but she is now more positive than ever.
[cpg]


But she was more positive than ever.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『屋敷＿室内』（昼）******************************************************



By noon the next day, the brothers and Yuika had become good friends.
[cpg]


[OnName num="josef"]
'Come visit me again, just once in a while, okay?
[cpg cn=true]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika451"]
[OnName num="yuika"]
Yuhka said, "Yes, I will. Yes, I will come again.
[cpg cn=true]


To brother Joseph, he is a hoarder,...... and really Yuika is a jovial person, or what can I say?
[cpg]


If I were in the opposite position, it would be the first thing I wouldn't do.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_12_2.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se000"]
;//【ＳＥ】『馬車移動する』



And then we are rocked by the carriage. We returned to town feeling fine.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夕方）******************************************************



[OnName num="kurto"]
I'm sure you've got a lot of work to do after all that time you've taken off.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuika452"]
[OnName num="yuika"]
I'm sure you've got a lot of work to do. It's no use working this late in the evening.
[cpg cn=true]


[OnName num="kurto"]
I guess so. I'd better switch things up.
[cpg cn=true]


I didn't feel like working now.
[cpg]


But more than that, just a little bit more. I wanted to be with Yuika. ......
[cpg]


[OnName num="kurto"]
Hey, Yuika. If you mean it's still a holiday, you know..."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuika453"]
[OnName num="yuika"]
"That's okay. I was next to him yesterday, and he seemed to be in agony."
[cpg cn=true]


They saw right through me. I really can't compete with that.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



I was heading to Yuika's house.
[cpg]


We didn't hesitate to seek each other anymore ......
[cpg]


Thinking back, it took a long time for this to happen.
[cpg]


From here, I wanted to make up for that time.
[cpg]



;//========================================
;//●ＣＧ（主人公に迫るヒロイン）ev_46
;//人物１：ヒロイン２　服装１：裸
;//人物ex：主人公　　　服装ex：裸
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bgm_09"]
;**【ＣＧ】 ev_46_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています

Yuika and I stayed by each other's side for a while.
[cpg]

[OnName num="kurto"]
'...... Yuika, do you have any dreams for the future?
[cpg cn=true]


[VOICE f="Yuika475"]
[OnName num="yuika"]
I think so. I think I'll become the world's best merchant.
[cpg cn=true]


[OnName num="kurto"]
I think I can do it. I think I can do it.
[cpg cn=true]

;**【ＣＧ】 ev_46_a ***********************
[CG id=13 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Yuika476"]
[OnName num="yuika"]
I don't intend to let this end as a dream. With Kurth, we can do anything.
[cpg cn=true]


While saying that, Yuhka turned to me and put her lips on mine.
[cpg]



;//========================================
;//●ＣＧ（キスをする二人。お互いに座っていて、手を繋いでいる）ev_70
;//人物１：ヒロイン２　服装１：裸
;//人物ex：主人公　　　服装ex：裸
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//========================================


;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bgm_10"]
;**【ＣＧ】 ev_70_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


I don't reject it either. I, of course, did not refuse.
[cpg]



[VOICE f="Yuika477"]
[OnName num="yuika"]
"Chuu......, chuu."
[cpg cn=true]


I didn't do anything. I'm not going to be able to do anything about it.
[cpg]



[VOICE f="Yuika478"]
[OnName num="yuika"]
I said, "...... Kurth, I'm sorry, but you're not my everything. I'm sorry, but you're not everything to me.
[cpg cn=true]


I know that somehow. Yuika loves her work.
[cpg]



[VOICE f="Yuika479"]
[OnName num="yuika"]
I still have things I want to do. You'll help me with that, won't you?
[cpg cn=true]


[OnName num="kurto"]
Of course. I won't let anyone get in the way of that.
[cpg cn=true]



[VOICE f="Yuika480"]
[OnName num="yuika"]
Thank you. You're not all of me, but you're half of me.
[cpg cn=true]


[OnName num="kurto"]
You know, like your right-hand man .......
[cpg cn=true]



[VOICE f="Yuika481"]
[OnName num="yuika"]
Ha, ha. I'm not going to use you like an aide.
[cpg cn=true]


 Yuika said that and laughed, but I was fine with that.
[cpg]


The actuality that the actuality is that you can't get a lot of these things.
[cpg]




;//ブラックアウト

[SCENE id=16]
[jump storage="epend.ks" target="*start"]



;//ＥＮＤ　ヒロイン２ルート
;//==============================
