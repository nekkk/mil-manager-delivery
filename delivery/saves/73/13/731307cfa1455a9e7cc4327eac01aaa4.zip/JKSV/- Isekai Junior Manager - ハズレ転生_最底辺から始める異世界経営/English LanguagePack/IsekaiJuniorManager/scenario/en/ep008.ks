
*start


;#################################################
*Ep008|New products with resin
;#################################################


[stflag Tai_sil = 0]

[if exp={getFlagValue("Tai_sil") == 0 }]
[stflag Tai_sil = 1000]
[endif]



[SCENE id=8]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



Holiday. I was facing something.
[cpg]

The first prototype rubber band. I told Mr. Edito about the features and he finished it up with something that could be used properly.
[cpg]

[OnName num="kurto"]
It works. ......
[cpg cn=true]



[BG f="b_11_2.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



After going through several prototypes, I adjusted the thickness and size of the ......
[cpg]


After a lot of trial and error, the finished product was ready.
[cpg]





[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



Then came the day of the sale.
[cpg]


Since we had advertised it extensively, quite a few people came to the store on the first day of sales.
[cpg]


Although there were many male customers to begin with, the sales were much better than we had imagined.
[cpg]


[OnName num="kurto"]
The ...... sold out immediately. This is a waste of time for this store alone.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Bianca230"]
[OnName num="bianca"]
I agree. What do you think, Catherina?
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Catalina135"]
[OnName num="catalina"]
I agree. But I don't think Kurth is a business owner.
[cpg cn=true]


Arma-san chuckles at such talk.
[cpg]


In the backyard of the restaurant. Both Katharina and Arma come here whenever they have free time.
[cpg]


It seemed to be a hangout for everyone.
[cpg]


Or does it mean that I'm collecting them?
[cpg]


I can't really feel it. But I guess that's how well it's going.
[cpg]


[free time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Alma024"]
[OnName num="alma"]
But I agree with the idea of opening a second store. Kurth, you're not ready to settle down yet.
[cpg cn=true]


[OnName num="kurto"]
I guess so. I guess so. It's a business that no one can imitate.
[cpg cn=true]


Some of my inventions are not similar without my skills.
[cpg]


[OnName num="kurto"]
But when it comes to hiring employees, the pressure is on.
[cpg cn=true]


I would have to take on the responsibility of being a manager rather than a mere merchant. Will I be able to do it?
[cpg]


[free time=1000]

While I was thinking about it, a customer came up to me and asked if I would open a second store.
[cpg]


[OnName num="male_customer"]
I was thinking, "This is pretty far away from here, isn't it? Aren't you planning to open a store in a more urban area?"
[cpg cn=true]


[OnName num="kurto"]
'Yes, we are. ......
[cpg cn=true]


If this happens, I have no choice but to do it. I decided to take the plunge.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



[OnName num="kurto"]
I never ...... thought I'd be in this position."
[cpg cn=true]


I never thought I would be in this position.
[cpg]


I'm going to be a manager," he said. I thought I had some understanding of it when Edito and Katharina were helping me, but ......
[cpg]


Somewhere along the way, I was reminded that I wasn't prepared enough.
[cpg]


Finally, they are trying to hire someone. It's different from making a request on an equal footing.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kurto"]
'If you're a ...... aristocrat like Arma, do you know what it feels like to be above people?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Alma025"]
[OnName num="alma"]
I think you do. I think you were an aristocrat, too.
[cpg cn=true]


[OnName num="kurto"]
I think you were an aristocrat, too.
[cpg cn=true]


I don't know if I can say that. It means that he was not aware that he would live as an aristocrat in the future.
[cpg]


[OnName num="kurto"]
But now I understand. I am not alone.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Alma026"]
[OnName num="alma"]
That's true, but it's not only a good thing.
[cpg cn=true]


I guess he was giving me advice from his position as an aristocrat. I will take it in stride.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

I went with Arma to see the planned site of the second store.
[cpg]


Even though it is in the city, it is not the kind of place you can open a store on a main street.
[cpg]


It would be a little secluded. But a place where people would come if they knew we were selling something interesting.
[cpg]


[OnName num="kurto"]
I think it's ...... good. What do you think Bianca?"
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Bianca231"]
[OnName num="bianca"]
Yes, but once we decide to open a restaurant, we also have to hire people......There is also the question of who will be the owner of the second store."
[cpg cn=true]


[OnName num="kurto"]
Well,...... Katharina would probably do it if you asked her, but she's a woman.
[cpg cn=true]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



It had been a long time since I had had the feeling that I missed the holidays.
[cpg]


Come to think of it, in order to get this kind of feeling, you have to be working properly.
[cpg]


[OnName num="kurto"]
"Sooner or later, you're going to start dealing with other people's holidays too. ......
[cpg cn=true]



That's not all. It's about how much of the money you make goes into your paycheck.
[cpg]

How much is the hourly wage in this world in general? Not only are those things not specified, but of course there are no statistics.
[cpg]

So, I don't think it's a question of not caring.
[cpg]

After all, even though we just opened the restaurant, we can't attract people unless we pay them well, and we don't want them to work unscrupulously.
[cpg]

On the other hand, it's not like we can afford it either. ......
[cpg]


When I think about it, I feel a shudder. I feel as if I want to scream out something.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kurto"]
It's kind of a big responsibility, isn't it?
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca232"]
[OnName num="bianca"]
'Yes, it is. But I'm sure the master will be fine.
[cpg cn=true]


I was grateful that I was not alone in these situations.
[cpg]


Bianca, Katharina, Edith, and even Arma came to help me.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



The lovely days pass by. The days were so fast-paced that I felt like I would be left behind if I didn't pay attention.
[cpg]

[OnName num="shop_owner"]
I'll do my best to sell them," he said. I'm a fan of your store, after all.
[cpg cn=true]

One of my regular customers ran for the position of owner of the second store, so I decided to leave it to him.
[cpg]

This is probably the most common form of goodwill sharing.
[cpg]

If there is no other place to sell the products, it may be because they are fans of the store.
[cpg]

[OnName num="kurto"]
He said, "Yeah, I'll do my best. Don't get too worked up, but do your best.
[cpg cn=true]

[OnName num="shop_owner"]
Yes!
[cpg cn=true]

After much deliberation, I decided to set the salary a little higher than the average salary in this world.
[cpg]

It's partly because it's such an uphill climb, but I still don't think it's a job that is totally guilt-free.
[cpg]

I decided to take that over the risk of quitting and not being able to keep the store open.
[cpg]

[OnName num="kurto"]
Then, it's time to open the doors.
[cpg cn=true]


On the day the second store was to open, customers were still gathering.
[cpg]


Of course, things are things, so people don't gather just because they are unusual. ......
[cpg]


On the other hand, there were not many people who were just looking for a place to chill out. It was a place where people who were interested would sneak in.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夕方）******************************************************


I have heard that the secret of management is simply not to overlook the trend of profit.
[cpg]

Of course, I'm not the manager I once aspired to be in the world of management, it's really just what I've heard. ......
[cpg]

I'm going to be spending more time dealing with numbers than ever before.
[cpg]

Which ones will sell, what time of day, which store will sell more ......
[cpg]


I hired a clerk for the main store, which I usually set up, because I couldn't have turned it around on my own.
[cpg]


Before I knew it, I had become a manager. Or rather, I should say that I had no choice but to become one.
[cpg]


No, it is better to put it bluntly here.
[cpg]


In another world, I will be a manager. No one would tell me what to do.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



And it's closing time.
[cpg]


[OnName num="kurto"]
"......?"
[cpg cn=true]


I saw a figure in the distance. It was too dark to see the face clearly, but it looked familiar.
[cpg]


Or rather, that distinctive attire. ......
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



It looked familiar. The next day, while I was working at the main store, I heard a voice saying, "It's been a long time.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yuika022"]
[OnName num="yuika"]
"Long time no see. Looks like you've been working hard.
[cpg cn=true]


[OnName num="kurto"]
Ah, ...... Yuika-san."
[cpg cn=true]


Yuika was visiting. I didn't expect her to come to me.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika023"]
[OnName num="yuika"]
I am glad to hear that you are doing well. I was worried that you might be working too hard, but from the look on your face, it seems that you are doing things at your own pace.
[cpg cn=true]


[OnName num="kurto"]
It's been a long time. It's been a while since you introduced me to Mr. Edith.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika024"]
[OnName num="yuika"]
I've been working a little too hard, but I can see by your face that you're taking it at your own pace. Yes, it has been.
[cpg cn=true]


The merchant who unites the Chamber of Commerce, Ms. Yuika Hinamiya. The fact that she came to me means that she caught my eye, right?
[cpg]


But if you're doing business around here, you're going to have to be aware of me, even if you don't want to be.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuika025"]
[OnName num="yuika"]
I have heard rumors about you. You are a merchant and an inventor.
[cpg cn=true]


Yuika-san doesn't know what he wants from me.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Yuika026"]
[OnName num="yuika"]
'It's an idea like none of your products are from this world. I'd like to take a peek inside your head to see where you get those ideas."
[cpg cn=true]


She's pretty close to being right.
[cpg]


I was simply using knowledge from my time in the original world. If I say it's not from this world, it is.
[cpg]


[OnName num="kurto"]
"Well, ......, since we're on the subject, I can explain it all to you ......."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Yuika027"]
[OnName num="yuika"]
Explain?　What are you talking about?
[cpg cn=true]


[OnName num="kurto"]
Yeah, actually.
[cpg cn=true]


I decided to tell them everything there.
[cpg]


I told them that I had lived in another world in a previous life. And that I was selling something from that time in this world.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika028"]
[OnName num="yuika"]
...... Heh."
[cpg cn=true]


Yuika-san listened to me without doubting me, and she was right on the mark.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuika029"]
[OnName num="yuika"]
It's getting more and more interesting. It seems not many people in this country believe in the word reincarnation.
[cpg cn=true]


[OnName num="kurto"]
I understand ....... It's the idea that you don't go to heaven or hell after you die.
[cpg cn=true]


Youka, you seem to be from a different country from ours.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika030"]
[OnName num="yuika"]
In my country's religion, the idea is that there is such a thing as reincarnation. Well, I'm not that religious.
[cpg cn=true]


It's just like Japan. Or is it Japan?
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuika031"]
[OnName num="yuika"]
Your story is interesting. When you say it like that, I guess it all makes sense.
[cpg cn=true]


Yuika seemed to be very curious. She was more interested in my story than I expected.
[cpg]


[OnName num="kurto"]
I'm sorry, I'm the only one talking. Yuika, you were on an errand, weren't you?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika032"]
[OnName num="yuika"]
I'm sorry, I'm the only one who talked about it. I know I'm getting off topic, but ...... would you like to sell your products in another country?
[cpg cn=true]


[OnName num="kurto"]
What kind of ...... is that?
[cpg cn=true]


I wasn't sure and asked back. Yuika-san smiled wryly.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Yuika033"]
[OnName num="yuika"]
I mean, why don't you join forces with me? I think you have nothing to lose by working with me here.
[cpg cn=true]


[OnName num="kurto"]
I'm not sure if ...... is a good idea. For a fledgling merchant like me."
[cpg cn=true]


Yuika shook her head. You mean you don't care about my career?
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika034"]
[OnName num="yuika"]
Of course. I'd rather support you because you're just starting out.
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



[OnName num="kurto"]
......That's what happened to me.
[cpg cn=true]



[FACE method="bow_1" pos="2/5"]
[VOICE f="Alma027"]
[OnName num="alma"]
I know that too, Mr. Yuika. I also know Yuika,......, she's a very good player.
[cpg cn=true]


[OnName num="kurto"]
I'm sure you're right. I don't have confidence in my ability to compete with her as an equal.
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Bianca233"]
[OnName num="bianca"]
What are you talking about? What are you talking about? - "Master, there is no need to be anxious.
[cpg cn=true]


Surely, everything is on the upswing. I would say that I have nothing to be anxious about.
[cpg]


But she's really unique. Not to say that she's intimidating, but ......
[cpg]


I feel like I get weirdly nervous. I guess I'm just being that way on my own.
[cpg]


[free time=1000]
[BG f="b_11_3.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



After that, there were times when Yuika-san would take time out of her busy schedule to meet with me.
[cpg]

I hear many interesting things from Yuika-san.
[cpg]

He is indeed a skilled businessman, and he has a different perspective than I do.
[cpg]

Yuika-san suggested that there was a possibility that the business would become too prosperous in the future and be subject to crackdowns by government officials.
[cpg]

I thought to myself, "I have to pay attention to such things when I run a business. ......
[cpg]

Now I was going to go as far as I could go.
[cpg]

Besides, I have to make the products that Yuika asked me to make.
[cpg]

I had to be careful about what the government officials would think, but that was secondary.
[cpg]

[FADEOUTBGM]
[window target=false]
[BG f="b_11_4.ui" time=1000]
[WAIT time=2000]

[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yuika035"]
[OnName num="yuika"]
Hey there. Thanks for staying up late.
[cpg cn=true]


[OnName num="kurto"]
Ah, Yuika-san ......, such a coincidence at this late hour of the night, isn't it?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sYuika001"]
[OnName num="yuika"]
I'd like to continue our conversation from the other day, but that was secondary. I'd like to continue the conversation we had the other day.
[cpg cn=true]


[OnName num="kurto"]
Yeah, where should we talk?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuika039"]
[OnName num="yuika"]
I'm staying near here. Can you follow me?
[cpg cn=true]


[SE f="se014"]
;//【ＳＥ】『歩く』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト


It was somewhat strange to be invited to a room at the ...... inn.
[cpg]


It is not that Yuika pulled my hand. But I couldn't refuse.
[cpg]



;//========================================
;//●ＣＧ（主人公に接近して座っているヒロイン）ev_12
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：宿＿室内
;//時間　：夜
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bgm_09"]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sYuika002"]
[OnName num="yuika"]
You are an interesting guy. You are my type.
[cpg cn=true]


And what was spoken was not limited to business.
[cpg]

[OnName num="kurto"]
He said, "I'm close to ......."
[cpg cn=true]


;**【ＣＧ】 ev_12_a ***********************
[CG id=4 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sYuika003"]
[OnName num="yuika"]
Oops. I wonder if you have a personality that doesn't appreciate situations like this."
[cpg cn=true]


She looked at that, too, as if it were a surprise.
[cpg]

I feel like I'm going to be pressured to laugh at her.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（朝）******************************************************


It's getting really, really outrageous. It's like she's strangely popular.
[cpg]


Yesterday, Bianca was suspicious that I was coming home late.
[cpg]


It's not that Bianca doesn't have feelings for me. I already know that.
[cpg]


But I also have to keep in touch with Yooka. ......
[cpg]


[OnName num="kurto"]
Yooka-san's skill, she said, is translation skill.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Bianca236"]
[OnName num="bianca"]
'That's ...... a terrific skill. Isn't he the strongest merchant?"
[cpg cn=true]


[OnName num="kurto"]
I know, right? I would like to have it too, but then I would lose the Mischief-making Magic I have now.
[cpg cn=true]


She was told that she had translation skills, plus a love of sightseeing, which led her to travel around the country.
[cpg]


[OnName num="kurto"]
I can't imagine ...... that my goods would be sold in a foreign country."
[cpg cn=true]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

From there, business continued to go well. I'm still a bit vain about it, though, thanks to everyone's cooperation.
[cpg]

I think I might have a pretty good business acumen .......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]



[if exp={getFlagValue("Tai_sil") == 1000 }]
[FG f="ci_money.ui" method="window_in_1000" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 400 }]
[FG f="ci_money.ui" method="window_in_400" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]



;//ここから、ウィンドウの枠を別の形にするか、色を変えてください


[SE f="se011"]
;//【ＳＥ】『お金増減』


[if exp={getFlagValue("Tai_sil") == 1000 }]
[FG f="ci_money.ui" method="cal_p1000_1000" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 400 }]
[FG f="ci_money.ui" method="cal_p1000_400" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]

[window target=true]

[stflag Tai_sil = 1000]

I got 1000sil!
[cpg]





;//ウィンドウの枠を元に戻してください



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（朝）******************************************************



I went to the store before it opened, and there was Mr. Edith.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Edith058"]
[OnName num="edith"]
He said, "Good morning ...... Mr. Kurth."
[cpg cn=true]


[OnName num="kurto"]
'Oh, hi. I see you've come to deliver the goods.
[cpg cn=true]


Ms. Edith nodded. She, too, seemed pleased to see her products being distributed around the world.
[cpg]

[free time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Alma029"]
[OnName num="alma"]
Good morning,......, I see you're here too, Mr. Edith.
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Edith059"]
[OnName num="edith"]
Well, hello ......."
[cpg cn=true]


Edith and Arma are a little awkward.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



Before I knew it, my shop, or the business I dealt with, had really grown.
[cpg]


The first thing that comes to mind is that the two are very close. Of course, the power relations won't be overturned so easily, but ......
[cpg]


Now, the Lammertz family might accept me. I don't think I'd go back, though.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sAlma001"]
;//[VOICE f="Alma030"]
[OnName num="alma"]
Good work. How about a lunch break?"
[cpg cn=true]


[OnName num="kurto"]
Oh, thank you very much. ......
[cpg cn=true]


Arma told me to go back to the backyard.
[cpg]


[free time=1000]


Basically, Bianca and I take turns tending to the store.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Edith060"]
[OnName num="edith"]
'Thanks for your help .......'
[cpg cn=true]


But there are quite a few more people helping out.
[cpg]


I'm starting to think that this situation could be called a harem.
[cpg]


And a harem is something that doesn't last forever.
[cpg]


In this country, polygamy is not allowed. ......
[cpg]

[free time=1000]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="4/5" time=800]

[VOICE f="Bianca238"]
[OnName num="bianca"]
'So you are not thinking of getting married, Master?'
[cpg cn=true]


[OnName num="kurto"]
"Nah. ......"
[cpg cn=true]


Bianca, as if seeing through my thoughts, says, "No, I don't have a girlfriend yet.
[cpg]


[OnName num="kurto"]
I'm not even sure I have a girlfriend yet.
[cpg cn=true]


Bianca's topic of conversation was followed by Arma's and Edith's responses.
[cpg]


[FACE method="shock_5" pos="2/5"]
[VOICE f="Edith061"]
[OnName num="edith"]
I'm not married yet," Bianca said.
[cpg cn=true]


Edith was aware of me, but seemed to think it was too early to tell.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Alma031"]
[OnName num="alma"]
I think love between different statuses can be very exciting," he said.
[cpg cn=true]


And Arma-san is imagining and dreaming of being married to me.
[cpg]


This is really nothing but a harem. ......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

So, what do we do from here? It's still too early to get defensive.
[cpg]

I feel like there are still a lot of things I can try. I'll consider all possibilities and decide on a course of action.
[cpg]


[if exp={getFlagValue("Tai_sil") == 2000 }]
[FG f="ci_money.ui" method="window_in_2000" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 1400 }]
[FG f="ci_money.ui" method="window_in_1400" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]


;//エロ経営用特殊選択肢は６択で起動。３ヶ所を選ぶ
;//■選択肢
;//[SetSelGra 2]

[switch]
[case "Make and distribute ads "FREE"."]
	[swap]
	[jump target="*select03_1"]
[case "Buy a present for Bianca "500sil"."]
	[swap]
	[jump target="*select03_2"]
[case "Buy a gift for Katharina "500sil"."]
	[swap]
	[jump target="*select03_3"]
[endswitch]


1, Make and distribute ads (no sil consumption)
;//※アイコンは主人公の店の背景の画像
2, Buy a present for Bianca (500sil consumed)
;//※アイコンはev_13の画像
3, Buy a present for Katharina (500sil consumed)
;//※アイコンはev_14の画像

;//==============================
;//１、広告を作って配る（sil消費なし）
*select03_1|New products with resin



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************

Remembering my experience in my previous life, I decided to make an advertisement.
[cpg]

It's not a business I can do very openly. So, I'm going to hand them out in the middle of the night: ......
[cpg]

[OnName num="kurto"]
"Nice to meet you, ......."
[cpg cn=true]

In other words, it's like handing out tissues. I thought Bianca and I could do it together, but it's not easy ......
[cpg]

We had neither the custom of handing out ads in this world nor the custom of receiving them.
[cpg]

It didn't go over well and ended up not being very effective.
[cpg]




[window target=false]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************

I thought it would be better to do it during the day when I could see their faces, but it still didn't work.
[cpg]

I wondered if it would be better to have them posted on the walls of some inns.
[cpg]

To begin with, the technology of printing had not yet penetrated the market, and it was not cost-effective.
[cpg]

I guess there must be a strategy that fits the cultural level.
[cpg]


;//ブラックアウト

Other than that, things are generally going well. It is important to try various things and think about which ones don't work.
[cpg]

With that in mind, we went through a trial-and-error process.
[cpg]


[jump target="*select03_4"]
;//==============================
;//２、ビアンカにプレゼントを買う（500sil消費）
*select03_2|New product using resin



We'll spend 500 sil!
[cpg]

[window target=false]



[SE f="se011"]
;//【ＳＥ】『お金増減』


[if exp={getFlagValue("Tai_sil") == 2000 }]
[FG f="ci_money.ui" method="cal_m500_2000" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 1400 }]
[FG f="ci_money.ui" method="cal_m500_1400" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]


[stflag Tai_sil = -500]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



Mr. Edith went back to his workshop. Arma went back to her house, and it was just me and Bianca. ......
[cpg]


It was not like that.
[cpg]


;//[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Catalina136"]
[OnName num="catalina"]
I'm sure Arma and Edith were here a while ago, too.　They're not busy, are they?"
[cpg cn=true]


[OnName num="kurto"]
......"
[cpg cn=true]


I was about to say, "Katharina, too," but decided not to.
[cpg]


I also think that not everyone has the time.
[cpg]


He's taking time out for me. It makes me feel kind of tantalized.
[cpg]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Catalina137"]
[OnName num="catalina"]
So, you're working on a new product, right?
[cpg cn=true]


[OnName num="kurto"]
Yes, I am. I can come up with any number of things made of resin.
[cpg cn=true]

;//[free time=1000]
;//[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
;//[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="4/5" time=800]
[FACE method="shake_7" pos="2/5"]
[VOICE f="sCatalina023"]
[OnName num="catalina"]
......That's a lot of confidence.
[cpg cn=true]

But it wasn't a baseless confidence. I was going to go as far as I could go.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夕方）******************************************************

But now I am not alone. Thanks to teaming up with Yuika, that went smoothly as well.
[cpg]

Yuika's memory is so good that I think she has a grasp of the flow of things.
[cpg]

Or rather, I thought it was amazing that she never ran out of things to be interested in, not her memory.
[cpg]

I guess I should be the same way. Management is a very deep subject.
[cpg]

How to be interested in it. I think that's what it's all about.
[cpg]

For example, farmers say that they can't do business unless they can see their vegetables and fruits as money.
[cpg]

I could say that converting them into money does not mean that they are indifferent to things, but rather that they are interested in them.
[cpg]


[free time=1000]
;//ブラックアウト


When I went out on the street, other people's business looked different from before.
[cpg]

It was kind of endearing to think that everything is made of interest.
[cpg]

With that thought in mind, I reached for ...... one item.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[SE f="se003"]
;//【ＳＥ】『ドアノック』


Then I was on my way to Bianca's room.
[cpg]



[SE f="se002"]
;//【ＳＥ】『ドア開く』

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1100]

[VOICE f="Bianca240"]
[OnName num="bianca"]
I was thinking, "Yes, I'd like to buy something. Can I help you?"
[cpg cn=true]


[OnName num="kurto"]
Bianca. It's a present.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="sBianca014"]
[OnName num="bianca"]
What?
[cpg cn=true]


[OnName num="kurto"]
It's a hair clip. I thought it would look good on you.
[cpg cn=true]


He had been thinking about Bianca, so he decided to buy her a present.
[cpg]

I wondered if Bianca would be happy with it, but she accepted it happily.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sBianca015"]
[OnName num="bianca"]
She said, "Thank you. But you shouldn't have bothered about me."
[cpg cn=true]


Even at a time like this, she tells me not to care.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sBianca016"]
[OnName num="bianca"]
'Because my happiness is the master's happiness.
[cpg cn=true]


She was kind of cute and I was feeling irresistible.
[cpg]

;//========================================
;//●ＣＧ（主人公に迫られているヒロイン）ev_13
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン４の部屋
;//時間　：夜
;//========================================
;//[FADEOUTBGM]
[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//[BGM f="bgm_10"]
;**【ＣＧ】 ev_13_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sBianca017"]
[OnName num="bianca"]
I was just so cute and I couldn't stop myself.　Hey, hey!"
[cpg cn=true]


I found myself hugging her.
[cpg]

[VOICE f="sBianca018"]
[OnName num="bianca"]
No, no, no, I haven't taken a bath yet.
[cpg cn=true]


I apologized and pulled away, thinking, "Is that what you're worried about ......?
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト



;//ヒロイン４変数+1
[stflag Cha_Flg4 = 1]

[jump target="*select03_4"]

;//==============================
;//３、カタリーナにプレゼントを買う（500sil消費）
*select03_3|New products using resin



Consume 500sil!
[cpg]

[window target=false]



[SE f="se011"]
;//【ＳＥ】『お金増減』


[if exp={getFlagValue("Tai_sil") == 2000 }]
[FG f="ci_money.ui" method="cal_m500_2000" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]
[if exp={getFlagValue("Tai_sil") == 1400 }]
[FG f="ci_money.ui" method="cal_m500_1400" layer=20 pos="4/7" time=1]
[WAIT time=1000]
[endif]


[stflag Tai_sil = -500]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************


All I could think about was Katharina.
[cpg]

How is she doing now?　She was my first fan, and I was strangely curious about her.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落』（夜）******************************************************



[FACE method="shake_7" pos="2/3"]
[VOICE f="Catalina138"]
[OnName num="catalina"]
'I wonder ...... at such a late hour of the night.'
[cpg cn=true]


Katharina looked sleepy.
[cpg]


[OnName num="kurto"]
'Excuse me. I was just trying to get you to take a look at our new merchandise."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sCatalina011"]
[OnName num="catalina"]
I'm sure you don't need ...... me."
[cpg cn=true]


She looked sleepy. Perhaps because she is half plant, she has difficulty being active at night.
[cpg]

[OnName num="kurto"]
But you're interested, right?"
[cpg cn=true]



[FACE method="bow_7" pos="2/3"]
[VOICE f="Catalina140"]
[OnName num="catalina"]
"......, sure. Come on up."
[cpg cn=true]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se002"]
;//【ＳＥ】『ドア開ける』

[FACE method="change_1" pos="2/3"]

When I showed Katharina some of the new products, her eyes lit up again.
[cpg]

[FACE method="change_2" pos="2/3"]

It was nice to see such an obvious interest.
[cpg]

Somewhere along the way, I found myself being attracted to her.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト



;//ヒロイン５変数+1
[stflag Cha_Flg5 = 1]


;//==============================

*select03_4|New products using resin


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（朝）******************************************************



Such things happen and ...... happy days continue.
[cpg]

The owner of the second store I hired also continues to be friendly.
[cpg]

[OnName num="shop_owner"]
He says, "You want me to hire an employee over here ......?　Can I do that on my own?"
[cpg cn=true]

[OnName num="kurto"]
I don't want to do it on my own. I want to leave it to you.
[cpg cn=true]

Some of the stores could not make it if they did not have a division of labor like this.
[cpg]


[OnName num="kurto"]
I'm also in charge of product development, so I want to make it work as well as possible.
[cpg cn=true]


[OnName num="shop_owner"]
"Wow, I understand. ...... that's a lot of pressure."
[cpg cn=true]

I think it's the same kind of pressure I used to feel.
[cpg]


[OnName num="kurto"]
I'm sure it's the same pressure I used to feel. There's a lot to be gained from standing on top of others.
[cpg cn=true]

I wonder if I am stating the obvious ......, but I guess it's something you don't realize.
[cpg]



[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************

Back at the store, I'm still staring at the numbers.
[cpg]

At this cultural level, machines are limited.
[cpg]

Even getting a graph out is a challenge. The only way is to make it yourself.
[cpg]


;//[window target=false]
;//[BG f="b_07_3.ui" time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



There is no end to the amount of things you can think of. I have to come to an agreement somewhere.
[cpg]

I need to meet Yuika more often.
[cpg]

I think I can learn a lot from her. I'm sure she's a much better manager than I am, and I'm sure she's working hard.
[cpg]

It was only after I started running a business that I realized how important it is to meet people.
[cpg]



;//ブラックアウト
[window target=false]
[BG f="b_11_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Anyway, I am fulfilled. There is no such thing as a wasted day.
[cpg]

I really wished that days like this could go on forever.
[cpg]

Still, change seems to happen whether we want it to or not.
[cpg]


[jump storage="ep009.ks" target="*start"]

;//=============================================================================
