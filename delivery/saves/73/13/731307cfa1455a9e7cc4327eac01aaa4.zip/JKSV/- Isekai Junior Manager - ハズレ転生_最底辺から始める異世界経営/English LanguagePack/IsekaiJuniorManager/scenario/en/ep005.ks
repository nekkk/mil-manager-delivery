
*start

;#################################################
*Ep005|The use of Mischief-making Magic
;#################################################

[SCENE id=5]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_08"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン』（朝）******************************************************



Katharina led me to a dungeon.
[cpg]


No, a dungeon. There are usually demons, tentacle creatures, and the like wandering around.
[cpg]


[OnName num="kurto"]
How did this happen? ......
[cpg cn=true]



[FACE method="bow_2" pos="2/5"]
[VOICE f="Bianca150"]
[OnName num="bianca"]
It's all right!　I'm good at gathering and Katharina-sama will escort me.
[cpg cn=true]


Ms. Katharina knows her magic. So even though she can be a bit reckless, ......
[cpg]


[OnName num="kurto"]
I can't even handle a sword.
[cpg cn=true]


While saying that, I held a rusty sword lying around in my hand.
[cpg]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Catalina083"]
[OnName num="catalina"]
It's all for a new product, isn't it?　Let's go!
[cpg cn=true]


Katharina-san seemed to rather want to fight the demons.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



From there, the demons, albeit small, were blocking the way ......
[cpg]


I defeated them together with Katharina-san, or rather, I left it mostly up to her.
[cpg]



[SE f="se000"]
;//【ＳＥ】『火が燃えさかる音』



Surprisingly, she handled fire magic. I wondered if she ever thought about burning herself or something.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ダンジョン』（朝）******************************************************



[OnName num="kurto"]
I wondered if she was thinking of burning herself or not.
[cpg cn=true]


[VOICE f="Bianca151"]
[OnName num="bianca"]
I hear they live quite a long time, if not a while.
[cpg cn=true]


[OnName num="kurto"]
Can the semen of a tentacled creature impregnate a human?"
[cpg cn=true]

[FACE method="shake_7" pos="2/5"]
Bianca shakes her head. Bianca shakes her head. But then, ......
[cpg]


[OnName num="kurto"]
I'll take it home with me, just in case. I'll take it home with me, just in case."
[cpg cn=true]


I put some in the bottle that was supposed to hold the magic stone.
[cpg]


This might also be useful for something. ......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『鉱脈』（朝）******************************************************



[FACE method="bow_1" pos="4/5"]
[VOICE f="Catalina084"]
[OnName num="catalina"]
There it is. It's a vein of magic stone.
[cpg cn=true]


[OnName num="kurto"]
'Oh, it doesn't look like we're going to get too much of this ...... though.'
[cpg cn=true]


It's a series of translucent stones. So we're going to turn this into an invention.
[cpg]


[OnName num="kurto"]
How do we collect them, ...... Bianca, do you know?"
[cpg cn=true]


She has the skill of collecting. She should be in charge of this kind of thing.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Bianca152"]
[OnName num="bianca"]
She's got the skills to do this. I think I can do it."
[cpg cn=true]


I'm so glad that Bianca was the first person to help me.
[cpg]


Without her, I might not have been able to do anything. ......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se019"]
;//【ＳＥ】『つるはしで削る』



I collected it, brought it back home, and studied it further.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************




All these efforts paid off, and this is the result.
[cpg]


[OnName num="kurto"]
Look at this. Bianca."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Bianca153"]
[OnName num="bianca"]
...... a small cloth bag, right? What's in it?
[cpg cn=true]


[OnName num="kurto"]
It's got a magic stone with my skills in it. It's wrapped in paper.
[cpg cn=true]


On the paper is the formula that Katharina wrote for me.
[cpg]


[OnName num="kurto"]
It's not the vibration magic, of course, but the one that makes the wind blow up your skirt.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca154"]
[OnName num="bianca"]
;//「でも、それって……悪用されるって話じゃなかったでしたっけ」
But I thought you said that would be ...... abused.
[cpg cn=true]


[OnName num="kurto"]
"Of course, it's a tool to make someone's skirt flap, but this is different. But this is different.
[cpg cn=true]


It's not about a specific person. It has to be someone specific, i.e., ......
[cpg]


[OnName num="kurto"]
I walk around with it on, and I get a glimpse of it about once a day.
[cpg cn=true]


I said proudly, but Bianca looked taken aback.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca155"]
[OnName num="bianca"]
How did you come up with this idea? I think Master is a genius after all."
[cpg cn=true]


And then she smiled. What kind of smile is that?
[cpg]


[OnName num="kurto"]
'I'm going to go to town with it, just to see how it works.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca156"]
[OnName num="bianca"]
I'm going to try it out and go to town with it. I'm off today, too, so I'll join you at .......
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



[SE f="se014"]
;//【ＳＥ】『歩く』



I'll walk around town. I will walk around the city to see if the amulet is effective.
[cpg]


I think Katharina's knowledge is real, so I don't doubt that part. But ......
[cpg]


And it's no good if you're punching someone you don't want to see.
[cpg]



[OnName num="kurto"]
Well, since Mischief-making Magic comes from the desire to be naughty, I don't see the problem there. ......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Bianca157"]
[OnName num="bianca"]
What?　What is it?
[cpg cn=true]


[OnName num="kurto"]
No, I'm just talking to myself. I'm talking to myself.
[cpg cn=true]


The first thing to do is to make sure that when you reincarnate, you are harboring a feeling of jealousy, and that's why you have such a skill.
[cpg]


Thinking that way, there is a possibility that I can't flip up the skirt of the person I don't want to see. When I think about it.
[cpg]


[free time=1000]

[SE f="se008"]
;//【ＳＥ】『風』
[WAIT time=1100]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Alma010"]
[OnName num="alma"]
Kyah!"
[cpg cn=true]


The skirt of a woman who looked like an elf fluttered up.
[cpg]


I couldn't see her face well from behind, but I think she was cute.
[cpg]

[free time=1000]

[OnName num="kurto"]
"I've seen this woman's back somewhere before.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Bianca158"]
[OnName num="bianca"]
Is that the effect of the new product?
[cpg cn=true]


[OnName num="kurto"]
I'll try more before I sell them, but go ahead. I'll sell them after I try more, but I think I can go for it.
[cpg cn=true]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



And so I began to put the new product on the shelf. I decided to name it simply "amulet.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夕方）******************************************************



This amulet, too, did not sell well at first, but slowly its reputation spread.
[cpg]


If a girl saw a pantie, she would think it was thanks to the amulet, and if she didn't, it was nothing to be discouraged about.
[cpg]


And the biggest thing is that the effect of the magic stone doesn't last forever. This was my idea.
[cpg]


I had it made to order so that the effect would be as short but definite as possible.
[cpg]


Thanks to this, there are repeaters. The effect was as expected.
[cpg]




;//ブラックアウト
[window target=false]
[BG f="b_08_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



Basically, I didn't have a store. I sell at stalls.
[cpg]


But there are people who visit my house and buy directly from me.
[cpg]


With this kind of sales, I'm sure I'll be able to make .......
[cpg]


[OnName num="kurto"]
Bianca. You can stop working at the bar now.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Bianca159"]
[OnName num="bianca"]
'Yes, I do. I want to help the master."
[cpg cn=true]


I didn't mean it that way,...... but it would save Bianca from having to work all the time.
[cpg]


[OnName num="kurto"]
'Okay, we'll have a celebration next time.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca160"]
[OnName num="bianca"]
"Hmmm. That sounds good."
[cpg cn=true]


I'm just barely getting by, but I'm getting by. This realization helped me to grow little by little.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



The days passed by at a dizzying pace. I think I have at least taken the first step toward becoming a big businessman.
[cpg]


I still have ideas. I still have a lot of ideas and a lot of things I want to do.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



[OnName num="kurto"]
......"
[cpg cn=true]


Still, making things is difficult.
[cpg]


The limit of handmade was about to be reached.
[cpg]

[FACE method="change_1" pos="2/3"]


Bianca and I couldn't handle it on our own. We had reached that point.
[cpg]


[OnName num="kurto"]
We were getting a little out of our depth. I could have made something else.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca161"]
[OnName num="bianca"]
I don't know the world in which the master once lived,......, but there must have been many things.
[cpg cn=true]


I think back. The machine is more sturdy to begin with.
[cpg]

Can we go any further without changing the material?
[cpg]


[OnName num="kurto"]
I'd like at least one more person to help us out around here.
[cpg cn=true]


Bianca nodded. We can't make the more difficult shapes from here on out on our own.
[cpg]


Blacksmith, artisan. Those words popped into my head.
[cpg]


A short distance from the town where we usually set up our stall, there should be a dwarven settlement.
[cpg]


I have heard that blacksmithing is very popular there.
[cpg]



;//背景と別の場所なので、上下に黒帯を入れるなどしてください

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


So we decided to go around there steadily.
[cpg]


[OnName num="kurto"]
How about ......?
[cpg cn=true]


[OnName num="blacksmith"]
"Interesting blueprints. I've never seen this vessel before."
[cpg cn=true]


The craftsman seems to have a twinkle in his eye.
[cpg]


I guess it is interesting to make a shape that has never been seen before.
[cpg]


[OnName num="blacksmith"]
So, what are you going to use it for? What goes in this cavity here?
[cpg cn=true]


[OnName num="kurto"]
Yes, actually, it's .......
[cpg cn=true]


There was no point in hiding things here. It would be a problem if they made the product without telling us what it was to be used for and then got into trouble later.
[cpg]


;//[lbox off]


;//ブラックアウト

Negotiations were difficult. Even if they were interested in the shape, they were wary because the key use of the product was something that had never existed in this world before.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



[VOICE f="Bianca162"]
[OnName num="bianca"]
...... sounds difficult, doesn't it?
[cpg cn=true]


[OnName num="kurto"]
Oh. After all, there are a lot of stubborn or ...... prideful people out there.
[cpg cn=true]


It's not a bad thing, or rather a good thing, I suppose.
[cpg]


But for me, it became a big barrier.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夕方）******************************************************



I tried going door to door, but I couldn't get anywhere with chopsticks or sticks.
[cpg]


[OnName num="kurto"]
I'm in trouble. I'll have to make it by hand somehow. ......?"
[cpg cn=true]


I tried to tell him, but it sounded too difficult.
[cpg]



[window target=false]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



In the end, we didn't get any harvest that day. I thought to myself, "This is bad," but there was nothing I could do.
[cpg]


The sun had set for the day. I had no choice but to go home.
[cpg]


[OnName num="merchant_A"]
I didn't expect her to come to this town too. ......
[cpg cn=true]


I overheard two men, who looked like merchants, standing around talking.
[cpg]


[OnName num="merchant_B"]
They said, "Oh, let's see how she does. Let's see how she does.
[cpg cn=true]


[OnName num="merchant_A"]
I don't think I can say that," he said. She ...... has real business acumen.
[cpg cn=true]


Hinamiya. The name sounded familiar, and I paused.
[cpg]


[OnName num="kurto"]
I've heard of ......, excuse me.
[cpg cn=true]


[OnName num="merchant_A"]
Excuse me?　What is it?
[cpg cn=true]


[OnName num="kurto"]
Is your name Hinamiya, Yuika Hinamiya?
[cpg cn=true]


[OnName num="merchant_A"]
Yes. She does business here in town.
[cpg cn=true]


[OnName num="merchant_B"]
You look familiar.
[cpg cn=true]


Yes, I have seen him before. Are you a merchant or a rival?
[cpg]


[OnName num="kurto"]
No, no. You've got the wrong guy.
[cpg cn=true]



[SE f="se014"]
;//【ＳＥ】『歩く』



I had heard what I wanted to hear, so I quickly walked away.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Bianca163"]
[OnName num="bianca"]
I remember you came here once, didn't you, Yuika-san?
[cpg cn=true]


[OnName num="kurto"]
Oh, yes. I wonder if I can somehow borrow your wisdom, if not your power .......
[cpg cn=true]


He is quite a big businessman. I mean, he's the greatest person ...... in the big business world.
[cpg]


It's different from when he was an aristocrat. I used to think of him as a somewhat equal person in another world.
[cpg]


But now I feel that he is a much higher ranked opponent in the same world.
[cpg]


;//ブラックアウト



We went back to the house, thinking about going to see Yuika.
[cpg]





[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




[OnName num="kurto"]
I said, "......, there's no way I won't use the fact that I know Yuika-san here, is there?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca164"]
[OnName num="bianca"]
'Yes, I do. We are so lucky to have you here in town.
[cpg cn=true]


Indeed. I'm pretty lucky, I'd say.
[cpg]


I should think of it as a chance, after all.
[cpg]


Maybe you know my name at least. ...... is just hubris, I guess.
[cpg]

[jump storage="ep006.ks" target="*start"]

;//=============================================================================
