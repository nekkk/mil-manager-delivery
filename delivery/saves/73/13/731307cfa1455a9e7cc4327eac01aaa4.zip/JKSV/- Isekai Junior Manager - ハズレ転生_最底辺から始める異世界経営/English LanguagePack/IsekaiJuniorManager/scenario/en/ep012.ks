
*start

;//４、ビアンカ


;#################################################
*Ep012|Bianca by my side
;#################################################

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]

*select07_4|Bianca by my side

[SCENE id=12]


I thought back to the past.
[cpg]


The person who was always by my side. The feelings I've always dared not face. ......
[cpg]


Bianca. I know why she likes me.
[cpg]


I've already heard her say that she saw her brother in him, and I know that's not the only reason.
[cpg]


We have had time together to face hard times together. I think that has strengthened our bond.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

Bianca is the one who is closest to me. Bianca is the one I can call out to immediately.
[cpg]


Bianca was the only one who could be at this distance.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



The next day, during the daytime, Bianca and I worked together tending to the store and managing the merchandise.
[cpg]


[OnName num="kurto"]
I knew that there would be few customers during the daytime on a weekday.
[cpg cn=true]


This is something I don't need to tell you. Bianca knows this.
[cpg]



[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca311"]
[OnName num="bianca"]
She knows this, too. But it's also important to keep the store open at these hours.
[cpg cn=true]


It's a trivial conversation. It's a matter of course, but we both say it.
[cpg]


[OnName num="kurto"]
Bianca: "...... Hey, Bianca."
[cpg cn=true]


I didn't mean that I couldn't hold my feelings in check.
[cpg]


Maybe, but there is such a thing as timing for confession. Like, it should be done when the mood is right as much as possible.
[cpg]


Saying that would probably be better at night than during the day. It would be a terrible thing to say at your regular workplace.
[cpg]


But that wasn't the case with Bianca and me.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca312"]
[OnName num="bianca"]
What is it?　"Master."
[cpg cn=true]


[OnName num="kurto"]
"Won't you go out with me? No, I want you to go out with me.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

We were so close that I had to rephrase my confession. There was not much tension here anymore.
[cpg]


Bianca didn't seem too surprised.
[cpg]


She even looked a little embarrassed.......Bianca and I have always had this kind of distance.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Bianca313"]
[OnName num="bianca"]
I've been waiting for you for a long, long time. I didn't serve my master without a thought.
[cpg cn=true]


[OnName num="kurto"]
I thought you were. I'm sorry for keeping you waiting.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca314"]
[OnName num="bianca"]
Really. If you ask me to go out with you, ...... I'll fall in love with you even more.
[cpg cn=true]


[OnName num="kurto"]
Isn't that a strange thing to say?　I don't care if you like me.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca315"]
[OnName num="bianca"]
I don't know how I feel about it. I don't really know how I feel.
[cpg cn=true]


She must have a lot of feelings inside. Maybe she thought that it would be better to keep the master-slave relationship forever or something.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Bianca316"]
[OnName num="bianca"]
But ...... I'm happy for you. Are you sure you're okay with me?"
[cpg cn=true]


[OnName num="kurto"]
She said, "Yeah. It has to be Bianca."
[cpg cn=true]


Bianca nodded. From that day on, we were no longer just master and servant.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


;//移植のためシーンをカットしています

[FACE method="bow_7" pos="2/3"]
[VOICE f="Bianca344"]
[OnName num="bianca"]
......May I call you by your first name, Master?
[cpg cn=true]


[OnName num="kurto"]
I'm not a stranger to you. You're a stranger to me.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Bianca345"]
[OnName num="bianca"]
Then ...... Kurth ...... sir."
[cpg cn=true]


I added "sir. I felt it was meaningless.
[cpg]


[OnName num="kurto"]
"Kurth is fine. You don't have to care about anything anymore.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca346"]
[OnName num="bianca"]
I can't call you that. ...... At least let me call you Mr. Kurth.
[cpg cn=true]


You've served me for quite a long time. It's hard to change now.
[cpg]

;//ここからビアンカは、クルトのことを「クルトさん」と呼びます
;//移植のためシーンをカットしています
;//ブラックアウト

 There were a lot of things I wanted to talk about in a relationship that was different from before.
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



And before I knew it, it was morning. Bianca was surprised.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Bianca364"]
[OnName num="bianca"]
"What, ......?　Is it morning already?"
[cpg cn=true]


[OnName num="kurto"]
Oh ......, I don't feel sleepy."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Bianca365"]
[OnName num="bianca"]
I've got ...... some work to do, don't I?
[cpg cn=true]


[OnName num="kurto"]
I'll work all night. I'll work all night.
[cpg cn=true]


It seemed like a good thing that we had both lost track of time.
[cpg]


That's how much we loved this time.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



[OnName num="kurto"]
......I'm sleepy as a rock."
[cpg cn=true]


I talk to myself when there are no customers.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Bianca366"]
[OnName num="bianca"]
Yes, really."
[cpg cn=true]


Bianca replied. And then.
[cpg]

[free time=1000]

[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Alma531"]
[OnName num="alma"]
You're sleepy?　Is something wrong?"
[cpg cn=true]


Arma was there, too. She was there to help me.
[cpg]


[OnName num="kurto"]
Yes, well, ......, various things.
[cpg cn=true]


It wasn't nothing with Arma, either.
[cpg]


I had been somewhat reluctant to tell her that I was dating Bianca.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Alma532"]
[OnName num="alma"]
If they both look sleepy, maybe...
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Bianca367"]
[OnName num="bianca"]
No, it's not like that. ......　Kurth?
[cpg cn=true]


Bianca was concerned about me, so she made a point of confirming it.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Alma533"]
[OnName num="alma"]
You don't call me 'master,' do you?"
[cpg cn=true]


Arma-san smiled and said so.
[cpg]

[FACE method="change_6" pos="2/5"]
It was obvious. Arma seemed to be smiling at the fact that we were both blushing.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



That night, I was tired as a stone and slept like mud.
[cpg]


The next morning, I went to ......
[cpg]




[window target=false]
[free time=1000]
[BG f="b_08_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kurto"]
I said to Bianca, "What should I do, Bianca? Shall I tell the house about us?"
[cpg cn=true]


I wasn't sure whether or not to tell my former parents. When I asked Bianca about it, she replied.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Bianca368"]
[OnName num="bianca"]
Yes, that's right. I think that would be good."
[cpg cn=true]


It's not like I have any obligation to them now. Rather, it's someone I have some resentment towards.
[cpg]


But maybe I can tell them that I'm ...... living happily.
[cpg]


After all, they are blood brothers and sisters, and they are parents.
[cpg]


[OnName num="kurto"]
I'll write you a letter. That sounds about right."
[cpg cn=true]


Bianca nodded and I decided to send a letter to her parents.
[cpg]


I told her that I had started dating Bianca and that I intended to marry her.
[cpg]


I also added that you already know that I am a successful merchant.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（朝）******************************************************



Today, Bianca and I are going to the store again.
[cpg]


I'm happy just to be by her side, even though it must have happened many times before.
[cpg]


Surprisingly, happiness may change depending on how you look at things.
[cpg]


Somehow, I tried to hold hands with Bianca.
[cpg]


Bianca was surprised for a moment and then held my hand.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca369"]
[OnName num="bianca"]
Bianca was surprised for a moment and then held my hand. It's warm.
[cpg cn=true]


She looked embarrassed. I want to keep this smile.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（朝）******************************************************



I don't want anyone to disturb it. Even if I thought so, time passes and circumstances change.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="4/5" time=800]

It happened suddenly. Yuika told me about it.
[cpg]


[OnName num="kurto"]
She said, "What, ......?　Such a rumor?"
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Yuika482"]
[OnName num="yuika"]
'Yeah. I don't know who is spreading it, but I heard that someone was injured by something you are making.
[cpg cn=true]


Bad rumor. I guess people who don't think well of my business are spreading it.
[cpg]


But I don't get the sense that you think this business itself is dirty.
[cpg]


If they did, they'd have a much different approach.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Bianca370"]
[OnName num="bianca"]
What do you mean ...... really, did you get hurt?"
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Yuika483"]
[OnName num="yuika"]
'Simultaneously, there's the same rumor going around. It's a different product. I sense an agenda.
[cpg cn=true]


Someone was harassing me.
[cpg]


I was surprised that I had no idea what was going on. ......
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



In fact, the person making the complaint never shows up at the store.
[cpg]


It is more likely that they are just spreading rumors.
[cpg]


If that's the case, I still think they have a grudge against me or something.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_08_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="kurto"]
What does that mean? A competitor, maybe.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Bianca371"]
[OnName num="bianca"]
If they are in the same business as ......, it wouldn't be surprising if they try to copy similar products or something like that, would it?
[cpg cn=true]


That's certainly true. I don't know about just hoaxing my product. I don't think I have anything to gain.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドアノック』



[OnName num="kurto"]
'Huh?　Is that a customer?"
[cpg cn=true]


Just then, I heard a knock at the door in the distance.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



[OnName num="kurto"]
"Yes, ......, my brother!
[cpg cn=true]


[OnName num="josef"]
Don't be so surprised. Don't be so surprised. I'm here to play with you.
[cpg cn=true]


There he was, the second son of the Rammerz family, ...... brother Joseph.
[cpg]




[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kurto"]
Why are you here at this hour?
[cpg cn=true]


[OnName num="josef"]
No," he said. You went out with Bianca, didn't you?
[cpg cn=true]


[OnName num="kurto"]
Oh, I didn't know that letter ...... had already arrived.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
Bianca looked embarrassed, but Joseph looked serious.
[cpg]


[OnName num="josef"]
Bianca looked embarrassed, but Joseph looked serious. I should have kept my mouth shut.
[cpg cn=true]


[OnName num="kurto"]
Why?"
[cpg cn=true]


[OnName num="josef"]
Bianca was angry with him. He liked Bianca.
[cpg cn=true]


[OnName num="kurto"]
......
[cpg cn=true]


The dots connected. The letter I sent to my parents' house, the hoax on the merchandise and the fact that I'm not a competitor apart from ......
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca372"]
[OnName num="bianca"]
'So that's what that was about. ...... I didn't realize that.'
[cpg cn=true]


[OnName num="josef"]
I'm not sure how much I can take. My brother was blatantly in love with Bianca."
[cpg cn=true]


[OnName num="kurto"]
But at ...... Aemir's age, it's not surprising that he's married.
[cpg cn=true]


[OnName num="josef"]
He is married. He is married, but things are not going well with his wife.
[cpg cn=true]


Is that so? No, it is possible for Aamir to be married.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



[OnName num="josef"]
Anyway, that's what happened. You'd better be careful.
[cpg cn=true]


[OnName num="kurto"]
Thank you, brother. ...... I wouldn't have known what was going on if I was alone.
[cpg cn=true]


[OnName num="josef"]
Don't thank me. You're a good brother to me and to you.
[cpg cn=true]


I was somewhat uncomfortable with the "for my brother too" part.
[cpg]


The fact that it was for him as well as for his brother was a bit of a turn-off.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule=".webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_07"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



Not long after that incident, I went to the restaurant in the daytime.
[cpg]



[SE f="se002"]
;//【ＳＥ】『ドア開く』



[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Bianca373"]
[OnName num="bianca"]
"Welcome to .......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[OnName num="emile"]
It's been a long time, Bianca. Bianca.
[cpg cn=true]


[OnName num="kurto"]
"You're here,......?
[cpg cn=true]


[OnName num="emile"]
Yeah, I've got something to tell Bianca. I have something to tell Bianca.
[cpg cn=true]


He didn't seem to care anymore.
[cpg]


[OnName num="emile"]
Bianca, are you really going out with Kurth?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Bianca374"]
[OnName num="bianca"]
I mean, ...... we're already dating.
[cpg cn=true]


[OnName num="emile"]
I'm already in a relationship with him. How far have you gone?
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Bianca375"]
[OnName num="bianca"]
Well, that's ......
[cpg cn=true]


[OnName num="kurto"]
What's your point, brother? Make it quick.
[cpg cn=true]


[OnName num="emile"]
Then I'll be brief. Bianca.
[cpg cn=true]


He turns to Bianca. He turns to Bianca.
[cpg]

[FACE method="change_4" pos="2/3"]

[OnName num="emile"]
I'm a nobleman. I'm a nobleman, and I'm not going to stay with a merchant who could go bad at any moment."
[cpg cn=true]


He was really going to confront her thoroughly. He was really going to confront me thoroughly.
[cpg]


[OnName num="kurto"]
He said, "Even if you feel that way, there's a way to say it.
[cpg cn=true]


[OnName num="emile"]
You're the one who asked me to be brief."
[cpg cn=true]


Brother Aemir seemed to be very irritated.
[cpg]


Maybe he's really curious about the extent of the relationship between me and Bianca.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Bianca376"]
[OnName num="bianca"]
'I'm ...... sorry, but I'm not leaving Kurth's side. At least, I won't go to Master Aemir."
[cpg cn=true]


He called me by "san" and his brother by "sama". I felt like that said it all.
[cpg]


[OnName num="emile"]
If you say so, you should know for yourself the power of nobility. You should know the power of nobility.
[cpg cn=true]


His arrogance seemed to have been refined.
[cpg]


[OnName num="emile"]
It's not a business you can be proud of in the first place," he said. I could work to control it.
[cpg cn=true]


[OnName num="kurto"]
You're not being mature, brother. Brother, you're not being mature.
[cpg cn=true]


[OnName num="emile"]
"I don't need to be mature. There is nothing you can get that I can't get.
[cpg cn=true]



[SE f="se004"]
;//【ＳＥ】『ドア閉まる』



With that, he left.
[cpg]


He seemed to be feeling quite complex.
[cpg]


I'm sure Bianca would hate me even more if I did this. ......
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



But the brother seemed to think that Bianca would come to him if this business went under.
[cpg]


When you walk around town, you will hear whispering.
[cpg]


[OnName num="kurto"]
I'm sorry to ...... brother, but I'm just going to do what I can do.
[cpg cn=true]


I was determined to expand my business.
[cpg]


The conflict only deepens, but I can't help it.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************




Then came the holidays. Bianca and I were at home.
[cpg]


I was feeling a bit nervous.
[cpg]


I couldn't think of any way in which my brother could take me away.
[cpg]


But I was ...... strangely anxious. I was being driven by fear by something that should never have happened in the unlikely event.
[cpg]

;//ブラックアウト
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています



The concern has always been there. Namely, that my brother is interfering with my business.
[cpg]


There's no guarantee that he won't take strong-arm measures. He might do it, I thought.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（朝）******************************************************



[FACE method="shake_7" pos="2/5"]
[VOICE f="Alma534"]
[OnName num="alma"]
"That's ...... a problem. My brother is ......."
[cpg cn=true]


Arma had come to help out at the store, and I was telling her what had happened.
[cpg]


[OnName num="kurto"]
She said, "Yes, that's right. I'm sure that nothing will ever happen to you.
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Alma535"]
[OnName num="alma"]
But men can be jealous, too.
[cpg cn=true]


Before I could reply, I was caught off guard by the "even men" part.
[cpg]


[OnName num="kurto"]
I'm sure that's true." "......"
[cpg cn=true]


I could not say that Arma was jealous, either.
[cpg]


There's no way he didn't think anything of the fact that he and Bianca got together. ......
[cpg]


[FACE method="shake_5" pos="4/5"]
[VOICE f="Bianca440"]
[OnName num="bianca"]
What is it? Why do you shut up?
[cpg cn=true]


[OnName num="kurto"]
I'm not. Nothing.
[cpg cn=true]


[OnName num="kurto"]
Anyway, I can't just leave what your brother is doing to you, can I?
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Alma536"]
[OnName num="alma"]
I don't know. What would I do?
[cpg cn=true]


With Arma's involvement, we thought about how we would deal with Aamir.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Alma537"]
[OnName num="alma"]
In the first place, this is about Bianca, isn't it?
[cpg cn=true]


[OnName num="kurto"]
Yes. Arma is right, I think it's jealousy.
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Alma538"]
[OnName num="alma"]
But you are married, aren't you?　It seems strange to me.
[cpg cn=true]


[OnName num="kurto"]
That's for sure. ......
[cpg cn=true]


If brother Emil gets along with his wife, is that all that matters?
[cpg]


That said, it's not something I can do anything about.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Bianca441"]
[OnName num="bianca"]
But ...... you don't have to worry about it, Kurth. I belong to you.
[cpg cn=true]


Yeah. Maybe you don't need to worry about that. But.
[cpg]


[OnName num="kurto"]
"But I don't want to have my business interfered with, do you?
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



I'll think about it. How can we resolve the situation? ......
[cpg]


Confrontation won't solve anything.
[cpg]


Unless he becomes such a big merchant that my brother can't interfere, but the other party is a nobleman.
[cpg]


If my brother becomes serious, even if he becomes a big merchant, he might interfere.
[cpg]


But for now, we just have to make a lot of new products and expand our business.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



We just started dating and we were supposed to be flirting without thinking.
[cpg]


The brother's presence was making us feel delicate.
[cpg]


Bianca might still be good. For my part, I'm of the mind that it might be taken away.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca442"]
[OnName num="bianca"]
You look ...... worried, don't you?
[cpg cn=true]


[OnName num="kurto"]
Well, yeah, I guess.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Bianca443"]
[OnName num="bianca"]
I'm sure my words will not be enough.　I would never leave you, Kurth.
[cpg cn=true]


[OnName num="kurto"]
I'm glad to hear you say that. ......
[cpg cn=true]


But that didn't mean that my worries had been resolved at the root. There was still a strange impatience going on.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


When we are anxious, we want to hang on to those who are by our side.
[cpg]

Even if it wasn't as much as a soggy ......, I felt like Bianca was there to make it bearable.
[cpg]


;//========================================
;//●ＣＧ（背中を向けたヒロインに迫る主人公）ev_34
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="kurto"]
You know,...... Bianca.
[cpg cn=true]


She is honest and always obeys me.
[cpg]

Even now, I think she wants me to do something.
[cpg]

[VOICE f="sBianca021"]
[OnName num="bianca"]
What's wrong ...... you don't do anything?"
[cpg cn=true]


[OnName num="kurto"]
She's like, "...... oh, I'm sorry. Sorry."
[cpg cn=true]


I don't want to do anything to Bianca that would upset this uneasy feeling I have.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



The two of us snuggle up together and sleep. While I felt that I would not let anyone disturb us, the reality was different.
[cpg]


I couldn't look away forever.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_07"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



During the day, when I was tending to the store.
[cpg]


[OnName num="kurto"]
I said, "......, brother."
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Bianca460"]
[OnName num="bianca"]
...... can I help you?"
[cpg cn=true]


At that time, there were only two of us, me and Bianca.
[cpg]


[OnName num="emile"]
I'm just here to make a statement. There are still nobles who don't think highly of your establishment.
[cpg cn=true]


[OnName num="emile"]
They want to collude with you to destroy this store. Then you will go back to your old life.
[cpg cn=true]


It would be so counterproductive. I guess they are trying to get Bianca to turn her back on them.
[cpg]


[OnName num="kurto"]
What do you want, brother? Do you want Bianca to hate you?
[cpg cn=true]


[OnName num="emile"]
No way. I'm just trying to make her realize how small she is.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Bianca461"]
[OnName num="bianca"]
With all due respect to ......, I like that about Kurth, too.
[cpg cn=true]


[OnName num="emile"]
What?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Bianca462"]
[OnName num="bianca"]
I'm attracted to the life-size Kurth. Kurth is different from Aamir.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Bianca463"]
[OnName num="bianca"]
I'm a tiny person myself, you know.
[cpg cn=true]


[OnName num="kurto"]
Bianca ......
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Bianca464"]
[OnName num="bianca"]
I don't think I will go to Aamir-sama no matter what happens from now on.
[cpg cn=true]


[OnName num="emile"]
I'm not going to go to Emil no matter what happens from here on out. I will not say so when I am in need of food.
[cpg cn=true]


Bianca's way of thinking was fundamentally different from that of her brother Aemir.
[cpg]


I think he is aware of this, but he can't stop now.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************



[FACE method="shake_7" pos="2/3"]
[VOICE f="Edith150"]
[OnName num="edith"]
So, such a thing ...... happened."
[cpg cn=true]


Mr. Edith came in later and was surprised.
[cpg]


Bianca was a little angry with the stones, and it was Bianca who told him everything.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Bianca465"]
[OnName num="bianca"]
'People like that ...... really exist, don't they? It was like he was obsessed with power.
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Edith151"]
[OnName num="edith"]
I don't know how I feel about it,......, but it's still not right.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Edith152"]
[OnName num="edith"]
It seems to me that they are doing it because they are not satisfied with what they are doing.
[cpg cn=true]


Ms.Edit didn't say it outright, but I felt like he gave me a hint to overcome the situation.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I felt like I could say that Bianca and I were getting along better because of our work, or rather our inventions.
[cpg]


Then a thought occurred to me.
[cpg]


[OnName num="kurto"]
'...... brother, you said you and your wife are having a hard time.'
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Bianca482"]
[OnName num="bianca"]
Yes, I did. Did you come up with anything?
[cpg cn=true]


[OnName num="kurto"]
No." "No," he said. I was just wondering how things were going.
[cpg cn=true]


It may be none of my business, but ...... there's nothing I can't do about it.
[cpg]


I mean, it's a more fundamental solution than just fighting against the obstruction or trying to stop it.
[cpg]


It's about getting your brothers to get along.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（朝）******************************************************



As soon as I had an idea, I acted on it.
[cpg]


I was on my own, heading toward my parents' house.
[cpg]


I didn't dare bring Bianca with me. If her brother had been there, he would have been a nervous wreck.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『屋敷＿室内』（昼）******************************************************



[OnName num="josef"]
She said, "I'm glad you're here. Your brother's not here right now.
[cpg cn=true]


[OnName num="kurto"]
No, it's good timing. No, it's good timing.
[cpg cn=true]


I handed the package to Joseph.
[cpg]


[OnName num="josef"]
What's this?
[cpg cn=true]


[OnName num="kurto"]
"Your brother is not getting along with his wife," I said. It's a present.
[cpg cn=true]


Joseph glanced at the contents of the package.
[cpg]


[OnName num="josef"]
I see. It's true, he's not a very nice person.
[cpg cn=true]


[OnName num="kurto"]
I knew it," Joseph said. Then it will be effective.
[cpg cn=true]


[OnName num="josef"]
I'd better not say Kurth gave it to me.
[cpg cn=true]


[OnName num="kurto"]
I don't want to say that Kurth gave it to me. I want you to say that Joseph gave it to me.
[cpg cn=true]


[OnName num="josef"]
I'll tell him that. I'll tell him that.
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夕方）******************************************************



In short, if it works out with your wife, it all goes away. That was the root of my thinking.
[cpg]


He would no longer be targeting Bianca.
[cpg]


[OnName num="kurto"]
I hope ...... this works out for you."
[cpg cn=true]


I wonder if Brother Aamir would use it if he knew I was selling it.
[cpg]


But if Joseph bought it, he might give it a try.
[cpg]


I don't think those two are at odds with each other. I spent my days with such expectations.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（朝）******************************************************



Some days and nights passed. All the while, I was still seeking Bianca.
[cpg]


When I think about it, I feel as if Bianca was the reason I was able to stay sane.
[cpg]


Brother Aemir must be losing that kind of support.
[cpg]




[SE f="se002"]
;//【ＳＥ】『扉開く』

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『屋敷＿室内』（昼）******************************************************



[OnName num="kurto"]
......I'm home."
[cpg cn=true]


This time, I visited him during the daytime on a holiday, when Aamir was sure to be there.
[cpg]


Ten days have passed since then. It's not surprising that it had some kind of effect on him.
[cpg]


[OnName num="emile"]
"Kurth, is that you? What do you want?
[cpg cn=true]


Brother Aamir was blunt.
[cpg]


[OnName num="kurto"]
I'm not here for anything, but ...... that ......
[cpg cn=true]


I couldn't ask him about the relationship between him and his wife.
[cpg]


If it wasn't going well, there was no way I could connect the dots from there. However.
[cpg]


[OnName num="emile"]
"......If you didn't want anything from me, that was fine. I had to thank you."
[cpg cn=true]


[OnName num="kurto"]
What?
[cpg cn=true]

[OnName num="emile"]
I guess what you make is really appreciated by people."
[cpg cn=true]


He was a little embarrassed, though he said something like that.
[cpg]


[OnName num="kurto"]
He looked a little embarrassed. It was worth it.
[cpg cn=true]

[OnName num="emile"]
I've changed the way I look at you, too," he said. I thought you had taken Bianca away from me for some crazy business deal.
[cpg cn=true]


[OnName num="emile"]
I thought you took Bianca away from me for some crazy business. You saved my life.
[cpg cn=true]


[OnName num="kurto"]
You don't have to say that. I'm flattered.
[cpg cn=true]


[OnName num="emile"]
I'm sorry I ever stood in your way.
[cpg cn=true]



;//ブラックアウト


In other words, it's all settled. ...... I thought it was like the North Wind and the Sun.
[cpg]


I should have focused on why the hostility was directed at me, not what to do about it.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



[FACE method="bwo_1" pos="2/3"]
[VOICE f="Yuika484"]
[OnName num="yuika"]
...... You look happy, Kurth."
[cpg cn=true]


[OnName num="kurto"]
"Do I?　It's normal.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Yuika485"]
[OnName num="yuika"]
I don't know. You look like you've reconciled with your siblings who have been at odds with each other for a long time.
[cpg cn=true]


[OnName num="kurto"]
Did you hear from Bianca at ......?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika486"]
[OnName num="yuika"]
I'm glad you're happy. That's good, isn't it?"
[cpg cn=true]


[OnName num="kurto"]
Yeah, I'm happy for her. But it doesn't seem like the kind of thing to talk about.
[cpg cn=true]


Yuika crossed her arms and giggled.
[cpg]


[FACE method="shake_2" pos="2/3"]
;//[VOICE f="Yuika487"]
[VOICE f="sYuika014"]
[OnName num="yuika"]
;//「もっと堂々としたらどうかな。君は、お兄さん達だけじゃなく、もっと多くの恋人達を救ってるはずだよ」
I think you should be more open about it.
[cpg cn=true]


I'm not really feeling it when you say that. But ......
[cpg]


I thought, maybe I should be proud of myself a little bit.
[cpg]



;//ブラックアウト

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


My heart was dancing as I was able to reconcile with my brother, Aemir, too.
[cpg]


Even though he was supposed to be the one I hated...I guess somewhere in my heart, I wanted to be recognized, I had that feeling.
[cpg]


Because they were family. I guess I just couldn't part with it.
[cpg]


;//========================================
;//●ＣＧ（主人公を起こすヒロイン）ev_54
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：
;//時間　：朝
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_54_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています


Then again, a few days later: ......
[cpg]


[VOICE f="sBianca022"]
[OnName num="bianca"]
Please wake up. It's time to go.
[cpg cn=true]


[OnName num="kurto"]
Time?　Oh, ......."
[cpg cn=true]


Yes, it was. Today is the big day.
[cpg]

;//ビアンカが起こしてくれて良かった……遅れたら大変だ。
;//[cpg]

[SE f="se000"]
;//【ＳＥ】『馬車の音』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_12_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]

[OnName num="kurto"]
......
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Bianca532"]
[OnName num="bianca"]
Is something wrong?
[cpg cn=true]


[OnName num="kurto"]
No, I just didn't think this day would ever come again.
[cpg cn=true]


I stop in front of my old family home.
[cpg]


I was so nervous that Bianca took my hand in hers.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2100]


[SE f="se002"]
;//【ＳＥ】『扉開く』

[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『屋敷＿室内』（昼）******************************************************



I took a deep breath and opened the door to see my parents.
[cpg]


[OnName num="emile"]
Kurth, how nice of you to come.
[cpg cn=true]


[OnName num="kurto"]
Brother Aamir..."
[cpg cn=true]


[OnName num="father"]
I'm sorry, Kurth. I'm really sorry.
[cpg cn=true]


[OnName num="mother"]
I'm sorry.
[cpg cn=true]


[OnName num="emile"]
Let me... apologize again.
[cpg cn=true]


[OnName num="kurto"]
No, it's okay. It was something that had to be done.
[cpg cn=true]


At one point, I hated my parents and siblings who abandoned me. I even thought about dying.
[cpg]


But I continued to live, and through all that happened, I was able to grow, which is why I am here now.
[cpg]


I have reconciled, I have learned to forgive others, and I have learned to put myself in the other person's shoes.
[cpg]


[OnName num="kurto"]
I am happy that I have grown as a person and, most importantly, that I can be with my family again.
[cpg cn=true]


[OnName num="father"]
Thank you my son.
[cpg cn=true]


I am a nobleman again. I am once again a nobleman, and nothing could be more convenient for expanding my business.
[cpg]


I was one step closer to becoming the best merchant in the world.
[cpg]


It was thanks to her, of all people, that I was able to keep going without giving up or becoming desperate.
[cpg]


I gently held her hand.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Bianca533"]
[OnName num="bianca"]
I hold her hand gently. ......
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca534"]
[OnName num="bianca"]
I'll be counting on you from now on, won't I? Kurth-san.
[cpg cn=true]



;//ブラックアウト

[SCENE id=17]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ　ヒロイン４ルート

;//==============================
