

*start

;//==============================
;//３、エーディト



;#################################################
*Ep014|Edith, who saw us through
;#################################################

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]


*select07_3|Edith, who anticipated me.

[SCENE id=14]


What came to my mind was Mr. Edith.
[cpg]


He had been working hard for the same purpose for a long time. And yet, he was originally a stranger to me. ......
[cpg]


I think I can say that he was someone who genuinely appreciated my talent.
[cpg]


When I say talent, I'm really just tracing memories from a previous life. ......
[cpg]


Still, I was remembering the time I showed the blueprints to Mr. Edith.
[cpg]


I was so happy. I can still vividly recall the twinkle in her eyes.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************



The next day, I had come to the store. Bianca was in the backyard and I was tending to the store.
[cpg]


During the daytime, there were not many customers. In the evening, the number of customers started to increase.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



That's when she came in.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Edith156"]
[OnName num="edith"]
She said, "Hello. I brought you an item ......."
[cpg cn=true]


She had brought me an item, so I took it.
[cpg]


[OnName num="kurto"]
She said, "Thank you very much. I'm always happy to help.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Edith157"]
[OnName num="edith"]
I'm glad I can be of help, too.
[cpg cn=true]


Ms. Edith looked more than happy, he seemed to be enjoying himself.
[cpg]


If he likes this job, I have nothing to say about it.
[cpg]


I'm a good business partner with Mr. Edith. But that's where it stops now.
[cpg]


[OnName num="kurto"]
I said, "Well, ...... Mr. Edith, do you have time this evening? Do you have time tonight?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Edith158"]
[OnName num="edith"]
"What?　I'm fine.
[cpg cn=true]


[OnName num="kurto"]
I have something important to tell you.
[cpg cn=true]


I wondered if it was okay to say, "I need to talk to you. Before I could think about it, I acted.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Edith159"]
[OnName num="edith"]
"...... understand."
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************



I had no doubt that I had said it.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Bianca542"]
[OnName num="bianca"]
You've made up your mind, Master.
[cpg cn=true]


[OnName num="kurto"]
You heard me, Bianca.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Bianca543"]
[OnName num="bianca"]
'Yes, I did. I knew you cared about Master Edith.
[cpg cn=true]


I was thinking it was that blatant ......, but Bianca had my back.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



I went to have dinner with Edith with the same momentum.
[cpg]


I didn't feel like adding alcohol. I had to stay as calm as possible.
[cpg]


On the other hand, I felt that if I stayed sober, I would never be able to confess my feelings. ......
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Edith160"]
[OnName num="edith"]
"I'm so full...... thanks for buying me a drink."
[cpg cn=true]


[OnName num="kurto"]
I'm not. I'm just thanking you for accompanying me on my rambling on and on.
[cpg cn=true]


Yes. I've told you a story that I can't stop talking about.
[cpg]


It was no good declaring that I had something important to talk about.
[cpg]


But I have a feeling that the other side is somehow getting the message.
[cpg]


I wonder if now is the right time to say something. I don't know what the timing is for this kind of thing.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Edith161"]
[OnName num="edith"]
"So, what's the important thing to talk about ......?"
[cpg cn=true]


[OnName num="kurto"]
"Uh, oh, no."
[cpg cn=true]


I was silent, and Edith waved me off.
[cpg]


The town is full of people coming and going. It is not a situation where the two of us are alone.
[cpg]


And above all, although it is not romantic, I felt that Mr. Edith was also in a hurry to reach a conclusion.
[cpg]


Or maybe it is me who is rushing to a conclusion. ......?　I don't know what the pause is.
[cpg]


While I was thinking about this, Mr. Edith started to speak first.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Edith162"]
[OnName num="edith"]
If you don't say anything, I'll tell you. ......
[cpg cn=true]


[OnName num="kurto"]
What?
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Edith163"]
[OnName num="edith"]
I like you. Kurth, I like you.
[cpg cn=true]


I fell silent. I don't know how many times I've fallen silent.
[cpg]


[OnName num="kurto"]
I'm sorry for making you say ...... I like you, too. Mr. Edith."
[cpg cn=true]


The words came out without thinking. It was not an appropriate response to a confession.
[cpg]


But Mr. Edith seemed happy.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Edith164"]
[OnName num="edith"]
Not "Mr. Edith," but "Edith ......."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Edith165"]
[OnName num="edith"]
You can call me by my first name. And you don't have to be polite.
[cpg cn=true]



;//ここからクルトはエーディトをさん付けしなくなり、丁寧語も使わなくなります
;//また、エーディトはクルトをクルトと呼ぶようになります



[OnName num="kurto"]
'...... right. Thank you."
[cpg cn=true]


I said, "I'm sorry. But what I should have said was thank you.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Edith166"]
[OnName num="edith"]
I ...... would do anything for you.
[cpg cn=true]


As he said this, Ms. Edit brought his lips to mine in the midst of the crowd.
[cpg]


The first thing to do is to make sure that you have the right tools and the right people to help you.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="kurto"]
......"
[cpg cn=true]


Back at home, I don't really feel it. I doubt if we really exchanged words.
[cpg]


She is a commoner, and I am a commoner. We are in a position to tie the knot without any problems.
[cpg]


It's so smooth that it's scary, or so I feel.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[SE f="se000"]
;//【ＳＥ】『鳥の鳴き声』



I can't sleep, even though I don't have Edith next to me.
[cpg]


When I imagine a happy future, it makes me feel uneasy.
[cpg]


[OnName num="kurto"]
......Sleepy."
[cpg cn=true]


Even though I'm sleepy, I have to work.
[cpg]


I rubbed my eyes and decided to have breakfast.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（朝）******************************************************



[SE f="se014"]
;//【ＳＥ】『歩く』



I finished getting ready and walked along my usual path.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

Bianca is next to me. She looked as if she had guessed everything.
[cpg]


[OnName num="kurto"]
I said, "......, what's with that face?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Bianca544"]
[OnName num="bianca"]
No, it's just that seeing Master so happy makes me happy, too.
[cpg cn=true]


I wonder if she has that kind of face. I'm embarrassed.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（朝）******************************************************



[FACE method="bow_2" pos="2/5"]
[VOICE f="Alma545"]
[OnName num="alma"]
Good morning, Mr. Kurth. Mr. Kurth.
[cpg cn=true]


[OnName num="kurto"]
"Hi, good morning. ......"
[cpg cn=true]


I was sleepy even to say morning greetings.
[cpg]


Arma-san looked a little worried, but didn't pursue me in particular.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Bianca545"]
[OnName num="bianca"]
'Thank you for everything, Arma-sama. Will you help me again today?
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Alma546"]
[OnName num="alma"]
Yes, I am. Kurth-san is a benefactor.
[cpg cn=true]


Mr. Arma is still saying that to me. I am sure that he likes me.
[cpg]


I think about that part too. I wonder if I should tell her that I'm dating Edito, or ......
[cpg]



[free time=1000]


[SE f="se002"]
;//【ＳＥ】『ドア開く』



But those thoughts turned out to be unfounded.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Edith167"]
[OnName num="edith"]
I said, "Good morning, Kurth. Kurth.
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

[OnName num="kurto"]
"Oh, good morning ......?
[cpg cn=true]


Edito came over, I thought, and he kissed me just like that.
[cpg]


The first thing you need to do is to make sure that you have a good time. And it was like they had just met, so there was no hesitation at all.
[cpg]


Bianca's cheeks were stained and she was looking at me. She looks like she just saw me. I guess she was aware of the relationship between me and Edith to some extent.
[cpg]


And Arma looked genuinely surprised.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Edith168"]
[OnName num="edith"]
I've brought you the goods.
[cpg cn=true]


[OnName num="kurto"]
Oh, ah, ......, I see."
[cpg cn=true]


The two of us headed for the back yard. I heard Arma and Bianca whispering.
[cpg]


I thought I heard the word "envy," and I felt kind of sorry.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（夜）******************************************************





And that night. I was walking around the city, as if Mr. Edith had asked me to join him.
[cpg]


[OnName num="kurto"]
Where are you going?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Edith170"]
[OnName num="edith"]
"A place to stay. I've already made reservations.
[cpg cn=true]


I had already guessed what she wanted to do, but I kept quiet.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Edith171"]
[OnName num="edith"]
'...... Kurth's house, Bianca's there. ......'
[cpg cn=true]


Edith added, as if she didn't think she was getting the message across.
[cpg]




;//ブラックアウト


[SE f="se002"]
;//【ＳＥ】『ドア開く』


;//========================================
;//●ＣＧ（主人公に迫られるヒロイン）ev_62
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：宿の一室
;//時間　：夜
;//========================================
;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bgm_09"]
;**【ＣＧ】 ev_62_0 ***********************
[CG id=20 index=0 time=1000]
;***************************************
[WAIT time=1000]


In a room at the inn, no one interrupted us.
[cpg]

We talked about things we hadn't been able to talk about before.
[cpg]

She was shy, but it was adorable that she had shown so much courage.
[cpg]
[VOICE f="sEdith006"]
[OnName num="edith"]
'Hey ......, Kurth!'
[cpg cn=true]


I couldn't resist and kissed her.
[cpg]

Still, Edith didn't mind.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=1000]

When I returned home in the morning, Bianca was smiling at me.
[cpg]


I thought she was jealous, but surprisingly she wasn't.
[cpg]


With that thought in mind, I slept like a mud ......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



Peaceful days passed peacefully.
[cpg]


I develop products with the idea that they will be used for Edits.
[cpg]


I had never thought of it that way before.
[cpg]


I guess I'm kind of a floater.
[cpg]


No matter what I did, I thought of Edith.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Edith194"]
[OnName num="edith"]
I'm smirking at ......."
[cpg cn=true]


[OnName num="kurto"]
Eh. No, no, I don't think so.
[cpg cn=true]


[free time=1000]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Bianca546"]
[OnName num="bianca"]
'You must be very happy. Master."
[cpg cn=true]


The way Bianca said it, I knew she was somewhat jealous.
[cpg]


But I knew they were blessing me more than that.
[cpg]





;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



A peaceful moment passed.
[cpg]


I thought that Edith and I were married, and that we were getting along as lovers without any problems.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（朝）******************************************************



But then one day. One day, however, Edith said something to me that I never expected.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（朝）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Edith218"]
[OnName num="edith"]
"Good morning, Kurth.
[cpg cn=true]


[OnName num="kurto"]
Good morning. Sorry about that.
[cpg cn=true]


It was when Edith brought me the goods. She was having a hard time saying something.
[cpg]


[OnName num="kurto"]
"What's wrong?　"Edith, you look like you want to say something.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Edith219"]
[OnName num="edith"]
She said, "Yeah, well, ...... I wanted to make weapons and armor, after all."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Edith220"]
[OnName num="edith"]
A different merchant from Kurth asked me if I'd like to sell them to him.
[cpg cn=true]


[OnName num="kurto"]
...... I see."
[cpg cn=true]


I was more than a little upset. I was a little upset. I had no idea that Edith had been thinking about that.
[cpg]


[OnName num="kurto"]
I was a little upset that Edith was thinking of doing that. If that's what he wants to do, he should do it.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Edith221"]
[OnName num="edith"]
"Really?　Then I want to."
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



I said that at the time, but the turmoil was growing inside me.
[cpg]


She is a blacksmith, after all. You don't think she wants to make inventions?
[cpg]


Or maybe she's embarrassed by my work. ......?
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Yuika491"]
[OnName num="yuika"]
Good evening. What's the matter, Kurth? You look kind of down."
[cpg cn=true]


[OnName num="kurto"]
'No, I'm not. ......
[cpg cn=true]


The tone of his voice was low. I thought I could be recognized.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuika492"]
[OnName num="yuika"]
I heard that you went out with Edith. Did something happen?
[cpg cn=true]


[OnName num="kurto"]
Nothing, nothing ......."
[cpg cn=true]


Edith is not in the store right now. I might be able to confide in Yuika here .......
[cpg]


But it's still no good. I can't do such a pathetic thing.
[cpg]


I wanted to be the one who could be proud of Edith.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuika493"]
[OnName num="yuika"]
You're telling me that Edith wants to start another business?
[cpg cn=true]


[OnName num="kurto"]
How did you know?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuika494"]
[OnName num="yuika"]
─ Well, he is a merchant, you know. I can at least hear rumors.
[cpg cn=true]


Yuhka had seen through it all.
[cpg]


[OnName num="kurto"]
Even if that's true,......, I'm not worried about it.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Yuika495"]
[OnName num="yuika"]
It's like I'm saying I'm troubled. Well, if you want to solve it yourself, that's fine too."
[cpg cn=true]


Yuika's words bothered me even more, but it was still something I had to face.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************



After work. I decided to visit Edith's house.
[cpg]




;//ブラックアウト

;//========================================
;//●ＣＧエロ（ロウソク責め。縛られて、仰向けに寝ているヒロイン）ev_64
;//人物１：ヒロイン３　服装１：裸
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン３の部屋
;//時間　：夜
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bgm_09"]
;**【ＣＧ】 ev_64_0 ***********************
[CG id=21 index=0 time=1000]
;***************************************
[WAIT time=1000]

[window target=true]
My impatience was growing.
[cpg]

I had thought of using my charm as a man to force my way in.
[cpg]

[VOICE f="sEdith007"]
[OnName num="edith"]
"Hey ...... Kurth, you're being too hasty ......."
[cpg cn=true]


But I had none of that, and forcing him to kiss me would only make him spin around.
[cpg]

And my impatience was growing again.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



In the midst of my growing worries, I had a bit of good news.
[cpg]


The news was that the magic stone needed to make the invention had been found.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『鉱脈』（昼）******************************************************



It is said to be deep in a dungeon where demons lurk.
[cpg]


The magic stone would last much longer and work much more strongly than the previous ones.
[cpg]


Katharina, who saw the piece of magic stone I brought back, said so, so I am sure of it.
[cpg]


I decided to hire an adventurer before someone else did.
[cpg]


I could do that with the profits from my store. And ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************





[OnName num="kurto"]
'I want Edito to help me out too. I want her to make weapons and armor for the adventurers."
[cpg cn=true]


Her business with another merchant seemed to be going well.
[cpg]


To a certain extent, that means the quality of the weapons and armor they make is good.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Edith245"]
[OnName num="edith"]
She said, "...... yes, I think I can do that. I think I can do it."
[cpg cn=true]


Edith nodded.
[cpg]


[OnName num="kurto"]
I'm glad to hear that," he said. Then will you start making them?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Edith246"]
[OnName num="edith"]
No, I think it's better to have a weapon that's already made. I think it's better to have a weapon that's already made, because every minute counts.
[cpg cn=true]


[OnName num="kurto"]
......That's true, too."
[cpg cn=true]


Edith's head was spinning.
[cpg]


I decided to dispatch adventurers.
[cpg]


Come to think of it, my previous life was as a dispatcher,...... I never thought I'd be in the opposite position, but this is fate of some kind.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン』（昼）******************************************************



I was on the dispatcher's side, too, and had come to the entrance of the dungeon.
[cpg]


[OnName num="kurto"]
I said, "......Then, I'm counting on you. I'll be waiting for good news.
[cpg cn=true]


[OnName num="adventurer_A"]
Yes, of course. I'll take care of it.
[cpg cn=true]


[OnName num="adventurer_B"]
You are the only one who would offer such a large sum of money to an adventurer nowadays.
[cpg cn=true]


It's not so much money as it is something to do with my business. It was my business, so I was willing to make this kind of investment.
[cpg]


[OnName num="kurto"]
Be careful.
[cpg cn=true]


[OnName num="adventurer_A"]
Yes, sir. I'll see you later.
[cpg cn=true]


After seeing them off, I went back to my work.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夕方）******************************************************



Sales are going well. I can do even better once I get the new magic stone.
[cpg]


Nothing is wrong. There's nothing for me to be worried about.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Bianca547"]
[OnName num="bianca"]
"You seem anxious ......, Master."
[cpg cn=true]


[OnName num="kurto"]
"Do I look so ......?"
[cpg cn=true]


The fact is, I was restless. The biggest reason for this is because of what happened with Edith.
[cpg]


The actuality is, you can find a lot of people who are not really interested in the particulars of the particulars.
[cpg]


The actuality is, you can find a lot of people who are not aware of the fact that they are not aware of the fact.
[cpg]


I wondered what she thought about the invention.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



Part of me couldn't wait for the store to close.
[cpg]


I want to talk to Edith. I wanted to visit her as soon as possible.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（夜）******************************************************



After work, I rushed to Edith's place.
[cpg]


[OnName num="kurto"]
"Hello, good evening, Edith. Edith.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Edith247"]
[OnName num="edith"]
"Good evening, ...... Kurth, have you eaten yet?"
[cpg cn=true]


[OnName num="kurto"]
No, not yet. I was thinking of going somewhere to eat.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Edith248"]
[OnName num="edith"]
"......, or better yet, how about a home-cooked meal from me?"
[cpg cn=true]


I see. I'd rather have it that way.
[cpg]


[OnName num="kurto"]
Well, I'll treat you.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Edith249"]
[OnName num="edith"]
Okay. Come in.
[cpg cn=true]



[free time=1000]


[SE f="se002"]
;//【ＳＥ】『ドア開く』



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

;//背景と別の場所なので、上下に黒帯を入れるなどしてください



Edith is naturally good with her hands. Her skills are not related to dexterity, because her skills are those of a skilled chef.
[cpg]


But she was very good at cooking. I used to think I'd make a living at cooking, too. ......
[cpg]


Edit was better than him by comparison.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kurto"]
It's ...... delicious."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Edith250"]
[OnName num="edith"]
I'm glad...... I'm happy."
[cpg cn=true]


We finished dinner and talked about nothing else for a while.
[cpg]


I can't go into what she thinks of my work.
[cpg]


It's possible that my fears are all unfounded. But I can't ask her if she doesn't like my job.
[cpg]



;//背景と別の場所なので、上下に黒帯を入れるなどしてください


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_07"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="kurto"]
......"
[cpg cn=true]


Edito is selling his regular weapons and armor to another merchant.
[cpg]


If he wanted me to do the same, I would ......
[cpg]


Would I stop inventing? This is what I've decided I'm going to earn from it.
[cpg]


Even if I didn't, there is no job more suited to me, with my skills and memories of my past life.
[cpg]


Thinking about it makes me feel like I can't sleep.
[cpg]


I was not so much being pushed around by Edith as I was being pushed around by my feelings for her.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Bianca548"]
[OnName num="bianca"]
Good morning, master, breakfast is ready. Master, breakfast is ready.
[cpg cn=true]


[OnName num="kurto"]
'Oh, good morning .......'
[cpg cn=true]


[free time=1000]


Even though the morning came, I still felt a little depressed.
[cpg]


So this is what love is all about. I thought it was something more fluent.
[cpg]


But ...... everything may be a happy trouble.
[cpg]


Even now, he has a lover named Edit, but he also has Bianca, his maid, serving him.
[cpg]


I feel like I've never been happier. Maybe I can just soak it all in without thinking about it. ......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（昼）******************************************************





That day, Katharina came to see me.
[cpg]


I know you want to hear and say what I think about the new magic stone. ......
[cpg]


The main reason she came here seemed to be her interest ...... in what I had made.
[cpg]


Her interest in my inventions is not at all stagnant.
[cpg]


I wish Edith was as straightforward as Katharina, but she doesn't say everything she thinks.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="sCatalina021"]
[OnName num="catalina"]
I don't know how you come up with your inventions," she said. I really don't have the words.
[cpg cn=true]


He talks a lot for someone who says he's speechless. But he said it in a way that gave me confidence.
[cpg]


[OnName num="kurto"]
When you praise me, Katharina, it makes me happy, too.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Catalina432"]
[OnName num="catalina"]
I'm not complimenting you, I'm just saying what I'm thinking.
[cpg cn=true]


I really wish I could hear those words from Edith. I thought so.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



I was going about my daily business and at the same time I was concerned about the new vein of ore.
[cpg]


Even now, adventurers are probably heading for the dungeon in question.
[cpg]


The weapons and armor that Edith made are indirectly contributing to my work.
[cpg]


I wonder what Edith thinks about this. ......
[cpg]


I wonder if he thinks it's just because it's my job and I sold the weapons because there were people who wanted them.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



A little more time passes. Reports were coming in from adventurers who were heading for the dungeon.
[cpg]


It was the news that they had cleared out the demons that had been nesting in the dungeon.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_03"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン』（昼）******************************************************




[OnName num="adventurer_A"]
We were saved by a good weapon," said Edito. You are quite skilled, aren't you, Mr. Edith?
[cpg cn=true]


[OnName num="adventurer_B"]
Indeed. Without these weapons and armor, we would have had a much harder time.
[cpg cn=true]


I was guided and taken to the mine. And then ......
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Edith303"]
[OnName num="edith"]
'Well, then ...... good.
[cpg cn=true]


Edith was there, too. I don't know for what reason he followed me.
[cpg]


[OnName num="kurto"]
So, was the vein going to be mined?
[cpg cn=true]


[OnName num="adventurer_A"]
I know it when I see it," he said. It's a treasure trove.
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『鉱脈』（昼）******************************************************



The place I was taken to, in the vein, ...... certainly had a view that could be called a treasure trove.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Edith304"]
[OnName num="edith"]
I've never seen ...... so many magic stones before.
[cpg cn=true]


With this, my job will be safe for a while. However.
[cpg]


I was still stuck. What was Edit's intention in helping me?
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Edith305"]
[OnName num="edith"]
What's wrong, Kurth ......, aren't you happy?
[cpg cn=true]


[OnName num="kurto"]
No, I'm happy. No, I'm happy.
[cpg cn=true]


I was not happy at all. And then he said, "Well, I'm glad you're happy.
[cpg]


[OnName num="adventurer_A"]
"It's all thanks to your hard work, Mr. Edith.
[cpg cn=true]


[OnName num="adventurer_B"]
Yes. When we told him about the nature of the demons, he immediately made weapons accordingly. ......
[cpg cn=true]


[OnName num="kurto"]
...... "Is that right?"
[cpg cn=true]


I definitely thought that he was just handing over the weapon he had already made.
[cpg]


I don't know why you would go to such lengths to help me .......
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Edith306"]
[OnName num="edith"]
I'll do at least that much,......, of course, to help Kurth.
[cpg cn=true]


I guess I've been worrying about something so trivial for so long.
[cpg]


You're involved in my business, albeit indirectly. That's the answer to everything.
[cpg]


[OnName num="kurto"]
You're right, "....... Was there ever a possibility that you wouldn't be involved in what I do anymore?"
[cpg cn=true]


I can't help but let the words come out of my mouth. Then.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Edith307"]
[OnName num="edith"]
'No way that's going to happen,...... I'm proud of the work Kurth does.
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Edith308"]
[OnName num="edith"]
I just found a more rewarding job than helping ...... it to start making weapons."
[cpg cn=true]


It was like a fog had lifted. How could I not see how simple this was?
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街＿異世界』（昼）******************************************************



From there, I acted quickly.
[cpg]


I sent miners to the veins and incorporated them into my products. I could do those things without hesitation.
[cpg]


Really, all I had to do was to confirm one word. I feel like I stalled because I couldn't do that.
[cpg]


In the end, it was resolved without even that one word. ......
[cpg]


It seemed that there was no need for concern between me and Edith anymore. Really, I was lost in the nonsense.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kurto"]
Mining seems to be going well."
[cpg cn=true]


Holiday. I was having a quiet time with Edith.
[cpg]


[FACE method="boe_7" pos="2/3"]
[VOICE f="Edith309"]
[OnName num="edith"]
It was worth ...... all the hard work.
[cpg cn=true]


[OnName num="kurto"]
Thank you," he said. I really don't know what to say.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Edith310"]
[OnName num="edith"]
'You don't have to say anything,...... just say thank you and I'm happy.'
[cpg cn=true]

;//ブラックアウト

;//========================================
;//●ＣＧ（屋外、主人公に寄り添うヒロイン。キスをする）ev_33
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：屋外
;//時間　：昼
;//========================================
;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bgm_02"]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=22 index=0 time=1000]
;***************************************
[WAIT time=1000]

Then she kissed me.
[cpg]

We had gotten over the misunderstanding and our distance had grown even closer.
[cpg]

[VOICE f="sEdith008"]
[OnName num="edith"]
'Do you think ...... I'm a flirt?
[cpg cn=true]


[OnName num="kurto"]
No way. I'm glad."
[cpg cn=true]



;//移植のためシーンをカットしています

;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



A few days later.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

A few days later, I was shopping in town with Edith.
[cpg]



[free time=1000]

[SE f="se000"]
;//【ＳＥ】『喧騒』



[OnName num="kurto"]
"What's going on?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Edith359"]
[OnName num="edith"]
"Is... something wrong?"
[cpg cn=true]


[OnName num="kurto"]
Is something wrong?"
[cpg cn=true]


[OnName num="adventurer"]
Yeah? Yeah, I think there was a little screw-up.
[cpg cn=true]


Apparently, one of the adventurers was seriously injured.
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Edith360"]
[OnName num="edith"]
......
[cpg cn=true]


[OnName num="kurto"]
What's wrong?
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Edith361"]
[OnName num="edith"]
Nothing..."
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_07"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



Edith was saying that, but there was something wrong with her.
[cpg]


[OnName num="kurto"]
What's wrong? If you have something to tell me, tell me.
[cpg cn=true]


[FACE method="boe_7" pos="2/3"]
[VOICE f="Edith362"]
[OnName num="edith"]
"......, actually.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Edith363"]
[OnName num="edith"]
I made that armor.
[cpg cn=true]


An adventurer was badly injured. He was wearing armor made by Edith.
[cpg]


She is kind. She must have thought it was her fault that he was injured.
[cpg]


[OnName num="kurto"]
She was probably thinking that it was her fault that he was injured. That's what adventurers do. It's not something for Edith to worry about.
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Edith364"]
[OnName num="edith"]
......
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



;//[SE f="se019"]
;//【ＳＥ】『鉄を打つ音』



[OnName num="kurto"]
"What? The sound has stopped?
[cpg cn=true]


The sound of her hammer, always in a lively rhythm, coming from the workshop.
[cpg]


It became quieter and quieter... and then the sound stopped.
[cpg]


Usually, this sound echoed until late.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Edith365"]
[OnName num="edith"]
"Kurth..."
[cpg cn=true]


[OnName num="kurto"]
Welcome back. You're back early.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Edith366"]
[OnName num="edith"]
What do I do?
[cpg cn=true]


[OnName num="kurto"]
What's wrong?
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Edith367"]
[OnName num="edith"]
I can't hit anymore.
[cpg cn=true]


The situation was more serious than she had expected.
[cpg]


She was distressed because she thought it was because she had made an imperfect armor, and she couldn't make anything.
[cpg]


It was like she was in a so-called slump.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



To break the slump, I thought about this and that.
[cpg]



;//========================================
;//●ＣＧ（ヒロインにマッサージをする主人公）ev_66
;//人物１：ヒロイン３　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_66_0 ***********************
[CG id=23 index=0 time=1000]
;***************************************
[WAIT time=1000]

I even tried to remind her of the first job she did for me.
[cpg]

In other words, I called her up to give her a massage. But ......
[cpg]

[VOICE f="sEdith009"]
[OnName num="edith"]
I said, "...... I knew it, no. I'm glad you care, but still no."
[cpg cn=true]


She seemed to rather dislike my concern.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="kurto"]
I don't know what I'm going to do about Edith.
[cpg cn=true]


Since that day, she has not been able to make a weapon.
[cpg]


The slump continues.
[cpg]


I hope it's only temporary, but it's not good if it lasts forever.
[cpg]


Blacksmithing is inseparably important to her.
[cpg]


Today, she continues to sell her inventions, wondering how she can get back to her roots.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の店＿店内』（夜）******************************************************


[OnName num="kurto"]
Welcome.
[cpg cn=true]


[OnName num="regular_customer"]
Hello. The usual, please.
[cpg cn=true]


[OnName num="kurto"]
Please wait a moment.
[cpg cn=true]


[OnName num="regular_customer"]
Well, the quality here is very good, and it's always useful.
[cpg cn=true]


[OnName num="kurto"]
Thank you very much. I am glad to hear you say so.
[cpg cn=true]


It was an ordinary conversation with a customer.
[cpg]


But then I thought to myself. It's a very simple thing ......, but I thought that this is what I need to do.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_02"]
[WAIT time=100]
;//【ＢＧ】『街＿異世界』（昼）******************************************************



What I came up with was to provide the real voices and impressions of the customers.
[cpg]


She is driven by remorse. The only person who can forgive her is herself.
[cpg]


So what does she need to give forgiveness? Not my words.
[cpg]


The words of the adventurers who buy her weapons and armor.
[cpg]


I remember when I received letters of feedback on my products, too.
[cpg]


I realized once again that this is what keeps the creators motivated.
[cpg]


There are a certain number of fans of the weapons and armor she makes, just not as many as Edito can see.
[cpg]


The merchant who handles them also said that they are always well received.
[cpg]


If that's the case, then all you have to do is just deliver them to them.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bgm_05"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Edith405"]
[OnName num="edith"]
The "I don't know what to do. If I can never make it again..." "(What will I do if I can never make it again?
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Edith406"]
[OnName num="edith"]
(I'll lose my raison d'etre... and I'll be causing Kurth a lot of trouble...)
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Edith407"]
[OnName num="edith"]
What if they don't want it?
[cpg cn=true]



[free time=1000]


[SE f="se002"]
;//【ＳＥ】『扉を開ける』



[OnName num="kurto"]
"Ah, welcome back. Good work.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Edith408"]
[OnName num="edith"]
I'm back.
[cpg cn=true]


[OnName num="kurto"]
Were you holed up in the workshop again?
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Edith409"]
[OnName num="edith"]
Yeah, but... sorry ...... not at all...
[cpg cn=true]


[OnName num="kurto"]
No need to apologize. Oh, and this.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Edith410"]
[OnName num="edith"]
What? What is it?
[cpg cn=true]


[OnName num="kurto"]
Read it.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Edith411"]
[OnName num="edith"]
It's ..........
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Edith412"]
[OnName num="edith"]
This is .......
[cpg cn=true]


I asked the merchant who sells the equipment that Edith makes to take a survey.
[cpg]


Through the merchant, I received a lot of requests for the equipment she makes.
[cpg]


I just...gave it to them.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Edith413"]
[OnName num="edith"]
'Ughhhh...ughhhh...'
[cpg cn=true]


She burst into tears.
[cpg]


[OnName num="kurto"]
'Edith. You seem to blame yourself, but the adventurers who use your weapons and armor have a different opinion. It was your armor that saved me from death. It was your armor that kept you alive."
[cpg cn=true]



[VOICE f="Edith414"]
[OnName num="edith"]
"Uh...uh...uh...uh...uh...uh..."
[cpg cn=true]


[OnName num="kurto"]
"So don't be so hard on yourself. They're all waiting to see what you're going to make.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Edith415"]
[OnName num="edith"]
"......, thank you... thank you... thank you... Kurth."
[cpg cn=true]


[OnName num="kurto"]
I didn't do anything. It's all Edith's hard work and the honest feelings of all adventurers.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Edith416"]
[OnName num="edith"]
Still... it was Kurth who brought this to me.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Edith417"]
[OnName num="edith"]
Thank you, Kurth.
[cpg cn=true]


[OnName num="kurto"]
You're welcome."
[cpg cn=true]


Finally, she seems to have forgiven herself.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



Edito was able to make weapons and armor again.
[cpg]


He knew I was working behind his back, and he was ridiculously grateful.
[cpg]


It was somewhat embarrassing.
[cpg]


But I think our bond with each other has grown deeper because of this one incident.
[cpg]

;//移植のためシーンをカットしています


;//ブラックアウト


;//========================================
;//●ＣＧ（ピロートーク）ev_69
;//人物１：ヒロイン３　服装１：裸シーツ
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_69_0 ***********************
[CG id=24 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Edith437"]
[OnName num="edith"]
Kurth...I love you. I love you, I love you, I love you."
[cpg cn=true]


[OnName num="kurto"]
"Oh, oh. You're kind of aggressive, aren't you?
[cpg cn=true]



[VOICE f="Edith438"]
[OnName num="edith"]
Yeah, because I know I have to put it into words.
[cpg cn=true]



[VOICE f="Edith439"]
[OnName num="edith"]
I know that sometimes your feelings and everyone else's feelings... can't be conveyed if you just think about them.
[cpg cn=true]


[OnName num="kurto"]
Yeah, that's right.
[cpg cn=true]



[VOICE f="Edith440"]
[OnName num="edith"]
So from now on I'm going to say I love you a lot. I'm going to tell Kurth I love him.
[cpg cn=true]



[VOICE f="Edith441"]
[OnName num="edith"]
I'm embarrassed... but...
[cpg cn=true]


[OnName num="kurto"]
"Ha-ha-ha. I'm glad. I like you too, Edith.
[cpg cn=true]



[VOICE f="Edith442"]
[OnName num="edith"]
"Hehehe...I'm so happy. I'm very, very happy.
[cpg cn=true]


[OnName num="kurto"]
"But I'll show you with my actions, not just my words."
[cpg cn=true]



[VOICE f="Edith443"]
[OnName num="edith"]
"Oh, nn...nn...nn... Kurth, you're too naughty.
[cpg cn=true]


[OnName num="kurto"]
You don't like it?
[cpg cn=true]



[VOICE f="Edith444"]
[OnName num="edith"]
"No, I love it. I love you more than anything in the world.
[cpg cn=true]




;//ブラックアウト

[SCENE id=19]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ　ヒロイン３ルート
;//==============================
