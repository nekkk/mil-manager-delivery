*start
;#################################################
*Ep007|Unshakeable Anxiety
;#################################################
[SCENE id=7]

[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_tbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・専門書の部屋　昼（エントランスからの光）******************************************************

[WAIT time=1500]


[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 20th
[cpg]


[OnName num="Kenji"]
"Ngh..."
[cpg cn=true]

I woke up to the dim light coming into the room, the burned out wax had melted and hardened on the marble floor.
[cpg]

[OnName num="Kenji"]
"Ugh, it's cold."
[cpg cn=true]

Shivering, I got out of my blanket and quickly put on a jacket and left the room.
[cpg]


[BG f="b_l_1f_entrance_p2.ui" time=1000]
[WAIT time=1500]

;//（踊り場　胸像前で本を開き朗読する栞P.U）
[free time=1000]
;**【ＣＧ】ev_11_0 ***********************
[CG id=10 index=0 time=1000]
;*****************************************
[WAIT time=1000]


;//上った = のぼった

[BGM f="dod"]


[VOICE f="Shiori807"]
[OnName num="Shiori"]
"Humpty Dumpty sat on a wall. Humpty Dumpty had a great fall. All the King's horses and all the king's men, couldn't put humpty together again."
[cpg cn=true]

When I went out to the entrance, I found Shiori reading to the bust of her grandfather under the morning light pouring in through the skylight.
[cpg]

The way she looked so divine, like a saint reading from a Bible in church, made me hesitate to call out to her.
[cpg]

Then she caught me looking at her and closed the book with a snap.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）（踊り場　胸像前で本を開き朗読する栞P.U）******************************************************

[WAIT time=1500]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=800]

[OnName num="Kenji"]
"Morning."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori111"]
[OnName num="Shiori"]
"Good morning..."
[cpg cn=true]

[OnName num="Kenji"]
"Reading to him again?"
[cpg cn=true]

Shiori gave a small nod in response.
[cpg]

[OnName num="Kenji"]
"Just now, were those lyrics or something?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori112"]
[OnName num="Shiori"]
"Mother Goose..."
[cpg cn=true]

[OnName num="Kenji"]
"What's Mother Goose...?"
[cpg cn=true]

I asked, embarrassed to reveal my ignorance.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori113"]
[OnName num="Shiori"]
"They are nursery rhymes that have been passed down from generation to generation in English-speaking countries, mainly in England. When I was a child, my grandfather used to read them to me..."
[cpg cn=true]

[OnName num="Kenji"]
"They're nursery rhymes?"
[cpg cn=true]

Her grandfather used to read to her, and now, in return, Shiori reads the lyrics and dedicates them to her grandfather.
[cpg]

What she was doing seemed so nice.
[cpg]

[OnName num="Kenji"]
"But it's a nursery rhyme and you don't sing it?"
[cpg cn=true]

I'd like to hear Shiori sing it, and I wanted to try asking her to.
[cpg]

But...
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori114"]
[OnName num="Shiori"]
"A lot of the lyrics are still around, but the melodies haven't been passed down... The I read one just now, I also don't know the melody, so..."
[cpg cn=true]

She reluctantly replied.
[cpg]

[OnName num="Kenji"]
"Yeah... It's a little sad that the melodies for some nursery rhymes have been lost. But if there are a few melodies left, then there must be some nursery rhyme songs out there, right?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori115"]
[OnName num="Shiori"]
"There are some with their original melodies and some with ones added later. The most famous ones are, 'London Bridge is Falling' and 'Twinkle Twinkle Little Star', and 'Mary Had a Little Lamb'..."
[cpg cn=true]

[OnName num="Kenji"]
"Oh! So those are also from Mother Goose? I learned something new."
[cpg cn=true]

It was true that I learned something new, but more than that, I was happy to be able to talk with Shiori like this.
[cpg]

I was not interested in nursery rhymes or Mother Goose, but I was very interested in Shiori.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika277"]
[OnName num="Erika"]
"Ah~ It's cold, cold, cold!"
[cpg cn=true]

Then Erika, wrapping a blanket around her body, and Yuna, rubbing her arms without a blanket, appeared from upstairs.
[cpg]

[VOICE f="Yuna135"]
[OnName num="Yuna"]
"Good morning."
[cpg cn=true]

[OnName num="Kenji"]
"Morning."
[cpg cn=true]

.........
[cpg]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika278"]
[OnName num="Erika"]
"This chill is really no fun. I'm definitely going to catch a cold."
[cpg cn=true]

Erika said, shivering deliberately.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori116"]
[OnName num="Shiori"]
"I'm sorry... I wish there was a heater or something..."
[cpg cn=true]

Somehow the electrical system went haywire and the centrally-controlled air conditioning broke down, so we've been living in near-zero temperatures ever since.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi200"]
[OnName num="Michi"]
"Morning."
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_2" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Syouko041"]
[OnName num="Syouko"]
"Good morning~!"
[cpg cn=true]

Michi and Shoko emerged from the basement with different levels of enthusiasm, carrying food that was supposed to be breakfast.
[cpg]

And at about the same time, Hosokawa came out of his room.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa155"]
[OnName num="Hosokawa"]
"Oh, you're all up early. Good morning."
[cpg cn=true]

Hosokawa's usually neat and tidy hair had become more tousled and stiff each time he slept due to the product still left in his hair.
[cpg]

If he didn't wash his hardened hair by the end of the day, it was going to get dirty with dust and stuff...
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa156"]
[OnName num="Hosokawa"]
"Uh~..."
[cpg cn=true]

[SE f="se053"]
;//【ＳＥ】頭掻く
As expected, Hosokawa was scratching his head like he had an itch.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika279"]
[OnName num="Erika"]
"Let's go wash our faces, Yuna. I'm hungry."
[cpg cn=true]

[VOICE f="Yuna136"]
[OnName num="Yuna"]
"Yes. Excuse us."
[cpg cn=true]

[SE f="se044"]
;//【ＳＥ】小走りで立ち去る×２
[free time=1000]
[WAIT time=1000]
As Erika and Yuna headed for the bathroom to wash their faces, we got ready for breakfast.
[cpg]

[OnName num="Kenji"]
"What should we have this morning~?"
[cpg cn=true]

A wry smile crept up on my face as I realized that I was getting used to this situation.
[cpg]

On the other hand...
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko042"]
[OnName num="Syouko"]
"Ahaha, it's kind of like a training camp, it's fun!"
[cpg cn=true]

And Shoko's reaction was just like ours on the first day.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa157"]
[OnName num="Hosokawa"]
"Tomorrow you won't feel that way..."
[cpg cn=true]

Tomorrow...?
[cpg]

Hosokawa's comment was a little upsetting.
[cpg]

Did he think that no help was coming today?
[cpg]

Is he convinced that this will still be the case tomorrow?
[cpg]

Why...?
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko043"]
[OnName num="Syouko"]
"How many days has it been today, folks?"
[cpg cn=true]

Shoko asks, as if to reverse my anxiety.
[cpg]

If we included the day we got locked up, today would be...
[cpg]

;//■選択肢５（３択）
[switch]
[case "Day three"]
	[swap]
	[jump target="*s5_a"]
[case "Day four"]
	[swap]
	[jump target="*s5_b"]
[case "Day five"]
	[swap]
	[jump target="*s5_c"]
[endswitch]
;//１，３日目　//５aへ
;//２，４日目　//５bへ
;//３，５日目　//５cへ
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//５a　３日目
*s5_a|Unshakeable Anxiety
[OnName num="Kenji"]
"It's day three...?"
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi201"]
[OnName num="Michi"]
"It's day four. Keep it together."
[cpg cn=true]

[OnName num="Kenji"]
"Huh, is that so..."
[cpg cn=true]

A lot of things have happened, and being in a dimly lit space all the time seems to have shifted my senses.
[cpg]

I needed to be more careful.
[cpg]


;//５dへ合流
[jump target="*s5_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//５b　４日目
*s5_b|Unshakeable Anxiety
[OnName num="Kenji"]
"It's been four days."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko044"]
[OnName num="Syouko"]
"What, four days?"
[cpg cn=true]

Even though she had heard about the number of days yesterday, Shoko was overly surprised.
[cpg]

I wondered if her memory was reset every time she went to bed.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko045"]
[OnName num="Syouko"]
"Um, when will we be able to get out of here...?"
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi202"]
[OnName num="Michi"]
"That's what I want to know..."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko046"]
[OnName num="Syouko"]
"I'll be in trouble if I can't get out..."
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi203"]
[OnName num="Michi"]
"Same goes for everyone..."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko047"]
[OnName num="Syouko"]
"Ah..."
[cpg cn=true]

Hmm?
[cpg]

I had a sudden realization and stared at Shoko.
[cpg]

She was still in her nurse's uniform.
[cpg]

That meant...!
[cpg]

[OnName num="Kenji"]
"Ms. Endo, you came from the hospital, right?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko048"]
[OnName num="Syouko"]
"Yes, I did, but..."
[cpg cn=true]

[OnName num="Kenji"]
"Then if you don't return, won't the people at the hospital get worried and come looking for you!"
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa158"]
[OnName num="Hosokawa"]
"!"
[cpg cn=true]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi204"]
[OnName num="Michi"]
"!"
[cpg cn=true]

All eyes were on Shoko.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko049"]
[OnName num="Syouko"]
"It's just that...um..."
[cpg cn=true]

We were all looking at Shoko expectantly, and she started to mumble while thinking about something.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko050"]
[OnName num="Syouko"]
"I...am taking a winter vacation starting today, in exchange for three days of work..."
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi205"]
[OnName num="Michi"]
"And?!  Were you planning to go back to the countryside? If so, your parents must be worried about you..."
[cpg cn=true]

Shiori and I nodded our heads while waiting for Shoko's response.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko051"]
[OnName num="Syouko"]
"Ah~ I had no plans to go home, I was going to watch all my DVD rentals at once..."
[cpg cn=true]

[OnName num="Kenji"]
"Huh~..."
[cpg cn=true]

Our hopes were cruelly dashed.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa159"]
[OnName num="Hosokawa"]
"But you came in your uniform, and you weren't planning to go straight home, were you?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko052"]
[OnName num="Syouko"]
"I was going to go straight home... I'm sorry. My house is close by..."
[cpg cn=true]

Unbelievable...
[cpg]


;//５dへ合流
[jump target="*s5_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//５c　５日目
*s5_c|Unshakeable Anxiety
[OnName num="Kenji"]
"Um, actually, I think it's day...five."
[cpg cn=true]



[FG f="CHA01_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Shiori117"]
[OnName num="Shiori"]
"Day four..."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, is it really...?"
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa160"]
[OnName num="Hosokawa"]
"Keep it together."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko053"]
[OnName num="Syouko"]
"If I'd known this was going to happen, I would've brought a ton of food."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi206"]
[OnName num="Michi"]
"Why don't you think about what you're saying before you say it..."
[cpg cn=true]

I agreed with Michi.
[cpg]

If you knew, you should have called for help, not food!
[cpg]


;//５dへ合流
[jump target="*s5_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//５d
*s5_d|Unshakeable Anxiety
[SE f="se054"]
;//【ＳＥ】走って来る×２

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika280"]
[OnName num="Erika"]
"Hey, hey, hey!"
[cpg cn=true]

Then, Erika and Yuna, who had finished washing their faces, came running in, gasping for breath.
[cpg]

[OnName num="Kenji"]
"What's going on?"
[cpg cn=true]

[VOICE f="Erika281"]
[OnName num="Erika"]
"Nurse!"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko054"]
[OnName num="Syouko"]
"Yes!"
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna137"]
[OnName num="Yuna"]
"Hey! Don't you have a cell phone?!"
[cpg cn=true]


[OnName num="Kenji"]
"Ah!!"
[cpg cn=true]

I was so busy yesterday that I forgot to check.
[cpg]

However, Erika and Yuna seemed to have noticed it and quickly leaned towards Shoko.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko055"]
[OnName num="Syouko"]
"A cell phone? I have one??"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi207"]
[OnName num="Michi"]
"Why didn't you say that earlier?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko056"]
[OnName num="Syouko"]
"What? Huh? You didn't ask..."
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika282"]
[OnName num="Erika"]
"Oh, my God! Just up and pull it out!"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna138"]
[OnName num="Yuna"]
"Please call for help!"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko057"]
[OnName num="Syouko"]
"Ye-ye-yesー!"
[cpg cn=true]

How long was she going to sit on that?!
[cpg]

If she had a cell phone, she could have called for help yesterday!
[cpg]

However, now was not the time to lay blame.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko058"]
[OnName num="Syouko"]
"Let's see, let's see..."
[cpg cn=true]

Shoko took her phone out of her pocket and turned it on.
[cpg]

The familiar electronic device now looked like a magical tool.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika283"]
[OnName num="Erika"]
"Make a call now! I don't care if it's the police or the fire department!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko059"]
[OnName num="Syouko"]
"O-okay!"
[cpg cn=true]

[STOPBGM]

;//＠
[SE f="se055"]
;//【ＳＥ】ボタンプッシュ三桁

[WAIT time=6000]

[SE f="se056"]
;//【ＳＥ】コール　～　繋がる

[WAIT time=1000]
[FG f="CHA08_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa161"]
[OnName num="Hosokawa"]
"It's connected!"
[cpg cn=true]

[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko060"]
[OnName num="Syouko"]
"Oh! Hello! You see...!"
[cpg cn=true]

Shoko began to speak hurriedly, and we watched with bated breath.
[cpg]

Then...
[cpg]

[SE f="se057"]
;//【ＳＥ】時報「ピッ、ピッ、ピッ、ポーン」

[WAIT time=5500]


[OnName num="unknown"]
"The time is now 8:00..."
[cpg cn=true]

[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko061"]
[OnName num="Syouko"]
"Huh...?"
[cpg cn=true]

[OnName num="Kenji"]
"Aren't you just listening to a time announcement?!"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko062"]
[OnName num="Syouko"]
"I'm sorry, my bad!"
[cpg cn=true]

[SE f="se058"]
;//【ＳＥ】電話切る

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika284"]
[OnName num="Erika"]
"Are you nuts?!"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna139"]
[OnName num="Yuna"]
"Call 110 or 119."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko063"]
[OnName num="Syouko"]
"Um... Oh, yeah!"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi208"]
[OnName num="Michi"]
"Hurry up and call!"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko064"]
[OnName num="Syouko"]
"Ye-yes! Huh? It's..."
[cpg cn=true]

[OnName num="Kenji"]
"Hmm?"
[cpg cn=true]

Shoko, who was simultaneously being shouted at and blamed by everyone around her, immediately tried to use the phone again, but froze when she saw the screen.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika285"]
[OnName num="Erika"]
"What are you doing? Give me that!"
[cpg cn=true]

Out of frustration, Erika eventually took away the phone from Shoko, and...looked at the screen.
[cpg]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika286"]
[OnName num="Erika"]
"Wahー!!"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna140"]
[OnName num="Yuna"]
"W-what? What's wrong?"
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika287"]
[OnName num="Erika"]
"The ba-battery...!"
[cpg cn=true]

I hurriedly looked at the phone, and a red warning mark flickered, and it mercilessly displayed a message.
[cpg]

"Please charge."
[cpg]

And to top it all off...
[cpg]

[SE f="se059"]
;//【ＳＥ】ブツッ（※本来音はしませんが、分かり易くOFFを表現）

[WAIT time=1000]

[OnName num="Kenji"]
"It's d-dead...!"
[cpg cn=true]

[BGM f="serious"]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna141"]
[OnName num="Yuna"]
"Eh..."
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa162"]
[OnName num="Hosokawa"]
"No way..."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko065"]
[OnName num="Syouko"]
"Oh..."
[cpg cn=true]

Unbelievable...
[cpg]

Why would the battery go dead at a time like this...?
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika288"]
[OnName num="Erika"]
"Heyー!"
[cpg cn=true]

Erika, who had been given some hope, became extremely angry.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika289"]
[OnName num="Erika"]
"Why is it that the battery is dead?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko066"]
[OnName num="Syouko"]
"Well, the thing is..., I'm addicted to this puzzle app..."
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika290"]
[OnName num="Erika"]
"That's not what I asked you! Idiotー!"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko067"]
[OnName num="Syouko"]
"I'm s-sorry."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi209"]
[OnName num="Michi"]
"You are simply unbelievable..."
[cpg cn=true]

.........
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna142"]
[OnName num="Yuna"]
"Oh..."
[cpg cn=true]

It's good that Erika was still able to convert her disappointment into anger.
[cpg]

The rest of us could only sit back and be disappointed.
[cpg]

If we didn't have a mobile phone to begin with, we wouldn't have fallen so far, but the shock of getting back up only to be pushed down again was too much.
[cpg]

In addition, once there was a signal...she got a time announcement.
[cpg]

At least if it had been directory assistance, we might have been able to work something out...sigh.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko068"]
[OnName num="Syouko"]
"My apologies...Really..."
[cpg cn=true]

[STOPBGM]

[FG f="CHA08_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa163"]
[OnName num="Hosokawa"]
".................."
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna143"]
[OnName num="Yuna"]
".................."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko069"]
[OnName num="Syouko"]
"I'm sorry..."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi210"]
[OnName num="Michi"]
".................."
[cpg cn=true]

She received the silent treatment from everyone.
[cpg]

The sight of Shoko apologizing by bowing deeply to everyone individually made me feel sorry for her, even though she deserved it.
[cpg]

[BGM f="dod"]

[OnName num="Kenji"]
"A-ah! I'm starving! Let's eat breakfast! Come on, everyone. Now, what should we eat today?"
[cpg cn=true]

[SE f="se024"]
;//【ＳＥ】柏手

Unable to bear the heavy atmosphere, I deliberately raised my voice cheerfully.
[cpg]

[OnName num="Kenji"]
"Whoa! I didn't know there were canned croissants."
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi211"]
[OnName num="Michi"]
"Let's make coffee."
[cpg cn=true]

Realizing my intentions, Michi also spoke up and lit a simple stove for me.
[cpg]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna144"]
[OnName num="Yuna"]
"Erika, look. A can of...peaches. Do you want some?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika291"]
[OnName num="Erika"]
"I do! Because fruit in the morning is the best!"
[cpg cn=true]

Yuna also made an effort to put Erika in a good mood, and managed to get breakfast.
[cpg]

Shoko looked apologetic the whole time, but as everyone gradually moved on, her hunched back began to straighten a bit.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_4" pos="3/3" time=800]

[SE f="se053"]
;//【ＳＥ】頭掻く
[WAIT time=1000]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika292"]
[OnName num="Erika"]
"Hey! Don't scratch your head in the middle of breakfast, that's dirty!"
[cpg cn=true]

While eating, Erika warned Hosokawa who was scratching his head.
[cpg]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa164"]
[OnName num="Hosokawa"]
"Even if you say that, I can't help it..."
[cpg cn=true]

I don't commend his behavior, but I understand the itch.
[cpg]

My scalp is a little itchy and dirty too.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi212"]
[OnName num="Michi"]
"If we at least had hot water..."
[cpg cn=true]

Of course, there was no bath in the library.
[cpg]

It was not meant to be used like this, so the only water we had access to is tap water.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko070"]
[OnName num="Syouko"]
"Well..., why don't I boil some water on this stove, and you can wash your head with it...?"
[cpg cn=true]

Oh, right...
[cpg]

I looked at the small kettle that was now on the fire for coffee.
[cpg]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi213"]
[OnName num="Michi"]
"It's going to take a very long time, but... Do you want to try it?"
[cpg cn=true]

A small kettle that could only boil a couple of cups at most.
[cpg]

I wondered how long it would take to boil enough water for everyone to wash their heads with it?
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa165"]
[OnName num="Hosokawa"]
"Well, I think I'll take you up on that offer. I couldn't care less about my body, but I can't take my head anymore."
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi214"]
[OnName num="Michi"]
"There's no shampoo, but we have soap. Ms. Endo, please help later."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko071"]
[OnName num="Syouko"]
"Roger that!"
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi215"]
[OnName num="Michi"]
"If anyone else wants to wash their hair or wipe their body, let's take turns."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna145"]
[OnName num="Yuna"]
"What should I do...?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika293"]
[OnName num="Erika"]
"I want to wash my hair, but do you have a hair dryer?"
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi216"]
[OnName num="Michi"]
"Unfortunately, no."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika294"]
[OnName num="Erika"]
"I figured..."
[cpg cn=true]

Guys didn't need much, but it must be hard for women with long hair.
[cpg]

Once they finish washing their hair, they might catch a cold afterwards.
[cpg]

As I thought about it, the food in front of me gradually dwindled.
[cpg]

Shiori also seemed to be able to eat a little bit of bread this morning.
[cpg]



;//＠
;//※＜缶詰フラグ＞が立っている場合、以下破線内の文章が挿入される
[if exp={getFlagValue("Canning") > 0 }]
[jump target="*j1_a"]
[else]
[jump target="*j1_c"]
[endif]



;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～

*j1_a|Unshakeable Anxiety

Oh, speaking of which...
[cpg]

;//＠
;//昨夜の缶詰を抱えたコトハ
Shiori went upstairs yesterday with a can of food in the middle of the night.
[cpg]

I wonder if that was a late-night snack?
[cpg]

Maybe her weak constitution only allowed her to eat a little at a time.
[cpg]

But whatever the case, I thought, if she could eat something outside of mealtime, there was no need to worry about her small appetite.
[cpg]

In addition, the food here really only belonged to Shiori, so she had the right to eat freely at any time.
[cpg]

There was nothing strange about taking food out in the middle of the night.
[cpg]

Just...
[cpg]

;//昨夜の缶詰を抱えたコトハ
I could understand the canned goods, but what was in the other bag she had?
[cpg]

It looked a little heavy, it was big, and it was something that needed to be taken from the basement to her room...
[cpg]

If she had told me, I could have helped her.
[cpg]

;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～

*j1_c|Unshakeable Anxiety

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna146"]
[OnName num="Yuna"]
"Thank you for the food."
[cpg cn=true]



[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika295"]
[OnName num="Erika"]
"Oh, is that all you're having for breakfast?"
[cpg cn=true]

When Erika saw that Yuna had finished eating, she looked surprised.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika296"]
[OnName num="Erika"]
"I'm not hungry at all."
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna147"]
[OnName num="Yuna"]
Well, That's not the same thing as being full..."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika297"]
[OnName num="Erika"]
"I want to eat more! I'm still hungry after all."
[cpg cn=true]

Erika had eaten bread and canned peaches and was still hungry.
[cpg]

How much was she planning on eating this morning?
[cpg]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi217"]
[OnName num="Michi"]
"I'm sorry, but I need you to stick to what you're given. It's not like we have an endless supply."
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa166"]
[OnName num="Hosokawa"]
"Oh, yeah... There's that..."
[cpg cn=true]

When Hosokawa heard Michi's words, his face turned pale and he muttered in a voice only I could hear.
[cpg]

[OnName num="Kenji"]
"What's that?"
[cpg cn=true]

When I asked about that, it was something horrible that I didn't even want to think about.
[cpg]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa167"]
[OnName num="Hosokawa"]
"You don't know how long we're going to be trapped in here. If we run out of food before help arrives..."
[cpg cn=true]

[OnName num="Kenji"]
"You can't be serious...We can't..."
[cpg cn=true]

The end of that sentence was not uttered by Hosokawa, so I did not finish mine either.
[cpg]

However, the phrase...'starve to death' was coming to mind.
[cpg]

I never thought we would...starve to death in a place like this.
[cpg]

I've heard that people can live for a month on water alone..., so we were okay.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika298"]
[OnName num="Erika"]
"I can't think straight if I don't eat because I'm still a growing teenager!"
[cpg cn=true]

As I tried to overcome my anxiety, Erika was still pouting.
[cpg]

She knows full well that our rations are limited...
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika299"]
[OnName num="Erika"]
"I want to eat! I'm hungry! I want more food!"
[cpg cn=true]


;//[free time=900]
;//[BG f="black.ui" time=900]
;//[WAIT time=1500]
;//[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）

;//[WAIT time=1500]

;//[FG f="CHA05_p3_01_a.ui" method="change_4" pos="1/3" time=800]
;//[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
;//[FG f="CHA04_p3_01_a.ui" method="change_4" pos="3/3" time=800]

[OnName num="Kenji"]
"Shut up. We're all trying to hold back."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika300"]
[OnName num="Erika"]
"I want to eat! I want to eat! I want to eat...ah! That's right!"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna148"]
[OnName num="Yuna"]
"What?"
[cpg cn=true]

As if something suddenly struck her, Erika's eyes shone brightly.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika301"]
[OnName num="Erika"]
"That guy, he always had a chocolate bar, didn't he? Isn't there one in his pocket?"
[cpg cn=true]

[OnName num="Kenji"]
"That guy...you don't mean..."
[cpg cn=true]

At this time, I could not help but question Erika's sanity.
[cpg]

Odds are, she wants to...Takagi is dead, so Erika wants to get a chocolate bar out of the corpse's pocket.
[cpg]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna149"]
[OnName num="Yuna"]
"Well, I don't know about th-that..."
[cpg cn=true]

Yuna also stopped Erika, but her mind was never easily changed.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika302"]
[OnName num="Erika"]
"What? He can't eat it anymore anyway, so why not just let me have it?"
[cpg cn=true]

When he was still alive, she would never have taken it even if he offered, but now that he's dead, she's going to have it...
[cpg]

How self-centered.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa168"]
[OnName num="Hosokawa"]
"But, well..., food is food, so I guess it's okay."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika303"]
[OnName num="Erika"]
"Right? Let's go. The sooner the better!"
[cpg cn=true]

[SE f="se069"]
;//【ＳＥ】駆け出す

[move from="2/3" to="5/3" ease="easeInOutSine" time=1000]
[WAIT time=500]
[FACE method="change_5" pos="1/3"]

[WAIT time=100]
[VOICE f="Michi218"]
[OnName num="Michi"]
"Hey, wait!"
[cpg cn=true]

[OnName num="Kenji"]
"It's no use..."
[cpg cn=true]

We reluctantly got up and followed Erika.
[cpg]

If she could run that fast, she probably didn’t need to eat a chocolate bar right now.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=2000]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）******************************************************

[WAIT time=1500]

[FG f="CHA03_p3_01_a.ui" method="change_7" pos="2/3" time=800]

When we arrived at the infirmary, we found Erika standing there with a strange look on her face.
[cpg]

[OnName num="Kenji"]
"Hey, what's wrong? Isn't there a chocolate bar? Just because you don't want to touch the corpse doesn't mean you're going to make me get it."

[cpg cn=true]

[STOPBGM]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika304"]
[OnName num="Erika"]
"Where is it?"
[cpg cn=true]

Instead of answering my words, Erika asked me a mysterious question.
[cpg]

[OnName num="Kenji"]
"Huh? What?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika305"]
[OnName num="Erika"]
"The body, where'd you put it?"
[cpg cn=true]

[OnName num="Kenji"]
"What do you mean 'where'...huh?"
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa169"]
[OnName num="Hosokawa"]
"It's n-not here. The body's gone!"
[cpg cn=true]

[SE f="se088"]
;//【ＳＥ】ショック

;//ステンレス台（※以下、便宜上、指示では解剖台と表記）


[FG f="CHA05_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi219"]
[OnName num="Michi"]
"What the hell? Move out of the way!"
[cpg cn=true]

A little later Michi arrived and went right between us.
[cpg]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi220"]
[OnName num="Michi"]
"N-no..., why... Where did it go?"
[cpg cn=true]

Yesterday, while Hosokawa and I were struggling, we put Takagi's body on the stainless steel table.
[cpg]

But now, there was not a single trace of that huge body on the table.
[cpg]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa170"]
[OnName num="Hosokawa"]
"I'm sure it was here yesterday! Right, Azuma?"
[cpg cn=true]

[OnName num="Kenji"]
"That's right, we put him on his back!"
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi221"]
[OnName num="Michi"]
"Indeed... It was there when I checked last night..."
[cpg cn=true]

Michi slept in Shiori's room but she checked on it before she went to bed.
[cpg]

;//＠
;//【ＢＧＭ】どんよりした恐怖
[BGM f="huan"]
[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika306"]
[OnName num="Erika"]
"What the hell..., what the hell is happening?"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna150"]
[OnName num="Yuna"]
"You don't think... He is actually still alive, or something..."
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

Everyone, except Michi, turned pale with astonishment at that outlandish theory.
[cpg]

But...
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi222"]
[OnName num="Michi"]
"No, he was definitely dead. As of this morning, rigor mortis had set in, and there was no way he was going to come back to life."
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa171"]
[OnName num="Hosokawa"]
"So, you know..."
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko072"]
[OnName num="Syouko"]
"Well..., then..., what are the other possibilities for the body's disappearance?"
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi223"]
[OnName num="Michi"]
"Well, anyway you look at it, someone's got to have taken it, right?"
[cpg cn=true]

Michi looked at me and Hosokawa quietly.
[cpg]

[OnName num="Kenji"]
"Well..., it wasn't us!"
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi224"]
[OnName num="Michi"]
"I know, but common sense dictates that it's impossible for a woman to carry the weight of Takagi's body..."
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa172"]
[OnName num="Hosokawa"]
"I can't either! Especially...not by myself."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko073"]
[OnName num="Syouko"]
"But the two of you could carry it, right?"
[cpg cn=true]

With bad intentions..., or probably not, Shoko tilted her head and asked Hosokawa.
[cpg]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa173"]
[OnName num="Hosokawa"]
"If we could carry it, why would we need to hide the body?"
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, that's right! What's the point of doing that?"
[cpg cn=true]

What would be the point...?
[cpg]

If someone hid the body, what good would it do?
[cpg]

When I thought about it, I felt bad, as if a great, yet unknown, fear was crawling up from under my feet.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika307"]
[OnName num="Erika"]
"Hey, didn't you hide the body so that people wouldn't find out that you kept his chocolate bar all to yourself?"
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa174"]
[OnName num="Hosokawa"]
"What?!"
[cpg cn=true]

With a rather calm expression, Erika thrusted her index finger into Hosokawa's chest.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika308"]
[OnName num="Erika"]
"If the body was still there, we'll figure out at some point that there's no chocolate bar in the pocket. You are the culprit who took the chocolate bar and hid the body to hide the evidence!"
[cpg cn=true]

;//[SE f="se000"]
;//【ＳＥ】ジャジャーン
;//[WAIT time=2000]


[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko074"]
[OnName num="Syouko"]
"Oh!"
[cpg cn=true]

[OnName num="Kenji"]
"Hmm..."
[cpg cn=true]

[free time=1]
[WAIT time=1]

[FG f="CHA05_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Michi225"]
[OnName num="Michi"]
"Sigh..."
[cpg cn=true]

.........
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna151"]
[OnName num="Yuna"]
"I don't know about that..."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa175"]
[OnName num="Hosokawa"]
"There's no other way of looking at it?"
[cpg cn=true]

Hosokawa's anger was understandable.
[cpg]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa176"]
[OnName num="Hosokawa"]
"What's with that weird crime theory?! Who would you go to the trouble of carrying that huge body for something like that?"
[cpg cn=true]

True, the calories someone would burn carrying that huge body were far more than those found in a chocolate bar.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko075"]
[OnName num="Syouko"]
"Just now, I really got into all that detective work, but was that...wrong?"
[cpg cn=true]

[OnName num="Kenji"]
"It's unlikely. I'm pretty sure Hosokawa said he doesn't like sweets, and he is allergic to peanuts..."
[cpg cn=true]

I said, remembering that Takagi and Hosokawa had had that conversation before.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA08_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Hosokawa177"]
[OnName num="Hosokawa"]
"Y-yeah! I'm allergic! So there's no way I'd steal a chocolate bar with peanuts in it!"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=1]
[move from="4/5" to="3/5" ease="easeInOutSine" time=1000]
[WAIT time=100]
[VOICE f="Hosokawa1177"]
[OnName num="Hosokawa"]
"Believe me, Ms. Kisaragi, you know I'm not a liar, right?"
[cpg cn=true]


Hosokawa stared pleadingly at Michi, and even held her hand, taking advantage of the confusion.
[cpg]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi226"]
[OnName num="Michi"]
"It depends on how allergic you are..."
[cpg cn=true]

[FACE method="change_3" pos="3/5"]
[WAIT time=100]
[VOICE f="Hosokawa178"]
[OnName num="Hosokawa"]
"I'm deathly allergic!"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi227"]
[OnName num="Michi"]
"Then, you wouldn't eat it."
[cpg cn=true]

[FACE method="change_2" pos="3/5"]
[WAIT time=100]
[VOICE f="Hosokawa179"]
[OnName num="Hosokawa"]
"Thank you very much. Ah, Ms. Kisaragi understands me very well after all..."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi228"]
[OnName num="Michi"]
"H-hold on..."
[cpg cn=true]

Hosokawa closes the distance between them, holding Michi's hand with a zealous grip.
[cpg]

His crescent-shaped eyes became even more disgustingly distorted.
[cpg]

Michi seemed to be in trouble, but what could I do...
[cpg]

;//■選択肢６（３択）
[switch]
[case "Get Erika"]
	[swap]
	[jump target="*s6_a"]
[case "Get Shoko"]
	[swap]
	[jump target="*s6_b"]
[case "Stop it myself"]
	[swap]
	[jump target="*s6_c"]
[endswitch]
;//１，エリカをけしかける　//６aへ
;//２，章子に頼む　　　　　//６bへ
;//３，自分が止めに入る　　//６cへ
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//６a　エリカをけしかける
*s6_a|Unshakeable Anxiety
[OnName num="Kenji"]
"Hey, Erika... Isn't he a bit..., you know?"
[cpg cn=true]


[VOICE f="Erika309"]
[OnName num="Erika"]
"Yeah! He's so creepy."
[cpg cn=true]

He reacted to Erika's words immediately.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[move from="2/5" to="1/3" ease="easeInOutSine" time=1000]
[move from="3/5" to="3/3" ease="easeInOutSine" time=1000]

[WAIT time=100]
[VOICE f="Erika310"]
[OnName num="Erika"]
"Hey! Stop molesting her!"
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa180"]
[OnName num="Hosokawa"]
"Molesting? I didn't mean to..."
[cpg cn=true]

When Erika yelled at him, Hosokawa let go of his grip on Michi's hand.
[cpg]


[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika311"]
[OnName num="Erika"]
"Even if you don't mean to, if the person you're touching thinks you're being a pervert, you're a pervert! Like sexual harassment!"
[cpg cn=true]

[VOICE f="Erika1311"]
[OnName num="Erika"]
"If you become a doctor, nurses and patients will be molested all the time, how gross! Hey, nurse, aren't there doctors who are perverts?"
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_3" pos="3/4" time=800]
[move from="1/3" to="1/4" ease="easeInOutSine" time=1000]
[move from="2/3" to="2/4" ease="easeInOutSine" time=1000]
[move from="3/3" to="4/4" ease="easeInOutSine" time=1000]
[WAIT time=100]
[VOICE f="Syouko076"]
[OnName num="Syouko"]
"There are! Just because they're doctors, these old creeps think they can do anything they want!"
[cpg cn=true]

Erika embarrassed Hosokawa by getting Shoko involved.
[cpg]

What a good job.
[cpg]

In this kind of situation, Erika is just the right assassin for the job.
[cpg]

[FACE method="change_5" pos="4/4"]
[WAIT time=100]
[VOICE f="Hosokawa181"]
[OnName num="Hosokawa"]
"M-me..., an o-old creep?!"
[cpg cn=true]

Hosokawa, who had turned red and pulled away from Michi, glared at Erika with an abhorrent look.
[cpg]

[FACE method="change_7" pos="1/4"]
[WAIT time=100]
[VOICE f="Michi229"]
[OnName num="Michi"]
"Huh..."
[cpg cn=true]

As if relieved, Michi tucked her hands into the pockets of her lab coat and glanced toward the sink.
[cpg]

There was hand sanitizer there.
[cpg]

She definitely wanted to wash...her hands.
[cpg]

When I realized that, I felt bad for Hosokawa, but I started to laugh.
[cpg]

[FACE method="change_4" pos="4/4"]
[WAIT time=100]
[VOICE f="Hosokawa182"]
[OnName num="Hosokawa"]
"What's so funny...?"
[cpg cn=true]

[OnName num="Kenji"]
"Nothing...pfft..."
[cpg cn=true]

[FACE method="change_1" pos="1/4"]


;//６dへ合流
[jump target="*s6_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//６b　章子に頼む
*s6_b|Unshakeable Anxiety
[OnName num="Kenji"]
Ms. Endo, don't you think you should stop this...? It's..."
[cpg cn=true]


[VOICE f="Syouko077"]
[OnName num="Syouko"]
What? Oh, you're right. Leave it to me!"
[cpg cn=true]

When I overheard her, Shoko thumped her chest and straightened her posture.
[cpg]

She then walked over to the sink and picked up a plastic bottle that had been placed there.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[move from="2/5" to="1/3" ease="easeInOutSine" time=1000]
[move from="3/5" to="3/3" ease="easeInOutSine" time=1000]
[WAIT time=100]
[VOICE f="Syouko078"]
[OnName num="Syouko"]
"There are about 150 different types of bacteria that live on our hands! Here! Doctor, take this!"
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi230"]
[OnName num="Michi"]
"Oh, th-thank...you..."
[cpg cn=true]

Michi quickly shook off Hosokawa's hand, pressed the pump on the bottle she was offered, and rubbed the liquid into her hands.
[cpg]

It appeared to be hand sanitizer, and Hosokawa's eyes widened in shock.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA03_p3_01_a.ui" method="change_2" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_2" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika312"]
[OnName num="Erika"]
"Ahahaha! Nice!"
[cpg cn=true]

[WAIT time=100]
[VOICE f="Yuna152"]
[OnName num="Yuna"]
"Giggle...!"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa183"]
[OnName num="Hosokawa"]
"H-hey...!"
[cpg cn=true]

As Erika and Yuna began to laugh, Hosokawa, realizing that the idea was that his hands were filthy, turned bright red and glared at Shoko.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko079"]
[OnName num="Syouko"]
"Keep your hands clean or you'll get sick ♪"
[cpg cn=true]

It's not exactly what I wanted to say, but it turned out okay.
[cpg]

I'm glad Shoko was there.
[cpg]
[FACE method="change_1" pos="1/3"]


;//６dへ合流
[jump target="*s6_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//６c　自分が止めに入る
*s6_c|Unshakeable Anxiety
[OnName num="Kenji"]
"Well~, Hosokawa! I'm glad you were cleared of any suspicion!"
[cpg cn=true]

[SE f="se045"]
;//【ＳＥ】ドンッ！
[free time=800]
[WAIT time=800]

[FG f="CHA08_p3_01_a.ui" method="change_5" pos="2/3" time=800]
I stepped in between him and Michi as if I were going to hit Hosokawa, and I grabbed his hand, which he quickly pulled away.
[cpg]

[SE f="se060"]
;//【ＳＥ】ギュゥゥ
[WAIT time=1000]
[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa184"]
[OnName num="Hosokawa"]
"Ou...ouch."
[cpg cn=true]

Then I exaggeratedly claimed credit for the discovery, without regard for Hosokawa's scowl.
[cpg]

[OnName num="Kenji"]
"It's good that I noticed the peanuts~. Oh~, Mr. Hosokawa, that kind of thing is important to know~!"
[cpg cn=true]

[SE f="se060"]
;//【ＳＥ】ギュゥゥ

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa185"]
[OnName num="Hosokawa"]
"Yes, th-thank you... You saved me..."
[cpg cn=true]

[OnName num="Kenji"]
"You're welcome! Hahaha!"
[cpg cn=true]

He genuinely thanked me, so I decided to cut him some slack.
[cpg]

But I did not enjoy holding another man's hand...sigh.
[cpg]

.........
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi231"]
[OnName num="Michi"]
"I'm sure we have plenty to talk about, but for now, let's head back to the first floor."
[cpg cn=true]

After regaining her composure, Michi chased everyone out of the room.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika313"]
[OnName num="Erika"]
"A-ah..., my chocolate bar..."
[cpg cn=true]

It wasn't yours.
[cpg]

Erika's concern was not for the whereabouts of the corpse, but the whereabouts of the chocolate bar of the man who she had called creepy and disgusting.
[cpg]

[free time=1000]
[WAIT time=2000]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi232"]
[OnName num="Michi"]
"Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"Yes?"
[cpg cn=true]

When everyone left the room, Michi stopped me at the end of the line.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi233"]
[OnName num="Michi"]
"I'd like to thank you for your help earlier. You saved me."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, no... I'm sorry if that was out of line."
[cpg cn=true]

For a moment, I wondered if I was too quick to come to the conclusion that Michi disliked me.
[cpg]

But, it seemed that was not the case since Michi was smiling.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi234"]
[OnName num="Michi"]
"It was not out of line. I don't think anything of Mr. Hosokawa."
[cpg cn=true]

[OnName num="Kenji"]
"I'm glad to hear that."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi235"]
[OnName num="Michi"]
"Well..., let's go."
[cpg cn=true]

[OnName num="Kenji"]
"Ah, yes."
[cpg cn=true]




;//６eへ合流
[jump target="*s6_e"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//６d
*s6_d|Unshakeable Anxiety


[WAIT time=100]
[VOICE f="Michi236"]
[OnName num="Michi"]
"I'm sure we have plenty to talk about, but for now, let's head back to the first floor."
[cpg cn=true]

After regaining her composure, Michi chased everyone out of the room.
[cpg]


[free time=1000]
[WAIT time=1500]

[FG f="CHA03_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika314"]
[OnName num="Erika"]
"A-ah, where did it go...?"
[cpg cn=true]

It wasn't the whereabouts of the body that the disgruntled Erika was concerned about, but the chocolate bar.
[cpg]

[move from="2/5" to="5/3" ease="easeInOutSine" time=1000]
[move from="4/5" to="6/3" ease="easeInOutSine" time=1000]


;//[free time=1000]
[WAIT time=3000]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi237"]
[OnName num="Michi"]
"Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"Huh?"
[cpg cn=true]

When everyone left the room, Michi stopped me at the end of the line.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi238"]
[OnName num="Michi"]
"Thank you for what you did. You're the one who got Erika involved, aren't you? You saved me."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, no... I'm sorry if that was out of line."
[cpg cn=true]

For a moment, I wondered if I'd been too quick to come to the conclusion that Michi didn't like me.
[cpg]

But, it seemed that was not the case since Michi was smiling.
[cpg]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi239"]
[OnName num="Michi"]
"It was not out of line. You're so much nicer than Hosokawa."
[cpg cn=true]

[OnName num="Kenji"]
"What...?"
[cpg cn=true]

[free time=2000]


Then Michi walked up the stairs.
[cpg]

"You're much nicer."
[cpg cn=true]

No way, did that mean...that she...
[cpg]

No, I needed to calm down. That's impossible.
[cpg]

I pushed down my growing paranoia and followed the others.
[cpg]


;//６eへ合流
[jump target="*s6_e"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//６e
*s6_e|Unshakeable Anxiety

[STOPBGM]
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）******************************************************

[WAIT time=1500]

[BGM f="library"]


When I returned to the first floor, there was no one at the entrance, and my feet inevitably went to the general collection room.
[cpg]

Then I saw the figures of Erika and Yuna near the entrance, and approached them.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_7" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika315"]
[OnName num="Erika"]
"...right? Isn't it...?"
[cpg cn=true]

[WAIT time=100]
[VOICE f="Yuna153"]
[OnName num="Yuna"]
"But..."
[cpg cn=true]

[OnName num="Kenji"]
"Hey, what are you talking about?"
[cpg cn=true]

When I called out to her, Erika frowned, which was unusual...
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika316"]
[OnName num="Erika"]
"It's none of Kenji's business. Go away for a while."
[cpg cn=true]

And then she waved her hands to keep me away.
[cpg]

[OnName num="Kenji"]
"What a weirdo!"
[cpg cn=true]

[free time=2000]
[WAIT time=1000]
If they wanted to talk in private, why didn't they go do it in the corner instead of the entrance?
[cpg]

I went to the counter, outraged.
[cpg]

;//カウンター付近
[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
.........
[cpg]

At the counter, Shiori was sitting, even though there were no visitors.
[cpg]

I'm sure this place made her feel at home.
[cpg]

[OnName num="Kenji"]
"How are you?"
[cpg cn=true]

I think it's a dumb greeting, but I didn't know what else to say.
[cpg]

Shiori also couldn't seem to think of a clever answer, so she just nodded her head.
[cpg]

I wondered where Hosokawa and Shoko went?
[cpg]

I couldn't see them.
[cpg]

Well, I guess they were reading a book somewhere, but something about everyone being spread out made me anxious.
[cpg]

[OnName num="Kenji"]
"Shouldn't we all stay together...?"
[cpg cn=true]

As I said this, I remembered the game we had played together.
[cpg]

[OnName num="Kenji"]
"Speaking of which, that thing we played with everyone... That was fun."
[cpg cn=true]

............?
[cpg]

Shiori tilted her head, as if the word "thing" didn't ring a bell.
[cpg]

[OnName num="Kenji"]
"I'm not sure what game it was, but it was like a board game. I think it came with a magazine."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori118"]
[OnName num="Shiori"]
"Oh..., uh...what was that?"
[cpg cn=true]

It seemed that even Shiori sometimes forgets things, or couldn't come up with the name of the game.
[cpg]

[OnName num="Kenji"]
"I haven't played a board game like that since I was a kid, so it was really fun. How about you, Shiori? Did you have fun?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori119"]
[OnName num="Shiori"]
"Yes,... It was a little difficult for me, but..."
[cpg cn=true]

[OnName num="Kenji"]
"?"
[cpg cn=true]

She looked okay, but there was something wrong with Shiori.
[cpg]

Normally, she doesn't move her gaze much and doesn't lose her facial expression, but for some reason, now she's wincing and her eyes are watering.
[cpg]

[OnName num="Kenji"]
"Miss Shiori..."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori120"]
[OnName num="Shiori"]
"Just, Shiori..."
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori121"]
[OnName num="Shiori"]
"Just Shiori is fine. Don't be so formal."
[cpg cn=true]

[OnName num="Kenji"]
"Really?!"
[cpg cn=true]

I was not expecting her to say such a thing, so I was a little amused.
[cpg]

But Shiori gave a small, embarrassed nod and let out a smile.
[cpg]

[OnName num="Kenji"]
"Got it. Then, Miss Shiori...I mean Shiori..."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori122"]
[OnName num="Shiori"]
"Yes..."
[cpg cn=true]

silence
[cpg]

Just dropping the formalities made me feel very self-conscious.
[cpg]

Could this be the reason why she was acting a little strange?
[cpg]

It must have been embarrassing, but she got up the courage to say it. That made me unbearably happy.
[cpg]

I felt like I was one step closer to her again.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori123"]
[OnName num="Shiori"]
"What is it...?"
[cpg cn=true]

[OnName num="Kenji"]
"Ah, yeah. Shiori..., isn't it hard for you to be trapped like this? And with your condition, are you okay?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori124"]
[OnName num="Shiori"]
"Well... I've been cooped up in my house since I was a little girl..."
[cpg cn=true]

[VOICE f="Shiori1124"]
[OnName num="Shiori"]
"Even after they built this library, I only went back and forth...between here and home. So, not being able to go outside is not such a big deal..."
[cpg cn=true]


Shiori looked a little sad and somewhat distant.
[cpg]

I and everyone else are already sick of the situation and are trying hard not to be distraught... about what happened to Takagi.
[cpg]

Shiori is surprisingly strong-minded.
[cpg]

[OnName num="Kenji"]
"It must have been hard. You've been on your own for a long time, and you've never been around kids your own age, right?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori125"]
[OnName num="Shiori"]
"Yes... That's why I'm so happy...to be able to talk to Kenji and everyone else little by little. It's the first time...I've talked to a man this much."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, yeah..."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori126"]
[OnName num="Shiori"]
"Yeah... The only man I've ever known is my late grandfather..."
[cpg cn=true]

After hearing all that, I suddenly wondered about her father. Or what about her mother?
[cpg]

Since I've just gotten to know her, I wondered if it was okay for me to ask her such personal questions...
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori127"]
[OnName num="Shiori"]
"Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"Hmm?"
[cpg cn=true]

As I was pondering, Shiori spoke up.
[cpg]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori128"]
[OnName num="Shiori"]
"Would you like to read a book?"
[cpg cn=true]

[OnName num="Kenji"]
"Oh, yeah."
[cpg cn=true]

I figured I'd score some more points with Shiori.
[cpg]

[OnName num="Kenji"]
"Do you have any suggestions?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori129"]
[OnName num="Shiori"]
"My recommendation is..., it's..."
[cpg cn=true]

Shiori pointed to a thick, hardcover book on the shelf next to the counter.
[cpg]

"The World of Fantasia."
[cpg]

The author's name is foreign and underneath it a translation was written.
[cpg]

Apparently, it's a Japanese translation of a Western book.
[cpg]

I picked up the book and asked Shiori about it while looking at it.
[cpg]

[OnName num="Kenji"]
"It seems like this is a fantasy book..."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori130"]
[OnName num="Shiori"]
"Yes, it is..."
[cpg cn=true]

[OnName num="Kenji"]
"It's not a mystery?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori131"]
[OnName num="Shiori"]
"Huh?"
[cpg cn=true]

[OnName num="Kenji"]
"No, I just thought you were going to recommend a mystery novel like you did the other day."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
............!
[cpg]

Shiori choked up a bit at my casual remark, as if she was surprised.
[cpg]

What in the world was wrong with that?
[cpg]

[OnName num="Kenji"]
"What's wrong?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori132"]
[OnName num="Shiori"]
"N-nothing... I also like fantasy..."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, I didn't know that."
[cpg cn=true]

It is more natural to like a variety of things than to be attached to only one genre.
[cpg]

So I didn't really question it too much, but...
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori133"]
[OnName num="Shiori"]
"Um...but.... Kenji if you prefer mysteries.... there are others..."
[cpg cn=true]

[OnName num="Kenji"]
"Don't worry. I'll read anything."
[cpg cn=true]

I mean, I've never read a book in my life, so I was just trying to figure out what worked for me.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori134"]
[OnName num="Shiori"]
"Is that so? That's good then...."
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

Shiori looked awkward, flustered, and not her usual self.
[cpg]


[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori135"]
[OnName num="Shiori"]
"That book..., uh..., there are seven volumes out now, and it's still going... You can read it from volume one... Cough, cough! Ugh...cough!"
[cpg cn=true]

[STOPBGM]

Shiori suddenly began to clutch her chest and cough while trying her best to say something.
[cpg]

[OnName num="Kenji"]
"Are you okay?! I'm sorry, I made you talk a lot."
[cpg cn=true]

I rushed around behind her and rubbed her back.
[cpg]


[BGM f="dod"]

[VOICE f="Shiori136"]
[OnName num="Shiori"]
"I'm o-okay... cough, if I just...sit for a bit... cough!"
[cpg cn=true]

If I listened carefully, I could hear a trapped breathing sound in between the words, which sounded very painful.
[cpg]

Her back was very small as I rubbed it, and her shoulders were very narrow.
[cpg]

Shiori has a really delicate body.
[cpg]

Her illness was just like a demon hiding inside her.
[cpg]



;//[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=1000]

[WAIT time=1500]

[OnName num="Kenji"]
"I'll go get Michi for you!"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori137"]
[OnName num="Shiori"]
"Wait...please..."
[cpg cn=true]

[OnName num="Kenji"]
"Uh..."
[cpg cn=true]

I turned around and was about to leave when Shiori's small hand quickly grabbed my hand.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori138"]
[OnName num="Shiori"]
"I'm really...okay... Cough... Stay here...cough, cough, please..."
[cpg cn=true]

[OnName num="Kenji"]
"A-alright..."
[cpg cn=true]

I was skeptical when she said she was okay, but her hands were so cold...
[cpg]

If I let go of that hand, it seemed so fragile that it would just disappear...
[cpg]

I stood there for a while, holding her hand.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori139"]
[OnName num="Shiori"]
"You see..., it's already going away, isn't it...?"
[cpg cn=true]

Just like she said, the cough had gradually become smaller.
[cpg]

Breathing slowly, Shiori muttered, trying not to speak too loudly.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori140"]
[OnName num="Shiori"]
"I want to get better..."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

I've never been sick, so I couldn't understand what Shiori was going through.
[cpg]

Not being able to understand was so frustrating and painful.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika317"]
[OnName num="Erika"]
"Shiioooriii~ ♪ Can I have a word?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[OnName num="Kenji"]
"..."
[cpg cn=true]

At that moment, Erika approached us with a sweet-sounding voice, and my hands and Shiori's quickly separated.
[cpg]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika318"]
[OnName num="Erika"]
"Oh, I'm sorry, am I interrupting something?"
[cpg cn=true]

Erika grinned eerily, even though this was a situation where she would normally start squealing.
[cpg]

There was something going on here...
[cpg]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika319"]
[OnName num="Erika"]
"You know, that room where the nurse was locked up? The storage room..."
[cpg cn=true]

Shiori nodded in alarm at Erika's words.
[cpg]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika320"]
[OnName num="Erika"]
"It's not just all dinosaur bones and stuff in there, right? What else do you have in there?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori141"]
[OnName num="Shiori"]
"I'm not sure, but I think there are antiques... But I don't know what's in there..."
[cpg cn=true]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika321"]
[OnName num="Erika"]
"Antiques, huh?"
[cpg cn=true]

............?
[cpg]

[OnName num="Kenji"]
"Wa-wait. Erika... Come here. Uh, Shiori..., you think you'll be okay by yourself?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori142"]
[OnName num="Shiori"]
"Oh, yes... I'll go take my medicine..."
[cpg cn=true]

Watching Shiori slowly get up from her seat, I grabbed Erika's arm tightly.
[cpg]

[move from="2/3" to="5/3" ease="easeInOutSine" time=2000]
[WAIT time=1000]
[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika322"]
[OnName num="Erika"]
"Huh? What?"
[cpg cn=true]

I was not sure what to make of Erika's grimace and disturbing smile.
[cpg]

I pulled on her arm and dragged her to Yuna, who was waiting.
[cpg]

;//机の一角
[move from="1/3" to="2/5" ease="easeInOutSine" time=2000]
[FG f="CHA04_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yuna154"]
[OnName num="Yuna"]
"O-oh, Erika... Kenji too..."
[cpg cn=true]

[OnName num="Kenji"]
"What are you up to now?"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika323"]
[OnName num="Erika"]
"What do you mean? You're so paranoid. I was just curious."
[cpg cn=true]

[OnName num="Kenji"]
"Yuna!"
[cpg cn=true]

Seeing that I was getting nowhere with Erika, I questioned Yuna.
[cpg]

[OnName num="Kenji"]
"What were you guys talking about just now?"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna155"]
[OnName num="Yuna"]
"Well, about...that..."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika324"]
[OnName num="Erika"]
"Ugh, fine. I'll tell you! You know, I was thinking maybe I could get some compensation for all our suffering..."
[cpg cn=true]

[OnName num="Kenji"]
"Compensation?"
[cpg cn=true]

That was a word I didn't expect, and I was flabbergasted.
[cpg]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika325"]
[OnName num="Erika"]
"On top of being trapped, now we're getting caught up in a murder case? If they're not careful, they'll have to pay for these damages!"
[cpg cn=true]

[VOICE f="Erika1325"]
[OnName num="Erika"]
"So, I'm not saying it has to be treasure, but I was wondering if I could at least have something that's been sitting in the storage room."
[cpg cn=true]


[OnName num="Kenji"]
"What? What are you talking about?! Haven't you learned your lesson yet?"
[cpg cn=true]

I scolded Erika in disgust.
[cpg]

[OnName num="Kenji"]
"Trapped, trapped... It's your fault we're locked in. And now you're trying to steal something again!"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika326"]
[OnName num="Erika"]
"Eh, but... Yuna agreed, right? Right, Yuna?"
[cpg cn=true]

[OnName num="Kenji"]
"Yuna?!"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna156"]
[OnName num="Yuna"]
"Uh...I..."
[cpg cn=true]

Sandwiched between Erika and me, Yuna's eyes darted around behind her glasses, looking for a way out.
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna157"]
[OnName num="Yuna"]
"I'm not saying I agree..., but maybe...talking about compensation isn't such a bad idea..."
[cpg cn=true]

[OnName num="Kenji"]
"You guys..."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna158"]
[OnName num="Yuna"]
"But...you know, I haven't been able to contact home for four days, and I'm sure I'll get scolded for it..."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika327"]
[OnName num="Erika"]
"Yeah, yeah. In return, you deserve some consolation money, right?"
[cpg cn=true]

What kind of nerve did it take to be a perpetrator and have a full-blown victim mentality?
[cpg]

I didn't think the two of them had anything to do with Takagi, but the lockdown was clearly their fault.
[cpg]

And yet, I can't believe that Erika, let alone Yuna, would have such a stupid idea...
[cpg]

[OnName num="Kenji"]
"Don't think that you'll get away with stealing."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika328"]
[OnName num="Erika"]
"It's fine, it's fine. Kenji, weren't you just listening? Shiori doesn't even know what's in the storage room, so she won't even notice what's missing."
[cpg cn=true]

[OnName num="Kenji"]
"That's not the point, is it?"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika329"]
[OnName num="Erika"]
"Then what is the problem?"
[cpg cn=true]

[OnName num="Kenji"]
"Enough!"
[cpg cn=true]

There was no point in talking to Erika.
[cpg]

If the two of them try to leave here with something, I could point it out then and make them return it.
[cpg]

That's what I thought.
[cpg]

Persuasion was a waste of time.
[cpg]


[stopse g=1]
;//ボイス
[stopse g=2]
;//通常se
[stopse g=6]
;//ループse
;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=2000]
[free time=100]
[BG f="b_l_1f_entrance_p4.ui" time=100]
;//【ＢＧ】図書館・１階・エントランス　夜（暗／蝋燭）******************************************************
[WAIT time=2000]
[transition target={false} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=3000]
[window target=true]

[BGM f="dod"]

[FG f="CHA06_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko080"]
[OnName num="Syouko"]
"Everyone, dinner is ready!"
[cpg cn=true]

[SE f="se062"]
;//【ＳＥ】カンカンカン！

As night fell, the entrance was filled with the Shoko's voice and the metallic sound of a kettle being struck.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa186"]
[OnName num="Hosokawa"]
"It is already night here... Help didn't come today either."
[cpg cn=true]

Hosokawa, who seemed to have gotten caught up in reading in the special reference book room, looked cleaner than he had been in the morning.
[cpg]

[OnName num="Kenji"]
"Huh? Did you wash your head after all?"
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa187"]
[OnName num="Hosokawa"]
"Yeah. I felt gross after all. I washed it with hot water."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, maybe I'll do it tomorrow."
[cpg cn=true]

While we were having this conversation, Michi and Shiori came down from the top of the stairs.
[cpg]

;//※以下、栞はコトハ
;//↓　名前は栞だけど本当はコトハ、という展開です。

[free time=1]
[WAIT time=1]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi240"]
[OnName num="Michi"]
"Well, today went by fast."
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko081"]
[OnName num="Syouko"]
"Uh, Doctor. What flavor would you like for dinner tonight?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi241"]
[OnName num="Michi"]
"What flavor?"
[cpg cn=true]

I looked at what Shoko had laid out on the red carpet: several packets of jello.
[cpg]

[OnName num="Kenji"]
"Jello...."
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko082"]
[OnName num="Syouko"]
"Don't underestimate it! This has enough calories for one meal."
[cpg cn=true]

It wasn't that I was underestimating it, but it was bland.
[cpg]

And when I looked at it to see what flavors were available, we had muscat, peach, grapefruit, yakiniku, and green juice...
[cpg]

The fruit seemed fine, but what were the last two...?
[cpg]

;//コトハ
[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori143"]
[OnName num="Shiori"]
"Ya-yakiniku...?"
[cpg cn=true]

I could tell that Shiori thought so too, as she blurted it out and frowned.
[cpg]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko083"]
[OnName num="Syouko"]
"Let's play rock-paper-scissors and whoever wins takes the one they want!"
[cpg cn=true]

Shoko, who seemed to be enjoying herself quite a bit, decided to do so on her own, and began to quickly start a round.
[cpg]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko084"]
[OnName num="Syouko"]
"Rock, paper, scissors, shoot!"
[cpg cn=true]

Maybe it was a Japanese thing, but when we hear that, we automatically put a hand out.
[cpg]

I also quickly held out scissors toward the middle of the circle of people.
[cpg]

[OnName num="Kenji"]
"Oh, I won..."
[cpg cn=true]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko085"]
[OnName num="Syouko"]
"Oh! That's great. Kenji, you won in one go! Now, please choose one♪"
[cpg cn=true]

[OnName num="Kenji"]
"Then, excuse me. I'll take one first..."
[cpg cn=true]

;//＠
;//エフェクト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1000]
[free time=100]
[BG f="b_l_1f_entrance_p4.ui" time=100]
[WAIT time=1000]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1000]
[window target=true]


[OnName num="Kenji"]
"Hehe, I'll take orange~"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_5" pos="3/3" time=800]

[WAIT time=100]
[VOICE f="Erika330"]
[OnName num="Erika"]
"Oh, that's not fair!"
[cpg cn=true]

What's not fair?
[cpg]

That was the winner's right.
[cpg]

I took off the lid and poured the delicious jello down my throat.
[cpg]

[OnName num="Kenji"]
"So good!"
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa188"]
[OnName num="Hosokawa"]
"Ugh..."
[cpg cn=true]

When I looked to the side, I saw Hosokawa who had apparently been given a green juice, sipping the jelly with a cold sweat.
[cpg]

[OnName num="Kenji"]
"H-how is it?"
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa189"]
[OnName num="Hosokawa"]
"Terrible..."
[cpg cn=true]

[OnName num="Kenji"]
"I'm sure..."
[cpg cn=true]

How unfortunate...
[cpg]

Who did the yakiniku go to?
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko086"]
[OnName num="Syouko"]
"Whoa! It's kalbi! It's gelatin, but it tastes like ribs!"
[cpg cn=true]

Shoko...
[cpg]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko087"]
[OnName num="Syouko"]
"This is revolutionary! Doctor, how about this for the hospital patients' meals?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi242"]
[OnName num="Michi"]
"I don't know..."
[cpg cn=true]

It was over...
[cpg]

I was able to get through it with flying colors.
[cpg]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko088"]
[OnName num="Syouko"]
"If yakiniku is edible, then toro or sea urchin will be good too, I'm sure!"
[cpg cn=true]

Ugh...
[cpg]

;//エフェクト

;//コトハ
[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori144"]
[OnName num="Shiori"]
"...chug, chug."
[cpg cn=true]

I looked over and saw that Shiori had chosen muscat and was holding the jello pack in both hands, sucking on it adorably.
[cpg]

[OnName num="Kenji"]
"...chuckle..."
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori145"]
[OnName num="Shiori"]
"Oh..., you're laughing..."
[cpg cn=true]

[OnName num="Kenji"]
"Sorry, sorry."
[cpg cn=true]

Noticing that I was staring, Shiori glared at me cutely, her cheeks tinted a little.
[cpg]

[OnName num="Kenji"]
"...hmm?"
[cpg cn=true]

Then I noticed that there was something on her nails as she grabbed the pack.
[cpg]

The fingertips of both her hands...
[cpg]

There seemed to be a slight white substance stuck to the surface.
[cpg]

What was it?
[cpg]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko089"]
[OnName num="Syouko"]
"Oh, yes, everyone! Please chew your food thoroughly. The more times you chew slowly, the more your satiety center will be satisfied, you know? Come on, aim for 100 times! Munch, munch, munch..."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika331"]
[OnName num="Erika"]
"Heh..., munch, munch, munch..."
[cpg cn=true]

With Shoko leading the way, everyone also began to casually chew their mouths.
[cpg]

So, I also tried to move my mouth as if ruminating on jello, no longer focused on Shiori's nails.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna159"]
[OnName num="Yuna"]
"Munch, munch, munch..."
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa190"]
[OnName num="Hosokawa"]
"Munch, munch, munch..."
[cpg cn=true]

[OnName num="Kenji"]
"Munch, much, munch... Uh, you know what, I can't even chew."
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika332"]
[OnName num="Erika"]
"If I try to chew it, it just goes down my throat!"
[cpg cn=true]

Was there really any point in chewing jello 100 times?
[cpg]

I'd bite my own tongue if it would make my stomach stop growling!
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA06_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko090"]
[OnName num="Syouko"]
"Munch, munch, munch, munch, munch, munch, munch, munch..."
[cpg cn=true]

But Shoko continued to move her jaws eagerly.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko091"]
[OnName num="Syouko"]
"Munch, munch, munch, munch, munch, munch, munch, munch..."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi243"]
[OnName num="Michi"]
"And...? Are you full?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko092"]
[OnName num="Syouko"]
"Of course I am!"
[cpg cn=true]

[SE f="se037"]
;//【ＳＥ】腹が鳴る

[WAIT time=2000]
[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko093"]
[OnName num="Syouko"]
"Oh..."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika333"]
[OnName num="Erika"]
"That was a waste of time."
[cpg cn=true]

In the end, Shoko, the one who started it all, didn't seem to be able to expand her stomach either, and she held her self-assertive belly in embarrassment.
[cpg]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko094"]
[OnName num="Syouko"]
"Ah~... I'm sorry~...."
[cpg cn=true]

I wondered how many times this one has apologized...since she got here.
[cpg]


[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=2100]
[free time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=1]
[WAIT time=1]
[transition target={false} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=2100]
[window target=true]

When our bland dinner was over, Shiori unrolled the garbage bag and started collecting everyone's packs.
[cpg]

[OnName num="Kenji"]
"I'll help you."
[cpg cn=true]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori146"]
[OnName num="Shiori"]
"Thanks..."
[cpg cn=true]

Shiori smiled at me, and the two of us closed the mouth of the garbage bag.
[cpg]

[OnName num="Kenji"]
"Where do I take it?"
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori147"]
[OnName num="Shiori"]
"I've put all the trash up until now in one place..."
[cpg cn=true]

And I asked her for detailed directions.
[cpg]

[OnName num="Kenji"]
"Got it."
[cpg cn=true]

[free time=1000]

Wait a minute...
[cpg]

I thought the basement was where Shoko slept.
[cpg]

So, Shoko was sleeping surrounded by garbage and books.
[cpg]

Wow, poor thing...
[cpg]

As I was heading to the basement, I saw Erika walking towards Michi.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika334"]
[OnName num="Erika"]
"Hey, Ms. Kisaragi, the storage room in the basement looks like a mess, but is there anything interesting in there?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi244"]
[OnName num="Michi"]
"Something interesting? I don't think we have anything that you can play with..."
[cpg cn=true]

Not again, I thought.
[cpg]

Erika has even been probing Michi for information.
[cpg]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi245"]
[OnName num="Michi"]
"And I don't even know how many things there are because I haven't made a list. Why?"
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika335"]
[OnName num="Erika"]
"I'm just asking."
[cpg cn=true]

[free time=1000]

[OnName num="Kenji"]
"Jeez..."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=800]


When Shiori saw me, she gave me a look that said, "What's wrong?"
[cpg]

[OnName num="Kenji"]
"Oh, no, it's nothing! I'll get going."
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori148"]
[OnName num="Shiori"]
"I'll go, too."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, yeah?"
[cpg cn=true]

I was going to go take down the garbage, but Shiori said she would accompany me, so we went down to the basement together.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗／懐中電灯）******************************************************

[WAIT time=1000]


[SE f="se006"]
;//【ＳＥ】足音
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=800]

The stairs and corridor down to the basement were lit by our flashlights.
[cpg]

[OnName num="Kenji"]
"................."
[cpg cn=true]

.........
[cpg]

Even if it was only a short distance, there was a sense of excitement like a haunted house.
[cpg]

[SE f="se136"]
;//【ＳＥ】ドア開ける

[WAIT time=1500]
[OnName num="Kenji"]
"Here or..."
[cpg cn=true]

It wasn't so much the quantity, but right when we opened the door we could already see trash bags.
[cpg]

There was also a blanket that could be seen in the far corner if I shined my flashlight a little further back.
[cpg]

After all, she didn't sleep near the garbage, did she?
[cpg]

;//コトハ
[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori149"]
[OnName num="Shiori"]
"A little scary..."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah..."
[cpg cn=true]

Perhaps frightened by the darkness, Shiori clung to my arm.
[cpg]

How...lucky.
[cpg]

[OnName num="Kenji"]
"I'm here for you. You'll be fine."
[cpg cn=true]

Consciously, I put a lot of pressure on Shiori's arms that were hugging me.
[cpg]

And then, just like that...
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori150"]
[OnName num="Shiori"]
"I knew Kenji's arms were...strong. Your bicep...is rock hard."
[cpg cn=true]

[OnName num="Kenji"]
"Really? My biceps aren't that big. I think they're normal."
[cpg cn=true]

When I tried to be humble about it, Shiori nodded her head and looked up at me, like she was fascinated.
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori151"]
[OnName num="Shiori"]
"I don't think so. They're better than average... I'm sure you have beautiful muscles all over your body."
[cpg cn=true]

I was so excited when she said that to me, that I couldn't help but...
[cpg]

[OnName num="Kenji"]
"I don't know about that. Want to have a look? Just kidding!"
[cpg cn=true]

And I became like a little erotic old man.
[cpg]

But...
[cpg]

;//コトハ
[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori152"]
[OnName num="Shiori"]
"Yes."
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

Did she just say..."yes"?
[cpg]

That meant she wants to see my whole body!
[cpg]

I think I had a very surprised look on my face.
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori153"]
[OnName num="Shiori"]
"...pfft, giggle."
[cpg cn=true]

Immediately, Shiori began to slightly giggle.
[cpg]

[OnName num="Kenji"]
"You were joking?!"
[cpg cn=true]

If I had just thought about it for a second and I would've gotten that!
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori154"]
[OnName num="Shiori"]
"I'm sorry. I didn't think you'd be that surprised."
[cpg cn=true]

[OnName num="Kenji"]
"What a mean joke! Ahahaha!"
[cpg cn=true]

If this kind of joke could come out of her mouth, it means that her condition has improved since she took her medicine.
[cpg]

That was the most important thing for me to be relieved about.
[cpg]

That's right.
[cpg]

When Shiori speaks slowly and in a whisper, it means that she is not feeling well or is about to get sick.
[cpg]

And when she smiles like this or her voice is strong, that's when she's feeling good.
[cpg]

This was a good thing to notice.
[cpg]

From now on, I'll be able to pay attention to her condition in advance.
[cpg]

[OnName num="Kenji"]
"Let's go back."
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗／蝋燭）******************************************************

[WAIT time=1500]

When we returned to the first floor, it seemed that everyone had rinsed their mouths in the bathroom and was getting ready for bed.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi246"]
[OnName num="Michi"]
"Did you take down the trash?"
[cpg cn=true]

Michi asked when she saw us.
[cpg]

;//コトハ
[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori155"]
[OnName num="Shiori"]
"Yes. With Kenji."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi247"]
[OnName num="Michi"]
"Well... You'd better get ready for bed."
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori156"]
[OnName num="Shiori"]
"Yes. Good night, Kenji."
[cpg cn=true]

[OnName num="Kenji"]
"Good night. Get some rest."
[cpg cn=true]

;//コトハ
[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori157"]
[OnName num="Shiori"]
"Thank you."
[cpg cn=true]

[move from="4/5" to="5/3" ease="easeInOutSine" time=800]

Shiori bowed lightly and went upstairs with light footsteps.
[cpg]

After seeing her off, I talked to Michi.
[cpg]

[OnName num="Kenji"]
"She looked bad during the day, but now she seems fine."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi248"]
[OnName num="Michi"]
"What?"
[cpg cn=true]

[OnName num="Kenji"]
"The medicine did help after all?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi249"]
[OnName num="Michi"]
"Oh, yes. But I have to tell her not to get carried away."
[cpg cn=true]

[OnName num="Kenji"]
"Get carried away? Shiori does that?"
[cpg cn=true]

I wondered if even someone like Shiori can get a little excited when she gets carried away.
[cpg]

I kind of wanted to see that.
[cpg]

See Shiori laugh and run around...
[cpg]

However, Michi had a serious expression, looking very doctorly.
[cpg]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi250"]
[OnName num="Michi"]
"Even if she gets excited, it can make her feel worse, because her body can't keep up. So I'm sorry, but try not to excite her too much."
[cpg cn=true]

[OnName num="Kenji"]
"Yes, I'll be careful..."
[cpg cn=true]

Don't let her get excited...
[cpg]

But I wonder what's wrong... A disease that requires that much rest, but not enough to be hospitalized?
[cpg]

I was about to open my mouth to ask about it, but Michi said something first.
[cpg]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi251"]
[OnName num="Michi"]
"Are you cold at night, Kenji?"
[cpg cn=true]

[OnName num="Kenji"]
"It is cold, but I wrap myself up in my blanket."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi252"]
[OnName num="Michi"]
"If you get cold, you can warm up a bit by doing some exercise."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, yeah. I'll give it a try."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi253"]
[OnName num="Michi"]
"Well, I'll see you tomorrow."
[cpg cn=true]

[OnName num="Kenji"]
"Good night."
[cpg cn=true]

[free time=1000]

Michi walked up the stairs.
[cpg]

Will she sleep in Shiori's room again tonight?
[cpg]

On the floor with a blanket?
[cpg]

Or will they be in that bed together?
[cpg]

Either way...
[cpg]

[OnName num="Kenji"]
"How nice..."
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa191"]
[OnName num="Hosokawa"]
"What's nice?"
[cpg cn=true]

[OnName num="Kenji"]
"Oh, no... nothing."
[cpg cn=true]

Suddenly, Hosokawa called me from behind, and my sweet and cute fantasy dissipated.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa192"]
[OnName num="Hosokawa"]
"Azuma, I have a favor to ask you."
[cpg cn=true]

[OnName num="Kenji"]
"Yes, what is it?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa193"]
[OnName num="Hosokawa"]
''I want to hear your honest opinion. Sigh~!"
[cpg cn=true]

[OnName num="Kenji"]
"Huh?!"
[cpg cn=true]

Hosokawa suddenly let out a hot breath in my face.
[cpg]

[OnName num="Kenji"]
"What are you doing?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa194"]
[OnName num="Hosokawa"]
"What do you think? Does it stink?"
[cpg cn=true]

[OnName num="Kenji"]
"Uh...."
[cpg cn=true]

Was this guy asking about bad breath?
[cpg]

Yeah..., it stinks!
[cpg]

How long have we all gone without brushing our teeth?
[cpg]

But...
[cpg]

[OnName num="Kenji"]
"It doesn't smell that bad..."
[cpg cn=true]

You can't tell someone you don't know very well that they have bad breath to their face.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa195"]
[OnName num="Hosokawa"]
"Is that so? That's good. That's good."
[cpg cn=true]

What was good about that? Hosokawa wrinkled the corners of his eyes and smirked.
[cpg]

[OnName num="Kenji"]
"What are you doing?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa196"]
[OnName num="Hosokawa"]
"Well, about that, have you seen Ms. Kisaragi?"
[cpg cn=true]

[OnName num="Kenji"]
"If you're looking for Michi, she went upstairs."
[cpg cn=true]

I answered carelessly and suddenly realized...
[cpg]

He was worried about bad breath... No way.
[cpg]

Tonight, Hosokawa was going to try to kiss Michi?!
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa197"]
[OnName num="Hosokawa"]
"Hehehe ♪"
[cpg cn=true]


[move from="2/3" to="5/3" ease="easeInOutSine" time=1000]


Meanwhile, Hosokawa was headed up the stairs with a weird spring in his step, twisting and turning.
[cpg]

What to do...?
[cpg]

Should I go after him and give him some excuse to stop?
[cpg]

No, kissing and stuff was all in my head anyway...
[cpg]


[VOICE f="Erika336"]
[OnName num="Erika"]
"Has everyone gone to their rooms?"
[cpg cn=true]


[VOICE f="Yuna160"]
[OnName num="Yuna"]
"Probably..."
[cpg cn=true]

While I was contemplating things, I heard Erika and Yuna's voices coming from the women's restroom.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_2" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika337"]
[OnName num="Erika"]
"Okay, I'm going to go get the treasure."
[cpg cn=true]

[VOICE f="Yuna161"]
[OnName num="Yuna"]
"B-but, don't you think we should give up on it after all?
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika338"]
[OnName num="Erika"]
"Yuna..., you think that. Can't you just listen to me?"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna162"]
[OnName num="Yuna"]
"O-okay..."
[cpg cn=true]

Oh, they're doing it...tonight?
[cpg]

Were they planning on stealing right now?
[cpg]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika339"]
[OnName num="Erika"]
"Let's go!"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna163"]
[OnName num="Yuna"]
"Yeah..."
[cpg cn=true]

[free time=1000]

Erika and Yuna seemed to be going down to the basement.
[cpg]

What should I do? Can I just let the thieves go?
[cpg]


[VOICE f="Hosokawa198"]
[OnName num="Hosokawa"]
"~♪"
[cpg cn=true]

Ah! But Hosokawa has already reached the second floor door!
[cpg]

Should I follow Erika or Hosokawa...?
[cpg]

;//■選択肢８（２択）
[switch]
[case "Follow Erika and Yuna"]
	[swap]
	[jump target="*s8_a"]
[case "Follow Hosokawa"]
	[swap]
	[jump target="*s8_b"]
[endswitch]
;//１，エリカと柚那を追う　//８aへ
;//２，細川を追う　　　　　//８bへ
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//８a　エリカと柚那を追う
*s8_a|Unshakeable Anxiety
I'm going after Erika and Yuna!
[cpg]

Hosokawa's intentions could just be my imagination, but what they were planning was definitely a crime.
[cpg]

I hurriedly chased after the two who were already out of sight.
[cpg]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_lr_0.ui" time=1000]
;//【ＢＧ】図書館・地下・物置Ｂ　（暗／懐中電灯）******************************************************

[WAIT time=1500]

[BGM f="silent"]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika340"]
[OnName num="Erika"]
"Try not to make a sound. The nurse is asleep."
[cpg cn=true]

[VOICE f="Yuna164"]
[OnName num="Yuna"]
"Uh, yeah..."
[cpg cn=true]

[SE f="se063"]
;//【ＳＥ】ガサゴソ
[WAIT time=1000]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika341"]
[OnName num="Erika"]
"Oh, what's that old box over there?"
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna165"]
[OnName num="Yuna"]
"I don't know... I'll open it. It's...a collection of poems."
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika342"]
[OnName num="Erika"]
"I don't want that... Next, next..."
[cpg cn=true]

Peeking through the crack in the door, Erika and Yuna seemed to be sneaking around the storage room with flashlights in their hands.
[cpg]

[SE f="se063"]
;//【ＳＥ】ガサゴソ
[WAIT time=1000]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika343"]
[OnName num="Erika"]
"Oh, what's that big box on the second shelf over there?"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna166"]
[OnName num="Yuna"]
"I wonder what it is... Oh, it's heavy..."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika344"]
[OnName num="Erika"]
"Take it down, take it down!"
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna167"]
[OnName num="Yuna"]
"Want to open it...?"
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika345"]
[OnName num="Erika"]
"Open it. Open it."
[cpg cn=true]

[SE f="se064"]
;//【ＳＥ】カタッ
[WAIT time=1000]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna168"]
[OnName num="Yuna"]
"Oh, my God, it's full of...clay figurines."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika346"]
[OnName num="Erika"]
"I don't want that! Is there anything that we could sell?"
[cpg cn=true]

The exchange between the two of them was a little amusing, but I couldn't just sit there and watch them forever.
[cpg]

[OnName num="Kenji"]
"Hey, you two!"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna169"]
[OnName num="Yuna"]
"Aaah!"
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika347"]
[OnName num="Erika"]
"What? It's just Kenji."
[cpg cn=true]

[OnName num="Kenji"]
"What do you mean 'what'! I told you to stop!"
[cpg cn=true]

I thought I was glaring as hard as I could, but it had no effect on Erika.
[cpg]

On the contrary...
[cpg]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika348"]
[OnName num="Erika"]
"Just as well. Help us look."
[cpg cn=true]

She even tried to rope me in.
[cpg]

[OnName num="Kenji"]
"Don't be stupid! There's no way I'm letting you steal anything. Get the hell out of here! If you don't, when the police come, I'll tell them about this."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna170"]
[OnName num="Yuna"]
"P-police..."
[cpg cn=true]

With a single word, Yuna seemed to recoil and retreated fearfully toward the door.
[cpg]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika349"]
[OnName num="Erika"]
"O-oh, no..., you're always overreacting. We haven't even stolen anything yet."
[cpg cn=true]

[OnName num="Kenji"]
"That's right. As a classmate, I'm stopping you before you commit a crime. You should be grateful."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna171"]
[OnName num="Yuna"]
"Come on, Erika..., let's not do this... Besides, we'll probably still be suspected by the police..."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika350"]
[OnName num="Erika"]
"...tsk."
[cpg cn=true]

There was no...back talk or anything.
[cpg]

I'll tell you now, when I first saw Erika, I thought she was kind of cute.
[cpg]

However, after I started to get to know her personality, I thought she was straight-forward...
[cpg]

After that, I started to think that she was tough and pushy, and I started to lose interest in her.
[cpg]

It doesn't matter how cute, stylish, and fashionable someone is, people still need to have substance.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗／懐中電灯）******************************************************

[WAIT time=1500]


[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yuna172"]
[OnName num="Yuna"]
".................."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika351"]
[OnName num="Erika"]
"Damn it.... It was a good idea, but we shouldn't have let Kenji find out about it."
[cpg cn=true]

Yuna looked remorseful and regretful, but Erika thought nothing of it.
[cpg]

[OnName num="Kenji"]
"Yuna, why don't you stop being friends with this one?"
[cpg cn=true]

I suggested this to Yuna in utter disgust.
[cpg]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna173"]
[OnName num="Yuna"]
"Uh..."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika352"]
[OnName num="Erika"]
"What are you saying? Yuna is my best friend! Rightー?"
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna174"]
[OnName num="Yuna"]
"Uh..., ah, yeah..."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

When I saw Erika forcibly rubbing shoulders with Yuna, I was speechless.
[cpg]

For Erika, Yuna may be a friend, but I wondered what Yuna thought of Erika.
[cpg]

Did she enjoy being lured into doing bad things like this, or always having to do things she didn't want to do?
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna175"]
[OnName num="Yuna"]
".................."
[cpg cn=true]

I felt sorry for Yuna, but I also felt a little sorry for Erika if Yuna was actually reluctant to go along with her.
[cpg]

Because that's not how friendship is supposed to work...
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗／蝋燭）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/5" time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=1000]

[WAIT time=1500]


[OnName num="Kenji"]
"I'm going to leave the door to my room open. If you come down here in the middle of the night, I'll catch you."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika353"]
[OnName num="Erika"]
"Okay~ We won't do it again...tonight."
[cpg cn=true]

[OnName num="Kenji"]
"Hey, you!"
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika354"]
[OnName num="Erika"]
"Kidding, kidding ♪ Don't get mad~"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna176"]
[OnName num="Yuna"]
"Um..., I'm sorry. Good night."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah."
[cpg cn=true]

From the bottom of the stairs, I saw them return to their room and let out a deep sigh.
[cpg]

[OnName num="Kenji"]
"Oh, yeah, what about him?"
[cpg cn=true]

Speaking of which, what happened with Hosokawa?
[cpg]

Thinking about it, I looked upstairs to the left, but didn't hear any strange noises or screams.
[cpg]

[OnName num="Kenji"]
"Was I worrying too much...?
[cpg cn=true]

Both Hosokawa and Michi are adults, unlike me.
[cpg]

First of all, even if Hosokawa had said something to Michi, I am sure she would have a way to get out of it.
[cpg]

So I went back to the bedroom where I was alone and put my jacket on the chair.
[cpg]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_tbr_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・専門書の部屋　夜（暗／蝋燭／机に大量の本）******************************************************

[WAIT time=1500]

;//机の上に大量の本が山積み

[OnName num="Kenji"]
"Ugh, what the hell..."
[cpg cn=true]

I raised my voice when I noticed a pile of books on my desk, where there was always nothing.
[cpg]

Hosokawa must have been here during the day.
[cpg]

I figured he must have just left them out.
[cpg]

[OnName num="Kenji"]
"All these books are so thick. I'm not going to help you put them away."
[cpg cn=true]

I mumbled to myself and wrapped myself up in my blanket.
[cpg]

[OnName num="Kenji"]
"Ugh, It's cold..."
[cpg cn=true]

It was very cold tonight.
[cpg]

I thought about doing some exercise like Michi said, but once I was in the blanket, I didn't feel like getting out.
[cpg]

[OnName num="Kenji"]
"I'll do it tomorrow. Tomorrow..."
[cpg cn=true]

I didn't need to make excuses, but I said so and closed my eyes.
[cpg]

[OnName num="Kenji"]
"Since I'll work out a bit and wash my hair tomorrow, I pray for help to come..."
[cpg cn=true]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

;//８cへ合流
[jump target="*s8_c"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//８b　細川を追う
*s8_b|Unshakeable Anxiety

;//＠
;//※＜鍵フラグ＞確立

[stflag Key=1]

I'd better follow Hosokawa.
[cpg]

Like I thought earlier, no matter what Erika and Yuna steal, if we catch them just before they leave here, they will return everything.
[cpg]

It would be better to check on Hosokawa, since I have no idea what he's about to do.
[cpg]

I walked up the stairs to the left, trying not to make a sound, and went through the same door as him.
[cpg]



[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_pcpass_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・関係者オンリー　廊下　夜（暗）******************************************************

[WAIT time=1500]


;//[BGM f="silent"]

[OnName num="Kenji"]
"Hmm?"
[cpg cn=true]

I came to the hallway, which was for staff only, but I couldn't see Hosokawa.
[cpg]

I wasn't sure if he'd gone into one of the rooms.
[cpg]

[OnName num="Kenji"]
"Wait a minute..."
[cpg cn=true]

If he had business with Michi the one room he'd go into would be...Shiori's room!
[cpg]

Michi aside, it's outrageous that Hosokawa would go into Shiori's room!
[cpg]

Although...
[cpg]

[OnName num="Kenji"]
"What?! Uh...?"
[cpg cn=true]

Unfamiliar with the place, I couldn't figure out where Shiori's room was.
[cpg]

With a row of similar doors, my eyes could only wander.
[cpg]

[OnName num="Kenji"]
"What should I do...?"
[cpg cn=true]

I wondered if I should turn back, or try every door from one end...to the other.
[cpg]


[VOICE f="Michi254"]
[OnName num="Michi"]
"Let go of me!"
[cpg cn=true]

I heard Michi's voice, which clearly sounded strange.
[cpg]

I ran down the hallway in the direction of her voice.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_sr_0.ui" time=1000]
;//【ＢＧ】図書館・２階・セキュリティルーム　（暗）******************************************************

[WAIT time=1500]

[BGM f="huan"]


;//美智の手首を掴んでいる細川

[FG f="CHA08_p3_01_a.ui" method="change_4" pos="3/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Hosokawa199"]
[OnName num="Hosokawa"]
"Don't be shy, I know you know how I feel!"
[cpg cn=true]

[VOICE f="Michi255"]
[OnName num="Michi"]
"Wait, it hurts..."
[cpg cn=true]

[FACE method="change_3" pos="3/5"]
[WAIT time=100]
[VOICE f="Hosokawa200"]
[OnName num="Hosokawa"]
"You know what? In a few more years, I'll be a great doctor. Then we'll be equals."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi256"]
[OnName num="Michi"]
"That's not the problem here, is it?"
[cpg cn=true]

[FACE method="change_3" pos="3/5"]
[WAIT time=100]
[VOICE f="Hosokawa201"]
[OnName num="Hosokawa"]
"I love you!"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi257"]
[OnName num="Michi"]
"Ahhhh!"
[cpg cn=true]

;//美智を押し倒す細川

[free time=1000]
[WAIT time=1]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/5" time=1000]

[SE f="se047"]
;//【ＳＥ】ドサッ
[WAIT time=1000]

[VOICE f="Hosokawa202"]
[OnName num="Hosokawa"]
"Don't fight it. You know what I know? I know about Shiori's disease."
[cpg cn=true]


[VOICE f="Michi258"]
[OnName num="Michi"]
"W-what do you mean?"
[cpg cn=true]

[FACE method="change_2" pos="3/5"]
[WAIT time=100]
[VOICE f="Hosokawa203"]
[OnName num="Hosokawa"]
"Ah, you're so beautiful. I've never met a woman so beautiful and smart. Isn't this nice? Hey! Ms. Kisaragi! I love you!"
[cpg cn=true]


[VOICE f="Michi259"]
[OnName num="Michi"]
"N-no!!"
[cpg cn=true]

[SE f="se065"]
;//【ＳＥ】乱暴にドア開ける

[WAIT time=1000]

;//[BG f="b_l_2f_sr_0.ui" time=1000]
;//【ＢＧ】図書館・２階・セキュリティルーム　（暗）

[OnName num="Kenji"]
"What are you doing? Ah....!"
[cpg cn=true]

When I stepped in, Michi was already being pushed down by Hosokawa and was about to have her underwear ripped off.
[cpg]


[VOICE f="Michi260"]
[OnName num="Michi"]
"Kenji!"
[cpg cn=true]

[FACE method="change_3" pos="3/5"]
[WAIT time=100]
[VOICE f="Hosokawa204"]
[OnName num="Hosokawa"]
"How rude! Get out of here!"
[cpg cn=true]

While shouting, Hosokawa's hands were grabbing Michi's ample breasts.
[cpg]

[OnName num="Kenji"]
"Who's being rude here? You bastard!"
[cpg cn=true]

The sight of Michi's disheveled appearance sent a rush of blood to my head as I was surprised that Hosokawa had done more than I had imagined.
[cpg]

[OnName num="Kenji"]
"Let go of Michi!"
[cpg cn=true]

[SE f="se045"]
;//【ＳＥ】殴り飛ばす


[FACE method="change_5" pos="3/5"]
[WAIT time=100]
[VOICE f="Hosokawa205"]
[OnName num="Hosokawa"]
"Aah!"
[cpg cn=true]

[SE f="se067"]
;//【ＳＥ】吹っ飛ぶ

[move from="3/5" to="5/3" ease="easeInOutSine" time=1000]

[WAIT time=2000]

[OnName num="Kenji"]
"Are you okay?!"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi261"]
[OnName num="Michi"]
"Th-thank you. I'm fine..."
[cpg cn=true]

When she ran up to Hosokawa, slamming her fist into his face, Michi spoke firmly, but her hands were shaking a little as she fixed her dishevelled clothes.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA08_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa206"]
[OnName num="Hosokawa"]
"You little brat~!"
[cpg cn=true]

Perhaps it was where he had fallen, but Hosokawa had grabbed something that looked like a telephone handset and jumped at me.
[cpg]

;//＠
[SE f="se066"]
;//【ＳＥ】振り回す
[WAIT time=1000]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa207"]
[OnName num="Hosokawa"]
"You should just do Shiori! Stay out of my way!"
[cpg cn=true]

Excited or angry, Hosokawa was waving the object in his grip around recklessly, white foam flying from the corner of his mouth.
[cpg]

[OnName num="Kenji"]
”You’re fucking kidding me. Don't lump me together with you!"
[cpg cn=true]

I couldn't forgive him for saying that I should "do" Shiori, so I punched Hosokawa in the face as hard as I could.
[cpg]

[SE f="se045"]
;//【ＳＥ】殴り飛ばす
[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa208"]
[OnName num="Hosokawa"]
"Heh!!"
[cpg cn=true]

[SE f="se067"]
;//【ＳＥ】さっきより激しく吹っ飛ぶ　壊れた機械の残骸が更に壊れる

[move from="2/3" to="5/3" ease="easeInOutSine" time=800]
[WAIT time=1000]
[VOICE f="Hosokawa209"]
[OnName num="Hosokawa"]
"Ar...ghhh."
[cpg cn=true]

[SE f="se047"]
;//【ＳＥ】ドサッ

Hosokawa, who had been hit in the face with the full force of my anger, flew farther than before and plunged into the wreckage of the machine.
[cpg]


[STOPBGM]

[OnName num="Kenji"]
"Hahー...hahー..."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi262"]
[OnName num="Michi"]
"Ke-kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"Michi!"
[cpg cn=true]

I went over to Michi, who was still unable to get up from the floor, and she clung to my chest, as if she was scared.
[cpg]

Ah...
[cpg]

[BGM f="h1"]

[OnName num="Kenji"]
"...Y-you're okay now."
[cpg cn=true]

At that time, while holding Michi in my arms, I was inappropriately intrigued by the sweet scent that tickled my nostrils.
[cpg]

It was the smell of a mature woman.
[cpg]

[OnName num="Kenji"]
"Are you injured? Does it hurt anywhere?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi263"]
[OnName num="Michi"]
"Forget about me...you're the one..."
[cpg cn=true]

[OnName num="Kenji"]
"Huh?"
[cpg cn=true]

It was only when Michi took my right hand that I noticed that my knuckles were soaked with blood.
[cpg]

It must have been cut when I punched him.
[cpg]

[OnName num="Kenji"]
"It's fine. This is nothing."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi264"]
[OnName num="Michi"]
"No...You don't want it to get infected."
[cpg cn=true]

[OnName num="Kenji"]
"Really. I just get injured easily. I'm not used to fighting, so I'm embarrassed that my hand would bleed from something like this."
[cpg cn=true]

I tried to play it off like that, hoping that Michi wouldn't worry, but...
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi265"]
[OnName num="Michi"]
"No. You were really...cool."
[cpg cn=true]

She whispered, and Michi put her lips to the cut on my right hand.
[cpg]

[OnName num="Kenji"]
"Oh..."
[cpg cn=true]

[SE f="se061"]
;//【ＳＥ】チュッ…

[WAIT time=1000]


[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi266"]
[OnName num="Michi"]
"Pain, pain...., go away..."
[cpg cn=true]


She kissed me instead of disinfecting me and I felt full of energy.
[cpg]

[OnName num="Kenji"]
"Even someone like Michi would say a chant...like that?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi267"]
[OnName num="Michi"]
"What? Is it that weird?"
[cpg cn=true]

It was unexpected that Michi, a woman of science and mathematics, used a silly little chant, and the gap made me dizzy.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi268"]
[OnName num="Michi"]
"When she was a kid, I used to say this to Shiori every time I gave her a shot."
[cpg cn=true]

[OnName num="Kenji"]
"Huh...?!"
[cpg cn=true]

It was heart-warming to hear...that she sang a little chant for Shiori when she was a child.
[cpg]

But if she did that...
[cpg]

[OnName num="Kenji"]
"Um...w-what?"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi269"]
[OnName num="Michi"]
"Oh... I get it."
[cpg cn=true]

[OnName num="Kenji"]
"Huh?!"
[cpg cn=true]

She deliberately glared at me with a slightly mischievous look in her eyes, then raised the corner of her mouth and spoke.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi270"]
[OnName num="Michi"]
"I'm sure you're wondering, 'How old is she?', right?"
[cpg cn=true]

[OnName num="Kenji"]
"Ah!"
[cpg cn=true]

She hit the nail on the head.
[cpg]

My guess was that she was about 25 or 30, based on Michi's appearance and her being a doctor, but she might be a little older...?
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi271"]
[OnName num="Michi"]
"You want to know?"
[cpg cn=true]

[OnName num="Kenji"]
"No-no..., uh...well..."
[cpg cn=true]

I wanted to know, but I didn't want to know...
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi272"]
[OnName num="Michi"]
"It's a secret."
[cpg cn=true]

[OnName num="Kenji"]
"Eh..."
[cpg cn=true]

I was expecting to be told, but when I was told that it was a secret, I imagined that she was much older...
[cpg]

I've heard that age-defying women are all the rage, and sometimes they are even 40 or 50...!
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi273"]
[OnName num="Michi"]
"Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"Yes?!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi274"]
[OnName num="Michi"]
"No matter what, I'm not middle-aged..."
[cpg cn=true]

[OnName num="Kenji"]
"O-oh, really?"
[cpg cn=true]

I guess all of my anxiety was showing on my face, since Michi gave me a disapproving look.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi275"]
[OnName num="Michi"]
"But thank you very much. After we've talked a bit, I'm feeling a lot better."
[cpg cn=true]

[OnName num="Kenji"]
"I'm glad to hear that."
[cpg cn=true]

Relieved that Michi seemed more like her usual self, I glanced at Hosokawa, who had collapsed and fainted.
[cpg]

Surprisingly, even after being beat up so much, his glasses had not come off, which was a little funny.
[cpg]

[OnName num="Kenji"]
"I'm not sure what to do about this guy. If the door can be locked, should I lock it?"
[cpg cn=true]

This time, I happened to notice what was going on, so I was able to stop him in time, but it doesn't mean he won't try to lay a hand on other girls.
[cpg]

Someone that dangerous should be locked up.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi276"]
[OnName num="Michi"]
"Yes... But if we leave him in this state and he develops a fever, it will be troublesome..."
[cpg cn=true]

I see, if we left him in a room with no heating, he could catch a cold.
[cpg]

If that happened, the one who would have to take care of him was Michi.
[cpg]

[OnName num="Kenji"]
"Then, I'll take him down to the room below. I'll just cover him with a blanket and lock the door."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi277"]
[OnName num="Michi"]
"Yes. Let's do that. He will have calmed down by tomorrow."
[cpg cn=true]

I concluded that and lifted Hosokawa's bleeding nose and slumped body onto my shoulders.
[cpg]

[OnName num="Kenji"]
"He's light..."
[cpg cn=true]

When I was surprised at how light he was compared to Takagi, Michi muttered evasively.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi278"]
[OnName num="Michi"]
"Even a man who is skin and bones like this is stronger than me. I hate being a woman..."
[cpg cn=true]

[OnName num="Kenji"]
"That's why there are men like me."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi279"]
[OnName num="Michi"]
"Oh, are you hitting on me?"
[cpg cn=true]

[OnName num="Kenji"]
"Huh?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi280"]
[OnName num="Michi"]
"Hehe."
[cpg cn=true]

While I was attracted to the angelic Shiori, I was also dazzled by such a devilishly mature woman.
[cpg]

Being a guy sucks...
[cpg]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）******************************************************

[WAIT time=1500]

[BGM f="dod"]


[SE f="se068"]
;//【ＳＥ】鍵

The general collection room was locked from the outside and Michi pocketed a key ring with several keys on it.
[cpg]

[OnName num="Kenji"]
"It wasn't an electronic lock..."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi281"]
[OnName num="Michi"]
"Oh..., the front door and the room to the left of the stairs are automatic, but the rest of the rooms have old-fashioned locks."
[cpg cn=true]

[VOICE f="Michi1281"]
[OnName num="Michi"]
"Since the first time we built this place, we've made a lot of changes, so it's kind of weird right now."
[cpg cn=true]


They should have kept the front door lock just as it was....
[cpg]

[free time=1000]

I parted with Michi at the entrance while my brain whined about it.
[cpg]

[OnName num="Kenji"]
"Phew..."
[cpg cn=true]

I'm glad I made the choice to follow Hosokawa.
[cpg]

If not, Michi would have surely been...
[cpg]

Just thinking about it, I shook my head.
[cpg]

Imagining such things would be disrespectful to Michi.
[cpg]

[OnName num="Kenji"]
"I should go to bed..."
[cpg cn=true]

But when I was about to head off to bed...
[cpg]

;//画面に懐中電灯の灯りが２個、ふらつく

[FG f="CHA03_p3_01_a.ui" method="change_2" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika355"]
[OnName num="Erika"]
"Hehehe, good for you, Yuna."
[cpg cn=true]

[VOICE f="Yuna177"]
[OnName num="Yuna"]
"I'm not sure.... I don't even know what it's for..."
[cpg cn=true]

What timing?
[cpg]

Erika and Yuna came up from the basement.
[cpg]

[OnName num="Kenji"]
"Hey, you two!"
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika356"]
[OnName num="Erika"]
"What the fuck?"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna178"]
[OnName num="Yuna"]
"K-Kenji..."
[cpg cn=true]

I was so pissed off that I went over to Erika.
[cpg]

[OnName num="Kenji"]
"You stole something, even after I told you not to! What did you steal?!"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika357"]
[OnName num="Erika"]
"N-nothing."
[cpg cn=true]

Erika retreats from my overpowering force.
[cpg]

[OnName num="Kenji"]
"Hand over what you stole. I'm serious. If you don't, I'm going to tell the police about you two after we leave here."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna179"]
[OnName num="Yuna"]
"The police?!"
[cpg cn=true]

At the word "police," Yuna clung to Erika.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna180"]
[OnName num="Yuna"]
"You can't go to the police... That will affect my higher education and any chance at employment..."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika358"]
[OnName num="Erika"]
"O-okay!"
[cpg cn=true]

;//金の鍵

[OnName num="Kenji"]
"A key...?"
[cpg cn=true]

Erika pulled out a small golden key from her skirt pocket.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika359"]
[OnName num="Erika"]
"That's all I stole! If you think I'm lying, why don't you conduct a body search?"
[cpg cn=true]

[OnName num="Kenji"]
"What's this key for?"
[cpg cn=true]

I questioned both of them, as the shape and size of the key didn't seem to be a door key.
[cpg]

But...
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna181"]
[OnName num="Yuna"]
"I don't know... That's why Erika said we'd find out tomorrow what kind of key it is..."
[cpg cn=true]

[OnName num="Kenji"]
"Okay. Anyway, don't steal anything."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika360"]
[OnName num="Erika"]
"Oh, come onー, you're such a goody two shoes!"
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna182"]
[OnName num="Yuna"]
"Erika..., let's go..."
[cpg cn=true]

Yuna went up the stairs in a daze, Erika in a whimper.
[cpg]

I stared at the key in my hand and thought about it.
[cpg]

Since I stopped them from stealing in the end, I wasn't going to tell on them.
[cpg]

I could put it back when I got the chance…
[cpg]

So I put the little gold key in my pants pocket and went back to my room.
[cpg]



[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_tbr_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・専門書の部屋　夜（暗／蝋燭／机に大量の本）******************************************************

;//机の上に大量の本が山積み
[OnName num="Kenji"]
"Wow~, what a messー!"
[cpg cn=true]

I shouted as I noticed a pile of books on my desk, which was always empty.
[cpg]

I'm sure Hosokawa was here during the day.
[cpg]

He must have left it there, I thought.
[cpg]

[OnName num="Kenji"]
"All those books are so thick! That scrawny bastard..."
[cpg cn=true]

Swearing at Hosokawa, I wrapped myself in a blanket.
[cpg]

I don't care what Michi says, I will never forgive that bastard.
[cpg]

If I ever get out of here, I'm going to beat the shit out of him!
[cpg]

My head and body were on edge, but the midnight chill gradually cooled me down and I fell asleep, just as I had done yesterday.
[cpg]

[STOPBGM]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=3000]

;//８cへ合流
[jump target="*s8_c"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//８c
*s8_c|Unshakeable Anxiety

[stopse g=2]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="ep008.ks" target="*start"]


