*start

*root_b|Refuse!
;//『ルートＢ』
;#################################################
*Ep015|Refuse!
;#################################################
[SCENE id=9]

I headed to the bathroom to drink some water before I went to bed.
[cpg]

Normally I wouldn't drink tap water, but even that didn't matter at this point.
[cpg]

Water was water.
[cpg]


[free time=900]
[BG f="black.ui" time=2000]
[WAIT time=3000]
[BG f="b_l_1f_entrance_p4.ui" time=2000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）******************************************************

[WAIT time=3000]

;//[BGM f="dod"]


[FG f="CHA06_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko128"]
[OnName num="Syouko"]
"What? Are you still awake, Kenji?"
[cpg cn=true]

When I went out to the entrance, Shoko had a tray with a tea set and was heading for the stairs.
[cpg]

[OnName num="Kenji"]
"I thought I'd get a drink of water."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko129"]
[OnName num="Syouko"]
"Water? There's mineral water in the pantry."
[cpg cn=true]

[OnName num="Kenji"]
"Thanks. What's that tea for?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko130"]
[OnName num="Syouko"]
"Oh, this? I was counting how many cups of tea I had left, just in case."
[cpg cn=true]

[VOICE f="Syouko1130"]
[OnName num="Syouko"]
"And then I found something in stock that looked expensive. I thought I'd give it to Shiori to drink."
[cpg cn=true]


[OnName num="Kenji"]
"I see."
[cpg cn=true]

It originally came from Shiori's house, so Shiori should drink it.
[cpg]

I was impressed with Shoko for being surprisingly aware of some things.
[cpg]

[OnName num="Kenji"]
"You're a good person, aren't you, Shoko ?"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko131"]
[OnName num="Syouko"]
"Huh?!"
[cpg cn=true]

I wasn't sure what surprised her so much about my words, but Shoko quickly removed her hand from the tray.
[cpg]

[OnName num="Kenji"]
"Wahー!"
[cpg cn=true]

[SE f="se100"]
;//【ＳＥ】食器が少し揺れる（カチャリ）
I quickly propped up the tray so it didn't fall over, but Shoko was unusually flustered.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko132"]
[OnName num="Syouko"]
"Ah! I'm s-s-sorry!"
[cpg cn=true]

[OnName num="Kenji"]
"It's okay, but... Why don't I carry this? You don't want to drop it on the stairs or anything."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko133"]
[OnName num="Syouko"]
"Uh~... Sorry..."
[cpg cn=true]

[OnName num="Kenji"]
"I'll tell her it's from you, Shoko"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko134"]
[OnName num="Syouko"]
"That's very kind of you. I'm so sorry..."
[cpg cn=true]

Shoko bowed over and over like a drinking bird.
[cpg]

In a way, it was funny to watch.
[cpg]

[OnName num="Kenji"]
"But, there was such nice cups. We always use paper cups."
[cpg cn=true]

I was strangely impressed by the tea set on the tray.
[cpg]

I didn't know what it was worth, but it was a very nice western style set.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko135"]
[OnName num="Syouko"]
"Yeahー. I was rummaging around in the storage room and found it, so I wanted to use it."
[cpg cn=true]

[VOICE f="Syouko1135"]
[OnName num="Syouko"]
"Oh, please don't tell anyone that I broke one of the cups in the set..."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah..."
[cpg cn=true]

Does Shoko know she's digging her own grave when she answers questions nobody asked?
[cpg]

[OnName num="Kenji"]
"Well, I'm off, then."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko136"]
[OnName num="Syouko"]
"Yes! Then please give my regards to Shiori."
[cpg cn=true]

[free time=1000]

I wondered...
[cpg]

I walked up the stairs with the tray carefully in my hands.
[cpg]

Wait...?
[cpg]

Was that a good idea... Rummaging through the storage room?
[cpg]

Why would Shoko go through the storage room?
[cpg]

I don't think it was for the same reason as Erika...
[cpg]

[OnName num="Kenji"]
"Nope... I shouldn't be suspicious of people..."
[cpg cn=true]

I pushed down the suspicion in my chest and headed for Shiori's room.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_lpass_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・左側廊下　夜（暗）******************************************************

[WAIT time=1500]

[OnName num="Kenji"]
"I wonder if Shiori is still awake~"
[cpg cn=true]

Honestly, it wasn't even that I wanted to bring her tea, I just wanted to be with Shiori.
[cpg]

It isn't that I have an ulterior motive just because it is nighttime.
[cpg]

No..., it's not that I don't have one, but...
[cpg]

No, no!
[cpg]

I'm not that kind of guy.
[cpg]

So I'm just going to give Shiori this and then we'll talk a little bit if she wants.
[cpg]

That's it.
[cpg]

[OnName num="Kenji"]
"Yeah, that's it!"
[cpg cn=true]

When I came to the front of Shiori 's room...
[cpg]

I walked up to Shiori's room and took a deep breath to calm myself down.
[cpg]

[STOPBGM]

[VOICE f="Michi335"]
[OnName num="Michi"]
"Is it okay? Is it cold?"
[cpg cn=true]


[VOICE f="Shiori195"]
[OnName num="Shiori"]
"Yeah..., it's nice and warm..."
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

[BGM f="h1"]

Then I heard Shiori and Michi's voices from inside the room.
[cpg]

...It seemed like they were doing something.
[cpg]

I stopped myself from knocking.
[cpg]


[VOICE f="Michi336"]
[OnName num="Michi"]
"Lift your arm up a little..."
[cpg cn=true]


[VOICE f="Shiori196"]
[OnName num="Shiori"]
"It tickles..."
[cpg cn=true]

It seemed like Michi was wiping Shiori's body.
[cpg]

That's all, but everything I overheard from their conversation swelled up in my head on it's own.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）******************************************************

[OnName num="Kenji"]
"......"
[cpg cn=true]

I couldn't stand it any longer and left...that place.
[cpg]

I knew that if I stayed here any longer I would start to have bad thoughts.
[cpg]

Good night, Shiori...
[cpg]

[STOPBGM]

;//エフェクト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=2100]
[free time=100]
[BG f="black.ui" time=100]
[window target=true]


[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 22nd
[cpg]

[window target=false]
[BG f="b_l_1f_tbr_p2.ui" time=100]
;//【ＢＧ】図書館・１階・専門書の部屋　昼（エントランスからの光）******************************************************
[WAIT time=2000]

[transition target={false} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=3000]

[window target=true]


[SE f="se101"]
;//【ＳＥ】ガンガンガン！

[OnName num="Kenji"]
"What the hell?!"
[cpg cn=true]

When I jumped up at a sudden noise, it seemed that the mysterious sound was coming from the entrance.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=1500]

[BGM f="danger"]


[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika393"]
[OnName num="Erika"]
"Waaaaaaaaaaah!!"
[cpg cn=true]

[OnName num="Kenji"]
"Hey..."
[cpg cn=true]

When I went out to the entrance, I saw that Erika was raising a chair and attacking the front door.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA06_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko137"]
[OnName num="Syouko"]
"Argh...."
[cpg cn=true]

[VOICE f="Yuna195"]
[OnName num="Yuna"]
"Ugh!"
[cpg cn=true]

Watching from afar, Yuna and Shoko just cringed in fear, and I had no idea what was going on.
[cpg]


[OnName num="Kenji"]
"What are you doing?!"
[cpg cn=true]

I yelled from a short distance away, and Erika yelled back, swinging a chair at the door repeatedly.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika394"]
[OnName num="Erika"]
"I'm breaking down the door! I'm not going to stay here for another minute!"
[cpg cn=true]

[OnName num="Kenji"]
"Why all of a sudden?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika395"]
[OnName num="Erika"]
"It's gone!"
[cpg cn=true]

[OnName num="Kenji"]
"What' gone?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika396"]
[OnName num="Erika"]
"Hosokawa's body just disappeared from the infirmary! There's a psycho! There's a psychopathic killer among us hereー!"
[cpg cn=true]

[SE f="se101"]
;//【ＳＥ】ガンガンガン！

[OnName num="Kenji"]
"So, what do we do...?"
[cpg cn=true]

Covered in sweat, Erika continued to attack the door like a madwoman.
[cpg]

If I tried to stop her now, she was going to crack my head open.
[cpg]

There...
[cpg]

[SE f="se069"]
;//【ＳＥ】小走り
[OnName num="Kenji"]
"Oh, Michi..."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Michi337"]
[OnName num="Michi"]
".................."
[cpg cn=true]

Michi had come running out from somewhere, slipped past me and went to Erika's side, where she quickly put something near her shoulder.
[cpg]

[SE f="se102"]
;//【ＳＥ】プスッ

[STOPBGM]

[WAIT time=2000]


[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika397"]
[OnName num="Erika"]
"Huh...?"
[cpg cn=true]

A few seconds later, I looked back at Erika, who had a strange look on her face...
[cpg]

[free time=1000]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/5" time=1000]

;//[SE f="se000"]
;//【ＳＥ】椅子落ちる
[OnName num="Kenji"]
"?!"
[cpg cn=true]

The chair was taken out of her hands and she slumped down into a crouch.
[cpg]

Michi supported Erika as she fell, but then lowered her to the floor and left her there.
[cpg]

[BGM f="silent"]


[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi338"]
[OnName num="Michi"]
"Huh..."
[cpg cn=true]

[move from="2/5" to="2/3" ease="easeInOutSine" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna196"]
[OnName num="Yuna"]
"What did you do?!"
[cpg cn=true]

Yuna and Shoko ran up to me, and I approached Michi.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi339"]
[OnName num="Michi"]
"It's just a sedative. She'll wake up"
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna197"]
[OnName num="Yuna"]
"Sedative...?"
[cpg cn=true]

Yuna stared at Erika with concern.
[cpg]

Meanwhile, Shoko's eyes twinkled with praise.
[cpg]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko138"]
[OnName num="Syouko"]
"Well done, Doctor! You were like an assassin from a movie!"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi340"]
[OnName num="Michi"]
"Is that a compliment...?"
[cpg cn=true]

[SE f="se025"]
;//【ＳＥ】ガーン
[FACE method="change_4" pos="3/3"]
[WAIT time=1000]


[OnName num="Kenji"]
"S-so... Hosokawa's body has disappeared?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi341"]
[OnName num="Michi"]
"Yes... I went to the infirmary this morning as soon as I woke up, and it had already..."
[cpg cn=true]

[OnName num="Kenji"]
"What?! Is that true? Where did it go...?"
[cpg cn=true]

I was so upset, but no one would give me an answer.
[cpg]

Just like with Takagi, no one knows what happened.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko139"]
[OnName num="Syouko"]
"Hey~, What if it's a new kind of virus or bacteria that eats up corpses..."
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi342"]
[OnName num="Michi"]
"There is no such thing."
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko140"]
[OnName num="Syouko"]
"Yeah, guess not..."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi343"]
[OnName num="Michi"]
"Anyway..., we need to get Erika to the infirmary."
[cpg cn=true]

[OnName num="Kenji"]
"I'll help."
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko141"]
[OnName num="Syouko"]
"Oh, Kenji! I got this! Don't worry. I can carry a woman."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, really?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi344"]
[OnName num="Michi"]
"Then, please."
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko142"]
[OnName num="Syouko"]
"Yes!"
[cpg cn=true]

To my surprise, Shoko was able to lift Erika's body all by herself.
[cpg]

[move from="2/3" to="5/3" ease="easeInOutSine" time=2000]

[move from="3/3" to="6/3" ease="easeInOutSine" time=2000]


I hear that nurses are strong people, and I'm impressed that they really are.
[cpg]

When Michi and Shoko went to the basement, Yuna, who stayed back, approached me and began to whisper a secret to me.
[cpg]

[move from="1/3" to="2/3" ease="easeInOutSine" time=1000]
[WAIT time=100]
[VOICE f="Yuna198"]
[OnName num="Yuna"]
"Did you see...just now?"
[cpg cn=true]

[OnName num="Kenji"]
"What do you mean?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna199"]
[OnName num="Yuna"]
"The injection!"
[cpg cn=true]

[OnName num="Kenji"]
"Oh, yeah, that was amazing."
[cpg cn=true]

The way Michi carried herself, the quickness with which she took down her prey in an instant, she was a real professional!
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna200"]
[OnName num="Yuna"]
"That's not it! If that wasn't a sedative, but a poison..."
[cpg cn=true]

[OnName num="Kenji"]
"Poison?!"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna201"]
[OnName num="Yuna"]
"I'm sure Erika's injection was different, but Hosokawa had no external injuries, right? If it was Ms. Kisaragi, she could have killed him with an injection like that..."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Shiori197"]
[OnName num="Shiori"]
"Not the doctor."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna202"]
[OnName num="Yuna"]
"What?!"
[cpg cn=true]

[OnName num="Kenji"]
"Shiori..."
[cpg cn=true]

Before we knew it, Shiori was standing behind us, looking a little angry at Michi being treated like a criminal.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna203"]
[OnName num="Yuna"]
"It doesn't mean that Ms. Kisaragi is the culprit... I just think he might have been killed by injection..."
[cpg cn=true]

When confronted about her suspicions, Yuna made lame excuses.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna204"]
[OnName num="Yuna"]
"F-first of all...Michi doesn't have a motive...right? Kenji."
[cpg cn=true]

[OnName num="Kenji"]
"Hmm? Oh.."
[cpg cn=true]

Yuna said she had no motive, but was that really true?
[cpg]

Hosokawa was all over Michi, so that's a motive, like self-defense or out of anger.
[cpg]

On the other hand, Takagi was making a pass at Shiori, so Michi might have stabbed him to protect her.
[cpg]

They're so close...and all...
[cpg]

I remembered what I witnessed that evening, and was seized with something that felt like jealousy.
[cpg]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori198"]
[OnName num="Shiori"]
"Kenji...? Are you Kenji also suspicious of the doctor?"
[cpg cn=true]

[OnName num="Kenji"]
"What? No, no way!"
[cpg cn=true]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori199"]
[OnName num="Shiori"]
"Good..."
[cpg cn=true]

For a moment, Shiori almost looked at me suspiciously, and I hurriedly dismissed the idea in my head.
[cpg]

[OnName num="Kenji"]
"It must have been an accident. Both of them had accidental deaths!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna205"]
[OnName num="Yuna"]
"They couldn't have died accidentally. Then why did their bodies disappear?"
[cpg cn=true]

[OnName num="Kenji"]
"Well, th-that's..."
[cpg cn=true]

That's right.
[cpg]

Even if I convinced myself that the deaths were accidental, I still couldn't understand why the bodies disappeared.
[cpg]

In other words, I couldn't understand why the killer had to hide the bodies.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna206"]
[OnName num="Yuna"]
"What should we do...? I want to get out of here as soon as possible..."
[cpg cn=true]

[OnName num="Kenji"]
"Y-yeah, I know, but..."
[cpg cn=true]

I felt like I should have been comforting Yuna, who was frightened, but I couldn't because I felt like Shiori would be offended if I just agreed with her.
[cpg]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori200"]
[OnName num="Shiori"]
"Kenji , don't worry about me... I see how uneasy everyone is."
[cpg cn=true]

[OnName num="Kenji"]
"I'm sorry..."
[cpg cn=true]

Shiori is more concerned about me.
[cpg]

I felt bad about it...
[cpg]

[STOPBGM]

;//エフェクト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=2100]


[window target=true]
;//【ＢＧ】ブラックアウト
[free time=100]
[BG f="black.ui" time=100]
[WAIT time=1500]

;//＠エンドの数を確認する

[if exp={ isSystemFlagsEnabled( "end1", "end2", "end3", "end4", "end5") }]
[jump target="*j5_a"]
[else]
[jump target="*j5_c"]
[endif]

;//※全てのエンド制覇で、以下破線内のシーン挿入
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～
*j5_a|Refuse!

[window target=true]

Around that time, there was this conversation going on in the infirmary...
[cpg]

[window target=false]


[BG f="b_l_b1_disp_0.ui" time=100]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン閉／蝋燭）******************************************************
[WAIT time=100]

[transition target={false} rule="163.jpg" color={0x000000ff} time=2000]
[WAIT time=3100]

[window target=true]

[BGM f="huan"]


[FG f="CHA03_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika398"]
[OnName num="Erika"]
"Uh...ugh."
[cpg cn=true]

;//コトハ
[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shiori201"]
[OnName num="Shiori"]
"Oh, did I wake you...?"
[cpg cn=true]



[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika399"]
[OnName num="Erika"]
"Huh..., Shiori? Why am I...here?"
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="2/5"]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori202"]
[OnName num="Shiori"]
"You were just sleeping."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika400"]
[OnName num="Erika"]
"I was...?"
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori203"]
[OnName num="Shiori"]
"Yeah. And, uh..., no, never mind..."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika401"]
[OnName num="Erika"]
"What? Don't stop when you were just about to say something, okay?"
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori204"]
[OnName num="Shiori"]
"Yeah... But I don't want Erika to be bothered by it..."
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika402"]
[OnName num="Erika"]
"What? It's bothering me too muchー! Just tell me!"
[cpg cn=true]

;//コトハ
[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori205"]
[OnName num="Shiori"]
"You know, I just saw...Yuna coming on to Kenji."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika403"]
[OnName num="Erika"]
"Huh? What? Are you kidding me?"
[cpg cn=true]

;//コトハ
[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori206"]
[OnName num="Shiori"]
"I'm pretty sure. I mean, she was hugging him and trying to...kiss him."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika404"]
[OnName num="Erika"]
"What?!"
[cpg cn=true]

;//コトハ
[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori207"]
[OnName num="Shiori"]
"Yeah, but I don't think she got to! But, Erika... If you're not careful, Yuna might take Kenji from you...?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika405"]
[OnName num="Erika"]
"I don't believe it... Yuna, she calls herself my best friend..."
[cpg cn=true]

;//コトハ
[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori208"]
[OnName num="Shiori"]
"Hehehe..., Well, see you. Take care..."
[cpg cn=true]

[STOPBGM]

[window target=false]
[transition target={true} rule="163.jpg" color={0x000000ff} time=2000]
[WAIT time=2100]

;//【ＢＧ】ブラックアウト
[free time=100]
[BG f="black.ui" time=100]
[WAIT time=200]

;//追加開始前にメッセージウィンドウを消してるので追加分岐の外で表示に切り替える
;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～
*j5_c|Refuse!


[BG f="b_l_1f_entrance_p4.ui" time=100]
;//【ＢＧ】図書館・１階・エントランス　夜（暗／蝋燭）******************************************************
[WAIT time=2000]
[transition target={false} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=3100]
[window target=true]

[BGM f="dod"]


In the evening, Erika came back to life.
[cpg]

It seemed that Erika was just in time for the last supper.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi345"]
[OnName num="Michi"]
"Well then, let us have...hope that help will come tomorrow."
[cpg cn=true]

Whether we cried or laughed, this was our last supper.
[cpg]

If no one comes tomorrow, we'll have to survive on water alone...
[cpg]

I was afraid that Erika would say something about this, but she was silent, as if she was still drugged up.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA03_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika406"]
[OnName num="Erika"]
".................."
[cpg cn=true]

[OnName num="Kenji"]
"Erika, do you want a spoon?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika407"]
[OnName num="Erika"]
"Mm, please..."
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna207"]
[OnName num="Yuna"]
"Erika, do you want green tea? Do you want black tea?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika408"]
[OnName num="Erika"]
"Nurse, coffee, please."
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko143"]
[OnName num="Syouko"]
"Y-yes."
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna208"]
[OnName num="Yuna"]
"Erika...?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika409"]
[OnName num="Erika"]
".................."
[cpg cn=true]

[OnName num="Kenji"]
"What's going on?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika410"]
[OnName num="Erika"]
"Nothing..."
[cpg cn=true]

She said, "nothing," with such a stern face.
[cpg]

I felt that Erika was acting cold only towards Yuna.
[cpg]

Why was she suddenly angry after waking up?
[cpg]

[free time=1]
[WAIT time=1]

;//※以下、この日が終わるまで栞はコトハ
;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori209"]
[OnName num="Shiori"]
"Hey, Kenji. Give me some of that."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, sure. Here."
[cpg cn=true]

Feeling much better, Shiori seemed to have an appetite and asked for some of the gummies I had been eating.
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori210"]
[OnName num="Shiori"]
"Delicious...!"
[cpg cn=true]

[OnName num="Kenji"]
"I'm glad to hear that. I'm glad you're feeling better."
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori211"]
[OnName num="Shiori"]
"Yeah... I'm sorry I worried you. But I'm fine now."
[cpg cn=true]

[OnName num="Kenji"]
"I see."
[cpg cn=true]

Seeing Shiori chatting happily with me, Shoko spoke to Michi with admiration.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_2" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko144"]
[OnName num="Syouko"]
"Doctor, that medicine really works! It seems like Shiori is all better now."
[cpg cn=true]


[VOICE f="Michi346"]
[OnName num="Michi"]
"Yeah..."
[cpg cn=true]

[free time=1]
[WAIT time=1]

[FG f="CHA02_p3_01_a.ui" method="change_2" pos="2/3" time=800]

As Shoko said, Shiori was in a good mood and eating normally.
[cpg]

[OnName num="Kenji"]
"Would you like to try some of this?"
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori212"]
[OnName num="Shiori"]
Thank you..., but Kenji, if you don't eat properly, you'll lose weight. Kenji, I don't want you to get fat or skinny..."
[cpg cn=true]

[OnName num="Kenji"]
"Hahaha, I'm not going to change that quickly."
[cpg cn=true]

The last supper seemed to be more delicious than usual, especially because Shiori's concern made me happy.
[cpg]

And yet...
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yuna209"]
[OnName num="Yuna"]
"Hey. Hey, Erika. Why are you angry?"
[cpg cn=true]

[VOICE f="Erika411"]
[OnName num="Erika"]
"No reason..."
[cpg cn=true]

The two of them were in a very bad mood, the exact opposite of the rest of us.
[cpg]

What was wrong with them all of a sudden?
[cpg]

[free time=1]
[WAIT time=1]
;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori213"]
[OnName num="Shiori"]
"I'm feeling better, Kenji, and I'd like to talk with you a little more tonight..."
[cpg cn=true]

[OnName num="Kenji"]
"Really? Of course I'd love to!"
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori214"]
[OnName num="Shiori"]
"Then, when we're done cleaning up, come to my room in private. If my doctor finds out, she'll scold you..."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, okay!"
[cpg cn=true]

I was so happy that I jumped up and down on the inside.
[cpg]

I was just happy that Shiori was feeling better, and I was thrilled that she was inviting me to her room.
[cpg]

I tidied up, excited, wondering about what we were going to talk about.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA03_p3_01_a.ui" method="change_7" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika412"]
[OnName num="Erika"]
"Yuna... I have something I want to talk to you about, so I need to see you later."
[cpg cn=true]

[WAIT time=100]
[VOICE f="Yuna210"]
[OnName num="Yuna"]
"Eh..., um, yeah...okay."
[cpg cn=true]

[OnName num="Kenji"]
"~♪"
[cpg cn=true]

My mind was somewhere else.
[cpg]

So I didn't pay any attention to what my two classmates were going to talk about afterwards.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_ros_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

[WAIT time=1500]

;//（※栞の部屋だが、いるのはコトハ）
[OnName num="Kenji"]
"I'm sorry to disturb you~"
[cpg cn=true]

I came to Shiori's room, careful not to be seen by the others.
[cpg]

Every time I stepped into her room, I felt like I was getting a little closer to her.
[cpg]

;//コトハ
[FG f="CHA01_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori215"]
[OnName num="Shiori"]
"Welcome. Hehehe."
[cpg cn=true]

[OnName num="Kenji"]
"It is really well done, though..."
[cpg cn=true]

I looked at a plaster statue of a cat and tried to comment on it.
[cpg]

[OnName num="Kenji"]
"You like animals?"
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori216"]
[OnName num="Shiori"]
"Yes."
[cpg cn=true]

[OnName num="Kenji"]
"Then why don't you get a pet?"
[cpg cn=true]

Shiori replied to my words with a slightly sad look on her face.
[cpg]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori217"]
[OnName num="Shiori"]
"Because living things die..."
[cpg cn=true]

Oh, like I thought, Shiori was still grieving over her grandfather.
[cpg]

Processing her grandfather's death was a painful memory for her.
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori218"]
[OnName num="Shiori"]
"It's better to see living creatures in a good condition, rather than to see them emaciated and wasting away."
[cpg cn=true]

Shiori said, staring at the white-faced dog and cat with gentle eyes.
[cpg]

[OnName num="Kenji"]
"I suppose you could say that."
[cpg cn=true]

I guess Shiori has never had anyone to talk to about these things before.
[cpg]

[FACE method="change_6" pos="2/3"]

I could see that her eyes were watering as she looked at me.
[cpg]

blush
[cpg]

[OnName num="Kenji"]
"......."
[cpg cn=true]

I could feel my ears burning as she stared at me with her beautiful eyes.
[cpg]

[if exp={getFlagValue("Key") > 0 }]
[jump target="*key2_t"]
[else]
[jump target="*key2_f"]
[endif]



;//※＜鍵フラグ＞が立っている場合、以下破線内の文章が挿入される
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～

*key2_t|Refuse!

Wanting to hide my red face, I unintentionally turned my back on Shiori and escaped by looking in the mirror.
[cpg]


;//※鏡に映った（実際は鏡の向こう）部屋の中に本が散乱している
[free time=1000]
[BG f="b_l_2f_rok_0.ui" time=1000]
;//【ＢＧ】図書館・２階・コトハの部屋
[WAIT time=2000]


[OnName num="Kenji"]
"Uh..."
[cpg cn=true]

I saw a glimpse of the room in the mirror.
[cpg]

I saw a number of books scattered on the floor.
[cpg]

[OnName num="Kenji"]
"Huh? There are books on the floor..."
[cpg cn=true]


[BG f="b_l_1f_ros_p4.ui" time=1]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

I turned around and looked around the room and saw that all the books here were neatly stored in the bookcase.
[cpg]

[OnName num="Kenji"]
"Strange, huh?"
[cpg cn=true]

So I looked in the mirror again, but it seemed to be an optical illusion and there were no books on the floor of the room in the reflection.
[cpg]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori219"]
[OnName num="Shiori"]
"Did something happen?"
[cpg cn=true]

[OnName num="Kenji"]
"What? No, it's nothing."
[cpg cn=true]

Maybe I was just tired.
[cpg]

;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～

*key2_f|Refuse!

I went back to the conversation with a nonchalant face so that Shiori wouldn't notice.
[cpg]

[OnName num="Kenji"]
"I understand having animals because they're cute to look at. But I don't think I can understand having their arms and legs~"
[cpg cn=true]

I said playfully, pointing to the arm that was lying on the floor.
[cpg]


;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori220"]
[OnName num="Shiori"]
"That was just practice. In order to become good at it, it's important to practice, because I don't want to fail when I make the real thing..."
[cpg cn=true]

[OnName num="Kenji"]
"I see. Shiori, you're very diligent."
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori221"]
[OnName num="Shiori"]
"Not really..."
[cpg cn=true]

Crunch..crunch...
[cpg]

For a while now, Shiori had been constantly biting her nails.
[cpg]

Her gestures were like a baby or a small animal, and to my eyes it was very endearing.
[cpg]

But if I looked closely, I could see that her nails had become a little jagged, and I was wondering if I should bring attention to them.
[cpg]



;//[BG f="b_l_1f_ros_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

;//[WAIT time=1000]

[STOPBGM]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori222"]
[OnName num="Shiori"]
"Hey... Kenji, you know what..."
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori223"]
[OnName num="Shiori"]
"Which is better...?"
[cpg cn=true]

[OnName num="Kenji"]
"Between what and what?"
[cpg cn=true]

As Shiori approached me slowly, she asked me a question I hadn't expected.
[cpg]

;//コトハ
[FG f="CHA02_p5_01_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori224"]
[OnName num="Shiori"]
"Do you want to talk..., or do you want to do this...?"
[cpg cn=true]

[OnName num="Kenji"]
"What...hmm?"
[cpg cn=true]

The next thing I knew, Shiori's hands were around my neck.
[cpg]

I couldn't help but grab her around the waist and we embraced like lovers.
[cpg]


;//[free time=900]
;//[BG f="black.ui" time=900]
;//[WAIT time=1500]
;//[BG f="b_l_2f_ros_0.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）
;//[WAIT time=1500]


[BGM f="h1"]


;//コトハ
[FG f="CHA02_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori225"]
[OnName num="Shiori"]
"Kenji, I've been admiring you for a long time."
[cpg cn=true]

[OnName num="Kenji"]
"Admiring? Me?"
[cpg cn=true]

What could a girl as beautiful as Shiori possibly see in me?
[cpg]

I'm flattered, but it was a mystery.
[cpg]

;//コトハ
[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori226"]
[OnName num="Shiori"]
"Because Kenji, you're...beautiful."
[cpg cn=true]

[OnName num="Kenji"]
"Beautiful...?"
[cpg cn=true]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori227"]
[OnName num="Shiori"]
"Unlike other people who come here, your shoulders and legs are ideal."
[cpg cn=true]

[VOICE f="Shiori1227"]
[OnName num="Shiori"]
"And since I've seen you up close, I've noticed that you don't have any pores and you have very little facial hair..."
[cpg cn=true]

[OnName num="Kenji"]
"Really?"
[cpg cn=true]

Since Shiori's hobby is sculpting, she probably has a keen eye for people's appearances.
[cpg]

So if I had been a little fatter or thinner than I am now, we might not have gotten along like this...
[cpg]

I learned to be grateful to my parents for giving me birth.
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori228"]
[OnName num="Shiori"]
"So I want to be close to you all the time, Kenji, like this."
[cpg cn=true]

So that's why she's done something so bold? I am very happy, but at the same time I feel very embarrassed.
[cpg]

However, Shiori had more surprises in store...
[cpg]

;//コトハ
[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori229"]
[OnName num="Shiori"]
"I said, 'I want to see' as a joke, but..., I really want to see all of your body, Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"Uh..., that's..."
[cpg cn=true]

What that meant was that she wanted to see me naked...
[cpg]

But would that be in an artistic sense, unlike what I'm thinking... I don't know!
[cpg]

What should I do...? What should I do...?
[cpg]


;//■選択肢１０（２択）
[switch]
[case "Show her"]
	[swap]
	[jump target="*s10_a"]
[case "Hesitate"]
	[swap]
	[jump storage="ep018.ks" target="*start"]
[endswitch]
;//１，見せてやる　　//このまま進行
;//２，ためらう　　　//『ルートＣ』へ
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１，見せてやる
*s10_a|Refuse!

Right, I'm a man.
[cpg]

[OnName num="Kenji"]
"If you insist, I'll show you..."
[cpg cn=true]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori230"]
[OnName num="Shiori"]
"Really! I'm so happy."
[cpg cn=true]

I was incredibly embarrassed, but I would have done anything for Shiori.
[cpg]

[SE f="se137"]
;//【ＳＥ】衣擦れ
I took off my jacket, my shirt, my pants, and my shorts.
[cpg]

;//コトハ
[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori231"]
[OnName num="Shiori"]
"Oh..., I knew it..."
[cpg cn=true]

Shiori looked at me wistfully and began to go into detail, looking very happy.
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori232"]
[OnName num="Shiori"]
"Not only are your biceps in good shape, but your triceps too... Your quads are all evenly balanced..., and your total golden ratio is perfect..."
[cpg cn=true]

[OnName num="Kenji"]
"Is that a good thing?"
[cpg cn=true]

Shiori vigorously nodded at my words.
[cpg]

[OnName num="Kenji"]
"Oh, really?"
[cpg cn=true]

I've never thought of my body as beautiful, but I was pleased to see Shiori's cheeks flush with delight.
[cpg]

[OnName num="Kenji"]
"I'm glad I could be a reference for Shiori."
[cpg cn=true]

;//コトハ
[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori233"]
[OnName num="Shiori"]
"Reference! That's not your level, Kenji... Hey, can I....touch you for a little?"
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, sure, but..."
[cpg cn=true]

slide...
Shiori put her finger on my stomach and slowly slid it down.
[cpg]

[OnName num="Kenji"]
"..."
[cpg cn=true]

;//コトハ
[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori234"]
[OnName num="Shiori"]
"You're more beautiful than I thought... I never imagined..."
[cpg cn=true]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori235"]
[OnName num="Shiori"]
"I want you..."
[cpg cn=true]

[OnName num="Kenji"]
"Shi...Shiori...?"
[cpg cn=true]

I hugged Shiori who was right in front of me and put my lips on hers.
[cpg]

;//コトハ
[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori236"]
[OnName num="Shiori"]
"Mmm..., ah..., Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"I love you... I love you...!"
[cpg cn=true]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori237"]
[OnName num="Shiori"]
"Me too..."
[cpg cn=true]

Feeling the tender passion from each other's body heat, we embraced.
[cpg]

And like that, time passed.
[cpg]

;#############################################################
;//Ev007|断る！
;#############################################################

[STOPBGM]
;//＠
;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=3000]
[BG f="b_l_1f_ros_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

[WAIT time=1500]

[BGM f="dod"]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori238"]
[OnName num="Shiori"]
"I think the doctor will be here soon, so..."
[cpg cn=true]

[OnName num="Kenji"]
"Ah, y-yes. That's right."
[cpg cn=true]

For a while, Shiori and I hugged each other, but after she said that I left.
[cpg]

I would have liked to stay like that for a long time. I was reluctant to leave, but it couldn't be helped.
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori239"]
[OnName num="Shiori"]
"See you later... Kenji."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, later. Good night."
[cpg cn=true]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori240"]
[OnName num="Shiori"]
"Good night."
[cpg cn=true]

That day, I left Shiori's room and fell into a happy sleep.
[cpg]

[STOPBGM]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

;//＠
[if exp={ isSystemFlagsEnabled( "end1", "end2", "end3", "end4", "end5") }]
[jump target="*j6_a"]
[else]
[jump target="*j6_c"]
[endif]

;//※エンド制覇で以下破線内シーン挿入
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～

*j6_a|Refuse!

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_ware_0.ui" time=1000]
;//【ＢＧ】図書館・地下・非常用倉庫　（暗／懐中電灯）******************************************************

[WAIT time=1500]

[BGM f="huan"]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika413"]
[OnName num="Erika"]
"Yuna, what are you doing?"
[cpg cn=true]

[VOICE f="Yuna211"]
[OnName num="Yuna"]
"What do you mean?"
[cpg cn=true]

The atmosphere in the panty was uneasy...
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika414"]
[OnName num="Erika"]
"Don't play dumb with me! I told you, didn't I? I told you not to flirt with Kenji."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna212"]
[OnName num="Yuna"]
"Huh?"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika415"]
[OnName num="Erika"]
"Why are all over Kenji?"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna213"]
[OnName num="Yuna"]
"What?! I never did that..."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika416"]
[OnName num="Erika"]
"You're messing around with the guy I like, when you're supposed to be my best friend?"
[cpg cn=true]

[SE f="se070"]
;//【ＳＥ】ビンタ

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna214"]
[OnName num="Yuna"]
"Aah!"
[cpg cn=true]

Erika slapped Yuna on the cheek as hard as she could.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika417"]
[OnName num="Erika"]
"Have you forgot who helped you become a model student?"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna215"]
[OnName num="Yuna"]
"No, I haven't. But..., that was such a long time ago..."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika418"]
[OnName num="Erika"]
"I'm hungry~ What~? Oh, right. I shoplifted, like, three loaves of bread!"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna216"]
[OnName num="Yuna"]
"Ugh..."
[cpg cn=true]

As a young child, Yuna was abused by her own father and was not given enough to eat.
[cpg]

She got so hungry that she stole food on the street and was discovered by Erika.
[cpg]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika419"]
[OnName num="Erika"]
"It's sad that it could even be called bread."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna217"]
[OnName num="Yuna"]
"No, because..., at that time..."
[cpg cn=true]

Anyway, the fear of dying if she didn't put something in her mouth had already ingrained into Yuna at an early age.
[cpg]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika420"]
[OnName num="Erika"]
"I didn't tell anyone and that's why you could live a normal life. If I had told everyone then, you definitely would have been bullied."
[cpg cn=true]

In primary school, a boy from a poor family in our class was severely bullied after he was caught shoplifting.
[cpg]

Yuna had always been looking to Erika in fear that she might end up like that poor boy.
[cpg]

Being abused by your father at home and then bullied by your friends at school, would make her life a living hell.
[cpg]

She wanted to avoid that.
[cpg]

But now her parents are divorced and she is living peacefully with her mother's second husband.
[cpg]

Only Erika was a threat to Yuna, and ironically, the fact that they shared this secret helped them form a strong bond.
[cpg]

It's almost like imprinting, but the trauma, etched deep in her psyche, has created Yuna's personality by building on her weaknesses.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika421"]
[OnName num="Erika"]
"I thought you were good at stealing, so I gave you a job and you failed. And now you're trying to steal my man. What nerve!"
[cpg cn=true]

Erika looked down at Yuna with the same intense eyes she had when she was a child.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna218"]
[OnName num="Yuna"]
"I didn't mean to... I just talked to Kenji because I was scared..."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika422"]
[OnName num="Erika"]
"You've been on a bit of a roll lately."
[cpg cn=true]

Erika spat bitterly at her.
[cpg]

;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～

*j6_c|Refuse!

;#############################################################
;//Ev008|
;#############################################################

[STOPBGM]
;//【ＢＧ】ブラックアウト
[free time=1500]
[BG f="black.ui" time=1500]
[WAIT time=3000]

[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 23rd
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_tbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・専門書の部屋　昼（エントランスからの光）******************************************************

[OnName num="Kenji"]
"Uh, uhhhnnn!"
[cpg cn=true]

Waking up feeling unusually refreshed, I took a big stretch and got out of my blanket.
[cpg]

The chilly morning air hit me, but even that felt refreshing now.
[cpg]

Simply put, I was walking on air.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=1500]

[BGM f="dod"]

.........
[cpg]

After I left the room, I could see Shiori on the landing of the stairs.
[cpg]

She seemed to be reading another book to her grandfather's statue.
[cpg]

[OnName num="Kenji"]
"Let me startle you a bit..."
[cpg cn=true]

I walked up the stairs, keeping low so as not to make a sound with my footsteps.
[cpg]

;//朗読する栞
[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori241"]
[OnName num="Shiori"]
"Roses are red, violets are blue, sugar is sweet,  and so are you..."
[cpg cn=true]

[OnName num="Kenji"]
"Just like me?"
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori242"]
[OnName num="Shiori"]
"Kya..."
[cpg cn=true]

I approached Shiori and hugged her body from behind.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori243"]
[OnName num="Shiori"]
"Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"Good morning, Shiori."
[cpg cn=true]

Shiori closed her book, slipped out of my arms, and turned straight toward me.
[cpg]

Shiori was as beautiful as ever, but today she had a different glow from yesterday.
[cpg]

I'm the only one who can clearly see how she shines.
[cpg]

[OnName num="Kenji"]
"Did you get a good night's sleep after that?"
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori244"]
[OnName num="Shiori"]
"Umm, yes..."
[cpg cn=true]

Embarrassed, Shiori nodded, her cheeks turning bright red.
[cpg]

[OnName num="Kenji"]
"Can I give you a good morning kiss...?"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori245"]
[OnName num="Shiori"]
"Huh...?"
[cpg cn=true]

Surprised by my words, Shiori looked around a little and whispered hesitantly.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori246"]
[OnName num="Shiori"]
"But..., my grandfather is watching..."
[cpg cn=true]

When I heard this, I bowed respectfully to the statue and stopped.
[cpg]

[OnName num="Kenji"]
"Good morning, Shiori's grandfather. Please forgive me for kissing your granddaughter."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori247"]
[OnName num="Shiori"]
"Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"Muah!"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori248"]
[OnName num="Shiori"]
"What?! Oh..."
[cpg cn=true]

[OnName num="Kenji"]
"Hehe."
[cpg cn=true]

It was a light kiss that took me by surprise.
[cpg]

I'm sure her grandfather would forgive me for that.
[cpg]

[STOPBGM]

That's what I was thinking, but those who would not forgive me also saw it.
[cpg]


[VOICE f="Erika423"]
[OnName num="Erika"]
"W-what are you doingー?"
[cpg cn=true]

[OnName num="Kenji"]
"Erika?!"
[cpg cn=true]

[BGM f="danger"]


[free time=1]
[WAIT time=1]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="5/3" time=800]


Erika was screaming with red bloodshot eyes as she ran down the stairs to grab Shiori.
[cpg]
[move from="5/3" to="4/5" ease="easeInOutSine" time=800]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Erika424"]
[OnName num="Erika"]
"Youー! You were actually the one who was after Kenjiー!"
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori249"]
[OnName num="Shiori"]
"W-what do you mean...?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika425"]
[OnName num="Erika"]
"Don't play dumb!"
[cpg cn=true]

[OnName num="Kenji"]
"Erika, calm down!"
[cpg cn=true]

In order to stop Erika before she could hit Shiori, I put myself between the two of them.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika426"]
[OnName num="Erika"]
"You cheaterー!"
[cpg cn=true]

[SE f="se104"]
;//【ＳＥ】ガリッ
[OnName num="Kenji"]
"Aah!"
[cpg cn=true]

Just as I stepped back to dodge the slap, Erika's long nails scratched my cheek.
[cpg]

[OnName num="Kenji"]
"I'm not a cheater or anything... We aren't even dating... Ow!"
[cpg cn=true]

I stroked my cheek against the tingling pain and got a little blood on my fingers.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori250"]
[OnName num="Shiori"]
"What did you do... What have you done to Kenji's face?"
[cpg cn=true]

[OnName num="Kenji"]
"Shiori?!"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori251"]
[OnName num="Shiori"]
"Unforgivable! I will never forgive you for hurting him!"
[cpg cn=true]

[move from="2/5" to="3/5" ease="easeInOutSine" time=300]


[FG f="CHA03_p3_01_a.ui" method="change_5" pos="4/5" time=1]
[WAIT time=100]
[VOICE f="Erika427"]
[OnName num="Erika"]
"Uh, ugh?!"
[cpg cn=true]

Unexpectedly, Shiori became enraged and, where she suddenly found her strength as she tightened her hands around Erika's neck.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika428"]
[OnName num="Erika"]
"That hu-hurts..."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori252"]
[OnName num="Shiori"]
"Wahhhhhh!"
[cpg cn=true]

[OnName num="Kenji"]
"I'm fine! It's just a little scratch!"
[cpg cn=true]

Aside from the sheer force, Erika stuck her tongue out in agony as her thumb pressed against her throat.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika429"]
[OnName num="Erika"]
"Aah!"
[cpg cn=true]

[OnName num="Kenji"]
"Shiori! That's enough!"
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=1500]


[FG f="CHA01_p3_01_a.ui" method="change_3" pos="2/4" time=800]
[WAIT time=100]
[VOICE f="Shiori253"]
[OnName num="Shiori"]
"Huff...huff..."
[cpg cn=true]

When I managed to pull Shiori's hands off Erika's neck, Erika fell to her knees and bitterly glared at Shiori.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="4/4" time=800]
[WAIT time=100]
[VOICE f="Erika430"]
[OnName num="Erika"]
"You crazy bitch!!"
[cpg cn=true]

[FACE method="change_4" pos="2/4"]
[WAIT time=100]
[VOICE f="Shiori254"]
[OnName num="Shiori"]
"Huff...huff... Ugh, cough, cough! Gah..."
[cpg cn=true]

Probably due to the sudden rush of emotions, Shiori started coughing and holding her chest.
[cpg]

The blood drained from my face as I watched.
[cpg]

[FACE method="change_4" pos="2/4"]
[WAIT time=100]
[VOICE f="Shiori255"]
[OnName num="Shiori"]
"Kenji..., your f-face..., your wound...quick, go see the doctor...ugh."
[cpg cn=true]

[OnName num="Kenji"]
"I'm fine. You're the one who should..."
[cpg cn=true]

[FACE method="change_3" pos="4/4"]
[WAIT time=100]
[VOICE f="Erika431"]
[OnName num="Erika"]
"You're faking it! You're just acting sick! You're a liar!"
[cpg cn=true]

[OnName num="Kenji"]
"Erika!"
[cpg cn=true]

Rubbing her strangled neck, Erika was still cursing Shiori.
[cpg]

Then, Michi came from the left side of the second floor.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/4" time=1]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="1/4" time=800]
[WAIT time=100]
[VOICE f="Michi347"]
[OnName num="Michi"]
"Good morning. What are you doing down there?"
[cpg cn=true]

[OnName num="Kenji"]
"Just in time! Shiori is...!  Shiori...!"
[cpg cn=true]

[FACE method="change_5" pos="1/4"]
[WAIT time=100]
[VOICE f="Michi348"]
[OnName num="Michi"]
"Huh, Shiori?"
[cpg cn=true]

[FACE method="change_4" pos="2/4"]
[WAIT time=100]
[VOICE f="Shiori256"]
[OnName num="Shiori"]
"Huff...huff...ugh."
[cpg cn=true]

[FACE method="change_3" pos="1/4"]
[WAIT time=100]
[VOICE f="Michi349"]
[OnName num="Michi"]
"Looks terrible. Come here!"
[cpg cn=true]

[move from="1/4" to="6/4" ease="easeInOutSine" time=1000]
[move from="2/4" to="7/4" ease="easeInOutSine" time=1000]
[WAIT time=500]

Accompanied by Michi, Shiori staggered back towards the room.
[cpg]

[FACE method="change_3" pos="4/4"]
[WAIT time=1]
[move from="4/4" to="2/3" ease="easeInOutSine" time=800]

[WAIT time=100]
[VOICE f="Erika432"]
[OnName num="Erika"]
"Kenji is being deceived!"
[cpg cn=true]

[OnName num="Kenji"]
"I don't know what you're talking about..."
[cpg cn=true]

Without apologizing for the scratch, Erika rattled off her theory.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika433"]
[OnName num="Erika"]
"One of those guys is definitely a murderer! No, they could all be accomplices! So why are you getting so close to them!"
[cpg cn=true]

[OnName num="Kenji"]
"Don't be ridiculous.That's impossible!"
[cpg cn=true]

It's unacceptable to talk about Shiori being a murderer or an accomplice.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika434"]
[OnName num="Erika"]
"Who then? Me? Yuna ? We didn't do it, right?!"
[cpg cn=true]

[VOICE f="Erika1434"]
[OnName num="Erika"]
"Then it must have been that doctor or Shiori who killed them! They locked us up like this and they're going to kill us all!"
[cpg cn=true]

[SE f="se105"]
;//【ＳＥ】ガシャーン！

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

There was the metallic sound of something falling below.
[cpg]

I could see Shoko at the bottom of the stairs, shaking.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko145"]
[OnName num="Syouko"]
"Wah..."
[cpg cn=true]

The kettle and stove she had were lying beneath her feet, and the kettle stand had come off and flew a little farther.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko146"]
[OnName num="Syouko"]
"No, th-they wouldn't...do such a horrible thing!"
[cpg cn=true]

[OnName num="Kenji"]
"Sorry, but first are your feet all right? The hot water is..."
[cpg cn=true]

I ran downstairs and took care of Shoko's feet, which had gotten wet from the water in the kettle.
[cpg]

But apparently it hadn't been boiled yet, since there was no steam.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko147"]
[OnName num="Syouko"]
"Those two have been living quietly and peacefully together for a long time, Shiori and the doctor. They don't hurt anyone or bother the people around them, they just stay here isolated..."
[cpg cn=true]

[VOICE f="Syouko1147"]
[OnName num="Syouko"]
"How could such people suddenly kill people?!"
[cpg cn=true]


Gradually raising her voice, Shoko finally shouted.
[cpg]

This is the first time that this woman, who was always smiling, has gotten angry.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika435"]
[OnName num="Erika"]
"No, it doesn't matter! Murderers are always the ones we least suspect!"
[cpg cn=true]

[VOICE f="Erika1435"]
[OnName num="Erika"]
"Besides, if you were a doctor, you'd know how to kill people better than most!"
[cpg cn=true]


[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko148"]
[OnName num="Syouko"]
"She's a doctor! Doctors save lives, not kill people!"
[cpg cn=true]

Shoko must personally have so much respect for Michi.
[cpg]

She went against Erika head-on.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika436"]
[OnName num="Erika"]
"Hmm! If that's the case, then you're the murderer."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko149"]
[OnName num="Syouko"]
"What?"
[cpg cn=true]

[OnName num="Kenji"]
"Stop it! Arguing isn't going to solve anything."
[cpg cn=true]

Having said that, there was no doubt in my mind that someone was guilty.
[cpg]

But there was also a part of me that wanted to deny it.
[cpg]

There could be...some stranger hiding somewhere, and they were out there watching us.
[cpg]

If anything, I wished that were true.
[cpg]

I'd like to see someone outside the group be the culprit.
[cpg]

So I said to the two people staring at each other...
[cpg]

[OnName num="Kenji"]
"The person who killed Takagi and Hosokawa is..."
[cpg cn=true]

;//■選択肢１１（３択）
[switch]
[case "Me"]
	[swap]
	[jump target="*s11_a"]
[case "Nobody could do such a thing."]
	[swap]
	[jump target="*s11_b"]
[case "Someone hiding somewhere."]
	[swap]
	[jump target="*s11_c"]
[endswitch]
;//１，俺　　　　　　　　　//１１aへ
;//２，そんなものはいない　//１１bへ
;//３，隠れている誰か　　　//１１cへ
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１１a　俺
*s11_a|Refuse!
[OnName num="Kenji"]
"I'm the killer!"
[cpg cn=true]

I say, straightening my back.
[cpg]

Then the two of them turned their heads, panicking.
[cpg]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika437"]
[OnName num="Erika"]
"What?! What are you talking about?"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko150"]
[OnName num="Syouko"]
"You're k-kidding, right?"
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, I'm kidding..."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika438"]
[OnName num="Erika"]
"Are you an idiot?!"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko151"]
[OnName num="Syouko"]
"That wasn't funny at all..."
[cpg cn=true]

[OnName num="Kenji"]
"Sorry..."
[cpg cn=true]

I said it to try to soften the situation a little bit, but it didn't seem to have much effect.
[cpg]


;//１１dへ合流
[jump target="*s11_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１１b　そんなものはいない
*s11_b|Refuse!
[OnName num="Kenji"]
"Nobody could do such a thing."
[cpg cn=true]

I folded my arms like I was confident in what I was saying.
[cpg]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika439"]
[OnName num="Erika"]
"Huh? What do you mean 'nobody'?"
[cpg cn=true]

[OnName num="Kenji"]
"Takagi died in an accident. Hosokawa must have died of disease."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko152"]
[OnName num="Syouko"]
"Accidental...?"
[cpg cn=true]

Shoko was puzzled, but Erika was able to make an undeniable point.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika440"]
[OnName num="Erika"]
"What kind of accident would cause a knife to go into his back?!"
[cpg cn=true]

[OnName num="Kenji"]
"He may have fallen on the knife or the knife may have fallen on him while he was sleeping..."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika441"]
[OnName num="Erika"]
"That's highly unlikely."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko153"]
[OnName num="Syouko"]
"But..., it would be nice if that was the case..."
[cpg cn=true]

I thought it was impossible when I said it myself, but there must be some other way they died.
[cpg]

An accident was probably too out there, but I didn't want there to be any culprits.
[cpg]

And Hosokawa probably had a clogged blood vessel or something.
[cpg]

I hope he died of disease.
[cpg]


;//１１dへ合流
[jump target="*s11_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１１c　隠れている誰か
*s11_c|Refuse!
[OnName num="Kenji"]
"'It must be someone still in hiding."
[cpg cn=true]

I said confidently.
[cpg]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika442"]
[OnName num="Erika"]
"Someone...?!"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko154"]
[OnName num="Syouko"]
"You're saying the killer is lurking out there somewhere?"
[cpg cn=true]

They seemed truly surprised by my hypothesis.
[cpg]

[OnName num="Kenji"]
"It's such a big place, there must be a blind spot somewhere. It's got to be someone we don't know about yet."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika443"]
[OnName num="Erika"]
"E-enough..."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko155"]
[OnName num="Syouko"]
"That's too scary...The idea that..."
[cpg cn=true]

Not knowing what or who to be wary of was getting scary.
[cpg]

But I don't want anyone to be the culprit, so it can't be helped.
[cpg]


;//１１dへ合流
[jump target="*s11_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１１d
*s11_d|Refuse!

[STOPBGM]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko156"]
[OnName num="Syouko"]
"Sigh..."
[cpg cn=true]

[BGM f="dod"]


Shoko sighed and began to pick up the things she had dropped.
[cpg]

I think she was tired of all this talk.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko157"]
[OnName num="Syouko"]
"I've been quiet about this..."
[cpg cn=true]

In a squatting position, Shoko muttered to herself so that Erika could not hear her.
[cpg]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko158"]
[OnName num="Syouko"]
"If the goal was to lock you in and kill you..., then whoever created this situation is the culprit."
[cpg cn=true]

[OnName num="Kenji"]
"......!"
[cpg cn=true]

The people who created this situation, that meant Erika and Yuna.
[cpg]

Just as Erika was suspicious of people from the library who she wasn't close to, Shoko was also suspicious of people she didn't know all that well.
[cpg]

[OnName num="Kenji"]
"Speaking of which..., where's Yuna?"
[cpg cn=true]

I asked Erika, noticing that Yuna, who always woke up with Erika, was nowhere to be seen.
[cpg]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika444"]
[OnName num="Erika"]
"She's still asleep."
[cpg cn=true]

[OnName num="Kenji"]
"You didn't wake her up?"
[cpg cn=true]

When I asked more worriedly, Erika twisted the corner of his mouth into a grin and spoke.
[cpg]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika445"]
[OnName num="Erika"]
"You know~, she seemed exhausted~"
[cpg cn=true]

I was concerned about the way she said it, somewhat implicitly. It's no wonder that Yuna was always so mentally fragile and fatigued.
[cpg]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko159"]
[OnName num="Syouko"]
"I'll make tea, so you can bring it with you."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika446"]
[OnName num="Erika"]
"Okayー. Then I'll go to the bathroom first."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

Erika had been giving off bad vibes, but then immediately acted like nothing happened.
[cpg]

Being able to switch like that is amazing, but it's also terrifying.
[cpg]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko160"]
[OnName num="Syouko"]
"Would you like a coffee, Kenji?"
[cpg cn=true]

[OnName num="Kenji"]
"Oh, I'm good."
[cpg cn=true]

I was curious about the Shiori earlier, so I decided to visit her room.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_lpass_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・左側廊下　昼（天窓からの光）******************************************************

[WAIT time=1500]


[OnName num="Kenji"]
"Shiori, are you okay?"
[cpg cn=true]

[SE f="se072"]
;//【ＳＥ】ノック

[WAIT time=2000]

There was no reply.
[cpg]

I was sure Michi was there too, but something was off...
[cpg]

[SE f="se072"]
;//【ＳＥ】ノック
[OnName num="Kenji"]
"Shiori..., I'm coming in, okay?"
[cpg cn=true]

[SE f="se136"]
;//【ＳＥ】ドア開ける

[WAIT time=1500]

[OnName num="Kenji"]
"What?"
[cpg cn=true]



[BG f="b_l_2f_gsr_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・祖父の書斎　昼（エントランスからの光）******************************************************

[WAIT time=1500]


When I opened the door, I realized I was in the wrong room.
[cpg]

There were a lot of similar doors in a row, so they needed to be counted properly, or this happens.
[cpg]

[OnName num="Kenji"]
"But..., this room is amazing..."
[cpg cn=true]

I decided to take the opportunity to look around this room, which I hadn't had the chance to see when we were all looking around.
[cpg]

[OnName num="Kenji"]
"Three-million-yen vase..."
[cpg cn=true]

I could understand why Erika was tempted to touch it.
[cpg]

I'm going to try to touch it, just a little bit.
[cpg]

[OnName num="Kenji"]
"Woah..., it's smooth..."
[cpg cn=true]

As I did this, I casually glanced at a desk and saw two picture frames.
[cpg]

[OnName num="Kenji"]
"This is...Shiori. Is that guy her grandfather?"
[cpg cn=true]

It was probably her garden at home.
[cpg]

A young girl and an old gentleman were smiling at me.
[cpg]

The first man looked younger than the bust on the landing and had a gentler face.
[cpg]

[OnName num="Kenji"]
"You seem to be a kind man..."
[cpg cn=true]

Shiori's beloved grandfather.
[cpg]

Looking at his smile, I could see how much he cared about Shiori.
[cpg]

[OnName num="Kenji"]
"I'll take good care of her..."
[cpg cn=true]

I was muttering to myself as I looked at the picture.
[cpg]

And when I looked at the other picture frame...
[cpg]

[OnName num="Kenji"]
"Huh?"
[cpg cn=true]

The strangeness of it all left me shaking my head.
[cpg]

[OnName num="Kenji"]
"How could they be the same...?"
[cpg cn=true]

The two picture frames on the desk had the exact same pictures in them.
[cpg]

I wasn't sure what the point was of having the same pictures next to each other in the same place.
[cpg]

[OnName num="Kenji"]
Is it an optical illusion?
[cpg cn=true]

Like when I look at each picture with one eye and my eyes cross, they make another picture.
[cpg]

I tried it out, but it wasn't that easy.
[cpg]

I don't even know if it's possible to do that with an ordinary photograph.
[cpg]

Also, there is no way that an elderly person would make such a thing.
[cpg]

[OnName num="Kenji"]
"Am I an idiot...?"
[cpg cn=true]

I stopped looking at the pictures and the next thing I was interested in were the desk drawers.
[cpg]

I hadn't opened them before because I only checked places where people could hide.
[cpg]

[OnName num="Kenji"]
"Inside the desk of a rich man..."
[cpg cn=true]

Curiosity got the better of me and I put my hand on the top drawer.
[cpg]

;//[SE f="se000"]
;//【ＳＥ】ガチャガチャ
[OnName num="Kenji"]
Oh, it didn't open.
[cpg cn=true]

Looks like the drawer was locked.
[cpg]

;//※＜鍵フラグ＞が立っている場合　→　『ルートＤ』へ
[if exp={getFlagValue("Key") > 0 }]
[jump storage="ep019.ks" target="*start"]
[else]
[endif]


[OnName num="Kenji"]
"I guess that means I shouldn't mess with it..."
[cpg cn=true]

I gave up on the drawer and grabbed the book on the desk.
[cpg]

[OnName num="Kenji"]
"Oh, it's an album."
[cpg cn=true]

The thick book I picked up was an album with lots of pictures inside.
[cpg]

But...
[cpg]


[OnName num="Kenji"]
"What the hell is this...?"
[cpg cn=true]

The photos in the album were always two of the same image, side by side.
[cpg]

It wasn't like the photos were printed by mistake.
[cpg]

There had to be some sort of agenda and when they were like this.
[cpg]

[STOPBGM]

;//？？？
[VOICE f="Michi350"]
[OnName num="unknown"]
"Looking for a house is a good hobby."
[cpg cn=true]

[OnName num="Kenji"]
"Whoa!"
[cpg cn=true]

[SE f="se106"]
;//【ＳＥ】アルバム落とす
Suddenly, a voice called out and I dropped the album.
[cpg]



;//[BG f="b_l_2f_gsr_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・祖父の書斎　昼（エントランスからの光）

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=1000]


[WAIT time=1500]

[BGM f="dod"]

When I looked behind me, I saw a scary-looking Michi standing there with her arms folded.
[cpg]

[OnName num="Kenji"]
"I'm s-sorry."
[cpg cn=true]

[WAIT time=100]
[VOICE f="Michi351"]
[OnName num="Michi"]
"People might think you're trying to steal something if you just touch whatever you want."
[cpg cn=true]

Michi walked over and picked up the album that I had dropped.
[cpg]

I wasn't surprised she was angry.
[cpg]

[OnName num="Kenji"]
"I'm sorry. I went into the wrong room and ended up in here..."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi352"]
[OnName num="Michi"]
"So you mistook this room for Shiori's...?"
[cpg cn=true]

Michi flicked the album closed with her hand and put it back.
[cpg]

[OnName num="Kenji"]
"You know, that album... And these picture frames, why are there doubles of every picture in each?"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi353"]
[OnName num="Michi"]
"What?"
[cpg cn=true]

When I asked, Michi opened the album to check it out, but quickly closed it and put it back on the desk.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi354"]
[OnName num="Michi"]
"It's just a habit, right?"
[cpg cn=true]

[OnName num="Kenji"]
"Habit?"
[cpg cn=true]

I had never heard of such a strange habit.
[cpg]

When I gave her a confused look, Michi continued.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi355"]
[OnName num="Michi"]
"Or maybe Shiori's grandfather was a cautious man and prepared them in case of damage or deterioration."
[cpg cn=true]

[OnName num="Kenji"]
"Oh...?"
[cpg cn=true]

If that was the case, it was understandable, but if preventing deterioration was really the reason, wouldn't they be stored separately?
[cpg]

If they were kept in the same place, both pictures would deteriorate in the same way...
[cpg]

But it was probably safe to say he was cautious, because he had spent a lot of money on a security system like that.
[cpg]

I dodn't understand why rich people do what they do.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi356"]
[OnName num="Michi"]
"Come on, that's enough. Get out."
[cpg cn=true]

[OnName num="Kenji"]
"Yes..."
[cpg cn=true]

Michi grabbed me by the arm and threw me out of the room.
[cpg]

It wasn't a good idea to visit Shiori like this, so we went downstairs together.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2up.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）（踊り場）******************************************************

[WAIT time=1500]

[FG f="CHA06_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko161"]
[OnName num="Syouko"]
"～♪"
[cpg cn=true]

As I descended the stairs, I saw Shoko humming to herself as she polished the statue on the landing.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi357"]
[OnName num="Michi"]
"Hey..."
[cpg cn=true]

[OnName num="Kenji"]
"Are you cleaning?"
[cpg cn=true]

When I called out to her, she replied while wiping the statue's face with a towel.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA06_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko162"]
[OnName num="Syouko"]
"Yes. I thought I'd make it shine!"
[cpg cn=true]

[STOPBGM]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi358"]
[OnName num="Michi"]
"S-stop!"
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】走る

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi359"]
[OnName num="Michi"]
"Don't you dare touch that statue!!"
[cpg cn=true]

[SE f="se049"]
;//【ＳＥ】タオル取り上げる

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Syouko163"]
[OnName num="Syouko"]
"Huh?"
[cpg cn=true]

[OnName num="Kenji"]
"M-Michi ?"
[cpg cn=true]



Michi took away the towel that Shoko was holding and hurriedly checked the statue.
[cpg]

It was so odd that Shoko and I just stood there wondering what to do.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=1]
[move from="2/3" to="4/5" ease="easeInOutSine" time=1000]
[WAIT time=1000]
[VOICE f="Michi360"]
[OnName num="Michi"]
"Ah..., This is a very important statue. Shiori doesn't want anyone to touch it."
[cpg cn=true]

[BGM f="dod"]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Syouko164"]
[OnName num="Syouko"]
"Oh, I see... I'm sorry, I shouldn't have done that..."
[cpg cn=true]

Shoko is disappointed that her generous gesture had backfired on her.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi361"]
[OnName num="Michi"]
"It was my fault for not telling you. I'm sorry."
[cpg cn=true]

However, with Michi's follow up, Shoko instantly recovered.
[cpg]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Syouko165"]
[OnName num="Syouko"]
"No! Please don't apologize! I'm sure you're tired, so I'll make you some tea!"
[cpg cn=true]

[move from="2/5" to="5/3" ease="easeInOutSine" time=1000]

As if fetching tea was her mission, Shoko went down the stairs with great enthusiasm.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi362"]
[OnName num="Michi"]
"Well, I'll be going, too. To rest a bit."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, yes."
[cpg cn=true]

[free time=1000]

Michi followed Shoko to the basement and I was left alone.
[cpg]

[OnName num="Kenji"]
"I guess I'll read a book..."
[cpg cn=true]



[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）******************************************************

[WAIT time=1500]

I came to the general collection room and picked up the first volume of "The World of Fantasia" that Shiori had mentioned earlier.
[cpg]

[SE f="se026"]
;//【ＳＥ】ページ捲る
"Young man, please save the Princess of Light from the Dark Lord."
[cpg cn=true]

"Leave it to me. No matter what hardships lie ahead, I will get the princess back!"
[cpg cn=true]

Apparently, this story is about a hero who travels around the world, gathering friends and facing difficulties in order to save the princess.
[cpg]

[OnName num="Kenji"]
"It seems pretty interesting..."
[cpg cn=true]

[SE f="se026"]
;//【ＳＥ】ページ捲る
I was unusually absorbed in reading the story.
[cpg]

Then...
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori257"]
[OnName num="Shiori"]
"Oh..., that's..."
[cpg cn=true]

[OnName num="Kenji"]
"Shiori..."
[cpg cn=true]

Alone, Shiori took a look at the book from behind me.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori258"]
[OnName num="Shiori"]
"You're reading..."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, because Shiori recommended it."
[cpg cn=true]

She still looked a little pale, but I was relieved that her coughing seems to have subsided.
[cpg]

[OnName num="Kenji"]
"I've only read a little of it, but it seems like an interesting adventure."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori259"]
[OnName num="Shiori"]
"Yes, it is. In the future, the protagonist will gain experience by going to various countries and meeting people of different races, but in the first fairy land, he...."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori1259"]
[OnName num="Shiori"]
"Oh... I'm sorry. I didn't mean to spoil the end of the book for you..."
[cpg cn=true]

[OnName num="Kenji"]
"Hahaha, that's okay."
[cpg cn=true]

The look of excitement on Shiori's face as she talked about the book was so cute, I wanted her to keep talking.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori260"]
[OnName num="Shiori"]
"I've loved this book since I was a kid..., and I've read it so many times..."
[cpg cn=true]

[OnName num="Kenji"]
"I can emotionally connect to the hero, but Shiori probably relates to the princess..."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori261"]
[OnName num="Shiori"]
"Me..., too. I always imagine I'm the hero when I read..."
[cpg cn=true]

[OnName num="Kenji"]
"Really?!"
[cpg cn=true]

The main character is a man, and a knight.
[cpg]

And yet, how can Shiori emotionally relate to someone like that?
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori262"]
[OnName num="Shiori"]
"Going to a lot of places on my own, going to battle, crying and laughing... I dream of doing any of that..."
[cpg cn=true]

Now Shiori seemed like she was the imprisoned princess.
[cpg]

Rather, Shiori wants to be as active and uninhibited as the hero is in the story.
[cpg]

[OnName num="Kenji"]
"You've never been abroad? Aren't your parents overseas?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori263"]
[OnName num="Shiori"]
"They live far away..., and...they don't like me."
[cpg cn=true]

[OnName num="Kenji"]
"Oh..."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori264"]
[OnName num="Shiori"]
"My mother and father abandoned me. They left me with my grandfather, who struggled to raise me since he was sick, and I never saw them again... I can't even remember their faces anymore..."
[cpg cn=true]

[OnName num="Kenji"]
"So that's what happened..."
[cpg cn=true]

I felt sad when I thought about Shiori's upbringing.
[cpg]

Always lonely, always anxious...
[cpg]

Projecting herself into books and having adventures with friends in those books...
[cpg]

[OnName num="Kenji"]
"You must be lonely..."
[cpg cn=true]

I patted her head as if I were talking to young Shiori.
[cpg]

[OnName num="Kenji"]
"If Shiori is the adventurer, then I'll be your princess."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

.........
[cpg]

Hmm...? I felt like I said something weird...
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori265"]
[OnName num="Shiori"]
"Ha..., ahaha."
[cpg cn=true]

[OnName num="Kenji"]
"Ahahaha, that'd be weird. Me being the princess..."
[cpg cn=true]

I tried to keep my laughter under control and breathe while she smiled and responded.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori266"]
[OnName num="Shiori"]
"Then... I will definitely save you princess..."
[cpg cn=true]

[OnName num="Kenji"]
"I'll be waiting."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1" pos="5/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="6/3" time=800]
[FACE method="change_2" pos="2/3"]
We chuckled and smiled again.
[cpg]

[move from="2/3" to="1/3" ease="easeInOutSine" time=1000]
[WAIT time=1]
[move from="5/3" to="2/3" ease="easeInOutSine" time=1000]
[move from="6/3" to="3/3" ease="easeInOutSine" time=1000]
[WAIT time=100]
[VOICE f="Erika447"]
[OnName num="Erika"]
"Well, I'm so glad you're feeling better."
[cpg cn=true]

[FACE method="change_7" pos="1/3"]


A demon appeared to ruin our precious time together.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna219"]
[OnName num="Yuna"]
"..................."
[cpg cn=true]

[OnName num="Kenji"]
"Ah, Yuna. You're up?"
[cpg cn=true]

Hiding behind Erika was Yuna.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika448"]
[OnName num="Erika"]
"You look like you're having a good time."
[cpg cn=true]

Erika looked at Shiori with annoyance, then said again with sarcasm.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika449"]
[OnName num="Erika"]
"You're always conveniently sick, and then you're fine again. It's just a fake illness, isn't it?"
[cpg cn=true]

.........
[cpg]

[OnName num="Kenji"]
"No, of course not. She wouldn't need a doctor if she wasn't sick."
[cpg cn=true]

The fact that Michi was here was proof enough that Shiori was really sick.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika450"]
[OnName num="Erika"]
"Hey, Yuna. What do you think? These two were kissing."
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna220"]
[OnName num="Yuna"]
"Oh, yeah..."
[cpg cn=true]

[OnName num="Kenji"]
"Yuna, do something about Erika. She's been like this all day."
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna221"]
[OnName num="Yuna"]
"I..., I can't take Shiori's side..."
[cpg cn=true]

[OnName num="Kenji"]
"Yuna?"
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna222"]
[OnName num="Yuna"]
"Because I'm...Erika's...best friend."
[cpg cn=true]

Yuna seemed to be frightened by something.
[cpg]

I'm sure Erika told her Shiori was the culprit.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika451"]
[OnName num="Erika"]
"And? What about you, Kenji? Did you...do it with her?"
[cpg cn=true]

[OnName num="Kenji"]
"Hey..."
[cpg cn=true]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori267"]
[OnName num="Shiori"]
"......."
[cpg cn=true]

It wasn't like what Erika was making it out to be, but suddenly saying that upset both Shiori and me.
[cpg]

That was not good. Erika made up her own conclusions based on our reactions and raised an eyebrow.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika452"]
[OnName num="Erika"]
"You conveniently have a coughing fit whenever something happens, but you can do that? Isn't it strange that you can't exercise or go to school? But you can kill people!"
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
.........
[cpg]

At Erika's outburst, Shiori could only look down and cry.
[cpg]

Shiori was so angry when I got scratched, but when it came to herself, she couldn't say anything.
[cpg]

[OnName num="Kenji"]
"Don't be ridiculous! You don't know what to say and what not to say! And Shiori and I, we didn't..."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika453"]
[OnName num="Erika"]
"Kenji, you're out of your mind! Sleeping with a murderer!"
[cpg cn=true]

Erika doesn't even listen to what people are saying.
[cpg]

Normally, Yuna would be the one to jump in here, but today, she just shrugged her shoulders and kept quiet.
[cpg]

Instead, the one who intervened was...
[cpg]

[SE f="se037"]
;//【ＳＥ】腹が鳴る
[WAIT time=1000]

[OnName num="Kenji"]
"Ah~..."
[cpg cn=true]

It was my stomach rumbling.
[cpg]

Obviously, I hadn't eaten anything since last night and my stomach was begging for food.
[cpg]

Erika, perhaps distracted by the sound, turned on her heel.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika454"]
[OnName num="Erika"]
"Forget it. Yuna, let's go get a coffee."
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna223"]
[OnName num="Yuna"]
"Y-eah..."
[cpg cn=true]

[move from="2/3" to="5/3" ease="easeInOutSine" time=1000]
[move from="3/3" to="6/3" ease="easeInOutSine" time=1000]

The way she stormed in here and said her piece and then left, she was like a typhoon.
[cpg]

[move from="1/3" to="2/3" ease="easeInOutSine" time=1000]

[WAIT time=100]
[VOICE f="Shiori268"]
[OnName num="Shiori"]
"I'm sorry... It's my fault that... You had to go through that, Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"It's not your fault, Shiori."
[cpg cn=true]

It was all Erika's fault.
[cpg]

[OnName num="Kenji"]
"Can I come to your room tonight too...?"
[cpg cn=true]

I wanted to comfort Shiori, but most of all I wanted to make love again.
[cpg]

But Shiori shook her head reluctantly...
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori269"]
[OnName num="Shiori"]
"My doctor told me...to rest all day today."
[cpg cn=true]

She muttered weakly.
[cpg]

[OnName num="Kenji"]
"I see. Well, I guess it's doctor's orders."
[cpg cn=true]

It was a shame, but it was inevitable for the sake of Shiori's health.
[cpg]

Also, yesterday's excitement could be the reason why she was not feeling well today.
[cpg]

[OnName num="Kenji"]
"Dream of me being a princess."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
Teasing her, Shiori chuckled and replied.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori270"]
[OnName num="Shiori"]
'That dream could be a really long dream..."
[cpg cn=true]

Right. That series had seven volumes and wasn't even finished yet.
[cpg]

This weird princess is still not going to be rescued.
[cpg]

[STOPBGM]

;//エフェクト
[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=2100]

[free time=100]
[BG f="b_l_1f_tbr_p4.ui" time=100]
;//【ＢＧ】図書館・１階・専門書の部屋　夜（暗）******************************************************
[WAIT time=2000]

[transition target={false} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=3000]

[window target=true]


Night came, but dinner time didn't.
[cpg]

We all just gulped down tea to cover up our hunger, and when the sun went down, we went to bed early, disappointed that no help came today.
[cpg]

Would anyone come tomorrow?
[cpg]

But, before that...
[cpg]

How many days had it been already?
[cpg]

I should have checked a few days ago, but I've been feeling even more out of sorts since then.
[cpg]

With so many things happening and the same conversations being repeated, I couldn't remember the chronological order of anything.
[cpg]

I wondered if it was because my brain wasn't getting enough nutrition...
[cpg]

However, as I thought about this, I started to feel sleepy and closed my eyes.
[cpg]

I should go to sleep.
[cpg]

If I did, I might be able to meet Shiori in my dreams.
[cpg]

Shiori as an energetic knight...
[cpg]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=2500]
;#############################################################
;//Ev009
;#############################################################

;//【ＢＧ】ブラックアウト

;//＠
[if exp={ isSystemFlagsEnabled( "end1", "end2", "end3", "end4", "end5") }]
;//エンド制覇
[jump target="*j8_b"]
[else]
;//通常
[jump target="*j8_a"]
[endif]

;//※以下破線内のシーン（A）と、エンド制覇でその後の破線内（B）が差し替わる（挿入ではなく差し替え）
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～
;//（A）通常進行シーン
*j8_a|Refuse!


[BG f="b_l_1f_wt_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・女子トイレ　夜（暗）******************************************************

[WAIT time=1500]


[BGM f="huan"]


[SE f="se051"]
;//【ＳＥ】水道


[VOICE f="Erika455"]
[OnName num="Erika"]
"~♪"
[cpg cn=true]

[SE f="se006"]
;//【ＳＥ】足音×２（※２人だとハッキリわかる）


[VOICE f="Erika456"]
[OnName num="Erika"]
"Who~? I'm little undressed, but don't worry about it~♪"
[cpg cn=true]

[SE f="se006"]
;//【ＳＥ】足音×２

[VOICE f="Erika457"]
[OnName num="Erika"]
"What...? What do you mean? You guys...!"
[cpg cn=true]

[SE f="se045"]
;//【ＳＥ】殴打

[WAIT time=2000]

[SE f="se047"]
;//【ＳＥ】ドサッ

[WAIT time=2000]



[jump target="*j8_c"]

;//追加開始前にメッセージウィンドウを消してるので追加分岐の外で表示に切り替える
;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～


;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～
;//（Ｂ）全ルート制覇による差し替えシーン
*j8_b|Refuse!


[BG f="b_l_1f_wt_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・女子トイレ　夜（暗）******************************************************

[WAIT time=1500]


[BGM f="huan"]

[SE f="se051"]
;//【ＳＥ】水道


[VOICE f="Erika458"]
[OnName num="Erika"]
"~♪"
[cpg cn=true]

[SE f="se006"]
;//【ＳＥ】足音×２（※２人だとハッキリわかる）


[VOICE f="Erika459"]
[OnName num="Erika"]
"Who~? A little undressed, but don't worry about it~♪"
[cpg cn=true]

[SE f="se006"]
;//【ＳＥ】足音×２




[VOICE f="Erika460"]
[OnName num="Erika"]
"What...? What do you mean? You guys...!"
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shiori271"]
[OnName num="Kotoha"]
"How dare you... Because of you, our Kenji has been sullied..."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shiori272"]
[OnName num="Shiori"]
"Unforgivable..."
[cpg cn=true]


[VOICE f="Erika461"]
[OnName num="Erika"]
"What the hell? Why are there two of you?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori273"]
[OnName num="Kotoha"]
"If you hadn't done what you did, you'd still be alive, you stupid bitch."
[cpg cn=true]


[VOICE f="Erika462"]
[OnName num="Erika"]
"Who...the hell are you? Where's Shiori?"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori274"]
[OnName num="Shiori"]
"I'm Shiori..."
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori275"]
[OnName num="Kotoha"]
"To you... I'm also Shiori..."
[cpg cn=true]


[VOICE f="Erika463"]
[OnName num="Erika"]
"What's going on? What the hell?"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori276"]
[OnName num="Shiori"]
"You're filthy..."
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori277"]
[OnName num="Kotoha"]
"I don't want your filth."
[cpg cn=true]

[VOICE f="Vex002"]
[OnName num="Shiori_Kotoha"]
"We only want...pure things."
[cpg cn=true]


[VOICE f="Erika464"]
[OnName num="Erika"]
"H-help me..."
[cpg cn=true]

[SE f="se045"]
;//【ＳＥ】殴打

[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=500]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=100]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=100]
[SE f="se047"]
;//【ＳＥ】ドサッ

[WAIT time=2000]


[BG f="b_l_1f_wt_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・女子トイレ　夜（暗）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/5" time=1000]
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="4/5" time=1000]

[WAIT time=2000]

[window target=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori278"]
[OnName num="Shiori"]
"Hiccup...hicc..."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori279"]
[OnName num="Kotoha"]
"Shiori..., don't cry."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori280"]
[OnName num="Shiori"]
"Kenji is...tainted..."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori281"]
[OnName num="Kotoha"]
"What do we do? You seem conflicted."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori282"]
[OnName num="Shiori"]
"Yeah...cough, cough, ugh..."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori283"]
[OnName num="Kotoha"]
"Oh, It's because you've seen something dirty... Are you okay? Let's go back."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori284"]
[OnName num="Shiori"]
"Yeah..."
[cpg cn=true]

[SE f="se107"]
;//【ＳＥ】立ち去る足音×２


[VOICE f="Erika465"]
[OnName num="Erika"]
"Uh...ugh..., w-why...?"
[cpg cn=true]


;//追加開始前にメッセージウィンドウを消してるので追加分岐の外で表示に切り替える
;//合流
;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～

*j8_c|Refuse!

[STOPBGM]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=3000]


[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 24th
[cpg]


[VOICE f="Yuna224"]
[OnName num="Yuna"]
"Noooooooー!"
[cpg cn=true]



[BG f="b_l_1f_tbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・専門書の部屋　昼（エントランスからの光）******************************************************

;//[SE f="se049"]
;//【ＳＥ】ガバッ！！

[WAIT time=1000]

[BGM f="danger"]


[OnName num="Kenji"]
"W-what was thatー?!"
[cpg cn=true]

A scream, clearly audible even through the door, woke me up and I rushed out in a panic.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

As soon as I ran out of the room, I saw Yuna and Shoko slumped in front of the women's restroom and dashed over there.
[cpg]

[SE f="se022"]
;//【ＳＥ】ダッシュ

;//＠
;//[free time=400]
;//[WAIT time=400]
;//[BG f="black.ui" time=900]
;//[WAIT time=1500]
;//[BGM f="d1"]
;//[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）　女子トイレ前

[OnName num="Kenji"]
"What happened?!"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Yuna225"]
[OnName num="Yuna"]
"Erika is... Erika is..."
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko166"]
[OnName num="Syouko"]
"Ahhhhh......."
[cpg cn=true]

Yuna and Shoko were hugging and shaking.
[cpg]

I looked into the women's restroom where Yuna was pointing...
[cpg]

;//☆死亡
;//エリカ死亡

[free time=1000]
[BG f="b_l_1f_wt_p4.ui" time=1000]
[WAIT time=1500]

;**【ＣＧ】ci_04_0 ***********************
;//カットイン
[CUTIN f="ci_04_0.ui" show={true} method="slidein"]
;*****************************************

[WAIT time=2000]


[OnName num="Kenji"]
"Erika?!"
[cpg cn=true]

;//脳天を割られて倒れているエリカ
There was Erika lying on the ground with her head covered in blood.
[cpg]

There was a pool of blood on the tiles and it looked exactly like a murder scene.
[cpg]


[VOICE f="Michi363"]
[OnName num="Michi"]
"Who screamed?!"
[cpg cn=true]

I heard Michi's voice from above, and I shook off my fear before I shouted back.
[cpg]

[OnName num="Kenji"]
"Michi! Over here, the girl's restroomー! Please come quickly!"
[cpg cn=true]

[CUTIN f="ci_04_0.ui" show={false} method="slideout"]



[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=1500]


[SE f="se022"]
;//【ＳＥ】走る

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=1000]
[WAIT time=1500]
[VOICE f="Michi364"]
[OnName num="Michi"]
"What happened now..."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]


Michi's face grew pale as she joined us and looked into the restroom.
[cpg]

Shiori, who had arrived a little later, noticed something was up and pulled away before she saw anything.
[cpg]

;//※以下、日付が変わるまで栞はコトハ
;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Shiori285"]
[OnName num="Shiori"]
"What's wrong...?"
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Syouko167"]
[OnName num="Syouko"]
"Erika is dead!"
[cpg cn=true]

[OnName num="Kenji"]
"Don't look at Shiori. Stay back with Shoko."
[cpg cn=true]

;//コトハ
[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Shiori286"]
[OnName num="Shiori"]
"O-okay..."
[cpg cn=true]

[free time=1000]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=1000]

With that, I went with Michi over to the body.
[cpg]

[BG f="b_l_1f_wt_p4.ui" time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="3/3" time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_04_0 ***********************
;//カットイン
[CUTIN f="ci_04_0.ui" show={true} method="slidein"]
;*****************************************


[WAIT time=2000]

[VOICE f="Michi365"]
[OnName num="Michi"]
"Cause of death is...a direct blow to the top of the head, probably bled to death."
[cpg cn=true]

[OnName num="Kenji"]
"A direct blow...?
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi366"]
[OnName num="Michi"]
"There's a deep wound in the head... You can't see it through the blood, but it's probably around her skull..."
[cpg cn=true]

[OnName num="Kenji"]
"Ugh..."
[cpg cn=true]

Blood stuck to her hair and all I could see was a black gash.
[cpg]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi367"]
[OnName num="Michi"]
"That's all I can tell by just looking..."
[cpg cn=true]

[OnName num="Kenji"]
"Who would do such a terrible thing...?"
[cpg cn=true]

Well, I was upset with Erika yesterday.
[cpg]

I thought she was annoying every day.
[cpg]

But I've never thought about killing her.
[cpg]

Who would have resented Erika enough to go to such lengths...
[cpg]


[VOICE f="Syouko168"]
[OnName num="Syouko"]
"Ah, Yuna!"
[cpg cn=true]

[move from="3/3" to="5/6" ease="easeInOutSine" time=1000]
[WAIT time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="6/6" time=800]
[WAIT time=100]
[VOICE f="Yuna226"]
[OnName num="Yuna"]
"Let m-me...see..."
[cpg cn=true]

[OnName num="Kenji"]
"Yuna..."
[cpg cn=true]

With a very pale face, Yuna came in.
[cpg]

While breathing heavily through her mouth, she saw the body of her best friend clearly with her eyes behind her glasses.
[cpg]

[FACE method="change_5" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna227"]
[OnName num="Yuna"]
"Dead...?"
[cpg cn=true]

I didn't know if it was directed at Michi , me, or...Erika. I just watched Yuna.
[cpg]

[FACE method="change_1" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna228"]
[OnName num="Yuna"]
"Ha..."
[cpg cn=true]

With her vacant eyes fixed on the corpse, Yuna let out a laugh.
[cpg]

[OnName num="Kenji"]
"Eh..."
[cpg cn=true]

[FACE method="change_2" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna229"]
[OnName num="Yuna"]
"Hehehe, hahaha... Dead... Erika, she's dead... Ahahahaha."
[cpg cn=true]

Delirious, Yuna began to laugh.
[cpg]

[FACE method="change_4" pos="5/6"]
[WAIT time=100]
[VOICE f="Michi368"]
[OnName num="Michi"]
"You should get out of here..."
[cpg cn=true]

When Michi said this, Yuna abruptly stopped laughing.
[cpg]

[STOPBGM]

[FACE method="change_5" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna230"]
[OnName num="Yuna"]
"There's something written..."
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

I followed Yuna's gaze and looked at the right hand of the corpse and saw what looked like a question mark written on the tile.
[cpg]

When I checked, I saw that Erika had written it herself since there was blood on her index finger.
[cpg]

[OnName num="Kenji"]
"What is it? A question mark? Or it looks like a '2' or '3'?"
[cpg cn=true]

[FACE method="change_3" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna231"]
[OnName num="Yuna"]
"A dying message..."
[cpg cn=true]

[BGM f="huan"]



;//コトハ
[FG f="CHA06_p3_01_a.ui" method="change_4" pos="2/6" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_4" pos="1/6" time=800]
[WAIT time=100]
[VOICE f="Shiori287"]
[OnName num="Shiori"]
"Dying message...?"
[cpg cn=true]

Perhaps sensing the unsettling atmosphere, Shiori and Shoko stood near the entrance and peeked fearfully inside.
[cpg]

[FACE method="change_3" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna232"]
[OnName num="Yuna"]
"Is it a '?' or a '2' or a '3'...?"
[cpg cn=true]

As if possessed by something, Yuna began to mumble the same words over and over again.
[cpg]

[OnName num="Kenji"]
"Yu, Yuna ?"
[cpg cn=true]

[FACE method="change_3" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna233"]
[OnName num="Yuna"]
"I think it's a..."2". Erika wrote about her killer."
[cpg cn=true]

[OnName num="Kenji"]
"What, really?"
[cpg cn=true]

While I was looking at the bloody message in amazement, Yuna asked responded to my question with a question.
[cpg]

[FACE method="change_3" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna234"]
[OnName num="Yuna"]
"What do you think the number '2' refers to, Kenji...?"
[cpg cn=true]

[OnName num="Kenji"]
"Um..."
[cpg cn=true]

What did the number "2" refer to...
[cpg]

;//■選択肢１２（３択）
[switch]
[case "The number of killers"]
	[swap]
	[jump target="*s12_a"]
[case "Michi"]
	[swap]
	[jump target="*s12_b"]
[case "The number of times she was hit"]
	[swap]
	[jump target="*s12_c"]
[endswitch]
;//１，犯人の数　　　//１２aへ
;//２，美智さん　　　//１２bへ
;//３，殴られた回数　//１２cへ
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１２a　犯人の数
*s12_a|Refuse!
[OnName num="Kenji"]
"The number of killers...?"
[cpg cn=true]

I answered, and Yuna nodded her head.
[cpg]

[FACE method="change_5" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna235"]
[OnName num="Yuna"]
"There were two perpetrators. Two people here are accomplices!"
[cpg cn=true]

[FACE method="change_5" pos="5/6"]
[WAIT time=100]
[VOICE f="Michi369"]
[OnName num="Michi"]
"W-what are you saying?"
[cpg cn=true]

[FACE method="change_3" pos="2/6"]
[WAIT time=100]
[VOICE f="Syouko169"]
[OnName num="Syouko"]
"Don't say such terrible things!"
[cpg cn=true]

Perhaps curious about what was being said, Shoko came in accompanied by Shiori.
[cpg]

But Yuna kept going.
[cpg]

[FACE method="change_3" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna236"]
[OnName num="Yuna"]
"Shiori and Ms. Kisaragi, or Ms. Kisaragi and Ms. Endo. I don't know which pair did it, but it's a two-thirds chance! Kenji, get away from them!"
[cpg cn=true]


;//１２dへ合流
[jump target="*s12_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１２b　美智さん
*s12_b|Refuse!
[OnName num="Kenji"]
"Could it be...Michi?"
[cpg cn=true]

[FACE method="change_5" pos="5/6"]
[WAIT time=100]
[VOICE f="Michi370"]
[OnName num="Michi"]
"Me?"
[cpg cn=true]

[FACE method="change_3" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna237"]
[OnName num="Yuna"]
"That's right... Her last name is Kisaragi, which means February in the Japanese calendar. So Ms. Kisaragi is the one who killed Erika!"
[cpg cn=true]

Was Michi the killer...?
[cpg]

It was a reasoning that sounded logical, but it was somewhat far-fetched.
[cpg]

[FACE method="change_3" pos="5/6"]
[WAIT time=100]
[VOICE f="Michi371"]
[OnName num="Michi"]
"How stupid."
[cpg cn=true]

Michi said coldly.
[cpg]

And Shiori backed her up.
[cpg]

;//コトハ
[FACE method="change_7" pos="1/6"]
[WAIT time=100]
[VOICE f="Shiori288"]
[OnName num="Shiori"]
"Erika..., I don't think she was familiar with the Japanese calendar..."
[cpg cn=true]

Shiori's statement was a bit pointed.
[cpg]

Erika would never have known that Kisaragi meant February.
[cpg]

[FACE method="change_7" pos="5/6"]
[WAIT time=100]
[VOICE f="Michi372"]
[OnName num="Michi"]
"If she had known, would she have gone to the trouble of writing riddles while she was dying?"
[cpg cn=true]

[OnName num="Kenji"]
"Good point... I think Erika would have written her name in hiragana."
[cpg cn=true]

Yuna's reasoning was torn to shreds by three people.
[cpg]

[FACE method="change_3" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna238"]
[OnName num="Yuna"]
"Then, then, the number of people! Between Shiori, Ms. Kisaragi, and Ms. Endo, two of you must be accomplices! The probability is two thirds... Kenji, come over here..."
[cpg cn=true]


;//１２dへ合流
[jump target="*s12_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１２c　殴られた回数
*s12_c|Refuse!
[OnName num="Kenji"]
"How many times she was hit?"
[cpg cn=true]

[FACE method="change_7" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna239"]
[OnName num="Yuna"]
"Why would she need to write that...?"
[cpg cn=true]

I guess not.
[cpg]

I took it as Erika saying, "I was hit twice, so I hit my attacker back twice!" and I was going to leave it at that...
[cpg]

[FACE method="change_3" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna240"]
[OnName num="Yuna"]
"That means there were two killers... Two of them are accomplices!"
[cpg cn=true]

[FACE method="change_3" pos="2/6"]
[WAIT time=100]
[VOICE f="Syouko170"]
[OnName num="Syouko"]
"What are you talking about?"
[cpg cn=true]

Unable to resist joining the conversation, Shoko came inside, accompanied by Shiori.
[cpg]

But Yuna kept going.
[cpg]

[FACE method="change_3" pos="6/6"]
[WAIT time=100]
[VOICE f="Yuna241"]
[OnName num="Yuna"]
"Shiori and Ms. Kisaragi, or Ms. Kisaragi and Ms. Endo. I don't know which pair did it, but it's a two-thirds chance! Kenji, get away from them!"
[cpg cn=true]


;//１２dへ合流
[jump target="*s12_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１２d
*s12_d|Refuse!

[CUTIN f="ci_04_0.ui" show={false} method="slideout"]


[FG f="CHA02_p3_01_a.ui" method="change_4" pos="1/6" time=1]
[FG f="CHA06_p3_01_a.ui" method="change_3" pos="2/6" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="5/6" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="6/6" time=1]
[WAIT time=1]

[move from="1/6" to="1/4" ease="easeInOutSine" time=2000]
[move from="2/6" to="2/4" ease="easeInOutSine" time=2000]
[move from="5/6" to="3/4" ease="easeInOutSine" time=2000]
[move from="6/6" to="4/4" ease="easeInOutSine" time=2000]


[WAIT time=2000]

Yuna quickly rattled off her theories and tried to cling to my arm.
[cpg]

[move from="1/4" to="1/5" ease="easeInOutSine" time=1000]
[move from="2/4" to="2/5" ease="easeInOutSine" time=1000]
[move from="3/4" to="3/5" ease="easeInOutSine" time=1000]
[move from="4/4" to="3/3" ease="easeInOutSine" time=1000]

But I rejected her and ran to Shiori.
[cpg]

[OnName num="Kenji"]
"You can't make a decision on a murderer based on something so vague and without any evidence."
[cpg cn=true]

When I said this to Yuna, Shiori leaned in close to me.
[cpg]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna242"]
[OnName num="Yuna"]
"Maybe it's not even a dying message from Erika!"
[cpg cn=true]

[OnName num="Kenji"]
"We don't know for sure if it's the number '2', her hand could have just moved."
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna243"]
[OnName num="Yuna"]
"How could you say that? Those were Erika's last words!"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="3/5" time=800]
[WAIT time=100]
[VOICE f="Michi373"]
[OnName num="Michi"]
"Why don't you calm down a bit?"
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=1]
[move from="3/3" to="5/5" ease="easeInOutSine" time=1000]
[WAIT time=100]
[VOICE f="Yuna244"]
[OnName num="Yuna"]
"Get away from me!"
[cpg cn=true]

Yuna shook off Michi's hand and ran off into the corner by herself.
[cpg]

[FACE method="change_4" pos="5/5"]
[WAIT time=100]
[VOICE f="Yuna245"]
[OnName num="Yuna"]
"No one come any closer... I-I-I don't want to die..."
[cpg cn=true]

She stared at us with only her eyes moving, watching our every move.
[cpg]


;//コトハ

[FACE method="change_4" pos="1/5"]

;//[FG f="CHA02_p3_01_a.ui" method="change_7" pos="1/5" time=800]
;//[FG f="CHA06_p3_01_a.ui" method="change_7" pos="2/5" time=800]
;//[FG f="CHA05_p3_01_a.ui" method="change_7" pos="3/5" time=800]
[WAIT time=100]
[VOICE f="Shiori289"]
[OnName num="Shiori"]
"Kenji..., I'm scared..."
[cpg cn=true]

[OnName num="Kenji"]
"It's okay. I'm here for you..."
[cpg cn=true]

I said softly, and Shiori's hand on my back moved quickly to my waist.
[cpg]

;//コトハ
[FACE method="change_4" pos="1/5"]
[WAIT time=100]
[VOICE f="Shiori290"]
[OnName num="Shiori"]
"Stay with me forever... You can sleep in my room from now on."
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

[FACE method="change_3" pos="3/5"]
[WAIT time=100]
[VOICE f="Michi374"]
[OnName num="Michi"]
"No."
[cpg cn=true]

I got happy too early, because then Michi intervened.
[cpg]

[FACE method="change_7" pos="3/5"]
[WAIT time=100]
[VOICE f="Michi375"]
[OnName num="Michi"]
"I told you, strangers of the opposite sex can't sleep in the same room."
[cpg cn=true]

Then Shiori spoke up sulkily, hiding behind me.
[cpg]

;//コトハ
[FACE method="change_3" pos="1/5"]
[WAIT time=100]
[VOICE f="Shiori291"]
[OnName num="Shiori"]
"We're not strangers anymore..."
[cpg cn=true]

[OnName num="Kenji"]
"Shh."
[cpg cn=true]

We warned about that in the first place, but what's done is done.
[cpg]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Syouko171"]
[OnName num="Syouko"]
"Oh~! Are you two together~?"
[cpg cn=true]

Of course she couldn't read the room.
[cpg]
[FACE method="change_2" pos="2/5"]

Shoko was smiling as if she was about to clap her hands.
[cpg]

I thought that a thunderbolt was going to strike me...but, based on Michi's expression, it was not.
[cpg]

[FACE method="change_3" pos="3/5"]
[WAIT time=100]
[VOICE f="Michi376"]
[OnName num="Michi"]
"Even so, what if you suddenly got sick, Shiori?"
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="1/5"]
[WAIT time=100]
[VOICE f="Shiori292"]
[OnName num="Shiori"]
"W-well..."
[cpg cn=true]

Stuck for words, Shiori gave up and moved away from me.
[cpg]

If she suddenly got sick, I couldn't I just go get Michi for her?
[cpg]

That's what I thought, but I couldn't say it because if I pushed too hard, people would see through my intentions.
[cpg]


[FACE method="change_5" pos="5/5"]
[WAIT time=100]
[VOICE f="Yuna246"]
[OnName num="Yuna"]
"How can you...enjoy talking so much...? How can you talk...so happily when Erika is dead...?"
[cpg cn=true]

Yuna glared at us from the same position she's been in.
[cpg]

[OnName num="Kenji"]
"Oh..."
[cpg cn=true]


[FACE method="change_4" pos="2/5"]


[WAIT time=100]
[VOICE f="Syouko172"]
[OnName num="Syouko"]
"I'm s-sorry..."
[cpg cn=true]

Yuna was right.
[cpg]

Have we gotten so used to being around death that we could chat in a place like this?
[cpg]

The reason why we were talking like this in the first place was...Shiori.
[cpg]

Shiori today, although frightened at first, seemed strangely energetic or somewhat normal.
[cpg]

It was good to be healthy, but it seemed like there was a huge difference between being fine and being about to die.
[cpg]

When I thought about it, I somehow got the feeling that her behavior was also changing depending on her physical condition.
[cpg]

Come to think of it, there was a time when Erika had said that Shiori was shy.
[cpg]

I think this meant she was gradually showing her real personality.
[cpg]

;//コトハ
[FACE method="change_3" pos="1/5"]
[WAIT time=100]
[VOICE f="Shiori293"]
[OnName num="Shiori"]
"Well then, Doctor..., what now? If it's okay, can I talk to Kenji in the room for a moment?"
[cpg cn=true]

Though she seemed to have given up, Shiori was not deterred by Yuna's words and insisted to Michi.
[cpg]

[FACE method="change_7" pos="3/5"]
[WAIT time=100]
[VOICE f="Michi377"]
[OnName num="Michi"]
"Right now...."
[cpg cn=true]

Michi pondered something for a bit, then sighed lightly and said.
[cpg]

[FACE method="change_7" pos="3/5"]
[WAIT time=100]
[VOICE f="Michi378"]
[OnName num="Michi"]
"Alright, just until it's time for your medicine."
[cpg cn=true]

;//コトハ
[FACE method="change_2" pos="1/5"]
[WAIT time=100]
[VOICE f="Shiori294"]
[OnName num="Shiori"]
"Okay.... Let's go, Kenji."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, but..."
[cpg cn=true]

Shiori pulled me aside, but I thought I'd have to carry Erika back to the infirmary, so I looked at Michi.
[cpg]

Then Michi said that Erika was in the 40 kilogram range, so Shoko could carry her, and had us leave the restroom.
[cpg]


[FACE method="change_5" pos="5/5"]
[WAIT time=100]
[VOICE f="Yuna247"]
[OnName num="Yuna"]
"Kenji! Don't leave me alone!"
[cpg cn=true]



[FACE method="change_1" pos="3/5"]
[WAIT time=100]
[VOICE f="Michi379"]
[OnName num="Michi"]
"Just go. Yuna, if you're so scared, why don't you lock yourself in a shed or something with a rod?"
[cpg cn=true]

[FACE method="change_4" pos="5/5"]
[WAIT time=100]
[VOICE f="Yuna248"]
[OnName num="Yuna"]
".................."
[cpg cn=true]

I was a little concerned about Yuna, but my desire to be with Shiori won out over that, so we both headed to her room.
[cpg]

;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=2100]

[free time=100]
[BG f="b_l_1f_ros_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************
[WAIT time=2000]

[transition target={false} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=3000]
[window target=true]


[BGM f="dod"]

[OnName num="Kenji"]
"Oh? Did you make something again?"
[cpg cn=true]

I asked, feeling like there were one or two more plaster casts of hands or legs.
[cpg]

Sitting on the bed, Shiori nodded and said, a little reluctantly.
[cpg]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori295"]
[OnName num="Shiori"]
"I've had a lot of episodes the past few days.... When I take my medicine, the pain goes away...."
[cpg cn=true]

[VOICE f="Shiori1295"]
[OnName num="Shiori"]
"But I can't leave the room until the doctor says it's okay, because I need to take it easy... So..."
[cpg cn=true]

So she makes plaster figures for comfort.
[cpg]

It's very artistic, somehow like me who didn't have the knack for it, admired it a little.
[cpg]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori296"]
[OnName num="Shiori"]
"Originally..., I began by making that bronze statue of my grandfather..."
[cpg cn=true]

[OnName num="Kenji"]
"What? So Shiori made that too?"
[cpg cn=true]

First of all, I was surprised that it was a bust first, not a limb.
[cpg]

;//コトハ
[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori297"]
[OnName num="Shiori"]
"I was very sad and lonely when my grandfather passed away... So I made a bust of him so that I can see him whenever I want..."
[cpg cn=true]

[VOICE f="Shiori1297"]
[OnName num="Shiori"]
"Then I wanted to make something else, and I wanted to try something other than bronze, so I started to learn more. I had a lot of time on my hands..."
[cpg cn=true]

[OnName num="Kenji"]
"That's amazing. I guess it's true what they say about being good at what you love."
[cpg cn=true]

When I said that, Shiori giggled and shook her head.
[cpg]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori298"]
[OnName num="Shiori"]
"I'm still not very good... I'm not even satisfied with the plaster statue here..."
[cpg cn=true]

[OnName num="Kenji"]
"What? But it's so well done."
[cpg cn=true]

Even though it was on par with a professional's work, Shiori didn't seem satisfied with her work.
[cpg]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori299"]
[OnName num="Shiori"]
"Actually..., I really wanted to make Grandfather a full-length statue, but it was too difficult, so I ended up with a bust."
[cpg cn=true]

[VOICE f="Shiori1299"]
[OnName num="Shiori"]
"It was made after he died, so it became a skinny, wrinkled figure..."
[cpg cn=true]

A full-length statue did seem difficult to make, but couldn't she make it look however she wanted?
[cpg]

[OnName num="Kenji"]
"Shiori, you could have made it however you like, you could have just left out the wrinkles."
[cpg cn=true]

When I mentioned that, Shiori shook her head again and explained.
[cpg]

;//コトハ
[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori300"]
[OnName num="Shiori"]
"I couldn't do that... Then it would just be something I made up..."
[cpg cn=true]

[VOICE f="Shiori1300"]
[OnName num="Shiori"]
"I think I'd like to keep my subjects looking just the way they were..."
[cpg cn=true]

[OnName num="Kenji"]
"I want to keep my subjects... like their original state."
[cpg cn=true]

I've always wondered why painters drew pictures with movement.
[cpg]

I wondered what kind of skill it took to be able to depict the moment of a person playing sports or dancing.
[cpg]

I wondered if sculpting was similar to that.
[cpg]

Something like a three-dimensional photograph that is frozen in time at that moment?
[cpg]
[FACE method="change_2" pos="2/3"]

Seeing me ponder this, Shiori chuckled.
[cpg]

[OnName num="Kenji"]
"What? Is something wrong?"
[cpg cn=true]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori301"]
[OnName num="Shiori"]
"No, If I was going to make a statue of you, Kenji, now would be a good time to do it..."
[cpg cn=true]

[OnName num="Kenji"]
"What, now?"
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori302"]
[OnName num="Shiori"]
"Because I think, at your age right now, you are at your most beautiful."
[cpg cn=true]

[OnName num="Kenji"]
"Is that so?"
[cpg cn=true]

;//コトハ
[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori303"]
[OnName num="Shiori"]
"Absolutely. Because... I fell in love with you, Kenji, at first sight when you frst came here..."
[cpg cn=true]

[OnName num="Kenji"]
"What—?"
[cpg cn=true]

She revealed something shocking.
[cpg]

I can't believe that at the same time I was falling in love with Shiori, she was also falling in love with me!
[cpg]

[OnName num="Kenji"]
"I always thought that Shiori hated me..."
[cpg cn=true]

;//コトハ
[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori304"]
[OnName num="Shiori"]
"At that time, I saw a beautiful man for the first time... and I didn't know what to do..."
[cpg cn=true]

This, combined with her shyness, had led to her cold responses...
[cpg]

How confusing! But I'm glad I understand her now.
[cpg]

I was crying tears of joy on the inside.
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori305"]
[OnName num="Shiori"]
"It's a dream come true to be this close to you..."
[cpg cn=true]

[OnName num="Kenji"]
"It's the same for me. I fell in love with Shiori at first sight, and now it's like a dream."
[cpg cn=true]

I pulled Shiori into a hug and gave her a sweet kiss.
[cpg]

;//コトハ
[FG f="CHA02_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori306"]
[OnName num="Shiori"]
"Mmm..."
[cpg cn=true]

Our tongues intertwined, and we became intoxicated while confirming our feelings for each other.
[cpg]

[OnName num="Kenji"]
"Wait... Before we go any further, are you okay? Are you feeling okay?"
[cpg cn=true]

Shiori put her hand on her chest and breathed to make sure she was okay before saying.
[cpg]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori307"]
[OnName num="Shiori"]
"I feel fine... I feel like being with you, Kenji, makes me feel better..."
[cpg cn=true]

[OnName num="Kenji"]
"R-really?"
[cpg cn=true]

It was impossible not to be happy to hear that.
[cpg]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori308"]
[OnName num="Shiori"]
"Oh..., but it's almost time for me to see the doctor..."
[cpg cn=true]

The time for Shiori's medicine seemed to be approaching, and I adjusted my hair in front of the mirror a little.
[cpg]

At that moment, I noticed that my hair was sticky and oily, so I casually asked Shiori about it.
[cpg]

[OnName num="Kenji"]
"Um... Hey, do I stink?"
[cpg cn=true]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori309"]
[OnName num="Shiori"]
"Stink...? Hehe, I don't care about that."
[cpg cn=true]

[OnName num="Kenji"]
"Y-yeah......."
[cpg cn=true]

Shiori did not say I didn't stink.
[cpg]

I also wondered if my body odor was getting a little too strong...
[cpg]

I wanted to take a bath...
[cpg]

The more aware I was of it, the more it bothered me.
[cpg]

Maybe I should just wash up with water...
[cpg]

I shuddered at the mere thought of the cold water and left Shiori's room.
[cpg]

[window target=false]

[free time=2000]
[BG f="black.ui" time=2000]

;//[SE f="se009"]
;//【ＳＥ】ドア開く

[WAIT time=3000]

;//エフェクト

[SE f="se009"]
;//【ＳＥ】ドア閉まる

[STOPBGM]
[WAIT time=1500]
[BG f="b_l_2f_lpass_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・左側廊下　昼（天窓からの光）******************************************************

[WAIT time=1500]
[window target=true]

[BGM f="dod"]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna249"]
[OnName num="Yuna"]
".................."
[cpg cn=true]

[OnName num="Kenji"]
"Yuna..."
[cpg cn=true]

When I went out the staff-only door on the second floor, I saw Yuna standing on the other side of the corridor, looking at me.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna250"]
[OnName num="Yuna"]
"Do you have a minute...?"
[cpg cn=true]

[OnName num="Kenji"]
"Yeah?"
[cpg cn=true]

As she beckoned me, I walked down the corridor and into the room with maps and history books.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_mhbr_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・地図と歴史書の部屋　昼（エントランスからの光）******************************************************

[WAIT time=1500]


[OnName num="Kenji"]
"What?"
[cpg cn=true]

I asked Yuna, who had a ponderous look on her face.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna251"]
[OnName num="Yuna"]
"You were with Shiori, weren't you...? What were you doing...?"
[cpg cn=true]

[OnName num="Kenji"]
"What do you mean...?"
[cpg cn=true]

I didn't think I could honestly say that we had been kissing.
[cpg]

When Yuna saw me clamoring, she wrinkled her brow for a moment and then muttered.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna252"]
[OnName num="Yuna"]
"I think she's lying...when Shiori says she likes you, Kenji."
[cpg cn=true]

[OnName num="Kenji"]
"What? What are you talking about?"
[cpg cn=true]

I was a little angry because she didn't know anything about me and Shiori, so I spoke up.
[cpg]

[OnName num="Kenji"]
"Yuna, that's your business if you want to decide that Shiori is the killer, but it's also for me to decide if I think she's not."
[cpg cn=true]

I knew that Yuna was out of it because of what happened to Erika.
[cpg]

But that didn't mean that it wasn't annoying to have her interfering with us.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna253"]
[OnName num="Yuna"]
"That's not what I meant..."
[cpg cn=true]

But what Yuna actually wanted to say was not what I was upset about.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna254"]
[OnName num="Yuna"]
"I know this is going to sound ridiculous, but... I think that Shiori..."
[cpg cn=true]

[OnName num="Kenji"]
"What? Spit it out."
[cpg cn=true]

It was a pain in the ass for her to call me over to talk and then not say anything.
[cpg]

I was irritated and urged Yuna to continue.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna255"]
[OnName num="Yuna"]
"I think Shiori...may have that kind of relationship with...Ms. Kisaragi..."
[cpg cn=true]

[OnName num="Kenji"]
"That kind of relationship?"
[cpg cn=true]

I didn't understand the meaning of what Yuna said, so I tilted my head and asked her.
[cpg]

Yuna then looked up and explained what was going on, looking at me from behind her glasses.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna256"]
[OnName num="Yuna"]
"I've seen it... A while ago, Ms. Kisaragi was wiping Shiori's body in the infirmary."
[cpg cn=true]

[OnName num="Kenji"]
"And?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna257"]
[OnName num="Yuna"]
"The atmosphere was different...than usual. It wasn't like a doctor and a patient."
[cpg cn=true]

[OnName num="Kenji"]
"Do you even know what you're saying?"
[cpg cn=true]

We already knew that Shiori and Michi were not in a normal doctor-patient relationship.
[cpg]

Michi is Shiori's guardian and roommate, like a family member.
[cpg]

But Yuna shook her head over and over again, repeating that it was different.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna258"]
[OnName num="Yuna"]
"But Shiori was naked, and... She was hugging Ms. Kisaragi, even though she was naked! Patients don't normally do that!"
[cpg cn=true]

[VOICE f="Yuna1258"]
[OnName num="Yuna"]
"The two of them must be in love. Kenji, you're being deceived!"
[cpg cn=true]


[OnName num="Kenji"]
"That's ridiculous."
[cpg cn=true]

I thought she was being delusional.
[cpg]

Those women in love with each other?
[cpg]

How could she come to such a conclusion?
[cpg]

Michi was acting like she had a bit of a crush on me, and I could understand if she was competing with Shiori for me, but the two of them together...
[cpg]

[OnName num="Kenji"]
"If you insist that much, have you ever seen them do it?"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna259"]
[OnName num="Yuna"]
"Well..., not exactly..., I didn't see that, but..."
[cpg cn=true]

[OnName num="Kenji"]
"Well, look at that. Don't be so sure about her being a killer or a lesbian."
[cpg cn=true]

I turned my back on Yuna thinking the conversation was over.
[cpg]

But...
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna260"]
[OnName num="Yuna"]
"Wait! Shiori, she's really weird. She's crazy! Sometimes it's like she's a different person, and she can't be trusted!"
[cpg cn=true]

She grabbed my arm and raised her voice.
[cpg]

[OnName num="Kenji"]
"Give me a break! Yuna, you're the one that's weird! You've been acting like a different person!"
[cpg cn=true]

I pushed her shoulder roughly, trying to get Yuna's hand off my arm.
[cpg]

But Yuna still clung desperately to me.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna261"]
[OnName num="Yuna"]
"I'm scared! Now that Erika is dead, Kenji, you're the only one I can turn to! Please don't abandon me!"
[cpg cn=true]

[OnName num="Kenji"]
"Abandon you? I'm not saying that..."
[cpg cn=true]

She was so desperate that I felt a little pressure, and my ability to push Yuna away weakened.
[cpg]

And then...
[cpg]

[FG f="CHA04_p5_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna262"]
[OnName num="Yuna"]
"Please, Kenji! I'll do anything for you! I'll do anything to make you happy!"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna263"]
[OnName num="Yuna"]
"I'll do whatever you say... I'll do anything you want..."
[cpg cn=true]

[OnName num="Kenji"]
"Wait, w-what are you doing...?!"
[cpg cn=true]

[SE f="se045"]
;//【ＳＥ】ドンッ！

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna264"]
[OnName num="Yuna"]
"——!"
[cpg cn=true]

I unintentionally pushed Yuna away.
[cpg]

[OnName num="Kenji"]
"What do you think you're doing?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna265"]
[OnName num="Yuna"]
"I-I just wanted you to be with me, Kenji."
[cpg cn=true]

[OnName num="Kenji"]
"I want to be with Shiori."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna266"]
[OnName num="Yuna"]
"!"
[cpg cn=true]

[OnName num="Kenji"]
"I don't intend to have that kind of relationship with you, Yuna, and the only person I like is Shiori."
[cpg cn=true]

I turned my back on Yuna this time and walked out of the room.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna267"]
[OnName num="Yuna"]
"Kenji, wake up! Don't be fooled by Shiori!"
[cpg cn=true]

She was still going on about that...
[cpg]

I turned my back on Yuna, not listening to her words any longer.
[cpg]

[STOPBGM]
;//【ＢＧ】ブラックアウト
[free time=1500]
[BG f="black.ui" time=1500]
[WAIT time=3500]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori310"]
[OnName num="Shiori"]
“...Tom, Tom, the piper's son. Stole a pig, and away did run. The pig was eat. And Tom was beat. And Tom went crying, down the street…”
[cpg cn=true]

[free time=1500]
[WAIT time=3000]


[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="ep016.ks" target="*start"]


