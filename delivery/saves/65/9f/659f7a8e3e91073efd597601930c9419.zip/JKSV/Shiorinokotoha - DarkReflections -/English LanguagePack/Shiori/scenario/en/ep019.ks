;//『ルートＤ』『双子』

*start
*root_d|Twins

;#################################################
*Ep019|Twins
;#################################################
[SCENE id=13]

[BG f="b_l_2f_gsr_p2.ui" time=1]

[OnName num="Kenji"]
"Don't do anything bad, you say? Hmm...?"
[cpg cn=true]

Without thinking, I put my hand in my pocket and felt the touch of metal.
[cpg]

I took it out and discovered that it was a small golden key.
[cpg]

This is what Erika and Yuna had found in the storage area.
[cpg]

[OnName num="Kenji"]
"It’s not going to work..."
[cpg cn=true]

[SE f="se068"]
;//【ＳＥ】引き出しの鍵開く

[WAIT time=500]

[OnName num="Kenji"]
"Oh, it opened."
[cpg cn=true]

When I used the key, it unlocked a drawer.
[cpg]

How did the key to the desk end up in the storage room?
[cpg]

[SE f="se116"]
;//【ＳＥ】引き出し開く

With some hesitation, I opened the top drawer to see what was inside.
[cpg]

[OnName num="Kenji"]
"What's this?"
[cpg cn=true]

The first thing that caught my eye was a rather large piece of paper.
[cpg]

There was a floor plan drawn on it, with "Tokita Library" written in the upper right corner.
[cpg]

[OnName num="Kenji"]
"Wow, They're the blueprints for this place."
[cpg cn=true]

It was somehow interesting to see what I usually saw in three dimensions on a flat surface.
[cpg]

I looked for each room on the blueprints.
[cpg]

[OnName num="Kenji"]
"This is the study where I am now..., and this is Shiori's room... Huh? That's weird."
[cpg cn=true]

Looking more closely at the blueprints, the study and the Shiori's room should be about the same size.
[cpg]

But the room I had been in, Shiori's room, was definitely smaller than this room.
[cpg]

Was it because there were so many books in that room that it gave the illusion of being cramped?
[cpg]

Or maybe those bookshelves were double-layered, and each row of books was thicker than the other?
[cpg]

Moreover, I felt that some rooms were off... I felt that the position and size of the rooms on the blueprints didn't match up to what I had seen.
[cpg]

Well, I was just imagining it, but...
[cpg]

That's what I thought as I folded the blueprints back up.
[cpg]

And the next thing I saw was...
[cpg]

[OnName num="Kenji"]
"Oh, is this a...diary?"
[cpg cn=true]

If it was here, then it must have been Shiori's grandfather's diary.
[cpg]

I was very interested in the diary, but I couldn't possibly read it without permission, since it was the diary of a stranger, albeit a deceased one.
[cpg]

[OnName num="Kenji"]
"I guess it's okay to read a little...just one page..."
[cpg cn=true]

But just as my curiosity got the better of me and I was about to open the diary...
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi460"]
[OnName num="Michi"]
"Snooping around someone's home sure seems like a fun hobby."
[cpg cn=true]

[OnName num="Kenji"]
"Ah!"
[cpg cn=true]

She suddenly called out to me and I quickly hid the diary in my jacket.
[cpg]

I turned around and saw a scary looking Michi standing there with her arms crossed.
[cpg]

[OnName num="Kenji"]
"I'm s-sorry!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi461"]
[OnName num="Michi"]
"If you just start rifling through stuff on your own, people will think you're a thief too."
[cpg cn=true]

She was right to be angry.
[cpg]

In fact, I had been trying to read the diary without permission.
[cpg]

[OnName num="Kenji"]
"I'm sorry. I went into the wrong room and ended up in here..."
[cpg cn=true]

I tried to make an excuse to cover up what I had been doing.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi462"]
[OnName num="Michi"]
"Meaning you mistook this room for Shiori's..."
[cpg cn=true]

Michi approached me suspiciously and seemed to be checking for any changes on the desk.
[cpg]

Her gaze wandered to the picture frames, and I took the opportunity to ask her about them.
[cpg]

[OnName num="Kenji"]
"Um, do you know why there are two copies of the same picture?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi463"]
[OnName num="Michi"]
"Shiori's grandfather was a cautious man, so he must have been prepared for damage and deterioration."
[cpg cn=true]

[OnName num="Kenji"]
"Oh...?"
[cpg cn=true]

If he was trying to prevent deterioration, wouldn't one be stored in a different place?
[cpg]

Like if they were lined up in the same place, wouldn't both pictures deteriorate in the same way...
[cpg]

But he must have been cautious because he did spend a lot of money to build a security system like that.
[cpg]

[OnName num="Kenji"]
"Michi, you were close with Shiori's grandfather, right?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi464"]
[OnName num="Michi"]
"He only hired me. For Shiori."
[cpg cn=true]

[OnName num="Kenji"]
"That's great that he hired a personal doctor for his granddaughter..."
[cpg cn=true]

When I said that, Michi gave me a distant look, as if she was remembering the past...
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi465"]
[OnName num="Michi"]
"That man loved Shiori so much that... Anyway, he said that he would take care of Shiori until his dying day, and that's why he left everything to Shiori."
[cpg cn=true]

[VOICE f="Michi1465"]
[OnName num="Michi"]
"That's why I'm still here with Shiori and it's my duty to eliminate anyone who hurts Shiori."
[cpg cn=true]


She said in a dignified tone.
[cpg]

Anyone who harms Shiori will be eliminated...?
[cpg]

After hearing those words, I remembered the fight between Michi and Erika.
[cpg]

I'm not sure how serious she was or not, but I shuddered to think what would happen if anything bad happened to Shiori.
[cpg]

[OnName num="Kenji"]
"Even though it's your job, Michi, you're pretty amazing..."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi466"]
[OnName num="Michi"]
"My job? Yeah... But I also like Shiori personally, and my ultimate goal is to cure her of her illness."
[cpg cn=true]

[OnName num="Kenji"]
"Shiori's illness..."
[cpg cn=true]

If that was her ultimate goal, did that mean that it would take a long time to find a cure...?
[cpg]

What kind of disease was it?
[cpg]

I was going to ask about that too, but then Michi spoke.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi467"]
[OnName num="Michi"]
"Come on, that's enough. Get out."
[cpg cn=true]

The conversation ended when she urged me to leave the room.
[cpg]

I couldn't very well say that I wanted to go and see Shiori now, as I was just caught snooping, so when Michi headed for Shiori's room, I headed downstairs by myself.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2up.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）（踊り場）******************************************************
;//章子が泣いている

[WAIT time=1500]
[BGM f="dod"]

[FG f="CHA06_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko295"]
[OnName num="Syouko"]
"Sob...sob..."
[cpg cn=true]

When I reached the landing of the stairs, I found Shoko crying next to the bronze bust.
[cpg]

Shoko, who was always cheerful and smiling...what happened to make her cry?
[cpg]

[OnName num="Kenji"]
"What's wrong?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko296"]
[OnName num="Syouko"]
"Hiccup...hicc..."
[cpg cn=true]

When I called out to her, Shoko looked up, sobbing.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko297"]
[OnName num="Syouko"]
"I'm... a clumsy and stupid giant isopod...hiccup."
[cpg cn=true]

[OnName num="Kenji"]
"What's that...?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko298"]
[OnName num="Syouko"]
"You're not making any sense..."
[cpg cn=true]

She was a natural airhead, even when she was crying.
[cpg]

[OnName num="Kenji"]
"Did something happen to you? Something to make you cry?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko299"]
[OnName num="Syouko"]
"No, I'm just ashamed of myself... Not only am I no help to the doctor at all, but I'm dragging her down..."
[cpg cn=true]

[VOICE f="Syouko1299"]
[OnName num="Syouko"]
"I get scolded every day at the hospital, and even though I've been a nurse for three years now, I keep making mistakes..."
[cpg cn=true]


[OnName num="Kenji"]
"Uh-huh..."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko300"]
[OnName num="Syouko"]
"On top of that, I got mixed up in this mess, people are dying, and in the corner of my mind I'm thinking about the late fees for my rental DVDs...and other tupid things."
[cpg cn=true]

[VOICE f="Syouko1300"]
[OnName num="Syouko"]
"All this stress built up over time and caused me to break down and cry..."
[cpg cn=true]


[OnName num="Kenji"]
"Aaah..."
[cpg cn=true]

In other words, she's crying over the inability to do her job and her late fees.
[cpg]

[OnName num="Kenji"]
"What's the use of worrying about it here? If you don't keep smiling, I'll get worried too. Please cheer up."
[cpg cn=true]

I said what I thought was fitting and patted Shoko on the head.
[cpg]

Then...
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko301"]
[OnName num="Syouko"]
"Kenji... You are being so kind to me... Hehe, it cheered me up a bit."
[cpg cn=true]

The woman, who had been crying, was now laughing, and returned to her usual smiling self.
[cpg]

[OnName num="Kenji"]
"I'm g-glad to hear that."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko302"]
[OnName num="Syouko"]
"If you keep being that nice to me, I'm going to end up falling in love with you..."
[cpg cn=true]

[OnName num="Kenji"]
"Huh, what?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko303"]
[OnName num="Syouko"]
"Because all the doctors in our hospital are old men! That's why meeting Kenji was such a treat for my eyes... Hehe!"
[cpg cn=true]

[VOICE f="Syouko1303"]
[OnName num="Syouko"]
"When you are sick or injured, please come to our hospital."
[cpg cn=true]


[OnName num="Kenji"]
"Sigh..."
[cpg cn=true]

I wanted to mention...that injuries are usually treated in a different ward, but I didn't want her to go off on another tangent, so I didn't.
[cpg]

[OnName num="Kenji"]
"Then, I'll be in the general collection room."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko304"]
[OnName num="Syouko"]
"Okay! I'm going to sort the medicine."
[cpg cn=true]

I left Shoko and headed to the first floor.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）******************************************************

[WAIT time=1500]

[OnName num="Kenji"]
"I brought this with me..."
[cpg cn=true]

It was Shiori's grandfather's diary that I had hidden from Michi.
[cpg]

I took it out of my jacket and looked at the cover.
[cpg]

I should put it back before anyone notices, but before I did, I wanted to take a look inside.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori470"]
[OnName num="Shiori"]
"Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"Shi, Shiori? Are you okay now?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori471"]
[OnName num="Shiori"]
"The medicine seems to be working..."
[cpg cn=true]

[OnName num="Kenji"]
"Really? That's great."
[cpg cn=true]

I shoved the diary into a bookcase somewhere so Shiori wouldn't see it.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori472"]
[OnName num="Shiori"]
"Were you reading?"
[cpg cn=true]

[OnName num="Kenji"]
"What?! Yeah, th-that's right. I was just about to read... the book you recommended, Shiori."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori473"]
[OnName num="Shiori"]
"That book, it's over there..."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, yeah, yeah. That's right."
[cpg cn=true]

Shiori had recommended "the World of Fantasia".
[cpg]



I started reading the first volume and Shiori was reading the seventh volume next to me.
[cpg]

We were just quietly reading, but I was so happy to get to be this close.
[cpg]

Only my shoulder area, where Shiori was touching, felt warm and comfortable.
[cpg]

"Oh, son of man! Your actions, your whole life, are all written in this book. You are only tracing it in vain."
[cpg cn=true]

The line that God said to the hero in the story caught my attention.
[cpg]

It was about the fate of knights.
[cpg]

[OnName num="Kenji"]
"I've heard this sort of thing before, but what about it...?"
[cpg cn=true]

As I muttered to myself, Shiori peeked at my book.
[cpg]

;//＠
[free time=1000]
;**【ＣＧ】ev_19_0 ***********************
[CG id=18 index=0 time=1000]
;*****************************************
;//[WAIT time=1000]


[VOICE f="Shiori474"]
[OnName num="Shiori"]
“Oh…, that's…”
[cpg cn=true]

She looked at where I was in the book, and began to speak slowly.
[cpg]


[VOICE f="Shiori475"]
[OnName num="Shiori"]
“It was a little different, but that's what grandfather used to tell me…”
[cpg cn=true]

[OnName num="Kenji"]
“Huh?”
[cpg cn=true]


[VOICE f="Shiori476"]
[OnName num="Shiori"]
"Even though your body is only here, your mind will trace the adventures in this book."
[cpg cn=true]

[VOICE f="Shiori1476"]
[OnName num="Shiori"]
"He used to say, ‘Everything you want to do, everything you need to do, it's all in this book’... Then he gave me the first volume..."
[cpg cn=true]

Shiori's grandfather must have taught her to project herself into books since she was too sick to go anywhere.
[cpg]


[VOICE f="Shiori477"]
[OnName num="Shiori"]
“I also learned about friendship, family, sadness, and anger from this book… When I finished the first volume, I moved on to volumes two and three…”
[cpg cn=true]

[VOICE f="Shiori1477"]
[OnName num="Shiori"]
"My world expanded thanks to this book that my grandfather gave me…”
[cpg cn=true]

[OnName num="Kenji"]
“And that's how you fell in love with fantasy."
[cpg cn=true]

Nodding her head at my words, Shiori continued.
[cpg]


[VOICE f="Shiori478"]
[OnName num="Shiori"]
"Then I started reading other books, and all the events in those books too became my stories that I traced…"
[cpg cn=true]

[VOICE f="Shiori1478"]
[OnName num="Shiori"]
“What’s written in these books can happen in reality. Even if it’s abstract, it’ll become my reality…”
[cpg cn=true]

[OnName num="Kenji"]
"It's a little hard for me to understand, but I do know that every book here is Shiori, and every one of them is filled with your grandfather's love. He was a wonderful man, wasn't he, your grandfather?"
[cpg cn=true]


[VOICE f="Shiori479"]
[OnName num="Shiori"]
“Yeah…”
[cpg cn=true]

When I said that, Shiori smiled, looking very happy.
[cpg]

Then, after looking around a bit to make sure it was okay, she put her mouth near my ear and whispered softly.
[cpg]

[STOPBGM]


[VOICE f="Shiori480"]
[OnName num="Shiori"]
"I'll only tell this to you, Kenji…"
[cpg cn=true]

[OnName num="Kenji"]
“?”
[cpg cn=true]


[VOICE f="Shiori481"]
[OnName num="Shiori"]
“Mi Tui Amas Vin…”
[cpg cn=true]

[OnName num="Kenji"]
“Huh? What’s that?”
[cpg cn=true]

[BGM f="dod"]


[VOICE f="Shiori482"]
[OnName num="Shiori"]
"A magic spell. My grandfather taught it to me alone, and then later I once saw it published in this book…, and I was so surprised…"
[cpg cn=true]

[OnName num="Kenji"]
“What does it mean?”
[cpg cn=true]


[VOICE f="Shiori483"]
[OnName num="Shiori"]
"Really? You're going to tell me something so important? Say it again. I want to remember."
[cpg cn=true]

[OnName num="Kenji"]
“Really? You're going to tell me something so important? Say it again. I want to remember."
[cpg cn=true]


[VOICE f="Shiori484"]
[OnName num="Shiori"]
“Mi Tui Amas Vin…”
[cpg cn=true]

[OnName num="Kenji"]
“Mi, Tui, Amas, Vin…”
[cpg cn=true]

I recited the important magic spell that Shiori taught me over and over again, carving it into my mind.
[cpg]

And then Shiori...
[cpg]


[VOICE f="Shiori485"]
[OnName num="Shiori"]
"Felice Gin Al Vie…"
[cpg cn=true]

She whispered a new spell again.
[cpg]

[OnName num="Kenji"]
“Huh, that too?”
[cpg cn=true]


[VOICE f="Shiori486"]
[OnName num="Shiori"]
“This is a password… Kenji, just remember the first one…”
[cpg cn=true]

[OnName num="Kenji"]
"Got it. Mi, Tui, Amas, Vin… Mi, Tui…"
[cpg cn=true]

Shiori didn't tell me what it meant, but maybe I'll find out as I continue reading the book.
[cpg]

I decided to save the fun of solving that mystery for later.
[cpg]

[OnName num="Kenji"]
"But I'm pretty happy that I know something that even Michi doesn't know. Michi’s kind of like a parental figure for you, Shiori, isn’t she?"
[cpg cn=true]

I suddenly remembered the conversation I had with Michi in the study and asked her about it.
[cpg]


[VOICE f="Shiori487"]
[OnName num="Shiori"]
“It's kind of weird to have a substitute parent when your parents are still alive…”
[cpg cn=true]

[OnName num="Kenji"]
“Ah…, I’m sorry…”
[cpg cn=true]


[VOICE f="Shiori488"]
[OnName num="Shiori"]
"No… My parents left me with my grandfather and I never heard from them again, so Michi certainly is the most important person in my life…"
[cpg cn=true]

[OnName num="Kenji"]
"How long have you known each other?"
[cpg cn=true]


[VOICE f="Shiori489"]
[OnName num="Shiori"]
“I don’t remember…”
[cpg cn=true]

[OnName num="Kenji"]
“Really?!”
[cpg cn=true]


[VOICE f="Shiori490"]
[OnName num="Shiori"]
“She came to my house when I was little… Since Dr. Michi came, my world has expanded again…”
[cpg cn=true]

[VOICE f="Shiori1490"]
[OnName num="Shiori"]
“She told me about what she has seen and heard, and she taught me chemistry and math, even though I had always been attracted to fantastical things…”
[cpg cn=true]

[OnName num="Kenji"]
"She also tutored you, didn't she? Michi is a scientist, so it must have been hard for you to get along."
[cpg cn=true]


[VOICE f="Shiori491"]
[OnName num="Shiori"]
“Not really… She never rejected a single thing about me, and she loved me just as much as grandfather did…”
[cpg cn=true]

[VOICE f="Shiori1491"]
[OnName num="Shiori"]
"If it hadn't been for Dr. Michi when grandfather died…, I might have been truly broken… So… "
[cpg cn=true]

[OnName num="Kenji"]
“So?”
[cpg cn=true]

Shiori turned her head slightly and looked pensive, then whispered in a quiet voice.
[cpg]


[VOICE f="Shiori492"]
[OnName num="Shiori"]
"I'm willing to do anything… that makes the doctor happy, I could do anything…"
[cpg cn=true]

[OnName num="Kenji"]
“I see…”
[cpg cn=true]

Michi was not only a doctor, but she has also been a pillar of strength for Shiori, who lost her grandfather.
[cpg]


[VOICE f="Shiori493"]
[OnName num="Shiori"]
“I want to hear more about Kenji, not just me…”
[cpg cn=true]

[OnName num="Kenji"]
“Hmm, about me?”
[cpg cn=true]

Normally, if someone told me something like this, it would just be troublesome, but I wanted to tell any story I could to Shiori, who didn't know what normal was.
[cpg]

[OnName num="Kenji"]
“Umm, I was born into a family that was neither poor nor rich, my father is a businessman and my mother is a housewife.”
[cpg cn=true]

[OnName num="Kenji"]
“When I was in elementary school, I used to play until dusk every day and forget to do my homework, which made my teacher and mother angry.”
[cpg cn=true]

[OnName num="Kenji"]
“When I entered junior high school, I got into soccer and baseball, but I soon got bored. In high school, I didn't join any club activities and played video games all the time.”
[cpg cn=true]

Shiori listened to my boring story with great interest.
[cpg]

To Shiori, my daily life might be a story from another world.
[cpg]


[VOICE f="Shiori494"]
[OnName num="Shiori"]
"I envy you… Kenji has parents and friends who are so healthy and…kind."
[cpg cn=true]

[VOICE f="Shiori1494"]
[OnName num="Shiori"]
"From my point of view, you seem perfect… I wish I could have been like… Like Kenji and the main character in this book…"
[cpg cn=true]

Wanting and yearning for things, but still have no control over the situation.
[cpg]

All this time I thought I had nothing because I wasn’t trying hard enough.
[cpg]

But even if Shiori wanted to put in the effort, she couldn't.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori495"]
[OnName num="Shiori"]
“I want to be like Erika and go shopping… I want to be like Yuna and get a part-time job… I want to be like Kenji…”
[cpg cn=true]

I felt so bad for Shiori as she muttered forlornly, I loved her so much…, My heart was aching and crying.
[cpg]



[FG f="CHA01_p5_01_a.ui" method="change_1" pos="2/3" time=1000]

[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）
[WAIT time=1500]

[OnName num="Kenji"]
“Let’s have…, an adventure…”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori496"]
[OnName num="Shiori"]
“Huh…?”
[cpg cn=true]


I softly kissed Shiori's small dainty lips.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]

Shiori looked a little surprised and confused, but closed her eyes quietly as I went to place my lips on hers once more.
[cpg]


[VOICE f="Shiori497"]
[OnName num="Shiori"]
“Mmm…”
[cpg cn=true]

Her closed eyelids and long eyelashes were beautiful.
[cpg]

I gently slip my tongue around Shiori's lips.
[cpg]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori498"]
[OnName num="Shiori"]
“Mmm…, uh….”
[cpg cn=true]

When our lips parted with a small chuckle, Shiori stared at me curiously.
[cpg]


[VOICE f="Shiori499"]
[OnName num="Shiori"]
“Is this…an adventure?”
[cpg cn=true]

[OnName num="Kenji"]
"An adventure in a way...or maybe the start of an adventure…?"
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori500"]
[OnName num="Shiori"]
"Well then…, take me to…Kenji's Fantasyland."
[cpg cn=true]

[OnName num="Kenji"]
“Then, princess, please take my hand."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori501"]
[OnName num="Shiori"]
“Hehe… Yes.”
[cpg cn=true]

I took Shiori's hand like a knight and opened the door behind the counter.
[cpg]

;#############################################################
;//Ev012
;#############################################################

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_lr_0.ui" time=1000]
;//【ＢＧ】図書館・地下・書庫　（暗／懐中電灯）

[WAIT time=1500]

[OnName num="Kenji"]
"Princess, there may be a terrible demon back here. Please stay close to me."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori502"]
[OnName num="Shiori"]
"Wow, how scary. But I have a wonderful knight with me, so I'm not afraid."
[cpg cn=true]

[OnName num="Kenji"]
“Hehehe…”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]


A princess and her knight. Shiori was on board with my simple adventure role-playing.
[cpg]

I took her by the hand and we explored the library as if it were a labyrinth.
[cpg]

She knew the place well, but Shiori seemed to be enjoying it, which made me happy.
[cpg]

;//【ＢＧ】図書館・地下・書庫　（暗／懐中電灯）

[OnName num="Kenji"]
“It's full of books, too….”
[cpg cn=true]

The upper floor was filled with books, but the basement was also filled with books, as it should be.
[cpg]

The sight startled me and brought me back to my senses.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori503"]
[OnName num="Shiori"]
"Yes… This library is full of me…"
[cpg cn=true]

Shiori was the library, and all the books were Shiori.
[cpg]

And I wanted to read all the books here, no matter how long it took. That’s what I thought.
[cpg]

[OnName num="Kenji"]
"The books around here are... They’re very old, aren't they?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori504"]
[OnName num="Shiori"]
"Yes. Some of the items are historically valuable, so we keep them here."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, even amazing stuff like that?!"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori505"]
[OnName num="Shiori"]
“Do you want to see…?”
[cpg cn=true]

[OnName num="Kenji"]
“What? No! Someone like me?!"
[cpg cn=true]

I'm confident that I wouldn’t be able to understand its value even a little.
[cpg]

I was also afraid that the books would be very expensive, so I refused, thinking that I might mess them up.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori506"]
[OnName num="Shiori"]
"I'll show you, because you’re special, Kenji."
[cpg cn=true]

[OnName num="Kenji"]
“Huh, really? Well, maybe just a little…”
[cpg cn=true]

I was so excited when Shiori told me I was special. I am simple-minded.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori507"]
[OnName num="Shiori"]
“Um…”
[cpg cn=true]

[free time=1000]


Shiori put the book she was holding on the desk and went over to the bookshelf.
[cpg]

I leaned against my desk, grinning at the Shiori’s back as she picked out a book for me…
[cpg]

[OnName num="Kenji"]
“Woah?!”
[cpg cn=true]

[SE f="se127"]
;//【ＳＥ】机、壊れる

;//[WAIT time=1000]

;//[SE f="se000"]
;//【ＳＥ】本が机から落ちる



The desk in the basement was damaged somehow, and a leg snapped.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori508"]
[OnName num="Shiori"]
“Are you o-okay? Kenji?!”
[cpg cn=true]

The desk was a wreck. At the same time I fell, the book that Shiori had always been holding fell to the floor.
[cpg]

[OnName num="Kenji"]
“S-sorry!”
[cpg cn=true]

[STOPBGM]

I dropped the book that Shiori cherished so much, and hurriedly reached out to pick up the book that had fallen, horrified.
[cpg]

;//開いた本のページに乾いて茶色くなった大量の血
[BGM f="huan"]

There was something brown and dry stained on the page of the book that it must have been opened to when it fell.
[cpg]

It looked like dried blood, and for a moment I froze.
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori509"]
[OnName num="Shiori"]
“What’s wrong…ah?”
[cpg cn=true]

[SE f="se125"]
;//【ＳＥ】本を閉じる



When Shiori noticed what was going on, she quickly took the book away and closed it.
[cpg]

[OnName num="Kenji"]
“That’s…”
[cpg cn=true]

I wanted to ask about the stain, but Shiori…
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori510"]
[OnName num="Shiori"]
“The World of Fantasia, Volume…4.”
[cpg cn=true]

She changed the subject.
[cpg]

And then…
[cpg]


[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori511"]
[OnName num="Shiori"]
“Ugh…”
[cpg cn=true]


And then, with a small grunt, she held her chest and crouched down on the spot.
[cpg]

[OnName num="Kenji"]
“Shiori! Are you in pain? Does it hurt? Hold on!”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori512"]
[OnName num="Shiori"]
“My medicine…, the doctor…”
[cpg cn=true]

[OnName num="Kenji"]
"Michi! Miiichii!"
[cpg cn=true]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
I hurried out of the stacks and shouted, hitting the reception bell on the counter repeatedly.
[cpg]

[OnName num="Kenji"]
“Miiichiii!!”
[cpg cn=true]

[SE f="se008" loop=true]
;//【ＳＥ】チンベル連打

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=2500]

[stopse g=2]
;//通常se

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko305"]
[OnName num="Syouko"]
“What’s wrong?!”
[cpg cn=true]

Shoko came out of the special reference book room and I told her what happened.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko306"]
[OnName num="Syouko"]
“Doctor! Where is she?! Doctor!!”
[cpg cn=true]

[SE f="se069"]
;//【ＳＥ】小走り

Not long after, Michi came downstairs and looked a little annoyed by the noise.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi468"]
[OnName num="Michi"]
“What? It’s so loud…”
[cpg cn=true]

[OnName num="Kenji"]
“Hurry, Shiori…!”
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi469"]
[OnName num="Michi"]
“What?! Where is she?”
[cpg cn=true]

[OnName num="Kenji"]
“Over, here!”
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】ダッシュ

;//＠
;//エフェクト
[window target=false]
[transition target={true} rule="108.jpg" color={0x000000ff} time=2000]
[WAIT time=2100]
[free time=100]
[BG f="black.ui" time=100]
[WAIT time=200]
[BG f="b_l_b1_lr_0.ui" time=100]
;//【ＢＧ】図書館・地下・書庫　（暗／懐中電灯）
[WAIT time=1500]

[transition target={false} rule="108.jpg" color={0x000000ff} time=2000]
[WAIT time=3100]
[window target=true]


[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi470"]
[OnName num="Michi"]
“Shiori! Stop dilly-dallying! Get her to the infirmary!”
[cpg cn=true]

[OnName num="Kenji"]
“Y-yes!”
[cpg cn=true]


[STOPBGM]

;//エフェクト
[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=2100]
[free time=100]
[BG f="black.ui" time=100]
[WAIT time=200]
[BG f="b_l_b1_disp_0.ui" time=100]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン閉／蝋燭）******************************************************
[WAIT time=2000]
[transition target={false} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=3100]
[window target=true]

[BGM f="dod"]

After taking some medicine in the infirmary, Shiori was put on an IV and went to sleep.
[cpg]

After completing the procedure, Michi sat down on a chair and turned to me with her long legs crossed.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi471"]
[OnName num="Michi"]
"You know Shiori's body isn't very strong... don't push her too hard."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi472"]
[OnName num="Michi"]
“If you're going to be a bad influence on Shiori, I can’t approve of your relationship.”
[cpg cn=true]

[OnName num="Kenji"]
“I’m sorry…”
[cpg cn=true]

I thought she sounded like a parent or a teacher, but Michi was actually both Shiori's parental figure and her teacher.
[cpg]

Besides, Shiori’s grandfather had directly asked Michi to take care of her so it was only natural that she would feel responsible if anything happened to her.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi473"]
[OnName num="Michi"]
"Shiori is not like other girls. She’s not someone you can play around with!"
[cpg cn=true]

[OnName num="Kenji"]
“Play around…I would never…!”
[cpg cn=true]

At least I cared about Shiori, and I had no intention of playing with her.
[cpg]

But…
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi474"]
[OnName num="Michi"]
"You're still in school, aren't you? If you want to enjoy puppy love, you should have it with a girl in your class."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

Michi was genuinely angry.
[cpg]

I guess Shiori was like her child.
[cpg]

That's why she has no mercy for those who hurt her and since the beginning she was trying to keep dangerous people away.
[cpg]

If I could have, I would have said something to her, but the fact was that I had caused Shiori to have an episode, so I had no say in the matter.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi475"]
[OnName num="Michi"]
“Just go…”
[cpg cn=true]

[OnName num="Kenji"]
“Yes…”
[cpg cn=true]

I left the doctor's office, sighing.
[cpg]

;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="101.jpg" color={0x000000ff} time=3000]
[WAIT time=3100]
[free time=100]
[BG f="black.ui" time=100]
[WAIT time=200]
[BG f="b_l_1f_entrance_p4.ui" time=100]
;//【ＢＧ】図書館・１階・エントランス　夜（暗／蝋燭）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_7" pos="2/3" time=100]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="1/3" time=100]
[FG f="CHA06_p3_01_a.ui" method="change_7" pos="3/3" time=100]

[WAIT time=1500]

[transition target={false} rule="101.jpg" color={0x000000ff} time=3000]
[WAIT time=3100]

[window target=true]

[WAIT time=100]
[VOICE f="Erika490"]
[OnName num="Erika"]
"Ohhhh … I'm so hungry…"
[cpg cn=true]

[VOICE f="Yuna363"]
[OnName num="Yuna"]
“I’m…dizzy…”
[cpg cn=true]

As if it was routine, we gathered at the entrance at night.
[cpg]

[VOICE f="Syouko307"]
[OnName num="Syouko"]
“At least have some tea…”
[cpg cn=true]

Shoko kept pouring me more and more tea, but even if I only drank water, I would just flush it down the toilet soon after.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika491"]
[OnName num="Erika"]
"I want to move my jaw.. I want to chew solid food... Hey, Yuna, sit away from me…”
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna364"]
[OnName num="Yuna"]
“Why…?”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika492"]
[OnName num="Erika"]
“I’ll only say this because we’re friends… You stink.”
[cpg cn=true]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna365"]
[OnName num="Yuna"]
“What…?”
[cpg cn=true]

I think a friend would have said it better.
[cpg]

But it’s true that the body odor was getting worse.
[cpg]

That's how long we've been trapped in here.
[cpg]

[OnName num="Kenji"]
“Even though…we can see outside…”
[cpg cn=true]

Looking up, there was a skylight right above us and we could see the sky.
[cpg]

Even though we could see outside beyond the glass, we were crouched close to the ground.
[cpg]

[SE f="se037"]
;//【ＳＥ】腹鳴る
I couldn't tell if it was my stomach rumbling or someone else's.
[cpg]

It hadn't even been a few days since we ran out of food, and now look at us.
[cpg]

Humans are so weak, I thought to myself.
[cpg]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna366"]
[OnName num="Yuna"]
"Why don't we just go to bed…? If we stay up, we’ll just get hungry again…"
[cpg cn=true]

It was a little early to go to bed, but I had no objections.
[cpg]

Because there was nothing else to do.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika493"]
[OnName num="Erika"]
"Oh, but I need more blankets. I got so cold last night that I woke up once."
[cpg cn=true]

Indeed, the cold weather these past few days was sudden and a bit unbearable.
[cpg]

They say women get cold easily, and so it was probably tough.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi476"]
[OnName num="Michi"]
"Oh, you're all here?”
[cpg cn=true]

..........
[cpg]

Shiori and Michi came up from below and joined us.
[cpg]

Shiori still looked a little queasy.
[cpg]

I wanted to say a few words of apology, but I couldn't because everyone was around and I felt Michi staring at me.
[cpg]

;//チョコバーを見つけて奪い合うシーンはルートＡ『汚物の行く末』（ルートごと削除済み）固有のイベントでしたが
;//何故かその話がこっちにも影響している？（ルートを見ているという前提で書いていたのか）ルートＡから分岐してるわけではないので
;//そもそもがおかしいので、表現を無くしました

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika494"]
[OnName num="Erika"]
“Oh, yeah. Blankets, blankets! Ms. Kisaragi, we still have blankets, right?"
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi477"]
[OnName num="Michi"]
“I think we do.”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika495"]
[OnName num="Erika"]
"I need about five more!"
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi478"]
[OnName num="Michi"]
"I don’t think we have f-five."
[cpg cn=true]

When Erika started to make demands, Yuna followed suit.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna367"]
[OnName num="Yuna"]
“I would like at least three blankets…, too…”
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi479"]
[OnName num="Michi"]
“With what we have, everyone could at least get one more.”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika496"]
[OnName num="Erika"]
"What? We're going to die! We’re going to freeze to death!"
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi480"]
[OnName num="Michi"]
“Well, there are the ones that Takagi and Hosokawa were using… If you can manage with those…”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika497"]
[OnName num="Erika"]
"What? Ew~..., I don’t want one of those, because they stink..."
[cpg cn=true]

You wanted Takagi's chocolate bar, but you don't want his blanket…
[cpg]

The cold seemed to be less pressing than starving to death, but Erika only complained about the cold.
[cpg]

But Erika didn't stop here.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika498"]
[OnName num="Erika"]
"The bedding on Shiori’s bed is down, right? It’s not fair that only she gets to use it!"
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Shiori513"]
[OnName num="Shiori"]
“Ah…”
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi481"]
[OnName num="Michi"]
“Shiori's sick. Find something else.”
[cpg cn=true]

The barricade called Michi was strong enough to keep her out of the way.
[cpg]

Then, Erika quickly moved on to her next target.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika499"]
[OnName num="Erika"]
"Hey, Yuna, can I borrow that coat tonight?"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna368"]
[OnName num="Yuna"]
“What?!”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika500"]
[OnName num="Erika"]
"It's fine, right? I have a lower body temperature than you."
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna369"]
[OnName num="Yuna"]
"B-But, if I give it to you, I'll freeze......"
[cpg cn=true]

[OnName num="Kenji"]
"If your body temperature was low, wouldn't you be more resistant to the cold?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika501"]
[OnName num="Erika"]
".................."
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna370"]
[OnName num="Yuna"]
".................."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika502"]
[OnName num="Erika"]
"It's freezing!"
[cpg cn=true]

After a moment of silence, Erika began to pull Yuna's coat off.
[cpg]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna371"]
[OnName num="Yuna"]
“But, I’m cold…”
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko308"]
[OnName num="Syouko"]
“Please stop, you two…”
[cpg cn=true]

Shoko intervened, pulling them by their coats.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna372"]
[OnName num="Yuna"]
“I said let go…!”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika503"]
[OnName num="Erika"]
“I said give it to me…!”
[cpg cn=true]

;//[SE f="se000"]
;//【ＳＥ】ギューギュー

Listening to the two of them squealing at each other, I felt myself getting worked up.
[cpg]

I was sick and tired of all the fighting.
[cpg]

[OnName num="Kenji"]
"That's enough! Quit your whining, are you a baby? If you're so cold, just wrap this around you!"
[cpg cn=true]

I took the scarf I had wrapped around my neck and threw it at Erika.
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika504"]
[OnName num="Erika"]
"Eh…, really? But, Kenji…., won’t you be cold?"
[cpg cn=true]

She didn't care about Yuna getting cold, but she showed me concern. I hated this sweet act of Erika’s.
[cpg]

[OnName num="Kenji"]
"In return, I want you to stay quiet. I'm losing my mind!"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika505"]
[OnName num="Erika"]
“Yes, I will! I'll be quiet! Sniff, sniff, ah~, Kenji’s smell…”
[cpg cn=true]

[OnName num="Kenji"]
“Ugh…”
[cpg cn=true]

Even though she was just complaining about body odor, she had no sense of delicacy.
[cpg]

But I thought it was a small price to pay if it would make her move on.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori514"]
[OnName num="Shiori"]
“Kenji…, don't catch a cold…”
[cpg cn=true]

[OnName num="Kenji"]
"Oh, oh! I'm okay. I'm an idiot."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori515"]
[OnName num="Shiori"]
“Huh?”
[cpg cn=true]

[OnName num="Kenji"]
"Idiots can't catch colds."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori516"]
[OnName num="Shiori"]
“Ummm…”
[cpg cn=true]

I was happy to hear Shiori's voice, but when I told her a cheesy joke, she didn't seem to get it.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko309"]
[OnName num="Syouko"]
"Well, well, everyone. Why don't you settle down and have some tea?"
[cpg cn=true]

More tea…
[cpg]

Shoko offered me tea whenever she got the chance.
[cpg]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna373"]
[OnName num="Yuna"]
“I’ve had e-enough… My stomach is churning…”
[cpg cn=true]

[OnName num="Kenji"]
"Ah, well…, as long as there’s water, we should be okay for a month or so, so it’ll be okay… We should be fine."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori517"]
[OnName num="Shiori"]
“Chuckle…”
[cpg cn=true]

Shiori laughed at my cheerfulness.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika506"]
[OnName num="Erika"]
"What kind of penalty game is that, a month with just water?"
[cpg cn=true]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko310"]
[OnName num="Syouko"]
“Haha.”
[cpg cn=true]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna374"]
[OnName num="Yuna"]
“Hehehe.”
[cpg cn=true]

Well, I'll take any kind of joke if it will make this place more pleasant.
[cpg]

Because in this situation, I think positive energy is the most important thing.
[cpg]

[STOPBGM]

;//エフェクト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=2100]

[free time=100]
[BG f="black.ui" time=100]
[BG f="b_l_2f_sr_2.ui" time=100]
;//【ＢＧ】図書館・２階・セキュリティルーム　（暗／数台のモニターが点灯）******************************************************
[WAIT time=1500]

[transition target={false} rule="163.jpg" color={0x000000ff} time=2000]
[WAIT time=3100]

[window target=true]

;//[BGM f="silent"]

;//モニター数台が稼働していて、皆がエントランスにいる様子が映し出されており、それを見ている誰か（コトハだが、顔は見えない）がいる

;//？？？
[VOICE f="Shiori518"]
[OnName num="unknown"]
“...hehe.”
[cpg cn=true]

[STOPBGM]

;//【ＢＧ】ブラックアウト

[BG f="black.ui" time=2000]
[WAIT time=3000]

;//以下、栞はコトハ
;//↓　名前は栞だけど本当はコトハ、という展開です。

I wondered how long I had been on the floor that day…
[cpg]

I woke up with the feeling of something touching my face.
[cpg]

[OnName num="Kenji"]
“Who?!”
[cpg cn=true]


;//懐中電灯で照らす

[BG f="b_l_1f_tbr_p4.ui" time=1000]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=1000]
[WAIT time=100]
[VOICE f="Shiori519"]
[OnName num="Shiori"]
".................."
[cpg cn=true]

[BGM f="dod"]

[OnName num="Kenji"]
"Shi, Shiori?! What are you doing, at this hour?"
[cpg cn=true]

I quickly turned on my flashlight, and there was Shiori, stroking my cheek.
[cpg]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori520"]
[OnName num="Shiori"]
“I was worried about your scratch…”
[cpg cn=true]

[OnName num="Kenji"]
“Scratch?”
[cpg cn=true]

The injury on my cheek where Erika scratched me.
[cpg]

It wasn't a big deal at all, but Shiori kept saying how she had been worried about it.
[cpg]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori521"]
[OnName num="Shiori"]
“Will it…leave a scar?”
[cpg cn=true]

[OnName num="Kenji"]
“Something like this...will disappear soon.”
[cpg cn=true]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori522"]
[OnName num="Shiori"]
“That’s a relief…”
[cpg cn=true]

[OnName num="Kenji"]
“You're overreacting.”
[cpg cn=true]

I joked about her needless worrying, while Shiori stroked my wound.
[cpg]

;//コトハ
[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori523"]
[OnName num="Shiori"]
"Hurting something beautiful is a sin… Hurting Kenji's face is something I…can't forgive."
[cpg cn=true]

Shiori still seemed to be angry with Erika.
[cpg]

[OnName num="Kenji"]
"Don't worry too much or you'll get stressed out."
[cpg cn=true]

I took the gentle Shiori's hand and held it between my hands.
[cpg]

[OnName num="Kenji"]
"Besides, if you stay up this late, Michi will…"
[cpg cn=true]

“I'll get scolded”… was what I was about to say, when I noticed something strange about Shiori's hand.
[cpg]

[OnName num="Kenji"]
“What happened to your nails?”
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori524"]
[OnName num="Shiori"]
“My nails…?”
[cpg cn=true]

The tip of her nails were all chipped.
[cpg]

[OnName num="Kenji"]
"I don't remember them being like this?"
[cpg cn=true]

;//コトハ
[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori525"]
[OnName num="Shiori"]
“Uh, yeah…”
[cpg cn=true]

Shiori quickly withdrew her hand and said a few words.
[cpg]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori526"]
[OnName num="Shiori"]
“I'm sorry to have woken you. Well, I'll see you tomorrow…”
[cpg cn=true]

[OnName num="Kenji"]
"You're leaving?"
[cpg cn=true]

Now that I was up, I wanted to spend some more time with her.
[cpg]

But…
[cpg]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori527"]
[OnName num="Shiori"]
“The doctor is waiting in my room…”
[cpg cn=true]

[free time=1000]

And then she quietly walked away.
[cpg]

She really just came to check on my wound.
[cpg]

[OnName num="Kenji"]
“Healthy…”
[cpg cn=true]

I stroked my cheek and closed my eyes again.
[cpg]

The only way to drown out the hunger was to sleep….
[cpg]

;//【ＢＧ】ブラックアウト
[STOPBGM]
[BG f="black.ui" time=900]
[WAIT time=3000]

[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 24th
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=1500]
[BGM f="dod"]

Maybe it was because I woke up once in the middle of the night last night, but I didn't sleep very well.
[cpg]

And since the reason I woke up this morning was my growling stomach, it was not a very refreshing wake up call.
[cpg]

;//胸像に話しかける栞（本物）

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=1000]
[WAIT time=100]
[VOICE f="Shiori528"]
[OnName num="Shiori"]
“Grandfather…”
[cpg cn=true]

I looked at the top of the stairs and saw Shiori talking to the bust.
[cpg]


[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori529"]
[OnName num="Shiori"]
"Am I wrong…? Why am I so confused about getting what I want…?"
[cpg cn=true]

It didn't seem to be a nursery rhyme reading.
[cpg]

Shiori put her hand on her grandfather's bust and muttered something with a sad expression.
[cpg]

If she had a problem, I hoped she would tell me, not some mute statue.
[cpg]

[OnName num="Kenji"]
“Shiori…”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori530"]
[OnName num="Shiori"]
“Ah…”
[cpg cn=true]

[OnName num="Kenji"]
“Good morning.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori531"]
[OnName num="Shiori"]
“G-good morning…”
[cpg cn=true]

Shiori averted my gaze, perhaps not too happy that I heard her talking to herself.
[cpg]

[OnName num="Kenji"]
"Did you go to sleep right after that last night?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori532"]
[OnName num="Shiori"]
“Right after that…?”
[cpg cn=true]

[OnName num="Kenji"]
“After you came to see me.”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori533"]
[OnName num="Shiori"]
“Uh, last night…? Yeah…, I went back to bed…”
[cpg cn=true]

[OnName num="Kenji"]
“Really…”
[cpg cn=true]


I felt somewhat choked up.
[cpg]

It was like she was looking for an answer, as if she had forgotten all about last night.
[cpg]

[OnName num="Kenji"]
"Perhaps sleepwalking…"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika507"]
[OnName num="Erika"]
"I'm cold, I'm hungry, do something about it~!"
[cpg cn=true]

Then Erika and Yuna came from upstairs and kicked that thought out of my head.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika508"]
[OnName num="Erika"]
"One blanket doesn't help! It's cold, cold, cold!"
[cpg cn=true]

Erika shivered, pulling the blanket over her head.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna375"]
[OnName num="Yuna"]
“I wonder if there are any chocolate bar pieces down here…”
[cpg cn=true]

Yuna was being Yuna, and as soon as she came downstairs, she started crawling on the floor looking for food.
[cpg]

The scene was bizarre, and I felt as if I had wandered into a slum in some foreign country.
[cpg]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika509"]
[OnName num="Erika"]
"Ugh… it’s cold. I'm dying."
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna376"]
[OnName num="Yuna"]
“Food…food…”
[cpg cn=true]

How can a person in a tight spot become so oblivious to the world around them?
[cpg]

They seemed to have forgotten the word "hygiene," with their disheveled hair, tattered clothes, and undone ribbons.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko311"]
[OnName num="Syouko"]
“Good morn~”
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika510"]
[OnName num="Erika"]
“Coffee!”
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna377"]
[OnName num="Yuna"]
“Tea for me!”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko312"]
[OnName num="Syouko"]
“Y-yes.”
[cpg cn=true]

Before Shoko could finish her greeting, the two of them demanded a drink.
[cpg]

If they wanted to drink, they could have gotten it on their own, but they completely treated Shoko like a maid.
[cpg]

[OnName num="Kenji"]
“Come on, you guys, get up yourselves sometimes.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko313"]
[OnName num="Syouko"]
“Oh, it's okay, it's okay. There’s only so much I can do…”
[cpg cn=true]

[OnName num="Kenji"]
“There you go…”
[cpg cn=true]

Shoko stopped me from getting angry, but I wondered if that was too demeaning?
[cpg]

How could she be so happy being used by people younger than her like that?
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko314"]
[OnName num="Syouko"]
“Shiori, come on.”
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Shiori534"]
[OnName num="Shiori"]
“Yes…”
[cpg cn=true]

;//[SE f="se000"]
;//【ＳＥ】ケトル　コトコト言い出す

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika511"]
[OnName num="Erika"]
“It's already boiling! Come on, hurry up!
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko315"]
[OnName num="Syouko"]
“Ah, yes.”
[cpg cn=true]

It was a small kettle that can only boil two or three cups at a time.
[cpg]

As soon as the lid started to clink, Erika demanded her coffee.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna378"]
[OnName num="Yuna"]
"Hurry, m-me too… My stomach is so empty and I'm about to collapse."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]

………
[cpg]

The disdain in Shiori's eyes, as she stared at the two selfish people, was darker than her disappointment.
[cpg]

When I looked at her, I saw that her lips were also paler than usual in the cool morning air.
[cpg]

[OnName num="Kenji"]
“Are you cold?”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori535"]
[OnName num="Shiori"]
“A little…”
[cpg cn=true]

[OnName num="Kenji"]
"You should stay under the covers until you’ve warmed up. Come on, let's go."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi482"]
[OnName num="Michi"]
“Kenji, may I have a word with you…?”
[cpg cn=true]

I was holding Shiori's shoulders and trying to get her to stand up, when Michi, who came out of nowhere, called out to me from the side of the stairs.
[cpg]

[OnName num="Kenji"]
“Haa… Wait, Right now Shiori is…”
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi483"]
[OnName num="Michi"]
“It’s okay. Shiori, go on up by yourself.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori536"]
[OnName num="Shiori"]
“Okay…”
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko316"]
[OnName num="Syouko"]
“Oh, I'll bring you some tea right away!”
[cpg cn=true]

Shiori headed up the stairs alone.
[cpg]

What was it…that would cause Michi to leave Shiori alone?
[cpg]

;#############################################################
;//Ev013
;#############################################################

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン閉／蝋燭）******************************************************

[WAIT time=1500]


I was brought to the infirmary, and Michi chewed me out again.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi484"]
[OnName num="Michi"]
“I told you, didn’t I? To leave Shiori alone.”
[cpg cn=true]

[OnName num="Kenji"]
“But..., she looked so cold.”
[cpg cn=true]

When I expressed my honest feelings, Michi's expression suddenly eased gently.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi485"]
[OnName num="Michi"]
"I know you’re kind. But I want you to keep your distance."
[cpg cn=true]

I couldn't wholeheartedly nod my head in agreement when she said that. Shiori was the only one for me…
[cpg]

;//エフェクト
[window target=false]
[transition target={true} rule="101.jpg" color={0x000000ff} time=3000]
[WAIT time=3100]
[free time=100]
[BG f="black.ui" time=100]
[WAIT time=200]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************
[WAIT time=1500]
[transition target={false} rule="101.jpg" color={0x000000ff} time=3000]
[WAIT time=5100]
[window target=true]

[STOPBGM]


[FG f="CHA03_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika512"]
[OnName num="Erika"]
“Aaaaaah!”
[cpg cn=true]

[BGM f="danger"]

When I returned to the entrance with Michi, I found Erika standing on the landing with a spear in hand, wondering what had happened.
[cpg]

[OnName num="Kenji"]
“W-what are you doing?!”
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA06_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Syouko317"]
[OnName num="Syouko"]
“After we started talking about freezing to death or starving to death… Then suddenly, Erika…!"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika513"]
[OnName num="Erika"]
"If I don't get out of here, I’m going to die! I can't do this anymore! I have to get out of here!"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Yuna379"]
[OnName num="Yuna"]
"You can't reach it, Erika! It won’t go that high."
[cpg cn=true]

[OnName num="Kenji"]
“That high…? Not the…”
[cpg cn=true]

There was a skylight far above Erika's head, just beyond her line of sight.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika514"]
[OnName num="Erika"]
“Aaaah!!”
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】走る

Before she could stop herself, Erika ran up the stairs to the second floor and threw the spear like it was a javelin.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi486"]
[OnName num="Michi"]
"Don't do anything stupid!"
[cpg cn=true]

[free time=1000]


However, Michi's angry shout did not reach Erika in time, and the very real spear was vigorously shot into the sky.
[cpg]

[SE f="se117"]
;//【ＳＥ】ガッシャーーーン！
[WAIT time=2000]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Yuna380"]
[OnName num="Yuna"]
“Kyaaaa!!”
[cpg cn=true]

[OnName num="Kenji"]
“Waaaaah?!”
[cpg cn=true]

[SE f="se130"]
;//【ＳＥ】ガラスが降り注ぐ
[free time=1000]
With considerable force, the spear broke the skylight, and came back crashing down, falling with countless pieces of glass.
[cpg]

We quickly fled to the corner of the room and could only watch as the shimmering glass shards rained down on us.
[cpg]

[SE f="se067"]
;//【ＳＥ】槍が銅像に当たる　ガッ！




[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2ex.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光／床ガラスまみれ）******************************************************


[FG f="CHA05_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi487"]
[OnName num="Michi"]
“Aaaah!!”
[cpg cn=true]

A scream came out of Michi's mouth, and when she looked, she saw that the bronze bust's ears had been chipped off by the falling spear.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika515"]
[OnName num="Erika"]
“Eeeeek!!”
[cpg cn=true]

The glass was still falling, rattling and clattering.
[cpg]

She was the one who did this, but Erika was slumped over with her head in her hands.
[cpg]

[OnName num="Kenji"]
"What the hell have you done? You fucking idiot!"
[cpg cn=true]

;//[SE f="se000"]
;//【ＳＥ】ガラス、踏み締める

The glass stopped falling and I yelled at Erika from below.
[cpg]

[SE f="se118"]
;//【ＳＥ】北風

[WAIT time=2000]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna381"]
[OnName num="Yuna"]
"Ugh, u-ugh, the wind…!"
[cpg cn=true]

With the window broken, the outside air was relentlessly coming inside.
[cpg]

This was the moment when we realized we hit rock bottom, as the north wind rushed in with a whooshing sound.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko318"]
[OnName num="Syouko"]
“Oh, there’s no way to board that up…"
[cpg cn=true]

[WAIT time=100]
[VOICE f="Michi488"]
[OnName num="Michi"]
“This idiot…., how much more trouble can you cause! If you want to freeze to death, why don't you do it alone! You should just die alone!”
[cpg cn=true]

Michi furiously yelled at Erika.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA03_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika516"]
[OnName num="Erika"]
“Ugh…It’s cold! It’s so cold!”
[cpg cn=true]

But Erika just shivered.
[cpg]

Comparing it to the coldness of the north wind, I realized how good we had it until now.
[cpg]

But once I realized it, there was no going back.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_7" pos="3/3" time=800]

[WAIT time=100]
[VOICE f="Michi489"]
[OnName num="Michi"]
"There's nothing we can do about it… We'll just have to close the doors to all the rooms and avoid the wind as much as we can."
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna382"]
[OnName num="Yuna"]
“Ugh, I don’t want to die! I don’t want to die!”
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko319"]
[OnName num="Syouko"]
“I-I’ll go too!”
[cpg cn=true]

[move from="1/3" to="5/3" ease="easeInOutSine" time=1000]
[move from="3/3" to="6/3" ease="easeInOutSine" time=1000]


Yuna and Shoko quickly ran into the general collection room.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi490"]
[OnName num="Michi"]
“Clean up the glass.”
[cpg cn=true]

[move from="2/3" to="5/3" ease="easeInOutSine" time=3000]
[WAIT time=1000]
Michi walked over to Erika, grabbed her by the scarf and dragged her down to the landing.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika517"]
[OnName num="Erika"]
“No! It’s cold! I want to go with Yuna!”
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi491"]
[OnName num="Michi"]
“Shut up!”
[cpg cn=true]

[SE f="se047"]
;//【ＳＥ】ガシャッ！

[OnName num="Kenji"]
“Ah…”
[cpg cn=true]

Michi roughly pulled Erika down onto the glass.
[cpg]

I thought it was a bit much, but considering the gravity of what she had done, I couldn't say anything.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi492"]
[OnName num="Michi"]
“Pick it all up. Don't leave a single piece."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika518"]
[OnName num="Erika"]
“Ugh…, the glass is scary.”
[cpg cn=true]

I felt a little sorry for her, but if I indulged her now, she would surely take advantage of me again later.
[cpg]

So I didn't say another word to Erika, and headed upstairs to Shiori's room.
[cpg]

I was worried that she would not come out of her room after all the commotion.
[cpg]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BGM f="dod"]

[BG f="b_l_1f_entrance_p2ex.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光／床ガラスまみれ）******************************************************
;//まだガラス掃除中
;//[BG f="b_l_2f_lpass_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・左側廊下　昼（天窓からの光）******************************************************

[SE f="se072"]
;//【ＳＥ】ノック
[OnName num="Kenji"]
“Shiori? Are you awake?”
[cpg cn=true]

;//以下、栞はコトハ
;//↓　名前は栞だけど本当はコトハ、という展開です。

;//コトハ

[VOICE f="Shiori537"]
[OnName num="Shiori"]
“Kenji…? Come in.”
[cpg cn=true]

[SE f="se136"]
;//【ＳＥ】ドア開ける

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BGM f="d1"]
[BG f="b_l_2f_ros_0.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=800]

When I entered the room, Shiori was sitting on the bed reading a book.
[cpg]

It must have been that book that she was always carrying around.
[cpg]

[OnName num="Kenji"]
“Didn't you hear what was going on?"
[cpg cn=true]

I asked, wondering why she hadn't come out if she had been awake.
[cpg]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori538"]
[OnName num="Shiori"]
“I thought it was another fight… Then I heard a very loud noise, and I thought about going …but, I was still scared."
[cpg cn=true]

[OnName num="Kenji"]
“Yeah, it must have been scary.”
[cpg cn=true]

If Shiori saw such a scene, she would probably have gotten sick again.
[cpg]

Besides, the bronze bust of her grandfather was broken, and it was better to keep that to myself.
[cpg]

So I decided to just tell her about the skylight.
[cpg]

[OnName num="Kenji"]
"You know…, actually…, the skylight broke."
[cpg cn=true]

;//コトハ
[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori539"]
[OnName num="Shiori"]
“What..., that window…?”
[cpg cn=true]

Shiori rolled her eyes in surprise.
[cpg]

She probably wondered how the skylight could have been broken.
[cpg]

[OnName num="Kenji"]
"Sorry… Erika threw a spear..."
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori540"]
[OnName num="Shiori"]
"Really…? But why would you apologize for what she did, Kenji?"
[cpg cn=true]

[OnName num="Kenji"]
“Uh…”
[cpg cn=true]

Even I thought it was strange.
[cpg]

But when I thought about it, I was the one who brought Erika here, and since we're classmates, I feel like I was partially responsible.
[cpg]

;//コトハ
[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori541"]
[OnName num="Shiori"]
“It's not Kenji's fault… Don't apologize…”
[cpg cn=true]

[OnName num="Kenji"]
“Yeah… Thanks…”
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori542"]
[OnName num="Shiori"]
“More importantly, …here.”
[cpg cn=true]

[SE f="se063"]
;//【ＳＥ】ガサゴソ
[OnName num="Kenji"]
“Oh, what?”
[cpg cn=true]

I couldn't hide my surprise at what she put in my hand.
[cpg]

[OnName num="Kenji"]
"Th-this is…?"
[cpg cn=true]

The food supply should have run out by now.
[cpg]

A can of spam was in my hand.
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori543"]
[OnName num="Shiori"]
"Please eat. In return, don't tell anyone…”
[cpg cn=true]

[OnName num="Kenji"]
"Where in the world did you get this…?"
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori544"]
[OnName num="Shiori"]
"I saved some leftovers from dinner…It's for you, Kenji."
[cpg cn=true]

[OnName num="Kenji"]
“I appreciate that, but…”
[cpg cn=true]

I wanted to eat so much that I was drooling.
[cpg]

But, the others were probably just as hungry as I was.
[cpg]

So I thought it would be a bad idea for me to eat this alone.
[cpg]

[OnName num="Kenji"]
“I can't be the only one. It's unfair to everyone.”
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori545"]
[OnName num="Shiori"]
“Kenji, you're bigger than the rest of us, and you need more calories, right? Besides… I would be sad to see you lose weight..."
[cpg cn=true]

Shiori put her finger on the pull tab of the spam can as she spoke.
[cpg]

[SE f="se031"]
;//【ＳＥ】缶開ける

[WAIT time=1000]

[OnName num="Kenji"]
“Fwuah~”
[cpg cn=true]

As soon as the lid of the can was opened, the smell of food entered my nose.
[cpg]

By the time it reached my brain, I was already...
[cpg]

[OnName num="Kenji"]
"Munch! Gobble gobble! It's so good!"
[cpg cn=true]

I gobbled up the spam like a dog.
[cpg]

;//エフェクト
[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=2100]

[BG f="b_l_2f_ros_0.ui" time=100]

[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=100]

[WAIT time=1000]

[transition target={false} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=3100]

[window target=true]


[OnName num="Kenji"]
"Phew~"
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori546"]
[OnName num="Shiori"]
“Was it good…?”
[cpg cn=true]

[OnName num="Kenji"]
“Yeah, thanks. That helped a lot.”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

The canned food was small, but it was enough to satisfy my appetite.
[cpg]

However, despite appeasing my appetite and my stomach, I felt guilty as soon as I finished eating.
[cpg]

I was trying to think of everyone else, but I ended up eating it all by myself.
[cpg]

I wondered what kind of face I should make when I went downstairs.
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori547"]
[OnName num="Shiori"]
“Hehe…”
[cpg cn=true]

Shiori chuckled at my satisfaction and guilt, and started reading her book again.
[cpg]

[OnName num="Kenji"]
"Volume 4? Or is that a new volume?"
[cpg cn=true]

I couldn't see the cover because of the book cover, but naturally I peeked in thinking it was "The World of Fantasia"...
[cpg]

[OnName num="Kenji"]
“Ugh…, what’s this..?”
[cpg cn=true]

The page Shiori opened showed a picture of a human body cut lengthwise.
[cpg]

And even a partial close-up of the explanatory diagram.
[cpg]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori548"]
[OnName num="Shiori"]
"This one is one of my favorites right now… Because the human body is so fascinating…”
[cpg cn=true]

[OnName num="Kenji"]
“R-really…?”
[cpg cn=true]

But I'm pretty sure that until yesterday, there was Volume 4 of "The World of Fantasia" in that book cover.
[cpg]

The one…with brown stained pages.
[cpg]

Does Shiori change the book inside everyday…?
[cpg]

Then I suddenly remembered what I had seen in the study, and I scurried around the room.
[cpg]

The floor plan I saw.
[cpg]

Shiori's room, which should be the same size as the study.
[cpg]

[OnName num="Kenji"]
“How strange…”
[cpg cn=true]

I knew it felt much smaller than the study.
[cpg]

No, it definitely felt narrower.
[cpg]

[OnName num="Kenji"]
"Does this room have like three layers of bookshelves?"
[cpg cn=true]

;//コトハ
[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori549"]
[OnName num="Shiori"]
What? No way… So why…?
[cpg cn=true]

[OnName num="Kenji"]
"Not at all."
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori550"]
[OnName num="Shiori"]
".................."
[cpg cn=true]

At my question, Shiori stared at me with a curious look on her face.
[cpg]

I began to feel as if my questions were somehow no good.
[cpg]

[OnName num="Kenji"]
"Really, I was just thinking. It's cold near the entrance, so you shouldn't come out too often. I'll be going then."
[cpg cn=true]

As cold as it was, I knew Shiori shouldn’t go out until the bronze bust was fixed.
[cpg]

I left Shiori's room as if to run away, and went back to the landing to check on Erika and Michi.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BGM f="d1"]
;//[BG f="b_l_1f_entrance_p2.ui" time=1000]
[BG f="b_l_1f_entrance_p2ex.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

;//[SE f="se000"]
;//【ＳＥ】ガシャガシャ

[WAIT time=1000]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi493"]
[OnName num="Michi"]
“Geez…”
[cpg cn=true]

In the end, Michi was collecting the glass pieces with a broom and dustpan.
[cpg]

[OnName num="Kenji"]
"I’ll help you. Actually, where’s Erika?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi494"]
[OnName num="Michi"]
“I let her go because she was useless, just crying.”
[cpg cn=true]

Michi's vein was popping out of her forehead.
[cpg]

[OnName num="Kenji"]
“Did you find any glue or anything?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi495"]
[OnName num="Michi"]
“I did, but…”
[cpg cn=true]

But when I looked at the statue and thought about it, what it was…, I saw that the ears were still attached, but the areas where the copper had been scraped off had turned white, and it was easy to tell that it was broken.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi496"]
[OnName num="Michi"]
"We have to make sure Shiori doesn't see…"
[cpg cn=true]

[OnName num="Kenji"]
“Yes, you’re right.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi497"]
[OnName num="Michi"]
“Ms. Endo is making tea in the room over there, why don't you go have some?”
[cpg cn=true]

[OnName num="Kenji"]
“But…”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi498"]
[OnName num="Michi"]
“I’m almost finished, and I’ll join you soon…”
[cpg cn=true]

[OnName num="Kenji"]
“Okay.”
[cpg cn=true]

At Michi's urging, I decided to visit the general collection room.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BGM f="d1"]
[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）******************************************************

[SE f="se136"]
;//【ＳＥ】ドア開ける

[WAIT time=1000]

[FG f="CHA03_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_1" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Syouko320"]
[OnName num="Syouko"]
"Ah, Kenji. Please, have some tea. Black tea, coffee, green tea, brown rice tea. Which would you like?"
[cpg cn=true]

To be honest, I was getting tired of tea, but in this cold weather, there was no choice but to warm up from the inside out.
[cpg]

[OnName num="Kenji"]
“Well, I'd like some black tea, please."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko321"]
[OnName num="Syouko"]
“Roger that!”
[cpg cn=true]

[STOPBGM]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika519"]
[OnName num="Erika"]
“What’s…that?”
[cpg cn=true]

Erika, who had shrunk back under the blanket, stared at me.
[cpg]



[OnName num="Kenji"]
“What do you mean?”
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika520"]
[OnName num="Erika"]
"What’s that on your mouth?"
[cpg cn=true]

[SE f="se049"]
;//【ＳＥ】ガバッ！

[FG f="CHA03_p5_01_a.ui" method="change_3" pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="3/3" time=1]
[FG f="CHA06_p3_01_a.ui" method="change_2" pos="2/3" time=1]

[OnName num="Kenji"]
“?!”
[cpg cn=true]

[BGM f="huan"]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika521"]
[OnName num="Erika"]
"Sniff, sniff, sniff… I smell food!"
[cpg cn=true]

[FG f="CHA04_p5_01_a.ui" method="change_5" pos="3/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_2" pos="2/3" time=1]

[WAIT time=100]
[VOICE f="Yuna383"]
[OnName num="Yuna"]
"What? Sniff, sniff, sniff… Really?"
[cpg cn=true]

I was suddenly shoved and fell to the floor, Erika and Yuna rubbing their noses against me.
[cpg]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna384"]
[OnName num="Yuna"]
“You ate something! Kenji, did you secretly eat something by yourself!"
[cpg cn=true]


[FACE method="change_3" pos="1/3"]
[VOICE f="Erika522"]
[OnName num="Erika"]
"Unbelievable! You traitor!"
[cpg cn=true]

[OnName num="Kenji"]
“S-stop! I didn’t eat anything!”
[cpg cn=true]

They both leaned over me and licked my mouth as they held my head down.
[cpg]

[FACE method="change_2" pos="3/3"]
[VOICE f="Yuna385"]
[OnName num="Yuna"]
"Mmmmmm, smells good!"
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[VOICE f="Erika523"]
[OnName num="Erika"]
"Ah! It tastes like something! It tastes so good!"
[cpg cn=true]

[OnName num="Kenji"]
“Woah?!”
[cpg cn=true]

The two tongues swirled around my mouth in a creepy manner.
[cpg]

Besides, I can't help it that I haven't brushed my teeth for a long time, but my breath smells terrible.
[cpg]

[OnName num="Kenji"]
“I told you to stop!”
[cpg cn=true]

[SE f="se045"]
;//【ＳＥ】ドンッ！


[free time=500]
[WAIT time=1000]
;//[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="1/3" time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="3/3" time=1000]
[FG f="CHA06_p3_01_a.ui" method="change_5" pos="2/3" time=1000]
[WAIT time=100]
[VOICE f="Erika524"]
[OnName num="Erika"]
"What the hell? What are you doing? You’re the one who just ate by yourself!"
[cpg cn=true]

[VOICE f="Yuna386"]
[OnName num="Yuna"]
"There's more! I know there's more food around here somewhere!"
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】ダッシュ

[move from="1/3" to="5/3" ease="easeInOutSine" time=1500]
[move from="3/3" to="6/3" ease="easeInOutSine" time=1500]


Erika and Yuna rushed out of the room as if they were competing with each other.
[cpg]

They must have gone to look for food.
[cpg]

There is no such thing anywhere…
[cpg]

Besides Shiori’s room.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko322"]
[OnName num="Syouko"]
"Huh. I guess it’s good that they’re feeling energetic."
[cpg cn=true]

[OnName num="Kenji"]
“I guess so…”
[cpg cn=true]

Sighing, I couldn't fully agree with Shoko's words.
[cpg]

If it’s like that, it’s better if they were weak and groggy.
[cpg]

[FG f="CHA06_p5_01_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko323"]
[OnName num="Syouko"]
“Kenji, now that everyone's gone…”
[cpg cn=true]

[OnName num="Kenji"]
“Huh…?”
[cpg cn=true]

I suddenly got nervous as Shoko closed the gap between us.
[cpg]

Shoko couldn’t possibly be interested in me….
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko324"]
[OnName num="Syouko"]
"There's some extra hot water, I'll wipe your back!"
[cpg cn=true]

[OnName num="Kenji"]
“W-what?”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko325"]
[OnName num="Syouko"]
“?”
[cpg cn=true]

Shoko had a hand towel in her hand.
[cpg]

I hadn't taken a bath yet, so she offered to wipe me down.
[cpg]

[OnName num="Kenji"]
“Sorry. But, I can do it myself.”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko326"]
[OnName num="Syouko"]
"It’s impossible to reach your back by yourself, right? Let me do it."
[cpg cn=true]

[OnName num="Kenji"]
"Uh, well, then…"
[cpg cn=true]

I took Shoko's word for it and took off my shirt.
[cpg]

[OnName num="Kenji"]
“It’s cold!”
[cpg cn=true]

The cold reminded me how important clothes were.
[cpg]

The chill that sliced through the air, was a reminder of the gravity of Erika's crime.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko327"]
[OnName num="Syouko"]
“Ye~s.”
[cpg cn=true]

[OnName num="Kenji"]
"Oh, it's warm."
[cpg cn=true]

The places where the towel soaked in hot water touched my skin, were the only places I felt relieved and at ease.
[cpg]

It quickly cooled down and became cold, but it still felt good to get rid of the grime and sweat.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko328"]
[OnName num="Syouko"]
“But Kenji, you know, you have a really good body.”
[cpg cn=true]

Being praised like that reminded me of Shiori.
[cpg]

Shiori also complimented me on my body…
[cpg]

When I thought about it, something I had forgotten came to my mind.
[cpg]

I wanted to talk about…
[cpg]

;//■選択肢１４（２択）
[switch]
[case "Shiori’s Medicine"]
	[swap]
	[jump target="*s14_a"]
[case "Her grandfather's diary"]
	[swap]
	[jump target="*s14_b"]
[endswitch]
;//１，栞の薬のこと　　　//１４aへ
;//２，祖父の日記のこと　//１４bへ
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１４a　栞の薬のこと
*s14_a|Twins
It was about Shiori's medicine.
[cpg]

[OnName num="Kenji"]
“Shoko, do you know anything about Shiori's medicine?"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko329"]
[OnName num="Syouko"]
"Well, what is it?"
[cpg cn=true]

[OnName num="Kenji"]
"For example, that…”
[cpg cn=true]

I tried to say the name of the drug to ask Shoko, but what was that again?
[cpg]

;//■選択肢１５（３択）
[switch]
[case "Citalopram"]
	[swap]
	[jump target="*s15_a"]
[case "Chitaropran"]
	[swap]
	[jump target="*s15_b"]
[case "Titaloplam"]
	[swap]
	[jump target="*s15_c"]
[endswitch]
;//１，Citalopram　　//１５aへ
;//２，Chitaropran　 //１５bへ
;//３，Titaloplam　　//１５cへ
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１５a　Citalopram
*s15_a|Twins

;//＠
;//※＜病気フラグ＞確立
[stflag Psychosis=1]


[OnName num="Kenji"]
“Citalo…pram!”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko330"]
[OnName num="Syouko"]
“Huh…? Umm? I'm pretty sure she wasn’t prescribed any medication by that name."
[cpg cn=true]

[OnName num="Kenji"]
“What? That can’t be…”
[cpg cn=true]

Maybe I made a mistake, but the conversation with Shoko didn't go any further from there.
[cpg]

So…
[cpg]

[OnName num="Kenji"]
"Thank you very much. I'm going to go to the room across the way.”
[cpg cn=true]

With that, I put on my shirt and hurried to the special reference book room.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BGM f="d1"]
[BG f="b_l_1f_tbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・専門書の部屋　昼（エントランスからの光）******************************************************

[OnName num="Kenji"]
"Where's it? Where’s it…? A medicine book…"
[cpg cn=true]

I searched for a while for a book with a list of drug names, but I couldn't find one.
[cpg]

[OnName num="Kenji"]
“I wonder if there isn’t one…”
[cpg cn=true]

I couldn't figure out why I was so caught up in that drug.
[cpg]

But I was also hoping that it would clear up the slight uneasiness I was feeling around Shiori.
[cpg]

[OnName num="Kenji"]
“Yeah, there isn’t one…”
[cpg cn=true]

;//[SE f="se045"]
;//【ＳＥ】ドカッ

I threw myself down in my chair and let myself feel weak, and my eyes caught a book in the spur of the moment.
[cpg]

[OnName num="Kenji"]
“Huh…?”
[cpg cn=true]

It was one of several books left on the desk.
[cpg]

It was the book Hosokawa had been reading.
[cpg]

I thought I'd just check the index for now, and there it was...
[cpg]

[OnName num="Kenji"]
“Here it is…! Citalopram? I must have read it wrong."
[cpg cn=true]

It was no wonder Shoko didn't understand.
[cpg]

[SE f="se016"]
;//【ＳＥ】激しくページ捲る

When I found what I was looking for, I turned the pages and followed the fine print with my eyes.
[cpg]

[OnName num="Kenji"]
“What…what..?”
[cpg cn=true]

Citalopram: An antidepressant that affects neurotransmitters involved in brain function, also used to treat anxiety disorders, panic attacks, and PTSD.
[cpg]

[OnName num="Kenji"]
“A psy-psychiatric drug…?”
[cpg cn=true]

Side effects include loss of appetite, nausea, dry mouth, sweating, headache, dizziness, insomnia, etc. Caution should be taken when giving it to patients with liver disease, kidney disease, diabetes, and heart disease.
[cpg]

[OnName num="Kenji"]
“Th-this is…”
[cpg cn=true]

There were many other details, but that was all I could read, and the rest was too technical for me to understand.
[cpg]

The only thing that was etched in my mind was that Shiori was taking psychotropic drugs…
[cpg]

Did this mean that Shiori had some kind of mental illness?
[cpg]

But yet, Michi went to the trouble of ordering and used a drug that seemed dangerous and full of side effects?
[cpg]

Why on earth would she…?
[cpg]

My suspicion that Shiori had some sort of mental abnormality, and my suspicion of Michi came flooding back.
[cpg]

She wasn't just physically weak…
[cpg]

When I thought about it, I couldn't help but think that there are many strange things about Shiori's behavior, and I couldn't help but feel that my previous feelings were starting to waver beneath my feet.
[cpg]

[OnName num="Kenji"]
“What should I do…”
[cpg cn=true]

Then I suddenly remembered Shiori's grandfather's diary.
[cpg]

Thinking that her grandfather might have written something down about this, I went to get the diary that I had hidden in the general collection room on a bookshelf, and opened it by the entrance so that Shoko wouldn't get suspicious.
[cpg]


;//１４e　　へ合流
[jump target="*s14_e"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１５b　Chitaropran
*s15_b|Twins
[OnName num="Kenji"]
"Chi... something...pran!"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko331"]
[OnName num="Syouko"]
“Huh…? Chi…something? I don't think any medication that starts with 'Chi' was written on her prescription…"
[cpg cn=true]

[OnName num="Kenji"]
“What? It can't be…"
[cpg cn=true]

Maybe I made a mistake, but the conversation with Shoko didn't go any further from there.
[cpg]

[OnName num="Kenji"]
“Thanks… Forget it.”
[cpg cn=true]

I was just about to put on my shirt and leave the room when I remembered that I hid my diary in the bookshelf here.
[cpg]

[OnName num="Kenji"]
“Excuse me…”
[cpg cn=true]

I walked past Shoko, retrieved the diary, and walked out to the entrance, concealing it so it wouldn't be seen.
[cpg]


;//１４e　　へ合流
[jump target="*s14_e"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１５c　Titaloplam
*s15_c|Twins
[OnName num="Kenji"]
"Titalo...pran!"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko332"]
[OnName num="Syouko"]
"Titalo…? I'm sure she wasn’t prescribed something like that…"
[cpg cn=true]

[OnName num="Kenji"]
“What? That can’t be…”
[cpg cn=true]

Maybe I made a mistake, but the conversation with Shoko didn't go any further from there.
[cpg]

[OnName num="Kenji"]
“Thanks… Forget it.”
[cpg cn=true]

I was just about to put on my shirt and leave the room when I remembered that I hid my diary in the bookshelf here.
[cpg]

[OnName num="Kenji"]
“Excuse me…”
[cpg cn=true]

I walked past Shoko, retrieved the diary, and walked out to the entrance, holding it so it wouldn't be seen.
[cpg]


;//１４e　　へ合流
[jump target="*s14_e"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１４b　祖父の日記のこと
*s14_b|Twins

There was Shiori's grandfather's diary.
[cpg]

I hid it in the bookshelf here and forgot about it, but I needed to get it back and return it to its original place.
[cpg]

[OnName num="Kenji"]
“Thanks… Forget it.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko333"]
[OnName num="Syouko"]
"Oh? Is that so? Please come again ♪"
[cpg cn=true]

That genius, Shoko, didn’t suspect me of taking out the diary.
[cpg]

I immediately went out to the entrance and thought about going to the study, but...
[cpg]

[OnName num="Kenji"]
"I can just read it a little…"
[cpg cn=true]

That’s what I told myself as I sat down on the stairs and opened the diary.
[cpg]


;//１４e　　へ合流
[jump target="*s14_e"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１４e

*s14_e|Twins

[SE f="se026"]
;//【ＳＥ】ページ捲る


;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]


;//以下、日記の文章、全画面スクロール表示でも可
XX Month XX Day
[cpg]

I decided to build a library.
[cpg]

I can't wait to see her happy face.
[cpg]

XX Month XX Day
[cpg]

A seizure. Kisaragi said that she could only do the transplant if she waited until she was old enough to be physically strong.
[cpg]

I sincerely hope that her life will not end before then.
[cpg]

Asthma is another concern.
[cpg]

XX Month XX Day
[cpg]

I haven't been feeling well lately either.
[cpg]

The worried look on her face was hard to take.
[cpg]

I don't want to see the worried faces of those kids.
[cpg]

XX Month XX Day
[cpg]

To deteriorate is a terrible thing.
[cpg]

I can no longer pick up my grandchildren with my own strength.
[cpg]

When I look at my hands, they are wrinkled and I feel anxious that I am withering away.
[cpg]

XX Month XX Day
[cpg]

Kisaragi is doing her best, but I'm not going to make it.
[cpg]

I don't have the strength.
[cpg]

It's hard to see them look at me.
[cpg]

XX Month XX Day
[cpg]

What kind of death will I face?
[cpg]

I can't give my precious grandchild back to that son and his wife.
[cpg]

I'll also ask my lawyer to make Kisaragi her guardian.
[cpg]

I'll have to tell them soon.
[cpg]

That's where the entries ended…
[cpg]

This diary is probably from after her grandfather realized he was dying.
[cpg]

But there were a few parts that bothered me.
[cpg]

“I can't even pick up my grandchildren."
[cpg cn=true]

Shiori was his grandchild, but what did he mean by “grandchildren”?
[cpg]

It couldn’t be…Michi?
[cpg]

It seemed unlikely that Michi would be in that kind of relationship with Shiori's grandfather.
[cpg]

"It's hard to see them look at me."
[cpg cn=true]

Could those two people be Shiori and Michi ?
[cpg]

But while Michi is mentioned in the diary as "Kisaragi", Shiori 's name was never mentioned.
[cpg]

Although it says "precious grandchild", it sounds unnatural somehow.
[cpg]

However, I was surprised to find out that Shiori was so sick that she needed a transplant.
[cpg]

As far as I can tell from her usual behavior, that hasn't been done yet.
[cpg]

I was also worried that she might not be strong enough to endure the surgery yet.
[cpg]

Should I ask Michi about what's written in this diary...?
[cpg]

However, if she learns that I had taken it out without permission, I might not get any answers.
[cpg]

[STOPBGM]

As I was trying to think of what to do, I heard a small scream behind me.
[cpg]


[WAIT time=1500]
[BG f="b_l_1f_entrance_p2up.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）（踊り場）******************************************************


;//以下、栞はコトハ
;//↓　名前は栞だけど本当はコトハ、という展開です。

[BGM f="danger"]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori551"]
[OnName num="Shiori"]
"Eeeeek! G-grandfather's...., Grandfather's ears!"
[cpg cn=true]

I turned around and sure enough, there was Shiori, twitching at the sight of the bust.
[cpg]

[OnName num="Kenji"]
"Oh, Shiori , well.."
[cpg cn=true]

;//コトハ
[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori552"]
[OnName num="Shiori"]
"Who did this?!"
[cpg cn=true]

I tried to calm her down, but she didn't hear me, and Shiori's eyes widened as she shouted.
[cpg]

As luck would have it, then Erika showed up, coming back from the basement.
[cpg]

[free time=1]
[WAIT time=1]
[BG f="b_l_1f_entrance_p2.ui" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika525"]
[OnName num="Erika"]
"Ugh, there's nothing around here...!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[VOICE f="Yuna387"]
[OnName num="Yuna"]
"I'm going to have to ask Kenji..."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[BG f="b_l_1f_entrance_p2up.ui" time=1]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/3" time=1]
[WAIT time=100]
[VOICE f="Shiori553"]
[OnName num="Shiori"]
"It was you, wasn't it?"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[BG f="b_l_1f_entrance_p2.ui" time=1]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=1]
[WAIT time=100]
[VOICE f="Erika526"]
[OnName num="Erika"]
"What?"
[cpg cn=true]

Shiori looked down at Erika from the landing and asked.
[cpg]

[free time=1]
[WAIT time=1]
[BG f="b_l_1f_entrance_p2up.ui" time=1]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/3" time=1]
[WAIT time=100]
[VOICE f="Shiori554"]
[OnName num="Shiori"]
"You're the one who did this to my grandfather!"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[BG f="b_l_1f_entrance_p2.ui" time=1]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=1]
[WAIT time=100]
[VOICE f="Erika527"]
[OnName num="Erika"]
"And what if I did...? Yeah, yeah, I'm sorry."
[cpg cn=true]

From my point of view, that was no way to apologize.
[cpg]

On top of that, Shiori , who loves her grandfather dearly and treats the statue like a living thing, could not tolerate Erika's ridiculous attitude.
[cpg]

[free time=1]
[WAIT time=1]
[BG f="b_l_1f_entrance_p2up.ui" time=1]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/3" time=1]
[WAIT time=100]
[VOICE f="Shiori555"]
[OnName num="Shiori"]
"I'm going to kill you!!"
[cpg cn=true]

[SE f="se115"]
;//【ＳＥ】ドタンバタン

[free time=500]


For a moment, it looked as if Shiori had jumped from the landing straight to Erika.
[cpg]

That's how quick it happened.
[cpg]

[BG f="b_l_1f_entrance_p2.ui" time=800]


[FG f="CHA02_p3_01_a.ui" method="change_3" pos="3/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Erika528"]
[OnName num="Erika"]
"Stop! Ow!"
[cpg cn=true]

;//コトハ
[FACE method="change_3" pos="3/5"]
[WAIT time=100]
[VOICE f="Shiori556"]
[OnName num="Shiori"]
"Unforgivable! I'll never forgive you! Arggggghh!"
[cpg cn=true]

While making strange noises, Shiori grabbed Erika by the hair and scratched her.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi499"]
[OnName num="Michi"]
"What are you doing?!"
[cpg cn=true]

[VOICE f="Syouko334"]
[OnName num="Syouko"]
"Shiori!"
[cpg cn=true]

When I came to my senses at the sound of Michi's and Shoko's voices, it had already turned into a brawl.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_3" pos="3/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_4" pos="2/5" time=800]

;//コトハ
[WAIT time=100]
[VOICE f="Shiori557"]
[OnName num="Shiori"]
"Waaaaaahhh!!"
[cpg cn=true]

[VOICE f="Erika529"]
[OnName num="Erika"]
"Kyaaaaaaaa!"
[cpg cn=true]

[SE f="se097"]
;//【ＳＥ】数回殴る

A sickening bang, bang, bang could be heard and Erika's face contorted.
[cpg]

[OnName num="Kenji"]
"Shiori , calm down!"
[cpg cn=true]

[move from="2/5" to="1/4" ease="easeInOutSine" time=1000]
[move from="3/5" to="4/4" ease="easeInOutSine" time=1000]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="2/4" time=800]
[WAIT time=100]
[VOICE f="Yuna388"]
[OnName num="Yuna"]
"Let go!"
[cpg cn=true]

Even though there was four of us, Shiori was so strong that it took all of us to pull her off.
[cpg]

;//コトハ
[FACE method="change_3" pos="4/4"]
[WAIT time=100]
[VOICE f="Shiori558"]
[OnName num="Shiori"]
"I'll kill you! I'm going to kill this bitch!"
[cpg cn=true]

;//[SE f="se000"]
;//【ＳＥ】ジタバタ

[FG f="CHA05_p3_01_a.ui" method="change_5" pos="3/4" time=800]
[WAIT time=100]
[VOICE f="Michi500"]
[OnName num="Michi"]
"Shi, Shiori , no! Calm down, relax... Breathe slowly. Calm down..."
[cpg cn=true]

;//コトハ
[VOICE f="Shiori559"]
[OnName num="Shiori"]
"Pant! Pant!"
[cpg cn=true]

[OnName num="Kenji"]
"Look at this..."
[cpg cn=true]

Was it really Shiori that just went on a rampage in front of my eyes?
[cpg]

I couldn't believe that a girl so weak that she can't even endure surgery had the power to beat up Erika.
[cpg]



;//[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************
;//[free time=1000]
;//[WAIT time=1000]
[FACE method="change_4" pos="2/4"]
[WAIT time=100]
[VOICE f="Yuna389"]
[OnName num="Yuna"]
"She looked like...a wild animal..."
[cpg cn=true]

Yuna shivered beside me and muttered.
[cpg]

That's how violent Shiori was.
[cpg]

;//[free time=1]
;//[WAIT time=1]

;//コトハ
;//[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/3" time=800]
;//[FG f="CHA05_p3_01_a.ui" method="change_3" pos="1/3" time=800]
;//[FG f="CHA05_p3_01_a.ui" method="change_3" pos="3/3" time=800]

[WAIT time=100]
[VOICE f="Shiori560"]
[OnName num="Shiori"]
"Aaaaaaaahhhh!!"
[cpg cn=true]

[move from="4/4" to="5/3" ease="easeInOutSine" time=1000]


Like a big cat roaring, Shiori screamed again and ran upstairs, shaking off Michi's hand.
[cpg]

[SE f="se022"]
;//【ＳＥ】ダッシュ
[FACE method="change_5" pos="2/4"]
[FACE method="change_5" pos="3/4"]
[WAIT time=100]
[VOICE f="Michi501"]
[OnName num="Michi"]
"Ah! Shiori?!"
[cpg cn=true]

[OnName num="Kenji"]
"I'll go after her!"
[cpg cn=true]

[FACE method="change_5" pos="3/4"]
[WAIT time=100]
[VOICE f="Michi502"]
[OnName num="Michi"]
"Wait..."
[cpg cn=true]

[OnName num="Kenji"]
"Michi, you should help Erika!"
[cpg cn=true]

[FACE method="change_3" pos="3/4"]
[WAIT time=100]
[VOICE f="Michi503"]
[OnName num="Michi"]
"Ugh..."
[cpg cn=true]

Erika had been punched in the face and her nose was bleeding.
[cpg]

If the bone was broken, it would not be possible for me or the nurse to treat it.
[cpg]

Anyway, I followed Shiori into the room to try to calm her down.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_ros_0.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

[WAIT time=1500]


;//コトハ
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori561"]
[OnName num="Shiori"]
"Sob! Sob! She broke Grandfather's statue! She ripped off his ears!"
[cpg cn=true]

As soon as she entered her room, she plopped down on her bed and cried.
[cpg]

;//コトハ
[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori562"]
[OnName num="Shiori"]
"I knew this was going to happen! That's why I told you to hurry up!"
[cpg cn=true]

[OnName num="Kenji"]
"Hurry up with...what?"
[cpg cn=true]

;//コトハ
[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori563"]
[OnName num="Shiori"]
"?!!"
[cpg cn=true]

Shiori looked back in amazement, as if she hadn't noticed that I was following her.
[cpg]

;//コトハ
[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori564"]
[OnName num="Shiori"]
"Ken, Kenji..., What was I just...?"
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

Shiori looks at me, confused.
[cpg]

Perhaps she didn't remember what she did...
[cpg]

[OnName num="Kenji"]
"Are you okay...? How's your breathing after all that? How's your chest?"
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori565"]
[OnName num="Shiori"]
"Y-yeah... just a little lightheaded..."
[cpg cn=true]

Then Shiori laid down on the bed.
[cpg]

Something felt off, and I looked around to see what was wrong.
[cpg]

[OnName num="Kenji"]
"Huh...? Aren't there more now....?"
[cpg cn=true]

The number of plaster statues on the floor had clearly increased from before.
[cpg]

It's not the number of animals, but a pair of human arms and legs.
[cpg]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori566"]
[OnName num="Shiori"]
"They were in the storage room in the basement... I didn't want them to get destroyed, so I brought them here..."
[cpg cn=true]

It would be ironic if they were destroyed.
[cpg]

But when the hell did it happen?
[cpg]

;//コトハ
[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori567"]
[OnName num="Shiori"]
"Just go, Kenji... Leave me alone... Sob."
[cpg cn=true]

[OnName num="Kenji"]
"I'm s-sorry. I'll go if you're okay."
[cpg cn=true]

She pressed her face to the pillow and started sobbing.
[cpg]

What happened to the bust must have come as a shock, and she had no time to pay attention to me now.
[cpg]

[STOPBGM]

;//エフェクト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=2100]
[free time=100]
[BG f="b_l_1f_tbr_p4.ui" time=100]
;//【ＢＧ】図書館・１階・専門書の部屋　夜（暗）******************************************************
[WAIT time=1500]

[transition target={false} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=3100]

[window target=true]

[BGM f="silent"]


We were all exhausted from the series of events that day.
[cpg]

Erika was upset about the beating, but she didn't have much energy left to scream because of her hunger, so she went back to her room with Yuna's help.
[cpg]

Michi and Shoko, also exhausted, parted ways going to the second floor and basement respectively, and I returned here.
[cpg]

[SE f="se118"]
;//【ＳＥ】風の音
The wind, which used to be blowing outside, is now blowing around the entrance and it was freezing cold.
[cpg]

And yet, perhaps because of all the tea I'd drunk, I felt the need to urinate in the middle of the night.
[cpg]

[SE f="se009"]
;//【ＳＥ】静かにドア開ける

[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗／蝋燭）******************************************************

[WAIT time=1000]

;//以下、栞は栞（本物）
I put on my jacket and went out to the entrance with a flashlight in my hand, and I thought that I could go out like that.
[cpg]

That's how freezing the air was.
[cpg]

I couldn't express enough how bitter I was towards Erika after everything.
[cpg]

Her foolish actions could not be forgiven with just a punch and a bloody nose.
[cpg]

[OnName num="Kenji"]
".........?!"
[cpg cn=true]

The light of my flashlight moved randomly and widely.
[cpg]

Something that should not have been seen entered into the circle of light from my flashlight.
[cpg]

[OnName num="Kenji"]
"Shiori."
[cpg cn=true]


For a moment I thought it was a ghost, standing there wobbling.
[cpg]

Then, there it was in the corridor of the second floor.
[cpg]

.........
[cpg]

I shined my flashlight on her, but she didn't seem to notice and her eyes were empty.
[cpg]

[OnName num="Kenji"]
"What have you got there...?!"
[cpg cn=true]

The object in her hand, which I couldn't see clearly from here, glinted in the reflected light.
[cpg]

;//[SE f="se000"]
;//【ＳＥ】ギラーン
[OnName num="Kenji"]
"!!"
[cpg cn=true]

It was a large knife.
[cpg]

[OnName num="Kenji"]
"Why do you have that?!"
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】ダッシュ
I rushed upstairs and took the knife out of Shiori's hand.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori568"]
[OnName num="Shiori"]
"What...?"
[cpg cn=true]

[OnName num="Kenji"]
"What's wrong? What are you doing here at this hour?"
[cpg cn=true]

I had a vague idea of where Shiori was going when she left the room, judging by the way her body was turned.
[cpg]

But it was too frightening to admit it.
[cpg]

[OnName num="Kenji"]
"I was thinking of going to see Erika...?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori569"]
[OnName num="Shiori"]
"What..? Why...? It's cold..."
[cpg cn=true]

[OnName num="Kenji"]
"You should get back to your room."
[cpg cn=true]

I held Shiori's shoulders since she seemed to be in a daze and sent her off to her room, trying not to provoke her.
[cpg]

;//[STOPBGM]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]


[if exp={getFlagValue("Psychosis") > 0 }]
[jump target="*j14_a"]
[else]
[jump target="*j14_c"]
[endif]


;//※＜病気フラグ＞が立っている場合、以下の破線内の文章挿入
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～
*j14_a|Twins


[BG f="b_l_2f_lpass_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・左側廊下　夜（暗／懐中電灯）******************************************************

.........
[cpg]

I still think that Shiori has some kind of mental illness.
[cpg]

Or maybe this behavior was a side effect of that medication.
[cpg]

Either way, Shiori must have been trying to do something about Erika with the knife.
[cpg]

Even if it is unconscious or a side effect..., it was still a horrible thing.
[cpg]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

;//追加開始前にメッセージウィンドウを消してるので追加分岐の外で表示に切り替える
;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～
*j14_c|Twins


[BG f="b_l_2f_ros_0.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

[WAIT time=1500]

;//[BGM f="silent"]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]

[OnName num="Kenji"]
"Michi isn't here...?"
[cpg cn=true]

There was no sign of Michi, who was supposed to be sleeping in Shiori's room with her.
[cpg]

Where was she at a time like this?
[cpg]

[OnName num="Kenji"]
".................."
[cpg cn=true]

The knife I confiscated was heavy in my hand.
[cpg]

It would be terrible to get stabbed or cut with this thing.
[cpg]

Besides, I recognized the knife.
[cpg]

[OnName num="Kenji"]
"Wasn't this knife used to kill..."
[cpg cn=true]

The handle of the knife had been sticking out of the back of Takagi's corpse.
[cpg]

This looked like it was the same knife.
[cpg]

Even if they are different knvies, if they were from the same set, Shiori would be able to obtain it.
[cpg]

[OnName num="Kenji"]
"Shiori, are you okay...?"
[cpg cn=true]

I did not know what to do with this fact.
[cpg]

However, it didn't mean that Shiori was going to kill Erika, because I stopped her before anything happened.
[cpg]

It could just be that she was trying to scare her...
[cpg]

It was a vain hypothesis, but as long as it wasn't completely impossible, I wanted to be on Shiori's side.
[cpg]

[OnName num="Kenji"]
"I won't tell anyone..."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori570"]
[OnName num="Shiori"]
"Keni..., what time is it...?"
[cpg cn=true]

[OnName num="Kenji"]
"It's...already past midnight."
[cpg cn=true]

[FACE method="change_"5 pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori571"]
[OnName num="Shiori"]
"Oh, no."
[cpg cn=true]

[OnName num="Kenji"]
"What's wrong...?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori572"]
[OnName num="Shiori"]
"Merry Christmas..."
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

My watch was a hand-me-down from my dad, so it didn't say the date, just the time.
[cpg]

So I only knew the time, and I had given up trying to figure out what day it was...
[cpg]

Shiori smiled kindly and wished me a Merry Christmas.
[cpg]

[OnName num="Kenji"]
"Oh, y-yeah! Here!"
[cpg cn=true]

I hurriedly dug into my breast pocket and pulled out the present I had been keeping there this whole time.
[cpg]

[OnName num="Kenji"]
"Shiori..., Merry Christmas."
[cpg cn=true]

This was the Christmas that I was excitedly looking forward to.
[cpg]

I'm glad I was able to give her a gift even though we got caught up in this mess.
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori573"]
[OnName num="Shiori"]
"This is...for me?"
[cpg cn=true]

My cheeks flushed and Shiori muttered as she took the flimsy package I'd given her.
[cpg]

[OnName num="Kenji"]
"It's not that expensive, but..."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori574"]
[OnName num="Shiori"]
"Can I open it?"
[cpg cn=true]

[OnName num="Kenji"]
"Sure."
[cpg cn=true]

[SE f="se137"]
;//【ＳＥ】包み開ける

[WAIT time=2000]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori575"]
[OnName num="Shiori"]
"Wow... It's beautiful..."
[cpg cn=true]

It was a thin, silver bookmark with a very detailed engraving on it: Shiori.
[cpg]

The design was of a child playing in a snowy landscape with a snowman.
[cpg]

[OnName num="Kenji"]
"I'm sorry I'm still a student so I could only afford to buy something like this...."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori576"]
[OnName num="Shiori"]
"No, it's wonderful... I'll cherish it..."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah. Please use it when you're reading."
[cpg cn=true]

[SE f="se137"]
;//【ＳＥ】コトン
At that time, I heard a faint sound behind me and turned around.
[cpg]

[OnName num="Kenji"]
"......?"
[cpg cn=true]

But there was nothing there, just my face reflected in a mirror...
[cpg]

[OnName num="Kenji"]
"What...?"
[cpg cn=true]

The image reflected behind my face was the room, but there were books scattered on the floor.
[cpg]

It was something that you had to strain your eyes to see.
[cpg]

I couldn't believe my own eyes and rubbed them with my hands.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori577"]
[OnName num="Shiori"]
"What's wrong...?"
[cpg cn=true]

[OnName num="Kenji"]
"N-no, this mirror...!"
[cpg cn=true]

But when I looked into the mirror again, all I could see was the reflection of me with a dumbfounded look on my face.
[cpg]

[OnName num="Kenji"]
"W-why......?"
[cpg cn=true]

That's what I thought at that time.
[cpg]

I wasn't sure if I was hallucinating or if this was a sign that I was going crazy.
[cpg]

Wasn't this hunger and the feeling of being trapped that was just making me think I was going crazy...?
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori578"]
[OnName num="Shiori"]
"Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"!"
[cpg cn=true]

I was surprised to see Shiori standing behind me and turned around.
[cpg]

But Shiori was...
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori579"]
[OnName num="Shiori"]
"......?"
[cpg cn=true]

It was her usual gentle smile, and  the face was definitely the Shiori I knew and loved.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori580"]
[OnName num="Shiori"]
"I...couldn't go out and buy you a present, so..."
[cpg cn=true]

Shiori seemed to be concerned about being the only one to receive a gift.
[cpg]

[OnName num="Kenji"]
"It's fine. I don't need anything."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori581"]
[OnName num="Shiori"]
"But that's sad... Just a little..."
[cpg cn=true]

[OnName num="Kenji"]
"What...?"
[cpg cn=true]

When she said this, Shiori turned to me with her arms wide open.
[cpg]

She was giving me a hug.
[cpg]

It was so lovely to see shy Shiori doing that.
[cpg]

;#############################################################
;//Ev014
;#############################################################

;//＠

;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）

[OnName num="Kenji"]
"Shiori..."
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori582"]
[OnName num="Shiori"]
"Kenji..."
[cpg cn=true]

Squeeze...
[cpg]

Merry Christmas.
[cpg]

God, I got to hug Shiori on this holy night.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori583"]
[OnName num="Shiori"]
"Cough...cough..."
[cpg cn=true]

Concerned about Shiori's coughing and body getting cold, I put her down on the bed and pulled the covers over her.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori584"]
[OnName num="Shiori"]
"I'm sorry... I wanted to do more..."
[cpg cn=true]

[OnName num="Kenji"]
"It's okay."
[cpg cn=true]

Shiori was about to say something, but I kissed her on the mouth and took away her words.
[cpg]

My heart belonged to Shiori and Shiori was mine.
[cpg]

The heart is what matters.
[cpg]

I thought it was a tender feeling.
[cpg]

[OnName num="Kenji"]
"Good night..., Shiori."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori585"]
[OnName num="Shiori"]
"Good night..., Kenji."
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BGM f="d1"]
[BG f="b_l_2f_lpass_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・左側廊下　夜（暗／懐中電灯）

[OnName num="Kenji"]
".................."
[cpg cn=true]

I left Shiori's room in a happy mood, but when I was alone, I began to be tormented by anxiety.
[cpg]

The hallucination I saw in her room...?
[cpg]

My sanity was beginning to waver...
[cpg]

When I put my hand on my neck, I felt like the lines of my face were sharper than before.
[cpg]

[OnName num="Kenji"]
I was losing weight...
[cpg cn=true]

Knowing that, it was like the shadow of death was slowly creeping up on me.
[cpg]

I returned to my freezing room to sleep alone, feeling both the happiness of that holy night and the fear of the unknown at the same time.
[cpg]

[STOPBGM]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 25th
[cpg]

;//朗読している栞、P.U

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=1000]
[WAIT time=1000]
[VOICE f="Shiori809"]
[OnName num="Shiori"]
"Miss, wake up and bake me a pie, it's Christmas morning... Miss, the maid's not up yet, it's Christmas morning..."
[cpg cn=true]

[VOICE f="Shiori1809"]
[OnName num="Shiori"]
"Miss, are the ducks going to die? It's Christmas morning and your wings are clipped and you can't flap them. It's Christmas morning..."
[cpg cn=true]

;//＠
;//ロングエフェクト

[free time=3000]
[BG f="black.ui" time=3000]
[WAIT time=4000]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=1500]

[BGM f="serious"]

[FG f="CHA06_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko335"]
[OnName num="Syouko"]
"There was no water..."
[cpg cn=true]

[OnName num="Kenji"]
"What...?"
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Shiori586"]
[OnName num="Shiori"]
"The water is..."
[cpg cn=true]

It seemed that the water pipes had frozen over and no water came out even if the faucet was turned on.
[cpg]

This was a death sentence as our lifeline had been cut off.
[cpg]

If there was water, we could have survived for several weeks.
[cpg]

On the other hand, if there's, we will die.
[cpg]

It was Christmas, but Santa Claus had taken away our last hope.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika530"]
[OnName num="Erika"]
"W-what are we going to do...?"
[cpg cn=true]

Muttering, Erika was either shivering because she was frightened or cold.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko336"]
[OnName num="Syouko"]
"If the ice thaws, water might...come out eventually."
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika531"]
[OnName num="Erika"]
"What happens if it doesn't?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko337"]
[OnName num="Syouko"]
"If it doesn't come out for a long time... We will die of dehydration or freeze to death..."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi504"]
[OnName num="Michi"]
"You idiot!"
[cpg cn=true]


;//【ＢＧＭ】どんよりとした恐怖


Michi scolded Shoko for speaking carelessly, but it was already too late and the fear of death was hanging over us.
[cpg]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika532"]
[OnName num="Erika"]
"It's c-cold..."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna390"]
[OnName num="Yuna"]
"It sure is cold..."
[cpg cn=true]

Yuna rubbed up against Erika's shivering body.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko338"]
[OnName num="Syouko"]
"A ma-marathon! Let's run a marathon! We need to warm up!"
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika533"]
[OnName num="Erika"]
"I'll d-do it... I'll try anything!"
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】ドタバタ

[move from="1/3" to="4/3" ease="easeInOutSine" time=1000]
[move from="2/3" to="5/3" ease="easeInOutSine" time=1000]
[move from="3/3" to="6/3" ease="easeInOutSine" time=1000]


Shoko said this, and Erika and Yuna ran around the entrance with her.
[cpg]

But...
[cpg]

[move from="4/3" to="1/3" ease="easeInOutSine" time=1000]
[move from="5/3" to="2/3" ease="easeInOutSine" time=1000]
[move from="6/3" to="3/3" ease="easeInOutSine" time=1000]

[WAIT time=1500]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna391"]
[OnName num="Yuna"]
"Hah... hah..., I can't anymore..."
[cpg cn=true]

[free time=1000]

And soon all three of them collapsed.
[cpg]

It's no wonder since they haven't eaten anything.
[cpg]

Now I'm feeling guilty about the spam again.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori587"]
[OnName num="Shiori"]
"Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah..."
[cpg cn=true]

When I saw Shiori come by, I felt guilty that me and Shiori were both eating food without telling them, so I was a little curt.
[cpg]

I wondered if Shiori was okay with this?
[cpg]

Wasn't it painful for her to see others mentally and physically weakened?
[cpg]

When I thought about it, I was a little scared of Shiori.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna392"]
[OnName num="Yuna"]
"Oh, yeah..., the IV drip..."
[cpg cn=true]

Yuna's eyes were closed.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna393"]
[OnName num="Yuna"]
"The IV drip has nutrients... Let me drink it!"
[cpg cn=true]

Michi refused in disgust at Yuna's outrageous request.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi505"]
[OnName num="Michi"]
"What are you talking about? You can't do that."
[cpg cn=true]

But Yuna was serious, and Erika backed her up on it.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika534"]
[OnName num="Erika"]
"If it's okay to put it in your body, it must be okay to drink! Let's go, Yuna!"
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】ダッシュ

[move from="2/3" to="5/3" ease="easeInOutSine" time=1000]
[move from="3/3" to="6/3" ease="easeInOutSine" time=1000]


[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi506"]
[OnName num="Michi"]
"Please wait!"
[cpg cn=true]

[OnName num="Kenji"]
"Give me a break..."
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko339"]
[OnName num="Syouko"]
"We have to go after them!"
[cpg cn=true]

The three of us chased after them and followed them to the basement.
[cpg]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_ware_0.ui" time=1000]
;//【ＢＧ】図書館・地下・非常用倉庫　（暗）******************************************************

[WAIT time=1500]

[BGM f="huan"]


[FG f="CHA05_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi507"]
[OnName num="Michi"]
"Hey! What are you doing?"
[cpg cn=true]

[VOICE f="Erika535"]
[OnName num="Erika"]
"Get out of our way!"
[cpg cn=true]

[VOICE f="Yuna394"]
[OnName num="Yuna"]
"We just don't want to die!"
[cpg cn=true]

A little later, as we descended the stairs, we saw Erika and Yuna trying to push Michi into the pantry.
[cpg]

[OnName num="Kenji"]
"Stop!"
[cpg cn=true]

I tried to stop them, but they were only getting stronger.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika536"]
[OnName num="Erika"]
"Shut up! You're fine because you ate something, Kenji!"
[cpg cn=true]

[OnName num="Kenji"]
"......!"
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna395"]
[OnName num="Yuna"]
"Let's tie her up..."
[cpg cn=true]

[free time=1]
[WAIT time=1]

[FG f="CHA06_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko340"]
[OnName num="Syouko"]
"No! Don't do that!"
[cpg cn=true]

[VOICE f="Shiori588"]
[OnName num="Shiori"]
"Stop! Don't do anything to the doctor!"
[cpg cn=true]

[free time=1]
[WAIT time=1]

[FG f="CHA05_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna396"]
[OnName num="Yuna"]
"Shut up! Are you okay with us dying...? Do you want us to die?"
[cpg cn=true]

Yuna was worse than Erika.
[cpg]

They were unpredictable when cornered, and it gave off a dangerous vibe.
[cpg]

Michi sensed this, too, and shook her head at Shiori, who was then tied up by the two women.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika537"]
[OnName num="Erika"]
"The infirmary..."
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna397"]
[OnName num="Yuna"]
"The IV drip..."
[cpg cn=true]

[OnName num="Kenji"]
"You guys are crazy. Come to your senses!"
[cpg cn=true]

But my shouting just made them even more furious.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika538"]
[OnName num="Erika"]
"We're crazy?! It's Kenji that's crazy!"
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna398"]
[OnName num="Yuna"]
"I think we should tie up that traitor Kenji, too..."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika539"]
[OnName num="Erika"]
"Yeah... You're right."
[cpg cn=true]

[OnName num="Kenji"]
"What?! No!"
[cpg cn=true]

Erika and Yuna were closing in on me like zombies in a horror movie.
[cpg]

I was horrified by their angry, expressionless faces and pushed them away.
[cpg]

[SE f="se045"]
;//【ＳＥ】ドンッ！

[WAIT time=1000]

[SE f="se064"]
;//【ＳＥ】ガタンガタン！

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika540"]
[OnName num="Erika"]
"Agh!"
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna399"]
[OnName num="Yuna"]
"What's in this...box?"
[cpg cn=true]

When she stumbled over the cardboard box, Yuna discovered it and took the liberty of taking off the duct tape that sealed it.
[cpg]

[SE f="se139"]
;//【ＳＥ】ガムテ剥がす
[WAIT time=1000]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna400"]
[OnName num="Yuna"]
"Ah! Erika..."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika541"]
[OnName num="Erika"]
"Alcohol?"
[cpg cn=true]

In the cardboard box was a vintage brandy.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shiori589"]
[OnName num="Shiori"]
"Oh..., that's..."
[cpg cn=true]

Apparently, it had been Shiori's grandfather's favorite drink. There was no one around to drink it anymore, but they couldn't bear to throw it away, so they just kept it.
[cpg]

[VOICE f="Syouko341"]
[OnName num="Syouko"]
"Brandy is something you drink in the snowy mountains..."
[cpg cn=true]

My knowledge was somewhat vague, but I knew that it would warm everyone up.
[cpg]

But was it safe to drink alcohol when you're not used to it...?
[cpg]

Before I could say anything, Yuna took out a bottle and opened it.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_2" pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Yuna401"]
[OnName num="Yuna"]
"It smells good! Gulp, gulp!"
[cpg cn=true]

[OnName num="Kenji"]
"Uh, wait..., hey..."
[cpg cn=true]

The brandy was poured down Yuna's throat in a gulp.
[cpg]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna402"]
[OnName num="Yuna"]
"Ah~!"
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika542"]
[OnName num="Erika"]
"I-I want some too! Aah! Aaaack!!"
[cpg cn=true]

Of course, after taking a swig like that, they held their throats, stretched their tongues out of their mouths and started hee-hawing.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="1/4" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7" pos="3/3" time=800]

[WAIT time=100]
[VOICE f="Michi508"]
[OnName num="Michi"]
"Even if you get acute alcohol poisoning, I won't help you..."
[cpg cn=true]

The tied up Michi murmured quietly.
[cpg]

[VOICE f="Syouko342"]
[OnName num="Syouko"]
"Can I-I have some of that too...?
[cpg cn=true]

.........
[cpg]

Shoko, who never knew how to read the air, glanced over at Shiori's face and asked. Shiori looked heartbroken, but still gave a small nod.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko343"]
[OnName num="Syouko"]
"Yay! I've never had brandy before! Gulp, gulp!"
[cpg cn=true]

[OnName num="Kenji"]
"Whaaaaat? What are you doing?"
[cpg cn=true]

You're a grown up, but she was stupid enough to follow Erika's lead and chug it down!
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko344"]
[OnName num="Syouko"]
"Ah! Yummy!"
[cpg cn=true]

[FACE method="change_7" pos="1/4"]
[WAIT time=100]
[VOICE f="Michi509"]
[OnName num="Michi"]
"I can't believe you have a nursing license."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko345"]
[OnName num="Syouko"]
"I'sh fiiiine I'sh fiiiine... Hiccup. Ahahahaha!"
[cpg cn=true]

[OnName num="Kenji"]
"Uh..."
[cpg cn=true]

Shoko's face turned bright red.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA06_p3_01_a.ui" method="change_2" pos="1/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna403"]
[OnName num="Yuna"]
"You're joking! You've got to be kidding me...hey..."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika543"]
[OnName num="Erika"]
"Sob, sob... We're all going to die... Hiccup."
[cpg cn=true]

[OnName num="Kenji"]
"What...is happening?"
[cpg cn=true]

The three people who drank the brandy were each drunk in their own unique way.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi510"]
[OnName num="Michi"]
All that strong liquor in an empty stomach, it was only natural that they'd suddenly go crazy.
[cpg cn=true]

[FG f="CHA04_p5_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna404"]
[OnName num="Yuna"]
"You drink too, here!"
[cpg cn=true]

[OnName num="Kenji"]
"Aah!"
[cpg cn=true]

A liquor bottle was shoved into my mouth, and a lot of alcohol was poured down my throat.
[cpg]

[OnName num="Kenji"]
"Ugh, gah!"
[cpg cn=true]

My throat was burning and my esophagus was on fire.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi511"]
[OnName num="Michi"]
The act of forcing another person to consume alcohol is considered assault.
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_2" pos="2/4" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="1/3" time=1]
[WAIT time=100]
[VOICE f="Syouko346"]
[OnName num="Syouko"]
"Well, well! You can have a drink too, doctor!"
[cpg cn=true]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi512"]
[OnName num="Michi"]
"Gulp?!"
[cpg cn=true]

It was lawless area.
[cpg]

The pantry was filled with the smell of brandy, and Shiori's expression on her face grew gloomier and gloomier.
[cpg]

I felt sorry for Michi, who was captured, but we couldn't stay here.
[cpg]

[OnName num="Kenji"]
"No, let's get out of here... Hiccup."
[cpg cn=true]

.........
[cpg]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_ros_0.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

[WAIT time=1500]

[BGM f="dod"]


[OnName num="Kenji"]
"Ugh... Thooose guuyys..."
[cpg cn=true]

I was losing my voice, and what's more, my eyes were starting to spin in circles.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori590"]
[OnName num="Shiori"]
"Kenji..., are you drunk...?"
[cpg cn=true]

[OnName num="Kenji"]
"Aish am nooot drunk..."
[cpg cn=true]

My head was fuzzy and I felt dizzy, but I answered that reflexively.
[cpg]

"Are you angry?", the answer is always the same whenever someone asks that question.
[cpg]

[OnName num="Kenji"]
"Shi, Shiori... It looks like there's two of you..."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori591"]
[OnName num="Shiori"]
"What? There's only one of me."
[cpg cn=true]

[OnName num="Kenji"]
"No, there are two..., three, four... and so many Shioris..."
[cpg cn=true]

I could tell that I was not doing so good. Actually, I was getting drunk.
[cpg]

[OnName num="Kenji"]
"Wow, there are so many Shioris..."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori592"]
[OnName num="Shiori"]
"Kya..."
[cpg cn=true]

Before I knew it, I was hugging Shiori's body.
[cpg]

[OnName num="Kenji"]
"Ah~..., Shiori."
[cpg cn=true]

[SE f="se047"]
;//【ＳＥ】ドサッ

[WAIT time=1000]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori593"]
[OnName num="Shiori"]
"Kenji...?"
[cpg cn=true]

Immediately after, I collapsed on the bed and buried my face into Shiori's body.
[cpg]

[OnName num="Kenji"]
"I love you... I love you..."
[cpg cn=true]

As I said this, my consciousness faded away.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori594"]
[OnName num="Shiori"]
"Hehe..."
[cpg cn=true]

[STOPBGM]

;//画面黒か白一色に
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

;#############################################################
;//Ev015
;#############################################################
;//↓台詞、二重に

;//栞&コトハ
[VOICE f="Vex003"]
[OnName num="Shiori"]
"I love you, Kenji..."
[cpg cn=true]

;//ロングエフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=2100]
[free time=100]
[BG f="b_l_2f_lpass_p2.ui" time=100]
;//【ＢＧ】図書館・２階・左側廊下　昼（天窓からの光）******************************************************
[WAIT time=2100]
[transition target={false} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=3100]

[window target=true]

[BGM f="silent"]

[OnName num="Kenji"]
"Uh...uh..."
[cpg cn=true]

I must have fallen asleep for a moment, because I suddenly woke up.
[cpg]

What was wrong with me...?
[cpg]

My head was spinning, and everything looked distorted and sounds were echoing...
[cpg]

If one drink could do this , what happened to the others who gulped it down...?
[cpg]

[OnName num="Kenji"]
"I should go..."
[cpg cn=true]

I went back to the basement.
[cpg]



[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_ware_0.ui" time=1000]
;//【ＢＧ】図書館・地下・非常用倉庫　（暗）******************************************************

[WAIT time=1500]

;//[BGM f="d1"]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi513"]
[OnName num="Michi"]
"Untie me! Get this off me!"
[cpg cn=true]

As I entered the pantry, a red-faced Michi was yelling at me.
[cpg]

It wasn't the alcohol that was doing it, it was the struggle to get the rope off that made her face red.
[cpg]

[OnName num="Kenji"]
"Where are those guys?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi514"]
[OnName num="Michi"]
"They've gone to the infirmary! Hurry, we have to stop them!"
[cpg cn=true]

I cut the rope around Michi with a utility knife from the toolbox and headed to the infirmary with her.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）******************************************************

[WAIT time=1500]

;//[BGM f="silent"]

;//＠

;//[FG f="CHA03_p3_01_a.ui" method="change_4" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Erika544"]
[OnName num="Erika"]
"U....ugh..."
[cpg cn=true]

;//[FG f="CHA04_p3_01_a.ui" method="change_2" pos="1/3" time=800]
;//[WAIT time=100]
[VOICE f="Yuna405"]
[OnName num="Yuna"]
"Wee~...., hiccup."
[cpg cn=true]

;//[FG f="CHA06_p3_01_a.ui" method="change_2" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Syouko347"]
[OnName num="Syouko"]
"Aahhh~... weeeee~..."
[cpg cn=true]

[OnName num="Kenji"]
"What the hell...?"
[cpg cn=true]

[free time=1]
[WAIT time=1]

[FG f="CHA05_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi515"]
[OnName num="Michi"]
"Aah... You're kidding..."
[cpg cn=true]

In the infirmary, there were three drunk people collapsed on the floor looking like slugs.
[cpg]

And next to them were several empty IV packs.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi516"]
[OnName num="Michi"]
"Those precious IVs are......"
[cpg cn=true]

With a slumped shoulder, Michi picked up the clear pack and began to check the rest of the IVs.
[cpg]

[OnName num="Kenji"]
"'Is this safe to drink?!"
[cpg cn=true]

The three red-faced women writhing on the floor, with their eyes bugging out of their heads, were quite scary.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi517"]
[OnName num="Michi"]
"Consuming it isn't lethal. But pouring it directly into their stomachs, when they are already full of alcohol, means they're probably absorbing it more quickly and getting even drunker."
[cpg cn=true]

After Michi explained this to me, she continued with a rather pissed off look on her face.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi518"]
[OnName num="Michi"]
"Hmm! You'll be unusually thirsty after this, but there's no water. You'll get what you deserve. I hope you suffer for it!"
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

[STOPBGM]

I was randomly looking at the stainless steel table beside the three women lying down and wriggling, when Michi started to clean up.
[cpg]

What my still impaired mind thought about was the missing bodies of Takagi and Hosokawa.
[cpg]

Why..., no, how did the bodies disappear?
[cpg]

Even Hosokawa, as skinny as he was, was hard for one person to carry.
[cpg]

If there was a killer here, it would be absolutely impossible for anyone other than me to move it.
[cpg]

Could that really be...?
[cpg]

I rejected my own thoughts.
[cpg]

Was there really no other way to move it?
[cpg]

No..., not all at once, but little by little...
[cpg]

When I thought about it, I got goosebumps all over my body.
[cpg]

If the corpses could be dismembered and divided into parts, it would be possible for any woman to move them, wouldn't it?
[cpg]

There was also a sink here.
[cpg]

There might even be a knife.
[cpg]

There are saws and machetes in the toolbox in the pantry.
[cpg]

[OnName num="Kenji"]
".................."
[cpg cn=true]

I noticed my hand was gripping something and looked to see that it was the rope that had restrained Michi.
[cpg]

I've been holding it...the whole time.
[cpg]

[OnName num="Kenji"]
"Michi..., sorry..."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi519"]
[OnName num="Michi"]
"What...?!"
[cpg cn=true]

[BGM f="huan"]


I tied her up again with the rope as soon as she turned her back to me.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi520"]
[OnName num="Michi"]
"What are you doing?! Kenji, what's wrong with you?!"
[cpg cn=true]

[OnName num="Kenji"]
"It's not completely impossible..."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi521"]
[OnName num="Michi"]
"Hey!!"
[cpg cn=true]

I tied Michi to the foot of the bed and went back to the pantry to get some rope for the others.
[cpg]

[OnName num="Kenji"]
"Don't feel bad..."
[cpg cn=true]

I tied up the three drunk women as well, then crouched down near the entrance of the infirmary and talked to Michi, the only sane one in the room.
[cpg]

[OnName num="Kenji"]
"I think someone here is the killer. So this is for everyone's safety."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi522"]
[OnName num="Michi"]
"W-what the hell are you talking about?! If it's one of these people, I don't want to be stuck with them!"
[cpg cn=true]

[OnName num="Kenji"]
"I don't even know who the killer is. It could even be...you, Michi."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi523"]
[OnName num="Michi"]
"?!"
[cpg cn=true]

That's all I said to her, and then I left the doctor's office.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_wt_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・女子トイレ　夜（暗）******************************************************

[WAIT time=1500]

;//[BGM f="huan"]

In the evening, when I had completely sobered up, I decided to see if Shiori and I could do something about the frozen water pipes.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori595"]
[OnName num="Shiori"]
"We can't just heat this up..."
[cpg cn=true]

[OnName num="Kenji"]
"Let's just try it..."
[cpg cn=true]

I tried to heat the main water pipe that stretched from the ground to the sink with the camping stove.
[cpg]

However, the white, frosty areas only slightly melted, and no water came out when the faucet was turned on.
[cpg]

As Shiori said, this was not the only frozen area.
[cpg]

Miracles don't come easy.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori596"]
[OnName num="Shiori"]
"Is everyone you tied up okay...?"
[cpg cn=true]

Shiori was very surprised when she heard that I had restrained everyone else, but when I told her about my theory about the disappearing bodies, she thought it was inevitable and didn't say anything.
[cpg]

[OnName num="Kenji"]
"Right, we should take some blankets with us."
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）******************************************************
[WAIT time=1500]
;//[BGM f="huan"]


When I went to the infirmary, in the position I had tied her up in, Michi was shaking her leg irritably, and the others were slouched over.
[cpg]

;//[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Erika545"]
[OnName num="Erika"]
"Ew..., I feel sick..."
[cpg cn=true]

;//[FG f="CHA04_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Yuna406"]
[OnName num="Yuna"]
"My head is pounding..."
[cpg cn=true]

;//[FG f="CHA06_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Syouko348"]
[OnName num="Syouko"]
"Gah..., my mouth is dry..."
[cpg cn=true]

[OnName num="Kenji"]
"We've brought some blankets."
[cpg cn=true]

As I pulled the blanket over her body, Michi shouted loudly.
[cpg]

;//[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi524"]
[OnName num="Michi"]
"Shiori ! How can you let him do this to me? Untie me!"
[cpg cn=true]

;//2 3 5 9(6)
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori597"]
[OnName num="Shiori"]
"Doctor..., I'm sorry..."
[cpg cn=true]

Shiori believed in me.
[cpg]

I didn't think she suspected Michi, but she didn't want to interfere with what I was doing.
[cpg]

;//[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Erika546"]
[OnName num="Erika"]
"Kenji...i, Why are you doing this... I'm not the killer..."
[cpg cn=true]

;//[FG f="CHA04_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Yuna407"]
[OnName num="Yuna"]
"This is awful... Kenji... This isn't right..."
[cpg cn=true]

;//[FG f="CHA06_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Syouko349"]
[OnName num="Syouko"]
"I don't know anything... Please help me..."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

When I looked at the face of each person, it seemed like no one was the culprit.
[cpg]

But someone had to be the killer, and someone was lying.
[cpg]

I pushed down my guilt, telling myself that as long as they're restrained like this, everyone was safe.
[cpg]

[OnName num="Kenji"]
"I'll be sure to bring you some water if we get some."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori598"]
[OnName num="Shiori"]
"I really...am sorry..."
[cpg cn=true]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）******************************************************

[WAIT time=1500]
[BGM f="silent"]

As we came up to the freezing entrance, Shiori looked up at the ceiling and muttered to herself.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori599"]
[OnName num="Shiori"]
"If I were a little bird..., I could get out of there..."
[cpg cn=true]

The skylight staring down at us was cracked wide open, revealing a black sky.
[cpg]

I felt sorry for Shiori, who has never had freedom.
[cpg]

[OnName num="Kenji"]
"If everyone is tied up like that, no one will get killed, but... If there is still no water and no one comes to help..."
[cpg cn=true]

The fear of dying from dehydration and freezing to death was fueled by the night wind that was blowing in.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori600"]
[OnName num="Shiori"]
"Kenji..., are you scared...?"
[cpg cn=true]

[OnName num="Kenji"]
"Ah..., I am afraid to die... What about you, Shiori ?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori601"]
[OnName num="Shiori"]
"I...I've always felt this way... Like today I might be okay, but tomorrow I might not."
[cpg cn=true]

Fascinated by death from an early age, Shiori had probably been frightened all her life because of her weak body.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori602"]
[OnName num="Shiori"]
"And now that Kenji is by my side..., even if I end up dying here..., we are all together... So that makes me a little...happy."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

Shiori says she was glad that she won't be the only one to die.
[cpg]

It was surprising to know she thought such a thing.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori603"]
[OnName num="Shiori"]
"Do you hate the thought of...dying with me?"
[cpg cn=true]

Shiori looked me straight in the eye and asked.
[cpg]

[OnName num="Kenji"]
"I don't hate it... But I'd rather live with you than die."
[cpg cn=true]

It was like I was proposing to her, and I hugged Shiori.
[cpg]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_sr_2.ui" time=1000]
;//【ＢＧ】図書館・２階・セキュリティルーム　（暗／数台のモニターが点灯）******************************************************

[WAIT time=1500]

;//モニターで一連の様子を見ている何者か（コトハだが顔は見えない）の姿
;//[SE f="se063"]
;//【ＳＥ】ゴトリゴトリと何か（頭）が転がる音

[WAIT time=2000]

[SE f="se099"]
;//【ＳＥ】ペチャペチャと何かが塗りつけられる音

;//名前（？）表示
;//？？？
[VOICE f="Shiori604"]
[OnName num="unknown"]
"I won't give you..."
[cpg cn=true]


[WAIT time=1500]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）******************************************************

[WAIT time=1500]

[SE f="se140"]
;//【ＳＥ】銅像から表面が剥がれ落ちる音（ガラッ）

[OnName num="Kenji"]
".........?"
[cpg cn=true]

I heard something fall nearby.
[cpg]

But before I could pinpoint the direction of the sound, Shiori was running up the stairs screaming.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori605"]
[OnName num="Shiori"]
"Grandfatherー!!"
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）（踊り場）******************************************************

[WAIT time=1500]
[BGM f="huan"]

;//銅像から額の半分ほどが崩れていて、芯に何か黄ばんだ物（頭蓋骨）が見える
The sound from earlier seemed to be the sound of the statue collapsing, and when I looked, I saw that the crack extending from the first chipped ear had spread little by little.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori606"]
[OnName num="Shiori"]
"Ooohhhh!"
[cpg cn=true]

Shiori was so upset that she cried out because the crack had caused half of his forehead to collapse at once.
[cpg]

[OnName num="Kenji"]
"How terrible..."
[cpg cn=true]

The person she loved was literally broken.
[cpg]

Not only Shiori, this would be sad for anyone.
[cpg]

[OnName num="Kenji"]
"Hmm...?"
[cpg cn=true]

Behind the bronze and underneath some kind of clay or plaster, there was something unidentifiable.
[cpg]

It was the core, and there was a strange sphere inside that was a yellowish white.
[cpg]

[OnName num="Kenji"]
"What is it...?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]


When I was about to reach for it, Shiori grabbed my arm and shook her head as if she didn't like it.
[cpg]

She didn't want me to touch it, I guess.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori607"]
[OnName num="Shiori"]
"No more... I can't look anymore..."
[cpg cn=true]

I supported Shiori and we headed for her room.
[cpg]

;//[STOPBGM]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

[SE f="se136"]
;//【ＳＥ】ゆっくりドア開ける

[BG f="b_l_2f_rok_0.ui" time=1000]
;//【ＢＧ】図書館・２階・コトハの部屋　（暗／蝋燭）******************************************************

[WAIT time=1500]
;//[BGM f="huan"]

;//中央に集められた動物の石膏像。その周りを取り囲むように、石膏で塗り固めた高木と細川の手脚、胴体、頭が置かれている。それ以外の場所には本が散乱。
[cpg]


As soon as we entered the room, I noticed something strange...
[cpg]

[OnName num="Kenji"]
"Waaaaaaahー!"
[cpg cn=true]

I think it took me a few seconds to realize that the loud voice belonged to me.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori608"]
[OnName num="Shiori"]
"......!"
[cpg cn=true]

[OnName num="Kenji"]
"Th-this is......."
[cpg cn=true]

This was not Shiori's room, like I knew it.
[cpg]

Books were scattered all over the room, and plaster statues of animals were gathered in the middle of the room.
[cpg]

And around them, in a circle, were plaster statues that resembled human arms and legs.
[cpg]

But what made me scream was the fact that there were two heads placed in the middle of it all.
[cpg]

[OnName num="Kenji"]
"Ta, Takagi..., Hosokawa...!"
[cpg cn=true]

Yes, it was definitely the heads of Takagi and Hosokawa...
[cpg]

[OnName num="Kenji"]
"W-what...what the hell is this?"
[cpg cn=true]

I grabbed Shiori's shoulders and questioned her.
[cpg]

Shiori turned around with a pale face and answered in a small voice.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori609"]
[OnName num="Shiori"]
"I made these..."
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

This hobby was way too horrible.
[cpg]

What was wrong with Shiori, that she would use a dead person's face as a model?
[cpg]

[OnName num="Kenji"]
"H-how did you make this..?"
[cpg cn=true]

As soon as I tried to pursue it further, a white gel-like substance peeled off from the sculpture of Takagi's head.
[cpg]

Slide...
[cpg]

[SE f="se099"]
;//【ＳＥ】ズルズル……ベチャァァ

[WAIT time=1000]

[OnName num="Kenji"]
"Aaaaahhhhー!"
[cpg cn=true]

After it fell heavily to the floor, it appeared to be Takagi's actual face.
[cpg]

His eyes were vacantly open, his mouth half open, just as I had carried him.
[cpg]

It was definitely the head of Takagi's corpse.
[cpg]

[OnName num="Kenji"]
"It can't be..., You couldn't have... Shiori did this..."
[cpg cn=true]

.........
[cpg]

[OnName num="Kenji"]
"Aaaaaaaaaaaaahー!!"
[cpg cn=true]

I ran out of the room at once.
[cpg]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]


[if exp={ isSystemFlagsEnabled( "end1", "end2", "end3", "end4", "end5") }]
[jump target="*j15_a"]
[else]
[jump target="*j15_c"]
[endif]

;//※全ルート制覇で、以下破線内のシーン挿入
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～
*j15_a|Twins
[STOPBGM]
[WAIT time=1500]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）******************************************************

[WAIT time=1000]

[BGM f="silent"]

;//コトハ
[FG f="CHA01_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Shiori610"]
[OnName num="Shiori"]
"Are you okay...?"
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko350"]
[OnName num="Syouko"]
"Oh! Shiori!"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi525"]
[OnName num="Michi"]
"......?!"
[cpg cn=true]

For a moment, Michi thought that Shiori had come to her aid, but she soon realized that it was Kotoha.
[cpg]

;//コトハ
[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori611"]
[OnName num="Shiori"]
"I've found out who killed those two."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika547"]
[OnName num="Erika"]
"Who?!"
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori612"]
[OnName num="Shiori"]
"It was Kenji..."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko351"]
[OnName num="Syouko"]
"What...?"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna408"]
[OnName num="Yuna"]
"No, it can't be!"
[cpg cn=true]

;//コトハ
[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori613"]
[OnName num="Shiori"]
"It's true. So you guys need to get out of here without him finding out."
[cpg cn=true]

[SE f="se141"]
;//【ＳＥ】カッターでロープ切る


[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi526"]
[OnName num="Michi"]
"What are you planning...?"
[cpg cn=true]

When Michi was freed, she immediately knew that Kotoha's plans had changed, but she wondered if Shiori knew about it too.
[cpg]

Kotoha didn't plan something on her own, did she...?
[cpg]

;//コトハ
[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori614"]
[OnName num="Shiori"]
"Hehehe..."
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko352"]
[OnName num="Syouko"]
"Shiori...?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika548"]
[OnName num="Erika"]
"It can't be! No way! Kenji can't be the killer."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna409"]
[OnName num="Yuna"]
"But.., if it were true..."
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko353"]
[OnName num="Syouko"]
".................."
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori615"]
[OnName num="Shiori"]
"Well, I'll leave you to it. Now it's everybody for themselves..."
[cpg cn=true]

[SE f="se009"]
;//【ＳＥ】ドア閉まる

[STOPBGM]

;//エフェクト
[window target=false]
[transition target={true} rule="tobira2.png" color={0x000000ff} time=2000]
[WAIT time=2100]
[BG f="black.ui" time=100]
[WAIT time=100]
[transition target={false} color={0x000000ff} time=100]
[WAIT time=200]
[window target=true]
;//追加開始前にメッセージウィンドウを消してるので追加分岐の外で表示に切り替える
;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～
*j15_c|Twins

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）******************************************************

[WAIT time=1500]
[BGM f="huan"]

[OnName num="Kenji"]
"Huh...?"
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika549"]
[OnName num="Erika"]
"Ken, Kenji..."
[cpg cn=true]

[VOICE f="Yuna410"]
[OnName num="Yuna"]
"Kenji..."
[cpg cn=true]

When I rushed into the infirmary, I couldn't believe what had happened.
[cpg]

Even though they were tied up properly, Erika and everyone else were free.
[cpg]

[OnName num="Kenji"]
"How did you..."
[cpg cn=true]

The ropes had all been cut with a blade.
[cpg]

Shiori was with me the whole time.
[cpg]

Then who did this?
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika550"]
[OnName num="Erika"]
"Kenji... Was it you, Kenji...?
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika551"]
[OnName num="Erika"]
"Did Kenji kill Takagi and Hosokawa?"
[cpg cn=true]

[OnName num="Kenji"]
"W-what are you talking about...?"
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna411"]
[OnName num="Yuna"]
"Don't come any closer!"
[cpg cn=true]

The women looked at me with frightened eyes and slowly retreated to the corner of the room.
[cpg]

[OnName num="Kenji"]
"No, it wasn't me... It was..."
[cpg cn=true]

I almost said, "It was Shiori," but I swallowed those words.
[cpg]

Even after seeing that thing, somewhere inside me still wanted to believe Shiori was good.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika552"]
[OnName num="Erika"]
"I...believe you. If Kenji says he didn't do it, then I...believe him."
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna412"]
[OnName num="Yuna"]
"Erika! No... No matter how much you like him, Kenji tied us up! You can't trust someone...who would do that."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika553"]
[OnName num="Erika"]
"But!"
[cpg cn=true]

As a wedge started to drive between Erika and Yuna, Michi just stared blankly at them.
[cpg]

I didn't know what she was thinking because she wasn't saying a word.
[cpg]

Michi probably also thought that Shiori was the culprit...
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Syouko354"]
[OnName num="Syouko"]
"Kenji..., I need to talk to you."
[cpg cn=true]

[OnName num="Kenji"]
"Huh?"
[cpg cn=true]

Shoko walked up to me and took me by the hand as we left the room.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_lr_0.ui" time=1000]
;//【ＢＧ】図書館・地下・物置Ｂ　（暗）******************************************************

[WAIT time=1500]
;//[BGM f="huan"]

Shoko brought me to the storage area and I wondered what was going on.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko355"]
[OnName num="Syouko"]
"You can't trust Shiori."
[cpg cn=true]

[OnName num="Kenji"]
"......."
[cpg cn=true]

Shoko said to me, with her back to the door.
[cpg]

[if exp={getFlagValue("Psychosis") > 0 }]
[jump target="*j16_a"]
[else]
[jump target="*j16_c"]
[endif]


;//※＜病気フラグ＞が立っている場合、以下破線内の文章が挿入される
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～
*j16_a|Twins

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko356"]
[OnName num="Syouko"]
"Something is off with Shiori... Sometimes she's like a different person..."
[cpg cn=true]

[OnName num="Kenji"]
"I...think so too."
[cpg cn=true]

I told Shoko that Shiori might have a mental disorder as well.
[cpg]

Then I told her all about what was wrong with Shiori, including the fact that she was wandering around with a knife on Christmas Eve.
[cpg]

[OnName num="Kenji"]
"We talked about her medication before, right? That drug..., was a psychiatric drug."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko357"]
[OnName num="Syouko"]
"Well, then...it's like I thought..."
[cpg cn=true]

[OnName num="Kenji"]
"What is...?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko358"]
[OnName num="Syouko"]
"I've had my suspicions... I thought Shiori might have a personality disorder..."
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko359"]
[OnName num="Syouko"]
"It's generally known as a split personality. I hadn't noticed it before, but..."
[cpg cn=true]

[VOICE f="Syouko1359"]
[OnName num="Syouko"]
"After spending so much time with her here, I started to think that her speech and personality were different depending on the time of day..."
[cpg cn=true]

[OnName num="Kenji"]
"I-I thought that too."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko360"]
[OnName num="Syouko"]
"If that type of medication is necessary, that's definitely it. So then it's possible..."
[cpg cn=true]

[OnName num="Kenji"]
"Then it's possible...?"
[cpg cn=true]

I didn't want to hear the rest of what she had to say.
[cpg]

But now that I've come this far, I had no choice but to listen...
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko361"]
[OnName num="Syouko"]
"It is possible that the person who killed those two was Shiori's alter."
[cpg cn=true]

[OnName num="Kenji"]
"Ah..."
[cpg cn=true]

What a grim conclusion.
[cpg]

Did Shiori, that Shiori, have another personality inside her, which committed those terrible crimes and created those awful sculptures?
[cpg]

[OnName num="Kenji"]
"So..., what do we do now...?"
[cpg cn=true]

;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～
*j16_c|Twins

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko362"]
[OnName num="Syouko"]
"Since it's like this, let me be frank. I don't trust Erika or Yuna. They're the type who like to steal."
[cpg cn=true]

Shoko said bluntly, leaving her past questionable behavior behind her.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko363"]
[OnName num="Syouko"]
"Besides, Michi and Shiori have an unbreakable bond. She will do everything in her power to protect Shiori no matter what we do."
[cpg cn=true]

[VOICE f="Syouko1363"]
[OnName num="Syouko"]
"So..., the only person I can trust here is you, Kenji."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah..."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko364"]
[OnName num="Syouko"]
"Why don't we work together? Until we get out of here, Kenji and I will team up!"
[cpg cn=true]

Shoko said, and shook my hand.
[cpg]


;//※＜病気フラグ＞が立っている場合　→　『ルートＦ』へ
[if exp={getFlagValue("Psychosis") > 0 }]
[jump storage="ep021.ks" target="*start"]
[else]
[endif]

[STOPBGM]

That’s when...
[cpg]

;//↓　名前は栞だけど本当はコトハ、という展開です。

[WAIT time=1500]
;//[BGM f="huan"]

;//コトハ
[VOICE f="Shiori616"]
[OnName num="Shiori"]
"Kenji..., where are you...?"
[cpg cn=true]

I heard Shiori's voice on the other side of the door.
[cpg]

;//コトハ
[VOICE f="Shiori617"]
[OnName num="Shiori"]
"Where are you...? I'm...scared..."
[cpg cn=true]

She sounded like she was about to start crying.
[cpg]

What I saw in the room earlier must have been a mistake.
[cpg]

Shiori must have had more she wanted to say to me.
[cpg]

That's what I assumed, and put my hand on the doorknob...
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko365"]
[OnName num="Syouko"]
"Don't."
[cpg cn=true]

[OnName num="Kenji"]
"?!"
[cpg cn=true]

Suddenly, Shoko covered my mouth with her hand.
[cpg]

[OnName num="Kenji"]
"Mmm...uggh."
[cpg cn=true]

;//コトハ

[VOICE f="Shiori618"]
[OnName num="Shiori"]
"Kenji~...... are you in here~?"
[cpg cn=true]

[SE f="se072"]
;//【ＳＥ】ノック

[WAIT time=1000]


[OnName num="Kenji"]
"Shio..."
[cpg cn=true]

;//コトハ

[VOICE f="Shiori619"]
[OnName num="Shiori"]
"I know you're in thereー! Kenji!"
[cpg cn=true]

[SE f="se121"]
;//【ＳＥ】激しくドア叩く（ガンガンガン！）

[WAIT time=1000]


[OnName num="Kenji"]
"?!"
[cpg cn=true]


[BGM f="danger"]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko366"]
[OnName num="Syouko"]
"Shhh...."
[cpg cn=true]

;//コトハ

[VOICE f="Shiori620"]
[OnName num="Shiori"]
"Why are you hiding?! It's me! It's Shiori!"
[cpg cn=true]

[SE f="se121"]
;//【ＳＥ】激しくドア叩く
The Shiori on the other side of the door was becoming more and more deranged.
[cpg]

;//コトハ
[VOICE f="Shiori621"]
[OnName num="Shiori"]
"You love me, don't you? I love you too! Ever since I first met you, I've been captivated by your beautiful face and body."
[cpg cn=true]

[VOICE f="Shiori1621"]
[OnName num="Shiori"]
"So I was very happy to be trapped with you, Kenji! I was happy to be with you all day, every day!"
[cpg cn=true]

[SE f="se121"]
;//【ＳＥ】激しくドア叩く

;//＠
;//【ＢＧ】図書館・地下・物置Ｂ　（暗）

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko367"]
[OnName num="Syouko"]
"Shiori, is going crazy! Don't open the door!"
[cpg cn=true]

[OnName num="Kenji"]
"Ugh..."
[cpg cn=true]

Shoko stopped me, and Shiori got louder and louder.
[cpg]

;//コトハ

[VOICE f="Shiori622"]
[OnName num="Shiori"]
"There's no one else like you! You're the only one for me! I want you! You're mine, I'm yours! Kenji, aren't we supposed to be in love?"
[cpg cn=true]


[VOICE f="Shiori623"]
[OnName num="Shiori"]
"Hey, come out and hold me right now! Because I'm the only one who can make you happy! Kenji! Kenjiiii!"
[cpg cn=true]

[SE f="se121"]
;//【ＳＥ】激しくドア叩く



[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko368"]
[OnName num="Syouko"]
"Eek...! She's definitely crazy. Shiori's mentally ill!"
[cpg cn=true]

[OnName num="Kenji"]
"Mentally ill..."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko369"]
[OnName num="Syouko"]
"That's why you can't trust her! No matter how much you love her, you can't be together!"
[cpg cn=true]

Shoko was desperately trying to persuade me.
[cpg]

Shiori was mentally ill...
[cpg]

I couldn't believe that such a serious illness had taken over her body and was eating away at her mind on top of it.
[cpg]

She has been all alone because of her illness.
[cpg]

And yet, even though she had finally met me, I left her...
[cpg]

I felt sorry for Shiori.
[cpg]

[OnName num="Kenji"]
"I still...love Shiori!"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko370"]
[OnName num="Syouko"]
"Kenji?!"
[cpg cn=true]

[OnName num="Kenji"]
"I like...the shy, pure, healthy, and loving Shiori!"
[cpg cn=true]

Even when I saw things like that, even when I saw the leopard change its spots, I could still see the pure smile of the Shiori who enjoyed talking about books and said she wanted to go on an adventure.
[cpg]

I love Shiori.
[cpg]

That's why I swore to protect her, to save her.
[cpg]

[OnName num="Kenji"]
"I'm...going."
[cpg cn=true]

I shook Shoko off and put my hand on the doorknob.
[cpg]

[SE f="se136"]
;//【ＳＥ】ドア開ける

[free time=1000]

[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗）******************************************************

[WAIT time=1500]


[OnName num="Kenji"]
".................."
[cpg cn=true]

When I stepped out into the hallway, Shiori was already gone.
[cpg]

[OnName num="Kenji"]
"I have to find her..."
[cpg cn=true]

[SE f="se136"]
;//【ＳＥ】バタンバタン
I looked in every room in the basement, but there was still no sign of Shiori.
[cpg]

[OnName num="Kenji"]
"Where did she go...?"
[cpg cn=true]

;//エフェクト
[window target=false]
[transition target={true} rule="tobira2.png" color={0x000000ff} time=2000]
[WAIT time=2100]
[BG f="black.ui" time=100]
[WAIT time=100]
[transition target={false} color={0x000000ff} time=100]
[WAIT time=200]

[if exp={ isSystemFlagsEnabled( "end1", "end2", "end3", "end4", "end5") }]
[jump target="*j17_a"]
[else]
[jump target="*j17_c"]
[endif]


;//※全ルート制覇で以下破線内の文章挿入
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～

*j17_a|Twins

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_ros_0.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

[WAIT time=1500]
[window target=true]

;//爪を切っているコトハ
[SE f="se120"]
;//【ＳＥ】爪を切る音

[WAIT time=1000]

[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori624"]
[OnName num="Kotoha"]
"It's not Shiori you like. It's me. Pure? Shy? That girl can't comfort you."
[cpg cn=true]

[VOICE f="Shiori1624"]
[OnName num="Kotoha"]
"What you like is my body, and what I like is your body... But, if you like Shiori that much, I'll become Shiori...for you."
[cpg cn=true]

;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="163.jpg" color={0x000000ff} time=2000]
[WAIT time=2100]
;//【ＢＧ】ブラックアウト
[free time=100]
[BG f="black.ui" time=100]
[transition target={false} color={0x000000ff} time=100]
[WAIT time=200]
[window target=true]
;//追加開始前にメッセージウィンドウを消してるので追加分岐の外で表示に切り替える
;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～
*j17_c|Twins

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）******************************************************

[WAIT time=1000]

[window target=true]


[BGM f="danger"]


[SE f="se084"]
;//【ＳＥ】本を破く音
When I got to the first floor, Erika and Yuna were tearing up all the books they could find.
[cpg]



[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika554"]
[OnName num="Erika"]
"If we burn the books, the smoke will rise and someone will notice!"
[cpg cn=true]

[VOICE f="Yuna413"]
[OnName num="Yuna"]
"The smoke will get out through there!"
[cpg cn=true]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]


The two of them seemed to be trying to create a smoke signal using the broken skylight.
[cpg]

But I couldn't deal with them right now.
[cpg]

While those two were busy over there, I headed for the second floor alone.
[cpg]

On the way there...
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BG f="b_l_1f_entrance_p4up.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）（踊り場）******************************************************

[WAIT time=1500]
;//[BGM f="danger"]

;//銅像の顔がほとんど崩れている

[OnName num="Kenji"]
"......?!"
[cpg cn=true]

I stopped when I suddenly noticed that the bronze statue on the landing had almost completely fallen apart.
[cpg]

[OnName num="Kenji"]
"Inside is..."
[cpg cn=true]

The object that was a mystery when part of the forehead came off was now completely exposed.
[cpg]

That was obviously the white skull of a human being.
[cpg]

I just somehow knew that it was Shiori's grandfather's and immediately ran upstairs.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_lpass_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・左側廊下　夜（暗）******************************************************

[WAIT time=1500]
;//[BGM f="danger"]

;//エントランスで代用
[OnName num="Kenji"]
"Shiori?!"
[cpg cn=true]

Shiori had collapsed in front of her room.
[cpg]

I immediately ran to her and picked her up, and a single tear fell from her eye.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori625"]
[OnName num="Shiori"]
"I..., I...killed Grandfather..."
[cpg cn=true]

;//[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Michi527"]
[OnName num="Michi"]
"That's not true."
[cpg cn=true]

[OnName num="Kenji"]
"?!"
[cpg cn=true]

A few moments laters, I heard a voice.
[cpg]

Michi stared at Shiori with a sad face, and then told her just the opposite.
[cpg]


[move from="2/3" to="2/5" ease="easeInOutSine" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi528"]
[OnName num="Michi"]
"Shiori, you didn't... You didn't kill anyone."
[cpg cn=true]


[VOICE f="Shiori626"]
[OnName num="Shiori"]
"I...did..."
[cpg cn=true]

[OnName num="Kenji"]
"What do you mean?"
[cpg cn=true]

I was trying to figure out who was telling the truth.
[cpg]

But it was true that earlier, and up until now, Shiori sometimes went crazy, and I really wanted to know why.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi529"]
[OnName num="Michi"]
"Shiori..., That's enough..."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori627"]
[OnName num="Shiori"]
"We're fighting, my sister and I. Let me tell you why. The truth. My sister likes coffee, I like tea. We're so different..."
[cpg cn=true]

[OnName num="Kenji"]
"Mother Goose...?"
[cpg cn=true]

Shiori slipped through my hands and leaned against the wall, muttering a nursery rhyme.
[cpg]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi530"]
[OnName num="Michi"]
"Kenji..., Come here..."
[cpg cn=true]

[OnName num="Kenji"]
".........."
[cpg cn=true]

With Michi's permission, I stepped into Shiori's room.
[cpg]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_ros_0.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗）******************************************************

[WAIT time=1500]
[BGM f="serious"]


;//本棚のスライド部分が開いていて、奥（コトハ）の部屋が見える状態になっている。
;//コトハの部屋は乱雑に本が散らばり、像を作る材料や道具も散乱している。

[OnName num="Kenji"]
"What..., it's huge..."
[cpg cn=true]

The room looked different from before and just a moment ago.
[cpg]

A few of the bookshelves have been moved and another room appeared at the back.
[cpg]

In the back of the room, there were books and unfamiliar tools scattered on the floor.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi531"]
[OnName num="Michi"]
"This is Kotoha's..., her sister's room."
[cpg cn=true]

[OnName num="Kenji"]
"S-sister?!"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi532"]
[OnName num="Michi"]
"Shiori has a twin sister named Kotoha..."
[cpg cn=true]

[OnName num="Kenji"]
"Ah!!"
[cpg cn=true]

All my questions were instantly answered with a single word.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi533"]
[OnName num="Michi"]
"Shiori was sick, Kotoha had a personality disorder, and their parents had a hard time taking care of the both of them, so they were left in the care of their grandfather, Mr. Tokita."
[cpg cn=true]

[VOICE f="Michi1533"]
[OnName num="Michi"]
"They grew very attached to Mr. Tokita and spent their early years being loved equally by him..."
[cpg cn=true]


Michi started explaining.
[cpg]

Shiori and Kotoha's life stories...
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi534"]
[OnName num="Michi"]
"Even though they had different personalities, they got along very well. If Kotoha misbehaved, Shiori would protect her, and if Shiori got sick, Kotoha would take care of her."
[cpg cn=true]

[VOICE f="Michi1534"]
[OnName num="Michi"]
"And as the twins grew up, everything led up to that tragedy..."
[cpg cn=true]


[OnName num="Kenji"]
"That tragedy...being...?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi535"]
[OnName num="Michi"]
"Mr. Tokita's aging... It was a tragedy for the twins, who loved and adored him. He couldn't pick them up anymore, and slowly, his face became deeply wrinkled and he had less and less mobility..."
[cpg cn=true]

[VOICE f="Michi1535"]
[OnName num="Michi"]
"They couldn't bear the sight of the man they loved withering away more and more every day..."
[cpg cn=true]


[STOPBGM]


;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=2100]
[BG f="black.ui" time=100]
[free time=100]
[WAIT time=200]
[transition target={false} color={0x000000ff} time=100]
[WAIT time=1500]
;//【ＢＧ】ブラックアウト
[window target=true]

[BGM f="serious"]

;//回想　セピア
;//栞とコトハ、８歳くらい
;//朱鷺田邸　中庭

[VOICE f="Shiori628"]
[OnName num="Shiori"]
"Grandfather is...shrinking... He's going to get smaller and smaller..."
[cpg cn=true]


[VOICE f="Shiori629"]
[OnName num="Kotoha"]
"Why? Why can't he stay our handsome grandfather...?"
[cpg cn=true]


[VOICE f="Michi536"]
[OnName num="Michi"]
"It's inevitable, you know? When people get older, they get thinner and smaller and go to heaven."
[cpg cn=true]


[VOICE f="Shiori630"]
[OnName num="Shiori"]
"No... If grandfather is going to heaven, I'm going with him..."
[cpg cn=true]


[VOICE f="Shiori631"]
[OnName num="Kotoha"]
"No, you can't Shiori! I'm not going to let grandfather get any smaller. That's why you have to stay with me forever, Shiori!"
[cpg cn=true]

;//【ＢＧ】ブラックアウト
;//[free time=400]
;//[WAIT time=400]
;//[BG f="black.ui" time=900]
;//[WAIT time=1500]

[STOPBGM]

[VOICE f="Michi537"]
[OnName num="Michi"]
"And then tragedy struck..."
[cpg cn=true]

;//祖父を刺したナイフを持ち血まみれのコトハ。そばで見ている栞


[VOICE f="Shiori632"]
[OnName num="Shiori"]
"I'm home, Kotoha..."
[cpg cn=true]


[VOICE f="Shiori633"]
[OnName num="Kotoha"]
"Welcome home. How was the hospital...?"
[cpg cn=true]


[VOICE f="Shiori634"]
[OnName num="Shiori"]
"Yes..., the injection hurt, but I didn't cry... What the...?!"
[cpg cn=true]

[SE f="se047"]
;//【ＳＥ】本が落ちる

[window target=false]
[transition target={true} rule="amamori2.png" color={0xff0000ff} time=2000]
[WAIT time=2100]
[BG f="red.ui" time=100]
[transition target={false} color={0xff0000ff} time=100]
[WAIT time=200]
[window target=true]

[BGM f="huan"]


[VOICE f="Shiori635"]
[OnName num="Kotoha"]
"Oh..., don't drop the book. You'll get blood all over it."
[cpg cn=true]

[VOICE f="Shiori636"]
[OnName num="Shiori"]
"Grandfather..., what happened?"
[cpg cn=true]


[VOICE f="Shiori637"]
[OnName num="Kotoha"]
"This way, he won't wither away... I used magic..."
[cpg cn=true]


[VOICE f="Shiori638"]
[OnName num="Shiori"]
"Magic?"
[cpg cn=true]


[VOICE f="Shiori639"]
[OnName num="Kotoha"]
"Magic that stops time."
[cpg cn=true]


[VOICE f="Shiori640"]
[OnName num="Shiori"]
"Grandfather, will stay just like this?"
[cpg cn=true]


[VOICE f="Shiori641"]
[OnName num="Kotoha"]
"Yes..."
[cpg cn=true]


[VOICE f="Shiori642"]
[OnName num="Shiori"]
"But the wrinkles will never go away..."
[cpg cn=true]


[VOICE f="Shiori643"]
[OnName num="Kotoha"]
"This should have been done earlier. When he was still handsome..."
[cpg cn=true]


[VOICE f="Shiori644"]
[OnName num="Shiori"]
"Always stay handsome...?"
[cpg cn=true]


[VOICE f="Shiori645"]
[OnName num="Kotoha"]
"Yeah. If you ever meet someone you like again, I'll freeze him in time at his peak."
[cpg cn=true]


[VOICE f="Shiori646"]
[OnName num="Shiori"]
"Yeah, let's do that."
[cpg cn=true]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]



[VOICE f="Michi538"]
[OnName num="Michi"]
"Shiori! Kotoha! Oh, my God...!!"
[cpg cn=true]


[VOICE f="Shiori647"]
[OnName num="Shiori"]
"Oh, Doctor, she stopped time for our grandfather."
[cpg cn=true]


[VOICE f="Shiori648"]
[OnName num="Kotoha"]
"Isn't it great? Now Shiori won't have to go to heaven, right?"
[cpg cn=true]

[VOICE f="Michi539"]
[OnName num="Michi"]
"...! U-uh..., yes... You two mustn't tell anyone about this. You have to promise me."
[cpg cn=true]


[VOICE f="Shiori649"]
[OnName num="Kotoha"]
"Okay."
[cpg cn=true]


[VOICE f="Shiori650"]
[OnName num="Shiori"]
"I promise. But, doctor, I want to stay with grandfather forever. Can he stay in my room with me?"
[cpg cn=true]


[VOICE f="Michi540"]
[OnName num="Michi"]
"Well... Wait a minute. I'll go...and make sure you can always be together..."
[cpg cn=true]


[VOICE f="Shiori651"]
[OnName num="Shiori"]
"Really? Yayー! Uh, ugh...my chest..."
[cpg cn=true]


[VOICE f="Shiori652"]
[OnName num="Kotoha"]
"Shiori? Doctor, I'll help you! I'll make sure Shiori can stay by grandfather's side. So hurry!"
[cpg cn=true]


[VOICE f="Michi541"]
[OnName num="Michi"]
"Then, Kotoha..., let's do it together..."
[cpg cn=true]

;//エフェクト
[window target=false]
[transition target={true} rule="encont.encount" color={0x000000ff} time=2000]
[WAIT time=2100]

;//回想明け

[STOPBGM]

[BG f="b_l_2f_ros_0.ui" time=100]
;//【ＢＧ】図書館・２階・栞の部屋　（暗）******************************************************
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=1500]

[transition target={false} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=3100]

[window target=true]

[BGM f="serious"]


[OnName num="Kenji"]
"Hey..."
[cpg cn=true]

When I heard that story, I couldn't feel or think anything, my mind went blank.
[cpg]

A child killed her own grandfather and Michi made a statue of it...
[cpg]

[OnName num="Kenji"]
"A corpse, embedded in a statue?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi542"]
[OnName num="Michi"]
"They wanted to make a standing statue, but old man Tokita's bones were too brittle to use."
[cpg cn=true]

[OnName num="Kenji"]
"Wasn't it hard to hide the body?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi543"]
[OnName num="Michi"]
"Of course, the disappearance of a wealthy man got the police involved. But they were never suspected."
[cpg cn=true]

[OnName num="Kenji"]
"They were just kids..."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi544"]
[OnName num="Michi"]
"There's that too, but Shiori had an alibi since she'd been at the hospital with me."
[cpg cn=true]

[OnName num="Kenji"]
"But, what about Kotoha?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi545"]
[OnName num="Michi"]
"The day she killed Mr. Tokita..., she became Shiori's shadow."
[cpg cn=true]

[OnName num="Kenji"]
"What does that mean...?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi546"]
[OnName num="Michi"]
"From the beginning, their cold parents only planned on adopting Shiori, who had been sick since birth and put her in the Tokita family registry with the intention of only raising her."
[cpg cn=true]

[VOICE f="Michi1546"]
[OnName num="Michi"]
"In other words, the Tokitas only adopted Shiori. Technically, Kotoha doesn't exist..."
[cpg cn=true]


[OnName num="Kenji"]
"Shiori...covered up what Kotoha had done with her own alibi."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi547"]
[OnName num="Michi"]
"Since then, these two have always been two sides of the same coin... Basically, Shiori comes out during the day and it's Kotoha's turn at night. But, whenever Shiori isn't feeling well, Kotoha takes her place..."
[cpg cn=true]

[OnName num="Kenji"]
"That...kind of life..."
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_1" pos="5/3" time=800]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi548"]
[OnName num="Michi"]
"It was going well. Until you came along..."
[cpg cn=true]


[move from="2/3" to="2/5" ease="easeInOutSine" time=1000]
[move from="5/3" to="4/5" ease="easeInOutSine" time=1000]

[WAIT time=100]
[VOICE f="Shiori653"]
[OnName num="Shiori"]
"Kotoha and I...fell in love with the same person..., fell in love with Kenji at the same time..."
[cpg cn=true]

Shiori, who was in the hallway, slowly came into the room and told the rest of the story.
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori654"]
[OnName num="Shiori"]
"The first time I saw you, I was reminded of...our grandfather. And when I was trapped here because of the trouble Erika caused, I promised..."
[cpg cn=true]

[VOICE f="Shiori1654"]
[OnName num="Shiori"]
"I thought this was my chance. I will not make the same mistake again. I said we should do the same thing to you, Kenji. While you're still beautiful."
[cpg cn=true]


[OnName num="Kenji"]
"Oh, you were going to make me a statue...?"
[cpg cn=true]

The blood drained from my face.
[cpg]

One wrong move and I'd have been killed too...
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori655"]
[OnName num="Shiori"]
"And yet..., as I spent time with you, Kenji, I was attracted not only to your outward appearance... I also liked what was on the inside."
[cpg cn=true]

[VOICE f="Shiori1655"]
[OnName num="Shiori"]
"And I began to think that it was wrong to take the life of someone so kind..."
[cpg cn=true]


[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi549"]
[OnName num="Michi"]
"But Kotoha wouldn't allow it. She began to think and act on her own..."
[cpg cn=true]

[VOICE f="Michi1549"]
[OnName num="Michi"]
"She killed Takagi, who messed with Shiori, and killed Hosokawa, who made a pass at me, and used them as experiments in order to develop a new standing statue."
[cpg cn=true]


[OnName num="Kenji"]
"A new...?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi550"]
[OnName num="Michi"]
"Bronze and plaster statues have very different textures from humans, so we've been working......on making them look like they're alive."
[cpg cn=true]

[VOICE f="Michi1550"]
[OnName num="Michi"]
"In my spare time, I've been developing the material in the infirmary."
[cpg cn=true]


[OnName num="Kenji"]
"Oh..."
[cpg cn=true]

I looked up at the heavens.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori656"]
[OnName num="Shiori"]
"I'm sorry... Even after I started to think it was a bad idea, I still helped Kotoha do what she did..."
[cpg cn=true]

[VOICE f="Shiori1656"]
[OnName num="Shiori"]
"I didn't want Kotoha to hate me, and I didn't want you to hate me... Every single day, I didn't know what to do, and this whole time it's been weighing heavy on my heart..."
[cpg cn=true]

Shiori dropped the book she was holding, held her chest and broke down crying.
[cpg]

The nails on her hands were clean and neat.
[cpg]

[OnName num="Kenji"]
"............"
[cpg cn=true]

I unintentionally checked the book and saw that it was "The World of Fantasia", and that it was indeed Shiori in front of me.
[cpg]

[OnName num="Kenji"]
"Shiori..., don't cry... It's not good for your body..."
[cpg cn=true]

I had a variety of mixed feelings, but I couldn't bring myself to condemn Shiori.
[cpg]

Shiori has never known the outside world and has only had her loved ones and books to rely on.
[cpg]

If anyone is to blame, it's the people around Shiori and not Shiori herself.
[cpg]

I hugged from behind Shiori as she crouched down.
[cpg]

[OnName num="Kenji"]
"Shiori..., run away with me."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori657"]
[OnName num="Shiori"]
"What...? But..., what about Kotoha...?"
[cpg cn=true]

[OnName num="Kenji"]
"I fell in love with Shiori, not Kotoha. I like you because you're gentle and have a love of fantasy."
[cpg cn=true]

[OnName num="Kenji"]
"I know it's hard, but you shouldn't stay with her. Shiori and Kotoha are two different people, okay?"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori658"]
[OnName num="Shiori"]
"Is that how...Kenji...feels?"
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, that's right. We'll get out of here somehow, and then you can come live with me."
[cpg cn=true]

I grabbed Shiori by her shoulders and spoke firmly, and Shiori looked at Michi, slightly confused.
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori659"]
[OnName num="Shiori"]
"Doctor..."
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi551"]
[OnName num="Michi"]
"I agree... I think you should..."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori660"]
[OnName num="Shiori"]
"Really...?"
[cpg cn=true]

[OnName num="Kenji"]
"Michi, is that really okay with you?"
[cpg cn=true]

I was surprised that Michi, who seemed to be half in love with Shiori, would say such a thing.
[cpg]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi552"]
[OnName num="Michi"]
"If it's Kenji..., I can trust him to take care of you, Shiori. I want you to let me continue to treat your illness, but maybe it would be better if you left us and forgot all the terrible things that have happened..."
[cpg cn=true]

Saying all that... Oh, I think Michi loved Shiori with all her heart...
[cpg]

The environment that protected Shiori and cared for Shiori ended up tormenting her, and I think Michi was also heartbroken.
[cpg]

[OnName num="Kenji"]
"So, where is Kotoha now?"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi553"]
[OnName num="Michi"]
"I don't know... But I'm sure she'll try to stop you. She definitely won't want to let either of you go..."
[cpg cn=true]

[STOPBGM]

That's when the conversation died down for a moment and I wondered what was going on.
[cpg]

I noticed the smell of something burning in the air.
[cpg]

[OnName num="Kenji"]
"What's that smell...?"
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori661"]
[OnName num="Shiori"]
"Is something burning..?"
[cpg cn=true]

[BGM f="danger"]

[OnName num="Kenji"]
"Oh no!"
[cpg cn=true]

[free time=1000]


I remembered what Erika and Yuna were trying to do and quickly opened the door to the room.
[cpg]

Then...
[cpg]

[SE f="se123"]
;//【ＳＥ】ゴーーーッ！

;//＠
;//レッドアウト？

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

There was a rush of hot air, a welcome change from the cold air we had been used to.
[cpg]

A moment later I frowned at the heat...
[cpg]

[SE f="se133"]
;//【ＳＥ】非常ベル

[WAIT time=1000]


[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi554"]
[OnName num="Michi"]
"Is there a fire?!"
[cpg cn=true]

The loud sound of the emergency bell began to ring. It was a bad idea to stay here like this.
[cpg]

[OnName num="Kenji"]
"Anyway, we have to get out of here!"
[cpg cn=true]

I say, holding out my hand to Shiori.
[cpg]

[OnName num="Kenji"]
"Let's go!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori662"]
[OnName num="Shiori"]
"Yeah...!"
[cpg cn=true]

We take each other's hands and head out into the upstairs hallway.
[cpg]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi555"]
[OnName num="Michi"]
"Wait."
[cpg cn=true]

[OnName num="Kenji"]
"?"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi556"]
[OnName num="Michi"]
"Kenji, take this."
[cpg cn=true]

Even though we were in the middle of an emergency, Michi stopped me and handed me something.
[cpg]

[OnName num="Kenji"]
"A key...?"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi557"]
[OnName num="Michi"]
"It's something I've been saving, but I'll give it to you. I'm sure you'll need it."
[cpg cn=true]

I'm not sure what she meant by that, but right now we needed to get out of here as soon as possible.
[cpg]

[OnName num="Kenji"]
"Okay. Anyway, let's get out of here."
[cpg cn=true]

[SE f="se065"]
;//【ＳＥ】スタッフオンリードア気負いよく開ける

[WAIT time=1000]


[SE f="se123"]
;//【ＳＥ】メラメラ

[OnName num="Kenji"]
"Whoa?!"
[cpg cn=true]

The first floor and the landing had already become a sea of fire when I opened the staff-only door.
[cpg]

[free time=1000]
[BG f="b_l_1f_entrance_p4ex4.ui" time=1000]
[WAIT time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shiori663"]
[OnName num="Kotoha"]
"Kenji!"
[cpg cn=true]

On the other side of the corridor, Kotoha stood and called my name.
[cpg]

[OnName num="Kenji"]
"They told me everything. You've been lying to me, Kotoha... I'm going with Shiori."
[cpg cn=true]

I squeezed Shiori's hand and told Kotoha, who had an identical face.
[cpg]

Then, with a desperate look on her face, she pleaded with me.
[cpg]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori664"]
[OnName num="Kotoha"]
"No, I'm Shiori...!"
[cpg cn=true]

[OnName num="Kenji"]
"What...?"
[cpg cn=true]

I quickly looked at Shiori beside me.
[cpg]

[FG f="CHA02_p5_01_a.ui" method="change_4" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shiori665"]
[OnName num="Shiori"]
"Believe me, Kenji. I am the real Shiori..."
[cpg cn=true]

Shiori claimed, clinging to my arm.
[cpg]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori666"]
[OnName num="Kotoha"]
"Kotoha, stop it! Let go of Kenji..."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori667"]
[OnName num="Shiori"]
"What are you talking about, Kotoha...? You should give up on Kenji."
[cpg cn=true]

[OnName num="Kenji"]
"Mi, Michi!"
[cpg cn=true]

With both of them clinging to me, I looked back at Michi, who was staring back at us with an expression of disbelief.
[cpg]

[OnName num="Kenji"]
"Don't you know?"
[cpg cn=true]


[VOICE f="Michi558"]
[OnName num="Michi"]
"I d-don't know..."
[cpg cn=true]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4ex4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（火事）******************************************************

[WAIT time=1500]
;//[BGM f="danger"]

[SE f="se117"]
;//【ＳＥ】崩れる胸像

[WAIT time=2000]

;//＠

[FG f="CHA01_p1_01_a.ui" method="change_5" pos="4/5" time=800]
[FG f="CHA02_p5_01_a.ui" method="change_5" pos="2/5" time=800]

[VOICE f="Vex004"]
[OnName num="Shiori_Kotoha"]
"Ah!"
[cpg cn=true]

The statue collapsed on the landing, and a moment later the white bones inside fell into the fire.
[cpg]

[FACE method="change_4" pos="2/5"]
[FACE method="change_4" pos="4/5"]

[VOICE f="Vex005"]
[OnName num="Shiori_Kotoha"]
"Grandfatheerr!"
[cpg cn=true]

Their timing, their voices, everything about these two was exactly the same.
[cpg]

Which one was the real Shiori?
[cpg]



[if exp={ isSystemFlagsEnabled( "end1", "end2", "end3", "end4", "end5") }]
[jump target="*j_ex"]
[else]
[jump target="*j_n"]
[endif]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～

*j_ex|Twins

;//==========================
;//全てのエンディングを制覇しているとEX選択肢が発生
;//新ルートに分岐
;//新ルート合流へ
;//==========================
;//■選択肢EX（２択）
[switch]
[case "Believe in the Shiori next to you"]
	[swap]
	[jump target="*ex_a"]
[case "Believe in the Shiori in front of you"]
	[swap]
	[jump storage="ep022.ks" target="*ex_b"]
[endswitch]
;//１、隣にいるシオリを信じる	ex_a
;//２、目の前のシオリを信じる	ex_b
;//==========================
;//１、隣にいるシオリを信じる　を選択した場合はこのまま進行
*ex_a|Twins
.......
[cpg]

.............
[cpg]

No, no. That's not her.
[cpg]

I believed in Shiori. But I didn't know if she was the one next to me or in front of me... I knew I couldn't choose.
[cpg]

Right here, right now... It wasn't about not knowing which one was Shiori.
[cpg]

All I had to do was to trust Shiori, the one that smiled at me in the past.
[cpg]

;//このあと下の選択肢へ
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//EX選択肢が発生しない場合は今まで通り下記の選択肢が発生。下記のまま進行する

*j_n|Twins

Then, like a flash of lightning, a word passed through my mind.
[cpg]

A secret word that Shiori only told me...
[cpg]

That was...
[cpg]

;//■選択肢１６（３択）
[switch]
[case "Mi Soi Samus Ville"]
	[swap]
	[jump target="*s16_a"]
[case "Mi Tour Yamak Vish"]
	[swap]
	[jump target="*s16_b"]
[case "Mi Tui Amas Vin"]
	[swap]
	[jump target="*s16_c"]
[endswitch]
;//１，ミ　ソイ　サムス　ヴィル　　　　//１６aへ
;//２，ミ　トゥール　ヤマク　ヴィシュ　//１６bへ
;//３，ミ　トゥイ　アマス　ヴィン　　　//１６cへ
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１６a　ミ　ソイ　サムス　ヴィル
*s16_a|Twins
[OnName num="Kenji"]
"Mi Soi Samus Ville!"
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[FACE method="change_5" pos="4/5"]


[VOICE f="Vex006"]
[OnName num="Shiori_Kotoha"]
"Eh?"
[cpg cn=true]

Both of them looked surprised at the words I had shouted.
[cpg]

;//『ルートＧ』へ
[jump storage="ep022.ks" target="*start"]
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１６b　ミ　トゥール　ヤマク　ヴィシュ
*s16_b|Twins
[OnName num="Kenji"]
"Mi Tour Yamak Vish!"
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[FACE method="change_5" pos="4/5"]

[VOICE f="Vex007"]
[OnName num="Shiori_Kotoha"]
"Eh?"
[cpg cn=true]

Both of them looked surprised at the words I had shouted.
[cpg]

;//『ルートＧ』へ
[jump storage="ep022.ks" target="*start"]
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１６c　ミ　トゥイ　アマス　ヴィン
*s16_c|Twins


[OnName num="Kenji"]
"Mi Tui Amas Vin!"
[cpg cn=true]

I shouted with all my strength.
[cpg]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori668"]
[OnName num="Shiori"]
"Eh? What..., what's wrong? Kenj..."
[cpg cn=true]

Shiori was standing next to me with a puzzled look on her face, and then...
[cpg]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori669"]
[OnName num="Kotoha"]
"Felice Jin Al Vieー!"
[cpg cn=true]

[OnName num="Kenji"]
"You were...Kotoha?"
[cpg cn=true]

I shook off the hand I was holding and ran off to the real Shiori.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3" pos="4/5" time=800]

[OnName num="Kenji"]
"Shiori! Stay right there!"
[cpg cn=true]



[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori670"]
[OnName num="Shiori"]
"Kenji...!"
[cpg cn=true]

The hand of my Shiori reached out across the corridor.
[cpg]

But...
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shiori671"]
[OnName num="Kotoha"]
"I won't let you go!"
[cpg cn=true]

[SE f="se060"]
;//【ＳＥ】ギュゥゥ

[WAIT time=1000]

[OnName num="Kenji"]
"Let go of me!"
[cpg cn=true]

Kotoha clung to my waist and wouldn't let go.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori672"]
[OnName num="Kotoha"]
"You just love Shiori because you saw her first! If I was first, you would have fallen in love with me!"
[cpg cn=true]

[OnName num="Kenji"]
"Maybe you're right, but that doesn't change the fact that I love Shiori!"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori673"]
[OnName num="Kotoha"]
"What..., our grandfather, the doctor too... It's always Shiori! Shiori... Just because I'm not sick they say, but everybody's only interested in her!"
[cpg cn=true]

[VOICE f="Shiori1673"]
[OnName num="Kotoha"]
"But, at last I have found somebody I deserve more. I will not give you to her, Kenji!"
[cpg cn=true]


After Kotoha said that, she hugged me.
[cpg]

It was then that I felt sorry for Kotoha.
[cpg]

Oh, she was pitiful too...
[cpg]

[OnName num="Kenji"]
"No, Kotoha... I was attracted to her at first because I thought she was pretty, but now I love her heart."
[cpg cn=true]

[OnName num="Kenji"]
"Even though you look the same, you and Shiori are not the same. And don't you only love me for what I look like?"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori674"]
[OnName num="Kotoha"]
"What's wrong with that? Hearts and minds can change! Just like how Mom and Dad left us! Just like how Shiori betrayed me!"
[cpg cn=true]

[VOICE f="Shiori1674"]
[OnName num="Kotoha"]
"But I can keep your body, just as beautiful as it is now! Isn't that right, doctor?! We can keep Kenji's body healthy and beautiful forever, right?"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi559"]
[OnName num="Michi"]
"Kotoha... The reason why I only care about Shiori is not because she is sick... It was because I loved her kindness..."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori675"]
[OnName num="Kotoha"]
"W-what are you saying...? I've...spent my entire life locked away, not even going to school, all for her... So what's the difference?!"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi560"]
[OnName num="Michi"]
"That girl was traumatized by what you did. She was troubled, she was worried, she was always defending you..."
[cpg cn=true]

[VOICE f="Michi1560"]
[OnName num="Michi"]
"It was enough to give her PTSD, but you pretended not to notice it, killing animals and prioritizing your own desires..."
[cpg cn=true]


[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori676"]
[OnName num="Kotoha"]
"...!"
[cpg cn=true]

Michi's words caused Kotoha to wince slightly.
[cpg]

Taking advantage of the moment, I ran to Shiori.
[cpg]

[SE f="se022"]
;//【ＳＥ】ダッシュ

[free time=1000]
[WAIT time=1000]

[OnName num="Kenji"]
"Shiori!"
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_2" pos="2/3" time=800]

[VOICE f="Shiori677"]
[OnName num="Shiori"]
"Kenji..."
[cpg cn=true]

I held Shiori in my arms and made my way through the fire to the ground floor.
[cpg]

[SE f="se122"]
;//【ＳＥ】消防車のサイレン
[free time=1000]

The fire seemed to have risen around the landing, but downstairs there were no flames in the four corners.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_2" pos="1/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_2" pos="3/3" time=800]

[VOICE f="Erika555"]
[OnName num="Erika"]
"Kenji!"
[cpg cn=true]


[VOICE f="Yuna414"]
[OnName num="Yuna"]
"Kenji!"
[cpg cn=true]


[VOICE f="Syouko371"]
[OnName num="Syouko"]
"Thank God you're both okay!"
[cpg cn=true]


;//[BG f="black.ui" time=900]
;//[WAIT time=1500]
;//[BG f="b_l_1f_entrance_p4ex4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（火事）

;//[WAIT time=1500]
;//[BGM f="danger"]


[OnName num="Kenji"]
"Is there any way out? Where the walls are collapsing or breaking?"
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[FACE method="change_7" pos="2/3"]
[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna415"]
[OnName num="Yuna"]
"We couldn't find a way out anywhere..."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika556"]
[OnName num="Erika"]
"We're gonna burn to death..."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko372"]
[OnName num="Syouko"]
"Oh, we can't give up."
[cpg cn=true]

[OnName num="Kenji"]
"Damn it..."
[cpg cn=true]

[free time=1000]


But what to do, how can we get out of here when we couldn't get out in the first place?
[cpg]

That's when I looked up the stairs.
[cpg]

I'll need it, that's what she told me and gave me that key.
[cpg]

[OnName num="Kenji"]
"Michi ! This key... Michi?!"
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi561"]
[OnName num="Michi"]
"Let g-go of me, Kotoha! The fire...!
[cpg cn=true]


[VOICE f="Shiori678"]
[OnName num="Kotoha"]
"Doctor, don't leave me all alone! You have to love me as much as you love Shiori!"
[cpg cn=true]


[VOICE f="Michi562"]
[OnName num="Michi"]
"Aaaaahhh!"
[cpg cn=true]


[VOICE f="Shiori679"]
[OnName num="Kotoha"]
"Shioriiiiii! Don't forget me! You're me, and I'm you!"
[cpg cn=true]



[VOICE f="Shiori680"]
[OnName num="Shiori"]
"......!"
[cpg cn=true]


[SE f="se132"]
;//【ＳＥ】『火柱』

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4ex4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（火事）******************************************************

[WAIT time=1500]
;//[BGM f="danger"]


Kotoha and Michi screamed and a pillar of fire erupted at the same time, engulfing them.
[cpg]

I held Shiori's body tightly, protecting her ears and her heart from their screams...
[cpg]

[OnName num="Kenji"]
"N-no..."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori681"]
[OnName num="Shiori"]
"Uh...ugh..."
[cpg cn=true]

Michi, who had been her rock, was gone and her mind went blank.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika557"]
[OnName num="Erika"]
"What are we going to do, Kenji?!"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna416"]
[OnName num="Yuna"]
"Cough...cough..."
[cpg cn=true]

[OnName num="Kenji"]
"Everybody, get down!"
[cpg cn=true]

I told everyone, because the only thing I knew was that it wasn't good to breathe in smoke.
[cpg]

But the clock was ticking.
[cpg]

[OnName num="Kenji"]
"Shiori, have you ever seen this key before?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori682"]
[OnName num="Shiori"]
"Uh... I wonder what it opens. I don't know, but...it was your grandfather's."
[cpg cn=true]

Then, I looked at the key and saw that it was engraved with some kind of pattern.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika558"]
[OnName num="Erika"]
"It's just a key to his study or something! It doesn't matter!"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori683"]
[OnName num="Shiori"]
"No, you're wrong. I could tell if it was to one of my grandfather's rooms... So this must be for something else."
[cpg cn=true]

There's not much that Shiori doesn't know about her beloved grandfather.
[cpg]

Still, she didn't seem to know about this key. But Michi gave it to me. So it had to be to something.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko373"]
[OnName num="Syouko"]
"Please r-remember!"
[cpg cn=true]

The fire was spreading all around. As the smoke filled the room, it seemed to be moving in a strange way.
[cpg]

[OnName num="Kenji"]
"What? The smoke...?"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna417"]
[OnName num="Yuna"]
''Wind? Maybe the air is flowing? Cough, cough..."
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika559"]
[OnName num="Erika"]
"There's nothing over there, is there?"
[cpg cn=true]

This reminded me of the blueprints I had seen of the building.
[cpg]

I thought the library had many strange spaces and gaps.
[cpg]

Maybe this key is...
[cpg]

[OnName num="Kenji"]
"Everyone, look over there! Check the walls and floors! We might be able to get out of here somewhere!"
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko374"]
[OnName num="Syouko"]
"What are you talking about?"
[cpg cn=true]

[OnName num="Kenji"]
"I don't have time to explain! We need to find a place that looks off! There's got to be a keyhole!"
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika560"]
[OnName num="Erika"]
"A keyhole? You mean like to a door? I told you we didn't find anything!"
[cpg cn=true]

Everyone was anxious, getting impatient, and starting to panic. But they were still doing their best to find something like I described.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna418"]
[OnName num="Yuna"]
"...! H-here! There's a draft!"
[cpg cn=true]

Yuna raised her voice as she hit the floor of the dead-end passage.
[cpg]

But, it was just a tiled floor. There was no keyhole.
[cpg]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko375"]
[OnName num="Syouko"]
"That's not a door, is it?"
[cpg cn=true]

We could all see that, but Shoko still decided to state the obvious.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika561"]
[OnName num="Erika"]
"We don't have time for this!"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna419"]
[OnName num="Yuna"]
"Aah..."
[cpg cn=true]

With a thud, I kicked the floor.
[cpg]

Thud...
[cpg]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna420"]
[OnName num="Yuna"]
"Did the tiles...just move?"
[cpg cn=true]

The floor moved slightly as Erika struck it in anger.
[cpg]

;//＠
[free time=1000]
;**【ＣＧ】ev_05_0 ***********************
[CG id=04 index=0 time=1000]
;*****************************************
[WAIT time=1000]


[VOICE f="Shiori684"]
[OnName num="Shiori"]
"This...looks like the puzzles that Grandfather used to do..."
[cpg cn=true]

I didn't think any part of that pattern looked like it was from a puzzle.
[cpg]


[VOICE f="Yuna421"]
[OnName num="Yuna"]
"There might be a room underneath where we can take shelter."
[cpg cn=true]


[VOICE f="Syouko376"]
[OnName num="Syouko"]
"R-really? We'll be saved?"
[cpg cn=true]


[VOICE f="Erika562"]
[OnName num="Erika"]
"But it's a puzzle, isn't it? Can we solve it? Do we have time for that?"
[cpg cn=true]

[OnName num="Kenji"]
"Shiori, what do you think? Can you solve it?"
[cpg cn=true]

Shiori looked down at the puzzle, turning and moving the tiles.
[cpg]

[STOPBGM]

[VOICE f="Shiori685"]
[OnName num="Shiori"]
"I'm sorry..."
[cpg cn=true]

But then her hand stopped.
[cpg]


[VOICE f="Shiori686"]
[OnName num="Shiori"]
"I don't think I'll be able to solve it like this..."
[cpg cn=true]

[BGM f="serious"]

Apparently there was a missing part. And no one had it.
[cpg]


[VOICE f="Erika563"]
[OnName num="Erika"]
"Haha... You're kidding?... Here, in this place..."
[cpg cn=true]


[VOICE f="Yuna422"]
[OnName num="Yuna"]
"...cough, cough...ugh, uugghh."
[cpg cn=true]


[VOICE f="Syouko377"]
[OnName num="Syouko"]
"We're...done for, aren't we?"
[cpg cn=true]

The strength drained from my body. What little hope I had left was gone.
[cpg]

Death was close at hand.
[cpg]


[VOICE f="Erika564"]
[OnName num="Erika"]
"Ugh...ugh..."
[cpg cn=true]

[free time=1000]
[BG f="b_l_1f_entrance_p4ex4.ui" time=1000]
[WAIT time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori687"]
[OnName num="Shiori"]
"Cough...cough..."
[cpg cn=true]

[OnName num="Kenji"]
"Shiori..."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori688"]
[OnName num="Shiori"]
"Ken...ji..."
[cpg cn=true]


We all crouched down and huddled together, desperate to escape the smoke.
[cpg]

Was it really the end...? Was this it?
[cpg]

Of course not, this couldn't be it.
[cpg]

I made a vow. To this girl trembling in my arms...
[cpg]

She was so fragile that it was as if she could disappear in a puff of smoke someday.
[cpg]

[OnName num="Kenji"]
"I'll p-protect you..."
[cpg cn=true]

[free time=1000]

Dragging my heavy body, I crawled forward.
[cpg]

The entrance was covered with rubble and the area around it looked terrible.
[cpg]

But thanks to that, what we needed was close at hand.
[cpg]

[OnName num="Kenji"]
"Pant...pant..."
[cpg cn=true]

I lugged a piece of iron, which felt heavier than anything I normally carried, towards the wall.
[cpg]

I picture the blueprints in my mind.
[cpg]

The house had been enlarged and renovated, and the building had some weak points.
[cpg]

And the walls should have taken on some damage from the fire.
[cpg]

However, I didn't think that the strength of one dying person would do it.
[cpg]

;//叩く
[SE f="se085"]
;//【ＳＥ】『叩く』

But...still...
[cpg]

[OnName num="Kenji"]
"Break!"
[cpg cn=true]

;//叩く
[SE f="se085"]
;//【ＳＥ】『叩く』
But...!
[cpg]

[OnName num="Kenji"]
"Break!!"
[cpg cn=true]

;//叩く
[SE f="se085"]
;//【ＳＥ】『叩く』
But...!
[cpg]

[OnName num="Kenji"]
"Breeaakkk!!!"
[cpg cn=true]

;//叩く
[SE f="se085"]
;//【ＳＥ】『叩く』
But...!
[cpg]

[OnName num="Kenji"]
"Break damn it!!!!!"
[cpg cn=true]

[STOPBGM]

;//叩く
[SE f="se085"]
;//【ＳＥ】『叩く』

[WAIT time=3000]

;//壁が崩れる
[SE f="se115"]
;//【ＳＥ】『壁が崩れる』

[WAIT time=3000]

God made a really small..., small hole in the ground.
[cpg]

;//モーニングスター落とす
[SE f="se127"]
;//【ＳＥ】『モーニングスター落とす』

[WAIT time=3000]

At this size, a small girl might be able to fit through the hole.
[cpg]

;//＠
[BGM f="op"]

[OnName num="Kenji"]
"Pant, pant... Shiori..."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori689"]
[OnName num="Shiori"]
"Uh... Kenji..."
[cpg cn=true]

Bending down, I crawled my way to Shiori.
[cpg]

She too was too out of it to reply properly.
[cpg]

[OnName num="Kenji"]
"Pant, pant... It'll be okay, I'll definitely...save you..."
[cpg cn=true]

I dragged Shiori towards the hole.
[cpg]

[OnName num="Kenji"]
"Shiori, hang in there, I'm sure you'll make it out."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori690"]
[OnName num="Shiori"]
"Ugh..."
[cpg cn=true]

I was going to push her into that hole.
[cpg]

[OnName num="Kenji"]
"Shiori, hang in there...don't die."
[cpg cn=true]

[OnName num="Kenji"]
"I want to go somewhere, just the two of us... Let's go on a date...so, please, hang on."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori691"]
[OnName num="Shiori"]
"Ngh... Ugh."
[cpg cn=true]

In response to my voice, Shiori also moved her arms and legs.
[cpg]

Drag...drag...drag...
[cpg]

[free time=2000]
[WAIT time=1000]

Little by little, Shiori's body went through the hole in the wall. And then...
[cpg]


[VOICE f="Shiori692"]
[OnName num="Shiori"]
"Hah, hah... Uh..., Kenji...?"
[cpg cn=true]

[OnName num="Kenji"]
"Good, Shiori. You made it out."
[cpg cn=true]

Shiori managed to get out. Ah, that's great. That's really great.
[cpg]

But it wasn't over yet.
[cpg]

;//一度場面切り替え
[FG f="CHA03_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_4" pos="3/3" time=800]

I was desperate. I was determined. Erika, Yuna, Shoko were too.
[cpg]

[free time=2000]
[WAIT time=1000]
I dragged them out as well, and with the help of Shiori from the outside, I managed to get the three of them out.
[cpg]

[OnName num="Kenji"]
"Good, now everyone is..."
[cpg cn=true]


[VOICE f="Shiori693"]
[OnName num="Shiori"]
"Kenji! Kenji, come on!"
[cpg cn=true]

[OnName num="Kenji"]
"No, I...won't fit."
[cpg cn=true]

I knew that from the start. That a man of my size would not be able to fit through.
[cpg]

I knew it. But it's okay. Everyone... Shiori could be saved.
[cpg]

[OnName num="Kenji"]
"Hurry, you need to get away from here. The house is falling apart."
[cpg cn=true]


[VOICE f="Shiori694"]
[OnName num="Shiori"]
"No! No! I have to leave with you, Kenji!"
[cpg cn=true]

[OnName num="Kenji"]
"I'm sorry, Shiori..."
[cpg cn=true]

[STOPBGM]

;//＠
[SE f="se119"]
;//【ＳＥ】火が燃える音

;//[WAIT time=7000]
;//[SE f="se000"]
;//【ＳＥ】瓦礫が崩れてくる
;//[WAIT time=4000]


;//＠
;//エフェクト
[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=500]
[WAIT time=3600]
[BG f="black.ui" time=100]
[WAIT time=200]
[transition target={false} color={0x000000ff} time=100]
[WAIT time=200]
;//ブラックアウト

[WAIT time=4000]

;//サイレン
[SE f="se122"]
;//【ＳＥ】『サイレン』

[WAIT time=3000]

[window target=true]

I didn't know what was going on..., but it was so loud.
[cpg]

And it hurts all over.
[cpg]

It hurts? Why...?
[cpg]

;//目をさます
;//エフェクト
[window target=false]
[transition target={true} color={0x000000ff} time=100]
[WAIT time=100]

;//＠
[free time=1000]
;**【ＣＧ】ev_16_0 ***********************
[CG id=15 index=0 time=1000]
;*****************************************

;//[BG f="b_o_iw_p2.ui" time=100]
;//【ＢＧ】その他・森の中　昼
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=3000]
[WAIT time=4100]
[window target=true]

[BGM f="dod"]

[OnName num="Kenji"]
"U-ugh..."
[cpg cn=true]


[VOICE f="Erika565"]
[OnName num="Erika"]
"Kenji!!!"
[cpg cn=true]


[VOICE f="Syouko378"]
[OnName num="Syouko"]
"It's Kenji! He's awake!"
[cpg cn=true]

When I woke up, I was outside the building on a stretcher.
[cpg]

[OnName num="Kenji"]
"Ugh, ah...I...am..."
[cpg cn=true]


[VOICE f="Yuna423"]
[OnName num="Yuna"]
"The firemen rescued you."
[cpg cn=true]

After I had lost consciousness, they told the firefighters where I was.
[cpg]

They opened the hole in the wall and widened it enough for me to get through, and then they rescued me.
[cpg]


[VOICE f="Shiori695"]
[OnName num="Shiori"]
"Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"Shiori..."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori696"]
[OnName num="Shiori"]
"Ugh...ugh...... I'm glad, I'm so glad..."
[cpg cn=true]

Shiori was sobbing on my chest. I patted her head.
[cpg]

It wasn't a dream. Shiori and I, we're alive.
[cpg]


[VOICE f="Erika566"]
[OnName num="Erika"]
"Oh..., it's snowing..."
[cpg cn=true]

[free time=2000]
;//[BG f="b_o_sky_p5.ui" time=2000]


White snow fell from the sky, covering Tokita Library with a thin layer of snow.
[cpg]

;//サイレン
[SE f="se122"]
;//【ＳＥ】『サイレン』


The sound of a fire engine.
[cpg]

Everyday life was just around the corner. At last, the extraordinary comes to an end.
[cpg]

[OnName num="Kenji"]
"It's over... Everything is over..."
[cpg cn=true]



;//エンドロール
;//＠
{
	tf["root_d_flag"] <- true;
}

[jump storage="epend.ks" target="*jump_ending"]


*root_d_end|Twins



[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_o_poli_p2.ui" time=1500]
;//【ＢＧ】その他・警察　取調室　昼******************************************************

[WAIT time=2500]

[window target=true]


[BGM f="serious"]


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori697"]
[OnName num="Shiori"]
"Yes... I'll tell you everything... At that time..."
[cpg cn=true]

;//＠
;//栞の独白に合わせて殺害シーングラ×２

;**【ＣＧ】ci_01_0 ***********************
;//カットイン
[CUTIN f="img/cg/ci_01_0.webp" show={true}]
;*****************************************
[WAIT time=1000]


[move from="2/3" to="1/4" ease="easeInOutSine" time=2000]

[WAIT time=2000]


[FACE method="change_7" pos="1/4"]

[WAIT time=100]
[VOICE f="Shiori698"]
[OnName num="Shiori"]
"I had rejected his confession and as I was going upstairs..., Takagi hugged me from behind on the landing..."
[cpg cn=true]

[FACE method="change_7" pos="1/4"]
[WAIT time=100]
[VOICE f="Shiori699"]
[OnName num="Shiori"]
"My sister then stabbed him in the back... Takagi fell forward and slid down the stairs."
[cpg cn=true]

[FACE method="change_7" pos="1/4"]
[WAIT time=100]
[VOICE f="Shiori700"]
[OnName num="Shiori"]
"My sister looked at him and laughed, saying he looked like a sea lion..."
[cpg cn=true]

[CUTIN f="img/cg/ci_01_0.webp" show={false}]

[WAIT time=3000]

;**【ＣＧ】ci_02_0 ***********************
;//カットイン
[CUTIN f="img/cg/ci_02_0.webp" show={true}]
;*****************************************
[WAIT time=1000]



;//[BG f="b_o_poli_p2.ui" time=1000]

[FACE method="change_7" pos="1/4"]
[WAIT time=100]
[VOICE f="Shiori701"]
[OnName num="Shiori"]
"Then with Hosokawa..., my sister found out that the doctor was about to be attacked, and she took her keys and the ointment the doctor had used to treat your injuries, Kenji. Then she went to visit him late at night..."
[cpg cn=true]

[FACE method="change_7" pos="1/4"]
[WAIT time=100]
[VOICE f="Shiori702"]
[OnName num="Shiori"]
"The ointment was made with peanut oil..."
[cpg cn=true]

[FACE method="change_7" pos="1/4"]
[WAIT time=100]
[VOICE f="Shiori703"]
[OnName num="Shiori"]
"Hosokawa had been allergic and went into anaphylactic shock..."
[cpg cn=true]

[FACE method="change_7" pos="1/4"]
[WAIT time=100]
[VOICE f="Shiori704"]
[OnName num="Shiori"]
"Their bodies were...cut up in the middle of the night by the doctor and removed by...me and my sister..."
[cpg cn=true]

[CUTIN f="img/cg/ci_02_0.webp" show={false}]

[move from="1/4" to="2/3" ease="easeInOutSine" time=1000]

[WAIT time=1000]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori705"]
[OnName num="Shiori"]
"I...cough, cough! Sorry... I have asthma and a heart condition..."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori706"]
[OnName num="Shiori"]
"I am sick..., and my sister has a twisted mind..."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori707"]
[OnName num="Shiori"]
"We were born twins...and we were each born with something wrong with us..."
[cpg cn=true]

;//祖父の机にあった２枚の写真


[STOPBGM]

;//＠
;//ホワイトアウト

;//ロングエフェクト
[window target=false]
[free time=4000]
[BG f="white.ui" time=4000]
[WAIT time=6000]
[window target=true]

Time has passed since then...
[cpg]

After a series of major seizures, Shiori gradually regained her composure.
[cpg]

She started to go out into the world with me, and after a few years of gradually gaining strength, she underwent a successful heart transplant operation, and we were married with the blessing of many people.
[cpg]


[WAIT time=1500]
[BG f="b_o_nh_p2.ui" time=1000]
;//【ＢＧ】その他・新居　昼******************************************************

[WAIT time=1500]

[BGM f="sys"]

[WAIT time=1500]

;//幼稚園くらいの双子
[free time=1000]
;**【ＣＧ】ev_17_0 ***********************
[CG id=16 index=0 time=1000]
;*****************************************

[WAIT time=1000]

[VOICE f="Vex008"]
[OnName num="Kotoko"]
"That toy is mine..."
[cpg cn=true]

[VOICE f="Vex009"]
[OnName num="Miku"]
"Then..., let me borrow it later..."
[cpg cn=true]

[OnName num="Kenji"]
"Miku is so kind. Kotoko, play nice."
[cpg cn=true]

[VOICE f="Vex010"]
[OnName num="Kotoko"]
"Yes... Miku, let's play together."
[cpg cn=true]

[VOICE f="Vex011"]
[OnName num="Miku"]
"Yes!"
[cpg cn=true]

Shiori and I have twins, and are living our happily ever after, as if the incident never happened.
[cpg]


[VOICE f="Shiori708"]
[OnName num="Shiori"]
"Those two look so much alike..."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, they do..."
[cpg cn=true]

But of course, even though they were twins, as soon as they started to speak, we started to notice the differences in their personalities.
[cpg]

Just like Shiori and Kotoha...
[cpg]

The incident has not been erased from our minds, and even now Shiori sometimes has nightmares about it.
[cpg]

[BG f="b_o_nh_p2.ui" time=1000]
;//【ＢＧ】空

[VOICE f="Shiori709"]
[OnName num="Shiori"]
"I had a nightmare again... This time, I saw you and my sister behind the fire..."
[cpg cn=true]

[OnName num="Kenji"]
"Speaking of which..."
[cpg cn=true]

I've never been able to ask her about something before.
[cpg]

It's not that I couldn't ask, it's that I hesitated to bring it up.
[cpg]

[OnName num="Kenji"]
"What did those magic words mean?"
[cpg cn=true]

When I suddenly asked, Shiori answered with a small smile.
[cpg]


[VOICE f="Shiori710"]
[OnName num="Shiori"]
"Mi Tui Amas Vin means 'I love you'. Felice Jin Al Vie means 'I wish you all the happiness'."
[cpg cn=true]

[OnName num="Kenji"]
"Oh..., I see..."
[cpg cn=true]

After reading "The World of Fantasia", I remembered that those words were exchanged between the knight and the princess.
[cpg]

That book is still being published regularly, and I hope that one day my daughters will be able to read it.
[cpg]

[free time=1000]
;**【ＣＧ】ev_17_0 ***********************
[CG id=16 index=0 time=1000]
;*****************************************

[WAIT time=1000]

[VOICE f="Vex012"]
[OnName num="Kotoko"]
"So, Miku is the cat and I'm the mother."
[cpg cn=true]

[VOICE f="Vex013"]
[OnName num="Miku"]
"Okay... Meow-meow..."
[cpg cn=true]


[VOICE f="Shiori711"]
[OnName num="Shiori"]
"No... Why a cat?"
[cpg cn=true]

[OnName num="Kenji"]
"Hahaha..."
[cpg cn=true]

To the outside world, my family probably seemed like a happy family with no problems.
[cpg]

But I've noticed...
[cpg]

[SE f="se128"]
;//【ＳＥ】爪を噛む


[VOICE f="Vex014"]
[OnName num="Kotoko"]
".................."
[cpg cn=true]

[OnName num="Kenji"]
Stop biting your nails, Kotoko...
[cpg cn=true]

Only one of the twins has developed the habit of biting their nails...
[cpg]

[VOICE f="Vex015"]
[OnName num="Miku"]
"Daddy, you know... I love you, Daddy..."
[cpg cn=true]

[VOICE f="Vex016"]
[OnName num="Kotoko"]
"I love you, too!"
[cpg cn=true]


[VOICE f="Shiori712"]
[OnName num="Shiori"]
"Why do you both love your dad so much?"
[cpg cn=true]

[VOICE f="Vex017"]
[OnName num="Miku_Kotoko"]
"Because he's handsome!"
[cpg cn=true]

Some day...
[cpg]

Maybe one day these kids will kill me...
[cpg]

;//【ＢＧ】ブラックアウト
[free time=1500]
[BG f="black.ui" time=1500]
[WAIT time=3500]

[stopse g=1]
;//ボイス
[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

[system end3=true]
[SCENE id=19]
;//ＥＮＤ『双子』
;**【ＥＮＤ】　　　　********************************
[jump storage="epend.ks" target="*back_title"]
;****************************************************

;//THE END


;// 
;//＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
