*start
;#################################################
*Ep016|One Thing After Another
;#################################################
[SCENE id=10]

[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 25th
[cpg]

The day after Erika died...
[cpg]

We had another serious problem.
[cpg]



[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[BGM f="huan"]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="5/5" time=800]
[WAIT time=1500]
[VOICE f="Syouko173"]
[OnName num="Syouko"]
“There’s no water…”
[cpg cn=true]

[OnName num="Kenji"]
“What…?”
[cpg cn=true]

Apparently, the water pipe had frozen over and no water would come out when the faucet was turned on.
[cpg]

This was a death sentence: our lifeline had been cut off.
[cpg]

If we had water, we could have survived for several weeks.
[cpg]

Having no water meant, we would die.
[cpg]

[FACE method="change_4" pos="5/5"]
[WAIT time=100]
[VOICE f="Yuna268"]
[OnName num="Yuna"]
“We're all going to die… We're all going to die here…”
[cpg cn=true]

Not having the energy to stand up, Yuna couched down and stared intently, mumbling repeatedly to herself.
[cpg]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Syouko174"]
[OnName num="Syouko"]
"Yuna, are you okay? Please be careful!"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi380"]
[OnName num="Michi"]
“This is a little dangerous. Yuna, let’s go to the infirmary…”
[cpg cn=true]

[move from="2/3" to="4/5" ease="easeInOutSine" time=1000]
[WAIT time=1000]

[FACE method="change_3" pos="5/5"]
[WAIT time=100]
[VOICE f="Yuna269"]
[OnName num="Yuna"]
"Don't touch me!"
[cpg cn=true]

[SE f="se085"]
;//【ＳＥ】叩く

[FACE method="change_5" pos="4/5"]
[WAIT time=1]

[move from="4/5" to="2/3" ease="easeInOutSine" time=1000]
[WAIT time=1000]


Yuna pushed away Michi's hand as she reached out to her, and when she opened her eyes, she screamed out loud.
[cpg]

[FACE method="change_3" pos="5/5"]
[WAIT time=100]
[VOICE f="Yuna270"]
[OnName num="Yuna"]
"Stay away from me, murderers! I already know you all did it!"
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】ダッシュ
[move from="5/5" to="6/3" ease="easeInOutSine" time=1000]

[WAIT time=1000]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Syouko175"]
[OnName num="Syouko"]
"Ah! Yuna!"
[cpg cn=true]

[move from="1/3" to="5/3" ease="easeInOutSine" time=1000]
[SE f="se022"]
;//【ＳＥ】ダッシュ

Yuna suddenly started running and Shoko followed after her.
[cpg]

Left behind, Shiori, Michi, and I stood there speechless.
[cpg]

That same Yuna, who had always been quiet…
[cpg]

Who was smart, kind, and serious. I couldn't believe how possessed she looked or that she would yell in such a loud voice.
[cpg]

They say that people show their true colors when they are cornered, but did that mean these were Yuna's true colors?
[cpg]

I just couldn't believe it.
[cpg]

[SE f="se037"]
;//【ＳＥ】腹が鳴る

[WAIT time=1000]

Even at this moment, my rumbling stomach was bothering me, and when pressed, my hand actually sank in.
[cpg]

My stomach felt empty and prickly.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Shiori311"]
[OnName num="Shiori"]
"Kenji… thinks I'm a murderer too…?"
[cpg cn=true]

Perhaps hearing Yuna's words, Shiori had asked me.
[cpg]

[OnName num="Kenji"]
"Yuna's going a little crazy."
[cpg cn=true]

I thought about it after the words left my mouth.
[cpg]

I thought it was impossible for Shiori, who was small and lacked the arm strength, to kill a large man.
[cpg]

However, Yuna's words and actions since yesterday had raised the possibility of there being an accomplice.
[cpg]

If Michi was an accomplice, then Shiori could have committed the crime...
[cpg]

I shuddered at the thought.
[cpg]

What the hell was I thinking?
[cpg]

I couldn't believe that I would consider someone I love to be a criminal, even hypothetically.
[cpg]

I wondered if I was going crazy because I was so hungry.
[cpg]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi381"]
[OnName num="Michi"]
"I wonder where they went… I'll go check it out."
[cpg cn=true]

[SE f="se006"]
;//【ＳＥ】歩き去る

[move from="2/3" to="6/4" ease="easeInOutSine" time=1000]

[WAIT time=1500]
[FACE method="change_1" pos="1/3"]
[WAIT time=1]
[move from="1/3" to="2/3" ease="easeInOutSine" time=1000]
[WAIT time=100]
[VOICE f="Shiori312"]
[OnName num="Shiori"]
"We could go look at some books..."
[cpg cn=true]

[OnName num="Kenji"]
“Yeah.”
[cpg cn=true]

Once Michi had gone, Shiori and I went into the general collection room.
[cpg]

[STOPBGM]
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）******************************************************

[WAIT time=1500]

[BGM f="dod"]


[FG f="CHA01_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori313"]
[OnName num="Shiori"]
"Kenji… Here, take this…."
[cpg cn=true]

[OnName num="Kenji"]
“Thanks.”
[cpg cn=true]

Shiori brought me a copy of "The World of Fantasia", which I had been reading.
[cpg]

[OnName num="Kenji"]
"Huh?"
[cpg cn=true]

When I took it from her, I casually looked at Shiori's nails and saw that they were well groomed.
[cpg]

[OnName num="Kenji"]
"Did you cut your nails?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori314"]
[OnName num="Shiori"]
“My nails…? Ah…, last night…”
[cpg cn=true]

[OnName num="Kenji"]
"Oh."
[cpg cn=true]

Nail biting is a bad habit, it must be hard to take care of her nails on a regular basis.
[cpg]

If she keeps doing that, won’t they just keep getting shorter and shorter until they’re down to the nail bed?
[cpg]

[SE f="se037"]
;//【ＳＥ】腹が鳴る

[WAIT time=1000]

[OnName num="Kenji"]
“Ah…. Not Again.”
[cpg cn=true]

"........."
[cpg]

My stomach growled loudly, and I tried to hide it, but it was too late.
[cpg]

[OnName num="Kenji"]
“Ah~, I’m woozy…”
[cpg cn=true]

I was hungry and dizzy.
[cpg]

My stomach and head were so upset that I couldn't even drink water.
[cpg]

"........."
[cpg]

Looking a little worried, Shiori stood up, holding the book she gave me in her hand again.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori315"]
[OnName num="Shiori"]
“Let’s read…, In my room…”
[cpg cn=true]

[OnName num="Kenji"]
“Huh? Ah, yeah!”
[cpg cn=true]

I thought she might be inviting me up.
[cpg]

I wanted to hug Shiori for as long as I could, even if it was just for a minute or a second, maybe she felt the same way.
[cpg]

[OnName num="Kenji"]
"Let's go."
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[SE f="se107"]
;//【ＳＥ】歩く×２

[WAIT time=1500]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori316"]
[OnName num="Shiori"]
“Ah…, wait…”
[cpg cn=true]

When she reached the middle of the stairs, Shiori stopped.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori317"]
[OnName num="Shiori"]
"There are no more candles in my room… I have to go get some…"
[cpg cn=true]

After she remembered, she started to head down the stairs.
[cpg]

[OnName num="Kenji"]
“Yeah, I'll go get some then.”
[cpg cn=true]

I volunteered to go to the basement.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori318"]
[OnName num="Shiori"]
“Well, I'll go upstairs… I’ll wait for you in my room..”
[cpg cn=true]

[OnName num="Kenji"]
“Yeah!”
[cpg cn=true]

[SE f="se069"]
;//【ＳＥ】小走り

;//エフェクト
[window target=false]
[transition target={true} rule="108.jpg" color={0x000000ff} time=2000]
[WAIT time=2100]
;//※以下、栞の部屋のシーンでは栞はコトハ
[free time=100]
[BG f="black.ui" time=100]
[WAIT time=200]
[BG f="b_l_2f_ros_0.ui" time=100]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************
[WAIT time=2000]
[transition target={false} rule="108.jpg" color={0x000000ff} time=2000]
[WAIT time=3000]
[window target=true]


[OnName num="Kenji"]
“Thanks for waiting.”
[cpg cn=true]

[SE f="se136"]
;//【ＳＥ】ドア開ける

When I entered Shiori's room with a candle I had taken from the basement, she was sitting on a chair.
[cpg]

As I moved the candle from its previous position and set it down next to me to provide light, Shiori approached me, looking rather happy.
[cpg]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori319"]
[OnName num="Shiori"]
“Here…”
[cpg cn=true]

[OnName num="Kenji"]
“Huh, what's this?”
[cpg cn=true]

When I saw what Shiori put in my palm, I couldn't hide my surprise.
[cpg]

[OnName num="Kenji"]
“Is this?!”
[cpg cn=true]

There wasn’t supposed to be any food left.
[cpg]

There was a can of spam in my hand.
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori320"]
[OnName num="Shiori"]
"Please eat this. In return, don't tell anyone…"
[cpg cn=true]

[OnName num="Kenji"]
"Where did you get this…?"
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori321"]
[OnName num="Shiori"]
"I saved some leftovers from dinner…It's for you, Kenji."
[cpg cn=true]

[OnName num="Kenji"]
“I appreciate it, but......”
[cpg cn=true]

I wanted to eat so badly that I was drooling.
[cpg]

But, the others were probably just as hungry as I was.
[cpg]

It would be a bad idea for me to eat this alone.
[cpg]

[OnName num="Kenji"]
“I can't be the only one eating. It wouldn’t be fair to everyone.”
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori322"]
[OnName num="Shiori"]
"Kenji, you're bigger than the rest of us, and you need more calories, right? Besides… I would be sad to see you lose weight..."
[cpg cn=true]

Shiori put her finger on the pull tab of the spam can as she spoke.
[cpg]

[SE f="se031"]
;//【ＳＥ】缶開ける

[OnName num="Kenji"]
“Fwuah~”
[cpg cn=true]

As soon as the lid of the can was opened, the smell of food entered my nose.
[cpg]

By the time it reached my brain, I was already...
[cpg]

[OnName num="Kenji"]
"Munch! Gobble gobble! It's so good!"
[cpg cn=true]

I gobbled up the spam like a dog.
[cpg]

;//エフェクト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=2100]
[free time=100]
[BG f="black.ui" time=100]
[WAIT time=200]
[BG f="b_l_2f_ros_0.ui" time=100]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************
[WAIT time=2000]
[transition target={false} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=3100]
[window target=true]

[OnName num="Kenji"]
"Phew~"
[cpg cn=true]

;//コトハ
[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori323"]
[OnName num="Shiori"]
“Was it good…?”
[cpg cn=true]

[OnName num="Kenji"]
“Yeah, thanks. That helped a lot.”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

The canned food was small, but it was enough to satisfy my appetite.
[cpg]

However, despite appeasing my appetite and my stomach, I felt guilty as soon as I finished eating.
[cpg]

I was trying to think of everyone else, but I ended up eating it all by myself.
[cpg]

I wondered what kind of face I should make when I went downstairs.
[cpg]

[free time=1000]


I turned my back to Shiori and looked into the mirror, not wanting her to know that I had hesitated but ended up gobbling up the food, and that even though I had eaten it, I was still conflicted about it.
[cpg]

Then I saw Shiori in the mirror, staring at my back as I sat in my chair.
[cpg]

;//鏡に映り込んだ栞の口がニッと歪む


[OnName num="Kenji"]
“...?!”
[cpg cn=true]

For a moment, I thought I saw Shiori raise the corner of her mouth and smirk.
[cpg]

It was the first time that I saw such a look on Shiori’s face...
[cpg]

;//コトハ

[VOICE f="Shiori324"]
[OnName num="Shiori"]
“Are you finished with the can…?”
[cpg cn=true]


;//[free time=900]
;//[BG f="black.ui" time=900]
;//[WAIT time=1500]
;//[BG f="b_l_2f_ros_0.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

;//[WAIT time=1500]

When I turned around, I saw that Shiori was about to leave the room with the can I had finished eating.
[cpg]

[OnName num="Kenji"]
“Where are you going?”
[cpg cn=true]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori325"]
[OnName num="Shiori"]
"There's a trash chute in the security room, I'm just going to throw it away there… Stay here…"
[cpg cn=true]

[OnName num="Kenji"]
"Oh, yeah, okay."
[cpg cn=true]

[SE f="se009"]
;//【ＳＥ】ドア開く

It was just as Shiori was about to open the door and step out into the hallway...
[cpg]

[STOPBGM]

[VOICE f="Michi382"]
[OnName num="Michi"]
“Stopー!!”
[cpg cn=true]

From downstairs, I heard a strange voice..
[cpg]

[BGM f="danger"]

[FACE method="change_5" pos="2/3"]

[OnName num="Kenji"]
“W-what?!”
[cpg cn=true]

;//コトハ
[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori326"]
[OnName num="Shiori"]
“Isn’t that the doctor?!”
[cpg cn=true]


[VOICE f="Syouko176"]
[OnName num="Syouko"]
“Kyaー!!”
[cpg cn=true]

[OnName num="Kenji"]
“Shoko too?! I have to go!!”
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】ダッシュ
I made a mad dash down the hallway and ran down the stairs.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）******************************************************

[WAIT time=1500]



[WAIT time=100]
[VOICE f="Michi383"]
[OnName num="Michi"]
“What do you think would happen if you did that?!"
[cpg cn=true]


[VOICE f="Syouko177"]
[OnName num="Syouko"]
“Please stop!!”
[cpg cn=true]

[OnName num="Kenji"]
“Over there!"
[cpg cn=true]

As I came near the entrance, I could hear voices coming from the general collection room, and I quickly jumped in.
[cpg]


[BG f="b_l_1f_nbr_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　夜（暗）******************************************************

[WAIT time=1500]


Then...
[cpg]

;//[SE f="se084"]
;//【ＳＥ】本、切り裂く


[free time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna271"]
[OnName num="Yuna"]
“Don’t come any closerー!!”
[cpg cn=true]

There was Yuna, holding a lighter in one hand while using the other to cut up books with a utility knife, while Michi and Shoko were panicking from a distance, unable to get closer.
[cpg]

[OnName num="Kenji"]
“What the hell are you doing?”
[cpg cn=true]

[free time=1]
[WAIT time=1]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi384"]
[OnName num="Michi"]
''I was trying to convince Yuna to go into the pantry, but she suddenly took a lighter and a cutter and started waving them around!"
[cpg cn=true]

[VOICE f="Syouko178"]
[OnName num="Syouko"]
“She's trying to set books on fire!”
[cpg cn=true]

[OnName num="Kenji"]
"What?! Why are you doing that?!"
[cpg cn=true]

Even though I understood what was happening, I couldn't understand why she was doing it.
[cpg]

However, it was Yuna who explained herself.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna272"]
[OnName num="Yuna"]
"I'm going to die…! I'm going to freeze to death, so I'm building a bonfire! Because I'm cold… I'm cold, I'm coldー!"
[cpg cn=true]

[VOICE f="Yuna1272"]
[OnName num="Yuna"]
“I'm going to die if I don't burn books to keep warm. I don't want to die… It's cold, cold, cold! I have to build a fire! I have to build a fireー!”
[cpg cn=true]


[move from="2/3" to="2/5" ease="easeInOutSine" time=800]

;//※以下、栞は栞（本物）
[FG f="CHA01_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Shiori327"]
[OnName num="Shiori"]
“Stopー!!”
[cpg cn=true]

[OnName num="Kenji"]
“...!!”
[cpg cn=true]

Shiori, who arrived much later than I did, screamed at the sight of this outrageous scene.
[cpg]

Nothing could be done, as her precious books were being torn apart in front of her eyes.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna273"]
[OnName num="Yuna"]
"I'm cold! Cold! I'm cold, cold, cold!"
[cpg cn=true]

[SE f="se084"]
;//【ＳＥ】本、ザクザク切る
[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Shiori328"]
[OnName num="Shiori"]
“Ah…aah…aaaahー!!”
[cpg cn=true]

Paper fluttered about as she cut books with a jagged blade.
[cpg]

Shiori was so shocked that she couldn't even blink and her jaw dropped.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi385"]
[OnName num="Michi"]
“Yuna! Calm down!”
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna274"]
[OnName num="Yuna"]
"Stay backー!!"
[cpg cn=true]

[SE f="se138"]
;//【ＳＥ】切る


;//＠レッドフラッシュ
[transition target={true} color={0xff0000ff} time=100]
[WAIT time=100]
[transition target={false} color={0xff0000ff} time=100]
[WAIT time=100]


[move from="2/3" to="3/4" ease="easeInOutSine" time=500]
[WAIT time=500]
[FACE method="change_3" pos="3/4"]
[WAIT time=100]
[VOICE f="Michi386"]
[OnName num="Michi"]
“Grr…!”
[cpg cn=true]

[OnName num="Kenji"]
“Michi!!”
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="3/4" time=1]

[WAIT time=100]
[VOICE f="Syouko179"]
[OnName num="Syouko"]
“Doctor!!”
[cpg cn=true]

Michi tried to stop him, but her hand was cut.
[cpg]

I needed to intervene…but just as I was thinking this, Shiori's voice rang out.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA04_p3_01_a.ui" method="change_3" pos="1/4" time=800]

[FG f="CHA01_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shiori329"]
[OnName num="Shiori"]
“I’m begging you!”
[cpg cn=true]

Shiori's eyes were open, and only her mouth was moving as she spoke.
[cpg]

She looked like a robot…
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori330"]
[OnName num="Shiori"]
“Please… Please don't harm the books…If you're cold, I'll give you this…!"
[cpg cn=true]

[SE f="se137"]
;//【ＳＥ】衣擦れ

[free time=1000]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="1/4" time=1000]


[OnName num="Kenji"]
"......!"
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_7" pos="4/4" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="3/4" time=800]
[WAIT time=100]
[VOICE f="Michi387"]
[OnName num="Michi"]
“Shi-, Shiori…”
[cpg cn=true]

Without any hesitation, Shiori took off all the clothes she was wearing.
[cpg]

She then stripped down in front of us and walked up to Yuna with the clothes she had been wearing in her hands.
[cpg]


[VOICE f="Shiori331"]
[OnName num="Shiori"]
"Here…, put this on…, it's warm…"
[cpg cn=true]

[FACE method="change_5" pos="1/4"]
[WAIT time=100]
[VOICE f="Yuna275"]
[OnName num="Yuna"]
".........?!"
[cpg cn=true]

[SE f="se109"]
;//【ＳＥ】ナイフ落とす

The knife fell from Yuna's hand, and I kicked it away.
[cpg]

When I approached Yuna to take hold of her hand, she looked up at me with glazed eyes.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna276"]
[OnName num="Yuna"]
"Hey, Kenji… What's this? What…is this smell?"
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

Then Shiori came closer, step by step.
[cpg]


[VOICE f="Shiori332"]
[OnName num="Shiori"]
"Here…, put this on…, it’ll warm you up…"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna277"]
[OnName num="Yuna"]
"Aaahhhh! I won’t be tricked! I will not be tricked! Aaahhhh!"
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】ダッシュ

[move from="2/3" to="6/3" ease="easeInOutSine" time=1000]


Yuna shouted and ran off somewhere again.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko180"]
[OnName num="Syouko"]
"Ah! A-again! I'm going after her!!”
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】ダッシュ

[move from="2/3" to="5/3" ease="easeInOutSine" time=1000]


It was like déjà vu, but I was having none of it.
[cpg]


[VOICE f="Shiori333"]
[OnName num="Shiori"]
"Ah…, look at this …"
[cpg cn=true]

Shiori, still naked, stroked the cruelly torn book and let out a tear.
[cpg]

[OnName num="Kenji"]
“Shiori, put this on!”
[cpg cn=true]

I quickly took off my jacket and put it on Shiori, rubbing her hard to keep her warm as I hugged her cold body.
[cpg]

[OnName num="Kenji"]
“Why are you being so reckless? You'll freeze to death!"
[cpg cn=true]


[VOICE f="Shiori334"]
[OnName num="Shiori"]
"These books represent grandfather’s love… They are all my memories... I would rather die with them than lose them…"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi388"]
[OnName num="Michi"]
"Shiori, get to the infirmary quickly. Kenji, I'm sorry, but you'll have to lend her your jacket for a bit."
[cpg cn=true]

Michi said as she picked up Shiori's clothes, while being careful of her cut on her hand.
[cpg]

[OnName num="Kenji"]
"Of course."
[cpg cn=true]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_tbr_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・専門書の部屋　夜（暗）******************************************************

[WAIT time=1500]

[BGM f="huan"]

Shiori and Michi went to the infirmary, while I went back to the special reference book room and pulled a blanket over my shoulders to beat the cold.
[cpg]

[OnName num="Kenji"]
“Ugh…it’s cold.”
[cpg cn=true]

The breath coming out of my mouth was white.
[cpg]

Shiori…, I hope she didn’t get sick…
[cpg]

[OnName num="Kenji"]
"Ugh…, no. I’ll shiver if I sit still."
[cpg cn=true]

I couldn't stand my hands getting more and more numb, so I decided to jog around the room and do some strength training.
[cpg]

[OnName num="Kenji"]
“Haaah, haaah, haaah.”
[cpg cn=true]

As I moved my body, I gradually warmed up, but in moderation as sweating would have the opposite effect.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko181"]
[OnName num="Syouko"]
“Kenji…”
[cpg cn=true]

[OnName num="Kenji"]
“Waah!”
[cpg cn=true]

Before I knew it, Shoko was in the room and called out to me.
[cpg]

[OnName num="Kenji"]
"What's with you all of a sudden! Where's Yuna?!"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko182"]
[OnName num="Syouko"]
"Well, it's just…"
[cpg cn=true]

Shoko said she had chased Yuna relentlessly around the bookshelves, thinking it would be a disaster if it was set on fire indiscriminately.
[cpg]

So when Shoko started running the other way to get ahead of her and catch her, she collided head-on with Yuna and they hit each other on the forehead, and Yuna collapsed…
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko183"]
[OnName num="Syouko"]
"Now, I've got another bump~"
[cpg cn=true]

Shoko's forehead, which she was rubbing as she said this, was indeed puffy.
[cpg]

[OnName num="Kenji"]
“What happened after that?”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko184"]
[OnName num="Syouko"]
"Since the doctor seemed to be busy, I tied her up and put her in the pantry for now."
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

To my surprise, Shoko waved her hand and had something else to add.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko185"]
[OnName num="Syouko"]
"Oh, don't worry. I've wrapped a lot of blankets around her to prevent her from freezing to death!"
[cpg cn=true]

[OnName num="Kenji"]
"A-ah..., Is that so…?"
[cpg cn=true]

After headbutting her, she tied her up and put her in the pantry…
[cpg]

In fact, maybe she was the scariest one of all…
[cpg]

[OnName num="Kenji"]
"So? Did you come all the way here to tell me that?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko186"]
[OnName num="Syouko"]
"Oh, no, no, that's not why… When I saw Shiori earlier I thought I'd do some research…"
[cpg cn=true]

[OnName num="Kenji"]
“What about Shiori?”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko187"]
[OnName num="Syouko"]
"Yeah… Actually…, last night, and just now, she felt off…"
[cpg cn=true]

Shoko, who always spoke her mind, seemed to be choosing her words very carefully.
[cpg]

Did she have something difficult to say?
[cpg]

[OnName num="Kenji"]
“When you said she seemed off just now, what did you mean by that?“
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko188"]
[OnName num="Syouko"]
"Uh…, like when her eyes look empty and she spaces out…"
[cpg cn=true]

Like when she seems dazed…
[cpg]

[OnName num="Kenji"]
"Oh, so Shiori was like that again last night? When?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko189"]
[OnName num="Syouko"]
"In the middle of the night. I just thought she couldn't sleep at the time, but she had the same look on her face earlier… Just a bit."
[cpg cn=true]

[OnName num="Kenji"]
"What do you mean…, Just a bit?”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko190"]
[OnName num="Syouko"]
"I thought she might have been sleepwalking…Or maybe…, it’s a side effect of some medication…"
[cpg cn=true]

[OnName num="Kenji"]
“Huh? Since you're a nurse, can't you just ask Michi?"
[cpg cn=true]

I guess nurses didn’t have doctor-patient privilege. 
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko191"]
[OnName num="Syouko"]
"Ah, no, no…, I'd better look into it myself first."
[cpg cn=true]

Today Shoko looked like she had something she wanted to share.
[cpg]

I couldn't stop thinking about it.
[cpg]

[OnName num="Kenji"]
"You're thinking something, aren't you? If Shiori was sleepwalking or something, what's the problem if she's just dizzy in the middle of the night…."
[cpg cn=true]

Saying that much, I had unpleasant thoughts that I couldn’t say out loud.
[cpg]

Shoko was probably thinking the same thing.
[cpg]

And in that moment, I knew that Shoko had sensed what I was thinking.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko192"]
[OnName num="Syouko"]
"It’s not a big deal… if it’s just dizziness. But if she’s doing other things while she’s dizzy... That's …"
[cpg cn=true]

Other things…
[cpg]

I didn't want to know what those words meant.
[cpg]

But in order to move forward, I had to say it out loud.
[cpg]

[OnName num="Kenji"]
“Shoko, you think Shiori killed…3 people because of her illness or her medication, don’t you?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko193"]
[OnName num="Syouko"]
"N-no way! I don't think that… But it’s not like the thought hasn’t crossed my mind…"
[cpg cn=true]

[VOICE f="Syouko1193"]
[OnName num="Syouko"]
“I just thought I'd check to see if that was a possibility…”
[cpg cn=true]

[OnName num="Kenji"]
"I understand... I'll help you."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko194"]
[OnName num="Syouko"]
“Uh…”
[cpg cn=true]

I decided to go over it with Shoko to disprove her theory.
[cpg]

Also, I've been noticing a change in Shiori lately.
[cpg]

Was it an emotional thing, the result having too many people around, or was it…her  disease?
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko195"]
[OnName num="Syouko"]
"Then I'll look into the medicine Shiori has been taking, and Kenji, can you look into sleepwalking?"
[cpg cn=true]

[OnName num="Kenji"]
“Okay.”
[cpg cn=true]

Then Shoko and I went through the relevant sections of the special reference books.
[cpg]

[SE f="se026"]
;//【ＳＥ】ページ捲る

[WAIT time=1500]

[OnName num="Kenji"]
“What?  What? ‘If subjects walk while sleeping, they will have no memory of it when they wake up. This can be caused by excessive stress or a side effect of sleep-inducing drugs’, it says…”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko196"]
[OnName num="Syouko"]
“She hasn't been prescribed any sleep medication, right?”
[cpg cn=true]

[OnName num="Kenji"]
“Oh, is that so?”
[cpg cn=true]

[OnName num="Kenji"]
“Then it says, ‘Attempting to force or restrain subjects may result in harm, which has led to murders in the past’…”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko197"]
[OnName num="Syouko"]
".................."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

It was so in line with Shoko's theory that I didn't know what to think.
[cpg]

Excessive stress or unreasonable contact might harm the subject, and they wouldn't remember it when they woke up...it said.
[cpg]

[OnName num="Kenji"]
“But something still seems wrong… What is it that Michi, always being nearby, wouldn’t have noticed?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko198"]
[OnName num="Syouko"]
"That's what I think, too. There's no way the doctor wouldn't have noticed the illness."
[cpg cn=true]

So, what conclusion did she want to make… I was slightly annoyed.
[cpg]

Shiori is sick, But how could Michi not notice? Then she's not sick, But that doesn't make any sense either, does it?
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko199"]
[OnName num="Syouko"]
“The medicine didn’t seem to have any side effects.”
[cpg cn=true]

When we talked about medicine, I remembered that sheet I had seen when Shoko had smashed up the medicine bag.
[cpg]

[OnName num="Kenji"]
"What kind of medicine is the one I picked up, that Chitaro, something?"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko200"]
[OnName num="Syouko"]
“Chitaro, something?”
[cpg cn=true]

[OnName num="Kenji"]
"I couldn't read it because it was in a foreign language, Citalo... something."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko201"]
[OnName num="Syouko"]
“What? What is it? I don't remember the name on the prescription…, but maybe that's something the doctor ordered overseas? If so, I don't know what it is!”
[cpg cn=true]

Shoko had a goofy smile.
[cpg]

[OnName num="Kenji"]
“Well, let’s keep looking.”
[cpg cn=true]

Sometimes, I thought I could understand why Michi was so cold towards Shoko.
[cpg]

[SE f="se026"]
;//【ＳＥ】ページ捲る

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko202"]
[OnName num="Syouko"]
“Chitaro…,Chi, Chi…”
[cpg cn=true]

[OnName num="Kenji"]
“How about under C?”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko203"]
[OnName num="Syouko"]
“C, C, Cー, Cー...”
[cpg cn=true]

Shoko slogged through the index of the thick book.
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko204"]
[OnName num="Syouko"]
"Cita...lo…, Citalopram!"
[cpg cn=true]

[OnName num="Kenji"]
“I didn't know that's what it was called…”
[cpg cn=true]

Apparently, I got the name of the drug wrong.
[cpg]

When Shoko found what she was looking for, she turned the page with a somewhat excited look on her face.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko205"]
[OnName num="Syouko"]
"One moment, please! Let's see… ‘It affects the neurotransmitters involved in brain function…' Th-this is…"
[cpg cn=true]

[OnName num="Kenji"]
“What is it?”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko206"]
[OnName num="Syouko"]
“This is…, apparently a psychiatric drug."
[cpg cn=true]

[OnName num="Kenji"]
“A psychiatric drug?!”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko207"]
[OnName num="Syouko"]
“Yes…, more specifically it’s a type of antidepressant…”
[cpg cn=true]

[OnName num="Kenji"]
“That… For example, does it make subjects high or brighten their personality when taken…?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko208"]
[OnName num="Syouko"]
“I'm not a psychiatric nurse, so I'm not sure about that… However, depending on the strength of the medication, that could be the case…"
[cpg cn=true]

[VOICE f="Syouko1208"]
[OnName num="Syouko"]
“More to the point, when the effects of the drug wear off, the subject’s reaction will be darker, and when they take it, it’ll be lighter again.”
[cpg cn=true]


Perhaps it was because I went into this research expecting a different outcome, but my thoughts were drawn to a single conclusion.
[cpg]

It was the same for Shoko.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko209"]
[OnName num="Syouko"]
"Anorexia or insomnia…, are listed as side effects…"
[cpg cn=true]

[OnName num="Kenji"]
“Shiori…, She had mental problems after all...?”
[cpg cn=true]

She hadn't eaten much rice, and sometimes she was very lively.
[cpg]

And after listening to Shoko, I took it upon myself to confirm it.
[cpg]

[STOPBGM]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko210"]
[OnName num="Syouko"]
“If th-that’s true…”
[cpg cn=true]

Shoko was about to say something, but it was clear that we both shared a common concern.
[cpg]

Shiori…could have done it all.
[cpg]

Either the disease itself or the side effects of the drug may have caused… Shiori to kill three people.
[cpg]

[BGM f="huan"]
;//【ＢＧＭ】不安

But…, deep down, I couldn't believe the conclusion I had come to.
[cpg]

I wanted to believe that Shiori would never do such a thing, and I do.
[cpg]

[OnName num="Kenji"]
"Oh, I'm going to check on Yuna..."
[cpg cn=true]

I had a sudden vague feeling of dread and a strange feeling that I should not leave Yuna alone.
[cpg]



[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗）******************************************************

[WAIT time=1500]

Heading down the stairs to the basement, I opened the door to the pantry where Yuna had been left.
[cpg]

[SE f="se136"]
;//【ＳＥ】ドア開ける

;//膝をついた柚那の背後から首を絞めている栞
[BG f="b_l_b1_ware_0.ui" time=1000]
[WAIT time=1000]

[BGM f="danger"]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="2/3" time=800]

[VOICE f="Yuna278"]
[OnName num="Yuna"]
“Uh…ugh…uh…”
[cpg cn=true]

"........."
[cpg]

What I saw in the dim darkness was unbelievable.
[cpg]

From behind Yuna, who was kneeling on the floor like she was collapsing, a vacant-eyed Shiori was strangling her with both hands.
[cpg]

[OnName num="Kenji"]
“Hey…, stop!”
[cpg cn=true]

[SE f="se045"]
;//【ＳＥ】ドンッ

[move from="2/3" to="1/3" ease="easeInOutSine" time=500]
[move from="4/5" to="5/5" ease="easeInOutSine" time=500]

[VOICE f="Shiori335"]
[OnName num="Shiori"]
“Ah…”
[cpg cn=true]

[SE f="se047"]
;//【ＳＥ】ドサッ



[free time=900]
;//[BG f="black.ui" time=900]
;//[WAIT time=1500]
;//[BG f="b_l_b1_ware_0.ui" time=1000]
;//【ＢＧ】図書館・地下・非常用倉庫　（暗）******************************************************

[WAIT time=1500]

As I pushed Shiori away, Yuna's body fell to the floor quite easily.
[cpg]

She was already unconscious.
[cpg]

[OnName num="Kenji"]
"Hey, someone! Michi! Shoko! Please come quickly!"
[cpg cn=true]

I slapped Yuna on the cheek and called for help.
[cpg]

[OnName num="Kenji"]
“Yuna! Yunaaa! Wake up!!”
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】走る

[FG f="CHA05_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi389"]
[OnName num="Michi"]
"What's wrong? What? Shiori…?!"
[cpg cn=true]

[OnName num="Kenji"]
“Shiori choked Yuna!!"
[cpg cn=true]

When I said that to Michi, who came running in, she hurriedly left the room. Shoko came running in to replace her.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko211"]
[OnName num="Syouko"]
“Shi, Shiori…, it was you after all…”
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Shiori336"]
[OnName num="Shiori"]
“...me?”
[cpg cn=true]

Shiori did not have the face of a horrible murderer, nor did she tremble with anger.
[cpg]

But I clearly saw her choke Yuna.
[cpg]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori337"]
[OnName num="Shiori"]
“It wasn’t…me…”
[cpg cn=true]

Was she in denial? Delirious? I didn't know.
[cpg]

But I could see that there was something wrong with her eyes.
[cpg]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi390"]
[OnName num="Michi"]
"Move!"
[cpg cn=true]

[move from="3/3" to="2/5" ease="easeInOutSine" time=1000]


Michi came over again, pushed me and Shoko out of the way, stepped forward, grabbed Shiori by the arm and gave her a single injection.
[cpg]

.........
[cpg]

[free time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_5" pos="2/5" time=1000]
[FG f="CHA06_p3_01_a.ui" method="change_3" pos="4/5" time=1000]


A few seconds later, Shiori's body relaxed, and Michi held her in her arms.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi391"]
[OnName num="Michi"]
"Kenji, Ms. Endo! Take Yuna to the infirmary. I'll go put Shiori to bed in her room."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko212"]
[OnName num="Syouko"]
“Y-yes!”
[cpg cn=true]

Michi had prioritized Shiori over Yuna, who had just been strangled and was unconscious.
[cpg]

I thought that was very suspicious.
[cpg]

I wondered if Michi was Shiori’s accomplice...
[cpg]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン閉／蝋燭）******************************************************

[WAIT time=1500]
[BGM f="huan"]

[FG f="CHA06_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko213"]
[OnName num="Syouko"]
"She's okay. She's breathing! And her pulse is normal!"
[cpg cn=true]

Shoko shouted as she examined Yuna, who was lying on the bed.
[cpg]

[OnName num="Kenji"]
“What a relief…”
[cpg cn=true]

Yuna had been acting strangely, but it was because we were locked up.
[cpg]

She's my classmate, and she's still my friend.
[cpg]

So I was genuinely happy that she was still alive.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko214"]
[OnName num="Syouko"]
“Kenji…, Did you see what happened…”
[cpg cn=true]

[OnName num="Kenji"]
“I saw…Shiori choking Yuna…”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko215"]
[OnName num="Syouko"]
“Oh, really…?”
[cpg cn=true]

Shoko looked down at Yuna's neck and stayed quiet.
[cpg]

[OnName num="Kenji"]
"Did Michi know about this…? From the beginning…"
[cpg cn=true]

When Takagi died, Michi probably already knew who the killer was…
[cpg]

If that was the case, then Michi was also responsible for the subsequent deaths of Hosokawa and Erika.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko216"]
[OnName num="Syouko"]
“I…don’t know…”
[cpg cn=true]

Shoko, who had always been on Michi's side, was also wavering.
[cpg]

I was at my limit.
[cpg]

I had to ask Michi the truth about everything.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_lpass_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・左側廊下　夜（暗）******************************************************

[WAIT time=1500]


I left Yuna with Shoko and went upstairs.
[cpg]

[SE f="se072"]
;//【ＳＥ】ノック
I knocked on the door of Shiori's room and heard Michi's reply from inside and I walked in.
[cpg]

[STOPBGM]
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_ros_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

[SE f="se136"]
;//【ＳＥ】ドア開ける

[WAIT time=1500]

[BGM f="silent"]

[OnName num="Kenji"]
".................."
[cpg cn=true]

Shiori was sleeping quietly in her bed with her eyes closed.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi392"]
[OnName num="Michi"]
“Sigh…”
[cpg cn=true]

Michi, who seemed to be exhausted, covered her forehead with both hands and sighed deeply.
[cpg]

Her profile looked more gaunt than before.
[cpg]

[OnName num="Kenji"]
“I have to ask you something.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi393"]
[OnName num="Michi"]
"I know… But first, let me tell you something."
[cpg cn=true]

After Michi said that, she started rambling.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi394"]
[OnName num="Michi"]
"Shiori's body has been affected by a cardiovascular disease since she was a small child..."
[cpg cn=true]

[VOICE f="Michi1394"]
[OnName num="Michi"]
“When she got a little older, she developed asthma on top of that. Whenever she has an asthma attack, it triggers a heart attack, so it becomes a vicious cycle…”
[cpg cn=true]


This is what Michi told me.
[cpg]

The stress and anxiety of the illness was taking its toll, and even the slightest emotional disturbance could cause an attack immediately.
[cpg]

Adults are able to control their emotions, but being so young, Shiori was unable to, so her parents gave up on raising her and left her in the care of her paternal grandfather, the head of the Tokita family.
[cpg]

After that, Shiori's parents ran away and moved overseas, and she lost touch with them. But…that might have been good for Shiori…
[cpg]

Her grandfather doted on Shiori and used his financial resources to get her every kind of treatment.
[cpg]

However, Shiori being so young and not that strong to begin with, could not be operated on or given strong medication, so there was nothing to be done but to maintain the status quo until she grew up.
[cpg]

So her grandfather summoned the youngest and most talented female doctor overseas, who was considered a genius, and ordered her to stay by Shiori's side all the time for a huge sum of money.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi395"]
[OnName num="Michi"]
"That doctor was me… That alone was amazing, but Shiori was so beloved by her grandfather…."
[cpg cn=true]

[VOICE f="Michi1395"]
[OnName num="Michi"]
“Since she was happy when books were read to her, he bought a lot of books for her and even built a library for her.”
[cpg cn=true]


That's the Tokita Library.
[cpg]

For Shiori, who has never known the love of her parents, her grandfather's love is the only unconditional love she has ever known.
[cpg]

Like lovers, Shiori was always there for her grandfather, and he loved her with everything he had.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi396"]
[OnName num="Michi"]
"Shiori's world was made up of the things her grandfather gave her… So when her grandfather died, her world itself collapsed…"
[cpg cn=true]

The only person who loved her and had given her everything was suddenly gone.
[cpg]

It was a crushing sadness that I could only imagine.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi397"]
[OnName num="Michi"]
"I think she was ten or so at the time… Shiori's young mind couldn't handle so much grief…"
[cpg cn=true]

[VOICE f="Michi1397"]
[OnName num="Michi"]
"So her mind created another personality to disperse her sorrow and pain… A personality different from her own, named Kotoha…"
[cpg cn=true]

[OnName num="Kenji"]
“Koto…ha…?”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi398"]
[OnName num="Michi"]
"Since then, Shiori becomes Kotoha to protect her fragile body whenever negative emotions run high."
[cpg cn=true]

According to Michi, Kotoha has no feelings of sadness, and has a tendency to openly express the desires that Shiori has suppressed.
[cpg]

And, to my surprise, Shiori herself didn't know about Kotoha's existence.
[cpg]

I couldn't believe what I was hearing, as if Michi had been making it up.
[cpg]

But as I listened to Michi, I remembered Shiori smiling cheerfully and Shiori aggressively seeking me out, and I had to…convince myself that that was not the same Shiori after all.
[cpg]

[OnName num="Kenji"]
"Then the Citalopram was a psychiatric treatment after all..."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi399"]
[OnName num="Michi"]
"You’re very knowledgeable… That's right. It's an unapproved drug in Japan, but I thought it might be good for Shiori, so I ordered it on a trial basis. It's a treatment for mental illness."
[cpg cn=true]

Shoko and I were on the right track after all.
[cpg]

However, knowing that didn’t make me happy.
[cpg]

[OnName num="Kenji"]
"So…, this alternate personality, Kotoha, killed three people?"
[cpg cn=true]

In response, Michi twisted her face painfully and muttered.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi400"]
[OnName num="Michi"]
“I don’t know…”
[cpg cn=true]

[OnName num="Kenji"]
“You don’t know?! Aren’t you her doctor?”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi401"]
[OnName num="Michi"]
"I still don’t know. Neither Shiori nor her other personality have ever been in contact with other people for this long before."
[cpg cn=true]

[VOICE f="Michi1401"]
[OnName num="Michi"]
“That's why it’s hard to figure out what she’s going to do or what she’s thinking, because I don’t even know what’s happening!”
[cpg cn=true]


[OnName num="Kenji"]
“So…, what do you think, Michi? Do you think Shiori…, Kotoha is the culprit?”
[cpg cn=true]

It was a loaded question.
[cpg]

But one that needed to be answered.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi402"]
[OnName num="Michi"]
“It's… I think it’s not completely impossible…”
[cpg cn=true]

Michi's answer came as a huge shock to me.
[cpg]

If only Michi had said, "No way" I might have been able to trust Shiori just as before.
[cpg]

I looked at Shiori sleeping peacefully, with mixed feelings, thinking that there were two hearts inside her.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi403"]
[OnName num="Michi"]
“Let me ask you this…”
[cpg cn=true]

Michi took a deep breath and slowly stared into my eyes.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi404"]
[OnName num="Michi"]
"Kenji. If she's guilty of murder, can you forgive her for that?"
[cpg cn=true]

[OnName num="Kenji"]
“Well…”
[cpg cn=true]

If Shiori… No, if Kotoha murdered Takagi and Hosokawa, and Erika too…
[cpg]

That's because of the disease.... Shiori doesn't know anything about it.
[cpg]

That being said, murder is murder…
[cpg]

Forgivable or unforgivable, the answer I gave was...
[cpg]

;//『ルートＥ』焼失　は削除
;//選択肢もなくなります　このまま進行
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
*s13_a|One Thing After Another

[OnName num="Kenji"]
“I’d forgive her…”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi405"]
[OnName num="Michi"]
“Even if she’s a murderer…?”
[cpg cn=true]

[OnName num="Kenji"]
“Yes…”
[cpg cn=true]

Shiori’s condition was tragic…
[cpg]

She didn't want to be sick herself, physically or mentally.
[cpg]

Her parents have abandoned her, her beloved grandfather has died, and her mind has been corrupted by illness.
[cpg]

I felt bad for Shiori living like that, and I felt sad for her and…loved her.
[cpg]

[OnName num="Kenji"]
"I'll accept her, sickness and all. Because I love Shiori."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi406"]
[OnName num="Michi"]
“Really…? I understand. Thank you…"
[cpg cn=true]

Michi thanked me quietly and stood up.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi407"]
[OnName num="Michi"]
"When I get out of here, I'm going to tell the police everything, including her illness."
[cpg cn=true]

[OnName num="Kenji"]
"Yes... But if she has a mental illness, she wouldn't be charged with a crime, would she?"
[cpg cn=true]

I heard about this kind of thing on the news.
[cpg]

I asked Michi, grasping at straws.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi408"]
[OnName num="Michi"]
“That’s not for us to decide…”
[cpg cn=true]

She may be right.
[cpg]

Both Takagi and Hosokawa, who were killed, must have families, then there are Erika's parents.
[cpg]

When I thought about how all those people would feel, I knew how much they would hate Shiori.
[cpg]

I wondered if Shiori, who knew nothing, would be able to take the blame...
[cpg]

It was inevitable that the gentle Shiori would suffer, even though it was done by another person.
[cpg]

I wanted to support her at that time if I could.
[cpg]

[SE f="se009"]
;//【ＳＥ】ドア閉まる
[move from="2/3" to="5/3" ease="easeInOutSine" time=1000]

After Michi left, I held Shiori's hand as she slept in bed.
[cpg]

Poor Shiori...
[cpg]

A girl starved for affection, clinging to love, wounded by the loss of everything.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori338"]
[OnName num="Shiori"]
"...Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"Did we wake you...?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori339"]
[OnName num="Shiori"]
“I…”
[cpg cn=true]

[OnName num="Kenji"]
“Don’t say anything…”
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_7" pos="2/3" time=800]

I just hugged Shiori and stroked her head gently.
[cpg]

[OnName num="Kenji"]
"I'm here for you..."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori340"]
[OnName num="Shiori"]
“Yeah…”
[cpg cn=true]

Kiss...
[cpg]


I kissed Shiori's forehead, and she lightly placed her lips on my cheek.
[cpg]

Kiss…
[cpg]

I felt a rush of heat in that area and I kissed Shiori on the lips, stroking her hair.
[cpg]

Kiss…
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori341"]
[OnName num="Shiori"]
“...mmm.”
[cpg cn=true]

[OnName num="Kenji"]
"Shiori..."
[cpg cn=true]

My love for Shiori grew, and we held each other for a while, our lips locked together.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori342"]
[OnName num="Shiori"]
"Ah…, Kenji's blazer…, it’s over there."
[cpg cn=true]

[OnName num="Kenji"]
“Hmm? Oh.”
[cpg cn=true]

My jacket, which I had lent to her when Yuna had been acting up, was hanging on the desk chair.
[cpg]

[OnName num="Kenji"]
"Shiori…, are you feeling okay…?"
[cpg cn=true]

I looked at Shiori, who was still lying on the bed as I collected my jacket.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori343"]
[OnName num="Shiori"]
"I'm okay…but…, I'm feeling a little…heavy…"
[cpg cn=true]

I pulled the blanket tightly around her as Shiori closed her eyes.
[cpg]

I decided that I would protect her from now on, just like a defenseless kitten…
[cpg]

[STOPBGM]


;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=3000]


[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="ep017.ks" target="*start"]


