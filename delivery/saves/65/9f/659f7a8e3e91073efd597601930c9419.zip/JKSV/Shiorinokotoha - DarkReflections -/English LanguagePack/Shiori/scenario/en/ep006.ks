*start

;#################################################
*Ep006|The Dead Don't Talk
;#################################################
[SCENE id=6]


[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=1000]

[BGM f="huan"]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika206"]
[OnName num="Erika"]
"Kenji! Kenjiiii!"
[cpg cn=true]

As soon as I ran out to the entrance, Erika jumped on me with all her might and I lost my balance.
[cpg]

[SE f="se035"]
;//【ＳＥ】転倒
[free time=1000]

[OnName num="Kenji"]
"Whoa! What's going on? Hey, Erika! What's wrong with you?"
[cpg cn=true]

[FG f="CHA03_p5_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika207"]
[OnName num="Erika"]
"Th-th-that!"
[cpg cn=true]


[OnName num="Kenji"]
"......?"
[cpg cn=true]

[STOPBGM]

[WAIT time=1000]

[FG f="CHA08_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa109"]
[OnName num="Hosokawa"]
"O-ooh, my God!"
[cpg cn=true]

;//☆死亡
;//高木死亡


;//階段の前、俯せに倒れている高木の背中に古めかしいナイフが刺さっている
;//【ＢＧＭ】死亡
;//[free time=1000]
;**【ＣＧ】ci_01_0 ***********************
;//カットイン
[CUTIN f="ci_01_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

[BGM f="danger"]

[OnName num="Kenji"]
"What..."
[cpg cn=true]

I saw the reason why Erika and Hosokawa screamed and I froze.
[cpg]

It was...
[cpg]

Due to the state Takagi was found in.
[cpg]

Takagi's huge body was lying face down in front of the stairs with a single deep knife wound in his back.
[cpg]

His jacket was covered with a wet red stain, and his bare hands and face were white and discolored.
[cpg]

[SE f="se022"]
;//【ＳＥ】走ってくる

[FG f="CHA05_p3_01_a.ui" method="change_5" pos="3/3" time=1500]
[WAIT time=1500]
[VOICE f="Michi142"]
[OnName num="Michi"]
"What's the matter! What was that voice just now..."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna105"]
[OnName num="Yuna"]
''Eh, kyaaaaah!!''
[cpg cn=true]

Michi and Yuna, who came running in later, had the same reaction as us and stiffened.
[cpg]

;//カットイン終了
[CUTIN f="ci_01_0.ui" show={false} method="slideout"]

;//[free time=900]
;//[BG f="black.ui" time=900]
;//[WAIT time=3000]
;//[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）

[WAIT time=1500]

;//[FG f="CHA05_p3_01_a.ui" method="change_5" pos="2/5" time=1000]
;//[WAIT time=1000]


[SE f="se022"]
;//【ＳＥ】走ってくる
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="1/3" time=1500]
[WAIT time=100]
[VOICE f="Shiori093"]
[OnName num="Shiori"]
"Wha...?"
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=1]
[move from="3/3" to="2/3" ease="easeInOutSine" time=800]
[WAIT time=100]
[VOICE f="Michi143"]
[OnName num="Michi"]
"Shiori! Don't look!"
[cpg cn=true]

Michi ran up to Shiori as she came down the stairs and immediately hugged her face to block her from seeing him.
[cpg]

But Michi couldn't keep that up forever, and Shiori escaped Michi's arms and peeked her head in the direction where everyone was staring.
[cpg]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori094"]
[OnName num="Shiori"]
“Wha…, Mr. Takagi? Uh…w-what…?”
[cpg cn=true]

The blood drained from Shiori's face so fast that I could hear it rushing out.
[cpg]

[free time=800]


Michi noticed this too and quickly propped her up and sat her down on the stairs.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika208"]
[OnName num="Erika"]
“He’s dead! He’s dead, right?!”
[cpg cn=true]

It was hard to believe anyone would think otherwise, but Erika's exclamation was perfectly understandable.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=2000]
[WAIT time=1000]
[VOICE f="Michi144"]
[OnName num="Michi"]
".................."
[cpg cn=true]

After making sure Shiori could sit up on her own, Michi gulped and slowly walked over to Takagi to place her fingers on his neck.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi145"]
[OnName num="Michi"]
"He's...dead."
[cpg cn=true]

[SE f="se088"]
;//【ＳＥ】ショック
I knew it, but I was shocked when Michi, a doctor, declared it.
[cpg]

Everyone stood there, speechless and stiff.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi146"]
[OnName num="Michi"]
"I'm not a coroner, so I can't say for sure, but... It was a stabbing, for what it's worth."
[cpg cn=true]

[OnName num="Kenji"]
"A stabbing..."
[cpg cn=true]


[FG f="CHA08_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa110"]
[OnName num="Hosokawa"]
“Which means…, which means someone stabbed him…"
[cpg cn=true]

The fact that every obvious thing had to be digested was proof of the confusion.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna106"]
[OnName num="Yuna"]
"W-what, why? Who could do this?!"
[cpg cn=true]

Murder means that someone had to have killed...him.
[cpg]

That means that...
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika209"]
[OnName num="Erika"]
"Who did it?!"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_3" pos="3/5" time=1000]
[FG f="CHA05_p1_01_a.ui" method="change_4" pos="2/5" time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_4" pos="1/5" time=1000]
[FG f="CHA04_p1_01_a.ui" method="change_3" pos="4/5" time=1000]
[FG f="CHA08_p1_01_a.ui" method="change_3" pos="5/5" time=1000]
[WAIT time=2000]

That means one of these people was the killer…
[cpg]

Erika's cries echoed wanly in the entrance.
[cpg]

[free time=1000]

Whoosh…sh…
[cpg]

We all looked at the faces of those close to us and naturally kept our distance.
[cpg]

It was a sad reality check.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="3/5" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/5" time=800]
.........
[cpg]


My eyes met with Shiori's, who was hiding behind Michi's, her petite body shaking.
[cpg]

At that moment, I instantly remembered the scene from last night.
[cpg]

Takagi had confessed his feelings to Shiori.
[cpg]

I wonder what happened after that.
[cpg]

There was no way..., Shiori did something...
[cpg]

I quickly dismissed the thought.
[cpg]

It was impossible for Shiori, who had no arm strength at all, to stab a big man with a knife that deep.
[cpg]

I could understand if Takagi stabbed Shiori when she refused to go out with him, but there is no reason for the person rejecting to stab anyone.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika210"]
[OnName num="Erika"]
“You did it, didn’t you?!”
[cpg cn=true]

Suddenly Erika pointed at someone and shouted.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA08_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa111"]
[OnName num="Hosokawa"]
“W-what are you talking about?!”
[cpg cn=true]

Her pink-nailed fingertip was pointed at Hosokawa.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa112"]
[OnName num="Hosokawa"]
“Why me?!”
[cpg cn=true]

Hosokawa was extremely upset by the sudden accusation.
[cpg]

His eyes behind his glasses were shifting around and quivering.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika211"]
[OnName num="Erika"]
"Besides Takagi, you and Kenji are the only other men. Kenji wouldn't do it, so you're the only one who could have!"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA08_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa113"]
[OnName num="Hosokawa"]
"You've got to be k-kidding me!"
[cpg cn=true]

When Erika came at him with her messed up logic, Hosokawa shook his head and shouted.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa114"]
[OnName num="Hosokawa"]
"He and I, we didn't know each other outside of this place, we had no conflict of interest! That means, I had no motive! If you say something so crazy, I'll sue you for libel!"
[cpg cn=true]

[OnName num="Kenji"]
"Conflict of interest..."
[cpg cn=true]

I let the words slip out of my mouth, and Hosokawa spat them right back at me.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa115"]
[OnName num="Hosokawa"]
"Yes! If it's a conflict of interest, you're the one with the conflict of interest!"
[cpg cn=true]

[OnName num="Kenji"]
"Huh, me?!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa116"]
[OnName num="Hosokawa"]
"Because you and Takagi both felt the same way about Shiori..."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yuna107"]
[OnName num="Yuna"]
"Please just stop! Saying that now won't change anything…."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="3/5" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Michi147"]
[OnName num="Michi"]
"Yes, let's just calm down."
[cpg cn=true]

The atmosphere was eerie and no one could bear to look at Takagi's corpse, then Shiori cried out.
[cpg]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori095"]
[OnName num="Shiori"]
"That anyone here could do such a thing..., I can't believe it…"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yuna108"]
[OnName num="Yuna"]
"P-perhaps…"
[cpg cn=true]

Yuna's words, which followed, sent a shiver through us all.
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna109"]
[OnName num="Yuna"]
"There could be someone hiding in this building… that we don't know about…"
[cpg cn=true]

[SE f="se041"]
;//【ＳＥ】静かな恐怖

[WAIT time=1000]


Shudder…
[cpg]

A cold sweat ran down my spine.
[cpg]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika212"]
[OnName num="Erika"]
"Oh, I see... That makes sense about the security room and the cell phones. There must be a murderer around here somewhere who locked us up!"
[cpg cn=true]

[OnName num="Kenji"]
“S-seriously…?”
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA08_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa117"]
[OnName num="Hosokawa"]
"If that's the case, it's not safe to leave it like this. We need to find whoever it is and get them..."
[cpg cn=true]

When the conversation progressed to this point, everyone naturally stared at Michi.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi148"]
[OnName num="Michi"]
"All right. Then we'll split up and inspect each room..."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_3" pos="1/3" time=1000]
[WAIT time=100]
[VOICE f="Erika213"]
[OnName num="Erika"]
"Ah, that’s a bad idea!”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi149"]
[OnName num="Michi"]
"Why?"
[cpg cn=true]

Erika interrupted Michi's suggestion by raising her hand, and then proceeded to skillfully explain her reasoning.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika214"]
[OnName num="Erika"]
"Doesn’t this happen all the time in horror movies? In these situations it's very dangerous to split up. We have to stick together."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi150"]
[OnName num="Michi"]
"Oh, yeah… If that's the case, let's all go around together. Is that okay with you guys?"
[cpg cn=true]

We nodded silently and decided to go around the library, one room at a time.
[cpg]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_lpass_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・左側廊下　昼（天窓からの光）******************************************************

[WAIT time=1500]

[BGM f="serious"]


[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi151"]
[OnName num="Michi"]
“First, upstairs on the left. Let's start with the treasure room."
[cpg cn=true]

We went up the stairs to the left, under the staff-only door, and stood right before the treasure room.
[cpg]

The door was heavy, but it was unlocked.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi152"]
[OnName num="Michi"]
"It's an electronic lock, but since the machine broke, it's open now."
[cpg cn=true]

[SE f="se136"]
;//【ＳＥ】扉開く

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_th_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・宝物庫　昼（エントランスからの光）******************************************************

[WAIT time=1500]


[VOICE f="Erika215"]
[OnName num="Erika"]
"Oh, What the hell is this?"
[cpg cn=true]

The door opened slowly, and behind it were a number of glass cases and a few stuffed animals.
[cpg]

There were no windows in the room at all, and the only light came from the skylight through the open door.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika216"]
[OnName num="Erika"]
"This is the treasure?!"
[cpg cn=true]

Erika peered into the glass case practically leaning against it, and her shoulders slumped in disappointment.
[cpg]

I looked in it afterwards, there were tattered scrolls and yellowing old books, with writing that was difficult to understand, like old Japanese.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna110"]
[OnName num="Yuna"]
"Are they valuable?"
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Shiori096"]
[OnName num="Shiori"]
"There are items from the Muromachi period and things written in the Asuka period..."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi153"]
[OnName num="Michi"]
"They're said to be priceless."
[cpg cn=true]

To Erika, who was expecting gold, silver, and treasure, these would be worth nothing.
[cpg]

Just like, casting pearls before swine or giving gold coins to a cat.
[cpg]


[FG f="CHA08_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa118"]
[OnName num="Hosokawa"]
"This taxidermy is quite well done."
[cpg cn=true]

Hosokawa approached the upright stuffed bear and voiced his admiration.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa119"]
[OnName num="Hosokawa"]
"I thought it might be possible to hide inside it, but...not with the way it's made."
[cpg cn=true]

I wondered if he had been looking for a zipper on the back of the bear...
[cpg]

Come to think of it, it would be too scary for someone to hide in a place like that...
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna111"]
[OnName num="Yuna"]
“There doesn't seem to be anywhere to hide in this room…”
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi154"]
[OnName num="Michi"]
"Let's move on."
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_gsr_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・祖父の書斎　昼（エントランスからの光）******************************************************

[WAIT time=1500]


Next to the treasure room was a magnificent study.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi155"]
[OnName num="Michi"]
"This was the study of the library’s founder…, Shiori's grandfather."
[cpg cn=true]

There was a massive desk and chair set, like those used by presidents and politicians.
[cpg]

There was a window here, with luxurious velvet curtains, but the shutters were down on the outside so we couldn't get out.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika217"]
[OnName num="Erika"]
"It's so much more gorgeous in here!"
[cpg cn=true]

Erika was excited and excited when she saw the paintings on the wall and the vases on display.
[cpg]

[OnName num="Kenji"]
"Hey, don't touch. You wouldn't want to break anything."
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika218"]
[OnName num="Erika"]
"Yeah, I know. Ms. Kisaragi, how much is this vase worth?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi156"]
[OnName num="Michi"]
“Well… Shiori, do you happen to know?”
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Shiori097"]
[OnName num="Shiori"]
"I think it's about three million..."
[cpg cn=true]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika219"]
[OnName num="Erika"]
"Three million!!"
[cpg cn=true]

Erika was surprised by Shiori's words.
[cpg]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika220"]
[OnName num="Erika"]
"Can I touch just a little?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi157"]
[OnName num="Michi"]
"Don't."
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika221"]
[OnName num="Erika"]
“Boo~”
[cpg cn=true]

What was the point of touching it…?
[cpg]


[FG f="CHA08_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa120"]
[OnName num="Hosokawa"]
"It's a nice room, but there's no place to hide."
[cpg cn=true]

I opened up the shelves and such to make sure, but there was so much stuff inside that even a cat couldn't get in.
[cpg]

[OnName num="Kenji"]
"Let's move on."
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_ros_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

[WAIT time=1500]

Next to the study was Shiori's private room.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika222"]
[OnName num="Erika"]
“It's kind of dreary.”
[cpg cn=true]

Erika said rudely to Shiori, who looked down in embarrassment.
[cpg]

[OnName num="Kenji"]
"Hey."
[cpg cn=true]

Although I criticized Erika, I was actually thinking the same thing.
[cpg]

I imagined Shiori's room to be princess-like, all pink and lace, but this room was more like...
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna112"]
[OnName num="Yuna"]
"Like it's part of the library..."
[cpg cn=true]

Yeah, that was it.
[cpg]

The four walls were covered in books, books, books.
[cpg]

It was a wall of bookshelves.
[cpg]

The desk and chair were simple, unlike the founder's study, and the bed looked like something you could buy online, and was made of pipes.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi158"]
[OnName num="Michi"]
"She doesn't live here, it's just a room for her to rest in."
[cpg cn=true]

If this room was just for resting, why were there so many books...
[cpg]

If it were me, I wouldn't be able to rest being surrounded by so many books.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa121"]
[OnName num="Hosokawa"]
"These aren't taxidermy, they're plaster casts."
[cpg cn=true]

Following Hosokawa's gaze, there were several small animal shaped figurines on the floor.
[cpg]

A few cats and dogs looked so lifelike, as if they were actually alive.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika223"]
[OnName num="Erika"]
"Oh no, my hair is a mess!"
[cpg cn=true]

Erika saw herself in the large mirror hanging on the side of the bookshelf and started fixing her hair with a comb.
[cpg]

[OnName num="Kenji"]
"This is not the time or place for that."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Shiori098"]
[OnName num="Shiori"]
"Um..., is it alright to move on to the next room?"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna113"]
[OnName num="Yuna"]
"I'm sorry."
[cpg cn=true]

There was no more space in Shiori's room for anyone else, so we moved on to the security room next.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_sr_0.ui" time=1000]
;//【ＢＧ】図書館・２階・セキュリティルーム　（暗）******************************************************
[WAIT time=1500]


[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi159"]
[OnName num="Michi"]
"Nothing seems to have changed since then."
[cpg cn=true]

The machine was still broken and would not turn on.
[cpg]

And there was no place for people to hide here either.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_mhbr_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・地図と歴史書の部屋　昼（エントランスからの光）******************************************************

[WAIT time=1500]

The large room to the right of the stairs was the room of maps and history books.
[cpg]

In the corner, there was a rolled up blanket and a neatly folded blanket.
[cpg]


[OnName num="Kenji"]
"I see. This is where two of the girls slept, right?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika224"]
[OnName num="Erika"]
"Yeah, that's right."
[cpg cn=true]

The rolled up blanket had to be Erika's.
[cpg]

It was easy to imagine that the folded blanket was Yuna's.
[cpg]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna114"]
[OnName num="Yuna"]
"I was reading until rather late..., but there was nothing out of the ordinary."
[cpg cn=true]

We inspected the shelves where the books were stored, but as Yuna had said, we couldn't find anything suspicious, so we went downstairs.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=1500]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]

............!
[cpg]

[OnName num="Kenji"]
"It's okay. Take my hand."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

Shiori nodded and took hold of my hand.
[cpg]

As we descended the stairs, it was hard not to notice Takagi's corpse, so I gave Shiori my hand to help her down the last few steps.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi160"]
[OnName num="Michi"]
"The general collection room was used by Kenji and the guys, and everyone came and went during the day, so that's fine. The room with special reference books was..."
[cpg cn=true]

I took a look to make sure, but there was nothing suspicious there as well.
[cpg]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa122"]
[OnName num="Hosokawa"]
"So next is the..., basement."
[cpg cn=true]

The basement...
[cpg]

Thanks to the skylight, the first floor was bright, but day or night, the basement remained the same.
[cpg]

Flashlight in hand, we cautiously went down the narrow stairs.
[cpg]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]


[VOICE f="Erika225"]
[OnName num="Erika"]
"Everything was fine on the second floor or the first floor, which means that..."
[cpg cn=true]


[VOICE f="Yuna115"]
[OnName num="Yuna"]
"No, don't say it..."
[cpg cn=true]

You didn't have to tell me.
[cpg]

So if there was anything, the basement was the only place left.
[cpg]



[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗／懐中電灯）******************************************************

[WAIT time=1500]

At the bottom of the stairs, the corridor was as dark as to be expected, and the flashlights came in handy. 
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi161"]
[OnName num="Michi"]
"The floor and walls are brick, so let's set up a few candles."
[cpg cn=true]

Following Michi's instructions, candles were set up in several places, and it finally seemed a bit brighter.
[cpg]

But because it was underground, it had the atmosphere of a medieval prison or a catacomb.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi162"]
[OnName num="Michi"]
"This room first."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi163"]
[OnName num="Michi"]
"It's the pantry."
[cpg cn=true]

This was the room where we came to get emergency rations and flashlights.
[cpg]

There were shelves, but they were so small that one could easily see through to the other side.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa123"]
[OnName num="Hosokawa"]
"Ropes, shovels, insecticide, and a toolbox...?"
[cpg cn=true]

Some of the tools didn't seem out of place in a library, but...
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi164"]
[OnName num="Michi"]
"The gardener and carpenter who regularly tend to the grounds keep a few tools on hand.”
[cpg cn=true]

We all accepted Michi's explanation.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi165"]
[OnName num="Michi"]
"And here's the infirmary."
[cpg cn=true]



[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

[SE f="se136"]
;//【ＳＥ】ドア開ける

[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン閉／蝋燭）******************************************************

[WAIT time=1500]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna116"]
[OnName num="Yuna"]
"Oh, it really does look like the infirmary at school..."
[cpg cn=true]

I didn't remember when, but I had heard this before.
[cpg]

Inside the room, there was a white bed like the ones in a hospital.
[cpg]

There was an IV setup and a medicine cabinet.
[cpg]

A white curtain was hung behind it, and the room was partitioned in the middle.
[cpg]

[OnName num="Kenji"]
"Can I open it?"
[cpg cn=true]


[WAIT time=100]
[VOICE f="Michi166"]
[OnName num="Michi"]
"Go ahead."
[cpg cn=true]

[free time=800]
[SE f="se042"]
;//【ＳＥ】カーテン開ける

;//＠
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）

[WAIT time=800]
[VOICE f="Hosokawa124"]
[OnName num="Hosokawa"]
"Oh..."
[cpg cn=true]

When I opened the curtain, there was a large stainless steel laboratory table.
[cpg]

It had running water, a sink, test tubes, a flask, and a gas burner.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna117"]
[OnName num="Yuna"]
"Why is there such a setup in the infirmary?"
[cpg cn=true]

Michi replied to Yuna's question with a slight smile.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi167"]
[OnName num="Michi"]
"I have a medical license, but I was a researcher before I came here. So, I'm still doing little experiments in my spare time for my dissertation."
[cpg cn=true]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa125"]
[OnName num="Hosokawa"]
"Well, that's wonderful! That's great, Ms. Kisaragi."
[cpg cn=true]

Hosokawa's face flushed and he praised Michi.
[cpg]

[OnName num="Kenji"]
"Amazing..."
[cpg cn=true]

There was a desk next to the stainless steel table, with the latest computer and microscope.
[cpg]

The bookshelf contained a number of medical books with difficult titles, but half of them seemed to be in foreign languages that I couldn't read.
[cpg]

[OnName num="Kenji"]
"Do you speak any foreign languages, Michi?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi168"]
[OnName num="Michi"]
"Well, a little."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika226"]
[OnName num="Erika"]
"Ohー, wow. English?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi169"]
[OnName num="Michi"]
"English and German. And Latin. My French and Spanish are conversational at best."
[cpg cn=true]

[OnName num="Kenji"]
"W-wow. Why do you know so many languages...?
[cpg cn=true]

Just being conversational at best with a few languages, does that mean she was perfectly fluent in others?
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi170"]
[OnName num="Michi"]
"Papers are written in English, and medical records are written in German. Many medical terms are in Latin, so you learn it naturally. The rest of it just comes naturally."
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna118"]
[OnName num="Yuna"]
"Oh, so Hosokawa, who wants to be a doctor, is also learning foreign languages?"
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa126"]
[OnName num="Hosokawa"]
"Huh! Well, yeah! Haha...ha... Of course."
[cpg cn=true]

Apparently, Hosokawa was not on that level...
[cpg]

But, even an idiot would ask, why would someone who writes papers and does research be squandering her talents here just for one patient?
[cpg]

Someone as good as Michi , would be able to work in a big hospital or even a foreign country.
[cpg]

[WAIT time=100]
[VOICE f="Michi171"]
[OnName num="Michi"]
"Now, are we all done here?"
[cpg cn=true]

Michi prompted us to leave the infirmary.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗／懐中電灯）******************************************************

[WAIT time=1500]

We all went out into the corridor, and closed the door to the infirmary.
[cpg]

[OnName num="Kenji"]
"Finally, the only room left is..."
[cpg cn=true]

Before I could say one more thing... something happened.
[cpg]

[SE f="se043"]
;//【ＳＥ】ドンドンドンドン！！

[STOPBGM]
[WAIT time=1000]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Vex001"]
[OnName num="Erika_Yuna"]
"Aahー!"
[cpg cn=true]

[BGM f="danger"]

[OnName num="Kenji"]
"?!"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Hosokawa127"]
[OnName num="Hosokawa"]
"What is it?!"
[cpg cn=true]


[VOICE f="Michi172"]
[OnName num="Michi"]
"What?!"
[cpg cn=true]


The door of the room directly across from us began to shake and rattle with a loud noise.
[cpg]


[SE f="se043"]
;//【ＳＥ】ドンドンドンドン！！

There was a crashing sound as if something was slamming into us from the inside, and we began to shake in unison.
[cpg]

There was a killer in here!
[cpg]

[OnName num="Kenji"]
''Who is it?!"
[cpg cn=true]

I shouted with all my courage.
[cpg]

Then...
[cpg]

[free time=800]
;//？？？
[VOICE f="Syouko002"]
[OnName num="unknown"]
"Please help me~!"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shiori099"]
[OnName num="Shiori"]
"Uh..."
[cpg cn=true]

[OnName num="Kenji"]
"A woman?"
[cpg cn=true]

We all looked at each other in surprise, and at the pitiful sound of the voice that came from inside.
[cpg]

;//？？？
[VOICE f="Syouko003"]
[OnName num="unknown"]
"Open the door~!"
[cpg cn=true]

[FACE method="change_4" pos="3/5"]
[WAIT time=100]
[VOICE f="Michi173"]
[OnName num="Michi"]
It's a storage room, so it's not locked...
[cpg cn=true]

[OnName num="Kenji"]
"Oh, really?"
[cpg cn=true]

[free time=1000]


The moment I twisted the doorknob, I was taken aback...
[cpg]

;//[SE f="se000"]
;//【ＳＥ】ドザーーーーッ！

[STOPBGM]




[OnName num="Kenji"]
"Whoaー!?"
[cpg cn=true]

A woman came out and fell down the hallway like a swimmer diving into the water.
[cpg]

;//？？？
[VOICE f="Syouko004"]
[OnName num="unknown"]
"Ow, ow, ow..."
[cpg cn=true]



;//[BG f="black.ui" time=900]
;//[WAIT time=1500]
;//[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗／懐中電灯）

[FG f="CHA06_p3_01_a.ui" method="change_4" pos="2/3" time=800]

[WAIT time=1500]

[BGM f="huan"]


[FG f="CHA05_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi174"]
[OnName num="Michi"]
"Ms. Endo?!"
[cpg cn=true]

[OnName num="Kenji"]
"Do you know her...?"
[cpg cn=true]

;//？？？
[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko005"]
[OnName num="unknown"]
"Oh, I'm so sorry!"
[cpg cn=true]

The woman struggling to stand up, when I looked at her calmly, I saw that she was wearing a nurse's uniform.
[cpg]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori100"]
[OnName num="Shiori"]
"Why are you...in such a place?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika227"]
[OnName num="Erika"]
"Who is this person?"
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi175"]
[OnName num="Michi"]
"This person is..., a nurse at the hospital where I work, Shoko Endo."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko006"]
[OnName num="Syouko"]
"Ni-nice to meet you! My name is Shoko Endo! Ooh..ah...ah..."
[cpg cn=true]

Shoko, who had greeted everyone cheerfully and bowed her head as much as she could, suddenly distorted her face and arched her back.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna119"]
[OnName num="Yuna"]
"Oh my God, you're hurt!?"
[cpg cn=true]

She must have gotten hurt when she fell earlier.
[cpg]

Shoko's knee was bleeding.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi176"]
[OnName num="Michi"]
“It can’t be helped… Let’s hear you out while we get you taken care of.”
[cpg cn=true]

Thus, with the mysterious nurse, we entered the infirmary again.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）******************************************************

[WAIT time=1500]

[free time=1000]
;**【ＣＧ】ev_04_0 ***********************
[CG id=03 index=0 time=1000]
;*****************************************

[WAIT time=1000]


[WAIT time=100]
[VOICE f="Syouko007"]
[OnName num="Syouko"]
"Aaaaah~, it hurts, doctor!"
[cpg cn=true]

[WAIT time=100]
[VOICE f="Michi177"]
[OnName num="Michi"]
"Be quiet!"
[cpg cn=true]

Shoko seemed unconcerned about our tense atmosphere, and Michi's hands were steady and calm as she tended to her wounds.
[cpg]

[WAIT time=100]
[VOICE f="Michi178"]
[OnName num="Michi"]
"So, why were you in there?"
[cpg cn=true]

[WAIT time=100]
[VOICE f="Syouko008"]
[OnName num="Syouko"]
"Ah, yes! You see, I came to the Tokita residence to deliver Shiori's medicine like you had asked."
[cpg cn=true]

[VOICE f="Syouko1008"]
[OnName num="Syouko"]
"But no one was home, so I thought you must had been at the library, so I came here."
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_2" pos="2/3" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="1/3" time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="3/3" time=1000]
[BG f="b_l_b1_disp_0.ui" time=1000]
[WAIT time=1500]
[VOICE f="Erika228"]
[OnName num="Erika"]
"How did you get in here?"
[cpg cn=true]

That's what we all wanted to know.
[cpg]

If there was a way in, then there must be a way out!
[cpg]



[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko009"]
[OnName num="Syouko"]
"What? I just entered through the front door."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna120"]
[OnName num="Yuna"]
"Huh?! You could open the door?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko010"]
[OnName num="Syouko"]
"Yes? I could open it."
[cpg cn=true]

[free time=1]
[WAIT time=1]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika229"]
[OnName num="Erika"]
"Ehー?!"
[cpg cn=true]


[VOICE f="Hosokawa128"]
[OnName num="Hosokawa"]
"Whatー?!"
[cpg cn=true]

[free time=1000]
[SE f="se044"]
;//【ＳＥ】２人走り出て行く
[OnName num="Kenji"]
"Oh, Erika!"
[cpg cn=true]

As soon as they heard what Shoko said, Hosokawa and Erika ran out.
[cpg]

But they soon came back...
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika230"]
[OnName num="Erika"]
"It wouldn't open! Liar!"
[cpg cn=true]

[VOICE f="Hosokawa129"]
[OnName num="Hosokawa"]
"Tell us how you really got in!"
[cpg cn=true]

They shouted at Shoko.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA06_p3_01_a.ui" method="change_5" pos="2/3" time=800]

[VOICE f="Syouko011"]
[OnName num="Syouko"]
"Uh? What?"
[cpg cn=true]

Michi asks again, since Shoko was seemingly unsure why they were angry.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi179"]
[OnName num="Michi"]
"You came in here, through the front door, and then what happened?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko012"]
[OnName num="Syouko"]
"Yes! Um, well...Oh, that's right! I looked in both rooms, but neither the doctor nor Shiori were there."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko1012"]
[OnName num="Syouko"]
“So I headed down to the basement, thinking you must be in the infirmary. Then…what? What happened next?”
[cpg cn=true]

[OnName num="Kenji"]
"Ugh..."
[cpg cn=true]

I think she may have hit her head.
[cpg]

That's how frustrating the conversation was.
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko013"]
[OnName num="Syouko"]
"Oh, yeah! There was a loud noise! It was the emergency bell! Suddenly, the emergency bell rang, and an earthquake was comingー"
[cpg cn=true]

[VOICE f="Syouko1013"]
[OnName num="Syouko"]
"I thought I needed to hideー, so I jumped into a random room!"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa130"]
[OnName num="Hosokawa"]
"Oh..., the emergency bell...?"
[cpg cn=true]

[OnName num="Kenji"]
"So you're saying that...Shoko came here..."
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna121"]
[OnName num="Yuna"]
"Two days ago...?"
[cpg cn=true]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika231"]
[OnName num="Erika"]
"Haaaaah?!"
[cpg cn=true]


[free time=1]
[WAIT time=1]
[FG f="CHA06_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko014"]
[OnName num="Syouko"]
"Huh? Two days? Eh? What?"
[cpg cn=true]

How could such an absurd thing happen?
[cpg]

So that means, this person has been cooped up in here for two days?
[cpg]

I couldn't believe it, that was...
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika232"]
[OnName num="Erika"]
"Unbelievable! She's our suspect!"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko015"]
[OnName num="Syouko"]
"Suspect?"
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika233"]
[OnName num="Erika"]
"My phone, give it back!"
[cpg cn=true]

Her phone was the priority?
[cpg]

But when I pulled Erika away from Shoko, who she was grabbing onto...
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko016"]
[OnName num="Syouko"]
"Ah! Ow, ouch! My head...hurts."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi180"]
[OnName num="Michi"]
"Huh? What's wrong? Let me see."
[cpg cn=true]

Clutching her head, Shoko suddenly moaned, while Michi parted her hair, surprised.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi181"]
[OnName num="Michi"]
"It's a huge...bump."
[cpg cn=true]

When we all took a look, we could see that the top of Shoko's head was swollen.
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko017"]
[OnName num="Syouko"]
"Oh!"
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika234"]
[OnName num="Erika"]
"What is it now?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko018"]
[OnName num="Syouko"]
"I remembered! I ran into that room, and right after I clung to the legs of the shelf, I heard a loud boom!"
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Shiori101"]
[OnName num="Shiori"]
"I'll go check it out..."
[cpg cn=true]

[move from="3/3" to="5/3" ease="easeInOutSine" time=1000]
We nodded our heads at what Shoko said as Shiori left the infirmary.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa131"]
[OnName num="Hosokawa"]
"Anyhow, this is an...impressive bump."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna122"]
[OnName num="Yuna"]
"A bump... Like what kids get..."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko019"]
[OnName num="Syouko"]
"Thank you very much!"
[cpg cn=true]

That was not a compliment.
[cpg]

Definitely, not a compliment.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=800]
[VOICE f="Shiori102"]
[OnName num="Shiori"]
"That's what was on the floor in that room.."
[cpg cn=true]

;//恐竜の頭蓋骨を抱えた栞
[OnName num="Kenji"]
"Whoa!"
[cpg cn=true]

Shiori came in, carrying what was the skull of some large animal.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa132"]
[OnName num="Hosokawa"]
"An animal..., no, this is a dinosaur head."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi182"]
[OnName num="Michi"]
"Oh..."
[cpg cn=true]

Apparently, this was the cause of Shoko's bump.
[cpg]

She really had hit her head...
[cpg]

But why was this thing in that room?
[cpg]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi183"]
[OnName num="Michi"]
"That room is also a storage room, but it's filled with the founder's hobby collection of antiques..., it's mostly junk."
[cpg cn=true]

[VOICE f="Michi1183"]
[OnName num="Michi"]
"If you shake the shelves, that stuff is going to...fall down."
[cpg cn=true]

Michi said as she placed an ice pack on Shoko's head.
[cpg]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa133"]
[OnName num="Hosokawa"]
"So Ms. Endo has been out cold for two days..., Huh..."
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko020"]
[OnName num="Syouko"]
"Um, what are you talking about, two days, what two days?"
[cpg cn=true]

[OnName num="Kenji"]
"You know, while you were unconscious, two days have passed."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko021"]
[OnName num="Syouko"]
"What? Really? W-what should I do?"
[cpg cn=true]

It took her a while, but Shoko finally grasped the situation and started to panic.
[cpg]

But it was a little different from the reaction I had imagined.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko022"]
[OnName num="Syouko"]
"I didn't record that drama I watch every week! Ohhh, I missed it..."
[cpg cn=true]

[OnName num="Kenji"]
"Huh."
[cpg cn=true]

This person was...weird!
[cpg]

Was she a little off, or was this her usual self?
[cpg]

There were so many things that still needed to be explained, but I was hesitant about where to start.
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko023"]
[OnName num="Syouko"]
"Ah! It's no good!"
[cpg cn=true]

[OnName num="Kenji"]
"What is it now?"
[cpg cn=true]

[move from="2/3" to="6/3" ease="easeInOutSine" time=1000]


Shoko stood up abruptly and walked out of the infirmary in a hurry.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika235"]
[OnName num="Erika"]
"What the hell. was that? Hey! Wait! Are you running away?!"
[cpg cn=true]

Where was there to run to?
[cpg]

[move from="2/3" to="5/3" ease="easeInOutSine" time=1000]


But Erika hurriedly headed for the door herself.
[cpg]

Then...
[cpg]

[free time=1]
[WAIT time=1]

[SE f="se045"]
;//【ＳＥ】ぶつかる（ドカッ！）


[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika236"]
[OnName num="Erika"]
"Aaah!"
[cpg cn=true]

[WAIT time=100]
[VOICE f="Syouko024"]
[OnName num="Syouko"]
"Wahー!"
[cpg cn=true]

[SE f="se045"]
;//【ＳＥ】ドシャーーーッ！

[move from="2/5" to="1/3" ease="easeInOutSine" time=500]
[move from="4/5" to="3/3" ease="easeInOutSine" time=500]


Shoko and Erika, who were returning at the same speed, collided head-on, sending them both flying in opposite directions.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika237"]
[OnName num="Erika"]
"Ouch!"
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko025"]
[OnName num="Syouko"]
"Oh, sorry! I'm sorry!"
[cpg cn=true]

[SE f="se046"]
;//【ＳＥ】ビニール袋ガサガサ
Suddenly, tons of medicine from the plastic bag that Shoko was carrying, scattered on the floor.
[cpg]

[OnName num="Kenji"]
"Are you okay?!"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna123"]
[OnName num="Yuna"]
"I'll help you."
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko026"]
[OnName num="Syouko"]
"I'm sooorrry!"
[cpg cn=true]

[free time=1000]

I crouched down and picked up a sheet that contained pills.
[cpg]

There seemed to be several different types of medicine, some with white grains, some with orange, some with silver sheets, some with green, among many others.
[cpg]

I wasn't sure how many different kinds of pills Shiori was taking...
[cpg]

The back of the wide sheet I picked up said "Citalopram".
[cpg]

Cital...ro...plan? I had never heard of that drug.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi184"]
[OnName num="Michi"]
"Thank you. I'll take it over from here."
[cpg cn=true]

Michi unfolded the bag and gathered the medicines that everyone had collected.
[cpg]

I wonder if Shiori...was so sick that she needed that much medicine.
[cpg]

What kind of illness did she have...?
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_7" pos="1/2" time=800]
[WAIT time=100]
[VOICE f="Erika238"]
[OnName num="Erika"]
"Hey, Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

While I was absent-mindedly thinking, Erika began talking to me in private.
[cpg]

[FACE method="change_3" pos="1/2"]
[WAIT time=100]
[VOICE f="Erika239"]
[OnName num="Erika"]
"I still think she's suspicious. Isn't it strange that she was only unconscious for two days? She must have gone and hit her head after finishing whatever she was up to.”
[cpg cn=true]

[OnName num="Kenji"]
"Hmmm..."
[cpg cn=true]

It was hard to believe that she was passed out the whole time.
[cpg]

But it wasn't as if such things were unheard of.
[cpg]

I've heard of people being in a coma for days after an accident, and anyway, if two days of unconsciousness wasn't possible, Michi would have pointed it out.
[cpg]

[OnName num="Kenji"]
"It's a little difficult to hit the top of your own head by yourself, isn't it?"
[cpg cn=true]

That one famous video game character with a beard would probably just jump right under a brick block, but it's hard to imagine a flesh-and-blood woman jumping to the ceiling or charging into a wall like a raging bull.
[cpg]

[FACE method="change_3" pos="1/2"]
[WAIT time=100]
[VOICE f="Erika240"]
[OnName num="Erika"]
''Anyway, we should keep an eye on her."
[cpg cn=true]

[OnName num="Kenji"]
"Uh, yeah..."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi185"]
[OnName num="Michi"]
"Now that Ms. Endo has been treated, let's go back to the first floor."
[cpg cn=true]

At Michi's command, we marched back up the stairs again.
[cpg]

From behind, I watched them form a single file and thought it looked like something out of an RPG, and I chuckled to myself a little.
[cpg]

Michi was the healer, Hosokawa was the monk, Erika was the warrior, and Yuna was the mage.
[cpg]

I wondered if the ditzy Ms. Endo was the flirt?
[cpg]

And Shiori was the...princess.
[cpg]

If Shiori was the princess, I would be the knight.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************
[WAIT time=1500]
[BGM f="silent"]

[FG f="CHA03_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika241"]
[OnName num="Erika"]
"Kenji, you can go ahead..."
[cpg cn=true]

[OnName num="Kenji"]
"Huh? Oh, yeah... Okay..."
[cpg cn=true]

On our way up the basement stairs to the entrance, Erika and Yuna urged me to go ahead.
[cpg]

It is likely that they remembered that there was Takagi's dead body ahead of them and their legs wouldn't move.
[cpg]

It was understandable.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA06_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko027"]
[OnName num="Syouko"]
"What's wrong with you?"
[cpg cn=true]

[OnName num="Kenji"]
"Um..., actually..."
[cpg cn=true]

Come to think of it, I realized that no one had told Shoko, but she had lightly walked away.
[cpg]

As a result...
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko028"]
[OnName num="Syouko"]
"What, what, what? Uh, uh... Ughhhh."
[cpg cn=true]

[free time=1000]
[WAIT time=1500]


[SE f="se047"]
;//【ＳＥ】昏倒（ドサッ！）

[WAIT time=1500]

[OnName num="Kenji"]
"Eeeeeeeeeeeeek!"
[cpg cn=true]

As soon as she saw the corpse, Shoko collapsed on the spot.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi186"]
[OnName num="Michi"]
"It's just a vagal response. She’s a nurse, so she should be more professional..."
[cpg cn=true]

Michi ran over to her, and touched her eyelids and neck a little with her fingers and then let her be.
[cpg]

[OnName num="Kenji"]
"Vaga...what was that again?"
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa134"]
[OnName num="Hosokawa"]
"Even I know that much. The vagus nerve reflex is a reflex in which external stimuli are transmitted to the central nervous system by afferent fibers of the vagus nerve."
[cpg cn=true]

[VOICE f="Hosokawa1134"]
[OnName num="Hosokawa"]
"And the centrifugal fibers of the vagus nerve form a life-supporting defense response in the peripheral organs or organs of effect."
[cpg cn=true]


[OnName num="Kenji"]
"What?"
[cpg cn=true]

You know, Hosokawa explained it in great detail, but I didn't understand any of it.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika242"]
[OnName num="Erika"]
"I don't get it at all! Don't you think you should give up trying to become a doctor?"
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa135"]
[OnName num="Hosokawa"]
"W-what?"
[cpg cn=true]

While Erika and Hosokawa were bickering, Shiori tugged on my sleeve and whispered to me.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori103"]
[OnName num="Shiori"]
"Simply put, she fainted... "
[cpg cn=true]

[OnName num="Kenji"]
"Oh, really? Thanks a lot."
[cpg cn=true]

When I thanked her, Shiori looked away, a little embarrassed.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori104"]
[OnName num="Shiori"]
"I don't think Shoko was lying when she said..."
[cpg cn=true]

[OnName num="Kenji"]
"I think so too."
[cpg cn=true]

If she fainted that easily, no wonder she was out for a couple of days after hitting her head.
[cpg]

[SE f="se037"]
;//【ＳＥ】腹が鳴る
At the sound of a stomach growl.
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori105"]
[OnName num="Shiori"]
"Oh..., you're hungry..., aren't you?"
[cpg cn=true]

[OnName num="Kenji"]
"That wasn't me!"
[cpg cn=true]

I was hungry, but not hungry enough to make stomach noises.
[cpg]
[free time=1000]
[SE f="se037"]
;//【ＳＥ】腹が鳴る
[WAIT time=3000]
[VOICE f="Syouko029"]
[OnName num="Syouko"]
"Mm-hmm... Spaghetti Napolitan!"
[cpg cn=true]

Shoko was still unconscious, her stomach rumbling and deliriously demanding Spaghetti Napolitan.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi187"]
[OnName num="Michi"]
"That's not going to happen..."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna124"]
[OnName num="Yuna"]
But, she must be starving. She hasn't eaten for two days."
[cpg cn=true]

That was a good point.
[cpg]

If what Shoko said is true, while she was unconscious, she hadn't had anything to eat or drink.
[cpg]

That was just too pitiful.
[cpg]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika243"]
[OnName num="Erika"]
"Hey, where are we going to eat? Do you want to go to the other room?"
[cpg cn=true]

[OnName num="Kenji"]
"Yeah..."
[cpg cn=true]

Takagi's corpse was lying in the entrance where we had been having our meals.
[cpg]

I'd rather not...eat there.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Shiori106"]
[OnName num="Shiori"]
"If you are going to eat, please do so in a room without books."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah..."
[cpg cn=true]

The only rooms in this building that didn't have books were the storage room and the security room.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika244"]
[OnName num="Erika"]
“Why? It can't be helped, we’re in a state of emergency after all."
[cpg cn=true]

Erika began to complain about Shiori's request.
[cpg]

When the two of them started getting into it, Michi, who was looking at them with her arms folded, turned her head and spoke.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi188"]
[OnName num="Michi"]
"Kenji, Mr. Hosokawa."
[cpg cn=true]

[OnName num="Kenji"]
"Yes?"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi189"]
[OnName num="Michi"]
"I'm sorry, but I need you two to move the body to the infirmary."
[cpg cn=true]

[OnName num="Kenji"]
"Uh..."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa136"]
[OnName num="Hosokawa"]
"What?!"
[cpg cn=true]

Both Hosokawa and I couldn't help but be astonished by her instructions.
[cpg]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Hosokawa137"]
[OnName num="Hosokawa"]
"No, I can't do it!"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi190"]
[OnName num="Michi"]
"Why not?"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa138"]
[OnName num="Hosokawa"]
"Since it's a homicide, we're supposed to keep the crime scene intact, right?"
[cpg cn=true]

I knew that, too.
[cpg]

Tampering or moving evidence from the scene of a murder will get us in trouble with the police later.
[cpg]

I've seen it on TV crime dramas.
[cpg]

However, Michi, unfazed, responded coolly.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi191"]
[OnName num="Michi"]
"If you leave it here, you'll see it every time you go upstairs or to the bathroom."
[cpg cn=true]

[VOICE f="Michi1191"]
[OnName num="Michi"]
"And, fortunately, it's winter now, but we can't be sure it won't start to rot. It's not good for your health or your mind."
[cpg cn=true]

[OnName num="Kenji"]
"R-rot..."
[cpg cn=true]

That meant...that the body was going to rot...
[cpg]

I remembered the pack of meat that my mother had forgotten in the fridge, which was ten days past its expiration date.
[cpg]

It was in the fridge, so I thought it would be good, but when I removed the plastic, I smelled that indescribable odor...
[cpg]

It was a fishy, rotten smell that stuck in my nostrils...
[cpg]

I was wondering if something like that could waft from a human being...
[cpg]

[OnName num="Kenji"]
"Understood..."
[cpg cn=true]

What else could I say?
[cpg]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa139"]
[OnName num="Hosokawa"]
"H-hey, Azuma!"
[cpg cn=true]

Hosokawa was not happy, but I had other things on my mind.
[cpg]

[OnName num="Kenji"]
"I feel sorry about Takagi, but I also feel sorry for the girls if we leave the body here."
[cpg cn=true]

Hosokawa seemed to agree with this idea, and reluctantly followed Michi's instructions.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa140"]
[OnName num="Hosokawa"]
"I get it..."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA08_p3_01_a.ui" method="change_4" pos="2/3" time=800]
Me and Hosokawa rolled over Takagi's body and put our arms around the corpse's knees and sides and tried to lift it.
[cpg]

[OnName num="Kenji"]
"U-ugh."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa141"]
[OnName num="Hosokawa"]
"So h-heavy..."
[cpg cn=true]

Eighty kilograms? A hundred kilograms?
[cpg]

Even so, it would weigh 50 kilos if two people carried it together, but it felt so much heavier.
[cpg]

My father once injured his back by lending his shoulder to a drunk, and I wondered if a dead human body could be so heavy...
[cpg]

On top of that, this was Takagi, who had a body like a lower level sumo wrestler.
[cpg]

Anyway, Hosokawa, who was like a walking stick insect, and I, were not strong enough.
[cpg]

[OnName num="Kenji"]
"Uhhhh, please carry it properly!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa142"]
[OnName num="Hosokawa"]
"I am!"
[cpg cn=true]

We walked a few steps, and then took a break, walked a few steps, and then took another break. Little by little, we moved Takagi's body underground.
[cpg]

It was heavy, but what was harder was that Takagi's body was surprisingly cold.
[cpg]

The body of a person who was ice cold and stiff.
[cpg]

I've attended funerals before, so it wasn't the first time I had seen a dead body, but...this was hard.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗／懐中電灯）******************************************************

[WAIT time=1500]


[FG f="CHA08_p3_01_a.ui" method="change_4" pos="2/3" time=800]

As I struggled down the narrow stairs, I felt as if I had become an ant.
[cpg]

One of those ants that take the corpses of their dead comrades back to the nest with them.
[cpg]

I wondered what happened to the corpses after that.
[cpg]

Did they mourn them, or did they..?
[cpg]

No more. I didn't want to think about it.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa143"]
[OnName num="Hosokawa"]
"U-uh..."
[cpg cn=true]

[SE f="se047"]
;//【ＳＥ】ドサッ！

;//[SE f="se000"]
;//【ＳＥ】ジュッ…

[OnName num="Kenji"]
"Aah!!"
[cpg cn=true]

Unable to bear the weight, Hosokawa's hand slipped and the body fell to the floor.
[cpg]

As he did, he came into contact with a candle that was standing on the floor.
[cpg]

[OnName num="Kenji"]
"...ugh."
[cpg cn=true]

There was a faint smell of burning skin in the air.
[cpg]

It was a disgusting, yet strange smell that I had smelled somewhere before.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa144"]
[OnName num="Hosokawa"]
"What are you doing?!"
[cpg cn=true]

[OnName num="Kenji"]
"M-me?!"
[cpg cn=true]

I'm sure it was Hosokawa that let go, but for some reason he yelled at me.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa145"]
[OnName num="Hosokawa"]
"You're the one who burnt the body! You're gonna have to explain yourself to the police. Okay?"
[cpg cn=true]

[OnName num="Kenji"]
"..............."
[cpg cn=true]

I had an indescribable feeling of dread when Hosokawa yelled hysterically.
[cpg]

No matter how skinny he was, he still had to be stronger than a girl.
[cpg]

The only men here were me and this guy.
[cpg]

I didn't kill Takagi, so I guess he had to be the killer...
[cpg]

I remembered what Erika had said.
[cpg]

;//<回想>-----------------------------

;//＠
[free time=900]
[BG f="white.ui" time=900]
[WAIT time=1500]
[BG f="cg_refrain_ep006.ui" time=1000]
;//[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=1500]


;//[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika245"]
[OnName num="Erika"]
"Kenji wouldn't do it, so you're the only one who could have!"
[cpg cn=true]

;//[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika246"]
[OnName num="Erika"]
"In these situations it's very dangerous to split up."
[cpg cn=true]

;//<回想明け>-------------------------
;//＠

[free time=900]
[BG f="white.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗／懐中電灯）******************************************************

[WAIT time=1500]


Was it safe for me to be alone with Hosokawa?
[cpg]


[BG f="black.ui" time=900]
[WAIT time=1500]

[SE f="se136"]
;//【ＳＥ】ドア開ける

[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）******************************************************

[WAIT time=1500]


[FG f="CHA08_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa146"]
[OnName num="Hosokawa"]
"I guess we should put it on the bed..."
[cpg cn=true]

The expression "put it on the bed".
[cpg]

It meant that Hosokawa already started thinking of Takagi as an object.
[cpg]

I felt a needless sense of regret, thinking that if I had gone with him instead of turning back then, none of this would have happened...
[cpg]

[OnName num="Kenji"]
"I don't think...the bed is such a good idea..."
[cpg cn=true]

If Shiori or anyone else got sick, they would need this bed.
[cpg]

Me and Hosokawa lifted Takagi's corpse up onto the stainless steel table and laid it face down like it was at the entrance.
[cpg]

[OnName num="Kenji"]
".................."
[cpg cn=true]

The knife in his back seemed so painful, that we couldn't bear to look at it.
[cpg]

In the meantime, to pay my respects, I pressed my hands together in front of the body.
[cpg]

Hosokawa looked at me,
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa147"]
[OnName num="Hosokawa"]
"Hmm..."
[cpg cn=true]

He said, with a snort.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa148"]
[OnName num="Hosokawa"]
"That won't bring the dead back to life."
[cpg cn=true]

[OnName num="Kenji"]
"That's true, but don't you feel sorry for him?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa149"]
[OnName num="Hosokawa"]
"Of course I feel sorry. But I don't believe in spirituality."
[cpg cn=true]

I thought that was cold, but I wasn't a religious person either, so I let it slide and closed the curtain.
[cpg]

[SE f="se042"]
;//【ＳＥ】カーテン締める

;//＠
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン閉／蝋燭）


[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa150"]
[OnName num="Hosokawa"]
"If Ms. Kisaragi wants to examine the body, I'd like to help. I'd learn a lot."
[cpg cn=true]

[OnName num="Kenji"]
"Uh, examine the body..."
[cpg cn=true]

That thought never occurred to me, It was unnerving.
[cpg]

But, Hosokawa seemed to be a little excited about it.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa151"]
[OnName num="Hosokawa"]
"You don't know this, but the sooner you do the autopsy, the better. Since the condition of the body changes every minute."
[cpg cn=true]

[OnName num="Kenji"]
"An autopsy?!"
[cpg cn=true]

Here?
[cpg]

An autopsy in the library's infirmary?
[cpg]

[OnName num="Kenji"]
"B-but, it's not like we don't already know the cause of death... Besides, Michi said herself she's not a coroner so..."
[cpg cn=true]

When I said that to Hosokawa, he chuckled and fidgeted with his glasses.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa152"]
[OnName num="Hosokawa"]
"I'm kidding. You can't take a joke, can you?"
[cpg cn=true]

A joke...
[cpg]

I doubted that Hosokawa was in his right mind to make such a joke at a time like this.
[cpg]

Even though a person was murdered, was this how all people who study medicine acted?
[cpg]

Michi too?
[cpg]

No way.
[cpg]

This guy must be a little crazy.
[cpg]

Only Hosokawa. He was the only one who thought like that.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=2500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=1500]


[BGM f="serious"]


[FG f="CHA06_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko030"]
[OnName num="Syouko"]
"Om, nom, nom! Munch, munch, munch!"
[cpg cn=true]

Back at the entrance, Shoko was devouring a can of food.
[cpg]

As Yuna predicted, Shoko's stomach must have been empty after not eating or drinking anything for two days.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko031"]
[OnName num="Syouko"]
"It's delicious! Mmmm! Nom, nom! Munch, munch, munch!"
[cpg cn=true]

Shoko shoveled the corned beef into her mouth as if she had no shame or self-respect.
[cpg]

The way she was kind of... energetic, was hard to hate somehow.
[cpg]

If only that hadn't happened, this scene would have been hilarious, but no one was smiling.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika247"]
[OnName num="Erika"]
"You know, it feels like no one is coming today either. That doesn't seem good... And on top of that, we have one more person to feed, is there enough food to go around?"
[cpg cn=true]

Certainly, the increase in the number of people in a place with limited food was a cause for concern.
[cpg]

I had agreed with Erika too, until I thought more logically...
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna125"]
[OnName num="Yuna"]
"But..., there's one less person, so our numbers haven't changed..."
[cpg cn=true]

silence
[cpg]

They all quieted down at Yuna's calm words.
[cpg]

With the death of Takagi and the addition of Shoko, there was no change...
[cpg]

It was a horrible, but obvious fact.
[cpg]

.........
[cpg]

;//＠
[free time=1000]
;**【ＣＧ】ev_14_a ***********************
[CG id=13 index=1 time=1000]
;*****************************************
[WAIT time=2000]


;//[free time=1]
;//[WAIT time=1]
;//[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/5" time=800]
;//[FG f="CHA05_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi192"]
[OnName num="Michi"]
"Shiori, try to eat a little. I understand how you're all feeling, but you need to get something in your stomach."
[cpg cn=true]

Concerned about Shiori, who was still pale, Michi urged us to eat as well.
[cpg]

I could put a spoon in my hand, but it felt very heavy.
[cpg]

I was hungry, but I didn't have an appetite.
[cpg]

I knew I needed to eat, but I couldn't get my mouth or hands to move.
[cpg]

;//[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi193"]
[OnName num="Michi"]
"See..."
[cpg cn=true]

.........
[cpg]

Michi took a plastic spoon and placed some porridge near Shiori's mouth.
[cpg]

Even so, Shiori couldn't even get half of the spoon into her mouth and shook her head weakly.
[cpg]



[free time=900]
[BG f="black.ui" time=900]
[WAIT time=2500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=1500]


[FG f="CHA06_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko032"]
[OnName num="Syouko"]
"Um..., I'm sorry... It's my fault that we are all in this mess."
[cpg cn=true]

She probably got caught up on the situation while me and Hosokawa were in the infirmary.
[cpg]

Shoko bowed to me with a sorry look on her face.
[cpg]

[OnName num="Kenji"]
"It's not your fault, Ms. Endo."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi194"]
[OnName num="Michi"]
"That's right. It's a good thing you were here to help. I was almost out of Shiori's medicine."
[cpg cn=true]

Michi tried to comfort Shoko.
[cpg]

"Yes, the medicine..."
[cpg]

There was one thing I had been wondering about.
[cpg]

Was it normal for a doctor to order a nurse to deliver medicine?
[cpg]

A nurse from a general hospital at that?
[cpg]

[OnName num="Kenji"]
"Does Ms. Endo always deliver medicine?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko033"]
[OnName num="Syouko"]
"No, not always. The delivery of a certain medicine was delayed this month, and it just so happened that the doctor wasn't working when it arrived..."
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi195"]
[OnName num="Michi"]
"Ms. Endo, it's fine. It's rare, but sometimes at the end of the year or before the holidays, we run out of certain medicine."
[cpg cn=true]

Michi interrupted Shoko, and kept going.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko034"]
[OnName num="Syouko"]
"In addition, if the pharmaceutical company is overseas, it may be held up at customs."
[cpg cn=true]

[FACE method="change_7" pos="1/3"]

[OnName num="Kenji"]
"Oh..."
[cpg cn=true]

Shoko suddenly interjected, amd Michi's expression grew dark.
[cpg]

Perhaps this nurse was quite the chatterbox?
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa153"]
[OnName num="Hosokawa"]
"I can't believe it's already this late..."
[cpg cn=true]

The sun, which could be seen through the skylight, was setting and the room was getting darker.
[cpg]

We found a dead body in the morning, searched the house, and then there was the Shoko mess... The day was coming to an end.
[cpg]

That meant, we were spending the night here again, right?
[cpg]

Perhaps no help was coming tomorrow or the day after.
[cpg]

An inexplicable feeling of anxiety spreads like a dark cloud in my head.
[cpg]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi196"]
[OnName num="Michi"]
"Since this is the situation, Ms. Endo, you should rest in the same room as Erika and Yuna."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko035"]
[OnName num="Syouko"]
"Oh, ye..."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika248"]
[OnName num="Erika"]
"You're kidding, right?!"
[cpg cn=true]

Without even waiting for Shoko's reply to Michi's instructions, Erika shouted.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika249"]
[OnName num="Erika"]
"I can't be in the same room as a possible murderer! Pick a different room!"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko036"]
[OnName num="Syouko"]
"No..., I'm innocent..."
[cpg cn=true]

After being accused, Shoko slumped down in shame.
[cpg]

Then Hosokawa started talking like Erika.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Hosokawa154"]
[OnName num="Hosokawa"]
"If only! I don't want to be in the same room as him either. The possibility is even higher for him than for Ms. Endo!"
[cpg cn=true]

[OnName num="Kenji"]
"I understand..."
[cpg cn=true]

To be honest, there was a part of me that was relieved that Hosokawa was the one to bring it up.
[cpg]

So I asked Michi if I could move to the room with all the special reference books.
[cpg]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi197"]
[OnName num="Michi"]
"If you're okay with that..., So, Ms. Endo will...uh..."
[cpg cn=true]

When Michi pondered a bit, Shoko raised her hand cheerfully and chimed in.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko037"]
[OnName num="Syouko"]
"I can sleep anywhere! I can sleep in a closet or the storage room!"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi198"]
[OnName num="Michi"]
"Okay, so you can sleep in the basement pantry."
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko038"]
[OnName num="Syouko"]
"Yes! I'll be responsible for protecting the food!"
[cpg cn=true]

I felt nothing but anxiety as Shoko gave me a military salute.
[cpg]

She was probably going to have another bad night's sleep or something and hit her head with a can that fell off the shelf...
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori107"]
[OnName num="Shiori"]
"Wait..."
[cpg cn=true]

As I was imagining what could happen, Shiori interrupted.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori108"]
[OnName num="Shiori"]
"It's just that the pantry..."
[cpg cn=true]

[OnName num="Kenji"]
"What's wrong?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori109"]
[OnName num="Shiori"]
"The pantry is..."
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

I waited carefully to see what Shiori was going to say, but Erika impatiently spoke up.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika250"]
[OnName num="Erika"]
"Oh! That's right! No way you can stay there, because you might steal the food. "
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko039"]
[OnName num="Syouko"]
"No, I won't do th-that..."
[cpg cn=true]

On top of murder, the accusation of being a food thief, made the poor Shoko shrivel up.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori110"]
[OnName num="Shiori"]
"It's not th-that... It's that there might be rats..."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna126"]
[OnName num="Yuna"]
"Rats?!"
[cpg cn=true]

I see.
[cpg]

I understood what Shiori was worried about.
[cpg]

Rats were probably an exaggeration, but there at least might be some cockroaches.
[cpg]

They are cunning and nasty, and they have a knack for attacking even a cup of noodles or food packaging.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi199"]
[OnName num="Michi"]
"Well... If that's the case... We don't want any problems in the middle of the night."
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko040"]
[OnName num="Syouko"]
"Roger that!"
[cpg cn=true]

Hmmm.
[cpg]

If Shoko came across a cockroach she would more than likely knock the pantry shelves down.
[cpg]

Even though we hadn't known each other long, I could easily picture it.
[cpg]


;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=2000]
[free time=100]
[BG f="b_l_1f_tbr_p4.ui" time=100]
;//【ＢＧ】図書館・１階・専門書の部屋　夜（暗／蝋燭）******************************************************
[WAIT time=2000]
[transition target={false} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=3000]
[window target=true]


In the evening, I was alone in the room with the special reference books.
[cpg]

In the large, quiet room it was as cold as if I were outside.
[cpg]

When I closed my eyes, the image of Takagi's corpse when we first discovered him kept playing in my head, and I could hardly fall asleep, so I started flipping through a book.
[cpg]

[SE f="se026"]
;//【ＳＥ】ページめくる
[OnName num="Kenji"]
"I have no idea what any of this means..."
[cpg cn=true]

I grabbed the book thinking that it didn't matter which one I picked, but I couldn't understand what it said.
[cpg]

Then I checked the cover for the first time and found it was called "Conformal Field Theory and One-Dimensional Quantum Systems".
[cpg]

Just looking at the cover, I couldn't understand what it was about.
[cpg]

[OnName num="Kenji"]
"Huh..."
[cpg cn=true]

I closed the book quietly and returned it to its original shelf.
[cpg]

If it was like this, I should have just let Hosokawa stay in this room.
[cpg]

I'm sure he would have enjoyed any of the books here.
[cpg]

[OnName num="Kenji"]
"I guess I'll go for a walk to the bathroom..."
[cpg cn=true]

At least a short walk to raise my body temperature would help me sleep.
[cpg]

For that reason, I left the room with the special reference books and headed to the back of the entrance.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）男子トイレ前******************************************************

[WAIT time=1500]

[BGM f="dod"]

[OnName num="Kenji"]
".................."
[cpg cn=true]

Yesterday, I overheard the exchange between Takagi and Shiori here.
[cpg]

I wondered what happened to him after that...
[cpg]


[VOICE f="Erika251"]
[OnName num="Erika"]
"Hyah!"
[cpg cn=true]

[OnName num="Kenji"]
"What...?"
[cpg cn=true]

I heard Erika's scream from the women's restroom.
[cpg]

Immediately, the scene from yesterday replayed in my mind.
[cpg]

I could go see what's happening, but if I went, I might see something terrible again.
[cpg]

What to do...
[cpg]

;//■選択肢３（３択）
[switch]
[case "Call out to her."]
	[swap]
	[jump target="*s3_a"]
[case "Pretend I didn't hear anything."]
	[swap]
	[jump target="*s3_b"]
[case "Go check on her."]
	[swap]
	[jump target="*s3_c"]
[endswitch]
;//１，声をかけてみる　　　　　//３aへ
;//２，聞かなかったことにする　//３bへ
;//３，様子を見に行く　　　　　//３cへ
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//３a　声をかけてみる
*s3_a|The Dead Don't Talk
But I couldn't just leave her there, so I decided to call out to her from the front of the men's room.
[cpg]

[OnName num="Kenji"]
"Hey! What's wrong? Are you okayー?!"
[cpg cn=true]

Then...
[cpg]


[VOICE f="Erika252"]
[OnName num="Erika"]
"Eh?! Kenji? Why are you here?"
[cpg cn=true]

And I responded curtly.
[cpg]

[OnName num="Kenji"]
"Why? I'm on my way to the restroom! I only called out to you because I heard a scream. What's wrong with you?"
[cpg cn=true]

And then....
[cpg]


[VOICE f="Yuna127"]
[OnName num="Yuna"]
"I'm f-fine, please don't come in here!"
[cpg cn=true]

And then I heard Yuna's voice.
[cpg]

[OnName num="Kenji"]
"What, Yuna is with you too? What are you doing?"
[cpg cn=true]


[VOICE f="Erika253"]
[OnName num="Erika"]
"Don't worry about it! It's none of your business, Kenji. So get out of hereー!"
[cpg cn=true]

[OnName num="Kenji"]
"Oh, is that so?"
[cpg cn=true]

I've been told to "get out of here", even though I was just worried sick.
[cpg]

A little pissed off, I quickly took a leak and went back to bed.
[cpg]

I wasn't going to care if she screamed anymore.
[cpg]


;//３dへ合流
[jump target="*s3_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//３b　聞かなかったことにする
*s3_b|The Dead Don't Talk
Eavesdropping and snooping wasn't going to do me any good.
[cpg]

So I pretended I hadn't heard it, finished my business, and went back to bed.
[cpg]

It's better to stay away from trouble.
[cpg]

In particular, it's better to stay away from trouble like...Erika.
[cpg]


;//３dへ合流
[jump target="*s3_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//３c　様子を見に行く
*s3_c|The Dead Don't Talk
But I couldn't leave it alone, so I decided to sneak a peek inside the women's restroom.
[cpg]

Then...
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_wt_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・女子トイレ　夜（暗）******************************************************


[WAIT time=1500]

[BGM f="h1"]


;//上半身裸で、身体を拭き合っているエリカと柚那


[VOICE f="Erika254"]
[OnName num="Erika"]
"Hyah! It's cold!"
[cpg cn=true]


[VOICE f="Yuna128"]
[OnName num="Yuna"]
"I knew we should have asked someone to make some hot water."
[cpg cn=true]

Surprisingly, there the two of them were, naked from the waist up.
[cpg]

They seemed to be wiping each other's bodies with wet towels.
[cpg]


[VOICE f="Erika255"]
[OnName num="Erika"]
"No, it's too much trouble. Plus it's embarrassing."
[cpg cn=true]


[VOICE f="Yuna129"]
[OnName num="Yuna"]
"Yeah, but..."
[cpg cn=true]


[VOICE f="Erika256"]
[OnName num="Erika"]
"Anyway, wipe down my back properly."
[cpg cn=true]


[VOICE f="Yuna130"]
[OnName num="Yuna"]
"Uh, yeah..."
[cpg cn=true]


[VOICE f="Erika257"]
[OnName num="Erika"]
"Oh, my God~ It's so cold!"
[cpg cn=true]


[VOICE f="Yuna131"]
[OnName num="Yuna"]
"Goosebumps, huh?"
[cpg cn=true]


[VOICE f="Erika258"]
[OnName num="Erika"]
"I'm fine! Come on, you too."
[cpg cn=true]


[VOICE f="Yuna132"]
[OnName num="Yuna"]
"Eek~ Cold! It's cold!"
[cpg cn=true]

I didn't know why they needed to wipe down their bodies with a wet towel on such a cold night.
[cpg]

If it was summer, I could understand, but in winter, nobody sweats that much or gets that dirty.
[cpg]


[VOICE f="Erika259"]
[OnName num="Erika"]
"How is it? Do I stink? Can you smell anything?"
[cpg cn=true]


[VOICE f="Yuna133"]
[OnName num="Yuna"]
"No..., I don't think so.""
[cpg cn=true]


[VOICE f="Erika260"]
[OnName num="Erika"]
"Sniff, sniff... Yeah, you seem okay too, Yuna."
[cpg cn=true]

Seeing the exchange, I wistfully thought that they were both still girls after all.
[cpg]

Even in this situation, in this season, no one cared about body odor, but it seemed like a big concern for them.
[cpg]


[VOICE f="Erika261"]
[OnName num="Erika"]
"If I smell funny, Kenji won't like me anymore."
[cpg cn=true]


[VOICE f="Yuna134"]
[OnName num="Yuna"]
"Don't worry."
[cpg cn=true]

I was deeply moved by a maiden's desire to clean her body, even if it meant enduring the cold.
[cpg]

Erika may be like that, but she had a feminine side too.
[cpg]

I raised up my jacket and took a little sniff around my armpits.
[cpg]

Hmm...seemed fine.
[cpg]

Hopefully, help would arrive before I started to stink.
[cpg]

With this in mind, I went back to the men's room to finish taking a leak and quietly went back to bed.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_tbr_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・専門書の部屋　夜（暗／蝋燭）******************************************************

[WAIT time=1500]

Even though it was an unforeseen circumstance, I couldn't sleep even after wrapping myself in a blanket because I had seen the girls naked.
[cpg]

I knew I wanted to warm up my body, but it was mainly the lower half of my body that was getting hot.
[cpg]

[OnName num="Kenji"]
"Stop thinking...about it..."
[cpg cn=true]

Getting excited over my classmates was not good.
[cpg]

And it was rude of me to spy on them.
[cpg]

I picked up the book I had given up on earlier and flipped through the pages again.
[cpg]

[SE f="se026"]
;//【ＳＥ】ページめくる
[OnName num="Kenji"]
"Ugh..."
[cpg cn=true]

It had an immediate effect.
[cpg]

Before I could read more than a few lines, my eyelids grew heavy and I sank into a long awaited sleep.
[cpg]


;//３dへ合流
[jump target="*s3_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//３d
*s3_d|The Dead Don't Talk

[STOPBGM]
;//＠
;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=3000]
How much time has passed...?
[cpg]

[SE f="se063"]
;//【ＳＥ】ガサゴソ

[WAIT time=1000]

[OnName num="Kenji"]
"Uh-uh..."
[cpg cn=true]

[SE f="se063"]
;//【ＳＥ】ガサゴソ

[WAIT time=1000]

[OnName num="Kenji"]
"Mmm..."
[cpg cn=true]

I felt a little queasy in my stomach.
[cpg]

I was slowly awakened by a strange feeling and the first thing I remembered was what we had talked about at dinner.
[cpg]

"There might be rats..."
[cpg cn=true]

[OnName num="Kenji"]
"Rats?!"
[cpg cn=true]

I imagined a rat crawling on my stomach, and I jumped up in surprise.
[cpg]

[SE f="se049"]
;//【ＳＥ】ガバッ！！




;//[BG f="b_l_1f_tbr_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・専門書の部屋　夜（暗／蝋燭）******************************************************

[WAIT time=1500]


[VOICE f="Erika262"]
[OnName num="Erika"]
"Gah?"
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

Hearing a voice, I turned on my flashlight to see Erika crouched beside me.
[cpg]

[free time=1000]
;**【ＣＧ】ev_02_0 ***********************
[CG id=01 index=0 time=1000]
;*****************************************

[WAIT time=1500]

[BGM f="h1"]



[VOICE f="Erika263"]
[OnName num="Erika"]
"You startled me~!"
[cpg cn=true]

[OnName num="Kenji"]
"I'm the one who was startled! What the hell are you doing here at this hour?"
[cpg cn=true]

When I quickly checked my watch, it was already around midnight.
[cpg]


[VOICE f="Erika264"]
[OnName num="Erika"]
"It took Yuna forever to fall asleep."
[cpg cn=true]

[OnName num="Kenji"]
"That's not an answer! I'm asking you what the hell you are doing here."
[cpg cn=true]

I was surprised, impatient, and angry, and unable to understand what was going on, but Erika spoke with an apologetic smile.
[cpg]


[VOICE f="Erika265"]
[OnName num="Erika"]
"But~ It's scary, so... Can we sleep together?!"
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

I understand being scared. I'm scared too.
[cpg]

But didn't Erika have a roommate named Yuna?
[cpg]

So why...
[cpg]


[VOICE f="Erika266"]
[OnName num="Erika"]
"Hey~, Kenji~"
[cpg cn=true]

To my dismay, Erika put her hand on my thigh and stroked it up and down.
[cpg]


[VOICE f="Erika267"]
[OnName num="Erika"]
"Wouldn't it be lonely to be in separate rooms when we have this chance to be together?"
[cpg cn=true]

Shiver...
[cpg]

The tingling sensation in my legs turned to pleasure before my brain realized what was happening, then I looked around in dismay.
[cpg]

There was no one around, however that only applied to this room.
[cpg]

In the same enclosed space, there were several other people present.
[cpg]


[VOICE f="Erika268"]
[OnName num="Erika"]
"This is nice~, isn't it? Kenji."
[cpg cn=true]

Erika's voice echoed in the darkness.
[cpg]

I did not love Erika.
[cpg]

I was in love with Shiori.
[cpg]

I didn't know what to do...
[cpg]

;//■選択肢４（２択）
[switch]
[case "Play it cool"]
	[swap]
	[jump target="*s4_a"]
[case "Turn her down"]
	[swap]
	[jump target="*s4_b"]
[endswitch]
;//１，クールに対応する　//４aへ
;//２，だが断る　　　//４bへ
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//４a　クールに対応する
*s4_a|The Dead Don't Talk
;#############################################################
;//Ev001
;#############################################################


[VOICE f="Erika269"]
[OnName num="Erika"]
"Keeenjiii~♪"
[cpg cn=true]


[VOICE f="Erika270"]
[OnName num="Erika"]
"Stay with me till morning."
[cpg cn=true]

[OnName num="Kenji"]
"I feel sorry for Yuna. You should head back."
[cpg cn=true]

The words came out of my mouth with a coolness that surprised even me.
[cpg]


[VOICE f="Erika271"]
[OnName num="Erika"]
"What?!"
[cpg cn=true]

[OnName num="Kenji"]
"Hurry up and go back. I'm sleepy."
[cpg cn=true]


[VOICE f="Erika272"]
[OnName num="Erika"]
"All right. But, Kenji , if you get lonely, you can come find me anytime♪"
[cpg cn=true]

[OnName num="Kenji"]
"Good night."
[cpg cn=true]

Instead of responding, I kicked Erika out of the room.
[cpg]

But honestly, it was bad. Being tempted, I couldn't help but think about her. Men are pathetic creatures.
[cpg]


;//４dへ合流
[jump target="*s4_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//４b　だが断る
*s4_b|The Dead Don't Talk

;//＠
;//※＜缶詰フラグ＞確立

[stflag Canning=1]



[VOICE f="Erika273"]
[OnName num="Erika"]
"Keeenjiii~♪"
[cpg cn=true]

[OnName num="Kenji"]
"!!"
[cpg cn=true]

Erika's hand reached towards me.
[cpg]

But...
[cpg]

[OnName num="Kenji"]
"I can't!"
[cpg cn=true]

I used all my reasoning power to fight off Erika's temptation.
[cpg]

[BG f="b_l_1f_tbr_p4.ui" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/3" time=1000]
[WAIT time=1000]
[VOICE f="Erika274"]
[OnName num="Erika"]
"What? No, you don't have to re-restrain yourself!"
[cpg cn=true]

[OnName num="Kenji"]
"I'm not!"
[cpg cn=true]

Erika, who I rejected with a half-hearted shove, was angry and in disbelief.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika275"]
[OnName num="Erika"]
"Don't be a coward!"
[cpg cn=true]

[OnName num="Kenji"]
"I don't care what you say, just stop! Go back to your room!!"
[cpg cn=true]

I didn't want to make the mistake of looking at another woman in Shiori's library, let alone anywhere else!
[cpg]

I love Shiori and I didn't want to do anything to make her hate me.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika276"]
[OnName num="Erika"]
"What! You idiot, Kenji! You bullheaded man!"
[cpg cn=true]

[OnName num="Kenji"]
"Ahー, yeah, yeah. Good night!"
[cpg cn=true]

[SE f="se065"]
;//【ＳＥ】ドア乱暴に閉める
[free time=800]
[WAIT time=800]
I locked Erika out of the room with all my might.
[cpg]

[OnName num="Kenji"]
"Sigh... I'll go to the bathroom..."
[cpg cn=true]

After I took a moment to compose myself, I headed to the bathroom once more.
[cpg]

[STOPBGM]
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）男子トイレ前******************************************************

[WAIT time=1500]

[BGM f="silent"]


I was on my way to the bathroom when I heard the sound of someone's footsteps.
[cpg]

[SE f="se006"]
;//【ＳＥ】ゆっくりした足音
But where were these footsteps coming from?
[cpg]

I wondered who was walking around at this time of night.
[cpg]

Out of curiosity, I turned off my flashlight and hid behind a pillar.
[cpg]

Then...
[cpg]

;//缶詰を片腕に抱え、片手に大きなゴミ袋を持ったコトハ。ゴミ袋を持つ手に懐中電灯も持っている

[SE f="se052"]
;//【ＳＥ】足音＋ゴミ袋がガサガサ


[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=2000]
[WAIT time=1500]
.........
[cpg]

Shiori...?
[cpg]

It was Shiori coming up from the basement to the first floor.
[cpg]

In the same hand that held her flashlight, there was a large bag with something in it.
[cpg]

The rustling sound was the sound of a plastic bag.
[cpg]

In addition, Shiori was holding several canned goods in her other hand.
[cpg]

Was she going to the pantry...?
[cpg]

I figured she must just be hungry.
[cpg]

She hadn't eaten a single spoonful of food during dinner, so it's no wonder she was hungry in the middle of the night...
[cpg]

But what was with that big bag?
[cpg]

[free time=1000]
I thought it might have been a pile of garbage, but that idea was nixed when Shiori went upstairs.
[cpg]

There's no need to take the garbage upstairs.
[cpg]

During this cold season, it's hard to imagine that the kitchen garbage would stink in two days or so.
[cpg]

Anyway, all the food was canned or pre-packaged, and there was no leftover food.
[cpg]

We washed the cans before throwing them away, and the paper plates we used didn't go bad yet.
[cpg]

So what is that garbage bag for?
[cpg]

I wondered a bit, but after all, this was Shiori's library and I was just an outsider.
[cpg]

It would have been rude to question or pursue every single little thing she does.
[cpg]

It was like staying at a friend's house and pointing out that the food was different from your own back home.
[cpg]

[OnName num="Kenji"]
"That's not an easy analogy to understand..."
[cpg cn=true]

I turned back to my room, realizing how stupid my brain had become.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_tbr_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・専門書の部屋　夜（暗／蝋燭）******************************************************

[WAIT time=1500]

By the way, in my house, when we eat, we take the side dishes from the platter.
[cpg]

But when I was a little boy, my friend who came to stay at my house said, "Your house is strange" and we had a big fight.
[cpg]

When I started going to various friends' houses, I learned that both were possible, but at my age, I realized that it was polite to follow the formalities when I went to someone else's house.
[cpg]

So what Shiori did in the middle of the night, or where she went, was her choice, not mine to scrutinize.
[cpg]

I thought about it as I...wrapped myself up in a blanket and drifted off to sleep.
[cpg]


;//４dへ合流
[jump target="*s4_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//４d

*s4_d|The Dead Don't Talk

[STOPBGM]
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

[stopse g=2]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="ep007.ks" target="*start"]


