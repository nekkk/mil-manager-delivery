*start
;#################################################
*Ep002|A Gathering
;#################################################
[SCENE id=2]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BGM f="dol"]
[BG f="b_o_sr_p2.ui" time=1000]
;//【ＢＧ】その他・八重戸学園・教室　昼******************************************************

[WAIT time=1500]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika017"]
[OnName num="Erika"]
"Hey, Kenji!"
[cpg cn=true]

One day, Erika came up to my desk during break time, and she was upset for some reason.
[cpg]

[OnName num="Kenji"]
"What are you mad about?"
[cpg cn=true]


[VOICE f="Erika018"]
[OnName num="Erika"]
"What do you mean what am I mad about? You lied to me about going to the library!"
[cpg cn=true]

[OnName num="Kenji"]
"What? I wasn't lying."
[cpg cn=true]


[VOICE f="Erika019"]
[OnName num="Erika"]
"No way! I've been checking the library every day since then and I haven't seen you once!"
[cpg cn=true]

[OnName num="Kenji"]
"Checking? The library? Why?"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika020"]
[OnName num="Erika"]
"Because you said you were going to be there."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, I was there."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika021"]
[OnName num="Erika"]
"No way!"
[cpg cn=true]

[OnName num="Kenji"]
"I told you, I'm not lying."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna009"]
[OnName num="Yuna"]
"Erika, which library did you go to?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika022"]
[OnName num="Erika"]
"Which library? Duh, the public library. The one next to City Hall."
[cpg cn=true]

[OnName num="Kenji"]
"No, that's the wrong library."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika023"]
[OnName num="Erika"]
"What? There's no other library."
[cpg cn=true]

[OnName num="Kenji"]
"Well, there is."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika024"]
[OnName num="Erika"]
"No way!"
[cpg cn=true]

[OnName num="Kenji"]
"Is that all you ever say?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna010"]
[OnName num="Yuna"]
"Well… Kenji probably goes to the library near Yaeto Shrine on the outskirts of town."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika025"]
[OnName num="Erika"]
“The outskirts? There was a library there?"
[cpg cn=true]

[OnName num="Kenji"]
"You sure know your stuff."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna011"]
[OnName num="Yuna"]
"Actually, I work there part-time..."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, really?!"
[cpg cn=true]

I couldn't hide how shocked I was. It was surprising that we hadn't run into each other there yet.
[cpg]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika026"]
[OnName num="Erika"]
"Is there really a library in such a place, Kenji?"
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, well...yeah."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika027"]
[OnName num="Erika"]
"Oh, yeah. So I was hopping to conclusions."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna012"]
[OnName num="Yuna"]
"Jumping to conclusions..."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika028"]
[OnName num="Erika"]
"So...? When's the next time you're going to that library?"
[cpg cn=true]

[OnName num="Kenji"]
"Next time? I won't be able to go again for a while. Final exams are coming up."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna013"]
[OnName num="Yuna"]
"I told them I was taking time off to study for the exams."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika029"]
[OnName num="Erika"]
"That's not fair! It sucks that I'm the only one who hasn't been."
[cpg cn=true]

Erika flapped her arms and legs, throwing a tantrum.
[cpg]

Just like a kindergartener.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna014"]
[OnName num="Yuna"]
"Ahhh......, but we can all go...when the exams are over, okay?"
[cpg cn=true]

[OnName num="Kenji"]
"Uh, yeah, that's right. When exams are over..."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika030"]
[OnName num="Erika"]
"Heh~"
[cpg cn=true]

If it was just me I think it would be fine, but probably Erika didn’t like the fact that Yuna went to the same library.
[cpg]

For a while after that, Erika was pouting.
[cpg]

;//ブラックアウト
[free time=400]
[WAIT time=400]
[STOPBGM]
[BG f="black.ui" time=900]
[WAIT time=2500]

;//タイプライター音の共に表示

[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 15th
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_o_sr_p2.ui" time=1000]
;//【ＢＧ】その他・八重戸学園・教室　昼******************************************************

[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】チャイム

[WAIT time=5000]


[BGM f="dol"]


;//＠
[WAIT time=1500]

[OnName num="Kenji"]
"'Oooooohhhh, We're finally done~!"
[cpg cn=true]

[SE f="se013"]
;//【ＳＥ】喧噪
The finals week was finally over, and with the chime of the bell the whole classroom was filled with a sense of freedom.
[cpg]

Regardless of my results, I could finally get up from my desk now.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_2" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika031"]
[OnName num="Erika"]
"Keeenjiii~ ♪"
[cpg cn=true]

[OnName num="Kenji"]
"Hey."
[cpg cn=true]

Erika seemed to feel the same way, and even though she had looked like she was dead this morning, she now had a bright smile on her face.
[cpg]

[OnName num="Kenji"]
"How’d you do? Do you think you avoided failing?"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika032"]
[OnName num="Erika"]
"Geez, don't ask me something like that when we’ve just finished.”
[cpg cn=true]

[OnName num="Kenji"]
"My bad."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika033"]
[OnName num="Erika"]
"But more importantly, we're going, right?"
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, let's go. How about okonomiyaki? Ramen sounds good too though. And then karaoke after!"
[cpg cn=true]

"After exams, Erika always likes to go out and have fun in the city."
[cpg]

This was the only time I took Erika up on her offer, because I needed to blow off some steam too.
[cpg]

I'm not sure why today was different.
[cpg]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika034"]
[OnName num="Erika"]
"That's not where I want to go."
[cpg cn=true]

And all my suggestions were rejected.
[cpg]

[OnName num="Kenji"]
"Well, where then?"
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika035"]
[OnName num="Erika"]
"The library."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah..."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika036"]
[OnName num="Erika"]
"I've been waiting to go this whole time! Exams are over. So today I'm going to have you and Yuna take me to your favorite library."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna015"]
[OnName num="Yuna"]
"But I don't have work today..."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika037"]
[OnName num="Erika"]
"I don't care! If I say we're going, we're going."
[cpg cn=true]

When Erika starts talking like this she will not listen to anybody.
[cpg]

Yuna and I gave each other a look, sighed, and knew we had no choice but to go.
[cpg]

I thought I didn’t need to go to the library anymore since exams were over…, but the thought of seeing Shiori naturally lightened my mood.
[cpg]

[OnName num="Kenji"]
"Well, whatever."
[cpg cn=true]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se

[stopse g=6]
;//ループse

;//＠エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="39.png" color={0x000000ff} time=2000]
[WAIT time=2000]
[free time=100]
[BG f="black.ui" time=100]
[BG f="b_o_sky_p2.ui" time=100]
[WAIT time=100]
;//【ＢＧ】空******************************************************
[transition target={false} rule="39.png" color={0x000000ff} time=2000]
[WAIT time=2500]
[window target=true]

[BGM f="dol"]

[SE f="se019"]
;//【ＳＥ】土の道を歩く３人
;//一時的に背景は空（昼）で


[WAIT time=2000]
[VOICE f="Erika038"]
[OnName num="Erika"]
"What's this~ I didn't know about this~"
[cpg cn=true]

As we got off the bus and started walking along the forest path to the library, Erika started complaining.
[cpg]


[VOICE f="Yuna016"]
[OnName num="Yuna"]
"About what?"
[cpg cn=true]



[BG f="b_o_iw_p2.ui" time=1000]
;//【ＢＧ】その他・森の中　昼******************************************************

[WAIT time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=800]

[VOICE f="Erika039"]
[OnName num="Erika"]
"It's a mountain path. We're mountain climbing. I'm so tired~"
[cpg cn=true]

[OnName num="Kenji"]
"Mountain climbing..., you're overreacting."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika040"]
[OnName num="Erika"]
"You're so mean, Kenji! You should give me a piggyback ride."
[cpg cn=true]

[OnName num="Kenji"]
"Why?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna017"]
[OnName num="Yuna"]
"Come on, come on. We're almost there."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika041"]
[OnName num="Erika"]
"Wow~! What's this~! How cool!"
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BGM f="d1"]
[BG f="b_l_ex_app_p2.ui" time=1000]
;//【ＢＧ】図書館・その他・朱鷺田図書館　外観　昼******************************************************

As soon as we saw the exterior of the library, the fatigue she had been feeling was gone.
[cpg]

Erika ran over immediately.
[cpg]

;//[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Erika042"]
[OnName num="Erika"]
"It's really here! It's amazing! It looks like Cinderella's Castle!"
[cpg cn=true]

;//[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yuna018"]
[OnName num="Yuna"]
"I don't think it does at all..."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah. It definitely doesn't."
[cpg cn=true]

;//[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika043"]
[OnName num="Erika"]
"Let's go in♪"
[cpg cn=true]

Completely ignoring our remarks, Erika fearlessly walked in with her hand on the door.
[cpg]

[SE f="se005"]
;//【ＳＥ】重いドア開ける
[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BGM f="library"]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/5" time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=1000]

[WAIT time=1000]

[VOICE f="Erika044"]
[OnName num="Erika"]
"Oh, my God!"
[cpg cn=true]

[OnName num="Kenji"]
"Hey, hey, shhhh!"
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika045"]
[OnName num="Erika"]
"What's this? It's like a museum!"
[cpg cn=true]

[OnName num="Kenji"]
"Ugh, 'What's this? What's this?' Shut up already!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna019"]
[OnName num="Yuna"]
"All right, shhh..."
[cpg cn=true]

The two of us struggled to restrain Erika, who could only express her shock out loud, and went into the room on the right.
[cpg]

[free time=1000]
[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（電灯）******************************************************

[WAIT time=1500]

[OnName num="Kenji"]
"H-hey."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]

It had been a while since I had seen Shiori.
[cpg]

She was as pretty as ever.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="5/3" time=800]

She seemed to notice me too, and I thought I saw her mouth start to move, but...
[cpg]

[move from="2/3" to="2/5" ease="easeInOutSine" time=800]
[move from="5/3" to="4/5" ease="easeInOutSine" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="5/3" time=800]
[WAIT time=100]
[VOICE f="Erika046"]
[OnName num="Erika"]
''Whoa~, so many books~''
[cpg cn=true]

[FACE method="change_3" pos="2/5"]

Noticing the presence of the loudmouth with me, Shiori returned to her stiff expression.
[cpg]

[move from="2/5" to="1/3" ease="easeInOutSine" time=1000]
[move from="4/5" to="2/3" ease="easeInOutSine" time=1000]
[move from="5/3" to="3/3" ease="easeInOutSine" time=1000]

[WAIT time=100]
[VOICE f="Yuna020"]
[OnName num="Yuna"]
"Oh, um..., Sorry Shiori..."
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori011"]
[OnName num="Shiori"]
"......?"
[cpg cn=true]


[VOICE f="Yuna021"]
[OnName num="Yuna"]
"You see, today…, our friend really wanted to come here…”
[cpg cn=true]

At Yuna's excuse, Shiori held out her basket and glanced at Erika, who sighed and then lowered her eyes.
[cpg]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna022"]
[OnName num="Yuna"]
"Erika, put your phone in the basket."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika047"]
[OnName num="Erika"]
"Huh? Why?"
[cpg cn=true]


[VOICE f="Yuna023"]
[OnName num="Yuna"]
“It's a rule here. We have to leave our cell phones and anything that makes noise until we leave.”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika048"]
[OnName num="Erika"]
"Huh~? Really...?"
[cpg cn=true]

[free time=400]

[VOICE f="Michi015"]
[OnName num="Michi"]
"What? Oh, it's Kenji. Long time no see."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]

While we were goofing around, Michi appeared.
[cpg]

[OnName num="Kenji"]
"Oh, Michi, exams are finally over."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1" pos="5/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1" pos="6/3" time=800]


Michi and I were happily chatting, when Erika interrupted us, obviously curious to know what we were talking about.
[cpg]
[move from="2/3" to="1/3" ease="easeInOutSine" time=1000]
[move from="5/3" to="2/3" ease="easeInOutSine" time=1000]
[move from="6/3" to="3/3" ease="easeInOutSine" time=1000]

[WAIT time=500]
[VOICE f="Erika049"]
[OnName num="Erika"]
"Hello~"
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi016"]
[OnName num="Michi"]
"A friend of yours?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika050"]
[OnName num="Erika"]
“Yes~. Kenji and Yuna have been taking care of me~. I'm Erika Kimishima, and we’re all in the same class.”
[cpg cn=true]

Michi looked at Erika curiously for a moment, and then smiled and greeted her as usual.
[cpg]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi017"]
[OnName num="Michi"]
"It's a pleasure to meet you. I am Michi Kisaragi. This is Shiori Tokita."
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika051"]
[OnName num="Erika"]
"Nice to meet you~"
[cpg cn=true]

Shiori greeted Erika with a slight bow of her chin.
[cpg]

Shiori must find such lively people to be a nuisance.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika052"]
[OnName num="Erika"]
"I didn't know there was a library in the mountains like this. It's a hidden gem! Like a hideaway!"
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi018"]
[OnName num="Michi"]
"Yes, I guess so...”
[cpg cn=true]

Even the always cool-headed Michi seemed confused by Erika's aggressiveness, especially since it was their first time meeting.
[cpg]

[OnName num="Kenji"]
“We’re not even in the mountains, so just read quietly.”
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna024"]
[OnName num="Yuna"]
"Yes, yes. Quietly. I'm sorry, Ms. Kisaragi."
[cpg cn=true]

Yuna bowed her head to Michi and apologized.
[cpg]

I wondered how much this girl apologized for Erika.
[cpg]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi019"]
[OnName num="Michi"]
"Erika, we have a few fashion magazines if you'd like to take a look."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika053"]
[OnName num="Erika"]
"Oh, really? I want to see them~ ♪"
[cpg cn=true]

[free time=400]

Now that Michi had Erika's attention, I was finally able to move around freely.
[cpg]

So I quickly walked over to the counter and called out to Shiori.
[cpg]


[OnName num="Kenji"]
"Um..., sorry about all the noise."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
.........
[cpg]

[OnName num="Kenji"]
"I'll try, no, I promise to keep her as quiet as possible."
[cpg cn=true]

............
[cpg]


[OnName num="Kenji"]
"Hahaha... Oh, yeah! It's almost Christmas, right?"
[cpg cn=true]

.........
[cpg]

At my mention of Christmas, Shiori glanced at the calendar, but she didn't seem too interested.
[cpg]

[OnName num="Kenji"]
"Any plans for Christmas, Shiori?"
[cpg cn=true]

.........
[cpg]

[SE f="se007"]
;//【ＳＥ】紙（ペラッ）

[OnName num="Kenji"]
"Hmm?"
[cpg cn=true]

I looked at the piece of paper that Shiori had silently offered me, and it was...
[cpg]

It was the "Library Holiday Schedule”.
[cpg]

According to it, neither the 24th nor the 25th of December was a holiday.
[cpg]

[OnName num="Kenji"]
"Is that so?"
[cpg cn=true]

.........
[cpg]

Wait a minute, that means...
[cpg]

If I come here for Christmas, I'll get to spend it with Shiori.
[cpg]

Well, it won't be just the two of us, but I might get the chance to give her a present.
[cpg]

[OnName num="Kenji"]
"Thanks for telling me!"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

............?
[cpg]

[free time=1000]


"I was in a good mood when I went back to my seat, thinking about what would be a good gift for Shiori."
[cpg]

[OnName num="Kenji"]
"Hmm?"
[cpg cn=true]

;//柚那とエリカが高木と細川に挟まれている
[FG f="CHA03_p3_01_a.ui" method="change_7" pos="2/4" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="3/4" time=800]
[FG f="CHA07_p3_01_a.ui" method="change_1" pos="1/4" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="4/4" time=800]

[WAIT time=100]
[VOICE f="Takagi001"]
[OnName num="Takagi"]
"I seeー, so you're a friend of Yuna's, huh?"
[cpg cn=true]


[VOICE f="Yuna025"]
[OnName num="Yuna"]
"Yes, I am..."
[cpg cn=true]

[FACE method="change_5" pos="4/4"]
[WAIT time=100]
[VOICE f="Hosokawa001"]
[OnName num="Hosokawa"]
"That's surprising... I didn't expect an intelligent person like you would choose to have this kind of friend."
[cpg cn=true]

[FACE method="change_3" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika054"]
[OnName num="Erika"]
"What do you mean, 'choose'? I'm telling you, I chose Yuna, she didn't choose me!"
[cpg cn=true]

I didn't know how long they had been here, but Yuna and Erika were chatting with two of the regulars.
[cpg]

Perhaps it's because of its location, but the number of visitors is extremely small.
[cpg]

However, just as every shop has its regulars, Tokita Library had a few besides me, and I had recently started chatting a bit with two of them.
[cpg]

The fat one is Futoshi Takagi. His name even means obese in Japanese.
[cpg]

The nervous-looking skinny guy is Nobuhito Hosokawa.
[cpg]

Both of them are an odd pair, and I couldn't help but have a weird laugh when I saw them.
[cpg]

[FACE method="change_1" pos="1/4"]
[WAIT time=100]
[VOICE f="Takagi002"]
[OnName num="Takagi"]
"How stylish. That uniform looks just like the one from Rumble Academy."
[cpg cn=true]

[FACE method="change_7" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika055"]
[OnName num="Erika"]
"Huh? What's that?"
[cpg cn=true]

[FACE method="change_2" pos="1/4"]
[WAIT time=100]
[VOICE f="Takagi003"]
[OnName num="Takagi"]
"You’ve never heard of it? It's an anime that was regrettably discontinued after two seasons. I can lend you the DVDs if you want."
[cpg cn=true]

[FACE method="change_4" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika056"]
[OnName num="Erika"]
"No, no, no! I don't even watch anime, that's so weird."
[cpg cn=true]

[FACE method="change_4" pos="3/4"]
[WAIT time=100]
[VOICE f="Yuna026"]
[OnName num="Yuna"]
"H-hey, Erika..."
[cpg cn=true]

[FACE method="change_1" pos="4/4"]
[WAIT time=100]
[VOICE f="Hosokawa002"]
[OnName num="Hosokawa"]
"Yuna, how about you? What do you think of the 2013 paper on the molecular mechanisms of synaptic plasticity and memory?"
[cpg cn=true]

[FACE method="change_7" pos="3/4"]
[WAIT time=100]
[VOICE f="Yuna027"]
[OnName num="Yuna"]
"Uh, well…, I'm not familiar…"
[cpg cn=true]

[FACE method="change_3" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika057"]
[OnName num="Erika"]
"Come on, speak our language. You're being weird."
[cpg cn=true]

"Takagi and Hosokawa seemed to be talking to Erika and Yuna, each bringing up their own interests to find common ground, but both were striking out."
[cpg]

[FACE method="change_1" pos="1/4"]
[WAIT time=100]
[VOICE f="Takagi004"]
[OnName num="Takagi"]
"Hey, I've got a chocolate bar. Do you want some? It's good."
[cpg cn=true]

[FACE method="change_3" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika058"]
[OnName num="Erika"]
"I don't want it. Weirdo."
[cpg cn=true]

[FACE method="change_2" pos="4/4"]
[WAIT time=100]
[VOICE f="Hosokawa003"]
[OnName num="Hosokawa"]
"So, the molecular basis of host cell competency in viral infection phenomena can be found at..."
[cpg cn=true]

[FACE method="change_3" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika059"]
[OnName num="Erika"]
"I don't understand what you're talking about. Weirdo."
[cpg cn=true]

[FACE method="change_7" pos="1/4"]
[WAIT time=100]
[VOICE f="Takagi005"]
[OnName num="Takagi"]
"But..."
[cpg cn=true]

[FACE method="change_3" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika060"]
[OnName num="Erika"]
"Don't talk to me weirdo."
[cpg cn=true]

[FACE method="change_1" pos="4/4"]
[WAIT time=100]
[VOICE f="Hosokawa004"]
[OnName num="Hosokawa"]
"So..."
[cpg cn=true]

[FACE method="change_3" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika061"]
[OnName num="Erika"]
"Weird! Creepy! Gross!"
[cpg cn=true]

I had been watching from the sidelines for a while, but Erika seemed out of control, so I had no choice but to intervene.
[cpg]

[OnName num="Kenji"]
"Hey, there."
[cpg cn=true]

[FACE method="change_4" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika062"]
[OnName num="Erika"]
"Oh, Kenji~, help me! These guys are super creepy!"
[cpg cn=true]

I wonder if Erika had any words like "rude" or "impolite" in her vocabulary.
[cpg]

I'm not sure that honesty is a virtue at this point.
[cpg]

[FACE method="change_1" pos="4/4"]
[WAIT time=100]
[VOICE f="Hosokawa005"]
[OnName num="Hosokawa"]
"Oh, you were here this whole time, too?"
[cpg cn=true]

[FACE method="change_1" pos="1/4"]
[WAIT time=100]
[VOICE f="Takagi006"]
[OnName num="Takagi"]
"Are you guys classmates?"
[cpg cn=true]

[OnName num="Kenji"]
"Yes, we are. Sorry if she's offended you with the way she talks."
[cpg cn=true]

When I apologized for Erika's behavior, Takagi didn't seem too concerned, but Hosokawa seemed irritated as he quickly adjusted his glasses.
[cpg]

[FACE method="change_7" pos="4/4"]
[WAIT time=100]
[VOICE f="Hosokawa006"]
[OnName num="Hosokawa"]
"Let me warn you, if we weren't gentlemen, who knows what would have happened?"
[cpg cn=true]

[FACE method="change_7" pos="4/4"]
[WAIT time=100]
[VOICE f="Hosokawa1006"]
[OnName num="Hosokawa"]
“Saying things like, ‘weirdo’ and 'creepy' to people is nothing but a catalyst for friction in interpersonal relationships.”
[cpg cn=true]


[FACE method="change_4" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika063"]
[OnName num="Erika"]
"Ugh...what a weirdo."
[cpg cn=true]

[FACE method="change_4" pos="3/4"]
[WAIT time=100]
[VOICE f="Yuna028"]
[OnName num="Yuna"]
"E-Erika......."
[cpg cn=true]

[FACE method="change_1" pos="1/4"]
[WAIT time=100]
[VOICE f="Takagi007"]
[OnName num="Takagi"]
"Well, Mr. Hosokawa. Words like 'creepy' are commonly used by girls nowadays. It's just a habit, it has no deep meaning."
[cpg cn=true]

[FACE method="change_7" pos="4/4"]
[WAIT time=100]
[VOICE f="Hosokawa007"]
[OnName num="Hosokawa"]
"Oh, really?"
[cpg cn=true]

[FACE method="change_3" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika064"]
[OnName num="Erika"]
“No, no, no. I was dead serious. I’m literally being serious. I said ‘creepy’, because you are.”
[cpg cn=true]

[OnName num="Kenji"]
"Ok, enough already!"
[cpg cn=true]

As far as I'm concerned, they were both in the wrong.
[cpg]

I mean Takagi and Hosokawa actually are creepy, but I wasn’t so sure Erika should be the one to say so.
[cpg]

Yuna, who was in the middle of it all, was the biggest victim.
[cpg]

[FACE method="change_7" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika065"]
[OnName num="Erika"]
"Man, you people are why I hate libraries …”
[cpg cn=true]

[FACE method="change_3" pos="4/4"]
[WAIT time=100]
[VOICE f="Hosokawa008"]
[OnName num="Hosokawa"]
"What do you mean by 'you people'?"
[cpg cn=true]

[FACE method="change_1" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika066"]
[OnName num="Erika"]
"Nerds and geeks."
[cpg cn=true]

[FACE method="change_5" pos="1/4"]
[FACE method="change_5" pos="4/4"]
[WAIT time=100]
[VOICE f="Takagi008"]
[OnName num="Takagi"]
"......"
[cpg cn=true]

[WAIT time=100]
[VOICE f="Hosokawa009"]
[OnName num="Hosokawa"]
"......"
[cpg cn=true]

It was so direct that even the two of them were speechless.
[cpg]

That just got her going, and Erika couldn't stop.
[cpg]

[FACE method="change_2" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika067"]
[OnName num="Erika"]
"Guys who read books all the time are such know-it-alls and lame. Men should be athletic, clean-cut, and good-looking. Just like Kenji ♪"
[cpg cn=true]

[OnName num="Kenji"]
"What, me?!"
[cpg cn=true]

I was surprised that this weird conversation became about me.
[cpg]

[FACE method="change_3" pos="1/4"]
[WAIT time=100]
[VOICE f="Takagi009"]
[OnName num="Takagi"]
"Mmmm..."
[cpg cn=true]

[FACE method="change_3" pos="4/4"]
[WAIT time=100]
[VOICE f="Hosokawa010"]
[OnName num="Hosokawa"]
"Grrr..."
[cpg cn=true]

[FACE method="change_1" pos="1/4"]
[WAIT time=100]
[VOICE f="Takagi010"]
[OnName num="Takagi"]
"Mr. Hosokawa, do you want a chocolate bar...?"
[cpg cn=true]

[FACE method="change_7" pos="4/4"]
[WAIT time=100]
[VOICE f="Hosokawa011"]
[OnName num="Hosokawa"]
“No, I don't like sweets, and that has peanuts, right? I'm allergic.”
[cpg cn=true]

[FACE method="change_7" pos="1/4"]
[WAIT time=100]
[VOICE f="Takagi011"]
[OnName num="Takagi"]
"That's too bad..."
[cpg cn=true]

[FACE method="change_1" pos="4/4"]
[WAIT time=100]
[VOICE f="Hosokawa012"]
[OnName num="Hosokawa"]
"I appreciate the offer..."
[cpg cn=true]

Wanting to escape the awkwardness of the situation, Takagi and Hosokawa started having their own conversation.
[cpg]

[OnName num="Kenji"]
"I'm really...sorry."
[cpg cn=true]

[FACE method="change_7" pos="3/4"]
[WAIT time=100]
[VOICE f="Yuna029"]
[OnName num="Yuna"]
"Erika, let's just go to another room. Okay?"
[cpg cn=true]

It looked like a fight was going to break out like this, so Yuna pulled Erika's hand and took her out of the room.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BGM f="d1"]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************
[WAIT time=1500]


[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika068"]
[OnName num="Erika"]
"Why do we have to run away?"
[cpg cn=true]

[VOICE f="Yuna030"]
[OnName num="Yuna"]
"We’re not running away, it's just that…, it's your first time here and I thought I'd show you around."
[cpg cn=true]

[OnName num="Kenji"]
"Come to think of it, I've only ever been in this part of the library..."
[cpg cn=true]

When I realized this, I decided to talk to Yuna about it.
[cpg]

[OnName num="Kenji"]
"What other rooms are there here?"
[cpg cn=true]

;//a b
[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna031"]
[OnName num="Yuna"]
“This part of the library has the general collection and children's books, and right across is the room with special reference books, like medical and physics books.”
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna032"]
[OnName num="Yuna"]
At the end of the stairs, there are the women's and men's restrooms.
[cpg cn=true]

[VOICE f="Yuna1032"]
[OnName num="Yuna"]
“And when you go upstairs, there's a map and history room, and a room for some valuables. But I've never gone in there."
[cpg cn=true]


[OnName num="Kenji"]
“What do you mean by 'valuables'?”
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna033"]
[OnName num="Yuna"]
"I don't know. Some kind of treasure?"
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika069"]
[OnName num="Erika"]
"Treasure?"
[cpg cn=true]

Once Yuna mentioned the word "treasure", Erika reacted with full force.
[cpg]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika070"]
[OnName num="Erika"]
“What could the treasure be? Jewels? Gold coins? A crown?"
[cpg cn=true]

[OnName num="Kenji"]
"A c-crown?"
[cpg cn=true]

The treasures that Erika imagined were on the level of fairy tales…
[cpg]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika071"]
[OnName num="Erika"]
“It's amazing! Wow, libraries usually have stuff like that?"
[cpg cn=true]

[OnName num="Kenji"]
"No, they don't."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna034"]
[OnName num="Yuna"]
"I don't know if there are any priceless jewels, but this isn't your average library."
[cpg cn=true]

[OnName num="Kenji"]
"What do you mean?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna035"]
[OnName num="Yuna"]
"Yes. Well, you know this is not a library built by the town or the government, but by Shiori's late grandfather."
[cpg cn=true]

Yuna then pointed to the top of the stairs.
[cpg]

I looked up at the landing and saw a magnificent bust with a strong presence.
[cpg]


;//＠背景アップ

[free time=1000]
[BG f="b_l_1f_entrance_p2up.ui" time=1000]
[WAIT time=1500]


[VOICE f="Yuna036"]
[OnName num="Yuna"]
"That bronze statue is Shiori's grandfather."
[cpg cn=true]


[VOICE f="Erika072"]
[OnName num="Erika"]
“Wow, it's so amazing that he built his own library! That means there must be a treasure room full of gold coins!”
[cpg cn=true]



;//＠戻す
[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/5" time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_1" pos="4/5" time=1000]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
[WAIT time=1500]

When Erika started talking about old wives’ tales again, Yuna just kept nodding her head.
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna037"]
[OnName num="Yuna"]
"But it's a library, so I'm not sure anyone would keep jewels here…"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika073"]
[OnName num="Erika"]
"They so would! Just picture it, looking at the jewels at night. Drinking brandy and stuff!"
[cpg cn=true]

[OnName num="Kenji"]
"Who would do all that..."
[cpg cn=true]

However, there was no doubt that he was a very wealthy man to have built a library and employed his own doctor.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika074"]
[OnName num="Erika"]
"I want to see the treasure!"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna038"]
[OnName num="Yuna"]
"I told you it's impossible."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika075"]
[OnName num="Erika"]
“No, I have to see it! If I we become friends, then I can get to see it."
[cpg cn=true]

[OnName num="Kenji"]
“What do you mean 'become friends’...”
[cpg cn=true]

In Erika's mind, she was probably already imagining a treasure trove like the British royal family.
[cpg]

Her eyes were sparkling.
[cpg]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika076"]
[OnName num="Erika"]
"Kenji, Yuna, I'll be here every day over the week-long break!"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna039"]
[OnName num="Yuna"]
Ah... I don't mind, I'll be working here part-time anyway…"
[cpg cn=true]

[OnName num="Kenji"]
"Uhh..."
[cpg cn=true]

Oh...
[cpg]

I thought I was going to be able to get closer with Shiori, but there will be someone in the way everyday…
[cpg]

I couldn't help but resent Yuna for working part-time here…
[cpg]

[STOPBGM]

;//エフェクト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=3000]

;//ブラックアウト

[window target=true]

On the way home...
[cpg]

[window target=false]
[free time=100]
[BG f="b_o_iw_p2.ui" time=100]
;//【ＢＧ】その他・バス停・八重戸神社前　昼******************************************************

[WAIT time=100]
[transition target={false} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=2500]
[window target=true]

[BGM f="dod"]

Erika was in a much better mood than she had been on the way to the bus stop, and her steps were light as she skipped along.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_2" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1" pos="4/5" time=800]

[OnName num="Kenji"]
"So self-absorbed..."
[cpg cn=true]

[VOICE f="Yuna040"]
[OnName num="Yuna"]
"But I'm glad you're in a better mood."
[cpg cn=true]

[OnName num="Kenji"]
"The complaining will start again soon, anyway. Saying something like the bus isn't coming."
[cpg cn=true]

Looking at the timetable at the stop, it looked like we had more than twenty minutes before the bus would arrive.
[cpg]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika077"]
[OnName num="Erika"]
"Still no bus?"
[cpg cn=true]

[OnName num="Kenji"]
"No. It's coming soon."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika078"]
[OnName num="Erika"]
"Okaaay"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]

Then Erika opened her bag, took out a fashion magazine and started reading it.
[cpg]

[SE f="se016"]
;//【ＳＥ】雑誌パラパラ

[WAIT time=1000]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna041"]
[OnName num="Yuna"]
"Huh? That's..."
[cpg cn=true]

When Yuna looked at the magazine and stared at it curiously, Erika replied without any remorse.
[cpg]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika079"]
[OnName num="Erika"]
"I borrowed it a while ago ♪"
[cpg cn=true]

[OnName num="Kenji"]
"What? From the library?"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna042"]
[OnName num="Yuna"]
"I'm pretty sure they don't lend them out..."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika080"]
[OnName num="Erika"]
"Is that so?"
[cpg cn=true]

[OnName num="Kenji"]
"You didn't tell anyone you were borrowing it? You're a thief!"
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika081"]
[OnName num="Erika"]
"You're overreacting! It's fine. I'll return it tomorrow."
[cpg cn=true]

[OnName num="Kenji"]
"It's not fine! Give it to me!"
[cpg cn=true]

;//[SE f="se000"]
;//【ＳＥ】雑誌奪い取る

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika082"]
[OnName num="Erika"]
"What are you doing?"
[cpg cn=true]

[OnName num="Kenji"]
"I'm going to return it now. You two go home."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna043"]
[OnName num="Yuna"]
"Uh, okay..."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika083"]
[OnName num="Erika"]
"Come on! I can't help it, if I didn't know the rules."
[cpg cn=true]

With Erika's voice booming behind me, I turned back to the forest path.
[cpg]

I couldn't believe it.
[cpg]

Even in a normal library, you have to go through a procedure to borrow a book, but I couldn't believe she just took it without saying anything.
[cpg]

When did she even have the chance to hide it in her bag?
[cpg]

You can't be too careful.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BGM f="d1"]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[SE f="se005"]
;//【ＳＥ】ドア、ゆっくり開ける

[WAIT time=2000]

I carefully opened the entrance door a little and slid myself in.
[cpg]

If possible, I wanted to sneak it back in without anyone finding out.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]

............?
[cpg]

[OnName num="Kenji"]
"Yikes!"
[cpg cn=true]

.........
[cpg]

Suddenly, someone called out from behind, and I let out a cry like a cat that just had its tail stepped on.
[cpg]

I hurriedly turned around to see Shiori standing there, her brow wrinkled, as if she had been offended by my scream.
[cpg]

[OnName num="Kenji"]
"S-sorry, I got a little startled."
[cpg cn=true]

Now that she had seen me, I had no choice but to give Shiori the magazine I was holding.
[cpg]

[FACE method="change_7" pos="2/3"]
............?
[cpg]

[OnName num="Kenji"]
"I think my friend took it by mistake, so I...came to return it."
[cpg cn=true]

Shiori looked a little surprised when she saw me with the magazine, but I couldn't tell if it was because I had taken the book or because I had come all the way back.
[cpg]

[OnName num="Kenji"]
"I'm really sorry. It's my fault for not telling her the rules first. Please forgive her."
[cpg cn=true]

As I bowed my head, Shiori piled the magazine on top of the book she was holding and muttered something.
[cpg]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori012"]
[OnName num="Shiori"]
"T-thank...you."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah..."
[cpg cn=true]

I wondered if it was the setting sun shining through the skylight that made her cheeks look faintly flushed.
[cpg]

I couldn’t believe I heard those words come out of her mouth…
[cpg]

It really does pay to be honest!
[cpg]

God, I'm going to live an honest life now on.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=1]

[move from="2/3" to="2/5" ease="easeInOutSine" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi020"]
[OnName num="Michi"]
"What? If it isn't Kenji. What's happened?"
[cpg cn=true]

[OnName num="Kenji"]
"Oh..., I forgot something."
[cpg cn=true]

I couldn't help but lie to Michi when she came from the stairs.
[cpg]

I was just preaching about being honest...
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi021"]
[OnName num="Michi"]
"Is that so? But you'd better hurry up or you'll miss the bus, and you'll have to wait 50 minutes for the next one."
[cpg cn=true]

[OnName num="Kenji"]
"Well, I'm g-going home! See you tomorrow!"
[cpg cn=true]

.........
[cpg]

Having to stand outside for 50 minutes in this weather is no joke.
[cpg]

I waved goodbye to the two of them and quickly left the library.
[cpg]

[SE f="se020"]
;//【ＳＥ】重いドア閉まる
[WAIT time=3000]


[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi022"]
[OnName num="Michi"]
"See you tomorrow...?"
[cpg cn=true]

Michi muttered something and looked at Shiori's face.
[cpg]

.........
[cpg]

Shiori was expressionless, but Michi understood her.
[cpg]

As she held the book to her chest, there was a slight surge of power.
[cpg]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori013"]
[OnName num="Shiori"]
"I'm going to my room..."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi023"]
[OnName num="Michi"]
"Yes, that's fine. I'll bring you some medicine later."
[cpg cn=true]

[SE f="se021"]
;//【ＳＥ】立ち去る
[move from="2/5" to="5/3" ease="easeInOutSine" time=2000]
[WAIT time=1000]


[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi024"]
[OnName num="Michi"]
"Kenji Azuma...Maybe I need to speed things up a little..."
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BGM f="d1"]
[BG f="b_l_1f_ros_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

[WAIT time=1500]


In a private room on the second floor of the Tokita Library...
[cpg]

Shiori walked straight up to the mirror hanging on a pillar that was surrounded by books.
[cpg]


;//※鏡に向かう栞を絵にして欲しいです（鏡に映り込んでいるのはコトハの顔ですが、ここでは解らないように両者を表現して欲しい）

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori014"]
[OnName num="Shiori"]
"That person came to return a magazine… If he hadn’t said anything, no one would have known…”
[cpg cn=true]

She murmured to herself in a tiny little voice.
[cpg]

Shiori spoke as if she was talking to herself.
[cpg]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori015"]
[OnName num="Shiori"]
"That person…is so beautiful… I'm going to want to keep looking at him…”
[cpg cn=true]

Shiori stared at herself in the mirror, with an entranced look on her face.
[cpg]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[STOPBGM]
[WAIT time=2500]

[stopse g=1]
;//ボイス
[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

[jump storage="ep003.ks" target="*start"]


