;//『ルートＧ』

*start
*root_g|Transformation

;#################################################
*Ep022|Transformation
;#################################################
[SCENE id=15]

[BGM f="danger"]

[BG f="b_l_1f_entrance_p4ex4.ui" time=1]


[FG f="CHA01_p1_01_a.ui" method="change_5" pos="4/5" time=1]
[FG f="CHA02_p5_01_a.ui" method="change_5" pos="2/5" time=1]
[WAIT time=1]


[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori719"]
[OnName num="Shiori"]
"Kenji, look at this. Here's proof..."
[cpg cn=true]

In Shiori's hand was the silver bookmark I had given her.
[cpg]

I was sure of it.
[cpg]

The girl by my side was Shiori.
[cpg]

[OnName num="Kenji"]
"Shiori!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori720"]
[OnName num="Kotoha"]
"No! Kenji, I'm coming over there..."
[cpg cn=true]

Kotoha was coming towards us from the other side, not caring about the rising smoke.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori721"]
[OnName num="Kotoha"]
"Cough! Cough!"
[cpg cn=true]

Kotoha was coughing, agitated by the black smoke coming out through the skylight.
[cpg]

[OnName num="Kenji"]
"Shiori, come here!"
[cpg cn=true]

I hugged Shiori protectively and backed away as Kotoha approached.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori722"]
[OnName num="Kotoha"]
"Cough, cough! Ugh..."
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shiori723"]
[OnName num="Shiori"]
"Kenji, I don't know what Kotoha is going to do... We have to run away..."
[cpg cn=true]

[OnName num="Kenji"]
"Ah! Michi, let's run downstairs!"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi567"]
[OnName num="Michi"]
".................."
[cpg cn=true]

I called out to Michi and picked up Shiori, but she was staring at Kotoha with dazed eyes as she was closing in.
[cpg]

[OnName num="Kenji"]
"Michi?!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi568"]
[OnName num="Michi"]
"...you two, get out of here."
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

[free time=1000]
;**【ＣＧ】ev_18_0 ***********************
[CG id=17 index=0 time=1000]
;*****************************************

[WAIT time=1000]


When Michi said that, I had no idea what she was thinking as she walked over to Kotoha and took hold of her.
[cpg]


[VOICE f="Shiori724"]
[OnName num="Kotoha"]
"Cough! Cough! Doctor, what are you...?"
[cpg cn=true]


[VOICE f="Michi569"]
[OnName num="Michi"]
"It's time to...end this..."
[cpg cn=true]

[OnName num="Kenji"]
"Michi!! No, come back!"
[cpg cn=true]

;//[SE f="se000"]
;//【ＳＥ】ガラガラガラ！

That's when the ceiling collapsed, creating a wall of flame between us.
[cpg]


[VOICE f="Shiori725"]
[OnName num="Kotoha"]
"I won't forget! I will never forget you...!"
[cpg cn=true]

[SE f="se132"]
;//【ＳＥ】火柱

[BG f="b_l_1f_entrance_p4ex4.ui" time=1000]

;//【ＢＧ】図書館・１階・エントランス　夜（火事）******************************************************

[WAIT time=1500]


[OnName num="Kenji"]
"Woah!!"
[cpg cn=true]

A pillar of fire rose from the landing and I knew there was no way we were going down there.
[cpg]

[OnName num="Kenji"]
"This way!"
[cpg cn=true]

[STOPBGM]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
Desperate, we ran into the security room.
[cpg]

;#############################################################
;//Ev017
;#############################################################


;//[BGM f="d1"]
[BG f="b_l_2f_sr_0.ui" time=1000]
;//【ＢＧ】図書館・２階・セキュリティルーム　（暗）******************************************************

[WAIT time=1500]


[FG f="CHA02_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori726"]
[OnName num="Shiori"]
"Aaaah! The doctor...Kotoha..."
[cpg cn=true]

[BGM f="serious"]


When the study door was closed, Shiori broke down in tears on the spot.
[cpg]

[OnName num="Kenji"]
"Pull yourself together, Shiori! If you don't, we'll be in danger."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori727"]
[OnName num="Shiori"]
"If I'm with Kenji..., I...can die here like this..."
[cpg cn=true]

[OnName num="Kenji"]
"Shiori..."
[cpg cn=true]

[SE f="se134"]
;//【ＳＥ】ショート（バチバチッ！）
[free time=1000]

There was a spark from somewhere in the security room.
[cpg]

Finally, this place is going to be burned down...., so I thought.
[cpg]

;//[SE f="se000"]
;//【ＳＥ】ブンッ（モニターつく）
[BG f="b_l_2f_sr_2.ui" time=1000]


Then some of the monitors that were supposed to be broken came back on and showed images of the infirmary and the entrance.
[cpg]

[OnName num="Kenji"]
"After all this time, it works..."
[cpg cn=true]

As I mutter this, Shiori told me something I didn't know.
[cpg]

[STOPBGM]

[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori728"]
[OnName num="Shiori"]
"This monitor was never broken in the first place."
[cpg cn=true]

[OnName num="Kenji"]
"What's that?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori729"]
[OnName num="Shiori"]
The part I destroyed was a separate control system, but the monitoring system still worked.
[cpg cn=true]

[OnName num="Kenji"]
"I didn't know that..."
[cpg cn=true]

No, wait a minute.
[cpg]

[OnName num="Kenji"]
What...? What did she just say...?
[cpg cn=true]

Didn't Shiori just say...?
[cpg]

"I destroyed"...
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori730"]
[OnName num="Shiori"]
"I broke it."
[cpg cn=true]

[SE f="se045"]
;//【ＳＥ】ドンッ


;//＠
;//賢治の首を絞める栞
[free time=1000]

;//**【ＣＧ】ev_07_0 ***********************
[CG id=06 index=0 time=1000]
;//*****************************************

[WAIT time=1000]


[OnName num="Kenji"]
"What?!"
[cpg cn=true]

[BGM f="danger"]


Shiori pushed me to the floor and tightened her grip on my neck, pinning me down from above.
[cpg]


[VOICE f="Shiori731"]
[OnName num="Shiori"]
"When those girls set off the emergency alarm, I knew this was my chance. If I missed this moment, there would never be another."
[cpg cn=true]

[VOICE f="Shiori1731"]
[OnName num="Shiori"]
"When I thought about it, my body started moving on its own. All so that I could have you..., Kenji!"
[cpg cn=true]


[OnName num="Kenji"]
"Y-you...you're Kotoha...!"
[cpg cn=true]

;//ここから名前はコトハ
How could this happen?
[cpg]

It seems I've made the biggest mistake of all.
[cpg]

But by the time I realized what was happening, it was too late and Kotoha's fingers were digging into my neck.
[cpg]


[VOICE f="Shiori732"]
[OnName num="Kotoha"]
"Ahahahahaha! All this talk of love and romance, and you couldn't even tell the difference between me and Shiori! You yourself chose me over Shiori!"
[cpg cn=true]

Kotoha laughed as she choked me.
[cpg]


[VOICE f="Shiori733"]
[OnName num="Kotoha"]
"Yes, I love this body! I love your body, I love your face, and I especially love the way your face is contorting with regret and pain right now! Ahahahahahaha!"
[cpg cn=true]

[OnName num="Kenji"]
"Ugh..."
[cpg cn=true]

While I was fading out of consciousness, I stared at Kotoha's face laughing at me.
[cpg]

Did Shiori also..., laugh like this...?
[cpg]

;//＠
[STOPBGM]
;//エフェクト
;//ロングエフェクト
[window target=false]
[transition target={true} rule="pipo-tr005.png" color={0x000000ff} time=5000]
[WAIT time=5100]
[free time=100]
[stopse g=1]
;//ボイス
[stopse g=2]
;//通常se
[stopse g=6]
;//ループse
[BG f="black.ui" time=100]
[WAIT time=200]
[transition target={false} color={0x000000ff} time=100]
[WAIT time=200]



[WAIT time=1500]
;//[BG f="b_l_ex_app_p2.ui" time=1000]
;//【ＢＧ】図書館・その他・朱鷺田図書館　外観　昼（半焼）******************************************************

[WAIT time=1500]

[window target=true]


[BGM f="serious"]


;//立ち絵は背景が出来たら戻して下さい

[OnName num="刑事"]
"So, let's review what happened. First, when the emergency bell rang on the first day..."
[cpg cn=true]


[VOICE f="Erika570"]
[OnName num="Erika"]
"I was...on the landing..."
[cpg cn=true]


[VOICE f="Yuna427"]
[OnName num="Yuna"]
"I was...upstairs on the left side of the..."
[cpg cn=true]

A month later, pending the recovery of those involved, the police conducted an investigation.
[cpg]

Those who had suffered burns and smoke inhalation were back in good shape by this time, and I have to say, I'm really glad they were.
[cpg]

It was a nightmarish confinement case with a lot going on, but I wondered if the police investigation would eventually reveal everything.
[cpg]


[VOICE f="Syouko394"]
[OnName num="Syouko"]
"O-oh? That figure is..."
[cpg cn=true]

Shoko pointed towards the landing and muttered.
[cpg]

Her finger pointed to a standing statue of a man.
[cpg]

;//賢治の立像

[BG f="b_l_1f_entrance_p2ex2.ui" time=1000]


It was placed next to the bust of Shiori's grandfather, which had fallen apart, and looked down on everyone from high up.
[cpg]

In the midst of the remains of the fire, only the statue stood there clean and new.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="3/4" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/4" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_7" pos="1/4" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/4" time=800]


[WAIT time=100]
[VOICE f="Shiori734"]
[OnName num="Shiori"]
"I knew he was...beautiful..."
[cpg cn=true]

Shiori, leaning into Michi, looked up at the standing statue and let out a single tear.
[cpg]

"Oh, Shiori..., you're safe and sound..."
[cpg]

I'm glad.
[cpg]

That's all I cared about...
[cpg]

[FACE method="change_7" pos="1/4"]
[WAIT time=100]
[VOICE f="Erika571"]
[OnName num="Erika"]
"Detective, when this is all over, you'll find Kenji, won't you?"
[cpg cn=true]

[FACE method="change_7" pos="4/4"]
[WAIT time=100]
[VOICE f="Yuna428"]
[OnName num="Yuna"]
"I don't think he's alive...., but at least find the body."
[cpg cn=true]

Apparently they had been rescued by the firefirghters, and my classmates were asking the detectives about me.
[cpg]

Thank you, both of you...
[cpg]

But I'm still here...
[cpg]

[free time=2000]


As dusk fell, I watched forlornly from the landing as people left after all was said and done.
[cpg]

Goodbye...
[cpg]

Goodbye, everyone...
[cpg]

Then I heard her voice right beside me.
[cpg]

;//[FG f="CHA02_p3_01_a.ui" method="change_2" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori735"]
[OnName num="Kotoha"]
"We'll always be together..."
[cpg cn=true]

Her hands slid down my body as she stared at me enraptured.
[cpg]

But I didn't feel anything anymore...
[cpg]

I'm sure I'll forget who she is sooner or later...
[cpg]

;//【ＢＧ】ブラックアウト
[free time=1500]
[BG f="black.ui" time=1500]
[WAIT time=3500]

[stopse g=1]
;//ボイス
[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

[system end5=true]
[SCENE id=21]

;//ＥＮＤ『変身』
;**【ＥＮＤ】　　　　********************************
[jump storage="epend.ks" target="*start"]
;****************************************************

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～


*ex_b|The End of Sorrow

;//新ルート合流
;//２、目の前のシオリを信じる　を選んだ場合こちらへ

;#################################################
*Ep023|The End of Sorrow
;#################################################
[SCENE id=16]

[BG f="b_l_1f_entrance_p4ex4.ui" time=1]
;//【ＢＧ】図書館・１階・エントランス　夜（火事）******************************************************

[BGM f="danger"]

[FG f="CHA01_p1_01_a.ui" method="change_4" pos="4/5" time=1]
[FG f="CHA02_p5_01_a.ui" method="change_4" pos="2/5" time=1]

;//新ルート『嘆きの果てに』

[STOPBGM]

[OnName num="Kenji"]
"All right. I believe...you."
[cpg cn=true]

I said that and took a step forward.
[cpg]

I chose the Shiori in front of me...the one actually called Kotoha.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shiori736"]
[OnName num="Shiori"]
"What?"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori737"]
[OnName num="Kotoha"]
"What?"
[cpg cn=true]

[BGM f="serious"]

I had no way of knowing. They were so much alike, so much alike.
[cpg]

But...when the Shiori I fell in love with looked at me, the atmosphere, the softness and warmth of her smile...
[cpg]

If such a mysterious thing is called love, I thought I'd bet on it.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori738"]
[OnName num="Shiori"]
"Why, Kenji? Why don't you believe me?"
[cpg cn=true]

[OnName num="Kenji"]
"...you may be Shiori. But you may also be Kotoha. The only thing I can say is that it wasn't you that I fell in love with."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori739"]
[OnName num="Shiori"]
"Oh..."
[cpg cn=true]

I let go of my grip on Shiori and headed towards Kotoha.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_2" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shiori740"]
[OnName num="Kotoha"]
"Kenji..."
[cpg cn=true]

[OnName num="Kenji"]
"I don't know if I should call you Shiori or Kotoha, but..."
[cpg cn=true]

One day Shiori said...
[cpg]

That they were so alike to the point it devastated them.
[cpg]

On the outside maybe it seemed that way. But no two people are exactly alike on the inside.
[cpg]

[OnName num="Kenji"]
"I like you. So I choose you."
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA01_p5_01_a.ui" method="change_2" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shiori741"]
[OnName num="Kotoha"]
"I'm so happy... I love Kenji too..."
[cpg cn=true]

;//一度暗転を挟んでから名前を戻します
;//ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

[BG f="b_l_1f_entrance_p4ex4.ui" time=1000]

[WAIT time=1500]


;//一度場面切り替えで
;//？？？

[FG f="CHA02_p1_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA01_p5_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shiori742"]
[OnName num="unknown"]
"Aaahhhh!"
[cpg cn=true]

[OnName num="Kenji"]
"?!"
[cpg cn=true]

;//？？？
[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori743"]
[OnName num="unknown"]
"Why, why, why, why, why, why?"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori744"]
[OnName num="Kotoha"]
"It's all your fault, Shiori...for not listening to your sister..."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori745"]
[OnName num="Shiori"]
"Kotoha...let's not..., let's not do this anymore."
[cpg cn=true]

It was as if Kotoha was with me a moment ago and Shiori was with me now.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori746"]
[OnName num="Kotoha"]
"It would have been fine, doing things just the way we always have! Then we would have been much happier!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori747"]
[OnName num="Shiori"]
"No! We can't keep doing this! It has to stop!"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori748"]
[OnName num="Kotoha"]
"You're gonna kill me?! That's how you're going to end it all?! You're just as guilty as I am, Shiori!"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori749"]
[OnName num="Shiori"]
"No! No, no..., you're wrong, Kotoha. That's not how this ends. No one will ever be happy."
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori750"]
[OnName num="Shiori"]
"If I don't change..., if we don't atone for our...sins... If we don't change, then we can't move forward."
[cpg cn=true]

Change, Shiori said. That was a huge decision.
[cpg]

They had always been together, two sides of the same coin, two people who had become one.
[cpg]

To change was to define yourself as an individual.
[cpg]

It would be a turning point in their lives.
[cpg]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori751"]
[OnName num="Kotoha"]
"There's no way I can...change. I know I'll never live a normal life!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori752"]
[OnName num="Shiori"]
"So! So, let's both...change, little by little."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori753"]
[OnName num="Kotoha"]
"You can't...you're just like me. We're twins. We do everything together! You can't change! We're the same, we always have been, we always will be!"
[cpg cn=true]

[OnName num="Kenji"]
"......"
[cpg cn=true]

The two of them disagreed with each other, and their conversations remained parallel.
[cpg]

In the meantime, the fire was getting bigger. It wasn't a good idea to stay here.
[cpg]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori754"]
[OnName num="Shiori"]
"Kenji, you go on ahead."
[cpg cn=true]

[OnName num="Kenji"]
"!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori755"]
[OnName num="Shiori"]
"I'll take Kotoha, we'll be right behind you."
[cpg cn=true]

I think Shiori was thinking the same thing. It wasn't safe for all of us to be stay here.
[cpg]

Someone had to find a way out.
[cpg]

[OnName num="Kenji"]
"I understand... I believe in you."
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori756"]
[OnName num="Shiori"]
"Yeah."
[cpg cn=true]

[free time=1000]

That's all I said as I turned my back on the girls.
[cpg]


[OnName num="Kenji"]
"Michi, let's go!"
[cpg cn=true]



[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi570"]
[OnName num="Michi"]
"Y-yeah..."
[cpg cn=true]

I called Michi, who seemed to want to stay there, and we went downstairs together.
[cpg]

[STOPBGM]

;//ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]



[BG f="b_l_1f_entrance_p4ex4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（火事）******************************************************

[WAIT time=1500]

[BGM f="danger"]


;//＠
;//ここのセリフはすでにあるものなのでコメントアウトしてます

;//
[FG f="CHA03_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika555"]
[OnName num="Erika"]
"Kenji!"
[cpg cn=true]

;//柚那
[FG f="CHA04_p3_01_a.ui" method="change_2" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna414"]
[OnName num="Yuna"]
"Kenji!"
[cpg cn=true]

;//章子
[FG f="CHA06_p3_01_a.ui" method="change_2" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko371"]
[OnName num="Syouko"]
"You two are safe!"
[cpg cn=true]


[OnName num="Kenji"]
"Is there any way out? Where the walls are collapsing or breaking?"
[cpg cn=true]

;//柚那
[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna415"]
[OnName num="Yuna"]
"We couldn't find a way out anywhere..."
[cpg cn=true]

;//エリカ
[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika556"]
[OnName num="Erika"]
"We're gonna burn to death..."
[cpg cn=true]

;//章子
[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko372"]
[OnName num="Syouko"]
"Oh, we can't give up."
[cpg cn=true]

Kenji: "Anyway, let's split up and find a way out!"
[cpg cn=true]

I had Erika and the others go to the north side of the library. Michi and I headed to the other side.
[cpg]

;//ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

[BG f="b_l_1f_entrance_p4ex4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（火事）******************************************************

[WAIT time=1500]

;//[BGM f="danger"]

;//別の背景があるならそっちに
[OnName num="Kenji"]
"Michi! Do you have any idea where we might be able to find a way out?"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi571"]
[OnName num="Michi"]
"......"
[cpg cn=true]

[OnName num="Kenji"]
"Michi...?"
[cpg cn=true]

Instead of answering my question, she turned away and mumbled to herself.
[cpg]

The sight sent a cold sweat down my spine. The atmosphere around Michi was strange.
[cpg]

[OnName num="Kenji"]
"What's...the matter?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi572"]
[OnName num="Michi"]
"...if we leave here, everything will be exposed... What I've done, the truth about Shiori and Kotoha..."
[cpg cn=true]

[OnName num="Kenji"]
"Michi? Pull yourself together."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi573"]
[OnName num="Michi"]
"Shiori could be charged with a crime... No...no, no, that...anything but that..."
[cpg cn=true]

Her bulging and bloodshot eyes looked at me.
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi574"]
[OnName num="Michi"]
"I knew it...you were the cause of all of this."
[cpg cn=true]

[OnName num="Kenji"]
"Michi, calm down."
[cpg cn=true]

Erika and the others were nowhere to be seen. They must have headed in the opposite direction, and in this situation even if I shouted they wouldn't be able to hear me.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi575"]
[OnName num="Michi"]
"If only you weren't...here!!!"
[cpg cn=true]

[FG f="CHA05_p5_01_a.ui" method="change_3" pos="2/3" time=800]


She immediately attacked me.
[cpg]

[OnName num="Kenji"]
"Ugh! Please calm down! Are you trying to die?!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi576"]
[OnName num="Michi"]
"Yeah, rather than being outside, I want to be here with everyone...with Shiori!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi577"]
[OnName num="Michi"]
"Not with you! With me! I've been thinking about...Shiori for a lot longer than you have!"
[cpg cn=true]

She put her hands around my neck and tightened her grip.
[cpg]

She had such tremendous strength, I couldn't believe she was a woman.
[cpg]

[OnName num="Kenji"]
"You're not the kind of person who would do something like this! You can think logically! Your priority right now is to get out!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi578"]
[OnName num="Michi"]
"Shut up! You don't know anything about me!"
[cpg cn=true]

[OnName num="Kenji"]
"Yea, I don't know! But if you die, Shiori will be very sad!"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi579"]
[OnName num="Michi"]
"...!"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_5" pos="2/3" time=800]

Her strength diminished and her hands loosened around my neck. I took the opportunity to get away.
[cpg]

[OnName num="Kenji"]
"Pant, pant...and she'll be sad when I'm dead. She's that kind of girl."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi580"]
[OnName num="Michi"]
"...yeah, well...she's a sweet girl."
[cpg cn=true]

Michi seemed to have regained some composure.
[cpg]

I didn't know what to do, but we didn't have time for this.
[cpg]

How can we get out of here when we couldn't get out in the first place?
[cpg]

At that moment, I hurriedly took out the key that I had in my pocket.
[cpg]

When she gave it to me she said that I would probably need it.
[cpg]

[OnName num="Kenji"]
"Michi, what the hell is this key for?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi581"]
[OnName num="Michi"]
"......."
[cpg cn=true]

Michi had a sour look. Probably thinking she shouldn't have given it to me.
[cpg]

[OnName num="Kenji"]
"Since you gave this to me, doesn't that mean that you approve of me and Shiori? That's why you left it to me in case something happened to you."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi582"]
[OnName num="Michi"]
"Give it back to me..."
[cpg cn=true]

When she said that, I turned on my heel and started running.
[cpg]

[OnName num="Kenji"]
"I'm not giving it to you! I'm going to use this to get us all out of here!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi583"]
[OnName num="Michi"]
"Ugh... Please wait!"
[cpg cn=true]

[OnName num="Kenji"]
"I'm not waiting! Tell me what this key is for!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi584"]
[OnName num="Michi"]
"I don't know what it's for!"
[cpg cn=true]

[OnName num="Kenji"]
"Stop being so stubborn and show us the way out of here!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi585"]
[OnName num="Michi"]
"Shut up! Can't you think for yourself?!"
[cpg cn=true]

We ran towards the entrance, yelling to each other like children playing tag.
[cpg]

[STOPBGM]

;//ブラックアウト
[free time=900]
[BG f="black.ui" time=900]

[WAIT time=1500]

[BGM f="serious"]

;//コトハたちの場面

[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/5" time=800]

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shiori757"]
[OnName num="Shiori"]
"Kotoha, why are you so reluctant?"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori758"]
[OnName num="Kotoha"]
"Aren't you afraid, Shiori? Aren't you afraid to change? And when you change, you have to admit what you've done, right?"
[cpg cn=true]

[VOICE f="Shiori1758"]
[OnName num="Kotoha"]
"You know who you are, what kind or person you are...and you can't let the world determine that!"
[cpg cn=true]


[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori759"]
[OnName num="Shiori"]
"I'm afraid, I'm very afraid. I'm afraid that all I have is this library and the memory of my grandfather...and Kotoha and Michi."
[cpg cn=true]

[VOICE f="Shiori1759"]
[OnName num="Shiori"]
"I still think I'd be happier if I stayed locked up in here forever."
[cpg cn=true]


[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori760"]
[OnName num="Kotoha"]
"Then...why?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori761"]
[OnName num="Shiori"]
"But I've decided to change. I want to be with Kenji. That's why I have to leave!"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori762"]
[OnName num="Kotoha"]
"......"
[cpg cn=true]

There was no way out, thought Kotoha.
[cpg]

That's why we bring them all into our world.
[cpg]

Like Kenji. They could use everything to bring him into our world. That's what she had thought.
[cpg]

But Shiori was different. She decided to go out into the world.
[cpg]

But Kotoha hadn't thought of that. It was a crucial difference between the two.
[cpg]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori763"]
[OnName num="Kotoha"]
"So...I see...we were really...very different from the start."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori764"]
[OnName num="Shiori"]
"Kotoha...?"
[cpg cn=true]

Shiori, who was changing on her own, who was taking hold of her future, already seemed different.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori765"]
[OnName num="Kotoha"]
"Let's part ways here, Shiori."
[cpg cn=true]

She pulled a sharp knife from her pocket.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori766"]
[OnName num="Shiori"]
"Kotoha...stop."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori767"]
[OnName num="Kotoha"]
"Don't worry, leave Kenji to me, okay?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori768"]
[OnName num="Shiori"]
"...!"
[cpg cn=true]

Ever since they were kids, they always played together in this library.
[cpg]

They had played hide-and-seek and tag in the library.
[cpg]

Those two were best friends, they were always together.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori769"]
[OnName num="Kotoha"]
"Shiori...!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori770"]
[OnName num="Shiori"]
"Kotoha...!"
[cpg cn=true]

The two of them ran out of the burning library.
[cpg]

;//ブラックアウト
[STOPBGM]
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

[BG f="b_l_1f_entrance_p4ex4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（火事）******************************************************

[WAIT time=1500]

[BGM f="danger"]

[OnName num="Kenji"]
"Pant, pant, pant!"
[cpg cn=true]

Chased by Michi, I ran back to the entrance.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori771"]
[OnName num="Shiori"]
"Pant, pant, pant...!"
[cpg cn=true]

[OnName num="Kenji"]
"Shiori?!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori772"]
[OnName num="Shiori"]
"Kenji?!"
[cpg cn=true]

I saw Shiori running upstairs, but behind her was Kotoha with a blade in her hand.
[cpg]

[OnName num="Kenji"]
"Wha..."
[cpg cn=true]

I quickly make my way towards Shiori.
[cpg]

And then...
[cpg]

;//天井が崩れて落ちてくる
[SE f="se129"]
;//【ＳＥ】『天井が崩れて落ちてくる』


The ceiling, which must have been weakened by the fire, came crashing down with a roar.
[cpg]

And worst of all, it was right above Shiori.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA05_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi586"]
[OnName num="Michi"]
"Shiori?!"
[cpg cn=true]

[OnName num="Kenji"]
"..."
[cpg cn=true]

My body moved without thinking.
[cpg]

[OnName num="Kenji"]
"Shioriiiiiii!!!!!"
[cpg cn=true]

[free time=1]
[WAIT time=1]

[FG f="CHA01_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori773"]
[OnName num="Shiori"]
"Kenjiiiii!!!"
[cpg cn=true]

;//ブラックアウト
[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=2000]

;//瓦礫音
[SE f="se142"]
;//【ＳＥ】『瓦礫音』
[STOPBGM]
[WAIT time=4000]
[free time=100]
[BG f="b_l_1f_entrance_p4ex4.ui" time=100]

[WAIT time=1000]

;//瞬きの演出。段々と視界がクリアに
;//エフェクト
[transition target={false} rule="sita.webp" color={0x000000ff} time=4000]
[WAIT time=5100]

[window target=true]


Huh, I'm alive...?
[cpg]

[OnName num="Kenji"]
"Shiori..?"
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori774"]
[OnName num="Shiori"]
"Kenji..."
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_2" pos="2/3" time=800]

Trying to protect her from the falling debris, I held Shiori in my arms.
[cpg]

I was prepared to die. That's how it was.
[cpg]

So why were we still alive?
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori775"]
[OnName num="Shiori"]
"D-doctor!"
[cpg cn=true]

The answer was at the end of Shiori's gaze. The fallen debris hadn't hit us.
[cpg]

Michi was underneath the rubble. She saved us by pushing us out of the way.
[cpg]

;//☆死亡
;//美智死亡

[move from="2/3" to="1/5" ease="easeInOutSine" time=1000]


;**【ＣＧ】ci_09_0 ***********************
;//カットイン
;//[CUTIN f="img/cg/ci_09_0.webp" show={true}]
;*****************************************

[WAIT time=1500]

[BGM f="serious"]

;//[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Michi587"]
[OnName num="Michi"]
"...cough...cough..."
[cpg cn=true]

[FACE method="change_3" pos="1/5"]
[WAIT time=100]
[VOICE f="Shiori776"]
[OnName num="Shiori"]
We'll clear the debris immediately!"
[cpg cn=true]

When Shiori said this, Michi shook her head.
[cpg]

;//[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Michi588"]
[OnName num="Michi"]
"It's okay, it's too late for me...just get out of here."
[cpg cn=true]

Her body was trapped under a large pile of rubble. Anyone could see there was no surviving that.
[cpg]

We had no way of moving the debris.
[cpg]

[OnName num="Kenji"]
"Why..."
[cpg cn=true]

;//[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Michi589"]
[OnName num="Michi"]
"Pant, pant...don't get me wrong, I did it for...Shiori."
[cpg cn=true]

Then she pointed to the west side of the library.
[cpg]

;//[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Michi590"]
[OnName num="Michi"]
"That way. Go on..."
[cpg cn=true]

[OnName num="Kenji"]
"Thank you..."
[cpg cn=true]

[FACE method="change_4" pos="1/5"]
[WAIT time=100]
[VOICE f="Shiori777"]
[OnName num="Shiori"]
"Nooooo, Doctor, Doctor..."
[cpg cn=true]

;//[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Michi591"]
[OnName num="Michi"]
"Thank you...for crying for me."
[cpg cn=true]

Then Michi closed her eyes softly.
[cpg]

;//[CUTIN f="img/cg/ci_09_0.webp" show={false}]

[WAIT time=2000]


;//戻ってくるエリカ達
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="3/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_7" pos="5/5" time=800]

[WAIT time=100]
[VOICE f="Erika572"]
[OnName num="Erika"]
"Hey Kenji, are you okay?"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna429"]
[OnName num="Yuna"]
"There was a terrible noise... What?"
[cpg cn=true]

[FACE method="change_5" pos="5/5"]
[WAIT time=100]
[VOICE f="Syouko395"]
[OnName num="Syouko"]
"What? Doctor! Nooooo! Doctor–!"
[cpg cn=true]

[OnName num="Kenji"]
"Let's go."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna430"]
[OnName num="Yuna"]
"What the hell..."
[cpg cn=true]

[OnName num="Kenji"]
"There's no time to explain. Just get to the west side!"
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna431"]
[OnName num="Yuna"]
"But I just looked on the west side. There's no way out..."
[cpg cn=true]

[OnName num="Kenji"]
"Just go!"
[cpg cn=true]

[FACE method="change_3" pos="3/5"]
[WAIT time=100]
[VOICE f="Erika573"]
[OnName num="Erika"]
"Oh, my God, just go, right? Look, I'm going!"
[cpg cn=true]

[FACE method="change_4" pos="5/5"]
[WAIT time=100]
[VOICE f="Syouko396"]
[OnName num="Syouko"]
"Ugh, sob..., The d-doctor is..."
[cpg cn=true]

[FACE method="change_3" pos="3/5"]
[WAIT time=100]
[VOICE f="Erika574"]
[OnName num="Erika"]
"Do you want to burn to death?!"
[cpg cn=true]

[FACE method="change_3" pos="3/5"]
[WAIT time=100]
[VOICE f="Yuna432"]
[OnName num="Yuna"]
"Let's go, Shoko."
[cpg cn=true]

[FACE method="change_4" pos="5/5"]
[WAIT time=100]
[VOICE f="Syouko397"]
[OnName num="Syouko"]
"Ugh...Okay..."
[cpg cn=true]

[move from="3/5" to="8/5" ease="easeInOutSine" time=1000]
[move from="4/5" to="9/5" ease="easeInOutSine" time=1000]
[move from="5/5" to="10/5" ease="easeInOutSine" time=1000]


The girls were taking away Shoko, who was grieving over Michi's death.
[cpg]

[OnName num="Kenji"]
"Shiori, us too..."
[cpg cn=true]


[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori778"]
[OnName num="Shiori"]
"......."
[cpg cn=true]

She was looking up the stairs. Kotoha stood there.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori779"]
[OnName num="Shiori"]
"Come on. Let's go together."
[cpg cn=true]

Shiori said as she turned to Kotoha and held out her hand.
[cpg]

[OnName num="Kenji"]
"Come. From now on, it'll be the three of us."
[cpg cn=true]

[free time=1]
[WAIT time=1]

[FG f="CHA02_p1_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Shiori780"]
[OnName num="Kotoha"]
"!"
[cpg cn=true]

So many things that happened. But Shiori will never give up on Kotoha.
[cpg]

[OnName num="Kenji"]
"Neither I nor Shiori want you to die!"
[cpg cn=true]

I spoke from the heart.
[cpg]

I didn't want to abandon either of them. I want both of them to be happy. That's really what I want.
[cpg]

[FACE method="change_7" pos="3/3"]

[WAIT time=2000]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Shiori781"]
[OnName num="Kotoha"]
"Thank you..."
[cpg cn=true]

But she did not respond.
[cpg]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Shiori782"]
[OnName num="Kotoha"]
"But I'm going to stay here. Because the doctor will be lonely..."
[cpg cn=true]

The moment I tried to grab the obstinate Kotoha's hand...
[cpg]

;//また瓦礫が落ちてくる
[SE f="se142"]
;//【ＳＥ】『また瓦礫が落ちてくる』

;//[free time=1000]
[WAIT time=1000]

[OnName num="Kenji"]
"Woah!"
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Shiori783"]
[OnName num="Shiori"]
"Kya..."
[cpg cn=true]

The stone fell from the ceiling again. The library was reaching its end.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori784"]
[OnName num="Shiori"]
"K-Kotoha!"
[cpg cn=true]

I looked at the rubble that blocked the way to Kotoha from here.
[cpg]

There was no way to go and help her...
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori785"]
[OnName num="Shiori"]
"Kotoha..."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Shiori786"]
[OnName num="Kotoha"]
"Don't make that face."
[cpg cn=true]

Then she took something out of her pocket and threw it to me.
[cpg]

[OnName num="Kenji"]
"This is...?"
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Shiori787"]
[OnName num="Kotoha"]
"Take it with you."
[cpg cn=true]

She handed me a thin plate, but I didn't have time to check what it was.
[cpg]


;//火の勢いが増す
[SE f="se119"]
;//【ＳＥ】『火の勢いが増す』


[OnName num="Kenji"]
"Shiori, let's go!"
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Shiori788"]
[OnName num="Shiori"]
"But Kotoha... Kotoha!"
[cpg cn=true]



[FG f="CHA02_p1_01_a.ui" method="change_2" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Shiori789"]
[OnName num="Kotoha"]
"Don't worry. I'll always be with you, okay?"
[cpg cn=true]

;//瓦礫
[SE f="se142"]
;//【ＳＥ】『瓦礫』

[free time=2000]
[WAIT time=1]
[FG f="CHA01_p5_01_a.ui" method="change_3" pos="1/3" time=1]
[WAIT time=1000]
Kotoha's figure was obscured by the falling debris.
[cpg]

I don't know what changed in her, but the last thing I saw was a smile on her face, like she had no longer been possessed.
[cpg]

[STOPBGM]

;//ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=2500]


[BG f="b_l_1f_entrance_p4ex4.ui" time=1000]
;//通路奥



[BGM f="danger"]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika575"]
[OnName num="Erika"]
"What are we going to do, Kenji! There's nothing here!"
[cpg cn=true]

Erika and the girls were the first to arrive at the end of the west corridor. As soon as they joined us, they shouted at us.
[cpg]

[OnName num="Kenji"]
"No...there must be something."
[cpg cn=true]

Michi did point us in this direction. So there must be something here.
[cpg]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna433"]
[OnName num="Yuna"]
"Cough...cough...the smoke, the fire has almost spread here."
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko398"]
[OnName num="Syouko"]
"It's...the end."
[cpg cn=true]

I remembered the floor plan of this building I saw the other day.
[cpg]

I thought the library ahd with many strange spaces and gaps.
[cpg]

Maybe this key...
[cpg]

[OnName num="Kenji"]
"Everyone, search the walls and floors! There might be a way out of here somewhere!"
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko399"]
[OnName num="Syouko"]
"What do you mean?"
[cpg cn=true]

[OnName num="Kenji"]
"There's no time to explain! We've got to find anything that looks off! There must be a keyhole somewhere!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika576"]
[OnName num="Erika"]
"A keyhole? You mean like to a door? I told you we didn't find anything!"
[cpg cn=true]

Everyone was anxious, getting impatient, and starting to panic. But they were still doing their best to find something like I described.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna434"]
[OnName num="Yuna"]
"...! H-here! There's a draft!"
[cpg cn=true]

Yuna raised her voice as she hit the floor of the dead-end passage.
[cpg]

But, it was just a tiled floor. There was no keyhole.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko400"]
[OnName num="Syouko"]
"That's not a door, is it?"
[cpg cn=true]

We could all see that, but Shoko still decided to state the obvious.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika577"]
[OnName num="Erika"]
"We don't have time for this!"
[cpg cn=true]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna435"]
[OnName num="Yuna"]
"Aah..."
[cpg cn=true]

With a thud, I kicked the floor.
[cpg]

Thud.
[cpg]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

[FACE method="change_5" pos="1/3"]
[FACE method="change_5" pos="2/3"]
[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna436"]
[OnName num="Yuna"]
"Did the tiles...just move?"
[cpg cn=true]

The floor moved slightly as Erika struck it in anger.
[cpg]

;//＠
[free time=1000]
;**【ＣＧ】ev_05_0 ***********************
[CG id=04 index=0 time=1000]
;*****************************************
[WAIT time=1000]




[VOICE f="Shiori790"]
[OnName num="Shiori"]
"This...looks like the puzzles that Grandfather used to do..."
[cpg cn=true]

I didn't think any part of that pattern looked like it was from a puzzle.
[cpg]


[VOICE f="Yuna437"]
[OnName num="Yuna"]
"There might be a room underneath where we can take shelter."
[cpg cn=true]


[VOICE f="Syouko401"]
[OnName num="Syouko"]
"R-really? We'll be saved?"
[cpg cn=true]


[VOICE f="Erika578"]
[OnName num="Erika"]
"But it's a puzzle, isn't it? Can we solve it? Do we have time for that?"
[cpg cn=true]

[OnName num="Kenji"]
"Shiori, please!"
[cpg cn=true]


[VOICE f="Shiori791"]
[OnName num="Shiori"]
"Well...it'll take some time, but I might be able to solve it..."
[cpg cn=true]


[VOICE f="Erika579"]
[OnName num="Erika"]
"See! I knew it! We're done for—!
[cpg cn=true]

It might be impossible to solve. But we couldn't be sure. Everything was uncertain and unclear.
[cpg]

But we didn't have the time to try it anymore.
[cpg]


[VOICE f="Syouko402"]
[OnName num="Syouko"]
"It's..., it's the end..."
[cpg cn=true]

Just when it seemed that all was lost...
[cpg]


[VOICE f="Shiori792"]
[OnName num="Shiori"]
"...could it be?"
[cpg cn=true]

Shiori took the plate that Kotoha had given us and added it to the puzzle.
[cpg]

Click, click, click...
[cpg]

Thunk.
[cpg]

[OnName num="Kenji"]
"It f-fit?!"
[cpg cn=true]


[VOICE f="Syouko403"]
[OnName num="Syouko"]
"Yay! You did it! That's what I'm talking about, Shiori."
[cpg cn=true]


[VOICE f="Erika580"]
[OnName num="Erika"]
"Wow, look at you! You did it!"
[cpg cn=true]

;//＠
[BG f="b_l_1f_entrance_p4ex4.ui" time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_3" pos="2/3" time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="1/3" time=1000]
[FG f="CHA06_p3_01_a.ui" method="change_3" pos="3/3" time=1000]
[WAIT time=1000]
[VOICE f="Yuna438"]
[OnName num="Yuna"]
"Come on, let's get out of here."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori793"]
[OnName num="Shiori"]
"Thank you, Kotoha... Kenji, give me the key."
[cpg cn=true]

[OnName num="Kenji"]
"Ah!"
[cpg cn=true]

The keyhole peeked out when Shiori removed the loose tile.
[cpg]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko404"]
[OnName num="Syouko"]
"The s-smoke, it's headed this way..."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika581"]
[OnName num="Erika"]
"Cough, cough, cough...H-hurry!"
[cpg cn=true]

Click, click, click!
[cpg]

[OnName num="Kenji"]
"It opened!"
[cpg cn=true]

When the key was removed, it could be used as a handle, allowing the floor door to open.
[cpg]

Creak, creak, creak...
[cpg]

;//＠
[free time=1000]
;**【ＣＧ】ev_08_0 ***********************
[CG id=07 index=0 time=1000]
;*****************************************
[WAIT time=1000]



[VOICE f="Erika582"]
[OnName num="Erika"]
"It's dark! And deep! A ladder?! Where does this lead to!"
[cpg cn=true]

[OnName num="Kenji"]
"Who cares! Just go if you want to live!"
[cpg cn=true]


[VOICE f="Yuna439"]
[OnName num="Yuna"]
"If you're not going, get out of the way!"
[cpg cn=true]


[VOICE f="Syouko405"]
[OnName num="Syouko"]
"Come on! Hurry! The fire's here~!"
[cpg cn=true]


[VOICE f="Erika583"]
[OnName num="Erika"]
"Whatever, come on! I'll go first!"
[cpg cn=true]


Not wanting to die, we all climbed the ladder to the space under the floor.
[cpg]

;**【ＣＧ】ev_08_a ***********************
[CG id=07 index=1 time=1000]
;*****************************************
[WAIT time=1000]

[OnName num="Kenji"]
"Shiori, hurry!"
[cpg cn=true]


[VOICE f="Shiori794"]
[OnName num="Shiori"]
"But what about you, Kenji?"
[cpg cn=true]

[OnName num="Kenji"]
"I'll go last, so just go!"
[cpg cn=true]

[SE f="se123"]
;//【ＳＥ】火が燃える音

[WAIT time=2000]

;//瓦礫が崩れてくる
[SE f="se142"]
;//【ＳＥ】『瓦礫が崩れてくる』


;//ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=2000]
[STOPBGM]

[WAIT time=2000]


Creak, creak...
[cpg]

Thump! Thump! Thump!
[cpg]

Bang!
[cpg]

;//ブラックアウト


[BG f="b_o_sky_p5.ui" time=1000]

[WAIT time=3000]

[BGM f="silent"]


[VOICE f="Erika584"]
[OnName num="Erika"]
"Woah—"
[cpg cn=true]


[VOICE f="Syouko406"]
[OnName num="Syouko"]
"We're outside~!"
[cpg cn=true]

[VOICE f="Yuna440"]
[OnName num="Yuna"]
"We're safe, aren't we?"
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, somehow..."
[cpg cn=true]

The door under the floor led to a ladder and then to an underground passage.
[cpg]

It led to the back of the library and we were able to get to the surface.
[cpg]

[SE f="se123"]
;//【ＳＥ】燃える館

[WAIT time=3000]

;//＠
[free time=1000]
;**【ＣＧ】ev_15_0 ***********************
[CG id=14 index=0 time=1000]
;*****************************************
[WAIT time=1000]


[VOICE f="Shiori795"]
[OnName num="Shiori"]
"Kotoha.. Michi..."
[cpg cn=true]

[OnName num="Kenji"]
"Shiori..."
[cpg cn=true]


[VOICE f="Shiori796"]
[OnName num="Shiori"]
"Those two saved us..."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah."
[cpg cn=true]

I think the key we got from Michi was the one she had kept with her.
[cpg]

And Kotoha had a piece of the puzzle.
[cpg]

I think their grandfather must have prepared it for them.
[cpg]

If something ever happened, if they were together, if they worked together, they could have gotten out of that place quickly.
[cpg]

[OnName num="Kenji"]
"Let's live. For the both of them."
[cpg cn=true]


[VOICE f="Shiori797"]
[OnName num="Shiori"]
"Yes..."
[cpg cn=true]

Doing her best to hold back her tears, Shiori nodded vigorously.
[cpg]



[STOPBGM]

;//＠
;//エフェクト
[window target=false]
[transition target={true} color={0xffffffff} time=3000]
;//サイレン
[SE f="se122"]
;//【ＳＥ】『サイレン』
[WAIT time=5100]
[BG f="black.ui" time=100]
[WAIT time=200]
[transition target={false} color={0xffffffff} time=2000]
[WAIT time=4000]
;//ゆっくりフェードアウト
;//場面転換

[stopse g=2]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[WAIT time=1000]


;//タイプライター音
[SE f="se135"]
;//【ＳＥ】『タイプライター』

[window target=true]

December 25th
[cpg]

A few years later...
[cpg]

;//コトハと美智のお墓前

[BG f="b_o_sky_p5.ui" time=2000]
[WAIT time=2000]

[BGM f="sys"]

;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori798"]
[OnName num="Shiori"]
"......"
[cpg cn=true]

[OnName num="Kenji"]
"......"
[cpg cn=true]

Shiori and I have been living a peaceful life.
[cpg]

Today is the anniversary of the deaths of Kotoha and Michi.
[cpg]

And we were holding hands in front of their graves.
[cpg]

[OnName num="Kenji"]
"Shiori, are you okay?"
[cpg cn=true]

;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori799"]
[OnName num="Shiori"]
"Yes, I'm fine."
[cpg cn=true]

Shiori was trying to act cheerful.
[cpg]

No, several years have passed since the incident, and she has changed.
[cpg]

After being interviewed by the police, Shiori told them everything.
[cpg]

Although Shiori didn't actually do anything...she received a fair punishment.
[cpg]

Nevertheless, I think they were considerably very lenient in light of the circumstances.
[cpg]

[OnName num="Kenji"]
"Let's go now. You'll freeze."
[cpg cn=true]

;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori800"]
[OnName num="Shiori"]
"Yeah, you're right. Let's go."
[cpg cn=true]

;//雪が降ってくる
;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori801"]
[OnName num="Shiori"]
"Oh, it's snowing."
[cpg cn=true]

[OnName num="Kenji"]
"It is."
[cpg cn=true]

;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori802"]
[OnName num="Shiori"]
"It was snowing that day, too."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah..."
[cpg cn=true]

Maybe it was better to forget about that incident.
[cpg]

That would have been one way to move on, to forget everything and start again from scratch.
[cpg]

But that wasn't the way to go about it.
[cpg]

So we live with it in our hearts.
[cpg]

[OnName num="Kenji"]
"You're lonely without Kotoha, right?"
[cpg cn=true]

;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori803"]
[OnName num="Shiori"]
"No, I'm not lonely. We'll always be together."
[cpg cn=true]

;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori804"]
[OnName num="Shiori"]
"Whenever you want to see Kotoha, just tell me."
[cpg cn=true]

I wondered what she meant by that.
[cpg]

;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori805"]
[OnName num="Shiori"]
"Shiori will always be with me."
[cpg cn=true]

When she said that, I answered back.
[cpg]

I'm sure their sisterly bond was still deep even in death, and their souls would always be together. That's probably what she meant.
[cpg]

I'm sure that's what she meant, and I convinced myself that's what she meant.
[cpg]

[OnName num="Kenji"]
"......"
[cpg cn=true]

Was it really Shiori that I saved? No, there was no doubt about it.
[cpg]

I remembered the first time I thought that Shiori might have a split personality.
[cpg]

Kotoha was a real person, but that doesn't negate the possibility that Shiori could have a split personality.
[cpg]

Maybe Kotoha has always been in her from the beginning...
[cpg]

[OnName num="Kenji"]
"......"
[cpg cn=true]

I stopped thinking about it. It didn't matter. I didn't need to think about it.
[cpg]

I had decided that I love Shiori.
[cpg]

I hoped those feelings hadn't wavered.
[cpg]

[OnName num="Kenji"]
"Let's go home."
[cpg cn=true]

;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori806"]
[OnName num="Shiori"]
"Okay."
[cpg cn=true]

We held hands and went home.
[cpg]

We headed back to a nostalgic place.
[cpg]


;//【ＢＧ】ブラックアウト
[free time=1500]
[BG f="black.ui" time=1500]
[WAIT time=3500]

[system end6=true]
[SCENE id=22]

[stopse g=1]
;//ボイス
[stopse g=2]
;//通常se
[stopse g=6]
;//ループse


;//ＥＮＤ『嘆きの果てに』
;**【ＥＮＤ】　　　　********************************
[jump storage="epend.ks" target="*start"]
;****************************************************
