*start
;#################################################
*Ep005|Never-ending Anxiety
;#################################################
[SCENE id=5]

[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 18th
[cpg]

;//エフェクト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=2000]
[BG f="b_l_1f_nbr_p2.ui" time=100]
[WAIT time=100]
;//翌朝
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）******************************************************
[transition target={false} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=2500]
[window target=true]

[BGM f="library"]


;//うっすらエントランスの天窓から差し込む日の光で、蝋燭がいらない程度に明るくなっている
[OnName num="Kenji"]
"Hmm... It's morning already..."
[cpg cn=true]

I woke up in the room with the door open and the sunlight spilling in through the skylight at the entrance.
[cpg]

[OnName num="Kenji"]
"It's...cold."
[cpg cn=true]

When I woke up shivering from the chill of the early morning, Hosokawa and Takagi were still snoring in their sleep.
[cpg]

[OnName num="Kenji"]
"What time is it...?"
[cpg cn=true]

I looked at my watch and it was a little before seven.
[cpg]

I'm not sure if the ladies were still asleep.
[cpg]

I didn't feel comfortable enough going back to sleep, so I just got up and headed for the bathroom.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BGM f="d1"]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[OnName num="Kenji"]
"Hmm...?"
[cpg cn=true]

I casually looked up and saw a shadow on the landing of the stairs and stopped...
[cpg]


;//胸像の前に立ち本を開いている栞
[free time=1000]
;**【ＣＧ】ev_11_0 ***********************
[CG id=10 index=0 time=1000]
;*****************************************
[WAIT time=1000]

;//＠
;//[BG f="b_l_1f_entrance_p2up.ui" time=1000]

Standing in front of a bronze statue, there was Shiori with a book open.
[cpg]


.........
[cpg]

Shiori looked as innocent and divine as a nun in the pure morning light pouring in through the skylight, I couldn't help but stare.
[cpg]

.........
[cpg]

I wasn't sure how long I was staring.
[cpg]

Shiori, noticing my gaze, closed her book.
[cpg]

[free time=1000]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
[WAIT time=1500]


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori050"]
[OnName num="Shiori"]
"'Good morning..."
[cpg cn=true]

I greeted Shiori back as she walked slowly down the stairs.
[cpg]

[OnName num="Kenji"]
"G-g-good morning. Did you sleep well?"
[cpg cn=true]

Shiori gave a small nod in response.
[cpg]

[OnName num="Kenji"]
"I'm glad to hear that."
[cpg cn=true]

.........
[cpg]

[OnName num="Kenji"]
".................."
[cpg cn=true]

It was not really my place to ask Shiori, the owner of this place, if she had slept well.
[cpg]

I realized that after I said it, and there was a moment of silence...
[cpg]

But there is no time to waste knowing I had so many rivals.
[cpg]

[OnName num="Kenji"]
"Why were you reading in such a place so early in the morning?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori051"]
[OnName num="Shiori"]
I always talk to my grandfather..., and read to him.
[cpg cn=true]

[OnName num="Kenji"]
"To the statue?"
[cpg cn=true]

;//p2 01 1 1
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori052"]
[OnName num="Shiori"]
"Yes... He doesn't have a grave, so I visit this bust of him...every day."
[cpg cn=true]

[OnName num="Kenji"]
"Wow, that's great. I've never even worshipped at the Buddhist altar in my house."
[cpg cn=true]

I didn't know what the hell I was talking about...
[cpg]

But, no grave?
[cpg]

I was sure that Shiori's family was rich, so how could that be?
[cpg]

I wondered about that a little bit, but I was afraid to ask such an insensitive question because it was probably too personal.
[cpg]

I'm sure it's because the cemetery is too far away for her to visit.
[cpg]

[OnName num="Kenji"]
“What have you been reading to him today?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori053"]
[OnName num="Shiori"]
"One of the fantasy paperback books my grandfather used to buy me all the time…"
[cpg cn=true]

[OnName num="Kenji"]
“Oh, fantasy…paperbacks…”
[cpg cn=true]

I had asked her about it, but I had no idea what she was talking about.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori054"]
[OnName num="Shiori"]
“You’re up pretty early…”
[cpg cn=true]

[OnName num="Kenji"]
“I just naturally woke up. I sometimes go for a run in the morning, so I guess I got into the habit of it."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori055"]
[OnName num="Shiori"]
"I see..."
[cpg cn=true]

Her gaze slanted downward at what I had said, and after a short pause to think about it, Shiori continued.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori056"]
[OnName num="Shiori"]
"Like I thought…, do you usually work out…?"
[cpg cn=true]

[OnName num="Kenji"]
"Huh?"
[cpg cn=true]

It was rare for Shiori to ask me a question!
[cpg]

Just the thought of her being interested in me made me want to do a little dance.
[cpg]

[OnName num="Kenji"]
"I don't work out as much as I'd like to, but I move around when I feel like it. I like to exercise. But why do you say ask? Do I seem like such a macho guy?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori057"]
[OnName num="Shiori"]
"N-no…, that's not what I meant… Sorry…"
[cpg cn=true]

[OnName num="Kenji"]
"Ahh..."
[cpg cn=true]

I got overexcited...
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="5/3" time=800]


Shiori didn't say anything more because of my energy.
[cpg]

[move from="2/3" to="2/5" ease="easeInOutSine" time=1000]
[move from="5/3" to="4/5" ease="easeInOutSine" time=1000]
[WAIT time=100]
[VOICE f="Michi112"]
[OnName num="Michi"]
"Good morning. You're early."
[cpg cn=true]

[OnName num="Kenji"]
"Ah, good morning!"
[cpg cn=true]

With no way to escape the tension, Michi came to our rescue and cheerfully greeted us.
[cpg]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi113"]
[OnName num="Michi"]
"Is coffee okay for everyone in the morning? It's instant."
[cpg cn=true]

[OnName num="Kenji"]
“Sounds good! Oh, I mean, I'll make it!"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi114"]
[OnName num="Michi"]
"Okay, I'll get some dry bread and calorie bars. Shiori, go wake everyone up."
[cpg cn=true]

;//エフェクト
[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=2000]
[free time=100]
[BG f="b_l_1f_entrance_p2.ui" time=100]
[WAIT time=1000]
[transition target={false} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=2500]

[window target=true]


While Michi and I were preparing breakfast, a bunch of sleepy-eyed people gathered around us.
[cpg]


[FG f="CHA08_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa086"]
[OnName num="Hosokawa"]
“Good Morning.”
[cpg cn=true]

[FG f="CHA07_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Takagi066"]
[OnName num="Takagi"]
“Good mo~...”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/3" time=800]

[VOICE f="Erika158"]
[OnName num="Erika"]
"Wow~ The coffee smells good~"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna086"]
[OnName num="Yuna"]
“S-sorry, I’ll help.”
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_2" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi115"]
[OnName num="Michi"]
"Hmm, looks like you two had a late night."
[cpg cn=true]

Michi laughed at her, and Yuna held her slightly bedraggled hair in her hands.
[cpg]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna087"]
[OnName num="Yuna"]
"Sorry… Erika kept talking the whole time…"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika159"]
[OnName num="Erika"]
"Well, training camps, which this is kind of like, are all about girl talk."
[cpg cn=true]

The two of them talked all year round. What left was there to talk about…?
[cpg]

[OnName num="Kenji"]
"Look, there’s coffee, so drink up. And here's breakfast."
[cpg cn=true]

Like last night, we sat in a circle and had breakfast.
[cpg]

But now, the morning sun was refreshing and felt nice.
[cpg]

[SE f="se032"]
;//【ＳＥ】ボリボリ乾パンを噛む

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika160"]
[OnName num="Erika"]
"My mouth feels dry..."
[cpg cn=true]

Erika frowned as she ate the dry bread.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika161"]
[OnName num="Erika"]
“Hmmm, at least if this were a deserted island, I could eat fresh fish~"
[cpg cn=true]


[FG f="CHA07_p3_01_a.ui" method="change_2" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Takagi067"]
[OnName num="Takagi"]
"True. I'm good at fishing!"
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa087"]
[OnName num="Hosokawa"]
"Hmm. I'm very knowledgeable about marine life, so I could help you identify poisonous creatures."
[cpg cn=true]

Somehow the conversation turned to fish, and I couldn't help but join in.
[cpg]

[OnName num="Kenji"]
"Oh, I'll prepare it then. If there’s a knife, that is."
[cpg cn=true]



[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori058"]
[OnName num="Shiori"]
"Amazing… I've never seen a fish being prepared before…"
[cpg cn=true]

[OnName num="Kenji"]
“Really? I can make sashimi out of anything. I'm good at filleting.”
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna088"]
[OnName num="Yuna"]
"Wow, I didn't know that. Surprising..."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_2" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika162"]
[OnName num="Erika"]
"Hmmm, Kenji is a man who can cook!"
[cpg cn=true]

[OnName num="Kenji"]
"Not really… I mean, why are you so proud?"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi116"]
[OnName num="Michi"]
“There aren't even that many women who can handle raw fish. I respect that."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, is that so? I learned it from my father.”
[cpg cn=true]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika163"]
[OnName num="Erika"]
"Kenji's father is also a man who can cook!"
[cpg cn=true]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi117"]
[OnName num="Michi"]
"Aw, how nice."
[cpg cn=true]

Erika said something unnecessary again, and for some reason that was becoming her speciality, but both Yuna and Michi looked at me with envy, which made me feel really good.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA07_p3_01_a.ui" method="change_7" pos="2/5" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Takagi068"]
[OnName num="Takagi"]
".................."
[cpg cn=true]


[VOICE f="Hosokawa088"]
[OnName num="Hosokawa"]
".................."
[cpg cn=true]

The other guys were not happy that the conversation had gotten away from them, but that didn't matter at this point.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA03_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="3/3" time=800]

[OnName num="Kenji"]
"Do you like sashimi, Shiori ?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori059"]
[OnName num="Shiori"]
"I like white sashimi..."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, really? I love flounder and great amberjack too!"
[cpg cn=true]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi118"]
[OnName num="Michi"]
"I'd like to try your sashimi, Kenji."
[cpg cn=true]

;//＠
[FG f="CHA08_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa089"]
[OnName num="Hosokawa"]
"Can I have some more coffee, please?"
[cpg cn=true]

When Michi joined in on the good atmosphere, Hosokawa came out to ruin it.
[cpg]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi119"]
[OnName num="Michi"]
“Here you are."
[cpg cn=true]

Michi, who didn't seem to think so, just kindly poured more coffee into Hosokawa's cup.
[cpg]

[FACE method="change_1" pos="2/3"]


Takagi, who was watching the whole thing, grinned and gave him back up.
[cpg]

[FG f="CHA07_p3_01_a.ui" method="change_2" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Takagi069"]
[OnName num="Takagi"]
“It's like we're a family~”
[cpg cn=true]


[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika164"]
[OnName num="Erika"]
"Geez, what are you talking about?"
[cpg cn=true]

[FACE method="change_2" pos="1/3"]
[FACE method="change_2" pos="2/3"]
[FACE method="change_2" pos="3/3"]
Everyone looked at each other and bursted out laughing at Takagi's words.
[cpg]

Except for one person, Shiori…
[cpg]


[free time=1]
[WAIT time=1]

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori060"]
[OnName num="Shiori"]
"Family..."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="CHA07_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika165"]
[OnName num="Erika"]
“If this is a family, who is what? What about the casting?”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa090"]
[OnName num="Hosokawa"]
"That's it. Ms. Kisaragi is the mother and I am the father. Given our ages."
[cpg cn=true]


[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika166"]
[OnName num="Erika"]
“Then Kenji would be the son and I would be his young wife ♪”
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna089"]
[OnName num="Yuna"]
“Then, that would mean Ms. Kisaragi is your mother-in-law…”
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi120"]
[OnName num="Michi"]
"Ugh..."
[cpg cn=true]

After Yuna pointed that out, Michi was surprisingly speechless.
[cpg]

No matter how you look at it, Michi was no mother-in-law… Yuna.
[cpg]


[WAIT time=100]
[VOICE f="Erika167"]
[OnName num="Erika"]
"And Yuna is the maid!"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna090"]
[OnName num="Yuna"]
“M-maid…”
[cpg cn=true]

[OnName num="Kenji"]
“That’s not a family member…”
[cpg cn=true]

Such people do exist…
[cpg]

Girls who forcefully cast themselves in any role they want.
[cpg]

That was exactly what Erika was doing right now.
[cpg]

[FG f="CHA07_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Takagi070"]
[OnName num="Takagi"]
"Then what about me~?"
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika168"]
[OnName num="Erika"]
"You're a, yeah… A pet raccoon dog."
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Takagi071"]
[OnName num="Takagi"]
“Pet?! Raccoon dog?!”
[cpg cn=true]

The fact that she didn't call him a pig suggested that Erika had a bit of a conscience.
[cpg]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Takagi072"]
[OnName num="Takagi"]
"Ugh..."
[cpg cn=true]

Relentless.
[cpg]

I take it back, Erika doesn’t have a conscience.
[cpg]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika169"]
[OnName num="Erika"]
"And Shiori-kins is..."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="3/3" time=800]

When did she start saying "kins"...?
[cpg]

I really didn't understand how her mind worked.
[cpg]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika170"]
[OnName num="Erika"]
"You're our daughter ♪"
[cpg cn=true]

Shiori didn't seem to be interested in the casting of this game of make-believe.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna091"]
[OnName num="Yuna"]
“Yes, that would mean Ms. Kisaragi is my grandmother…”
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi121"]
[OnName num="Michi"]
"G-grand…mother…”
[cpg cn=true]

How terrible...
[cpg]

Michi seemed stunned to be treated like a grandmother despite her youth.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa091"]
[OnName num="Hosokawa"]
"So that makes me your grandfather… Bummer."
[cpg cn=true]

[STOPBGM]
[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3" pos="2/3" time=800]

[VOICE f="Shiori061"]
[OnName num="Shiori"]
"No!"
[cpg cn=true]

[SE f="se033"]
;//【ＳＥ】コップを倒す（バシャッ）

[WAIT time=1000]


[OnName num="Kenji"]
"?!"
[cpg cn=true]

Suddenly, Shiori stood up, and her paper cup of coffee fell down as she did.
[cpg]


[BGM f="serious"]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori062"]
[OnName num="Shiori"]
"My grandfather is…nothing like you…!"
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa092"]
[OnName num="Hosokawa"]
“Oh, I'm sorry, I didn't mean to…”
[cpg cn=true]

Hosokawa looked at the statue at the top of the stairs and hurriedly explained himself.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi122"]
[OnName num="Michi"]
“Sh-shiori…, I was just kidding. Okay?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=1]
[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori063"]
[OnName num="Shiori"]
"Oh…, S-sorry…I…."
[cpg cn=true]

[OnName num="Kenji"]
“Did you burn yourself?!”
[cpg cn=true]

Coffee had spilled on Shiori's legs, and I was worried about that.
[cpg]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi123"]
[OnName num="Michi"]
"Go get changed."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori064"]
[OnName num="Shiori"]
"Yeah... I'm sorry..."
[cpg cn=true]

[move from="2/3" to="5/3" ease="easeInOutSine" time=1000]
In the silence, Shiori went upstairs as Michi urged her.
[cpg]

When she disappeared behind the door, Erika restarted the conversation.
[cpg]

;//[FG f="CHA05_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
;//[FG f="CHA04_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika171"]
[OnName num="Erika"]
“What was that? She can’t take a joke?”
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi124"]
[OnName num="Michi"]
"You have to understand. Her grandfather is irreplaceable to her."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

I remembered the scene from this morning.
[cpg]

;//胸像の前に立ち本を開いている栞

Shiori had been talking to the statue of her grandfather.
[cpg]

She wouldn't have done that if she didn't feel so strongly about him.
[cpg]

That was why she didn't want anyone trying to replace her grandfather, even as a joke.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa093"]
[OnName num="Hosokawa"]
"With all due respect…, isn't Shiori a bit neurotic?"
[cpg cn=true]

When Hosokawa said this, Michi glared at him sharply.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi125"]
[OnName num="Michi"]
“What do you know?”
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa094"]
[OnName num="Hosokawa"]
"Well, no…, I'm just making a diagnosis based on what I've observed…”
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi126"]
[OnName num="Michi"]
“You're not a doctor and you shouldn't talk about diseases so casually. Don't assume you know everything.”
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa095"]
[OnName num="Hosokawa"]
"........."
[cpg cn=true]

After being torn down by a professional, Hosokawa shrunk back, dejected.
[cpg]

There are people on the internet who give advice to strangers who ask for medical help…
[cpg]

Not being a doctor, it's so easy to say that medicine is good or that it must be such and such disease.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika172"]
[OnName num="Erika"]
"W-well! Now that my stomach is full, I think I'll go read a book…”
[cpg cn=true]

Wanting to escape the tension, regardless of her role in the conversation, Erika got up and went to her usual room.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna092"]
[OnName num="Yuna"]
“Ah, well, I'll go to…”
[cpg cn=true]

[FG f="CHA07_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Takagi073"]
[OnName num="Takagi"]
"Me too."
[cpg cn=true]

It was almost time for the library to open.
[cpg]

We decided to read whatever book we wanted and wait for help.
[cpg]


[free time=900]
[BG f="black.ui" time=900]

[STOPBGM]

[WAIT time=1500]
[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）******************************************************

[WAIT time=1500]


[BGM f="silent"]


;//【ＢＧ】図書館・その他・本棚の間　昼（暗）


[OnName num="Kenji"]
“What should I read…?"
[cpg cn=true]

I casually went between the bookshelves.
[cpg]

I followed the titles on the spines with my eyes, not really looking for anything in particular.
[cpg]

"The Siberian Train Murder."
"And Then There Were None."
"Hidden Cards."
[OnName num="Kenji"]
"Is this the mystery section…?”
[cpg cn=true]

;//以降、栞表記で絵はコトハ

[VOICE f="Shiori065"]
[OnName num="Shiori"]
“Do you like...Tabatha Christie?”
[cpg cn=true]

[OnName num="Kenji"]
"Huh?"
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=1000]
[WAIT time=1500]
I turned around hearing the voice behind me, and saw Shiori standing there.
[cpg]

[OnName num="Kenji"]
"Oh, um… Yeah!"
[cpg cn=true]

Remembering what Yuna said about Shiori liking mystery novels, I couldn't help how I answered.
[cpg]

Smiling happily, Shiori asked me about the author, the world-famous queen of mysteries.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori066"]
[OnName num="Shiori"]
"What's your favorite of Christie’s works?"
[cpg cn=true]

[OnName num="Kenji"]
“Oh, um…uh…”
[cpg cn=true]

I used what little knowledge I had about Tabatha Christie to keep the conversation going.
[cpg]

[OnName num="Kenji"]
"Uh, Miss Maple! And the Detective Pocarro…series! “
[cpg cn=true]

Many of the author's works have been made into movies, so I knew at least that much.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori067"]
[OnName num="Shiori"]
"Is that so? So…what's your favorite book in that series?"
[cpg cn=true]

[OnName num="Kenji"]
"Eh..., well...ummm..."
[cpg cn=true]

Crap, crap, crap...
[cpg]

I knew that there were detectives with those names, but I didn't know which titles belonged to which.
[cpg]

If I continued like this, she was going to think I was all talk.
[cpg]

What to do?!
[cpg]

;//■選択肢２（３択）
[switch]
[case "Death by Tile"]
	[swap]
	[jump target="*s2_a"]
[case "Goddess of Counterattacks"]
	[swap]
	[jump target="*s2_b"]
[case "The Village of Eight Idiots"]
	[swap]
	[jump target="*s2_c"]
[endswitch]
;//１，タイルに死す　//２aへ
;//２，逆襲の女神　　//２bへ
;//３，八つ馬鹿村　　//２cへ
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//２a　タイルに死す
*s2_a|Never-ending Anxiety
[OnName num="Kenji"]
"Death by Tile!"
[cpg cn=true]

I said the title of one of the books I had been looking at.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori068"]
[OnName num="Shiori"]
“Oh, it's very famous… I've seen the movie version too. On video tape though..."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, really? That's wonderful!"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

............?
[cpg]

[OnName num="Kenji"]
"No, no! I just mean I'm glad we like the same one."
[cpg cn=true]

Close call...
[cpg]

;//２dへ合流
[jump target="*s2_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//２b　逆襲の女神
*s2_b|Never-ending Anxiety
[OnName num="Kenji"]
"Goddess of Counterattacks!"
[cpg cn=true]

I said the title of one of the books I had been looking at.
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori069"]
[OnName num="Shiori"]
"Oh..."
[cpg cn=true]

Shiori furrowed her brow at my answer.
[cpg]

I might have screwed up...
[cpg]

However, as I was trying to think of an excuse, Shiori continued.
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori070"]
[OnName num="Shiori"]
"Amazing... It's a pretty minor title, but I can't believe you've read that…"
[cpg cn=true]

[OnName num="Kenji"]
"Oh, yeah? Haha."
[cpg cn=true]

Close call…
[cpg]

;//２dへ合流
[jump target="*s2_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//２c　八つ馬鹿村
*s2_c|Never-ending Anxiety
[OnName num="Kenji"]
"The Village of Eight Idiots!"
[cpg cn=true]

I said the title of one of the books I had been looking at.
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori071"]
[OnName num="Shiori"]
"Huh...?"
[cpg cn=true]

Shiori furrowed her brow at my answer.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori072"]
[OnName num="Shiori"]
"That’s…not one of Christie’s…"
[cpg cn=true]

[OnName num="Kenji"]
"What? B-but it's right here."
[cpg cn=true]

............?
[cpg]

When Shiori saw the book I had been pointing at, she pulled it off the shelf and...
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori073"]
[OnName num="Shiori"]
"It's a Japanese book, how come it's in here...? Maybe Yuna made a mistake..."
[cpg cn=true]

With the book in her hand, Shiori seemed a little angry.
[cpg]

It was my fault that Yuna might get scolded later... Sorry, Yuna.
[cpg]

;//２dへ合流
[jump target="*s2_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//２d　合流
*s2_d|Never-ending Anxiety
[OnName num="Kenji"]
"S-so, what do you like best, Shiori?"
[cpg cn=true]

I wanted to hear what Shiori had to say, even if I couldn't understand it myself.
[cpg]

I wanted to talk to her, or rather, I wanted to listen to her voice.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori074"]
[OnName num="Shiori"]
“I like…‘The Moving Head’ and ‘The ABCD Murders’. Aside from Christie, I also love the work of Man Dine and Dustin Rule.”
[cpg cn=true]

[OnName num="Kenji"]
"Oh, really? Well, I'll read those too.”
[cpg cn=true]

I asked Shiori what books she recommended, and it was nice to have something in common to talk about…
[cpg]

[OnName num="Kenji"]
"So, that Dustin something is…"
[cpg cn=true]

[FG f="CHA07_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Takagi074"]
[OnName num="Takagi"]
"Oh, it's Shiori-kins~"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika173"]
[OnName num="Erika"]
“Oh, Kenji, you were here?”
[cpg cn=true]

[OnName num="Kenji"]
"Ah..."
[cpg cn=true]

The third and fourth wheels have appeared!
[cpg]

If this were an RPG game, I would have used the "Fight" command without hesitation.
[cpg]

When Takagi and Erika spotted Shiori and me, they came running at us, each with their own target in mind.
[cpg]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Takagi075"]
[OnName num="Takagi"]
"Shiori-kins~ I finally finished reading last week's recommendations!"
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Takagi076"]
[OnName num="Takagi"]
"I was thrilled to read it, but what I was curious about was the stew that everyone was eating at the bar in the middle of the book. What’s in it?”
[cpg cn=true]

Shiori seemed to be quite annoyed by Takagi's excitement.
[cpg]

No matter what book he read though, he was always thinking about food…
[cpg]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika174"]
[OnName num="Erika"]
"Kenji, which dress do you think is the cutest from this spring collection?"
[cpg cn=true]

[OnName num="Kenji"]
"Well..."
[cpg cn=true]

There were so many books here, but in the end, Erika was all about clothes or…herself.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori075"]
[OnName num="Shiori"]
“The second edition in that series has some cooking in it... You should read it.”
[cpg cn=true]


[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Takagi077"]
[OnName num="Takagi"]
"Really? Wow ♪"
[cpg cn=true]

[OnName num="Kenji"]
"I don't think I really like any of these colors..."
[cpg cn=true]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika175"]
[OnName num="Erika"]
"Really? Well, I'll bring you some other magazines to look at."
[cpg cn=true]

As Takagi and Erika picked out books and magazines, Shiori and I both sighed at the same time.
[cpg]

[OnName num="Kenji"]
"They're...interrupting."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori076"]
[OnName num="Shiori"]
"...yeah."
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

.........
[cpg]

[FACE method="change_2" pos="2/3"]
I was surprised to see Shiori muttering to herself, and she smiled a little at me.
[cpg]

Does Shiori feel the same way I do?
[cpg]

Was she a little disappointed that our conversation was interrupted?
[cpg]

Oh...
[cpg]

I was really glad I got locked in here.
[cpg]

I never thought I'd get to have this time with Shiori!
[cpg]

It was only for a few moments, but I was able to savor the happiness.
[cpg]

That's how crazy I am...about Shiori.
[cpg]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika176"]
[OnName num="Erika"]
"I haven't changed my style for a while now. Oh, well, that's because these are all the colors that will be in next year."
[cpg cn=true]

[OnName num="Kenji"]
"Ah, yeah..."
[cpg cn=true]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika177"]
[OnName num="Erika"]
"But I found something good instead! Do you want to try it with everyone?"
[cpg cn=true]

[OnName num="Kenji"]
"Hmm?"
[cpg cn=true]

What Erika was holding? Some kind of appendix?
[cpg]

It was a rather large piece of folded cardboard.
[cpg]

On the front, it said, "The Game of a Lifetime.”
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1" pos="5/3" time=1]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="6/3" time=1]

[FACE method="change_1" pos="3/3"]
[FACE method="change_1" pos="2/3"]
[FACE method="change_2" pos="1/3"]

[WAIT time=100]
[VOICE f="Erika178"]
[OnName num="Erika"]
"Everyone, gather round!"
[cpg cn=true]

[move from="1/3" to="1/5" ease="easeInOutSine" time=1000]
[move from="2/3" to="2/5" ease="easeInOutSine" time=1000]
[move from="3/3" to="3/5" ease="easeInOutSine" time=1000]
[move from="5/3" to="4/5" ease="easeInOutSine" time=1000]
[move from="6/3" to="5/5" ease="easeInOutSine" time=1000]


"At Erika's command, everyone except Michi gathered at one table and was assigned a paper frame."
[cpg]

[OnName num="Kenji"]
"Are you sure? Are you sure you want to use this book edition?”
[cpg cn=true]

Concerned, I asked Shiori about it, and she nodded her head.
[cpg]


[FACE method="change_5" pos="5/5"]
[WAIT time=100]
[VOICE f="Hosokawa096"]
[OnName num="Hosokawa"]
"Hmm? I don't think we have enough pieces.”
[cpg cn=true]


[VOICE f="Shiori077"]
[OnName num="Shiori"]
"That's okay... I'll keep score, so you guys can play."
[cpg cn=true]

After that was decided, the game began.
[cpg]

;//＠
[free time=1000]
;**【ＣＧ】ev_10_0 ***********************
[CG id=09 index=0 time=1000]
;*****************************************

[STOPBGM]

[WAIT time=1500]

[BGM f="library"]



It was a simple board game, but it was a lot of fun playing in a large group…
[cpg]

[SE f="se034"]
;//【ＳＥ】サイコロ振る


[VOICE f="Takagi078"]
[OnName num="Takagi"]
"Wow! It says 'Fell in a pit'."
[cpg cn=true]


[VOICE f="Shiori078"]
[OnName num="Shiori"]
"Minus one million yen..."
[cpg cn=true]

[SE f="se034"]
;//【ＳＥ】サイコロ振る
[OnName num="Kenji"]
"Buy a car?!"
[cpg cn=true]


[VOICE f="Shiori079"]
[OnName num="Shiori"]
"Minus 12 million yen."
[cpg cn=true]


[VOICE f="Hosokawa097"]
[OnName num="Hosokawa"]
"That's a very expensive car you got there."
[cpg cn=true]

[OnName num="Kenji"]
"Ugh..."
[cpg cn=true]

[SE f="se034"]
;//【ＳＥ】サイコロ振る

[VOICE f="Yuna093"]
[OnName num="Yuna"]
"'It says 'Baby on board, collect gifts from everyone', huh? Sorry guys."
[cpg cn=true]


[VOICE f="Shiori080"]
[OnName num="Shiori"]
"All of you, minus 100,000 yen..."
[cpg cn=true]


[VOICE f="Erika179"]
[OnName num="Erika"]
"Yikes! That's a lot!"
[cpg cn=true]


.........
[cpg]

;//左手にペンを持ち、スコアをつける栞（コトハ）。（※伏線なので絵にしてください）
[OnName num="Kenji"]
"...huh?"
[cpg cn=true]

When I saw Shiori silently adding the scores, I felt a sense of discomfort.
[cpg]


[VOICE f="Yuna094"]
[OnName num="Yuna"]
"What's wrong?"
[cpg cn=true]

As I tilted my head, Yuna, who was beside me, spoke up.
[cpg]

[OnName num="Kenji"]
"Oh, yeah... You're left-handed, aren't you, Shiori?"
[cpg cn=true]

The hand that was holding the pen was her left hand.
[cpg]


[VOICE f="Yuna095"]
[OnName num="Yuna"]
"What? Oh, that's true. I never noticed."
[cpg cn=true]

I had heard that left-handed people were supposed to be smart.
[cpg]

Shiori was also left-handed, which was probably why she was so intelligent.
[cpg]

Right? Or was she left-handed because she was intelligent?
[cpg]

As I was thinking this, Shiori suddenly pointed at Erika with the pen in her left hand.
[cpg]


[VOICE f="Erika180"]
[OnName num="Erika"]
"Aah! W-what?"
[cpg cn=true]


[VOICE f="Shiori081"]
[OnName num="Shiori"]
“Just now, when you threw the die you rolled a 3, but you moved 4 spaces.”
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika181"]
[OnName num="Erika"]
"Um..."
[cpg cn=true]

Erika clammed up when Shiori pointed that out.
[cpg]

[OnName num="Kenji"]
"Did you...cheat?"
[cpg cn=true]

As I questioned her, Hosokawa and Takagi checked what the third space said.
[cpg]


[VOICE f="Hosokawa098"]
[OnName num="Hosokawa"]
"What? The third space says 'Lost in the mountains, pay 20 million yen for the search and rescue'."
[cpg cn=true]


[VOICE f="Takagi079"]
[OnName num="Takagi"]
"The fourth square said, 'Won Big in Vegas, collect 10 million yen'."
[cpg cn=true]

Indeed.
[cpg]

She cheated.
[cpg]



Just as I was about to say that, Shiori, our scorekeeper, read the rulebook without hesitation.
[cpg]


;//コトハ

[VOICE f="Shiori082"]
[OnName num="Shiori"]
"The rules state that if you cheat, you forfeit all your money."
[cpg cn=true]


[VOICE f="Erika182"]
[OnName num="Erika"]
"Aww～ ! I'll go bankrupt!"
[cpg cn=true]

Everyone burst into laughter.
[cpg]



To lose all your money for a small infraction is the epitome of human life.
[cpg]

Shiori had never been to school, so she probably never had a chance to hang out with a bunch of friends like this.
[cpg]

I wish I could have done more typical fun activities with Shiori like this.
[cpg]


[VOICE f="Erika183"]
[OnName num="Erika"]
"Ughhh... What, what...?"
[cpg cn=true]

Erika, the girl with self-inflicted bankruptcy, said resentfully.
[cpg]


[VOICE f="Erika184"]
[OnName num="Erika"]
“Even though she looks like she wouldn't hurt a fly, she's surprisingly strict… Isn't she a wolf in sheep's clothing?"
[cpg cn=true]

[OnName num="Kenji"]
"A wolf in sheep's clothing..."
[cpg cn=true]



Indeed, I have heard many times that Shiori was shy.
[cpg]

I had heard that many people who are shy tend to be more outgoing once they warm up to people.
[cpg]

Was Shiori like that?
[cpg]

If so, I was looking forward to getting to know Shiori more.
[cpg]

I wondered what kind of personality she really had.
[cpg]


[VOICE f="Yuna096"]
[OnName num="Yuna"]
"Kenji, isn't it your turn next?"
[cpg cn=true]

[OnName num="Kenji"]
"Oh, y-yes."
[cpg cn=true]

Yuna urged me to roll the dice.
[cpg]


[SE f="se034"]
;//【ＳＥ】サイコロ振る
[WAIT time=2000]



[VOICE f="Yuna097"]
[OnName num="Yuna"]
"Let's see, ‘Arm-wrestle with the person to your right, loser pays 2 million yen’."
[cpg cn=true]

[OnName num="Kenji"]
"Whaaaatー?"
[cpg cn=true]


When I looked to my right, I saw the unlucky person...
[cpg]

[BG f="b_l_1f_nbr_p2.ui" time=1000]
[FG f="CHA07_p3_01_a.ui" method="change_1" pos="2/3" time=1000]
[WAIT time=2000]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Takagi080"]
[OnName num="Takagi"]
"Mwuahaha...2 million yen ♪"
[cpg cn=true]

[OnName num="Kenji"]
"Whoa!"
[cpg cn=true]

Takagi was like a junior level sumo wrestler.
[cpg]

His arm circumference was about the same as Erika's leg.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_2" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika185"]
[OnName num="Erika"]
"Good luck, Kenji!"
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa099"]
[OnName num="Hosokawa"]
"Takagi, go for it!"
[cpg cn=true]

Determined, I took off my jacket and rolled up my sleeves.
[cpg]



[FG f="CHA07_p5_01_a.ui" method="change_2" pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_2" pos="1/3" time=1]
[FG f="CHA08_p3_01_a.ui" method="change_3" pos="3/3" time=1]

[WAIT time=100]
[VOICE f="Takagi081"]
[OnName num="Takagi"]
"Well, bring it on!"
[cpg cn=true]

Leaning over the desk I was face-to-face with Takagi’s boneless ham-like arm, our hands clasped tightly together.
[cpg]

Not sure why, but my palms were sweaty and uncomfortable.
[cpg]

[OnName num="Kenji"]
"Ugh... Yeah, l-let's go!"
[cpg cn=true]

;//[SE f="se000"]
;//【ＳＥ】歓声

[FACE method="change_3" pos="1/3"]
[FACE method="change_3" pos="3/3"]


[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Takagi082"]
[OnName num="Takagi"]
"Ugggghhhh..."
[cpg cn=true]

[OnName num="Kenji"]
"Aggghhhh!"
[cpg cn=true]

The game was unexpectedly competitive.
[cpg]

I didn't feel as much power in Takagi's arm as I thought I would.
[cpg]

This meant I could win.
[cpg]

[OnName num="Kenji"]
"Waaaahー!!"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Takagi083"]
[OnName num="Takagi"]
"Arghhhー?!"
[cpg cn=true]

[SE f="se035"]
;//【ＳＥ】ドーン！
[STOPBGM]

[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=500]
[WAIT time=1100]
[BG f="white.ui" time=1]
[WAIT time=1]
[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=1]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="1/3" time=1]
[FG f="CHA08_p3_01_a.ui" method="change_5" pos="3/3" time=1]
[WAIT time=1]

[transition target={true} color={0xffffffff} time=1]
[BG f="b_l_1f_nbr_p2.ui" time=1]
[WAIT time=1000]
[transition target={false} color={0xffffffff} time=500]
[WAIT time=1000]
[window target=true]


I found myself pushing Takagi's hand down on the desk with all my strength.
[cpg]

[BGM f="library"]

;//＠
[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika186"]
[OnName num="Erika"]
"Yaaaayー! Kenji, you're so cooooolー!"
[cpg cn=true]

[FG f="CHA07_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Takagi084"]
[OnName num="Takagi"]
"H-how... why... You're so skinny..."
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa100"]
[OnName num="Hosokawa"]
"Hmmm....... Muscles, you see... Well, before that, you're just all fat, so just being bigger doesn't mean you're stronger."
[cpg cn=true]

[OnName num="Kenji"]
"Hehe~ Sorry, 2 million pleeaase ♪"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Takagi085"]
[OnName num="Takagi"]
"Wow!"
[cpg cn=true]

As I received the wad of toy money and put it away, Shiori stared at my arms intently.
[cpg]

[free time=1]
[WAIT time=1]
;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori083"]
[OnName num="Shiori"]
"'Beautiful muscles..."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, do you think so?"
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori084"]
[OnName num="Shiori"]
"Do you do any sports?"
[cpg cn=true]

It was embarrassing to have a girl compliment you on your body, but I didn't feel too bad about it.
[cpg]

When I happily tried to answer Shiori 's question, Erika leaned forward instead for some reason.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_2" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika187"]
[OnName num="Erika"]
"Kenji doesn't do anything! Still, he has excellent athletic skills and gets the top physical fitness scores in his grade!"
[cpg cn=true]

[OnName num="Kenji"]
"Why are you so proud...?"
[cpg cn=true]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika188"]
[OnName num="Erika"]
"And, and! Baseball, soccer, track and field, swimming, rugby and karate!"
[cpg cn=true]

[VOICE f="Erika1188"]
[OnName num="Erika"]
"He has been scouted by so many clubs and turned them all down because he isn't interested! Super cool, right?"
[cpg cn=true]


To tell the truth, I felt a small sense of pride from Erika praising me like that.
[cpg]

Not just Erika.
[cpg]

Other girls also talked about how cool I was, and upperclassmen constantly tried to recruit me for their club activities.
[cpg]

There was a part of me that was high from all the praise.
[cpg]

But it wasn't not like it was from my own efforts, I was just grateful to my parents for bringing me into this world...
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori085"]
[OnName num="Shiori"]
"You are not doing any strenuous exercise, are you?... If so, that's good..."
[cpg cn=true]

Hearing Erika's indirect boast, Shiori chimed in.
[cpg]

[OnName num="Kenji"]
"What? Why? Is that good?"
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori086"]
[OnName num="Shiori"]
"Because..., intense team sports and martial arts can cause injuries. Besides..., if you work out even more, then you will get bigger than you are now, right?"
[cpg cn=true]

[OnName num="Kenji"]
"Bigger?"
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa101"]
[OnName num="Hosokawa"]
"Hmm. The more you train your muscles, the bigger they develop. If you push it to the limit, you will end up looking like a bodybuilder."
[cpg cn=true]

Hosokawa explained, striking a macho pose with a body that looked like chicken bones.
[cpg]


[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika189"]
[OnName num="Erika"]
"Yeah. Gorilla-looking beefy guys are gross. The lean and fit look you have going on right now works for you."
[cpg cn=true]

[FG f="CHA07_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Takagi086"]
[OnName num="Takagi"]
"Hey~, what's my body type?"
[cpg cn=true]

Takagi, who came into the conversation, asks Erika while fidgeting with his arm.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika190"]
[OnName num="Erika"]
"You're just obese."
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[FACE method="change_5" pos="2/3"]
[WAIT time=1000]

[FG f="CHA04_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna098"]
[OnName num="Yuna"]
"Erika , that's not... Takagi is, um... apple-shaped?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=1000]

Yuna.. Was that any better?
[cpg]

[FACE method="change_3" pos="1/3"]
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika191"]
[OnName num="Erika"]
"But why did you say that, Shiori? Do you, by any chance, think Kenji is cool?"
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

Erika's jaw dropped, but I was delighted.
[cpg]

If so...If so...!
[cpg]

I waited excitedly to see how Shiori would answer...
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi127"]
[OnName num="Michi"]
"Shiori, it's time for your medication."
[cpg cn=true]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori087"]
[OnName num="Shiori"]
"Yeah..."
[cpg cn=true]

[move from="2/3" to="5/3" ease="easeInOutSine" time=1000]
[move from="3/3" to="6/3" ease="easeInOutSine" time=1000]
[WAIT time=1000]
Michi came to get Shiori and the two of them left the room together.
[cpg]

Damn it!
[cpg]

[FG f="CHA07_p3_01_a.ui" method="change_1" pos="2/3" time=800]

[WAIT time=100]
[VOICE f="Takagi087"]
[OnName num="Takagi"]
"Medication time...? That's good..."
[cpg cn=true]

As he watched Shiori's back, Takagi muttered to himself.
[cpg]

[OnName num="Kenji"]
"What's good?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Takagi088"]
[OnName num="Takagi"]
"Shiori-kins always look so pale, doesn't she? Whether it's because she is sick or delicate, that side of her is just so cute that I can't take it~"
[cpg cn=true]

[STOPBGM]

I couldn't help but feel annoyed when Takagi smirked like that.
[cpg]

[BGM f="huan"]

[OnName num="Kenji"]
"That's not appropriate to say about people who are sick!"
[cpg cn=true]

Shiori isn't sick because she wants to be.
[cpg]

To top it off, she couldn’t even go to school like she wanted to, or make friends, that must be lonely.
[cpg]

She wasn’t here for guys.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Takagi089"]
[OnName num="Takagi"]
“What the hell…? Even though you think so too, just a little bit."
[cpg cn=true]

[OnName num="Kenji"]
"I do not!"
[cpg cn=true]

At that moment, I could have grabbed Takagi.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna099"]
[OnName num="Yuna"]
"Kenji, that's enough…”
[cpg cn=true]

If Yuna hadn't stopped me, it would have turned into a fistfight.
[cpg]

I had spoiled the fun atmosphere, and the game ended there.
[cpg]

[STOPBGM]
[free time=1500]
[BG f="black.ui" time=1500]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）******************************************************
[WAIT time=1000]

[BGM f="serious"]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika192"]
[OnName num="Erika"]
"Hey, it's getting dark! What’s the meaning of this? Wasn’t someone supposed to come?! Something’s not right!"
[cpg cn=true]

Erika shouted, and Yuna, who was beside her, looked up at the skylight with a worried expression.
[cpg]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna100"]
[OnName num="Yuna"]
"Staying out overnight, my family must be worried sick…"
[cpg cn=true]

Same goes for me too, but Erika and Yuna even more so since they were girls.
[cpg]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna101"]
[OnName num="Yuna"]
"They might have filed a missing persons report or something..."
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Hosokawa102"]
[OnName num="Hosokawa"]
“Still having said that, it might not be so bad. To have the police come looking around here would be wishful thinking."
[cpg cn=true]

Hosokawa said, but Yuna shook her head without effort.
[cpg]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna102"]
[OnName num="Yuna"]
"But I didn't have a part-time job yesterday, and I only told my mom I was going out with Erika for a little bit"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika193"]
[OnName num="Erika"]
"Me too. I just said ‘I'm going out’ and left…”
[cpg cn=true]

Apparently, the same went for Takagi and Hosokawa, and I had never told my family that I was going to the library.
[cpg]

So even if a search report was filed, it is unlikely that a search party would come here anytime soon.
[cpg]

[OnName num="Kenji"]
“But…, Yuna is a part-timer here, and if she's not found elsewhere, I'm sure they'll come here to look for her sometime.”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika194"]
[OnName num="Erika"]
“When is sometime?”
[cpg cn=true]

[OnName num="Kenji"]
"I-it's..."
[cpg cn=true]

[free time=1]
[WAIT time=1]

[SE f="se036"]
;//【ＳＥ】階段を下りてくる
;//※以降、栞は栞（本物）

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/5" time=2000]
[FG f="CHA05_p3_01_a.ui" method="change_4" pos="4/5" time=2000]
[WAIT time=2100]
[VOICE f="Michi128"]
[OnName num="Michi"]
".................."
[cpg cn=true]

.........
[cpg]

They must have heard us talking.
[cpg]

Michi and Shiori came down from the second floor.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi129"]
[OnName num="Michi"]
"I didn't expect that no one would come..."
[cpg cn=true]

There had been rare days in the past when I was the only visitor.
[cpg]

But it wasn't every day, so I didn't expect today to be...a day with no visitors.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika195"]
[OnName num="Erika"]
"What will we do? Are we supposed to spend the night here again?”
[cpg cn=true]

[FG f="CHA07_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Takagi090"]
[OnName num="Takagi"]
“Or rather…, if no one comes tomorrow…
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika196"]
[OnName num="Erika"]
"Yeah, that's right! We're gonna die in the gutter like this!"
[cpg cn=true]

I had wanted to say, "How impressive, that you can die in the gutter indoors," but this wasn’t the right atmosphere for it.
[cpg]

[OnName num="Kenji"]
“I'm sure the people at Shiori's house are worried sick, They'll come by to check on her, right?”
[cpg cn=true]

I asked, grasping at straws, however unsuccessfully.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi130"]
[OnName num="Michi"]
“Unfortunately, I'm usually the only one who stays with her…”
[cpg cn=true]

Michi furrowed her brows in annoyance.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa103"]
[OnName num="Hosokawa"]
"It's just the two of you..."
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi131"]
[OnName num="Michi"]
"Yes. Ever since Shiori's grandfather died, it's just been us. There are relatives scattered throughout the other prefectures."
[cpg cn=true]

It was just the two of them here...
[cpg]

That was why Michi also made the meals.
[cpg]


[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika197"]
[OnName num="Erika"]
"Where are your parents?"
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Shiori088"]
[OnName num="Shiori"]
"My parents are abroad..."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika198"]
[OnName num="Erika"]
"They're celebrities!"
[cpg cn=true]

She asked something so personal, and yet Erika's response was incomprehensible.
[cpg]

Living abroad = being a celebrity...
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna103"]
[OnName num="Yuna"]
"Oh, but if Ms. Kisaragi doesn't show up for work, maybe the hospital will wonder where you are."
[cpg cn=true]



[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi132"]
[OnName num="Michi"]
"The hospital...?"
[cpg cn=true]

Yuna's epiphany gave everyone a ray of hope, but Michi soon extinguished that light.
[cpg]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi133"]
[OnName num="Michi"]
“I have the outpatient clinic once a week, and I just went the day before yesterday. So it's going to be at least five more days before my usual shift… And…."
[cpg cn=true]

[OnName num="Kenji"]
"And?"
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi134"]
[OnName num="Michi"]
“Last month, they asked me when I wanted to take my year-end vacation, and I asked them if I could take it from next week, so if that gets approved, that call might go straight to voicemail...”
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa104"]
[OnName num="Hosokawa"]
"Oh no! Ah, anyway, isn’t Ms. Kisaragi's phone gone too?!"
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi135"]
[OnName num="Michi"]
"Yeah… I keep it in my locker when I am here, so…"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika199"]
[OnName num="Erika"]
"Who the hell did it? No one will get angry, just return the phones you stole!!"
[cpg cn=true]

Erika yelled, already angry.
[cpg]

But no amount of screaming was going to change things.
[cpg]

[SE f="se037"]
;//【ＳＥ】腹が鳴る

[free time=1000]

[WAIT time=2000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）

When all eyes turned to the direction of a disruptive sound, a flippant Takagi looked embarrassed.
[cpg]

[BGM f="dod"]


[FG f="CHA07_p3_01_a.ui" method="change_6" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Takagi091"]
[OnName num="Takagi"]
“I'm starving…”
[cpg cn=true]

[OnName num="Kenji"]
"Huh~..."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi136"]
[OnName num="Michi"]
“In the meantime, let's talk over dinner."
[cpg cn=true]

[free time=800]
[WAIT time=800]

Unlike yesterday, today, dinner began with a gloomy feeling.
[cpg]

We lit candles on the floor again and huddled together to open the pre-packaged food.
[cpg]

[FG f="CHA07_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Takagi092"]
[OnName num="Takagi"]
"What's this, mochi?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
Takagi was a little excited to find mochi he could eat, it just needed water to return to its original state.
[cpg]

[OnName num="Kenji"]
"Come to think of it, we only eat mochi at New Year's, huh? Oh, it comes with either soy sauce or kinako on it!"
[cpg cn=true]

I deliberately tried to make everyone feel at ease by using a cheerful voice.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_2" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika200"]
[OnName num="Erika"]
"Okay. I'll take kinako."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna104"]
[OnName num="Yuna"]
"Then I'll have soy sauce..."
[cpg cn=true]

[OnName num="Kenji"]
"It's a little early, but it's like ringing in the New Year!"
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika201"]
[OnName num="Erika"]
"This year isn't even over yet!"
[cpg cn=true]

[FACE method="change_2" pos="1/3"]
[FACE method="change_2" pos="2/3"]
[FACE method="change_2" pos="3/3"]

A few smiles returned to everyone's face.
[cpg]


[free time=800]
[WAIT time=800]

After all, empty stomachs lead to crankiness, so it was probably a good idea to have dinner right about now.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]

[OnName num="Kenji"]
“Shiori, eat up, okay?”
[cpg cn=true]

I handed her a pair of disposable chopsticks, and she gave a small nod and used them to bring the soft mochi to her mouth.
[cpg]

;//右手に割り箸を持って食事をする栞（※伏線なので絵を入れてください）
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori089"]
[OnName num="Shiori"]
"Delicious..."
[cpg cn=true]

Shiori, who was nibbling on mochi, looked so cute, like a little girl.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA07_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Takagi093"]
[OnName num="Takagi"]
"Nngh."
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa105"]
[OnName num="Hosokawa"]
“Are you okay? You shouldn't eat so much at once.”
[cpg cn=true]

Takagi seemed to have choked his mochi, and Hosokawa was patting him on the back.
[cpg]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa106"]
[OnName num="Hosokawa"]
"Oh, by the way, there are accidents every New Year's when old people die from eating mochi, but when that happens, they don't try to suck them out of their throats with a vacuum cleaner, because it's dangerous. It can damage the trachea.”
[cpg cn=true]

While Hosokawa was rambling on about this, Takagi started flapping his arms and legs and I panicked.
[cpg]

[OnName num="Kenji"]
"It’s not your time! Come on, drink your tea!"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Takagi094"]
[OnName num="Takagi"]
"Argh!... Phew, I thought I was going to die."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika202"]
[OnName num="Erika"]
"Mochi is…extremely dangerous.”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Takagi095"]
[OnName num="Takagi"]
“But, it’s so delicious ♪”
[cpg cn=true]

Takagi came back to life with the tea that I offered him, and he chewed on mochi again without fail.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori090"]
[OnName num="Shiori"]
"Kenji is…kind. Even in times like these, you can make everyone happy and care for others… I don't think that's so easy to do…"
[cpg cn=true]

Shiori was impressed and complimented me.
[cpg]

[OnName num="Kenji"]
"No~, not really."
[cpg cn=true]

I felt my face getting hot, and I gulped down a cup of tea, feeling embarrassed.
[cpg]

But on the other hand, Takagi, who didn't have anything good to say today, wasn't amused...
[cpg]


[FG f="CHA07_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Takagi096"]
[OnName num="Takagi"]
"Shiori-kins! Mochi isn't very tasty, is it? Here, eat this if you want!"
[cpg cn=true]

He held out his precious chocolate bar to Shiori.
[cpg]

[FACE method="change_4" pos="2/3"]
[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Takagi097"]
[OnName num="Takagi"]
"A delicious chocolate bar! It's got peanuts!"
[cpg cn=true]

The brown stick that he was holding tightly was moderately soft, probably because it had been in his pocket for a long time.
[cpg]

Not only that, but the wrapping at the end of it was slightly rolled up.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika203"]
[OnName num="Erika"]
"Who's going to eat that? You’ve been eating it!”
[cpg cn=true]

[SE f="se038"]
;//【ＳＥ】チョコバー叩き落とされる（ベシッ！）
Erika yelled and slapped Takagi's hand, causing the chocolate bar to roll to the floor.
[cpg]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Takagi098"]
[OnName num="Takagi"]
"Wahー! My chocolate bar!"
[cpg cn=true]

.........
[cpg]

Shiori stared coldly at Takagi, who was chasing after the chocolate bar and squealing.
[cpg]

Probably thinking…bringing in food was prohibited.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi137"]
[OnName num="Michi"]
"So, here's what we're going to do…"
[cpg cn=true]

After we settled down, Michi started speaking.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi138"]
[OnName num="Michi"]
“Yesterday, I was hopeful, but it looks like you're all going to have to stay here tonight.”
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika204"]
[OnName num="Erika"]
"Hey..."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi139"]
[OnName num="Michi"]
"I'll tell you what."
[cpg cn=true]

Interrupting Erika, who was about to say something, Michi continued nonchalantly.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi140"]
[OnName num="Michi"]
"Shiori is the person in charge here, and I am her guardian, but it was not our intention for this to happen. That's all you need to understand."
[cpg cn=true]

[VOICE f="Michi1140"]
[OnName num="Michi"]
"So we will provide food and do what we can, but no one has the right to complain. That is all."
[cpg cn=true]

[FACE method="change_4" pos="1/3"]

We had no choice but to remain silent in the face of her well-reasoned words.
[cpg]

The only thing that filled the quiet and empty space was the dim candlelight.
[cpg]

After saying what she had wanted to say, Michi smiled again.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi141"]
[OnName num="Michi"]
“There are still some blankets, so please keep warm and go to bed so you don't catch a cold.”
[cpg cn=true]

The meal ended with an awkward atmosphere, and we headed to our respective sleeping areas with our blankets, just like yesterday.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_nbr_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　夜（暗）******************************************************

[WAIT time=1500]

[OnName num="Kenji"]
"It's…cold."
[cpg cn=true]

It was a sturdy building, but it was December.
[cpg]

It is terribly cold without heating.
[cpg]

I wrapped several blankets around my body and laid down, trying to shrivel up.
[cpg]

Someone should be here tomorrow.
[cpg]

This was not just a private residence, it was a library, there was no way that a day would go by without someone coming.
[cpg]

I told myself that, and closed my eyes, the image of today's Shiori replaying over and over again on the back of my eyelids.
[cpg]

;//本日の栞（コトハ＆栞）の画像リフレイン

;//＠回想
;//【ＣＧ】ev_11_0
;//[BG f="cg_refrain_11.ui" time=1000]
;//[WAIT time=3000]

Another new side of Shiori that I had come to learn about.
[cpg]

The joy of knowing another side of her that I never knew before.
[cpg]

If Shiori were a book, I would read it like a fiend.
[cpg]

;//＠回想
;//【ＣＧ】ev_10_0 
;//[BG f="cg_refrain_10.ui" time=1000]
;//[WAIT time=3000]

Maybe reading a book was the pleasure of knowing something you didn't know before.
[cpg]

I wondered what Shiori was thinking about while she was in her own bed right now…
[cpg]

Even it was just a little bit…
[cpg]

I hoped she was thinking about me… 
[cpg]

;//【ＢＧ】ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=3000]

[SE f="se039"]
;//【ＳＥ】ゴソゴソゴソ…
[WAIT time=3000]

[OnName num="Kenji"]
"W-what the hell?"
[cpg cn=true]

Just as I was about to fall into a deep sleep, I was awakened by a faint noise.
[cpg]

When I looked to the side to see what it was, I saw no sign of Takagi, who was supposed to be there.
[cpg]

All that was left was his blanket that looked like an igloo, it was round in shape with one opening.
[cpg]

[OnName num="Kenji"]
"Toilet, probably..."
[cpg cn=true]


[VOICE f="Hosokawa107"]
[OnName num="Hosokawa"]
"Grind...grind...grind..."
[cpg cn=true]

Beyond the shell of the blanket, Hosokawa was asleep and neurotically grinding his teeth.
[cpg]

[OnName num="Kenji"]
"I'm going to the bathroom too..."
[cpg cn=true]

I figured it would get colder in the middle of the night, and now that I was awake, I headed to the bathroom to take a leak.
[cpg]



[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）******************************************************

As I left the room and was about to pass through the entrance, I heard people talking.
[cpg]

[OnName num="Kenji"]
"......?"
[cpg cn=true]

;//【ＢＧ】図書館・１階・エントランス　夜（暗）女子トイレ前


I peeked out from in front of the men's room, by the stairs leading to the basement, and saw two figures standing in front of the women's room on the other side.
[cpg]

Someone huge and someone small.
[cpg]

[OnName num="Kenji"]
"......!"
[cpg cn=true]

When I saw them, I got more than a little upset.
[cpg]

;//栞に詰め寄る高木
[FG f="CHA07_p3_01_a.ui" method="change_2" pos="2/5" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Takagi099"]
[OnName num="Takagi"]
"I-I-I can't take it anymore. I've been in love with you for so long, Shiori!
[cpg cn=true]

.........
[cpg]

Takagi was cornering a confused Shiori.
[cpg]

No mistaking it, this was definitely a…confession.
[cpg]

He probably couldn't stand the fact that Shiori and I were slowly closing the distance between us.
[cpg]

What to do…
[cpg]

No matter how much I wished I was, I wasn’t Shiori's boyfriend, and I didn't have the right to stop Takagi from confessing.
[cpg]

However, there was no reason to just keep spying.
[cpg]

While his feelings of self-esteem and love struggled with each other, Takagi got excited on his own.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi100"]
[OnName num="Takagi"]
"I've thought you were cute since I first saw you, and I've grown to love you. I'll lose weight, play sports, and become lean and fit for you!"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori091"]
[OnName num="Shiori"]
"Le-ean and…fit…???"
[cpg cn=true]

Ah...
[cpg]

So Takagi was still bitter about what the girls had talked about earlier…
[cpg]

Even I would have been jealous of Takagi if Shiori had told me she liked fat people.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi101"]
[OnName num="Takagi"]
"So, please be my girlfriend!"
[cpg cn=true]

Shiori was clearly confused.
[cpg]

Perhaps this was the first time she had ever been confessed to by someone of the opposite sex.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi102"]
[OnName num="Takagi"]
"I'll take good care of you, get a good job, make lots of money, and make you happy! Shiori-kins, please become mine!"
[cpg cn=true]

His confession was overwhelming.
[cpg]

To be honest, I thought there was no way I could lose to Takagi.
[cpg]

But Takagi had the courage to confess, while I was...hiding in a place like this, eavesdropping.
[cpg]

When I thought about it…, that guy was more impressive than me.
[cpg]

I felt defeated, so I turned back without going to the bathroom.
[cpg]

In the background, I heard Shiori's small voice.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori092"]
[OnName num="Shiori"]
“I’m…sorry.”
[cpg cn=true]

[FACE method="change_5" pos="2/5"]

Ah…, what a horrible person I was.
[cpg]

Even though I had just acknowledged Takagi’s bravery, I was cheering on the inside.
[cpg]

It was as if spring had come.
[cpg]

Full of self-loathing, I returned to my blanket, thinking only of how to comfort Takagi tomorrow.
[cpg]

Even though he was defeated, he was still my rival.
[cpg]

It is a man's duty to praise a rival's efforts...
[cpg]

[STOPBGM]
;//エフェクト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=2000]

;//【ＢＧ】ブラックアウト
[free time=100]
[BG f="black.ui" time=100]
[WAIT time=1000]
[window target=true]


[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 19th
[cpg]

[SE f="se040"]
;//【ＳＥ】鉄の防窓を隔てて聞こえる鳥のさえずり

The sound of birds chirping outside was different from what I usually heard in my room.
[cpg]

Why did they sound so far away...?
[cpg]

Ah, right...
[cpg]

The birds...were behind the steel shutters I guess.
[cpg]

;//目を開ける
[window target=false]
[BG f="b_l_1f_nbr_p2.ui" time=100]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）******************************************************
[transition target={false} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=2500]
[window target=true]

[BGM f="library"]

Waking up without sunlight made it a dull morning.
[cpg]

I sat up, still feeling a little sleepy, and rubbed my eyes.
[cpg]

[STOPBGM]

[VOICE f="Erika205"]
[OnName num="Erika"]
“Kyaaaaaaaaaaaaaaaー!!”
[cpg cn=true]

[OnName num="Kenji"]
"?!"
[cpg cn=true]

A woman's scream cut through the hazy morning air.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa108"]
[OnName num="Hosokawa"]
"W-what the hell?!"
[cpg cn=true]

Hosokawa jumped up beside me, and we both ran out of the room.
[cpg]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=2500]


[stopse g=2]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse
[jump storage="ep006.ks" target="*start"]


