*start
;※賢治、エリカ、柚那は、休日でも校則により制服姿です
;※コトハが栞を演じているシーンでは、口調が徐々に変化していますが、声のトーンなどは一気に変えすぎないようにして下さい（そもそも双子だし、コトハも意識して栞に合わせているので）
;//シオリノコトハ　～密室図書館の生贄～　改編版

;//【プロローグ】
;#################################################
*Ep000|The Beginning
;#################################################
[SCENE id=0]
[OnName num=""]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

;//缶詰フラグ

[stflag Canning=0]


;//鍵フラグ
[stflag Key=0]


;//病気フラグ
[stflag Psychosisg=0]


;//タイプライター音の共に表示

[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 24th
[cpg]

It's that time of the year when deep snow can be seen outside the window.
[cpg]

Today is a special day.
[cpg]

For the world, and for us.
[cpg]


[WAIT time=1500]
[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（電灯）******************************************************

[BGM f="huan"]

[WAIT time=1500]


[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika001"]
[OnName num="Erika"]
"How long do I have to stay here?"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna001"]
[OnName num="Yuna"]
"I want to go home, I want to go home...Mom..."
[cpg cn=true]

I sat quietly, glancing at the girls raising their voices beside me.
[cpg]

No, I just didn't have the strength in my body.
[cpg]

I could see my breath while the heat was being drained from my body.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Syouko001"]
[OnName num="Syouko"]
"It's cold... it's cold... I can't move anymore..."
[cpg cn=true]

That's right. It's cold...too cold...I'm going to freeze at this rate.
[cpg]

[free time=400]

[OnName num="Kenji"]
"Shiori, are you okay?"
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]

I looked at the face of the girl next to me.
[cpg]

[FACE method="change_2" pos="2/3"]

She smiled. Just like the first time we met.
[cpg]

I smiled back too.
[cpg]

And she smiled too.
[cpg]

;//ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

[SE f="se119"]
;//【ＳＥ】館が燃える

Amazing...
[cpg]

My body started to get hot.
[cpg]

Ah, it's warm...
[cpg]

I could hear the crackling of the trees.
[cpg]

Now, I'm not cold anymore.
[cpg]

;//ホワイトアウト
[window target=false]
[free time=400]
[WAIT time=400]
[BG f="white.ui" time=2000]
[WAIT time=2000]
[STOPBGM]
[WAIT time=2000]


;//場面転換

;//ブラックアウト

[BG f="black.ui" time=900]
[WAIT time=1500]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se

[stopse g=6]
;//ループse


[jump storage="ep001.ks" target="*start"]

