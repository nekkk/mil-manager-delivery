*start
;#################################################
*Ep008|Victims
;#################################################
[SCENE id=8]

[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 21st
[cpg]

;//胸像に朗読している栞（※本物）
[free time=1000]
;**【ＣＧ】ev_11_0 ***********************
[CG id=10 index=0 time=1000]
;*****************************************

[WAIT time=1000]


[VOICE f="Shiori158"]
[OnName num="Shiori"]
"Georgie Porgie, Puddin’ and Pie. Kissed the girls and made them cry. When the boys came out to play, Georgie Porgie ran away."
[cpg cn=true]



[WAIT time=1500]
[BG f="b_l_1f_entrance_p2up.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）（踊り場）******************************************************

[WAIT time=1500]


[BGM f="library"]


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko095"]
[OnName num="Syouko"]
"Good morning, Shiori."
[cpg cn=true]

[VOICE f="Shiori159"]
[OnName num="Shiori"]
"Good morning..."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko096"]
[OnName num="Syouko"]
"It's time to prepare breakfast, even though it's just a matter of getting it from downstairs. Though, no one has woken up yet. Where's Dr. Kisaragi?"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori160"]
[OnName num="Shiori"]
"She is still sleeping... I'll help you."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko097"]
[OnName num="Syouko"]
"No way! I'll be scolded by your doctor if I ask you to do that. Please, take it easy!"
[cpg cn=true]

[SE f="se069"]
;//【ＳＥ】走り去る

[move from="4/5" to="5/3" ease="easeInOutSine" time=1000]

[WAIT time=2000]

[STOPBGM]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori161"]
[OnName num="Shiori"]
"...Grandfather."
[cpg cn=true]

;//胸像がアップになる

[free time=1000]

[BG f="b_l_1f_entrance_p2up.ui" time=1000]

[WAIT time=3000]


;//エフェクト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=2000]
[free time=100]
[BG f="b_l_1f_tbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・専門書の部屋　昼（エントランスからの光）******************************************************
[WAIT time=2000]
[transition target={false} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=3000]
[window target=true]

[BGM f="library"]


[OnName num="Kenji"]
"Hmm... Morning..."
[cpg cn=true]

As soon as I woke up, what came to my mind was what happened last night.
[cpg]

At first when I was locked up, I was happy to be friends with Shiori, but as the days went on, I was getting more and more mentally and physically drained.
[cpg]

I needed to get out of here soon...
[cpg]

I don't want to see the bad side of anyone I know anymore.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[OnName num="Kenji"]
"Oh..., good morning."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori162"]
[OnName num="Shiori"]
"Good morning..."
[cpg cn=true]

When I left the special reference book room, Shiori was standing in front of the general collection room door.
[cpg]

[OnName num="Kenji"]
"Huh? Where are the others?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori163"]
[OnName num="Shiori"]
"They're still asleep..."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, I see..."
[cpg cn=true]

It's a wonder I'm not more tired after coming here.
[cpg]

A little bit of oversleeping was unavoidable.
[cpg]

For what it's worth, Shiori has been resting a little during the day as well, so perhaps she hasn't accumulated any major fatigue.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna183"]
[OnName num="Yuna"]
"Good morning..."
[cpg cn=true]

A tired-looking Yuna came down the stairs.
[cpg]

[VOICE f="Erika361"]
[OnName num="Erika"]
"Morning..."
[cpg cn=true]

Erika, who followed behind, also had dark circles under her eyes.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko098"]
[OnName num="Syouko"]
"Are you awake? Good morning! It's time for breakfastー!"
[cpg cn=true]

Was Shoko the only one who was energetic?
[cpg]

Even though she was out cold for two days, she's actually been here just as long as us, but she's tough...
[cpg]

Was it because she was used to being a hardworking nurse?
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko099"]
[OnName num="Syouko"]
On this morning's menu is my selection of 'three kinds of cookies with crackers'!"
[cpg cn=true]

Just the thought of this menu made my mouth water.
[cpg]

But of course, I can’t say it's too luxurious.
[cpg]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika362"]
[OnName num="Erika"]
"I want cocoa..."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko100"]
[OnName num="Syouko"]
"Cocoa? Looks like there is none."
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika363"]
[OnName num="Erika"]
"I want a cup of cocoaー!"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko101"]
[OnName num="Syouko"]
"Umm... We don't have any. I'm sorry."
[cpg cn=true]

Shoko bowed her head at Erika's selfish request.
[cpg]

It wasn't her fault, but she was prone to apologizing.
[cpg]

[OnName num="Kenji"]
"Hey, stop that. It can't be helped even if you throw a tantrum."
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika364"]
[OnName num="Erika"]
"I'm sick and tired of this! I want to go home!"
[cpg cn=true]

[OnName num="Kenji"]
"You think you're the only one? Do you think you're the only one who has it hard?"
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna184"]
[OnName num="Yuna"]
"Ah, um..., Please don't start a fight in the morning..."
[cpg cn=true]

Yuna chided us for fighting while Erika turned her back to me.
[cpg]

This was the norm, but for some reason, I felt like a different kind of thorniness was on full display.
[cpg]

Not just Erika, but me too...
[cpg]

My mind was on edge.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="4/5" time=1000]
[FG f="CHA06_p3_01_a.ui" method="change_4" pos="2/5" time=500]
[WAIT time=100]
[VOICE f="Michi282"]
[OnName num="Michi"]
"Good morning..."
[cpg cn=true]

Michi, who came down the stairs late, also looked pale.
[cpg]

Normally, I would have been able to poke fun at her by saying something like "doctor's should practice what they preach", but in this situation, I couldn't.
[cpg]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Syouko102"]
[OnName num="Syouko"]
"All that's left is Mr. Hosokawa. Let's go wake him up!"
[cpg cn=true]

[SE f="se069"]
;//【ＳＥ】小走り

[move from="2/5" to="5/3" ease="easeInOutSine" time=2000]
[WAIT time=2000]

[if exp={getFlagValue("Key") > 0 }]
[jump target="*j2_a"]
[else]
[jump target="*j2_c"]
[endif]





;//＜鍵フラグ＞が立っている場合、破線内の文章が挿入
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～
*j2_a|Victims
This is bad...
[cpg]

If Shoko goes, she'll find out the room was locked.
[cpg]

Then, inevitably, I'd have to explain why.
[cpg]

[OnName num="Kenji"]
".........."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi283"]
[OnName num="Michi"]
"........."
[cpg cn=true]

Me and Michi made eye contact and stood in Shoko's way.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="2/5" time=500]
[WAIT time=100]
[VOICE f="Syouko103"]
[OnName num="Syouko"]
"Huh?"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="4/5" time=500]
[WAIT time=100]
[VOICE f="Michi284"]
[OnName num="Michi"]
"I'll go. You boil the water."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Syouko104"]
[OnName num="Syouko"]
"I've already got the water on the fire! Besides, you're tired, so leave it to me!"
[cpg cn=true]

[SE f="se069"]
;//【ＳＥ】小走り
[move from="2/5" to="5/3" ease="easeInOutSine" time=1000]
[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi285"]
[OnName num="Michi"]
"Ah!"
[cpg cn=true]

[OnName num="Kenji"]
"Aah!"
[cpg cn=true]

After slipping between me and Michi like a swift little animal, Shoko immediately put her hand on the doorknob.
[cpg]

[STOPBGM]

[SE f="se009"]
;//【ＳＥ】ドア開く

[WAIT time=1000]

[FACE method="change_5" pos="4/5"]
[OnName num="Kenji"]
"What?!"
[cpg cn=true]

[BGM f="silent"]

[VOICE f="Syouko105"]
[OnName num="Syouko"]
"Mr. Hosokawa, it's morning~!"
[cpg cn=true]

Shoko walked into the room, shouting loudly.
[cpg]

When I saw this, I couldn't help but look at Michi.
[cpg]

[OnName num="Kenji"]
"W-why...?"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi286"]
[OnName num="Michi"]
"What's the meaning of this...?"
[cpg cn=true]

I was sure the door was locked yesterday.
[cpg]

There was no way, Hosokawa was locked up just after that happened.
[cpg]

So why...
[cpg]

Is the door unlocked now?
[cpg]

;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～

*j2_c|Victims


[WAIT time=2000]


[STOPBGM]

[VOICE f="Syouko106"]
[OnName num="Syouko"]
"D-doctor! Can you come here for a minute!"
[cpg cn=true]

Shoko, who had entered the general collection room, called Michi from inside in an unusual voice.
[cpg]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi287"]
[OnName num="Michi"]
"......?"
[cpg cn=true]

So Michi, and the rest of us, ran to where Hosokawa had been sleeping.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）
;//☆死亡
;//細川死亡

[BGM f="danger"]

;//細川が目を剥いて死んでいる
;//[free time=1000]
;**【ＣＧ】ci_02_0 ***********************
;//カットイン
[CUTIN f="ci_02_0.ui" show={true} method="slidein"]
;*****************************************
;;//[WAIT time=1000]


[OnName num="Kenji"]
"...What?!"
[cpg cn=true]

Wrapped tightly in a blanket, Hosokawa was staring steadily at the ceiling.
[cpg]

His eyes seem to be open wider than usual.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_5" pos="2/7" time=800]
[WAIT time=100]
[VOICE f="Michi288"]
[OnName num="Michi"]
"This is..."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="6/7" time=800]
[WAIT time=100]
[VOICE f="Erika365"]
[OnName num="Erika"]
"Get the hell up. Your eyes are open..., aren't they? Eh? What...?"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="7/7" time=800]
[WAIT time=100]
[VOICE f="Yuna185"]
[OnName num="Yuna"]
"You're joking..., right? That can't be..."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="1/7" time=800]
[WAIT time=100]
[VOICE f="Shiori164"]
[OnName num="Shiori"]
"Ah... Ah..."
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_4" pos="1/7" time=800]
[WAIT time=100]
[VOICE f="Syouko107"]
[OnName num="Syouko"]
"Doctor..."
[cpg cn=true]

All of the people who gathered around the sleeping Hosokawa reacted in different ways, but no one said anything conclusive.
[cpg]

This is because only Michi could...
[cpg]

[CUTIN f="ci_02_0.ui" show={false} method="slideout"]


;//[free time=900]
;//[BG f="black.ui" time=900]
;//[WAIT time=1500]
;/[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）

[WAIT time=1000]


;//[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[FACE method="change_3" pos="2/6"]
[WAIT time=100]
[VOICE f="Michi289"]
[OnName num="Michi"]
"Everyone stand back..."
[cpg cn=true]

[move from="2/6" to="2/3" ease="easeInOutSine" time=1000]
[move from="1/6" to="9/6" ease="easeInOutSine" time=1000]
[move from="5/6" to="10/6" ease="easeInOutSine" time=1000]
[move from="6/6" to="11/6" ease="easeInOutSine" time=1000]

[WAIT time=1000]

With the face of a doctor, Michi put her fingers on Hosokawa's neck, then deftly ripped off the blanket and rolled up the sleeves of the shirt he had been wearing.
[cpg]

Then she stood up slowly and told us in a sad voice...
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi290"]
[OnName num="Michi"]
"He's dead..."
[cpg cn=true]

;//【ＢＧＭ】死亡
;//[BGM f="d1"]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5" pos="4/5" time=800]

[WAIT time=100]
[VOICE f="Erika366"]
[OnName num="Erika"]
"Eh?! Why? How?! Why, how?!"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna186"]
[OnName num="Yuna"]
"A-another murder?! No...no way... Nooooo!"
[cpg cn=true]

Erika and Yuna collapsed in a hug on the spot.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori165"]
[OnName num="Shiori"]
"Ugh...cough! Cough, cough!"
[cpg cn=true]

[OnName num="Kenji"]
"Shiori , don't look..."
[cpg cn=true]

[free time=1000]

I held Shiori's shoulders as she began to cough and turned her face away from Hosokawa, then asked Michi.
[cpg]

[OnName num="Kenji"]
"What was the cause of death...?"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi291"]
[OnName num="Michi"]
"I don't know."
[cpg cn=true]

[OnName num="Kenji"]
"You don't know...?"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi292"]
[OnName num="Michi"]
"There were no external injuries, and I checked his arm to see if it was drugs, but I couldn't find any traces of an injection..."
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Syouko108"]
[OnName num="Syouko"]
"Could it be a heart attack...?"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi293"]
[OnName num="Michi"]
"We can't find out anything more here...let's take him to the infirmary. We can't do an autopsy, but we can get a closer look and see what we can find out."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika367"]
[OnName num="Erika"]
"What do you mean, 'get a closer look'? He was murdered anyway! One of the three of you killed himー!"
[cpg cn=true]

Erika declared as she tightly hugged Yuna, who was trembling.
[cpg]

I think she was scared out of her mind.
[cpg]

[OnName num="Kenji"]
"H-hey, I know you're scared, but it could have been due to an illness."
[cpg cn=true]

When I said that, Erika turned to look at me.
[cpg]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika368"]
[OnName num="Erika"]
"What are you talking about? Sometimes one person is killed, and another dies of a mysterious illness? This was definitely the work of a serial killer!"
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Syouko109"]
[OnName num="Syouko"]
"B-but, you know, Erika..."
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika369"]
[OnName num="Erika"]
"Kyaー! Get away from me!!"
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Syouko110"]
[OnName num="Syouko"]
"Oh, woah..."
[cpg cn=true]

Shoko was just trying to comfort her, but Erika threatened her with a hysterical scream.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi294"]
[OnName num="Michi"]
"We'd better leave her alone for a while... I'm sorry, Kenji but please help me."
[cpg cn=true]

[OnName num="Kenji"]
"Ah..., yes... I'll hold his head."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi295"]
[OnName num="Michi"]
"Oh, go for the legs. With his size, he might be easy to move, shoulders and all."
[cpg cn=true]

[OnName num="Kenji"]
"All right."
[cpg cn=true]

Without questioning, I followed Michi's instructions and lifted Hosokawa's legs.
[cpg]

His body was rigid and it felt like he was on a stretcher.
[cpg]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）******************************************************

[WAIT time=1500]

[BGM f="serious"]

Hosokawa's body was taken to the infirmary and laid out on the stainless steel table...
[cpg]

His skin looked whiter than Takagi's had.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi296"]
[OnName num="Michi"]
"Sigh..."
[cpg cn=true]

I stared silently as Michi let out a sigh with a tired face.
[cpg]

[OnName num="Kenji"]
".................."
[cpg cn=true]

[if exp={getFlagValue("Key") > 0 }]
[jump target="*j3_a"]
[else]
[jump target="*j3_c"]
[endif]



;//＜鍵フラグ＞が立っている場合、破線内の文章が挿入
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～

*j3_a|Victims
The person who locked him in that room was Michi.
[cpg]

Naturally, the key was in Michi's possession.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi297"]
[OnName num="Michi"]
"What...?"
[cpg cn=true]

She noticed my gaze, her eyes were the same color as mine.
[cpg]

[OnName num="Kenji"]
"How many...keys are there?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi298"]
[OnName num="Michi"]
"There's only one key... You suspect me, don't you?"
[cpg cn=true]

[OnName num="Kenji"]
"Well..."
[cpg cn=true]

When I clammed up at her straightforward question, Michi muttered, her eyes slightly downcast.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi299"]
[OnName num="Michi"]
"It's okay. It's only natural. Besides..., I'm suspicious of you."
[cpg cn=true]

[OnName num="Kenji"]
"Huh...?"
[cpg cn=true]

Suspicious of me?
[cpg]

Even though she was the one with the key... Why?
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi300"]
[OnName num="Michi"]
"It's an old-fashioned key. You could open it with something like a hairpin. Boys are good at that sort of thing, aren't they?"
[cpg cn=true]

[OnName num="Kenji"]
"What are you talking about? I wouldn't do something like that!"
[cpg cn=true]

Was she saying that all men are criminals?
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi301"]
[OnName num="Michi"]
"Yesterday, you were furious... After that, you were still angry, so you went back and unlocked the door somehow..."
[cpg cn=true]

[OnName num="Kenji"]
"Somehow?!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi302"]
[OnName num="Michi"]
"Well, I don't know. I'm not a good guesser."
[cpg cn=true]

[OnName num="Kenji"]
"That's unlikely, isn't it? It's more likely that Hosokawa unlocked the door from the inside and let someone in."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi303"]
[OnName num="Michi"]
"Unfortunately, that door can't be opened from the inside without a key. Oh..., that makes me seem even more likely to be the culprit..."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]


I can't get rid of the idea that the doctor in front of me might be the murderer.
[cpg]

But at the same time I thought it was too far-fetched.
[cpg]

If she had been planning to kill him, she shouldn't have locked the door when she did.
[cpg]

Then she wouldn't be suspected.
[cpg]

Then I wouldn't have been so suspicious of her either.
[cpg]

Would Michi be that sloppy?
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi304"]
[OnName num="Michi"]
"But, well..., it's true that I had thought that for a moment, but I soon realized that it wasn't you."
[cpg cn=true]

[OnName num="Kenji"]
"Huh...?"
[cpg cn=true]

As if the past was a prelude, Michi looked up and stared at the corpse of Hosokawa.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi305"]
[OnName num="Michi"]
"If you had done it, Kenji, it would have been impossible to kill him without leaving a mark. Bludgeoning, stabbing, strangulation, they all leave marks."
[cpg cn=true]

[OnName num="Kenji"]
"So...?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi306"]
[OnName num="Michi"]
"Didn't I tell you already? I don't know. He could have died of natural causes."
[cpg cn=true]

[OnName num="Kenji"]
"That's true. It's not like that's not a possibility!"
[cpg cn=true]

Erika decided it was murder, but death by illness is more common.
[cpg]

The death of Takagi was just unusual.
[cpg]

I felt a glimmer of hope shining down on me, and I felt a little lighter.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi307"]
[OnName num="Michi"]
"But there is another possibility..."
[cpg cn=true]

[OnName num="Kenji"]
"Yes, what is it?"
[cpg cn=true]

In contrast to my slightly cheerful voice, Michi's expression was dark.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi308"]
[OnName num="Michi"]
"I don't want to say too much, but... if you hit him so hard yesterday that he had a brain hemorrhage..."
[cpg cn=true]

[OnName num="Kenji"]
"!!"
[cpg cn=true]

When she said that, I went to a dark place.
[cpg]

[OnName num="Kenji"]
"Well, then..., could it be that I....I killed him...?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi309"]
[OnName num="Michi"]
"No. Even if that was the case, it was an accident. I knew it was a possibility, when I left him there."
[cpg cn=true]

[OnName num="Kenji"]
"B-but..., I hit him, so..."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi310"]
[OnName num="Michi"]
"Please, don't be so hard on yourself."
[cpg cn=true]

[FG f="CHA05_p5_01_a.ui" method="change_7" pos="2/3" time=800]


Michi hugged me to her chest.
[cpg]

Just like I was for her yesterday, she was comforting, caring, gentle, and strong.
[cpg]

Thump...thump...thump...
[cpg]

The sound of her heart pulsing beneath the soft swelling of her chest.
[cpg]

It was an important rhythm to hear because it meant she was alive.
[cpg]

That sound could no longer be heard from Hosokawa.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi311"]
[OnName num="Michi"]
"No one knows what really happened yet. So let's keep yesterday a secret between us. Of course, I'll tell the police everything later, but until then..."
[cpg cn=true]

[OnName num="Kenji"]
"Yes..."
[cpg cn=true]

I also didn't want to blow the whistle on the possibility that I might have killed him.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi312"]
[OnName num="Michi"]
".................."
[cpg cn=true]

;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～

*j3_c|Victims

I don't think I can take being in this intense atmosphere with dead bodies anymore.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi313"]
[OnName num="Michi"]
"Shall we go back...?"
[cpg cn=true]

[OnName num="Kenji"]
"Yes..."
[cpg cn=true]

When I turned around in front of the door to leave the infirmary, Hosokawa's motionless body looked like a mannequin.
[cpg]

And I was struck by a vague and mysterious sense of unease.
[cpg]

That corpse...is not going to disappear too, is it...?
[cpg]

;//エフェクト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
;//栞の襟首を掴んでいるエリカ　柚那と章子はオロオロしている
[BG f="black.ui" time=100]
[free time=100]
[WAIT time=200]

[BG f="b_l_1f_entrance_p2.ui" time=100]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=100]
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="3/3" time=100]

[WAIT time=1000]

[STOPBGM]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[window target=true]


[BGM f="huan"]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika370"]
[OnName num="Erika"]
"What are you going to do about it?"
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Shiori166"]
[OnName num="Shiori"]
"I'm sorry..., if it wasn't for this system, none of this would...have happened."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika371"]
[OnName num="Erika"]
"Yes! It's all your fault!"
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

When Michi and I returned from the basement, we found an unbelievable scene unfolding at the entrance.
[cpg]

Erika grabbed Shiori by the collar and Shiori was apologizing over and over through her tears.
[cpg]


;//[free time=900]
;//[BG f="black.ui" time=900]
;//[WAIT time=1500]
;//[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

;//[WAIT time=1500]


[VOICE f="Michi314"]
[OnName num="Michi"]
"What are you doing?!"
[cpg cn=true]

Before I could say anything else, Michi jumped out.
[cpg]

[SE f="se045"]
;//【ＳＥ】ドカッ！

[FACE method="change_5" pos="2/3"]
[WAIT time=1]
[move from="2/3" to="1/3" ease="easeInOutSine" time=800]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika372"]
[OnName num="Erika"]
"Hey!"
[cpg cn=true]

Michi pushed Erika to release the Shiori, and without pausing, she raised her right hand.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi315"]
[OnName num="Michi"]
"How dare you go after Shiori!"
[cpg cn=true]

[SE f="se070"]
;//【ＳＥ】ビンタ

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika373"]
[OnName num="Erika"]
"Agh!"
[cpg cn=true]

[SE f="se035"]
;//【ＳＥ】転倒

[free time=1000]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=1000]
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="3/3" time=1000]
She looked angrily at Erika, who had slumped to the floor.
[cpg]


[VOICE f="Michi316"]
[OnName num="Michi"]
"Go to your room."
[cpg cn=true]

Michi instructed Shiori.
[cpg]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Shiori167"]
[OnName num="Shiori"]
"But...cough, cough."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi317"]
[OnName num="Michi"]
"Go. Now."
[cpg cn=true]

[move from="3/3" to="5/3" ease="easeInOutSine" time=2500]
[WAIT time=2000]

Shiori went upstairs, coughing.
[cpg]

When she was out of sight of the entrance, Michi spoke in a frighteningly cold voice to Erika .
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA03_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi318"]
[OnName num="Michi"]
"Don't get carried away."
[cpg cn=true]

[OnName num="Kenji"]
".........!"
[cpg cn=true]

The tone was so different from usual that I, Yuna, and even Shoko shuddered.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika374"]
[OnName num="Erika"]
"What's with...everyone protecting her? I just told her the truth, that's all! I told her that the library management is responsible for the two people who died!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi319"]
[OnName num="Michi"]
"Responsible for what...? What are you talking about?"
[cpg cn=true]

In contrast to Erika, who was like a barking lapdog, Michi approached in a slow tone of voice, like a wild panther.
[cpg]

Erika will now have to pay for biting the one person she should never have bitten.
[cpg]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi320"]
[OnName num="Michi"]
You're not very bright, so let me be clear. We are in captivity because of your criminal activities."
[cpg cn=true]

[VOICE f="Michi1320"]
[OnName num="Michi"]
"If you'd been quiet, I would have let it go, but now that this has happened, I'm not going to let it go."
[cpg cn=true]


[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika375"]
[OnName num="Erika"]
"W-what? What are you going to do?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi321"]
[OnName num="Michi"]
"I'm going to sue you as soon as I get out of here for attempted theft."
[cpg cn=true]

[VOICE f="Michi1321"]
[OnName num="Michi"]
"In addition to actual damages, I'm demanding compensation for the assault on Shiori and for the emotional distress caused by the assault."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika376"]
[OnName num="Erika"]
"H-huh?! What are you talking about? Over something stupid like that?"
[cpg cn=true]

Erika was upset, not losing her will to fight, but losing the battle. But Erika was no more powerful than a toy water gun against an angry Michi.
[cpg]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi322"]
[OnName num="Michi"]
"Shiori has suffered traumatic stress and I will write a medical report on it. I hope your family is wealthy."
[cpg cn=true]

[VOICE f="Michi1322"]
[OnName num="Michi"]
"If not, they're probably bankrupt. You and your family will be out on the street!"
[cpg cn=true]


She probably at least understood what bankruptcy and family meant, even if she didn't understand the jumbled jargon that came before it.
[cpg]

Erika just looked up at Michi in frustration.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika377"]
[OnName num="Erika"]
"What, then me too. I'm suing you too!"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi323"]
[OnName num="Michi"]
"Well. You should. At the very least, you should be prepared with plenty of money for court costs. It would be a shame if you went bankrupt before the verdict."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika378"]
[OnName num="Erika"]
"Aaaaarghhh!"
[cpg cn=true]

[free time=1000]

Erika, defeated by Michi's words, roared as if she was going to grab Michi at any moment. Panicking, Yuna and Shoko stopped her.
[cpg]

[OnName num="Kenji"]
"Sigh..."
[cpg cn=true]

I hate this...
[cpg]

Why did we have to fight like this...?
[cpg]

I was so weak that I looked up at the sky.
[cpg]

Then...
[cpg]

;//２階左側の階段上で、手招きする栞
.........
[cpg]

[OnName num="Kenji"]
"Shiori...?"
[cpg cn=true]

I don't know how long I'd been there, but there was Shiori staring at me from the second floor door, beckoning me over.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_3" pos="1/4" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/4" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_4" pos="3/4" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="4/4" time=800]
[WAIT time=100]
[VOICE f="Yuna187"]
[OnName num="Yuna"]
"Erika, stop it!"
[cpg cn=true]

[FACE method="change_1" pos="4/4"]
[WAIT time=100]
[VOICE f="Michi324"]
[OnName num="Michi"]
"Oh, no, you don't have to stop. If you want to do something, go ahead. Are you going to hit me? Kick me?"
[cpg cn=true]

[FACE method="change_3" pos="2/4"]
[WAIT time=100]
[VOICE f="Erika379"]
[OnName num="Erika"]
"This bitc..."
[cpg cn=true]

[FACE method="change_5" pos="3/4"]
[WAIT time=100]
[VOICE f="Syouko111"]
[OnName num="Syouko"]
"Woah! Doctor, don't encourage her!"
[cpg cn=true]

[FACE method="change_2" pos="4/4"]
[WAIT time=100]
[VOICE f="Michi325"]
[OnName num="Michi"]
"I said it's fine. I think she wants to add assault to the charges."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

I was fed up with the ongoing fight, and headed upstairs at Shiori's invitation to sneak out.
[cpg]


[STOPBGM]

;//エフェクト
[window target=false]
[transition target={true} rule="39.png" color={0x000000ff} time=2000]
[WAIT time=2000]
[free time=100]
[BG f="black.ui" time=100]
[WAIT time=200]

[BG f="b_l_2f_ros_0.ui" time=100]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************
[WAIT time=2000]
[transition target={false} rule="39.png" color={0x000000ff} time=2000]
[WAIT time=3000]

[window target=true]

[BGM f="dod"]


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori168"]
[OnName num="Shiori"]
"Come in..."
[cpg cn=true]

[OnName num="Kenji"]
"Sorry to bother you..."
[cpg cn=true]

Shiori invited me into her room, sat down on her bed and offered me a chair.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori169"]
[OnName num="Shiori"]
"I thought...you didn't want to watch the fight..."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah...Thanks. I appreciate it."
[cpg cn=true]

I'm sure Shiori felt the same way I did.
[cpg]

Especially, in her case, she must not have been able to bear to see that side of her beloved Michi.
[cpg]

Also, because Michi didn't want to be seen, she probably let Shiori go to her room.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori170"]
[OnName num="Shiori"]
"That was scary, wasn't it...?"
[cpg cn=true]

[OnName num="Kenji"]
"A little..."
[cpg cn=true]

Fights between women are scary because they're rare.
[cpg]

That's why I was just flabbergasted and useless earlier.
[cpg]

It was sad, but it's probably how any man would have reacted.
[cpg]

[OnName num="Kenji"]
"Shiori..., have you been listening this whole time?"
[cpg cn=true]

I asked, and Shiori nodded bashfully.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori171"]
[OnName num="Shiori"]
"The doctor said something like that, but... I have PTSD..."
[cpg cn=true]

[OnName num="Kenji"]
"P...what?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori172"]
[OnName num="Shiori"]
"Post Traumatic Stress Disorder..."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, is that what you call it?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori173"]
[OnName num="Shiori"]
"Even though I'm...really okay..."
[cpg cn=true]

 Shiori looked so sad while mumbling.
[cpg]

[OnName num="Kenji"]
"Michi is just worried about Shiori. And I'm sure that was just a threat to punish Erika, so you shouldn't worry about it."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori174"]
[OnName num="Shiori"]
"That argument...is pointless..."
[cpg cn=true]

[OnName num="Kenji"]
"You're right..."
[cpg cn=true]

It wasn't like having a fight was going to bring help or find us a way out.
[cpg]

But it was really pointless to create a bad atmosphere.
[cpg]

[OnName num="Kenji"]
"Ah, anyway, your room is nice~"
[cpg cn=true]

We decided to change the subject at this point, and stood up just as each other's words trailed off.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori175"]
[OnName num="Shiori"]
"Not really, but..."
[cpg cn=true]

[OnName num="Kenji"]
"No, no. It really is. When I first came here, I was amazed at the number of books in your collection."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori176"]
[OnName num="Shiori"]
"Before I realized it, there were so many..."
[cpg cn=true]

[OnName num="Kenji"]
"And all these animals."
[cpg cn=true]

I looked at the plethora of books in the Shiori room and then looked at the sculptures at my feet.
[cpg]

The figurines of dogs and cats, which looked as if they were alive, seemed to me, as an amateur, to be wonderful works of art.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori177"]
[OnName num="Shiori"]
"Oh, please don't touch them... They break easily..."
[cpg cn=true]

[OnName num="Kenji"]
"Is that so? Yeah, I won't touch it."
[cpg cn=true]

I wanted to touch it for a moment, but I withdrew my hand in case I broke it.
[cpg]

[OnName num="Kenji"]
"Hmm? There are such things?"
[cpg cn=true]

At that time, I noticed the partial sculptures of human hands and feet, which were hidden by cats and dogs.
[cpg]

I had seen such things in the art room at school.
[cpg]

[OnName num="Kenji"]
'Hey, this one here is..."
[cpg cn=true]

In a room full of books and animals, I discovered an oddly shaped object that had been placed there.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori178"]
[OnName num="Shiori"]
"Oh, that's...a puzzle."
[cpg cn=true]

[OnName num="Kenji"]
"Wowー, that's great. You do this kind of thing too?"
[cpg cn=true]

It was a difficult looking puzzle that looked different from the ones sold in stores.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori179"]
[OnName num="Shiori"]
"It was given to me by my grandfather. I used to play with it when I was little."
[cpg cn=true]

[OnName num="Kenji"]
"Wowー."
[cpg cn=true]

He must have prepared it especially for his granddaughter.
[cpg]

It may have been for educational use, but aside from that, you could feel his love for Shiori.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori180"]
[OnName num="Shiori"]
"Anyway..., what did the doctor say about Mr. Hosokawa?"
[cpg cn=true]

[OnName num="Kenji"]
"Oh, nothing in particular..."
[cpg cn=true]

Shiori was also wondering what caused Hosokawa's death.
[cpg]

[OnName num="Kenji"]
"I hope he wasn't killed, but..."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori181"]
[OnName num="Shiori"]
"Dying of natural causes is scarier..."
[cpg cn=true]

[OnName num="Kenji"]
"Huh?"
[cpg cn=true]

I couldn't gauge the meaning of Shiori's words and looked at the expression on her face...
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori182"]
[OnName num="Shiori"]
"Grandfather...was not sick, but he got thin... He got thinner and thinner and then shriveled up..."
[cpg cn=true]

She began to talk about her grandfather...in a very sad way.
[cpg]

[OnName num="Kenji"]
"It was senility, right? But that's only natural, you know."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori183"]
[OnName num="Shiori"]
"Even though I knew it in my head, I...felt so sorry for my grandfather, getting thinner and thinner day by day... It was very hard for me to watch him..."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah..."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori184"]
[OnName num="Shiori"]
"And..., I think it must have been hard for him to be seen like that..."
[cpg cn=true]

Just as Shiori said, it really must be painful to stare at your loved ones as they gradually move towards death.
[cpg]

It's also hard for your loved ones to see you weakened by them.
[cpg]

[OnName num="Kenji"]
"But Shiori, you took care of your grandfather, right?"
[cpg cn=true]

I waited for Shiori to nod, and then I continued.
[cpg]

[OnName num="Kenji"]
"Then I think your grandfather must have been happy, because his beloved grandchild was with him all the time."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori185"]
[OnName num="Shiori"]
"Yeah...?"
[cpg cn=true]

[OnName num="Kenji"]
"You know, I..."
[cpg cn=true]

;//＠
[free time=1000]
[BG f="black.ui" time=1000]

I was embarrassed by the line I was about to utter, so I turned my back to Shiori.
[cpg]

I stared at her through the mirror that hung on the bookshelf and spoke, trying not to let my voice trail off.
[cpg]

;//＠
;//※鏡に映る賢治の顔半分と、後のベッドに座っている栞（鏡はキーのひとつなので出来れば絵にしてください）

[OnName num="Kenji"]
"When I die, I want to die beside the person I love."
[cpg cn=true]

[OnName num="Kenji"]
"If I could die in the arms of someone I love, I would go to heaven feeling great, even if my life had been a disaster!"
[cpg cn=true]

I really wanted to look into Shiori's eyes and say it, but I didn't have the courage, so I looked...through the mirror.
[cpg]

But did my feelings reach her?
[cpg]


[VOICE f="Shiori186"]
[OnName num="Shiori"]
"Hmm... Yeah... After all, I think so too... That's good. I'm glad Kenji thinks the same way I do..."
[cpg cn=true]

;//＠
;//[free time=900]
;//[BG f="black.ui" time=900]
;//[WAIT time=1500]
;//[BG f="b_l_1f_ros_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）
;//[WAIT time=1500]

[STOPBGM]

[OnName num="Kenji"]
"......!"
[cpg cn=true]

The next thing I knew, Shiori was standing right behind me.
[cpg]

Then she put her cheek on my back and put her arms around me and whispered.
[cpg]

;//＠
[BGM f="h1"]

;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori187"]
[OnName num="Shiori"]
"I'm scared... Because of this weak body..., I'm afraid that I'm going to die...at any moment too. So if I'm going to die, I want to die...near someone I love."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah..."
[cpg cn=true]

Shiori with her frail body may be much closer to death than I am.
[cpg]

We are constantly confronted with the fear of the Grim Reaper, wondering when he will come and when he will not.
[cpg]

;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori188"]
[OnName num="Shiori"]
"And now, as Kenji said..."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah..."
[cpg cn=true]

;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori189"]
[OnName num="Shiori"]
"I want the man I love to...die beside me, just like my grandfather..."
[cpg cn=true]

[OnName num="Kenji"]
"Shiori..."
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_5" pos="2/3" time=500]

I turned around and hugged Shiori's small body to my chest.
[cpg]

She was so fragile, talking about life and death, that if I didn't protect her, it seemed like she would disappear into the air and fly away.
[cpg]

[OnName num="Kenji"]
"Hey, enough of this talk. That's way down the line. Let's talk about living happily together."
[cpg cn=true]

I hope that Shiori and I can be friends for a long time to come.
[cpg]

I'm going to take the little bird Shiori out of this birdcage called the library and show her the fun and vast world.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori190"]
[OnName num="Shiori"]
"Kenji is warm..."
[cpg cn=true]

Shiori didn't respond to what I said, but smiled and buried her face in my chest instead.
[cpg]

[OnName num="Kenji"]
"Shiori is warm too."
[cpg cn=true]

If this cold winter weather makes it easier for us to feel each other's body heat, then I hope winter lasts forever...
[cpg]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=1500]

[BGM f="dod"]

The hands of my watch pointed to noon, and after making sure that downstairs was quiet, we went back to the entrance.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi326"]
[OnName num="Michi"]
"What have you two been up to?"
[cpg cn=true]

[OnName num="Kenji"]
"No, nothing..."
[cpg cn=true]

Michi was still in a bad mood, though not as bad as during the fight.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi327"]
[OnName num="Michi"]
"Well, you must be hungry. You should eat, too."
[cpg cn=true]

There were cookies and crackers on a paper plate that Shoko had probably prepared for breakfast.
[cpg]

[SE f="se071"]
;//【ＳＥ】クッキー貪る
[free time=1]
[WAIT time=1]

[FG f="CHA03_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika380"]
[OnName num="Erika"]
".................."
[cpg cn=true]


[VOICE f="Yuna188"]
[OnName num="Yuna"]
".................."
[cpg cn=true]

[OnName num="Kenji"]
"......"
[cpg cn=true]

Erika and Yuna reached out silently and devoured the cookies.
[cpg]

They were so hungry that their eyes changed color.
[cpg]

[SE f="se071"]
;//【ＳＥ】クラッカー貪る

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika381"]
[OnName num="Erika"]
"Mmm... gobble..."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna189"]
[OnName num="Yuna"]
"Munch, munch, munch..."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

It was expected of Erika, but even the ladylike Yuna was gobbling up as many crackers as she could stuff in her mouth, the sight was much more shocking than the fight.
[cpg]

And then...
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko112"]
[OnName num="Syouko"]
"Um, can I have everyone's attention while we eat?"
[cpg cn=true]

As Shoko abruptly cut in, me, Shiori, and Michi stopped our hands, but Erika and Yuna didn't even look up.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko113"]
[OnName num="Syouko"]
"In fact..., I'm very sorry to say this, but... Um..."
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi328"]
[OnName num="Michi"]
"What is it? Say it quickly."
[cpg cn=true]


[STOPBGM]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko114"]
[OnName num="Syouko"]
"Yes..., then I will just come out and say it. We've only got enough food for one more day!"
[cpg cn=true]

[BGM f="huan"]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika382"]
[OnName num="Erika"]
"Puh?!"
[cpg cn=true]

[VOICE f="Yuna190"]
[OnName num="Yuna"]
"......?!"
[cpg cn=true]

The gravity of the situation was so great that Erika cookies and crackers came flying out of her mouth, and Yuna covered her mouth with her eyes wide open.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi329"]
[OnName num="Michi"]
"Is that...true?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko115"]
[OnName num="Syouko"]
"Yes... I thought it would last a few more days by my rough estimate, but..."
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika383"]
[OnName num="Erika"]
"But what? You mean you made a mistake in your calculations? Or did you steal food?"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko116"]
[OnName num="Syouko"]
"What?? I didn't do that!"
[cpg cn=true]

I thought about saying something, fed up with Erika blaming others again.
[cpg]

But it's hard to say anything when the food has run out.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko117"]
[OnName num="Syouko"]
"Oh, but we have plenty of tea leaves and coffee, so that's still okay, right?"
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika384"]
[OnName num="Erika"]
"What's okay?!"
[cpg cn=true]

That would...mean that we wouldn't starve to death yet...
[cpg]

[SE f="se071"]
;//【ＳＥ】クッキー貪る

[WAIT time=2000]

;//＠
[free time=1000]
;**【ＣＧ】ev_03_0 ***********************
[CG id=02 index=0 time=1000]
;*****************************************
[WAIT time=1000]


[VOICE f="Erika385"]
[OnName num="Erika"]
"Ah! Yuna, what are you doing! That's mine! Give it backー!"
[cpg cn=true]

[OnName num="Kenji"]
"Uh..."
[cpg cn=true]



[VOICE f="Yuna191"]
[OnName num="Yuna"]
"Munch, munch, munch..."
[cpg cn=true]

When I looked over, I saw Yuna crawling on the floor, putting the cookie and cracker crumbs that Erika had spit out into her mouth.
[cpg]


[VOICE f="Erika386"]
[OnName num="Erika"]
"Open your mouth! You...!"
[cpg cn=true]


[VOICE f="Yuna192"]
[OnName num="Yuna"]
"Munch, munch, munch..."
[cpg cn=true]

[OnName num="Kenji"]
"Ugh..."
[cpg cn=true]

It was strange.
[cpg]

The always quiet Yuna could avoid Erika's pushy hands and still pick up food scraps.
[cpg]

There was at least enough food for tomorrow, but then what?
[cpg]

[STOPBGM]

;//エフェクト
[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=2000]
[free time=100]
[BG f="black.ui" time=100]
[WAIT time=200]

[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

;//[BG f="b_l_1f_nbr_p2.ui" time=100]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）
[WAIT time=2000]
[transition target={false} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=3000]
[window target=true]


[BGM f="dod"]

[FG f="CHA03_p3_01_a.ui" method="change_6" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=800]

When the plates were emptied and the food was cleaned up, Yuna, who had been like a child missing food, came to her senses.
[cpg]



[VOICE f="Yuna193"]
[OnName num="Yuna"]
"I'm...sorry. I am ashamed. I don't know why I did what I did..."
[cpg cn=true]

[VOICE f="Erika387"]
[OnName num="Erika"]
"Well..., give me back my portion of the food during dinner."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna194"]
[OnName num="Yuna"]
"Yeah..."
[cpg cn=true]

Yuna looked so pensive.
[cpg]

I'm sure she was stressed out.
[cpg]

But I'm glad she's back to normal.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika388"]
[OnName num="Erika"]
"Aah, I'm hungry and bored..."
[cpg cn=true]

Erika started complaining again.
[cpg]

How can she be bored when we have so many books?
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika389"]
[OnName num="Erika"]
"I want to go out. I want to go shopping. I am so bored!"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko118"]
[OnName num="Syouko"]
"Then let's do some cleaning!"
[cpg cn=true]

Shoko suggested it as if it was a good idea, but of course no one wanted to do it.
[cpg]

[VOICE f="Michi330"]
[OnName num="Michi"]
"But, well..., you can certainly see some dust now, so that might be a good idea."
[cpg cn=true]

Michi said, and I agreed.
[cpg]

It'd be good to move around a bit.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko119"]
[OnName num="Syouko"]
"Well, it's a big place, so I'm going to make up a chore chart!"
[cpg cn=true]

It was like a class meeting.
[cpg]

In other words, Shoko was a beautification committee member.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko120"]
[OnName num="Syouko"]
"Well, do you have a pen and paper?"
[cpg cn=true]

Shiori nodded and brought some writing materials from the counter.
[cpg]

Then, Shoko, our beautification committee person, took charge.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko121"]
[OnName num="Syouko"]
"Well, let's start with the restrooms first."
[cpg cn=true]

[OnName num="Kenji"]
"There first...?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko122"]
[OnName num="Syouko"]
"Does anyone want to volunteer?"
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi331"]
[OnName num="Michi"]
"Kenji is in charge of the men's room. You're in charge of the women's room."
[cpg cn=true]

[OnName num="Kenji"]
"Yes..."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko123"]
[OnName num="Syouko"]
"Okay, then..."
[cpg cn=true]

In the end, Michi made the decisions, and Shoko and I were put in charge of the restrooms, with or without our consent.
[cpg]

Well, it's good that I'm the only man left, but I felt bad for Shoko.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko124"]
[OnName num="Syouko"]
"I've got the restroom. So next is..."
[cpg cn=true]

After writing that on a piece of paper, Shoko regained her composure and started over.
[cpg]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi332"]
[OnName num="Michi"]
"Shiori and I will take the left side of the second floor. Erika will take the right side. Yuna and Kenji will do the first floor. Everyone will do the entrance. Then the basement medical room will be me and..."
[cpg cn=true]

Shoko has been chosen for the storage room.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko125"]
[OnName num="Syouko"]
"Ahhh..."
[cpg cn=true]

In spite of all the hard work, in the end Michi decided everything.
[cpg]

In addition, no one had any objections to it.
[cpg]

Even Erika did not disobey because of what happened this morning.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko126"]
[OnName num="Syouko"]
"Well? The first floor was Erika's? Hmm? No, me? Huh?"
[cpg cn=true]

Because Michi had said it all at once, Shoko's hand, which held the pen, couldn't keep up on the paper.
[cpg]

Perhaps noticing this, Shiori took over and wrote for her.
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko127"]
[OnName num="Syouko"]
"Aww, I'm sorry..."
[cpg cn=true]

Shiori has a great memory..., well, I think it'd be easy to forget, but she writes out the assignments on a piece of paper in beautiful handwriting.
[cpg]

;//書き物を右手でする栞（※絵にしてください）



The way she read a book was brilliant and beautiful, but the way she wrote was also wonderful.
[cpg]

Her back was straight, her sides tightened up, and her right hand grip was also correct...
[cpg]

[OnName num="Kenji"]
"Is that...?"
[cpg cn=true]

Something was funny..., I realized vaguely mid thought.
[cpg]

For a moment I couldn't figure out what was wrong, but a little later I realized why.
[cpg]

[OnName num="Kenji"]
"I thought Shiori was left-handed?"
[cpg cn=true]


;//コトハ
[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori191"]
[OnName num="Shiori"]
"...Huh?"
[cpg cn=true]

[OnName num="Kenji"]
"Didn't you write with your left hand the last time we played a game?"
[cpg cn=true]

I thought maybe I was mistaken, but when I looked at Yuna, she nodded.
[cpg]



;//コトハ
[FACE method="change_7" pos="1/3"]
[WAIT time=100]

[VOICE f="Shiori192"]
[OnName num="Shiori"]
"I'm ambidextrous..."
[cpg cn=true]

[OnName num="Kenji"]
"Ambidextrous?"
[cpg cn=true]

I knew there were people like that, but this was the first time I had actually seen one.
[cpg]

It was amazing that she could use both hands equally well.
[cpg]



;//[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）
;//[WAIT time=1500]


[FACE method="change_7" pos="1/3"]
[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika390"]
[OnName num="Erika"]
"So you can hold chopsticks with your left and write with your right? Isn't it super nice to be able to write two lines of kanji at once?"
[cpg cn=true]

[OnName num="Kenji"]
"Why are you like this..."
[cpg cn=true]

The reason why Erika was envious was quite dumbfounding.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika391"]
[OnName num="Erika"]
"Hey, hey, let me see you do it!"
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori193"]
[OnName num="Shiori"]
"See what...?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika392"]
[OnName num="Erika"]
"Try writing two columns of the same sentence at once!"
[cpg cn=true]

Erika's face brightened up, as if she was watching "Ripley’s Believe it or not!"
[cpg]

Well, to put it nicely, this kind of childlike wonder is one of her strong points.
[cpg]

On top of that, I was also a little bit curious, so I didn't try to stop her, but...
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi333"]
[OnName num="Michi"]
"Don't be silly, now that we've decided, let's start cleaning. Shiori, you can do your own room, can't you?"
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori194"]
[OnName num="Shiori"]
"Yeah..."
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi334"]
[OnName num="Michi"]
"Okay, that's settled then."
[cpg cn=true]

[SE f="se024"]
;//【ＳＥ】柏手
Michi clapped her hands, and that was the end of the matter.
[cpg]

What a shame.
[cpg]

;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=2000]
[BG f="black.ui" time=1]
[free time=1]
[WAIT time=1]
[transition target={false} rule="162.png" color={0x000000ff} time=1]

[WAIT time=1]


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_l_1f_tbr_p4.ui" time=1]
;//【ＢＧ】図書館・１階・専門書の部屋　夜（暗／蝋燭／机に大量の本）******************************************************

[WAIT time=1]
[transition target={false} rule="ue.webp" color={0x000000ff} time=2000]
[WAIT time=3000]
[window target=true]


Since it was a big place, it took half a day to clean.
[cpg]

Exhausted, we ate porridge packages, which now seemed like a luxury, and quickly went to our own beds.
[cpg]

[OnName num="Kenji"]
"Oh..., I didn't do this yet..."
[cpg cn=true]

On the desk in the special reference book room, there was a pile of books that Hosokawa had probably left out.
[cpg]

[OnName num="Kenji"]
"What has he reading all this for...?"
[cpg cn=true]

I traced the spines of the piles of books with my eyes...
[cpg]

I read "Pharmacology", "Psychiatry", "Brain Science Approaches to Mental Illness", "The Future of Cardiovascular Therapy", "Clinical Respiratory Diseases", etc...
[cpg]


[OnName num="Kenji"]
"Ahhhh..."
[cpg cn=true]

I don't want to speak ill of the dead, but what the hell did Hosokawa want to be a doctor of?
[cpg]

I looked at the books and I saw that they are all in different fields, even though they were all in the medical field.
[cpg]

It was no use thinking about it.
[cpg]

;//このまま『ルートＢ』へ進行

[stopse g=1]
;//ボイス
[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

;//[jump target="*root_b"]
[jump storage="ep015.ks" target="*start"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～


