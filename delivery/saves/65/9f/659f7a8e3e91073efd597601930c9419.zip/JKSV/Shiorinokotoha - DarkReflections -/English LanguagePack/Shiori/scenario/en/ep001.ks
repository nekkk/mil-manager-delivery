*start
;#################################################
*Ep001|That Girl in the Library
;#################################################
[SCENE id=1]

;//＠タイプライター音の共に表示
[SE f="se135"]
;//【ＳＥ】『タイプライター』
[window target=true]

December 9th
[cpg]
[window target=false]


[SE f="se001" loop=true]
;//【ＳＥ】バスの走行
;//ループ

[WAIT time=3000]

[window target=true]


[OnName num="Kenji"]
"Hmm...huh?"
[cpg cn=true]

While enjoying the gentle rumbling of the bus, I opened my eyes and noticed that the view out the window was different from usual. 
[cpg]

[OnName num="Kenji"]
"Where is...? This place?"
[cpg cn=true]

I looked around the bus, and for some reason I was the only passenger.
[cpg]

[OnName num="Kenji"]
"Excuse me! Are we at Yaeto Academy yet?"
[cpg cn=true]

I asked the driver, and he answered curtly, looking ahead.
[cpg]

[OnName num="運転士"]
"We passed it a long time ago."
[cpg cn=true]

[OnName num="Kenji"]
"Whatー?!"
[cpg cn=true]

Oh, man...
[cpg]

I took out my phone to check the time, but I was already late for school.
[cpg]

I should get off at the next stop and find a bus that’ll take me back.
[cpg]

Or should I just skip school today?
[cpg]

As I was considering my options, the driver's voice over the microphone echoed through the empty bus.
[cpg]

[OnName num="運転士"]
"Yaeto Shrine. Yaeto Shrine."
[cpg cn=true]

[OnName num="Kenji"]
"Yaeto Shrine?"
[cpg cn=true]

I'd never heard of such a stop and was stunned at how long I'd been asleep.
[cpg]

[stopse g=6]
[WAIT time=1]
;//ループ停止

[SE f="se002"]
;//【ＳＥ】バスのドア開く


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=3000]
[BG f="b_o_iw_p2.ui" time=1000]
;//【ＢＧ】その他・森の中　昼******************************************************
[WAIT time=2000]

[BGM f="silent"]


[OnName num="Kenji"]
"Where is this...place?"
[cpg cn=true]

It was good to get off the bus anyway, but the whole area was so unfamiliar.
[cpg]

I had never imagined that there was such a place in my city.
[cpg]

I didn't think it was such a large city, but the bus driving along the dirt road made me feel like I was in the middle of nowhere.
[cpg]

I was mildly shocked to see a bus stop for the opposite direction just across the street.
[cpg]

I sprinted to it and checked the timetable...
[cpg]

[OnName num="Kenji"]
"Geez! Seriously?"
[cpg cn=true]

The bus wouldn't be coming for another 40 minutes.
[cpg]

You've got to be kidding me.
[cpg]

That's it, I'm ditching.
[cpg]

Since I made up my mind, I felt like exploring this unfamiliar scenic spot.
[cpg]

The name of the stop was "Yaeto Shrine", so there must be a shrine around here.
[cpg]

I started looking around for Yaeto Shrine.
[cpg]

[OnName num="Kenji"]
"This can't be...it, right?"
[cpg cn=true]

It was a run-down building that looked more like a life-size miniature street shrine than the beautiful shrines I’m used to.
[cpg]

Honestly, I'm not sure anyone would come to this place to worship.
[cpg]

I was planning to kill some time by drawing a fortune, but this was a bust.
[cpg]

[OnName num="Kenji"]
"What to do...?"
[cpg cn=true]

I was surrounded by green trees no matter which way I turned.
[cpg]

I was at my wit’s end, and then...
[cpg]

[SE f="se003"]
;//【ＳＥ】ガサガサッ

[WAIT time=2000]

[OnName num="Kenji"]
"?!"
[cpg cn=true]

[SE f="se004"]
;//【ＳＥ】ヒョイッ

[WAIT time=1000]


[OnName num="Kenji"]
"A ra, raccoon dog!? A raccoon!?"
[cpg cn=true]

I was surprised to see an unidentified creature peeking out from the bushes, but then it got startled and immediately ran back into the bushes.
[cpg]

[OnName num="Kenji"]
"Oh, hey, wait!"
[cpg cn=true]

I thought I'd take a picture, so I took out my phone and followed the critter into the bushes.
[cpg]

I couldn't miss something so rare.
[cpg]

[SE f="se003"]
;//【ＳＥ】ガサガサガサ

[WAIT time=2000]


But of course, there was no way I could catch up with the wild beast, and suddenly I was left all alone in the bushes.
[cpg]

[OnName num="Kenji"]
"Ohhhh..."
[cpg cn=true]

I put my phone back in my pocket and sighed.
[cpg]

I looked down at my feet and saw a few small red berries rain down from the trees.
[cpg]

Perhaps that beast had come out to gather food before hibernation?
[cpg]

[OnName num="Kenji"]
"Do raccoon dogs even eat berries?..."
[cpg cn=true]

Thinking about such stupid stuff, I turned back towards the bushes I came from...or so I thought...
[cpg]

[OnName num="Kenji"]
"What the...?"
[cpg cn=true]

There's no path...
[cpg]

Come to think of it, I couldn't see anything that even looked like a path.
[cpg]

Before I knew it, I had lost my sense of direction in the bushes and started going the wrong way.
[cpg]

[OnName num="Kenji"]
“It's not a good idea to get lost out here…”
[cpg cn=true]

Frustrated, I knew I had to start walking anyway.
[cpg]

And how long did I wander?
[cpg]

Even in the slightly chilly air of early autumn, my neck and back started to sweat and then...
[cpg]

[SE f="se003"]
;//【ＳＥ】ガサガサ

[WAIT time=2000]


[OnName num="Kenji"]
"?!"
[cpg cn=true]



[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_ex_app_p2.ui" time=1000]
;//【ＢＧ】図書館・その他・朱鷺田図書館　外観　昼******************************************************

[WAIT time=2000]

Suddenly, a large European-style building appeared through the deep forest.
[cpg]

I thought I had been bewitched by a raccoon dog.
[cpg]

That's how abruptly the impressive structure appeared.
[cpg]

At first I thought it was some rich guy's villa, but there was an elegant wooden sign on the stone gatepost that read "Tokita Library ".
[cpg]

I patted my chest, relieved to know that it was a place where I would not be in trouble for entering.
[cpg]

[OnName num="Kenji"]
"Too...Tukita...How do you pronounce that?"
[cpg cn=true]

[SE f="se005"]
;//【ＳＥ】重たいドアを開ける

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=2000]


[OnName num="Kenji"]
"...Ugh."
[cpg cn=true]


[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=2000]

[BGM f="library"]


I open the door and look inside and it looked like a European castle just like in the movies.
[cpg]

The red carpet that laid out in front of me stretched straight up to the stairs, and two armored figures stood across the stairs holding spears.
[cpg]

Part of the vaulted ceiling was a skylight, and the light pouring down from it created an absolutely fantastic scene.
[cpg]

[OnName num="Kenji"]
"It's a library..., right?"
[cpg cn=true]

As I fearlessly entered, I was relieved to see that there were large doors on either side of the entrance, with many bookshelves behind them.
[cpg]

[SE f="se006"]
;//【ＳＥ】革靴の踵が大理石に（カツンッ）

[OnName num="Kenji"]
"Oops..."
[cpg cn=true]

When I stepped off of the red carpet, I was greeted by a slippery stone floor, and the sound of my shoes echoed in the quiet space.
[cpg]

Still there was no sign of anyone coming out of the rooms on either side.
[cpg]

I decided to go into the room on the right, with an unnecessary sense of urgency.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（電灯）******************************************************

[WAIT time=1500]


[OnName num="Kenji"]
"There's no one...here."
[cpg cn=true]

The bookshelves were lined up and evenly spaced like giant dominoes.
[cpg]

But in the meantime there was no one in sight.
[cpg]

And there was no one at the desk or anywhere else.
[cpg]

[OnName num="Kenji"]
“Umｍ...excuse me~...”
[cpg cn=true]

I finally shouted louder, thinking that I wouldn't be a bother if there was no one around reading.
[cpg]

;//？？？
[VOICE f="Shiori001"]
[OnName num="unknown"]
"Shh..."
[cpg cn=true]

[OnName num="Kenji"]
"!"
[cpg cn=true]

I heard a cold, reproachful breath behind me and turned in surprise…
[cpg]

[free time=1000]
;**【ＣＧ】ev_13_0 ***********************
[CG id=12 index=0 time=1000]
;*****************************************
[WAIT time=1500]

;//？？？

[VOICE f="Shiori002"]
[OnName num="unknown"]
"..............."
[cpg cn=true]

A girl was standing there, staring at me blankly.
[cpg]

[OnName num="Kenji"]
"....Oh, um."
[cpg cn=true]

For a moment, I almost lost myself in her eyes that seemed to suck me in, but I spoke up again to make myself seem less suspicious…
[cpg]

;//？？？
[VOICE f="Shiori003"]
[OnName num="unknown"]
"..............."
[cpg cn=true]

[SE f="se007"]
;//【ＳＥ】チラシを差し出す（ペラッ）

[OnName num="Kenji"]
"What...?"
[cpg cn=true]


[BG f="b_l_1f_nbr_p2.ui" time=1000]
[WAIT time=1500]

The girl held out a piece of paper, which I took without a second thought, and walked noiselessly toward the counter.
[cpg]

[OnName num="Kenji"]
"What the hell is this...?"
[cpg cn=true]

When I took a look at the paper in my hand, I found the "Rules of the Tokita Library" written on it. 
[cpg]

It said...
[cpg]

・Please leave mobile phones or watches with alarms at the counter.
[cpg]

・Please handle the books with clean hands.
[cpg]

・The library does not lend out books.
[cpg]

・No food or drink is allowed in the library.
[cpg]

[OnName num="Kenji"]
"Leave your cell phone?! We don't lend out books at the....library!?"
[cpg cn=true]

;//？？？
[FG f="CHA01_p3_01_a.ui" method="change_3" pos="2/3" time=1000]
[WAIT time=100]
[VOICE f="Shiori004"]
[OnName num="unknown"]
"..............."
[cpg cn=true]

The girl sitting at the counter glared at me when I raised my voice in a curt manner.
[cpg]

[OnName num="Kenji"]
“S-sorry…”
[cpg cn=true]

It’s intimidating when a beautiful girl has a scary expression on her face, so I shrunk back and proceeded quietly to the counter.
[cpg]

[OnName num="Kenji"]
"Hey...I'm lost. Can you please just tell me how to get to the bus stop?"
[cpg cn=true]

;//？？？
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori005"]
[OnName num="unknown"]
"................"
[cpg cn=true]

As she looked up at me from where she was sitting, I couldn’t help but feel nervous seeing her face.
[cpg]

What a beautiful girl...
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]

Clear white skin.
[cpg]


Big eyes with long eyelashes.
[cpg]

Thin lips with a glossy shine.
[cpg]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]

I was so speechless and dumbfounded by her appearance, I would believe it if someone told me she was actually a doll.
[cpg]

[SE f="se008"]
;//【ＳＥ】チンベル（チーン！）

[OnName num="Kenji"]
"Uhh..."
[cpg cn=true]

;//？？？
[VOICE f="Shiori006"]
[OnName num="unknown"]
"..............."
[cpg cn=true]


Suddenly, the girl's hand rang the bell on the counter, startling me enough to make me jump, but soon after, the door behind her opened and…
[cpg]

[SE f="se009"]
;//【ＳＥ】ドア開く



[free time=1000]
;**【ＣＧ】ev_01_0 ***********************
[CG id=00 index=0 time=1000]
;*****************************************
;//？？？
[WAIT time=1500]
[VOICE f="Michi001"]
[OnName num="unknown"]
"Yes, what is it?"
[cpg cn=true]

From inside, a woman in a white coat emerged.
[cpg]

Unlike the girl who didn't say a word, the fact that this person saw me and called out to me made me feel less nervous.
[cpg]

[OnName num="Kenji"]
"Oh, thank God..."
[cpg cn=true]

;//？？？
[WAIT time=100]
[VOICE f="Michi002"]
[OnName num="unknown"]
"I'm sorry. Am I being rude?"
[cpg cn=true]

[OnName num="Kenji"]
"No, not rude..."
[cpg cn=true]


I glanced at the girl, but she ignored me and resumed writing something in her notebook.
[cpg]

[OnName num="Kenji"]
"Well, you see...I'm a little lost and I was wondering if you could tell me how to get to the bus stop..."
[cpg cn=true]

I repeated myself to the woman in the white coat who seemed to understand what I was saying.
[cpg]



;//？？？
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="4/5" time=1000]
[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/5" time=1000]
[BG f="b_l_1f_nbr_p2.ui" time=1000]
[WAIT time=1500]


[VOICE f="Michi003"]
[OnName num="unknown"]
"You got lost and ended up here?"
[cpg cn=true]

The woman looked at me suspiciously.
[cpg]

A different type of beauty from the girl at the counter.
[cpg]

I wonder if the white coat is what gave her a cool vibe.
[cpg]

[OnName num="Kenji"]
"This is a...library, isn't it?"
[cpg cn=true]

;//？？？
[WAIT time=100]
[VOICE f="Michi004"]
[OnName num="unknown"]
"'I guess you could say that..."
[cpg cn=true]

I guess you could say that?
[cpg]

What was with this atmosphere…
[cpg]

Like they didn't want any visitors.
[cpg]

Even though it was a library...
[cpg]

Perhaps realizing my suspicions, the woman quickly gave me directions.
[cpg]

;//？？？
[WAIT time=100]
[VOICE f="Michi005"]
[OnName num="unknown"]
"How and from where did you get lost? There's a minor path right outside the gate, go down it and you'll see the bus stop.”
[cpg cn=true]

[OnName num="Kenji"]
"What, Mi...?!"
[cpg cn=true]

;//？？？
[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi006"]
[OnName num="unknown"]
“...hehe”
[cpg cn=true]

[OnName num="Kenji"]
"Huh?"
[cpg cn=true]

I just couldn't believe I hadn't noticed the path and then the woman in white spoke to me again with a small smile.
[cpg]

;//？？？
[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi007"]
[OnName num="unknown"]
"I'm sorry about that. I didn't mean to laugh. I thought you were calling me by name. I'm Michi, Michi Kisaragi."
[cpg cn=true]

[OnName num="Kenji"]
"O-oh...is that so? I'm sorry. My name is Kenji Azuma.”
[cpg cn=true]

[WAIT time=100]
[VOICE f="Michi008"]
[OnName num="Michi"]
"Is that uniform from Yaeto Academy? Is it a school holiday today?"
[cpg cn=true]

[OnName num="Kenji"]
"Uh..."
[cpg cn=true]

I thought I'd been caught ditching.
[cpg]

I don't believe it, she was going to tell the school, wasn’t she...
[cpg]

[OnName num="Kenji"]
“No, it's not. I dozed off on the bus on my way to school and ended up here...I-I’m so sorry.”
[cpg cn=true]

The more I spoke, the more I felt like I was digging my own grave, so I finally shut up.
[cpg]

But Ms. Kisaragi didn't seem fazed at all.
[cpg]

[WAIT time=100]
[VOICE f="Michi009"]
[OnName num="Michi"]
"I don't care whether you go home or read a book."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, I see... Well then, might as well stay a little…”
[cpg cn=true]

I felt kind of bad to just walk away, so I decided to pick up a book that I wasn't even interested in.
[cpg]

[OnName num="Kenji"]
“Um..., is there a fee for reading?"
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi010"]
[OnName num="Michi"]
"It's free. It is a normal library."
[cpg cn=true]

[OnName num="Kenji"]
"Oh..."
[cpg cn=true]

I don't think this is normal, but I've never been to a library before, so I didn't know the usual system.
[cpg]

[SE f="se010"]
;//【ＳＥ】椅子をずらす

;//背景戻す


;//？？？
[VOICE f="Shiori007"]
[OnName num="unknown"]
"..............."
[cpg cn=true]

The girl, who had stayed silent, held out a small basket to me.
[cpg]

[OnName num="Kenji"]
"???"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi011"]
[OnName num="Michi"]
"Oh, and if you're going to read a book, you'll need to put your phone or anything that makes noise in this basket. That's the rule."
[cpg cn=true]

[OnName num="Kenji"]
"Ah, yes..."
[cpg cn=true]

I took my phone out of my pocket and put it in the basket, then the girl gave me a numbered tag in return.
[cpg]

Since she was so silent, I had wondered if she was...unable to speak.
[cpg]

Then Ms. Kisaragi let out a sigh and scolded the girl.
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi012"]
[OnName num="Michi"]
“You're a guest, she should at least greet you. My apologies.”
[cpg cn=true]

Ms. Kisaragi was mid speech when the girl finally opened her mouth.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori008"]
[OnName num="Shiori"]
"Shiori...Tokita"
[cpg cn=true]

[OnName num="Kenji"]
"Tokita..."
[cpg cn=true]

Thin and tall.
[cpg]

Her voice was small, but it had a clarity that rang in my ears.
[cpg]

She had a beautiful voice that fit her beautiful face.
[cpg]

When I started blushing, Shiori turned her face away and went back to work again.
[cpg]

At that moment, I felt...disappointed.
[cpg]

The desire to talk to her some more was building up in my chest.
[cpg]

As I felt my face burning, Ms. Kisaragi stood between Shiori and me.
[cpg]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi013"]
[OnName num="Michi"]
"Did you read the sign out front? What an unusual last name, right?”
[cpg cn=true]

[OnName num="Kenji"]
"Oh, so it is 'Tokita'? I couldn't read it."
[cpg cn=true]

That was the first time I understood how to read the name of the library.
[cpg]

And when I also understood that Shiori's last name was that "Tokita".
[cpg]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi014"]
[OnName num="Michi"]
“She's...very shy. If you need anything other than books, just let me know and I'll be happy to help."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, okay..."
[cpg cn=true]


[SE f="se011"]
;//【ＳＥ】スマホ着メロ

[WAIT time=1000]


[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori009"]
[OnName num="Shiori"]
"......!"
[cpg cn=true]

[OnName num="Kenji"]
"Oh, sorry!"
[cpg cn=true]

There was an incoming call on the phone I had left with her, and Shiori jolted and rushed to go get it.
[cpg]

[OnName num="Kenji"]
“I'll turn it off right away!”
[cpg cn=true]

[move from="2/5" to="1/5" ease="easeInOutSine" time=800]
[WAIT time=100]
[VOICE f="Shiori010"]
[OnName num="Shiori"]
"What?"
[cpg cn=true]

Going for the phone, I slightly brushed my hand against Shiori's hand and she quickly backed away.
[cpg]

[OnName num="Kenji"]
“You don't have to be so frightened…”
[cpg cn=true]

[SE f="se012"]
;//【ＳＥ】スマホ切る

[WAIT time=1000]


I was more than a little shocked at how much she was taken aback, and my shoulders slumped.
[cpg]

[FACE method="change_1" pos="1/5"]

[WAIT time=100]

.........
[cpg]

[move from="1/5" to="5/3" ease="easeInOutSine" time=2000]

But Shiori just sat back down at the counter without saying a word, clutching the hand I had touched to her chest.
[cpg]

[OnName num="Kenji"]
".................."
[cpg cn=true]

Her hands were so cold...
[cpg]

This girl is actually a doll after all, isn't she?
[cpg]

That raccoon dog did something to me after all, right?
[cpg]

That's what it felt like.
[cpg]

That's how unbelievable she was.
[cpg]

The hustle and bustle of the real world as we knew it felt so far away.
[cpg]

;//ブラックアウト
[free time=400]
[WAIT time=400]
[STOPBGM]
[BG f="black.ui" time=900]
[WAIT time=2500]

;//＠タイプライター音の共に表示
[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 10th
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BGM f="dol"]
[BG f="b_o_sr_p2.ui" time=1000]
;//【ＢＧ】その他・八重戸学園・教室　昼******************************************************


[SE f="se013"]
;//【ＳＥ】休み時間の喧噪
[OnName num="Kenji"]
"Phew~"
[cpg cn=true]

Remembering what happened at the library yesterday, I let out a deep, deep sigh.
[cpg]

No matter how hard I try, was I doomed to never get along with Shiori?
[cpg]

Is it true that first love is never reciprocated…?
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika002"]
[OnName num="Erika"]
“What’s with the sighing? That's dark."
[cpg cn=true]

My classmate, Erika Kimishima, was the one who was mocking me.
[cpg]

She's a bit of a pain in the neck, always trying to get involved in everyone's business.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika003"]
[OnName num="Erika"]
"You're probably thinking about your final exam, right? Don't worry, I haven't studied at all either."
[cpg cn=true]

I didn't understand what she meant by "don't worry".
[cpg]

But then I remembered that there was a final exam in about a week…
[cpg]

[OnName num="Kenji"]
“What does the test cover again?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika004"]
[OnName num="Erika"]
"How would I know? Do you know, Yuna ?"
[cpg cn=true]

[move from="2/3" to="2/5" ease="easeInOutSine" time=1000]


[FG f="CHA04_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yuna002"]
[OnName num="Yuna"]
Yeah.
[cpg cn=true]

The girl who had been behind Erika stepped forward quietly.
[cpg]

Her name is Yuna Shiraki.
[cpg]

Apparently, they have known each other since they were in elementary school.
[cpg]


[VOICE f="Yuna003"]
[OnName num="Yuna"]
"Modern Japanese starting from page 25. Math starting from page 20. History starts from the Azuchi-Momoyama period and…"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika005"]
[OnName num="Erika"]
"What era is Azuti-Momoyama?"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna004"]
[OnName num="Yuna"]
"It's..."
[cpg cn=true]

[OnName num="Kenji"]
"You're an idiot. Even I know that."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika006"]
[OnName num="Erika"]
"Huh? Kenji, you're amazing. PE isn't the only subject you're good at?"
[cpg cn=true]

[OnName num="Kenji"]
"What's that?"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika007"]
[OnName num="Erika"]
“I mean, you're in such high remand with all the sports teams!”
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna005"]
[OnName num="Yuna"]
"High demand..."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika008"]
[OnName num="Erika"]
“Being asked to join the rugby team, the baseball team, the soccer team...and turning them all down~”
[cpg cn=true]

[VOICE f="Erika1008"]
[OnName num="Erika"]
“That's kind of cool, isn't it? You're like a lone wolf, like an outlaw."
[cpg cn=true]

Erika and Yuna are polar opposites.
[cpg]

Erika is a fashion-forward girl who alters her uniform without any regard for the dress code.
[cpg]

She is cheerful, but has strong and agressive personality.
[cpg]

On the other hand, Yuna is the quiet and unassuming type who studies hard every day.
[cpg]

It’s a wonder how they even became friends.
[cpg]

[OnName num="Kenji"]
"As for me, I'm pretty sure Erika will fail everything."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika009"]
[OnName num="Erika"]
"That's not true. Yuna's going to help me study what's on the test and lend me her notes. Right?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna006"]
[OnName num="Yuna"]
"Uh, yeah..."
[cpg cn=true]

Not paying attention to Yuna's forced smile, Erika leaned forward to talk to me.
[cpg]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika010"]
[OnName num="Erika"]
"Why don't you study with us, Kenji? Yuna can always predict what’s going to come up on the test, trust me~"
[cpg cn=true]

[OnName num="Kenji"]
"I'll pass...I'm going to study at the library."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna007"]
[OnName num="Yuna"]
"Is that so?"
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika011"]
[OnName num="Erika"]
"Kenji?! At the library?!"
[cpg cn=true]

Erika shrieked in a high-pitched voice that made my ears ring.
[cpg]

[OnName num="Kenji"]
"What's wrong? Is it wrong for me to go to the library?"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika012"]
[OnName num="Erika"]
"It's not wrong, but it's not like you to go to a library...I can't believe it!"
[cpg cn=true]

Well, I wouldn't have believed it either.
[cpg]

Personally, the library is a better place to study than school…at least that’s what I was telling myself.
[cpg]

And if I study at Tokita Library, Michi can help me with the parts I don't understand, and I can enjoy looking at Shiori, so that’s killing two birds with one stone.
[cpg]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika013"]
[OnName num="Erika"]
"Just to make sure, it's not like a gym named Lie-brary, is it?"
[cpg cn=true]

[OnName num="Kenji"]
"What kind of name is that...?"
[cpg cn=true]

I wonder how Erika's mind works.
[cpg]

She should use this peculiar brain of hers to become a comedian or something.
[cpg]

[OnName num="女子学生１"]
"Were you just talking about going to the library?"
[cpg cn=true]

[OnName num="女子学生２"]
"Azuma, are you going to study at the library? If that's the case, I might as well join you."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika014"]
[OnName num="Erika"]
"Um..."
[cpg cn=true]

The other girls, hearing Erika's loud voice, joined in on our conversation.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika015"]
[OnName num="Erika"]
"No, not with you guys! You'll just distract Kenji."
[cpg cn=true]

[OnName num="女子学生１"]
"Oh, come on, that's not true!
[cpg cn=true]

[OnName num="女子学生２"]
"We're just going to study quietly."
[cpg cn=true]


[VOICE f="Erika016"]
[OnName num="Erika"]
"Anyway, no means noooooo!"
[cpg cn=true]

Erika dragged the other girls away from the conversation and started compaining about something.
[cpg]

Yuna, who had been observing quietly the whole time, whispered to me with a small sigh.
[cpg]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna008"]
[OnName num="Yuna"]
“Erika's just jealous.”
[cpg cn=true]

[OnName num="Kenji"]
"Huh?"
[cpg cn=true]

I pretended not to notice, but I was aware of Erika's feelings.
[cpg]

She always comes on so strong.
[cpg]

She gave me chocolate for Valentine's Day and got me presents for my birthday and Christmas.
[cpg]

But…, unfortunately I don't see Erika that way.
[cpg]

She is cheerful, lively, and not a bad person, but I could never  imagine her as a…girlfriend.
[cpg]

Up until now, I just thought Erika was annoying, but after I started having feelings for Shiori, I felt kind of sorry for her.
[cpg]

I'd like to stay together as long as possible.
[cpg]

Not in a romantic way, of course, but as friends…
[cpg]

;//ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]


[stopse g=2]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="ep002.ks" target="*start"]


