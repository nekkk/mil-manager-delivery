*start

;#################################################
*Ep003|Shadows in Motion
;#################################################
[SCENE id=3]

;//タイプライター音

[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 16th
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（電灯）******************************************************

[BGM f="library"]
[WAIT time=1500]

Erika called me up in the morning and invited me to the library, like she declared she would do yesterday.
[cpg]

Somehow, Yuna, who works part-time at the library, and I both got entangled with Michi.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika084"]
[OnName num="Erika"]
"And that's why... Michi!"
[cpg cn=true]

[VOICE f="Michi025"]
[OnName num="Michi"]
"Ah...yes..."
[cpg cn=true]

It seems that "Operation Become Friends" is in full swing, but Michi is not a library employee.
[cpg]

In addition to that, Michi didn't seem to be interested in talking to Erika at all.
[cpg]

[VOICE f="Yuna044"]
[OnName num="Yuna"]
"I feel like...We're bothering her..."
[cpg cn=true]

[OnName num="Kenji"]
"I feel guilty..."
[cpg cn=true]

Sighing in frustration, Yuna regained her composure and turned to me.
[cpg]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna045"]
[OnName num="Yuna"]
"By the way, Kenji. If you're looking for something to read, you should have a look at the recommended books section.”
[cpg cn=true]

[OnName num="Kenji"]
"Oh, you have one of those sections?"
[cpg cn=true]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna046"]
[OnName num="Yuna"]
"Yeah, it's on the bookshelf by the counter."
[cpg cn=true]

[OnName num="Kenji"]
"Thanks. I'll take a look."
[cpg cn=true]

[free time=400]

So I left my seat to choose a book, and Yuna went back to organizing the books.
[cpg]

;//本棚
;//【ＢＧ】図書館・その他・本棚の間　昼（電灯）
[OnName num="Kenji"]
"Which section is it? This month's recommendations are..."
[cpg cn=true]

On the bookshelf that Yuna mentioned, there were several books lined up on a shelf at eye level with their covers visible.
[cpg]

Unlike bookstores, they don't need to push bestsellers, so I was curious to see what their standards were.
[cpg]

"An Evening of Lamenting the Dead"
"Kokoro Kororon"
"Walking in Space"
"Wives in Silent Prayer"
"Here's a Statue"
[OnName num="Kenji"]
"Ummm..."
[cpg cn=true]

It was a mix of different genres and a bunch of titles I've never heard of.
[cpg]

It might just be that I didn't know much about books, but I didn't know which one I wanted to read even from that selection.
[cpg]

At any rate, I picked up a suitable book and returned to my seat.
[cpg]

;//＠机

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BGM f="d1"]
[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（電灯）******************************************************

[WAIT time=1000]

[FG f="CHA03_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika085"]
[OnName num="Erika"]
"Ehehe ♪"
[cpg cn=true]

[OnName num="Kenji"]
"W-what is it?"
[cpg cn=true]

As soon as I took my seat, a grinning Erika sat down in the chair beside me.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika086"]
[OnName num="Erika"]
"You know, I think this library is pretty great."
[cpg cn=true]

[OnName num="Kenji"]
"What's so great about it?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika087"]
[OnName num="Erika"]
"They even have a basement!"
[cpg cn=true]

[OnName num="Kenji"]
"Hmm."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika088"]
[OnName num="Erika"]
"Also, that armor on the stairs has actually been worn by someone!"
[cpg cn=true]

[OnName num="Kenji"]
"Who's that?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika089"]
[OnName num="Erika"]
"I don't know who. A soldier?"
[cpg cn=true]

[OnName num="Kenji"]
"..............."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika090"]
[OnName num="Erika"]
"Isn't it amazing?! It looks like it's worth millions!"
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, it's amazing. What are you going to do with that information?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika091"]
[OnName num="Erika"]
"Nothing really. Just idle curiosity."
[cpg cn=true]

[OnName num="Kenji"]
"Huh..."
[cpg cn=true]

I wondered if this was like when gossips watch entertainment news...
[cpg]

When it has nothing to do with you, but you’re just dying to know.
[cpg]

That feeling was hard for me to understand.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika092"]
[OnName num="Erika"]
“And that treasure room! It seems to contain a bunch of treasure that people from the museum sometimes come to borrow!"
[cpg cn=true]

[OnName num="Kenji"]
"Hmm."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika093"]
[OnName num="Erika"]
"What do you think is in there Kenji? A diamond the size of a softball? Or a golden toilet bowl?"
[cpg cn=true]

[OnName num="Kenji"]
"You know… You say all that, but you have no idea what’s in there, do you?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika094"]
[OnName num="Erika"]
"Because Michi left in the middle of our conversation."
[cpg cn=true]

More like she ran away.
[cpg]

[OnName num="Kenji"]
"Let's cut the chit-chat..."
[cpg cn=true]

[STOPBGM]

[VOICE f="Shiori016"]
[OnName num="Shiori"]
"What are you up to...?!"
[cpg cn=true]

As I opened my mouth to scold Erika, a tremendous shout rang out from somewhere.
[cpg]

Erika and I went over to where the voice came from to see what was going on.
[cpg]

;//本棚の間（床に膝と手を付く柚那。辺りに本が散らばっている）


[window target=false]
[transition target={true} rule="101.jpg" color={0x000000ff} time=2000]
[WAIT time=2000]

[free time=1]
[WAIT time=100]

[FG f="CHA01_p3_01_a.ui" method="change_3" pos="2/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="4/5" time=1]
[WAIT time=100]

[transition target={false} rule="101.jpg" color={0x000000ff} time=2000]
[WAIT time=2500]
[window target=true]

[BGM f="huan"]


[VOICE f="Yuna047"]
[OnName num="Yuna"]
"Sorry!"
[cpg cn=true]


[VOICE f="Shiori017"]
[OnName num="Shiori"]
"Sorry won't cut it...! Oh, my God..."
[cpg cn=true]

There was Yuna crawling on the book-strewn floor, and Shiori trembling with anger.
[cpg]

Shiori's eyes peeled open, and her face was tinged with a look of anger that I had never seen or even imagined before.
[cpg]

[VOICE f="Yuna048"]
[OnName num="Yuna"]
"My hand just slipped."
[cpg cn=true]

[VOICE f="Shiori018"]
[OnName num="Shiori"]
"Just slipped?! Don't be ridiculous...my precious book is...!"
[cpg cn=true]

I looked and saw that the cover of one of the old books had been torn off completely.
[cpg]

[OnName num="Kenji"]
"Wait, what happened here?"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna049"]
[OnName num="Yuna"]
"As I was putting the books away, one almost fell out of my hands… I quickly grabbed it by the cover and it tore…and I truly am very sorry!"
[cpg cn=true]


[VOICE f="Shiori019"]
[OnName num="Shiori"]
"This is unforgivable...! An apology won't fix it …!"
[cpg cn=true]

[OnName num="Kenji"]
"Wait, calm down!"
[cpg cn=true]

;//【ＢＧ】図書館・その他・本棚の間　昼（電灯）

;//[free time=900]
;//[BG f="black.ui" time=900]
;//[WAIT time=1500]
;//[BGM f="d1"]
;//[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（エントランスからの光）******************************************************


It wasn't too difficult to stop Shiori from grabbing hold of Yuna.
[cpg]

The small and weak Shiori struggled in my arms.
[cpg]

;//[FG f="CHA01_p3_01_a.ui" method="change_3" pos="2/5" time=800]
;//[FG f="CHA04_p3_01_a.ui" method="change_4" pos="4/5" time=800]
;//[WAIT time=100]
[VOICE f="Yuna050"]
[OnName num="Yuna"]
"I'm sorry! I'll pay for the damage."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

[VOICE f="Shiori020"]
[OnName num="Shiori"]
"It's not about the money... That priceless book was something my grandfather bought for me...! That book, that book...!"
[cpg cn=true]

That book must have been very important for the normally quiet Shiori to get so angry.
[cpg]

Anyone could tell how much Shiori loved her late grandfather and his books.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="5/3" time=800]

However, Erika, who failed to read the room, was upset.
[cpg]
[move from="2/5" to="1/3" ease="easeInOutSine" time=1000]
[move from="4/5" to="2/3" ease="easeInOutSine" time=1000]
[move from="5/3" to="3/3" ease="easeInOutSine" time=1000]
[WAIT time=100]
[VOICE f="Erika095"]
[OnName num="Erika"]
"What?! You don't have to get so angry, it's just a book!"
[cpg cn=true]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori021"]
[OnName num="Shiori"]
"Just a book...?!"
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika096"]
[OnName num="Erika"]
"Yuna has apologized and offered to pay for it, right? You're too rich to be acting this petty!"
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori022"]
[OnName num="Shiori"]
“Wha…, ugh! Cough! C...cough!”
[cpg cn=true]

[OnName num="Kenji"]
"What's wrong?"
[cpg cn=true]

Suddenly, Shiori crouched down, holding her chest.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="5/3" time=800]
[WAIT time=100]
[VOICE f="Michi026"]
[OnName num="Michi"]
"Shiori! Are you okay?!"
[cpg cn=true]
;//＠
[move from="2/3" to="4/5" ease="easeInOutSine" time=1500]
[move from="3/3" to="5/5" ease="easeInOutSine" time=1500]
[move from="5/3" to="2/4" ease="easeInOutSine" time=1500]

[SE f="se022"]
;//【ＳＥ】走ってくる

[WAIT time=1500]


Michi, who had come over to hear the commotion, ran up to Shiori.
[cpg]

[FACE method="change_7" pos="2/4"]
[WAIT time=100]
[VOICE f="Michi027"]
[OnName num="Michi"]
"Hush..., stay calm... Breathe slowly..."
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori023"]
[OnName num="Shiori"]
"U-uh......, ugh...uh..."
[cpg cn=true]

Michi held Shiori in a hug and rubbed her back slowly while looking up at us.
[cpg]

[FACE method="change_3" pos="2/4"]
[WAIT time=100]
[VOICE f="Michi028"]
[OnName num="Michi"]
"What in the world...happened?"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna051"]
[OnName num="Yuna"]
"I'm sorry...I was careless and I ripped a book..."
[cpg cn=true]

[FACE method="change_4" pos="2/4"]
[WAIT time=100]
[VOICE f="Michi029"]
[OnName num="Michi"]
"I see..."
[cpg cn=true]

[FACE method="change_3" pos="5/5"]
[WAIT time=100]
[VOICE f="Erika097"]
[OnName num="Erika"]
"But, she was also in the wrong! She got so worked up, even after apologizing!"
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori024"]
[OnName num="Shiori"]
"...ugh, cough, cough!"
[cpg cn=true]

[FACE method="change_3" pos="2/4"]
[WAIT time=100]
[VOICE f="Michi030"]
[OnName num="Michi"]
"Don't provoke Shiori any further!"
[cpg cn=true]

[FACE method="change_7" pos="2/4"]

The force of Michi's words made even Erika unable to say anything else.
[cpg]

[FACE method="change_7" pos="2/4"]
[WAIT time=100]
[VOICE f="Michi031"]
[OnName num="Michi"]
"Yuna, don't worry about the book anymore. Just be careful next time."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna052"]
[OnName num="Yuna"]
"Okay... I'm sorry..."
[cpg cn=true]

At that moment, I was just stunned, and I just stood there like a statue.
[cpg]

I wonder if the Shiori just now was the same Shiori from earlier.
[cpg]

I can't believe she could get so angry and raise her voice that loud.
[cpg]

[FACE method="change_1" pos="2/4"]
[WAIT time=100]
[VOICE f="Michi032"]
[OnName num="Michi"]
"Shiori, let's go. You need to take your medicine..."
[cpg cn=true]

[OnName num="Kenji"]
"O-oh! Is she all right...?"
[cpg cn=true]

[FACE method="change_1" pos="2/4"]
[WAIT time=100]
[VOICE f="Michi033"]
[OnName num="Michi"]
"Yes, she's fine. She'll be better soon. I'm sorry for all the commotion."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="1/3" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/4" time=1]


[OnName num="Kenji"]
"No..."
[cpg cn=true]

[move from="1/3" to="5/3" ease="easeInOutSine" time=2000]
[move from="2/4" to="6/3" ease="easeInOutSine" time=2000]

Michi helped Shiori stand up, and then left the room.
[cpg]

The three of us stood in silence for a while in the quiet room.
[cpg]

However, Erika was always the one to start talking at a time like this.
[cpg]

[move from="4/5" to="2/5" ease="easeInOutSine" time=1000]
[WAIT time=1]
[move from="5/5" to="4/5" ease="easeInOutSine" time=1000]
[WAIT time=1000]
[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika098"]
[OnName num="Erika"]
"W-what the hell...was that?"
[cpg cn=true]

[OnName num="Kenji"]
"Oh, stop..."
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika099"]
[OnName num="Erika"]
"No matter how important it is, it's just a book made of a bunch of pieces of paper! She can just buy another one!"
[cpg cn=true]

I understood what Erika was saying, but for Shiori, it was probably more than just a book.
[cpg]

I'm sure the book was filled with memories of her grandfather.
[cpg]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna053"]
[OnName num="Yuna"]
"But it was my fault..."
[cpg cn=true]

[OnName num="Kenji"]
"It can't be helped..."
[cpg cn=true]

Erika yells at Yuna and me, when we both became dejected.
[cpg]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika100"]
[OnName num="Erika"]
"Nonsense! I can't stand it when an inreasonable lady yells at my best friend like that!"
[cpg cn=true]

[OnName num="Kenji"]
"An inreasonable lady...?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna054"]
[OnName num="Yuna"]
"Unreasonable..."
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika101"]
[OnName num="Erika"]
"That's it. I'm so pissed off. I'm going to take away the one thing she cares about most!"
[cpg cn=true]


[OnName num="Kenji"]
"What? What the hell are you talking about?"
[cpg cn=true]

Erika started sprouting nonsense again, and she grabbed Yuna's hand before I could do or say anything.
[cpg]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika102"]
[OnName num="Erika"]
"I'm going to make sure you get your revenge!"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna055"]
[OnName num="Yuna"]
"I'm not looking to get revenge..."
[cpg cn=true]

Erika held up Yuna's hand like she was hyping up a champion boxer.
[cpg]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Erika103"]
[OnName num="Erika"]
"You ready? Yuna and Kenji, forget about what happened today for the time being, and from tomorrow on, act as if nothing happened, while keeping the enemy in a good mood. You got it?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna056"]
[OnName num="Yuna"]
"Uh-huh..."
[cpg cn=true]

[OnName num="Kenji"]
"Ohhhh..."
[cpg cn=true]

She was definitely up to something stupid again.
[cpg]

I let out a deep sigh as I thought about it.
[cpg]

If only I had lectured and scolded Erika more that time, instead of being so dumbfounded...
[cpg]

All that trouble could have been avoided...
[cpg]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[STOPBGM]
[WAIT time=2000]

[stopse g=1]
;//ボイス
[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

[jump storage="ep004.ks" target="*start"]


