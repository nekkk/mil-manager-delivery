;//『ルートＦ』

*start
*root_f|Ambush

;#################################################
*Ep021|Ambush
;#################################################
[SCENE id=14]

;#############################################################
;//Ev016
;#############################################################

[BG f="b_l_b1_lr_0.ui" time=1]
[FG f="CHA06_p3_01_a.ui" method="change_3" pos="2/3" time=1]


Well, there was nothing wrong with teaming up with Shoko.
[cpg]

I accepted her offer.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko379"]
[OnName num="Syouko"]
"We're partners now, aren't we?"
[cpg cn=true]

I didn't know if we were partners exactly, but I felt like she wouldn't betray me now....
[cpg]

;//【ＢＧ】図書館・地下・物置Ｂ　（暗）


However, now that it's like this, we will be more concerned about the others' movements.
[cpg]

Michi was at odds with Yuna and Erika, and if those two were in the same room, they might start doing something outlandish again.
[cpg]

Besides, if Shiori's other personality were to come out and all three of them were in danger, that wouldn't be good.
[cpg]

[OnName num="Kenji"]
"I wonder what they're doing now."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko380"]
[OnName num="Syouko"]
"Oh..., right. I forgot all about them..."
[cpg cn=true]

We hurriedly got ourselves ready and rushed back to the infirmary.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）******************************************************

[WAIT time=1500]

;//[BGM f="d1"]


[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="1/3" time=800]

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika567"]
[OnName num="Erika"]
"Untie us."
[cpg cn=true]

[VOICE f="Yuna424"]
[OnName num="Yuna"]
"Help us!"
[cpg cn=true]

[OnName num="Kenji"]
"What...?"
[cpg cn=true]

When we entered the infirmary, for some reason Erika and Yuna were tied up.
[cpg]

They had just been freed, what in the world happened?
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika568"]
[OnName num="Erika"]
"That woman did it!"
[cpg cn=true]

[OnName num="Kenji"]
"That woman?"
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna425"]
[OnName num="Yuna"]
"Ms. Kisaragi tied us up and walked out!"
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko381"]
[OnName num="Syouko"]
"The doctor did?!"
[cpg cn=true]

I didn't know why Michi restrained them, and Shoko didn't seem to agree with it either.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko382"]
[OnName num="Syouko"]
"Maybe she was planning on confronting Shiori..."
[cpg cn=true]

[OnName num="Kenji"]
"Confronting her?!"
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko383"]
[OnName num="Syouko"]
"Ah, not Shiori, but the alter. But the doctor has a strong sense of responsibility, so even if they stab each other, they may still be able to work things out!"
[cpg cn=true]

[OnName num="Kenji"]
"They can't stab each other!"
[cpg cn=true]

The plausibility of Shoko's theory made me rush out of the infirmary.
[cpg]

[SE f="se022"]
;//【ＳＥ】ダッシュ
[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika569"]
[OnName num="Erika"]
"W-wait!"
[cpg cn=true]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna426"]
[OnName num="Yuna"]
"Untie us!"
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）******************************************************

[WAIT time=1500]

[BGM f="huan"]

After confirming that Michi and Shiori were nowhere on the first floor, I ran up the stairs with Shoko, who was right behind me.
[cpg]

[SE f="se022"]
;//【ＳＥ】ダッシュ


[BG f="b_l_1f_entrance_p4up5.ui" time=1000]
;//頭欠け胸像
;//[BG f="b_l_1f_entrance_p4up.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）（踊り場）******************************************************

[WAIT time=1500]

[OnName num="Kenji"]
"Huh?!"
[cpg cn=true]

When we reached the landing, I immediately stopped in my tracks because of what I saw.
[cpg]

The bust of Shiori's grandfather, which had always been there, had sadly fallen apart.
[cpg]

On top of that, a skull was peeking out from under the bust, which had cracked and collapsed when the ear broke.
[cpg]

[OnName num="Kenji"]
"B-bone..."
[cpg cn=true]

It had turned yellow, but it was clearly a skull.
[cpg]

Why would such a thing be inside a statue...?
[cpg]

[OnName num="Kenji"]
"What the hell is this...?
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko384"]
[OnName num="Syouko"]
"I think it's Shiori's grandfather..."
[cpg cn=true]

Shoko muttered right after me.
[cpg]

[OnName num="Kenji"]
"What the...?!"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko385"]
[OnName num="Syouko"]
"Shiori's love is extraordinary... I've heard that sometimes there's no grave, not that there isn't one, but maybe she wanted to keep her beloved grandfather close by...?"
[cpg cn=true]

[OnName num="Kenji"]
"No..., no way..."
[cpg cn=true]

I thought that it was strange.
[cpg]

I didn't care how much she loved him, it was insane to tamper with a corpse and turn it into a statue.
[cpg]

But, actually there was something in Shiori's room that appeared to be...Takagi's corpse.
[cpg]

Maybe inside Hosokawa's statue was Hosokawa himself.
[cpg]

At this point, I was convinced that Shiori was insane.
[cpg]

Shiori was...crazy.
[cpg]

[OnName num="Kenji"]
"We need to help Michi..."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko386"]
[OnName num="Syouko"]
"Yes!"
[cpg cn=true]

We headed upstairs, trying to control our panicking.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_ros_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

[WAIT time=1500]

[BGM f="huan"]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori713"]
[OnName num="Shiori"]
"You've seen the statue..."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi563"]
[OnName num="Michi"]
".................."
[cpg cn=true]

When she saw us rushing into the room, Shiori spoke with a face devoid of any emotion.
[cpg]

Michi was also in the room, but she was sitting in a chair, legs crossed, looking at us silently.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko387"]
[OnName num="Syouko"]
"Whoa!"
[cpg cn=true]

"Whoa!"
[cpg]

I took another look at it, and it was definitely Takagi's actual head inside.
[cpg]

[OnName num="Kenji"]
"I'm going to ask you straight out... Is that Takagi's head in there?"
[cpg cn=true]

My throat felt dry, and I found myself getting nervous.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori714"]
[OnName num="Shiori"]
"Yeah..."
[cpg cn=true]

Shiori replied, nodding, and even though I already knew that, my heart was crushed, like a steel frame was dropped on it.
[cpg]

[OnName num="Kenji"]
"So, so..., Hosokawa's face and limbs over there have real human parts inside...?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori715"]
[OnName num="Shiori"]
"Yeah..."
[cpg cn=true]

[OnName num="Kenji"]
"!!"
[cpg cn=true]

It was a terrifyingly honest admission, and all my emotions were swirling around in me, crushing my heart.
[cpg]

[OnName num="Kenji"]
"How could you do this?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori716"]
[OnName num="Shiori"]
"Who knows..."
[cpg cn=true]

[OnName num="Kenji"]
"Who knows?!"
[cpg cn=true]

I couldn't believe that Shiori answered emotionlessly as if it were someone else.
[cpg]

Then Michi, who had been silent until now, adjusted her long legs in her chair and began to speak.
[cpg]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi564"]
[OnName num="Michi"]
"Shiori has a mental illness. So she won't charge her with anything. I'm sorry to tell you this, but there's no point in pursuing it."
[cpg cn=true]

[OnName num="Kenji"]
"W-what...?"
[cpg cn=true]

What was this person talking about...?
[cpg]

Michi knew what Shiori had done and was trying to cover it up!
[cpg]

[OnName num="Kenji"]
"Before we even talk about pursuing charges, people are dying! If she's sick, she's sick, but that's something you have to share with the police and the world!"
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi565"]
[OnName num="Michi"]
"Well, it's up to you if you want to tell everyone, but don't you think it would be best for Shiori to keep quiet?"
[cpg cn=true]

[OnName num="Kenji"]
"I don't think so... Michi, it's your responsibility."
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi566"]
[OnName num="Michi"]
".................."
[cpg cn=true]

[OnName num="Kenji"]
"If Shiori was sick enough to do this, then you, as a doctor, should have stopped her and kept her in isolation!"
[cpg cn=true]

[OnName num="Kenji"]
"But you let her get sick and then you try to cover up what happened! It's crazy... You're both crazy!""
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori717"]
[OnName num="Shiori"]
"Crazy... I'm...abnormal..."
[cpg cn=true]

Shiori, who had been listening to my words, repeated them in a hushed voice.
[cpg]

The way she looked like a broken robot seemed creepy.
[cpg]

[OnName num="Kenji"]
"Shiori..., I was wrong about you. I was a fool to let your appearance deceive me into liking you."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori718"]
[OnName num="Shiori"]
"Kenji... I'm sorry..."
[cpg cn=true]

[OnName num="Kenji"]
"Shoko, let's go!"
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko388"]
[OnName num="Syouko"]
"Huh..., uh...Yes."
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4ex5.ui" time=1000]
;//頭欠け胸像
;//[BG f="b_l_2f_lpass_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・左側廊下　夜（暗）******************************************************

[WAIT time=1500]

[BGM f="huan"]

Shiori's apologies did not reach my heart.
[cpg]

She was a cruel girl who, together with another person, had tricked me and hid her acts of murder.
[cpg]

But no more.
[cpg]

Now that I knew the truth, I knew exactly what I had to do.
[cpg]

I apologized to Erika and Yuna, and the four of us, with Shoko, would get out of here.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko389"]
[OnName num="Syouko"]
"Where are we going, Kenji?"
[cpg cn=true]

[OnName num="Kenji"]
"We need to get to the infirmary and free Erika and Yuna."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko390"]
[OnName num="Syouko"]
"Oh, yes!"
[cpg cn=true]

Shoko, obediently went along with me.
[cpg]

Her vibrant smile cheered me up.
[cpg]

[OnName num="Kenji"]
"We're going to get out of here alive. Together."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko391"]
[OnName num="Syouko"]
"Yes!"
[cpg cn=true]

;//☆死亡
;//エリカ、柚那死亡

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）
[WAIT time=1500]


[STOPBGM]


;//[free time=1000]
;**【ＣＧ】ci_08_0 ***********************
;//カットイン
[CUTIN f="ci_08_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=2000]

[SE f="se088"]
;//【ＳＥ】ショック

[WAIT time=5500]

[BGM f="serious"]



[OnName num="Kenji"]
"You're kidding..."
[cpg cn=true]

When I returned to the infirmary, I found Erika and Yuna lying on the floor, still tied up.
[cpg]

Their necks had been snapped and the floor was a sea of blood.
[cpg]

At first glance, it was clear that they were not breathing.
[cpg]

[OnName num="Kenji"]
"No..., how...? Both Shiori and Michi were in the room upstairs, and yet..."
[cpg cn=true]

I racked my brain, wondering who could have come in here and murdered these two.
[cpg]

However, my frustrated and irritated brain couldn't come up with a clear answer.
[cpg]

[CUTIN f="ci_08_0.ui" show={false} method="slideout"]

[OnName num="Kenji"]
"This is...strange...Hey, what do you think, Shoko...?"
[cpg cn=true]

;//画面揺れる
[SE f="se045"]
;//【ＳＥ】ガスッ！

[WAIT time=1500]

[SE f="se047"]
;//【ＳＥ】ドサッ


;//画面横向きになる

[WAIT time=1500]

I turned around and received a huge blow to the head and fell to the floor.
[cpg]

;//＠
[free time=1000]
;**【ＣＧ】ev_06_0 ***********************
[CG id=05 index=0 time=1000]
;*****************************************
[WAIT time=1000]



[VOICE f="Syouko392"]
[OnName num="Syouko"]
"That was a close one, Kenji. Ahaha ♪"
[cpg cn=true]

She crouched down right next to my face and laughed.
[cpg]


[VOICE f="Syouko393"]
[OnName num="Syouko"]
"I respect Dr. Kisaragi. So I think this outcome was also possible."
[cpg cn=true]

Her clothes were spattered with red dots.
[cpg]

As soon as I realized that it was my blood..., my consciousness faded away.
[cpg]

;//【ＢＧ】ブラックアウト
[free time=1500]
[BG f="black.ui" time=1500]
[WAIT time=3500]

[stopse g=1]
;//ボイス
[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

[system end4=true]
[SCENE id=20]

;//ＥＮＤ『伏兵』
;**【ＥＮＤ】　　　　********************************
[jump storage="epend.ks" target="*start"]
;****************************************************



;//＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
