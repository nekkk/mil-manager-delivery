*start
;#################################################
*Ep017|The Meaning of “2”
;#################################################
[SCENE id=11]

[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 26th
[cpg]

The next day, Yuna finally woke up.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン閉／蝋燭）******************************************************

[WAIT time=1500]
[BGM f="dod"]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna279"]
[OnName num="Yuna"]
"I..., what the...?"
[cpg cn=true]

When she regained consciousness, Yuna had returned to the quiet girl she was before her delirium.
[cpg]

I was relieved to hear that, and together with Michi, I gave her a false explanation.
[cpg]

[OnName num="Kenji"]
“You just suddenly collapsed.”
[cpg cn=true]

[WAIT time=100]
[VOICE f="Michi409"]
[OnName num="Michi"]
"I think it's probably just anemia from hunger. I've given you an IV so you'll feel a little better."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna280"]
[OnName num="Yuna"]
"So that’s what happened… I'm sorry for all the trouble…"
[cpg cn=true]

[free time=800]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_7" pos="3/3" time=800]

It may not have cleared her suspicions about Michi, but Yuna still thanked her properly and laid down on the bed again.
[cpg]

[VOICE f="Syouko217"]
[OnName num="Syouko"]
".................."
[cpg cn=true]

Shoko watched our demeanor in silence, but her face was filled with suspicion.
[cpg]

I looked in the back and saw Erika's body on the stainless steel table.
[cpg]

Glad that it hadn't disappeared, a sigh of relief escaped me.
[cpg]

[SE f="se009"]
;//【ＳＥ】ドア


;//以下、栞はコトハ
;//↓　名前は栞だけど本当はコトハ、という展開です。

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori344"]
[OnName num="Shiori"]
“Good morning.”
[cpg cn=true]

[OnName num="Kenji"]
“A-ah, good morning…”
[cpg cn=true]

When I saw Shiori come into the infirmary, I immediately realized that it wasn't her.
[cpg]

There was a big smile on her face.
[cpg]

Shiori did not smile like this….
[cpg]

This was…Kotoha.
[cpg]

I was pretty sure that Shiori had been replaced by Kotoha.
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori345"]
[OnName num="Shiori"]
“Kenji, let’s go.”
[cpg cn=true]

[OnName num="Kenji"]
“Uh, where to…”
[cpg cn=true]

Shiori took my hand and tried to pull me out of the room.
[cpg]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi410"]
[OnName num="Michi"]
".................."
[cpg cn=true]

After getting the nod from Michi, I left the infirmary like she wanted.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_ros_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

[WAIT time=1500]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori346"]
[OnName num="Shiori"]
"Here, you must be hungry."
[cpg cn=true]

[OnName num="Kenji"]
“Ah…”
[cpg cn=true]

Shiori offered me some more food that she had been hiding.
[cpg]

[OnName num="Kenji"]
“But, this is…”
[cpg cn=true]

The horrible thought occurred to me that if we shared the food, my portion would be reduced.
[cpg]

;//コトハ
[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori347"]
[OnName num="Shiori"]
“Please eat.”
[cpg cn=true]

[OnName num="Kenji"]
“Y-yeah…”
[cpg cn=true]

I ended up devouring the food she gave me all by myself.
[cpg]

A feeling of guilt washed over me when my stomach became full again, and I was speechless.
[cpg]

;//コトハ
[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori348"]
[OnName num="Shiori"]
"Good. You ate it all."
[cpg cn=true]

Shiori spoke, hugging my arm and grinning.
[cpg]

As Shiori rubbed my arm lovingly, I couldn't help but ask.
[cpg]

Even if Shiori didn't know about Kotoha, I wondered about Kotoha…
[cpg]

[OnName num="Kenji"]
“You’re…, Kotoha, aren’t you?”
[cpg cn=true]

For a moment, her eyes seemed to shift, but soon she was smiling innocently.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori349"]
[OnName num="Kotoha"]
“Aha, I’ve been found out?”
[cpg cn=true]

Then the girl in front of me, who looked like Shiori, seemed like a different person to me already.
[cpg]

[OnName num="Kenji"]
"Kotoha. Do you know that you're a different person from Shiori?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori350"]
[OnName num="Kotoha"]
"Of course I know that. I'm here because of Shiori."
[cpg cn=true]

Perhaps she had been pretending to be Shiori, but when she began to speak, Kotoha's tone did not resemble Shiori's at all.
[cpg]

[OnName num="Kenji"]
“You killed…, three people…?”
[cpg cn=true]

Kotoha didn't seem to be the least bit offended or even confused when I suddenly asked a question that got to the heart of the matter.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori351"]
[OnName num="Kotoha"]
“Yeah.”
[cpg cn=true]

[OnName num="Kenji"]
"!!"
[cpg cn=true]

Even though I vaguely had the grasp of the situation, I was still very upset when the murderer replied to me honestly.
[cpg]

[OnName num="Kenji"]
“W-why…, did you…”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori352"]
[OnName num="Kotoha"]
"Well, Takagi tried to force himself on Shiori even though she rejected him. Hosokawa attacked the teacher. So I had to protect them both."
[cpg cn=true]

She said it so nonchalantly.
[cpg]

There was certainly no guilt in this personality.
[cpg]

[OnName num="Kenji"]
“Then, what about Erika?”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori353"]
[OnName num="Kotoha"]
"Oh, that girl was punished for seducing my Kenji."
[cpg cn=true]

Kotoha was different from a ghost.
[cpg]

She was an individual personality who shared a physical body with Shiori.
[cpg]

As I froze in fear, Kotoha continued without hesitation.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori354"]
[OnName num="Kotoha"]
"I can’t forgive that girl Yuna either~ She messed up the books that Grandfather left her. Shiori was just crying, so I'm going to get revenge."
[cpg cn=true]

[OnName num="Kenji"]
“No, don't do that."
[cpg cn=true]

I wish she hadn't said that to me with Shiori's face.
[cpg]

I was shocked by the truth that she was Kotoha, and I asked her all the questions I had been wanting to ask.
[cpg]

[OnName num="Kenji"]
“Where are Takagi and Hosokawa's bodies…?”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori355"]
[OnName num="Kotoha"]
"Oh, those guys..."
[cpg cn=true]

As she was about to answer, Kotoha's eyebrows furrowed for a moment.
[cpg]

[OnName num="Kenji"]
"?!"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori356"]
[OnName num="Kotoha"]
“They…are…”
[cpg cn=true]

[OnName num="Kenji"]
“Kotoha?!”
[cpg cn=true]

I was surprised to see Kotoha leaning forward and I supported her body…
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori357"]
[OnName num="Kotoha"]
“Who…is…Koto…ha…?”
[cpg cn=true]

[OnName num="Kenji"]
“Huh.”
[cpg cn=true]

;//▲状況整理　コトハ本人だが、栞に人格交代したフリをしている
;//コトハ
[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori358"]
[OnName num="Shiori"]
“Kenji…, How…? How did I get here…?”
[cpg cn=true]

[OnName num="Kenji"]
“Shi, Shiori…?”
[cpg cn=true]

A personality change occurred in front of me, and Kotoha was back to being Shiori.
[cpg]

So I kept my mouth shut and put what I was talking about with Kotoha in the back of my mind.
[cpg]

If Shiori found out about Kotoha's existence now, her delicate heart would break.
[cpg]

I wanted to avoid that at all costs.
[cpg]

If we ever got out of here, Michi said she would tell the police about Shiori's illness.
[cpg]

At least until then, I wanted to protect Shiori just as she is.
[cpg]

All I had to do was restrain Kotoha and keep Yuna from messing with her.
[cpg]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori359"]
[OnName num="Shiori"]
"Kenji…, um…, what's wrong...?"
[cpg cn=true]

[OnName num="Kenji"]
"It's nothing. I just came to read with you."
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori360"]
[OnName num="Shiori"]
“Is…that so…?”
[cpg cn=true]

Shiori was a princess after all.
[cpg]

That’s why I'll protect her.
[cpg]

Please let me save you…
[cpg]

[STOPBGM]

;//ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン閉／蝋燭）******************************************************

[WAIT time=1500]
[BGM f="huan"]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yuna281"]
[OnName num="Yuna"]
"Ms. Endo…, Where's Ms. Kisaragi…?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko218"]
[OnName num="Syouko"]
"Oh, the doctor went upstairs for a minute. What's wrong?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna282"]
[OnName num="Yuna"]
“I…, who did this to me …?"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko219"]
[OnName num="Syouko"]
“Huh?!”
[cpg cn=true]

Yuna made sure that no one was around before approaching Shoko.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna283"]
[OnName num="Yuna"]
“Shiori or Ms. Kisaragi must have done something to me!”
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko220"]
[OnName num="Syouko"]
“Well, you see…”
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna284"]
[OnName num="Yuna"]
"Tell me honestly! I have the right to know!"
[cpg cn=true]

Yuna grabbed Shoko's collar and tightened it, like Erika had always done to her.
[cpg]

It was dangerous not to stay one step ahead.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko221"]
[OnName num="Syouko"]
"Y-yes...that's...it. Shiori strangled you…"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna285"]
[OnName num="Yuna"]
"I knew it..."
[cpg cn=true]

Yuna could no longer trust even Kenji.
[cpg]

Kenji was with Shiori.
[cpg]

No matter what Yuna said to him, he wouldn't listen anymore.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna286"]
[OnName num="Yuna"]
"Ms. Endo... It's just the two of us now."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko222"]
[OnName num="Syouko"]
“Uh…”
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna287"]
[OnName num="Yuna"]
"If we leave her alone, you and I will never get out of here alive! We have to do something about that girl before that happens!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko223"]
[OnName num="Syouko"]
“Y-yeah…you’re right.”
[cpg cn=true]

Shoko agreed with Yuna.
[cpg]

Both Michi, who kept Shiori hidden, and Kenji, who saw the truth with her, are on Shiori's side.
[cpg]

If it’s like this, she must protect Yuna and herself.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna288"]
[OnName num="Yuna"]
"She's probably hiding food. I smelled food coming from Kenji yesterday!"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko224"]
[OnName num="Syouko"]
“What?!”
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna289"]
[OnName num="Yuna"]
"Those two...are keeping the food to themselves... They're going to laugh at us as we starve to death..."
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko225"]
[OnName num="Syouko"]
“F-food...”
[cpg cn=true]

Shoko was also dizzy and hungry.
[cpg]

Constantly thinking about food, to the point where just getting an IV would be easier.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna290"]
[OnName num="Yuna"]
"Let's go. You and I, we're going to get the food back!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko226"]
[OnName num="Syouko"]
“Y-yes!”
[cpg cn=true]

Yuna had switched from being the one being ordered around to the one giving orders.
[cpg]

Her obsession with life made her stronger and she used Erika as a role model to encourage Shoko.
[cpg]

The two of them then headed for Shiori's room.
[cpg]

On the way, they had taken some stuff from the decorated armor…
[cpg]



;//▲状況整理　ここにいるのはコトハだが、このあとの展開的に栞本人になっていないとダメっぽいのでドアを叩かれた時にコトハが咄嗟に栞と入れ替わる、という形で辻褄を合わせます

;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="pipo-tr005.png" color={0x000000ff} time=2000]
[WAIT time=2100]
[free time=100]
[BG f="b_l_2f_ros_0.ui" time=100]
;//【ＢＧ】図書館・２階・栞の部屋******************************************************
[WAIT time=2000]
[transition target={false} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=3100]
[window target=true]


[SE f="se121"]
;//【ＳＥ】乱暴にドアが叩かれる

[WAIT time=800]

;//＠CG元の位置

[BGM f="danger"]

[OnName num="Kenji"]
“W-what?!”
[cpg cn=true]

While Shiori and I were cuddling up reading, the door slammed hard. It was so loud.
[cpg]

[OnName num="Kenji"]
“Shiori, get back!”
[cpg cn=true]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori361"]
[OnName num="Shiori"]
“Y-yeah…”
[cpg cn=true]

;//ここでコトハが栞と入れ替わる
;//ここからは栞本人になります

[free time=1000]

[WAIT time=1000]

I stood between Shiori and the door to protect her. What the hell was going on here?
[cpg]

My mind was racing. But I had to protect Shiori.
[cpg]

[OnName num="Kenji"]
"Ah, the lock!"
[cpg cn=true]

I wondered if the door to the room was locked. But it was a little too late for that.
[cpg]

Whoever was knocking on the door hadn't noticed it either yet.
[cpg]

By the time I got to the door to lock it, it was too late.
[cpg]

[SE f="se065"]
;//【ＳＥ】乱暴にドアが開かれる

;//＠
[free time=1000]
[WAIT time=1000]

[FG f="CHA06_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="2/3" time=800]

The door flung open and Yuna and Shoko came in.
[cpg]

[OnName num="Kenji"]
"Yu, Yuna? What are you doing here, Shoko?"
[cpg cn=true]

It was unlike them to show up like this and I was taken aback.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna291"]
[OnName num="Yuna"]
“Hand over the food! You have food, don't you? Give it to us!”
[cpg cn=true]

;//[SE f="se000"]
;//【ＳＥ】ギラーン
In her hand, she held a dagger, which must have come from the armor, the tip of which was pointing at us.
[cpg]

Yuna's arms were trembling. Was it because of the weight of the dagger, or because it was frightening to point a dagger at someone...?
[cpg]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko227"]
[OnName num="Syouko"]
“Shut up and hand over the food.”
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Shiori362"]
[OnName num="Shiori"]
"Uh, um... What food... What are you talking about...?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna292"]
[OnName num="Yuna"]
"Don't play dumb with me!"
[cpg cn=true]

[OnName num="Kenji"]
"!!"
[cpg cn=true]

I could feel Erika's presence behind Yuna.
[cpg]

Yuna looked exactly like Erika did when she was angry, this wasn’t delirium. 
[cpg]

[OnName num="Kenji"]
"A-anyway, put that dangerous thing down…, okay?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna293"]
[OnName num="Yuna"]
"Shut up!"
[cpg cn=true]

[SE f="se111"]
;//【ＳＥ】ブンッ！

[transition target={true} color={0xffffffff} time=100]
[WAIT time=100]
[transition target={false} color={0xffffffff} time=500]
[WAIT time=500]

[OnName num="Kenji"]
"Whoa!"
[cpg cn=true]

Yuna cut the air right in front of me with the dagger, and all my blood quickly drained away.
[cpg]

She was serious...
[cpg]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko228"]
[OnName num="Syouko"]
"Kenji, did you eat something without telling us? Yuna said she smelled food."
[cpg cn=true]

[OnName num="Kenji"]
"......."
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko229"]
[OnName num="Syouko"]
"Please hand it over. Please share the food with us. It's not fair. Please give us some food!"
[cpg cn=true]


;//[BG f="b_l_2f_ros_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

[WAIT time=1500]

[OnName num="Kenji"]
“U-ugh!”
[cpg cn=true]

Even Shoko's eyes changed color as she grabbed me.
[cpg]

;//＠
[if exp={ isSystemFlagsEnabled( "end1", "end2", "end3", "end4", "end5") }]
[jump target="*j9_a"]
[else]
[jump target="*j9_c"]
[endif]



;//※エンド制覇で、以下破線内のシーン挿入
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～

*j9_a|The Meaning of “2”

;//▲状況整理　二人が部屋に押し入ってくる直前に入れ替わるコトハ

;//＠
;//エフェクト
[window target=false]
[transition target={true} rule="39.png" color={0x000000ff} time=2000]
[WAIT time=2100]

[free time=100]
[BG f="b_l_2f_ros_0.ui" time=100]
;//【ＢＧ】図書館・２階・栞の部屋
[WAIT time=1000]
[transition target={false} rule="39.png" color={0x000000ff} time=2000]
[WAIT time=3100]
[window target=true]


[WAIT time=1500]
[BGM f="danger"]

[SE f="se121"]
;//【ＳＥ】乱暴にドアが叩かれる
[OnName num="Kenji"]
“W-what the?!”
[cpg cn=true]

[OnName num="Kenji"]
“Shiori, stay back!”
[cpg cn=true]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori363"]
[OnName num="Shiori"]
"Y-yeah…”
[cpg cn=true]

[STOPBGM]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori364"]
[OnName num="Kotoha"]
“(...this is going to be a pain in the ass)”
[cpg cn=true]

;//カチッ

While Kenji headed for the door, Kotoha approached the bookshelf and pressed a switch.
[cpg]

The bookshelf slid open to reveal a hidden room in the back, but Kenji hadn't noticed it.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori365"]
[OnName num="Kotoha"]
“(I’ll leave the rest to you)”
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Shiori366"]
[OnName num="Shiori"]
“(Eh…Ko, Kotoha?)”
[cpg cn=true]

The two instantly switched places. For Shiori, it was against her will, though.
[cpg]

;//ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

[SE f="se065"]
;//【ＳＥ】乱暴にドアが開かれる

[OnName num="Kenji"]
“Yu, Yuna? What's wrong with you and Shoko?!”
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_rok_0.ui" time=1000]
;//【ＢＧ】図書館・２階・コトハの部屋　（闇）（栞の部屋の鏡のかかった本棚の向こう側）******************************************************

[WAIT time=1500]
[BGM f="silent"]

;//コトハと美智が鏡から栞の部屋を覗いている

[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/5" time=800]

.......
[cpg]

.............
[cpg]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori367"]
[OnName num="Kotoha"]
“Heh…how troublesome…”
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi411"]
[OnName num="Michi"]
"......"
[cpg cn=true]

There behind the mirror in Shiori's room.
[cpg]

There was Kotoha's room.
[cpg]

Michi had also been watching the whole thing from that room when it happened.
[cpg]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi412"]
[OnName num="Michi"]
"What do you want to do with them?"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori368"]
[OnName num="Kotoha"]
"You know what..."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi413"]
[OnName num="Michi"]
"The more test subjects, the better. We're almost there and it's working."
[cpg cn=true]

Michi's formula was designed to keep the body beautiful.
[cpg]

A formula that does not gut the sbuject like a mummy, but keeps the eyeballs and brain intact, so that they can be contained in plaster or copper without rotting.
[cpg]

In order to create a standing statue that would be exactly the same as when the subject was alive, Michi had continued her research day and night.
[cpg]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori369"]
[OnName num="Kotoha"]
"But animals and humans are very different. I'm glad we got so many samples."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi414"]
[OnName num="Michi"]
"At first I didn't know what to do, being locked up like this."
[cpg cn=true]

The confinement was only an accident.
[cpg]

Kotoha saw the accident as an opportunity and carried out the hunt for samples.
[cpg]

[FACE method="change_1" pos="3/5"]
[WAIT time=100]
[VOICE f="Shiori370"]
[OnName num="Kotoha"]
"How long do you think it'll take? I'm finished with Takagi's parts."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi415"]
[OnName num="Michi"]
“There was too much fat on that one. Hosokawa worked rather well, so we'll adjust the formula a little and try it a few more times and it should work.”
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori371"]
[OnName num="Kotoha"]
"Will it be ready in time for Kenji?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi416"]
[OnName num="Michi"]
"Yes."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori372"]
[OnName num="Kotoha"]
“If we don't hurry, he'll lose weight.”
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi417"]
[OnName num="Michi"]
"Yes, let's do it quickly. I want to see how happy it will make Shiori."
[cpg cn=true]

[STOPBGM]

[window target=false]
[transition target={true} rule="39.png" color={0x000000ff} time=2000]
[WAIT time=2100]

[free time=100]
[BG f="b_l_2f_ros_0.ui" time=100]
;//【ＢＧ】図書館・２階・栞の部屋******************************************************
[WAIT time=1000]
[transition target={false} rule="39.png" color={0x000000ff} time=2000]
[WAIT time=3100]
[window target=true]

[BGM f="danger"]

;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～

*j9_c|The Meaning of “2”

[free time=1000]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7" pos="1/3" time=1000]
[FG f="CHA06_p3_01_a.ui" method="change_3" pos="3/3" time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="2/3" time=1000]


[OnName num="Kenji"]
"Shiori, run!"
[cpg cn=true]


[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori373"]
[OnName num="Shiori"]
“B-but…”
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna294"]
[OnName num="Yuna"]
"I will not let you escape!"
[cpg cn=true]

[SE f="se111"]
;//【ＳＥ】ブンッ！ブンッ！

[transition target={true} color={0xffffffff} time=100]
[WAIT time=100]
[transition target={false} color={0xffffffff} time=100]
[WAIT time=100]

While Shiori was panicking, Yuna waved her dagger at her and closed in.
[cpg]

[OnName num="Kenji"]
“Leave Shiori alone!”
[cpg cn=true]

I pushed Shoko's body as hard as I could towards Yuna, trying to stop her anyway I could.
[cpg]

[SE f="se045"]
;//【ＳＥ】ドンッ


[FG f="CHA06_p3_01_a.ui" method="change_5" pos="3/3" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/3" time=1]
[WAIT time=1]
[move from="3/3" to="4/5" ease="easeInOutSine" time=500]

[WAIT time=100]
[VOICE f="Syouko230"]
[OnName num="Syouko"]
“Kyaaaa!”
[cpg cn=true]

Shoko tried to stay on her feet, but ultimately she was unable to stand and fell down to the ground.
[cpg]

[SE f="se117"]
;//【ＳＥ】ガシャン！

[free time=1000]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_5" pos="1/3" time=1000]
[WAIT time=2000]
[VOICE f="Shiori374"]
[OnName num="Shiori"]
“Aah!!”
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA06_p3_01_a.ui" method="change_4" pos="2/3" time=800]

The sound of something breaking caused everyone's eyes to focus on Shoko for a moment.
[cpg]

And where Shoko had fallen, the plaster dog statue was broken.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko231"]
[OnName num="Syouko"]
“Ouch…”
[cpg cn=true]

When Shoko tried to get up, the white plaster crumbled away with a rattle.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori375"]
[OnName num="Shiori"]
“N-no…, No…”
[cpg cn=true]

[free time=1]

[STOPBGM]

;//[SE f="se000"]
;//【ＳＥ】ガラガラガラ

[WAIT time=1]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko232"]
[OnName num="Syouko"]
“Huh…? Ahhhhhhh!”
[cpg cn=true]

[VOICE f="Yuna295"]
[OnName num="Yuna"]
“Eeeeeeeek! W-what’s this?!”
[cpg cn=true]

[OnName num="Kenji"]
“It, it's…”
[cpg cn=true]

There was something brown and dried out underneath the plaster…
[cpg]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna296"]
[OnName num="Yuna"]
“Ahhh! Eeeek!”
[cpg cn=true]

[SE f="se101"]
;//【ＳＥ】ガンガン叩く

When Yuna hit it with a scream, more and more plaster fell off, revealing what it really was.
[cpg]

[OnName num="Kenji"]
"U-ugh!"
[cpg cn=true]

It was a dried up and mummified dog...
[cpg]


[free time=1000]

[BGM f="huan"]

[WAIT time=1000]
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori376"]
[OnName num="Shiori"]
“Aaaah…, poor thing, poor poor thing…”
[cpg cn=true]

Shiori began to scrape up the pieces of the destroyed dog, tears streaming down her face
[cpg]

She then attempted to wriggle the white pieces back onto the dog's mummy.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna297"]
[OnName num="Yuna"]
"You're insane… I knew you were crazy!"
[cpg cn=true]

Yuna exclaimed when she saw the scene in front of her.
[cpg]



;//[BG f="b_l_2f_ros_0.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

;//[WAIT time=1500]
[free time=1000]

With those words, Shiori picked up the mummified dog with a sad expression on her face.
[cpg]

For a moment, I thought she had changed into Kotoha, but apparently not.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3" pos="1/4" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_4" pos="4/4" time=800]
[WAIT time=100]
[VOICE f="Shiori377"]
[OnName num="Shiori"]
“It's awful… I didn't want to…see it like this…. If it weren't for you, it would still be…okay."
[cpg cn=true]

[SE f="se110"]
;//【ＳＥ】カシャ…カシャ…

[move from="1/4" to="1/3" ease="easeInOutSine" time=1000]


The plaster, which she had just scraped up and placed on the floor, fell to the floor as Shiori walked.
[cpg]



[move from="2/3" to="3/4" ease="easeInOutSine" time=1000]

[WAIT time=100]
[VOICE f="Yuna298"]
[OnName num="Yuna"]
“No! Don't come any closer! Murderer! You're a madwoman!”
[cpg cn=true]

[SE f="se111"]
;//【ＳＥ】ブンッ！ブンッ！

[transition target={true} color={0xffffffff} time=100]
[WAIT time=100]
[transition target={false} color={0xffffffff} time=100]
[WAIT time=100]

[WAIT time=1000]
[VOICE f="Shiori378"]
[OnName num="Shiori"]
“Poor thing…, poor thing…”
[cpg cn=true]

[move from="1/3" to="3/5" ease="easeInOutSine" time=1000]


[VOICE f="Syouko233"]
[OnName num="Syouko"]
“A-aaaah!”
[cpg cn=true]


[VOICE f="Yuna299"]
[OnName num="Yuna"]
“N-noooooo!”
[cpg cn=true]

;//[SE f="se000"]
;//【ＳＥ】槍落とす
;//[WAIT time=1000]

[SE f="se022"]
;//【ＳＥ】ダッシュ

[move from="3/4" to="5/3" ease="easeInOutSine" time=1000]
[move from="4/4" to="6/3" ease="easeInOutSine" time=1000]

Screaming, the two assailants ran away.
[cpg]

[OnName num="Kenji"]
"Wait!"
[cpg cn=true]

[free time=1000]
[BG f="b_l_1f_entrance_p2up.ui" time=1000]
[WAIT time=1000]

I knew that if I left them alone, Shiori would be in danger again.
[cpg]

So I chased after Yuna and Shoko and caught up to them on the landing of the stairs.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yuna300"]
[OnName num="Yuna"]
"Let go!"
[cpg cn=true]

[VOICE f="Syouko234"]
[OnName num="Syouko"]
"Please let go!"
[cpg cn=true]

[OnName num="Kenji"]
"Sorry, I can't do that!"
[cpg cn=true]

Standing in front of Shiori's grandfather’s bust, I made a vow.
[cpg]

[OnName num="Kenji"]
“I won't let you hurt Shiori."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna301"]
[OnName num="Yuna"]
“What are you talking about? Didn't you see that dog? What the hell was that? You must be crazy to care about that monster!"
[cpg cn=true]

[OnName num="Kenji"]
"Don't say that!"
[cpg cn=true]

I didn’t know what that was, but there had to be extenuating circumstances.
[cpg]

[OnName num="Kenji"]
“I need you two to stay put until help arrives.”
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko235"]
[OnName num="Syouko"]
“W-what do you plan on doing?”
[cpg cn=true]

[OnName num="Kenji"]
“The same thing you did to Yuna.”
[cpg cn=true]

I dragged the two reluctant women to the basement.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_ware_0.ui" time=1000]
;//【ＢＧ】図書館・地下・非常用倉庫　（暗／懐中電灯）******************************************************

[WAIT time=1500]

[SE f="se060"]
;//【ＳＥ】ギリリリ
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko236"]
[OnName num="Syouko"]
"Ow, ow, ow! It's too tight."
[cpg cn=true]

[OnName num="Kenji"]
“You'll have to be patient.”
[cpg cn=true]

I tied Yuna and Shoko up with rope and put a blanket over them.
[cpg]

[OnName num="Kenji"]
“Stay here and keep quiet.”
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna302"]
[OnName num="Yuna"]
"No! They'll kill us if we're tied up in here!"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko237"]
[OnName num="Syouko"]
"Please help me! I'm scared of Shiori!"
[cpg cn=true]

[OnName num="Kenji"]
"I'll keep an eye on her...."
[cpg cn=true]

I knew that if me and Michi kept our eyes on Shiori the whole time, we should be fine.
[cpg]

That way, even if Shiori turned into Kotoha, we would be able to handle her and she would not hurt anyone anymore.
[cpg]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Yuna303"]
[OnName num="Yuna"]
"Ahhhh, even Kenji has gone crazy. Shiori must have poisoned his mindー!"
[cpg cn=true]

[OnName num="Kenji"]
"Stop it. I'm not crazy."
[cpg cn=true]

That's what every crazy person says, but I know I'm not crazy.
[cpg]

If I were crazy, I would have punched Yuna in the face a long time ago...
[cpg]

[OnName num="Kenji"]
“If there’s any water, I'll bring some to you.”
[cpg cn=true]

I said, leaving the pantry.
[cpg]

The two of them were screaming for a while, but they soon grew quiet.
[cpg]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_ros_0.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）******************************************************

[WAIT time=1500]
[BGM f="dod"]

[OnName num="Kenji"]
“Shiori, are you okay?”
[cpg cn=true]

When I returned to the room, I found Shiori sitting amongst the plaster wreckage holding out the dog mummy.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori379"]
[OnName num="Shiori"]
“I’m sorry…, I’m sorry…”
[cpg cn=true]

Shiori was crying and apologizing to the dog's carcass.
[cpg]

I moved the dagger from the floor to the side of the bookshelf and crouched down beside Shiori.
[cpg]

[OnName num="Kenji"]
"Um…, what happened to the dog…?"
[cpg cn=true]

I asked gently, trying not to irritate her.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori380"]
[OnName num="Shiori"]
"It wandered into my life a long time ago… I used to feed it from time to time, but one day it just stopped moving in the yard…"
[cpg cn=true]

[VOICE f="Shiori1380"]
[OnName num="Shiori"]
"I…was so sad…that I asked the doctor to make me a plaster statue…"
[cpg cn=true]

[OnName num="Kenji"]
"To put the body in…?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori381"]
[OnName num="Shiori"]
“I figured then it could stay with me, just like when it was alive…”
[cpg cn=true]

However, the carcass in front of me was completely mummified.
[cpg]

Unless it was kept on ice, it couldn't remain in the same condition as when it was still alive.
[cpg]

All things break, and things that have life will one day die and return to the earth.
[cpg]

That was the law of nature.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori382"]
[OnName num="Shiori"]
“U-ugh…uh…”
[cpg cn=true]

I hugged Shiori's crying shoulders and looked at the plaster statues in front of me.
[cpg]

I didn't want to think about it, but I wondered if all these animal statues had "something" inside…
[cpg]

It wasn’t impossible to imagine, but even if it were true, it couldn't be helped because Shiori was sick.
[cpg]

It was only natural for Shiori, who was physically weak, to seek solace.
[cpg]

[OnName num="Kenji"]
“You should get some sleep.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori383"]
[OnName num="Shiori"]
"Yeah..."
[cpg cn=true]

I laid Shiori down on the bed and held her hand in mine.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori384"]
[OnName num="Shiori"]
"Let’s sleep together, Kenji…"
[cpg cn=true]

[OnName num="Kenji"]
"Okay…"
[cpg cn=true]

I laid down next to Shiori and gave her my arm and closed my eyes.
[cpg]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[STOPBGM]
[WAIT time=3000]

[SE f="se037"]
;//【ＳＥ】腹が鳴る

[OnName num="Kenji"]
"Hmmm…"
[cpg cn=true]

[BG f="b_l_2f_ros_0.ui" time=1000]
[WAIT time=1000]

When I woke up to the sound of my own stomach, Shiori was sleeping quietly beside me.
[cpg]

"........."
[cpg]

The expression on her face as she slept peacefully didn't seem like she had been carrying a lot of heavy things.
[cpg]

She had a beautiful doll-like face.
[cpg]

[OnName num="Kenji"]
“So cute…”
[cpg cn=true]

I looked at my watch and saw that the hands were pointing at two o'clock.
[cpg]

For a moment, I couldn't tell if it was day or night, and I was a little disoriented.
[cpg]

[OnName num="Kenji"]
“I should go check on them…”
[cpg cn=true]

I was curious about Yuna and Shoko, so I quietly pulled my arm out from under Shiori's neck and left the room while trying not to wake her.
[cpg]

If there was any water, I had to make them drink it.
[cpg]

[SE f="se009"]
;//【ＳＥ】ドア閉まる

[BG f="black.ui" time=1000]
[WAIT time=3000]

[VOICE f="Shiori808"]
[OnName num="Shiori"]
"...lions and unicorns get their crowns and start fighting, lions chase unicorns, the whole town is scared and in an uproar. White bread, Black bread, some people give you sweet bread, they both come out…"
[cpg cn=true]

[stopse g=1]
;//ボイス
[stopse g=2]
;//通常se
[stopse g=5]
;//システム
[stopse g=6]
;//ループse

[WAIT time=2000]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************


[WAIT time=1500]
[BGM f="dod"]

I stopped by the restroom to see if there was any water, but the pipes were still icy and not even a drop would come out.
[cpg]

I walked down the stairs to the basement, disappointed.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗／懐中電灯）******************************************************

[WAIT time=1500]

[SE f="se072"]
;//【ＳＥ】ノック

[OnName num="Kenji"]
“Yuna, Shoko, I'm coming in.”
[cpg cn=true]

There was no answer, but I took the liberty of opening the door and stepping inside.
[cpg]

Then...
[cpg]


[BG f="b_l_b1_ware_0.ui" time=1000]

[STOPBGM]


;//２人いっぺんに槍で串刺しになっている
[free time=1000]
;**【ＣＧ】ci_10_0 ***********************
;//カットイン
[CUTIN f="ci_10_0.ui" show={true} method="slidein"]
;*****************************************

[WAIT time=1000]

[SE f="se088"]
;//【ＳＥ】ショック

;//☆死亡
;//柚那、章子死亡

[OnName num="Kenji"]
“Aaahhhhhh!”
[cpg cn=true]

[BGM f="danger"]

Blood was pouring out of Yuna and Shoko's bodies.
[cpg]

The blood that flowed out of their bodies was like a black swamp, and the two of them were lying on the floor in it.
[cpg]

[OnName num="Kenji"]
“Ah…aa…aahh.”
[cpg cn=true]

It was all my fault…
[cpg]

Because I left the two of them tied up in a place like this…
[cpg]

Intense regret washed over me like a stormy sea, and at the same time I wondered who had done it.
[cpg]

[OnName num="Kenji"]
"The killer is…"
[cpg cn=true]

Shiori had been asleep in my arms the whole time
[cpg]

I had held her close to my chest, so if she got up and slipped out, I would have definitely noticed.
[cpg]

If that was the case, then there was only one person left.
[cpg]

[OnName num="Kenji"]
"Michi..."
[cpg cn=true]

She would not tolerate anyone hurting Shiori.
[cpg]

So I'm sure she resented Yuna.
[cpg]

[OnName num="Kenji"]
“But why…, Shoko…”
[cpg cn=true]

I wonder if she was collateral damage…
[cpg]

"2"
Suddenly, I remembered the dying message that Erika had written.
[cpg]

[OnName num="Kenji"]
“Michi and Kotoha!”
[cpg cn=true]

Michi told me all that, but she must have been helping Kotoha commit the crimes.
[cpg]

And Erika saw the two of them.
[cpg]

If that's true, Michi's claim that she would tell the police was probably a lie.
[cpg]

I was the only one left...
[cpg]

Wouldn't it be more convenient for her to keep me quiet and cover it up…
[cpg]

[CUTIN f="ci_10_0.webp" show={false} method="slideout"]


;//[free time=900]
;//[BG f="black.ui" time=900]
;//[WAIT time=1500]
;//[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン閉／蝋燭）

[WAIT time=1500]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi418"]
[OnName num="Michi"]
“Kenji...?”
[cpg cn=true]

[OnName num="Kenji"]
“Mi, Michi...”
[cpg cn=true]

Michi was standing right behind me, probably coming from infirmary.
[cpg]

Then she looked inside and said with a surprised look on his face.
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi419"]
[OnName num="Michi"]
"Th-this is...terrible...! Ah…, what happened..."
[cpg cn=true]

[OnName num="Kenji"]
“No more lies...”
[cpg cn=true]

;//☆死亡
;//美智死亡

;//ホビ提出版では立ち絵で処理
;//[free time=1000]
;**【ＣＧ】ci_11_0 ***********************
;//カットイン
[CUTIN f="ci_11_0.ui" show={true} method="slidein"]
;*****************************************

[WAIT time=1000]


[VOICE f="Michi420"]
[OnName num="Michi"]
“What? Ugh?!"
[cpg cn=true]

Before I knew it, my hands were on Michi's neck and I began to apply pressure.
[cpg]


[VOICE f="Michi421"]
[OnName num="Michi"]
“Ken, Kenji..., why...”
[cpg cn=true]

[OnName num="Kenji"]
“Why? How can you ask that after what you've done?"
[cpg cn=true]

I said as I strangled Michi.
[cpg]


[VOICE f="Michi422"]
[OnName num="Michi"]
“It hurts...”
[cpg cn=true]

Michi's face became redder and redder, and the whites of her eyes began to fill with blood.
[cpg]

[OnName num="Kenji"]
“It was you... You did everything..."
[cpg cn=true]

At first, I was just angry at Michi, but as I strangled her, I began to think that it was possible to move all of the blame from Shiori...no, Kotoha to this person.
[cpg]

Shiori didn't know about Kotoha.
[cpg]

Then why didn't I just keep this all to myself...?
[cpg]

[OnName num="Kenji"]
From now on, I'll protect Shiori...
[cpg cn=true]


[VOICE f="Michi423"]
[OnName num="Michi"]
"Ugh...ack...uh, Kenji..."
[cpg cn=true]

[CUTIN f="ci_11_0.ui" show={false} method="slideout"]


;//【ＢＧ】ブラックアウト
[BG f="black.ui" time=900]
[free time=900]
[WAIT time=1500]
Her eyes fluttered upward and she started drooling as she said my name.
[cpg]

[SE f="se047"]
;//【ＳＥ】ドサッ
When I let go, Michi's body crumpled to the floor and didn't move a muscle.
[cpg]

[OnName num="Kenji"]
"This was for the best... Michi, you're no good for Shiori..."
[cpg cn=true]

This was the result of confining Shiori to only her home and the library, drugging her, and overprotecting her.
[cpg]

But I'm different.
[cpg]

I can take her, this caged princess, out into the world and give her a happy life.
[cpg]

;//※以下、栞はコトハ
;//↓　名前は栞だけど本当はコトハ、という展開です。
[cpg]

[STOPBGM]

[WAIT time=1500]
[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗／懐中電灯）******************************************************

[WAIT time=1500]
[BGM f="serious"]

;//コトハ
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=1000]
[WAIT time=100]
[VOICE f="Shiori385"]
[OnName num="Shiori"]
"Kenji...?"
[cpg cn=true]

[OnName num="Kenji"]
"Shiori..."
[cpg cn=true]

Shiori was standing in the hallway.
[cpg]

I was nervous for a moment, but as soon as I saw her face, I knew it was Kotoha.
[cpg]

[OnName num="Kenji"]
“You’re Kotoha..., right?”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori386"]
[OnName num="Kotoha"]
“Is the doctor...dead too?”
[cpg cn=true]

[OnName num="Kenji"]
“That's right. All those murders and everything else was done by Michi. Alright?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori387"]
[OnName num="Kotoha"]
“If that's what Kenji says, then so be it."
[cpg cn=true]

Kotoha replied with a smile.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori388"]
[OnName num="Kotoha"]
“I want to show you something. I just finished it a little while ago, okay?"
[cpg cn=true]

Kotoha pulled me by the hand and walked on ahead.
[cpg]

;//地下　廊下　→　エントランス　→　階段　→　宝物庫

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************
[WAIT time=3000]




[BG f="b_l_2f_th_p2.ui" time=2000]
;//【ＢＧ】図書館・２階・宝物庫　昼（エントランスからの光）******************************************************
[STOPBGM]

[SE f="se136"]
;//【ＳＥ】ドア開ける

[WAIT time=3000]


[BGM f="danger"]

[FG f="CHA02_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori389"]
[OnName num="Kotoha"]
"Here, look!"
[cpg cn=true]

[OnName num="Kenji"]
“…?!”
[cpg cn=true]

I was brought to the treasure room.
[cpg]

And when I saw what was placed inside, I was shocked and stiffened, my eyes and mouth wide open.
[cpg]

;//手脚がバラバラに転がされている高木、首が傾いている細川、頭が割れているエリカ達の像

Takagi's arms and legs were on the floor in pieces, and only his torso was sitting on the floor.
[cpg]

Hosokawa's neck was broken and leaning against his shoulder.
[cpg]

And Erika, whose head was split open...
[cpg]

The three statues stood side by side in front of the taxidermy animals. 
[cpg]

[OnName num="Kenji"]
"What the hell… is all this…?"
[cpg cn=true]

Strange standing statues that were neither copper nor plaster.
[cpg]


;//[BG f="b_l_2f_th_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・宝物庫　昼（エントランスからの光）


[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=1000]
[WAIT time=100]
[VOICE f="Shiori390"]
[OnName num="Kotoha"]
"These three pieces and the animals in Shiori's room are just experiments. So they’re not beautiful or anything."
[cpg cn=true]

Kotoha explained as she kicked Takagi's leg away
[cpg]

[SE f="se117"]
;//【ＳＥ】ガシャン
[WAIT time=1000]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori391"]
[OnName num="Kotoha"]
"Grandfather was made into a bronze statue, but it doesn't look very good, does it? It looks like a pile of mud."
[cpg cn=true]

[VOICE f="Shiori1391"]
[OnName num="Kotoha"]
“I wanted the statue to look more like a proper living person, but I didn't have the knowledge to do that in the past, and it was in a rush."
[cpg cn=true]

Kotoha kept going on and on.
[cpg]

It felt like I could hear that voice somewhere far off in the distance.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori392"]
[OnName num="Kotoha"]
“That’s why the doctor and I were working on a new way to make statues, a way to keep beautiful things beautiful forever. I believed that someone like Kenji would appear one day…”
[cpg cn=true]

[OnName num="Kenji"]
“What…about m-me…”
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori393"]
[OnName num="Kotoha"]
“These people were experiments. But grandfather and Kenji are different. I love you, and I want you to stay by my side in all your beauty…”
[cpg cn=true]

back away
[cpg]

Kotoha took a step closer to me and I took a step back.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori394"]
[OnName num="Kotoha"]
"You love me, don't you, Kenji? If so, you'll stay by my side forever, right?"
[cpg cn=true]

[OnName num="Kenji"]
“You're trying to make me…like these guys…?”
[cpg cn=true]

A cold sweat ran down my temples.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori395"]
[OnName num="Kotoha"]
“Nope, I'll make you much more beautiful."
[cpg cn=true]

[FG f="CHA02_p5_01_a.ui" method="change_2" pos="2/3" time=800]


back away ... back away
[cpg]

Kotoha slowly came closer.
[cpg]

[OnName num="Kenji"]
"Don't come any closer. It's Shiori I love, not you, Kotoha."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori396"]
[OnName num="Kotoha"]
“What are you talking about, Kenji? This is originally what Shiori wanted, not me."
[cpg cn=true]

[OnName num="Kenji"]
"That's a lie!"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori397"]
[OnName num="Kotoha"]
“It's not. Because Shiori killed Grandfather.”
[cpg cn=true]

[OnName num="Kenji"]
“You…!”
[cpg cn=true]

Kotoha grinned and twisted the corner of her mouth into a smile.
[cpg]

But the next moment, she squeezed her eyes shut, held her chest and crouched down.
[cpg]

;//コトハが栞のふりをする
;//コトハ
[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori398"]
[OnName num="Shiori"]
“Ugh…! Gah…cough! Cough! Ken, Kenji…what happened…”
[cpg cn=true]

[OnName num="Kenji"]
“Shiori?! Are you okay?!”
[cpg cn=true]

She switched from Kotoha to Shiori, and panicking, I rubbed her back.
[cpg]

;//コトハ
[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori399"]
[OnName num="Shiori"]
“Kenji..., where is the doctor…? Go call the doctor…”
[cpg cn=true]

[OnName num="Kenji"]
“Mi, Michi is…”
[cpg cn=true]

Oh, what a mess I've made of things.
[cpg]

I was clearly out of my mind at that time, even though I knew Shiori needed Michi.
[cpg]

;//コトハ
[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori400"]
[OnName num="Shiori"]
“It hurts… Cough! I can’t breathe and my chest hurts…”
[cpg cn=true]

[OnName num="Kenji"]
“Shiori! Hold on!”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori401"]
[OnName num="Kotoha"]
"He, hehehehe. I got you~"
[cpg cn=true]

[OnName num="Kenji"]
"?!"
[cpg cn=true]

The face of the person who grabbed my hand tightly, it was Kotoha's.
[cpg]

back away
[cpg]

Her jagged nails dug into the skin of my hands, causing pain.
[cpg]

[OnName num="Kenji"]
"Ko, Kotoha..."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori402"]
[OnName num="Kotoha"]
"Why are you trying to escape? Me and Shiori will be able to stare at you for the rest of our lives."
[cpg cn=true]

[OnName num="Kenji"]
“N-no…”
[cpg cn=true]

I shook off Kotoha's hand and took a huge step back.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori403"]
[OnName num="Kotoha"]
"You're beautiful, Kenji. If we wait any longer, you will become thin and ugly. Before that happens, I..WANT TO KILL YOU!"
[cpg cn=true]

;//[SE f="se000"]
;//【ＳＥ】キラーン
Kotoha held a single scalpel in her hand.
[cpg]

[OnName num="Kenji"]
“That's not love! If you want to kill me, you don’t really love me!"
[cpg cn=true]

I shouted, not taking my eyes off the scalpel that Kotoha was holding.
[cpg]

Then…, I heard a voice coming from right behind me.
[cpg]

[STOPBGM]

;//ちょっと加工した、怖い声
;//？？？
[VOICE f="Shiori404"]
[OnName num="unknown"]
“No, I love you…”
[cpg cn=true]

[SE f="se099"]
;//【ＳＥ】ズブッ

;//画面赤く染まる
;//【ＢＧ】レッドアウト
[free time=1000]
[BG f="red.ui" time=1000]
[WAIT time=1500]


[OnName num="Kenji"]
“Huh…?”
[cpg cn=true]

I felt a searing pain in my back.
[cpg]

I didn't need to check with my hands to see the red puddle spreading under my feet.
[cpg]

Was this…my blood?
[cpg]


[VOICE f="Shiori405"]
[OnName num="Kotoha"]
"Bye-bye, Kenji."
[cpg cn=true]

In front of me stood Kotoha in the form of Shiori.
[cpg]

No one should be alive anymore, but what was that voice I heard earlier...?
[cpg]

[SE f="se047"]
;//【ＳＥ】ドサッ

;//画面、横向きになり栞とコトハの足だけが見える

;//＠
[free time=1000]
;**【ＣＧ】ev_20_0 ***********************
[CG id=19 index=0 time=1000]
;*****************************************
[WAIT time=1000]

;//【ＢＧ】図書館・２階・宝物庫　昼（真赤／横向き）

I crumpled to the floor, and in my fading consciousness, I saw something.
[cpg]

I could see four legs in front of me…
[cpg]

[OnName num="Kenji"]
"There are two...of you..."
[cpg cn=true]

;//【ＢＧ】ブラックアウト
[free time=1500]
[BG f="black.ui" time=1500]
[WAIT time=3500]

[system end1=true]
[SCENE id=17]

[stopse g=1]
;//ボイス
[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

;//ルートB
;//ＥＮＤ『２』
;**【ＥＮＤ】　　　　********************************
[jump storage="epend.ks" target="*start"]
;****************************************************



;// 
;//＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～

