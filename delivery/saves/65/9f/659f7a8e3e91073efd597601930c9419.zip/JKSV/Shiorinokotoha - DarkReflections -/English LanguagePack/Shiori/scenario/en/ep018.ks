*start
*root_c|A Massacre

;//『ルートＣ』『ミナゴロシ』
;#################################################
*Ep018|A Massacre
;#################################################
[SCENE id=12]


[BG f="b_l_2f_ros_0.ui" time=1]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／蝋燭）


[BGM f="h1"]

;//コトハ
[FG f="CHA02_p5_01_a.ui" method="change_6" pos="2/3" time=1]

[OnName num="Kenji"]
“Y-yeah, that's a bit of a stretch…”
[cpg cn=true]

It was too embarrassing to just show her my naked body, no matter how much she wanted to see it.
[cpg]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori406"]
[OnName num="Shiori"]
“Really…”
[cpg cn=true]

[OnName num="Kenji"]
“S-sorry…”
[cpg cn=true]

I looked at Shiori, who looked disappointed, and that was when I realized how badly she wanted to see my body.
[cpg]



[SE f="se072"]
;//【ＳＥ】ノック

[WAIT time=2000]


[SE f="se009"]
;//【ＳＥ】ドア開く

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="4/4" time=800]
[WAIT time=100]
[VOICE f="Michi424"]
[OnName num="Michi"]
“Do you have a minute?”
[cpg cn=true]

Michi opened the door and peeked in.
[cpg]

[FACE method="change_1" pos="4/4"]
[WAIT time=100]
[VOICE f="Michi425"]
[OnName num="Michi"]
“Shiori, you should get some sleep.”
[cpg cn=true]

;//コトハ
[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori407"]
[OnName num="Shiori"]
"Alright..."
[cpg cn=true]

[FACE method="change_7" pos="4/4"]
[WAIT time=100]
[VOICE f="Michi426"]
[OnName num="Michi"]
“Kenji, you should leave for the night."
[cpg cn=true]

[OnName num="Kenji"]
"Okay..."
[cpg cn=true]

I nodded obediently at Michi's words, said goodnight to Shiori and left the room.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_lpass_p4.ui" time=1000]
;//【ＢＧ】図書館・２階・左側廊下　夜（暗）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=1000]
[WAIT time=1500]
[VOICE f="Michi427"]
[OnName num="Michi"]
“Kenji, I know what you're thinking…”
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi428"]
[OnName num="Michi"]
“You're a man after all, and I really don't want to say this. But, you know…"
[cpg cn=true]

[OnName num="Kenji"]
“What’s that?”
[cpg cn=true]

Once we were in the hallway, Michi spoke to me, choosing her words carefully.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi429"]
[OnName num="Michi"]
“I'm sorry, but Shiori doesn't have the body to endure such an activity.”
[cpg cn=true]

[OnName num="Kenji"]
“Huh?!”
[cpg cn=true]

I was well aware that Shiori was sick.
[cpg]

But I couldn't hide my surprise at both how bad it was and that Michi knew about my ulterior motives.
[cpg]

[OnName num="Kenji"]
"Oh, I'm not really…"
[cpg cn=true]

Embarrassed and uncomfortable, I nervously excused myself.
[cpg]

[OnName num="Kenji"]
"I just wanted to talk to Shiori…"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi430"]
[OnName num="Michi"]
“It's fine. There's no way a man your age wouldn't think twice about it when seeing a girl he likes."
[cpg cn=true]

[OnName num="Kenji"]
“Uh…”
[cpg cn=true]

Being a doctor, Michi seemed to have everything figured out.
[cpg]

;#############################################################
;//Ev010
;#############################################################
[STOPBGM]
;//【ＢＧ】ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=3000]



[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 23rd
[cpg]



;//[WAIT time=1500]
;//[BG f="b_l_1f_tbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・専門書の部屋　昼（エントランスからの光）
;//[BGM f="d1"]
;//[WAIT time=3000]




[BG f="b_l_1f_entrance_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=1500]
[BGM f="dod"]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi431"]
[OnName num="Michi"]
"Good morning."
[cpg cn=true]

[OnName num="Kenji"]
"Ah, good morning."
[cpg cn=true]

When I came out of my room, Michi was making coffee at the entrance.
[cpg]

After yesterday, I was incredibly embarrassed to see her face to face.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi432"]
[OnName num="Michi"]
“Would you like some coffee?”
[cpg cn=true]

[OnName num="Kenji"]
"Thank you."
[cpg cn=true]

Michi was so close. That alone made me a little nervous.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi433"]
[OnName num="Michi"]
“What's wrong?"
[cpg cn=true]

[OnName num="Kenji"]
“Uh, n-nothing…um…”
[cpg cn=true]

As I stuttered like that…
[cpg]

[STOPBGM]

[VOICE f="Erika466"]
[OnName num="Erika"]
“What the hell are you doing?”
[cpg cn=true]

I could hear a jealous voice. I looked up and saw Erika standing on the landing, looking like a demon.
[cpg]

[OnName num="Kenji"]
“E, Erika…”
[cpg cn=true]

I didn't expect her to wake up so early, and I was pretty upset.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="5/3" time=800]


[VOICE f="Erika467"]
[OnName num="Erika"]
“What are you doing getting all close? Are you after Kenji too? Stay away from Kenji! Even though you're old… and a murderer!"
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】ダッシュ

[move from="5/3" to="3/3" ease="easeInOutSine" time=1000]


As she came tumbling down the stairs, Erika snatched the spear from the armor on the side of the stairs and threw it at Michi.
[cpg]

[BGM f="danger"]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi434"]
[OnName num="Michi"]
“?!”
[cpg cn=true]

[SE f="se111"]
;//【ＳＥ】ブンッ！

[move from="2/3" to="1/3" ease="easeInOutSine" time=500]


Michi dodged it at the last second, but still panicked and ran away.
[cpg]

[SE f="se111"]
;//【ＳＥ】ブンブンッ！

[move from="3/3" to="2/3" ease="easeInOutSine" time=1000]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi435"]
[OnName num="Michi"]
“Kyaaa!”
[cpg cn=true]

[OnName num="Kenji"]
“Erika, s-stop! Calm down!
[cpg cn=true]

Even for her this was too much.
[cpg]

Erika, who looked like a demon, ran around with a spear and charged at Michi.
[cpg]

I couldn't even get close to her, so I just shouted.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko238"]
[OnName num="Syouko"]
"What's all the fuss about…., Aaaaah! W-what are you doing?”
[cpg cn=true]

[VOICE f="Shiori408"]
[OnName num="Shiori"]
"......?!"
[cpg cn=true]

[VOICE f="Yuna304"]
[OnName num="Yuna"]
"Erika?!"
[cpg cn=true]

Everyone above and below froze when they saw the horrible scene.
[cpg]

There was no time to explain while Michi fled to the landing.
[cpg]

[SE f="se022"]
;//【ＳＥ】ダッシュ

[free time=1]
[WAIT time=1]
[BG f="b_l_1f_entrance_p2up.ui" time=800]

[FG f="CHA05_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika468"]
[OnName num="Erika"]
“Waitー! You man stealer-!!!”
[cpg cn=true]

Erika, seeming to have lost her mind in anger, threw the spear at Michi.
[cpg]

[SE f="se111"]
;//【ＳＥ】ブンッ！
[move from="2/5" to="1/5" ease="easeInOutSine" time=1000]

[WAIT time=1000]


[OnName num="Kenji"]
"That's dangerous!"
[cpg cn=true]

[VOICE f="Michi436"]
[OnName num="Michi"]
"Kyaー!"
[cpg cn=true]

[SE f="se104"]
;//【ＳＥ】ガキッ！！

[STOPBGM]

[OnName num="Kenji"]
"Eh...?"
[cpg cn=true]

The spear flew through the air with such force that it passed over the cowering Michi and pierced the bust on the landing.
[cpg]


;//[free time=1]
;//[WAIT time=1]

;//[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori409"]
[OnName num="Shiori"]
“N-noooooooー!!”
[cpg cn=true]

[BGM f="danger"]

At the same time, Shiori, who had been watching the brawl from the second floor, turned pale and screamed.
[cpg]

[OnName num="Kenji"]
“Shi, Shiori!”
[cpg cn=true]

;//[free time=1]
;//[WAIT time=1]

[move from="1/5" to="2/5" ease="easeInOutSine" time=1000]

[WAIT time=100]
[VOICE f="Michi437"]
[OnName num="Michi"]
"Oh, my God! What did you do?!"
[cpg cn=true]

Michi, who heard Shiori's scream, attempted to pull out the spear that was lodged in the neck of the bust.
[cpg]

[SE f="se092"]
;//【ＳＥ】ギシギシギシ

The spear wobbled, and just when it looked like it was about to fall out...
[cpg]

;//[SE f="se000"]
;//【ＳＥ】メキメキッ

[WAIT time=2000]


[SE f="se117"]
;//【ＳＥ】ゴトッ…
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2ex3.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

Surprisingly, the neck of the bust snapped off at the root and fell to the floor.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shiori410"]
[OnName num="Shiori"]
“Eeeeeeeeekー!! Grandfather! Not again…!”
[cpg cn=true]

[free time=1000]

Right after she shouted, Shiori passed out.
[cpg]

"Her grandfather, again? What does she mean by ‘again’?”
[cpg]

But there was no time to ask about it.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Michi438"]
[OnName num="Michi"]
“Ms. Endo! Help!”
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko239"]
[OnName num="Syouko"]
"Y-es!"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi439"]
[OnName num="Michi"]
"Don't touch the statue! Nobody touch it, just leave it like this!"
[cpg cn=true]

[free time=1000]

Michi shouted, and she and Shoko picked up Shiori and carried her down to the basement.
[cpg]

I grabbed Erika and gave her a lecture, still angry.
[cpg]

[OnName num="Kenji"]
“What the hell are you doing?! One wrong move and you'd have stabbed Michi!"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika469"]
[OnName num="Erika"]
“It's her fault! Kenji is just being Kenji! What the hell? Did you sleep with her?!”
[cpg cn=true]

[OnName num="Kenji"]
".........."
[cpg cn=true]

It was so direct that I didn't have time to search for words, which only fueled Erika's anger.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika470"]
[OnName num="Erika"]
“Unbelievable… Kenji, you’re an idiot! Yuna, let’s go!!”
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna305"]
[OnName num="Yuna"]
“Ah…yeah…”
[cpg cn=true]

[OnName num="Kenji"]
“Where do you think you’re going?”
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika471"]
[OnName num="Erika"]
"To the restroom!"
[cpg cn=true]

[free time=1000]


[OnName num="Kenji"]
".................."
[cpg cn=true]

I couldn't hold Erika back any longer, because I didn't like the idea of her realizing what I had done.
[cpg]

But still, throwing a spear, one wrong move and she would have become a murderer herself…
[cpg]

Once again, I was horrified by Erika's rage.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2ex3.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）（踊り場）******************************************************

[WAIT time=1500]
[BGM f="silent"]

[OnName num="Kenji"]
"Ah…, it's pretty broken…"
[cpg cn=true]

The head of the bust was lying on the floor.
[cpg]

Unlike the bronze outside, the inside was made of a white material.
[cpg]

[OnName num="Kenji"]
“Hmmm? What's this…?”
[cpg cn=true]

However, I notice that there is a strange brown core within the white material.
[cpg]

The area occupied by that brown stuff is surprisingly large and seems…to be noticeably thicker than the white layer.
[cpg]

[OnName num="Kenji"]
"What the...hell is this?"
[cpg cn=true]

I poked it with my finger, but I couldn't figure out what it was.
[cpg]

Was the inside of the bronze statue made of paper mache or plaster?
[cpg]

But the brown part of it was hard, and covered with numerous wrinkles, like dried fish or something.
[cpg]

How strange...
[cpg]

I had never seen such a thing before in my life.
[cpg]

[STOPBGM]

[VOICE f="Yuna306"]
[OnName num="Yuna"]
“Kyaaー!!”
[cpg cn=true]

[OnName num="Kenji"]
"Yuna?!"
[cpg cn=true]

I heard Yuna's scream from downstairs and immediately went to go check it out.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_wt_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・女子トイレ　昼（窓から光）******************************************************

[OnName num="Kenji"]
"What's wrong?!"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna307"]
[OnName num="Yuna"]
“Er-rika is…, Erika is…!”
[cpg cn=true]

[WAIT time=1000]


[BGM f="huan"]

[OnName num="Kenji"]
"?!"
[cpg cn=true]

When I stepped into the women's restroom, I found Erika lying on the floor with blood pouring from her head.
[cpg]

[SE f="se021"]
;//【ＳＥ】微かに遠ざかる足音


;//[BG f="b_l_1f_wt_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・女子トイレ　昼（窓から光）******************************************************

[WAIT time=1500]

[OnName num="Kenji"]
"?!"
[cpg cn=true]

Just then, I thought I heard small footsteps, and I walked around the women's restroom to the stairs.
[cpg]


[free time=1000]

[BG f="b_l_1f_entrance_p2ex3.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************

[WAIT time=1500]

But by the time I got there, the sound of footsteps had already disappeared, and I couldn't find anyone.
[cpg]

[BG f="b_l_1f_wt_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・女子トイレ　昼（窓から光）******************************************************
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="2/3" time=1000]
[WAIT time=1500]

[OnName num="Kenji"]
“Are you okay?! Who did this?”
[cpg cn=true]

I turned back and yelled at Yuna as I ran over to Erika on the ground.
[cpg]

But Yuna was so frightened that she just shivered.
[cpg]

[WAIT time=100]
[VOICE f="Yuna308"]
[OnName num="Yuna"]
"I d-don't know…I was about to leave the stall when I heard a loud bang… When I got out, Erika was already like this…"
[cpg cn=true]

[OnName num="Kenji"]
“Anyway, let's get her to the infirmary!"
[cpg cn=true]

Even though she had just attacked somebody, I couldn't just leave the injured behind.
[cpg]

[free time=900]
[BG f="black.ui" time=900]

I held Erika's body in my arms and headed to the infirmary with Yuna.
[cpg]

[SE f="se065"]
;//【ＳＥ】ドア乱暴に開ける

[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）******************************************************

[WAIT time=1500]


[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Michi440"]
[OnName num="Michi"]
"Quiet!"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko240"]
[OnName num="Syouko"]
“I'm in the middle of a procedure… What?”
[cpg cn=true]

Shoko jumped up in shock when she saw us running into the room.
[cpg]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko241"]
[OnName num="Syouko"]
"What's wrong?! That injury…?!"
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi441"]
[OnName num="Michi"]
“Injury? Huh, what?!”
[cpg cn=true]

Michi looked at me from beside the unconscious Shiori and looked horrified.
[cpg]

However, she quickly regained her composure and had Erika lie down on the stainless steel table.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna309"]
[OnName num="Yuna"]
“Erika! Hang in there!"
[cpg cn=true]


[VOICE f="Erika472"]
[OnName num="Erika"]
“Ouch…”
[cpg cn=true]

Erika was conscious.
[cpg]

Shoko held her hand as she moaned and tried to put her head down, and the bleeding quickly stopped.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko242"]
[OnName num="Syouko"]
“Don't touch the wound! I'll take care of it right away!"
[cpg cn=true]

I couldn’t tell if Shoko was any good at this.
[cpg]


[VOICE f="Michi442"]
[OnName num="Michi"]
"..............."
[cpg cn=true]

However, Michi only checked it with a sideways glance and did not try to lend a hand.
[cpg]

It might have been asking too much, since she was the one who almost killed her.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko243"]
[OnName num="Syouko"]
“Umm, oh~, I can't cut the gauze. Sorry…, I'm an internal medicine nurse so…"
[cpg cn=true]


[VOICE f="Erika473"]
[OnName num="Erika"]
"Ouch… Hey, you should be more gentle…"
[cpg cn=true]

Even though it seemed that she was unable to shout, Erika was gradually regaining consciousness.
[cpg]

[OnName num="Kenji"]
“Erika, do you remember who did this to you?!”
[cpg cn=true]

After I opened my mouth, I huffed and looked around the room.
[cpg]

[OnName num="Kenji"]
"Um…, did anyone leave this room, even for a moment?"
[cpg cn=true]

Shoko and Michi were in this room.
[cpg]

Shiori sleeping on the bed made three.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi443"]
[OnName num="Michi"]
“How could I leave? I've been by her side ever since."
[cpg cn=true]

Shoko nodded in agreement with Michi.
[cpg]

[OnName num="Kenji"]
“But then, who did this to Erika..?”
[cpg cn=true]

And just as I asked, Erika woke up and her hand suddenly tugged on Yuna's hair.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika474"]
[OnName num="Erika"]
"You traitor!"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna310"]
[OnName num="Yuna"]
"Aaah!"
[cpg cn=true]

[OnName num="Kenji"]
“Erika! Stop! What are you talking about?!”
[cpg cn=true]

Surprised, Yuna held Erika's hand and she let Yuna go, but Erika was still emotional and kept shouting at her.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika475"]
[OnName num="Erika"]
"You pretended to go into the restroom and waited outside! And then you came back later just as I was leaving the stall!"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna311"]
[OnName num="Yuna"]
“That's ridiculous! Why would I do that…!”
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika476"]
[OnName num="Erika"]
“You were pissed at me, weren't you? You pretended to be quiet and obedient, but you really wanted to get back at me for punishing you!”
[cpg cn=true]

[OnName num="Kenji"]
"Punishing...?"
[cpg cn=true]

I looked at Yuna's face when I heard that.
[cpg]

But Yuna's eyes shifted and she was trembling, the blood drained from her face.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna312"]
[OnName num="Yuna"]
“I d-don't know… It wasn’t me… I didn't do anything…"
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika477"]
[OnName num="Erika"]
"Don't lie to meー!"
[cpg cn=true]

When Erika tried to grab Yuna again...
[cpg]

[FACE method="change_3" pos="3/3"]
[WAIT time=1]
[move from="2/3" to="8/9" ease="easeInOutSine" time=1000]
[WAIT time=1]
[move from="3/3" to="3/5" ease="easeInOutSine" time=1000]


[WAIT time=100]
[VOICE f="Syouko244"]
[OnName num="Syouko"]
"Please be quiet!"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_3" pos="2/3" time=800]

[FACE method="change_5" pos="1/3"]
[FACE method="change_5" pos="3/3"]

Shoko shouted in a stern voice, and we quieted down.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko245"]
[OnName num="Syouko"]
"This is an infirmary! It's just like a hospital! Didn't your mother ever tell you to be quiet in a hospital!"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/4" time=800]
[move from="2/3" to="3/4" ease="easeInOutSine" time=1000]

[WAIT time=100]
[VOICE f="Michi444"]
[OnName num="Michi"]
“You need to be quiet.”
[cpg cn=true]

[SE f="se045"]
;//【ＳＥ】『ドカッ！』

[FACE method="change_4" pos="3/4"]
[WAIT time=100]
[VOICE f="Syouko246"]
[OnName num="Syouko"]
“Wah, So-sorry…”
[cpg cn=true]

After Shoko’s lecture, it was now Michi's turn to lecture us.
[cpg]

[FACE method="change_7" pos="2/4"]


Michi looked at the gauze on Erika's head, sighed deeply, and told Shoko.
[cpg]

[FACE method="change_7" pos="2/4"]
[WAIT time=100]
[VOICE f="Michi445"]
[OnName num="Michi"]
"This is not going to close the wound, okay? It's not a matter of internal medicine or surgery, this kind of stuff is basic."
[cpg cn=true]

[VOICE f="Michi1445"]
[OnName num="Michi"]
“Even if you're just a psychiatric nurse, you should at least be able to do this."
[cpg cn=true]


[FACE method="change_4" pos="3/4"]
[WAIT time=100]
[VOICE f="Syouko247"]
[OnName num="Syouko"]
“Ugh…, I’m sorry…”
[cpg cn=true]

That said, Michi herself didn't seem to want to redo Erika's treatment, so she just turned to Shiori and sat down on a chair.
[cpg]

;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori411"]
[OnName num="Shiori"]
"Ugh..."
[cpg cn=true]

Shiori was lying in bed, moaning in pain and talking in her sleep.
[cpg]

;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[WAIT time=100]
[VOICE f="Shiori412"]
[OnName num="Shiori"]
"Grandfather…, forgive me… Please forgive us…"
[cpg cn=true]

That bronze statue of her grandfather, whom she cherished so much and even read to.
[cpg]

Shiori was so distressed that it had been cruelly broken at the neck.
[cpg]

[OnName num="Kenji"]
"You have to apologize."
[cpg cn=true]

I said, glaring at Erika.
[cpg]

She needed to apologize to Michi as well, but I thought she should definitely apologize to Shiori who was innocent in all of this.
[cpg]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika478"]
[OnName num="Erika"]
“W-what? What…? So Kenji’s on their side?! I can't trust anyone anymore, even Yuna is my enemy!”
[cpg cn=true]

[SE f="se049"]
;//【ＳＥ】ガバッ

Erika jumped up from the table and rushed to the door, disregarding the gauze on her bleeding head.
[cpg]

;//[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika479"]
[OnName num="Erika"]
"Since I'm the victim, I'll take her room! It’s the safest one!"
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】ダッシュ

[move from="1/3" to="5/3" ease="easeInOutSine" time=1000]


Right after she said it, Erika quickly ran out of the infirmary.
[cpg]

[FACE method="change_7" pos="1/3"]
[FACE method="change_4" pos="2/3"]
[WAIT time=1]
[move from="2/4" to="1/3" ease="easeInOutSine" time=1000]
[move from="3/4" to="2/3" ease="easeInOutSine" time=1000]
[WAIT time=100]
[FACE method="change_7" pos="1/3"]
[FACE method="change_4" pos="2/3"]

[VOICE f="Michi446"]
[OnName num="Michi"]
“Just now…, what did she mean?”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna313"]
[OnName num="Yuna"]
"I think it means...that she's taking Shiori’s room…"
[cpg cn=true]

[OnName num="Kenji"]
“That’s not good!”
[cpg cn=true]

I left the infirmary to follow Yuna and Erika.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_lpass_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・左側廊下　昼（天窓からの光）******************************************************

[WAIT time=1500]

As expected, or rather, as Yuna had predicted, Erika was holed up in Shiori's room.
[cpg]

[SE f="se072"]
;//【ＳＥ】ノック

[WAIT time=1000]

[OnName num="Kenji"]
“Erika! What the hell do you think you're doing, locking yourself in someone's room!"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna314"]
[OnName num="Yuna"]
“Come on out.. I’m, I’m on your side… Erika?”
[cpg cn=true]


[VOICE f="Erika480"]
[OnName num="Erika"]
"I don't trust anybody anymore!"
[cpg cn=true]

[OnName num="Kenji"]
“Erika? What's the use of staying where you are?"
[cpg cn=true]


[VOICE f="Erika481"]
[OnName num="Erika"]
"Shut up, shut up!"
[cpg cn=true]

[OnName num="Kenji"]
"But…?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna315"]
[OnName num="Yuna"]
“Erika, please just listen…”
[cpg cn=true]


[VOICE f="Erika482"]
[OnName num="Erika"]
“Shut uuuuppp!!”
[cpg cn=true]

[SE f="se115"]
;//【ＳＥ】ドタンバタン

[WAIT time=1000]

[OnName num="Kenji"]
"It’s no use…"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna316"]
[OnName num="Yuna"]
"We may have to wait until things settle down…"
[cpg cn=true]

[OnName num="Kenji"]
“Yeah, you’re right…”
[cpg cn=true]

The sound of Erika flailing inside echoed down the hallway.
[cpg]

It was going to be hard to clean up her mess...
[cpg]

[if exp={ isSystemFlagsEnabled( "end1", "end2", "end3", "end4", "end5") }]
[jump target="*j10_a"]
[else]
[jump target="*j10_c"]
[endif]

;//※エンド制覇で、以下破線内のシーン挿入
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～

*j10_a|A Massacre

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_ros_0.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗）


[SE f="se115"]
;//【ＳＥ】ドタンバタン

[WAIT time=2000]

[SE f="se112"]
;//【ＳＥ】ズズーーーッ

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika483"]
[OnName num="Erika"]
“Shut uuuuppp!!”
[cpg cn=true]

At that moment, the bookshelf behind Erika made a faint sound and slid sideways in a big way.
[cpg]

[STOPBGM]

;//[FG f="CHA02_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Shiori413"]
[OnName num="unknown"]
“You're the one being loud.”
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika484"]
[OnName num="Erika"]
“?!”
[cpg cn=true]

;//エリカに大ぶりのナイフを持って迫るコトハ
;//＠
[free time=1000]
;**【ＣＧ】ev_09_0 ***********************
[CG id=08 index=0 time=1000]
;*****************************************

[WAIT time=1000]


[BGM f="danger"]

Shiori appeared.
[cpg]

No…, that’s just what Erika thought, but it was actually Kotoha.
[cpg]


[VOICE f="Shiori414"]
[OnName num="Kotoha"]
"I guess one shot wasn't enough. Blockhead."
[cpg cn=true]


[VOICE f="Erika485"]
[OnName num="Erika"]
“W-what, what are you doing here…? And what's with that bookshelf?”
[cpg cn=true]


[VOICE f="Shiori415"]
[OnName num="Kotoha"]
“I'll give you something. A gift from grandfather.”
[cpg cn=true]


[VOICE f="Erika486"]
[OnName num="Erika"]
"?!"
[cpg cn=true]


[VOICE f="Shiori416"]
[OnName num="Kotoha"]
"I thought I'd just hit you today, but you've got a lot of nerve coming in here."
[cpg cn=true]


[VOICE f="Erika487"]
[OnName num="Erika"]
“What are you doing…? Stay away! Don't come any closerー!”
[cpg cn=true]


[VOICE f="Yuna317"]
[OnName num="Yuna"]
"I'm not going to… I'm waiting for Erika to come out on her own…"
[cpg cn=true]

Yuna's voice could be heard on the other side of the door.
[cpg]


[VOICE f="Shiori417"]
[OnName num="Kotoha"]
“What a sweet friend. She's so concerned about you, she didn't even try to come in."
[cpg cn=true]

Kotoha held up her knife and quickly closed the distance between Erika and herself.
[cpg]

Open the door and Yuna and Kenji can come help!
[cpg]

Just open the door!
[cpg]


[VOICE f="Erika488"]
[OnName num="Erika"]
"Arggh!"
[cpg cn=true]

[SE f="se099"]
;//【ＳＥ】ブシューーーーーッ！

;//＠
;//レッドアウト

;//血しぶき
;//＠

[free time=1000]

[window target=false]
[transition target={true} rule="amamori2.png" color={0xff0000ff} time=2000]
[WAIT time=2100]
[BG f="red.ui" time=100]
[WAIT time=200]
[transition target={false} rule="amamori2.png" color={0xff0000ff} time=200]
[WAIT time=200]
[window target=true]



[WAIT time=1000]



[VOICE f="Erika489"]
[OnName num="Erika"]
"Hah...ah...uhhh..."
[cpg cn=true]

Erika wanted to scream for help.
[cpg]

However, there was already nothing but blood and air coming out from her throat where it had been slashed with a sharp knife.
[cpg]


[VOICE f="Shiori418"]
[OnName num="Kotoha"]
“It’s all over.”
[cpg cn=true]

;//＠
[SE f="se113"]
;//【ＳＥ】ガシュガシュガシュ……ゴトリ

[WAIT time=2500]

;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～

*j10_c|A Massacre

[STOPBGM]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

Several minutes passed.
[cpg]

The room finally quieted down and we decided to try to talk to Erika again.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_lpass_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・左側廊下　昼（天窓からの光）******************************************************

[WAIT time=1500]
[BGM f="dod"]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna318"]
[OnName num="Yuna"]
“Erika…, have you calmed down…?”
[cpg cn=true]

[OnName num="Kenji"]
"You can’t stay in there forever. You know that, right?"
[cpg cn=true]

But...
[cpg]

silence
[cpg]

There was no reply from inside.
[cpg]

[OnName num="Kenji"]
“She didn’t fall asleep, did she?”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna319"]
[OnName num="Yuna"]
“I wonder…”
[cpg cn=true]

It was Erika.
[cpg]

It could be that she had fallen asleep in Shiori's bed.
[cpg]

If so, what could we do?
[cpg]

[SE f="se107"]
;//【ＳＥ】歩く×２

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[FG f="CHA06_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi447"]
[OnName num="Michi"]
"Did she lock it?"
[cpg cn=true]

[OnName num="Kenji"]
"Yes..."
[cpg cn=true]

Michi and Shoko came in, after finishing treatments.
[cpg]

[SE f="se072"]
;//【ＳＥ】ノック

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Syouko248"]
[OnName num="Syouko"]
"Erika~, can you please let me redo the gauze on your head?"
[cpg cn=true]

Shoko said and knocked on the door, but not even an angry word could be heard from inside.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna320"]
[OnName num="Yuna"]
“Maybe she fell asleep...”
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi448"]
[OnName num="Michi"]
"That's not good. It's dangerous to go to sleep so soon after a concussion."
[cpg cn=true]

Michi said and put her hand on the doorknob without any hesitation.
[cpg]

[SE f="se136"]
;//【ＳＥ】ドア開ける

[OnName num="Kenji"]
"Oh, it wasn't locked…"
[cpg cn=true]

[STOPBGM]

I finally noticed such stupid thing, but after I opened the door I realized what I was seeing and shouted.
[cpg]

[FACE method="change_5" pos="1/3"]
[FACE method="change_5" pos="2/3"]
[FACE method="change_5" pos="3/3"]
[OnName num="Kenji"]
"Aaahhhhー!"
[cpg cn=true]

[VOICE f="Yuna321"]
[OnName num="Yuna"]
"Kyaaaaaー!!"
[cpg cn=true]

[VOICE f="Syouko249"]
[OnName num="Syouko"]
“Eeeeeeeekー!!”
[cpg cn=true]


;//☆死亡
;//エリカ死亡

[free time=1000]

[BG f="b_l_2f_ros_0.ui" time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_03_0 ***********************
;//カットイン
[CUTIN f="ci_03_0.ui" show={true} method="slidein"]
;*****************************************

[WAIT time=1000]


[BGM f="danger"]

[FG f="CHA05_p3_01_a.ui" method="change_5" pos="1/6" time=800]
[WAIT time=100]

[VOICE f="Michi449"]
[OnName num="Michi"]
“W-what the…”
[cpg cn=true]

Red all over as far as the eye can see...red...red...red…
[cpg]

The floor, the books, the plaster statues, everything was stained a bright red.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="6/6" time=800]
[WAIT time=100]
[VOICE f="Yuna322"]
[OnName num="Yuna"]
"Aaaaahhhh!"
[cpg cn=true]

Yuna, screaming right beside me, was staring at something bright red.
[cpg]

[OnName num="Kenji"]
“E, Eri…ka…”
[cpg cn=true]

In the reddish-black room, there was Erika, with her…neck and body separated...
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_4" pos="2/6" time=800]
[WAIT time=100]
[VOICE f="Syouko250"]
[OnName num="Syouko"]
“Aaaaah! Her n-neck! Her neck is…!”
[cpg cn=true]

There was something…missing.
[cpg]

Her severed head was lying on the floor like a part of a mannequin doll.
[cpg]


[VOICE f="Yuna323"]
[OnName num="Yuna"]
"Noooooooooo!"
[cpg cn=true]


[VOICE f="Syouko251"]
[OnName num="Syouko"]
"Aaaaahhhー!!"
[cpg cn=true]

Yuna and Shoko clung to me, screaming.
[cpg]


[VOICE f="Yuna324"]
[OnName num="Yuna"]
“Aaahー! Aaaaahー!!”
[cpg cn=true]

[SE f="se045"]
;//【ＳＥ】ドンッ
[CUTIN f="ci_03_0.ui" show={false} method="slideout"]

[free time=500]
[BG f="b_l_2f_lpass_p2.ui" time=500]
;//【ＢＧ】図書館・２階・左側廊下　昼（天窓からの光）******************************************************

[WAIT time=500]

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko252"]
[OnName num="Syouko"]
“Hyaaaaa!!”
[cpg cn=true]

[free time=1000]

[OnName num="Kenji"]
"Yuna?!"
[cpg cn=true]

I don't know what she was thinking, but Yuna pushed Shoko away and tried to pull her out of the room with all the strength she could muster.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna325"]
[OnName num="Yuna"]
“Kenji, come on! I’m begging you! We can't stay hereー!!”
[cpg cn=true]

[OnName num="Kenji"]
"B-but..."
[cpg cn=true]

;//[free time=1000]

Michi was crouched in a pool of blood, inspecting Erika's body.
[cpg]

;//[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi450"]
[OnName num="Michi"]
"Go. If you make any more noise, I’ll get nothing done…"
[cpg cn=true]

[OnName num="Kenji"]
"O-okay."
[cpg cn=true]


As Michi kicked me out and Yuna pulled me out, I left the horror in Shiori’s room.
[cpg]

;//[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi451"]
[OnName num="Michi"]
"You should go to the restroom. You look terrible."
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_4" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Syouko253"]
[OnName num="Syouko"]
“I’m s-sorry…”
[cpg cn=true]

[STOPBGM]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_mhbr_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・地図と歴史書の部屋　昼（エントランスからの光）******************************************************

[WAIT time=1500]
[BGM f="huan"]

The other side of the second floor.
[cpg]

As I was led into the room of maps and history books, I couldn't help but think about the horrible incident that had just occurred.
[cpg]

[OnName num="Kenji"]
"How could that have happened…?"
[cpg cn=true]

We were in front of the room.
[cpg]

Absolutely no one came, but Erika inside, murdered.
[cpg]

How? How could something like that happen?
[cpg]

[OnName num="Kenji"]
“Hey Yuna…, Erika's head…”
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna326"]
[OnName num="Yuna"]
“Stop, I don’t want to hear it!”
[cpg cn=true]

Yuna bobbed her head from side to side as if to erase the memory.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna327"]
[OnName num="Yuna"]
“I can’t do this anymore…, I’m going to die… They’re going to kill me too…”
[cpg cn=true]

[OnName num="Kenji"]
“C-calm down…”
[cpg cn=true]

;//＠
[free time=1000]
;**【ＣＧ】ev_12_0 ***********************
[CG id=11 index=0 time=1000]
;*****************************************
[WAIT time=1000]


[VOICE f="Yuna328"]
[OnName num="Yuna"]
“I don't want to die! Kenji, I don't want to end up like that! I don't want to end up like Erika! Protect me!I'll do anything! I'll do anything, so please protect me!"
[cpg cn=true]

Yuna shouted and clung to me as she collapsed.
[cpg]


[VOICE f="Yuna329"]
[OnName num="Yuna"]
"You know, right? We were together at that time, remember? If that's the case, then the other two somehow managed to kill Erika!"
[cpg cn=true]

[OnName num="Kenji"]
"Somehow managed…?"
[cpg cn=true]


[VOICE f="Yuna330"]
[OnName num="Yuna"]
"Anyway, one of them did it! Help me! Help meー!!!!"
[cpg cn=true]

Yuna was already half-crazed.
[cpg]

She sobbed and rubbed her tear stained face against my chest.
[cpg]


[VOICE f="Yuna331"]
[OnName num="Yuna"]
“Waaaah!”
[cpg cn=true]

[OnName num="Kenji"]
“Hold…on…”
[cpg cn=true]


[VOICE f="Yuna332"]
[OnName num="Yuna"]
“I can do anything, I can do anything Kenji wants, so just protect me.”
[cpg cn=true]

;#############################################################
;//Ev011
;#############################################################
[OnName num="Kenji"]
"W-wait, Calm down. I'm not going to abandon anyone."
[cpg cn=true]

I was not going to get anywhere with her like this.
[cpg]

That's what I thought, and I quickly promised to protect her.
[cpg]


[VOICE f="Yuna333"]
[OnName num="Yuna"]
"R-really? Really...?"
[cpg cn=true]

[OnName num="Kenji"]
"Aah... not just Yuna, but everyone."
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_2f_mhbr_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・地図と歴史書の部屋　昼（エントランスからの光）******************************************************
[WAIT time=1500]

[FG f="CHA04_p5_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna334"]
[OnName num="Yuna"]
“Kenji…”
[cpg cn=true]

After she had wiped her glasses, Yuna put her arms around me.
[cpg]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna335"]
[OnName num="Yuna"]
"You'll keep your promise, right? We'll always be together, okay? We're…."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

I had no intention of abandoning Yuna, but I didn’t like her clinging to me like this.
[cpg]

I was only trying to calm her down...
[cpg]

[STOPBGM]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

[if exp={ isSystemFlagsEnabled( "end1", "end2", "end3", "end4", "end5") }]
[jump target="*j11_a"]
[else]
[jump target="*j11_c"]
[endif]

;//※エンド制覇で、以下破線内のシーン挿入
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～

*j11_a|A Massacre

[BG f="b_l_2f_ros_0.ui" time=1000]
;//【ＢＧ】図書館・２階・栞の部屋　（暗／血まみれ）

[WAIT time=1500]
[BGM f="silent"]

;//エリカの血を浴びたコトハと話す美智
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Michi452"]
[OnName num="Michi"]
“Why did you have to do that?”
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_2" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shiori419"]
[OnName num="Kotoha"]
"I made her go through the same thing Grandfather did. Ahahahaha."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi453"]
[OnName num="Michi"]
“You didn't even lock the door, what do you think would have happened if they had walked in back there?!”
[cpg cn=true]

[VOICE f="Michi1453"]
[OnName num="Michi"]
"Given the circumstances, there's a good chance they'll suspect Shiori!"
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori420"]
[OnName num="Kotoha"]
“That's not your concern.”
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi454"]
[OnName num="Michi"]
“What do you mean by that…?”
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori421"]
[OnName num="Kotoha"]
"Ahー, scary. She gets angry whenever Shiori is involved. No one likes a jealous woman, you know?"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi455"]
[OnName num="Michi"]
"I don't know. Nothing, I was… just thinking about Shiori. Shiori is my…"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori422"]
[OnName num="Kotoha"]
“Your what? Lover? Doll? Doctor, Shiori…, may be relying on you, but she doesn't want that kind of relationship with you, okay?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi456"]
[OnName num="Michi"]
“W-what are you saying…?”
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori423"]
[OnName num="Kotoha"]
“It’s disgusting, doctor. You’re both women. Besides, Shiori doesn't love you."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi457"]
[OnName num="Michi"]
"That's not true! That's not...true."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori424"]
[OnName num="Kotoha"]
"Don't you get it yet? Shiori wanted to make Grandfather a statue, and she wanted to make him a statue, but did she ever once say she wanted to make the doctor one?"
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi458"]
[OnName num="Michi"]
".........!!"
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori425"]
[OnName num="Kotoha"]
"That's what this is all about. If you understand, don't be so sure you've got us under control."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi459"]
[OnName num="Michi"]
“It's not true… Shiori… Shiori doesn’t love me…”
[cpg cn=true]

[STOPBGM]
;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=3000]
;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～
;//追加開始前にメッセージウィンドウを消してるので追加分岐の外で表示に切り替える

*j11_c|A Massacre

[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 24th
[cpg]



[BG f="b_l_2f_mhbr_p2.ui" time=1000]
;//【ＢＧ】図書館・２階・地図と歴史書の部屋　昼（エントランスからの光）******************************************************

[WAIT time=1500]

[BGM f="dod"]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna336"]
[OnName num="Yuna"]
"Hmm..."
[cpg cn=true]

[OnName num="Kenji"]
“We fell asleep…”
[cpg cn=true]

I fell asleep upstairs with Yuna yesterday.
[cpg]

When I woke up, Yuna's sweaty head was beside me, and I felt uncomfortable as soon as I woke up.
[cpg]

Plus…
[cpg]

[SE f="se037"]
;//【ＳＥ】腹が鳴る
When I tried to get up, I felt dizzy and lightheaded, and my stomach rumbled repeatedly.
[cpg]

[STOPBGM]

[VOICE f="Syouko254"]
[OnName num="Syouko"]
“Aaaaahhー!!”
[cpg cn=true]

[OnName num="Kenji"]
"?!"
[cpg cn=true]

I've heard so much screaming since I've been here.
[cpg]

Something bad had happened every time, so there was bound to be something bad this time, too.
[cpg]

Still, I couldn't just hide here forever.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna337"]
[OnName num="Yuna"]
"W-what now…?"
[cpg cn=true]

[OnName num="Kenji"]
“Anyway, let’s go.”
[cpg cn=true]

I ran out of the room, taking Yuna with me.
[cpg]

And then...
[cpg]

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]


[VOICE f="Syouko255"]
[OnName num="Syouko"]
“Aaah…aaah…D-doctor…The doctor…”
[cpg cn=true]

;//☆死亡
;//美智死亡

[BG f="b_l_1f_entrance_p2ex3.ui" time=1000]

;//[free time=1000]
;**【ＣＧ】ci_05_0 ***********************
;//カットイン
[CUTIN f="ci_05_0.ui" show={true} method="slidein"]
;*****************************************

[WAIT time=1000]


[BGM f="danger"]

[OnName num="Kenji"]
"?!"
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_4" pos="1/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="5/5" time=800]
[WAIT time=100]
[VOICE f="Yuna338"]
[OnName num="Yuna"]
"Kyaaaー!"
[cpg cn=true]

Shoko looked up from below.
[cpg]

All eyes wandered halfway between the first and second floors.
[cpg]

There was Michi, hanging from the railing of the corridor on the second floor with a rope around her neck.
[cpg]

[OnName num="Kenji"]
“Aaaaah…Mi, Michi…Why?”
[cpg cn=true]

Michi, who seemed the least likely to take her own life, apparently committed suicide by hanging herself.
[cpg]


[VOICE f="Yuna339"]
[OnName num="Yuna"]
“Was it su-suicide…? Or did someone…?!”
[cpg cn=true]


[VOICE f="Syouko256"]
[OnName num="Syouko"]
“Aaaahー! Doctor! Dooctooor!”
[cpg cn=true]

[OnName num="Kenji"]
“Shoko! Get a hold of yourself!”
[cpg cn=true]

[SE f="se022"]
;//【ＳＥ】駆け下りる

[CUTIN f="ci_05_0.ui" show={false} method="slideout"]


;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

As I ran over to comfort Shoko, who was upset and crying, Yuna, who had quickly followed me, suddenly got a chair and slammed it against the doorway.
[cpg]



[BG f="b_l_1f_entrance_p2ex3.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）
[WAIT time=1500]

[SE f="se101"]
;//【ＳＥ】ガンガンッ！

[OnName num="Kenji"]
“Stop! What are you doing?”
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna340"]
[OnName num="Yuna"]
“We have to escape! We have to get out of hereー!!”
[cpg cn=true]

In a fit of madness, Yuna threw a chair, her hair disheveled.
[cpg]

[SE f="se101"]
;//【ＳＥ】ガンガンッ！

[FG f="CHA06_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Syouko257"]
[OnName num="Syouko"]
“Waaaaaahー!”
[cpg cn=true]

[OnName num="Kenji"]
“Shoko...”
[cpg cn=true]

Even though I'm upset too, why do these guys keep screaming on their own?
[cpg]

I'm the only one who can keep myself sane.
[cpg]

I also wanted to go crazy and scream and cry.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Syouko258"]
[OnName num="Syouko"]
"Ahhhhー... Kenji, let's use this opportunity to go to the infirmary."
[cpg cn=true]

[OnName num="Kenji"]
"Huh?"
[cpg cn=true]

Shoko whispered while glancing over at Yuna, who was flailing about.
[cpg]

I was surprised how quickly she changed gears, but the seriousness in her eyes told me that there was something important going on
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna341"]
[OnName num="Yuna"]
“Outー!! Let me outー!!”
[cpg cn=true]

[SE f="se101"]
;//【ＳＥ】ガンガンガンガン！！

;//【ＢＧ】ブラックアウト
[free time=900]
[BG f="black.ui" time=900]
[free time=900]


I decided to leave the frenzied Yuna at the entrance and head to the infirmary with Shoko.
[cpg]

[STOPBGM]
;//エフェクト
[window target=false]
[transition target={true} rule="101.jpg" color={0x000000ff} time=100]
[WAIT time=100]



[if exp={ isSystemFlagsEnabled( "end1", "end2", "end3", "end4", "end5") }]
[jump target="*j12_a"]
[else]
[jump target="*j12_c"]
[endif]

;//※エンド制覇で、以下破線内のシーン挿入
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～
*j12_a|A Massacre

[BG f="b_l_1f_entrance_p2ex3.ui" time=100]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************
[free time=100]
[transition target={false} rule="163.jpg" color={0x000000ff} time=2000]
[WAIT time=3100]
[window target=true]

[stopse g=2]
;//通常se

[stopse g=6]
;//ループse

[BGM f="silent"]

[FG f="CHA04_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yuna342"]
[OnName num="Yuna"]
"Let me outー! Let me outー!"
[cpg cn=true]

[SE f="se101"]
;//【ＳＥ】ガンガンガン！

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shiori426"]
[OnName num="Shiori"]
"Yuna..."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna343"]
[OnName num="Yuna"]
“Ah! S-stay back! Kenji?! Shoko?! Where did they go?!”
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori427"]
[OnName num="Shiori"]
“Yuna…, here…”
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna344"]
[OnName num="Yuna"]
“Huh?!”
[cpg cn=true]

What Shiori offered was something that had enough power to restore Yuna's sanity.
[cpg]

However, it wasn’t anything big, just a cookie.
[cpg]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna345"]
[OnName num="Yuna"]
“Really?! Munch, munch, munch, munch!”
[cpg cn=true]

Obsessed with food, Yuna grabbed it out of Shiori's hands and gobbled it up, not even bothering to open the bag.
[cpg]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna346"]
[OnName num="Yuna"]
"Om, nom, nom! Gah! Cough, cough!"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori428"]
[OnName num="Shiori"]
“Are you okay…? Have some water…”
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna347"]
[OnName num="Yuna"]
“Ugg! Gulp, gulp, gulp!” 
[cpg cn=true]

As soon as her stomach was filled with food and water, the normal calmness returned to Yuna's eyes, which had been like those of a demon.
[cpg]

Then, she suddenly felt ashamed of herself for being so greedy.
[cpg]

[FACE method="change_6" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna348"]
[OnName num="Yuna"]
“Th-thanks… But, why…?”
[cpg cn=true]

Shiori definitely had a stash of food, but the fact that she gave it to Yuna and not to Kenji was a mystery.
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori429"]
[OnName num="Shiori"]
“I…know…”
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna349"]
[OnName num="Yuna"]
"What...?"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori430"]
[OnName num="Shiori"]
“That Kenji and Shoko are working together…”
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna350"]
[OnName num="Yuna"]
“Th-that’s not true…, that…can’t be…”
[cpg cn=true]

Kenji and Shoko?
[cpg]

What connection did those two have?
[cpg]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori431"]
[OnName num="Shiori"]
“It’s true… They went somewhere just the two of them, didn’t they? I'm sure they're discussing which of us they're going to kill next…"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna351"]
[OnName num="Yuna"]
“No way…, Kenji…”
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori432"]
[OnName num="Shiori"]
"Yuna, don't worry… You're the only one I'll help."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna352"]
[OnName num="Yuna"]
“Shiori…”
[cpg cn=true]

[FACE method="change_4" pos="4/5"]


The fact that Shiori gave her food made Yuna completely trust her.
[cpg]

Shiori was just trying to help by offering such a valuable item, right?
[cpg]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori433"]
[OnName num="Shiori"]
"I have an idea, you can hide in the closet. You'll be safe if you stay locked in there until I come for you."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna353"]
[OnName num="Yuna"]
“Uh, but…”
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori434"]
[OnName num="Shiori"]
“Here, take this…”
[cpg cn=true]

Shiori reached into her pocket again and held out a packet of sweets.
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna354"]
[OnName num="Yuna"]
“I got it… Um, Shiori…”
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori435"]
[OnName num="Shiori"]
"Yes?"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna355"]
[OnName num="Yuna"]
“I'm sorry for everything I've done…"
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori436"]
[OnName num="Shiori"]
“It’s okay… I’ll see you later…”
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna356"]
[OnName num="Yuna"]
"Be careful..."
[cpg cn=true]

After sending Yuna to the basement, Shiori headed for the women's restroom.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_wt_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・女子トイレ　昼（窓から光）******************************************************

[WAIT time=1500]

[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Shiori437"]
[OnName num="Kotoha"]
"Did you do it? Then, you can rest.”
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori438"]
[OnName num="Shiori"]
“Yeah… Hey, Kotoha…”
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori439"]
[OnName num="Kotoha"]
"What?"
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori440"]
[OnName num="Shiori"]
“Why is the doctor dead…?”
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori441"]
[OnName num="Kotoha"]
“Something probably happened that made her want to die?”
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori442"]
[OnName num="Shiori"]
"Why...?"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori443"]
[OnName num="Kotoha"]
“It's okay. There are plenty of other doctors out there. We can look for them together when this is over."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori444"]
[OnName num="Kotoha"]
“Then, I’ll go…”
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Shiori445"]
[OnName num="Shiori"]
"Yeah..."
[cpg cn=true]

[SE f="se099"]
;//【ＳＥ】ビチャッ

;//＠
;//画面赤く染まる

[free time=2000]
[BG f="red.ui" time=2000]
[WAIT time=3000]
;//【ＢＧ】レッドアウト
;//エフェクト
[window target=false]
[transition target={true} rule="amamori2.png" color={0xff0000ff} time=2000]
[BG f="red.ui" time=500]
[transition target={false} color={0xff0000ff} time=500]
[WAIT time=800]
[BG f="black.ui" time=2000]
[WAIT time=2000]
[transition target={true} rule="101.jpg" color={0x000000ff} time=100]
[WAIT time=100]

[STOPBGM]
;//追加開始前にメッセージウィンドウを消してるので追加分岐の外で表示に切り替える
;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～
*j12_c|A Massacre


[free time=2000]
[BG f="black.ui" time=2000]
[WAIT time=3000]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン閉／蝋燭）******************************************************

[window target=true]

[transition target={false} rule="101.jpg" color={0x000000ff} time=2000]
[WAIT time=3000]
[BGM f="huan"]

[FG f="CHA06_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko259"]
[OnName num="Syouko"]
"Since that happened to the doctor, I'll be brief and clear."
[cpg cn=true]

When Shoko entered the infirmary, she turned firmly to me, wiped her tears, and spoke.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko260"]
[OnName num="Syouko"]
"The one behind everything is…Shiori."
[cpg cn=true]

[OnName num="Kenji"]
“W-what?! What’re you saying?!”
[cpg cn=true]

I raised my voice to argue, explaining how weak Shiori was and how pitiful she was.
[cpg]

But unlike before, Shoko didn't budge.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko261"]
[OnName num="Syouko"]
"Look at this. I found it in this room."
[cpg cn=true]

[OnName num="Kenji"]
“Huh...?”
[cpg cn=true]

What Shoko handed over was a scrapbook.
[cpg]

[SE f="se026"]
;//【ＳＥ】ページ捲る

[WAIT time=1000]

Inside, there were newspaper articles and foreign magazine articles carefully cut and pasted on every page.
[cpg]

All of them were articles about a young doctor named Michi Kisaragi.
[cpg]

"The closest Japanese psychiatrist to winning a Nobel Prize."
[cpg]

[OnName num="Kenji"]
"Psychiatrist? Michi is in internal medicine…"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko262"]
[OnName num="Syouko"]
“As far as I can tell, it doesn’t seem so…”
[cpg cn=true]

Shoko told me that she had only been able to read the articles in Japanese, but she gave me a quick rundown of the contents.
[cpg]

She had been called a child prodigy in other countries and obtained several doctorates in her early twenties.
[cpg]

Among other things, she was a psychiatrist who made various achievements and then disappeared, saying she was going back to Japan.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko263"]
[OnName num="Syouko"]
"She must have been hired by Mr. Tokita in Japan."
[cpg cn=true]

[OnName num="Kenji"]
“What was Shiori's grandfather doing, hiring a psychiatrist?”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko264"]
[OnName num="Syouko"]
“That's why…he wanted to hire such a level-headed psychiatrist, isn't it?"
[cpg cn=true]

[OnName num="Kenji"]
"What do you mean?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko265"]
[OnName num="Syouko"]
“For Shiori, of course.”
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

Shoko's conclusion shocked me.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko266"]
[OnName num="Syouko"]
"According to this article, the doctor was also an excellent cardiac surgeon, and if anything, she was the least experienced in internal medicine."
[cpg cn=true]

[VOICE f="Syouko1266"]
[OnName num="Syouko"]
"And it's true that Shiori's heart is bad…, so I think it was necessary to get a doctor who could treat both of them."
[cpg cn=true]

[OnName num="Kenji"]
"Wait a minute. I'm sure she was hired for her skills as a cardiac surgeon, and psychiatry just happened to be her specialty…"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko267"]
[OnName num="Syouko"]
“Hiring two doctors would make it that much easier for information to leak out. Mr. Tokita didn't want people to know about Shiori's mental illness. A disease like that…, a disease that could kill people."
[cpg cn=true]

[OnName num="Kenji"]
“How…”
[cpg cn=true]

Shoko seemed to be convinced that Shiori had killed someone because of her mental illness.
[cpg]

[OnName num="Kenji"]
“How…ridiculous…”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko268"]
[OnName num="Syouko"]
"At first I thought it was ridiculous, too, you know? But… there's only me, Kenji and Yuna left!”
[cpg cn=true]

[VOICE f="Syouko1268"]
[OnName num="Syouko"]
“Who else but Shiori would go around killing people?”
[cpg cn=true]


[OnName num="Kenji"]
"Ah, th-that's…?!"
[cpg cn=true]

If Shoko's hypothesis was correct, then Shiori and Yuna could be on the loose right now.
[cpg]

Even if Yuna was the killer and not Shiori, then Shiori would be in danger this time!
[cpg]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Syouko269"]
[OnName num="Syouko"]
“Ah…”
[cpg cn=true]

Shoko must have realized this by now, because we looked at each other and hurriedly left the doctor's office and ran up the stairs.
[cpg]

[SE f="se022"]
;//【ＳＥ】走る

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p2ex3.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　昼（天窓からの光）******************************************************



[OnName num="Kenji"]
“?!”
[cpg cn=true]

When I reached the top of the stairs, I immediately noticed something strange.
[cpg]

From the inside of the restroom to the entrance, there is a streak of red blood running down the joints of the tiles.
[cpg]

[OnName num="Kenji"]
“Shi, Shiori!!”
[cpg cn=true]

When I ran in, I found Shiori lying there.
[cpg]

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Syouko270"]
[OnName num="Syouko"]
“No way…!”
[cpg cn=true]

Shoko's hypothesis collapsed, and at that moment… Yuna was proven to be the murderer.
[cpg]

That half-crazed look, that clinging gaze, it was all an act…!
[cpg]

[free time=1000]

[OnName num="Kenji"]
“Shiori! Hold on! Shioriー!!”
[cpg cn=true]


I was truly ashamed that I had doubted her, even for a moment.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori446"]
[OnName num="Shiori"]
“Kenji…”
[cpg cn=true]

[OnName num="Kenji"]
“Are you okay?!”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori447"]
[OnName num="Shiori"]
"Yeah… I'm just a little...dizzy...is all."
[cpg cn=true]

[OnName num="Kenji"]
“Shoko! What’s this all about?!”
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Syouko271"]
[OnName num="Syouko"]
“Huh?! Aaa…um…eh? Huh?”
[cpg cn=true]

Shoko was being Shoko, confused and utterly useless.
[cpg]

[OnName num="Kenji"]
“We need to take care of this right away!”
[cpg cn=true]

I lent my shoulder to Shiori, who was holding her head, as we went down to the infirmary again.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン閉／蝋燭）******************************************************

[FG f="CHA06_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko272"]
[OnName num="Syouko"]
“Please… Let me examine your w-wound…”
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Shiori448"]
[OnName num="Shiori"]
“Ah, no…, it’s…scary so…I’ll do it myself.”
[cpg cn=true]

Perhaps because Shoko's hands were shaking, Shiori turned pale and picked up some tweezers.
[cpg]

[OnName num="Kenji"]
“Yeah, that would be better. For sure…”
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko273"]
[OnName num="Syouko"]
“Ugh…”
[cpg cn=true]

[FACE method="change_6" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori449"]
[OnName num="Shiori"]
“Um…, please don’t look at me…”
[cpg cn=true]

[free time=1000]
[WAIT time=1]
[FG f="CHA06_p3_01_a.ui" method="change_7" pos="4/5" time=1000]

Shiori got some medical tools together and closed the curtains.
[cpg]

I was surprised at the amount of blood, but relieved to see that the wound itself didn't seem too deep.
[cpg]

[OnName num="Kenji"]
“I hope it doesn't need stitches…."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko274"]
[OnName num="Syouko"]
“The head can bleed a lot from even the tiniest of wounds.”
[cpg cn=true]

Even if her wound needed stitches, Michi wasn’t here anymore.
[cpg]

I wasn't sure if I should talk to Shiori shiori about it or not, but if she was there, she must have inevitably witnessed Michi's hanging body.
[cpg]


[VOICE f="Shiori450"]
[OnName num="Shiori"]
"Why…did the doctor commit suicide…?"
[cpg cn=true]

From behind the curtain, I could hear Shiori sobbing along with the sound of gauze being cut.
[cpg]

[OnName num="Kenji"]
“I don’t know…”
[cpg cn=true]

Why did Michi take her own life, or was it murder disguised as suicide?
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko275"]
[OnName num="Syouko"]
"Shiori… Um… Please don't be offended. The doctor was a psychiatrist, wasn't she…?"
[cpg cn=true]


[VOICE f="Shiori451"]
[OnName num="Shiori"]
“Where did you hear that…?”
[cpg cn=true]

Shiori remained silent behind the curtain when Shoko asked.
[cpg]

[OnName num="Kenji"]
"I've never been able to ask you this before..., What's wrong with you…?"
[cpg cn=true]


[VOICE f="Shiori452"]
[OnName num="Shiori"]
“Heart problems…, asthma…"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko276"]
[OnName num="Syouko"]
"But! What about that medicine…, the one that the doctor was ordering from overseas?"
[cpg cn=true]

Even though I couldn't see Shiori's grief-stricken face, I could sense how she felt and I elbowed Shoko in the arm.
[cpg]


[VOICE f="Shiori453"]
[OnName num="Shiori"]
"That medicine is just a mood stabilizer… Ever since grandfather passed away…, I have been a little depressed, and the doctor said that…it was bad for my body."
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko277"]
[OnName num="Syouko"]
“Oh, a stabilizer?! That’s what it was…”
[cpg cn=true]

[OnName num="Kenji"]
"What the hell do you mean, ‘oh’?"
[cpg cn=true]

I scolded Shoko, so Shiori wouldn't hear.
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko278"]
[OnName num="Syouko"]
“S-sorry…, It's true that certain medications have multiple uses. Viagra is a heart drug, but it’s more popular for down there, right?”
[cpg cn=true]

Useless...
[cpg]

That word perfectly describes Shoko right now.
[cpg]

[SE f="se042"]
;//【ＳＥ】カーテン開く


;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）

;//[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/5" time=800]


;//頭にガーゼを止めた栞（時間無いので、現状は栞の立ち絵は非表示で。）
As we were whispering to each other, Shiori, who had finished treating herself, opened the curtain.
[cpg]

The blood-soaked gauze looked painful, but I was glad to know it was nothing too serious.
[cpg]

[OnName num="Kenji"]
"Anyway that means…, the one behind this was…"
[cpg cn=true]

[FG f="CHA06_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko279"]
[OnName num="Syouko"]
“You mean Yuna, right…?”
[cpg cn=true]

Was that really true…?
[cpg]

I asked Shiori if she had seen who did it, but she said she didn't know because she was hit from behind.
[cpg]

Was there a reason why she wasn't just killed, like Erika?
[cpg]

[OnName num="Kenji"]
“However, it's not hard to understand why Yuna would become deranged and violent, considering the state she was in, but she must have still been her normal self when Takagi and Hosokawa were still here…”
[cpg cn=true]

[OnName num="Kenji"]
“And I don't think Yuna had anything against those two…"
[cpg cn=true]

When I said as much, Shoko spoke up.
[cpg]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko280"]
[OnName num="Syouko"]
“But she did hold a grudge against Erika!”
[cpg cn=true]

[OnName num="Kenji"]
“I don't think she resented her enough to kill her… And besides, Yuna and I were in the hallway together when Erika died. So how could she cut off her head?"
[cpg cn=true]

;//[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/5" time=800]
;//[WAIT time=100]
[VOICE f="Shiori454"]
[OnName num="Shiori"]
"Ugh..."
[cpg cn=true]

[OnName num="Kenji"]
“Ah, sorry…”
[cpg cn=true]

I guess my words made her feel worse, because Shiori turned around, holding her mouth.
[cpg]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko281"]
[OnName num="Syouko"]
“A murder in a locked room!”
[cpg cn=true]

[OnName num="Kenji"]
“That's true… Rather, the building itself is locked down.”
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko282"]
[OnName num="Syouko"]
“Ah…”
[cpg cn=true]

Useless…!
[cpg]

;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/5" time=800]
;//[WAIT time=100]
[VOICE f="Shiori455"]
[OnName num="Shiori"]
"Um…, where is Yuna now…?"
[cpg cn=true]

[OnName num="Kenji"]
“Ah.”
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko283"]
[OnName num="Syouko"]
“Ah.”
[cpg cn=true]

Aside from the other murders, there was no doubt that Yuna was the one who attacked Shiori.
[cpg]

If we didn't find her soon, there's no telling what she  would do again.
[cpg]

[OnName num="Kenji"]
"I'll go look for her."
[cpg cn=true]

;//[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/5" time=800]
;//[WAIT time=100]
[VOICE f="Shiori456"]
[OnName num="Shiori"]
"But…, isn't that dangerous…?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko284"]
[OnName num="Syouko"]
“Then, I’ll go with you”!
[cpg cn=true]

[OnName num="Kenji"]
"What are you talking about! You can't leave Shiori alone, wounded like this!"
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko285"]
[OnName num="Syouko"]
“Y-you're right…”
[cpg cn=true]

[OnName num="Kenji"]
"Okay? If Yuna comes around, just yell. You’re okay now, right Shiori?"
[cpg cn=true]

;//[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/5" time=800]
;//[WAIT time=100]
[VOICE f="Shiori457"]
[OnName num="Shiori"]
"Yeah..."
[cpg cn=true]

I left the two of them in the infirmary and decided to look for Yuna.
[cpg]

;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="tobira2.png" color={0x000000ff} time=2000]
[WAIT time=2000]



;//【ＢＧ】ブラックアウト
[free time=100]
[BG f="black.ui" time=100]



[if exp={ isSystemFlagsEnabled( "end1", "end2", "end3", "end4", "end5") }]
[jump target="*j13_a"]
[else]
[jump target="*j13_c"]
[endif]

;//※エンド制覇で、以下破線内のシーン挿入
;//<追加・始>～～～～↓～～～～↓～～～～↓～～～～
*j13_a|A Massacre


[BG f="b_l_b1_disp_0.ui" time=100]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）******************************************************
[WAIT time=1500]
[transition target={false} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=3100]
[window target=true]

[BGM f="silent"]

[FG f="CHA06_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Syouko286"]
[OnName num="Syouko"]
"Aaah, Shiori…, You've got blood all over your gauze."
[cpg cn=true]

;//[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/5" time=800]
;//[WAIT time=100]
[VOICE f="Shiori458"]
[OnName num="Shiori"]
"Oh really…?"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko287"]
[OnName num="Syouko"]
"You'll have to bandage it, here. Don't worry, I'll take care of it!"
[cpg cn=true]

;//[FACE method="change_1" pos="2/5"]
;//[WAIT time=100]
[VOICE f="Shiori459"]
[OnName num="Shiori"]
"Yes…, please…"
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko288"]
[OnName num="Syouko"]
"Okay!"
[cpg cn=true]

[SE f="se137"]
;//【ＳＥ】紙テープ剥がす

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko289"]
[OnName num="Syouko"]
"Sorry~ I just assumed that Shiori was the culprit... But I was wrong. I'm really sorry!"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori460"]
[OnName num="Shiori"]
"That’s alright…"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko290"]
[OnName num="Syouko"]
"So, let's disinfect the wound again… Huh?"
[cpg cn=true]

[SE f="se137"]
;//【ＳＥ】ゴソゴソ

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori461"]
[OnName num="Shiori"]
"What’s wrong…?”
[cpg cn=true]

[STOPBGM]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko291"]
[OnName num="Syouko"]
“There’s…no wound.”
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori462"]
[OnName num="Shiori"]
"....................."
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko292"]
[OnName num="Syouko"]
“What… What’s the meaning of this…?”
[cpg cn=true]

;//？？？
[VOICE f="Shiori463"]
[OnName num="unknown"]
“Here’s what it means.”
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Syouko293"]
[OnName num="Syouko"]
"?!"
[cpg cn=true]

[SE f="se045"]
;//【ＳＥ】ボカッ！！

;//☆死亡
;//章子死亡

[STOPBGM]
[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=500]
[WAIT time=2000]
;//【ＢＧ】ブラックアウト
[free time=100]
[BG f="black.ui" time=100]

;//追加開始前にメッセージウィンドウを消してるので追加分岐の外で表示に切り替える
;//<追加・完>～～～～↑～～～～↑～～～～↑～～～～
*j13_c|A Massacre


[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗／懐中電灯）******************************************************

[transition target={false} rule="101.jpg" color={0x000000ff} time=2000]
[WAIT time=3100]
[window target=true]

[BGM f="huan"]

When I left the infirmary, I checked the storage room first.
[cpg]

[SE f="se136"]
;//【ＳＥ】ドア開ける

[BG f="b_l_b1_lr_0.ui" time=1000]
;//【ＢＧ】図書館・地下・書庫　（暗／懐中電灯）

Other than the blanket Shoko had been sleeping on, there were only books on the floor.
[cpg]

[SE f="se009"]
;//【ＳＥ】ドア閉める


[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗／懐中電灯）******************************************************

Next was the pantry...
[cpg]

[SE f="se136"]
;//【ＳＥ】ドア開ける


[BG f="b_l_b1_ware_0.ui" time=1000]
;//【ＢＧ】図書館・地下・非常用倉庫　（暗／懐中電灯）******************************************************

The room that was completely devoid of food.
[cpg]

It was sad...
[cpg]

[SE f="se009"]
;//【ＳＥ】ドア閉める


[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗／懐中電灯）******************************************************

And inside was…
[cpg]

[SE f="se137"]
;//【ＳＥ】ガサッ

[STOPBGM]

[OnName num="Kenji"]
“Hmm? Yuna…? Are you in there?!”
[cpg cn=true]

[SE f="se072"]
;//【ＳＥ】ノック

[WAIT time=3000]

I knocked, but there was no answer.
[cpg]

I didn’t want to think so, but she could be dead inside…
[cpg]

I got scared and flung the door open.
[cpg]

[SE f="se136"]
;//【ＳＥ】ドア開ける



[BG f="b_l_b1_ware_0.ui" time=1000]
;//【ＢＧ】図書館・地下・非常用倉庫　（暗／懐中電灯）

[WAIT time=1500]

[BGM f="danger"]

[FG f="CHA04_p3_01_a.ui" method="change_3" pos="2/3" time=800]


[VOICE f="Yuna357"]
[OnName num="Yuna"]
“Stay backー!!”
[cpg cn=true]

[SE f="se111"]
;//【ＳＥ】ブンブンブンッ！

[OnName num="Kenji"]
"?!"
[cpg cn=true]

As soon as I opened the door, Yuna attacked me, wielding a blade.
[cpg]


[VOICE f="Yuna358"]
[OnName num="Yuna"]
“Don’t come any closerー!!”
[cpg cn=true]

[SE f="se111"]
;//【ＳＥ】ブンブンブン！

[OnName num="Kenji"]
"Yuna! I knew you were the one who killed them all!"
[cpg cn=true]

I couldn't believe it.
[cpg]

But the Yuna I saw was not the Yuna I knew, but a full-blown murderer.
[cpg]


[VOICE f="Yuna359"]
[OnName num="Yuna"]
“Aaaaaaahhhー!!”
[cpg cn=true]

[OnName num="Kenji"]
“S-stopー!”
[cpg cn=true]

[SE f="se115"]
;//【ＳＥ】ドタンバタン！

I grabbed Yuna's arm as she attacked me, and fought hard to keep from being stabbed.
[cpg]

[SE f="se115"]
;//【ＳＥ】ドタンバタン！



;//[BG f="black.ui" time=900]
;//[WAIT time=1500]
;//[BG f="b_l_b1_ware_0.ui" time=1000]
;//【ＢＧ】図書館・地下・非常用倉庫　（暗／懐中電灯）

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna360"]
[OnName num="Yuna"]
“Waaaaaaaahー!!”
[cpg cn=true]

[OnName num="Kenji"]
“Nooooooー!!”
[cpg cn=true]

I wondered how long we had been struggling...
[cpg]

She must have run out of steam, because suddenly Yuna's hand relaxed, and it looked like I was safe for now.
[cpg]

[OnName num="Kenji"]
"Huh?!"
[cpg cn=true]

[SE f="se099"]
;//【ＳＥ】ブスッ！

[STOPBGM]

;//＠
;//レッドアウト
[transition target={true} rule="amamori2.png" color={0xff0000ff} time=2000]
[WAIT time=2000]
[free time=1]
[BG f="red.ui" time=1]
[WAIT time=1]
[transition target={false} rule="amamori2.png" color={0xff0000ff} time=1]
[WAIT time=1000]
;//☆死亡
;//柚那死亡

;//ホビ提出版では立ち絵で処理

[BG f="b_l_b1_ware_0.ui" time=1000]
[FG f="CHA04_p3_01_a.ui" method="change_3" pos="2/3" time=1000]

;//[free time=1000]
;**【ＣＧ】ci_06_0 ***********************
;//カットイン
[CUTIN f="ci_06_0.ui" show={true} method="slidein"]
;*****************************************


[WAIT time=1500]


[BGM f="huan"]


[VOICE f="Yuna361"]
[OnName num="Yuna"]
“Agh!”
[cpg cn=true]

[OnName num="Kenji"]
“N-no way…”
[cpg cn=true]

It was an accident.
[cpg]

My hand had twisted around Yuna's hand, which was holding the blade.
[cpg]

The blade plunged into Yuna's stomach.
[cpg]

Blood was dripping down.
[cpg]

It gradually made even my hands red and wet
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Yuna362"]
[OnName num="Yuna"]
“Murderer…ugh…”
[cpg cn=true]

[CUTIN f="ci_06_0.ui" show={false} method="slideout"]

[SE f="se035"]
;//【ＳＥ】倒れる

[free time=900]
;//[BG f="black.ui" time=900]
;//[WAIT time=1500]
;//[BG f="b_l_b1_ware_0.ui" time=1000]
;//【ＢＧ】図書館・地下・非常用倉庫　（暗／懐中電灯）******************************************************

[WAIT time=1500]

[OnName num="Kenji"]
“Uh…Aaaaaah!”
[cpg cn=true]

Yuna collapsed in front of me, coughing up blood from her mouth.
[cpg]

The stench of blood filled the windowless basement…
[cpg]

I stared at my own bloodied hands and felt like I was going insane.
[cpg]

I killed her...
[cpg]

I killed Yuna...
[cpg]

But…, still…
[cpg]

[OnName num="Kenji"]
“With this…, it’s over.”
[cpg cn=true]

No more being scared of some unknown killer.
[cpg]

Now all I had to do was wait with Shiori and Shoko for help to arrive.
[cpg]

Those two would never be as crazy or violent as Yuna was.
[cpg]

No matter how hungry they were, no matter how cold it got…
[cpg]

With that in mind, I dragged my exhausted body back to the infirmary.
[cpg]

I have to be honest and tell them that I killed Yuna…
[cpg]

[SE f="se136"]
;//【ＳＥ】ドア開ける

[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）******************************************************

[WAIT time=1500]

;//☆死亡
;//章子死亡

;//[free time=1000]
;**【ＣＧ】ci_07_0 ***********************
;//カットイン
[CUTIN f="ci_07_0.ui" show={true} method="slidein"]
;*****************************************

[WAIT time=1000]



[OnName num="Kenji"]
"...huh?"
[cpg cn=true]


;//[VOICE f="Syouko294"]
[OnName num="Syouko"]
".................."
[cpg cn=true]

When I opened the door to the infirmary, I found Shoko lying on the floor.
[cpg]

Her limbs were sprawled out, and her head was bleeding profusely, and she didn't move a muscle.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7" pos="5/5" time=800]


[VOICE f="Shiori464"]
[OnName num="Shiori"]
“Kenji…”
[cpg cn=true]

Beside Shoko's corpse was Shiori, standing quietly
[cpg]

Shiori…did this?
[cpg]

[OnName num="Kenji"]
"Why...?"
[cpg cn=true]

My head felt fuzzy from hunger.
[cpg]

I don’t know what happened and couldn’t even imagine how it happened.
[cpg]

[CUTIN f="ci_07_0.ui" show={false} method="slideout"]


;//[BG f="b_l_b1_disp_0.ui" time=1000]
;//【ＢＧ】図書館・地下・医務室　（暗／カーテン開／蝋燭）


[move from="5/5" to="2/3" ease="easeInOutSine" time=1000]


As Shiori approached me, she started to explain.
[cpg]

Like it was a dream, she was quietly coming closer and closer… little by little.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori465"]
[OnName num="Shiori"]
“Kenji…, You said…you loved me…”
[cpg cn=true]

[OnName num="Kenji"]
“Uh…, W-well…”
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori466"]
[OnName num="Shiori"]
"You’re just like all the others... So, I…don't need you anymore…"
[cpg cn=true]

[OnName num="Kenji"]
"Wait..., no. I didn’t mean to…"
[cpg cn=true]

While I was making excuses, Shiori was getting closer and closer.
[cpg]

While staring straight into my glazed eyes….
[cpg]

[FG f="CHA01_p5_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori467"]
[OnName num="Shiori"]
“I liked your kind and beautiful heart too… I didn't just like your body, I liked your heart as well…"
[cpg cn=true]

Drop...
[cpg]


A single tear fell from Shiori's beautiful eyes.
[cpg]

Just one thing…
[cpg]

[OnName num="Kenji"]
“Shiori, listen to me. I really do!”
[cpg cn=true]

I clutched my chest and tried to express my feelings from the bottom of my heart.
[cpg]

Then I felt the package in my breast pocket with my hand and remembered.
[cpg]

[OnName num="Kenji"]
"That's right. This was a Christmas present for you!"
[cpg cn=true]

I held out the gift to Shiori, it was a symbol of my love for her.
[cpg]

But whether Shiori saw it or not, she just shook her head slowly.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori468"]
[OnName num="Shiori"]
"Forget it. I don't need you, but there are people who still love you, even if it's just for your body..."
[cpg cn=true]

[OnName num="Kenji"]
"What? W-where?"
[cpg cn=true]

;//？？？

[VOICE f="Shiori469"]
[OnName num="unknown"]
"Right here..."
[cpg cn=true]

[SE f="se045"]
;//【ＳＥ】ボカッ！！

[WAIT time=1500]

;//＠
;//レッドアウト
[transition target={true} rule="amamori2.png" color={0xff0000ff} time=2000]
[WAIT time=2000]
[free time=1]
[BG f="red.ui" time=1]
[WAIT time=1]
[transition target={false} rule="amamori2.png" color={0xff0000ff} time=1]
[WAIT time=2000]



;//【ＢＧ】図書館・地下・医務室　（真赤／カーテン開／横向き）

;//画面赤く染まる
I felt a blow to the back of my head and my vision instantly turned red.
[cpg]

There is no doubt that this is the best way to go.
[cpg]

I've been hit...by someone who needs me.
[cpg]

[OnName num="Kenji"]
"Who...?"
[cpg cn=true]

There was...someone else...besides Shiori.
[cpg]

;//【ＢＧ】ブラックアウト
[free time=1500]
[BG f="black.ui" time=1500]
[WAIT time=3500]

[system end2=true]
[SCENE id=18]

[stopse g=1]
;//ボイス
[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

;//ＥＮＤ『ミナゴロシ』
;**【ＥＮＤ】　　　　********************************
[jump storage="epend.ks" target="*start"]
;****************************************************


;// 
;//＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
