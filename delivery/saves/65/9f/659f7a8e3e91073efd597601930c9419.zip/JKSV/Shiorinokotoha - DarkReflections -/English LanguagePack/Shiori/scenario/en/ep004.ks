*start

;#################################################
*Ep004|The Incident
;#################################################
[SCENE id=4]

The Next Day...
[cpg]


[SE f="se135"]
;//【ＳＥ】『タイプライター』

December 17th
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_nbr_p2.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（電灯）******************************************************

[BGM f="library"]

[WAIT time=1500]

;//机
[FG f="CHA07_p3_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Hosokawa013"]
[OnName num="Hosokawa"]
"It's..."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi012"]
[OnName num="Takagi"]
"That's right..."
[cpg cn=true]

When I came to the library as usual, Takagi and Hosokawa were already whispering at their desks that day.
[cpg]

As soon as they entered the library, Erika and Yuna oddly went straight to the room with special reference books, so there were a few familiar faces here.
[cpg]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa014"]
[OnName num="Hosokawa"]
“It’s almost time..”
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi013"]
[OnName num="Takagi"]
”Right..."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa015"]
[OnName num="Hosokawa"]
“...before she makes any other plans.”
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi014"]
[OnName num="Takagi"]
“I know, right…”
[cpg cn=true]

[OnName num="Kenji"]
"......?"
[cpg cn=true]

It was hard not to eavesdrop in such a quiet space.
[cpg]

If I sat close enough, I could naturally overhear the conversation without even trying to listen in.
[cpg]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa016"]
[OnName num="Hosokawa"]
"Christmas is a special day for women. As much as I'd like to surprise her on the day, I think it's better to ask her out beforehand…"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi015"]
[OnName num="Takagi"]
"If she agrees to Christmas dinner, it means she agrees to everything else, so you have to do your best to invite her out…”
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa017"]
[OnName num="Hosokawa"]
"I'd better get a present too…”
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi016"]
[OnName num="Takagi"]
"How much are you going to spend?"
[cpg cn=true]

Hey...
[cpg]

Hey, hey, hey, hey! Hold on. Wait a second!
[cpg]

Doesn't this mean these guys are probably thinking the same thing as me?!
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa018"]
[OnName num="Hosokawa"]
"You're fine. I'm dealing with an actual doctor, so my budget is through the roof."
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi017"]
[OnName num="Takagi"]
"What are you talking about? Mine's a lady of wealth."
[cpg cn=true]

Oh, man...
[cpg]

I didn't even pay attention to the price of the gift.
[cpg]

I mean… I already bought it…
[cpg]

I held the gift in my hand, while it was still in the breast pocket of my jacket.
[cpg]

I wanted to keep it on me until Christmas came, so I put it in my pocket.
[cpg]

It was inexpensive and small, it was nothing special.
[cpg]

But I may have picked it out too quickly...
[cpg]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa019"]
[OnName num="Hosokawa"]
"Today's the day I'm going to be brave enough to ask her out."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi018"]
[OnName num="Takagi"]
"Yeah. I'll do my best too."
[cpg cn=true]

[free time=800]
Don't try so hard, please.
[cpg]

I pretended to be reading a book, but my ears perked up and I was getting impatient.
[cpg]

What to do?
[cpg]

Like this, he'll get to ask first.
[cpg]

I wasn't sure about Hosokawa, but Takagi was definitely my rival.
[cpg]

He wasn't the popular type, but having no idea what Shiori thought of him made me feel uneasy.
[cpg]

I mean, there was a possibility that she would end up going on a double date with Michi, even if only for dinner after the library closed.
[cpg]

I couldn't let that happen!
[cpg]

[SE f="se010"]
;//【ＳＥ】席を立つ（ガタン）

[free time=400]

I had to make the first move.
[cpg]

I headed straight for the counter.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[OnName num="Kenji"]
"Excuse me!"
[cpg cn=true]

............?
[cpg]

Shiori seemed surprised when I suddenly called out to her, but then she looked up.
[cpg]

Her eyes opened a little wider than usual and her exquisite upward gaze shot through my heart with a thud...at least that's what it felt like.
[cpg]

[OnName num="Kenji"]
"...huh!?"
[cpg cn=true]

Shiori stared at me, and my mind was already going blank.
[cpg]

At this point, I couldn't even speak my native language.
[cpg]

[OnName num="Kenji"]
"Uh, u-um, C...chri...christmas!"
[cpg cn=true]

What was I even saying?
[cpg]

Get it together, mouth!
[cpg]

[FACE method="change_7" pos="2/3"]
............?
[cpg]

Shiori's expression became more and more suspicious as she watched me in a state of confusion.
[cpg]

[OnName num="Kenji"]
"F-f-food!"
[cpg cn=true]

............?
[cpg]

[OnName num="Kenji"]
"Do you like food?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori025"]
[OnName num="Shiori"]
"...yes."
[cpg cn=true]

[OnName num="Kenji"]
"Me too!"
[cpg cn=true]

Shiori looked at me accusingly as I yelled out.
[cpg]

[OnName num="Kenji"]
"I'm s-sorry..."
[cpg cn=true]

Aaah~...it's all over.
[cpg]

What happened?
[cpg]

My mind was agonizing over too many things, but why couldn't I find the right words?
[cpg]

It should have been easy.
[cpg]

Like asking Erika or Yuna out to dinner.
[cpg]

"Let's go out for dinner ♪ What do you want to eat?"
[cpg cn=true]

That was all I needed to say.
[cpg]


Why was it so difficult to ask Shiori?
[cpg]

[FG f="CHA07_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Takagi019"]
[OnName num="Takagi"]
"Shiori-kins, you got a minute?"
[cpg cn=true]

While I was panicking, Takagi finally arrived, his belly shaking.
[cpg]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Takagi020"]
[OnName num="Takagi"]
"You know, it's almost Christmas, right? How about having dinner with me on Christmas Eve?"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori026"]
[OnName num="Shiori"]
"Uh..."
[cpg cn=true]

Shiori was puzzled by Takagi's slurred words.
[cpg]

This guy...looked like an antisocial nerd at first glance, so how could he ask her out so easily...
[cpg]

My heart was filled with a sense of defeat.
[cpg]

Compared to my attempt, no wonder Takagi could take Shiori away from me.
[cpg]

Oh, God...
[cpg]

I prayed to the heavens for some guidance....
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
.........
[cpg]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Takagi021"]
[OnName num="Takagi"]
"What do you say?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
.........
[cpg]

Takagi propped both elbows on the counter and looked into Shiori's confused face.
[cpg]

If this were a drama or a movie, I'd be able to gallantly say, "Stop it!", but I'm not sure I'm in the right position to actually do that.
[cpg]

I wasn't sure if I was the star of this drama called reality, or if Takagi actually was...
[cpg]


[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Takagi022"]
[OnName num="Takagi"]
"Do you already have plans?"
[cpg cn=true]

.........
[cpg]

When I looked at her fearfully, I saw that her eyes were swimming in water.
[cpg]

And then her right hand looked like it was floating above the counter...
[cpg]

[SE f="se008"]
;//【ＳＥ】チンベル（チーン！）

[WAIT time=1000]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Takagi023"]
[OnName num="Takagi"]
"Uhhh"
[cpg cn=true]

[OnName num="Kenji"]
"Huh"
[cpg cn=true]

The call bell rang loudly.
[cpg]


Takagi and I looked like pigeons that had been hit by a peashooter.
[cpg]



[FG f="CHA05_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi034"]
[OnName num="Michi"]
"Yes, what is it?"
[cpg cn=true]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Takagi024"]
[OnName num="Takagi"]
"Eh."
[cpg cn=true]

[OnName num="Kenji"]
"Oh."
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi035"]
[OnName num="Michi"]
"Hmm?"
[cpg cn=true]

Michi appeared behind us without a sound.
[cpg]

.........
[cpg]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Takagi025"]
[OnName num="Takagi"]
".................."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi036"]
[OnName num="Michi"]
"Oh, dear. What's wrong? Everyone's frozen."
[cpg cn=true]

Apparently, Shiori had summoned Michi because she was unable to deal with Takagi on her own.
[cpg]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi037"]
[OnName num="Michi"]
"Mr. Takagi? What happened?"
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Takagi026"]
[OnName num="Takagi"]
"I just invited Shiori-kins to dinner on Christmas Eve, that's all I did."
[cpg cn=true]

Takagi touched his lips with his finger, and spoke in an awkward tone.
[cpg]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi038"]
[OnName num="Michi"]
"I’m sorry. Unfortunately, Shiori is very weak, so it isn’t good for her to go out in the middle of winter. Would you mind inviting someone else?"
[cpg cn=true]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Takagi027"]
[OnName num="Takagi"]
"Oh..., I understand..."
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
Oh, really....
[cpg]

Then I guess I couldn't invite her out either.
[cpg]

Takagi was disappointed, but I was somewhat relieved.
[cpg]

But was this excuse really true?
[cpg]

I have a feeling that Michi just shot him down well.
[cpg]

If that was true, then Shiori should have been able to say it herself...
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa020"]
[OnName num="Hosokawa"]
"I see, I see..."
[cpg cn=true]

[OnName num="Kenji"]
"Ah...!"
[cpg cn=true]

Hosokawa had also crept up on us before we knew it.
[cpg]

He spoke coolly right next to Michi, who was elegantly standing there.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa021"]
[OnName num="Hosokawa"]
"I'm sorry to hear about Shiori, but what about your plans Ms. Kisaragi?"
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi039"]
[OnName num="Michi"]
"Me?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa022"]
[OnName num="Hosokawa"]
"What are your plans for Christmas Eve? If you'd like, we can have French..."
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi040"]
[OnName num="Michi"]
"Oh..."
[cpg cn=true]

Despite Hosokawa's calm tone, the speed at which his fingers were adjusting his glasses was several times faster than usual.
[cpg]

He was pretty nervous in his own way, but Michi did not seem to care.
[cpg]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi041"]
[OnName num="Michi"]
"I hate to tell you, but I have a lot of paperwork I need to wrap up this year, and I don't even have a second to spare."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[SE f="se025"]
;//【ＳＥ】ガーン
[WAIT time=1000]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa023"]
[OnName num="Hosokawa"]
"Oh, really...?"
[cpg cn=true]

Wow. "Not even a second to spare" she said.
[cpg]

She didn't leave room for any back and forth, and her refusal was so merciless that it was almost refreshing.
[cpg]

Seemed like Takagi and Hosokawa were going to spend Christmas alone, and this confirmed I would be too...
[cpg]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Michi042"]
[OnName num="Michi"]
"But it's business as usual here, so please enjoy yourselves as usual. Now, everyone, please return to your seats."
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Takagi028"]
[OnName num="Takagi"]
"Yes..."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa024"]
[OnName num="Hosokawa"]
"Yes..."
[cpg cn=true]

[OnName num="Kenji"]
"Yes..."
[cpg cn=true]

[free time=800]

After we had turned into a trio of idiots, we dragged ourselves back to our seats.
[cpg]


However, I might have been less wounded than these two.
[cpg]

No one knows if I would have been turned down.
[cpg]


[VOICE f="Michi043"]
[OnName num="Michi"]
"Was that okay?"
[cpg cn=true]

......
[cpg]

As I was leaving, I overheard them whispering to each other over my back.
[cpg]


[VOICE f="Michi044"]
[OnName num="Michi"]
"We'll celebrate Christmas just like any other year, right?"
[cpg cn=true]


[VOICE f="Shiori027"]
[OnName num="Shiori"]
"...yes. Grandfather used to love that..."
[cpg cn=true]


[VOICE f="Michi045"]
[OnName num="Michi"]
"Hehe, White stew. Leave it to me."
[cpg cn=true]


[VOICE f="Shiori028"]
[OnName num="Shiori"]
"The carrots... Make them small."
[cpg cn=true]


[VOICE f="Michi046"]
[OnName num="Michi"]
"Of course."
[cpg cn=true]

Shiori...didn't like carrots?
[cpg]

How cute.
[cpg]

When she talked to Michi, she was like a little kid.
[cpg]

Wait, stew?
[cpg]

Shiori's food, I wondered if Michi was always the one making it.
[cpg]

A family doctor does that much? Must be a lot of work.
[cpg]

I sat down and started flipping through the pages of my book, thinking about it....
[cpg]



[SE f="se026"]
;//【ＳＥ】ゆっくりとページめくられる
[WAIT time=2000]


[FG f="CHA07_p3_01_a.ui" method="change_7" pos="2/5" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Takagi029"]
[OnName num="Takagi"]
"I thought I was going on my first date ever in my life…"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa025"]
[OnName num="Hosokawa"]
"Don't be discouraged. There's cherry blossom viewing season in the spring and the chance to go swimming in summer. Never give up."
[cpg cn=true]

Those losers were whispering nearby.
[cpg]

It was a long-winded conversation.
[cpg]

But I couldn’t lose to that persistence.
[cpg]

I was going to get better at speaking to Shiori and ask her out when the weather warmed up.
[cpg]

[SE f="se026"]
;//【ＳＥ】ゆっくりとページめくられる
[WAIT time=1000]

Ah...
[cpg]

Hopeless.
[cpg]

I turned the page again before I could read it.
[cpg]

I needed to focus…, but then again, where did Erika and Yuna go?
[cpg]

[SE f="se026"]
;//【ＳＥ】ゆっくりとページめくられる
[WAIT time=1000]
[OnName num="Kenji"]
"Whew..."
[cpg cn=true]

As I've never been big on reading, a gentle wave of sleepiness came over me.
[cpg]

In the quiet, heated space, my eyelids were slowly getting heavier...
[cpg]

;//【ＢＧ】ブラックアウト（ゆっくり）
[free time=3000]
[BG f="black.ui" time=3000]
[WAIT time=3000]
[stopse g=1]
;//ボイス
[stopse g=2]
;//通常se
[stopse g=6]
;//ループse
[WAIT time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori029"]
[OnName num="Shiori"]
"Wow! Thank you! This is the first time I've received such a wonderful gift!"
[cpg cn=true]

[OnName num="Kenji"]
"I'm glad you like it."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori030"]
[OnName num="Shiori"]
"But I...didn't get you anything..."
[cpg cn=true]

[OnName num="Kenji"]
"Don't worry about it. In return, I have a favor to ask you."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori031"]
[OnName num="Shiori"]
"What?"
[cpg cn=true]

[OnName num="Kenji"]
"Spring, summer, fall, and next Christmas. I want the two of us to make memories."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori032"]
[OnName num="Shiori"]
"Oh, that's..."
[cpg cn=true]

[OnName num="Kenji"]
"Shiori, I'm in love...with-"
[cpg cn=true]

[STOPBGM]

;//＠ループ
[SE f="se027" loop=true]
;//【ＳＥ】けたたましい非常ベル
[WAIT time=2000]

[free time=400]
[BG f="b_l_1f_nbr_p2.ui" time=400]
;//【ＢＧ】図書館・１階・一般書の部屋　昼（電灯）******************************************************
[WAIT time=500]

[BGM f="danger"]

[OnName num="Kenji"]
"Wha...?!?!"
[cpg cn=true]

;//視界が開け、あたふたと右往左往する背景
My wonderfully idyllic dream was shattered by a mysterious rumbling sound.
[cpg]

I jumped up out of my chair and looked around in a panic.
[cpg]

[OnName num="Kenji"]
“W-what is this? An emergency bell? Fire!? Where!?”
[cpg cn=true]

A sound hundreds of times louder than any alarm clock, announced a state of emergency.
[cpg]

[OnName num="Kenji"]
"What the hell! What's going on? Where is everyone!"
[cpg cn=true]

There were definitely a few visitors in addition to the usual regulars, but they were nowhere to be seen.
[cpg]

In fact, somehow I was the only one in this room.
[cpg]

[SE f="se028"]
;//【ＳＥ】鉄の固まりが落下するような重たい衝撃音が数回


[WAIT time=3000]
[BG f="b_l_1f_nbr_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　夜（暗）******************************************************
;//※演出上この背景を使用


[OnName num="Kenji"]
"What?!"
[cpg cn=true]

The sound of impact, as if a very heavy object had fallen, echoed over and over, and the room instantly went completely dark.
[cpg]

[OnName num="Kenji"]
"Someoneー! Somebodyー!"
[cpg cn=true]

Unable to cope with this unusual situation, I could only shout from where I was.
[cpg]

Then...
[cpg]

[SE f="se029"]
;//【ＳＥ】バタバタ駆け込んで来て転倒×２名

[WAIT time=3000]


[OnName num="Kenji"]
"W-whatー?"
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_5" pos="4/5" time=800]
[FG f="CHA07_p3_01_a.ui" method="change_5" pos="2/5" time=800]
[WAIT time=100]
[VOICE f="Takagi030"]
[OnName num="Takagi"]
"Whoa! What, what, what! I can't see anything~!"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa026"]
[OnName num="Hosokawa"]
"Ow! You're too heavy! Get off of me!"
[cpg cn=true]

Apparently, Takagi and Hosokawa came running into the room and fell over.
[cpg]

Takagi had apparently landed on top of Hosokawa and all hell broke loose, but I was able to regain my composure at once.
[cpg]

[OnName num="Kenji"]
"Takagi! Hosokawa! What in the hell happened?"
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi031"]
[OnName num="Takagi"]
"I d-don't know!"
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa027"]
[OnName num="Hosokawa"]
"We were coming back from the restroom when the emergency bell suddenly rang, and quickly tried to get out, but the front door wouldn’t open!”
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi032"]
[OnName num="Takagi"]
“Not only that! It looks like the shutters have closed on the windows too!"
[cpg cn=true]

[OnName num="Kenji"]
"You’re kidding!?"
[cpg cn=true]

Was that the reason for all this darkness?
[cpg]

There weren't many windows in this library to begin with, and each window was very small.
[cpg]

I had been relying on indirect lighting for all my lighting, but now that was also gone, and it was discouraging.
[cpg]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi033"]
[OnName num="Takagi"]
"This is bad. It must be a fire, I'm sure."
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa028"]
[OnName num="Hosokawa"]
"Calm down! We don't know that for sure yet."
[cpg cn=true]

We didn't know anything for sure, but wouldn't it be bad for security to have the door locked in an emergency?
[cpg]

If there was a fire, we wouldn't be able to escape and we'd all burn to death!
[cpg]

;//＠
;//非常ベル停止

[stopse g=6]
;//ループse
[STOPBGM]

[WAIT time=1000]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi034"]
[OnName num="Takagi"]
"Oh, it stopped."
[cpg cn=true]


While we were messing around, the emergency bell stopped.
[cpg]

[BGM f="serious"]

[OnName num="Kenji"]
"We're saved..."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="5/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7" pos="6/3" time=800]


It was almost impossible to talk with that alarm going off the whole time.
[cpg]

;//【ＢＧ】図書館・１階・一般書の部屋　昼（暗／懐中電灯２本）

[move from="2/5" to="1/4" ease="easeInOutSine" time=1000]
[move from="4/5" to="2/4" ease="easeInOutSine" time=1000]
[move from="5/3" to="3/4" ease="easeInOutSine" time=1000]
[move from="6/3" to="4/4" ease="easeInOutSine" time=1000]
[WAIT time=100]
[VOICE f="Michi047"]
[OnName num="Michi"]
"Is everyone okay?"
[cpg cn=true]

[OnName num="Kenji"]
"Oh, Michi!"
[cpg cn=true]

I was completely relieved when the two round lights coming towards us in the dark turned out to be Michi and Shiori's flashlights.
[cpg]

[FACE method="change_7" pos="2/4"]
[WAIT time=100]
[VOICE f="Hosokawa029"]
[OnName num="Hosokawa"]
"What's this all about?"
[cpg cn=true]

[OnName num="Kenji"]
"Is there a fire?"
[cpg cn=true]

[FACE method="change_4" pos="1/4"]
[WAIT time=100]
[VOICE f="Takagi035"]
[OnName num="Takagi"]
"Help! I don't want to die!"
[cpg cn=true]

[FACE method="change_3" pos="3/4"]
[WAIT time=100]
[VOICE f="Michi048"]
[OnName num="Michi"]
"I think it's just a malfunction in the security system. So please remain calm. I'll check it out right away..."
[cpg cn=true]

[OnName num="Kenji"]
"Ah, then I'm coming with you!"
[cpg cn=true]

Shiori hid behind Michi, frightened.
[cpg]

I took the flashlight from her hand and left the room.
[cpg]

[FACE method="change_5" pos="1/4"]
[WAIT time=100]
[VOICE f="Takagi036"]
[OnName num="Takagi"]
"Don't leave me in a dark room~"
[cpg cn=true]

[FACE method="change_3" pos="2/4"]
[WAIT time=100]
[VOICE f="Hosokawa030"]
[OnName num="Hosokawa"]
"We should go too."
[cpg cn=true]

The five of us headed for the entrance, relying on the two flashlights.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BGM f="d1"]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗い／鎧が懐中電灯に照らされる）******************************************************

[WAIT time=1000]


[FG f="CHA07_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Takagi037"]
[OnName num="Takagi"]
''Squeeeeeー!"
[cpg cn=true]

Seeing the flashlights shine on the armor, Takagi screamed like a pig being strangled.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa031"]
[OnName num="Hosokawa"]
"Even with a skylight, it's so dark..."
[cpg cn=true]

With that being said, looking up at the night sky through the skylight....there was just complete darkness.
[cpg]

[OnName num="Kenji"]
"It's only five o'clock..."
[cpg cn=true]

I was surprised to find that the sun had set more than I realized, when I heard a voice coming from the other direction.
[cpg]




[VOICE f="Erika104"]
[OnName num="Erika"]
"What the hell are you doing?"
[cpg cn=true]

[OnName num="Kenji"]
''Erika! Yuna! Where are you?"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi049"]
[OnName num="Michi"]
"Upstairs!"
[cpg cn=true]


[free time=1000]
[BG f="b_l_1f_entrance_p4up.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗い／胸像が懐中電灯に照らされる）******************************************************

[WAIT time=1000]


The flashlights that Michi and I held illuminated the stairs at the same time.
[cpg]

[OnName num="Kenji"]
"Whoa! Who's there?"
[cpg cn=true]

I thought I saw a figure on the landing of the stairs and called out.
[cpg]

But...
[cpg]


[VOICE f="Michi050"]
[OnName num="Michi"]
"Calm down. That's just a bust."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, yeah..."
[cpg cn=true]

It was a mere bronze statue that was illuminated by the dim light.
[cpg]

Could it be that I'm being a tad jumpy?
[cpg]

That and…the stairs split left and right from the central landing where the bust was placed.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p1_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=800]

Part way, I could see Yuna slumped over and Erika yanking her arm.
[cpg]

[OnName num="Kenji"]
"What are you doing?"
[cpg cn=true]


[VOICE f="Michi051"]
[OnName num="Michi"]
"Are you two hurt?"
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
When we shouted, Erika huffed, pulled her hand away from Yuna, and bobbed her head and hands like a toy doll.
[cpg]


[VOICE f="Erika105"]
[OnName num="Erika"]
"N-no, no. I didn't do anything!"
[cpg cn=true]

[OnName num="Kenji"]
"Oh......?"
[cpg cn=true]

Since Erika was saying “I didn’t do anything”, this usually meant she definitely did something bad…
[cpg]

I walked up the stairs with the other four, feeling veeeeerrrry uneasy.
[cpg]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4up.ui" time=1000]
;//階段
;//【ＢＧ】図書館・１階・エントランス　夜（暗い／胸像が懐中電灯に照らされる）******************************************************


[WAIT time=2000]
[FG f="CHA03_p3_01_a.ui" method="change_7" pos="2/3" time=500]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="3/3" time=500]

[WAIT time=2000]

[OnName num="Kenji"]
"Erika, what did you do...?"
[cpg cn=true]

I asked the question first, not Shiori or Michi, who were still trying to grasp the situation.
[cpg]

Then Erika realized the seriousness of my tone and pushed Yuna's shoulder.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika106"]
[OnName num="Erika"]
"It wasn't me! It's all Yuna's fault! She's the reason the emergency bell went off!"
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna057"]
[OnName num="Yuna"]
"I was just doing what Erika told me to do!"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi052"]
[OnName num="Michi"]
"Wait a minute… What the hell is going on? Calmly explain what happened.”
[cpg cn=true]

Michi and Shiori, as well as Takagi and Hosokawa, had no idea what was going on.
[cpg]

[OnName num="Kenji"]
“Erika, shut up. Yuna, you have to tell everyone what Erika told you and what you did."
[cpg cn=true]

I glared at Erika to keep her from interrupting, and crouched down between the two of them to protect Yuna.
[cpg]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna058"]
[OnName num="Yuna"]
“W-well, actually..., Erika said…she really wanted to see the treasures in the library. She wanted me to unlock the…door with this."
[cpg cn=true]

[OnName num="Kenji"]
"What, with this?"
[cpg cn=true]

It was the membership card of a karaoke bar that Yuna held out, crying.
[cpg]

[FG f="CHA07_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Takagi038"]
[OnName num="Takagi"]
"Oh~, opening a locked door with a credit card like they show in movies?!"
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa032"]
[OnName num="Hosokawa"]
"Stupid... There's no way a real lock can be opened with that thing."
[cpg cn=true]

Even though it was impossible, Erika's brain thought it could open the door...
[cpg]

I collapsed on the spot, deflated.
[cpg]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna059"]
[OnName num="Yuna"]
"I told her I couldn't do it because I've never done anything like that before, but she.. Erika said it would open up eventually if I just did it right."
[cpg cn=true]

[OnName num="Kenji"]
"You..."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika107"]
[OnName num="Erika"]
"Everyone can do it! It's just because Yuna is so clumsy!"
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi053"]
[OnName num="Michi"]
"Is...that so?"
[cpg cn=true]

silence
[cpg]

In an instant, the place froze, and we all knew what was going on here.
[cpg]

The security system had been triggered when Erika tried to get Yuna to break down the door to the treasure room.
[cpg]

[OnName num="Kenji"]
“You have to apologize. Apologize to everyone!”
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
I yelled at Erika as hard as I could.
[cpg]

But...
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika108"]
[OnName num="Erika"]
"What the hell! I just wanted to see what kind of treasure was in there! It's someone's fault for being stingy and locking the door!"
[cpg cn=true]

[OnName num="Kenji"]
"Oh, you!"
[cpg cn=true]

This was getting us nowhere.
[cpg]

In her mind, it’s your own fault for not dodging a punch when you get hurt in a fight, and it’s your own fault for getting tricked into doing something.
[cpg]

Hopefully, Erika will never become a judge.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi054"]
[OnName num="Michi"]
"Maybe I should call the police."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika109"]
[OnName num="Erika"]
"What? You're overreacting!"
[cpg cn=true]

The word "police" from Michi's lips finally made Erika realize the seriousness of the matter.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika110"]
[OnName num="Erika"]
"I just wanted to have a look! It was curiosity! My curiosity just got the better of me!"
[cpg cn=true]

Erika was in a panic to explain herself, but Michi looked at her coldly.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi055"]
[OnName num="Michi"]
"What were you going to do if the door was unlocked? Then you say you just want to touch it, so you break the glass case, and then you just want to take it home with you, so you put it in your bag?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika111"]
[OnName num="Erika"]
"I didn't say that!"
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi056"]
[OnName num="Michi"]
"Just because you're underage doesn't mean you can do anything you want. I'll not only call the police, but I'll notify your parents and your school."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika112"]
[OnName num="Erika"]
"Wait! After apologizing, you can't do that!"
[cpg cn=true]

...she hasn't apologized.
[cpg]

Not a single word of apology from Erika since this conversation started.
[cpg]

Yuna also noticed this, and bowed deeply to Shiori and Michi, apologizing for her behavior.
[cpg]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna060"]
[OnName num="Yuna"]
"I'm really...sorry...hic...hic"
[cpg cn=true]

.........
[cpg]

Shiori's face was expressionless as she stared at Yuna, who was crying and bending over at a 90-degree angle.
[cpg]

There was no trace of anger or pity on her face.
[cpg]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi057"]
[OnName num="Michi"]
"...Anyway, let's disable the security lock first. It's none of Takagi or Hosokawa's business, so we have to let them leave."
[cpg cn=true]

In a way that neither accepted nor brushed off Yuna's apology, for now, Michi went to take care of the two people who had nothing to do with this.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa033"]
[OnName num="Hosokawa"]
"I'd appreciate it if you would. I've got some studying to do this evening."
[cpg cn=true]

[FG f="CHA07_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Takagi039"]
[OnName num="Takagi"]
"Me too... I didn't record any of my anime, so I'll just be going..."
[cpg cn=true]

The two people who could not bear the heavy atmosphere were relieved by Michi 's concern, and seemed to want to go home as soon as possible.
[cpg]

No wonder.
[cpg]

If I were an outsider, I would want to get out of here as soon as possible too.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Shiori033"]
[OnName num="Shiori"]
"Then..., I'm going to the security room..."
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi058"]
[OnName num="Michi"]
"Are you okay by yourself?"
[cpg cn=true]

[move from="2/3" to="5/3" ease="easeInOutSine" time=2000]

Shiori gave a small nod, took the flashlight from my hand and went up the stairs.
[cpg]

As I watched her in the dim light from the landing, I could see her use the key from her pocket to open the door and go inside.
[cpg]

[OnName num="Kenji"]
'"You should apologize too. You've caused so much trouble, do you think you can just let Yuna lower her head the whole time?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika113"]
[OnName num="Erika"]
".................."
[cpg cn=true]

When Shiori disappeared behind the door upstairs, I tried, but failed to get Yuna to lift her head up, so I poked Erika in the shoulder instead.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika114"]
[OnName num="Erika"]
"I'm s-sorry..."
[cpg cn=true]

The moment Erika's lips moved in a muffled manner, the apology seemed to finally spill out...
[cpg]

[STOPBGM]

[VOICE f="Shiori034"]
[OnName num="Shiori"]
"O-oh, my God..., someone get over here...!"
[cpg cn=true]

Shiori was shouting in a thin voice as she leaned over the handrail of the second floor corridor.
[cpg]

[BGM f="danger"]

[FACE method="change_5" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi059"]
[OnName num="Michi"]
"Shiori?!"
[cpg cn=true]

[OnName num="Kenji"]
"What is it?"
[cpg cn=true]

[WAIT time=100]
[VOICE f="Takagi040"]
[OnName num="Takagi"]
"Shiori-kins!"
[cpg cn=true]

We all ran up the stairs as Shiori shouted loudly, a situation that in some ways pointed to a more urgent situation than the emergency bell had.
[cpg]

[SE f="se022"]
;//【ＳＥ】全員で階段を駆け上がる

;//エフェクト
[window target=false]
[transition target={true} rule="101.jpg" color={0x000000ff} time=2000]
[WAIT time=2000]
;//【ＢＧ】ブラックアウト
[free time=100]
[window target=true]


I walked through a large door with a sign that said "Authorized Personnel Only" and down a long corridor, I saw several doors on the side.
[cpg]

And a room located at the farthest end of it...
[cpg]

[window target=false]
[BG f="b_l_2f_sr_0.ui" time=100]
[WAIT time=100]
;//【ＢＧ】図書館・２階・セキュリティルーム　（暗い／懐中電灯）******************************************************
[transition target={false} rule="101.jpg" color={0x000000ff} time=2000]
[WAIT time=2500]

[window target=true]


[OnName num="Kenji"]
"This is..."
[cpg cn=true]

Beckoned by Shiori, everyone entered Tokita Library’s security room.
[cpg]

The room looked like it had been ransacked by bandits, and the machinery, which resembled what you'd find in a recording studio, had somehow been destroyed.
[cpg]


[VOICE f="Takagi041"]
[OnName num="Takagi"]
"Well…, you wouldn’t say…this is just how it normally looks, would you?”
[cpg cn=true]

[OnName num="Kenji"]
"If you think this is normal, how messy is your room?"
[cpg cn=true]

It wasn't even on the same level as simply being untidy.
[cpg]

I wasn’t not sure, but the room was like a TV station's monitor room or recording room, with big machines, a few monitors, and a few computers...
[cpg]

This room, where the monitor had a crack in the screen and there was a heavy chair thrown on top of a big table-like machine was…a mess.
[cpg]


[VOICE f="Hosokawa034"]
[OnName num="Hosokawa"]
"Wow..., even the cables have been cut..."
[cpg cn=true]

When I thought about what Hosokawa said, I could see that a thick bundle of cords had been cleanly cut.
[cpg]


[VOICE f="Michi060"]
[OnName num="Michi"]
"Who in the world would do this...?"
[cpg cn=true]

Once the words left Michi’s mouth, suddenly all our eyes turned to Erika.
[cpg]

.........
[cpg]

[OnName num="Kenji"]
".................."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika115"]
[OnName num="Erika"]
"Hey…don’t look at me! I didn't even know there was a room like this!"
[cpg cn=true]

When Erika realized that she was being suspected, she panicked and started to proclaim her innocence.
[cpg]

But since she was the one who started all this trouble, her words couldn’t be trusted.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa035"]
[OnName num="Hosokawa"]
"I'm not so sure..."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika116"]
[OnName num="Erika"]
"What do you mean?"
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa036"]
[OnName num="Hosokawa"]
"You wanted to get into the treasure room. However, the security was too tough."
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa1036"]
[OnName num="Hosokawa"]
"So, wouldn't short-circuiting the security be the next thing you think of? Wouldn't that make it all too easy?"
[cpg cn=true]


Unfortunately, that was highly likely.
[cpg]

But Erika rejected Hosokawa's reasoning with all her might.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika117"]
[OnName num="Erika"]
"You've got to be kidding me! Why would I do such a thing…!"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna061"]
[OnName num="Yuna"]
"Um..., I don't think that's...what happened."
[cpg cn=true]

[OnName num="Kenji"]
"Yuna?"
[cpg cn=true]

Yuna, who had kept her head down this whole time, opened her mouth to refute Hosokawa's accusation.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna062"]
[OnName num="Yuna"]
"The door Erika told me to open was the first door with the 'Staff Only' sign on it."
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Yuna501"]
[OnName num="Yuna"]
"But as I was about to open it, the emergency bell rang, and we didn't know there were so many rooms back here."
[cpg cn=true]


[VOICE f="Yuna1501"]
[OnName num="Yuna"]
"I wouldn't even have been able to...break through the door here at the far end and do something like this."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, that's right. Shiori went upstairs and used the key. I...saw her"
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa037"]
[OnName num="Hosokawa"]
"So..., who could have done all this?"
[cpg cn=true]

.........
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi061"]
[OnName num="Michi"]
".................."
[cpg cn=true]

[OnName num="Kenji"]
".................."
[cpg cn=true]

The room was dead silent, cold, and a complete mess.
[cpg]


[FG f="CHA07_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Takagi042"]
[OnName num="Takagi"]
"But, you know what...!"
[cpg cn=true]

The first one to speak up was Takagi.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Takagi043"]
[OnName num="Takagi"]
“What if, in fact, Yuna had unlocked the door with her card and Erika had actually gone inside and mistook this room for the treasure room..."
[cpg cn=true]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Takagi1043"]
[OnName num="Takagi"]
"What if you got pissed off after you realized it was the wrong room, snapped and messed it up, then came back and Yuna locked the door with her card again…or something?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Erika118"]
[OnName num="Erika"]
"What are you talking about, fatty?"
[cpg cn=true]

Erika yelled in anger at Takagi's latest theory.
[cpg]

His theory was a little too far-fetched, though.
[cpg]

[OnName num="Kenji"]
"You can open a door with a card by tampering with the lock, but you can't...lock a door with a card, can you?"
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Takagi044"]
[OnName num="Takagi"]
"No? You can't?"
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi062"]
[OnName num="Michi"]
"Good point..."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna063"]
[OnName num="Yuna"]
"But then..., who did it?"
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi063"]
[OnName num="Michi"]
"..................."
[cpg cn=true]

.........
[cpg]

;//[free time=1]
;//[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
;//[FG f="CHA05_p3_01_a.ui" method="change_4" pos="1/3" time=800]


Michi and Shiori looked at each other, and at the same time we all shared looks.
[cpg]

I have no idea what's going on in this library right now.
[cpg]

[OnName num="Kenji"]
"Hey~... Why don't we go outside for now? There's no point in staying here."
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa038"]
[OnName num="Hosokawa"]
"T-true. Aside from figuring out what happened, constantly being in all this darkness is suffocating."
[cpg cn=true]

If Hosokawa and I agree...
[cpg]

[FACE method="change_4" pos="2/3"]
[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi064"]
[OnName num="Michi"]
".................."
[cpg cn=true]

.........
[cpg]

Michi and Shiori looked at each other again and with clouded expressions.
[cpg]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi065"]
[OnName num="Michi"]
"I'm sorry, but..."
[cpg cn=true]

What Michi told us was enough to shock everyone.
[cpg]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi066"]
[OnName num="Michi"]
"Since the machine was destroyed with the security system still activated, it's very unlikely we'll be able to disable it."
[cpg cn=true]

[OnName num="Kenji"]
"...what? You're kidding?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi067"]
[OnName num="Michi"]
"Well, for now, you can't get out through the windows or the doors."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika119"]
[OnName num="Erika"]
"Ohー, my God! Seriously?!"
[cpg cn=true]

We were all surprised, but I just didn't want Erika to say it.
[cpg]

[OnName num="Kenji"]
"You can't say anythingー!"
[cpg cn=true]

[STOPBGM]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi068"]
[OnName num="Michi"]
"Ah, but don't worry. The system automatically calls the security company when the emergency bell rings."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[FACE method="change_1" pos="3/3"]
[WAIT time=100]

When Michi told us this, everyone was a little less anxious.
[cpg]

[BGM f="dod"]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa039"]
[OnName num="Hosokawa"]
“What? Then, help is probably on the way right now. What a relief."
[cpg cn=true]

Even though everyone was relieved that help was on its way, Shiori seemed to feel a sense of responsibility.
[cpg]

As I noticed Shiori's fearful expression, I looked at Erika with resentment...
[cpg]


[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Erika120"]
[OnName num="Erika"]
"W-what? I feel bad about it. But I definitely didn't break the machine!"
[cpg cn=true]

I didn't think Erika was lying about that.
[cpg]

There was nothing for her to gain by doing that.
[cpg]

But I knew that would lead to another round of "Who done it?", so I avoided the topic further.
[cpg]

[OnName num="Kenji"]
“It’s okay if we're trapped for a bit, like when there's a train accident and we have to wait for hours at the station. Right?"
[cpg cn=true]

I asked Takagi and Hosokawa to agree, and when they nodded, I smiled at Shiori.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Shiori035"]
[OnName num="Shiori"]
"Tha-thanks..."
[cpg cn=true]

Even though the situation could have been blamed on Erika and us, Shiori looked sincerely sorry, and her expression, words, and actions conveyed her kindness.
[cpg]

It was not just Shiori's face that was beautiful, it was all of her...
[cpg]

I was moved by just thinking about her.
[cpg]


[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi069"]
[OnName num="Michi"]
"Let's go downstairs, then. Since there's been property damage, the police will have to collect fingerprints..."
[cpg cn=true]

I see.
[cpg]

If this room was dusted for fingerprints, we could find out who did it.
[cpg]

We went down to the entrance, being careful not to touch anything and guiding our feet by flashlight.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗）******************************************************

When we got down the stairs, it was much darker than before.
[cpg]

It seems that the sun had finally fully set.
[cpg]

[FG f="CHA03_p5_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika121"]
[OnName num="Erika"]
"It's...dark. I'm scared."
[cpg cn=true]

I was a little annoyed when Erika clung to my arm.
[cpg]

But I couldn't get angry, because I understood her fear.
[cpg]

I'm too nice.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi070"]
[OnName num="Michi"]
"I’m sure, there are candles in the underground storeroom, so I'm going to go get some."
[cpg cn=true]

[free time=800]

After informing us, Michi disappeared behind the stairs.
[cpg]

Then Hosokawa started whispering to Takagi.
[cpg]


[FG f="CHA07_p3_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Hosokawa040"]
[OnName num="Hosokawa"]
"Have you ever heard of the suspension bridge effect?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi045"]
[OnName num="Takagi"]
"The suspension bridge effect? No, I haven't."
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa041"]
[OnName num="Hosokawa"]
"You know when you cross a high suspension bridge and you get scared and your heart starts pounding? When a man and a woman are together in such a state, the body mistakes that pounding for love."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi046"]
[OnName num="Takagi"]
"Huh?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa042"]
[OnName num="Hosokawa"]
"In other words, when you're in a situation where you feel fear, your chances of getting a woman to fall for you go way up."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi047"]
[OnName num="Takagi"]
"Oh, I see. Shiori-kins, it's dark and scary, isn't it? You can come closer ♪"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
Frowning, Shiori shook her head.
[cpg]

That Takagi. Once he hears about something, he'll try it immediately.
[cpg]

However, it was unlikely that Shiori would be scared to death in her own library just because it was dark.
[cpg]

Thinking about this, I suddenly looked at Erika, who was attached to my arm.
[cpg]

[OnName num="Kenji"]
"You..., are you creating a suspension bridge effect?"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika122"]
[OnName num="Erika"]
"Huh? A suspension bridge? Bungee jumping? Never done it.."
[cpg cn=true]

What was with that train of thought...?
[cpg]

This idiotic behavior was not for some psychological effect.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi071"]
[OnName num="Michi"]
"Thanks for waiting."
[cpg cn=true]

Michi returned and lit a few candles with a lighter.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BGM f="d1"]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗／蝋燭）******************************************************


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="1/3" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_1" pos="3/3" time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=1000]

[WAIT time=1500]

[WAIT time=100]
[VOICE f="Erika123"]
[OnName num="Erika"]
"Wow. How nice ♪"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi072"]
[OnName num="Michi"]
"Do you think it's safe to put candles on the marble?"
[cpg cn=true]

Shiori nodded a little at Michi in response.
[cpg]

With Shiori's permission, we set up a few candles on the floor, avoiding the carpet area, and turned off our flashlights.
[cpg]

[OnName num="Kenji"]
"It's kind of romantic..."
[cpg cn=true]

The entrance where the small orange flames flickered seemed magical.
[cpg]

The two sets of armor beside the stairs also played into the whole ambiance.
[cpg]

[OnName num="Kenji"]
"I've only seen this kind of thing in movies."
[cpg cn=true]

I was so impressed that I spoke to Shiori.
[cpg]

Shiori met my words with a puzzled look.
[cpg]

[OnName num="Kenji"]
"This armor?"
[cpg cn=true]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori036"]
[OnName num="Shiori"]
"16th century, Maximilian European-style…fluted armor…"
[cpg cn=true]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika124"]
[OnName num="Erika"]
"It's expensive, right?"
[cpg cn=true]

Erika interrupted Shiori's explanation from the side.
[cpg]

But...
[cpg]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori037"]
[OnName num="Shiori"]
"Well...The price is...It was bought by my grandfather, so..."
[cpg cn=true]

After that, Shiori shot Michi a glance, so Michi continued explaining.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi073"]
[OnName num="Michi"]
"He originally wanted to display the armor on horseback, but that would have taken up too much space, so he gave up."
[cpg cn=true]

[OnName num="Kenji"]
"Oh~, so your grandfather was into that sort of stuff."
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori038"]
[OnName num="Shiori"]
"Ah... that doesn't mean he particularly liked that..."
[cpg cn=true]

[STOPBGM]

[FG f="CHA08_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa043"]
[OnName num="Hosokawa"]
"Anyway, it's getting pretty late..."
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[FACE method="change_7" pos="2/3"]
[FACE method="change_7" pos="3/3"]


Why is it that whenever I tried to talk to Shiori, someone always interrupted...?
[cpg]

It was then that Hosokawa muttered, staring at the large front door.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa044"]
[OnName num="Hosokawa"]
"If the alarm was set off by a burglar, they would have escaped by now."
[cpg cn=true]

[BGM f="serious"]

True.
[cpg]

A lot of time has passed since the alarm went off.
[cpg]

Nowadays, with the development of the GPS, it's unlikely that people in that line of work would get lost.
[cpg]


[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi074"]
[OnName num="Michi"]
"If you ask me, it is getting a little late."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna064"]
[OnName num="Yuna"]
"If the machine was broken before the...notification system was activated, there was no alert sent out..."
[cpg cn=true]

[OnName num="Kenji"]
"What?"
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika125"]
[OnName num="Erika"]
"Huh? How is that even possible?"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="1/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=800]
At Yuna's unexpected conclusion, we all looked at Shiori and Michi at once.
[cpg]

It wasn't unreasonable to think that only they know about the system here.
[cpg]

Still...
[cpg]

When I looked at Shiori, she shook her head, as if to say that she didn't know either.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi075"]
[OnName num="Michi"]
"The emergency bell rings when a door or window is about to be broken into, or when a fire is detected. From each sensor, you can send a message to the security system at… Ah, that’s right."
[cpg cn=true]

[OnName num="Kenji"]
"What's that?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi076"]
[OnName num="Michi"]
"The emergency bell can be rung independently, but the commands from it are... useless if the receiving computer is destroyed first."
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa045"]
[OnName num="Hosokawa"]
"So you're saying the security company won't be coming?"
[cpg cn=true]

We were thrown by the unexpected possibility.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_2" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika126"]
[OnName num="Erika"]
"Oh, a phone! Why don't we just call them on a cell phone?"
[cpg cn=true]

[OnName num="Kenji"]
"Oh, yeah."
[cpg cn=true]

We had completely forgotten about the existence of such an important tool during this extraordinary event, and Erika's words made us ashamed of ourselves.
[cpg]

[FG f="CHA07_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Takagi048"]
[OnName num="Takagi"]
"I'm not sure why I didn't think of it sooner. Ehehe."
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa046"]
[OnName num="Hosokawa"]
"Shiori, can you give us back our phones that we left with you?"
[cpg cn=true]



Shiori gave a small nod, grabbed the flashlight that had been left on the floor, and quickly headed for the room behind the counter.
[cpg]


[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika127"]
[OnName num="Erika"]
"Since it's getting late, I'm going to have my dad pick me up. Why don't you two ride with us?"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna065"]
[OnName num="Yuna"]
"'Thanks..."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, well... I guess I'll take you up on your offer."
[cpg cn=true]

[FACE method="change_1" pos="1/3"]

We waited for Shiori to come back, but she was taking a long time.
[cpg]

Michi must have been thinking that too...
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi077"]
[OnName num="Michi"]
"That's odd. Shioriiiiー?"
[cpg cn=true]

;//[free time=800]

[move from="3/3" to="5/3" ease="easeInOutSine" time=1000]


She grabbed the other flashlight and ran to the general collection room.
[cpg]

[FG f="CHA07_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Takagi049"]
[OnName num="Takagi"]
"Oh no~. I should have gone too!"
[cpg cn=true]

Rest assured, Takagi.
[cpg]

You wouldn't be allowed to go.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa047"]
[OnName num="Hosokawa"]
"It's probably taking too long because it's dark."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah."
[cpg cn=true]

[free time=800]
But, both Hosokawa and I were wrong.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4" pos="2/5" time=800]
.........
[cpg]

Michi came back with Shiori quietly.
[cpg]

Illuminated by the flickering candlelight, Shiori's face looked pale despite the orange glow.
[cpg]


[VOICE f="Shiori039"]
[OnName num="Shiori"]
"The phones..., I couldn't find....a single one."
[cpg cn=true]

[OnName num="Kenji"]
"What?!"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="1/3" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="3/3" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_4" pos="2/3" time=1]
[WAIT time=100]
[VOICE f="Erika128"]
[OnName num="Erika"]
"What's that? My phone! Where did you put my phone?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi078"]
[OnName num="Michi"]
"Well..., they were not in the locker where I usually keep them."
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_5" pos="1/3" time=1]
[WAIT time=100]
[VOICE f="Hosokawa048"]
[OnName num="Hosokawa"]
"What do you mean?"
[cpg cn=true]

We gathered around the two of them and asked them to explain.
[cpg]

Apparently, the door behind the counter leads to a luggage storage area with small lockers to keep valuables and cell phones.
[cpg]

The cell phones and valuables in the baskets were put directly into one locker per person and locked, and Shiori kept the key on herself at all times.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_7" pos="3/3" time=1]
[WAIT time=100]
[VOICE f="Yuna066"]
[OnName num="Yuna"]
"But then..., does that mean the locks were broken into and everything was stolen?"
[cpg cn=true]

Responding to Yuna, Shiori shook her head emphatically, and Michi explained.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi079"]
[OnName num="Michi"]
"There was nothing wrong with the lock, and there were no signs of tampering. Only the contents are missing."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, my God..."
[cpg cn=true]

Erika shouted next to me, loudly.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3" pos="1/3" time=1]
[WAIT time=100]
[VOICE f="Erika129"]
[OnName num="Erika"]
"Then that means she stole our stuff!"
[cpg cn=true]

.........
[cpg]

[OnName num="Kenji"]
"What are you saying?"
[cpg cn=true]

Obviously the person who had the key, Shiori, would be the first to be suspected.
[cpg]

Who in the world would be stupid enough to do such a thing?
[cpg]

[FG f="CHA07_p3_01_a.ui" method="change_4" pos="3/3" time=1]
[WAIT time=100]
[VOICE f="Takagi050"]
[OnName num="Takagi"]
"Should we...frisk her?"
[cpg cn=true]

[OnName num="Kenji"]
"Wha...?"
[cpg cn=true]

This would be the natural development in a suspenseful mystery, but since the suggestion was made by Takagi, he clearly had an ulterior motive.
[cpg]


[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika130"]
[OnName num="Erika"]
"Fine by me. I'm not the culprit."
[cpg cn=true]

[free time=800]

A bit out of character for her, Erika agreed with the others as I rushed to Shiori's side.
[cpg]

[OnName num="Kenji"]
"That's uncalled for!"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="1/3" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7" pos="3/3" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/3" time=1]

I tried to stop them, but both Michi and Shiori had opened their arms in preparation for a body-search, to prove their innocence.
[cpg]


I had no choice but to check their pockets with Takagi and Hosokawa.
[cpg]

As a result, as expected, no one had any kind of mobile phone on them.
[cpg]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika131"]
[OnName num="Erika"]
"If these people were the culprits, they could hide them in any room, so it wouldn't matter."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi080"]
[OnName num="Michi"]
"What do you mean by that? Do you think we have any reason to do that?"
[cpg cn=true]

Michi seemed to be upset with the baseless treatment and accusations.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi081"]
[OnName num="Michi"]
"It's you who should be questioned, since it was your foolishness that got us into this mess in the first place. You destroyed that expensive machine, you stole the phones."
[cpg cn=true]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika132"]
[OnName num="Erika"]
"Wha-what? I was just saying that it would be nice to see the treasures, but it was Yuna that actually did it!"
[cpg cn=true]

[FACE method="change_3" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika1132"]
[OnName num="Erika"]
"It's not my fault that Yuna did something on her own! It was Yuna!"
[cpg cn=true]


Erika points the finger at Yuna with forcefully shifting the blame.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_5" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna067"]
[OnName num="Yuna"]
"No, no! I didn't do anything...! I couldn't even pick a simple lock."
[cpg cn=true]

Panicking, Yuna was so upset that even from the sidelines she looked pitiful.
[cpg]

[FG f="CHA07_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Takagi051"]
[OnName num="Takagi"]
"Yuna..."
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna068"]
[OnName num="Yuna"]
"It wasn't me! I didn't do anything!"
[cpg cn=true]

[OnName num="Kenji"]
"Yuna..."
[cpg cn=true]

[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna069"]
[OnName num="Yuna"]
"I don't know! It wasn't me!"
[cpg cn=true]

There was once an adventure game that, no matter what was asked, the responses were, "It wasn't me! I didn't do it!"
[cpg cn=true]

Yuna has become just like one of those characters, who would answer like that.
[cpg]

[OnName num="Kenji"]
"Hold on. Let's just calm down! Okay, no cell phone means… Does that mean no way to contact the outside world? How about a landline?"
[cpg cn=true]

When I asked Michi as calmly as possible, she shook her head.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi082"]
[OnName num="Michi"]
"Didn't you see that earlier? The cable in the security room had been cut, which means that the landline phone is not working either. This place is now in complete lockdown."
[cpg cn=true]

[FG f="CHA07_p3_01_a.ui" method="change_3" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Takagi052"]
[OnName num="Takagi"]
"Complete..."
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa049"]
[OnName num="Hosokawa"]
"lockdown..."
[cpg cn=true]

;//＠

[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="4/5" time=800]
[WAIT time=2500]
[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=2500]
[free time=1]
[WAIT time=1]
[FG f="CHA07_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=2500]

[free time=800]

No security on the way. No cell phones. No landline.
[cpg]

Now, Tokita Library is a huge locked room.
[cpg]

Confronted with this fact, and we cowered in disbelief.
[cpg]



[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi083"]
[OnName num="Michi"]
"Now that we know the situation, we'll have to find the person who destroyed the system. There's a good chance that person has hidden the phones somewhere."
[cpg cn=true]


Michi looks over us with an unusually stern expression.
[cpg]

Unfortunately, that was the way things were.
[cpg]

It was the only way for us to get out for now.
[cpg]

[OnName num="Kenji"]
"So…, let's go over everyone’s alibis, shall we? Let's see where you were and what you were doing when the emergency bell rang."
[cpg cn=true]

I couldn't stand the silence, so I suggested that and started to talk about what I could remember.
[cpg]

[OnName num="Kenji"]
“I was reading a book in my usual room, but before I knew it, I dozed off… I woke up to the sound of the emergency bell, and Takagi and Hosokawa came running in."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA07_p3_01_a.ui" method="change_7" pos="2/5" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_7" pos="4/5" time=800]
[WAIT time=100]

The two guys I had mentioned picked up where I left off.
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa050"]
[OnName num="Hosokawa"]
“We saw that Azuma had fallen asleep, and then we both went to the bathroom.”
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi053"]
[OnName num="Takagi"]
"We talked for a bit in the bathroom, but I don't think we were gone for more than four or five minutes."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa051"]
[OnName num="Hosokawa"]
"Right after we left the bathroom while talking, the emergency bell rang and we were startled to see everything go dark, so we ran back into the room."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi054"]
[OnName num="Takagi"]
"Yeah, yeah. Then, Mr. Azuma was all flustered… Oh, he had bedhead!"
[cpg cn=true]

[OnName num="Kenji"]
"That's not important!"
[cpg cn=true]

I shouted out, embarrassed that I had dozed off, but I guess this proved my innocence.
[cpg]

Because it seemed impossible to go down the stairs from the security room and come to the general collection room without running into them coming back from the bathroom.
[cpg]

[OnName num="Kenji"]
"So, what about Erika and Yuna?"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika133"]
[OnName num="Erika"]
"Oh, I was..."
[cpg cn=true]

Even Erika felt uncomfortable confessing the details of her wrongdoing, so she began to speak in a hushed voice.
[cpg]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika134"]
[OnName num="Erika"]
"Today, since I got here, I've just been chatting with Yuna in the room across from our usual room. Because there are less people there…"
[cpg cn=true]

[VOICE f="Erika1134"]
[OnName num="Erika"]
"So I waited until most people started to leave, and then I gave Yuna my card and sent her upstairs..., and I looked out for people from the landing."
[cpg cn=true]

"Looking out for people"...sounded like she had been doing Yuna a favor.
[cpg]

Normally, I would have made a big crack about it, but I was not in the mood, and Yuna continued.
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna070"]
[OnName num="Yuna"]
“I refused to do it so many times, but Erika wouldn't listen, so I figured I'd try it and if it didn't unlock, she'd let up…”
[cpg cn=true]

[VOICE f="Yuna1070"]
[OnName num="Yuna"]
"Then I headed upstairs to that 'Staff Only' door."
[cpg cn=true]


[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna071"]
[OnName num="Yuna"]
"And I was messing with it and suddenly the emergency bell rang... and I got scared and ran away and Erika caught me on the landing and... She scolded me."
[cpg cn=true]

The guard caught the perpetrator and scolded them on the spot...
[cpg]

It was like a comedy sketch.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna072"]
[OnName num="Yuna"]
"It was dark before I knew it, and I was panicking..."
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika135"]
[OnName num="Erika"]
"I was on the stairs and I froze because I couldn't move..."
[cpg cn=true]

If Erika and Yuna's testimonies were true, then neither of them had been able to go beyond that door at this point.
[cpg]

Then all that remains is...
[cpg]


[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
Our eyes naturally drifted to the two people from the library.
[cpg]

[FACE method="change_4" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi084"]
[OnName num="Michi"]
"Shiori and I were in the..."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori040"]
[OnName num="Shiori"]
"We were in the infirmary..."
[cpg cn=true]

[OnName num="Kenji"]
"Infirmary?"
[cpg cn=true]

It was the name of the room, which made everyone tilt their heads.
[cpg]

I didn't know there was such a room in this building.
[cpg]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi085"]
[OnName num="Michi"]
"There's a room in the basement where we can do a few treatments. It's like a school nurse's office..."
[cpg cn=true]

[VOICE f="Michi1085"]
[OnName num="Michi"]
"There's also a bed where visitors who get sick can lie down for a while. But we usually use it mostly for Shiori."
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori041"]
[OnName num="Shiori"]
"At that time…, I was having minor palpitations, so I had my blood pressure taken while I was taking my medication…"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Michi086"]
[OnName num="Michi"]
“Ah, and I also printed out her results and they have a time stamp, so you can check them out if you don’t believe me.”
[cpg cn=true]

Michi said confidently without hesitation.
[cpg]

If she were to play the role of a criminal in a mystery, she would have given the investigating detective a hard time.
[cpg]

[FACE method="change_4" pos="2/5"]
[WAIT time=100]
[VOICE f="Shiori042"]
[OnName num="Shiori"]
"As soon as I took my medicine, the emergency bell started ringing… The lights went out like it was a blackout, so I went into the storage room with the doctor to get flashlights, and then we went upstairs…”
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Michi087"]
[OnName num="Michi"]
"Then I walked straight into the room you were in."
[cpg cn=true]

[OnName num="Kenji"]
"I see..."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa052"]
[OnName num="Hosokawa"]
"Well, that's all the testimony we have. So?"
[cpg cn=true]

[OnName num="Kenji"]
"What? Well? What do you mean 'so'?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa053"]
[OnName num="Hosokawa"]
"What does this tell us?"
[cpg cn=true]

[OnName num="Kenji"]
"Well..."
[cpg cn=true]

We were supposed to go over everyone's movements and get an idea of who the culprit was, but it seemed like everyone had an alibi.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa054"]
[OnName num="Hosokawa"]
"You're hopeless. Don't you get it? There's only one person who doesn't have an alibi."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, really?!"
[cpg cn=true]

"Who's that...?"
[cpg]

;//■選択肢１（３択）
[switch]
[case "Shiori"]
	[swap]
	[jump target="*s1_a"]
[case "Myself"]
	[swap]
	[jump target="*s1_b"]
[case "Yuna"]
	[swap]
	[jump target="*s1_c"]
[endswitch]
;//１，栞　　//１aへ
;//２，自分　//１bへ
;//３，柚那　//１cへ
;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１a　栞
*s1_a|The Incident
[OnName num="Kenji"]
"You don't mean... Shiori!?"
[cpg cn=true]

......!?
[cpg]

Sure, Michi might have lied in Shiori's defense.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa055"]
[OnName num="Hosokawa"]
"No! What are you talking about?"
[cpg cn=true]

[OnName num="Kenji"]
"N-no?"
[cpg cn=true]

.........
[cpg]

Impossible.
[cpg]

Shiori's feelings got hurt unintentionally...
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa056"]
[OnName num="Hosokawa"]
"Not her. Yuna..."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=1]

;//１dへ合流
[jump target="*s1_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１b　自分
*s1_b|The Incident
[OnName num="Kenji"]
"Not...me?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa057"]
[OnName num="Hosokawa"]
"What...?"
[cpg cn=true]

True, I can't prove that I was asleep while Takagi and company were in the bathroom.
[cpg]

[OnName num="Kenji"]
"But I didn't do it! It wasn't me!"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_7" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika136"]
[OnName num="Erika"]
"I know that!"
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna073"]
[OnName num="Yuna"]
"Erika and I didn't see Kenji come upstairs..."
[cpg cn=true]

[OnName num="Kenji"]
"Phew..."
[cpg cn=true]

I almost lost it.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa058"]
[OnName num="Hosokawa"]
"No. Actually, Yuna..."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=1]

;//１dへ合流
[jump target="*s1_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１c　柚那
*s1_c|The Incident
[OnName num="Kenji"]
"It was...Yuna, wasn't it?"
[cpg cn=true]

I dug up the little bit of doubt I had about Yuna and said it out loud.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Hosokawa059"]
[OnName num="Hosokawa"]
"Yes."
[cpg cn=true]

And Hosokawa agreed with me.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[WAIT time=1]

;//１dへ合流
[jump target="*s1_d"]

;//～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～
;//１d
*s1_d|The Incident


[FACE method="change_7" pos="1/3"]
[FACE method="change_5" pos="2/3"]

[WAIT time=100]
[VOICE f="Yuna074"]
[OnName num="Yuna"]
"Oh, me?! But, but I..."
[cpg cn=true]

When her name was mentioned, Yuna was visibly upset.
[cpg]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa060"]
[OnName num="Hosokawa"]
"You say you were upstairs in front of the door, struggling with the lock, but you couldn't be seen from the landing. Could she, Erika?"
[cpg cn=true]

Hosokawa fiddled with his glasses and asked Erika in a detective-like tone.
[cpg]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika137"]
[OnName num="Erika"]
"W-well, yeah. I was looking down, not up at Yuna."
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa061"]
[OnName num="Hosokawa"]
"That's it. I'm sure that Yuna had actually unlocked the door and gotten in."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna075"]
[OnName num="Yuna"]
"But! The door can be unlocked with a card, but it can't be locked with one."
[cpg cn=true]

The theory that Yuna unlocked the door had already been put forward by Takagi.
[cpg]

However, it also had already been disproven in the security room.
[cpg]

Hosokawa was still theorizing and presenting it as his own idea.
[cpg]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa062"]
[OnName num="Hosokawa"]
"It's impossible to unlock and lock the door with a card, but what if you had the key itself? A copy of the key."
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_5" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi088"]
[OnName num="Michi"]
"A copy...?"
[cpg cn=true]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa063"]
[OnName num="Hosokawa"]
"Yeah, that's right."
[cpg cn=true]

The exchange of words sounded like something you'd see on TV in a suspense drama, and Hosokawa said it with such confidence.
[cpg]

Could it be that Hosokawa was the main character in this detective story?
[cpg]

Or was I just a supporting character who added to the excitement?
[cpg]

And was Yuna the culprit?!
[cpg]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa064"]
[OnName num="Hosokawa"]
"Yuna. For some unknown reason, you've been working here part-time for a while now. And while you were working, you had the opportunity to copy Shiori's key and wait for your chance.”
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa065"]
[OnName num="Hosokawa"]
"Eventually, knowing that some annoying friend of yours would want to see the treasure room, you took advantage of that by using your copy of the key to get behind the door..."
[cpg cn=true]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa1065"]
[OnName num="Hosokawa"]
"And you destroyed the security system. You went back in, locked the door, and here we are. Isn't that what happened?"
[cpg cn=true]


;//[SE f="se000"]
;//【ＳＥ】ジャジャーン！

Hosokawa posed coolly, pointing at Yuna.
[cpg]

But...
[cpg]

[OnName num="Kenji"]
"Oh, so...Yuna's aim was to destroy the security system?"
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi089"]
[OnName num="Michi"]
"If a key was used, it wouldn't have set off the alarm..."
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa066"]
[OnName num="Hosokawa"]
“Huh. The e-emergency bell must have rung when you destroyed the system!"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Shiori043"]
[OnName num="Shiori"]
“Why risk it… when the emergency bell can just be turned off, so it won't ring?"
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa067"]
[OnName num="Hosokawa"]
"Err."
[cpg cn=true]

[FG f="CHA05_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Michi090"]
[OnName num="Michi"]
"And as for the part-time job, she didn't apply for it, I asked a friend to introduce her, so it's not like Yuna approached me."
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa068"]
[OnName num="Hosokawa"]
"Eh, is th-that so?"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Yuna076"]
[OnName num="Yuna"]
"Sigh... A friend of my father's asked me to..."
[cpg cn=true]

Yes, debunked.
[cpg]

Hosokawa may have a very smart appearance, but if you listened to what he just said, he may be...stupid.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika138"]
[OnName num="Erika"]
"Whaaat? For a moment, I thought you were a great detective, and now I've lost hope!"
[cpg cn=true]

Her best friend was almost framed for the crime, and I wondered about her lack of concern.
[cpg]

But now we were back to square one in our search for the culprit.
[cpg]

[FACE method="change_7" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika139"]
[OnName num="Erika"]
"It's kind of...cold."
[cpg cn=true]

Erika complained, and I noticed that the temperature was indeed dropping.
[cpg]

[FACE method="change_7" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi091"]
[OnName num="Michi"]
"The power cable has been cut off, so the temperature can no longer be controlled."
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika140"]
[OnName num="Erika"]
"That means we're going to freeze to death! How terrible!"
[cpg cn=true]



[FG f="CHA03_p5_01_a.ui" method="change_4" pos="3/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_4" pos="2/3" time=800]

Erika shouted while she hugged me.
[cpg]

[FACE method="change_2" pos="3/3"]
Since we were in a building, we probably wouldn't freeze to death that quickly, but it was not an ideal situation.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Yuna077"]
[OnName num="Yuna"]
"Aside from looking for the culprit, we need to think about how to get help..."
[cpg cn=true]

Everyone nodded their heads at Yuna's suggestion.
[cpg]

[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Michi092"]
[OnName num="Michi"]
"There is a stockpile of emergency blankets and food, so let's go get them. If we can survive on that until tomorrow, I'm sure other visitors will come and find us."
[cpg cn=true]

[FACE method="change_1" pos="3/3"]
[WAIT time=100]
[VOICE f="Yuna078"]
[OnName num="Yuna"]
"Yes, that's right. You're right. There are other regular visitors, too."
[cpg cn=true]

We were all a little relieved by the escape plan Michi offered.
[cpg]

I'm not sure about spending the night here, but thinking of it as a natural disaster like a typhoon, didn't make half a day seem so bad.
[cpg]

However, Shiori seemed to be tormented by a strong sense of guilt...
[cpg]

[FACE method="change_4" pos="1/3"]
[WAIT time=100]
[VOICE f="Shiori044"]
[OnName num="Shiori"]
"I'm really...sorry. I will... explain and apologize to your families..."
[cpg cn=true]

She bowed deeply again and apologized to us.
[cpg]

[OnName num="Kenji"]
"Forget it. And you've stocked up on emergency rations, that's a big help."
[cpg cn=true]

I patted Shiori on her frail shoulder to try and comfort her.
[cpg]

.........
[cpg]

[FG f="CHA07_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Takagi055"]
[OnName num="Takagi"]
"That's right! Shiori-kins didn't do anything wrong."
[cpg cn=true]

[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]

Thus, we were led by Michi to the underground storage room.
[cpg]

Compared to the gorgeous staircase at the front, the back was a bit narrower.
[cpg]


[BG f="b_l_b1_pass_0.ui" time=1000]
;//【ＢＧ】図書館・地下・廊下　（暗／懐中電灯）******************************************************
[WAIT time=1500]


Going down to the basement, the floor and walls were made of bricks. That and the darkness reminded me of European catacombs.
[cpg]

The hallway had two doors, one on each side.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi093"]
[OnName num="Michi"]
"The back right room is the infirmary that I mentioned earlier. The front left room is where emergency supplies are kept, and the back left room is..., well, something like a storage room."
[cpg cn=true]

[VOICE f="Michi1093"]
[OnName num="Michi"]
"There is quite a lot packed in there that we didn't know if we should keep or not."
[cpg cn=true]


After that quick explanation, Michi opened the front left door and shined a flashlight inside.
[cpg]



[BG f="b_l_b1_ware_0.ui" time=1000]
;//【ＢＧ】図書館・地下・非常用倉庫　（暗／懐中電灯）******************************************************

There was a wooden shelf inside.
[cpg]

There were several blankets in clear plastic bags stacked on top of each other, and on another shelf were piles of canned food and emergency rations.
[cpg]

It wasn't a lot, but it should be enough to last for a few days for a group our size.
[cpg]

[FG f="CHA07_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Takagi056"]
[OnName num="Takagi"]
"Wow, there's also mixed rice ♪"
[cpg cn=true]

Takagi's eyes practically changed color as he saw familiar items such as dry bread and crackers, as well as some other emergency food.
[cpg]

[OnName num="Kenji"]
"You have your own, right, Takagi?"
[cpg cn=true]

I said, looking in his pants pocket.
[cpg]

I don't know how many bars he had, but I just thought he should be eating those chocolate bars he was always hiding.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Takagi057"]
[OnName num="Takagi"]
"Shhh. Don't tell anyone about it. I'll be scolded if I get found out."
[cpg cn=true]

What was he saying at a time like this?
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi094"]
[OnName num="Michi"]
"Add a stove and some water, and we'll be good to go."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna079"]
[OnName num="Yuna"]
"Why do you have such a huge stockpile?"
[cpg cn=true]

Michi responded to Yuna's reasonable question.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi095"]
[OnName num="Michi"]
“We are surrounded by nature, so if a typhoon hits, we wouldn't be able to leave. That's why we've prepared some rations for our visitors too.”
[cpg cn=true]

Thanks to this, we didn't have to worry about going hungry tonight.
[cpg]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=2500]
[BGM f="dod"]
[BG f="b_l_1f_entrance_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・エントランス　夜（暗／蝋燭）******************************************************
[WAIT time=1500]


;//☆

There were blankets and food. Each of us brought a flashlight, and we sat in a circle on the red carpet at the entrance, lined up with canned goods, and had a bizarre dinner.
[cpg]

[SE f="se030"]
;//【ＳＥ】湯が沸く

We boiled water on a simple stove and had tea.
[cpg]



As the hot liquid went down my throat and reached my stomach, a sigh escaped from everyone.
[cpg]

[SE f="se031"]
;//【ＳＥ】缶詰開ける

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=2000]
[FACE method="change_2" pos="2/3"]
[VOICE f="Michi096"]
[OnName num="Michi"]
''Well then, this is all there is, but please enjoy it."
[cpg cn=true]

[OnName num="Kenji"]
"Bon appétit."
[cpg cn=true]

It was amazing how canned goods could look like a gorgeous meal when put all together.
[cpg]

[free time=400]
Each of us looked around, trying to decide which one to eat first, hesitating with forks instead of chopsticks.
[cpg]



[FG f="CHA03_p3_01_a.ui" method="change_2" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Erika141"]
[OnName num="Erika"]
"Hey, there's canned crab! Nice!"
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa069"]
[OnName num="Hosokawa"]
"I'll have the boiled mackerel. That blue fish is rich in DHA..."
[cpg cn=true]

[FG f="CHA07_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Takagi058"]
[OnName num="Takagi"]
"Yum, yum ♪"
[cpg cn=true]

If we had been one step outside, this would’ve been a little like camping, but the reality was this was an emergency situation. 
[cpg]

But...
[cpg]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Erika142"]
[OnName num="Erika"]
"Isn't this kind of fun, like we’re at a training camp? Maybe this isn't so bad after all."
[cpg cn=true]

[OnName num="Kenji"]
"Well...yeah."
[cpg cn=true]

Erika’s optimism gradually made the uncomfortable atmosphere lighter around everyone.
[cpg]



;//右手にフォークを持っている栞（※伏線なので絵を入れてください）
;//＠
[free time=1000]
;**【ＣＧ】ev_14_0 ***********************
[CG id=13 index=0 time=1000]
;*****************************************

[WAIT time=2000]

.........
[cpg]

[OnName num="Kenji"]
"You’ve barely eaten anything, are you okay?"
[cpg cn=true]

I asked because I couldn’t help but notice how Shiori’s fork wasn’t making much progress with the canned food in front of her.
[cpg]

Shiori had her head down while her can wasn’t even half eaten.
[cpg]

[OnName num="Kenji"]
"You have to eat a little more or you'll get sick."
[cpg cn=true]

[WAIT time=100]
[VOICE f="Shiori045"]
[OnName num="Shiori"]
"I know, but... I can't get it down my throat..."
[cpg cn=true]

I guess she was feeling responsible for all this.
[cpg]

The expression on Shiori 's face was gloomy the whole time.
[cpg]

Michi also looked worried and spoke up, offering her another can of food.
[cpg]

[WAIT time=100]
[VOICE f="Michi097"]
[OnName num="Michi"]
“Even if you aren’t hungry, try to eat. You can’t take your medicine on an empty stomach.”
[cpg cn=true]

Shiori nodded at Michi's words.
[cpg]

Still, Shiori's stomach seemed to have reached its limit, and only about half of her tiny little can was gone. 
[cpg]

[WAIT time=100]
[VOICE f="Shiori046"]
[OnName num="Shiori"]
“I don't think I can eat it all in one sitting..., so I'm going to…save it for dinner…"
[cpg cn=true]

[OnName num="Kenji"]
"I see..."
[cpg cn=true]

Shiori put the fork that was in her right hand on her half-eaten can and gently put the round lid on top.
[cpg]

[BG f="b_l_1f_entrance_p4.ui" time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="1/3" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_1" pos="3/3" time=1000]
[WAIT time=1100]
[VOICE f="Erika143"]
[OnName num="Erika"]
"By the way, Shiori, how old are you? You look about the same age as us, but where do you go to school?"
[cpg cn=true]

Perhaps she didn't like the fact that I was only concerned about Shiori, but Erika took it upon herself to interrupt me.
[cpg]

Not just Takagi, but also Hosokawa and Yuna listened to this question with great interest.
[cpg]

[FACE method="change_4" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori047"]
[OnName num="Shiori"]
"Well..., I've never been to school..."
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika144"]
[OnName num="Erika"]
"Whaaaatー? Whyー? Do such people even exist?!"
[cpg cn=true]

.........
[cpg]

Everyone was surprised by Shiori's answer, but Erika, who had left things like delicacy in her mother's womb, kept going.
[cpg]

When Shiori timidly looked down, Michi spoke up instead.
[cpg]

[FACE method="change_1" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi098"]
[OnName num="Michi"]
"Shiori has been physically weak ever since she was little, so she has always been homeschooled by a private tutor. Despite all that, she’s intelligent enough to get into Tokyo University straight away, you know?"
[cpg cn=true]


[FG f="CHA08_p3_01_a.ui" method="change_5" pos="3/3" time=1000]
[WAIT time=100]
[VOICE f="Hosokawa070"]
[OnName num="Hosokawa"]
"Wow… That's amazing. You must have a very good tutor.”
[cpg cn=true]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Michi099"]
[OnName num="Michi"]
"Actually, I'm her tutor."
[cpg cn=true]

[FACE method="change_2" pos="3/3"]
[WAIT time=100]
[VOICE f="Hosokawa071"]
[OnName num="Hosokawa"]
"Whoa!"
[cpg cn=true]

[OnName num="Kenji"]
"Wow!"
[cpg cn=true]

Was Michi not only looking after Shiori's health, but also her studies?
[cpg]

Of course doctors are smart, but she was truly a super woman.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1" pos="3/3" time=1000]
[WAIT time=100]
[VOICE f="Erika145"]
[OnName num="Erika"]
"It's so nice that you don't have to go to school. I'm so jealous!"
[cpg cn=true]

Shiori shook her head at Erika with a sigh.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=100]
[VOICE f="Shiori048"]
[OnName num="Shiori"]
"I've always longed to go to… school. I also wanted to experience… playing sports and field trips."
[cpg cn=true]

[OnName num="Kenji"]
"That's right..."
[cpg cn=true]

In elementary and junior high, there was always at least one sickly person in my class, and they could only watch us during PE.
[cpg]

The look in Shiori's eyes now reminded me of that same forlorn look in my friend’s eyes as they watched everyone run around.
[cpg]

Yuna seemed to feel the same way as she showed concern for Shiori.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_2" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna080"]
[OnName num="Yuna"]
"You know..., If you'd like, you can take a walk with me in the future. The air around here is good, and having a picnic lunch is fun. It's like a field trip."
[cpg cn=true]

;//エフェクト
[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=2000]
[free time=100]
[BG f="b_l_1f_entrance_p4.ui" time=100]
[WAIT time=100]
;//【ＢＧ】図書館・１階・エントランス　夜（暗／蝋燭）******************************************************
[transition target={false} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=2500]
[window target=true]

;//[BGM f="d1"]


[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi100"]
[OnName num="Michi"]
"Well, why don't I start cleaning up?"
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Yuna081"]
[OnName num="Yuna"]
"I'll help."
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_1" pos="3/3" time=1000]
[WAIT time=100]
[VOICE f="Hosokawa072"]
[OnName num="Hosokawa"]
"Let's divide up the work."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi101"]
[OnName num="Michi"]
"Thank you. Give the cans a little rinse with the water from the tap and put them in a garbage bag."
[cpg cn=true]


[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1000]
[free time=100]
[WAIT time=1000]

[transition target={false} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1500]
[window target=true]


After we had finished cleaning up, blankets were handed out to everyone.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi102"]
[OnName num="Michi"]
"So..., we need to decide where we're going to sleep."
[cpg cn=true]

When Michi said that, Erika clung to me as if she had been waiting for me.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_2" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika146"]
[OnName num="Erika"]
"I want to sleep with Kenji!"
[cpg cn=true]

[OnName num="Kenji"]
"Hey..."
[cpg cn=true]

.........
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi103"]
[OnName num="Michi"]
"You can't."
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika147"]
[OnName num="Erika"]
"Why not?!"
[cpg cn=true]

For any number of reasons. Thank God Michi said as much.
[cpg]

I know that if I'm in a room with Erika I'll be up all night.
[cpg]

I didn't want to get caught up in her ghost stories or some other nonsensical chit-chat.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi104"]
[OnName num="Michi"]
"Even if it is just for one night, if anything happens, I will be scolded by all your parents. I'll be the responsible adult here and give out room assignments."
[cpg cn=true]



Every single thing that Michi said was true.
[cpg]

She was the only adult in this group, and we should listen to her.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi105"]
[OnName num="Michi"]
"All the boys, Kenji, Mr. Takagi, and Mr. Hosokawa, will use the general collection room. Erika and Yuna, please use the map and history room on the second floor on the right."
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Yuna082"]
[OnName num="Yuna"]
"Understood. Thank you very much."
[cpg cn=true]

[VOICE f="Erika148"]
[OnName num="Erika"]
"Boo~"
[cpg cn=true]

[free time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi106"]
[OnName num="Michi"]
"Oh, and if you can't sleep, you can read a book, but make sure you put the candle on the stone floor, away from the bookshelf. Because if there's a fire, it won't be noticed right away."
[cpg cn=true]

[OnName num="Kenji"]
"Yes, ma'am."
[cpg cn=true]

After all that was said, it seemed like we were going to be dismissed…, but then Erika said something unnecessary again.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Erika149"]
[OnName num="Erika"]
"Where are you two going to sleep?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi107"]
[OnName num="Michi"]
"I'll sleep in the infirmary."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Shiori049"]
[OnName num="Shiori"]
"I'm going to..., my own private room."
[cpg cn=true]

[FACE method="change_5" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika150"]
[OnName num="Erika"]
"You have a room? Perhaps even a bed?"
[cpg cn=true]

[FACE method="change_7" pos="1/3"]
Shiori nodded apologetically at Erika's words.
[cpg]

[FACE method="change_3" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika151"]
[OnName num="Erika"]
"Hey, that's not fair!"
[cpg cn=true]

[OnName num="Kenji"]
"Erika! How's that unfair? Don't say that?"
[cpg cn=true]

This was Shiori's private library, so if there was a bed there, she had the right to sleep there.
[cpg]

Moreover, since Shiori was sickly, there was no reason to call that unfair.
[cpg]

[FACE method="change_3" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi108"]
[OnName num="Michi"]
"Erika, as I told you before, Shiori is frail. Besides, it's not her fault that we're in this situation, is it?"
[cpg cn=true]

[VOICE f="Michi1108"]
[OnName num="Michi"]
"So, why don't you think about who's fault it really is?"
[cpg cn=true]


[FACE method="change_4" pos="3/3"]
[WAIT time=100]
[VOICE f="Erika152"]
[OnName num="Erika"]
".................."
[cpg cn=true]

Michi, who was usually so gentle and soft-spoken, snapped at Erika in a sharp voice, and that tyrant seemed unable to say anything and fell silent.
[cpg]

[FACE method="change_1" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi109"]
[OnName num="Michi"]
"Mr. Hosokawa."
[cpg cn=true]

[FG f="CHA08_p3_01_a.ui" method="change_7" pos="1/3" time=800]
[WAIT time=100]
[VOICE f="Hosokawa073"]
[OnName num="Hosokawa"]
"Yes?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[WAIT time=100]
[VOICE f="Michi110"]
[OnName num="Michi"]
"If she goes to Kenji in the middle of the night, please report it to me immediately."
[cpg cn=true]

[FACE method="change_2" pos="1/3"]
[WAIT time=100]
[VOICE f="Hosokawa074"]
[OnName num="Hosokawa"]
"Yes, ma'am! Leave it to me!"
[cpg cn=true]

Michi was using Hosokawa like a tool, she was good...
[cpg]

He was the loyal dog type.
[cpg]

On top of that, it was an order from his beloved Michi, so he will definitely keep his word.
[cpg]

And I was grateful for it.
[cpg]

[FACE method="change_1" pos="1/3"]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[WAIT time=100]
[VOICE f="Michi111"]
[OnName num="Michi"]
"Well, good night, everyone."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_1" pos="3/3" time=800]
[WAIT time=100]
[VOICE f="Yuna083"]
[OnName num="Yuna"]
"Good night."
[cpg cn=true]

[free time=1500]
[WAIT time=800]

And so, we scattered, one by one, to go to the bathroom or grab our blankets and get ready for bed.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3" pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Erika153"]
[OnName num="Erika"]
"...geez, acting all high and mighty."
[cpg cn=true]

As soon as Michi and Shiori left, Erika started complaining.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika154"]
[OnName num="Erika"]
"Maybe it's just me, but it's none of her business what happens between me and Kenji. I think she might have a thing for Kenji."
[cpg cn=true]

[OnName num="Kenji"]
"Huh? What are you talking about?"
[cpg cn=true]

Michi was into me?
[cpg]

If so, as a man I would be so ecstatic, but a mature woman like her being into a kid like me was more unrealistic than our current predicament.
[cpg]

But Erika nodded as if she were sure of it.
[cpg]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika155"]
[OnName num="Erika"]
"It's a woman's intuition. Yuna, wouldn't you agree?"
[cpg cn=true]

[FACE method="change_5" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna084"]
[OnName num="Yuna"]
"What..., me? I don't know...anything about that."
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[WAIT time=100]
[VOICE f="Erika156"]
[OnName num="Erika"]
"What?! Oh my gosh, why is everyone around me so dense?”
[cpg cn=true]

[FACE method="change_4" pos="4/5"]

As Erika stomped her feet before us, Yuna and I looked at each other and sighed.
[cpg]

I was glad that she was here to keep the mood from getting too gloomy, but I didn’t want to be overcome with exhaustion on a regular basis.
[cpg]


[VOICE f="Takagi059"]
[OnName num="Takagi"]
"Hey, Mr. Azuma~. Where do you want to set up camp?"
[cpg cn=true]



Then Takagi strolled into our room, and I followed behind, leaving Erika and Yuna.
[cpg]



[OnName num="Kenji"]
"See you two tomorrow, then."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Yuna085"]
[OnName num="Yuna"]
"Yeah. Good night."
[cpg cn=true]

[VOICE f="Erika157"]
[OnName num="Erika"]
"Nighty night. Oh, and if you get lonely tonight, you can always come on over!"
[cpg cn=true]

[OnName num="Kenji"]
"Who would want to go over there at night?"
[cpg cn=true]


[free time=900]
[BG f="black.ui" time=900]
[WAIT time=1500]
;//[BGM f="d1"]
[BG f="b_l_1f_nbr_p4.ui" time=1000]
;//【ＢＧ】図書館・１階・一般書の部屋　夜（暗）******************************************************

[WAIT time=1500]



Us three guys who were assigned the usual room decided to sleep on the carpeted space in the corner of the children's book section.
[cpg]

Each of us were wrapped in our blankets and secured our own sleeping position, and suddenly started chatting.
[cpg]

[FG f="CHA07_p3_01_a.ui" method="change_1" pos="2/5" time=800]
[FG f="CHA08_p3_01_a.ui" method="change_1" pos="4/5" time=800]
[WAIT time=100]
[VOICE f="Hosokawa075"]
[OnName num="Hosokawa"]
"This is one hell of a mess we're in."
[cpg cn=true]

[VOICE f="Takagi060"]
[OnName num="Takagi"]
"But it's a lot of fun. I'm happy to be able to spend time with Shiori-kins ♪ Munch, munch..."
[cpg cn=true]

Takagi was lying down and chewing on his precious chocolate bar.
[cpg]

But to tell you the truth, I was thinking the same thing as him.
[cpg]

I wouldn't have had a chance to talk to Shiori if it wasn't for this.
[cpg]

Today, I was able to hear Shiori talk about how she had never been to school, and I think she was slightly more open to conversation than usual.
[cpg]

I'm not sure if it's because she felt guilty, but it was a good thing for me.
[cpg]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa076"]
[OnName num="Hosokawa"]
“Well, this is an unexpected opportunity. Even tomorrow morning, there’s no way people will come early in the morning.”
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa1076"]
[OnName num="Hosokawa"]
"At least until opening time, we'll have the girls all to ourselves."
[cpg cn=true]


I had no idea, but besides Takagi and Hosokawa, there seemed to be other Shiori and Michi fans.
[cpg]

When I asked him about it, Hosokawa responded in disgust.
[cpg]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa077"]
[OnName num="Hosokawa"]
"Sure, there are some rare books here, but with bad traffic, strict rules, and no checkout…”
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa1077"]
[OnName num="Hosokawa"]
“What’s the point in coming here? It’s obvious that they just want to get close to the girls.”
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi061"]
[OnName num="Takagi"]
“Some old people who live deeper in the woods sometimes come here on a walk, but other than that, the men are definitely after one or the other."
[cpg cn=true]

[OnName num="Kenji"]
"I didn't know that..."
[cpg cn=true]

I thought that my only rival was Takagi, but in fact there were more enemies lying in wait.
[cpg]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa078"]
[OnName num="Hosokawa"]
"You two have your eyes set on Shiori, right? I'm all about Ms. Kisaragi."
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi062"]
[OnName num="Takagi"]
"Is it okay to say such a thing~? She calls Mr. Azuma by his first name, right?"
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa079"]
[OnName num="Hosokawa"]
"Gulp… I-I don’t mind that much, because I have a lot in common with her. I’m sure we’ll become even closer once I get my medical license soon."
[cpg cn=true]

[OnName num="Kenji"]
"Yeah, of course. Hosokawa, what kind of doctor are you going to be?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa080"]
[OnName num="Hosokawa"]
"I haven't decided yet."
[cpg cn=true]

[OnName num="Kenji"]
"Huh?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa081"]
[OnName num="Hosokawa"]
“No need to decide on a specialty yet. But if you ask me, I'm against the division of specialties these days.”
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa1081"]
[OnName num="Hosokawa"]
"It's important to have a wide range of knowledge so that you can have multiple methods to treat any patient, like in the past. Just like Ms. Kisaragi."
[cpg cn=true]


[OnName num="Kenji"]
“Uh, Michi is a physician, right?"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa082"]
[OnName num="Hosokawa"]
"A medical license is not something you get for each field. You know those small hospitals with signs that say 'ENT, Ophthalmology, Gynecology'?”
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa1082"]
[OnName num="Hosokawa"]
“It's not that there are a bunch of specialists, it's just that there are a bunch of practicing doctors with different specialties.”
[cpg cn=true]

[OnName num="Kenji"]
"What? So they just put it on their sign because they're good at it?"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi063"]
[OnName num="Takagi"]
"It's like you're introducing yourself by saying you're good at PE, arts and crafts, and music."
[cpg cn=true]

[OnName num="Kenji"]
"I'm becoming a little scared of private hospitals..."
[cpg cn=true]

While we were chatting, a thought occurred to me.
[cpg]

[OnName num="Kenji"]
"In addition to internal medicine, Michi also has other specialities?"
[cpg cn=true]

However, Hosokawa did not answer that question.
[cpg]

[FACE method="change_7" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa083"]
[OnName num="Hosokawa"]
"Why? Why do you want to know so much about her?"
[cpg cn=true]

He had taken off his glasses to go to bed, and Hosokawa's eyes looked like razor thin lines.
[cpg]

[OnName num="Kenji"]
"No, not really. Just curious."
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa084"]
[OnName num="Hosokawa"]
“I’m not sure. He's probably trying to get information about Ms. Kisaragi out of me and then go back to Shiori if he has to. I'm not going to fall for it."
[cpg cn=true]

[OnName num="Kenji"]
"Oh, no..."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi064"]
[OnName num="Takagi"]
"Mr. Azuma is quite the clever guy, isn't he? I'm going to be careful too. Munch, munch..."
[cpg cn=true]

[OnName num="Kenji"]
"It's not like that."
[cpg cn=true]

[FACE method="change_1" pos="4/5"]
[WAIT time=100]
[VOICE f="Hosokawa085"]
[OnName num="Hosokawa"]
"I'm about to blow out the candles, Takagi. Are you sure you don't want to rinse out your mouth?"
[cpg cn=true]

Hosokawa warned Takagi, who was always eating chocolate bars.
[cpg]

[FACE method="change_2" pos="2/5"]
[WAIT time=100]
[VOICE f="Takagi065"]
[OnName num="Takagi"]
"It's okay, it's okay. It's better to have the taste of chocolate in your mouth while you sleep, so you can dream better."
[cpg cn=true]

[OnName num="Kenji"]
"Gross..."
[cpg cn=true]

Takagi's mouth was probably full of bacteria...
[cpg]

The thought of it gave me nightmares, so I burrowed like a worm into my blanket and went to sleep.
[cpg]

Shiori…I wondered if she had eaten properly…
[cpg]


[free time=2000]
[BG f="black.ui" time=2000]
[WAIT time=3000]
[STOPBGM]


[stopse g=2]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="ep005.ks" target="*start"]


