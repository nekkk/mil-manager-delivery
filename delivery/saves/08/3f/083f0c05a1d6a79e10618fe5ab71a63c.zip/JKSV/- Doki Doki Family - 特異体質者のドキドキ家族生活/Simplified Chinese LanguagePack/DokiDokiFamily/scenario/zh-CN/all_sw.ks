
*start
;//あねいもままの射精管理　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//寿々音　裸　私服　スーツ
;//ひまり　裸　私服　制服
;//砂羽　　裸　私服

;//以下音声なし
;//吾郎 父親 男子学生Ａ 男子学生Ｂ
;//医者 女子学生 女子学生Ａ 女子学生Ｂ 男子学生
;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//寿々音　一人称「私」　ひまり呼び「ひまり」　砂羽呼び「お母さん」　吾郎呼び「吾郎」
;//ひまり　一人称「私」　寿々音呼び「お姉ちゃん」　砂羽呼び「お母さん」　吾郎呼び「お兄ちゃん」
;//砂羽　一人称「私」　寿々音呼び「寿々音」　ひまり呼び「ひまり」　吾郎呼び「吾郎」
;//吾郎　一人称「俺」　寿々音呼び「姉さん」　ひまり呼び「ひまり」　砂羽呼び「母さん」


;###################################################################
*Ep000|神秘的宪法。
;###################################################################

[SCENE id=0]


[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[stflag jump_scene=1]


;///////////////////////////ここからが本編です///////////////////////////



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_me"]
;//ブラックアウト





当我还很年轻的时候。
[cpg]


我的妈妈和爸爸在一次事故中去世。我当时还是个孩子，所以我并不真正知道发生了什么事。
[cpg]


我记得我也在哭，因为我周围的人都在哭，这让我莫名地害怕。
[cpg]


我认为失去父母的真正悲痛是在更远的地方。
[cpg]


我的一个远房亲戚萨瓦-高坂也参加了葬礼。她现在是我的母亲，我的岳母。
[cpg]


我想这也是我第一次见到我的嫂子，铃音。
[cpg]



;//下記寿々音のセリフは子供の頃の声です






[VOICE f="Suzune001"]
[OnName num="suzune"]
...... 不要哭。你在天堂的母亲和父亲也会哭泣。
[cpg cn=true]


我想我当时甚至没有理解他的大部分意思。
[cpg]


我想我姐姐当时是出于好意。
[cpg]


她甚至在忍耐即将到来的泪水。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我的家庭包括我的母亲和父亲，我的姐姐铃音和我的妹妹绯红。而我是被收养的，所以我们有五个人。
[cpg]


没有一个人与我有血缘关系。我想我与他们有一点关系，但我与绯红和她的妹妹的关系比我与我的堂兄弟姐妹的关系更远。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari001"]
[OnName num="himari"]
'哦，我不想去学校。......，这是五月的病，不是吗？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune002"]
[OnName num="suzune"]
'现在已经是六月了。别傻了'。
[cpg cn=true]


绯红和她的妹妹正在进行这样的对话。我也有点呆滞。
[cpg]


[OnName num="gorou"]
'我知道这是低气压的影响，这......'
[cpg cn=true]

[free time=1000]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa001"]
[OnName num="sawa"]
'咯咯笑。'但他们说低压对你有好处！'
[cpg cn=true]


[OnName num="gorou"]
'真的......？　我从来没有听说过。"
[cpg cn=true]


[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune003"]
[OnName num="suzune"]
'我也听说了。你知道，寿命长的地方气压都很低'。
[cpg cn=true]


我不知道。不过我有点懒。
[cpg]


[OnName num="gorou"]
"懒惰会增加你的预期寿命还是......？"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari002"]
[OnName num="himari"]
'那我就会活得更久，因为我每天都很懒惰。叹气，我不想去'。
[cpg cn=true]


爸爸已经在工作了，我们却在进行这种愚蠢的谈话。
[cpg]


没有什么成果，如果有的话，只是获得一点琐事。......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************





我姐姐是我所在学校的老师。
[cpg]


所以她当然比我更早离开家。问题是我和绯红。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Himari003"]
[OnName num="himari"]
'......，我们不是有六月病吗？　我想就是这样了。"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa002"]
[OnName num="sawa"]
'我不知道。即使有，我也不认为绯红会有什么不同。"
[cpg cn=true]


[OnName num="gorou"]
'对。它太慢性了，不可能是一种疾病，你知道。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Himari004"]
[OnName num="himari"]
我不知道这是否符合宪法。......
[cpg cn=true]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]

[window target=true]


宪法》。是的，这是一个关于宪法的故事。
[cpg]


我过去是，现在仍然是，受到某种体质的影响。
[cpg]




;//ブラックアウト


[window target=false]




[BG f="b_01_1.ui" time=1000]
[WAIT time=1500]


[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





我一边想，一边走在与绯红不同的路上。
[cpg]


有许多方法可以用一个词来表达宪法。早上难以醒来，对酒精的高度容忍和愤怒也是构成因素。
[cpg]


在这样的情况下，我已经形成了一种 "捣蛋的依赖"。
[cpg]


我最喜欢的漫画是一部浪漫的喜剧。我最喜欢的动画片也是一部爱情喜剧。我最喜欢的音乐是偶像们唱的情歌。
[cpg]


这很令人尴尬，但我不能没有这种东西。......
[cpg]


我渴望得到一种叫做 "捣蛋 "的东西。我甚至不知道我怎么会变成这样。
[cpg]


[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[WAIT time=2000]

;//========================================
;//●ＣＧ非エロ（授業をするヒロイン１。黒板に背を向けて本を手に持っている）ev_01
;//人物１：ヒロイン１
;//服装１：スーツ
;//場所　：学園教室
;//時間　：昼
;//========================================


[WAIT time=1000]
[BGM f="bg_d2"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]






[VOICE f="Suzune004"]
[OnName num="suzune"]
'嗯，在这里很容易出错......，像这样......'。
[cpg cn=true]


上午的最后一堂课是我姐姐的。
[cpg]

当她面对黑板时，她很有趣，很聪明。
[cpg]


说实话，她在男孩中相当受欢迎，至少可以这么说。
[cpg]


[OnName num="male_student_A"]
'...... 小坂老师很漂亮，不是吗？
[cpg cn=true]


[OnName num="male_student_B"]
'哦......，你太有风格了，那个人。
[cpg cn=true]


但是，尽管她是我的嫂子，当人们这样称呼我的家人时，我觉得有点不舒服。
[cpg]


我当然也姓小坂，所以人们问我各种各样的问题，但我假装不知道。
[cpg]


如果他们知道我是我妹妹，我就会有大麻烦。
[cpg]


我可以看到，我将受到不必要的嫉妒和奇怪做法的困扰，所以我不告诉他们。......。
[cpg]


[OnName num="male_student_A"]
'这些乳房是一种致命的武器。我不知道他们吃什么才能长成这样。......"
[cpg cn=true]


我也知道，但我没有说。
[cpg]


;**【ＣＧ】 ev_01_a ***********************
[CG id=0 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Suzune005"]
[OnName num="suzune"]
'嘿，那里。你应该避免和我说话。"
[cpg cn=true]


[OnName num="male_student_A"]
'......'
[cpg cn=true]

我的意思是，她说的正是她的妹妹，她可能已经注意到了这一点。


尽管如此，我认为她不动声色是很好的。
[cpg]


如果你只看她现在的样子，你会看到她是一个坚实的人。......
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[window target=true]


对。她在学校表现得相当稳重，但我知道她有点不在状态。
[cpg]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『学園教室』（昼）******************************************************





她经常忘记事情。她在当老师时很少犯错，但在家里却相当粗心。
[cpg]


在帮助做饭的时候，她把盐当成糖是常有的事。
[cpg]


我来到这所学校，因为它是留给我唯一可以滑倒的地方。
[cpg]


对我来说，与我妹妹在同一所学校是很尴尬的。但我再也忍不住了。
[cpg]


我做不起浪人，我在这里是因为......，我在这里。
[cpg]


顺便说一下，绯红是一个比较聪明的人。与我相反的是，她是那种看起来不合群但却能出人意料地做事的人。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************





而与这些情况完全无关的是，我当时遇到了危机。
[cpg]


即使在学校，我对 "Doki-Doki "的依赖也没有减少。
[cpg]


然而，我不能在学校传播漫画，所以我用手机听音乐。
[cpg]


太甜太酸的情歌。尽管这是一首偶像歌曲，但它是现在连学生都不听的那种东西。
[cpg]


我怎么会变成这样？......，我是这么想的，但我对自己是疯子这一事实无能为力。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************





最重要的是，你不能只是去学校，并期望获得良好的教育。
[cpg]


我在路上没有和绯红碰面。这是与她相反的方向。
[cpg]


[SE f="se003"]
;//【ＳＥ】『ドア開く』

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[OnName num="gorou"]
我回来了。"
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（主人公に笑顔で抱きつくヒロイン。胸を腕に押し当てている）ev_02
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の家＿玄関
;//時間　：夕方
;//========================================


[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


我一回到家，绯红就找到我。
[cpg]


[VOICE f="Himari005"]
[OnName num="himari"]
'欢迎回家，大哥哥！
[cpg cn=true]

;//＠
;//彼女は私服に着替えていて、もうとっくに家に戻っていたようだった。


他拍拍屁股走到门口，拥抱了我。
[cpg]


[OnName num="gorou"]
'阿志，你太近了......，都快打到我了。
[cpg cn=true]


;//;**【ＣＧ】 ev_02_a ***********************
;//[CG id=1 index=1 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="Himari006"]
[OnName num="himari"]
你太调皮了。你在用这种方式看我妹妹吗？"
[cpg cn=true]


[OnName num="gorou"]
...... 没什么。"
[cpg cn=true]


我很激动，感觉到一些我无法伪造的东西。
[cpg]


[OnName num="gorou"]
我的意思是，绯红有五月的蓝调，对吗？　你看起来已经很好了。"
[cpg cn=true]


;//;**【ＣＧ】 ev_02_0 ***********************
;//[CG id=1 index=0 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="Himari007"]
[OnName num="himari"]
'我在晚上感觉更好。我想知道为什么'。
[cpg cn=true]


绯红假装不明白，但我认为她只是有一个脆弱的早晨。
[cpg]


这样的话语几乎传入我的喉咙，但我没有说出来。
[cpg]


[OnName num="gorou"]
'现在，离我远点，......，我需要穿上衣服。
[cpg cn=true]



[VOICE f="Himari008"]
[OnName num="himari"]
'Duh.然后我就看着你换衣服'。
[cpg cn=true]


你在说什么。看我弟弟穿衣服有什么乐趣？
[cpg]


[OnName num="gorou"]
'我不认为看到我的裸体是件有趣的事，...... 可怜的东西。
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]

我推开试图进入我房间的Himari，然后穿上衣服。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





我只是在我的房间里闲逛。他说："我是一个很有耐心的人，我希望我的朋友们都能理解我。"他说："我希望我的朋友们都能理解我。
[cpg]


你需要做的第一件事是确保你对你所做的事情有充分的了解。我对这样的事情感到紧张。
[cpg]


我想我的心脏正在遭受某种疾病的折磨。　或者头部。
[cpg]



[window target=false]



[BG f="b_06_4.ui" time=1500]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





之后，我在网上查了查这个，那个。被禁止的部分，或者说是我长期以来一直回避的部分。
[cpg]


是否有爱的依赖这一回事。实际上，我更依赖刺激本身，而不是爱情。......
[cpg]


不是说没有，显然。但他们说这在已经和别人有关系的女性中更常见。
[cpg]


我没有女朋友，我是个男人，......，最近甚至感觉我必须要紧张才能呼吸。
[cpg]


也许我应该偷偷溜去医院。我会这样做的。
[cpg]


[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ非エロ（ヒロインが料理をしている。手伝う主人公。主人公が横にいてヒロインは味見してる感じ）ev_03
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の家＿ダイニングキッチン
;//時間　：夜
;//========================================

[WAIT time=1000]

[SE f="se006"]
;//【ＳＥ】『料理』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]




当我走到厨房时，我母亲正在准备晚餐。
[cpg]

[OnName num="gorou"]
'我也要做什么吗？　妈妈。"
[cpg cn=true]


[VOICE f="Sawa003"]
[OnName num="sawa"]
'哦，你要帮我？　谢谢你！"
[cpg cn=true]



有时我姐姐会帮忙做饭，但我没有看到她。
[cpg]


[OnName num="gorou"]
你妹妹在哪里？"
[cpg cn=true]



[VOICE f="Sawa004"]
[OnName num="sawa"]
'你已经在你的房间里下去了!她一定也很难受。"
[cpg cn=true]


我相信你是对的。当她松懈时，她松懈到了极限。
[cpg]


从这个角度来看，他并不是一个完全稳固的人。
[cpg]


;**【ＣＧ】 ev_03_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Himari009"]
[OnName num="himari"]
祝你好运，你们两个。
[cpg cn=true]


绯红的声音从后面传来。
[cpg]


我认为这家伙可以帮助做家务，但他没有。
[cpg]


他是否像他姐姐那样懒惰？
[cpg]


绯红是如此懒惰，以至于她无法关闭。
[cpg]


...... 仔细想想，我的母亲是最靠谱的一个吗？　真是不费吹灰之力。
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





这就是为什么我们都在这里。爸爸当然是在那里吃饭的。
[cpg]


[OnName num="father"]
'......，这是怎么回事。五郎，什么事困扰着你？"
[cpg cn=true]


[OnName num="gorou"]
'不，谢谢你。我很好。"
[cpg cn=true]


我看起来很阴沉吗？好吧，我可以看起来很阴沉吗？
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Sawa005"]
[OnName num="sawa"]
'我也很担心。你最近一直表现得很奇怪，很害怕。
[cpg cn=true]


我在努力不让他们看到我的恐惧。......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune006"]
[OnName num="suzune"]
'五郎以前受过惊吓，是吗？　在学院里更是如此。"
[cpg cn=true]


你是这样看的吗？我有点震惊了。
[cpg]




;//ブラックアウト


[window target=false]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[STOPBGM]
[WAIT time=1000]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************





第二天休息。我正在去医院的路上。
[cpg]


我仍然有一种想要一直悸动的感觉。我想这只是我的体质。......
[cpg]


就这一点而言，我想知道我的身体发生了什么。
[cpg]


;//ブラックアウト


[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]


[SE f="se003"]
;//【ＳＥ】『ドア開く』

[WAIT time=1000]


所以我在一家小医院进行了检查。......。
[cpg]


[OnName num="doctor"]
'这是......，发生了什么事。我不明白。......"
[cpg cn=true]


显然，我的身体正在发生一些奇怪的事情。
[cpg]


他们把我转到一家更大的医院，我显然不得不向家人倾诉。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿玄関』（昼）******************************************************





[OnName num="gorou"]
我回来了。......
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa006"]
[OnName num="sawa"]
'欢迎回来。怎么了，你不是出去购物了吗？
[cpg cn=true]


[OnName num="gorou"]
我想要的那款产品已经卖完了，.......。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa007"]
[OnName num="sawa"]
'哦，是的。那太糟糕了。...... 那是什么？"
[cpg cn=true]


[OnName num="gorou"]
啊！"
[cpg cn=true]


一封介绍信从袋子里掉了出来。我愣了一下。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[OnName num="father"]
'...... ill?你能单独去咨询这个问题，已经很不错了'。
[cpg cn=true]


[OnName num="gorou"]
'不，我是说，哈哈......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune007"]
[OnName num="suzune"]
'我也很好奇。你有什么症状？
[cpg cn=true]


[OnName num="gorou"]
'嘿，我能说什么呢......，这有点像感冒。
[cpg cn=true]


苦难。我很痛苦。随着时间的推移，这一切都会变得清晰。
[cpg]


甚至绯红和她的母亲也在做神秘的表情。绯红的表情是这样的，我一定让她担心了。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夕方）******************************************************





所以我立即前往我被转诊的医院。我的家人和我一起来到这里。
[cpg]


从那里开始就很艰难。他们说我需要进行全面检查或其他什么。
[cpg]


据说这是一种罕见的疾病，只影响到数百万人中的一个，甚至更少。
[cpg]


我很不解，但还是照他们说的做了，解释说有可能会陷入严重的状况。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





那晚的晚餐很尴尬。
[cpg]


吃饭时还可以，但饭后的家庭会议，或......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa008"]
[OnName num="sawa"]
'......，运气不好。这就是为什么你独自在医院里。
[cpg cn=true]


在这一点上，我开始想，我至少可以和我父亲谈谈这个问题。
[cpg]


套用一句话，他的体质使他难以呼吸，除非定期提高心率。这已经随着年龄的增长而表现出来。
[cpg]


简而言之，如果你不提高你的心率，最坏的情况是你会诱发其他疾病。
[cpg]


他们威胁我说有可能陷入危急状态，我就头疼了。也许我的家人也会。
[cpg]

[free time=800]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sSuzune001"]
[OnName num="suzune"]
'你为什么不独自去......，看浪漫漫画或其他什么。这可能会有帮助。"
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="sHimari001"]
[OnName num="himari"]
'不!　如果我不能为此感到兴奋，我就会死。
[cpg cn=true]


死亡是一种夸张的说法，但它不是谎言。
[cpg]


毕竟，这是一种未知的疾病，任何事情都可能发生。
[cpg]


[OnName num="father"]
'嗯，这很好。五郎会自己处理好的，太过担心也不好。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari011"]
[OnName num="himari"]
'我不知道............ 我知道我很焦虑。
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（昼）******************************************************





我们这样一谈，就同意暂时由我来做自我评判。
[cpg]


日子就这样一天天过去了。我想知道这样做是否正确，但没有别的办法。
[cpg]


......在这一切之中。
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



一个早晨。爸爸去上班后，举行了一次家庭会议。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune002"]
[OnName num="suzune"]
'我想，你不是对我们有好感吗？
[cpg cn=true]



[OnName num="gorou"]
'嘿，你在说什么？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune003"]
[OnName num="suzune"]
'你是什么意思，你一定很激动？我和五郎甚至没有血缘关系'。
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSawa001"]
[OnName num="sawa"]
'是的，没错。我知道我也是如此。
[cpg cn=true]


甚至我的母亲也会加入进来，谈论这些话题。不过，这很好。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSuzune004"]
[OnName num="suzune"]
幸运的是，你白天也和我一起去学校。......
[cpg cn=true]


[VOICE f="sSuzune005"]
[OnName num="suzune"]
'如果你有一天有了悸动的冲动，而且变得太硬，你可以指望我们。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="3/3" time=800]
[VOICE f="sHimari002"]
[OnName num="himari"]
'你又不能依靠我！'这是不可能的。　你必须积极主动地与他们调情。"
[cpg cn=true]


绯红这么说，但她不是在开玩笑。
[cpg]

[OnName num="gorou"]
'我不想这样，我拒绝这样！'。　我绝对讨厌它。"
[cpg cn=true]

[SE f=se010]
;//【ＳＥ】『走る』
[free time=1000]
[WAIT time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Suzune013"]
[OnName num="suzune"]
'哦，绯红！　别让他跑了，把他按住。"
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Himari013"]
[OnName num="himari"]
'我知道!　大哥，你想逃跑是没有意义的。"
[cpg cn=true]




[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[WAIT time=2000]
;//ブラックアウト



就这样。
[cpg]


我受到了我的姐姐、妹妹和母亲的所谓'捣蛋管理'。......
[cpg]



[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（朝）******************************************************



然后，在了解了我的体质后，我感到有一种额外的欲望，想让自己激动起来。
[cpg]


我想感到兴奋。如果我不碾压，我就会死。这是一部多么困难的宪法。
[cpg]


但我不能在上课时听音乐，上午的课程结束后，我感到很晕眩。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************


当我失去意识时，我的姐姐帮助我。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune014"]
[OnName num="suzune"]
她说：'我想知道我应该去哪里，.......我知道这将是学生指导办公室。......
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune015"]
[OnName num="suzune"]
'但你也不应该过多地使用它。你怎么看？
[cpg cn=true]


我只能回答说我不知道。但最后，他们把我带到了学生咨询室。
[cpg]


我已经在挣扎着呼吸了，我不能再忍受了。
[cpg]


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

;//ブラックアウト


最后，我和我妹妹单独在一个封闭的房间里，没有人可以看到我。
[cpg]


[VOICE f="sSuzune006"]
[OnName num="suzune"]
'别误会，我不能为你做那么多。
[cpg cn=true]


说着说着，姐姐就把手放在了我的胸前。
[cpg]


[OnName num="gorou"]
'Ugh. ......'
[cpg cn=true]


这并不是说我从来没有意识到我妹妹是个女人。
[cpg]


当她离我如此之近时，我无法停止...... 扑腾。
[cpg]


那是一段无法形容的舒适时光。一个奇怪的时期，我感到紧张，但同时又很自在。
[cpg]

;//移植前シーンカット


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



[OnName num="gorou"]
'......，你每天都坚持这样做吗？
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune033"]
[OnName num="suzune"]
'这不是我的错，是吗？这更是你的错。"
[cpg cn=true]


他从学生指导办公室出来时这样说。
[cpg]


一般来说，这是一个相当糟糕的场景。
[cpg]


学生们可能不知道，但老师们知道我和我妹妹是姐妹和兄弟。
[cpg]




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（夕方）******************************************************


在这种事情发生时，时间就会流逝。
[cpg]


尽管从中午到现在没过多少时间，但我已经接近我的极限了。
[cpg]


如果我不被重击，我就会得另一种病，我明白了，我想是这样。......
[cpg]


我在挣扎着呼吸，好像在这之前我就要疯掉了。
[cpg]


[OnName num="female_student"]
'怎么了？　小坂君，你的行为很奇怪。"
[cpg cn=true]


[OnName num="gorou"]
'爸，我很好。这不算什么'。
[cpg cn=true]


不可能什么都没有，但我决定回答这个问题。
[cpg]


我不能再这样做了。当我看着女孩们的脸时，这就更难了。
[cpg]


这是一种来自我的体质的痛苦，我的体质显然与正常男孩的体质不同。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





而我正试图回到家里。
[cpg]


我不禁发现街上的所有女人都很有吸引力。这是不正常的。
[cpg]


但我无法单独控制我的感觉。
[cpg]


受控 "这个词太冷淡了。我正在被折磨，而不是被控制。
[cpg]


我回家的感觉是这样的。......
[cpg]


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[SE f="se003"]
;//【ＳＥ】『ドア開く』
[WAIT time=1000]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa010"]
[OnName num="sawa"]
'欢迎回来。你看起来很痛苦，戈罗。"
[cpg cn=true]


爸爸离开前的时间。
[cpg]


我想做点什么，我打算跪下来，向我妈妈求助。
[cpg]


这就是我的真实感受。我无法忍受这一点。
[cpg]


我不想忍受它。我紧紧抓住母亲。
[cpg]


[OnName num="gorou"]
我很高兴见到她，我也很高兴见到她。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa011"]
[OnName num="sawa"]
'咯咯笑。'对--你这样看着我，我什么也做不了。
[cpg cn=true]


这是在爸爸回来之前呢。我希望他能做一些事情。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト



[BG f="b_04_3_up.ui" time=1000]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7" time=1000]
[WAIT time=2000]


我被带到了我妈妈的房间。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa002"]
[OnName num="sawa"]
'好吧，那我要给你一个拥抱了。
[cpg cn=true]


[OnName num="gorou"]
'是的，你确定吗......？
[cpg cn=true]




[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa013"]
[OnName num="sawa"]
'没关系的。看到我的儿子处于痛苦之中，我很痛心'。
[cpg cn=true]


这样的话语引诱我到......
[cpg]

;//移植前シーンカット

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]


在母亲的怀抱中，我的眼泪都快流出来了。
[cpg]


这与兴奋的感觉有点不同。
[cpg]


但就解脱而言，我可能比和我妹妹在一起时更解脱。
[cpg]


这就是我母亲连我的焦虑都笼罩的程度。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[OnName num="father"]
......
[cpg cn=true]


[OnName num="gorou"]
"......"
[cpg cn=true]


晚餐时，我和爸爸都沉默不语。我认为有些事情，男人可以在某种程度上理解对方。
[cpg]


我是个男人，却爱上了你，这很令人尴尬，但......。
[cpg]


也许他们多少能理解这种尴尬的感觉。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="Himari014"]
[OnName num="himari"]
'妈妈，把酱油递给我。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa032"]
[OnName num="sawa"]
'好吧--给你。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune034"]
[OnName num="suzune"]
'你就在它旁边。自己去拿吧，绯红'。
[cpg cn=true]


女人进行这样的对话。这是一件非常、非常随和的事情。
[cpg]


或者说，他们甚至似乎很兴奋。明天他们会不会照顾绯红呢......？
[cpg]


我仍然不知道我的母亲和妹妹的情况。但绯红是我的妹妹。
[cpg]


对你的妹妹感到紧张是不正常的。
[cpg]


我感到那里有危险的东西，但我不能说什么。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





我脱下衣服，换上了睡衣。
[cpg]


在我睡觉的时候，我的症状并没有恶化，但这并不能缓解，因为.......。
[cpg]


我深深地叹了口气，为即将到来的事情感到担忧。
[cpg]


真的，会发生什么......？
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』朝チュン


[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



即使你在考虑要发生什么，早晨也会正常到来。
[cpg]


我以前睡觉的时候都很好，但今天我梦见我有一个可爱的女朋友。
[cpg]


这是连正常男人都很难醒来的那种梦。
[cpg]


我想找人帮忙，所以我还是去找我姐姐。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[BG f="b_04_1_up.ui" time=1000]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[WAIT time=2000]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune007"]
[OnName num="suzune"]
'什么？　早晨我不负责任。"
[cpg cn=true]


那是什么，这样的轮换已经建立了？
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune036"]
[OnName num="suzune"]
'我把早上的事留给了绯红。所以我希望你去找她。"
[cpg cn=true]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari015"]
[OnName num="himari"]
'早上好，大哥哥。你看起来不舒服。
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
不好。他说他的体质本来就很奇怪。
[cpg]


[OnName num="gorou"]
'...... 緋紅......，关于我的体质。
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari003"]
[OnName num="himari"]
'我知道--我知道。那么？　你想让我做什么？"
[cpg cn=true]


他在笑，想让我告诉他。
[cpg]


看来爸爸已经离家了。我想这就是为什么Himaru要告诉我这些。......
[cpg]


而这并不是一种毫无保留的说法。好吧，只有我、绯红、我姐姐和我母亲知道我们在做什么。
[cpg]


相反，爸爸是唯一不知道的人。只要我爸爸不在这里，我说什么又有什么关系呢？
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari004"]
[OnName num="himari"]
你曾经和一个女孩牵过手吗？
[cpg cn=true]


[OnName num="gorou"]
不，我不知道。"
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari005"]
[OnName num="himari"]
'嗯。那么如果有人这样对你，你会感到兴奋吗？
[cpg cn=true]

在她说这句话的时候，Himari握住了我的手。
[cpg]


然后，将他们的手指交织在一起，成为一种...... 情人的联系，或类似的形式。
[cpg]


我变得很紧张。而苦涩的感觉也消失了。
[cpg]


[OnName num="gorou"]
'谢谢你，.......'
[cpg cn=true]

[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari036"]
[OnName num="himari"]
现在你是我的了，大哥哥......ehehe。"
[cpg cn=true]


绯红似乎很高兴。
[cpg]


绯红可能也会有占有欲。
[cpg]


我不知道，但我有一种感觉，她是。......。
[cpg]

;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



然后我们吃早餐。姐姐看着我们手拉手，很是不安。
[cpg]


但我知道为什么会发生这种情况。
[cpg]


早上是绯红。在下午，或者说在学校，是我妹妹。晚上，我们又有一次与我母亲......，我相信。
[cpg]


我昨天和今天发现了这个问题。也许这就是他们一天三次的计算方法。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari037"]
[OnName num="himari"]
'这很好吃。炒蛋看起来不能做'。
[cpg cn=true]


是否有这样的事情，即不能做炒蛋？就在我这样想的时候，我妹妹探出头来。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune037"]
[OnName num="suzune"]
'你只是不想让他们，你......'。
[cpg cn=true]


绯红并不觉得她刚才和我牵手。
[cpg]


好像她切换得很快或什么的。
[cpg]


但她和我单独在一起时也是这样吗？
[cpg]


我不知道。我不知道，但如果你这样说，我母亲也是如此。......。
[cpg]


我的姐姐给了我一些 "砰 "的一声，但绯红和我的母亲却没有那么多。
[cpg]




;//ブラックアウト


[window target=false]

[STOPBGM]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



在她离开一段时间后，我们也去了学校。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Himari038"]
[OnName num="himari"]
我现在要走了。再见，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'嗯，嗯。那我就走了。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa033"]
[OnName num="sawa"]
'嗯，有一个好的一天。
[cpg cn=true]


这个微笑是什么意思？不，你的母亲看到了一切。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（朝）******************************************************





[OnName num="gorou"]
'哦，......，现在会发生什么......'。
[cpg cn=true]


我终于对自己说了我想了好几遍的话。
[cpg]


我不知道如果我不这样做会发生什么。
[cpg]


我继续过着让家人激动的生活，即使是婆媳关系。
[cpg]


那么我就不能把我的妈妈、姐姐和绯红看成只是家人。
[cpg]


我在痛苦中去了学院。
[cpg]





[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

;//[jump storage="ep001.ks" target="*start"]


;/////////////////////////////////////////////////////////////////////


*start

;###################################################################
*Ep001|悸动管理的开始
;###################################################################

;//ブラックアウト
[SCENE id=1]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]

[SE f="se002"]
;//【ＳＥ】『喧噪』

[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************





[OnName num="female_student_A"]
'你的情绪有些变化，小坂君，......。
[cpg cn=true]


[OnName num="female_student_B"]
是的，"他说。我只是一个食草动物，但我也有...... 忧郁症。"
[cpg cn=true]


我听到了，我听到了。我听着窃窃私语，想着。
[cpg]


他没有说我的坏话，这感觉很好。但是。
[cpg]


如果他们是因为我的宪法而这么说，我不知道该怎么说。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************




而到了午餐时间，已经很辛苦了。我的脑袋里满是想要捣乱的想法。
[cpg]



我无法理解上午的最后部分。
[cpg]


我很难呼吸，我不能再想别的事情了。
[cpg]


这让我很抓狂，扑面而来的依赖性真的让我很难受。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************





[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune038"]
[OnName num="suzune"]
'......，是时候了，这很痛苦。我知道它的大部分内容。"
[cpg cn=true]


[OnName num="gorou"]
'哦，拜托。我不能再这样做了，我不能。......"
[cpg cn=true]


女性化的话语从我口中说出。但我不能帮助它。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune039"]
[OnName num="suzune"]
'好吧。来吧。"
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植前シーンカット

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_03_2_up.ui" time=1000]
[WAIT time=1000]

我跟着他来到学生指导办公室。
[cpg]


我进去了，想知道这次他们会对我做什么。
[cpg]


...... 结果是，这和前几天的情况一样，这很好。
[cpg]


我可以看到我的姐姐是多么关心我，试图不过度刺激我。
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



捣毁管理。每天三次，使心率上升：......
[cpg]


这是一个相当怪异的情况，但这就是我所处的那种情况。
[cpg]


一天三次已经很困难了。我希望它是这个数字的两倍。
[cpg]


但我们不能无休止地触摸对方，这可能会越界。
[cpg]


是否有这样的治疗方法？有一些人具有难以置信的吸引力，他们接近我。
[cpg]


我不能做我想做的事。我被管理得无以复加。
[cpg]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（夕方）******************************************************





[OnName num="male_student_A"]
'我听说了。他和小坂老师一起走进了学生咨询办公室。
[cpg cn=true]


[OnName num="male_student_B"]
'发生了什么事。那你做了什么？"
[cpg cn=true]


我认为被这样质疑是很自然的。
[cpg]


但我无法回答任何问题。
[cpg]


[OnName num="gorou"]
'这是职业建议。......，这没什么可担心的。
[cpg cn=true]


[OnName num="male_student_A"]
'有传言说你从里面出来的时候躺在......，很慌张。
[cpg cn=true]


这就是他们得到信息的程度。我下次离开时要小心了。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夕方）******************************************************





啊，我离开的时候会小心的。我迫不及待地想回家。
[cpg]


现在轮到我妈妈了。今天我已经可以承受了，如果我可以说我可以承受的话。......
[cpg]


不过，这还是让人相当苦恼的事。
[cpg]


我甚至不能和同学们交谈，更不用说认真上课了。
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』


[OnName num="gorou"]
'塔，我回来了。......'
[cpg cn=true]




[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa003"]
[OnName num="sawa"]
'欢迎回来。你现在很难受吗？"
[cpg cn=true]


[OnName num="gorou"]
'什么，......？　不，嗯，是......"
[cpg cn=true]


我没有立即回答，压抑着自己的感觉，我真的希望现在就能做点什么。
[cpg]


不知为何，我不想说我理解。另一方面，让我的母亲告诉我也不好。......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa004"]
[OnName num="sawa"]
'你不必如此。你看起来很苍白'。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSawa005"]
[OnName num="sawa"]
'我们今天该做什么？　你想和我一起洗个澡吗？"
[cpg cn=true]


他们看穿了这一切，感到很难堪。
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_04_3_up.ui" time=1000]
[WAIT time=1000]


话虽如此，我还是不能以尴尬为由拒绝。
[cpg]

[VOICE f="sSawa006"]
[OnName num="sawa"]
'是的，一件游泳衣。有了这个，你就不会感到尴尬了'。
[cpg cn=true]

[OnName num="gorou"]
'但是，但是......，我可以吗？
[cpg cn=true]


[VOICE f="sSawa007"]
[OnName num="sawa"]
'好的。我不想再看到你痛苦的脸。
[cpg cn=true]


我按母亲的要求做了，然后去洗澡。
[cpg]


......，希望没有人发现。
[cpg]


;//========================================
;//●ＣＧエロ（石けんで洗いながら手コキ。ヒロインは背後から片手で主人公の乳首も弄りながらしごく）ev_08
;//人物１：ヒロイン３
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：主人公の家＿風呂
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


这有点像我不能说我没有问题......，因为我穿着游泳衣。
[cpg]


我不知道要花多少钱，但我不知道和家人这样做是否可以，即使他们没有血缘关系。
[cpg]


[VOICE f="sSawa008"]
[OnName num="sawa"]
'当你在洗澡的时候，我也要给你洗身体吗？
[cpg cn=true]


妈妈表现得好像无动于衷。
[cpg]


[OnName num="gorou"]
'是的，很好。我自己会做的'。
[cpg cn=true]



而我呢，我的声音都快变了。
[cpg]


;**【ＣＧ】 ev_08_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sawa038"]
[OnName num="sawa"]
'你这么说，但你真的想把我宠坏，不是吗？
[cpg cn=true]


我有一种想要被呵护的欲望。但我不能大声说出来。
[cpg]


我感觉我的母亲也知道这一点，并且正在接近我。
[cpg]


[OnName num="gorou"]
这真的很好。......
[cpg cn=true]


[VOICE f="sSawa009"]
[OnName num="sawa"]
'别憋着了。我有一个不激动的借口'。
[cpg cn=true]



[OnName num="gorou"]
'当你称它为借口时，就更尴尬了。
[cpg cn=true]


妈妈笑了，用肥皂和海绵给他们擦洗。
[cpg]


;**【ＣＧ】 ev_08_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa010"]
[OnName num="sawa"]
'那好吧，让我给你洗吧。
[cpg cn=true]

海绵触动了我。这已经足够让我的心跳加速了。......
[cpg]


[VOICE f="sSawa011"]
[OnName num="sawa"]
我可以感觉到你的脉搏在加快。吁。
[cpg cn=true]


她的手指在泡沫上滑行。这种痒痒的感觉是骗人的。......
[cpg]


渐渐地，呼吸变得不那么困难了。这本身就是一件令人欣慰的事情。
[cpg]


再加上我与这样一个美丽的人亲密接触的事实。
[cpg]


那是一段可以说是幸福的时光。这部宪法可能并不全是坏事。
[cpg]


[VOICE f="sSawa012"]
[OnName num="sawa"]
我不知道我是否已经洗了大部分的东西。你还有什么要我洗的吗？"
[cpg cn=true]


你还有什么意思......，你还打算做什么？
[cpg]



[OnName num="gorou"]
'你想让我说什么？
[cpg cn=true]


我想说这是一种阻力，但妈妈却拂袖而去。
[cpg]


;**【ＣＧ】 ev_08_b ***********************
[CG id=3 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa013"]
[OnName num="sawa"]
'这是什么？　我想不出来了。"
[cpg cn=true]


妈妈可能有点刻薄，不是吗？
[cpg]



[OnName num="gorou"]
'...... 如果你想不出来，就不要说了。
[cpg cn=true]

[VOICE f="sSawa014"]
[OnName num="sawa"]
'嗯。好吧，那我就把你冲下去。
[cpg cn=true]


感受到了温暖的水。它不仅使你的脉搏加快，而且我认为它也提高了你的体温。
[cpg]


也许我妈妈也是这样，......？
[cpg]


[VOICE f="sSawa015"]
[OnName num="sawa"]
'什么？　那张脸。你想让我多洗洗吗？"
[cpg cn=true]


[OnName num="gorou"]
'呃，不。这没什么。"
[cpg cn=true]


热水会冲走泡沫。的确，这感觉有点像一种提醒。
[cpg]


我已经受够了敲打......，这不是你可以和你的家人一起做的事情了。
[cpg]






[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


等到跳动声减弱时，我意识到我的呼吸不在了。
[cpg]


这提醒了我，如果我不真的捣鼓，就会有生命危险。......
[cpg]

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





做完这一切后，我们围坐在餐桌旁，看起来好像不知道发生了什么事。
[cpg]


我真的觉得我不应该这样做。
[cpg]



[SE f="se011"]
;//【ＳＥ】『食器の音』




[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune058"]
[OnName num="suzune"]
'...... 吾郎。你没有胃口吗？
[cpg cn=true]


[OnName num="gorou"]
不，思考......。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari039"]
[OnName num="himari"]
'在思考，嗯？我最近也在做大量的思考'。
[cpg cn=true]


主要是在想如何搞乱我。这就是我所想的。
[cpg]


[OnName num="father"]
'怎么了？　你说的是宪法。"
[cpg cn=true]


嗯，大概就是这样。爸爸是唯一被排除在这群人之外的人。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





然后我回到我的房间。每当我想起今天发生的事情，我就感到很尴尬。
[cpg]


我不知道该怎么做。我只需要修复我的体质，不是吗？
[cpg]


但如果我不知道如何解决它，我就不能做任何事情。......
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


[SE f="se004"]
;//【ＳＥ】『衣擦れ』

当我带着这些想法入睡时，我被一种奇怪的感觉惊醒了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari040"]
[OnName num="himari"]
'早上好，兄弟。
[cpg cn=true]


[OnName num="gorou"]
'...... 不，不是早安。
[cpg cn=true]


绯红正抚摸着我的头。这也与我的宪法有关吗？
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari006"]
[OnName num="himari"]
'大哥的头太值得抚摸了，不是吗？
[cpg cn=true]


...... 显然不是。他只是想挑逗我。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari007"]
[OnName num="himari"]
'进展如何？　你很激动吗？"
[cpg cn=true]


[OnName num="gorou"]
......，一般般。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari008"]
[OnName num="himari"]
我当时想，"好，好，好。你得说出来。"
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
绯红这样说，并把她的脸靠近他。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari009"]
[OnName num="himari"]
'看。我可能会像这样吻你'。
[cpg cn=true]


[OnName num="gorou"]
'哦，我很抱歉。......'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari010"]
[OnName num="himari"]
如果你知道我的意思的话。
[cpg cn=true]


;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************




[OnName num="gorou"]
'......Himari, you're pretty mean.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari011"]
[OnName num="himari"]
'你在说什么。我没有这么好的妹妹，你有吗？
[cpg cn=true]


...... 当然，如果你问我，那是真的。她一直是个皮实的姐姐，但现在她似乎真的很享受这种感觉。
[cpg]


我想。
[cpg]



;//■選択肢
[switch]
[case "她对我如此投入，我很高兴。"]
	[swap]
	[jump target="*select01_1"]
[case "我迫不及待地要修复这部宪法。"]
	[swap]
	[jump target="*select01_2"]
[endswitch]

第一，我很高兴你对我如此忠诚。
2、我想尽快修复这个宪法。



;//==============================
;//１、こんなに尽くしてくれて幸せだ
*select01_1|捣毁管理的开始




我很高兴绯红对我如此忠诚。
[cpg]


我相信一定有类似于爱的反面的东西。
[cpg]


当我想到这一点时，绯红似乎也是一个可爱的人。
[cpg]

[stflag Cha2flg = 1]

;//ヒロイン２が候補に

[jump target="*select01_3"]

;//==============================
;//２、早くこの体質を治したい

*select01_2|捣毁管理的开始



我知道我不想这样做太久。
[cpg]

如果可能的话，我想现在就解决我的体质问题，重新过上无忧无虑的生活。......
[cpg]


但我相信这将是更远的事情。
[cpg]



;//==============================

*select01_3|捣毁管理的开始

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


;//[jump storage="ep002.ks" target="*start"]



;/////////////////////////////////////////////////////////////////////

*start

;###################################################################
*Ep002|被管理的痛苦
;###################################################################

[SCENE id=2]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





看来她姐姐已经在去工作的路上了，或者说是去学院。
[cpg]


她也是个大忙人，所以我不怪她。
[cpg]


我猜她自然要比学生们来的早。
[cpg]


当我想到这一点时，有些事情我是无法理解的。......。
[cpg]


与我不同的是，我觉得我仍然是一个工作的人。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************




[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa055"]
[OnName num="sawa"]
'好吧，那就去吧。不要停下来，再回来'。
[cpg cn=true]


我不需要你来告诉我，我不会停下来的，因为晚上我又要受罪了。
[cpg]


考虑到这一点，我回过头来问候了我的母亲。
[cpg]


[OnName num="gorou"]
我走了。 "
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari067"]
[OnName num="himari"]
你走吧！"
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************


早晨的教室。我已经去上课了，越来越硬。
[cpg]


上课是你应该集中精力学习的时候。
[cpg]


但是当老师是个女人时，我就忍不住了。即使她不是那么年轻。
[cpg]


而当老师是个男人时，我的注意力就会转向我的同学们的女孩。
[cpg]


仅仅是想要悸动的感觉就使它变得如此艰难。
[cpg]


我已经很痛苦了，以至于我不得不在很早的时候就给我姐姐帮了一把。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（朝）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune059"]
[OnName num="suzune"]
'...... 等到午餐时间。你是个男孩，你必须有点耐心。"
[cpg cn=true]


[OnName num="gorou"]
'我有麻烦了，因为我是个男孩......'
[cpg cn=true]


'确实如此，'我姐姐嘟囔道。不，这并不重要。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



从那以后，我设法坚持到了午餐时间，这次我压住了她。
[cpg]


我不会再怀念它了。如果我错过这个时机，我就真的会死。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune008"]
[OnName num="suzune"]
'那好吧，我们今天去某个空教室好吗？
[cpg cn=true]


[OnName num="gorou"]
'什么，不是...... 学生咨询室？
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune061"]
[OnName num="suzune"]
'如果你用得太多，它就会很突出。
[cpg cn=true]


这是正确的，但如果你使用一个空教室，有人会找到你。......。
[cpg]



;//ブラックアウト


[VOICE f="sSuzune009"]
[OnName num="suzune"]
'好吧，我们该怎么做？　我的意思是，来吧。"
[cpg cn=true]


我有很多顾虑，但我无法阻止自己。
[cpg]


;//========================================
;//●ＣＧ（ヒロインに背後から抱きつく主人公。衝動を必死にこらえる）ev_10
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]





[OnName num="gorou"]
'姐.......
[cpg cn=true]


她从后面抱住她的妹妹。我闻到她的好味道，感觉我的脉搏加快了。
[cpg]


回想起来，我从小到大即使想做也做不到。
[cpg]


但现在，我可以毫不犹豫地宠爱她。
[cpg]


从这个意义上说，我目前的体质在一定程度上帮助了我。 ......
[cpg]


[VOICE f="sSuzune010"]
[OnName num="suzune"]
'......，这太突然了。你吓了我一跳。"
[cpg cn=true]


我觉得她也有点脸红。
[cpg]


也许她对我所做的事情有想法。
[cpg]


[OnName num="gorou"]
'对不起，我只是不能再忍受了。
[cpg cn=true]


;**【ＣＧ】 ev_10_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune011"]
[OnName num="suzune"]
'你现在是这样一个...... 无助的小女孩。
[cpg cn=true]


她似乎既感到震惊又感到尴尬。
[cpg]


[VOICE f="sSuzune012"]
[OnName num="suzune"]
'嗯，她在那方面也很可爱。
[cpg cn=true]


我很漂亮，你说，我的心再次向你走去。
[cpg]


这也是一种来自我的体质的感觉，我想...... 磅。
[cpg]


但不管怎样，我也想有一个暗恋对象。
[cpg]


我想被我妹妹误导。我想被迷惑，所有的时间。......
[cpg]


[VOICE f="sSuzune013"]
[OnName num="suzune"]
五郎的体温，感觉是越来越高了。"
[cpg cn=true]


[OnName num="gorou"]
'是的，我不认为如此。
[cpg cn=true]


如果有人告诉我并且我意识到了这一点，我很可能会格外害羞。
[cpg]


[VOICE f="sSuzune014"]
[OnName num="suzune"]
'是的，我是。我不认为这只是我的想象'。
[cpg cn=true]


但即使是这样说的姐姐也觉得有点热。
[cpg]


;**【ＣＧ】 ev_10_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune015"]
[OnName num="suzune"]
'我现在该走了吗？　你平静下来了吗？"
[cpg cn=true]


我摇摇头。这还不够。
[cpg]


我感到一阵欲望，想把她抱得更紧，我努力压制着它。
[cpg]


[VOICE f="sSuzune016"]
[OnName num="suzune"]
'真的，你不能帮助它，孩子。
[cpg cn=true]


这不是一个冷冰冰的说法，而是一个亲切的话语，直奔主题。
[cpg]


我从母亲那里感受到了一种不同的母爱，或类似的东西。
[cpg]


[VOICE f="sSuzune017"]
[OnName num="suzune"]
'溺爱 ...... 好，让我们再保持这样的状态。
[cpg cn=true]


她这样说，并允许我做我所做的。
[cpg]


我觉得如果她对我这么好，我就不能再忍下去了。......
[cpg]


但我还是忍住了，没有再做什么。
[cpg]


[OnName num="gorou"]
'谢谢你......'
[cpg cn=true]


[VOICE f="sSuzune018"]
[OnName num="suzune"]
'不客气。看到我的兄弟陷入困境，我不能置身事外'。
[cpg cn=true]


说这话的姐姐是我的妹妹，似乎在隐瞒什么。
[cpg]


我想知道她是否会对我有所想法，或者.......。
[cpg]


[OnName num="gorou"]
'你闻起来很香.......'
[cpg cn=true]


;**【ＣＧ】 ev_10_b ***********************
[CG id=4 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune019"]
[OnName num="suzune"]
'不要闻。而且不要说任何令人尴尬的话。
[cpg cn=true]


她没有感到羞愧，而是以一种更像是嘲弄的方式说道。
[cpg]


但我想知道她是否也能闻到我。
[cpg]


我希望她在想些什么。...... 很快，午休就会结束。
[cpg]



;//ブラックアウト

快乐的时光不可避免地很快过去。
[cpg]


你越想让它永远持续下去，它就越早结束，从身体上来说。
[cpg]


而我越是希望它结束，越是痛苦的时间就要重新开始。
[cpg]


我想感到兴奋。我可以说上一整天。......
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



事后。谣言传播得很快，还是那个人在第一时间看到了？
[cpg]


[OnName num="male_student_A"]
'我看到了。你和小坂老师一起进了教室，尽管那是午餐时间。"
[cpg cn=true]


[OnName num="male_student_B"]
'你在做什么。你在做什么？
[cpg cn=true]


啊哈，我想，但我回答。
[cpg]


[OnName num="gorou"]
'不，是......，你知道我和我的老师是同姓的吗？
[cpg cn=true]


[OnName num="male_student_A"]
'哦，你是小坂五郎，对吗？你有相同的汉字吗？
[cpg cn=true]


[OnName num="gorou"]
'是的，它是。我和我的老师，我们是姐弟恋'。
[cpg cn=true]


[OnName num="male_student_B"]
'真的吗？　多么令人羡慕啊！......！"
[cpg cn=true]


[OnName num="gorou"]
这就是为什么我一直在请教诸如家庭问题之类的事情。"
[cpg cn=true]


我没有说谎。我不能很好地说出真相。
[cpg]


[OnName num="male_student_A"]
'话说回来，去一个空的教室是很奇怪的。
[cpg cn=true]


[OnName num="gorou"]
'这是我不希望任何人听到的建议。
[cpg cn=true]


我不知道，我不能帮助它。......，但这不仅仅是我的错。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園教室』（夕方）******************************************************





然后是下午的课程。在我服用时，这一次我母亲的脸开始在我脑海中闪现。
[cpg]


最后，我不能没有你们三个人。我想起了这一点。
[cpg]


我被打上了印记，我不能再和他们作对了。......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





我在回家的路上已经摇摇晃晃了。我的同学们都很担心我。
[cpg]


[OnName num="female_student_A"]
'你还好吗？　小坂君。"
[cpg cn=true]


[OnName num="female_student_B"]
'嘿，嘿，你和小坂老师是姐弟恋是真的吗？
[cpg cn=true]


考虑到谣言传播得很快，我离开了，当时就回复了。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa056"]
[OnName num="sawa"]
'欢迎回来。你已经在痛苦中了吗？　我不知道。"
[cpg cn=true]


[OnName num="gorou"]
'Ts，这很难。...... 帮助我，妈妈。
[cpg cn=true]


我说了我的想法，但妈妈笑着说
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa057"]
[OnName num="sawa"]
'漂亮的脸蛋。嘿，戈罗，你今天为什么不试着多一点耐心呢？"
[cpg cn=true]


他说。我不由自主地脱口而出。
[cpg]


[OnName num="gorou"]
'嘘，我要死了......！'
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





有人告诉我，我不应该太过频繁地敲打。
[cpg]


但一天三次是目标，这意味着即使一天两次也不会杀死你。
[cpg]


事实上，他们可能已经说了三次，以设定一个上限。
[cpg]


习惯捣鼓那么多可能是个问题。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari068"]
[OnName num="himari"]
'兄弟，你似乎过得很辛苦。我希望你的身体迅速痊愈'。
[cpg cn=true]


我吃完饭，从椅子上不稳地站起来。
[cpg]

[free time=1000]

我什么都做不了。或者说，我不能看有吸引力的女人，如绯红、我的姐姐和我的母亲。
[cpg]


最好是一个人睡。考虑到这一点，我走回了我的房间。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





我不知道我还得等多久。我母亲该睡觉了，不是吗？
[cpg]


当我这样想时，我开始失去意识。
[cpg]


我可能真的又要得病了。在这一切的中间。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[WAIT time=1100]



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa058"]
[OnName num="sawa"]
'对不起，让你久等了。到我的房间来。"
[cpg cn=true]


[OnName num="gorou"]
'......，你确定......？
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa059"]
[OnName num="sawa"]
'你可以说得出口。我应该怎么做？"
[cpg cn=true]


[OnName num="gorou"]
呃--呃!　求你了，我已经束手无策了。"
[cpg cn=true]


甚至我母亲也这样对我说。我已经没有选择了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//移植前シーンカット


那天晚上，我在母亲抚摸着我的头入睡。
[cpg]


我没有逃跑或躲藏，我让我的心怦怦直跳。
[cpg]


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa016"]
[OnName num="sawa"]
'你太可爱了。你看起来很解气'。
[cpg cn=true]

我实际上是松了一口气。我很激动，但也松了一口气。
[cpg]


之后，我筋疲力尽，直接和我母亲一起睡了。......
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





然后第二天，在妈妈醒来之前，我回到了我的房间。
[cpg]


没过多久，捣蛋的管理层就开始了。这就是我注意到的地方。
[cpg]


我想，经常给人捶打可能会使我更加依赖它。
[cpg]


另一方面，如果我不这样做，我将很难呼吸。......
[cpg]


我在想该怎么办，但也在想，我不能再这样下去了。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari012"]
[OnName num="himari"]
'Onii-chan。今天我们也和我漂亮的小妹妹亲热一下吧'。
[cpg cn=true]


绯红说，类似这样的话。你说自己很可爱。......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari070"]
[OnName num="himari"]
'爸爸已经走了，所以...... 吁，你可以做任何你想做的事。
[cpg cn=true]


你说的 "任何东西 "是什么意思？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Suzune079"]
[OnName num="suzune"]
'别闹了。趁我不注意的时候做吧'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari071"]
[OnName num="himari"]
'Ew.'不要紧，你没看到也没关系，姐姐。
[cpg cn=true]



她姐姐的反应是合理的，但绯红似乎也预见到了这一点。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





我尴尬地回到我的房间里呆了一会儿，但仔细一想这是个坏主意。
[cpg]


这意味着我不能在早上感到兴奋。它可以持续到午餐时间。
[cpg]


我是否应该按照绯红的要求在这里做，即使我感到有点尴尬？
[cpg]


不，不，不，不，我毕竟不能在我母亲和妹妹面前这样做。......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我的冲突并没有持续很久。
[cpg]


我知道我不能什么都不做。我觉得我失去了一些东西给Himari。......
[cpg]


我决定跟随绯红。除了她的母亲，她的姐姐冷冷地看着我。
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari072"]
[OnName num="himari"]
'为什么你不从一开始就按我说的做？你太固执了'。
[cpg cn=true]


我决定听从绯红的安排。除了她的母亲，她的姐姐冷冷地看着我。
[cpg]



;//========================================
;//●ＣＧ（倒れ込んでいる主人公にキスをしようとするヒロイン。寸止めでキスはしない）ev_12
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の家＿リビング
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari013"]
[OnName num="himari"]
'嘿，让我们接吻吧。这是你能做的最激动人心的事情'。
[cpg cn=true]


然后我们就出现了这种情况。绯红比我们早了一步。
[cpg]


看来她不仅仅是......，看着我倒下和悸动而感到有趣。
[cpg]


[OnName num="gorou"]
'你说吻的时候是认真的吗，......？
[cpg cn=true]


绯红看起来好像不是在开玩笑。而且她也是那种说到做到的人。
[cpg]


;**【ＣＧ】 ev_12_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari014"]
[OnName num="himari"]
'我是认真的。你也想让我这样做，是吗，大哥？
[cpg cn=true]


我认为这当然是最令人兴奋的事情。然而。
[cpg]


[OnName num="gorou"]
'如果我这样做，除了...... 接吻之外，我可能无法对其他事情感到兴奋。
[cpg cn=true]


[VOICE f="sHimari015"]
[OnName num="himari"]
'......，你是什么意思？
[cpg cn=true]


[OnName num="gorou"]
并不是说突然做这样的事情不好，更像是习惯了就不好了。"
[cpg cn=true]


;**【ＣＧ】 ev_12_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari016"]
[OnName num="himari"]
'嗯，这就是困扰我的地方。
[cpg cn=true]


绯红说得好像这是别人的问题，但对我来说这是一个严重的问题。
[cpg]


[OnName num="gorou"]
'我确实关心!　如果我的心脏不能再跳动，我就会死。"
[cpg cn=true]


[VOICE f="sHimari017"]
[OnName num="himari"]
'你需要放弃。我不会再让你得逞了'。
[cpg cn=true]


绯红似乎是认真的。如果她不打算让他逃跑，那么也许他就不能逃跑。
[cpg]


[OnName num="gorou"]
'等待，等待.......'
[cpg cn=true]


绯红比我更有力量，而我比绯红更有女人味。
[cpg]


;**【ＣＧ】 ev_12_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari018"]
[OnName num="himari"]
'我等不及了。来吧，把你的脸转向这边。"
[cpg cn=true]


说着，Himari将她的脸靠近。
[cpg]


她柔软的嘴唇也同时靠近。他们几乎碰在一起。
[cpg]


我可以闻到好闻的味道。绯红就在身边，闭着眼睛。
[cpg]


而当我快到时，我就下定决心。
[cpg]


我等待着，等待着，等待着她的嘴唇接触.......
[cpg]


[OnName num="gorou"]
"...... 什么？"
[cpg cn=true]


在我等待的过程中，我没有感觉到有任何...... 嘴唇贴着我。
[cpg]


然后，她及时地把脸拉开。
[cpg]


;**【ＣＧ】 ev_12_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari019"]
[OnName num="himari"]
'呵。你感觉到扑通一声吗？
[cpg cn=true]


对，这就是我的意思。我被带去兜风了。
[cpg]


[OnName num="gorou"]
嗯，嗯。
[cpg cn=true]


她天生就是这样的人。不要把她说的话看得太重。......
[cpg]


[VOICE f="sHimari020"]
[OnName num="himari"]
那么我想我们的目标已经实现了。"
[cpg cn=true]


绯红可能是一个令人惊讶的纵容者。
[cpg]


还是她只是在挑逗我？　或者只是做他们想做的事？
[cpg]


我不是什么都知道，但我刚才的重击是相当不错的，所以我不能抱怨: ......
[cpg]


;**【ＣＧ】 ev_12_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari021"]
[OnName num="himari"]
'那好吧，祝你今天好运。因为当我的兄弟受苦时，我也会受苦'。
[cpg cn=true]


[OnName num="gorou"]
'谢谢你......'
[cpg cn=true]


我不知道谢谢你是否是正确的回应，但没有别的可说。
[cpg]



;//ブラックアウト

但是，我仍然想知道在我妹妹面前这样做是否合适。
[cpg]


我不确定在她面前这样做是否合适，但这是我一直在考虑的事情。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************


而在与绯红做了这样的事情后，姐姐的冷言冷语也在等着我。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="sSuzune020"]
[OnName num="suzune"]
'这真的很不谦虚。我想知道她是否没有尴尬的感觉'。
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari089"]
[OnName num="himari"]
'嘿嘿。我想我没有'。
[cpg cn=true]


我有。所以我感到抱歉和尴尬，我觉得我不能说什么。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune082"]
[OnName num="suzune"]
'哦，好吧。我现在要走了。"
[cpg cn=true]


[OnName num="gorou"]
'是的，继续，继续。......'
[cpg cn=true]



我妹妹总是早早离开。我们在这之后。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************





过了一会儿，我和绯红不得不离开房子。
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa079"]
[OnName num="sawa"]
'再见。回头见。"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari090"]
[OnName num="himari"]
我走了。"
[cpg cn=true]


绯红欢快地回答道。我没有这个心情。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


;//[jump storage="ep003.ks" target="*start"]



;/////////////////////////////////////////////////////////////////////

*start

;###################################################################
*Ep003|我的耐心已经接近极限了。
;###################################################################


[SCENE id=3]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（朝）******************************************************





当我在城里走动时，就不会这样了。我是说，这一刻也很难说。
[cpg]


但还不足以让我感到心慌意乱。我也逐渐习惯了这些石头。
[cpg]


下一次，我姐姐会帮我做。等到这个时候，我走了。
[cpg]


如果我没有这样的短期目标，或者没有路线图，我也没办法。
[cpg]


当我想到它是永远持续下去的东西时，我感到很无助。......。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（朝）******************************************************


[SE f="se002"]
;//【ＳＥ】『喧噪』


然后我们到达了学院。我想我已经从第一天的捣乱管理中多少平静下来了。
[cpg]


[OnName num="male_student"]
'你前一阵子看起来有点不舒服，但你最近看起来好多了。这是一种解脱。"
[cpg cn=true]


[OnName num="gorou"]
'是的，...... 是的，我想这些天情况相当好。
[cpg cn=true]


我知道我周围的人认为这很奇怪。我在思考这个问题。
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************



上课的时候已经很辛苦了，而且是在中午。
[cpg]


我甚至在吃晚饭之前就想去我姐姐那里，但那样她可能也吃了。
[cpg]


最终，大约在午休的晚些时候，我终于前往我姐姐的地方。
[cpg]


我没有太多的时间，但我仍然不能什么都不做。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune021"]
[OnName num="suzune"]
'......，听起来你的日子很难过。

[cpg cn=true]


[OnName num="gorou"]
姐姐......，我已经快死了。"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune084"]
[OnName num="suzune"]
'对。我被告知有获得另一种疾病的风险'。
[cpg cn=true]


她一边平静地说话，一边把我的手拉开。
[cpg]


我想如果她看到这一点会很糟糕，但她把我带到了学生咨询室。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_03_2_up.ui" time=1000]
[WAIT time=2000]


如果我不断地重复这样做，它一定会升级的。
[cpg]


如果是这样的话，我最终会不会也亲吻我的妹妹？
[cpg]


我想知道我的妹妹对我有什么看法，等等。
[cpg]


我不认为我想做她不希望我做的事。
[cpg]


或者......，她还会为我即将死去而感到悲伤吗？
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



我走出学生指导办公室，确定没有人在看。
[cpg]


如果有人看到我，他们又会对我说三道四。
[cpg]


我不能一直做这种事。
[cpg]


我需要更有创意一些，......，但我不知道怎么做。
[cpg]


我在校园里的整个过程中，都无法忍耐。
[cpg]



[window target=false]

[WAIT time=2000]

[BG f="b_03_3.ui" time=1500]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



同时，现在是放学后。
[cpg]


我试图回家。现在是我还能设法忍受的时候，.......。
[cpg]


[OnName num="male_student_A"]
'嘿，小坂。让我们回家休息一下，找点乐子。"
[cpg cn=true]


[OnName num="male_student_B"]
'你最近不善于社交。怎么了？"
[cpg cn=true]


[OnName num="gorou"]
'不，有事情发生。所以，请让我回家。......"
[cpg cn=true]


[OnName num="male_student_A"]
没有。好了，我们去电玩城吧。"
[cpg cn=true]


他一开始就是一个好朋友。我确实不能忽视他们。
[cpg]


但是你知道。......，我越晚回家就越难。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夜）******************************************************



男孩们就在我旁边。或者说，我和所有男孩一起玩。
[cpg]


而我却在寻找一个暗恋的对象。
[cpg]


我周围的人似乎不知道发生了什么事，他们以为我感冒了或什么。
[cpg]


所以我被提前释放了，但......，还是已经是午夜了。
[cpg]


[OnName num="gorou"]
'哦，......，这很糟糕，这是...... 糟糕。
[cpg cn=true]



我不禁想到了我母亲的脸。我想知道爸爸是否已经回来了。
[cpg]


如果我想让他做一些事情，我需要尽快做。......，我回去了，思考。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa080"]
[OnName num="sawa"]
'欢迎回来。你回来晚了。"
[cpg cn=true]


[OnName num="gorou"]
'对不起......，对不起。......
[cpg cn=true]


[OnName num="father"]
'你在哪里停了下来？　快到晚饭时间了。"
[cpg cn=true]


[OnName num="gorou"]
是的，......，那是......."
[cpg cn=true]


它不是为了告诉你在哪里停过车而建造的。
[cpg]


但这还不是最糟糕的部分。爸爸的家。
[cpg]


会不会是在他吃晚饭的时候，我必须坚持下去？
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


我的猜测是正确的。主要是因为我父亲回来后，我母亲不可能为我做什么。
[cpg]


我心里充满了苦涩，这让绯红觉得很好笑。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari091"]
[OnName num="himari"]
'嗯，嗯。'现在大哥哥，你真可爱。你的母亲真狡猾'。
[cpg cn=true]


[OnName num="father"]
'......?'
[cpg cn=true]


爸爸显然不知道我在说什么。
[cpg]


这很好，但我当时的情况很危急，我无法围绕它做出适当的决定。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



在最后一分钟，我母亲对我说。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa081"]
[OnName num="sawa"]
我在我的房间里等你。你可以随时来'。
[cpg cn=true]


他现在想去......。我是这么想的，但我不能让爸爸起疑。
[cpg]



;//ブラックアウト


远远超过了我的忍耐极限，我逐渐失去了立足之地。
[cpg]


就在那个时候，我去了我母亲的地方。
[cpg]


就像我再也无法忍受了。......
[cpg]


;//========================================
;//●ＣＧ（主人公に胸を押しつけるヒロイン。主人公の体に少し触れている感じ）ev_14
;//人物１：ヒロイン３
;//服装１：パジャマ
;//人物２：主人公
;//服装２：パジャマ
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa017"]
[OnName num="sawa"]
'你今天一定过得很辛苦。我要给你一个好的依偎'。
[cpg cn=true]


[OnName num="gorou"]
"...... 母亲，先生。"
[cpg cn=true]


[VOICE f="sSawa018"]
[OnName num="sawa"]
'这很难。现在一切都好了。"
[cpg cn=true]


[OnName num="gorou"]
哦，哦，......."
[cpg cn=true]


我感到很欣慰，忍不住要发出有趣的声音。
[cpg]


[VOICE f="sSawa019"]
[OnName num="sawa"]
'咯咯笑。这对你来说一定很困难。
[cpg cn=true]


仅仅通过触摸她，我就能感觉到某种大脑化学物质被释放。
[cpg]


我不禁知道，这一定是我现在需要的东西。
[cpg]


我很激动，但也松了一口气。这是一种奇怪的感觉，我已经失去了表情。
[cpg]


;**【ＣＧ】 ev_14_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa020"]
[OnName num="sawa"]
'我怎么能让你激动呢？
[cpg cn=true]


他一边说一边轻轻地抚摸着我的身体。我觉得我无法忍受它。
[cpg]


[OnName num="gorou"]
'我已经够紧张了。
[cpg cn=true]


[VOICE f="sSawa021"]
[OnName num="sawa"]
'是的。很好'。
[cpg cn=true]


我觉得我似乎想拥抱她，但我忍住了。
[cpg]


[VOICE f="sSawa022"]
[OnName num="sawa"]
'你的脉搏变得非常快。我可以感觉到它。
[cpg cn=true]


紧张是很自然的。有些人说，如果你接近这样一个美丽的人，你.......
[cpg]


还有来自一个地方的重击，比如说如果我爸爸发现了会发生什么。
[cpg]


我知道光是有这些感觉就是个问题。
[cpg]


我知道我这样做是不道德的，我也知道光有这些感觉是有问题的，但我不能压制它们。
[cpg]


;**【ＣＧ】 ev_14_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa023"]
[OnName num="sawa"]
你想今天再一起睡吗？
[cpg cn=true]


妈妈说了一句相当大胆的话。
[cpg]


[OnName num="gorou"]
'嗯，那是...... 确实不好。
[cpg cn=true]


[VOICE f="sSawa024"]
[OnName num="sawa"]
'我很好。只要五郎没问题就好。
[cpg cn=true]


当你说这样的话时，我很想这么做，但我......，忍住了。
[cpg]


如果我父亲发现了，他会怀疑发生了什么。
[cpg]


我父亲在某些方面可以说是直言不讳，但仍然是一个糟糕的......。
[cpg]


[OnName num="gorou"]
'......，我还是不行。我今天要回去了。"
[cpg cn=true]


[VOICE f="sSawa025"]
[OnName num="sawa"]
'是吗？　我这里永远欢迎你。"
[cpg cn=true]


当你说这样的话时，我几乎是在考虑。
[cpg]


不过，与我姐姐和绯红不同，我知道我不会对我母亲犯任何错误。
[cpg]



;//ブラックアウト

带着遗憾的心情，我离开了母亲的房间。
[cpg]


尽管这是我的职责，但他对我来说是一个不可替代的人，我不知道这样做是否正确。
[cpg]


这不可能是好事。......我知道，但我无法停止。
[cpg]






;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』



之后，我就瘫软在我的房间里。
[cpg]


无论我怎么觉得自己被折腾得太厉害，我都无法以自己的意志......。
[cpg]


这主要是我的体质。但......
[cpg]


我想知道我母亲是否也对你有看法。或者，也许她不像我一样有任何暗恋的对象。
[cpg]


我还想到了这个：......
[cpg]



;//■選択肢
[switch]
[case "我为我的父亲感到遗憾。"]
	[swap]
	[jump target="*select02_1"]
[case "如果你对我有想法，我想回应一下。"]
	[swap]
	[jump target="*select02_2"]
[endswitch]

第一，我为我的父亲感到遗憾。
二，如果你对我有看法，我想回应。



;//==============================
;//１、父に申し訳ない
*select02_1|我的耐心已经接近极限了。




我为我的父亲感到遗憾，不是吗？我和妈妈是陌生人，但爸爸和妈妈是夫妻。
[cpg]


这并不意味着我们有血缘关系，但......，我仍然认为我做错了什么。
[cpg]


我并不是说，如果是向日葵或我的妹妹，我就不会有什么想法了。
[cpg]

[jump target="*select02_3"]


;//==============================
;//２、何か思ってくれてるなら応えたい

*select02_2|我的耐心已经接近极限了。



如果我妈妈还在想什么，我觉得我别无选择，只能做出回应。
[cpg]


即使是尖酸刻薄的关系，你也不能突然断绝关系。也许这是相互的。......
[cpg]



[stflag Cha3flg = 1]

;//ヒロイン３が候補に



;//==============================

*select02_3|我的耐心已经接近极限了。


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]



;//[jump storage="ep004.ks" target="*start"]


;/////////////////////////////////////////////////////////////////////

*start

;###################################################################
*Ep004|我们为每个人着想。
;###################################################################

[SCENE id=4]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[transition target={false} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





早晨。我被一个不怎么好的梦惊醒。
[cpg]


我梦见我在一个我不知道在哪里的地方，周围有我的母亲、姐姐和绯红。
[cpg]


我认为梦到别人是可以的。但我不这样做，就有点疯狂了。
[cpg]


想到这里，我带着一种无奈的心情走向餐厅。
[cpg]



;//ブラックアウト


[window target=false]



[BG f="b_04_1_up.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="gorou"]
'嘿，绯红是在......？
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Sawa099"]
[OnName num="sawa"]
'我不知道--我不知道。也许他还在他的房间里？
[cpg cn=true]


我有麻烦了。......，我得往我的方向走？我感觉我正在失去。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Suzune102"]
[OnName num="suzune"]
'好吧，我现在要走了。回头见。"
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se000"]
;//【ＳＥ】『ノック』



我敲了敲绯红的房间，敲了敲它的门。
[cpg]


[VOICE f="Himari092"]
[OnName num="himari"]
'你可以进来了。你是她的哥哥，对吗？
[cpg cn=true]


[OnName num="gorou"]
"...... 是的。"
[cpg cn=true]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_04_1_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari093"]
[OnName num="himari"]
'我一直想试试那种情况，你哥哥到我房间来，你知道吗？
[cpg cn=true]


绯红是无忧无虑的。我们的生命危在旦夕。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari022"]
[OnName num="himari"]
'你看起来很苦恼。你不能没有我，对吗？"
[cpg cn=true]


[OnName num="gorou"]
'你没有错。我生病了'。
[cpg cn=true]


绯红说她病了，她并不高兴。
[cpg]


[VOICE f="sHimari023"]
[OnName num="himari"]
'好吧，我不在乎是不是因为我生病了。只要你到我身边来'。
[cpg cn=true]



说着，绯红张开双手。我无法拒绝这个邀请。
[cpg]


;//移植前シーンカット



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（昼）******************************************************





日子就这样一点点地过去了。
[cpg]


对我来说，这似乎是一个无尽的时间，但显然只过去了大约一个星期。
[cpg]


而我又去了医院。然后我发现：......
[cpg]


[window target=false]


[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



这毕竟是一种未知的宪法，是我们已经知道了一段时间的东西，但我已经看到了一个电灯泡的时刻。
[cpg]


这一线生机是我希望我没有再看到的。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Sawa100"]
[OnName num="sawa"]
'...... 医生，你说了一些惊人的事情！'
[cpg cn=true]


[OnName num="gorou"]
'嗯，是的。......，我不知道我是否想考虑太多。
[cpg cn=true]


医生说，这种情况是一种爱上某人的本能过度活跃的状态。
[cpg]


他解释说，通过与别人相爱，宪法会平静下来。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari113"]
[OnName num="himari"]
'这就像你感冒了，它就会消失。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune103"]
[OnName num="suzune"]
'我认为......，这是不同的。
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





回到家里，回到我的房间，我遇到了麻烦。
[cpg]


爱上某人了吗？　这是个大问题了。
[cpg]


我没有女朋友。如果我这样做，就不会发生这种情况。
[cpg]


...... 绯红和她的妹妹呢？我从来没有听说过她有男朋友，也没有听说过她有男朋友。
[cpg]


如果我不检查，这就不好了。这是一个关于未来的故事。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



这就是为什么我问我姐姐和绯红。
[cpg]


[OnName num="gorou"]
'...... 你们俩有男朋友吗？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune104"]
[OnName num="suzune"]
'你突然间怎么了......，不，想那种事是很诱人的。
[cpg cn=true]


大姐似乎已经猜到了什么，脸红了。还有。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune105"]
[OnName num="suzune"]
'不，我不知道。Himaru也不例外。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari024"]
[OnName num="himari"]
'是的。我也是'。
[cpg cn=true]



绯红在说这句话时笑了。这看起来是一种欢迎，但这是一种欢迎的态度。......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune106"]
[OnName num="suzune"]
'我很好。如果是为了五郎'。
[cpg cn=true]


她更进一步。'好，你是什么意思？　你是什么意思？
[cpg]


[OnName num="gorou"]
'那是...... 误听，听起来很好？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sHimari025"]
[OnName num="himari"]
'只有你姐姐是偷偷摸摸的。我和你在一起'。
[cpg cn=true]


......，我不得不把我的头从我的屁股里拿出来。
[cpg]


姑娘们说，这对我来说很好。甚至爱上了我。......
[cpg]



;//■選択肢
[switch]
[case "你不能这样做。"]
	[swap]
	[jump target="*select03_1"]
[case "我可能不得不这样做。"]
	[swap]
	[jump target="*select03_2"]
[endswitch]
第一，你不能这样做。
二，我们可能不得不这样做。



;//==============================
;//１、そんなことはできない
*select03_1|这个想法在每个人的脑海中都有。




我还是做不到。我不能这样做......
[cpg]


更不用说你的姐姐和绯红了，你的母亲更糟糕。
[cpg]


我带着这些想法回到了我的房间。
[cpg]


[jump target="*select03_3"]

;//==============================
;//２、そうするしかないかもしれない

*select03_2|思想是给大家的。



但你不可能一直这样生活，对吗？
[cpg]


也许有一天我会和其他人在一起。......
[cpg]


带着这些想法，我离开了这个地方。
[cpg]

[stflag Cha1flg = 1]

;//後の選択肢で選択肢４が候補に



;//==============================

*select03_3|思想与谁同在


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





几天的通行证。在你知道之前，这又是一个工作日。
[cpg]




[window target=false]

[STOPBGM]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





从那时起，我必须定期提高我的心率。
[cpg]


那段日子是如此痛苦，以至于我终于想到要治好病情本身。
[cpg]


然而，我想不出有谁能与之相爱。
[cpg]


班上有一些女孩和我相处得很好，但当我想到我是否喜欢她们时，我想不出有谁......。
[cpg]


不，更重要的是，让我们撇开你是否爱上某人不谈：......
[cpg]


我必须至少和一个人谈起这个问题，才能感到舒服。
[cpg]


我想，如果我要谈恋爱，真的，假想一下，会是谁呢？
[cpg]



[if exp={getFlagValue("Cha1flg") == 0 }]
[endif]

[if exp={getFlagValue("Cha2flg") == 0 }]
[endif]

[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*select04_1"]
[endif]
//////////////////////////////////////////

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*C2"]
[endif]

[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*Out2C3"]
[endif]


[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "纪晓岚"]
	[swap]
	[jump target="*select04_1"]
[case "我无法选择。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]


[jump target="*select04_1"]
//////////////////////////////////////////
*Out2C3|谁对谁有感情？

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "居顺"]
	[swap]
	[jump target="*select04_1"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[case "我无法选择。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "纪晓岚"]
	[swap]
	[jump target="*select04_1"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[endswitch]

//////////////////////////////////////////
*C2|你在想谁？
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*C2C3"]
[endif]

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "纪晓岚"]
	[swap]
	[jump target="*select04_1"]
[case "太阳雨"]
	[swap]
	[jump target="*select04_2"]
[case "我无法选择。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "寿命说明"]
	[swap]
	[jump target="*select04_1"]
[case "阳光"]
	[swap]
	[jump target="*select04_2"]
[endswitch]

//////////////////////////////////////////
*C2C3|谁在你心中

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "寿命说明"]
	[swap]
	[jump target="*select04_1"]
[case "阳光"]
	[swap]
	[jump target="*select04_2"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[case "我无法选择。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "纪晓岚"]
	[swap]
	[jump target="*select04_1"]
[case "太阳雨"]
	[swap]
	[jump target="*select04_2"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[endswitch]








;//■選択肢
[switch]
[case "庆祝长寿"]
	[swap]
	[jump target="*select04_1"]
[case "太阳雨"]
	[swap]
	[jump target="*select04_2"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[case "不能选择"]
	[swap]
	[jump target="*select04_4"]
[endswitch]

1、铃音。
2, Himari
3，苏纳
4，我无法选择。



;//ここまでの選択で候補になっている選択肢から選択
;//ただし、候補がヒロイン１のみの場合選択肢は発生せずそのまま進行


;//*select04_1|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[jump storage="ep005.ks" target="*start"]


;//*select04_2|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[jump storage="ep006.ks" target="*start"]



;//*select04_3|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[jump storage="ep007.ks" target="*start"]


;//*select04_4|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[jump storage="ep008.ks" target="*start"]


;//==============================

*start

;###################################################################
*Ep005|关于铃音的思考
;###################################################################


;//１、寿々音
*select04_1|对苏珊的看法


[SCENE id=5]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


...... 我想她毕竟是我的妹妹。
[cpg]


我认为她是最可靠的人。有一些东西是缺失的，但她仍然与绯红和我的母亲非常不同。
[cpg]


绯红做什么事都太随和了，而我母亲则有些软弱和放松。
[cpg]


但这并不是爱上她的理由。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我早早起床，只有我和我妹妹。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune107"]
[OnName num="suzune"]
'早上好。你今天起得很早。"
[cpg cn=true]


[OnName num="gorou"]
'是的。...... 嘿，我需要和你谈点事。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune108"]
[OnName num="suzune"]
'我想知道。是关于宪法的吗？
[cpg cn=true]


我点点头，继续与我的妹妹交谈。
[cpg]


[OnName num="gorou"]
'......，我想如果我要爱上一个人，她会是唯一的一个。......'
[cpg cn=true]


[OnName num="gorou"]
'但如果我们那样做，我们就会在家族中结婚，不是吗？　所以，你知道。"
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
我一直在说，我不能归结为什么。最后。
[cpg]


[OnName num="gorou"]
'......，我应该怎么做呢？
[cpg cn=true]


他总结说。她没有给我一个惊愕的眼神。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune109"]
[OnName num="suzune"]
'首先，你必须和你喜欢的人在一起。'如果是因为你认为我会原谅你，这仍然不是一个好主意。
[cpg cn=true]


[OnName num="gorou"]
我知道。......，是的，我可以看到。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune110"]
[OnName num="suzune"]
'那么你最好考虑一下你喜欢谁。然后我们可以谈一谈。"
[cpg cn=true]


......，我不能说什么。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




;//＠
之后，绯红让我的心跳加快，我就去了学院。
[cpg]


不知何故，当我和绯红在一起时，我不能想太多东西。
[cpg]


我不禁想起了我的妹妹。
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************





然后我在学校花了一些时间。现在轮到我去我姐姐那里了。
[cpg]


在遇到她之前，我是如此紧张，以至于我无法与遇到绯红时相比。
[cpg]



;//ブラックアウト


[window target=false]



[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『学園教室』（昼）******************************************************





空荡荡的教室。我们带着某种尴尬的心情面对着对方。
[cpg]

;//ブラックアウト

;//========================================
;//●ＣＧ（主人公と密着するヒロイン。胸が当たっている）ev_16
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]





我的姐姐接近我。我们在学校里，而她却在做这个。
[cpg]


由于我的体质，这是没办法的事，无论我怎么想......。
[cpg]


并非所有其他看到这一幕的人都会这么想。
[cpg]


而这一事实正是让我心跳加速的原因。
[cpg]


[VOICE f="sSuzune022"]
[OnName num="suzune"]
'我不知道.......所有这些东西是否让你感到紧张？"
[cpg cn=true]


我只是与她保持密切联系。尽管这只是一次亲密接触，但我非常兴奋，因为她对我非常重要。
[cpg]


只要能有这样的感觉，能够接触对方就意味着很多。
[cpg]


[OnName num="gorou"]
......"
[cpg cn=true]


我甚至连一个字都说不出来。看到这一点，我妹妹很担心。
[cpg]


;**【ＣＧ】 ev_16_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune023"]
[OnName num="suzune"]
'如果你不说点什么，我就会担心。
[cpg cn=true]


当他走到那一步时，我终于回复了。
[cpg]


[OnName num="gorou"]
'是的。这是非常......。"
[cpg cn=true]


;**【ＣＧ】 ev_16_b ***********************
[CG id=7 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune024"]
[OnName num="suzune"]
'不要告诉我这很好。你会让我意识到这一点的。
[cpg cn=true]


她很冷淡，但我可以看出她有点尴尬。
[cpg]


如果她感到尴尬，说明她对我有看法。
[cpg]


这也让我很高兴。除了高兴之外，我还想说的是。
[cpg]


[OnName num="gorou"]
你脸红了。
[cpg cn=true]


;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune025"]
[OnName num="suzune"]
'你这么说，但你也是如此。
[cpg cn=true]


我一直希望能在她身边。
[cpg]


如果我说，只要有她在，我就不需要别的东西，我觉得对绯红很不好 .......
[cpg]


即便如此，我的姐姐对我来说是一个不可替代的存在。
[cpg]


我不知道如何将她与其他任何人进行比较。
[cpg]


;**【ＣＧ】 ev_16_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune026"]
[OnName num="suzune"]
'我的身体也开始发热，我在这里......，这让我很尴尬。
[cpg cn=true]


我对我和我妹妹之间这种微妙的距离感念念不忘。
[cpg]


当然，现在我在身体上非常接近，但我的思想却不是。
[cpg]


[OnName num="gorou"]
'......，你妹妹似乎也很激动。
[cpg cn=true]


我注意到，她的脉搏在加快。
[cpg]


;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune027"]
[OnName num="suzune"]
'真的吗？　不仅仅是你这样。"
[cpg cn=true]


[OnName num="gorou"]
'我不这么认为。......，我认为这是我的想象力。
[cpg cn=true]


[VOICE f="sSuzune028"]
[OnName num="suzune"]
'这只是我的想象。
[cpg cn=true]


我所说的一些话是真的吗？这就是我的想法，我们都在......。
[cpg]


在这个世界上只有我们两个人，或者说他们是这么说的，但这是一个学院。
[cpg]


我可以听到另一个学生的声音就在外面。我有一部分人感到紧张，因为我们并不孤单。
[cpg]


教会我这些感觉的姐妹是不可替代的。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


我和我妹妹在白天的时候互相触摸。
[cpg]


晚上，是我的母亲。早上是绯红。那些日子已经持续了很久，现在也不会改变。
[cpg]


[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





第二天早上。向学校走去，我在路上与女孩们会合。
[cpg]


[OnName num="female_student"]
'早上好，小坂君。
[cpg cn=true]


[OnName num="gorou"]
'哦，早上好......'
[cpg cn=true]


[OnName num="female_student"]
'最近，小坂君改变了他的情绪，是吗？我不知道该怎么说，这更像是忧郁。......
[cpg cn=true]


[OnName num="gorou"]
'什么，......？　你在说什么？"
[cpg cn=true]


[OnName num="female_student"]
'不，这没什么!　到时见。"
[cpg cn=true]


...... 那个迅速离开的女孩可能也对我有好感。
[cpg]


我也没有一个这样的女孩。
[cpg]


但当你想到要一起度过你的余生时，情况就不同了。
[cpg]


回想起来，我跟随姐姐的脚步已经有很长一段时间了。
[cpg]


我一直很佩服她。我又意识到了这一点。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


然后早晨又变成了中午，是我和我妹妹在一起的时候了。
[cpg]

[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[OnName num="gorou"]
'......Oh，请。这对我来说已经很困难了。......"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune130"]
[OnName num="suzune"]
'这对你来说一定很困难。我知道，如果我站在你的立场上，我也会很难过。
[cpg cn=true]


...... 一些奇怪的说法。如果你处于我的位置，你会怎么做？
[cpg]


[OnName num="gorou"]
你的意思是......？"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune029"]
[OnName num="suzune"]
'这没什么。更重要的是，你今天在做什么？
[cpg cn=true]


我是被迫作弊的。而我仍然呼吸困难。
[cpg]



我不能过多地考虑其他事情。对。
[cpg]


[OnName num="gorou"]
那好吧，......."
[cpg cn=true]


;//========================================
;//●ＣＧ（座っているヒロインのことを見つめる主人公）ev_17
;//人物１：ヒロイン１
;//服装１：スーツ（はだけ）
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


我想出了一些和以前不一样的东西，我决定给它一个机会。
[cpg]


我妹妹看起来有点惊愕，但这很好，包括她脸上的表情。
[cpg]


[VOICE f="Suzune134"]
[OnName num="suzune"]
'......，你想出了最奇怪的事情。
[cpg cn=true]


今天，我将停止要求我的妹妹触摸我或接近我。
[cpg]


我想看着我妹妹。我曾要求她这样做。
[cpg]


[OnName num="gorou"]
'这并不奇怪。我认为你想一直看着我。
[cpg cn=true]


她似乎对我的话有些迷惑。
[cpg]


;**【ＣＧ】 ev_17_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune030"]
[OnName num="suzune"]
'你确定你想这样做，只是看着？
[cpg cn=true]


[VOICE f="sSuzune031"]
[OnName num="suzune"]
'我认为你需要触摸它或接近它，或......，这样的东西。
[cpg cn=true]


没有这些，我就已经很激动了。我现在可能会这样。
[cpg]


[OnName num="gorou"]
...... 是的。"
[cpg cn=true]


看着她，她似乎是我需要的一切。
[cpg]


我不好意思这么说，但我这么想也没关系。
[cpg]


;**【ＣＧ】 ev_17_b ***********************
[CG id=8 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune032"]
[OnName num="suzune"]
她看五郎的样子，有点恶心。"
[cpg cn=true]


[OnName num="gorou"]
'是的，我不认为如此。
[cpg cn=true]


她看起来很困惑和尴尬。
[cpg]


唯一的一点是，被盯着看是被盯着看的人可能在想的事情。
[cpg]


[OnName num="gorou"]
'姐姐......，真的非常、非常漂亮。
[cpg cn=true]


她刚才在看我，现在又看向别处。
[cpg]


;**【ＣＧ】 ev_17_c ***********************
[CG id=8 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune033"]
[OnName num="suzune"]
'你怎么敢？
[cpg cn=true]


[OnName num="gorou"]
'我没有撒谎。我是认真的。
[cpg cn=true]


她对我的话做出了轻微的颤抖姿态。
[cpg]


[VOICE f="sSuzune034"]
[OnName num="suzune"]
我的手指都没放在她身上，但这太奇怪了。这也让我很紧张。
[cpg cn=true]


姐姐说这话时脸红了。
[cpg]


我不能就这样看着她。
[cpg]


[OnName num="gorou"]
我想继续盯着她看。姐姐。
[cpg cn=true]


那个更害羞的妹妹开口了。
[cpg]


;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune035"]
[OnName num="suzune"]
'......，就像被五郎的话语所触动。
[cpg cn=true]


她这样说并不是在撒谎。
[cpg]


作为证据，她的妹妹甚至脸红到了耳根。
[cpg]


我想观察一切，甚至她是如何看起来像那样的。这就是我的感觉。
[cpg]


接受我的目光和话语的姐妹。
[cpg]


我觉得那里有一些像母亲的东西。
[cpg]


[OnName num="gorou"]
'即使我只是看着她，我也很高兴。
[cpg cn=true]


;**【ＣＧ】 ev_17_c ***********************
[CG id=8 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune036"]
[OnName num="suzune"]
'不要感到尴尬。不过，我受宠若惊了。
[cpg cn=true]


她当然看起来既尴尬又高兴。
[cpg]


我只为这个感到高兴。
[cpg]


[FG f="ci_lbox.ui" method="feadin_up"  pos="4/7"]

[WAIT time=1000]
;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】『学園のチャイム』


时间过去了一段时间。我们不可能永远在一起，我们不可能和对方在一起。
[cpg]


午餐时间过后，我和姐姐都要去上课。
[cpg]


这一次比以往任何时候都更让人沮丧。
[cpg]





[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


还有下午上课后，放学后。
[cpg]


[window target=false]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



傍晚时分的学校。我们离开教室，试图回家。
[cpg]


在那里我有这样的想法。
[cpg]


一天三次，一天三次，我有时间激动不已。......
[cpg]


所有这些，我都是为了想和我妹妹在一起。
[cpg]


首先，我必须和我妈妈谈谈。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************





当我回到家时，就像这样，只有我妈妈在那里。
[cpg]


[OnName num="gorou"]
'哦，你知道，...... 母亲。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa101"]
[OnName num="sawa"]
'这是什么？　这对你来说有点早，不是吗？"
[cpg cn=true]


[OnName num="gorou"]
'不，不是那个，是那个。这是关于你晚上要为我做什么，我想让...... 你的妹妹来代替我。
[cpg cn=true]


我解释说。只有关于我喜欢我妹妹的部分仍然被隐藏着。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa102"]
[OnName num="sawa"]
'...... 是的。我明白了。
[cpg cn=true]


但我的妈妈似乎把一切都想好了。这是正确的，她是我的母亲。......
[cpg]




;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[WAIT time=1000]

[SE f="se012"]
;//【ＳＥ】『ノック』


[WAIT time=1500]

[window target=true]


;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune151"]
[OnName num="suzune"]
我进来了，戈罗。
[cpg cn=true]


[OnName num="gorou"]
呃，是的。...... 进来吧。"
[cpg cn=true]


[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune037"]
[OnName num="suzune"]
'我听说了。你想让我做你母亲的那份？
[cpg cn=true]


[OnName num="gorou"]
我想不会。...... 真的，这取决于我。"
[cpg cn=true]


不知怎的，我有种感觉，他们不会说不。
[cpg]


然后我的姐姐微微叹了口气，说
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune153"]
[OnName num="suzune"]
'你认为如果你告诉我这些，我能说不吗？　真的，他是一个可爱的小兄弟。"
[cpg cn=true]



;//========================================
;//●ＣＧ（密着する二人。ヒロインが体を前に倒している状態。ヒロインの髪が主人公の体に当たっている）ev_18
;//人物１：ヒロイン１
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：主人公の部屋
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]


[SE f="se004"]
;//【ＳＥ】『衣擦れ』


[BGM f="bg_h1"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune038"]
[OnName num="suzune"]
'也许......，我也已经疯了。
[cpg cn=true]


他说这话时，表情略显浑浊，或者说他的眼睛里有一种忧郁的神情。
[cpg]


[OnName num="gorou"]
'你这话是什么意思？
[cpg cn=true]


姐姐在选择她的话语。她仿佛不知道该说什么。
[cpg]


[VOICE f="sSuzune039"]
[OnName num="suzune"]
'没有你，我感觉好像我的心在痛苦。
[cpg cn=true]


...... 我应该如何看待这个问题？
[cpg]


与其说是深思熟虑，不如说是感觉他按捺不住，言之有物。
[cpg]


当然，我的体质让我很痛苦，但我无法想象我的妹妹会从我这里得到这些。
[cpg]


[VOICE f="sSuzune040"]
[OnName num="suzune"]
'我觉得我想更接近你。我不知道为什么'。
[cpg cn=true]


你妹妹的长发贴着我的身体。我感到很沮丧。
[cpg]


[OnName num="gorou"]
'妹子。你的头发让我很痒。"
[cpg cn=true]


她不是没有注意到，但我敢于说出来。然后。
[cpg]


;**【ＣＧ】 ev_18_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune041"]
[OnName num="suzune"]
'真的吗？　你不喜欢它？"
[cpg cn=true]


他说了一句话，让人分外难受。
[cpg]


[OnName num="gorou"]
'......，我并不讨厌它。
[cpg cn=true]


[VOICE f="sSuzune042"]
[OnName num="suzune"]
'很好，那么。让我像这样多呆一会儿吧'。
[cpg cn=true]


姐姐说了一些咄咄逼人的话。我不觉得我这样做只是为了让她紧张。
[cpg]


也许这就是它的开始，但它与我的宪法已经没有关系。
[cpg]


我觉得我们已经到了一个不应该有的地步。
[cpg]


但这是......，即使如此，我也不讨厌它。
[cpg]


[OnName num="gorou"]
'是的。这是......，直到它让你感觉更好。"
[cpg cn=true]


;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune043"]
[OnName num="suzune"]
'这很古怪。我是为了你的宪法而做的。
[cpg cn=true]


但我觉得那是一个借口，或者说是我们共同的逃避途径。
[cpg]


当这种体质被治好后，我们将做什么？
[cpg]


[VOICE f="sSuzune044"]
[OnName num="suzune"]
'我可以闻到五郎的味道。
[cpg cn=true]


当然，相反的情况也是如此。这就是我们的关系。
[cpg]


仿佛不仅是我们的身体，而且我们的心也变得更加紧密。
[cpg]


;**【ＣＧ】 ev_18_b ***********************
[CG id=9 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune045"]
[OnName num="suzune"]
这很奇怪。我们总是在一起，但你似乎是一个不同的人。
[cpg cn=true]


当她这样说时，她更加靠近。呼吸打。
[cpg]


我希望时间能像这样停止。我想这么想，我觉得扑通扑通的声音让我很解气。......
[cpg]


因重击而感到安心，听起来像是一个矛盾，但这是此刻对我来说最合适的词。
[cpg]


我相信这是一对半路出家的恋人所感受不到的。
[cpg]


;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune046"]
[OnName num="suzune"]
我想多和你在一起。我也很担心你。
[cpg cn=true]


尽管我和妹妹没有血缘关系，但我们也是姐妹和兄弟。
[cpg]


我在那里感到安全一定是有原因的。
[cpg]


[VOICE f="sSuzune047"]
[OnName num="suzune"]
'如果这样做会让我感觉更好，我会......，一直这样做。
[cpg cn=true]


她在说这句话时，把她的皮肤拉到我身上。
[cpg]


[OnName num="gorou"]
'我很高兴。姐姐'。
[cpg cn=true]


这对我来说是一种浪费，但这并不意味着我不想把它给别人。
[cpg]


我想让她成为我的亲妹妹。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]



[OnName num="gorou"]
'谢谢你。我现在很好。"
[cpg cn=true]


呼吸不再有任何疼痛感。但我的心却有些痛苦。
[cpg]


仿佛我的身体和思想彼此不一致。
[cpg]


[VOICE f="sSuzune048"]
[OnName num="suzune"]
'真的吗？　别紧张。"
[cpg cn=true]


我真的很想和你睡觉，但如果我这样做了，我可能会习惯于我所受到的重击。
[cpg]



[window target=false]


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




我不觉得自己会被那些常见的、奇怪的梦境惊醒。
[cpg]


也许这是对我姐姐为我所做的事情的满足。
[cpg]


我并不感到孤独，即使是在一个人的房间里。......
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



还有早晨。现在我必须要和绯红谈谈。
[cpg]


我想我应该昨天就做了，因为......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari026"]
[OnName num="himari"]
'早上好。来吧，今天我再给你一个刺激。"
[cpg cn=true]


真让人吃惊，因为绯红走过来对我说。
[cpg]


她还把她漂亮的大奶子推给我，但我虽然不应该被扫地出门。
[cpg]


[OnName num="gorou"]
'哦，你知道，......，我很抱歉你总是这样对我，但那.........'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari117"]
[OnName num="himari"]
'什么？　你甚至想让我和你妹妹交换位置吗？"
[cpg cn=true]


[OnName num="gorou"]
是的。......"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Himari118"]
[OnName num="himari"]
'我主要是从你母亲那里听说的。你一定是真的那么喜欢你的妹妹'。
[cpg cn=true]


绯红看起来有点悲伤。
[cpg]


这就是为什么，或者说......，我感到有什么东西把我推到了边缘。
[cpg]


我不能再这样下去了。半心半意的态度甚至会伤害到绯红。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune170"]
[OnName num="suzune"]
'......，我也在早上做？　一天三次，不过都是由我来做。"
[cpg cn=true]


[OnName num="gorou"]
'哦，不？
[cpg cn=true]


她笑了一下。我一定是看起来很傻。
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune049"]
[OnName num="suzune"]
'不，我不知道。然后.......'。
[cpg cn=true]


;//ブラックアウト

;//========================================
;//●ＣＧ（主人公に寄り添うヒロイン。朝出かける前）ev_19
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：朝
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



我不需要任何更多的话，但我不想保持沉默，所以我说。
[cpg]


[OnName num="gorou"]
'这很温暖。'姐姐'。
[cpg cn=true]


姐姐看着我。然后她问道。
[cpg]


[VOICE f="sSuzune050"]
[OnName num="suzune"]
'......，难道你光是在我身边就没有快感了吗？
[cpg cn=true]


[OnName num="gorou"]
'不。不，不是的'。
[cpg cn=true]


[VOICE f="sSuzune051"]
[OnName num="suzune"]
你确定你没有在逼迫它吗？"
[cpg cn=true]


[OnName num="gorou"]
'这是真的，我告诉你。你看起来没有任何痛苦的证据'。
[cpg cn=true]


[VOICE f="sSuzune052"]
[OnName num="suzune"]
'真的吗？　我希望如此。"
[cpg cn=true]


她在说这句话时向我靠拢。
[cpg]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[VOICE f="sSuzune053"]
[OnName num="suzune"]
'...... Goro对我来说比什么都重要。我很抱歉让你认为我不是。
[cpg cn=true]


触感柔软。就在这时，我的心才停止了跳动。
[cpg]


我想更接近。我的欲望并没有就此停止。
[cpg]


我想成为你的...... 情人。
[cpg]


[OnName num="gorou"]
姐姐。嗯，嗯......"
[cpg cn=true]


我正准备说些什么，我妹妹却不肯闭嘴，看到我说不出话来。
[cpg]


;**【ＣＧ】 ev_19_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune054"]
[OnName num="suzune"]
'我也很紧张，...... 你知道吗？
[cpg cn=true]


[OnName num="gorou"]
是的。我得到了这个消息'。
[cpg cn=true]


就像我越不主动，我妹妹就越亲近。
[cpg]


这种关系在某种程度上让人感到安心，与重击的方式不同。
[cpg]


;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune055"]
[OnName num="suzune"]
胡胡，这有点尴尬。"
[cpg cn=true]


他们在一起的时间在谈论这些事情时过去了。
[cpg]


[OnName num="gorou"]
'我可能会感到尴尬，但我想留在你的身边......。
[cpg cn=true]


[VOICE f="sSuzune056"]
[OnName num="suzune"]
是的，我也一样。"
[cpg cn=true]


她觉得自己与姐姐的关系比任何人都要密切，但仍然感到很沮丧。
[cpg]


[VOICE f="sSuzune057"]
[OnName num="suzune"]
'吾郎 ......'
[cpg cn=true]


她抚摸着我的头，低声说。
[cpg]


她抚摸着我的头发。她的脸也走近了。
[cpg]


而且她的嘴唇越来越近。我赶紧闭上眼睛。
[cpg]


我几乎失去了距离。我不能以这种紧迫性做任何事情。
[cpg]


;**【ＣＧ】 ev_19_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune058"]
[OnName num="suzune"]
'周周'。
[cpg cn=true]


他们互相抚摸。她向我走了一步。
[cpg]


我太爱她了，以至于我觉得自己要......，失去了控制。言语无法解释我有多爱她。
[cpg]


我不认识这么可爱的人。我觉得我现在就想抱抱她。
[cpg]


我不能永远这样做，尽管我无法抗拒。
[cpg]


;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune059"]
[OnName num="suzune"]
......，差不多该走了。我得走了。"
[cpg cn=true]


在我什么都做不了的时候，我姐姐对我说了这句话。
[cpg]


我咒骂自己的无能，但我很高兴她吻了我。
[cpg]


[OnName num="gorou"]
我很高兴她吻了我。回头见。"
[cpg cn=true]


我不可能在一段时间内忘记她嘴唇的感觉。
[cpg]


我是说一段时间。...... 这将是一个我永远不会忘记的吻。
[cpg]


;//ブラックアウト



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


然后我妹妹比我先离开了家。
[cpg]


这是很平常的事情，但关于它的孤独感却与平常不同。
[cpg]


我去学校的时候会看到她，但我会非常想念她。
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa103"]
[OnName num="sawa"]
我待会儿见。要小心。
[cpg cn=true]


[OnName num="gorou"]
'是的，我去了......'。
[cpg cn=true]


我们和绯红一起离开了房子。我心里有一些想法。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************



我要向我姐姐坦白。我想和她在一起。
[cpg]


她是我不可替代的妹妹，但我还是想。
[cpg]


我还想亲吻她，拥抱她。
[cpg]


这并不是说我想治愈这种体质或什么。......
[cpg]


我意识到，我仍然喜欢我的妹妹。
[cpg]


我可以说，这要归功于绯红。如果她不告诉我，我可能永远不会从心底里意识到这一点。
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

白天，像往常一样，我让我的姐姐提高我的心率。但在放学后，......。
[cpg]

[WAIT time=1000]

[STOPBGM]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（夕方）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune190"]
[OnName num="suzune"]
'现在怎么办......？　你在白天已经做过了。"
[cpg cn=true]


[OnName num="gorou"]
'...... 姐姐，你说我应该和我喜欢的人在一起。
[cpg cn=true]


姐姐的表情变得有些僵硬。也许她在想象会说什么。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune191"]
[OnName num="suzune"]
'......，那怎么办？
[cpg cn=true]


不过，我还是得说。我不能让我妹妹猜到。
[cpg]


如果我在这样的地方被宠坏了，我的余生就真的被宠坏了。
[cpg]


[OnName num="gorou"]
"哦，我......，我是，你知道，......"。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune192"]
[OnName num="suzune"]
'我知道，我知道。你喜欢我，对吗？"
[cpg cn=true]


哦，不。这种趋势将使我的余生都受到宠爱。
[cpg]


但我现在不能帮助它。我已经说了我的观点。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune193"]
[OnName num="suzune"]
'别担心，我也喜欢你。不是作为一个兄弟，而是作为一个情人。
[cpg cn=true]




;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



我和我妹妹分别回家。我们有不同的工作和学习，有不同的时间投入其中。
[cpg]


但我想了一下，至少今天我想一起回家。
[cpg]


最后，我姐姐让我先回家，但......，我有点迫不及待地想见到她。
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





那天的饭桌上没有什么异常。
[cpg]


我还是和往常一样。我妹妹和往常一样。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari119"]
[OnName num="himari"]
'再来一个!　大约百分之七十在碗里！"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune194"]
[OnName num="suzune"]
'你会发胖的。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Himari120"]
[OnName num="himari"]
'与我姐姐不同，我并没有得到多少好处，我。
[cpg cn=true]


我认为我的姐姐是瘦的那个，绯红说。
[cpg]


但姐姐并没有露出厌恶的神情。或者说，她在某种程度上高于它。......。
[cpg]


...... 我想知道他们是否在想我。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





还有夜晚。我妹妹在我的房间里。
[cpg]


[OnName num="gorou"]
'呃，呃，......，很高兴见到你。
[cpg cn=true]


一天三次，出于三次心跳。然而，我却非常紧张。
[cpg]


在这一切中，我妹妹对我说。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune060"]
[OnName num="suzune"]
'我必须告诉你，我从来没有过女朋友。
[cpg cn=true]


[OnName num="gorou"]
'诶......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune061"]
[OnName num="suzune"]
我是说你是第一个。"
[cpg cn=true]


说着，她向他走近。
[cpg]


;//移植前シーンカット
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]

;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]



[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

当我和姐姐在一起时，我觉得内心深处很充实。
[cpg]


这可能是人们固有的东西，而不是与他们的宪法有关的东西。
[cpg]


我感到很兴奋。甚至在她离开后，我也睡不着，因为我太紧张了。
[cpg]


我想让她永远留在我身边。但她离开了房间。
[cpg]


我说这是没办法的事，我也没办法。如果我父亲发现她从我的房间出来，那就糟糕了。
[cpg]


我没有选择，只能等待明天。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



然后明天就来了，这有点尴尬。
[cpg]


我从未想过我会有这样的感觉。她是我一直认识的那个姐姐。
[cpg]


她看起来像一个不同的人，或者也许是我变了。
[cpg]


我目送她离开房子，心想。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune213"]
[OnName num="suzune"]
我第一次见到她时，我想："好吧，那我走了，戈罗。绯红。
[cpg cn=true]


[OnName num="gorou"]
'是的。要小心。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari121"]
[OnName num="himari"]
祝你有个愉快的一天。"
[cpg cn=true]

[free time=1000]
爸爸也离开了家。我们剩下的三个人是我、绯红和我母亲。
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Sawa104"]
[OnName num="sawa"]
'那么，你打算怎么做？　我想知道他是否要和铃音约会。
[cpg cn=true]


[OnName num="gorou"]
'E...... yeah, yeah.这就是计划'。
[cpg cn=true]


经过片刻的困惑，我能够给出我的答案。
[cpg]


我再也无法隐藏它了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="Himari122"]
[OnName num="himari"]
'要快乐。我也喜欢你的哥哥'。
[cpg cn=true]


[OnName num="gorou"]
"...... 是的。"
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』





还有学院的一个空教室。
[cpg]


我与我的妹妹面对面，摇摇晃晃，挣扎着要呼吸。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune214"]
[OnName num="suzune"]
'...... 我。我不想这样做，因为我的体质。
[cpg cn=true]


他一边走一边告诉我这些。
[cpg]


我猜他很担心，因为他在想我。我对此有一定的了解。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune215"]
[OnName num="suzune"]
'此外，当绯红和你母亲在处理五郎时，我不禁感到嫉妒。
[cpg cn=true]


[OnName num="gorou"]
'......，就是这么回事。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune062"]
[OnName num="suzune"]
'不过，现在很好。我将填补...... 他们所有人。"
[cpg cn=true]


对。关于我的一切都在我姐姐的手上。
[cpg]


这感觉相当令人欣慰。
[cpg]


;//移植前シーンカット



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

从现在起，我可以永远呆在你身边。仅仅是这样想，我就觉得有点松了一口气。
[cpg]


[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************



在我松了一口气的同时，我对捣蛋的欲望也越来越强烈。
[cpg]


这其实只是一个小小的时间差，但我再也受不了了。
[cpg]


我再也无法忍受了。但我姐姐说那是晚上。
[cpg]


首先，现在她是我的妹妹而不是我的母亲，我不能一回家就看到她。
[cpg]


我走了，感觉无法忍受。......
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





晚餐。我爸爸是唯一不知道我和我妹妹之间发生了什么的人。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari123"]
[OnName num="himari"]
'那么你的姐姐和弟弟去哪里了？
[cpg cn=true]


在这一切中，绯红说了这样一段话。我几乎把正在吃的食物喷了出来。
[cpg]


[free time=1000]

[OnName num="father"]
'你在说什么？
[cpg cn=true]


[OnName num="gorou"]
'不，这没什么!　这没什么。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]

话虽如此，我的妹妹看起来有点暴躁。
[cpg]


是的，有一天我必须向我父亲解释。
[cpg]


他从来没有像一个严格和顽固的父亲，但......
[cpg]


不过，有些事情还是让我紧张。一想到要告诉我爸爸，我就有些焦虑。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





而且夜夜如此。在我达到极限之前，我妹妹来到我的房间。
[cpg]



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune063"]
[OnName num="suzune"]
'你看起来很高兴。
[cpg cn=true]


[OnName num="gorou"]
'......，有那么明显吗？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune064"]
[OnName num="suzune"]
'是的。不过，她在这方面也很可爱。
[cpg cn=true]


我很尴尬，但等着看我妹妹会怎么做。
[cpg]


我不知道，我经常这样做。不过，我倾向于带头。
[cpg]

;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



我看着姐姐再次回到她的房间，我在痛苦中设法睡着了。
[cpg]


明天，我们仍将是恋人。我很高兴。......
[cpg]


我应该高兴得不得了，但我的体质中有一种紧绷的感觉。
[cpg]


我必须做一些事情。要做到这一点，我想我需要和我的妹妹做一些更有情趣的事情。
[cpg]


这是一种...... 巨大的事情，但首先我必须向我父亲解释。
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


而这一天出乎意料地迅速到来。
[cpg]

[window target=false]

[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************





[OnName num="gorou"]
'嗯，我不能!　我还没有准备好。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune253"]
[OnName num="suzune"]
'爸爸，我今天心情很好。'不是说他总是心情不好。
[cpg cn=true]


;//＠
一个星期天。有人找我谈了这个问题。
[cpg]


我的意思是，我告诉我爸爸。"把你的女儿给我！"还有。
[cpg]


;//ブラックアウト


[window target=false]

[STOPBGM]

[free time=1000]

[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



没有绯红和妈妈。这是我、我爸爸和我妹妹。
[cpg]


[OnName num="father"]
"......"
[cpg cn=true]


[OnName num="gorou"]
"......"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune254"]
[OnName num="suzune"]
'所以这就是为什么我们......，不，Goro可以和你说话吗？
[cpg cn=true]

爸爸没有严厉的面孔，但接近于无表情，有点吓人。
[cpg]


[OnName num="gorou"]
'嗯，把你的女儿交给...... 我。
[cpg cn=true]


[OnName num="father"]
......"
[cpg cn=true]


在我说这句话的时候，我想我看到了爸爸嘴角的微笑。
[cpg]


[OnName num="gorou"]
'志，不。嗯，我想和我妹妹...... Suzune-san出去，或者说，我们要出去。
[cpg cn=true]


[OnName num="father"]
'噗，哈哈哈!　哦，是的，我知道你有一天会这样。"
[cpg cn=true]


[OnName num="gorou"]
什么？......？"
[cpg cn=true]


爸爸的反应令人惊讶。我原本以为他也会感到困惑。
[cpg]


[OnName num="father"]
'不，在这种情况下，要照顾好铃音。我相信五郎将能够帮助你'。
[cpg cn=true]


他宽慰地笑了笑，向我们表示祝贺。
[cpg]


我想，这是一个多么伟大的父亲，当然我也很感激......，所以......
[cpg]


[OnName num="gorou"]
哦，非常感谢你，......."
[cpg cn=true]


我说。我从来没有对我父亲经常使用过礼貌用语。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





[OnName num="gorou"]
'......，很顺利。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune255"]
[OnName num="suzune"]
'对。我以为我是有点名气的'。
[cpg cn=true]


他们在那里仍然是父子关系吗？
[cpg]


我不理解我父亲的所有感受，但我的姐姐似乎理解。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune256"]
[OnName num="suzune"]
我不知道怎么做，但我不打算这样做。这很难，不是吗？"
[cpg cn=true]


[OnName num="gorou"]
'是的。......，这很难。
[cpg cn=true]


我的体质仍在愈合。我很确定我已经爱上了，但可能还需要一点时间才能治愈我的体质。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune065"]
[OnName num="suzune"]
'来。现在我希望你能让......，我很激动。
[cpg cn=true]


[OnName num="gorou"]
'......，我会努力的。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune258"]
[OnName num="suzune"]
胡忧，你已经长大了，可以这么说了。"
[cpg cn=true]


姐姐拍拍她的头。我感到很尴尬。
[cpg]

;//移植前シーンカット

;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************




几天的通行证。暑假已经开始，嗯，没关系。
[cpg]


校外已经有传言说我爱上了我的妹妹。
[cpg]


而在到处都是谣言的情况下，暑假仍然是曙光。
[cpg]


这成为全校的大新闻。无数的男孩为此感到震惊，甚至女孩也有一些粉丝或不知道。......
[cpg]



[window target=false]

[STOPBGM]

[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]


[window target=true]


;//【ＢＧ】『街』（夜）******************************************************



尽管如此，日子还是一天天过去了。我想毫无顾忌地以我姐姐的情人身份出现。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune066"]
[OnName num="suzune"]
'......，现在，你难道不觉得苦吗？
[cpg cn=true]


[OnName num="gorou"]
是的。 轻松多了。"
[cpg cn=true]


从那时起，我的体质就像一个谎言一样安定下来。
[cpg]


所以医生说的都是真的，起初我以为是个笑话。
[cpg]


我想知道我是否可以用'宪法'这个词把它收起来，但我和我妹妹没有必要再靠近了。
[cpg]


不过，这并不改变我们想要对方的事实。
[cpg]


[OnName num="gorou"]
我能说什么呢，那些日子好像是个谎言。......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune278"]
[OnName num="suzune"]
'对。那些日子是那些日子，它们很有趣，但是......
[cpg cn=true]


[OnName num="gorou"]
'现在你不能忍受你的妹妹？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune279"]
[OnName num="suzune"]
我真的希望你不要再叫我 "姐姐"。
[cpg cn=true]


[OnName num="gorou"]
Ugh, it's ......"
[cpg cn=true]


当然，现在是时候解决这个问题了。
[cpg]


[OnName num="gorou"]
'但你不能帮助已经变得根深蒂固的东西，是吗？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune067"]
[OnName num="suzune"]
'比如说，如果你有一个孩子，你还会把我称为你的妹妹吗？
[cpg cn=true]


[OnName num="gorou"]
那我就叫你妈妈。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune281"]
[OnName num="suzune"]
'......，你越来越善于归还东西了。
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune068"]
[OnName num="suzune"]
'我希望我可以整天和你在一起。我们不必再对任何人隐瞒了'。
[cpg cn=true]


[OnName num="gorou"]
我说，"对。"...... 嘿。
[cpg cn=true]


她开始抚摸我的头发。我扭动着身体，痒痒的。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune069"]
[OnName num="suzune"]
'什么？
[cpg cn=true]


[OnName num="gorou"]
'那很痒，哈哈哈，哈哈哈'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune070"]
[OnName num="suzune"]
'你认为五郎有被挠的弱点吗？　要我为你做更多吗？"
[cpg cn=true]


这是一个多么适合调情的时代。


[window target=false]

[SE f="se000"]
;//【ＳＥ】『ノック』

[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




在这一切之中，有人敲响了我房间的门。
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari124"]
[OnName num="himari"]
'兄弟，你要用我的漫画走那条路吗？
[cpg cn=true]


[OnName num="gorou"]
'哦，绯红......？　嗯，我不知道。"
[cpg cn=true]


现在已经很晚了。在这个时候，谈论漫画？
[cpg]


我想，我猜测。有人暗示我太吵了。
[cpg]


[OnName num="gorou"]
'......，很吵吗？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari125"]
[OnName num="himari"]
'什么？　更重要的是，漫画呢？"
[cpg cn=true]


[OnName num="gorou"]
'哦，呃，我不认为我借了它。......'
[cpg cn=true]


我妹妹已经猜到了，让我闭嘴。然而。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari126"]
[OnName num="himari"]
'嗯。好吧，那就祝你们俩好运。
[cpg cn=true]

[free time=1000]

绯红说过这样的话。我知道你太吵了。
[cpg]


[OnName num="gorou"]
'......，我应该怎么做，姐姐？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune299"]
[OnName num="suzune"]
'别担心。我说，'我祝愿你一切顺利'。
[cpg cn=true]


这是事实，但我认为这是......，具有讽刺意味。
[cpg]


;//＠なんて思いつつ、俺達はもう一度交わることにした。




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


更多的时间过去了。我的体质已经完全稳定下来，我再也不用去医院了。
[cpg]


他们要求我解释发生了什么，但我只是感到尴尬。
[cpg]


我想知道我是否应该让我妹妹在我旁边。我正在考虑这个问题。
[cpg]


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************



然后时间就过去了。有一个假期，我和我的妹妹在散步。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune316"]
[OnName num="suzune"]
她说："我们结婚后可以住在同一个房子里，这很方便。"
[cpg cn=true]


[OnName num="gorou"]
'哦，那是肯定的。你不会在那里迷路的'。
[cpg cn=true]


真是一场对话，我们的关系又有点不同了。
[cpg]


我妹妹怀孕了。显然，这是一个女孩，我们已经想好了名字。
[cpg]


[OnName num="gorou"]
'所以......，我不知道我要做什么。我仍然不确定我是否会继续接受高等教育'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune317"]
[OnName num="suzune"]
'我们之前已经谈过这个问题了。继续接受高等教育'。
[cpg cn=true]


[OnName num="gorou"]
'但你会让你的妹妹陷入困境。抓紧时间找工作不是更好吗？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune318"]
[OnName num="suzune"]
'五郎的优先事项应该是他想做的事情。'你又不是给我糟蹋了，或者什么，你可以依靠我。
[cpg cn=true]


......，如果你想说那么多，我就不说了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_01_2_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune071"]
[OnName num="suzune"]
'总之，你记得今天是什么日子吗？
[cpg cn=true]


[OnName num="gorou"]
'让我看看......，是什么......'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune072"]
[OnName num="suzune"]
'你不记得了？　这是我们开始约会的日子，不是吗？"
[cpg cn=true]


[OnName num="gorou"]
我不记得我们开始约会的日子，......，也不记得我们成为恋人的日子。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune073"]
[OnName num="suzune"]
我们想要庆祝，即使这部分有点模糊。"
[cpg cn=true]


[OnName num="gorou"]
我想知道它是否是这样的。"
[cpg cn=true]



[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune074"]
[OnName num="suzune"]
五郎这样的人太沉闷了。
[cpg cn=true]


[OnName num="gorou"]
'不，不。日期有点模糊，但我也一直想庆祝一下'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune075"]
[OnName num="suzune"]
什么？"
[cpg cn=true]


[OnName num="gorou"]
'我有一个礼物给你。我回家后要不要打开它？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune076"]
[OnName num="suzune"]
感谢......."
[cpg cn=true]



[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


孩子出生后，我真的很忙。
[cpg]


我是个学生，但我算是个家庭主夫，我必须抚养孩子。
[cpg]


但我不认为这是艰苦的工作。我真的不认为这是必要的或任何东西。
[cpg]


这就是我和我的妹妹......，铃音的日子是多么快节奏和可爱。
[cpg]



时间在迅速流逝。而三年已经过去了。
[cpg]




;//========================================
;//●ＣＧ（街を三人で歩く。幸せそうなヒロインと娘の笑顔が正面から見えるアングル）ev_26
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//人物３：主人公の娘
;//服装３：私服
;//場所　：街
;//時間　：昼
;//備考　：娘の年齢は三歳くらいです。また、本編から三年の時間が経過しています
;//========================================




[BGM f="bg_h1"]
;**【ＣＧ】 ev_26_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]




我想，我们成了一对幸福的夫妇。
[cpg]


我没有和铃音打过一次架。我们不吵架，我们没有那种关系。
[cpg]


我们周围的人羡慕我们，但这是我们之间的自然距离。
[cpg]


我现在不想打架。我们在一起生活的时间比大多数夫妻都长。
[cpg]


我们甚至比一对儿时的朋友更了解对方。
[cpg]


[VOICE f="Suzune319"]
[OnName num="suzune"]
嘿，吾郎。
[cpg cn=true]


铃音转向我，微笑着说。
[cpg]


[OnName num="gorou"]
怎么了，铃音？
[cpg cn=true]


[VOICE f="Suzune320"]
[OnName num="suzune"]
'你很高兴。我仍然无法相信我将作为你的妻子而感到幸福'。
[cpg cn=true]


...... 那是因为我当姐姐的时间比较长。这也是没办法的事。
[cpg]


但最终你们会花更大比例的时间作为夫妻。
[cpg]


我必须尽快摆脱当她小弟的命运。我的某些部分把铃音当成了我的妹妹。
[cpg]


;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

而当我从铃音的小弟弟毕业时，她可能会有一个妹妹或弟弟。
[cpg]


考虑到这些想法，我们已经走了很长的路。
[cpg]



[SCENE id=9]

[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン１ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

*start

;###################################################################
*Ep006|珍惜绯红。
;###################################################################

;//==============================
;//２、ひまり
*select04_2|珍惜阳光


[SCENE id=6]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


我认为...... 绯红。虽然可依赖，但并不讨人喜欢。
[cpg]


但如果你问我喜欢谁，我喜欢绯红。
[cpg]


她就像一个孩子，但也有母性。
[cpg]


她有一部分把我玩弄于股掌之间，我已经越来越喜欢她了。
[cpg]


我不知道我是否有欺负人的气质，喜欢这样的人。
[cpg]


但我不介意和绯红在一起。......
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[WAIT time=1000]



[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari127"]
[OnName num="himari"]
'One-chan。这是早晨的乐趣！"
[cpg cn=true]


当我在思考这个问题的时候，绯红来了。
[cpg]


[OnName num="gorou"]
'啊，啊。是的。.......'
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari128"]
[OnName num="himari"]
'怎么了？你看起来不舒服。
[cpg cn=true]


[OnName num="gorou"]
'不是我心情不好，是......，我需要和你谈点事情。
[cpg cn=true]


他重新转向向日葵。然后他切入正题。
[cpg]


[OnName num="gorou"]
'...... 你知道他们怎么说吗，当你爱上一个人时，你的体质就会安定下来？
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari129"]
[OnName num="himari"]
'我知道。我知道医生是怎么说的'。
[cpg cn=true]


[OnName num="gorou"]
'那么，...... 绯红呢？
[cpg cn=true]


我很谨慎地问道。但绯红似乎已经猜到了。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari027"]
[OnName num="himari"]
'嗯，是的。如果是和我哥哥一起，我完全没问题。我想我也会很高兴。......"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari028"]
[OnName num="himari"]
'如果我们在一起，病情没有消失，你打算怎么做？
[cpg cn=true]


[OnName num="gorou"]
'你打算怎么做？......，这当然是令人不安的。
[cpg cn=true]


而我想的是我自己，但绯红似乎在想一些不同的事情。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Himari132"]
[OnName num="himari"]
'你可能会和其他人欺骗我。有了这样的宪法，'。
[cpg cn=true]


嗯，我很担心这个问题，我想.......
[cpg]


[OnName num="gorou"]
'我不会的。我可以向你保证。"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari133"]
[OnName num="himari"]
'我不相信。我相当怀疑和妒忌'。
[cpg cn=true]


绯红来找我，说它不止于此。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari029"]
[OnName num="himari"]
'现在，我给你一个刺激。我们该怎么做？"
[cpg cn=true]


[OnName num="gorou"]
哦，请......"
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin_up"  pos="4/7"]

[BG f="b_06_1_up.ui" time=10]
[WAIT time=200]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari030"]
[OnName num="himari"]
'现在我们该怎么做？我厌倦了用我的手触摸你。
[cpg cn=true]


[OnName num="gorou"]
即使你说你很无聊......，那么你要做什么呢？"
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari031"]
[OnName num="himari"]
'嗯，今天......，这样的事情怎么样？
[cpg cn=true]


绯红做了一些不同的事情，说。
[cpg]


;//========================================
;//●ＣＧ（ヒロインに足蹴にされる主人公。からかうような表情のヒロイン）ev_27
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：朝
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]



所以她把她的脚，而不是她的手，贴近我的身体。
[cpg]


我当时想，'你以为我是什么人？ '但我不能拒绝，因为如果我不喜欢，就会不计后果地结束它。
[cpg]


[VOICE f="sHimari032"]
[OnName num="himari"]
'我不知道。我不知道，大哥哥，我想你从这种事情中得到了刺激。"
[cpg cn=true]


你不能在这里表现得像你很高兴。另一方面，我也不能勉为其难。
[cpg]


[OnName num="gorou"]
嗯
[cpg cn=true]


[VOICE f="sHimari033"]
[OnName num="himari"]
'你看起来不开心，但我知道你其实很开心。
[cpg cn=true]


[OnName num="gorou"]
'我不高兴......，你认为我有什么样的个性？
[cpg cn=true]


但他肯定很激动。
[cpg]


;**【ＣＧ】 ev_27_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari034"]
[OnName num="himari"]
'如果这是一个征兆，我希望你能这么说。你这么固执，很可爱'。
[cpg cn=true]


[OnName num="gorou"]
'我并不是说要直言不讳。
[cpg cn=true]


是吗？　她边说边看着我的反应。
[cpg]


[VOICE f="sHimari035"]
[OnName num="himari"]
我认为刺激来自于不寻常的情况。
[cpg cn=true]


对于这个问题，绯红是如何想出这些东西的？
[cpg]


[OnName num="gorou"]
緋紅一直在考虑...... 这些事情。"
[cpg cn=true]


;**【ＣＧ】 ev_27_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari036"]
[OnName num="himari"]
'嗯？　总是这样吗？"
[cpg cn=true]


[OnName num="gorou"]
所以，即使你没有看到我。
[cpg cn=true]


[VOICE f="sHimari037"]
[OnName num="himari"]
'我不知道，我不知道...'　这只是我想到的一个想法。"
[cpg cn=true]


绯红边说边用脚摸索着我的胸甲。
[cpg]


这不是怕痒或什么。但这感觉很奇怪，是不道德的。
[cpg]


然而，我没有做任何讨厌的事情。......。
[cpg]


[VOICE f="sHimari038"]
[OnName num="himari"]
'你更喜欢哪一个，你的手还是你的脚，大哥哥？
[cpg cn=true]


[OnName num="gorou"]
什么，这个问题？
[cpg cn=true]


他问了我一些很奇怪的问题，我无法保持冷静。
[cpg]


我无法直视他。绯红看穿了这一点。
[cpg]


;**【ＣＧ】 ev_27_b ***********************
[CG id=12 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari039"]
[OnName num="himari"]
'别装傻了，我正在努力决定下一步为你做什么。
[cpg cn=true]


[OnName num="gorou"]
'......'
[cpg cn=true]


你说了那么多，我甚至无法回答。
[cpg]


我担心如果我说脚，他们现在会对我做什么，如果我说手，他们就会停止现在做的事情。
[cpg]


[VOICE f="sHimari040"]
[OnName num="himari"]
'嗯，好的。从现在开始，我也会让你在晚上感受到这种刺激。
[cpg cn=true]


当我在思考这个问题时，Himari说了一句更令人惊讶的话。
[cpg]


她表现得非常积极。这又不是我要求她做的。
[cpg]


[OnName num="gorou"]
'诶，...... 可以吗？
[cpg cn=true]


[VOICE f="sHimari041"]
[OnName num="himari"]
'不是我不介意，更多的是我想让它属于我自己。你妈妈也会给你的。我确定'。
[cpg cn=true]


他们把你当做一个东西，好像你都是自己的，或者你把它送人。
[cpg]


但我也很高兴，或者说我觉得我可以感受到绯红对我的爱。
[cpg]




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


触摸她之后，痛苦的时间又回来了。
[cpg]


但是，我可以在中午看到我的姐姐，此外，她还说绯红会在晚上为我做。......
[cpg]


相信这一点，我只得暂时忍耐。
[cpg]


[window target=false]


[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************



[SE f="se000"]
;//【ＳＥ】『歩く』





走在街上。一路走到学院。
[cpg]


同时，它仍然没有那么痛苦。但当上午的课程即将结束时，这是最困难的。
[cpg]


到午餐时间的时间，或者说，这就是......，不管你怎么想，你都必须做好准备。
[cpg]




[window target=false]


[STOPBGM]

[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************





[OnName num="male_student"]
'嘿，小坂。我听说你前几天和一个女孩在一起散步。
[cpg cn=true]


[OnName num="gorou"]
'什么？　嗯，情况并非总是如此。......"
[cpg cn=true]


[OnName num="male_student"]
别装傻了!　你说你和一个女孩手拉手，她都在你身上。"
[cpg cn=true]


[OnName num="gorou"]
你在说什么呢？　我不认识任何与我关系那么好的女孩。......"
[cpg cn=true]


哦，他来了。绯红。也许有人在她离开房子时看到了她或其他东西。
[cpg]


但如果是这样，很明显，她是我的妹妹。
[cpg]


[OnName num="gorou"]
这是我的妹妹。她的名字叫小坂绯红。
[cpg cn=true]


[OnName num="male_student"]
'哦，啊......，所以她是你的妹妹。所以她不是你的女朋友或什么？
[cpg cn=true]


[OnName num="gorou"]
'...... 是的。是的，不是女朋友。"
[cpg cn=true]


...... 一般来说，妹妹不是爱人。
[cpg]


我疯了，不是吗？我必须被提醒这一点。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



;//その後、昼休みになって姉さんに抜いてもらった。
;//＠
后来，在午餐时间，我让我姐姐提高我的心率。
[cpg]


事后。我姐姐说了这样的话。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune321"]
[OnName num="suzune"]
'嘿。你喜欢绯红吗？　也许是某种形式的忏悔？"
[cpg cn=true]


[OnName num="gorou"]
'......，你知道我的意思吗？
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune322"]
[OnName num="suzune"]
'我可以看到。绯红早上离开你的房间时，脸上有一种严肃的表情'。
[cpg cn=true]


这就是你在看的东西。我猜她有点像个鉴赏家，或者她很有姐妹情谊。
[cpg]


[OnName num="gorou"]
如果你指的是忏悔，你是否做了......？"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune323"]
[OnName num="suzune"]
'我不认为我有，没有。你需要承担适当的责任'。
[cpg cn=true]


;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



我姐姐教训我，我感觉很微妙。
[cpg]


我喜欢绯红。毋庸置疑。
[cpg]


但当我想到我是否正确面对绯红时，就很难说了。
[cpg]


她害怕作弊。考虑到我的体质，这很自然。
[cpg]

;//＠妊娠しても体質が治らなかったらと考えるのは、当然かもしれない。
可能会很自然地想到，即使我的爱得到满足，如果我的体质没有得到治愈。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************



[OnName num="gorou"]
'我回家了: ......'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari153"]
[OnName num="himari"]
'欢迎回来，兄弟。我们可以吗？"
[cpg cn=true]


[OnName num="gorou"]
'做，有点太快了......？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari042"]
[OnName num="himari"]
'你必须适应我的心情。你的兄弟没有权利选择。
[cpg cn=true]


就这样，他们强迫我，把我的手拿走了。
[cpg]


而我被带到了Himari的房间。......
[cpg]



;//========================================
;//●ＣＧ（主人公に顔を近づけるヒロイン。キスをする）ev_28
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]



她是在近距离。我无法直视她。
[cpg]


但当我把目光移开时，绯红指出了这一点。
[cpg]


[VOICE f="sHimari043"]
[OnName num="himari"]
'别看了。再仔细看看我。"
[cpg cn=true]


当你说这样的话时，它只是让我紧张。
[cpg]


[OnName num="gorou"]
'...... 是的。
[cpg cn=true]


我现在没有选择，只能点头。我没有胆量在这里拒绝。
[cpg]


但我也没有胆量接受它。
[cpg]


;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari044"]
[OnName num="himari"]
我不知道该怎么做。你将永远是一个新手。
[cpg cn=true]


像往常一样，绯红的脸皮相当厚。
[cpg]


如果她像她一样随和，也许我就不会有这种宪法了。......
[cpg]


[OnName num="gorou"]
'你不能帮助它。...... 如果你不再激动，那就是一个问题。
[cpg cn=true]



我很害怕，绯红比平时更接近，说。
[cpg]


[VOICE f="sHimari045"]
[OnName num="himari"]
'从那时起，我就想知道什么让你最紧张。
[cpg cn=true]


绯红看着我，给了我一个计谋性的微笑。
[cpg]


在这么远的地方有这么漂亮的女孩，真让人激动。
[cpg]


但绯红仍然看起来想做什么。
[cpg]


[OnName num="gorou"]
'，你是如此接近。
[cpg cn=true]


;**【ＣＧ】 ev_28_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari046"]
[OnName num="himari"]
'现在说这个有点晚了，不是吗？　你以前做了那么多事情，你还害怕只是接吻吗？"
[cpg cn=true]


我不敢说这件事，但绯红说了。
[cpg]


我知道她要吻我。
[cpg]


[OnName num="gorou"]
'......，对我好一点。
[cpg cn=true]


[VOICE f="sHimari047"]
[OnName num="himari"]
'我说得像个女孩，漂亮~'
[cpg cn=true]


如果发生这种情况，我想我只能准备好自己。我就是这么想的，然后闭上了眼睛。......
[cpg]


;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari048"]
[OnName num="himari"]
'呵。漂亮的脸蛋。"
[cpg cn=true]


然后她就没有再吻我。
[cpg]


我睁开细长的眼睛，看着希玛莉。
[cpg]


[VOICE f="sHimari049"]
[OnName num="himari"]
'我想我会用我的手机拍下我弟弟的吻脸...'
[cpg cn=true]


[OnName num="gorou"]
'做，你是什么意思？
[cpg cn=true]


[VOICE f="sHimari050"]
[OnName num="himari"]
'你想让我吻你吗？　那我希望你能这么说。
[cpg cn=true]


[OnName num="gorou"]
'...... 有时绯红看起来像一个恶魔。
[cpg cn=true]


[VOICE f="sHimari051"]
[OnName num="himari"]
'你是说恶魔般的类型？　我真为你感到高兴。"
[cpg cn=true]


绯红笑着说。但对于悬浮在半空中的我来说，它看起来仍然像魔鬼的微笑。
[cpg]


[VOICE f="sHimari052"]
[OnName num="himari"]
'那么，你是怎么想的？　我想让你吻我。"
[cpg cn=true]


[OnName num="gorou"]
这是......."
[cpg cn=true]


在我说这句话的时候，她给了我一个不可抗拒的眼神，并把她的嘴唇送到我的面前。
[cpg]


;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト


;**【ＣＧ】 ev_28_b ***********************
[CG id=13 index=2 time=1000]
;***************************************
[WAIT time=1000]

我们的嘴唇相互接触。这是一个轻柔的吻，但感觉我们终于越过了界限。
[cpg]



;//ＣＧ再び表示

;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]

然后我们拉开距离。我们不再只是兄弟姐妹。
[cpg]


[VOICE f="sHimari053"]
[OnName num="himari"]
'...... 大哥哥，你真的很可爱。
[cpg cn=true]


当他对我说这句话时，我可以感觉到我的脸越来越热。
[cpg]


我没有想到，被告知我很漂亮会让我如此紧张和......。
[cpg]


我也没有想到这个吻本身会有这样的感觉。
[cpg]


[VOICE f="sHimari054"]
[OnName num="himari"]
'那好吧。我会把接吻推迟一段时间，我不想让你通过正常的皮肤关系失去刺激。"
[cpg cn=true]


我觉得我的脸都红了。我认为这更像是因为另一边的绯红也在脸红。
[cpg]


我想知道从现在开始我们会有什么样的关系......。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


要记住的最重要的事情是，你不应该害怕寻求帮助。
[cpg]


我感觉我无法入睡，但我比这更高兴。
[cpg]


我想知道绯红是否处于类似的心理状态......，但我不能确定。
[cpg]


一段时间后，在星期六。
[cpg]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の家＿玄関』（昼）******************************************************



当时我刚从医院回来。
[cpg]


我和我妈妈去了那里，我被告知了一些事情，有点......，令人震惊。
[cpg]




;//ブラックアウト


[window target=false]


[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Himari173"]
[OnName num="himari"]
'欢迎回来。情况如何？"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Sawa105"]
[OnName num="sawa"]
'事情是这样的--......，这有点，有点大材小用。
[cpg cn=true]


我必须告诉你细节，不是吗？这不是我要让我母亲告诉我的事情。
[cpg]


[OnName num="gorou"]
'......，他们说有一种药可以治好我的病。但是。"
[cpg cn=true]


[OnName num="gorou"]
'他说，他非但没有治好自己的病，反而会对爱情失去兴趣。
[cpg cn=true]


简而言之，我们谈论的是失去了激动人心的愿望。
[cpg]


如果你不再想与任何人相爱，这是一个关于...... 人的生命的故事。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
绯玉和她姐姐的表情变得阴晴不定。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune324"]
[OnName num="suzune"]
'医生也会说可怕的事情，......，如果他们说这样的话，你只会变得更加焦虑。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

是的，没错。但是，希玛里沉默不语，也许想的是不同的。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

而我和绯红单独在一个房间里。
[cpg]


绯红闯入我的房间。
[cpg]


她想谈点什么，或者说，我也想和她谈点什么。
[cpg]


[OnName num="gorou"]
'......，你怎么看。关于如何治疗你的体质'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari055"]
[OnName num="himari"]
'这很好。没什么，我想如果我这样做就可以了'。
[cpg cn=true]


[OnName num="gorou"]
'嗬，说真的!　因为......，如果我吃了药，我相信我也不会对绯红有什么想法。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari175"]
[OnName num="himari"]
'如果我哥哥不欺骗我，我还是会喜欢的。但......."
[cpg cn=true]


绯红在说这句话时显得有些尴尬。和......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari056"]
[OnName num="himari"]
'如果我可以，我也希望你仍然是你一直以来的兄弟，只是你的体质会被治愈。
[cpg cn=true]


...... 我明白了。绯红是这样想的吗？
[cpg]


正如医生所说，你和绯红应该走到一起，你的体质应该稳定下来。
[cpg]


那是最好的状态。但如果宪法没有安顿下来，那么......
[cpg]


也许我将被剥夺爱本身的权利。
[cpg]


即使有这样的决心，我还是要和绯红出去。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari057"]
[OnName num="himari"]
'嘿。你也准备好了，不是吗，大哥哥？
[cpg cn=true]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト



[window target=true]


绯红走近。她试图吻我。......
[cpg]


我开始有点不耐烦了。我知道我也想和绯红做爱。
[cpg]


[window target=false]

[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





时间在流逝，再过一会儿就到了吃晚饭的时间。
[cpg]



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari058"]
[OnName num="himari"]
快到吃晚饭的时间了。我们很快就可以走了吗？"
[cpg cn=true]


[OnName num="gorou"]
'......'
[cpg cn=true]



我觉得我可以多和绯红接触，看看她的体质是否稳定下来。
[cpg]


但是，如果我太仓促，绯红会不会变得幻灭，而爱情本身也会没有结果？
[cpg]


经过思考，我想出了一个答案。
[cpg]


;//■選択肢
[switch]
[case "我将会更加接近绯红，即使我必须要稍微推动一下自己。"]
	[swap]
	[jump target="*select05_1"]
[case "慢慢来，别着急"]
	[swap]
	[jump target="*select05_2"]
[endswitch]

1.更接近Himaru，即使有点不知所措
2，慢慢来，不要着急。



;//==============================
;//１、多少無理してもひまりに近づく
*select05_1|珍惜绯红。




[OnName num="gorou"]
'再和我们呆一会儿吧。緋紅"。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sHimari059"]
[OnName num="himari"]
但食物是......"
[cpg cn=true]


[OnName num="gorou"]
'快走吧!　如果你继续这样下去，你无法真正治愈你的体质。"
[cpg cn=true]



[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari060"]
[OnName num="himari"]
'...... 是的。好吧，如果你坚持这么说的话。
[cpg cn=true]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ブラックアウト


[window target=true]

就这样，与绯红的日子继续着。但在幕后，不适感也在不断累积。
[cpg]


绯红怎么会看到我着急呢？
[cpg]


如果我吓到她或让她感到不舒服，哪怕是一点点，那就不好了。
[cpg]


甚至 "我不擅长这个 "的感觉也再次变成了不耐烦。
[cpg]


;//移植前シーンカット


[window target=false]
[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari061"]
[OnName num="himari"]
'嘿，兄弟。你不应该得到我所说的待遇吗？"
[cpg cn=true]


[OnName num="gorou"]
为什么......，我喜欢绯红？"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari062"]
[OnName num="himari"]
'是的，但也许是你的体质使你认为你喜欢我。
[cpg cn=true]


[VOICE f="sHimari063"]
[OnName num="himari"]
'如果你不捶打，你就无法呼吸。我以为你爱上了我，因为你想捣蛋。
[cpg cn=true]


面对我的不耐烦，向日葵开始质疑她是否真的被爱。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（昼）******************************************************





然后，绯红逐渐开始对我采取冷漠的态度。
[cpg]


但我的体质还很好，所以我和绯红的关系很苦。
[cpg]


[OnName num="gorou"]
'该死，我很痛苦，...... 緋紅!
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari064"]
[OnName num="himari"]
'我不知道该怎么做。我没有心情'。
[cpg cn=true]



[window target=false]

[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『街』（夜）******************************************************



讽刺的是，在我痛苦的时候，绯红对我产生了兴趣。
[cpg]


也许她一直都有这种气质。
[cpg]



我只能想象，但......，我有一种感觉，她确实如此。
[cpg]


[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト


绯红不再向我靠近。她不能再做捶打，而我还在痛苦中。
[cpg]


它是如此痛苦，以至于有一天晚上我甚至无法入睡.......。
[cpg]


;//========================================
;//●ＣＧ（寝ている主人公に寄り添うヒロイン。サディスティックな感じ）ev_30
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="gorou"]
'哈，哈......，绯红？
[cpg cn=true]


她来到了我的房间。我已经等了她很久了，我觉得我现在就想拥抱她。
[cpg]


但我无法呼吸，也无法起身。
[cpg]


无论她是否知道我处于这种情况，她都说。
[cpg]


[VOICE f="sHimari065"]
[OnName num="himari"]
'也许我想一直看着我痛苦的弟弟......。
[cpg cn=true]


他一边笑着一边说着残酷的事情。
[cpg]


我不能呼吸，我一直不能呼吸，呼吸太难了，如果不呼吸，我真的会死。
[cpg]


[OnName num="gorou"]
'绯红......，请到我身边来。
[cpg cn=true]


;**【ＣＧ】 ev_30_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari066"]
[OnName num="himari"]
'我想知道我应该怎么做？　我哥哥现在有点太绝望了，也许我不想和他亲近。"
[cpg cn=true]


绯红以她一贯的语气平静而轻蔑地说道。
[cpg]


[OnName num="gorou"]
'桑尼，绯红并不关心我发生了什么。
[cpg cn=true]


[VOICE f="sHimari067"]
[OnName num="himari"]
'......，这很难，大哥哥。你已经变得如此依赖捣蛋了'。
[cpg cn=true]


依靠绯红而不是Dokidoki，我叫她的名字。
[cpg]


[OnName num="gorou"]
'緋紅......，哦，緋紅，緋紅！'
[cpg cn=true]


[VOICE f="sHimari068"]
[OnName num="himari"]
'怎么了？　你想从我这里得到什么，叫我那么多？"
[cpg cn=true]


管它呢，这很明显。
[cpg]


[OnName num="gorou"]
'请...... 捣毁我。如果你不这样做，这是在你的宪法中。......
[cpg cn=true]


[VOICE f="sHimari069"]
[OnName num="himari"]
宪法，嗯？ 对。"
[cpg cn=true]


;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari070"]
[OnName num="himari"]
'嘿。实际上，我正在接受一些药物治疗，以治愈我的病情。"
[cpg cn=true]


[OnName num="gorou"]
什么？"
[cpg cn=true]


有一瞬间，我不明白希玛里在说什么。
[cpg]


但我昏昏沉沉的脑袋渐渐开始明白了。
[cpg]


[VOICE f="sHimari071"]
[OnName num="himari"]
'我想，也许我的兄弟不会想自己喝酒。但现在你在痛苦中，你确实想喝酒'。
[cpg cn=true]


[OnName num="gorou"]
'哦，不......，只要绯红能靠近我，那就足以帮助我呼吸了。
[cpg cn=true]


我想我是自私的。但我忍不住说了出来。
[cpg]


这就是它的痛苦之处。不仅是我的呼吸，而且我的心脏也在受苦。
[cpg]


;**【ＣＧ】 ev_30_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari072"]
[OnName num="himari"]
'这只是暂时的，不是吗？你必须一直让我在你身边，这是不健康的。
[cpg cn=true]


[OnName num="gorou"]
但是！"
[cpg cn=true]


绯红从头到尾都显得有些惊慌失措。
[cpg]


我越是绝望，越是适得其反。尽管我知道，但我还是忍不住不耐烦了。
[cpg]


[VOICE f="sHimari073"]
[OnName num="himari"]
'我想知道这些药丸里有什么？　它是否会减少睾丸激素？"
[cpg cn=true]


[VOICE f="sHimari074"]
[OnName num="himari"]
'那你就可以知道为什么我对浪漫失去了兴趣。我想这也会让我对没有心跳的感觉好起来。
[cpg cn=true]


绯红说的是可怕的事情。我真的要放下这份爱吗？
[cpg]


光是想象我不能爱上绯红就很难了。但呼吸更困难了。
[cpg]


[OnName num="gorou"]
'Kuu...... 痛苦，緋紅，帮助我。
[cpg cn=true]


看到我痛苦的样子，緋紅似乎并不着急。
[cpg]


[OnName num="gorou"]
'我应该怎么做......，我做了什么让你这么恨我？
[cpg cn=true]


;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari075"]
[OnName num="himari"]
'没事的。我不恨你。尽管我的哥哥已经中立了，但我仍然喜欢他。
[cpg cn=true]


她用平静、温和的语气说着可怕的事情。
[cpg]


[VOICE f="sHimari076"]
[OnName num="himari"]
'也许到时候我会把你当做一个装扮的娃娃来玩？
[cpg cn=true]


[OnName num="gorou"]
'那个，啊，那个.......'
[cpg cn=true]


这种爱，已经嗤之以鼻。绯红有些乐在其中。
[cpg]


而我，则没有时间去享受它。
[cpg]


我没有想到......，最后会变成这样。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



......，怎么会变成这样？
[cpg]


尽管我很后悔，但最后我的呼吸还是很痛苦。
[cpg]


为了逃避痛苦，我吃了药。
[cpg]


[OnName num="gorou"]
'哈哈，哈哈......，緋紅。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari077"]
[OnName num="himari"]
'这就对了。你太有魄力了，大哥哥，你吓到我了。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari078"]
[OnName num="himari"]
现在我的兄弟是我的，也是我一个人的。......
[cpg cn=true]


说到这里，绯红拍了拍我的头。对此，我不再感到激动。
[cpg]


[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ブラックアウト



我的捣蛋真的是由绯红管理的。
[cpg]


我的心已经被锁住了。......
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*back_title"]
;//ＥＮＤ：バッドエンドルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================
;//２、ゆっくり慣らしていこう
*select05_2|珍惜绯红。




[OnName num="gorou"]
'......，我同意。
[cpg cn=true]




绯红可能是困难的。我不想让她看到我太着急了。
[cpg]


相反，我想照顾好...... 緋紅。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



之后，在我们吃完晚饭后，绯红就来到了我的房间。
[cpg]


她说她不希望看到我受苦。
[cpg]


通过不从我这边要求太多，绯红从我这边要求了。......
[cpg]



[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari079"]
[OnName num="himari"]
'我希望我可以......，做点什么。医生说如果你坠入爱河，你就会痊愈，对吗？"
[cpg cn=true]


[OnName num="gorou"]
'嗯，差不多就是这样的情况。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari080"]
[OnName num="himari"]
'它是蓬松的，不是吗？爱有什么关系呢？
[cpg cn=true]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_h1"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



比如说。你不是在谈论简单的结婚或类似的事情。
[cpg]

即使是这样，我也不想仓促行事。我不想强迫绯红做任何事情。
[cpg]


[window target=false]


[STOPBGM]

[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



但似乎绯红在我之前就下定了决心。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari229"]
[OnName num="himari"]
'...... 你知道吗？如果事情继续这样下去，它不会很快结束，对吗？"
[cpg cn=true]


[OnName num="gorou"]
'没有必要急于求成。让我们慢慢来吧....... Himari？"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari081"]
[OnName num="himari"]
'更多伟大的事情，我会为你做。即使你哥哥不愿意，我也会。
[cpg cn=true]


[OnName num="gorou"]
'......，要温柔。
[cpg cn=true]



我从来没有厌恶过它。但我认为如果我要求的话，就不会发生这种情况。
[cpg]


我真的以为爱情是一种奇怪的东西。
[cpg]


;//ブラックアウト

;//移植前シーンカット


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



绯红和我花了一天时间进行适度的调情。
[cpg]


我们甚至在路上去餐厅吃饭。......。
[cpg]




;//ブラックアウト


[window target=false]



[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari247"]
[OnName num="himari"]
'谢谢你的食物。那么，大哥哥，我们回你的房间去吧。
[cpg cn=true]


[OnName num="gorou"]
'这太明目张胆了，......'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari248"]
[OnName num="himari"]
'时间是有限的，我们不能磨磨蹭蹭。
[cpg cn=true]

[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa106"]
[OnName num="sawa"]
'咯咯笑。你们真的很亲密......'
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



然后他们回到自己的房间，进行了一场黏稠的调情。

[cpg]


在做这些的时候，我们甚至谈到了一起睡在被褥上。......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari249"]
[OnName num="himari"]
'嘿，这很好。也许人们已经知道了。"
[cpg cn=true]


[OnName num="gorou"]
我知道。...... 那么好吧。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari250"]
[OnName num="himari"]
'知道了。和我弟弟睡觉。"
[cpg cn=true]


看到绯红这样，我觉得她仍然是我的小妹妹。
[cpg]


尽管我真的想做她的情人。在那里，它将不可避免地成为一个中间地带。
[cpg]


她是我的妹妹，但她是我的爱人。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=1000]

然后他们依偎在一起，进入了梦乡。......。
[cpg]


激动但松了一口气。我又想起了这个词，因为我已经想了很多次。
[cpg]


我认为那是一段快乐的时光。这感觉就像是对我和绯红之间的爱情的确认。
[cpg]


如果当时我很着急，绯红体内的感情可能会冷却下来。
[cpg]


当然，会有一个与现在不同的未来。
[cpg]


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari251"]
[OnName num="himari"]
"嗯 ...... 困了 ......"
[cpg cn=true]


绯红先醒过来，摇晃着我。
[cpg]


现在已经是工作日了吗？我必须要去学院。......
[cpg]


但现在的时间还很早。有什么计划？
[cpg]


[OnName num="gorou"]
'现在不是早......吗？　如果你困了，为什么不回到床上去？"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari082"]
[OnName num="himari"]
'不'。你在试图治疗你的体质。
[cpg cn=true]


[OnName num="gorou"]
......，你是对的。"
[cpg cn=true]


如果我不花一点时间和你在一起，我的体质就不会稳定下来。
[cpg]


即使是这样，我认为也不必在这么早的时候。......
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_06_1_up.ui" time=1000]
[WAIT time=2000]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sHimari083"]
[OnName num="himari"]
'嘿，让我们接吻吧。我还没有刷牙。"
[cpg cn=true]


[OnName num="gorou"]
这是不卫生的。......
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari084"]
[OnName num="himari"]
'如果你想想你的身体，如果你不吻它，你会更痛苦。
[cpg cn=true]


...... 的确如此。
[cpg]



;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



快乐的时光意味着它们很快就会过去。我还得去上学。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari085"]
[OnName num="himari"]
嗯。......，我希望我的早晨能长一点。"
[cpg cn=true]


[OnName num="gorou"]
'我想我只能早起了？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari086"]
[OnName num="himari"]
'那会使夜晚变得更短，不是吗？
[cpg cn=true]



;//ブラックアウト



没有绯红的日子越来越难熬了。
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『学園教室』（昼）******************************************************





不出所料，到了中午时分，我已经摇摇晃晃了。
[cpg]


我想过要去我姐姐那里，但我还是忍住了。
[cpg]


一般来说，如果我不断地重复这样的日子，我的体质就会及时地稳定下来。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************





时间过去了。特别是......
[cpg]


足够的时间过去了，我不需要捣鼓，也不需要用力呼吸。
[cpg]


与绯红的关系在家里已经完全暴露。
[cpg]


我向父亲解释了很久，但他终于承认了。
[cpg]



;//ブラックアウト


[window target=false]

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari087"]
[OnName num="himari"]
'你哥哥要做你的丈夫，对吗？
[cpg cn=true]


[OnName num="gorou"]
如果你这样说的话，那么绯春也是你的妻子。"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari088"]
[OnName num="himari"]
'嘿嘿。很高兴听到这个消息'。
[cpg cn=true]



直到最近，她还只是一个小妹妹。我晕头转向的日子开始......
[cpg]



;//ブラックアウト


[window target=false]

[STOPBGM]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


我已经有了一份工作，我将在春天开始工作。
[cpg]


绯想马上结婚，所以为了所谓的学校而学习是不够的。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari272"]
[OnName num="himari"]
'我进来了，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'哦，绯红......，怎么了？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari089"]
[OnName num="himari"]
'你哥哥的体质最近已经稳定下来了，是吗？这就是为什么......，我想念你。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari090"]
[OnName num="himari"]
'我不知道......，我想靠近我的兄弟。
[cpg cn=true]


[OnName num="gorou"]
'是的。我也这么认为。这与敲打没有关系'。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari091"]
[OnName num="himari"]
'我喜欢我的...... 弟弟的这一点。你把我当回事。
[cpg cn=true]


[OnName num="gorou"]
'真的吗？　我觉得我很轻浮。"
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari092"]
[OnName num="himari"]
'但你不像我这么轻浮，是吗，大哥？
[cpg cn=true]




...... 緋紅称我为她的大哥哥。
[cpg]


我希望她现在不要再这样叫我了，但......，绯红很难改变。
[cpg]



[OnName num="gorou"]
'你知道吗？如果你要结婚，你可以改变你对我的称呼。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari293"]
[OnName num="himari"]
'连你的哥哥都叫你姐姐。
[cpg cn=true]


这完全无关紧要。我和我妹妹没有任何关系。
[cpg]



[OnName num="gorou"]
这是一派胡言。......，这是行不通的。"
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari294"]
[OnName num="himari"]
'没关系的。我再不说就不行了，所以现在就说'大哥'吧。
[cpg cn=true]



对，这就是我的意思。那么我可以理解，为什么他们不能这样说呢？
[cpg]

;//ブラックアウト
;//移植前シーンカット
;//移植前シーンカット

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



就这样，我和绯红的日子一直在继续。
[cpg]


这让人头晕目眩。然后，当我们终于结婚时：......
[cpg]


;//========================================
;//●ＣＧ（椅子に座って、編み物をするヒロイン。おなかは膨らんでいない形にしてください）ev_35
;//人物１：ヒロイン２
;//服装１：私服
;//場所　：主人公の家＿リビング
;//時間　：朝
;//備考　：元のＣＧと違って、おなかは膨らんでいない形にしてください
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


有人看到绯红在客厅里织毛衣。
[cpg]


我不认为她是一个狡猾的人，但我不知道她是否有这样的爱好。
[cpg]


[OnName num="gorou"]
'......，我不记得她会编织。
[cpg cn=true]



绯红摇了摇头。我知道，我从未见过她这样做。
[cpg]


[OnName num="gorou"]
[OnName num="gorou"]
'我不能做的时候就做。
[cpg cn=true]


[VOICE f="Himari315"]
[OnName num="himari"]
'你将能够。'因为我知道会有一些日子，你会感到无聊。
[cpg cn=true]


你和我有这样的对话。也许他们正在谈论生孩子的问题。
[cpg]


我不需要再问了。而在这一天，我听到了我一直期待的话语。
[cpg]


;//;**【ＣＧ】 ev_35_a ***********************
;//[CG id=15 index=1 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="sHimari093"]
[OnName num="himari"]
'从现在开始留在我身边，戈罗。
[cpg cn=true]


他叫我戈罗。我感觉自己的胸口被打了一拳。
[cpg]


在这一刻，我已经从一个单纯的大哥哥毕业了。
[cpg]


这并不公平。绯红用她的称呼迷惑了我，但我对此无能为力。
[cpg]


[OnName num="gorou"]
'...... 是的。緋紅"。
[cpg cn=true]


我别无选择，只能叫绯红为绯红。但有一天，我会叫她妈妈。
[cpg]


你叫我五郎的时间会很短。
[cpg]


但这也没关系。这就是我的快乐。......
[cpg]


我哥哥成为父亲的日子在我眼前渐渐逼近。
[cpg]


我只是很高兴。
[cpg]



;//ブラックアウト

不是作为她的兄弟，而是作为她的情人，就在身边。
[cpg]


你不是每天都能成为曾经的兄弟和现在的女友。
[cpg]


我有一种感觉，从现在开始我就会很兴奋，有一天我也想让Himaru有同样的感觉。
[cpg]


她的性格相当强势，所以我可能很难做点什么。......
[cpg]


我想感到兴奋，我想让他们感到兴奋。这就是一个普通情人的欲望。
[cpg]





;//ブラックアウト

[SCENE id=10]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン２ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================

*start

;###################################################################
*Ep007|对Sunahane的不想要的想法。
;###################################################################


;//３、砂羽
*select04_3|

[SCENE id=7]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


我想到了我母亲的脸。不，我知道这不可能发生，但它就这样出现在我面前。
[cpg]


姐姐和绯红还是不错的。她们是妯娌，年龄相仿。
[cpg]


但是和我妈妈在一起，年龄差距相当大。不......
[cpg]


他说他是一个已婚男人。你有一个父亲。
[cpg]


而我的父亲对我来说仍然是我的父亲，......，我越想越觉得不可能。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[window target=true]

是绯红让我在早上感到紧张。她来到我的房间，......
[cpg]


而在那之后，我对离开房子感到犹豫不决。
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari317"]
[OnName num="himari"]
'兄弟，你不是已经去了吗？　我们要迟到了。"
[cpg cn=true]


[OnName num="gorou"]
'是的，我一会儿就到.......，去吧。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari318"]
[OnName num="himari"]
'嗯。我得去看看你妈妈。
[cpg cn=true]


他们看穿了这一点。这就是事情的真相。......
[cpg]


[free time=1000]

[SE f="se003"]
;//【ＳＥ】『ドア閉まる』


绯红离开后，就剩下我和妈妈。
[cpg]


姐姐和爸爸去工作了。绯红也上了学。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa108"]
[OnName num="sawa"]
'......，你想要见我，对吗？　我想知道......"
[cpg cn=true]


他在轻松的气氛中问我。
[cpg]


我想你已经可以看出，我有一些严肃的想法。但我的母亲敢于让我这样做。
[cpg]


[OnName num="gorou"]
'我，嗯，...... 我母亲的...... 母亲和...... 嗯...'
[cpg cn=true]


我不知所措了。我不知道该说些什么。
[cpg]


我觉得如果我说出来，就意味着结束了。在这样的时候。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa109"]
[OnName num="sawa"]
'我几乎可以看到它。也许我离得太近了--'
[cpg cn=true]


我几乎总是能看出来，我母亲曾告诉我。还有就是我离得太近了。......
[cpg]


[OnName num="gorou"]
'嗯，嗯，......，这是...'
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa026"]
[OnName num="sawa"]
'我不能帮助它。如果你说你喜欢它。
[cpg cn=true]


......，轻松通过。不，这不是好事。
[cpg]


[OnName num="gorou"]
'嘿，等一下，等一下!　我是认真的。"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa027"]
[OnName num="sawa"]
'不管怎样，今天晚上见。如果我不早点到那里，我上学就要迟到了。
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





所以我们去了学校。
[cpg]


但我已经在空中了。尽管我在白天会看到我的妹妹，......
[cpg]


即使考虑到这一点，我也无法保持冷静。想到我的母亲会为我这样做。
[cpg]


这一点就使我痛苦地感到紧张。我以前从来没有过这样的暗恋。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************



而在晚上放学的时候。我感到很慌张。
[cpg]


妈妈说："我也没办法，是吧？"这是真的吗？
[cpg]


我有些不讲情面。自然，我必须在爸爸回家之前和他谈谈。
[cpg]


爸爸和妈妈有单独的房间，所以他们没有机会撞到一起。
[cpg]




;//ブラックアウト


[window target=false]

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



当我在想这些的时候，我到了家。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Himari319"]
[OnName num="himari"]
欢迎回家。你看起来棒极了。"
[cpg cn=true]


它是什么颜色？它是红色还是蓝色？这并不重要。
[cpg]

[free time=1000]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa028"]
[OnName num="sawa"]
'嗯。你看起来很难受的样子。很好。"
[cpg cn=true]


拍了拍我的头，我被带到了母亲的房间。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




只要有她在我身边，握着我的手，就足以让我感觉到我要失去它。
[cpg]


我不禁感到，我的思想被控制得那么厉害。
[cpg]



;//========================================
;//●ＣＧ（ヒロインが寝ている主人公に近づく。穏やかに微笑んでいる→心配そうな表情に）ev_36
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================



[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sSawa029"]
[OnName num="sawa"]
'......，我想知道像这样在你身边是否会让你紧张。
[cpg cn=true]


我很激动。我点了点头，回答道。
[cpg]


[OnName num="gorou"]
'是的。......，它非常、非常平静。
[cpg cn=true]


妈妈撅了一会儿嘴，然后笑了一下。
[cpg]


[VOICE f="sSawa030"]
[OnName num="sawa"]
'嗯。平静，是这样吗？　你不应该感到兴奋吗？"
[cpg cn=true]


但我只能这么说。
[cpg]


也许我毕竟不是想悸动，我是想冷静下来。
[cpg]


也许是我一直有呼吸困难的事实，也许是我不能得到一个暗恋的对象，我就像焦虑的.......。
[cpg]


如果是这样的话，也许我的体质只要做这个就能治好。
[cpg]


只要在妈妈身边，我就觉得很有成就感。
[cpg]


;**【ＣＧ】 ev_36_a ***********************
[CG id=16 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa031"]
[OnName num="sawa"]
'哦，好吧。我想做你想让我做的事。
[cpg cn=true]


[OnName num="gorou"]
'谢谢你。妈妈。"
[cpg cn=true]


[VOICE f="sSawa032"]
[OnName num="sawa"]
'......，我真的很担心你。我也把五郎当作我的孩子。
[cpg cn=true]


然后，突然，他看起来很担心。
[cpg]


;**【ＣＧ】 ev_36_b ***********************
[CG id=16 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa033"]
[OnName num="sawa"]
'我想如果你为我感到兴奋，那也很好。
[cpg cn=true]


[VOICE f="sSawa034"]
[OnName num="sawa"]
'如果这意味着他不必受苦，我愿意为五郎做任何事。
[cpg cn=true]


我不知道你这么看重我。她给人的印象是平静的，所以我有点吃了一惊。
[cpg]


[OnName num="gorou"]
'我很高兴.......非常感谢你。"
[cpg cn=true]


我这样说，知道这是一个愚蠢的说法，但想让他知道我很感激。
[cpg]


我努力使自己的脸色尽可能严肃，声音也尽可能严肃。我试图传达我的感受，但......
[cpg]


但我妈妈看起来特别恼火。
[cpg]


出于某种原因，她看起来更苦恼，这就是她在我看来的样子。
[cpg]


[VOICE f="sSawa035"]
[OnName num="sawa"]
'如果五郎说他喜欢我，那么我想这也是可以的。这不是谎言'。
[cpg cn=true]


妈妈小心翼翼地选择她的语言，并逐渐告诉我她的感受。
[cpg]


;**【ＣＧ】 ev_36_c ***********************
[CG id=16 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa036"]
[OnName num="sawa"]
'我不知道该怎么做。他绝对是我的孩子，但我也喜欢他'。
[cpg cn=true]


我明白了。......，我不知道我让你这么想。
[cpg]


[OnName num="gorou"]
......."
[cpg cn=true]


我是不是太不敏感了？我面对的是一个儿子，尽管是一个继子。
[cpg]


我把我妈妈逼到了绝境。我已经意识到了这一点。
[cpg]


我想我的行为可能太自私了，但我仍然无法停止...... 这种感觉。
[cpg]


[OnName num="gorou"]
我很抱歉。但我不能停下来。"
[cpg cn=true]


我不知道该怎么做。但如果我把这种焦虑大声表达出来，会不会让我母亲更加恼火？
[cpg]


那么我想最好是说我想做什么。
[cpg]


[OnName num="gorou"]
我想吻你。
[cpg cn=true]


仿佛是为了掩饰，我说。她点了点头。
[cpg]


我看到她闭上了眼睛，我走近了一些。......
[cpg]


这一步将是任何理智的人都不会采取的措施。但我早已经疯了。
[cpg]


[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

...... 而且。
[cpg]


我亲吻了我母亲的嘴。我迈出了显然不应该迈出的一步。
[cpg]


[OnName num="gorou"]
......"


;//ＣＧ
;**【ＣＧ】 ev_36_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sSawa037"]
[OnName num="sawa"]
'呼。不要做这种表情。
[cpg cn=true]


我本来会是什么样子？　他看起来很遗憾吗？
[cpg]


[VOICE f="sSawa038"]
[OnName num="sawa"]
我有没有好好地敲打你？"
[cpg cn=true]


你这样一说，我不激动是假的。然而。
[cpg]


[OnName num="gorou"]
'再来一次......'
[cpg cn=true]


[VOICE f="sSawa039"]
[OnName num="sawa"]
'不，你不能。今天就到此为止。你已经习惯了重击，这对你没有好处，是吗？
[cpg cn=true]


[OnName num="gorou"]
嗯，是的，但是...
[cpg cn=true]


[VOICE f="Sawa132"]
[OnName num="sawa"]
'哦，上帝。不要太执着，否则女孩们会讨厌你！'
[cpg cn=true]


女孩，是否包括我的母亲？
[cpg]


这样问很不礼貌，所以我闭嘴，退了出去。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





我不想让我的母亲讨厌我。我不想为此做任何事情。
[cpg]


我很矛盾，不知道它们是否有冲突。
[cpg]

[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[SE f="se009"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





早上，我无法正常看到母亲的脸。
[cpg]


看到这一点，我姐姐和绯红似乎也感觉到了。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Himari320"]
[OnName num="himari"]
'你越过了某种界限，不是吗？　大哥哥。"
[cpg cn=true]


[OnName num="gorou"]
'...... 那是......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune325"]
[OnName num="suzune"]
'......，我不会说什么。你们两个需要在自己之间解决这个问题。
[cpg cn=true]


这就像已经说了。这很令人厌恶。
[cpg]


但我不能帮助它。我喜欢我的母亲。
[cpg]


[free time=1000]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa133"]
[OnName num="sawa"]
不要过多地折磨五郎。是我推着你去做的。
[cpg cn=true]


他将与我一起承担。如果爸爸在这里，他就会有很多麻烦。
[cpg]


我很高兴我爸爸是早早离开家的人。......，我完成了我的早餐。
[cpg]


;//ブラックアウト

[window target=false]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************


[OnName num="gorou"]
我走了。......
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa134"]
[OnName num="sawa"]
'是的。祝你有个愉快的一天。
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari321"]
[OnName num="himari"]
我走了。"
[cpg cn=true]


......，我感到无法形容。我想在我母亲的身边。
[cpg]


但这是一个未实现的愿望。
[cpg]


我是她的儿子，尽管她是我的继女，而且我首先要去学院。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[window target=false]

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[window target=true]


我打算去学院，同时有点心事重重。
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="male_student"]
我不知道我的感觉如何，但我不确定。你不觉得今天的我有些不同吗？"
[cpg cn=true]


[OnName num="gorou"]
'我不...... 知道，我也不认为，但......'
[cpg cn=true]


[OnName num="male_student"]
'我们出去了!　我的春天也已经来临了，哈哈。"
[cpg cn=true]


[OnName num="gorou"]
'是的。对你有好处。"
[cpg cn=true]


[OnName num="male_student"]
'多么单薄的回应啊。当然，我们甚至还没有亲吻过'。
[cpg cn=true]


...... 我吻了一个我甚至没有约会的人。而且是和我的岳母一起。
[cpg]


即使我想说，我也不能这么说。在此期间，是我妹妹等我的时候了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_03_2_up.ui" time=1000]
[WAIT time=2000]

还有午餐时间。当我们单独在一起时，我妹妹对我说。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Suzune326"]
[OnName num="suzune"]
'......，你的母亲是我们真正的母亲。所以......."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Suzune327"]
[OnName num="suzune"]
'不要大意，不要破坏我们的家庭。
[cpg cn=true]


他们说。这是个相当严厉的词。
[cpg]


她说'亲生母亲'的方式也有点刺耳。但我没有选择。
[cpg]


我就像一个异物。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





我的体质如果不与别人相爱，就无法治愈。
[cpg]


我想，我的姐姐和绯红也是可能的伙伴。
[cpg]


但我并不想这么做。我爱的人是我的母亲。
[cpg]


我想不出别的办法。我喜欢我的母亲。
[cpg]


现在我说出来了，我明白为什么我姐姐告诉我不要拆散这个家庭。
[cpg]


我姐姐告诉我的话在我脑中回荡。
[cpg]


;//ブラックアウト


[window target=false]

[STOPBGM]

[BG f="b_04_3_up.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa135"]
[OnName num="sawa"]
'欢迎回来。你怎么样，已经很辛苦了吗？
[cpg cn=true]


这已经很困难了。我当时没有状态去撒谎。
[cpg]


[OnName num="gorou"]
'...... 是的。我想和我妈妈在一起。好吗？"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa136"]
[OnName num="sawa"]
'当然了。我已经决定我要做晚上的--'
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



然后我被带到了我妈妈的房间。
[cpg]


只要来到这里，就觉得是一种解脱.......
[cpg]


;//========================================
;//●ＣＧ（寝ているヒロインに迫る主人公。抱きしめ合う感じ）ev_37
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================


[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h2"]
;**【ＣＧ】 ev_37_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSawa040"]
[OnName num="sawa"]
'来吧，我给你一个拥抱。
[cpg cn=true]


当我看到妈妈张开双臂时，我都快哭了。
[cpg]


我想告诉她我现在的一切感受。
[cpg]


但我不能说出来，我还是觉得自己要哭了。
[cpg]


我不知道该怎么做。我甚至不知道我是否应该通过这种爱。
[cpg]


在我看来，我爱我的母亲是毫无疑问的。
[cpg]


而且更重要的是，我不想惹恼我的母亲。
[cpg]


[OnName num="gorou"]
...... 我仍然爱我的母亲。
[cpg cn=true]


这句话的声音很小，连我都感到惊讶。我知道我不应该说这么多。
[cpg]


如果我在这里说，我想做你的女朋友，那就完了。
[cpg]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa041"]
[OnName num="sawa"]
'对。我知道。你不必什么都说'。
[cpg cn=true]


我不是想让你说出所有的事情。这将有助于我。
[cpg]


[OnName num="gorou"]
'...... 是的。
[cpg cn=true]


[VOICE f="sSawa042"]
[OnName num="sawa"]
'你今天一定很痛苦。破坏它也没关系'。
[cpg cn=true]


我认为有些话，如果你说出来，你就不能收回。如果我母亲能让他们闭嘴，那将是相当有帮助的。
[cpg]


我没有说什么，就拥抱了她。
[cpg]


[OnName num="gorou"]
'你闻起来像我母亲。
[cpg cn=true]


她并不讳言这一点。她肯定与她的姐姐和绯红不同。
[cpg]


妈妈认为我不会再靠近了。
[cpg]


;**【ＣＧ】 ev_37_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa043"]
[OnName num="sawa"]
'好吧，...... 吾郎将永远是一个被宠坏的孩子。
[cpg cn=true]


这个温柔的声音使我无法压制我一直在假装的东西，我一直在忍耐的东西。
[cpg]


我想让你成为我的全部。说这一个字很容易。
[cpg]


但......，我不知道我是否真的能做到这一点。
[cpg]


不仅我不知道，而且连她也可能不知道。
[cpg]


如果是这样，我说的话就会无从谈起。
[cpg]


[VOICE f="sSawa044"]
[OnName num="sawa"]
'怎么了？　你看起来像要哭了。"
[cpg cn=true]


她现在不是我唯一的妈妈。我不禁想到了这一点。
[cpg]


她看起来也像是要哭了。我真的喜欢上了我的妈妈。
[cpg]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa045"]
[OnName num="sawa"]
'我想知道她是否有什么可悲之处，而不仅仅是痛苦。
[cpg cn=true]


这不是悲伤，是难过。目前的这种情况是可悲的。
[cpg]


这不再是好事，我知道，这就是为什么我不能停止。
[cpg]


[OnName num="gorou"]
'妈妈，......，我已经下定决心了。
[cpg cn=true]


妈妈看起来有点担心。
[cpg]


也许她以某种方式知道她将被告知什么。
[cpg]


;**【ＣＧ】 ev_37_b ***********************
[CG id=17 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa046"]
[OnName num="sawa"]
'决定了什么？
[cpg cn=true]


[OnName num="gorou"]
'你知道他们是怎么说我的，如果我不谈恋爱，我的体质就不会安定下来。
[cpg cn=true]


妈妈显然知道一切。尽管如此，她只是带着相貌听我说话。
[cpg]


[VOICE f="sSawa047"]
[OnName num="sawa"]
'是的。怎么了？"
[cpg cn=true]


一旦我说出这句话，就没有回头路可走了。这是我经常思考的问题。
[cpg]


[OnName num="gorou"]
'我喜欢......，你的母亲。
[cpg cn=true]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa048"]
[OnName num="sawa"]
'是的。我知道。"
[cpg cn=true]


[OnName num="gorou"]
'不，不。你的母亲还不明白'。
[cpg cn=true]


[OnName num="gorou"]
当我说我爱你时，我是指爱。"
[cpg cn=true]


;//移植前シーンカット

;//ブラックアウト



我终于说出来了。喜欢 "这个词与 "爱 "这个词有不同的含义。
[cpg]


短暂的沉默。然后妈妈反问道。
[cpg]


;**【ＣＧ】 ev_37_b ***********************
[CG id=17 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sawa153"]
[OnName num="sawa"]
'你是认真的吗？　你知道这意味着什么。"
[cpg cn=true]


我想我知道。我想我知道。......
[cpg]


[VOICE f="Sawa154"]
[OnName num="sawa"]
'也许我们会被分开。你准备好了吗？"
[cpg cn=true]


对。这是可能摧毁家庭的事情。
[cpg]


你的妹妹会怎么想？而且，即使绯红不觉得有什么，最大的问题是爸爸。
[cpg]


我又得迷路了。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



爸爸通常会回家吃饭。
[cpg]


[OnName num="father"]
'铃音。这些天的工作怎么样？"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune328"]
[OnName num="suzune"]
嗯，......，还有很多地方我不够强壮。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari322"]
[OnName num="himari"]
'你作为一个姐妹，力量并不弱。我有点不适应'。
[cpg cn=true]


他们正在谈论这个问题。正常的、亲子的对话。
[cpg]


但我......，感觉有点被疏远。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



之后，我邀请绯红和她的妹妹到我的房间。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari323"]
[OnName num="himari"]
'...... 怎么了？　你的脸上有一种神秘的表情'。
[cpg cn=true]


[OnName num="gorou"]
是的，好的。......
[cpg cn=true]


我不知道该如何谈及这个话题，这时绯红说。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Himari324"]
[OnName num="himari"]
'你是在说你的母亲吗？　可能，是的。"
[cpg cn=true]


[OnName num="gorou"]
'......，你完全知道我的意思。你仍然不是绯红的对手'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune329"]
[OnName num="suzune"]
'你是什么意思？　我对事情的发展不满意。"
[cpg cn=true]


[OnName num="gorou"]
我仍然想治愈这种体质。为此，我希望能像我的母亲一样。"
[cpg cn=true]


这位典型的姐姐退缩了。她就是那个曾经钉死我的人。
[cpg]


但绯红是个酒鬼。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari325"]
[OnName num="himari"]
'不知怎的，我知道这将会发生。是的，我知道。
[cpg cn=true]


她仍然感到困惑。但我一直在说话。
[cpg]


[OnName num="gorou"]
'我很抱歉，姐姐，......，我为绯红和你姐姐为我做的事感到高兴，但这并不能解决什么。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune330"]
[OnName num="suzune"]
'...... 是的。原来如此。......"
[cpg cn=true]


他们会接受吗？你仍然觉得你没有完全理解它。......
[cpg]


但这是你必须花时间去了解的事情。
[cpg]


毕竟，她是她姐姐和绯红的真正母亲。
[cpg]


这是一种相当复杂的关系，但我已经爱上了我的妈妈。我再也忍不住了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト








到了晚上，我妹妹被说服了。
[cpg]


最后，她似乎支持我。
[cpg]

[BG f="b_06_4.ui" time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]

[WAIT time=2000]

[VOICE f="Suzune331"]
[OnName num="suzune"]
'不要太鲁莽，.......我现在真的很关心我的家人"。
[cpg cn=true]


想了想后，他们各自回到自己的房间睡觉去了。
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[OnName num="gorou"]
'...... 哦，那个？　妈妈。"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa049"]
[OnName num="sawa"]
'绯红告诉我。她说我应该是早上给你一个刺激的人。
[cpg cn=true]


[OnName num="gorou"]
'嗯，是的，......，我为你感到高兴，但是，呃...'
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSawa050"]
[OnName num="sawa"]
我们会想念学校的。
[cpg cn=true]


当我陷入沉思时，我的母亲走近了。
[cpg]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト
;//移植前シーンカット

[window target=true]


她只是抚摸着我的头，拥抱着我。她没有吻我。
[cpg]


尽管如此，我还是足够兴奋。因为她是我最喜欢的人。
[cpg]



[window target=false]


[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************


然后我不得不马上离开家，所以我跳过了早餐。
[cpg]


[OnName num="gorou"]
'好吧，那我就走了。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa174"]
[OnName num="sawa"]
'祝你有个愉快的一天。晚上也要向......'打招呼。
[cpg cn=true]


这是我的台词，不过。考虑到这一点，我离开了家。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_01_1.ui" time=1000]
[WAIT time=1000]


一路走到学院。没有什么特别的，只是一个普通的日子。
[cpg]


但我不得不考虑一些事情。
[cpg]


我可能会破坏我的家庭。无论我是否准备这样做。
[cpg]


也许有办法可以防止这种情况发生。但也有突发事件。
[cpg]


我得想，这不是好事。我不能呆在这个宪法里。
[cpg]




[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune332"]
[OnName num="suzune"]
'...... 不可能是我吗？
[cpg cn=true]

;//＠昼に空き教室で抜いてもらってから、姉さんにそう言われた。


[OnName num="gorou"]
不是说我不能，更像是......，你必须是我的母亲。"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Suzune333"]
[OnName num="suzune"]
如果我告诉你，我也喜欢你呢？
[cpg cn=true]


[OnName num="gorou"]
......"
[cpg cn=true]


他的脸上带着严肃的表情。他是认真的吗？或者是......
[cpg]


他是否为了保护他的家人而强迫自己这么说？我无法决定。
[cpg]


[OnName num="gorou"]
'我还是不行。我爱我的母亲 .......'
[cpg cn=true]

敢于使用强烈的语言。她看起来很懊恼。
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune334"]
[OnName num="suzune"]
'我看......，我不能阻止你，是吗？
[cpg cn=true]


她说她会支持我，但我认为她心中仍有一些犹豫。
[cpg]


这并不难理解她的感受。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************


我也仍然迷茫。我经常怀疑我做的事情是否正确。
[cpg]


我们之间存在着明显的年龄差异，这一点我不必再考虑了。
[cpg]


更重要的是，她是养育我的人。
[cpg]


而且我爸爸也是父母，尽管对我来说是继父母。......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_04_3.ui" time=1000]
[WAIT time=1000]


我可能正在犯一个可怕的错误。我认为这一点。
[cpg]


但我的母亲轻轻地把我包了起来。
[cpg]


;//移植前シーンカット

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa051"]
[OnName num="sawa"]
'欢迎回来，戈罗。你还在痛苦中，是吗？"
[cpg cn=true]



[OnName num="gorou"]
是的。......
[cpg cn=true]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


我还在向我父亲隐瞒。我知道我不能把它永远藏起来。
[cpg]


我姐姐和绯红也对此事保持沉默，但我想它不能永远这样下去。......
[cpg]


[window target=false]


[STOPBGM]

[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


全家一起吃过晚饭后，我回到了自己的房间。
[cpg]


这时我把我的母亲带过来和她谈。......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa052"]
[OnName num="sawa"]
'我想知道。你痛苦是因为你想再捣鼓一下吗？
[cpg cn=true]


妈妈甚至似乎在淡化它。
[cpg]


我，我觉得我看起来很严肃。我想知道它是否已经完成？
[cpg]


[OnName num="gorou"]
'我仍然爱你，妈妈。爱你还不够'。
[cpg cn=true]


尽可能的直接。就像你不关心你的长相一样。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sawa193"]
[OnName num="sawa"]
'不要.......如果你的父亲发现了怎么办？"
[cpg cn=true]


[OnName num="gorou"]
'我会确保他们不会发现的。我保证。"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sawa194"]
[OnName num="sawa"]
'是的。......，我知道。五郎是认真的，不是吗？"
[cpg cn=true]


妈妈的反应是，她好像明白了什么。
[cpg]


她接着说。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa195"]
[OnName num="sawa"]
'你是认真的，对吗？　我们不能结婚，无论如何都不能。"
[cpg cn=true]



[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSawa053"]
[OnName num="sawa"]
'我想你，而不是我，会被你的感情所约束。你还是可以接受的，不是吗？
[cpg cn=true]


我点了点头。我已经受够了那方面的冲突。
[cpg]


然后我的母亲看起来有点烦恼，说。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSawa054"]
[OnName num="sawa"]
'好吧。
[cpg cn=true]


;//ブラックアウト

我妈妈认为她也喜欢我。我仍然不知道这是否是一种浪漫的感觉。
[cpg]


但我对这一点没有意见。这不是我应该担心的事情。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSawa055"]
[OnName num="sawa"]
唯一的另一件事是，我不会以...... Goro而告终。
[cpg cn=true]


对。如果我连这个都接受，那将是一个好故事。
[cpg]


我很早就已经接受了这个事实。我已经知道这是禁忌之爱。
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





第二天早上。早上从绯红变成了我的母亲。
[cpg]


而对于我的母亲，我打算做一些与以前不同的事情。
[cpg]


我告诉她，我是说，......，我想吻她。
[cpg]


[OnName num="gorou"]
我是...... 紧张，我就知道。"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa199"]
[OnName num="sawa"]
'我可能比五郎更紧张。
[cpg cn=true]


母亲说这话时笑了。你看起来并不紧张。
[cpg]



;//移植前シーンカット

;//ブラックアウト

[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

我们变得更接近一点。距离消失了。
[cpg]


我们的嘴唇互相接触。初吻的感觉被不道德所覆盖。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『街』（昼）******************************************************



时间过去了。所有的时间，只要有可能，我都和我的母亲在一起。
[cpg]



[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d2"]

;//【ＢＧ】『街』（夜）******************************************************


而......，这是值得的，我的体质逐渐平静了下来。
[cpg]


;//ブラックアウト

[window target=false]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


我深信不疑。我不能以任何方式结婚。
[cpg]


我们甚至不能像正常的恋人那样行事。但这也没关系。
[cpg]


我们只是秘密地爱着对方，不管我们走多远。
[cpg]


而对我母亲来说，最重要的人必然是我的父亲。
[cpg]


当我看到我的母亲若无其事地微笑时，我就是这么想的。
[cpg]


这是一种无论如何都不会有结果的爱。但我认为它已经走到了尽头。
[cpg]


;//ブラックアウト


[window target=false]


[STOPBGM]

[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


随着时间的推移，我的情况继续得到改善。
[cpg]


我不必再去医院了。
[cpg]


但你可以说，问题是从这里开始的。
[cpg]


我想我和我母亲之间的爱必须继续下去。否则，我的体质可能会回来。
[cpg]


然后我将永远这样，直到我爱上别人。
[cpg]


我也没有想到我现在会爱上别的人。
[cpg]


换句话说，结果就像我的...... 母亲说的那样，我将把自己绑在自己身上。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』

[WAIT time=1500]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa217"]
[OnName num="sawa"]
'五郎。我可以和你说句话吗 - ......."
[cpg cn=true]


[OnName num="gorou"]
'怎么了？　你想我了吗？"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa056"]
[OnName num="sawa"]
'嗯。你得说出来'。
[cpg cn=true]


尽管我的体质已经平静下来，不需要再紧张了，但我的母亲宁可尝试触摸我。
[cpg]


这是我的错。我无法拒绝，所以我服从了。
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植前シーンカット

当我和母亲在一起时，仅这一点就让我感到安全。
[cpg]


在这个意义上，我也不能说不。
[cpg]


;//ブラックアウト


[window target=false]


[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="gorou"]
我不会对她说不的。...... 我们不能明天改天再谈这个问题吗？　如果你呆得太晚，人们可能会认为你很奇怪。"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa235"]
[OnName num="sawa"]
'是的，但...... 好。我会耐心等待。"
[cpg cn=true]


妈妈说这话时似乎真的很喜欢我。
[cpg]


我是如此尴尬、高兴和...... 歉意，以至于我无法直视她。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



[OnName num="gorou"]
'好吧，那我就走了。
[cpg cn=true]


我和绯红一起离开家，向母亲问好。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari327"]
[OnName num="himari"]
'...... 嘿，大哥哥。我和我哥哥的关系会发生什么变化？"
[cpg cn=true]


[OnName num="gorou"]
你说的'会发生什么'是什么意思......？"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari094"]
[OnName num="himari"]
'你将成为你母亲喜欢的人。我应该叫你爸爸吗？
[cpg cn=true]


我认为他是在开玩笑。这似乎是无辜的绯红。
[cpg]



[OnName num="gorou"]
'Ze，绝对不要这样叫我......'。
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『歩く』



在这样的谈话之后，我们在城市中漫步。
[cpg]


我们前往学院。我不必再要求我的姐姐为我做任何事情。
[cpg]




[window target=false]


[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="male_student"]
'哦，不，我前几天终于吻了她。
[cpg cn=true]


[OnName num="gorou"]
'...... 是的。
[cpg cn=true]


他就是那个很久以前为有女朋友而大惊小怪的人。
[cpg]


我想，我妹妹会叫我爸爸或什么的，我很不能这么说。
[cpg]




[window target=false]


[STOPBGM]

[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（夕方）******************************************************


还有一次。我是被一个与我没有特别关系的女学生叫来的。
[cpg]



[OnName num="female_student"]
'...... 小坂君，你有女朋友吗？
[cpg cn=true]


[OnName num="gorou"]
'为什么不呢？　她是...... 嗯，......"
[cpg cn=true]


一个可能对我有好感的女孩。当然，我都是为了我的妈妈。
[cpg]


但我甚至不能说我有一个女朋友。而且她不是我的妻子。
[cpg]


[OnName num="gorou"]
我不知道是否有我喜欢的人......."
[cpg cn=true]


[OnName num="female_student"]
'我明白了。对'。
[cpg cn=true]


最后的措辞是这样的。我不知道，也许我可以和她约会。
[cpg]


但我所拥有的是我的母亲。我选择了她，而不是我姐姐或绯红。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『歩く』



我们又步行回家，一吃完晚饭，就到了晚上。
[cpg]


我这样说听起来很无味，但有一件事已经改变了很多。
[cpg]



[window target=false]


[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


那就是我母亲在晚上来找我。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSawa057"]
[OnName num="sawa"]
...... Goro。"
[cpg cn=true]


他们叫我的方式和以前一样，但我还是很高兴。
[cpg]


我想更多地靠近你。这就是我的想法。
[cpg]


;//＠それから何度か交わった後、俺達は別れた。



然后每个早晨都会到来。
[cpg]


[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我确信，你是唯一能在我身边的人。我想知道我母亲的情况。
[cpg]


我不知道我母亲的情况，但我不知道我是否爱上了我父亲。
[cpg]


但这是一种无法以任何方式实现的爱。我们不可能成为恋人。......
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）

[BG f="b_01_1.ui" time=1000]
[WAIT time=1000]

我吃完早餐，走出前门。向向日葵的相反方向前进。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari329"]
[OnName num="himari"]
'回头见，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'哦。到时见'。
[cpg cn=true]

[free time=1000]

;//【ＢＧ】『街』（朝）


我在一种昏迷中度过了我的日子。
[cpg]


不是女朋友或情人，但绝对是我爱的人。
[cpg]


这是最幸福但不寻常的幸福。
[cpg]



[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_02_1.ui" time=1000]

[WAIT time=2000]

[BG f="b_02_2.ui" time=1000]

[WAIT time=2000]


[BGM f="bg_d2"]
[BG f="b_02_3.ui" time=1000]

[WAIT time=1000]


然后我去了学院，上课，放学。
[cpg]

;//【ＢＧ】『学園教室』（夕方）


[OnName num="female_student"]
'...... 小坂君。哦，你知道，......."
[cpg cn=true]


[OnName num="gorou"]
...... 什么？"
[cpg cn=true]


有一天的女学生。是她问我是否喜欢某人。
[cpg]


[OnName num="female_student"]
'我喜欢小坂君。那......，你想和我出去吗？
[cpg cn=true]


我遇到了麻烦。也许我可以在这里转移到一个体面的生活。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



最后，我带着待定的答案离开了。
[cpg]


我不能马上给你一个答案。我不能和她出去，直到我和我妈妈的关系结束。
[cpg]


考虑到这一点，我走回了我的房子。......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="gorou"]
'......，这就是所发生的事情。妈妈。"
[cpg cn=true]


我按照学院的情况讲述了这个故事。然后妈妈说。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa252"]
[OnName num="sawa"]
'你可以和他们一起出去，不是吗？　我不会阻止你。"
[cpg cn=true]


[OnName num="gorou"]
为什么......，我喜欢你？"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa253"]
[OnName num="sawa"]
'我很清楚这一点。但你甚至不能让我在你的余生中做你的女朋友'。
[cpg cn=true]


...... 这可能确实是事实。
[cpg]


我不知道如果发生这种情况，我爸爸会怎么样。
[cpg]


妈妈也可以爱爸爸。
[cpg]


[OnName num="gorou"]
'...... 了解。我会考虑的。"
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************


然后我忍住不回应那个在学校向我表白的女孩。
[cpg]


我们继续保持着不太相爱的关系，开始是朋友。
[cpg]


她似乎真的很喜欢我，而且似乎觉得这很令人沮丧。
[cpg]


但我就是我，我从未失去对我母亲的爱。
[cpg]


我不觉得我可以适当地爱这个刚刚向我表白的女孩。
[cpg]



;//ブラックアウト



;//========================================
;//●ＣＧ（主人公に膝枕するヒロイン）ev_44
;//人物１：ヒロイン３
;//服装１：私服
;//場所　：主人公の家＿リビング
;//時間　：昼
;//備考　：妊娠していない状態に変えてください
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』


[BGM f="bg_h1"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]



尽管这些暧昧的日子，我还是很开心。
[cpg]


无论我过什么样的生活，我的母亲都会支持我。
[cpg]


我觉得这就是我需要的一切。我很有成就感。
[cpg]


[VOICE f="sSawa058"]
[OnName num="sawa"]
'...... 你后悔吗？　五郎。"
[cpg cn=true]


但他看起来肯定只是有点失落。妈妈开始担心了。
[cpg]


[OnName num="gorou"]
'不可能。不可能的'。
[cpg cn=true]


这些话自然而然就说出来了。我想这是因为我是真心的。
[cpg]


这不仅仅是一个口号。我完全没有遗憾。
[cpg]


;**【ＣＧ】 ev_44_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa059"]
[OnName num="sawa"]
'我很好，我不在乎我和谁相爱。你喜欢我安抚你的体质，这才是最重要的。
[cpg cn=true]


他说了一句话，让我有点难过。他说他现在不能回去了。
[cpg]


[OnName num="gorou"]
'那是不可能的事。我真的爱上了你，我的体质已经稳定下来了'。
[cpg cn=true]


相反，我的体质已经稳定下来的事实证明，我喜欢我的母亲。
[cpg]


在确定爸爸、姐姐和绯红已经离开后，我说。
[cpg]


[OnName num="gorou"]
'我爱你，.......苏纳赫恩"。
[cpg cn=true]


我突然叫她的名字，但我母亲不会感到沮丧。
[cpg]


;//;**【ＣＧ】 ev_44_b ***********************
;//[CG id=18 index=2 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="sSawa060"]
[OnName num="sawa"]
'是的。我也是'。
[cpg cn=true]


我喜欢这种关系。我想一直呆在她身边。
[cpg]



;//ブラックアウト

我希望它能永远继续下去，但我不知道这是否会发生。
[cpg]


也许我的立场会随着时间的推移而改变，当我工作的时候，我就会想建立一个家庭。
[cpg]


但......，目前还是不错的。因为我想继续做我母亲的孩子。
[cpg]


[SCENE id=11]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン３ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================

*start


;###################################################################
*Ep008|快乐的优柔寡断。
;###################################################################

;//４、選ぶことができない

*select04_4|快乐优柔寡断

[SCENE id=8]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


...... 号。我还是无法选择。
[cpg]


这不是一个容易做出的决定，即使有人告诉你需要恋爱。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="gorou"]
'对不起，我还是......无法选择。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[VOICE f="Suzune337"]
[OnName num="suzune"]
五郎......"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari331"]
[OnName num="himari"]
'大哥......'
[cpg cn=true]


我很迷茫，无法选择任何人。
[cpg]


然后我告诉他们，我不能选择反对他们三个人。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa273"]
[OnName num="sawa"]
'我知道五郎的想法。那么你就不必选择了'。
[cpg cn=true]


[OnName num="gorou"]
嗯？"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari095"]
[OnName num="himari"]
'换句话说，我还是要和我们三个人一起捣鼓你，兄弟，就像我们一直以来一样。
[cpg cn=true]


不，但这不是...
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/3" time=800]
[VOICE f="Suzune338"]
[OnName num="suzune"]
'没关系的。这是我们已经讨论过并决定的事情'。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="3/3" time=800]
[VOICE f="sSawa061"]
[OnName num="sawa"]
'如果他们说坠入爱河可以治愈你的体质，那么人越多越好。
[cpg cn=true]


嗯，这当然是......？　它是否能使治愈的机会增加三倍？
[cpg]


[OnName num="gorou"]
'......'
[cpg cn=true]


即使是这样，我是否可以这样利用一个对我这么好的家庭成员？
[cpg]


但我仍然担心......，我的呼吸会出现问题。
[cpg]


[OnName num="gorou"]
'......，谢谢你，请。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="Suzune339"]
[OnName num="suzune"]
为了五郎的缘故，我会......尽我所能。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari333"]
[OnName num="himari"]
我让你去吧。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa275"]
[OnName num="sawa"]
'你会把你的母亲宠坏的。
[cpg cn=true]


虽然不解，但她还是决定服从，认为如果他们三个人这么说，那就这么办吧。
[cpg]





;//ブラックアウト

[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]


这事发生几天后。
[cpg]


他们三个人仍然像往常一样对我来者不拒。当然，他们还没有吻过我。......
[cpg]


但这一天终于到来，他越过了治愈这种疾病的界限。
[cpg]


[window target=false]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





我醒来的时候，我妹妹已经和我一起爬到了床上。
[cpg]


[OnName num="gorou"]
'嗯...'
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari334"]
[OnName num="himari"]
'哦，我起来了。早上好，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'是的......早上好。你为什么这么近？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari096"]
[OnName num="himari"]
为什么，当然是为了吻我。
[cpg cn=true]


[OnName num="gorou"]
转到.......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari336"]
[OnName num="himari"]
'否则你将永远无法恢复。你确定你想保持这种方式吗？"
[cpg cn=true]


[OnName num="gorou"]
我不......，认为这是个好主意。
[cpg cn=true]


以这种方式被大家激动，是一种福利，也可能是一种美味的环境。
[cpg]


但这种使生活受到更多限制的体质，仍然必须得到治愈。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari097"]
[OnName num="himari"]
'那好吧，让我们接吻吧。如果是和我哥哥......好吧。"
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


然后她把她的嘴唇送到他的面前。
[cpg]


我甚至还没有刷牙，......，想着我现在不应该想的事情。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_h1"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


绯红拉开她的嘴唇，看起来很高兴。当她做出这样的表情时，敲击声就会越来越强。
[cpg]



[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari098"]
[OnName num="himari"]
'这对你来说还不够，是吗？　我还是会让你悸动的。"
[cpg cn=true]


[OnName num="gorou"]
'什么，你还打算这么做？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari099"]
[OnName num="himari"]
'我不在乎你做了多少次。我必须通过做爱来治疗我的体质'。
[cpg cn=true]


[OnName num="gorou"]
'但是，这是否可以......'
[cpg cn=true]




[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari100"]
[OnName num="himari"]
'好。你关心什么呢？
[cpg cn=true]


[OnName num="gorou"]
因为我不认为你在单挑我们。"
[cpg cn=true]


我想当时有一个规则，就是每个人都是平等的。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari363"]
[OnName num="himari"]
'现在是我负责的时间，所以很好。也许你们两个也会这样做......'
[cpg cn=true]


她是一个非常有活力的妹妹。我想我妹妹会有所保留，更不用说我母亲了。
[cpg]


即使有这样的想法，我们最终还是在一起度过了整个时间......。
[cpg]



[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[window target=true]


然后就到了交接的时候。
[cpg]


严格说来不是从这里出发，但......，我姐姐来拉我。
[cpg]

[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune077"]
[OnName num="suzune"]
'...... a bit.你要和我坚持多久，绯红？"
[cpg cn=true]


姐姐似乎有点生气，因为希卡里在午餐后留下来陪她。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari101"]
[OnName num="himari"]
'哦...姐姐'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune341"]
[OnName num="suzune"]
'是时候走了。来吧，走吧。"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari365"]
[OnName num="himari"]
啧啧。"
[cpg cn=true]

[free time=1000]

绯红不情愿地离开了房间。这不像绯红会马上听我的话，但我猜她觉得我独占她这么久很不好。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune342"]
[OnName num="suzune"]
你......你没事吧？ 一点也不，緋紅。
[cpg cn=true]


[OnName num="gorou"]
'嗯，是的......有点过于紧张和疲惫，但是......'
[cpg cn=true]


我的妹妹似乎对我说的话有点不以为然。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune343"]
[OnName num="suzune"]
'...... 你想做什么？我不知道如果我不这样做是否更好......'
[cpg cn=true]


[OnName num="gorou"]
'不，我很好。我不能让你和其他人单独在一起'。
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune344"]
[OnName num="suzune"]
'谢谢你，戈罗。我很高兴。但是......不要做一个假正经的人。"
[cpg cn=true]


[OnName num="gorou"]
我们会好好照顾它。"
[cpg cn=true]


这次是和你妹妹一起。不无节制可能是很难做到的。
[cpg]


我们不得不转移到另一个地方，前往我姐姐的房间。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

;//移植前シーンカット

她没有吻我，但我觉得她很清楚该怎么做才能让我紧张。
[cpg]


她能看出我很喜欢她，即使我们没有紧紧抓住对方。
[cpg]



;//ブラックアウト

[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



而更多的时间过去了，然后......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa276"]
[OnName num="sawa"]
'五郎。现在轮到你母亲了！"
[cpg cn=true]


[OnName num="gorou"]
'嗯...让我休息一下...'
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa277"]
[OnName num="sawa"]
'嗯，嗯。Dahme♪''
[cpg cn=true]


[OnName num="gorou"]
是的，先生。
[cpg cn=true]


我们又搬了房间，这次是和我母亲一起。
[cpg]


我认为我的房间对她来说不够好，但她不愿意。
[cpg]


也许有一些本能的东西.......，不，如果不是这样就太不礼貌了。
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_04_2_up.ui" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[WAIT time=2000]

;//移植前シーンカット

我妈妈可能是我们三个人中最不宽容的。
[cpg]


你可以说她最担心的是我。如果我不扑腾，我就很难呼吸了。
[cpg]


上午是绯红，下午是我妹妹，晚上是我母亲。他们每个人都有自己的捣蛋时间。
[cpg]


这是那种可以被描述为男人最好的一天。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



当我继续这样的粗暴对待时，我的体质就稳定下来了。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="sHimari102"]
[OnName num="himari"]
'这很奇怪!当你坠入爱河时，你真的被治愈了。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSuzune078"]
[OnName num="suzune"]
'......，就我而言，我想知道你爱上的是谁。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]

[VOICE f="sSawa062"]
[OnName num="sawa"]
'他们是谁并不重要。这是每个人的Goro'。
[cpg cn=true]


我母亲说了一句话，有点棘手。不，当你说出来的时候，你也说出来了，姐姐。
[cpg]


我自己也不知道我们三个人都爱上了谁。
[cpg]


但现在真的没有回头路了。
[cpg]


我的体质已经稳定下来了，这意味着证明我爱上了他们三个中的一个。
[cpg]



;//ブラックアウト

;//移植前シーンカット

我希望我有足够的资格在这里说我爱谁。
[cpg]


不幸的是，我是那个在关键时刻无法选人的人。
[cpg]


我相信在......，每个人都觉得这很令人沮丧。但我同样喜欢他们。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************

;//ブラックアウト

[OnName num="father"]
'不知为什么，你们这些天相处得非常好。
[cpg cn=true]


而我父亲，正如预期的那样，说了一些话，让我意识到他已经注意到了。
[cpg]


也许我更早地注意到它。只是他现在说出来了。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="sSuzune079"]
[OnName num="suzune"]
'什么？　不，不，这不是......"
[cpg cn=true]


我妹妹对我爸爸的行为很可疑。尽管他们是家人。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari103"]
[OnName num="himari"]
'这就对了!我们一直都很亲密，不是吗？
[cpg cn=true]


[OnName num="father"]
你有吗？"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSawa063"]
[OnName num="sawa"]
'是的，没错。他正处于想要被宠爱的年龄，我打赌。
[cpg cn=true]


[OnName num="father"]
'......，我明白了。
[cpg cn=true]


爸爸看起来有点复杂。
[cpg]


当然，我不会在他面前无谓地调情。姐姐。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari104"]
[OnName num="himari"]
'爸爸，你不能吃醋。你只属于我，大哥哥。
[cpg cn=true]


然而，绯红并不害怕在爸爸面前坚持下去。
[cpg]


看到我妹妹痛苦的脸，我也很难受。......
[cpg]

;//移植前シーンカット


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『街』（昼）******************************************************


最后，我们三个人，每个人都保持同样的距离。
[cpg]


或者也许我只是没有注意到，因为我离他们所有人都很近。
[cpg]


周末来了又走，不知道这种关系是否好。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]


[VOICE f="sHimari105"]
[OnName num="himari"]
'我们四个人已经很久没有一起出去了。
[cpg cn=true]


我们出来的时候，只有爸爸有差事要做。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="sSawa064"]
[OnName num="sawa"]
'是的，我想是的。我想特别是铃音可能会有点害羞'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune080"]
[OnName num="suzune"]
'......，现在没有什么可害羞的了。
[cpg cn=true]


这当然是真的。如果我要害羞，那就应该在更早的时候。......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="sHimari106"]
[OnName num="himari"]
'那么，我们应该去哪里？　你有一个约会计划吗，妈妈？"
[cpg cn=true]


向母亲要一个约会计划，听起来......，很奇怪，但这并没有错。
[cpg]


;//背景と違う場所です。上下に黒帯を入れるなどの演出を入れてください

[FACE method="feadin" pos="4/7"]
[BG f="b_01_2_up.ui" time=1000]
[WAIT time=1000]


我们要去商场。我记得小时候经常去那里。
[cpg]


当然，我现在已经不好意思和他们出去了。
[cpg]


在这种情况下再次外出，对我来说是一种非常感性的体验。
[cpg]


就像他们三个人认出了我的奇怪体质。......
[cpg]


更重要的是，我觉得他们接受了我的感受。
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="sSawa065"]
[OnName num="sawa"]
'你已经改变了很多。所有的服装店'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSuzune081"]
[OnName num="suzune"]
'嗯，......，也许这就是它的方式。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]

[VOICE f="sHimari107"]
[OnName num="himari"]
'你真的想买那么多衣服吗？　不过我更想吃一顿好的。"
[cpg cn=true]


[OnName num="gorou"]
对了，我想我们是时候吃晚饭了。"
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]

[VOICE f="sSuzune082"]
[OnName num="suzune"]
我很惊讶你能负责。
[cpg cn=true]


[OnName num="gorou"]
不，不，我不认为我是负责人。
[cpg cn=true]


我们的谈话多么精彩，我们多么享受我们在一起的时光。
[cpg]


这样一来，我们仍然觉得自己是家人而不是恋人。
[cpg]


这就像我们仍然是一个家庭，但我们变得更亲密了。......
[cpg]


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="sHimari108"]
[OnName num="himari"]
这很有趣。我哥哥给我买了衣服。"
[cpg cn=true]


[OnName num="gorou"]
'你告诉我你想做的就是买衣服。......
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari109"]
[OnName num="himari"]
'没事的，没事的。不要把我说的话看得那么严重'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSuzune083"]
[OnName num="suzune"]
'它必须是......
[cpg cn=true]


我母亲看着我们的谈话，微笑着。
[cpg]


回想起来，也许这就是我一直想要的东西。
[cpg]


我在一次事故中失去了父母后，我希望得到家庭的温暖。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="sSawa066"]
[OnName num="sawa"]
你玩得开心吗，戈罗？
[cpg cn=true]


[OnName num="gorou"]
是的。当然，这是一个很大的乐趣。"
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]


...... 我最喜欢这种时间。我相信这比我和我女朋友在一起的时间要多。......
[cpg]


我不想为了和任何一个人在一起而拆散家庭关系。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


随着我们家庭关系的增长，我感到很遗憾，这个人是一只蚊子。
[cpg]


[OnName num="father"]
'...... 什么？　你想和我谈谈。"
[cpg cn=true]


[OnName num="gorou"]
'不。只是我们今天自己出去了'。
[cpg cn=true]


[OnName num="father"]
'别担心。我知道你们两个相处得很好。"
[cpg cn=true]


可怜的是，我想，但......，还有一件事我在想。
[cpg]


[OnName num="gorou"]
'谢谢你.......因为接受我进入这个家。"
[cpg cn=true]


[OnName num="father"]
'什么？　出乎意料。"
[cpg cn=true]


[OnName num="gorou"]
'不，不。我只是觉得我没有说太多。"
[cpg cn=true]


[OnName num="father"]
'这正是你需要担心的事情。我不能丢下你一个人。
[cpg cn=true]


爸爸看起来很尴尬。
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSawa067"]
[OnName num="sawa"]
怎么了？"　听起来你们两个已经有了很多的对话。"
[cpg cn=true]


[OnName num="gorou"]
'是的。我只是很高兴能在这个房子里。"
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sSawa068"]
[OnName num="sawa"]
'嗯。不寻常。"
[cpg cn=true]


不寻常的。我确实没有对你说过这些话。
[cpg]


[OnName num="gorou"]
我为我的不孝感到抱歉。
[cpg cn=true]


[OnName num="father"]
'别担心。你还没有大到可以担心这种事情的地步'。
[cpg cn=true]


爸爸重复着'不要担心'这句话。我对此表示感谢。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]


我欠我父亲一个人情。我的姐姐、绯红，甚至我的母亲都让我感到紧张。
[cpg]


我知道他没有告诉我也不要担心这个问题，......，但这仍然让我感觉好些。
[cpg]


[window target=false]


[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

吃完晚饭后，在我的房间里休息，绯红过来了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari110"]
[OnName num="himari"]
'嘿，你确定你不打算选人吗？
[cpg cn=true]


[OnName num="gorou"]
是的，从那时起我就一直在思考这个问题。......"
[cpg cn=true]


[OnName num="gorou"]
'不是说我同样喜欢他们，更多的是我不能只选其中一个的原因。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sHimari111"]
[OnName num="himari"]
你是什么意思？"
[cpg cn=true]


[OnName num="gorou"]
我......，喜欢这个房子。
[cpg cn=true]


[OnName num="gorou"]
'我现在不想毁掉这段关系。在今天发生的事情之后，我深深感受到了这一点'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari112"]
[OnName num="himari"]
'...... 这对你姐姐来说可能是一件很难说出口的事情，不是吗？　从我们的角度来看，你是孤独的。"
[cpg cn=true]


[OnName num="gorou"]
'...... 抱歉。
[cpg cn=true]


绯红似乎有点生气，但也很宽容。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari113"]
[OnName num="himari"]
'好吧，这不是我哥哥第一次优柔寡断了，所以我已经放弃了。
[cpg cn=true]


[OnName num="gorou"]
我非常抱歉。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari114"]
[OnName num="himari"]
'你不需要道歉。你已经下定决心。你那优柔寡断的弟弟'。
[cpg cn=true]


我有点抱歉，不能说什么。
[cpg]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]
;//【ＢＧ】『街』（朝）******************************************************

我的体质越来越平和了。我并不是爱上了任何一个人。
[cpg]


一切都在向好的方向发展，尽管就这段关系而言，没有任何改变。
[cpg]


...... 就在这时，事情发生了。
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『学園教室』（昼）******************************************************

[OnName num="gorou"]
'姐姐，怎么了？
[cpg cn=true]


我在一个空荡荡的教室里，我姐姐叫我进去。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune084"]
[OnName num="suzune"]
'...... 抱歉。我不是有意这么突然叫你出来的。
[cpg cn=true]


[OnName num="gorou"]
'这很好，但有些事情是不对的。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune085"]
[OnName num="suzune"]
这并不是说事情刚刚发生，更像是......，一直以来，都有事情发生。"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune086"]
[OnName num="suzune"]
'五郎。你喜欢我吗？"
[cpg cn=true]


[OnName num="gorou"]
'是的。我喜欢你。"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune087"]
[OnName num="suzune"]
'你不是最好的听众。你喜欢我这个恋人吗？
[cpg cn=true]


[OnName num="gorou"]
这是......，已经决定我不会选择其他人。"
[cpg cn=true]


我妹妹听到我的话后，显得很痛苦。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune088"]
[OnName num="suzune"]
'我非常喜欢你，我想做你的情人。
[cpg cn=true]


...... 我直到刚才才考虑到这种可能性。
[cpg]


这不是由我来选择其他人。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune089"]
[OnName num="suzune"]
与我们四个人在一起很有趣，但也可能很辛苦。"
[cpg cn=true]


显然，我姐姐很爱我。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune090"]
[OnName num="suzune"]
'我已经准备好成为你唯一的我。
[cpg cn=true]


我想让你成为我，只做你的妹妹 "这句话背后的意图隐藏在 "我想让你成为我，只做你的妹妹"。
[cpg]


[OnName num="gorou"]
'......'
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune091"]
[OnName num="suzune"]
'我不会对你隐瞒。我想和你结婚'。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune092"]
[OnName num="suzune"]
'如果你说你不会选择任何人，......，我想与你保持距离。当我们不能在一起时，我在你身边是很痛苦的。"
[cpg cn=true]


这是一个令人心痛的想法。我只想和我的家人在一起。
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『学園廊下』（夕方）******************************************************

[OnName num="male_student_A"]
'哦，不。职业道路"。
[cpg cn=true]


[OnName num="male_student_B"]
'你为什么会迷路呢？你说你想在毕业后马上找到一份工作'。
[cpg cn=true]


[OnName num="male_student_A"]
我在努力，但我的父母似乎不允许我这样做。
[cpg cn=true]


[OnName num="male_student_A"]
我和我的兄弟姐妹们也很挑剔。......。
[cpg cn=true]


[OnName num="male_student_B"]
'你必须做你自己。家庭，无论你多么关心他们，他们不可能永远留在你身边。
[cpg cn=true]


...... 在稍远的地方，可以听到两个互不相识的人之间的对话。
[cpg]


家庭不可能永远呆在一起。我想可能确实是这样的情况。
[cpg]


[window target=false]



[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************


要么你与你的妹妹有一种非家庭的关系，要么你与她这个家庭成员保持距离。它是一个还是另一个？
[cpg]


我想保持我们的关系是这样的。
[cpg]


[window target=false]

[STOPBGM]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


那天在餐桌上，我和姐姐之间的关系变得很尴尬。
[cpg]


当然，Himaru似乎已经注意到了什么，并且很担心。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sSawa069"]
[OnName num="sawa"]
'怎么了？　我不再吃了。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSuzune093"]
[OnName num="suzune"]
是的。......，我没有什么胃口。"
[cpg cn=true]


如何对待你的妹妹。我觉得我仍有一些事情需要告诉她。
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="gorou"]
'......，我知道这是唯一的办法。
[cpg cn=true]


思考。经过反复思考，我得出了一个结论。
[cpg]


我不会在我妹妹和绯红之间做出选择。我找到了继续我们目前关系的唯一方法。
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

第二天早上。在我离开之前，我给我姐姐打了电话。
[cpg]


[OnName num="gorou"]
'对不起。我很忙。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune094"]
[OnName num="suzune"]
'...... 不'。你想过这个故事吗？
[cpg cn=true]


[OnName num="gorou"]
'是的。我给出了自己的答案。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sHimari115"]
[OnName num="himari"]
那是关于什么的故事？"
[cpg cn=true]


绯春也在这里。我真的需要她在那里。
[cpg]


因为如果我和我妹妹结婚，绯红还是不会说她想留在我身边。
[cpg]


我甚至不需要再问这个问题了，或者说问这个问题太自私，太不礼貌了。
[cpg]


当然，我母亲除外，否则她不会要求这样做。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="sSuzune095"]
[OnName num="suzune"]
'......，我不能不对绯红隐瞒。我告诉戈罗。我告诉他，我非常爱他，我想嫁给他。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="sHimari116"]
[OnName num="himari"]
'呵。这很大胆。"
[cpg cn=true]


绯红似乎一点也不难过。她可能认为我不能在那里鼓起勇气。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune096"]
[OnName num="suzune"]
我......，如果我不能结婚，那么我就很难在五郎身边，这是我说的。"
[cpg cn=true]


[OnName num="gorou"]
是的，我希望你能和我在一起。但我也希望緋紅能和我在一起。"
[cpg cn=true]


[OnName num="gorou"]
我想知道这样的方便是否可能。"
[cpg cn=true]


我妹妹喘着气，等着我说什么。
[cpg]


[OnName num="gorou"]
'......，让他们两个人结婚怎么样？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="sHimari117"]
[OnName num="himari"]
嗯？"
[cpg cn=true]


[OnName num="gorou"]
'当然，不是现在。因为我喜欢我们这个家庭'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="sSuzune097"]
[OnName num="suzune"]
你知道你在说什么吗？　日本不承认一夫多妻制"。
[cpg cn=true]


[OnName num="gorou"]
'是的，好吧，......，实际上不会是关于注册的。
[cpg cn=true]


[OnName num="gorou"]
'但如果他们说他们可以在国外做，如果这就是他们出国的原因，那么我认为这也很好'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune098"]
[OnName num="suzune"]
'哦，你知道，......，这不是一个法律问题，而是一个心灵问题。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune099"]
[OnName num="suzune"]
'现在你们已经搬到一起住了，或者有了孩子，你会好好考虑吗？
[cpg cn=true]


[OnName num="gorou"]
'我正在考虑这个问题。我在认真考虑与你们俩结婚。"
[cpg cn=true]


[OnName num="gorou"]
'因为我决定不做选择。我不认为走到一半是个好主意。
[cpg cn=true]


一种奇怪的沉默占了上风。在这种情况下，Himari开始笑了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari118"]
[OnName num="himari"]
'...... phew, ha ha ha'.
[cpg cn=true]


[OnName num="gorou"]
'緋紅?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari119"]
[OnName num="himari"]
'我没有意识到你在想这些。你应该告诉我'。
[cpg cn=true]


笑完后，绯红插话说。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari120"]
[OnName num="himari"]
'我不需要和你们两个人结婚，也不需要出国，或者任何东西。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari121"]
[OnName num="himari"]
'因为我可以一直呆呆的，即使我的姐姐和弟弟结婚了。
[cpg cn=true]


[OnName num="gorou"]
什么？"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune100"]
[OnName num="suzune"]
'但是，但是......，我将拥有五郎一个人。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSuzune101"]
[OnName num="suzune"]
如果绯红像你一样喜欢五郎，你将无法原谅他。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="sHimari122"]
[OnName num="himari"]
'你们都想得太多了。你不知道未来会怎样'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari123"]
[OnName num="himari"]
'你为什么一开始就想结婚？　你从哪里得到的垄断？　我完全可以做我哥哥的第二。
[cpg cn=true]


绯红的性格是让模棱两可的东西模糊不清。
[cpg]


她正试图把我们从思想中解救出来。
[cpg]


也许她正在努力管理这种情况，即使它有点不堪重负。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune102"]
[OnName num="suzune"]
'绯红，你不吃醋吗？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari124"]
[OnName num="himari"]
'我愿意。但和我妹妹在一起，我很好。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari125"]
[OnName num="himari"]
'你们俩都太守规矩了。这一天到来时，又不是世界末日，为什么事情不能按原样发展？
[cpg cn=true]


我和我妹妹互相看了看。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari126"]
[OnName num="himari"]
'那你确定你是准时的吗？　我已经习惯于迟到了。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="sSuzune103"]
[OnName num="suzune"]
啊！"
[cpg cn=true]


;//ブラックアウト

[window target=false]

[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（朝）******************************************************

我们开始交谈。我赶紧准备一下，然后去学院，但我妹妹可能会迟到。
[cpg]


绯红说的那件事是......，说是最后什么都没做，但我的心却奇怪的很清楚。
[cpg]


我决定做的事情也可能是像绯红所说的那样。
[cpg]


我想尽可能长时间地保持相同的距离。
[cpg]


绯红可能已经看穿了这一点，她可能已经安抚了她的妹妹。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『学園教室』（昼）******************************************************


[OnName num="male_student_A"]
'我已经决定了。我毕竟要去找一份工作。
[cpg cn=true]


[OnName num="male_student_B"]
'嗯，这很好。为了你的家庭，继续接受高等教育是很愚蠢的'。
[cpg cn=true]


[OnName num="male_student_A"]
'哦。'我想如果我要考虑什么是对我的家庭最好的，那么我不妨做我想做的事。
[cpg cn=true]


[OnName num="male_student_A"]
'在我焦头烂额的时候，这对我的家庭是不利的。
[cpg cn=true]


[OnName num="male_student_A"]
'我想有时我为自己做的事也是为我的家人做的事。
[cpg cn=true]


...... 有时间的二人组。看起来我们已经取得了一些进展。
[cpg]


我也不能一直迷路。我不能迷失，不能选择任何人，我不能迷失。
[cpg]


如果你已经下定决心，就继续向前推进吧。这就是我的想法。
[cpg]


[window target=false]

[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『学園教室』（夕方）******************************************************

这是一种思维方式，但我也想知道是否所有的事情都要决定。
[cpg]


有时，像向日葵这样的思维方式可以解决一切问题。
[cpg]


即使它不能解决所有问题，但有些时候，现状是最幸福的。
[cpg]


似乎不从我姐姐那里学到，我甚至不能意识到这么明显的事情。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune104"]
[OnName num="suzune"]
因此，......，这里的解决方案是：......
[cpg cn=true]


你的妹妹表现得很平静，她没有提醒你她迟到了。
[cpg]


当我在同一个教室里时也是如此。可能要感谢绯红的存在，我才能像这样保持冷静。
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************



[OnName num="female_student"]
'哦，不。我已经被终止了，嗯？"
[cpg cn=true]


[OnName num="male_student"]
'审查？　漫画？"
[cpg cn=true]


[OnName num="female_student"]
'是的，一部卡通片。你想在那里坚持下去吗？　它就这样结束了。"
[cpg cn=true]


[OnName num="male_student"]
'太糟糕了。我宁愿有一个后宫，而不是一些奇怪的联姻。
[cpg cn=true]


现实不是漫画书。不要担心被审查。
[cpg]


我在听一些夫妇的谈话时也这么想。
[cpg]


[OnName num="female_student"]
'嗯？　我不喜欢后宫和通常的东西。你是不是有什么外遇？"
[cpg cn=true]


[OnName num="male_student"]
'不，不。......，怎么可能呢？
[cpg cn=true]


...... 好吧，我们说有一些关系在一起没有问题，比如说这两个人。
[cpg]


但同样，现实不是卡通。
[cpg]


我的生活不是为了让人看到，为了给人看。
[cpg]


如果是这样的话，追求幸福总是更好的，即使它是模糊的。
[cpg]




;//ブラックアウト


[window target=false]



[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="sSuzune105"]
[OnName num="suzune"]
'Himari.不要再在你父亲面前调情了。
[cpg cn=true]


[VOICE f="sHimari127"]
[OnName num="himari"]
'你为什么不和你妹妹也调情呢？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune106"]
[OnName num="suzune"]
'不!　这不会耽误我们的工作。"
[cpg cn=true]


[OnName num="gorou"]
'当人们说他们不喜欢它时，我很伤心。......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune107"]
[OnName num="suzune"]
哦，不，我不是这个意思。"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]

妈妈笑着说。
[cpg]


起初我觉得很奇怪，没有人选择她，但也许这就是日常生活应该有的样子。
[cpg]


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[window target=true]


然后过了一会儿，......
[cpg]


;//========================================
;//●ＣＧ（ベッドに三人寝転がっている。おなかは膨らんでない）ev_50
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//人物３：ヒロイン３
;//服装３：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================


[STOPBGM]
[WAIT time=1000]
[BGM f="bg_op"]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sHimari128"]
[OnName num="himari"]
'嘿嘿~。我们都在一起，这有点像一次旅行。"
[cpg cn=true]


[VOICE f="sSawa070"]
[OnName num="sawa"]
'嗯，没错。我们已经有一段时间没有过家庭假期了。
[cpg cn=true]


[VOICE f="sSuzune108"]
[OnName num="suzune"]
......，是的，没错。"
[cpg cn=true]


今天，我们四个人在绯红的要求下在一起。
[cpg]


这也不适合我，因为我的体质已经稳定下来了。
[cpg]


这是我的命运，因为我没有选择其他任何人。
[cpg]


[VOICE f="sHimari129"]
[OnName num="himari"]
'来吧，兄弟。你想要多少刺激，我就给你多少刺激。"
[cpg cn=true]


[VOICE f="sSuzune109"]
[OnName num="suzune"]
'......，很疯狂。这就是......'
[cpg cn=true]


[VOICE f="sHimari130"]
[OnName num="himari"]
'嗯，我很开心。我希望我们都能一直在一起'。
[cpg cn=true]


我当时的心情无法形容，但却很激动。
[cpg]


[VOICE f="sSawa071"]
[OnName num="sawa"]
'呵。绯红是如此的无辜'。
[cpg cn=true]


还有我的母亲，她说，嗯，她也在天真地笑着。
[cpg]


我不知道他们三个人到底在想什么。但他们似乎很高兴。
[cpg]




[VOICE f="Suzune385"]
[OnName num="suzune"]
如果你对我的爱不够，我就会生气，因为我们三个人在一起。
[cpg cn=true]


[VOICE f="sHimari131"]
[OnName num="himari"]
'很高兴见到你，大哥哥。'不，我想我总有一天会成为一个父亲。
[cpg cn=true]


[OnName num="gorou"]
'我不知道。
[cpg cn=true]


[VOICE f="Sawa315"]
[OnName num="sawa"]
不要漏掉一个人！"
[cpg cn=true]




[OnName num="gorou"]
...... 我知道我在做什么。
[cpg cn=true]


是否有后宫这种东西，或者是否应该有？
[cpg]



;//ブラックアウト

家庭。恋人。不能用这些词来定义的关系。
[cpg]


我当然很高兴，让模棱两可的事情保持模棱两可。
[cpg]


我想我姐姐、绯红和我母亲可能也有同样的感觉。......
[cpg]

[SCENE id=12]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]
;//ＥＮＤ：ハーレムルート






;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





