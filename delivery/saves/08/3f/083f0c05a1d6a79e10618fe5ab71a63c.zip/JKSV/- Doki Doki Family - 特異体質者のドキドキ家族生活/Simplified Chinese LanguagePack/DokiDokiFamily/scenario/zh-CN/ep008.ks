
*start


;###################################################################
*Ep008|快乐优柔寡断
;###################################################################

;//４、選ぶことができない

*select04_4|快乐优柔寡断

[SCENE id=8]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


...... 号。我还是无法选择。
[cpg]


即使有人告诉你需要恋爱，也不是那么容易做出决定的。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="gorou"]
'对不起，我还是......无法选择。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[VOICE f="Suzune337"]
[OnName num="suzune"]
五郎......"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari331"]
[OnName num="himari"]
'大哥......'
[cpg cn=true]


我很迷茫，无法选择任何人。
[cpg]


然后我告诉他们，我不能选择反对他们三个人。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa273"]
[OnName num="sawa"]
'我知道五郎的想法。那么你就不必选择了'。
[cpg cn=true]


[OnName num="gorou"]
嗯？"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari095"]
[OnName num="himari"]
'换句话说，我还是要和我们三个人一起捣鼓你，兄弟，就像我们一直以来一样。
[cpg cn=true]


不，但这不是...
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/3" time=800]
[VOICE f="Suzune338"]
[OnName num="suzune"]
'没关系的。这是我们已经讨论过并决定的事情'。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="3/3" time=800]
[VOICE f="sSawa061"]
[OnName num="sawa"]
'如果他们说坠入爱河可以治愈你的体质，那么人越多越好。
[cpg cn=true]


嗯，这当然是......？　它是否能使治愈的机会增加三倍？
[cpg]


[OnName num="gorou"]
'......'
[cpg cn=true]


即使是这样，我是否可以这样利用一个对我这么好的家庭成员？
[cpg]


但我仍然担心......，我的呼吸会出现问题。
[cpg]


[OnName num="gorou"]
'......，谢谢你，请。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="Suzune339"]
[OnName num="suzune"]
为了五郎的缘故，我会......尽我所能。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari333"]
[OnName num="himari"]
我让你去吧。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa275"]
[OnName num="sawa"]
'你会把你的母亲宠坏的。
[cpg cn=true]


虽然不解，但她还是决定服从，认为如果他们三个人这么说，那就这么办吧。
[cpg]





;//ブラックアウト

[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]


这事发生几天后。
[cpg]


他们三个人仍然像往常一样对我来者不拒。当然，他们还没有吻过我。......
[cpg]


但这一天终于到来，他越过了治愈这种疾病的界限。
[cpg]


[window target=false]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





我醒来的时候，我妹妹已经和我一起爬到了床上。
[cpg]


[OnName num="gorou"]
'嗯...'
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari334"]
[OnName num="himari"]
'哦，我起来了。早上好，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'是的......早上好。你为什么这么近？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari096"]
[OnName num="himari"]
为什么，当然是为了吻我。
[cpg cn=true]


[OnName num="gorou"]
转到.......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari336"]
[OnName num="himari"]
'否则你将永远无法恢复。你确定你想保持这种方式吗？"
[cpg cn=true]


[OnName num="gorou"]
我不......，认为这是个好主意。
[cpg cn=true]


以这种方式被大家激动，是一种福利，也可能是一种美味的环境。
[cpg]


但这种使生活受到更多限制的体质，仍然必须得到治愈。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari097"]
[OnName num="himari"]
'那好吧，让我们接吻吧。如果是和我哥哥......好吧。"
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


然后她把她的嘴唇送到他的面前。
[cpg]


我甚至还没有刷牙，......，想着我现在不应该想的事情。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_h1"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


绯红拉开她的嘴唇，看起来很高兴。当她做出这样的表情时，敲击声就会越来越强。
[cpg]



[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari098"]
[OnName num="himari"]
'这对你来说还不够，是吗？　我还是会让你悸动的。"
[cpg cn=true]


[OnName num="gorou"]
'什么，你还打算这么做？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari099"]
[OnName num="himari"]
'我不在乎你做了多少次。我必须通过做爱来治疗我的体质'。
[cpg cn=true]


[OnName num="gorou"]
'但是，这是否可以......'
[cpg cn=true]




[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari100"]
[OnName num="himari"]
'好。你关心什么呢？
[cpg cn=true]


[OnName num="gorou"]
因为我不认为你在单挑我们。"
[cpg cn=true]


我想当时有一个规则，就是每个人都是平等的。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari363"]
[OnName num="himari"]
'现在是我负责的时间，所以很好。也许你们两个也会这样做......'
[cpg cn=true]


她是一个非常有活力的妹妹。我想我妹妹会有所保留，更不用说我母亲了。
[cpg]


即使有这样的想法，我们最终还是在一起度过了整个时间......。
[cpg]



[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[window target=true]


然后就到了交接的时候。
[cpg]


严格说来不是从这里出发，但......，我姐姐来拉我。
[cpg]

[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune077"]
[OnName num="suzune"]
'...... a bit.你要和我坚持多久，绯红？"
[cpg cn=true]


姐姐似乎有点生气，因为希卡里在午餐后留下来陪她。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari101"]
[OnName num="himari"]
'哦...姐姐'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune341"]
[OnName num="suzune"]
'是时候走了。来吧，走吧。"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari365"]
[OnName num="himari"]
啧啧。"
[cpg cn=true]

[free time=1000]

绯红不情愿地离开了房间。这不像是绯红马上就听我的话，但我猜她觉得我独占她这么久很不好。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune342"]
[OnName num="suzune"]
你......你没事吧？ 一点也不，緋紅。
[cpg cn=true]


[OnName num="gorou"]
'嗯，是的......有点过于紧张和疲惫，但是......'
[cpg cn=true]


我的妹妹似乎对我说的话有点不以为然。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune343"]
[OnName num="suzune"]
'...... 你想做什么？我不知道如果我不这样做是否更好......'
[cpg cn=true]


[OnName num="gorou"]
'不，我很好。我不能让你和其他人单独在一起'。
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune344"]
[OnName num="suzune"]
'谢谢你，戈罗。我很高兴。但是......不要做一个假正经的人。"
[cpg cn=true]


[OnName num="gorou"]
我们会好好照顾它。"
[cpg cn=true]


这次是和你妹妹一起。不无节制可能是很难做到的。
[cpg]


我们不得不转移到另一个地方，前往我姐姐的房间。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

;//移植前シーンカット

她没有吻我，但我觉得她很清楚该怎么做才能让我紧张。
[cpg]


她能看出我很喜欢她，即使我们没有紧紧抓住对方。
[cpg]



;//ブラックアウト

[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



而更多的时间过去了，然后......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa276"]
[OnName num="sawa"]
'五郎。现在轮到你母亲了！"
[cpg cn=true]


[OnName num="gorou"]
'嗯...让我休息一下...'
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa277"]
[OnName num="sawa"]
'嗯，嗯。Dahme♪''
[cpg cn=true]


[OnName num="gorou"]
"...... 是。"
[cpg cn=true]


我们又搬了房间，这次是和我母亲一起。
[cpg]


我认为我的房间对她来说不够好，但她不愿意。
[cpg]


也许有一些本能的东西.......，不，如果不是这样就太不礼貌了。
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_04_2_up.ui" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[WAIT time=2000]

;//移植前シーンカット

我妈妈可能是我们三个人中最不宽容的。
[cpg]


你可以说她最担心的是我。如果我不扑腾，我就很难呼吸了。
[cpg]


上午是绯红，下午是我妹妹，晚上是我母亲。他们每个人都有自己的捣蛋时间。
[cpg]


这是那种可以被描述为男人最好的一天。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



当我继续这样的粗暴对待时，我的体质就稳定下来了。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="sHimari102"]
[OnName num="himari"]
'这很奇怪!当你坠入爱河时，你真的被治愈了。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSuzune078"]
[OnName num="suzune"]
'......，就我而言，我想知道你爱上的是谁。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]

[VOICE f="sSawa062"]
[OnName num="sawa"]
'他们是谁并不重要。这是每个人的吾郎'。
[cpg cn=true]


我母亲说了一句话，有点棘手。不，当你说出来的时候，你也说出来了，姐姐。
[cpg]


我自己也不知道我们三个人都爱上了谁。
[cpg]


但现在真的没有回头路了。
[cpg]


我的体质已经稳定下来了，这意味着证明我爱上了他们三个中的一个。
[cpg]



;//ブラックアウト

;//移植前シーンカット

我希望我有足够的资格在这里说我爱谁。
[cpg]


不幸的是，我是那个在关键时刻无法选人的人。
[cpg]


我相信在......，每个人都觉得这很令人沮丧。但我同样喜欢他们。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************

;//ブラックアウト

[OnName num="father"]
'不知为什么，你们这些天相处得非常好。
[cpg cn=true]


而我父亲，正如预期的那样，说了一些话，让我意识到他已经注意到了。
[cpg]


也许我更早地注意到它。只是他现在说出来了。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="sSuzune079"]
[OnName num="suzune"]
'什么？　不，不，这不是......"
[cpg cn=true]


我妹妹对我爸爸的行为很可疑。尽管他们是家人。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari103"]
[OnName num="himari"]
'这就对了!我们一直都很亲密，不是吗？
[cpg cn=true]


[OnName num="father"]
你有吗？"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSawa063"]
[OnName num="sawa"]
'是的，没错。他正处于想要被宠爱的年龄，我打赌。
[cpg cn=true]


[OnName num="father"]
'......，我明白了。
[cpg cn=true]


爸爸看起来有点复杂。
[cpg]


当然，我不会在他面前无谓地调情。姐姐。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari104"]
[OnName num="himari"]
'爸爸，你不能吃醋。你只属于我，大哥哥。
[cpg cn=true]


然而，绯红并不害怕在爸爸面前坚持下去。
[cpg]


看到我妹妹痛苦的脸，我也很难受。......
[cpg]

;//移植前シーンカット


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『街』（昼）******************************************************


最后，我们三个人，每个人都保持同样的距离。
[cpg]


或者，也许我只是没有注意到，因为我离他们所有人都那么近。
[cpg]


周末来了又走，不知道这种关系是否好。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]


[VOICE f="sHimari105"]
[OnName num="himari"]
'我们四个人已经很久没有一起出去了。
[cpg cn=true]


我们出来的时候，只有爸爸有差事要做。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="sSawa064"]
[OnName num="sawa"]
'是的，我想是的。我想特别是铃音可能会有点害羞'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune080"]
[OnName num="suzune"]
'......，现在没有什么可害羞的了。
[cpg cn=true]


这当然是真的。如果我要害羞，那就应该在更早的时候。......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="sHimari106"]
[OnName num="himari"]
'那么，我们应该去哪里？　你有一个约会计划吗，妈妈？"
[cpg cn=true]


向母亲要一个约会计划，听起来......，但这并没有错。
[cpg]


;//背景と違う場所です。上下に黒帯を入れるなどの演出を入れてください

[FACE method="feadin" pos="4/7"]
[BG f="b_01_2_up.ui" time=1000]
[WAIT time=1000]


我们要去商场。我记得小时候经常去那里。
[cpg]


当然，我现在已经不好意思和他们出去了。
[cpg]


在这种情况下再次外出，对我来说是一种非常感性的体验。
[cpg]


就像他们三个人认出了我的奇怪体质。......
[cpg]


更重要的是，我觉得他们接受了我的感受。
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="sSawa065"]
[OnName num="sawa"]
'你已经改变了很多。所有的服装店'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSuzune081"]
[OnName num="suzune"]
'嗯，......，也许这就是它的方式。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]

[VOICE f="sHimari107"]
[OnName num="himari"]
'你真的想买那么多衣服吗？　不过我更想吃一顿好的。"
[cpg cn=true]


[OnName num="gorou"]
对了，我想我们是时候吃晚饭了。"
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]

[VOICE f="sSuzune082"]
[OnName num="suzune"]
我很惊讶你能负责。
[cpg cn=true]


[OnName num="gorou"]
不，不，我不认为我是负责人。
[cpg cn=true]


我们进行了多么精彩的对话，享受我们在一起的时光。
[cpg]


这样一来，我们仍然觉得自己是家人而不是恋人。
[cpg]


这就像我们仍然是一个家庭，但我们变得更亲密了。......
[cpg]


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="sHimari108"]
[OnName num="himari"]
这很有趣。我哥哥给我买了衣服。"
[cpg cn=true]


[OnName num="gorou"]
'你告诉我你想做的就是买衣服。......
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari109"]
[OnName num="himari"]
'没事的，没事的。不要把我说的话看得那么严重'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSuzune083"]
[OnName num="suzune"]
'它必须是......
[cpg cn=true]


我母亲看着我们的谈话，微笑着。
[cpg]


回想起来，也许这就是我一直想要的东西。
[cpg]


我在一次事故中失去了父母后，我希望得到家庭的温暖。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="sSawa066"]
[OnName num="sawa"]
你玩得开心吗，戈罗？
[cpg cn=true]


[OnName num="gorou"]
是的。当然，这是一个很大的乐趣。"
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]


...... 我最喜欢这种时间。我相信这比我和我女朋友在一起的时间要多。......
[cpg]


我不想为了和任何一个人在一起而拆散家庭关系。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


随着我们家庭关系的增长，我感到很遗憾，这个人是一只蚊子。
[cpg]


[OnName num="father"]
'...... 什么？　你想和我谈谈。"
[cpg cn=true]


[OnName num="gorou"]
'不。只是我们今天又出去了'。
[cpg cn=true]


[OnName num="father"]
'别担心。我知道你们两个相处得很好。"
[cpg cn=true]


可怜的是，我想，但......，还有一件事我在想。
[cpg]


[OnName num="gorou"]
'谢谢你.......因为接受我进入这个家。"
[cpg cn=true]


[OnName num="father"]
'什么？　出乎意料。"
[cpg cn=true]


[OnName num="gorou"]
'不，不。我只是觉得我没有说太多。"
[cpg cn=true]


[OnName num="father"]
'这正是你需要担心的事情。我不能丢下你一个人。
[cpg cn=true]


爸爸看起来很尴尬。
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSawa067"]
[OnName num="sawa"]
怎么了？　你们两个似乎谈了很多。"
[cpg cn=true]


[OnName num="gorou"]
'是的。我只是很高兴能在这个房子里。"
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sSawa068"]
[OnName num="sawa"]
'嗯。不寻常。"
[cpg cn=true]


不寻常的。我确实没有对你说过这些话。
[cpg]


[OnName num="gorou"]
我为我的不孝感到抱歉。
[cpg cn=true]


[OnName num="father"]
'别担心。你还没有大到可以担心这种事情的地步'。
[cpg cn=true]


爸爸重复着'不要担心'这句话。我对此表示感谢。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]


我欠我父亲一个人情。我的姐姐、绯红，甚至我的母亲都让我感到紧张。
[cpg]


我知道他没有告诉我也不要担心这个问题，......，但这仍然让我感觉好些。
[cpg]


[window target=false]


[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

吃完晚饭后，在我的房间里休息，绯红过来了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari110"]
[OnName num="himari"]
'嘿，你确定你不打算选人吗？
[cpg cn=true]


[OnName num="gorou"]
是的，从那时起我就一直在思考这个问题。......"
[cpg cn=true]


[OnName num="gorou"]
'不是说我同样喜欢他们，更多的是我不能只选其中一个的原因。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sHimari111"]
[OnName num="himari"]
你是什么意思？"
[cpg cn=true]


[OnName num="gorou"]
我......，喜欢这个房子。
[cpg cn=true]


[OnName num="gorou"]
'我现在不想毁掉这段关系。在今天发生的事情之后，我深深感受到了这一点'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari112"]
[OnName num="himari"]
'...... 这对你姐姐来说可能是一件很难说出口的事情，不是吗？　从我们的角度来看，你是孤独的。"
[cpg cn=true]


[OnName num="gorou"]
'...... 抱歉。
[cpg cn=true]


绯红似乎有点生气，但也很宽容。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari113"]
[OnName num="himari"]
'好吧，这不是我哥哥第一次优柔寡断了，所以我已经放弃了。
[cpg cn=true]


[OnName num="gorou"]
我非常抱歉。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari114"]
[OnName num="himari"]
'你不需要道歉。你已经下定决心。你那优柔寡断的弟弟'。
[cpg cn=true]


我有点抱歉，不能说什么。
[cpg]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]
;//【ＢＧ】『街』（朝）******************************************************

我的体质越来越平和了。我并不是爱上了任何一个人。
[cpg]


一切都在向好的方向发展，尽管就这段关系而言，没有任何改变。
[cpg]


...... 就在这时，事情发生了。
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『学園教室』（昼）******************************************************

[OnName num="gorou"]
'姐姐，怎么了？
[cpg cn=true]


我在一个空荡荡的教室里，我姐姐叫我进去。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune084"]
[OnName num="suzune"]
'...... 抱歉。我不是有意这么突然叫你出来的。
[cpg cn=true]


[OnName num="gorou"]
'这很好，但有些事情是不对的。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune085"]
[OnName num="suzune"]
这并不是说事情刚刚发生，更像是......，一直以来，都有事情发生。"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune086"]
[OnName num="suzune"]
'五郎。你喜欢我吗？"
[cpg cn=true]


[OnName num="gorou"]
'是的。我喜欢你。"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune087"]
[OnName num="suzune"]
'你不是最好的听众。你喜欢我这个恋人吗？
[cpg cn=true]


[OnName num="gorou"]
这是......，已经决定我不会选择其他人。"
[cpg cn=true]


我妹妹听到我的话后，显得很痛苦。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune088"]
[OnName num="suzune"]
'我非常喜欢你，我想做你的情人。
[cpg cn=true]


...... 我直到刚才才考虑到这种可能性。
[cpg]


这不是由我来选择其他人。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune089"]
[OnName num="suzune"]
与我们四个人在一起很有趣，但也可能很困难。"
[cpg cn=true]


显然，我姐姐很爱我。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune090"]
[OnName num="suzune"]
'我已经准备好成为你唯一的我。
[cpg cn=true]


我想让你成为我，只做你的妹妹 "这句话背后的意图隐藏在 "我想让你成为我，只做你的妹妹"。
[cpg]


[OnName num="gorou"]
'......'
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune091"]
[OnName num="suzune"]
'我不会对你隐瞒。我想和你结婚'。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune092"]
[OnName num="suzune"]
'如果你说你不会选择任何人，......，我想与你保持距离。当我们不能在一起时，我在你身边是很痛苦的。"
[cpg cn=true]


这是一个令人心痛的想法。我只想和我的家人在一起。
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『学園廊下』（夕方）******************************************************

[OnName num="male_student_A"]
'哦，不。职业道路"。
[cpg cn=true]


[OnName num="male_student_B"]
'你为什么会迷路呢？你说你想在毕业后马上找到一份工作'。
[cpg cn=true]


[OnName num="male_student_A"]
我在努力，但我的父母似乎不允许我这样做。
[cpg cn=true]


[OnName num="male_student_A"]
我和我的兄弟姐妹们也很挑剔。......。
[cpg cn=true]


[OnName num="male_student_B"]
'你必须做你自己。家庭，无论你多么关心他们，他们不可能永远留在你身边。
[cpg cn=true]


...... 在稍远的地方，可以听到两个互不相识的人之间的对话。
[cpg]


家庭不可能永远呆在一起。我想可能确实是这样的情况。
[cpg]


[window target=false]



[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************


要么你与你的妹妹有一种非家庭的关系，要么你与她这个家庭成员保持距离。它是一个还是另一个？
[cpg]


我想保持我们的关系是这样的。
[cpg]


[window target=false]

[STOPBGM]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


那天在餐桌上，我和姐姐之间的关系变得很尴尬。
[cpg]


当然，Himaru似乎已经注意到了什么，并且很担心。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sSawa069"]
[OnName num="sawa"]
'怎么了？　我不再吃了。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSuzune093"]
[OnName num="suzune"]
是的。......，我没有什么胃口。"
[cpg cn=true]


如何对待你的妹妹。我觉得我仍有一些事情需要告诉她。
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="gorou"]
'......，我知道这是唯一的办法。
[cpg cn=true]


思考。经过反复思考，我得出了一个结论。
[cpg]


我不会在我妹妹和绯红之间做出选择。我找到了继续我们目前关系的唯一方法。
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

第二天早上。在我离开之前，我给我姐姐打了电话。
[cpg]


[OnName num="gorou"]
'对不起。我很忙。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune094"]
[OnName num="suzune"]
'...... 不'。你想过这个故事吗？
[cpg cn=true]


[OnName num="gorou"]
'是的。我给出了自己的答案。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sHimari115"]
[OnName num="himari"]
那是关于什么的故事？"
[cpg cn=true]


绯春也在这里。我真的需要她在那里。
[cpg]


因为如果我和我妹妹结婚，绯红还是不会说她想留在我身边。
[cpg]


我甚至不需要再问这个问题了，或者说问这个问题太自私，太不礼貌了。
[cpg]


当然，我母亲除外，否则她不会要求这样做。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="sSuzune095"]
[OnName num="suzune"]
'......，我不能不对绯红隐瞒。我告诉戈罗。我告诉他，我非常爱他，我想嫁给他。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="sHimari116"]
[OnName num="himari"]
'呵。这很大胆。"
[cpg cn=true]


绯红似乎一点也不难过。她可能认为我不能在那里鼓起勇气。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune096"]
[OnName num="suzune"]
我......，如果我不能结婚，那么我就很难在五郎身边，这是我说的。"
[cpg cn=true]


[OnName num="gorou"]
是的，我希望你能和我在一起。但我也希望緋紅能和我在一起。"
[cpg cn=true]


[OnName num="gorou"]
我想知道这样的方便是否可能。"
[cpg cn=true]


我妹妹喘着气，等着我说什么。
[cpg]


[OnName num="gorou"]
'......，让他们两个人结婚怎么样？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="sHimari117"]
[OnName num="himari"]
嗯？"
[cpg cn=true]


[OnName num="gorou"]
'当然，不是现在。因为我喜欢我们这个家庭'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="sSuzune097"]
[OnName num="suzune"]
你知道你在说什么吗？　日本不承认一夫多妻制"。
[cpg cn=true]


[OnName num="gorou"]
'是的，好吧，......，实际上不会是关于注册的。
[cpg cn=true]


[OnName num="gorou"]
'但如果他们说他们可以在国外做，如果这就是他们出国的原因，那么我认为这也很好'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune098"]
[OnName num="suzune"]
'哦，你知道，......，这不是一个法律问题，而是一个心灵问题。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune099"]
[OnName num="suzune"]
'现在你们已经搬到一起住了，或者有了孩子，你会好好考虑吗？
[cpg cn=true]


[OnName num="gorou"]
'我正在考虑这个问题。我在认真考虑与你们俩结婚。"
[cpg cn=true]


[OnName num="gorou"]
'因为我决定不做选择。我不认为走到一半是个好主意。
[cpg cn=true]


一种奇怪的沉默占了上风。在这种情况下，緋紅开始笑了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari118"]
[OnName num="himari"]
'...... phew, ha ha ha'.
[cpg cn=true]


[OnName num="gorou"]
'緋紅?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari119"]
[OnName num="himari"]
'我没有意识到你在想这些。你应该告诉我'。
[cpg cn=true]


笑完后，绯红插话说。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari120"]
[OnName num="himari"]
'我不需要和你们两个人结婚，也不需要出国，或者任何东西。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari121"]
[OnName num="himari"]
'因为我可以一直呆呆的，即使我的姐姐和弟弟结婚了。
[cpg cn=true]


[OnName num="gorou"]
什么？"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune100"]
[OnName num="suzune"]
'但是，但是......，我将拥有五郎一个人。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSuzune101"]
[OnName num="suzune"]
如果绯红像你一样喜欢五郎，你将无法原谅他。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="sHimari122"]
[OnName num="himari"]
'你们都想得太多了。你不知道未来会怎样'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari123"]
[OnName num="himari"]
'你为什么一开始就想结婚？　你从哪里得到的垄断？　我完全可以做我哥哥的第二。
[cpg cn=true]


绯红的性格是让模棱两可的事情变得模糊不清。
[cpg]


她正试图把我们从思想中解救出来。
[cpg]


也许她正在努力管理这种情况，即使它有点不堪重负。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune102"]
[OnName num="suzune"]
'绯红，你不吃醋吗？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari124"]
[OnName num="himari"]
'我愿意。但和我妹妹在一起，我很好。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari125"]
[OnName num="himari"]
'你们俩都太守规矩了。这一天到来时，又不是世界末日，为什么事情不能按原样发展？
[cpg cn=true]


我和我妹妹互相看了看。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari126"]
[OnName num="himari"]
'那你确定你是准时的吗？　我已经习惯于迟到了。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="sSuzune103"]
[OnName num="suzune"]
啊！"
[cpg cn=true]


;//ブラックアウト

[window target=false]

[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（朝）******************************************************

我们开始交谈。我赶紧准备一下，然后去学院，但我妹妹可能会迟到。
[cpg]


绯红说的那件事是......，说是最后什么都没做，但我的心却奇怪的很清楚。
[cpg]


我决定做的事情也可能是像绯红所说的那样。
[cpg]


我想尽可能长时间地保持相同的距离。
[cpg]


绯红可能已经看穿了这一点，她可能已经安抚了她的妹妹。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『学園教室』（昼）******************************************************


[OnName num="male_student_A"]
'我已经决定了。我毕竟要去找一份工作了。
[cpg cn=true]


[OnName num="male_student_B"]
'嗯，这很好。为了你的家庭，继续接受高等教育是很愚蠢的'。
[cpg cn=true]


[OnName num="male_student_A"]
'哦。'我想如果我要考虑什么是对我的家庭最好的，那么我不妨做我想做的事。
[cpg cn=true]


[OnName num="male_student_A"]
'在我焦头烂额的时候，这对我的家庭是不利的。
[cpg cn=true]


[OnName num="male_student_A"]
'我想有时我为自己做的事也是为我的家人做的事。
[cpg cn=true]


...... 有时间的二人组。看起来我们已经取得了一些进展。
[cpg]


我也不能一直迷路。我不能迷失，不能选择任何人，我不能迷失。
[cpg]


如果你已经下定决心，就继续向前推进吧。这就是我的想法。
[cpg]


[window target=false]

[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『学園教室』（夕方）******************************************************

这是一种思维方式，但我也想知道是否所有的事情都要决定。
[cpg]


有时，像向日葵这样的思维方式可以解决一切问题。
[cpg]


即使它不能解决所有问题，但有些时候，现状是最幸福的。
[cpg]


似乎不从我姐姐那里学到，我甚至不能意识到这么明显的事情。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune104"]
[OnName num="suzune"]
因此，......，这里的解决方案是：......
[cpg cn=true]


你的妹妹表现得很平静，她没有提醒你她迟到了。
[cpg]


当我在同一个教室里时也是如此。可能要感谢绯红的存在，我才能像这样保持冷静。
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************



[OnName num="female_student"]
'哦，不。我已经被终止了，嗯？"
[cpg cn=true]


[OnName num="male_student"]
'审查？　漫画？"
[cpg cn=true]


[OnName num="female_student"]
'是的，一部卡通片。你想在那里坚持下去吗？　它就这样结束了。"
[cpg cn=true]


[OnName num="male_student"]
'惭愧。我宁愿有一个后宫，而不是一些奇怪的联姻。
[cpg cn=true]


现实不是漫画书。不要担心被审查。
[cpg]


我在听一些夫妇的谈话时也这么想。
[cpg]


[OnName num="female_student"]
'嗯？　我不喜欢后宫和通常的东西。你是不是有什么外遇？"
[cpg cn=true]


[OnName num="male_student"]
'不，不。......，怎么可能呢？
[cpg cn=true]


...... 好吧，我们说有一些关系在一起没有问题，比如说这两个人。
[cpg]


但同样，现实不是卡通。
[cpg]


我的生活不是为了让人看到，为了给人看。
[cpg]


如果是这样的话，追求幸福总是更好的，即使它是模糊的。
[cpg]




;//ブラックアウト


[window target=false]



[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="sSuzune105"]
[OnName num="suzune"]
'緋紅.不要再在你父亲面前调情了。
[cpg cn=true]


[VOICE f="sHimari127"]
[OnName num="himari"]
'你为什么不和你妹妹也调情呢？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune106"]
[OnName num="suzune"]
'不!　这不会耽误我们的工作。"
[cpg cn=true]


[OnName num="gorou"]
'当人们说他们不喜欢它时，我很伤心。......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune107"]
[OnName num="suzune"]
哦，不，我不是这个意思。"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]

妈妈笑着说。
[cpg]


起初我觉得很奇怪，没有人选择她，但也许这就是日常生活应该有的样子。
[cpg]


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[window target=true]


然后过了一会儿，......
[cpg]


;//========================================
;//●ＣＧ（ベッドに三人寝転がっている。おなかは膨らんでない）ev_50
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//人物３：ヒロイン３
;//服装３：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================


[STOPBGM]
[WAIT time=1000]
[BGM f="bg_op"]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sHimari128"]
[OnName num="himari"]
'嘿嘿~。我们都在一起，这有点像一次旅行。"
[cpg cn=true]


[VOICE f="sSawa070"]
[OnName num="sawa"]
'嗯，没错。我们已经有一段时间没有过家庭假期了。
[cpg cn=true]


[VOICE f="sSuzune108"]
[OnName num="suzune"]
......，是的，没错。"
[cpg cn=true]


今天，我们四个人在绯红的要求下在一起。
[cpg]


这也不适合我，因为我的体质已经稳定下来了。
[cpg]


这是我的命运，因为我没有选择其他任何人。
[cpg]


[VOICE f="sHimari129"]
[OnName num="himari"]
'来吧，兄弟。你想要多少刺激，我就给你多少刺激。"
[cpg cn=true]


[VOICE f="sSuzune109"]
[OnName num="suzune"]
'......，很疯狂。这就是......'
[cpg cn=true]


[VOICE f="sHimari130"]
[OnName num="himari"]
'嗯，我很开心。我希望我们都能一直在一起'。
[cpg cn=true]


我当时的心情无法形容，但却很激动。
[cpg]


[VOICE f="sSawa071"]
[OnName num="sawa"]
'呵。绯红是如此的无辜'。
[cpg cn=true]


还有我的母亲，她说，嗯，她也在天真地笑着。
[cpg]


我不知道他们三个人到底是怎么想的。但他们似乎有点高兴。
[cpg]




[VOICE f="Suzune385"]
[OnName num="suzune"]
'如果你对我的爱不够，我就会生气，因为我们三个人在一起。
[cpg cn=true]


[VOICE f="sHimari131"]
[OnName num="himari"]
'很高兴见到你，大哥哥。'不，我想我总有一天会成为一个父亲。
[cpg cn=true]


[OnName num="gorou"]
'我不知道。
[cpg cn=true]


[VOICE f="Sawa315"]
[OnName num="sawa"]
不要漏掉一个人！"
[cpg cn=true]




[OnName num="gorou"]
...... 我知道我在做什么。
[cpg cn=true]


是否有后宫这种东西，或者是否应该有？
[cpg]



;//ブラックアウト

家庭。恋人。不能用这些词来定义的关系。
[cpg]


我当然很高兴，让模棱两可的事情保持模棱两可。
[cpg]


我想我姐姐、绯红和我母亲可能也有同样的感觉。......
[cpg]

[SCENE id=12]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]
;//ＥＮＤ：ハーレムルート






;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





