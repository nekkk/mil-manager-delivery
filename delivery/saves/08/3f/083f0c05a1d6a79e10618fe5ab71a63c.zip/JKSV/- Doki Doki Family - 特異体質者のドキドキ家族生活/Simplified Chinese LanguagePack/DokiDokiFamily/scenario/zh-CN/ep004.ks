
*start

;###################################################################
*Ep004|思想和谁在一起？
;###################################################################

[SCENE id=4]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[transition target={false} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





早晨。我被一个不怎么好的梦惊醒。
[cpg]


我梦见我在一个我不知道在哪里的地方，周围有我的母亲、姐姐和绯红。
[cpg]


我认为梦到别人是可以的。但我不这样做，就有点疯狂了。
[cpg]


想到这里，我带着一种无奈的心情走向餐厅。
[cpg]



;//ブラックアウト


[window target=false]



[BG f="b_04_1_up.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="gorou"]
'嘿，绯红是在......？
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Sawa099"]
[OnName num="sawa"]
'我不知道--我不知道。也许他还在他的房间里？
[cpg cn=true]


我有麻烦了。......，我得往我的方向走？我感觉我正在失去。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Suzune102"]
[OnName num="suzune"]
'好吧，我现在要走了。回头见。"
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se000"]
;//【ＳＥ】『ノック』



我敲了敲绯红的房间，敲了敲它的门。
[cpg]


[VOICE f="Himari092"]
[OnName num="himari"]
'你可以进来了。你是她的哥哥，对吗？
[cpg cn=true]


[OnName num="gorou"]
"...... 是的。"
[cpg cn=true]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_04_1_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari093"]
[OnName num="himari"]
'我一直想试试那种情况，你哥哥到我房间来，你知道吗？
[cpg cn=true]


绯红是无忧无虑的。我们的生命危在旦夕。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari022"]
[OnName num="himari"]
'你看起来很苦恼。你不能没有我，对吗？"
[cpg cn=true]


[OnName num="gorou"]
'你没有错。我生病了'。
[cpg cn=true]


绯红说她病了，她并不高兴。
[cpg]


[VOICE f="sHimari023"]
[OnName num="himari"]
'好吧，我不在乎是不是因为我生病了。只要你到我身边来'。
[cpg cn=true]



说着，绯红张开双手。我无法拒绝这个邀请。
[cpg]


;//移植前シーンカット



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（昼）******************************************************





日子就这样一点点地过去了。
[cpg]


对我来说，这似乎是一个无尽的时间，但显然只过去了大约一个星期。
[cpg]


而我又去了医院。然后我发现：......
[cpg]


[window target=false]


[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



这毕竟是一种未知的宪法，是我们已经知道了一段时间的东西，但我已经看到了一个电灯泡的时刻。
[cpg]


这一线生机是我希望我没有再看到的。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Sawa100"]
[OnName num="sawa"]
'...... 医生，你说了一些惊人的事情！'
[cpg cn=true]


[OnName num="gorou"]
'嗯，是的。......，我不知道我是否想考虑太多。
[cpg cn=true]


医生说，这种情况是一种爱上某人的本能过度活跃的状态。
[cpg]


他解释说，通过与别人相爱，宪法会平静下来。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari113"]
[OnName num="himari"]
'这就像你感冒了，它就会消失。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune103"]
[OnName num="suzune"]
'我认为......，这是不同的。
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





回到家里，回到我的房间，我遇到了麻烦。
[cpg]


爱上某人了吗？　这是个大问题了。
[cpg]


我没有女朋友。如果我这样做，就不会发生这种情况。
[cpg]


...... 绯红和她的妹妹呢？我从来没有听说过她有男朋友，也没有听说过她有男朋友。
[cpg]


如果我不检查，这就不好了。这是一个关于未来的故事。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



这就是为什么我问我姐姐和绯红。
[cpg]


[OnName num="gorou"]
'...... 你们俩有男朋友吗？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune104"]
[OnName num="suzune"]
'你突然间怎么了......，不，想那种事是很诱人的。
[cpg cn=true]


大姐似乎已经猜到了什么，脸红了。还有。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune105"]
[OnName num="suzune"]
'不，我不知道。緋紅也不例外。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari024"]
[OnName num="himari"]
'是的。我也是'。
[cpg cn=true]



绯红在说这句话时笑了。这看起来是一种欢迎，但这是一种欢迎的态度。......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune106"]
[OnName num="suzune"]
'我很好。如果是为了五郎'。
[cpg cn=true]


她更进一步。'好，你是什么意思？　你是什么意思？
[cpg]


[OnName num="gorou"]
'那是...... 误听，听起来很好？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sHimari025"]
[OnName num="himari"]
'只有你姐姐是偷偷摸摸的。我和你在一起'。
[cpg cn=true]


......，我不得不把我的头从我的屁股里拿出来。
[cpg]


姑娘们说，这对我来说很好。甚至爱上了我。......
[cpg]



;//■選択肢
[switch]
[case "你不能这样做。"]
	[swap]
	[jump target="*select03_1"]
[case "我可能不得不这样做。"]
	[swap]
	[jump target="*select03_2"]
[endswitch]
第一，你不能这样做。
二，我们可能不得不这样做。



;//==============================
;//１、そんなことはできない
*select03_1|这个想法在每个人的脑海中都有。




我还是做不到。我不能这样做......
[cpg]


更不用说你的姐姐和绯红了，你的母亲更糟糕。
[cpg]


我带着这些想法回到了我的房间。
[cpg]


[jump target="*select03_3"]

;//==============================
;//２、そうするしかないかもしれない

*select03_2|思想是给大家的。



但你不能永远这样生活下去，对吗？
[cpg]


也许有一天我会和其他人在一起。......
[cpg]


带着这些想法，我离开了这个地方。
[cpg]

[stflag Cha1flg = 1]

;//後の選択肢で選択肢４が候補に



;//==============================

*select03_3|思想与谁同在


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





几天的通行证。在你知道之前，这又是一个工作日。
[cpg]




[window target=false]

[STOPBGM]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





从那时起，我必须定期提高我的心率。
[cpg]


那段日子是如此痛苦，以至于我终于想到要治好病情本身。
[cpg]


然而，我想不出有谁能与之相爱。
[cpg]


班上有一些女孩和我相处得很好，但当我想到我是否喜欢她们时，我想不出有谁......。
[cpg]


不，更重要的是，让我们撇开你是否爱上某人不谈：......
[cpg]


我至少要和一个人谈起这个问题才会感到舒服。
[cpg]


我想，如果我要谈恋爱，真的，假想一下，会是谁呢？
[cpg]



[if exp={getFlagValue("Cha1flg") == 0 }]
[endif]

[if exp={getFlagValue("Cha2flg") == 0 }]
[endif]

[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*select04_1"]
[endif]
//////////////////////////////////////////

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*C2"]
[endif]

[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*Out2C3"]
[endif]


[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "纪晓岚"]
	[swap]
	[jump target="*select04_1"]
[case "我无法选择。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]


[jump target="*select04_1"]
//////////////////////////////////////////
*Out2C3|谁对谁有感情？

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "居顺"]
	[swap]
	[jump target="*select04_1"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[case "我无法选择。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "纪晓岚"]
	[swap]
	[jump target="*select04_1"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[endswitch]

//////////////////////////////////////////
*C2|你在想谁？
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*C2C3"]
[endif]

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "纪晓岚"]
	[swap]
	[jump target="*select04_1"]
[case "太阳雨"]
	[swap]
	[jump target="*select04_2"]
[case "我无法选择。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "寿命说明"]
	[swap]
	[jump target="*select04_1"]
[case "阳光"]
	[swap]
	[jump target="*select04_2"]
[endswitch]

//////////////////////////////////////////
*C2C3|谁在你心中

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "寿命说明"]
	[swap]
	[jump target="*select04_1"]
[case "阳光"]
	[swap]
	[jump target="*select04_2"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[case "我无法选择。"]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "纪晓岚"]
	[swap]
	[jump target="*select04_1"]
[case "太阳雨"]
	[swap]
	[jump target="*select04_2"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[endswitch]








;//■選択肢
[switch]
[case "庆祝长寿"]
	[swap]
	[jump target="*select04_1"]
[case "太阳雨"]
	[swap]
	[jump target="*select04_2"]
[case "沙羽"]
	[swap]
	[jump target="*select04_3"]
[case "不能选择"]
	[swap]
	[jump target="*select04_4"]
[endswitch]

1、铃音。
2, 緋紅
3，苏纳
4、不能选择。



;//ここまでの選択で候補になっている選択肢から選択
;//ただし、候補がヒロイン１のみの場合選択肢は発生せずそのまま進行


*select04_1|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[jump storage="ep005.ks" target="*start"]


*select04_2|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[jump storage="ep006.ks" target="*start"]



*select04_3|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[jump storage="ep007.ks" target="*start"]


*select04_4|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[jump storage="ep008.ks" target="*start"]


;//==============================
