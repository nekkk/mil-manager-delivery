
*start

;###################################################################
*Ep002|被管理的痛苦。
;###################################################################

[SCENE id=2]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





看来她姐姐已经在去工作的路上了，或者说是去学院。
[cpg]


她也是个大忙人，所以我不怪她。
[cpg]


我猜她自然要比学生们来的早。
[cpg]


当我想到这一点时，有些事情我是无法理解的。......。
[cpg]


与我不同的是，我觉得我仍然是一个工作的人。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************




[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa055"]
[OnName num="sawa"]
'好吧，那就去吧。不要停下来，再回来'。
[cpg cn=true]


我不需要你来告诉我，我不会停下来的，因为晚上我又要受罪了。
[cpg]


考虑到这一点，我回过头来问候了我的母亲。
[cpg]


[OnName num="gorou"]
我走了。 "
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari067"]
[OnName num="himari"]
你走吧！"
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************


早晨的教室。我已经去上课了，越来越硬。
[cpg]


上课是你应该集中精力学习的时候。
[cpg]


但是当老师是个女人时，我就忍不住了。即使她不是那么年轻。
[cpg]


而当老师是个男人时，我的注意力就会转向我的同学们的女孩。
[cpg]


仅仅是想要悸动的感觉就使它变得如此艰难。
[cpg]


我已经很痛苦了，以至于我不得不在很早的时候就给我姐姐帮了一把。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（朝）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune059"]
[OnName num="suzune"]
'...... 等到午餐时间。你是个男孩，你必须有点耐心。"
[cpg cn=true]


[OnName num="gorou"]
'我有麻烦了，因为我是个男孩......'
[cpg cn=true]


'确实如此，'我姐姐嘟囔道。不，这并不重要。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



从那以后，我设法坚持到了午餐时间，这次我压住了她。
[cpg]


我不会再怀念它了。如果我错过这个时机，我就真的会死。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune008"]
[OnName num="suzune"]
'那好吧，我们今天去某个空教室好吗？
[cpg cn=true]


[OnName num="gorou"]
'什么，不是...... 学生咨询室？
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune061"]
[OnName num="suzune"]
'如果你用得太多，它就会很突出。
[cpg cn=true]


这是正确的，但如果你使用一个空教室，有人会找到你。......。
[cpg]



;//ブラックアウト


[VOICE f="sSuzune009"]
[OnName num="suzune"]
'好吧，我们该怎么做？　我的意思是，来吧。"
[cpg cn=true]


我有很多顾虑，但我无法阻止自己。
[cpg]


;//========================================
;//●ＣＧ（ヒロインに背後から抱きつく主人公。衝動を必死にこらえる）ev_10
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]





[OnName num="gorou"]
'姐.......
[cpg cn=true]


她从后面抱住她的妹妹。我闻到她的好味道，感觉我的脉搏加快了。
[cpg]


回想起来，我从小到大即使想做也做不到。
[cpg]


但现在，我可以毫不犹豫地宠爱她。
[cpg]


从这个意义上说，我目前的体质在一定程度上帮助了我。 ......
[cpg]


[VOICE f="sSuzune010"]
[OnName num="suzune"]
'......，这太突然了。你吓了我一跳。"
[cpg cn=true]


我觉得她也有点脸红。
[cpg]


也许她对我所做的事情有想法。
[cpg]


[OnName num="gorou"]
'对不起，我只是不能再忍受了。
[cpg cn=true]


;**【ＣＧ】 ev_10_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune011"]
[OnName num="suzune"]
'你现在是这样一个...... 无助的小女孩。
[cpg cn=true]


她似乎既感到震惊又感到尴尬。
[cpg]


[VOICE f="sSuzune012"]
[OnName num="suzune"]
'嗯，她在那方面也很可爱。
[cpg cn=true]


我很漂亮，你说，我的心再次向你走去。
[cpg]


这也是一种来自我的体质的感觉，我想...... 悸动。
[cpg]


但不管怎样，我也想有一个暗恋对象。
[cpg]


我想被我妹妹误导。我想被迷惑，所有的时间。......
[cpg]


[VOICE f="sSuzune013"]
[OnName num="suzune"]
五郎的体温，感觉是越来越高了。"
[cpg cn=true]


[OnName num="gorou"]
'是的，我不认为如此。
[cpg cn=true]


如果有人告诉我并且我意识到了这一点，我很可能会格外害羞。
[cpg]


[VOICE f="sSuzune014"]
[OnName num="suzune"]
'是的，我是。我不认为这只是我的想象'。
[cpg cn=true]


但即使是这样说的姐姐也觉得有点热。
[cpg]


;**【ＣＧ】 ev_10_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune015"]
[OnName num="suzune"]
'我现在该走了吗？　你平静下来了吗？"
[cpg cn=true]


我摇摇头。这还不够。
[cpg]


我感到一阵欲望，想把她抱得更紧，我努力压制着它。
[cpg]


[VOICE f="sSuzune016"]
[OnName num="suzune"]
'真的，你不能帮助它，孩子。
[cpg cn=true]


这不是一个冷冰冰的说法，而是一个亲切的话语，直奔主题。
[cpg]


我从母亲那里感受到了一种不同的母爱，或类似的东西。
[cpg]


[VOICE f="sSuzune017"]
[OnName num="suzune"]
'溺爱 ...... 好，让我们再保持这样的状态。
[cpg cn=true]


她这样说，并允许我做我所做的。
[cpg]


我觉得如果她对我这么好，我就不能再忍下去了。......
[cpg]


但我还是忍住了，没有再做什么。
[cpg]


[OnName num="gorou"]
'谢谢你......'
[cpg cn=true]


[VOICE f="sSuzune018"]
[OnName num="suzune"]
'不客气。看到我的兄弟陷入困境，我不能置身事外'。
[cpg cn=true]


说这话的姐姐是我的妹妹，似乎在隐瞒什么。
[cpg]


我想知道她是否会对我有所想法，或者.......。
[cpg]


[OnName num="gorou"]
'你闻起来很香.......'
[cpg cn=true]


;**【ＣＧ】 ev_10_b ***********************
[CG id=4 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune019"]
[OnName num="suzune"]
'不要闻。而且不要说任何令人尴尬的话。
[cpg cn=true]


她没有感到羞愧，而是以一种更像是嘲弄的方式说道。
[cpg]


但我想知道她是否也能闻到我。
[cpg]


我希望她在想些什么。...... 很快，午休就会结束。
[cpg]



;//ブラックアウト

快乐的时光不可避免地很快过去。
[cpg]


你越想让它永远持续下去，它就越早结束，从物理上讲。
[cpg]


而我越是希望它结束，越是痛苦的时间就要重新开始。
[cpg]


我想感到兴奋。我可以说上一整天。......
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



事后。谣言传播得很快，还是那个人在第一时间看到了？
[cpg]


[OnName num="male_student_A"]
'我看到了。你和小坂老师一起进了教室，尽管那是午餐时间。"
[cpg cn=true]


[OnName num="male_student_B"]
'你在做什么。你在做什么？
[cpg cn=true]


啊哈，我想，但我回答。
[cpg]


[OnName num="gorou"]
'不，是......，你知道我和我的老师是同姓的吗？
[cpg cn=true]


[OnName num="male_student_A"]
'哦，你是小坂五郎，对吗？你有相同的汉字吗？
[cpg cn=true]


[OnName num="gorou"]
'是的，它是。我和我的老师，我们是姐弟恋'。
[cpg cn=true]


[OnName num="male_student_B"]
'真的吗？　多么令人羡慕啊！......！"
[cpg cn=true]


[OnName num="gorou"]
这就是为什么我一直在请教诸如家庭问题之类的事情。"
[cpg cn=true]


我没有说谎。我不能很好地说出真相。
[cpg]


[OnName num="male_student_A"]
'话说回来，去一个空的教室是很奇怪的。
[cpg cn=true]


[OnName num="gorou"]
'这是我不希望任何人听到的建议。
[cpg cn=true]


我不知道，我不能帮助它。......，但这不仅仅是我的错。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園教室』（夕方）******************************************************





然后是下午的课程。在我服用时，这一次我母亲的脸开始在我脑海中闪现。
[cpg]


最后，我不能没有你们三个人。我想起了这一点。
[cpg]


我被打上了印记，我不能再和他们作对了。......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





我在回家的路上已经摇摇晃晃了。我的同学们都很担心我。
[cpg]


[OnName num="female_student_A"]
'你还好吗？　小坂君。"
[cpg cn=true]


[OnName num="female_student_B"]
'嘿，嘿，你和小坂老师是姐弟恋是真的吗？
[cpg cn=true]


考虑到谣言传播得很快，我离开了，当时就回复了。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa056"]
[OnName num="sawa"]
'欢迎回来。你已经在痛苦中了吗？　我不知道。"
[cpg cn=true]


[OnName num="gorou"]
'Ts，这很难。...... 帮助我，妈妈。
[cpg cn=true]


我说了我的想法，但妈妈笑着说
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa057"]
[OnName num="sawa"]
'漂亮的脸蛋。嘿，戈罗，你今天为什么不试着多一点耐心呢？"
[cpg cn=true]


他说。我不由自主地脱口而出。
[cpg]


[OnName num="gorou"]
'嘘，我要死了......！'
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





有人告诉我，我不应该太过频繁地敲打。
[cpg]


但一天三次是目标，这意味着即使一天两次也不会杀死你。
[cpg]


事实上，他们可能已经说了三次，以设定一个上限。
[cpg]


习惯捣鼓那么多可能是个问题。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari068"]
[OnName num="himari"]
'兄弟，你似乎过得很辛苦。我希望你的身体迅速痊愈'。
[cpg cn=true]


我吃完饭，从椅子上不稳地站起来。
[cpg]

[free time=1000]

我什么都做不了。或者说，我不能看有吸引力的女人，如绯红、我的姐姐和我的母亲。
[cpg]


最好是一个人睡。考虑到这一点，我走回了我的房间。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





我不知道我还得等多久。我母亲该睡觉了，不是吗？
[cpg]


当我这样想时，我开始失去意识。
[cpg]


我可能真的又要得病了。在这一切的中间。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[WAIT time=1100]



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa058"]
[OnName num="sawa"]
'对不起，让你久等了。到我的房间来。"
[cpg cn=true]


[OnName num="gorou"]
'......，你确定......？
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa059"]
[OnName num="sawa"]
'你可以说得出口。我应该怎么做？"
[cpg cn=true]


[OnName num="gorou"]
呃--呃!　求你了，我已经束手无策了。"
[cpg cn=true]


甚至我母亲也这样对我说。我已经没有选择了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//移植前シーンカット


那天晚上，我在母亲抚摸着我的头入睡。
[cpg]


我没有逃跑或躲藏，我让我的心怦怦直跳。
[cpg]


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa016"]
[OnName num="sawa"]
'你太可爱了。你看起来很解气'。
[cpg cn=true]

我实际上是松了一口气。我很激动，但也松了一口气。
[cpg]


之后，我筋疲力尽，直接和我母亲一起睡了。......
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





然后第二天，在妈妈醒来之前，我回到了我的房间。
[cpg]


没过多久，捣蛋的管理层就开始了。这就是我注意到它的地方。
[cpg]


我想，经常给人捶打可能会使我更加依赖它。
[cpg]


另一方面，如果我不这样做，我将很难呼吸。......
[cpg]


我在想该怎么办，但也在想，我不能再这样下去了。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari012"]
[OnName num="himari"]
'Onii-chan。今天我们也和我漂亮的小妹妹亲热一下吧'。
[cpg cn=true]


绯红说，类似这样的话。你说自己很可爱。......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari070"]
[OnName num="himari"]
'爸爸已经走了，所以...... 吁，你可以做任何你想做的事。
[cpg cn=true]


你说的 "任何东西 "是什么意思？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Suzune079"]
[OnName num="suzune"]
'别闹了。趁我不注意的时候做吧'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari071"]
[OnName num="himari"]
'Ew.'不要紧，你没看到也没关系，姐姐。
[cpg cn=true]



她姐姐的反应是合理的，但绯红似乎也预见到了这一点。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





我尴尬地回到我的房间里呆了一会儿，但仔细一想这是个坏主意。
[cpg]


这意味着我不能在早上感到兴奋。它可以持续到午餐时间。
[cpg]


我是否应该按照绯红的要求在这里做，即使我感到有点尴尬？
[cpg]


不，不，不，不，我毕竟不能在我母亲和妹妹面前这样做。......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我的冲突并没有持续很久。
[cpg]


我知道我不能什么都不做。我觉得我失去了一些东西给緋紅。......
[cpg]


我决定跟随绯红。除了她的母亲，她的姐姐冷冷地看着我。
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari072"]
[OnName num="himari"]
'为什么你不从一开始就按我说的做？你太固执了'。
[cpg cn=true]


我决定听从绯红的安排。除了她的母亲，她的姐姐冷冷地看着我。
[cpg]



;//========================================
;//●ＣＧ（倒れ込んでいる主人公にキスをしようとするヒロイン。寸止めでキスはしない）ev_12
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の家＿リビング
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari013"]
[OnName num="himari"]
'嘿，让我们接吻吧。这是你能做的最激动人心的事情'。
[cpg cn=true]


然后我们就出现了这种情况。绯红比我们早了一步。
[cpg]


看来她不仅仅是......，看着我倒下和悸动而感到有趣。
[cpg]


[OnName num="gorou"]
'你说吻的时候是认真的吗，......？
[cpg cn=true]


绯红看起来好像不是在开玩笑。而且她也是那种说到做到的人。
[cpg]


;**【ＣＧ】 ev_12_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari014"]
[OnName num="himari"]
'我是认真的。你也想让我这样做，是吗，大哥？
[cpg cn=true]


我认为这当然是最令人兴奋的事情。然而。
[cpg]


[OnName num="gorou"]
'如果我这样做，除了...... 接吻之外，我可能无法对其他事情感到兴奋。
[cpg cn=true]


[VOICE f="sHimari015"]
[OnName num="himari"]
'......，你是什么意思？
[cpg cn=true]


[OnName num="gorou"]
并不是说突然做这样的事情不好，更像是习惯了就不好了。"
[cpg cn=true]


;**【ＣＧ】 ev_12_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari016"]
[OnName num="himari"]
'嗯，这就是困扰我的地方。
[cpg cn=true]


绯红说得好像这是别人的问题，但对我来说这是一个严重的问题。
[cpg]


[OnName num="gorou"]
'我确实关心!　如果我的心脏不能再跳动，我就会死。"
[cpg cn=true]


[VOICE f="sHimari017"]
[OnName num="himari"]
'你需要放弃。我不会再让你得逞了'。
[cpg cn=true]


绯红似乎是认真的。如果她不打算让他逃跑，那么也许他就不能逃跑。
[cpg]


[OnName num="gorou"]
'等待，等待.......'
[cpg cn=true]


绯红比我更有力量，而我比绯红更有女人味。
[cpg]


;**【ＣＧ】 ev_12_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari018"]
[OnName num="himari"]
'我等不及了。来吧，把你的脸转向这边。"
[cpg cn=true]


说着，緋紅将她的脸靠近。
[cpg]


她柔软的嘴唇也同时靠近。他们几乎碰在一起。
[cpg]


我可以闻到好闻的味道。绯红就在身边，闭着眼睛。
[cpg]


而当我快到时，我就下定决心。
[cpg]


我等待着，等待着，等待着她的嘴唇接触.......
[cpg]


[OnName num="gorou"]
"...... 什么？"
[cpg cn=true]


在我等待的过程中，我没有感觉到有任何...... 嘴唇贴着我。
[cpg]


然后，她及时地把脸拉开。
[cpg]


;**【ＣＧ】 ev_12_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari019"]
[OnName num="himari"]
'呵。你感觉到扑通一声吗？
[cpg cn=true]


对，这就是我的意思。我被带去兜风了。
[cpg]


[OnName num="gorou"]
嗯，嗯。
[cpg cn=true]


她天生就是这样的人。不要把她说的话看得太重。......
[cpg]


[VOICE f="sHimari020"]
[OnName num="himari"]
那么我想我们的目标已经实现了。"
[cpg cn=true]


绯红可能是一个令人惊讶的纵容者。
[cpg]


还是她只是在挑逗我？　或者只是做他们想做的事？
[cpg]


我不是什么都知道，但我刚才的重击是相当不错的，所以我不能抱怨: ......
[cpg]


;**【ＣＧ】 ev_12_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari021"]
[OnName num="himari"]
'那好吧，祝你今天好运。因为当我的兄弟受苦时，我也会受苦'。
[cpg cn=true]


[OnName num="gorou"]
'谢谢你......'
[cpg cn=true]


我不知道谢谢你是否是正确的回应，但没有别的可说。
[cpg]



;//ブラックアウト

但是，我仍然想知道在我妹妹面前这样做是否合适。
[cpg]


我不知道在我妹妹面前这样做是否可以，但我真的很好奇。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************


而在与绯红做了这样的事情后，姐姐的冷言冷语也在等着我。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="sSuzune020"]
[OnName num="suzune"]
'这真的很不谦虚。我想知道她是否没有尴尬的感觉'。
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari089"]
[OnName num="himari"]
'嘿嘿。我想我没有'。
[cpg cn=true]


我有。所以我感到抱歉和尴尬，我觉得我不能说什么。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune082"]
[OnName num="suzune"]
'哦，好吧。我现在要走了。"
[cpg cn=true]


[OnName num="gorou"]
'是的，继续，继续。......'
[cpg cn=true]



我妹妹总是早早离开。我们在这之后。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************





过了一会儿，我和绯红不得不离开房子。
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa079"]
[OnName num="sawa"]
'再见。回头见。"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari090"]
[OnName num="himari"]
我走了。"
[cpg cn=true]


绯红欢快地回答道。我没有这个心情。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep003.ks" target="*start"]



;/////////////////////////////////////////////////////////////////////
