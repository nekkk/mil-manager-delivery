
*start

;###################################################################
*Ep007|不愿看到的沙羽之思
;###################################################################


;//３、砂羽
*select04_3|

[SCENE id=7]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


我想到了我母亲的脸。不，我知道这不会发生，但它只是突然出现在我的脑子里。
[cpg]


姐姐和绯红还是不错的。她们是妯娌，年龄相仿。
[cpg]


但是和我妈妈在一起，年龄差距相当大。不......
[cpg]


他说他是一个已婚男人。你有一个父亲。
[cpg]


而我的父亲对我来说仍然是我的父亲，......，我越想越觉得不可能。
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[window target=true]

是绯红让我在早上感到紧张。她来到我的房间，......
[cpg]


而在那之后，我对离开房子感到犹豫不决。
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari317"]
[OnName num="himari"]
'兄弟，你不是已经去了吗？　我们要迟到了。"
[cpg cn=true]


[OnName num="gorou"]
'是的，我一会儿就到.......，去吧。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari318"]
[OnName num="himari"]
'嗯。我得去看看你妈妈。
[cpg cn=true]


他们看穿了这一点。这就是事情的真相。......
[cpg]


[free time=1000]

[SE f="se003"]
;//【ＳＥ】『ドア閉まる』


绯红离开后，就剩下我和妈妈。
[cpg]


姐姐和爸爸去工作了。绯红也上了学。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa108"]
[OnName num="sawa"]
'......，你想要见我，对吗？　我想知道......"
[cpg cn=true]


他在轻松的气氛中问我。
[cpg]


我想你已经可以看出，我有一些严肃的想法。但我的母亲敢于让我这样做。
[cpg]


[OnName num="gorou"]
'我，嗯，...... 我母亲的...... 母亲和...... 嗯...'
[cpg cn=true]


我不知所措了。我不知道该说些什么。
[cpg]


我觉得如果我说出来，就意味着结束了。在这样的时候。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa109"]
[OnName num="sawa"]
'我几乎可以看到它。也许我离得太近了--'
[cpg cn=true]


我几乎总是能看出来，我母亲曾告诉我。还有就是我离得太近了。......
[cpg]


[OnName num="gorou"]
'嗯，嗯，......，这是...'
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa026"]
[OnName num="sawa"]
'我不能帮助它。如果你说你喜欢它。
[cpg cn=true]


......，轻松通过。不，这不是好事。
[cpg]


[OnName num="gorou"]
'嘿，等一下，等一下!　我是认真的。"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa027"]
[OnName num="sawa"]
'不管怎样，今天晚上见。如果我不早点到那里，我上学就要迟到了。
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





所以我们去了学校。
[cpg]


但我已经在空中了。尽管我在白天会看到我的妹妹，......
[cpg]


即使考虑到这一点，我也无法保持冷静。想到我的母亲会为我这样做。
[cpg]


这一点就使我痛苦地感到紧张。我以前从来没有过这样的暗恋。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************



而在晚上放学的时候。我感到很慌张。
[cpg]


妈妈说："我也没办法，是吧？"这是真的吗？
[cpg]


我有些不讲情面。自然，我必须在爸爸回家之前和他谈谈。
[cpg]


爸爸和妈妈有单独的房间，所以他们没有机会撞到一起。
[cpg]




;//ブラックアウト


[window target=false]

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



当我在想这些的时候，我到了家。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Himari319"]
[OnName num="himari"]
欢迎回家。你看起来棒极了。"
[cpg cn=true]


它是什么颜色？它是红色还是蓝色？这并不重要。
[cpg]

[free time=1000]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa028"]
[OnName num="sawa"]
'嗯。你看起来很难受的样子。很好。"
[cpg cn=true]


拍了拍我的头，我被带到了母亲的房间。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




只要有她在我身边，握着我的手，就足以让我感觉到我要失去它。
[cpg]


我不禁感到，我的心被控制得那么厉害。
[cpg]



;//========================================
;//●ＣＧ（ヒロインが寝ている主人公に近づく。穏やかに微笑んでいる→心配そうな表情に）ev_36
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================



[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sSawa029"]
[OnName num="sawa"]
'......，我想知道像这样在你身边是否会让你紧张。
[cpg cn=true]


我很激动。我点了点头，回答道。
[cpg]


[OnName num="gorou"]
'是的。......，它非常、非常平静。
[cpg cn=true]


妈妈撅了一会儿嘴，然后笑了一下。
[cpg]


[VOICE f="sSawa030"]
[OnName num="sawa"]
'嗯。平静，是这样吗？　你不应该感到兴奋吗？"
[cpg cn=true]


但我只能这么说。
[cpg]


也许我毕竟不是想悸动，我是想冷静下来。
[cpg]


也许是我一直有呼吸困难的事实，也许是我不能得到一个暗恋的对象，我就像焦虑的.......。
[cpg]


如果是这样的话，也许我的体质只要做这个就能治好。
[cpg]


只要在妈妈身边，我就觉得很有成就感。
[cpg]


;**【ＣＧ】 ev_36_a ***********************
[CG id=16 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa031"]
[OnName num="sawa"]
'哦，好吧。我想做你想让我做的事。
[cpg cn=true]


[OnName num="gorou"]
'谢谢你。妈妈。"
[cpg cn=true]


[VOICE f="sSawa032"]
[OnName num="sawa"]
'......，我真的很担心你。我也把五郎当作我的孩子。
[cpg cn=true]


然后，突然，他看起来很担心。
[cpg]


;**【ＣＧ】 ev_36_b ***********************
[CG id=16 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa033"]
[OnName num="sawa"]
'我想如果你为我感到兴奋，那也很好。
[cpg cn=true]


[VOICE f="sSawa034"]
[OnName num="sawa"]
'如果这意味着他不必受苦，我愿意为五郎做任何事。
[cpg cn=true]


我不知道你这么看重我。她给人的印象是平静的，所以我有点吃了一惊。
[cpg]


[OnName num="gorou"]
'我很高兴.......非常感谢你。"
[cpg cn=true]


我这样说，知道这是一个愚蠢的说法，但想让他知道我很感激。
[cpg]


我努力使自己的脸色尽可能严肃，声音也尽可能严肃。我试图传达我的感受，但......
[cpg]


但我妈妈看起来特别恼火。
[cpg]


出于某种原因，她看起来更苦恼，这就是她在我看来的样子。
[cpg]


[VOICE f="sSawa035"]
[OnName num="sawa"]
'如果五郎说他喜欢我，那么我想这也是可以的。这不是谎言'。
[cpg cn=true]


妈妈小心翼翼地选择她的语言，并逐渐告诉我她的感受。
[cpg]


;**【ＣＧ】 ev_36_c ***********************
[CG id=16 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa036"]
[OnName num="sawa"]
'我不知道该怎么做。他绝对是我的孩子，但我也喜欢他'。
[cpg cn=true]


我明白了。......，我不知道我让你这么想。
[cpg]


[OnName num="gorou"]
......."
[cpg cn=true]


我是不是太不敏感了？我面对的是一个儿子，尽管是一个继子。
[cpg]


我把我妈妈逼到了绝境。我已经意识到了这一点。
[cpg]


我想我的行为可能太自私了，但我仍然无法停止...... 这种感觉。
[cpg]


[OnName num="gorou"]
我很抱歉。但我不能停下来。"
[cpg cn=true]


我不知道该怎么做。但如果我把这种焦虑大声表达出来，会不会让我母亲更加恼火？
[cpg]


那么我想最好是说我想做什么。
[cpg]


[OnName num="gorou"]
我想吻你。
[cpg cn=true]


仿佛是为了掩饰，我说。她点了点头。
[cpg]


我看到她闭上了眼睛，我走近了一些。......
[cpg]


这一步将是任何理智的人都不会采取的措施。但我早已经疯了。
[cpg]


[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

...... 而且。
[cpg]


我亲吻了我母亲的嘴。我迈出了明显不应该迈出的一步。
[cpg]


[OnName num="gorou"]
......"


;//ＣＧ
;**【ＣＧ】 ev_36_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sSawa037"]
[OnName num="sawa"]
'呼。不要做这种表情。
[cpg cn=true]


我本来会是什么样子？　他看起来很遗憾吗？
[cpg]


[VOICE f="sSawa038"]
[OnName num="sawa"]
我有没有好好地敲打你？"
[cpg cn=true]


你这样一说，我不激动是假的。然而。
[cpg]


[OnName num="gorou"]
'再来一次......'
[cpg cn=true]


[VOICE f="sSawa039"]
[OnName num="sawa"]
'不，你不能。今天就到此为止。你已经习惯了重击，这对你没有好处，是吗？
[cpg cn=true]


[OnName num="gorou"]
嗯，是的，但是...
[cpg cn=true]


[VOICE f="Sawa132"]
[OnName num="sawa"]
'哦，上帝。不要太执着，否则女孩们会讨厌你！'
[cpg cn=true]


女孩，是否包括我的母亲？
[cpg]


这样问很不礼貌，所以我闭嘴，退了出去。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





我不想让我的母亲讨厌我。我不想为此做任何事情。
[cpg]


我很矛盾，不知道它们是否有冲突。
[cpg]

[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[SE f="se009"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





早上，我无法正常看到母亲的脸。
[cpg]


看到这一点，我姐姐和绯红似乎也感觉到了。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Himari320"]
[OnName num="himari"]
'你越过了某种界限，不是吗？　大哥哥。"
[cpg cn=true]


[OnName num="gorou"]
'...... 那是......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune325"]
[OnName num="suzune"]
'......，我不会说什么。你们两个需要在自己之间解决这个问题。
[cpg cn=true]


这就像已经说了。这很令人厌恶。
[cpg]


但我不能帮助它。我喜欢我的母亲。
[cpg]


[free time=1000]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa133"]
[OnName num="sawa"]
不要过多地折磨五郎。是我推着你去做的。
[cpg cn=true]


他将与我一起承担。如果爸爸在这里，他就会有很多麻烦。
[cpg]


我很高兴我爸爸是早早离开家的人。......，我完成了我的早餐。
[cpg]


;//ブラックアウト

[window target=false]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************


[OnName num="gorou"]
我走了。......
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa134"]
[OnName num="sawa"]
'是的。祝你有个愉快的一天。
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari321"]
[OnName num="himari"]
我走了。"
[cpg cn=true]


......，我感到无法形容。我想在我母亲的身边。
[cpg]


但这是一个未实现的愿望。
[cpg]


我是她的儿子，尽管她是我的继女，而且我首先要去学院。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[window target=false]

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[window target=true]


我打算去学院，同时有点心事重重。
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="male_student"]
我不知道我的感觉如何，但我不确定。你不觉得今天的我有些不同吗？"
[cpg cn=true]


[OnName num="gorou"]
'我不...... 知道，我也不认为，但......'
[cpg cn=true]


[OnName num="male_student"]
'我们出去了!　我的春天也已经来临了，哈哈。"
[cpg cn=true]


[OnName num="gorou"]
'是的。对你有好处。"
[cpg cn=true]


[OnName num="male_student"]
'多么单薄的回应啊。当然，我们甚至还没有亲吻过'。
[cpg cn=true]


...... 我吻了一个我甚至没有约会的人。而且是和我的岳母一起。
[cpg]


即使我想说，我也不能这么说。在此期间，是我妹妹等我的时候了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_03_2_up.ui" time=1000]
[WAIT time=2000]

还有午餐时间。当我们单独在一起时，我妹妹对我说。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune326"]
[OnName num="suzune"]
'......，你的母亲是我们真正的母亲。所以......."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune327"]
[OnName num="suzune"]
'不要大意，不要破坏我们的家庭。
[cpg cn=true]


他们说。这是个相当严厉的词。
[cpg]


她说'亲生母亲'的方式也有点刺耳。但我没有选择。
[cpg]


我就像一个异物。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





我的体质如果不与别人相爱，就无法治愈。
[cpg]


我想，我的姐姐和绯红也是可能的伙伴。
[cpg]


但我并不想这么做。我爱的人是我的母亲。
[cpg]


我想不出别的办法。我喜欢我的母亲。
[cpg]


现在我说出来了，我明白为什么我姐姐告诉我不要拆散这个家庭。
[cpg]


我姐姐告诉我的话在我脑中回荡。
[cpg]


;//ブラックアウト


[window target=false]

[STOPBGM]

[BG f="b_04_3_up.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa135"]
[OnName num="sawa"]
'欢迎回来。你怎么样，已经很辛苦了吗？
[cpg cn=true]


这已经很困难了。我当时没有状态去撒谎。
[cpg]


[OnName num="gorou"]
'...... 是的。我想和我妈妈在一起。好吗？"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa136"]
[OnName num="sawa"]
'当然了。我已经决定我要做晚上的--'
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



然后我被带到了我妈妈的房间。
[cpg]


只要来到这里，就觉得是一种解脱.......
[cpg]


;//========================================
;//●ＣＧ（寝ているヒロインに迫る主人公。抱きしめ合う感じ）ev_37
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================


[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h2"]
;**【ＣＧ】 ev_37_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSawa040"]
[OnName num="sawa"]
'来吧，我给你一个拥抱。
[cpg cn=true]


当我看到妈妈张开双臂时，我都快哭了。
[cpg]


我想告诉她我现在的一切感受。
[cpg]


但我不能说出来，我还是觉得自己要哭了。
[cpg]


我不知道该怎么做。我甚至不知道我是否应该通过这种爱。
[cpg]


在我看来，我爱我的母亲是毫无疑问的。
[cpg]


而且更重要的是，我不想惹恼我的母亲。
[cpg]


[OnName num="gorou"]
...... 我仍然爱我的母亲。
[cpg cn=true]


这句话的声音很小，连我都感到惊讶。我知道我不应该说这么多。
[cpg]


如果我在这里说，我想做你的女朋友，那就完了。
[cpg]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa041"]
[OnName num="sawa"]
'对。我知道。你不必什么都说'。
[cpg cn=true]


我不是想让你说出所有的事情。这将有助于我。
[cpg]


[OnName num="gorou"]
'...... 是的。
[cpg cn=true]


[VOICE f="sSawa042"]
[OnName num="sawa"]
'你今天一定很痛苦。破坏它也没关系'。
[cpg cn=true]


我认为有些话，如果你说出来，你就不能收回。如果我母亲能让他们闭嘴，那将是相当有帮助的。
[cpg]


我没有说什么，就拥抱了她。
[cpg]


[OnName num="gorou"]
'你闻起来像我母亲。
[cpg cn=true]


她并不讳言这一点。她肯定与她的姐姐和绯红不同。
[cpg]


妈妈认为我不会再靠近了。
[cpg]


;**【ＣＧ】 ev_37_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa043"]
[OnName num="sawa"]
'好吧，...... 吾郎将永远是一个被宠坏的孩子。
[cpg cn=true]


这个温柔的声音使我无法压制我一直在假装的东西，我一直在忍耐的东西。
[cpg]


我想让你成为我的全部。说这一个字很容易。
[cpg]


但......，我不知道我是否真的能做到这一点。
[cpg]


不仅我不知道，而且连她也可能不知道。
[cpg]


如果是这样，我说的话就会无从谈起。
[cpg]


[VOICE f="sSawa044"]
[OnName num="sawa"]
'怎么了？　你看起来像要哭了。"
[cpg cn=true]


她现在不是我唯一的妈妈。我不禁想到了这一点。
[cpg]


她看起来也像是要哭了。我真的喜欢上了我的妈妈。
[cpg]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa045"]
[OnName num="sawa"]
'我想知道她是否有什么可悲之处，而不仅仅是痛苦。
[cpg cn=true]


这不是悲伤，是难过。目前的这种情况是可悲的。
[cpg]


这不再是好事，我知道，这就是为什么我不能停止。
[cpg]


[OnName num="gorou"]
'妈妈，......，我已经下定决心了。
[cpg cn=true]


妈妈看起来有点担心。
[cpg]


也许她以某种方式知道她将被告知什么。
[cpg]


;**【ＣＧ】 ev_37_b ***********************
[CG id=17 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa046"]
[OnName num="sawa"]
'决定了什么？
[cpg cn=true]


[OnName num="gorou"]
'你知道他们是怎么说我的，如果我不谈恋爱，我的体质就不会安定下来。
[cpg cn=true]


妈妈显然知道一切。尽管如此，她只是带着相貌听我说话。
[cpg]


[VOICE f="sSawa047"]
[OnName num="sawa"]
'是的。怎么了？"
[cpg cn=true]


一旦我说出这句话，就没有回头路可走了。这是我经常思考的问题。
[cpg]


[OnName num="gorou"]
'我喜欢......，你的母亲。
[cpg cn=true]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa048"]
[OnName num="sawa"]
'是的。我知道。"
[cpg cn=true]


[OnName num="gorou"]
'不，不。你的母亲还不明白'。
[cpg cn=true]


[OnName num="gorou"]
当我说我爱你时，我是指爱。"
[cpg cn=true]


;//移植前シーンカット

;//ブラックアウト



我终于说出来了。喜欢 "这个词与 "爱 "这个词有不同的含义。
[cpg]


短暂的沉默。然后妈妈反问道。
[cpg]


;**【ＣＧ】 ev_37_b ***********************
[CG id=17 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sawa153"]
[OnName num="sawa"]
'你是认真的吗？　你知道这意味着什么。"
[cpg cn=true]


我想我知道。我想我知道。......
[cpg]


[VOICE f="Sawa154"]
[OnName num="sawa"]
'也许我们会被分开。你准备好了吗？"
[cpg cn=true]


对。这是可能摧毁家庭的事情。
[cpg]


你的妹妹会怎么想？而且，即使绯红不认为有什么，最大的问题是爸爸。
[cpg]


我又得迷路了。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



爸爸通常会回家吃饭。
[cpg]


[OnName num="father"]
'铃音。这些天的工作怎么样？"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune328"]
[OnName num="suzune"]
嗯，......，还有很多地方我不够强壮。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari322"]
[OnName num="himari"]
'你作为一个姐妹，力量并不弱。我有点不适应'。
[cpg cn=true]


他们正在谈论这个问题。正常的、亲子的对话。
[cpg]


但我......，感觉有点被疏远。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



之后，我邀请绯红和她的妹妹到我的房间。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari323"]
[OnName num="himari"]
'...... 怎么了？　你的脸上有一种神秘的表情'。
[cpg cn=true]


[OnName num="gorou"]
是的，好的。......
[cpg cn=true]


我不知道该如何谈及这个话题，这时绯红说。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Himari324"]
[OnName num="himari"]
'你是在说你的母亲吗？　可能，是的。"
[cpg cn=true]


[OnName num="gorou"]
'......，你完全知道我的意思。你仍然不是绯红的对手'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune329"]
[OnName num="suzune"]
'你是什么意思？　我对事情的发展不满意。"
[cpg cn=true]


[OnName num="gorou"]
我仍然想治愈这种体质。为此，我希望能像我的母亲一样。"
[cpg cn=true]


这位典型的姐姐退缩了。她就是那个曾经钉死我的人。
[cpg]


但绯红是个酒鬼。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari325"]
[OnName num="himari"]
'不知怎的，我知道这将会发生。是的，我知道。
[cpg cn=true]


她仍然感到困惑。但我一直在说话。
[cpg]


[OnName num="gorou"]
'我很抱歉，姐姐，......，我为绯红和你姐姐为我做的事感到高兴，但这并不能解决什么。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune330"]
[OnName num="suzune"]
'...... 是的。原来如此。......"
[cpg cn=true]


他们会接受吗？你仍然觉得你没有完全理解它。......
[cpg]


但这是你必须花时间去了解的事情。
[cpg]


毕竟，她是她姐姐和绯红的真正母亲。
[cpg]


这是一种相当复杂的关系，但我已经爱上了我的妈妈。我再也忍不住了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト








到了晚上，我妹妹被说服了。
[cpg]


最后，她似乎支持我。
[cpg]

[BG f="b_06_4.ui" time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]

[WAIT time=2000]

[VOICE f="Suzune331"]
[OnName num="suzune"]
'不要太鲁莽，.......我现在真的很关心我的家人"。
[cpg cn=true]


想了想后，他们各自回到自己的房间睡觉去了。
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[OnName num="gorou"]
'...... 哦，那个？　妈妈。"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa049"]
[OnName num="sawa"]
'绯红告诉我。她说我应该是早上给你一个刺激的人。
[cpg cn=true]


[OnName num="gorou"]
'嗯，是的，......，我为你感到高兴，但是，呃...'
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSawa050"]
[OnName num="sawa"]
我们会想念学校的。
[cpg cn=true]


当我陷入沉思时，我的母亲走近了。
[cpg]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト
;//移植前シーンカット

[window target=true]


她只是抚摸着我的头，拥抱着我。她没有吻我。
[cpg]


尽管如此，我还是足够兴奋。因为她是我最喜欢的人。
[cpg]



[window target=false]


[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************


然后我不得不马上离开家，所以我跳过了早餐。
[cpg]


[OnName num="gorou"]
'好吧，那我就走了。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa174"]
[OnName num="sawa"]
'祝你有个愉快的一天。晚上也要向......'打招呼。
[cpg cn=true]


这是我的台词，不过。考虑到这一点，我离开了家。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_01_1.ui" time=1000]
[WAIT time=1000]


一路走到学院。没有什么特别的，只是一个普通的日子。
[cpg]


但我不得不考虑一些事情。
[cpg]


我可能会破坏我的家庭。无论我是否准备这样做。
[cpg]


也许有办法可以防止这种情况发生。但也有意外情况。
[cpg]


我得考虑一下。我不能停留在这种宪法中。
[cpg]




[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune332"]
[OnName num="suzune"]
......，就不能是我吗？"
[cpg cn=true]

;//＠昼に空き教室で抜いてもらってから、姉さんにそう言われた。


[OnName num="gorou"]
这不像是没有，更像是......，必须是你。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Suzune333"]
[OnName num="suzune"]
如果我告诉你，我也喜欢你呢？
[cpg cn=true]


[OnName num="gorou"]
......"
[cpg cn=true]


他的脸上带着严肃的表情。他是认真的吗？或者是......
[cpg]


他是否为了保护他的家人而强迫自己这么说？我无法决定。
[cpg]


[OnName num="gorou"]
'我还是不行。我爱我的母亲 .......'
[cpg cn=true]

敢于使用强烈的语言。她看起来很懊恼。
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune334"]
[OnName num="suzune"]
'我看......，我不能阻止你，是吗？
[cpg cn=true]


她说她会支持我，但我认为她心中仍有一些犹豫。
[cpg]


这并不难理解她的感受。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************


我也仍然迷茫。我经常怀疑我做的事情是否正确。
[cpg]


我们之间存在着明显的年龄差异，这一点我不必再考虑了。
[cpg]


更重要的是，她是抚养我长大的父母。
[cpg]


而且我爸爸也是父母，尽管对我来说是继父母。......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_04_3.ui" time=1000]
[WAIT time=1000]


我可能正在犯一个可怕的错误。我认为这一点。
[cpg]


但我的母亲轻轻地把我包了起来。
[cpg]


;//移植前シーンカット

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa051"]
[OnName num="sawa"]
'欢迎回来，戈罗。你还在痛苦中，是吗？"
[cpg cn=true]



[OnName num="gorou"]
是的。......
[cpg cn=true]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


我还在向我父亲隐瞒。我知道我不可能永远隐藏它。
[cpg]


我姐姐和绯红也对此事保持沉默，但我想它不能永远这样下去。......
[cpg]


[window target=false]


[STOPBGM]

[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


全家一起吃过晚饭后，我回到了自己的房间。
[cpg]


这时我把我的母亲带过来和她谈。......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa052"]
[OnName num="sawa"]
'我想知道。你痛苦是因为你想再捣鼓一下吗？
[cpg cn=true]


妈妈甚至似乎在淡化它。
[cpg]


我，我觉得我看起来很严肃。我想知道它是否已经完成？
[cpg]


[OnName num="gorou"]
'我仍然爱你，妈妈。爱你还不够'。
[cpg cn=true]


尽可能的直接。就像你不关心你的长相一样。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sawa193"]
[OnName num="sawa"]
'不要.......如果你的父亲发现了怎么办？"
[cpg cn=true]


[OnName num="gorou"]
'我会确保他们不会发现的。我保证。"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sawa194"]
[OnName num="sawa"]
'是的。......，我知道。五郎是认真的，不是吗？"
[cpg cn=true]


妈妈的反应是，她好像明白了什么。
[cpg]


她接着说。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa195"]
[OnName num="sawa"]
'你是认真的，对吗？　我们不能结婚，无论如何都不能。"
[cpg cn=true]



[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSawa053"]
[OnName num="sawa"]
'我想你，而不是我，会被你的感情所约束。你还是可以接受的，不是吗？
[cpg cn=true]


我点了点头。我已经受够了那方面的冲突。
[cpg]


然后我的母亲看起来有点烦恼，说。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSawa054"]
[OnName num="sawa"]
'好吧。
[cpg cn=true]


;//ブラックアウト

我妈妈认为她也喜欢我。我仍然不知道这是否是一种浪漫的感觉。
[cpg]


但我对这一点没有意见。这不是我应该担心的事情。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSawa055"]
[OnName num="sawa"]
唯一的另一件事是，我不会以...... 吾郎而告终。
[cpg cn=true]


对。如果我连这个都接受，那将是一个好故事。
[cpg]


我很早就已经接受了这个事实。我已经知道这是禁忌之爱。
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





第二天早上。早上从绯红变成了我的母亲。
[cpg]


而对于我的母亲，我打算做一些与以前不同的事情。
[cpg]


我告诉她，我是说，......，我想吻她。
[cpg]


[OnName num="gorou"]
我是...... 紧张，我就知道。"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa199"]
[OnName num="sawa"]
'我可能比五郎更紧张。
[cpg cn=true]


母亲说这话时笑了。你看起来并不紧张。
[cpg]



;//移植前シーンカット

;//ブラックアウト

[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

我们变得更接近一点。距离消失了。
[cpg]


我们的嘴唇互相接触。初吻的感觉被不道德所覆盖。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『街』（昼）******************************************************



时间过去了。所有的时间，只要有可能，我都和我的母亲在一起。
[cpg]



[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d2"]

;//【ＢＧ】『街』（夜）******************************************************


而......，这是值得的，我的体质逐渐平静了下来。
[cpg]


;//ブラックアウト

[window target=false]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


我深信不疑。我不能以任何方式结婚。
[cpg]


我们甚至不能像正常的恋人那样行事。但这也没关系。
[cpg]


我们只是秘密地爱着对方，不管我们走多远。
[cpg]


而对我母亲来说，最重要的人必然是我的父亲。
[cpg]


当我看到我的母亲若无其事地微笑时，我就是这么想的。
[cpg]


这是一种无论如何都不会有结果的爱。但我认为它已经走到了尽头。
[cpg]


;//ブラックアウト


[window target=false]


[STOPBGM]

[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


随着时间的推移，我的情况继续得到改善。
[cpg]


我不必再去医院了。
[cpg]


但你可以说，问题是从这里开始的。
[cpg]


我想我和我母亲之间的爱必须继续下去。否则，我的体质可能会回来。
[cpg]


然后我将永远这样，直到我爱上别人。
[cpg]


我也没有想到我现在会爱上别的人。
[cpg]


换句话说，结果就像我的...... 母亲说的那样，我将把自己绑在自己身上。
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』

[WAIT time=1500]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa217"]
[OnName num="sawa"]
'五郎。我可以和你说句话吗 - ......."
[cpg cn=true]


[OnName num="gorou"]
'怎么了？　你想我了吗？"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa056"]
[OnName num="sawa"]
'嗯。你得说出来'。
[cpg cn=true]


尽管我的体质已经平静下来，不需要再紧张了，但我的母亲宁可尝试触摸我。
[cpg]


这是我的错。我无法拒绝，所以我服从了。
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植前シーンカット

当我和母亲在一起时，仅这一点就让我感到安全。
[cpg]


在这个意义上，我也不能说不。
[cpg]


;//ブラックアウト


[window target=false]


[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="gorou"]
我不会对她说不的。...... 我们不能明天改天再谈这个问题吗？　如果你呆得太晚，人们可能会认为你很奇怪。"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa235"]
[OnName num="sawa"]
'是的，但...... 好。我会耐心等待。"
[cpg cn=true]


妈妈说这话时似乎真的很喜欢我。
[cpg]


我是如此尴尬、高兴和...... 歉意，以至于我无法直视她。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



[OnName num="gorou"]
'好吧，那我就走了。
[cpg cn=true]


我和绯红一起离开家，向母亲问好。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari327"]
[OnName num="himari"]
'...... 嘿，大哥哥。我和我哥哥的关系会发生什么变化？"
[cpg cn=true]


[OnName num="gorou"]
你说的'会发生什么'是什么意思......？"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari094"]
[OnName num="himari"]
'你将成为你母亲喜欢的人。我应该叫你爸爸吗？
[cpg cn=true]


我认为他是在开玩笑。这似乎是无辜的绯红。
[cpg]



[OnName num="gorou"]
'Ze，永远不要这样叫我。......
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『歩く』



在这样的谈话之后，我们在城市中漫步。
[cpg]


我们前往学院。我没有再要求我姐姐为我做任何事情。
[cpg]




[window target=false]


[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="male_student"]
'哦，不，我前几天终于吻了她。
[cpg cn=true]


[OnName num="gorou"]
'...... 是的。
[cpg cn=true]


他就是那个很久以前为有女朋友而大惊小怪的人。
[cpg]


我想，我妹妹会叫我爸爸或什么的，我很不能这么说。
[cpg]




[window target=false]


[STOPBGM]

[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（夕方）******************************************************


还有一次。我是被一个与我没有特别关系的女学生叫来的。
[cpg]



[OnName num="female_student"]
'...... 小坂君，你有女朋友吗？
[cpg cn=true]


[OnName num="gorou"]
'为什么不呢？　她是...... 嗯，......"
[cpg cn=true]


一个可能对我有好感的女孩。当然，我都是为了我的妈妈。
[cpg]


但我甚至不能说我有一个女朋友。而且她不是我的妻子。
[cpg]


[OnName num="gorou"]
我不知道是否有我喜欢的人......."
[cpg cn=true]


[OnName num="female_student"]
'我明白了。对'。
[cpg cn=true]


最后的措辞是这样的。我不知道，也许我可以和她约会。
[cpg]


但我所拥有的是我的母亲。我选择了她，而不是我姐姐或绯红。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『歩く』



我们又步行回家，一吃完晚饭，就到了晚上。
[cpg]


我这样说听起来很无味，但有一件事已经改变了很多。
[cpg]



[window target=false]


[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


那就是我母亲在晚上来找我。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSawa057"]
[OnName num="sawa"]
...... 吾郎。"
[cpg cn=true]


他们叫我的方式和以前一样，但我还是很高兴。
[cpg]


我想更多地靠近你。这就是我的想法。
[cpg]


;//＠それから何度か交わった後、俺達は別れた。



然后每个早晨都会到来。
[cpg]


[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我确信，你是唯一能在我身边的人。我想知道我母亲的情况。
[cpg]


我不知道我母亲的情况，但我不知道我是否爱上了我父亲。
[cpg]


但这是一种无法以任何方式实现的爱。我们不可能成为恋人。......
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）

[BG f="b_01_1.ui" time=1000]
[WAIT time=1000]

我吃完早餐，走出前门。向向日葵的相反方向前进。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari329"]
[OnName num="himari"]
'回头见，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'哦。到时见'。
[cpg cn=true]

[free time=1000]

;//【ＢＧ】『街』（朝）


我在一种昏迷中度过了我的日子。
[cpg]


不是女朋友或情人，但绝对是我爱的人。
[cpg]


这是最幸福但不寻常的幸福。
[cpg]



[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_02_1.ui" time=1000]

[WAIT time=2000]

[BG f="b_02_2.ui" time=1000]

[WAIT time=2000]


[BGM f="bg_d2"]
[BG f="b_02_3.ui" time=1000]

[WAIT time=1000]


然后我去了学院，上课，放学。
[cpg]

;//【ＢＧ】『学園教室』（夕方）


[OnName num="female_student"]
'......Kasaka-kun。哦，你知道，......."
[cpg cn=true]


[OnName num="gorou"]
...... 什么？"
[cpg cn=true]


有一天的女学生。是她问我是否喜欢某人。
[cpg]


[OnName num="female_student"]
'我喜欢小坂君。那......，你想和我出去吗？
[cpg cn=true]


我遇到了麻烦。也许我可以在这里转移到一个体面的生活。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



最后，我带着待定的答案离开了。
[cpg]


我不能马上给你一个答案。我不能和她出去，直到我和我妈妈的关系结束。
[cpg]


考虑到这一点，我走回了我的房子。......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="gorou"]
'......，这就是所发生的事情。妈妈。"
[cpg cn=true]


我按照学院的情况讲述了这个故事。然后妈妈说。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa252"]
[OnName num="sawa"]
'你可以和他们一起出去，不是吗？　我不会阻止你。"
[cpg cn=true]


[OnName num="gorou"]
为什么......，我喜欢你？"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa253"]
[OnName num="sawa"]
'我很清楚这一点。但你甚至不能让我在你的余生中做你的女朋友'。
[cpg cn=true]


...... 这可能确实是事实。
[cpg]


我不知道如果发生这种情况，我爸爸会怎么样。
[cpg]


妈妈也可以爱爸爸。
[cpg]


[OnName num="gorou"]
'...... 了解。我会考虑的。"
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************


然后我忍住不回应那个在学校向我表白的女孩。
[cpg]


我们继续保持着不太相爱的关系，开始是朋友。
[cpg]


她似乎真的很喜欢我，而且似乎觉得这很令人沮丧。
[cpg]


但我就是我，我从未失去对我母亲的爱。
[cpg]


我不觉得我可以适当地爱这个刚刚向我表白的女孩。
[cpg]



;//ブラックアウト



;//========================================
;//●ＣＧ（主人公に膝枕するヒロイン）ev_44
;//人物１：ヒロイン３
;//服装１：私服
;//場所　：主人公の家＿リビング
;//時間　：昼
;//備考　：妊娠していない状態に変えてください
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』


[BGM f="bg_h1"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]



尽管这些暧昧的日子，我还是很开心。
[cpg]


无论我过什么样的生活，我的母亲都会支持我。
[cpg]


我觉得这就是我需要的一切。我很有成就感。
[cpg]


[VOICE f="sSawa058"]
[OnName num="sawa"]
'...... 你后悔吗？　五郎。"
[cpg cn=true]


但他看起来肯定只是有点失落。妈妈开始担心了。
[cpg]


[OnName num="gorou"]
'不可能。不可能的'。
[cpg cn=true]


这些话自然而然就说出来了。我想这是因为我是真心的。
[cpg]


这不仅仅是一个口号。我完全没有遗憾。
[cpg]


;**【ＣＧ】 ev_44_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa059"]
[OnName num="sawa"]
'我很好，我不在乎我和谁相爱。你喜欢我安抚你的体质，这才是最重要的。
[cpg cn=true]


他说了一句话，让我有点难过。他说他现在不能回去了。
[cpg]


[OnName num="gorou"]
'那是不可能的事。我真的爱上了你，我的体质已经稳定下来了'。
[cpg cn=true]


相反，我的体质已经稳定下来的事实证明，我喜欢我的母亲。
[cpg]


在确定爸爸、姐姐和绯红已经离开后，我说。
[cpg]


[OnName num="gorou"]
'我爱你，.......苏纳赫恩"。
[cpg cn=true]


我突然叫她的名字，但我母亲不会感到沮丧。
[cpg]


;//;**【ＣＧ】 ev_44_b ***********************
;//[CG id=18 index=2 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="sSawa060"]
[OnName num="sawa"]
'是的。我也是'。
[cpg cn=true]


我喜欢这种关系。我想一直呆在她身边。
[cpg]



;//ブラックアウト

我希望它能永远继续下去，但我不知道这是否会发生。
[cpg]


也许我的立场会随着时间的推移而改变，当我工作的时候，我就会想建立一个家庭。
[cpg]


但......，目前还是不错的。因为我想继续做我母亲的孩子。
[cpg]


[SCENE id=11]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン３ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================
