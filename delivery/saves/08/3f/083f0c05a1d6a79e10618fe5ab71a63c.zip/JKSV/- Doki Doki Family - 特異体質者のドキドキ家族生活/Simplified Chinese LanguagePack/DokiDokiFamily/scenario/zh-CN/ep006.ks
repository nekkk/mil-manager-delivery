
*start

;###################################################################
*Ep006|珍惜阳光
;###################################################################

;//==============================
;//２、ひまり
*select04_2|珍惜阳光


[SCENE id=6]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


我认为...... 绯红。虽然可依赖，但并不讨人喜欢。
[cpg]


但如果你问我喜欢谁，我喜欢绯红。
[cpg]


她就像一个孩子，但也有母性。
[cpg]


她有一部分把我玩弄于股掌之间，我已经越来越喜欢她了。
[cpg]


我不知道我是否有欺负人的气质，喜欢这样的人。
[cpg]


但我不介意和绯红在一起。......
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[WAIT time=1000]



[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari127"]
[OnName num="himari"]
'One-chan。这是早晨的乐趣！"
[cpg cn=true]


当我在思考这个问题时，绯红来了。
[cpg]


[OnName num="gorou"]
'啊，啊。是的。.......'
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari128"]
[OnName num="himari"]
'怎么了？你看起来不舒服。
[cpg cn=true]


[OnName num="gorou"]
'不是我心情不好，是......，我需要和你谈点事情。
[cpg cn=true]


他重新转向向日葵。然后他切入正题。
[cpg]


[OnName num="gorou"]
'...... 你知道他们怎么说吗，当你爱上一个人时，你的体质就会安定下来？
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari129"]
[OnName num="himari"]
'我知道。我知道医生是怎么说的'。
[cpg cn=true]


[OnName num="gorou"]
'那么，...... 緋紅呢？
[cpg cn=true]


我很谨慎地问道。但绯红似乎已经猜到了。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari027"]
[OnName num="himari"]
'嗯，是的。如果是和我哥哥一起，我完全没问题。我想我也会很高兴。......"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari028"]
[OnName num="himari"]
'如果我们在一起，病情没有消失，你打算怎么做？
[cpg cn=true]


[OnName num="gorou"]
'你打算怎么做？......，这当然是令人不安的。
[cpg cn=true]


而我想的是我自己，但绯红似乎在想一些不同的事情。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Himari132"]
[OnName num="himari"]
'你可能会和其他人欺骗我。有了这样的宪法，'。
[cpg cn=true]


嗯，我很担心这个问题，我想.......
[cpg]


[OnName num="gorou"]
'我不会的。我可以向你保证。"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari133"]
[OnName num="himari"]
'我不相信。我相当怀疑和妒忌'。
[cpg cn=true]


绯红来找我，说它不止于此。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari029"]
[OnName num="himari"]
'现在，我给你一个刺激。我们该怎么做？"
[cpg cn=true]


[OnName num="gorou"]
'......Oh, please......'
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin_up"  pos="4/7"]

[BG f="b_06_1_up.ui" time=10]
[WAIT time=200]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari030"]
[OnName num="himari"]
'现在我们该怎么做？我厌倦了用我的手触摸你。
[cpg cn=true]


[OnName num="gorou"]
即使你说你很无聊......，那么你要做什么呢？"
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari031"]
[OnName num="himari"]
'嗯，今天......，这样的事情怎么样？
[cpg cn=true]


绯红做了一些不同的事情，说。
[cpg]


;//========================================
;//●ＣＧ（ヒロインに足蹴にされる主人公。からかうような表情のヒロイン）ev_27
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：朝
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]



所以她把她的脚，而不是她的手，贴近我的身体。
[cpg]


我当时想，'你以为我是什么人？ '但我不能拒绝，因为如果我不喜欢，就会不计后果地结束它。
[cpg]


[VOICE f="sHimari032"]
[OnName num="himari"]
'我不知道。我不知道，大哥哥，我想你从这种事情中得到了刺激。"
[cpg cn=true]


你不能在这里表现得像你很高兴。另一方面，我也不能勉为其难。
[cpg]


[OnName num="gorou"]
嗯
[cpg cn=true]


[VOICE f="sHimari033"]
[OnName num="himari"]
'你看起来不开心，但我知道你其实很开心。
[cpg cn=true]


[OnName num="gorou"]
'我不高兴......，你认为我有什么样的个性？
[cpg cn=true]


但他肯定很激动。
[cpg]


;**【ＣＧ】 ev_27_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari034"]
[OnName num="himari"]
'如果这是一个征兆，我希望你能这么说。你这么固执，很可爱'。
[cpg cn=true]


[OnName num="gorou"]
'我并不是说要直言不讳。
[cpg cn=true]


是吗？　她边说边看着我的反应。
[cpg]


[VOICE f="sHimari035"]
[OnName num="himari"]
我认为刺激来自于不寻常的情况。
[cpg cn=true]


对于这个问题，绯红是如何想出这些东西的？
[cpg]


[OnName num="gorou"]
緋紅一直在考虑...... 这些事情。"
[cpg cn=true]


;**【ＣＧ】 ev_27_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari036"]
[OnName num="himari"]
'嗯？　总是这样吗？"
[cpg cn=true]


[OnName num="gorou"]
所以，即使你没有看到我。
[cpg cn=true]


[VOICE f="sHimari037"]
[OnName num="himari"]
'我不知道，我不知道...'　这只是我想到的一个想法。"
[cpg cn=true]


绯红边说边用脚摸索着我的胸甲。
[cpg]


这不是怕痒或什么。但这感觉很奇怪，是不道德的。
[cpg]


然而，我没有做任何讨厌的事情。......。
[cpg]


[VOICE f="sHimari038"]
[OnName num="himari"]
'你更喜欢哪一个，你的手还是你的脚，大哥哥？
[cpg cn=true]


[OnName num="gorou"]
什么，这个问题？
[cpg cn=true]


他问了我一些很奇怪的问题，我无法保持冷静。
[cpg]


我无法直视他。绯红看穿了这一点。
[cpg]


;**【ＣＧ】 ev_27_b ***********************
[CG id=12 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari039"]
[OnName num="himari"]
'别装傻了，我正在努力决定下一步为你做什么。
[cpg cn=true]


[OnName num="gorou"]
'......'
[cpg cn=true]


你说了那么多，我甚至无法回答。
[cpg]


我担心如果我说脚，他们现在会对我做什么，如果我说手，他们就会停止现在做的事情。
[cpg]


[VOICE f="sHimari040"]
[OnName num="himari"]
'嗯，好的。从现在开始，我也要让你在晚上感受到这种刺激。
[cpg cn=true]


当我在思考这个问题时，緋紅说了一句更令人惊讶的话。
[cpg]


她表现得非常积极。这又不是我要求她做的。
[cpg]


[OnName num="gorou"]
'诶，...... 可以吗？
[cpg cn=true]


[VOICE f="sHimari041"]
[OnName num="himari"]
'不是我不介意，更多的是我想让它属于我自己。你妈妈也会给你的。我确定'。
[cpg cn=true]


他们把你当做一个东西，好像你都是自己的，或者你把它送人。
[cpg]


但我也很高兴，或者说我觉得我可以感受到绯红对我的爱。
[cpg]




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


触摸她之后，痛苦的时间又回来了。
[cpg]


但是，我可以在中午看到我的姐姐，此外，她还说，绯红会在晚上为我做。......
[cpg]


相信这一点，我只得暂时忍耐。
[cpg]


[window target=false]


[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************



[SE f="se000"]
;//【ＳＥ】『歩く』





走在街上。一路走到学院。
[cpg]


同时，它仍然没有那么痛苦。但当上午的课程即将结束时，这是最困难的。
[cpg]


到午休前的时间，或者说，那是你必须为......，无论你怎么想。
[cpg]




[window target=false]


[STOPBGM]

[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************





[OnName num="male_student"]
'嘿，小坂。我听说你前几天和一个女孩在一起散步。
[cpg cn=true]


[OnName num="gorou"]
'什么？　嗯，情况并非总是如此。......"
[cpg cn=true]


[OnName num="male_student"]
别装傻了!　你说你和一个女孩手拉手，她都在你身上。"
[cpg cn=true]


[OnName num="gorou"]
你在说什么呢？　我不认识任何与我关系那么好的女孩。......"
[cpg cn=true]


哦，他来了。绯红。也许有人在她离开房子时看到了她或其他东西。
[cpg]


但如果是这样，很明显，她是我的妹妹。
[cpg]


[OnName num="gorou"]
这是我的妹妹。她的名字叫小坂绯红。
[cpg cn=true]


[OnName num="male_student"]
'哦，啊......，所以她是你的妹妹。所以她不是你的女朋友或什么？
[cpg cn=true]


[OnName num="gorou"]
'...... 是的。是的，不是女朋友。"
[cpg cn=true]


...... 一般来说，妹妹不是爱人。
[cpg]


我疯了，不是吗？我必须被提醒这一点。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



;//その後、昼休みになって姉さんに抜いてもらった。
;//＠
后来，在午餐时间，我让我姐姐提高我的心率。
[cpg]


事后。我姐姐说了这样的话。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune321"]
[OnName num="suzune"]
'嘿。你喜欢绯红吗？　也许是某种形式的忏悔？"
[cpg cn=true]


[OnName num="gorou"]
'......，你知道我的意思吗？
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune322"]
[OnName num="suzune"]
'我可以看到。绯红早上离开你的房间时，脸上有一种严肃的表情'。
[cpg cn=true]


这就是你在看的东西。我猜她有点像个鉴赏家，或者她很有姐妹情谊。
[cpg]


[OnName num="gorou"]
如果你指的是忏悔，你是否做了......？"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune323"]
[OnName num="suzune"]
'我不认为我有，没有。你需要承担适当的责任'。
[cpg cn=true]


;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



我姐姐教训我，我感觉很微妙。
[cpg]


我喜欢绯红。毋庸置疑。
[cpg]


但当我想到我是否正确面对绯红时，就很难说了。
[cpg]


她害怕作弊。考虑到我的体质，这很自然。
[cpg]

;//＠妊娠しても体質が治らなかったらと考えるのは、当然かもしれない。
可能会很自然地想到，即使我的爱得到满足，如果我的体质没有得到治愈。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************



[OnName num="gorou"]
'我回家了: ......'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari153"]
[OnName num="himari"]
'欢迎回来，兄弟。我们可以吗？"
[cpg cn=true]


[OnName num="gorou"]
'做，有点太快了......？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari042"]
[OnName num="himari"]
'你必须适应我的心情。你的兄弟没有权利选择。
[cpg cn=true]


就这样，他们强迫我，把我的手拿走了。
[cpg]


而我被带到了緋紅的房间。......
[cpg]



;//========================================
;//●ＣＧ（主人公に顔を近づけるヒロイン。キスをする）ev_28
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]



她是在近距离。我无法直视她。
[cpg]


但当我把目光移开时，绯红指出了这一点。
[cpg]


[VOICE f="sHimari043"]
[OnName num="himari"]
'别看了。再仔细看看我。"
[cpg cn=true]


当你说这样的话时，它只是让我紧张。
[cpg]


[OnName num="gorou"]
'...... 是的。
[cpg cn=true]


我现在没有选择，只能点头。我没有胆量在这里拒绝。
[cpg]


但我也没有胆量接受它。
[cpg]


;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari044"]
[OnName num="himari"]
我不知道该怎么做。你将永远是一个新手。
[cpg cn=true]


像往常一样，绯红的脸皮相当厚。
[cpg]


如果她像她一样随和，也许我就不会有这种宪法了。......
[cpg]


[OnName num="gorou"]
'你不能帮助它。...... 如果你不再激动，那就是一个问题。
[cpg cn=true]



我很害怕，绯红比平时更接近，说。
[cpg]


[VOICE f="sHimari045"]
[OnName num="himari"]
'从那时起，我就想知道什么让你最紧张。
[cpg cn=true]


绯红看着我，给了我一个计谋性的微笑。
[cpg]


在这么远的地方有这么漂亮的女孩，真让人激动。
[cpg]


但绯红仍然看起来想做什么。
[cpg]


[OnName num="gorou"]
'，你是如此接近。
[cpg cn=true]


;**【ＣＧ】 ev_28_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari046"]
[OnName num="himari"]
'现在说这个有点晚了，不是吗？　你以前做了那么多事情，你还害怕只是接吻吗？"
[cpg cn=true]


我不敢说这件事，但绯红说了。
[cpg]


我知道她要吻我。
[cpg]


[OnName num="gorou"]
'......，对我好一点。
[cpg cn=true]


[VOICE f="sHimari047"]
[OnName num="himari"]
'我说得像个女孩，漂亮~'
[cpg cn=true]


如果发生这种情况，我想我只能准备好自己。我就是这么想的，然后闭上了眼睛。......
[cpg]


;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari048"]
[OnName num="himari"]
'呵。漂亮的脸蛋。"
[cpg cn=true]


然后她就没有再吻我。
[cpg]


我睁开细长的眼睛，看着希玛莉。
[cpg]


[VOICE f="sHimari049"]
[OnName num="himari"]
'我想我会用我的手机拍下我弟弟的吻脸...'
[cpg cn=true]


[OnName num="gorou"]
'做，你是什么意思？
[cpg cn=true]


[VOICE f="sHimari050"]
[OnName num="himari"]
'你想让我吻你吗？　那我希望你能这么说。
[cpg cn=true]


[OnName num="gorou"]
'...... 有时绯红看起来像一个恶魔。
[cpg cn=true]


[VOICE f="sHimari051"]
[OnName num="himari"]
'你是说恶魔般的类型？　我真为你感到高兴。"
[cpg cn=true]


绯红笑着说。但对于悬浮在半空中的我来说，它看起来仍然像魔鬼的微笑。
[cpg]


[VOICE f="sHimari052"]
[OnName num="himari"]
'那么，你是怎么想的？　我想让你吻我。"
[cpg cn=true]


[OnName num="gorou"]
这是......."
[cpg cn=true]


在我说这句话的时候，她给了我一个不可抗拒的眼神，并把她的嘴唇送到我的面前。
[cpg]


;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト


;**【ＣＧ】 ev_28_b ***********************
[CG id=13 index=2 time=1000]
;***************************************
[WAIT time=1000]

我们的嘴唇互相接触。这是一个轻柔的吻，但感觉我们终于越过了界限。
[cpg]



;//ＣＧ再び表示

;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]

然后我们拉开距离。我们不再只是兄弟姐妹。
[cpg]


[VOICE f="sHimari053"]
[OnName num="himari"]
'...... 大哥哥，你真的很可爱。
[cpg cn=true]


当他对我说这句话时，我可以感觉到我的脸越来越热。
[cpg]


我没有想到，被告知我很漂亮会让我如此紧张和......。
[cpg]


我也没有想到这个吻本身会有这样的感觉。
[cpg]


[VOICE f="sHimari054"]
[OnName num="himari"]
'那好吧。我会把接吻推迟一段时间，我不想让你通过正常的皮肤关系失去刺激。"
[cpg cn=true]


我觉得我的脸都红了。我认为这更像是因为另一边的绯红也在脸红。
[cpg]


我想知道从现在开始我们会有什么样的关系......。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


要记住的最重要的事情是，你不应该害怕寻求帮助。
[cpg]


我感觉我无法入睡，但我比这更高兴。
[cpg]


我想知道绯红是否处于类似的心理状态......，但我不能确定。
[cpg]


一段时间后，在星期六。
[cpg]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の家＿玄関』（昼）******************************************************



当时我刚从医院回来。
[cpg]


我和我妈妈去了那里，我被告知了一些事情，有点......，令人震惊。
[cpg]




;//ブラックアウト


[window target=false]


[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Himari173"]
[OnName num="himari"]
'欢迎回来。情况如何？"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Sawa105"]
[OnName num="sawa"]
'事情是这样的--......，这有点，有点大材小用。
[cpg cn=true]


我必须告诉你细节，不是吗？这不是我要让我母亲告诉我的事情。
[cpg]


[OnName num="gorou"]
'......，他们说有一种药可以治好我的病。但是。"
[cpg cn=true]


[OnName num="gorou"]
'他说，他非但没有治好自己的病，反而会对爱情失去兴趣。
[cpg cn=true]


简而言之，我们谈论的是失去了激动人心的愿望。
[cpg]


如果你不再想与任何人相爱，这是一个关于...... 人的生命的故事。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
绯玉和她姐姐的表情变得阴晴不定。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune324"]
[OnName num="suzune"]
'医生也会说可怕的事情，......，如果他们说这样的话，你只会变得更加焦虑。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

是的，没错。但是，希玛里沉默不语，也许想的是不同的。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

而我和绯红单独在一个房间里。
[cpg]


绯红闯入我的房间。
[cpg]


她想谈点什么，或者说，我也想和她谈点什么。
[cpg]


[OnName num="gorou"]
'......，你怎么看。关于如何治疗你的体质'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari055"]
[OnName num="himari"]
'这很好。没什么，我想如果我这样做就可以了'。
[cpg cn=true]


[OnName num="gorou"]
'嗬，说真的!　因为......，如果我吃了药，我相信我也不会对绯红有什么想法。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari175"]
[OnName num="himari"]
'如果我哥哥不欺骗我，我还是会喜欢的。但......."
[cpg cn=true]


绯红在说这句话时显得有些尴尬。和......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari056"]
[OnName num="himari"]
'如果我可以，我也希望你仍然是你一直以来的兄弟，只是你的体质会被治愈。
[cpg cn=true]


...... 我明白了。绯红是这样想的吗？
[cpg]


正如医生所说，你和绯红应该走到一起，你的体质应该稳定下来。
[cpg]


那是最好的状态。但如果宪法没有安顿下来，那么......
[cpg]


也许我将被剥夺爱本身的权利。
[cpg]


即使有这样的决心，我还是要和绯红出去。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari057"]
[OnName num="himari"]
'嘿。你也准备好了，不是吗，大哥哥？
[cpg cn=true]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト



[window target=true]


绯红走近。她试图吻我。......
[cpg]


我开始有点不耐烦了。我知道我也想和绯红做爱。
[cpg]


[window target=false]

[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





时间在流逝，再过一会儿就到了吃晚饭的时间。
[cpg]



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari058"]
[OnName num="himari"]
快到吃晚饭的时间了。我们很快就可以走了吗？"
[cpg cn=true]


[OnName num="gorou"]
'......'
[cpg cn=true]



我觉得我可以多和绯红接触，看看她的体质是否稳定下来。
[cpg]


但是，如果我太仓促，绯红会不会变得幻灭，而爱情本身也会没有结果？
[cpg]


经过思考，我想出了一个答案。
[cpg]


;//■選択肢
[switch]
[case "我将会更加接近绯红，即使我必须要稍微推动一下自己。"]
	[swap]
	[jump target="*select05_1"]
[case "慢慢来，别着急"]
	[swap]
	[jump target="*select05_2"]
[endswitch]

1.更接近Himaru，即使有点不知所措
2，慢慢来，不要着急。



;//==============================
;//１、多少無理してもひまりに近づく
*select05_1|珍惜绯红。




[OnName num="gorou"]
'再和我们呆一会儿吧。緋紅"。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sHimari059"]
[OnName num="himari"]
但食物是......"
[cpg cn=true]


[OnName num="gorou"]
'快走吧!　如果你继续这样下去，你无法真正治愈你的体质。"
[cpg cn=true]



[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari060"]
[OnName num="himari"]
'...... 是的。好吧，如果你坚持这么说的话。
[cpg cn=true]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ブラックアウト


[window target=true]

就这样，与绯红的日子继续着。但在幕后，不适感也在不断累积。
[cpg]


绯红怎么会看到我着急呢？
[cpg]


如果我吓到她或让她感到不舒服，哪怕是一点点，那就不好了。
[cpg]


甚至 "我不擅长这个 "的感觉也再次变成了不耐烦。
[cpg]


;//移植前シーンカット


[window target=false]
[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari061"]
[OnName num="himari"]
'嘿，兄弟。你不应该得到我所说的待遇吗？"
[cpg cn=true]


[OnName num="gorou"]
为什么......，我喜欢绯红？"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari062"]
[OnName num="himari"]
'是的，但也许是你的体质使你认为你喜欢我。
[cpg cn=true]


[VOICE f="sHimari063"]
[OnName num="himari"]
'如果你不捶打，你就无法呼吸。我以为你爱上了我，因为你想捣蛋。
[cpg cn=true]


面对我的不耐烦，向日葵开始质疑她是否真的被爱。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（昼）******************************************************





然后，绯红逐渐开始对我采取冷漠的态度。
[cpg]


但我的体质还很好，所以我和绯红的关系很苦。
[cpg]


[OnName num="gorou"]
'该死，我很痛苦，...... 緋紅!
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari064"]
[OnName num="himari"]
'我不知道该怎么做。我没有心情'。
[cpg cn=true]



[window target=false]

[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『街』（夜）******************************************************



讽刺的是，在我痛苦的时候，绯红对我产生了兴趣。
[cpg]


也许她一直都有这种气质。
[cpg]



我只能想象，但......，我有一种感觉，她确实如此。
[cpg]


[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト


绯红不再向我靠近。她不能再做捶打，而我还在痛苦中。
[cpg]


它是如此痛苦，以至于有一天晚上我甚至无法入睡.......。
[cpg]


;//========================================
;//●ＣＧ（寝ている主人公に寄り添うヒロイン。サディスティックな感じ）ev_30
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="gorou"]
'哈，哈......，绯红？
[cpg cn=true]


她来到了我的房间。我已经等了她很久了，我觉得我现在就想拥抱她。
[cpg]


但我无法呼吸，也无法起身。
[cpg]


无论她是否知道我处于这种情况，她都说。
[cpg]


[VOICE f="sHimari065"]
[OnName num="himari"]
'也许我想一直看着我痛苦的弟弟......。
[cpg cn=true]


他一边笑着一边说着残酷的事情。
[cpg]


我不能呼吸，我一直不能呼吸，呼吸太难了，如果不呼吸，我真的会死。
[cpg]


[OnName num="gorou"]
'绯红......，请到我身边来。
[cpg cn=true]


;**【ＣＧ】 ev_30_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari066"]
[OnName num="himari"]
'我想知道我应该怎么做？　我哥哥现在有点太绝望了，也许我不想和他亲近。"
[cpg cn=true]


绯红以她一贯的语气平静而轻蔑地说道。
[cpg]


[OnName num="gorou"]
'桑尼，绯红并不关心我发生了什么。
[cpg cn=true]


[VOICE f="sHimari067"]
[OnName num="himari"]
'......，这很难，大哥哥。你已经变得如此依赖捣蛋了'。
[cpg cn=true]


依靠绯红而不是Dokidoki，我叫她的名字。
[cpg]


[OnName num="gorou"]
'緋紅......，哦，緋紅，緋紅！'
[cpg cn=true]


[VOICE f="sHimari068"]
[OnName num="himari"]
'怎么了？　你想从我这里得到什么，叫我那么多？"
[cpg cn=true]


管它呢，这很明显。
[cpg]


[OnName num="gorou"]
'请...... 捣毁我。如果你不这样做，这是在你的宪法中。......
[cpg cn=true]


[VOICE f="sHimari069"]
[OnName num="himari"]
宪法，嗯？ 对。"
[cpg cn=true]


;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari070"]
[OnName num="himari"]
'嘿。实际上，我正在接受一些药物治疗，以治愈我的病情。"
[cpg cn=true]


[OnName num="gorou"]
什么？"
[cpg cn=true]


有一瞬间，我不明白希玛里在说什么。
[cpg]


但我昏昏沉沉的脑袋渐渐开始明白了。
[cpg]


[VOICE f="sHimari071"]
[OnName num="himari"]
'我想，也许我的兄弟不会想自己喝酒。但现在你在痛苦中，你确实想喝酒'。
[cpg cn=true]


[OnName num="gorou"]
'哦，不......，只要绯红能靠近我，那就足以帮助我呼吸了。
[cpg cn=true]


我想我是自私的。但我忍不住说了出来。
[cpg]


这就是它的痛苦之处。不仅是我的呼吸，而且我的心脏也在受苦。
[cpg]


;**【ＣＧ】 ev_30_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari072"]
[OnName num="himari"]
'这只是暂时的，不是吗？你必须一直让我在你身边，这是不健康的。
[cpg cn=true]


[OnName num="gorou"]
但是！"
[cpg cn=true]


绯红从头到尾都显得有些惊慌失措。
[cpg]


我越是绝望，越是适得其反。尽管我知道，但我还是忍不住不耐烦了。
[cpg]


[VOICE f="sHimari073"]
[OnName num="himari"]
'我想知道这些药丸里有什么？　它是否会减少睾丸激素？"
[cpg cn=true]


[VOICE f="sHimari074"]
[OnName num="himari"]
'那你就可以知道为什么我对浪漫失去了兴趣。我想这也会让我对没有心跳的感觉好起来。
[cpg cn=true]


绯红说着可怕的事情。我真的要放下这份爱吗？
[cpg]


光是想象我不能爱上绯红就很难。但呼吸更困难了。
[cpg]


[OnName num="gorou"]
'Kuu...... 痛苦，緋紅，帮助我。
[cpg cn=true]


看到我痛苦的样子，緋紅似乎并不着急。
[cpg]


[OnName num="gorou"]
'我应该怎么做......，我做了什么让你这么恨我？
[cpg cn=true]


;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari075"]
[OnName num="himari"]
'没事的。我不恨你。尽管我的哥哥已经中立了，但我仍然喜欢他。
[cpg cn=true]


她用平静、温和的语气说着可怕的事情。
[cpg]


[VOICE f="sHimari076"]
[OnName num="himari"]
'也许到时候我会把你当做一个装扮的娃娃来玩？
[cpg cn=true]


[OnName num="gorou"]
'那个，啊，那个.......'
[cpg cn=true]


这种爱，已经嗤之以鼻。绯红有些乐在其中。
[cpg]


而我，则没有时间去享受它。
[cpg]


我没有想到......，最后会变成这样。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



......，怎么会变成这样？
[cpg]


尽管我很后悔，但最后我的呼吸还是很痛苦。
[cpg]


为了逃避痛苦，我吃了药。
[cpg]


[OnName num="gorou"]
'哈哈，哈哈......，緋紅。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari077"]
[OnName num="himari"]
'这就对了。你太有魄力了，大哥哥，你吓到我了。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari078"]
[OnName num="himari"]
现在我的兄弟是我的，也是我一个人的。......
[cpg cn=true]


说到这里，绯红拍了拍我的头。对此，我不再感到激动。
[cpg]


[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ブラックアウト



我的捣蛋真的是由绯红管理的。
[cpg]


我的心已经被锁住了。......
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*back_title"]
;//ＥＮＤ：バッドエンドルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================
;//２、ゆっくり慣らしていこう
*select05_2|珍惜绯红。




[OnName num="gorou"]
'......，我同意。
[cpg cn=true]




绯红可能是困难的。我不想让她看到我太着急了。
[cpg]


相反，我想照顾好...... 緋紅。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



之后，在我们吃完晚饭后，绯红就来到了我的房间。
[cpg]


她说她不希望看到我受苦。
[cpg]


通过不从我这边要求太多，绯红从我这边要求了。......
[cpg]



[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari079"]
[OnName num="himari"]
'我希望我可以......，做点什么。医生说，如果你坠入爱河，你就会痊愈，对吗？"
[cpg cn=true]


[OnName num="gorou"]
'嗯，差不多就是这样的情况。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari080"]
[OnName num="himari"]
'它是蓬松的，不是吗？爱有什么关系呢？
[cpg cn=true]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_h1"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



比如说。你不是在谈论简单的结婚或类似的事情。
[cpg]

即使是这样，我也不想仓促行事。我不想强迫绯红做任何事情。
[cpg]


[window target=false]


[STOPBGM]

[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



但似乎绯红在我之前就下定了决心。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari229"]
[OnName num="himari"]
'...... 你知道吗？如果事情继续这样下去，它不会很快结束，对吗？"
[cpg cn=true]


[OnName num="gorou"]
'没有必要急于求成。让我们慢慢来吧....... 緋紅？"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari081"]
[OnName num="himari"]
'更多伟大的事情，我会为你做。即使你哥哥不愿意，我也会。
[cpg cn=true]


[OnName num="gorou"]
'......，要温柔。
[cpg cn=true]



我从来没有厌恶过它。但我认为如果我要求的话，就不会发生这种情况。
[cpg]


我真的以为爱情是一种奇怪的东西。
[cpg]


;//ブラックアウト

;//移植前シーンカット


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



绯红和我花了一天时间进行适度的调情。
[cpg]


我们甚至在路上去餐厅吃饭。......。
[cpg]




;//ブラックアウト


[window target=false]



[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari247"]
[OnName num="himari"]
'谢谢你的食物。那么，大哥哥，我们回你的房间去吧。
[cpg cn=true]


[OnName num="gorou"]
'这太明目张胆了，......'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari248"]
[OnName num="himari"]
'时间是有限的，我们不能磨磨蹭蹭。
[cpg cn=true]

[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa106"]
[OnName num="sawa"]
'咯咯笑。你们真的很亲密......'
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



然后他们回到自己的房间，进行了一场黏稠的调情。

[cpg]


在做这些的时候，我们甚至谈到了一起睡在被褥上。......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari249"]
[OnName num="himari"]
'嘿，这很好。也许人们已经知道了。"
[cpg cn=true]


[OnName num="gorou"]
我知道。...... 那么好吧。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari250"]
[OnName num="himari"]
'知道了。和我弟弟睡觉。"
[cpg cn=true]


看到绯红这样，我觉得她仍然是我的小妹妹。
[cpg]


尽管我真的想做她的情人。在那里，它将不可避免地成为一个中间地带。
[cpg]


她是我的妹妹，但她是我的爱人。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=1000]

然后我们俩依偎在一起，进入了梦乡。......
[cpg]


激动但松了一口气。这个词再次出现在我的脑海中，因为我已经想了很多次。
[cpg]


我认为那是一段快乐的时光。这感觉就像是对我和绯红之间的爱情的确认。
[cpg]


如果当时我很着急，绯红体内的感情可能会冷却下来。
[cpg]


当然，会有一个与现在不同的未来。
[cpg]


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari251"]
[OnName num="himari"]
"嗯 ...... 困了 ......"
[cpg cn=true]


绯红先醒过来，摇晃着我。
[cpg]


现在已经是工作日了吗？我必须要去学院。......
[cpg]


但现在的时间还很早。有什么计划？
[cpg]


[OnName num="gorou"]
'现在不是早......吗？　如果你困了，为什么不回到床上去？"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari082"]
[OnName num="himari"]
'不'。你在试图治疗你的体质。
[cpg cn=true]


[OnName num="gorou"]
......，你是对的。"
[cpg cn=true]


如果我不花一点时间和你在一起，我的体质就不会稳定下来。
[cpg]


即使是这样，我认为也不必在这么早的时候。......
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_06_1_up.ui" time=1000]
[WAIT time=2000]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sHimari083"]
[OnName num="himari"]
'嘿，让我们接吻吧。我还没有刷牙。"
[cpg cn=true]


[OnName num="gorou"]
'这是不卫生的。......'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari084"]
[OnName num="himari"]
'如果你想想你的身体，如果你不吻它，你会更痛苦。
[cpg cn=true]


...... 的确如此。
[cpg]



;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



快乐的时光很快就会过去。我必须要去上学。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari085"]
[OnName num="himari"]
嗯。......，我希望我的早晨能长一点。"
[cpg cn=true]


[OnName num="gorou"]
'我想我只能早起了？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari086"]
[OnName num="himari"]
'那会使夜晚变得更短，不是吗？
[cpg cn=true]



;//ブラックアウト



没有绯红的日子越来越难熬了。
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『学園教室』（昼）******************************************************





不出所料，到了中午时分，我已经摇摇晃晃了。
[cpg]


我想过要去我姐姐那里，但我还是忍住了。
[cpg]


一般来说，如果我不断地重复这样的日子，我的体质就会及时地稳定下来。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************





时间过去了。特别是......
[cpg]


足够的时间过去了，我不需要再扑腾了，也不需要再用力呼吸了。
[cpg]


与绯红的关系在家里已经完全暴露。
[cpg]


我向父亲解释了很久，但他终于承认了。
[cpg]



;//ブラックアウト


[window target=false]

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari087"]
[OnName num="himari"]
'你哥哥要做你的丈夫，对吗？
[cpg cn=true]


[OnName num="gorou"]
如果你这样说的话，那么绯春也是你的妻子。"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari088"]
[OnName num="himari"]
'嘿嘿。很高兴听到这个消息'。
[cpg cn=true]



直到最近，她还只是一个小妹妹。我晕头转向的日子开始......
[cpg]



;//ブラックアウト


[window target=false]

[STOPBGM]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


我已经有了一份工作，我将在春天开始工作。
[cpg]


绯想尽快结婚，所以为了所谓的学校而学习是不够的。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari272"]
[OnName num="himari"]
'我进来了，大哥哥。
[cpg cn=true]


[OnName num="gorou"]
'哦，绯红......，怎么了？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari089"]
[OnName num="himari"]
'你哥哥的体质最近已经稳定下来了，是吗？这就是为什么......，我想念你。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari090"]
[OnName num="himari"]
'我不知道......，我想靠近我哥哥。
[cpg cn=true]


[OnName num="gorou"]
'是的。我也这么认为。这与敲打没有关系'。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari091"]
[OnName num="himari"]
'我喜欢我的...... 弟弟的这一点。你把我当回事。
[cpg cn=true]


[OnName num="gorou"]
'真的吗？　我觉得我很轻浮。"
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari092"]
[OnName num="himari"]
'但你不像我这么轻浮，是吗，大哥？
[cpg cn=true]




...... 緋紅称我为她的大哥哥。
[cpg]


我希望她现在不要再这样叫我了，但......，绯红很难改变。
[cpg]



[OnName num="gorou"]
'你知道吗？如果你要结婚，你可以改变你对我的称呼。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari293"]
[OnName num="himari"]
'连你的哥哥都叫你姐姐。
[cpg cn=true]


这完全无关紧要。我和我妹妹没有任何关系。
[cpg]



[OnName num="gorou"]
这是一派胡言。......，这是行不通的。"
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari294"]
[OnName num="himari"]
'没关系的。我再不说就不行了，所以现在就说'大哥'吧。
[cpg cn=true]



对，这就是我的意思。那么我可以理解，为什么他们不能这样说呢？
[cpg]

;//ブラックアウト
;//移植前シーンカット
;//移植前シーンカット

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



就这样，我和绯红的日子一直在继续。
[cpg]


这让人头晕目眩。然后，当我们终于结婚时：......
[cpg]


;//========================================
;//●ＣＧ（椅子に座って、編み物をするヒロイン。おなかは膨らんでいない形にしてください）ev_35
;//人物１：ヒロイン２
;//服装１：私服
;//場所　：主人公の家＿リビング
;//時間　：朝
;//備考　：元のＣＧと違って、おなかは膨らんでいない形にしてください
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


有人看到绯红在客厅里织毛衣。
[cpg]


我不认为她是一个狡猾的人，但我不知道她是否有这样的爱好。
[cpg]


[OnName num="gorou"]
'......，我不记得她会编织。
[cpg cn=true]



绯红摇了摇头。我知道，我从未见过她这样做。
[cpg]


[OnName num="gorou"]
[OnName num="gorou"]
'我不能做的时候就做。
[cpg cn=true]


[VOICE f="Himari315"]
[OnName num="himari"]
'你将能够。'因为我知道会有一些日子，你会感到无聊。
[cpg cn=true]


你和我有这样的对话。也许他们正在谈论生孩子的问题。
[cpg]


我不需要再问了。而在这一天，我听到了我一直期待的话语。
[cpg]


;//;**【ＣＧ】 ev_35_a ***********************
;//[CG id=15 index=1 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="sHimari093"]
[OnName num="himari"]
'从现在开始留在我身边，戈罗。
[cpg cn=true]


他叫我戈罗。我感觉自己的胸口被打了一拳。
[cpg]


在这一刻，我已经从一个单纯的大哥哥毕业了。
[cpg]


这并不公平。绯红用她的称呼迷惑了我，但我对此无能为力。
[cpg]


[OnName num="gorou"]
'...... 是的。緋紅"。
[cpg cn=true]


我别无选择，只能叫绯红为绯红。但总有一天，我会叫她妈妈。
[cpg]


你叫我五郎的时间会很短。
[cpg]


但这也没关系。这就是我的快乐。......
[cpg]


我哥哥成为父亲的日子在我眼前渐渐逼近。
[cpg]


我只是很高兴。
[cpg]



;//ブラックアウト

不是作为她的兄弟，而是作为她的情人，就在身边。
[cpg]


你不是每天都能成为曾经的兄弟和现在的女友。
[cpg]


我有一种感觉，从现在开始我就会很兴奋，有一天我也想让Himaru有同样的感觉。
[cpg]


她的性格相当强势，所以我可能很难做点什么。......
[cpg]


我想感到兴奋，我想让他们感到兴奋。我有这样一个共同的爱人的愿望。
[cpg]





;//ブラックアウト

[SCENE id=10]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン２ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


