
*start
;//あねいもままの射精管理　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//寿々音　裸　私服　スーツ
;//ひまり　裸　私服　制服
;//砂羽　　裸　私服

;//以下音声なし
;//吾郎 父親 男子学生Ａ 男子学生Ｂ
;//医者 女子学生 女子学生Ａ 女子学生Ｂ 男子学生
;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//寿々音　一人称「私」　ひまり呼び「ひまり」　砂羽呼び「お母さん」　吾郎呼び「吾郎」
;//ひまり　一人称「私」　寿々音呼び「お姉ちゃん」　砂羽呼び「お母さん」　吾郎呼び「お兄ちゃん」
;//砂羽　一人称「私」　寿々音呼び「寿々音」　ひまり呼び「ひまり」　吾郎呼び「吾郎」
;//吾郎　一人称「俺」　寿々音呼び「姉さん」　ひまり呼び「ひまり」　砂羽呼び「母さん」


;###################################################################
*Ep000|一种神秘的身体状况。
;###################################################################

[SCENE id=0]


[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[stflag jump_scene=1]


;///////////////////////////ここからが本編です///////////////////////////



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_me"]
;//ブラックアウト





当我还很年轻的时候。
[cpg]


我的妈妈和爸爸在一次事故中去世。我当时还是个孩子，所以我不明白发生了什么事。
[cpg]


我记得我很害怕，因为我周围的人都在哭，所以我也哭了。
[cpg]


我认为失去父母的真正悲痛是在更远的地方形成的。
[cpg]


我的一个远房亲戚，Sawa Kosaka也参加了葬礼。她现在是我母亲的继母。
[cpg]


我想我还在这里第一次见到了我的继妹铃音。
[cpg]



;//下記寿々音のセリフは子供の頃の声です






[VOICE f="Suzune001"]
[OnName num="suzune"]
她告诉我，"......，不要哭。如果你哭了，你在天上的父亲和母亲也会哭"。
[cpg cn=true]


我想我当时并不太明白她说的是什么意思。
[cpg]


我认为铃音是想表现得善良。
[cpg]


她也在忍着泪水。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我的家庭包括我的爸爸妈妈，我的姐姐Suzune，和我的妹妹Himari。然后还有收养的我，所以我们是一个五口之家。
[cpg]


我们都没有血缘关系。我想我们有一点关系，但绯红和铃音与我的关系比我的表亲更远。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari001"]
[OnName num="himari"]
"我不想去学校。......这是五月的抑郁症，不是吗？"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune002"]
[OnName num="suzune"]
"现在已经是六月了。别傻了。"
[cpg cn=true]


这就是绯红和铃音在谈论的事情。不知怎的，我也觉得很疲惫。
[cpg]


[OnName num="gorou"]
"可能是气压的下降......"
[cpg cn=true]

[free time=1000]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa001"]
[OnName num="sawa"]
她咯咯地笑了起来。"但他们说低压对你有好处！"
[cpg cn=true]


[OnName num="gorou"]
"真的......？我从来没有听说过它。"
[cpg cn=true]


[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune003"]
[OnName num="suzune"]
"我也听说了。住在大气压低的地方的人更长寿。"
[cpg cn=true]


我不知道这一点。虽然我的身体感觉有点沉闷。
[cpg]


[OnName num="gorou"]
"感觉懒惰是否会增加你的预期寿命......？"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari002"]
[OnName num="himari"]
"那我就能活得更久，因为我每天都很累。我不想去。"
[cpg cn=true]


我们的父亲已经在工作了，而我们却在这里进行着毫无意义的谈话。
[cpg]


除了一些微不足道的知识，没有任何收获......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************





铃音是我学校的一名教师。
[cpg]


所以，当然，她比我更早离开家。问题是绯红和我。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Himari003"]
[OnName num="himari"]
"你认为六月抑郁症存在吗？我想我有这个病。"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa002"]
[OnName num="sawa"]
"我不知道。即使有，我也不认为你有绯红。"
[cpg cn=true]


[OnName num="gorou"]
"我确信你是对的。它太慢性了，不可能是一种疾病。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Himari004"]
[OnName num="himari"]
"我想知道这是否是一种身体状况。......"
[cpg cn=true]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]

[window target=true]


身体状况。是的，这是一个关于身体状况的故事。
[cpg]


我过去和现在都受到某种身体状况的困扰。
[cpg]




;//ブラックアウト


[window target=false]




[BG f="b_01_1.ui" time=1000]
[WAIT time=1500]


[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





我一边想，一边走在与绯红不同的路上。
[cpg]


"身体状况 "有很多含义。它可以是一种使人早上难以起床的状况，容易受酒精影响，或容易发怒。
[cpg]


就我而言，我有一个 "Dokidoki依赖症"，或者换句话说，"心悸成瘾"。
[cpg]


我最喜欢的漫画类型是浪漫喜剧。我最喜欢的动漫类型也是浪漫喜剧。我最喜欢的音乐是偶像们唱的情歌。
[cpg]


这很令人尴尬，但我不能没有这种东西。......
[cpg]


我渴望得到一种叫做 "Doki-Doki "的东西。我甚至不知道它是如何变成这样的。
[cpg]


[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[WAIT time=2000]

;//========================================
;//●ＣＧ非エロ（授業をするヒロイン１。黒板に背を向けて本を手に持っている）ev_01
;//人物１：ヒロイン１
;//服装１：スーツ
;//場所　：学園教室
;//時間　：昼
;//========================================


[WAIT time=1000]
[BGM f="bg_d2"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]






[VOICE f="Suzune004"]
[OnName num="suzune"]
"嗯，这部分很容易被误解......。但它可以这样看 ......."
[cpg cn=true]


上午的最后一堂课是铃音的课。
[cpg]

当她面对黑板时，她有一种有趣和聪明的气场。
[cpg]


至少可以说，她在男生中相当受欢迎。
[cpg]


[OnName num="male_student_A"]
"......小坂女士很漂亮，不是吗？"
[cpg cn=true]


[OnName num="male_student_B"]
"是啊......，她有完美的身材。"
[cpg cn=true]


尽管她是我的小姨子，但当人们这样称呼一个家庭成员时，我觉得有点不好。
[cpg]


我有相同的姓氏，小坂，所以人们问我各种各样的问题，但我假装我没有关系。
[cpg]


如果他们发现她是我的妹妹，我就会有大麻烦。
[cpg]


我可以看到，我将被不必要的嫉妒和奇怪的接近所困扰，所以我不告诉人们......。
[cpg]


[OnName num="male_student_A"]
"这些乳房就像一个致命的武器。我想知道她吃了什么才长成这样的。......"
[cpg cn=true]


我知道，但我不说。
[cpg]


;**【ＣＧ】 ev_01_a ***********************
[CG id=0 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Suzune005"]
[OnName num="suzune"]
"嘿，那里。安静点。"
[cpg cn=true]


[OnName num="male_student_A"]
"......"
[cpg cn=true]

她让我们不要说话，但她可能已经注意到我们在谈论她。


不过，我还是觉得她似乎不感兴趣，这很不可思议。
[cpg]


如果你现在只看到她，你会看到她是一个可靠的人。......
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[window target=true]


是的，铃音在学校里表现得像个可靠的人，但只有我知道，她可能是相反的。
[cpg]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『学園教室』（昼）******************************************************





她经常忘记事情。她只有在教学时才会犯一些错误，但在家里，当她放松的时候，她就很粗心。
[cpg]


她会帮忙做饭，但随后会把盐和糖搞错。
[cpg]


我来到这所学校，因为这是我唯一能够进入的地方。
[cpg]


对我来说，与铃音在同一所学校是很尴尬的，但我也无能为力。
[cpg]


我不能浪费我的时间去进入另一所学校，所以......，我来到了这里。
[cpg]


在这个话题上，绯红有点儿聪明。她是那种看起来不在状态的人，但能力却令人惊讶。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************





我当时处于危机之中，与这些情况完全无关。
[cpg]


即使在学校，我的 "心捣瘾 "也无法停止。
[cpg]


然而，我不能在学校打开漫画，所以我在手机上听音乐。
[cpg]


一首情歌，太过酸甜苦辣。尽管这是一首偶像歌曲，但它是现在的学生不听的东西。
[cpg]


我想知道我怎么会变成这样，......，但我又不能对我是疯子这一事实做什么。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************





学校结束了，我回到了家里。
[cpg]


我在路上没有和向日葵碰头。我们去的学校方向相反。
[cpg]


[SE f="se003"]
;//【ＳＥ】『ドア開く』

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[OnName num="gorou"]
"我回来了。"
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（主人公に笑顔で抱きつくヒロイン。胸を腕に押し当てている）ev_02
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の家＿玄関
;//時間　：夕方
;//========================================


[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


我一回到家，绯红就向我走来。
[cpg]


[VOICE f="Himari005"]
[OnName num="himari"]
"欢迎兄弟回家！"
[cpg cn=true]

;//＠
;//彼女は私服に着替えていて、もうとっくに家に戻っていたようだった。


她拍拍屁股走到门口，拥抱了我。
[cpg]


[OnName num="gorou"]
"你是如此接近......他们在打我......."
[cpg cn=true]


;//;**【ＣＧ】 ev_02_a ***********************
;//[CG id=1 index=1 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="Himari006"]
[OnName num="himari"]
"你太顽皮了。你怎么能以这种方式看你妹妹？"
[cpg cn=true]


[OnName num="gorou"]
"我不是......"
[cpg cn=true]


我很激动，这是一种难以伪造的感觉。
[cpg]


[OnName num="gorou"]
"绯，我以为你有五月的抑郁症。你看起来已经很好了。"
[cpg cn=true]


;//;**【ＣＧ】 ev_02_0 ***********************
;//[CG id=1 index=0 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="Himari007"]
[OnName num="himari"]
"我在晚上感觉更好。我想知道为什么。"
[cpg cn=true]


绯红假装她不明白，但我认为她只是对晨曦有一种弱点。
[cpg]


我几乎就要说出来了，但我没有。
[cpg]


[OnName num="gorou"]
"你能让我单独呆一会吗？......我需要改变我的衣服。"
[cpg cn=true]



[VOICE f="Himari008"]
[OnName num="himari"]
"我不想这样，所以我想我会看着你改变。"
[cpg cn=true]


她在说什么呢？看着她的弟弟被换衣服有什么乐趣？
[cpg]


[OnName num="gorou"]
"我不认为看我的裸体有什么乐趣。......，反正我的身体看起来很弱。"
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]

我把试图进入我房间的绯红推到一边，然后我穿上衣服。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





我想在我的房间里放松。对我来说，这样做已经变得很困难。
[cpg]


绯红把她的胸部靠在我身上，这也是不好的。我对这种事情感到紧张。
[cpg]


我想我的心正在遭受某种疾病的折磨。或者是我的头？
[cpg]



[window target=false]



[BG f="b_06_4.ui" time=1500]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





然后我在网上查了这个和那个。那些被禁止的东西，或者说，那些我已经回避了很久的东西。
[cpg]


是否有爱的依赖这种东西，与爱的快感相比，我对爱的依赖程度并不高......。
[cpg]


这些东西显然是存在的。但他们说这在已经和某人有关系的女性中更常见。
[cpg]


我没有女朋友，我是个男人，......，最近我甚至觉得如果我的心脏不跳动，我就很难呼吸了。
[cpg]


也许我应该悄悄地去医院。我想我会这么做的。
[cpg]


[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ非エロ（ヒロインが料理をしている。手伝う主人公。主人公が横にいてヒロインは味見してる感じ）ev_03
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の家＿ダイニングキッチン
;//時間　：夜
;//========================================

[WAIT time=1000]

[SE f="se006"]
;//【ＳＥ】『料理』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]




当我走到厨房时，我妈妈正在准备晚餐。
[cpg]

[OnName num="gorou"]
"你想让我帮你解决妈妈？"
[cpg cn=true]


[VOICE f="Sawa003"]
[OnName num="sawa"]
"哦，你会吗？那可真是太好了！"
[cpg cn=true]



铃音有时会帮忙做饭，但我今天没有看到她。
[cpg]


[OnName num="gorou"]
"铃音在哪里？"
[cpg cn=true]



[VOICE f="Sawa004"]
[OnName num="sawa"]
"她在她的房间里休息。我想她今天过得很辛苦。"
[cpg cn=true]


我想她是对的。每当她偷懒的时候，她就偷懒到了极限。
[cpg]


从这个角度来看，很难说她是一个可靠的人。
[cpg]


;**【ＣＧ】 ev_03_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Himari009"]
[OnName num="himari"]
"祝你好运，你们两个。"
[cpg cn=true]


我听到绯红从我身后说。
[cpg]


她也可以帮助做家务，但她不做。
[cpg]


她与铃音的相似之处在于她们都很懒惰。
[cpg]


绯红是那种一旦进入懒惰模式就很难切换回来的类型。
[cpg]


......那么，妈妈是最可靠的那个吗？嗯，我想这是一个没有问题的问题。
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





现在我们都在这里。当然，爸爸也在饭桌上吃饭。
[cpg]


[OnName num="father"]
"......,怎么了，五郎？有什么事困扰着你吗？"
[cpg cn=true]


[OnName num="gorou"]
"没什么。我很好。"
[cpg cn=true]


我看起来很阴沉吗？嗯，我想我是的。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Sawa005"]
[OnName num="sawa"]
"我也很担心。最近，你一直表现得很胆小。"
[cpg cn=true]


我总是试图小心翼翼地避免被认为是胆小怕事。......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune006"]
[OnName num="suzune"]
"五郎看起来总是很胆小。在校园里更是如此。"
[cpg cn=true]


他们是这样看我的吗？我有点震惊。
[cpg]




;//ブラックアウト


[window target=false]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[STOPBGM]
[WAIT time=1000]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************





第二天。我正在去医院的路上。
[cpg]


我一直都知道我有那种想要心脏跳动的感觉。我想这只是我的身体状况......。
[cpg]


就这一点而言，我想知道我的身体发生了什么。
[cpg]


;//ブラックアウト


[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]


[SE f="se003"]
;//【ＳＥ】『ドア開く』

[WAIT time=1000]


所以我在一家小医院进行了检查。......
[cpg]


[OnName num="doctor"]
"......，这里发生了什么。我不明白......"
[cpg cn=true]


显然，我的身体发生了一些奇怪的事情。
[cpg]


他们把我转到一家较大的医院，我不得不向家人倾诉。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿玄関』（昼）******************************************************





[OnName num="gorou"]
"我回家了。......"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa006"]
[OnName num="sawa"]
"欢迎回来。怎么了，我以为你出去购物了。"
[cpg cn=true]


[OnName num="gorou"]
"我想要的东西已经卖完了......."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa007"]
[OnName num="sawa"]
"哦，是的。那太糟糕了。......那是什么？"
[cpg cn=true]


[OnName num="gorou"]
"啊！"
[cpg cn=true]


一封介绍信从袋子里掉了出来。我愣了一下。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[OnName num="father"]
"...... 病了，是吧？你一个人去咨询，一定很严重。"
[cpg cn=true]


[OnName num="gorou"]
"不，我是说，哈哈......"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune007"]
[OnName num="suzune"]
"我也很好奇。你有什么症状？"
[cpg cn=true]


[OnName num="gorou"]
"我不确定。......我只是觉得有点像感冒了。"
[cpg cn=true]


苦难。我在受苦，尽管这一切都会在时间上变得清晰。
[cpg]


向日葵和甚至妈妈都显得很担心。我感到很抱歉，因为我让向日葵担心。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夕方）******************************************************





所以很快我就在去往我被转诊的医院的路上。我的家人和我一起去。
[cpg]


从那里开始，一切都非常困难。我被告知，我需要接受彻底的检查。
[cpg]


据说这是一种罕见的疾病，只影响到百万分之一的人，甚至更少。
[cpg]


我很不解，但还是照做了，因为有人向我解释，有可能会陷入严重的状况。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





那晚的晚餐很尴尬。
[cpg]


吃饭时还可以，但吃完饭后，我们有一个家庭会议......。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa008"]
[OnName num="sawa"]
"......这一定很困难吧。所以你不得不独自去医院。"
[cpg cn=true]


我开始觉得我应该在这个时候向爸爸或其他人咨询。
[cpg]


套用一句话，他的身体状况使他难以呼吸，除非定期提高心率。这已随着年龄的增长而表现出来。
[cpg]


就我而言，如果我的心脏不跳动，最坏的情况是可能引发另一种疾病。
[cpg]


当他们告诉我陷入危急状况的风险时，我感到头疼。我的家人可能也有类似的感觉。
[cpg]

[free time=800]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sSuzune001"]
[OnName num="suzune"]
"你为什么不......，读一本浪漫的漫画书或什么。那会解决这个问题。"
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="sHimari001"]
[OnName num="himari"]
"不！如果这不能让他的心脏跳动，他就会死。"
[cpg cn=true]


死亡是一种夸张的说法，但它不是谎言。
[cpg]


毕竟，这是一种未知的疾病，所以任何事情都可能发生。
[cpg]


[OnName num="father"]
"好吧，好吧。我相信五郎会自己处理好的；太过担心是不好的。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari011"]
[OnName num="himari"]
"我不知道............我很焦急。"
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（昼）******************************************************





谈话结束后，我们同意暂时由我自己判断。
[cpg]


几天过去了。我想知道这样做是否正确，但我没有别的事可做。
[cpg]


......在这一切之中。
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



一天早上。我爸爸去上班后，我们开了一个家庭会议。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune002"]
[OnName num="suzune"]
"你不是对我们中的一个人有好感吗？"
[cpg cn=true]



[OnName num="gorou"]
"你在说什么呢？"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune003"]
[OnName num="suzune"]
"为了生存，你必须让你的心脏跳动起来，对吗？我们没有血缘关系。"
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSawa001"]
[OnName num="sawa"]
"是的，我也是这样的。"
[cpg cn=true]


甚至妈妈也参与了这个话题。但我并不介意。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSuzune004"]
[OnName num="suzune"]
"幸运的是，你白天也和我一起去学校。......"
[cpg cn=true]


[VOICE f="sSuzune005"]
[OnName num="suzune"]
"如果你有过心脏跳动的困难，如果有必要，你可以依靠我们。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="3/3" time=800]
[VOICE f="sHimari002"]
[OnName num="himari"]
"这不是让他依赖的东西。我们应该积极帮助他让他的心脏跳动起来。"
[cpg cn=true]


绯红这么说，但这不是玩笑。
[cpg]

[OnName num="gorou"]
"我不想这样做！我拒绝这样做。我拒绝!我绝对不希望这样。"
[cpg cn=true]

[SE f=se010]
;//【ＳＥ】『走る』
[free time=1000]
[WAIT time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Suzune013"]
[OnName num="suzune"]
"Himari !别让他跑了。按住他。"
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Himari013"]
[OnName num="himari"]
"我知道！五郎你不能就这样从我们身边跑开。"
[cpg cn=true]




[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[WAIT time=2000]
;//ブラックアウト



就这样。
[cpg]


我受到了大姐、小妹和母亲的 "捣心管理"。......
[cpg]



[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（朝）******************************************************



在我了解了自己的身体状况后，我变得格外渴望得到刺激。
[cpg]


我希望得到刺激。如果我没有暗恋对象，我就会死。多么困难的条件。
[cpg]


上课时我不能听音乐，上午的课后，我会感到头晕目眩。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************


在我失去意识的时候，铃音来救我了。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune014"]
[OnName num="suzune"]
"我们应该怎么做。我想你应该到学生顾问办公室去。......
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune015"]
[OnName num="suzune"]
"但那个房间用得太多也不好。你觉得呢？"
[cpg cn=true]


我只能回答说我不知道。但最后，我被带到了学生顾问办公室。
[cpg]


我的呼吸已经很困难了，我再也受不了了。
[cpg]


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

;//ブラックアウト


最后，我和铃音单独在一个秘密的房间里，没有人能看到我。
[cpg]


[VOICE f="sSuzune006"]
[OnName num="suzune"]
"别误会，我不能为你做那么多。"
[cpg cn=true]


说着，铃音把她的手放在我的胸前。
[cpg]


[OnName num="gorou"]
"Ugh ......."
[cpg cn=true]


我不是从来没有意识到她是一个女人的事实。
[cpg]


她离我这么近，我的心不住地跳动。
[cpg]


那是一段难以形容的舒适时光。我的心脏跳动得很快，但在这段奇怪的时间里，我却能感到安心。
[cpg]

;//移植前シーンカット


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



[OnName num="gorou"]
"......，我们每天都要这样做吗？"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune033"]
[OnName num="suzune"]
"我肯定这不是我的错。更是你的错。"
[cpg cn=true]


我们离开学生指导办公室时说了这样的话。
[cpg]


一般来说，这是一个相当糟糕的场景。
[cpg]


学生们可能不知道，但老师们知道，我和铃音是一个家庭。
[cpg]




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（夕方）******************************************************


时间在这一切中流逝。
[cpg]


从中午到现在没过多少时间，但我已经接近我的极限了。
[cpg]


如果我不能让我的心脏跳动起来，我就会得另一种病，我想.......
[cpg]


在此之前，我呼吸困难，仿佛要疯了。
[cpg]


[OnName num="female_student"]
"怎么了？小坂，你还好吗？"
[cpg cn=true]


[OnName num="gorou"]
"我很好。这没什么。"
[cpg cn=true]


这不可能什么都没有，但我决定这样回答。
[cpg]


我再也无法忍受了。当我看着女孩们的脸，就更难受了。
[cpg]


这是一种来自于我的状况的痛苦，这显然与正常男孩的状况不同。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





我决定回家。
[cpg]


我不禁发现街上所有的女人都很有吸引力。这是不正常的。
[cpg]


我自己无法控制自己的感情。
[cpg]


被管理是一个不温不火的词。我正在被折磨，而不是让我的病情得到控制。
[cpg]


带着这种感觉，我回到了家。......
[cpg]


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[SE f="se003"]
;//【ＳＥ】『ドア開く』
[WAIT time=1000]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa010"]
[OnName num="sawa"]
"欢迎回来。你看起来很痛苦的样子，戈罗。"
[cpg cn=true]


那是在爸爸回家之前。
[cpg]


我想做点什么，我打算跪下来，请求妈妈帮助我。
[cpg]


这就是我真正想做的事情。我不能忍受这个。
[cpg]


我不想忍受它。我紧紧抓住妈妈.
[cpg]


[OnName num="gorou"]
"我现在很难受。......，你知道我的情况，对吗？"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa011"]
[OnName num="sawa"]
她咯咯地笑起来。如果你这样看着我，我不能什么都不做。"
[cpg cn=true]


爸爸还没有回来。我希望她能做些什么。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト



[BG f="b_04_3_up.ui" time=1000]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7" time=1000]
[WAIT time=2000]


妈妈把我带到她的房间。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa002"]
[OnName num="sawa"]
"我要给你一个拥抱。"
[cpg cn=true]


[OnName num="gorou"]
"你确定吗......？"
[cpg cn=true]




[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa013"]
[OnName num="sawa"]
"没关系的。看到我的儿子处于痛苦之中，我很痛苦。"
[cpg cn=true]


通过这些话，我......
[cpg]

;//移植前シーンカット

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]


在我妈妈的怀抱中，我快要哭了。
[cpg]


这与兴奋的感觉有些不同。
[cpg]


但就解脱而言，我可能比在铃音怀里的时候更感到解脱。
[cpg]


妈妈包揽了一切，甚至是我的焦虑。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[OnName num="father"]
"......"
[cpg cn=true]


[OnName num="gorou"]
"......"
[cpg cn=true]


晚餐时，我和爸爸都沉默不语。我想有些事情，男人之间多少可以理解。
[cpg]


我是一个男人，我爱上了爱情，这很尴尬，但......
[cpg]


也许他能多少理解这种尴尬的感觉。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="Himari014"]
[OnName num="himari"]
"妈妈，你能把酱油递给我吗？"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa032"]
[OnName num="sawa"]
"好，给你。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune034"]
[OnName num="suzune"]
"你就在它旁边。自己去拿吧，绯红。"
[cpg cn=true]


妇女们正在进行这样的对话。她们似乎很自在。
[cpg]


或者说，他们甚至似乎很兴奋。我是否会被明天的绯红所照顾......？
[cpg]


我仍然理解我的母亲和妹妹。但绯红是我的妹妹。
[cpg]


对你的妹妹感到紧张是不正常的。
[cpg]


我感到那里有危险的东西，但我不能说什么。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





我脱下衣服，换上睡衣。
[cpg]


在我睡觉的时候，我的症状没有变得更糟，但也没有感觉更好.......。
[cpg]


我深深地叹了口气，为未来担忧。
[cpg]


真的，我将会发生什么......？
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』朝チュン


[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



尽管我想知道我将会发生什么，但早晨会正常到来。
[cpg]


到目前为止，我在睡眠中一直很好，但今天我梦到我有一个可爱的女朋友。
[cpg]


这是那种连正常人都很难醒过来的梦。
[cpg]


我想请人帮忙，所以我去找铃音。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[BG f="b_04_1_up.ui" time=1000]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[WAIT time=2000]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune007"]
[OnName num="suzune"]
"什么？""我在早上不负责任。"
[cpg cn=true]


管它呢，似乎有一个轮换制度。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune036"]
[OnName num="suzune"]
"我把早晨的事情留给了绯红。所以去找她吧。"
[cpg cn=true]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari015"]
[OnName num="himari"]
"早上好，五郎。你看起来不舒服。"
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
我感觉不舒服。我有一个奇怪的状况，首先是。
[cpg]


[OnName num="gorou"]
"......你好，Himari ...... 关于我的情况。"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari003"]
[OnName num="himari"]
"我知道。那么？你想让我做什么？"
[cpg cn=true]


她正试图让我说出来，脸上带着笑意。
[cpg]


看来爸爸已经出门了。这可能就是为什么绯红会说这样的话，但......
[cpg]


这仍然不是一个毫无保留的说法。绯红、铃音、妈妈和我是唯一知道我们在做什么的人。
[cpg]


爸爸是唯一不知道的人。只要爸爸不在这里，我们说什么都无所谓。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari004"]
[OnName num="himari"]
"你曾经和一个女孩牵过手吗？"
[cpg cn=true]


[OnName num="gorou"]
"不，我没有。"
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari005"]
[OnName num="himari"]
"嗯。那么，如果有人对你这样做，你会感到兴奋吗？"
[cpg cn=true]

在她说这句话的时候，绯红拉着我的手。
[cpg]


然后我们的手指交织在一起，......，这就是所谓的情人结。
[cpg]


我变得紧张。而苦涩的感觉也消失了。
[cpg]


[OnName num="gorou"]
"谢谢你，......."
[cpg cn=true]

[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari036"]
[OnName num="himari"]
"现在你是我的了，Goro ......"，她笑着说。
[cpg cn=true]


绯红似乎很高兴。
[cpg]


我猜这意味着她可能也有占有欲。
[cpg]


我不知道，但这就是我的感觉 ......
[cpg]

;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



然后我们吃早餐。铃音惊讶地看着我们。
[cpg]


但她知道为什么会发生这种情况。
[cpg]


早上，我去找绯红。下午，或者说在学校，铃音帮助我。晚上，我有妈妈.......，这似乎是惯例。
[cpg]


我在昨天和今天之间发现了这一点。这是一个每天三次安慰的惯例。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari037"]
[OnName num="himari"]
"这很好吃。炒蛋看起来很容易做，但其实不然。"
[cpg cn=true]


有这样的事情吗？"不能做炒蛋？我正这么想的时候，铃音捅了捅她。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune037"]
[OnName num="suzune"]
"你只是不想让他们......."
[cpg cn=true]


绯红不像是刚才和我牵手时的样子。
[cpg]


她好像换了个地方，还是什么。
[cpg]


但我想知道她和我单独在一起时是否也是这样。
[cpg]


我不知道。我不知道，但妈妈也是如此 ......
[cpg]


铃音有时会显得很紧张，但绯红和妈妈就不那么紧张了。
[cpg]




;//ブラックアウト


[window target=false]

[STOPBGM]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



铃音离开后的一段时间，我们去了学校。
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Himari038"]
[OnName num="himari"]
"我要走了。再见，戈罗。"
[cpg cn=true]


[OnName num="gorou"]
"嗯，是的。好吧，那我也要去了。"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa033"]
[OnName num="sawa"]
"嘿嘿，祝你今天愉快。"
[cpg cn=true]


那个微笑是什么意思？妈妈可能能看穿一切。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（朝）******************************************************





[OnName num="gorou"]
"哦，......，现在会发生什么......？"
[cpg cn=true]


我终于大声对自己说了我想过好几次的事情。
[cpg]


我不知道如果我不这样做会发生什么。
[cpg]


尽管他们不是我真正的家人，但我仍然过着让我心潮澎湃的生活。
[cpg]


话又说回来，我不能把妈妈、铃音或绯红看成只是家人。
[cpg]


我在痛苦中前往学校。
[cpg]





[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="ep001.ks" target="*start"]


;/////////////////////////////////////////////////////////////////////
