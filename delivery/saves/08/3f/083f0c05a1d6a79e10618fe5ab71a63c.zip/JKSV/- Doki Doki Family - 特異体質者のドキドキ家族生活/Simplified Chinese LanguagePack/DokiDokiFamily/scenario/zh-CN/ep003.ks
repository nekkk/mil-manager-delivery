
*start

;###################################################################
*Ep003|我的耐心已经接近尾声了。
;###################################################################


[SCENE id=3]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（朝）******************************************************





当你在城里走动时，它还是不错的。我是说，这一刻也很难说。
[cpg]


但还不足以让我感到心慌意乱。我也逐渐习惯了这些石头。
[cpg]


下一次，我姐姐会帮我做。等到这个时候，我走了。
[cpg]


如果我没有这样的短期目标，或者没有路线图，我也没办法。
[cpg]


当我想到它是永远持续下去的东西时，我感到很无助。......。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（朝）******************************************************


[SE f="se002"]
;//【ＳＥ】『喧噪』


然后我们到达了学院。我想我已经从第一天的捣乱管理中多少平静下来了。
[cpg]


[OnName num="male_student"]
'你前一阵子看起来有点不舒服，但你最近看起来好多了。这是一种解脱。"
[cpg cn=true]


[OnName num="gorou"]
'是的，...... 是的，我想这些天情况相当好。
[cpg cn=true]


我知道我周围的人认为这很奇怪。我在思考这个问题。
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************



上课的时候已经很辛苦了，而且是在中午。
[cpg]


我甚至在吃完饭之前就想去我姐姐那里，但那样她可能也吃完饭了。
[cpg]


最后，我终于在午休的后半段去了我姐姐那里。
[cpg]


我没有太多的时间，但我还是不能什么都不做。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune021"]
[OnName num="suzune"]
'......，听起来很痛苦。

[cpg cn=true]


[OnName num="gorou"]
姐姐......，我已经快死了。"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune084"]
[OnName num="suzune"]
'对。我被告知有获得另一种疾病的风险'。
[cpg cn=true]


她一边平静地说话，一边把我的手拉开。
[cpg]


我想如果她看到这一点会很糟糕，但她把我带到了学生咨询室。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_03_2_up.ui" time=1000]
[WAIT time=2000]


如果我不断地重复这样做，它一定会升级的。
[cpg]


如果是这样的话，我最终会不会也亲吻我的妹妹？
[cpg]


我想知道我的妹妹对我有什么看法，等等。
[cpg]


我不认为我想做她不希望我做的事。
[cpg]


或者......，她还会为我即将死去而感到悲伤吗？
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



我走出学生指导办公室，确定没有人在看。
[cpg]


如果有人看到我，他们又会对我说三道四。
[cpg]


我不能一直做这种事。
[cpg]


我需要更有创意一些，......，但我不知道怎么做。
[cpg]


我在校园里的整个过程中，都无法忍耐。
[cpg]



[window target=false]

[WAIT time=2000]

[BG f="b_03_3.ui" time=1500]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



同时，现在是放学后。
[cpg]


我试图回家。现在是我还能设法忍受的时候，.......。
[cpg]


[OnName num="male_student_A"]
'嘿，小坂。让我们回家休息一下，找点乐子。"
[cpg cn=true]


[OnName num="male_student_B"]
'你最近不善于社交。怎么了？"
[cpg cn=true]


[OnName num="gorou"]
'不，有事情发生。所以，请让我回家。......"
[cpg cn=true]


[OnName num="male_student_A"]
没有。好了，我们去电玩城吧。"
[cpg cn=true]


他一开始就是一个好朋友。我确实不能忽视他们。
[cpg]


但是你知道。......，我越晚回家就越难。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夜）******************************************************



男孩们就在我旁边。或者说，我和所有男孩一起玩。
[cpg]


而我却在寻找一个暗恋的对象。
[cpg]


我周围的人似乎不知道发生了什么事，他们以为我感冒了或什么。
[cpg]


所以我被提前释放了，但......，还是已经是午夜了。
[cpg]


[OnName num="gorou"]
'哦，......，这很糟糕，这是...... 糟糕。
[cpg cn=true]



我不禁想到了我母亲的脸。我想知道爸爸是否已经回来了。
[cpg]


如果我想让他做一些事情，我需要尽快做。......，我回去了，思考。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa080"]
[OnName num="sawa"]
'欢迎回来。你回来晚了。"
[cpg cn=true]


[OnName num="gorou"]
'对不起......，对不起。......
[cpg cn=true]


[OnName num="father"]
'你在哪里停了下来？　快到晚饭时间了。"
[cpg cn=true]


[OnName num="gorou"]
是的，......，那是......."
[cpg cn=true]


它不是为了告诉你在哪里停过车而建造的。
[cpg]


但这还不是最糟糕的部分。爸爸的家。
[cpg]


会不会是在他吃晚饭的时候，我必须坚持下去？
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


我的猜测是正确的。主要是因为我父亲回来后，我母亲不可能为我做什么。
[cpg]


我心里充满了苦涩，这让绯红觉得很好笑。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari091"]
[OnName num="himari"]
'嗯，嗯。'现在大哥哥，你真可爱。你的母亲真狡猾'。
[cpg cn=true]


[OnName num="father"]
'......?'
[cpg cn=true]


爸爸显然不知道我在说什么。
[cpg]


这很好，但我当时的情况很危急，我无法围绕它做出适当的决定。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



在最后一分钟，我母亲对我说。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa081"]
[OnName num="sawa"]
我在我的房间里等你。你可以随时来'。
[cpg cn=true]


他现在想去......。我是这么想的，但我不能让爸爸起疑。
[cpg]



;//ブラックアウト


远远超过了我的忍耐极限，我逐渐失去了自己的立足点。
[cpg]


就在那个时候，我去了我母亲的地方。
[cpg]


就像我再也无法忍受了。......
[cpg]


;//========================================
;//●ＣＧ（主人公に胸を押しつけるヒロイン。主人公の体に少し触れている感じ）ev_14
;//人物１：ヒロイン３
;//服装１：パジャマ
;//人物２：主人公
;//服装２：パジャマ
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa017"]
[OnName num="sawa"]
'你今天一定过得很辛苦。我要给你一个好的依偎'。
[cpg cn=true]


[OnName num="gorou"]
"...... 母亲，先生。"
[cpg cn=true]


[VOICE f="sSawa018"]
[OnName num="sawa"]
'这很难。现在一切都好了。"
[cpg cn=true]


[OnName num="gorou"]
哦，哦，......."
[cpg cn=true]


我感到很欣慰，忍不住要发出有趣的声音。
[cpg]


[VOICE f="sSawa019"]
[OnName num="sawa"]
'咯咯笑。这对你来说一定很困难。
[cpg cn=true]


仅仅通过触摸她，我就能感觉到我大脑中的一些东西。
[cpg]


我不禁知道，这一定是我现在需要的东西。
[cpg]


我很激动，但也松了一口气。这是一种奇怪的感觉，我已经失去了表情。
[cpg]


;**【ＣＧ】 ev_14_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa020"]
[OnName num="sawa"]
'我怎么能让你激动呢？
[cpg cn=true]


他一边说一边轻轻地抚摸着我的身体。我觉得我无法忍受它。
[cpg]


[OnName num="gorou"]
'我已经够紧张了。
[cpg cn=true]


[VOICE f="sSawa021"]
[OnName num="sawa"]
'是的。很好'。
[cpg cn=true]


我觉得我似乎想拥抱她，但我忍住了。
[cpg]


[VOICE f="sSawa022"]
[OnName num="sawa"]
'你的脉搏变得非常快。我可以感觉到它。
[cpg cn=true]


紧张是很自然的。有些人说，如果你接近这样一个美丽的人，你.......
[cpg]


还有来自一个地方的重击，比如说如果我爸爸发现了会怎么样。
[cpg]


我知道光是有这些感觉就是个问题。
[cpg]


我知道我这样做是不道德的，我也知道光有这些感觉是有问题的，但我不能压制它们。
[cpg]


;**【ＣＧ】 ev_14_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa023"]
[OnName num="sawa"]
你想今天再一起睡吗？
[cpg cn=true]


妈妈说了一句相当大胆的话。
[cpg]


[OnName num="gorou"]
'嗯，那是...... 确实不好。
[cpg cn=true]


[VOICE f="sSawa024"]
[OnName num="sawa"]
'我很好。只要五郎没问题就好。
[cpg cn=true]


当你说这样的话时，我很想这么做，但我......，忍住了。
[cpg]


如果我父亲发现了，他会怀疑发生了什么。
[cpg]


我父亲在某些方面可以说是直言不讳，但仍然是一个糟糕的......。
[cpg]


[OnName num="gorou"]
'......，我还是不行。我今天要回去了。"
[cpg cn=true]


[VOICE f="sSawa025"]
[OnName num="sawa"]
'是吗？　我这里永远欢迎你。"
[cpg cn=true]


当你说这样的话时，我几乎是在考虑。
[cpg]


不过，与我姐姐和绯红不同，我知道我不会在母亲的伴侣身上犯任何错误。
[cpg]



;//ブラックアウト

带着遗憾的心情，我离开了母亲的房间。
[cpg]


尽管这是我的职责，但他对我来说是一个不可替代的人，我不知道这样做是否正确。
[cpg]


这不可能是好事。......我知道，但我无法停止。
[cpg]






;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』



之后，我就瘫软在我的房间里。
[cpg]


不管我怎么觉得自己被折腾得太厉害了，我都无能为力......，靠自己的意志。
[cpg]


这主要是我的体质。但......
[cpg]


我想知道我母亲是否也对你有看法。或者，也许她不像我一样有任何暗恋的对象。
[cpg]


我还想到了这个：......
[cpg]



;//■選択肢
[switch]
[case "我为我的父亲感到遗憾。"]
	[swap]
	[jump target="*select02_1"]
[case "如果你对我有想法，我想回应一下。"]
	[swap]
	[jump target="*select02_2"]
[endswitch]

第一，我为我的父亲感到遗憾。
二，如果你对我有看法，我想回应。



;//==============================
;//１、父に申し訳ない
*select02_1|我的耐心已经接近极限了。




我为我的父亲感到遗憾，不是吗？我和妈妈是陌生人，但爸爸和妈妈是夫妻。
[cpg]


这并不意味着我们有血缘关系，但......，我仍然认为我做错了什么。
[cpg]


我并不是说，如果是绯红或我的妹妹，我就不会有任何想法。
[cpg]

[jump target="*select02_3"]


;//==============================
;//２、何か思ってくれてるなら応えたい

*select02_2|我的耐心已经接近极限了。



如果我妈妈还在想什么，我觉得我别无选择，只能做出回应。
[cpg]


即使是尖酸刻薄的关系，你也不能突然断绝关系。也许这是相互的。......
[cpg]



[stflag Cha3flg = 1]

;//ヒロイン３が候補に



;//==============================

*select02_3|我的耐心已经接近极限了。


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]



[jump storage="ep004.ks" target="*start"]


;/////////////////////////////////////////////////////////////////////
