

*start

;###################################################################
*Ep001|开始捣鼓管理。
;###################################################################

;//ブラックアウト
[SCENE id=1]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]

[SE f="se002"]
;//【ＳＥ】『喧噪』

[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************





[OnName num="female_student_A"]
'你的情绪有些变化，小坂君，......。
[cpg cn=true]


[OnName num="female_student_B"]
是的。 他只是一个食草动物，但他也是...... 忧郁的。"
[cpg cn=true]


我听到了，我听到了。我听着窃窃私语，想着。
[cpg]


他没有说我的坏话，这感觉很好。但是。
[cpg]


如果他们是因为我的宪法而这么说，我不知道该怎么说。
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************




而到了午餐时间，已经很辛苦了。我的脑袋里满是想要捣乱的想法。
[cpg]



我无法理解上午的最后部分。
[cpg]


我很难呼吸，我不能再想别的事情了。
[cpg]


这让我很抓狂，扑面而来的依赖性真的让我很难受。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************





[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune038"]
[OnName num="suzune"]
'......，是时候了，这很痛苦。我知道它的大部分内容。"
[cpg cn=true]


[OnName num="gorou"]
'哦，拜托。我不能再这样做了，我不能。......"
[cpg cn=true]


女性化的话语从我口中说出。但我不能帮助它。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune039"]
[OnName num="suzune"]
'好吧。来吧。"
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植前シーンカット

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_03_2_up.ui" time=1000]
[WAIT time=1000]

我跟着他来到学生指导办公室。
[cpg]


我进去了，想知道这次他们会对我做什么。
[cpg]


...... 结果，这和前几天发生的事情如出一辙。
[cpg]


我可以看到我的姐姐是多么关心我，试图不过度刺激我。
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



捣毁管理。每天三次，使心率上升：......
[cpg]


这是一个相当怪异的情况，但这就是我所处的那种情况。
[cpg]


一天三次已经很困难了。我希望它是这个数字的两倍。
[cpg]


但我们不能无休止地触摸对方，这可能会越界。
[cpg]


是否有这样的治疗方法？有一些人具有难以置信的吸引力，他们接近我。
[cpg]


我不能做我想做的事。我被管理得无以复加。
[cpg]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（夕方）******************************************************





[OnName num="male_student_A"]
'我听说了。他和小坂老师一起走进了学生咨询办公室。
[cpg cn=true]


[OnName num="male_student_B"]
'发生了什么事。那你做了什么？"
[cpg cn=true]


我认为被这样质疑是很自然的。
[cpg]


但我无法回答任何问题。
[cpg]


[OnName num="gorou"]
'这是职业建议。......，这没什么可担心的。
[cpg cn=true]


[OnName num="male_student_A"]
'有传言说你从里面出来的时候躺在......，很慌张。
[cpg cn=true]


这就是他们得到信息的程度。我下次离开时要小心了。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夕方）******************************************************





啊，我离开的时候会小心的。我迫不及待地想回家。
[cpg]


现在轮到我妈妈了。今天我已经可以承受了，如果我可以说我可以承受的话。......
[cpg]


不过，这还是让人相当苦恼的事。
[cpg]


我甚至不能和同学们交谈，更不用说认真上课了。
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』


[OnName num="gorou"]
'塔，我回来了。......'
[cpg cn=true]




[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa003"]
[OnName num="sawa"]
'欢迎回来。你现在很难受吗？"
[cpg cn=true]


[OnName num="gorou"]
'什么，......？　不，嗯，是......"
[cpg cn=true]


我没有立即回答，压抑着自己的感觉，我真的希望现在就能做点什么。
[cpg]


不知为何，我不想说我理解。另一方面，让我的母亲告诉我也不好。......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa004"]
[OnName num="sawa"]
'你不必如此。你看起来很苍白'。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSawa005"]
[OnName num="sawa"]
'我们今天该做什么？　你想和我一起洗个澡吗？"
[cpg cn=true]


他们看穿了这一切，感到很难堪。
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_04_3_up.ui" time=1000]
[WAIT time=1000]


话虽如此，我还是不能以尴尬为由拒绝。
[cpg]

[VOICE f="sSawa006"]
[OnName num="sawa"]
'是的，一件游泳衣。有了这个，你就不会感到尴尬了'。
[cpg cn=true]

[OnName num="gorou"]
'但是，但是......，我可以吗？
[cpg cn=true]


[VOICE f="sSawa007"]
[OnName num="sawa"]
'好的。我不想再看到你痛苦的脸。
[cpg cn=true]


我按母亲的要求做了，然后去洗澡。
[cpg]


......，希望没有人发现。
[cpg]


;//========================================
;//●ＣＧエロ（石けんで洗いながら手コキ。ヒロインは背後から片手で主人公の乳首も弄りながらしごく）ev_08
;//人物１：ヒロイン３
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：主人公の家＿風呂
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


这有点像我不能说我没有问题......，因为我穿着游泳衣。
[cpg]


我不知道要花多少钱，但我不知道和家人这样做是否可以，即使他们没有血缘关系。
[cpg]


[VOICE f="sSawa008"]
[OnName num="sawa"]
'当你在洗澡的时候，我也要给你洗身体吗？
[cpg cn=true]


妈妈表现得好像无动于衷。
[cpg]


[OnName num="gorou"]
'是的，很好。我自己会做的'。
[cpg cn=true]



而我呢，我的声音都快变了。
[cpg]


;**【ＣＧ】 ev_08_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sawa038"]
[OnName num="sawa"]
'你这么说，但你真的想把我宠坏，不是吗？
[cpg cn=true]


我有一种想要被呵护的欲望。但我不能大声说出来。
[cpg]


我感觉我的母亲也知道这一点，并且正在接近我。
[cpg]


[OnName num="gorou"]
这真的很好。......
[cpg cn=true]


[VOICE f="sSawa009"]
[OnName num="sawa"]
'别憋着了。我有一个不激动的借口'。
[cpg cn=true]



[OnName num="gorou"]
'当你称它为借口时，就更尴尬了。
[cpg cn=true]


妈妈笑了，用肥皂和海绵给他们擦洗。
[cpg]


;**【ＣＧ】 ev_08_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa010"]
[OnName num="sawa"]
'那好吧，让我给你洗吧。
[cpg cn=true]

海绵触动了我。这已经足够让我的心跳加速了。......
[cpg]


[VOICE f="sSawa011"]
[OnName num="sawa"]
我可以感觉到你的脉搏在加快。吁。
[cpg cn=true]


她的手指在泡沫上滑行。这种痒痒的感觉是骗人的。......
[cpg]


渐渐地，呼吸变得不那么困难了。这本身就是一件令人欣慰的事情。
[cpg]


再加上我与这样一个美丽的人亲密接触的事实。
[cpg]


那是一段可以说是幸福的时光。这部宪法可能并不全是坏事。
[cpg]


[VOICE f="sSawa012"]
[OnName num="sawa"]
我不知道我是否已经洗了大部分的东西。你还有什么要我洗的吗？"
[cpg cn=true]


你还有什么意思......，你还打算做什么？
[cpg]



[OnName num="gorou"]
'你想让我说什么？
[cpg cn=true]


我想说这是一种阻力，但妈妈却拂袖而去。
[cpg]


;**【ＣＧ】 ev_08_b ***********************
[CG id=3 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa013"]
[OnName num="sawa"]
'这是什么？　我想不出来了。"
[cpg cn=true]


妈妈可能有点刻薄，不是吗？
[cpg]



[OnName num="gorou"]
'...... 如果你想不出来，就不要说了。
[cpg cn=true]

[VOICE f="sSawa014"]
[OnName num="sawa"]
'嗯。好吧，那我就把你冲下去。
[cpg cn=true]


感受到了温暖的水。它不仅使你的脉搏加快，而且我认为它也提高了你的体温。
[cpg]


也许我妈妈也是这样，......？
[cpg]


[VOICE f="sSawa015"]
[OnName num="sawa"]
'什么？　那张脸。你想让我多洗洗吗？"
[cpg cn=true]


[OnName num="gorou"]
'呃，不。这没什么。"
[cpg cn=true]


热水会冲走泡沫。的确，这感觉有点像一种提醒。
[cpg]


我已经受够了敲打......，这不是你可以和你的家人一起做的事情了。
[cpg]






[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


等到跳动减弱时，我意识到我的呼吸不在了。
[cpg]


这提醒了我，如果我不真的捣鼓，就会有生命危险。......
[cpg]

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





做完这一切后，我们围坐在餐桌旁，看起来好像不知道发生了什么事。
[cpg]


我真的觉得我不应该这样做。
[cpg]



[SE f="se011"]
;//【ＳＥ】『食器の音』




[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune058"]
[OnName num="suzune"]
'...... 吾郎。你没有胃口吗？
[cpg cn=true]


[OnName num="gorou"]
不，思考......。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari039"]
[OnName num="himari"]
'在思考，嗯？我最近也在做大量的思考'。
[cpg cn=true]


主要是在想如何搞乱我。这就是我所想的。
[cpg]


[OnName num="father"]
'怎么了？　你说的是宪法。"
[cpg cn=true]


嗯，大概就是这样。爸爸是唯一被排除在这群人之外的人。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





然后我回到我的房间。每当我想起今天发生的事情，我就感到很尴尬。
[cpg]


我不知道该怎么做。我只需要修复我的体质，不是吗？
[cpg]


但如果我不知道如何解决它，我就不能做任何事情。......
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


[SE f="se004"]
;//【ＳＥ】『衣擦れ』

当我带着这些想法入睡时，我被一种奇怪的感觉惊醒了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari040"]
[OnName num="himari"]
'早上好，兄弟。
[cpg cn=true]


[OnName num="gorou"]
'...... 不，不是早安。
[cpg cn=true]


绯红正抚摸着我的头。这也与我的宪法有关吗？
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari006"]
[OnName num="himari"]
'大哥的头太值得抚摸了，不是吗？
[cpg cn=true]


...... 显然不是。他只是想挑逗我。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari007"]
[OnName num="himari"]
'进展如何？　你很激动吗？"
[cpg cn=true]


[OnName num="gorou"]
......，一般般。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari008"]
[OnName num="himari"]
我当时想，"好，好，好。你得说出来。"
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
绯红这样说，并把她的脸靠近他。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari009"]
[OnName num="himari"]
'看。我可能会像这样吻你'。
[cpg cn=true]


[OnName num="gorou"]
'哦，我很抱歉。......'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari010"]
[OnName num="himari"]
如果你知道我的意思的话。
[cpg cn=true]


;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************




[OnName num="gorou"]
......緋紅，你很卑鄙。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari011"]
[OnName num="himari"]
'你在说什么。我没有这么好的妹妹，你有吗？
[cpg cn=true]


...... 当然，如果你问我，那是真的。她一直是个皮实的姐姐，但现在她似乎真的很享受这种感觉。
[cpg]


我想。
[cpg]



;//■選択肢
[switch]
[case "她对我如此投入，我很高兴。"]
	[swap]
	[jump target="*select01_1"]
[case "我迫不及待地要修复这部宪法。"]
	[swap]
	[jump target="*select01_2"]
[endswitch]

第一，我很高兴你对我如此忠诚。
2、我想尽快修复这个宪法。



;//==============================
;//１、こんなに尽くしてくれて幸せだ
*select01_1|捣毁管理的开始




我很高兴绯红对我如此忠诚。
[cpg]


我相信一定有类似于爱的反面的东西。
[cpg]


当我想到这一点时，绯红似乎也是一个可爱的人。
[cpg]

[stflag Cha2flg = 1]

;//ヒロイン２が候補に

[jump target="*select01_3"]

;//==============================
;//２、早くこの体質を治したい

*select01_2|捣毁管理的开始



我知道我不想这样做太久。
[cpg]

如果可能的话，我想现在就解决我的体质问题，重新过上无忧无虑的生活。......
[cpg]


但我相信这将是更远的事情。
[cpg]



;//==============================

*select01_3|捣毁管理的开始

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep002.ks" target="*start"]



;/////////////////////////////////////////////////////////////////////
