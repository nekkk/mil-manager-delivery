
*start

;###################################################################
*Ep005|对Jujuon的看法
;###################################################################


;//１、寿々音
*select04_1|关于铃音的思考


[SCENE id=5]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


...... 我想这毕竟是我的妹妹。
[cpg]


我认为她是最可靠的人。有一些东西是缺失的，但即便如此，她与绯红和我的母亲完全不同。
[cpg]


绯红做什么事都太随和了，而我母亲则有些软弱和放松。
[cpg]


但这并不是爱上她的理由。
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



我早早起床，只有我和我妹妹。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune107"]
[OnName num="suzune"]
'早上好。你今天起得很早。"
[cpg cn=true]


[OnName num="gorou"]
'是的。...... 嘿，我需要和你谈点事。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune108"]
[OnName num="suzune"]
'我想知道。是关于宪法的吗？
[cpg cn=true]


我点点头，继续与我的妹妹交谈。
[cpg]


[OnName num="gorou"]
'......，我想如果我要爱上一个人，她会是唯一的一个。......'
[cpg cn=true]


[OnName num="gorou"]
'但如果我们那样做，我们就会在家族中结婚，不是吗？　所以，你知道。"
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
我一直在说，我不能归结为什么。最后。
[cpg]


[OnName num="gorou"]
'......，我应该怎么做呢？
[cpg cn=true]


他总结说。她没有给我一个惊愕的眼神。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune109"]
[OnName num="suzune"]
'首先，你必须和你喜欢的人在一起。'如果是因为你认为我会原谅你，这仍然不是一个好主意。
[cpg cn=true]


[OnName num="gorou"]
我知道。......，是的，我可以看到。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune110"]
[OnName num="suzune"]
'那么你最好考虑一下你喜欢谁。然后我们可以谈一谈。"
[cpg cn=true]


......，我不能说什么。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




;//＠
之后，绯红让我的心跳加快，我就去了学院。
[cpg]


不知何故，当我和绯红在一起时，我不能想太多东西。
[cpg]


我不禁想起了我的妹妹。
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************





然后我在学校花了一些时间。现在轮到我去我姐姐那里了。
[cpg]


在遇到她之前，我是如此紧张，以至于我无法与遇到绯红时相比。
[cpg]



;//ブラックアウト


[window target=false]



[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『学園教室』（昼）******************************************************





空荡荡的教室。我们带着某种尴尬的心情面对着对方。
[cpg]

;//ブラックアウト

;//========================================
;//●ＣＧ（主人公と密着するヒロイン。胸が当たっている）ev_16
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]





我的姐姐接近我。我们在学校里，而她却在做这个。
[cpg]


由于我的体质，这是没办法的事，无论我怎么想......。
[cpg]


并非所有其他看到这一幕的人都会这么想。
[cpg]


而这一事实正是让我心跳加速的原因。
[cpg]


[VOICE f="sSuzune022"]
[OnName num="suzune"]
'我不知道.......所有这些东西是否让你感到紧张？"
[cpg cn=true]


我只是与她保持密切联系。尽管这只是一次亲密接触，但我非常兴奋，因为她对我非常重要。
[cpg]


只要能有这样的感觉，能够接触对方就意味着很多。
[cpg]


[OnName num="gorou"]
......"
[cpg cn=true]


我甚至连一个字都说不出来。看到这一点，我妹妹很担心。
[cpg]


;**【ＣＧ】 ev_16_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune023"]
[OnName num="suzune"]
'如果你不说点什么，我就会担心。
[cpg cn=true]


当他走到那一步时，我终于回复了。
[cpg]


[OnName num="gorou"]
'是的。这是非常......。"
[cpg cn=true]


;**【ＣＧ】 ev_16_b ***********************
[CG id=7 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune024"]
[OnName num="suzune"]
'不要告诉我这很好。你会让我意识到这一点'。
[cpg cn=true]


她很冷淡，但我可以看出她有点尴尬。
[cpg]


如果她感到尴尬，说明她对我有看法。
[cpg]


这也让我很高兴。除了高兴之外，我还想说的是。
[cpg]


[OnName num="gorou"]
你脸红了。
[cpg cn=true]


;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune025"]
[OnName num="suzune"]
'你这么说，但你也是如此。
[cpg cn=true]


我一直希望能在她身边。
[cpg]


如果我说，只要有她在，我就不需要别的东西，我觉得对绯红很不好 .......
[cpg]


即便如此，我的姐姐对我来说是一个不可替代的存在。
[cpg]


我不知道如何将她与其他任何人进行比较。
[cpg]


;**【ＣＧ】 ev_16_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune026"]
[OnName num="suzune"]
'我的身体也开始发热，我在这里......，这让我很尴尬。
[cpg cn=true]


我对我和我妹妹之间这种微妙的距离感念念不忘。
[cpg]


当然，现在我在身体上非常接近，但我的思想却不是。
[cpg]


[OnName num="gorou"]
'......，你妹妹似乎也很激动。
[cpg cn=true]


我注意到，她的脉搏在加快。
[cpg]


;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune027"]
[OnName num="suzune"]
'真的吗？　不仅仅是你这样。"
[cpg cn=true]


[OnName num="gorou"]
'我不这么认为。......，我认为这是我的想象力。
[cpg cn=true]


[VOICE f="sSuzune028"]
[OnName num="suzune"]
'这只是我的想象。
[cpg cn=true]


我所说的一些话是真的吗？这就是我的想法，我们都在......。
[cpg]


在这个世界上只有我们两个人，或者说他们是这么说的，但这是一个学院。
[cpg]


我可以听到另一个学生的声音就在外面。我有一部分人感到紧张，因为我们并不孤单。
[cpg]


教会我这些感觉的姐妹是不可替代的。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


我和我妹妹在白天的时候互相触摸。
[cpg]


晚上，是我的母亲。早上是绯红。那些日子已经持续了很久，现在也不会改变。
[cpg]


[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





第二天早上。向学校走去，我在路上与女孩们会合。
[cpg]


[OnName num="female_student"]
'早上好，小坂君。
[cpg cn=true]


[OnName num="gorou"]
'哦，早上好......'
[cpg cn=true]


[OnName num="female_student"]
'最近，小坂君改变了他的情绪，是吗？我不知道该怎么说，这更像是忧郁。......
[cpg cn=true]


[OnName num="gorou"]
'什么，......？　你在说什么？"
[cpg cn=true]


[OnName num="female_student"]
'不，这没什么!　到时见。"
[cpg cn=true]


...... 那个迅速离开的女孩可能也对我有好感。
[cpg]


我也没有一个这样的女孩。
[cpg]


但当你想到要一起度过你的余生时，情况就不同了。
[cpg]


回想起来，我跟随姐姐的脚步已经有很长一段时间了。
[cpg]


我一直很佩服她。我又意识到了这一点。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


然后早晨又变成了中午，是我和我妹妹在一起的时候了。
[cpg]

[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[OnName num="gorou"]
'......Oh，请。这对我来说已经很困难了。......"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune130"]
[OnName num="suzune"]
'这对你来说一定很困难。我知道，如果我站在你的立场上，我也会很难过。
[cpg cn=true]


...... 一些奇怪的说法。如果你处于我的位置，你会怎么做？
[cpg]


[OnName num="gorou"]
你的意思是......？"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune029"]
[OnName num="suzune"]
'这没什么。更重要的是，你今天在做什么？
[cpg cn=true]


我是被迫作弊的。而我仍然呼吸困难。
[cpg]



我不能过多地考虑其他事情。对。
[cpg]


[OnName num="gorou"]
那好吧，......."
[cpg cn=true]


;//========================================
;//●ＣＧ（座っているヒロインのことを見つめる主人公）ev_17
;//人物１：ヒロイン１
;//服装１：スーツ（はだけ）
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


我想出了一些和以前不一样的东西，我决定给它一个机会。
[cpg]


我妹妹看起来有点惊愕，但这很好，包括她脸上的表情。
[cpg]


[VOICE f="Suzune134"]
[OnName num="suzune"]
'......，你想出了最奇怪的事情。
[cpg cn=true]


今天，我将停止要求我的妹妹触摸我或接近我。
[cpg]


我想看着我妹妹。我曾要求她这样做。
[cpg]


[OnName num="gorou"]
'这并不奇怪。我认为你想一直看着我。
[cpg cn=true]


她似乎对我的话有些迷惑。
[cpg]


;**【ＣＧ】 ev_17_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune030"]
[OnName num="suzune"]
'你确定你想这样做，只是看着？
[cpg cn=true]


[VOICE f="sSuzune031"]
[OnName num="suzune"]
'我认为你需要触摸它或接近它，或......，这样的东西。
[cpg cn=true]


没有这些，我就已经很激动了。我现在可能会这样。
[cpg]


[OnName num="gorou"]
...... 是的。"
[cpg cn=true]


看着她，她似乎是我需要的一切。
[cpg]


我不好意思这么说，但我这么想也没关系。
[cpg]


;**【ＣＧ】 ev_17_b ***********************
[CG id=8 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune032"]
[OnName num="suzune"]
她看五郎的样子，有点恶心。"
[cpg cn=true]


[OnName num="gorou"]
'是的，我不认为如此。
[cpg cn=true]


她看起来很困惑和尴尬。
[cpg]


唯一的一点是，被盯着看是被盯着看的人可能在想的事情。
[cpg]


[OnName num="gorou"]
'姐姐......，真的非常、非常漂亮。
[cpg cn=true]


她刚才在看我，现在又看向别处。
[cpg]


;**【ＣＧ】 ev_17_c ***********************
[CG id=8 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune033"]
[OnName num="suzune"]
'你怎么敢？
[cpg cn=true]


[OnName num="gorou"]
'我没有撒谎。我是认真的。
[cpg cn=true]


她对我的话做出了轻微的颤抖姿态。
[cpg]


[VOICE f="sSuzune034"]
[OnName num="suzune"]
我的手指都没放在她身上，但这太奇怪了。这也让我很紧张。
[cpg cn=true]


姐姐说这话时脸红了。
[cpg]


我不能就这样看着她。
[cpg]


[OnName num="gorou"]
我想继续盯着她看。姐姐。
[cpg cn=true]


那个更害羞的妹妹开口了。
[cpg]


;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune035"]
[OnName num="suzune"]
'......，就像被五郎的话语所触动。
[cpg cn=true]


她这样说并不是在撒谎。
[cpg]


作为证据，她的妹妹甚至脸红到了耳根。
[cpg]


我想观察一切，甚至她的样子。这就是我的感觉。
[cpg]


接受我的目光和话语的姐妹。
[cpg]


我觉得那里有一些像母亲的东西。
[cpg]


[OnName num="gorou"]
'即使我只是看着她，我也很高兴。
[cpg cn=true]


;**【ＣＧ】 ev_17_c ***********************
[CG id=8 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune036"]
[OnName num="suzune"]
'不要感到尴尬。不过，我受宠若惊了。
[cpg cn=true]


她当然看起来既尴尬又高兴。
[cpg]


我只为这个感到高兴。
[cpg]


[FG f="ci_lbox.ui" method="feadin_up"  pos="4/7"]

[WAIT time=1000]
;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】『学園のチャイム』


时间过去了一段时间。我们不可能永远在一起，我们不可能和对方在一起。
[cpg]


午餐时间过后，我和姐姐都要去上课。
[cpg]


这一次比以往任何时候都更让人沮丧。
[cpg]





[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


还有下午上课后，放学后。
[cpg]


[window target=false]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



傍晚时分的学校。我们离开教室，试图回家。
[cpg]


在那里我有这样的想法。
[cpg]


一天三次，一天三次，我有时间激动不已。......
[cpg]


所有这些，我都是为了想和我妹妹在一起。
[cpg]


首先，我必须和我妈妈谈谈。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************





当我回到家时，就像这样，只有我妈妈在那里。
[cpg]


[OnName num="gorou"]
'哦，你知道，...... 母亲。
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa101"]
[OnName num="sawa"]
'这是什么？　这对你来说有点早，不是吗？"
[cpg cn=true]


[OnName num="gorou"]
'不，不是那个，是那个。这是关于你晚上要为我做什么，我想让...... 你的妹妹来代替我。
[cpg cn=true]


我解释说。只有关于我喜欢我妹妹的部分仍然被隐藏着。
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa102"]
[OnName num="sawa"]
'...... 是的。我明白了。
[cpg cn=true]


但我的妈妈似乎把一切都想好了。这是正确的，她是我的母亲。......
[cpg]




;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[WAIT time=1000]

[SE f="se012"]
;//【ＳＥ】『ノック』


[WAIT time=1500]

[window target=true]


;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune151"]
[OnName num="suzune"]
我进来了，戈罗。
[cpg cn=true]


[OnName num="gorou"]
呃，是的。...... 进来吧。"
[cpg cn=true]


[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune037"]
[OnName num="suzune"]
'我听说了。你想让我做你母亲的那份？
[cpg cn=true]


[OnName num="gorou"]
我不知道我是否应该......，真的，但这取决于我。"
[cpg cn=true]


不知怎的，我有种感觉，他们不会说不。
[cpg]


然后姐姐微微叹了口气，然后
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune153"]
[OnName num="suzune"]
'你认为如果你告诉我这些，我能说不吗？　真的，他是一个可爱的小兄弟。"
[cpg cn=true]



;//========================================
;//●ＣＧ（密着する二人。ヒロインが体を前に倒している状態。ヒロインの髪が主人公の体に当たっている）ev_18
;//人物１：ヒロイン１
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：主人公の部屋
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]


[SE f="se004"]
;//【ＳＥ】『衣擦れ』


[BGM f="bg_h1"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune038"]
[OnName num="suzune"]
'也许......，我也已经疯了。
[cpg cn=true]


他说这话时，表情略显浑浊，或者说他的眼睛里有一种忧郁的神情。
[cpg]


[OnName num="gorou"]
'你这话是什么意思？
[cpg cn=true]


姐姐在选择她的话语。她仿佛不知道该说什么。
[cpg]


[VOICE f="sSuzune039"]
[OnName num="suzune"]
'没有你，我感觉好像我的心在痛苦。
[cpg cn=true]


...... 我应该如何看待这个问题？
[cpg]


与其说是深思熟虑，不如说是感觉他按捺不住，言之有物。
[cpg]


当然，我的体质让我很痛苦，但我无法想象我的妹妹会从我这里得到这些。
[cpg]


[VOICE f="sSuzune040"]
[OnName num="suzune"]
'我觉得我想更接近你。我不知道为什么'。
[cpg cn=true]


你妹妹的长发贴着我的身体。我感到很沮丧。
[cpg]


[OnName num="gorou"]
'妹子。你的头发让我很痒。"
[cpg cn=true]


她不是没有注意到，但我敢于说出来。然后。
[cpg]


;**【ＣＧ】 ev_18_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune041"]
[OnName num="suzune"]
'真的吗？　你不喜欢它？"
[cpg cn=true]


他说了一句话，让人分外难受。
[cpg]


[OnName num="gorou"]
'......，我并不讨厌它。
[cpg cn=true]


[VOICE f="sSuzune042"]
[OnName num="suzune"]
'很好，那么。让我像这样多呆一会儿吧'。
[cpg cn=true]


姐姐说了一些咄咄逼人的话。我不觉得我这样做只是为了让她紧张。
[cpg]


也许这就是它的开始，但它与我的宪法已经没有关系。
[cpg]


我觉得我们已经到了一个不应该有的地步。
[cpg]


但这是......，即使如此，我也不讨厌它。
[cpg]


[OnName num="gorou"]
'是的。这是......，直到它让你感觉更好。"
[cpg cn=true]


;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune043"]
[OnName num="suzune"]
'这很古怪。我是为了你的宪法而做的。
[cpg cn=true]


但我觉得那是一个借口，或者说是我们共同的逃避途径。
[cpg]


当这种体质被治好后，我们将做什么？
[cpg]


[VOICE f="sSuzune044"]
[OnName num="suzune"]
'我可以闻到五郎的味道。
[cpg cn=true]


当然，相反的情况也是如此。这就是我们的关系。
[cpg]


仿佛不仅是我们的身体，而且我们的心也变得更加紧密。
[cpg]


;**【ＣＧ】 ev_18_b ***********************
[CG id=9 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune045"]
[OnName num="suzune"]
这很奇怪。我们总是在一起，但你似乎是一个不同的人。
[cpg cn=true]


当她这样说时，她更加靠近。呼吸打。
[cpg]


我希望时间能像这样停止。我想这么想，我觉得扑通扑通的声音让我很解气。......
[cpg]


因重击而感到安心，听起来好像很矛盾，但对此刻的我来说，这是个正确的词。
[cpg]


我相信这是一对半路出家的恋人所感受不到的。
[cpg]


;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune046"]
[OnName num="suzune"]
我想多和你在一起。我也很担心你。
[cpg cn=true]


尽管我和妹妹没有血缘关系，但我们也是姐妹和兄弟。
[cpg]


我在那里感到安全一定是有原因的。
[cpg]


[VOICE f="sSuzune047"]
[OnName num="suzune"]
'如果这样做会让我感觉更好，我会......，一直这样做。
[cpg cn=true]


她在说这句话时，把她的皮肤拉到我身上。
[cpg]


[OnName num="gorou"]
'我很高兴。姐姐'。
[cpg cn=true]


这对我来说是一种浪费，但这并不意味着我不想把它给别人。
[cpg]


我想让她成为我的亲妹妹。
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]



[OnName num="gorou"]
'谢谢你。我现在很好。"
[cpg cn=true]


呼吸不再有任何疼痛感。但我的心却有些痛苦。
[cpg]


仿佛我的身体和思想彼此不一致。
[cpg]


[VOICE f="sSuzune048"]
[OnName num="suzune"]
'真的吗？　别紧张。"
[cpg cn=true]


我真的很想和你睡觉，但如果我这样做了，我可能会习惯于我所受到的重击。
[cpg]



[window target=false]


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




我不觉得自己会被那些常见的、奇怪的梦境惊醒。
[cpg]


也许这是对我姐姐为我所做的事情的满足。
[cpg]


我并不感到孤独，即使是在一个人的房间里。......
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



还有早晨。现在我必须要和绯红谈谈。
[cpg]


我想我应该昨天就做了，因为......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari026"]
[OnName num="himari"]
'早上好。来吧，今天我再给你一个刺激。"
[cpg cn=true]


真让人吃惊，因为绯红走过来对我说。
[cpg]


她还把她漂亮的大奶子推给我，但我虽然不应该被扫地出门。
[cpg]


[OnName num="gorou"]
'哦，你知道，......，我很抱歉你总是这样对我，但那.........'。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari117"]
[OnName num="himari"]
'什么？　你甚至想让我和你妹妹交换位置吗？"
[cpg cn=true]


[OnName num="gorou"]
是的。......"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Himari118"]
[OnName num="himari"]
'我主要是从你母亲那里听说的。你一定是真的那么喜欢你的妹妹'。
[cpg cn=true]


绯红看起来有点悲伤。
[cpg]


这就是为什么，或者说......，我感到有什么东西把我推到了边缘。
[cpg]


我不能再这样下去了。半心半意的态度甚至会伤害到绯红。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune170"]
[OnName num="suzune"]
'......，我也在早上做？　一天三次，不过都是由我来做。"
[cpg cn=true]


[OnName num="gorou"]
'哦，不？
[cpg cn=true]


她笑了一下。我一定是看起来很傻。
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune049"]
[OnName num="suzune"]
'不，我不知道。然后.......'。
[cpg cn=true]


;//ブラックアウト

;//========================================
;//●ＣＧ（主人公に寄り添うヒロイン。朝出かける前）ev_19
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：朝
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



我不需要任何更多的话，但我不想保持沉默，所以我说。
[cpg]


[OnName num="gorou"]
'这很温暖。'姐姐'。
[cpg cn=true]


姐姐看着我。然后她问道。
[cpg]


[VOICE f="sSuzune050"]
[OnName num="suzune"]
'......，难道你光是在我身边就没有快感了吗？
[cpg cn=true]


[OnName num="gorou"]
'不。不，不是的'。
[cpg cn=true]


[VOICE f="sSuzune051"]
[OnName num="suzune"]
你确定你没有在逼迫它吗？"
[cpg cn=true]


[OnName num="gorou"]
'这是真的，我告诉你。你看起来没有任何痛苦的证据'。
[cpg cn=true]


[VOICE f="sSuzune052"]
[OnName num="suzune"]
'真的吗？　我希望如此。"
[cpg cn=true]


她在说这句话时向我靠拢。
[cpg]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[VOICE f="sSuzune053"]
[OnName num="suzune"]
'...... 吾郎对我来说比什么都重要。我很抱歉让你认为我不是。
[cpg cn=true]


触感柔软。就在这时，我的心才停止了跳动。
[cpg]


我想更接近。我的欲望并没有就此停止。
[cpg]


我想成为你的...... 情人。
[cpg]


[OnName num="gorou"]
姐姐。嗯，嗯......"
[cpg cn=true]


我正准备说些什么，我妹妹却不肯闭嘴，看到我说不出话来。
[cpg]


;**【ＣＧ】 ev_19_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune054"]
[OnName num="suzune"]
'我也很紧张，......，你知道吗？
[cpg cn=true]


[OnName num="gorou"]
是的。我得到了这个消息'。
[cpg cn=true]


就像我越不主动，我妹妹就越亲近。
[cpg]


这种关系在某种程度上让人感到安心，与重击的方式不同。
[cpg]


;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune055"]
[OnName num="suzune"]
胡胡，这有点尴尬。"
[cpg cn=true]


他们在一起的时间在谈论这些事情时过去了。
[cpg]


[OnName num="gorou"]
'我可能会感到尴尬，但我想留在你的身边......。
[cpg cn=true]


[VOICE f="sSuzune056"]
[OnName num="suzune"]
是的，我也一样。"
[cpg cn=true]


她觉得自己与姐姐的关系比任何人都要密切，但仍然感到很沮丧。
[cpg]


[VOICE f="sSuzune057"]
[OnName num="suzune"]
'吾郎......'
[cpg cn=true]


她抚摸着我的头，低声说。
[cpg]


她抚摸着我的头发。她的脸也走近了。
[cpg]


而且她的嘴唇越来越近。我赶紧闭上眼睛。
[cpg]


我几乎失去了距离。我不能以这种紧迫性做任何事情。
[cpg]


;**【ＣＧ】 ev_19_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune058"]
[OnName num="suzune"]
'周周'。
[cpg cn=true]


他们互相抚摸。她向我走了一步。
[cpg]


我太爱她了，以至于我觉得自己要......，失去了控制。言语无法解释我有多爱她。
[cpg]


我不认识这么可爱的人。我觉得我现在就想抱抱她。
[cpg]


我不能永远这样做，尽管我无法抗拒。
[cpg]


;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune059"]
[OnName num="suzune"]
......，差不多该走了。我得走了。"
[cpg cn=true]


在我什么都做不了的时候，我姐姐对我说了这句话。
[cpg]


我咒骂自己的无能，但我很高兴她吻了我。
[cpg]


[OnName num="gorou"]
我很高兴她吻了我。回头见。"
[cpg cn=true]


我不可能在一段时间内忘记她嘴唇的感觉。
[cpg]


我是说一段时间。...... 这将是一个我永远不会忘记的吻。
[cpg]


;//ブラックアウト



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


然后我妹妹比我先离开了家。
[cpg]


这是很平常的事情，但关于它的孤独感却与平常不同。
[cpg]


我去学校的时候会看到她，但我会非常想念她。
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa103"]
[OnName num="sawa"]
我待会儿见。要小心。
[cpg cn=true]


[OnName num="gorou"]
'是的，我去了......'。
[cpg cn=true]


我们和绯红一起离开了房子。我心里有一些想法。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************



我要向我姐姐坦白。我想和她在一起。
[cpg]


她是我不可替代的妹妹，但我还是想。
[cpg]


我还想亲吻她，拥抱她。
[cpg]


这并不是说我想治愈这种体质或什么。......
[cpg]


我意识到，我仍然喜欢我的妹妹。
[cpg]


我可以说，这要归功于绯红。如果她不告诉我，我可能永远不会从心底里意识到这一点。
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

白天，像往常一样，我让我的姐姐提高我的心率。但在放学后，......。
[cpg]

[WAIT time=1000]

[STOPBGM]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（夕方）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune190"]
[OnName num="suzune"]
'现在怎么办......？　你在白天已经做过了。"
[cpg cn=true]


[OnName num="gorou"]
'...... 姐姐，你说我应该和我喜欢的人在一起。
[cpg cn=true]


姐姐的表情变得有些僵硬。也许她在想象会说什么。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune191"]
[OnName num="suzune"]
'......，那怎么办？
[cpg cn=true]


不过，我还是得说。我不能让我妹妹猜到。
[cpg]


如果我在这样的地方被宠坏了，我的余生就真的被宠坏了。
[cpg]


[OnName num="gorou"]
"哦，我......，我是，你知道，......"。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune192"]
[OnName num="suzune"]
'我知道，我知道。你喜欢我，对吗？"
[cpg cn=true]


哦，不。这种趋势将使我的余生都受到宠爱。
[cpg]


但我现在不能帮助它。我已经说了我的观点。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune193"]
[OnName num="suzune"]
'别担心，我也喜欢你。不是作为一个兄弟，而是作为一个情人。
[cpg cn=true]




;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



我和我妹妹分别回家。我们有不同的工作和学习，有不同的时间投入其中。
[cpg]


但我想了一下，至少今天我想一起回家。
[cpg]


最后，我姐姐让我先回家，但......，我有点迫不及待地想见到她。
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





那天的饭桌上没有什么异常。
[cpg]


我还是和往常一样。我妹妹和往常一样。
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari119"]
[OnName num="himari"]
'再来一个!　大约百分之七十在碗里！"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune194"]
[OnName num="suzune"]
'你会发胖的。
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Himari120"]
[OnName num="himari"]
'与我姐姐不同，我并没有得到多少好处，我。
[cpg cn=true]


我认为我的姐姐是瘦的那个，緋紅说。
[cpg]


但姐姐并没有露出厌恶的神情。或者说，她在某种程度上高于它。......。
[cpg]


...... 我想知道他们是否在想我。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





还有夜晚。我妹妹在我的房间里。
[cpg]


[OnName num="gorou"]
'呃，呃，......，很高兴见到你。
[cpg cn=true]


一天三次，出于三次心跳。然而，我却非常紧张。
[cpg]


在这一切中，我妹妹对我说。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune060"]
[OnName num="suzune"]
'我必须告诉你，我从来没有过女朋友。
[cpg cn=true]


[OnName num="gorou"]
'诶......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune061"]
[OnName num="suzune"]
我是说你是第一个。"
[cpg cn=true]


说着，她向他走近。
[cpg]


;//移植前シーンカット
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]

;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]



[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

当我和姐姐在一起时，我觉得内心深处很充实。
[cpg]


这可能是人们固有的东西，而不是与他们的宪法有关的东西。
[cpg]


我感到很兴奋。甚至在她离开后，我也睡不着，因为我太紧张了。
[cpg]


我想让她永远留在我身边。但她离开了房间。
[cpg]


我说这是没办法的事，我也没办法。如果我父亲发现她从我的房间出来，那就糟糕了。
[cpg]


我没有选择，只能等待明天。
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



然后明天就来了，这有点尴尬。
[cpg]


我从未想过我会有这样的感觉。她是我一直认识的那个姐姐。
[cpg]


她看起来像一个不同的人，或者也许是我变了。
[cpg]


我目送她离开房子，心想。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune213"]
[OnName num="suzune"]
我第一次见到她时，我想："好吧，那我走了，戈罗。绯红。
[cpg cn=true]


[OnName num="gorou"]
'是的。要小心。"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari121"]
[OnName num="himari"]
祝你有个愉快的一天。"
[cpg cn=true]

[free time=1000]
爸爸也离开了家。我们剩下的三个人是我、绯红和我母亲。
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Sawa104"]
[OnName num="sawa"]
'那么，你打算怎么做？　我想知道他是否要和铃音约会。
[cpg cn=true]


[OnName num="gorou"]
'E...... yeah, yeah.这就是计划'。
[cpg cn=true]


经过片刻的困惑，我能够给出我的答案。
[cpg]


我再也无法隐藏它了。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="Himari122"]
[OnName num="himari"]
'要快乐。我也喜欢你的哥哥'。
[cpg cn=true]


[OnName num="gorou"]
"...... 是的。"
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』





还有学院的一个空教室。
[cpg]


我与我的妹妹面对面，摇摇晃晃，挣扎着要呼吸。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune214"]
[OnName num="suzune"]
'...... 我。我不想这样做，因为我的体质。
[cpg cn=true]


他一边走一边告诉我这些。
[cpg]


我猜他很担心，因为他在想我。我对此有一定的了解。
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune215"]
[OnName num="suzune"]
'此外，当绯红和你母亲在处理五郎时，我不禁感到嫉妒。
[cpg cn=true]


[OnName num="gorou"]
'......，就是这么回事。
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune062"]
[OnName num="suzune"]
'不过，现在很好。我将填补...... 他们所有人。"
[cpg cn=true]


对。关于我的一切都在我姐姐的手上。
[cpg]


这感觉相当令人欣慰。
[cpg]


;//移植前シーンカット



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

从现在起，我可以永远呆在你身边。仅仅是这样想，我就觉得有点松了一口气。
[cpg]


[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************



在我松了一口气的同时，我对捣蛋的欲望也越来越强烈。
[cpg]


这其实只是一个小小的时间差，但我再也受不了了。
[cpg]


我再也无法忍受了。但我姐姐说那是晚上。
[cpg]


首先，现在她是我的妹妹而不是我的母亲，我不能一回家就看到她。
[cpg]


我走了，感觉无法忍受。......
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





晚餐。现在的情况是，我爸爸是唯一不知道我和我妹妹之间关系的人。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari123"]
[OnName num="himari"]
'那么你的姐姐和弟弟去哪里了？
[cpg cn=true]


在这一切中，绯红说了这样一段话。我差点把吃的东西喷出来。
[cpg]


[free time=1000]

[OnName num="father"]
'你在说什么？
[cpg cn=true]


[OnName num="gorou"]
'不，这没什么!　这没什么。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]

话虽如此，我的妹妹看起来有点暴躁。
[cpg]


是的，有一天我必须向我父亲解释。
[cpg]


他从来没有像一个严格和顽固的父亲，但......
[cpg]


不过，有些事情还是让我紧张。一想到要告诉我爸爸，我就有些焦虑。
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





而且夜夜如此。在我达到极限之前，我妹妹来到我的房间。
[cpg]



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune063"]
[OnName num="suzune"]
'你看起来很高兴。
[cpg cn=true]


[OnName num="gorou"]
'......，有那么明显吗？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune064"]
[OnName num="suzune"]
'是的。不过，她在这方面也很可爱。
[cpg cn=true]


我很尴尬，但等着看我妹妹会怎么做。
[cpg]


我不知道，我经常这样做。不过，我倾向于带头。
[cpg]

;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



我看着姐姐再次回到她的房间，我在痛苦中设法睡着了。
[cpg]


明天，我们仍将是恋人。我很高兴。......
[cpg]


我应该高兴得不得了，但我的体质里有一种紧绷感。
[cpg]


我必须做一些事情。要做到这一点，我想我需要和我的妹妹做一些更有情趣的事情。
[cpg]


这是一种...... 巨大的事情，但首先我必须向我父亲解释。
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


而这一天出乎意料地迅速到来。
[cpg]

[window target=false]

[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************





[OnName num="gorou"]
'嗯，我不能!　我还没有准备好。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune253"]
[OnName num="suzune"]
'爸爸，我今天心情很好。'不是说他总是心情不好。
[cpg cn=true]


;//＠
一个星期天。有人找我谈了这个问题。
[cpg]


我的意思是，我告诉我爸爸。"把你的女儿给我！"还有。
[cpg]


;//ブラックアウト


[window target=false]

[STOPBGM]

[free time=1000]

[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



没有绯红和妈妈。这是我、我爸爸和我妹妹。
[cpg]


[OnName num="father"]
"......"
[cpg cn=true]


[OnName num="gorou"]
"......"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune254"]
[OnName num="suzune"]
'所以这就是为什么我们......，不，吾郎可以和你说话吗？
[cpg cn=true]

爸爸没有严厉的面孔，但接近于无表情，有点吓人。
[cpg]


[OnName num="gorou"]
'嗯，把你的女儿交给...... 我。
[cpg cn=true]


[OnName num="father"]
......"
[cpg cn=true]


在我说这句话的时候，我想我看到了爸爸嘴角的微笑。
[cpg]


[OnName num="gorou"]
'志，不。嗯，我想和我妹妹...... Suzune-san出去，或者说，我们要出去。
[cpg cn=true]


[OnName num="father"]
'噗，哈哈哈!　哦，是的，我知道你有一天会这样。"
[cpg cn=true]


[OnName num="gorou"]
什么？......？"
[cpg cn=true]


爸爸的反应令人惊讶。我原本以为他也会感到困惑。
[cpg]


[OnName num="father"]
'不，在这种情况下，要照顾好铃音。我相信五郎将能够帮助你'。
[cpg cn=true]


他宽慰地笑了笑，向我们表示祝贺。
[cpg]


我想，这是一个多么伟大的父亲，当然我也很感激......，所以......
[cpg]


[OnName num="gorou"]
哦，非常感谢你，......."
[cpg cn=true]


我说。我从来没有对我父亲经常使用过礼貌用语。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





[OnName num="gorou"]
'......，很顺利。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune255"]
[OnName num="suzune"]
'对。我以为我是有点名气的'。
[cpg cn=true]


他们在那里仍然是父子关系吗？
[cpg]


我不理解我父亲的所有感受，但我的姐姐似乎理解。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune256"]
[OnName num="suzune"]
我不知道怎么做，但我不打算这样做。这很难，不是吗？"
[cpg cn=true]


[OnName num="gorou"]
'是的。......，这很难。
[cpg cn=true]


我的体质仍在愈合。我很确定我已经爱上了，但可能还需要一点时间才能治愈我的体质。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune065"]
[OnName num="suzune"]
'来。现在我希望你能让...... 我激动不已'。
[cpg cn=true]


[OnName num="gorou"]
'......，我会努力的。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune258"]
[OnName num="suzune"]
胡忧，你已经长大了，可以这么说了。"
[cpg cn=true]


姐姐拍拍她的头。我感到很尴尬。
[cpg]

;//移植前シーンカット

;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************




几天的通行证。暑假已经开始，嗯，没关系。
[cpg]


校外已经有传言说我爱上了我的妹妹。
[cpg]


而在到处都是谣言的情况下，暑假仍然是曙光。
[cpg]


这成为全校的大新闻。无数的男孩为此感到震惊，甚至女孩也有一些粉丝或不知道。......
[cpg]



[window target=false]

[STOPBGM]

[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]


[window target=true]


;//【ＢＧ】『街』（夜）******************************************************



尽管如此，日子还是一天天过去了。我想毫无顾忌地以我姐姐的情人身份出现。
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune066"]
[OnName num="suzune"]
'......，现在，你难道不觉得苦吗？
[cpg cn=true]


[OnName num="gorou"]
是的。 轻松多了。"
[cpg cn=true]


从那时起，我的体质就像一个谎言一样安定下来。
[cpg]


所以医生说的都是真的，起初我以为是个笑话。
[cpg]


我想知道我是否可以用'宪法'这个词把它收起来，但我和我妹妹没有必要再靠近了。
[cpg]


不过，这并不改变我们想要对方的事实。
[cpg]


[OnName num="gorou"]
我能说什么呢，那些日子好像是个谎言。......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune278"]
[OnName num="suzune"]
'对。那些日子是那些日子，它们很有趣，但是......
[cpg cn=true]


[OnName num="gorou"]
'现在你不能忍受你的妹妹？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune279"]
[OnName num="suzune"]
我真的希望你不要再叫我 "姐姐"。
[cpg cn=true]


[OnName num="gorou"]
Ugh, it's ......"
[cpg cn=true]


当然，现在是时候解决这个问题了。
[cpg]


[OnName num="gorou"]
'但你不能帮助已经变得根深蒂固的东西，是吗？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune067"]
[OnName num="suzune"]
'比如说，如果你有一个孩子，你还会把我称为你的妹妹吗？
[cpg cn=true]


[OnName num="gorou"]
那我就叫你妈妈。"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune281"]
[OnName num="suzune"]
'......，你越来越善于归还东西了。
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune068"]
[OnName num="suzune"]
'我希望我可以整天和你在一起。我们不必再对任何人隐瞒了'。
[cpg cn=true]


[OnName num="gorou"]
我说，"对。"...... 嘿。
[cpg cn=true]


她开始抚摸我的头发。我扭动着身体，痒痒的。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune069"]
[OnName num="suzune"]
'什么？
[cpg cn=true]


[OnName num="gorou"]
'那很痒，哈哈哈，哈哈哈'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune070"]
[OnName num="suzune"]
'你认为五郎有被挠的弱点吗？　要我为你做更多吗？"
[cpg cn=true]


这是一个多么适合调情的时代。


[window target=false]

[SE f="se000"]
;//【ＳＥ】『ノック』

[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




在这一切之中，有人敲响了我房间的门。
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari124"]
[OnName num="himari"]
'兄弟，你要用我的漫画走那条路吗？
[cpg cn=true]


[OnName num="gorou"]
'哦，绯红......？　嗯，我不知道。"
[cpg cn=true]


现在已经很晚了。在这个时候，谈论漫画？
[cpg]


我想，我猜测。有人暗示我太吵了。
[cpg]


[OnName num="gorou"]
'......，很吵吗？
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari125"]
[OnName num="himari"]
'什么？　更重要的是，漫画呢？"
[cpg cn=true]


[OnName num="gorou"]
'哦，呃，我不认为我借了它。......'
[cpg cn=true]


我妹妹已经猜到了，让我闭嘴。然而。
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari126"]
[OnName num="himari"]
'嗯。好吧，那就祝你们俩好运。
[cpg cn=true]

[free time=1000]

绯红说过这样的话。我知道你太吵了。
[cpg]


[OnName num="gorou"]
'......，我应该怎么做，姐姐？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune299"]
[OnName num="suzune"]
'别担心。我说，'我祝愿你一切顺利'。
[cpg cn=true]


这是事实，但我认为这是......，具有讽刺意味。
[cpg]


;//＠なんて思いつつ、俺達はもう一度交わることにした。




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


更多的时间过去了。我的体质已经完全稳定下来，我再也不用去医院了。
[cpg]


他们要求我解释发生了什么，但我只是感到尴尬。
[cpg]


我想知道我是否应该让我妹妹在我旁边。我正在考虑这个问题。
[cpg]


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************



然后时间就过去了。有一个假期，我和我的妹妹在散步。
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune316"]
[OnName num="suzune"]
她说："我们结婚后可以住在同一个房子里，这很方便。"
[cpg cn=true]


[OnName num="gorou"]
'哦，那是肯定的。你不会在那里迷路的'。
[cpg cn=true]


真是一场对话，我们的关系又有点不同了。
[cpg]


我妹妹怀孕了。显然是个女孩，而且我们已经想好了名字。
[cpg]


[OnName num="gorou"]
'所以......，我不知道我要做什么。我仍然不确定我是否会继续接受高等教育'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune317"]
[OnName num="suzune"]
'我们之前已经谈过这个问题了。继续接受高等教育'。
[cpg cn=true]


[OnName num="gorou"]
'但你会让你的妹妹陷入困境。抓紧时间找工作不是更好吗？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune318"]
[OnName num="suzune"]
'五郎的优先事项应该是他想做的事情。你又没有破坏我的生活或什么，你可以依靠我'。
[cpg cn=true]


......，如果你想说那么多，我就不说了。
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_01_2_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune071"]
[OnName num="suzune"]
'总之，你记得今天是什么日子吗？
[cpg cn=true]


[OnName num="gorou"]
'让我看看......，是什么......'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune072"]
[OnName num="suzune"]
'你不记得了？　这是我们开始约会的日子，不是吗？"
[cpg cn=true]


[OnName num="gorou"]
我不记得我们开始约会的日子，......，也不记得我们成为恋人的日子。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune073"]
[OnName num="suzune"]
我们想要庆祝，即使这部分有点模糊。"
[cpg cn=true]


[OnName num="gorou"]
我想知道它是否是这样的。"
[cpg cn=true]



[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune074"]
[OnName num="suzune"]
五郎这样的人太沉闷了。
[cpg cn=true]


[OnName num="gorou"]
'不，不。日期有点模糊，但我也一直想庆祝一下'。
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune075"]
[OnName num="suzune"]
什么？"
[cpg cn=true]


[OnName num="gorou"]
'我有一个礼物给你。我回家后要不要打开它？
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune076"]
[OnName num="suzune"]
感谢......."
[cpg cn=true]



[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


孩子出生后，我真的很忙。
[cpg]


我是个学生，但我算是个家庭主夫，我必须抚养孩子。
[cpg]


但我不认为这是艰苦的工作。我真的不认为这是必要的或任何东西。
[cpg]


这就是我和我的妹妹......，铃音的日子是多么快节奏和可爱。
[cpg]



时间在迅速流逝。而三年已经过去了。
[cpg]




;//========================================
;//●ＣＧ（街を三人で歩く。幸せそうなヒロインと娘の笑顔が正面から見えるアングル）ev_26
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//人物３：主人公の娘
;//服装３：私服
;//場所　：街
;//時間　：昼
;//備考　：娘の年齢は三歳くらいです。また、本編から三年の時間が経過しています
;//========================================




[BGM f="bg_h1"]
;**【ＣＧ】 ev_26_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]




我想，我们成了一对幸福的夫妇。
[cpg]


我没有和铃音打过一次架。我们不吵架，我们没有那种关系。
[cpg]


我们周围的人羡慕我们，但这是我们之间的自然距离。
[cpg]


我现在不想打架。我们在一起生活的时间比大多数夫妻都长。
[cpg]


我们甚至比一对儿时的朋友更了解对方。
[cpg]


[VOICE f="Suzune319"]
[OnName num="suzune"]
嘿，戈罗。
[cpg cn=true]


铃音转向我，微笑着说。
[cpg]


[OnName num="gorou"]
'怎么了，铃音？
[cpg cn=true]


[VOICE f="Suzune320"]
[OnName num="suzune"]
'你很高兴。我仍然不相信我可以作为你的妻子而感到幸福。
[cpg cn=true]


...... 那是因为我当姐姐的时间比较长。这也是没办法的事。
[cpg]


但最终你们会花更大比例的时间作为夫妻。
[cpg]


我必须尽快摆脱当她小弟的命运。我的某些部分把铃音当成了我的妹妹。
[cpg]


;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

而当我从铃音的小弟弟毕业时，她可能会有一个妹妹或弟弟。
[cpg]


想到这里，我们在一条长长的道路上走了出来。
[cpg]



[SCENE id=9]

[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン１ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

