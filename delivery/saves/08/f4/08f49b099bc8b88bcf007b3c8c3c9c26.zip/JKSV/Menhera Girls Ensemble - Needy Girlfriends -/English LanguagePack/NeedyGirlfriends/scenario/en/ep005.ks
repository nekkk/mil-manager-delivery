
*start


;//==============================
;//上記ルートに分岐しなかった場合


;#################################################
*Ep005|Cutting ties with Shizuka
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

*root_1_2|Disconnect from Shizuka


[SCENE id=5]


[OnName num="shouya"]
Isn't that too much ......?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka369"]
[OnName num="shizuka"]
"Is it?　Shoya doesn't think so?"
[cpg cn=true]


I thought I would break up with Shizuka someday.
[cpg]


I'm not joking.
[cpg]


So I can't do that, but ......
[cpg]


If I can create the mood to break up with her a little bit at a time and eventually break up with her, I will.
[cpg]


If we can't do that, if he insists on bringing out the knife, we'll call the police: ......
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002"]
;//【ＳＥ】『雑踏』





And the next morning. We head to the school as usual.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
Shizuka seems happy. She seemed to be completely unconcerned about Ryoko.
[cpg]


[OnName num="shouya"]
Shizuka, don't you feel any pain in your heart about Ryoko?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka370"]
[OnName num="shizuka"]
Shoya, do you like Mizuhara-san?"
[cpg cn=true]


Why would she do that? No, I guess she does.
[cpg]


Her thought process has gone to a place I can't even begin to fathom.
[cpg]


I still think it would be a good idea to make it a little cooler and then .......
[cpg]


[OnName num="shouya"]
She said, "That's a bit harsh, Shizuka. It's normal to be heartbroken, regardless of whether you like her or not."
[cpg cn=true]


Shizuka has a look on her face like she doesn't know what I'm talking about.
[cpg]


I rather don't understand that expression, but I can't help saying that.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





And daytime. As expected, Ryoko didn't come to the school.
[cpg]


Not only Mitsuki, but even Ryoko has been absent from the school.
[cpg]


I wonder what will happen now. Will I be able to part with her properly?
[cpg]


I was thinking that while eating her homemade bento.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka371"]
[OnName num="shizuka"]
"Hey, is it good?"
[cpg cn=true]


[OnName num="shouya"]
......Yes.
[cpg cn=true]



;//ＢＫ



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
On the way home, Shizuka naturally walked along with me.
[cpg]


This has been repeated so many times that it's become the norm, but it's still strange.
[cpg]


So you're walking a useless distance. It's not a matter of love being heavy or anything.
[cpg]


Something is off. It's clearly different from the kind of love I'm looking for.
[cpg]


If that's the case, it's not that there's anything wrong with either of them, but it's inevitable that they will break up.
[cpg]


I think it is better not to continue being lovers if you don't love each other at least.
[cpg]


I know there are many loveless lovers in the world.
[cpg]


But in my case, it would be more correct to say that I have run out of love for her rather than that I don't love her.
[cpg]


That is how shocked I was by Ryoko's reaction to my suicide attempt.
[cpg]

;//移植のためシーンをカットしています



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

Shizuka wanted to stay at home, but I suggested that she should go home.
[cpg]


[OnName num="shouya"]
She said, "You have an early morning tomorrow, don't you? You didn't bring a change of clothes, did you?
[cpg cn=true]


;//[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka387"]
[OnName num="shizuka"]
Yes,......, well,......."
[cpg cn=true]


In the end, these words were the deciding factor and I succeeded in getting Shizuka to leave.
[cpg]


Even if they were lovers, how could they have "succeeded in getting her home"?
[cpg]


I realized once again that we can no longer be lovers.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[SE f="se005"]
;//【ＳＥ】『鳥の鳴き声』





I decided. I decided to break up with her today.
[cpg]


If they bring out a knife, I will call the police. In that sense, the school is a bad idea.
[cpg]


If possible, I don't want to make a big mess. I'd rather go to her house or something like that.
[cpg]


[OnName num="shouya"]
"...... is the moment of truth.
[cpg cn=true]


I don't know what will happen from here. The person who almost stabbed Mitsuki.
[cpg]


The best way to do this is to get a good idea of what you're looking for. You have to be prepared for that.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]


When I headed to the school, Shizuka was the same as before.
[cpg]


She was flirting with me. She was so doting that it was painful to watch.
[cpg]


She hugged me with both arms. She doesn't care about being seen.
[cpg]


But I still have to shake him off. This is a very hard thing to do.
[cpg]


But it's something I have to do.
[cpg]


[OnName num="shouya"]
"Listen, I need to talk to you. Can I go to Shizuka's house after school today?"
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]

Shizuka's eyes light up. I guess she is expecting the opposite, it was hard to see her like that.
[cpg]



;//ＢＫ



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





On the way home, this time I walk in the direction of Shizuka's house.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka388"]
[OnName num="shizuka"]
Do we have to talk about it at ......?"
[cpg cn=true]


Shizuka looks like she can't wait. But I can't talk about this outside.
[cpg]


I want as few witnesses as possible. If it gets to the point where I get hurt, that is.
[cpg]


[OnName num="shouya"]
If possible, I'd prefer to do it at home.
[cpg cn=true]


I blush. That kind of expectation makes my chest tighten.
[cpg]


[OnName num="shouya"]
I tell him, "...... don't get your hopes up. It's not something Shizuka would be happy about.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka389"]
[OnName num="shizuka"]
What do you mean?
[cpg cn=true]


They really don't know what it means.
[cpg]


They never dreamed that they would be asked to part ways.
[cpg]


He doesn't know what he's talking about. Even if it is obvious to others, they may not understand it.
[cpg]


[OnName num="shouya"]
He said, "I mean it just as it is. So don't be too happy.
[cpg cn=true]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

And then, finally, it was time. She was sitting on the bed and I was sitting on a chair.
[cpg]


[OnName num="shouya"]
I said, "I think we should break up. No, we should break up."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka390"]
[OnName num="shizuka"]
She said, "...... giggle, what are you talking about?　Are you kidding?"
[cpg cn=true]


She laughs and says yes back. He seems to think it's a joke.
[cpg]


I can't say this kind of thing as a joke, especially to Shizuka.
[cpg]


[OnName num="shouya"]
I'm serious. I'm done with Shizuka."
[cpg cn=true]


Shizuka is still laughing. I wonder if she doesn't understand what's going on. I don't think so.
[cpg]




[OnName num="shouya"]
I apologize for saying I liked Shizuka back then, I was the one who said it. ......
[cpg cn=true]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[OnName num="shouya"]
I knew it, I didn't want you to say that about Ryoko like that. ......!"
[cpg cn=true]


He said it all in one breath. Shizuka looked cold.
[cpg]




[free time=1000]



[SE f="se011"]
;//【ＳＥ】『ドア開く』



And then he walked out of the room without saying a word.
[cpg]


[OnName num="shouya"]
I knew this was ......."
[cpg cn=true]


That's not good. He's probably going to look for a knife. I should be able to respond immediately the next time he comes.
[cpg]


If I didn't know Shizuka's traits, I wouldn't have been able to respond.
[cpg]



[SE f="se011"]
;//【ＳＥ】『ドア閉まる』





[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka408"]
[OnName num="shizuka"]
"Let me ask you one more time. Do you want to break up with me?"
[cpg cn=true]


Then, as expected, Shizuka appeared with a knife in her hand.
[cpg]


But something unexpected had happened. Blood was trickling from her wrist.
[cpg]


Not just flowing, but spurting out. She was going to die if she didn't stop.
[cpg]


[OnName num="shouya"]
What are you doing?　Police, no, ambulance: ......."
[cpg cn=true]


I try to call. But Shizuka comes at me and grabs my hand.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Shizuka409"]
[OnName num="shizuka"]
Do you want to break up with me?　Hey, Shoya, did I do something wrong?
[cpg cn=true]


[OnName num="shouya"]
I didn't!　I'm not breaking up with you, so put away the knife, and, um, what should I do ......?
[cpg cn=true]


I have to stop the blood. The first thing to do is to grab the arm tightly.
[cpg]


 That's what I thought, and I grabbed Shizuka's arm, who was getting dizzy.
[cpg]

[free time=1000]
I can't stop the blood from overflowing. I don't know what to do.
[cpg]


If this continues, Shizuka will really die. ......!
[cpg]


[OnName num="shouya"]
Shizuka!　Shizuka, no, you can't die!
[cpg cn=true]


Even Shizuka, who had been the object of so much fear, still feels this way when someone dies in front of her eyes.
[cpg]



;//ＢＫ

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Shizuka managed to save her life, but she lost a lot of blood and was put on bed rest.
[cpg]

She will not be able to come out of the hospital for a while. My wish to break up with her has come true.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[FADEOUTBGM]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************





[OnName num="shouya"]
......
[cpg cn=true]


I jump out of the futon. I dreamt that Shizuka killed me.
[cpg]


I thought I would be able to sleep soon because I was tired from the ...... interview and everything that happened yesterday, and in fact, I was able to sleep right away.
[cpg]


But I was never free from Shizuka's shadow.
[cpg]



;//ＢＫ



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





I dozed off due to lack of sleep. Then I dream that Shizuka kills me.
[cpg]


The cycle repeats itself. My mind is going crazy.
[cpg]


A person died in front of me. I make a suggestion to myself. It was inevitable.
[cpg]


I keep having the same dream over and over again.
[cpg]


[OnName num="teacher"]
"...... wake up, Ichijo."
[cpg cn=true]


[OnName num="shouya"]
Yes, sir.
[cpg cn=true]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





People around me who knew what was going on sympathized with me.
[cpg]


I wondered how they knew everything.
[cpg]


I'm a little scared, but if they don't touch my trauma, so much the better.
[cpg]


Speaking of people who don't know what's going on, I think Ryoko, who doesn't come to the school, is one of them. ......
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





Days go by with such thoughts in mind.
[cpg]


Many things have changed since before I met Shizuka.
[cpg]


Although things have changed, a new daily life is being built.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





It was after school. I fell down in a residential area.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko180"]
[OnName num="ryoko"]
I asked him, "...... Shoya, why did you choose Tojo-san?"
[cpg cn=true]


 Ryoko stands still with a kitchen knife in her hand, even though she is being watched.
[cpg]


The figure was overshadowed by Shizuka.
[cpg]


The figure overlapped with the figure that I had seen in my dreams many times. ......
[cpg]


[OnName num="shouya"]
Aaaaaaahhhhhh!"
[cpg cn=true]

[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
She slumps down and backs away. Ryoko approaches slowly.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




I think this is my punishment. I must have committed a crime.
[cpg]



[VOICE f="Shizuka410"]
[OnName num="shizuka"]
Come here, Shoya. ......
[cpg cn=true]



;//ＥＮＤ：ヒロイン１ルート２

[system cl_h1r2=true]

[SCENE id=14]

[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

