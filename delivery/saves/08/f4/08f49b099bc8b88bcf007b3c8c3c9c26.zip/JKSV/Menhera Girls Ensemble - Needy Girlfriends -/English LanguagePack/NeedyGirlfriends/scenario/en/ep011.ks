
*start

;//==============================
;//恋愛ポイントが０の場合

;#################################################
*Ep011|I don't believe in fortune-telling
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


*root_3_2|I don't believe in fortune-telling.


[SCENE id=11]

[OnName num="shouya"]
'...... you shouldn't say things like that, even in jest. I'm disillusioned."
[cpg cn=true]


I was disillusioned with Mitsuki.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mituki285"]
[OnName num="mituki"]
I'm just telling it like it is. Why don't you believe me?
[cpg cn=true]


[OnName num="shouya"]
I'm going to get angry, Mitsuki. It's true that I like you, Mitsuki, but there are things I can say and things I can't ......"
[cpg cn=true]


The first thing to do is to make sure that you have a good understanding of what you're talking about.
[cpg]


[OnName num="shouya"]
The "......" is a very good thing.
[cpg cn=true]


What should I do? How can a girl stop crying at a time like this?
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki286"]
[OnName num="mituki"]
I've never lied to you. I didn't lie to you.
[cpg cn=true]


[OnName num="shouya"]
I'm sorry. I said too much,......, but you shouldn't talk about people's life and death too casually.
[cpg cn=true]


The first thing you need to do is to make sure that you have a good understanding of what you're talking about.
[cpg]


;//移植のためシーンをカットしています

[OnName num="shouya"]
'...... we should keep our distance a little bit.
[cpg cn=true]



[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki302"]
[OnName num="mituki"]
"What ......?　What?
[cpg cn=true]


Because it's unacceptable. Even if it is fortune-telling, I can't believe that my love interest would tell me that he is going to die.
[cpg]


The only difference is whether or not you actually take action.
[cpg]


[OnName num="shouya"]
You should go home today, Mitsuki.
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mituki303"]
[OnName num="mituki"]
Why ...... why?　I don't ......
[cpg cn=true]


 My hands are shaking. I was getting tired of looking at such places.
[cpg]


[OnName num="shouya"]
 "I'll take you to the front of my house. Let's go."
[cpg cn=true]


 Mitsuki didn't act violently. You know that if you do that, you'll just hate me.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





[OnName num="shouya"]
I'll see you tomorrow. See you tomorrow.
[cpg cn=true]


Mitsuki didn't say anything else. I was so happy to see her.
[cpg]


I saw her off, thinking that she was the one who was going to have an accident.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



This was good. I think it was for the best.
[cpg]


There was no way that both of us would be in an accident at the same time.
[cpg]


Unless Mitsuki is psychic, it would never happen.
[cpg]




[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





The next morning, when I was thinking that. Neither Ryoko nor Shizuka were there.
[cpg]


It was a weekday, Monday. Normally, they would have come to my house.
[cpg]


Thinking it was strange, I headed to the school.
[cpg]


No way. No way. It can't be. ......
[cpg]


[OnName num="shouya"]
What am I thinking?
[cpg cn=true]


 I just thought yesterday that it's impossible unless Mitsuki is a psychic.
[cpg]


But nature and gait will be faster. I walk believing that when I go to school, both of us should be there.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





They are not there. They are nowhere to be found.
[cpg]


Ryoko is not in my class. Shizuka is not in my class.
[cpg]


Are they both late for school? Isn't that right, Mitsuki?
[cpg]


With this in mind, I approached Mitsuki.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki304"]
[OnName num="mituki"]
She said, "......, those two were in an accident and are in critical condition."
[cpg cn=true]


[OnName num="shouya"]
That's ...... a lie, isn't it?"
[cpg cn=true]


I was too shocked to move for a while.
[cpg]


If it was a lie, I would have called him to confirm it.
[cpg]


But I couldn't do it. I was too scared to do it.
[cpg]


I've got no choice but to love Mitsuki now. Is this how our quadrilateral relationship is going to end ......?
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




Stunned, I returned to my classroom.
[cpg]


I have to go to class. Perhaps this was ingrained in my body, but I had begun to head to class when the time came.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





Then, I received a text message.
[cpg]


The content was as follows. I caught a cold." "I'm sorry for worrying you," "But I'm fine," "Is Shoya okay?" and ......
[cpg]


It was unmistakably Shizuka's text. I can't believe it's written by someone else.
[cpg]


And the frequency with which she sends these messages. It's definitely Shizuka.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Ryoko379"]
[OnName num="ryoko"]
I'm sorry!　I'm late.
[cpg cn=true]


[OnName num="shouya"]
"...... Ryoko ......"
[cpg cn=true]


I felt weak. I was so weak that I thought I was going to fall off my chair.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





It was all a lie by Mitsuki. But that was not the end of the story.
[cpg]


[OnName num="shouya"]
What do you mean? They are both alive.
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Mituki305"]
[OnName num="mituki"]
No, they are not. They were both in an accident. ......
[cpg cn=true]


Ryoko is right next to me.
[cpg]


Then who is this?
[cpg]


[OnName num="shouya"]
Mitsuki can't see me?　It's Ryoko.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Mituki306"]
[OnName num="mituki"]
'......Do, what's wrong?　Shoya, do you see anything?"
[cpg cn=true]


This reaction. It was as if to say that it would be strange if he could see her, but Ryoko was certainly here.
[cpg]


I looked at Ryoko. Mitsuki seems to have really gone crazy.
[cpg]


I wonder what the reason is, was it bad that I cut him off from me that he should keep his distance?
[cpg]


Was it that she was so shocked that she couldn't help believing in her own fortune telling ...... or something?
[cpg]


[OnName num="shouya"]
'Look, just touch it. You can feel it."
[cpg cn=true]


I took Mitsuki's hand and let Ryoko touch it. But ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Mituki307"]
[OnName num="mituki"]
'What have you been saying since a while ago,......?　What Shoya-san is saying, wow, I don't understand......"
[cpg cn=true]


Is it true? True true true true true true true true true true true true true true true true true true true true true true true true true true true ......
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




The next day, Shizuka also came to school. The next day, the day when Shizuka also came to school, I confirmed it again.
[cpg]





[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki308"]
[OnName num="mituki"]
"That's why I told you I can't see it,......."
[cpg cn=true]


Mitsuki insisted so. Me, Shizuka and Ryoko were just stunned.
[cpg]


Mitsuki was going crazy in an unusual way.
[cpg]


Is this also called psychosis?
[cpg]


I think she may just be acting, but that makes her seem sickly.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





......This is how the person I loved broke down.
[cpg]


I went along with her to see a psychiatrist.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki309"]
[OnName num="mituki"]
She said, "I'm not crazy in any way. ...... Why?"
[cpg cn=true]


[OnName num="shouya"]
Yeah, you're right. ......
[cpg cn=true]


It's hard to say that the person you love is broken. It's a lot of pain.
[cpg]


I'm no longer able to keep my spirit right in the form of that person I fell in love with.
[cpg]


It might be my fault. If I had loved only Mitsuki from the beginning.
[cpg]


If I had loved only Mitsuki from the beginning, this might not have happened. ...... I continued to go to the hospital, thinking so.
[cpg]



;//ＥＮＤ：ヒロイン３ルート２

[system cl_h3r2=true]

[SCENE id=18]

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

