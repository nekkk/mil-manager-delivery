

*start|A Time to Decide

;#################################################
*Ep002|Time to make a decision
;#################################################


[SCENE id=2]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





And then the incident happened. It happened the next morning.
[cpg]


It happened in the hallway as we were moving to another classroom after morning class.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




[OnName num="shouya"]
"Nn......?"
[cpg cn=true]


I saw Mitsuki being led by Shizuka to an unpopular classroom that no one was supposed to be using.
[cpg]


I could see that something was out of the ordinary.
[cpg]


The actual "I'm not a fan of the way you do it," he said, "but I'm not a fan of the way you do it, either.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





[OnName num="shouya"]
I was just going to go to ......."
[cpg cn=true]


The room beyond that, as expected, there was a scene that I was glad I followed .......
[cpg]


The actual "I'm not a fan of the way you do it," he said, "but I'm not a fan of the way you do it either.
[cpg]


They are pushing each other just at the neck. It looked like she was really going to kill him.
[cpg]


[OnName num="shouya"]
No!　What are you doing, Shizuka?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Shizuka152"]
[OnName num="shizuka"]
I'm going to kill you!　I'll kill you if you take away my Shoya. ......
[cpg cn=true]


I don't know what you are talking about. I know what he's saying, but why did he explode so suddenly just now?
[cpg]


[OnName num="shouya"]
"Look, get away ...... Mitsuki, get away while you still can!"
[cpg cn=true]


The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it.
[cpg]


The skin just below the neck has been cut and is bleeding. It's bad. If the artery is severed, it will really kill you.
[cpg]



[VOICE f="Mituki111"]
[OnName num="mituki"]
Ah, ah, ah ......!
[cpg cn=true]


Mitsuki's face is drawn with fear. I decided to take the cutter knife from Shizuka for the time being.
[cpg]


[OnName num="shouya"]
What happened, Shizuka?　What happened, Shizuka?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Shizuka153"]
[OnName num="shizuka"]
I know what happened. ......!　Shoya, you only loved Shimano-san, didn't you!
[cpg cn=true]


I don't remember. I don't even remember saying that. I'm going to explain that.
[cpg]


[OnName num="shouya"]
There must be some mistake!　For now, calm down, take a deep breath and ......"
[cpg cn=true]


I don't know what to do in a situation like this.
[cpg]


But there was something strange about what Shizuka was saying.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Shizuka154"]
[OnName num="shizuka"]
She said, "I was told what Mizuhara-san bugged me about. ......!　Then she told me that Shoya only loves Shimano-san."
[cpg cn=true]


Ryoko?　Why is Ryoko's name mentioned there?
[cpg]


And if she was listening in on me, she wouldn't have said she only loves Mitsuki.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************




[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/2" time=800]

Calming down a bit, I called Shizuka and Ryoko into the empty classroom.
[cpg]


Ryoko and I are sitting on chairs. And Shizuka was standing.
[cpg]


I thought it would be better not to call Mitsuki here. I would be in trouble if he wielded a knife again.
[cpg]


[OnName num="shouya"]
I asked her, "What do you mean by ......, Ryoko? Explain."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ryoko152"]
[OnName num="ryoko"]
"Oh, ......, I screwed up, didn't I?"
[cpg cn=true]


[OnName num="shouya"]
She says Ryoko told her. You have proof that I told her I love Mitsuki, right?
[cpg cn=true]


[OnName num="shouya"]
Let me hear you say that.
[cpg cn=true]


I have an idea. The other day, Shizuka almost stabbed Mitsuki.
[cpg]


Didn't Ryoko want to reproduce that again?
[cpg]


That way, Ryoko can get rid of both Shizuka and Mitsuki, who are a nuisance to her.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Ryoko153"]
[OnName num="ryoko"]
"...... got it. I'll stream it."
[cpg cn=true]


What comes from her phone is a recording with poor sound quality.
[cpg]


Someone's voice is definitely saying. She says she loves only Mitsuki and doesn't care about Shizuka or Ryoko.
[cpg]


But if you listen carefully, this is not my voice.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Ryoko154"]
[OnName num="ryoko"]
I asked another boy to let me record these things. I asked another boy to let me record these things."
[cpg cn=true]


She says so without any bad feeling. Ryoko is a crazy Ryoko.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Shizuka155"]
[OnName num="shizuka"]
I'm sorry, I misunderstood you. I'm sorry."
[cpg cn=true]


And Shizuka acts as if it was no big deal.
[cpg]


Everything is not normal anymore. Mitsuki is injured.
[cpg]


The first thing that comes to mind is the fact that the two of them have been in the same room for a long time.
[cpg]

[free time=1000]

[OnName num="shouya"]
The first thing you need to do is to make sure that you have a good understanding of what is going on in your life. The first thing you need to do is to make sure that you have a good understanding of what you're doing.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Mituki112"]
[OnName num="mituki"]
I'm going to ...... that way then. ......
[cpg cn=true]


Mitsuki had a bandage on the bottom of his neck, around his collarbone. It was painful to watch.
[cpg]


Now, the four of us are all here, including me. I think it's time to settle everything here.
[cpg]


[OnName num="shouya"]
I've decided to go to ....... I'm going to make it clear who I'm going to choose.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="3/3" time=800]
[VOICE f="Mituki113"]
[OnName num="mituki"]
What are you talking about?　Me and Shoya-san are already dating.
[cpg cn=true]


Mitsuki is a funny thing about Mitsuki. You could say that she is the one who has been adding fuel to the fire.
[cpg]


That said, I can't say the other two are normal either.
[cpg]


And there are parts of each of them that are pretty girls: ......
[cpg]


I think they are, to put it mildly, three people with a high level of good looks.
[cpg]


I have to think about it. The three of them are staring at me.
[cpg]



;//■選択肢
[switch]
[case "Shizuka"]
	[swap]
	[jump target="*select04_1"]
[case "Ryoko"]
	[swap]
	[jump target="*select04_2"]
[case "Mitsuki"]
	[swap]
	[jump target="*select04_3"]
[case "I'll cut ties with all of them."]
	[swap]
	[jump target="*select04_4"]
[endswitch]


1, Shizuka
Ryoko
3, Mitsuki.
4, I'm cutting off from all of them.


*select04_1|Time to make a decision
[jump storage="ep003.ks" target="*select04_1"]

*select04_2|Time of decision
[jump storage="ep006.ks" target="*select04_2"]

*select04_3|Time of decision
[jump storage="ep009.ks" target="*select04_3"]

*select04_4|Decision time
[jump storage="ep012.ks" target="*select04_4"]


