
*start

;#################################################
*Ep010|Believe in Fortune Telling
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

*root_3_1|Believe in Divination

[SCENE id=10]


[OnName num="shouya"]
I believe in fortune-telling. I believe, so can't you somehow change that fate?"
[cpg cn=true]


I decided to believe Mitsuki's story, even though I felt it was ridiculous.
[cpg]


The actual "I'm not a fan of the way you do it," he said.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mituki200"]
[OnName num="mituki"]
;//「……わ、分かった。二人にあらかじめ厄災が降りかかるのを伝えれば、なんとかなると思う」
I'm going to go to ...... and see if I can figure out what's going on. I think if I tell the two of you in advance that disaster is coming, we can work something out."
[cpg cn=true]


[OnName num="shouya"]
'Then it would be better if I told them, wouldn't it?　I'm sure they won't believe me if I tell them from Mitsuki."
[cpg cn=true]


Mitsuki nodded. I said something rude.
[cpg]


[OnName num="shouya"]
I'll talk to you both another time.
[cpg cn=true]


;//移植のためシーンをカットしています



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************




[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

The next day, Monday. I walk with them in the city.
[cpg]


[OnName num="shouya"]
I walked with the two of them in the city.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Shizuka417"]
[OnName num="shizuka"]
"What is it? You look so serious.
[cpg cn=true]


Do I look serious?
[cpg]


[OnName num="shouya"]
Mitsuki told me that he has read your fortune.
[cpg cn=true]


The two of them look as if they don't know what they are talking about.
[cpg]


Of course you're going to have that look on your face. They'll also be asking if I believe in fortune-telling.
[cpg]


[OnName num="shouya"]
I'm sure they're going to ask if I believe in fortune-telling, and I'm sure they're going to say something about some bad luck that's going to befall the two of you.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ryoko373"]
[OnName num="ryoko"]
"......What, that story. I'm usually careful, but what more can I do?"
[cpg cn=true]


[OnName num="shouya"]
I don't know about that. ......
[cpg cn=true]


I just told them. It may be something that will change the fate of the world.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se014"]
;//【ＳＥ】『学園のチャイム』





Then it was lunchtime. The three of us had lunch together.
[cpg]


The three of us are me, Shizuka, and Ryoko. Mitsuki does not join us.
[cpg]


But there were rumors around us.
[cpg]


[OnName num="male_student"]
How could he do that ...... to date three menschs?"
[cpg cn=true]


[OnName num="female_student"]
"Shush, I can't hear you."
[cpg cn=true]


[OnName num="male_student"]
But it's funny. But it's funny. Do those types of guys attract mendicants?
[cpg cn=true]


Yeah, that's probably true. At least Ryoko was my childhood friend.
[cpg]


I can't deny that there is something that attracts menhera.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko374"]
[OnName num="ryoko"]
'...... don't worry about it, Shoya.
[cpg cn=true]


Is he talking about the current gossip? I don't care or anything ......
[cpg]


[OnName num="shouya"]
They say terrible things about you."
[cpg cn=true]


I don't care, she says. I don't care at all, but I'm not so sure about that. ......
[cpg]



;//ＢＫ



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************




[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mituki218"]
[OnName num="mituki"]
"Ki, thank you for coming."
[cpg cn=true]


;//========================================
;//●ＣＧ（主人公に抱きつくヒロイン。可能ならお互い立っている姿勢にしてください）ev_41
;//人物１：ヒロイン３
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_41_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]



An empty classroom. Mitsuki hugs me, as if to say she can't stand it.
[cpg]


[OnName num="shouya"]
The first thing you need to do is to make sure that you have a good time with your family and friends. The first thing you need to do is to make sure that you have a good time.
[cpg cn=true]


I told that to Mitsuki. It was too late for anything to happen.
[cpg]

;**【ＣＧ】 ev_41_a ***********************
[CG id=17 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sMituki013"]
[OnName num="mituki"]
"Da, da, it's okay... if Shoya-san is in danger, I'm sure he'll come out for fortune-telling."
[cpg cn=true]


I doubt it. She's overconfident in her fortune telling, but when did that happen?
[cpg]


[OnName num="shouya"]
Mitsuki, you believe in fortune-telling,......, but what triggered that?"
[cpg cn=true]


The first thing that comes to mind is the fact that the "trigger" is the " fortune-telling".
[cpg]


[VOICE f="sMituki014"]
[OnName num="mituki"]
The reason for this is that ...... fortune-telling is absolute.
[cpg cn=true]


No good. I can't get it out of him this way.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

We talked for a while and she seemed satisfied.
[cpg]

I could have met her anytime if I wanted to, but calling her in class is a very good idea. ......
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





Then we returned to our respective classrooms.
[cpg]


Mitsuki started to send me e-mails every once in a while. But she doesn't send me many mails like Shizuka does.
[cpg]


The contents are cute, like "Do you really like me?　or something cute like that.
[cpg]


I replied that I love only Mitsuki. I didn't resist those words any more.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Shizuka418"]
[OnName num="shizuka"]
I asked her, "Do you really love me, ......?"
[cpg cn=true]


Shizuka says the same thing that Mitsuki asked me in a text message just a few minutes ago.
[cpg]


Ryoko is also next door. I can't say anything rash.
[cpg]


[OnName num="shouya"]
I like you. I like you all equally."
[cpg cn=true]


This is a bad way to put it. If those e-mails were seen, ......
[cpg]


If they see the e-mail saying I love only Mitsuki, Shizuka and Ryoko will know I'm lying.
[cpg]


But I can't help it ...... because what I really love is Mitsuki.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ryoko375"]
[OnName num="ryoko"]
'Shoya, have you been hiding anything from me lately?
[cpg cn=true]


[OnName num="shouya"]
I'm not. I'm sure Ryoko is the one who is hiding something from me.
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
I said, "That's not it," and shut up. I already know that Ryoko is also secretly probing me.
[cpg]


Anyway, I have to get away from these two somehow.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Shizuka419"]
[OnName num="shizuka"]
'...... we always go home together, the three of us, don't we?
[cpg cn=true]


[OnName num="shouya"]
I know. Shizuka's house is in the opposite direction, is that okay?"
[cpg cn=true]


That's fine," said Shizuka, continuing her words.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Shizuka420"]
[OnName num="shizuka"]
Why doesn't Shimano-san go home with us?"
[cpg cn=true]


...... It's because he knows that you love only him.
[cpg]


I can't say, "I don't know," even if I could.
[cpg]


[OnName num="shouya"]
It's because we're going in different directions. I wouldn't normally follow someone in the wrong direction home every day."
[cpg cn=true]


I implicitly called Shizuka unusual, but she didn't seem to mind.
[cpg]


Anyway, I'm glad she didn't get caught. ......
[cpg]


I may be about to get ripped off like this in the future.
[cpg]


She might see through it. I have to be careful.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se011"]
;//【ＳＥ】『ドア閉まる』




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





[OnName num="shouya"]
Whew. ......"
[cpg cn=true]


I sigh involuntarily. I feel like I'm walking a tightrope.
[cpg]


I only want to go out with Mitsuki, but it's not going well.
[cpg]


My indecisive nature brought this on. I have to do something about it.
[cpg]


However, suddenly breaking up with someone is not the best thing to do.
[cpg]


I have thought about this before, but both Shizuka and Ryoko are in danger in other areas.
[cpg]


I can't suddenly break up with them. That is the only thing you must not do.
[cpg]


But when it comes to fading out the relationship, ...... is ideal, but I don't know how to do it.
[cpg]


Like, maybe just cold turkey a little bit at a time?　Would both of them give up on me like that?
[cpg]


I have a feeling that Shizuka would never give up, let alone Ryoko.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





While I was thinking about such things, eating dinner and taking a bath, it was already nighttime.
[cpg]


Shizuka has sent me many e-mails.
[cpg]


She keeps asking me if I like her or not.
[cpg]


Even though what I do with Mitsuki is the same, I find it bothersome.
[cpg]


I must be a really terrible person to feel troublesome here, but I can't help what I feel. ......
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002"]
;//【ＳＥ】『雑踏』





Morning comes again. Me, Shizuka and Ryoko, the usual members, walk together.
[cpg]


Shizuka and Ryoko don't fight each other anymore.
[cpg]


Both of them are looking at me with suspicion.
[cpg]


I wondered if they really treated the three of us equally.
[cpg]


Perhaps Shizuka and Ryoko are not satisfied with equality. They should love only themselves.
[cpg]


On top of that, if someone else is their true love, they must be furious.
[cpg]


In ...... essence, it is about to be discovered that he loves Mitsuki the most.
[cpg]


I don't know where they get that kind of hint, but they both seem to think so.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





An empty classroom during lunch break. I was with Mitsuki.
[cpg]


;//========================================
;//●ＣＧ（背中を向けるヒロイン。窓から運動場を見ている感じに変えてください）ev_42
;//人物１：ヒロイン３
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_42_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="shouya"]
I was with Mitsuki. It's not good. She's going to find out that I like only Mitsuki.
[cpg cn=true]


[VOICE f="Mituki239"]
[OnName num="mituki"]
I was with Mitsuki in the empty classroom during lunch break. The first thing you need to do is to make sure that you have a good understanding of what you're doing and how to do it.
[cpg cn=true]


The first thing you need to do is to make sure that you have a good understanding of what you're doing.
[cpg]


She looked out of the window and saw the two of them in her line of sight. ......
[cpg]


[OnName num="shouya"]
The first thing that comes to mind is the fact that the two of them are in the same room.　Did your fortune teller give you a bad result or something?"
[cpg cn=true]


[VOICE f="Mituki240"]
[OnName num="mituki"]
That's right, that's ...... what happened to you two, and now it's about to happen to you all together.
[cpg cn=true]


I have no idea what this means.
[cpg]


I don't know much about fortune telling, so I thought I'd pass on it.
[cpg]


But when I was told about the bad omens for both of us, I felt like I couldn't leave it alone.
[cpg]


[OnName num="shouya"]
What do you mean by ......?"
[cpg cn=true]


After some hesitation, I decided to ask for more details.
[cpg]


According to him, it was averted by me telling him that a bad omen had befallen us both.
[cpg]


I was told that the wrinkle was coming to me.
[cpg]


;**【ＣＧ】 ev_42_a ***********************
[CG id=18 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Mituki241"]
[OnName num="mituki"]
I'm afraid there's nothing I can do about it. ......
[cpg cn=true]


[OnName num="shouya"]
I'm prepared for it. You're talking about the two of them finding out.
[cpg cn=true]


If that's what you're talking about, there's nothing I can do about it.
[cpg]


It's not up to me, and it's my fault to begin with.
[cpg]


The result of my indecisiveness is that I neglected it. I'll take it in stride.
[cpg]


I told Mitsuki how I felt about it, but he didn't seem to be convinced.
[cpg]


[VOICE f="Mituki242"]
[OnName num="mituki"]
I don't want to ...... stay with Shoya-san.
[cpg cn=true]


I wonder if something will happen that will make it impossible for us to stay together. If so, it would be a big deal. ......
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se014"]
;//【ＳＥ】『学園のチャイム』





Then we each took our own afternoon classes.
[cpg]


I am somewhat concerned about what Mitsuki said.
[cpg]


I have never seen her fortune-telling come true, but I know what she is trying to say.
[cpg]


As long as Shizuka and Ryoko are around, I continue to be in danger.
[cpg]


More importantly, as long as I love Mitsuki on top of that.
[cpg]


I could be stabbed at any time. If that's what the horoscope is showing me, then ......
[cpg]


It's not hard to see. I am sure that danger is about to befall me.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





And in the evening. Shizuka came to my class, where Ryoko and I were.
[cpg]


It was the usual thing. I didn't have any more comments.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka421"]
[OnName num="shizuka"]
Shouya said, "Well then, let's go. Shoya.
[cpg cn=true]


[OnName num="shouya"]
Shall we go to ......?"
[cpg cn=true]


The answer is inevitably a somber one.
[cpg]


The two seemed dissatisfied, whether they saw through that or not.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se010"]
;//【ＳＥ】『歩く』





[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





The relationship with these two people needs to fade out.
[cpg]


I can't think of a way to do that, which is something I've thought about before.
[cpg]


I thought about it before. I should just tell Mitsuki that I only love him.
[cpg]


Shizuka would try to hurt me. But if I called the police right away, I might get away with it.
[cpg]


And Ryoko will probably lock herself away in her own world and hurt herself, so that's not a problem. ......
[cpg]


No, it's still a problem. Me and Mitsuki might be able to be happy, but the two of us can't be happy.
[cpg]


We have to somehow find a way to resolve this amicably.
[cpg]


[OnName num="shouya"]
"......What should I do? ......"
[cpg cn=true]


The words spilled out unintentionally. Shizuka immediately picked up on it.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Shizuka422"]
[OnName num="shizuka"]
What are you wondering about?　Are we talking about us?"
[cpg cn=true]


[OnName num="shouya"]
Oh, no, it's nothing. Nothing, don't worry about it.
[cpg cn=true]


Shizuka is clearly suspicious as she says, "Yes.
[cpg]


Ryoko also has a cold expression on her face when she hears this.
[cpg]


It's not good, is it? This situation will go on for a long time. ......
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se011"]
;//【ＳＥ】『ドア閉まる』




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





I can't think of anything to do after I get home.
[cpg]


I can't imagine a situation where those two would give up on me.
[cpg]


That's exactly what I think I need to show them that I like Mitsuki.
[cpg]


It's risky. It's very risky, and it will hurt their feelings.
[cpg]


I think we should keep it this way for a while. ...... It won't solve anything.
[cpg]


I think it's time for what Mitsuki calls a disaster to befall us.
[cpg]


In other words, the future of being stabbed by Shizuka.
[cpg]


But that seems to be the same whether I reveal to these girls that I like Mitsuki or not.
[cpg]


It's just the difference between getting stabbed earlier or later. ......
[cpg]


[OnName num="shouya"]
'...... no good. I'm having weird thoughts."
[cpg cn=true]


What a thought I'm having. What do I think about the girl's feelings?
[cpg]


All I can think about is my own self-preservation. I should confide in both of them.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************





Even though I have thought that far ahead to ......, I still feel like it's okay in the morning.
[cpg]


I have a tendency to put things off.
[cpg]


In a state of self-loathing, I responded to one of Shizuka's e-mails.
[cpg]


I don't remember what Shizuka wrote in her e-mail and what I replied. I was too heartless.
[cpg]




;//ＢＫ



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

From there, it was business as usual. The three of us headed to the school together.
[cpg]


As expected, there are no more sparks between Shizuka and Ryoko.
[cpg]


She must be suspicious of me and Mitsuki.
[cpg]


On the way, Ryoko said something like this.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Ryoko376"]
[OnName num="ryoko"]
'Hey, you really love us equally, don't you?'
[cpg cn=true]


To this I had no choice but to lie back. Thinking so, I answered.
[cpg]


[OnName num="shouya"]
I answered, "Yes, of course I do. Of course I do.
[cpg cn=true]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





Then we arrived at the school and went to class.
[cpg]


I was too busy with class. I was thinking about when I would confide in the two of them.
[cpg]


They will find out sooner or later. If I wait for that moment, there is no way to take countermeasures.
[cpg]


It would be better to tell them myself so that I can prepare myself. ......
[cpg]


When I was thinking that, I received a text message from Ryoko.
[cpg]


...... "Why are you lying?" I wondered which lie she was talking about. I wondered which lie she was talking about.
[cpg]


Probably, I suspect the point about loving everyone equally.
[cpg]


This phone is also possibly being looked into by Ryoko.
[cpg]


Then, she's also seen my email exchange with Mitsuki: ......
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





It's getting worse. If Ryoko tells Shizuka, it will be the end.
[cpg]


I won't get away with it. I might not just get killed.
[cpg]


I might get hurt even worse. ...... I thought so.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka423"]
[OnName num="shizuka"]
So, let's go home.
[cpg cn=true]


But Shizuka still didn't seem to realize it, or at least didn't seem to have any proof of it.
[cpg]


I don't know if I should be happy or not. It doesn't change the fact that the time limit is already at hand.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





After that, I went back to my house. I received a text message from Mitsuki.
[cpg]


She wanted to meet me at the park at night, so I decided to sneak out of the house late at night.
[cpg]


After making sure my parents were asleep, I grabbed my keys and left.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se011"]
;//【ＳＥ】『ドア開く』




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************





[OnName num="shouya"]
I said, "...... what's wrong with you, texting me like that?"
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sMituki015"]
[OnName num="mituki"]
I just had to see you."
[cpg cn=true]


I thought that must be what it was about.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I knew that Mitsuki was the cutest thing in the world.
[cpg]

I'm not hesitant to kiss her even in a place like this, where someone is watching us.
[cpg]

I would think that if this would make Mitsuki happy and sleep well.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=800]

From there, we talked a little and Mitsuki seemed satisfied.
[cpg]



;//無表情の静香の立ち絵を表示してください



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1000]

[VOICE f="Shizuka424"]
[OnName num="shizuka"]
"......"
[cpg cn=true]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se011"]
;//【ＳＥ】『ドア閉まる』


[OnName num="shouya"]
"......I'm home......"
[cpg cn=true]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I sneak back to my room. Okay, my parents haven't found out.
[cpg]


I'm the kind of person who completely turns off the light when I go to bed, so they can't find out. I think.
[cpg]


If I had to say so, I thought it might be bad that I didn't have my shoes, but I don't think they would check something like that late at night.
[cpg]


I completed today's mission perfectly. No one could have found me.
[cpg]


With such a fulfilled feeling, I go to sleep. ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************





[OnName num="shouya"]
I thought to myself, "...... is it morning already? I was late last night."
[cpg cn=true]


I woke up thinking that the three of us would be heading to the school again.
[cpg]


But my expectations were a little off. Because.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





When I came out of the house, Shizuka was not there today.
[cpg]


[OnName num="shouya"]
I said to myself, "......?　Shizuka is not here.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko377"]
[OnName num="ryoko"]
Yes, ......."
[cpg cn=true]


Ryoko's reply was somehow strange. She didn't seem to care much about it.
[cpg]


It's more like she knows that Shizuka isn't coming ......?
[cpg]


I had an indescribable bad premonition at that time.
[cpg]



;//ＢＫ



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





I went to my morning classes. Ryoko was too strangely quiet.
[cpg]


That Shizuka never came to my house. I'm sure it's something very serious. ......
[cpg]


It is certainly possible that she might have caught a cold.
[cpg]


Students don't necessarily go to school every weekday. I was taking it that way.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se014"]
;//【ＳＥ】『学園のチャイム』





It was during lunch break that things changed. Shizuka came to my class.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sShizuka021"]
[OnName num="shizuka"]
I need to talk to you. May I?"
[cpg cn=true]


Her voice sounded as if she was sinking. I thought to myself, "This is finally going to be bad.
[cpg]


[OnName num="shouya"]
She said, "I understand. Okay."
[cpg cn=true]


With that in mind, I decided to follow along with the cell phone in one hand.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




I also noticed that Ryoko was following a little behind.
[cpg]


She was probably trying to see how things were going to turn out.
[cpg]


But she probably won't stop Shizuka if he goes off the rails.
[cpg]


If she knew I loved Mitsuki, Ryoko must hate me as much as Shizuka does.
[cpg]


[OnName num="shouya"]
Ah ......"
[cpg cn=true]


Furthermore, I met Mitsuki in the hallway.
[cpg]


The best way to get the most out of your time in the city is to get a good night's sleep. If she follows us, she might be in danger too.
[cpg]



[VOICE f="Mituki280"]
[OnName num="mituki"]
Where are you going?　Tojo-san."
[cpg cn=true]


Shizuka doesn't answer. She just kept on going and took me along with her.
[cpg]


Mitsuki naturally followed. Shizuka didn't seem to mind at all.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka426"]
[OnName num="shizuka"]
I heard from Mizuhara-san. Shoya only really loves Mitsuki.
[cpg cn=true]


[OnName num="shouya"]
Shouya said, "...... misunderstood. I told you I love you all equally.
[cpg cn=true]


I hold the cell phone behind my back so that I can call the police immediately.
[cpg]


 Then Shizuka took something wrapped in newspaper out of her bag.
[cpg]


Inside was a kitchen knife, not a cutter knife or anything like that.
[cpg]


I showed the cell phone to Shizuka, thinking, "Oh my God, I knew this was going to happen. .......
[cpg]


[OnName num="shouya"]
I'll call the police, Shizuka. If you're going to stab me, ......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Shizuka427"]
[OnName num="shizuka"]
Do what you want. I'll kill you and I'll die too.
[cpg cn=true]


There is this kind of Mengele image, right? It's so different from Mitsuki's.
[cpg]


I knew I couldn't love Shizuka after all.
[cpg]


Ryoko is Ryoko, and it's bad. You know this is going to happen, right?
[cpg]


She somehow managed to extract the contents of my phone.
[cpg]


She's trying to kill me in a roundabout way. That's probably the craziest thing I've ever heard.
[cpg]


[OnName num="shouya"]
"Calm down. Killing me won't help you. ......"
[cpg cn=true]


My voice wasn't calm. I swallowed after saying it out loud.
[cpg]


Why don't either of them stop it?
[cpg]


I know Ryoko won't stop them, but I'm sure Mitsuki will. ......
[cpg]


No, you can't approach someone with a knife. No matter how much someone you love is about to be killed.
[cpg]

[free time=1000]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/2" time=800]

[VOICE f="Mituki281"]
[OnName num="mituki"]
No, no, no. ......!
[cpg cn=true]


[OnName num="shouya"]
Mitsuki......!
[cpg cn=true]


I broke in between Shizuka and me and spread my hands.
[cpg]


If I did that, Mitsuki would die. If he were to die, it should be me.
[cpg]


The reason is that I'm the one who started the whole thing. If you ask me if I want to die or not, I don't want to die. ......
[cpg]


I don't want Mitsuki to get hurt. I know that much.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Shizuka428"]
[OnName num="shizuka"]
"Don't get in my way......!　Do you want to die?
[cpg cn=true]


Shizuka's knife cuts through the air. The first thing you need to do is to make sure that you have a good idea of what you're doing.
[cpg]


The first thing to do is to make sure that you have a good idea of what you're doing.
[cpg]


Naturally, Mitsuki also fell backward. She was in a position where she could not resist anything.
[cpg]


I can't run away either. Oh, it's all over.
[cpg]


Shizuka points a knife at me. I'm sure she won't hesitate to stab me.
[cpg]


If I stop her here, she won't be prepared. It's impossible, considering how crazy she is.
[cpg]


But yes. Mitsuki is the only one I have to protect. What should I do?
[cpg]


Maybe after stabbing me, a calm Shizuka would try to kill Mitsuki too.
[cpg]


So, should I make her stay calm?
[cpg]


Pretend to take the blade from ...... and make her hurt only me. Can I do that?
[cpg]


[OnName num="shouya"]
'......Wow!'
[cpg cn=true]


I won't know until I try. If I could get the blade, that would be the end.
[cpg]



;//画面赤く
[free time=1000]
[BG f="red.ui" time=1000]
[WAIT time=1500]
;//RO




But it didn't work out that way.
[cpg]


[BG f="b_01_2.ui" time=1000]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mituki282"]
[OnName num="mituki"]
"Ah, ah ...... Shoya-san ......!"
[cpg cn=true]


There is the sound of a kitchen knife falling.
[cpg]


If Mitsuki is killed as well, it will be meaningless for me to have put my body on the line so far.
[cpg]


Blood is spurting out. The blood is probably coming from my body.
[cpg]


Where did I get cut?　I'm so dazed that I don't know.
[cpg]


I wonder if Mitsuki would cry if I died.
[cpg]


I hadn't thought about that. Would it have been better if we had died together?
[cpg]


I don't know anymore.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]



......And then.
[cpg]


Months passed. A tremendous amount of time passed.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



;//場所は街中ではないので上下に黒帯を入れるなどしてください



;//[lbox on]

It seems I was in a coma while I was stabbed.
[cpg]


As soon as I woke up, I couldn't move my body. I was only conscious.
[cpg]


But I could move my fingertips. That confirmed that I was conscious or unconscious.
[cpg]


Then, after more time, he moved his body. When he was able to speak, his parents came to see me.
[cpg]


I was crying, I was crying, but I was the one who wanted to ...... cry.
[cpg]


It's strange that I can't move my body like this. Yes, four years had passed since I was stabbed.
[cpg]


I was thinking about what I was going to do with my life.
[cpg]


And more than that, I had to think about them.
[cpg]

;//[lbox off]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



;//場所は街中ではないので上下に黒帯を入れるなどしてください
;//時間が経過していますので立ち絵は表示しないでください



;//[lbox on]


[VOICE f="Mituki283"]
[OnName num="mituki"]
I thought, "Me, me, me, I woke up. ...... It's true."
[cpg cn=true]


Yes, it's true. If I finish rehabilitation, I might be able to make love with Mitsuki again.
[cpg]


 However, it wasn't just Mitsuki who came.
[cpg]



[VOICE f="Ryoko378"]
[OnName num="ryoko"]
I want to hear it this time. Who do you love?
[cpg cn=true]


Ryoko and Shizuka also came. The first thing you need to do is to make sure that you have a good time with your family.
[cpg]


;//もう刑期を終えたのか。殺人ではないから、こんなものなのか……と思ったものだ。
;//[cpg]


[OnName num="shouya"]
"......, uh, uh, ......, well..."
[cpg cn=true]


[VOICE f="Shizuka429"]
[OnName num="shizuka"]
Tell us. We can't leave until you pick someone.
[cpg cn=true]


If I say I like Mitsuki here, I'm going backwards again.
[cpg]


I don't know what they did to me. I can't say anything careless here.
[cpg]


[OnName num="shouya"]
I think I like all three of you equally. ......
[cpg cn=true]


Thus, the four-cornered relationship over the past four years still continued.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




Even after I finished rehabilitation and was able to live a normal life, I still had to deal with all three of them.
[cpg]


This is exactly the same as before I was stabbed.
[cpg]


There is no medicine for my indecision, which I can't wake up ...... even when I'm on the verge of death.
[cpg]


And one day, when I was on a date with Mitsuki. He said to me.
[cpg]



[VOICE f="Mituki284"]
[OnName num="mituki"]
"I'm not going to go along with this. ......
[cpg cn=true]



;//ＥＮＤ：ヒロイン３ルート１

[system cl_h3r1=true]

[SCENE id=17]

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



