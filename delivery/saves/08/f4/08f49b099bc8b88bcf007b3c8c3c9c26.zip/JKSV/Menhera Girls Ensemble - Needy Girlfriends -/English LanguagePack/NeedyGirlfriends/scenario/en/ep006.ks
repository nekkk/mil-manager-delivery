
*start


;//==============================
;//２、涼子

;#################################################
*Ep006|Select Ryoko
;#################################################

[stflag LoLiflg = 0]
[if exp={ isSystemFlagsEnabled( "sysSel01") }]
[stflag LoLiflg = 1]
[endif]
[if exp={ isSystemFlagsEnabled( "sysSel02") }]
[stflag LoLiflg = 1]
[endif]
[if exp={ isSystemFlagsEnabled( "sysSel03") }]
[stflag LoLiflg = 1]
[endif]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="3/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

*select04_2|Choose Ryoko

[SCENE id=6]

[OnName num="shouya"]
"I've decided ...... I'm going out with Ryoko.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Shizuka411"]
[OnName num="shizuka"]
"What are you talking about?　Did I mishear you?"
[cpg cn=true]


Shizuka has a look of despair on her face. The first thing you need to do is to make sure that you have a good understanding of what you are talking about.
[cpg]


[OnName num="shouya"]
Mitsuki, listen to me carefully. Mitsuki and I were never together in the first place. From now on, I'm going out with Ryoko.
[cpg cn=true]


Mitsuki repeated "What? Mitsuki repeated over and over again, then wobbled and collapsed.
[cpg]



[free time=1000]



[SE f="se012"]
;//【ＳＥ】『人倒れる　ドサッ』



[OnName num="shouya"]
......"
[cpg cn=true]


 Normally, I should have asked if it was okay here.
[cpg]


But Shizuka is looking at me too. I thought I should show her that Ryoko is the only one for me.
[cpg]


[OnName num="shouya"]
"Shizuka. I'm sorry for doing something halfway until now."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka412"]
[OnName num="shizuka"]
Oh, don't apologize ...... don't apologize ......!"
[cpg cn=true]


After saying this, he let out a deafening, unlettered scream.
[cpg]


[free time=1000]

Meanwhile, Ryoko was calm.
[cpg]


She did not blush, nor did she turn pale.
[cpg]


Looking back, I think she was wary that Shizuka might brandish a knife at this moment.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




I decided to take Mitsuki to the infirmary. And Shizuka was sitting and mumbling in that classroom.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





And then she left the school as if she was running away, leaving the two behind.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko181"]
[OnName num="ryoko"]
'...... you're choosing me. I was a little surprised.
[cpg cn=true]


[OnName num="shouya"]
'So ......?　Not so sure?"
[cpg cn=true]


My hands are still shaking. At that moment, I wondered what would happen.
[cpg]


And Ryoko seemed to be calm after all.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ryoko182"]
[OnName num="ryoko"]
I did a terrible thing, didn't I? I cheated on Tojo-san, and I cheated on Shimano-san with ......."
[cpg cn=true]


[OnName num="shouya"]
You know that was a terrible thing, don't you? Maybe Shizuka doesn't think what she did was wrong.
[cpg cn=true]


[OnName num="shouya"]
Besides, I know Ryoko, who was a kind childhood friend.
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
Finally, she blushes a little. She might not have felt it in her mind.
[cpg]


[OnName num="shouya"]
Anyway, Ryoko and I are now lovers. I can't back out now.
[cpg cn=true]


I told Ryoko and told myself the same thing.
[cpg]




[FADEOUTBGM]
;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




Shizuka, Mitsuki and Ryoko are not normal.
[cpg]


She was the one who was manipulating them behind their backs this time as well as the overdose incident.
[cpg]


I think she is also mentally ill in some way. But I chose her.
[cpg]




[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





The next day at school. Mitsuki seems to be absent from the school.
[cpg]


And Shizuka is in a different class to begin with, so she doesn't come to my class anymore.
[cpg]


I think this is a good thing. I think it was good.
[cpg]


I thought I liked Ryoko. That is certain.
[cpg]


No matter what happens to the other two, even if it's too much to think .......
[cpg]


At least Ryoko and I should be happy. That's what I thought.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Ryoko183"]
[OnName num="ryoko"]
"Oh, you know,......, do you want to come over to my place on your way home today?"
[cpg cn=true]


[OnName num="shouya"]
I'm sure we'll have a great time. Let's go.
[cpg cn=true]


This is the kind of conversation that would have been a terrible thing if Shizuka had heard it.
[cpg]


But it's no longer a relationship between me and Shizuka. This is the end of our halfway relationship.
[cpg]



;//ＢＫ



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





On the way home. Ryoko and I walked hand in hand.
[cpg]


I was worried that Shizuka might be following us, but she was not.
[cpg]


She seemed to be up to something, but so far she hasn't done anything.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Ryoko184"]
[OnName num="ryoko"]
'...... wonder. Me and Shoya, we really became lovers."
[cpg cn=true]


[OnName num="shouya"]
I think so. It feels like it took us a long time to get here.
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
It's true," murmured Ryoko.
[cpg]


 I thought it was cute to see him pouting.
[cpg]


[OnName num="shouya"]
I will only look at Ryoko from now on. I promise.
[cpg cn=true]


[OnName num="shouya"]
I made you feel lonely, didn't I? I'm sorry.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ryoko185"]
[OnName num="ryoko"]
Don't apologize. I will make it up to you from now on.
[cpg cn=true]


She smiled at me. I felt relieved when I saw her smile.
[cpg]



;//ＢＫ


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア閉まる』



[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





After that, I was taken to Ryoko's house.
[cpg]


I think we had a good time as lovers. But ......
[cpg]


[OnName num="shouya"]
"It's already this late...... time, I have to go home soon."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko203"]
[OnName num="ryoko"]
"......Why?　You can stay the night if you want.
[cpg cn=true]


[OnName num="shouya"]
'Not so fast, I haven't explained anything to our parents.
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
Ryoko has a complicated expression on her face. It's not like it's goodbye for life.
[cpg]


[OnName num="shouya"]
I'll come back tomorrow. That's all right, right?"
[cpg cn=true]


Ryoko didn't seem to be convinced. What should I do? ......
[cpg]


As I was thinking, Ryoko took out some pills from a small pouch and swallowed about five pills at a time.
[cpg]


[OnName num="shouya"]
She said, "Hey!　What are you doing!"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko204"]
[OnName num="ryoko"]
'...... medicine that will make you feel safe.
[cpg cn=true]


[OnName num="shouya"]
So, so ......."
[cpg cn=true]


No, am I right in this reaction?　Is medicine usually taken that way?
[cpg]


The medicine that can make you feel secure is a tranquilizer ......?　Or is it something called an anti-anxiety drug?
[cpg]


I don't know what the difference is, but now I'm getting anxious.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************





But that didn't mean I couldn't go home.
[cpg]


So I decided to go home.
[cpg]


It was really quite late. I'm sure they'll ask me where I've been.
[cpg]


I hate it. ......, I thought as I headed home.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




But then, sure enough. Finally, we were told that she was the one.
[cpg]


I had already told my parents that it was Ryoko.
[cpg]


In many ways, I can't back out now.
[cpg]


I'm okay with it, she seems the most decent of the three, ...... though I didn't choose her for that reason.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





[OnName num="shouya"]
Good morning. Ryoko."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Ryoko205"]
[OnName num="ryoko"]
Good morning,......, you look kind of shy even though you're with us all the time.
[cpg cn=true]


Maybe so. For Ryoko, it's the first time she's commuted to school with her boyfriend.
[cpg]


No, it's the same for me too, I thought, ......
[cpg]


Speaking of which, Shizuka isn't here.
[cpg]


[OnName num="shouya"]
'...... then, let's go.'
[cpg cn=true]


But I felt funny worrying about it, so I decided to head to the school already.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





I knew something was going to happen at the academy.
[cpg]


How Shizuka would act after a day. I couldn't imagine it, but ......
[cpg]


It was a normal lunch break. Shizuka made her move in the midst of many other students.
[cpg]


[OnName num="shouya"]
She said, "No, stop it!　Someone go get the teacher!"
[cpg cn=true]



[SE f="se002"]
;//【ＳＥ】『ざわざわ』





The classroom was buzzing. Shizuka is leaning on Ryoko and is about to put a box cutter knife to her neck.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Shizuka413"]
[OnName num="shizuka"]
I'll kill you, I'll kill you!
[cpg cn=true]


Ryoko is all frightened. She was trying to push off Shizuka's arm even though she was frightened.
[cpg]


And I'm trying to pull them both off of me. ......
[cpg]


Since they are separated by the force of two stones, Shizuka couldn't hurt Ryoko either.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




Then, Shizuka never came to the school.
[cpg]


She must have been taken to a psychiatrist or something. She was crazy from the start. ......
[cpg]


If she was going to be like that again, the school might have had something to do with it.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************




Days go by. There are a few things I found out about Ryoko and her lover.
[cpg]


She takes some kind of medicine every day. When I asked her why she was taking them, she wouldn't tell me.
[cpg]


The only thing I could get out of her was that she said, "I have more anxiety than others.
[cpg]


I was also feeling a bit anxious, but I continued to date her.
[cpg]


;//移植のためシーンをカットしています



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





My relationship with her continues. When I'm with her, many things happen.
[cpg]


[OnName num="shouya"]
She said, "What's wrong ......?　Your hands are shaking."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko225"]
[OnName num="ryoko"]
"Oh, really,...... wait a minute."
[cpg cn=true]


Then she takes out a medicine and drinks it.
[cpg]


I don't know what they are, but they are all different colors and shapes, and I'm taking about five of them at once.
[cpg]


I couldn't even ask him if it was okay to take that many pills.　I couldn't even ask him if it was okay to take that many pills, so I kept quiet.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
;//[VOICE f="Ryoko226"]
[VOICE f="sRyoko903"]
[OnName num="ryoko"]
;//「するのに夢中で、夕方の分を飲み忘れてたみたい。ごめんね」
He said, "I think I forgot to take the evening's dose. I'm sorry.
[cpg cn=true]


[OnName num="shouya"]
If you're okay with it, that's fine.
[cpg cn=true]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




She should have been happy when she started going out with me, right?
[cpg]


Yet, for some reason, Ryoko's mood seemed to be becoming unstable.
[cpg]


Perhaps it comes from the feeling that if you are a lover, you should love more. ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko227"]
[OnName num="ryoko"]
'...... you're late.
[cpg cn=true]


[OnName num="shouya"]
I'm sorry, I overslept a bit. You could have gone to the school first."
[cpg cn=true]


Then he looks gloomy. Then ......
[cpg]


bandage on his wrist. I didn't even want to think about what was under it.
[cpg]


[OnName num="shouya"]
He said, "...... am I really that inadequate of a lover? You can tell me if there's anything you want me to do.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ryoko228"]
[OnName num="ryoko"]
I'm fine. Never mind."
[cpg cn=true]


Ryoko, like Shizuka, was not quick to express her dissatisfaction.
[cpg]


Ryoko was the last to be in a three-way situation.
[cpg]


I feel like taking yourself hostage is not much different than hurting someone else. ......
[cpg]


I didn't want Ryoko to get hurt any more than she already was.
[cpg]


Is it strange to think that I could get Ryoko in a good mood and somehow make her into a normal girl ......?
[cpg]


What do I want to do?　Should I accept her as she is?
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I'm not quite sure what's going on.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="shouya"]
Ah ......
[cpg cn=true]


The events at the school, or rather, a slight change.
[cpg]


Mitsuki is coming to school. She didn't even look at me anymore.
[cpg]


The first thing you need to do is to make sure that you have a good understanding of what you're doing.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ryoko229"]
[OnName num="ryoko"]
I was like, "No, don't look at her. Don't look at me, just look at me.
[cpg cn=true]


[OnName num="shouya"]
Oh, I'm sorry. I'm sorry.
[cpg cn=true]


That's right. I should only look at Ryoko.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


And on the way home. I was going to Ryoko's house again today.
[cpg]

;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko246"]
[OnName num="ryoko"]
"Will you stay over today ......?"
[cpg cn=true]


[OnName num="shouya"]
"I'll have to tell ...... my parents.
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
Ryoko looked a little sad.
[cpg]


Didn't I just say I'd talk to my parents about it? Wouldn't it have been better if I had answered immediately that I would stay here?
[cpg]


[OnName num="shouya"]
Besides, I don't know if Ryoko's parents would say it's a good idea either,.......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko247"]
[OnName num="ryoko"]
'You don't care about my parents. Just look at me."
[cpg cn=true]


Ryoko is coming on to me. Even though I know she won't harm me like Shizuka did, I'm still a little scared.
[cpg]


[OnName num="shouya"]
I know that she is not going to harm me like Shizuka, but I am still a little scared.
[cpg cn=true]


I wonder if she will understand if I say this. I don't think she would understand.
[cpg]


Ryoko reaches for her medicine pouch again. She takes the pills as she is used to doing.
[cpg]


It was a familiar behavior, but I really hated to see it.
[cpg]


[OnName num="shouya"]
'Is that medicine really that good to take?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sRyoko007"]
[OnName num="ryoko"]
'I'm fine. ...... ugggh.'
[cpg cn=true]


I feel like I'm going to throw up. What, what the hell?
[cpg]


Did you overdose again?　I just said I couldn't stay the night.
[cpg]


No, I didn't even say you couldn't stay. I just said I need my parents' permission.
[cpg]


But Ryoko was about to throw up. I got scared and called someone from Ryoko's house.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Soon after that an ambulance was called and she was taken away.
[cpg]




[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I wondered if I could love her.
[cpg]


She keeps repeating suicide attempts like this over and over again.
[cpg]


I think it's too much for me. It's not that it's too much, it's that love is too much.
[cpg]


I don't mind being loved. I mean, who doesn't want to be loved?
[cpg]


But I feel that the nature of love is inverted in our minds.
[cpg]


We cannot live without love. If love is a medicine, we are dependent on it.
[cpg]


Not only Ryoko, but also me. I am dependent on being loved.
[cpg]


Is there something wrong with me that I'm drunk on supporting her?
[cpg]


I have to answer the question. By the time I see her again ......
[cpg]




;//ＢＫ



;//==============================
;//恋愛ポイントが２以上の場合

[if exp={getFlagValue("LoLiflg") <= 1}]
[jump target="*root_2_2"]
[endif]



*root_2_1|Choose Ryoko
[jump storage="ep007.ks" target="*root_2_1"]

*root_2_2|I choose Ryoko.
[jump storage="ep008.ks" target="*root_2_2"]



