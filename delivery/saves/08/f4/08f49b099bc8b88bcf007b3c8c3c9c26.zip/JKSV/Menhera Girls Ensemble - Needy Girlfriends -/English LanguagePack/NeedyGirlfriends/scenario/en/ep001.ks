
*start

;#################################################
*Ep001|A hunch that something was going to happen.
;#################################################

[SCENE id=1]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002"]
;//【ＳＥ】『雑踏』





It was the next day that things started to change a little.
[cpg]


The morning went as usual. I say "as usual," but Shizuka went out of her way to pick me up.
[cpg]


Ryoko was next to me. This usual routine was quite tiring.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Shizuka039"]
[OnName num="shizuka"]
I made lunch. Are you hungry?
[cpg cn=true]


[OnName num="shouya"]
Yeah, well, I had a normal breakfast, but I think I'll be hungry around ...... lunchtime.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Shizuka040"]
[OnName num="shizuka"]
I'm looking forward to it. I'm looking forward to it, Shoya."
[cpg cn=true]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





 That bento was, in a word, luxurious.
[cpg]


Too gorgeous, is an appropriate way to put it. What is this?
[cpg]


I've never seen anything like it before, but there are delicious-looking dishes arranged in small portions.
[cpg]


And the bento itself was huge. It was too big for even two people to eat.
[cpg]


I suddenly remembered the case of the cake.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka041"]
[OnName num="shizuka"]
I had prepared it three days in advance.
[cpg cn=true]


Three days in advance. What do you mean?　That was around the time we first met, right?
[cpg]


What would you have done if I had refused the bento today?
[cpg]


The taste itself was very good, but the fact that it tasted so good scared me.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





And this time, in the evening. Shimano-san called me.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki011"]
[OnName num="mituki"]
She said, "Oh, uh, um, ...... next Sunday, uh, do you want to go play ......?"
[cpg cn=true]


Shimano-san was probably asking me out on a date while repeatedly stuttering.
[cpg]


I was tired of watching Shizuka and Ryoko bicker and thought it might be nice to spend some time with her.
[cpg]


[OnName num="shouya"]
She said, "Fine. Let's meet at the station then."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mituki012"]
[OnName num="mituki"]
Umm, yes!　Um, well, that's what I meant, so, um, so ...... um..."
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
I looked around the place with a fidgety look on my face. I don't know why she is doing this.
[cpg]


It was so cute to see.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



The way home was the same as the way there. I had to watch Shizuka and Ryoko bickering again on the way home.
[cpg]


It was quite stressful, but I knew I shouldn't be stressed.
[cpg]


Both of them are seriously thinking about me.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





A few days go by, and it is Sunday morning.
[cpg]


I didn't have a quirky holiday morning to come to the front of the house.
[cpg]


Instead, I received mail. Dozens of them.
[cpg]


They were asking me to go out with them, but I had promised Shimano-san that I would go out with him.
[cpg]


I thought so and turned them down, but the e-mails still kept coming.
[cpg]


They kept asking me why I couldn't hang out with them.
[cpg]


I got tired of it and hung up on the notification.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki013"]
[OnName num="mituki"]
I said, "Oma, Tase......, Shoya-san."
[cpg cn=true]


[OnName num="shouya"]
I'm not waiting for you. I'm not waiting for you.
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mituki014"]
[OnName num="mituki"]
"Mimi, Mimi, it's Mitsuki, okay ......."
[cpg cn=true]


He says so with a face so red that it looks like it might explode. If I put ice on his forehead, it would melt.
[cpg]


[OnName num="shouya"]
The actuality is, it's not just a matter of time before the actuality is not. The actuality of the particulars is that you can find a lot of different types of products and services.
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki015"]
[OnName num="mituki"]
"Well, before that, ...... contact information."
[cpg cn=true]


[OnName num="shouya"]
Mitsuki said, "Oh, yes, that's right. Then, let's exchange it.
[cpg cn=true]


I have known Ryoko's contact information from the beginning. I also exchanged with Shizuka. Now I can contact all three of them.
[cpg]


Then, after exchanging contact information, he offered me his ...... hand from the other side. I wasn't sure if I should grab it, but I did.
[cpg]


If I refused, I would be denying that we were destined to be together.
[cpg]


She would be beyond depressed.
[cpg]


But this is like having three legs. ......
[cpg]


I walked down the street thinking, "I really need to do something about this.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





As we walked hand in hand, I could see that her hands were sweating profusely.
[cpg]


She must be very nervous. Probably something she wouldn't have been able to do without Tarot's encouragement.
[cpg]


It's going to be a healthy date today, I thought as we cruised around the shopping mall or something. ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





Finally, she took me to her house.
[cpg]


[OnName num="shouya"]
Wait a minute," she said. It's too early.
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mituki016"]
[OnName num="mituki"]
"What do you mean ...... we are lovers ......"
[cpg cn=true]


I don't remember saying that. I don't remember saying that, and it was the first time we had ever gone out together.
[cpg]


[FG f="CHA03_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki017"]
[OnName num="mituki"]
"We're dating, right ......?　Aren't we?"
[cpg cn=true]


It's radio waves. I think the idea is a little strange.
[cpg]


I mean, we did hold hands, and I did take him up on his offer to hang out.
[cpg]


[OnName num="shouya"]
No, it's too early to tell. ......
[cpg cn=true]


Not quite ready" is a bad way to put it. It's a statement of intent to go there soon.
[cpg]


[FG f="CHA03_p3_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mituki018"]
[OnName num="mituki"]
Why don't you like ...... him?
[cpg cn=true]


[OnName num="shouya"]
I don't hate you, but we're friends.
[cpg cn=true]

[FG f="CHA03_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
The first thing to do is to take a few steps back and look at the words. The first thing to do is to make sure that you have a good understanding of what you're doing.
[cpg]


[OnName num="shouya"]
The actuality is, you can't just go to the store and buy a new one.　Are you okay ......?"
[cpg cn=true]


[free time=1000]

Then he turned on his heel and ran away.
[cpg]


I was so stunned that I missed my chance to chase after him.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





When I got home and looked at my phone, I saw that I had received over a hundred e-mails.
[cpg]


More than fifty of them were "Why are you ignoring me? The rest were similar in meaning.
[cpg]


I was horrified. This is a frightening situation, and I want it to stop.
[cpg]


So I decided to call Shizuka.
[cpg]



;//[lbox on]

[SE f="se000"]
;//【ＳＥ】『携帯電話の発信音』




[VOICE f="Shizuka042"]
[OnName num="shizuka"]
......Why are you ignoring me?"
[cpg cn=true]


That was the first voice. Her voice was quite somber.
[cpg]


I should be glad she didn't come to my house.
[cpg]


[OnName num="shouya"]
Oh, you know, ...... don't send too many e-mails, I can tell from just one.
[cpg cn=true]


[OnName num="shouya"]
So this kind of thing, I'd like you to stop ......
[cpg cn=true]


[VOICE f="Shizuka043"]
[OnName num="shizuka"]
"You don't like me anymore?　Hey, Shoya.
[cpg cn=true]


I don't hate you. I wonder why we are talking about that.
[cpg]


[OnName num="shouya"]
"...... okay, just moderate it ......."
[cpg cn=true]


;//[lbox off]

I said that and hung up the phone.
[cpg]


I'm going to be blamed for that e-mail from now on. It seems that it is an inevitable fate.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002"]
;//【ＳＥ】『雑踏』





The next morning, before Shizuka arrived, Ryoko and I headed to the school.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko036"]
[OnName num="ryoko"]
Where did you go yesterday?"
[cpg cn=true]


A casual remark. She probably visited my house.
[cpg]


But I couldn't say that I was playing with Mitsuki. Ryoko would have been jealous.
[cpg]


[OnName num="shouya"]
She would be jealous. I went to the movies by myself.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ryoko037"]
[OnName num="ryoko"]
I went to the movies by myself. What kind of movie?
[cpg cn=true]


[OnName num="shouya"]
"......, it doesn't matter. What's wrong?
[cpg cn=true]


The first thing to do is to make sure that you have a good time. With a smile, she turned to me and said, "Why are you lying to me?
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ryoko038"]
[OnName num="ryoko"]
Why are you lying to me?　It's not a movie, it's a shopping mall.
[cpg cn=true]


[OnName num="shouya"]
What?"
[cpg cn=true]


How did you know?　Did they see you?
[cpg]


If so, were you followed or something?
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko039"]
[OnName num="ryoko"]
"That was Shimano-san, wasn't it? I saw everything."
[cpg cn=true]


[OnName num="shouya"]
"Ryoko ......?　What are you talking about?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sRyoko901"]
[OnName num="ryoko"]
;//「家に入らなかったのは正解だよ。入ってたら、私どうなってたか分からないもん」
It's a good thing I didn't go in there. If I had, I don't know what would have happened to me.
[cpg cn=true]


I got goosebumps. I was being stalked.
[cpg]


It was close. I really don't know what would have happened to me if I had entered her house in that moment. ......
[cpg]


I didn't notice it because of Shizuka and Mitsuki's abnormality, but Ryoko is a bit strange too.
[cpg]


[OnName num="shouya"]
'Were you following me?　Where in the world did you come from...... no, how did you know I left the house?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko041"]
[OnName num="ryoko"]
How could you? You can't do that kind of thing anymore."
[cpg cn=true]

[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

Shizuka joined me on the way to school. Thank God, I thought.
[cpg]


I didn't want to be alone with Ryoko any longer. This girl is not normal.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Shizuka044"]
[OnName num="shizuka"]
What's wrong, you two ...... Why are you looking like that?"
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





And then, the school. The first time I went to the school, I was in the classroom at the end of the class.
[cpg]


The first time I saw her, she was a little nervous. The first time, he was much more direct this time.
[cpg]


[OnName num="shouya"]
Wait, where are you taking me ......?"
[cpg cn=true]


She pulled my hand and took me to an empty classroom. The two of us are all alone.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
;//[VOICE f="Mituki019"]
;//[OnName num="mituki"]
;//「……この間、家に、来てくれなかった」
;//[cpg cn=true]


I heard him talking about how he's still feeling about not going to Mitsuki's house the other day.
[cpg]

I can't say I'm sorry or anything.
[cpg]

;//光希はそのことを引きずっているらしい。俺は申し訳ないとも何とも言えない。
;//[cpg]


[OnName num="shouya"]
I'm sorry,......, but I'm not even his girlfriend,.......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Mituki020"]
[OnName num="mituki"]
I'm already a lover with Shoya-san!
[cpg cn=true]


Mitsuki making a loud voice. Oh no, I think I stepped on a land mine.
[cpg]


;//========================================
;//●ＣＧ（主人公を見つめるヒロイン。ヒロインはしゃがんでいる）ev_04
;//人物１：ヒロイン３
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_04_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


For some reason, Mitsuki crouches down and looks up at me.
[cpg]

[OnName num="shouya"]
What's wrong ...... what are you going to do?
[cpg cn=true]


[VOICE f="sMituki001"]
[OnName num="mituki"]
I would do anything for you,.......
[cpg cn=true]


What do you mean by anything? What are you going to do with this posture?
[cpg]

If someone sees you like this, you'll be in trouble.
[cpg]

[OnName num="shouya"]
I'm really sorry, you know.
[cpg cn=true]


While we were arguing, I felt someone's eyes on me.
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[WAIT time=100]

[free time=1000]


[OnName num="shouya"]
"Shizuka ......!
[cpg cn=true]


An empty classroom where no one was supposed to be. I didn't think anyone would come this far into the school.
[cpg]


But they were watching me. I saw Shizuka leaving.
[cpg]


This is not good. I thought so and chased after Shizuka.
[cpg]



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki035"]
[OnName num="mituki"]
"Oh, ...... Shoya-san?　What's wrong?
[cpg cn=true]


[OnName num="shouya"]
I'll explain later!"
[cpg cn=true]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



In the end, right after that, I did not know where Shizuka had left off.
[cpg]



[SE f="se014"]
;//【ＳＥ】『学園のチャイム』





The chime that signals the next class rings as it does. I had no choice but to go to class.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





Then, after school. I went to the classroom where Shizuka was supposed to be.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko042"]
[OnName num="ryoko"]
I asked her, "Hey, where are you going?　Let's go home together."
[cpg cn=true]


...... I know, right? There is also the matter of Ryoko. But right now, the first priority is to explain to Shizuka.
[cpg]


I have to tell her that I didn't want to do it.
[cpg]


[OnName num="shouya"]
I'm sorry, I might not be able to do it today. Maybe some other day."
[cpg cn=true]

[free time=1000]

I apologize and run out.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Shizuka is not there. At least not in the classroom where she was supposed to be.
[cpg]


I looked for her and found her in that empty classroom where Mitsuki and I had been playing.
[cpg]





[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka045"]
[OnName num="shizuka"]
 ...... Shoya, why did you do that to me?
[cpg cn=true]


[OnName num="shouya"]
I didn't do anything. Besides, he was coming on to me."
[cpg cn=true]


The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it.
[cpg]


The shock to Shizuka is immeasurable. I would not be able to stand it even if I were in the opposite position.
[cpg]


And considering Shizuka's personality, it's not surprising what she would do. ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Shizuka046"]
[OnName num="shizuka"]
I like Shoya. I like Shoya.
[cpg cn=true]


[OnName num="shouya"]
I know that somehow,.......
[cpg cn=true]


I'm not saying somehow, but you know it pretty clearly.
[cpg]


It's been a terrific approach up until now. It's strange that you don't notice it.
[cpg]


And then Shizuka starts to say this.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka047"]
[OnName num="shizuka"]
I liked someone else, didn't I?　I was going to give you chocolates, remember?"
[cpg cn=true]


How could I forget? The day our relationship began.
[cpg]


[OnName num="shouya"]
I remember ...... how you fell for me so much.
[cpg cn=true]


The way you say that you've moved on might upset Shizuka's nerves.
[cpg]


But there was no other way to say it. I waited for her reply.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka048"]
[OnName num="shizuka"]
I waited for her to reply, "......After all, you were in love with love then. But you weren't."
[cpg cn=true]


Shizuka looks at me from the window.
[cpg]


Then she said in an earnest tone of voice.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Shizuka049"]
[OnName num="shizuka"]
I love you because I love you. I like you so much, I'm going crazy."
[cpg cn=true]


[OnName num="shouya"]
...... so."
[cpg cn=true]


I don't have the courage to push Shizuka away here.
[cpg]


No, that's not courage. It's determination, or whatever it is I'm lacking.
[cpg]


The first thing to do is to make sure that you have the right tools to do the job. I remembered the story of the incident at the previous school.
[cpg]


She would never do such a thing. But I couldn't help feeling sorry for Shizuka.
[cpg]


I had a feeling that, aside from Mitsuki, Shizuka and I would get together someday.
[cpg]


;//移植のためシーンをカットしています

[VOICE f="sShizuka001"]
[OnName num="shizuka"]
I was so happy to see him again. "Please don't do anything strange with Shimano-san anymore. Please, Shoya."
[cpg cn=true]

[OnName num="shouya"]
'......Yeah. I'll try.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Shizuka068"]
[OnName num="shizuka"]
"...... try?"
[cpg cn=true]


He gave me a very scary look. I correct him impatiently.
[cpg]


[OnName num="shouya"]
"No, I won't!　I'll never do it, don't worry. Don't worry."
[cpg cn=true]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





It was a little late when I returned home. I wondered if Ryoko had already left.
[cpg]


I thought so, but Ryoko was waiting for me at the gate of the school.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko043"]
[OnName num="ryoko"]
She was waiting for me at the gate of the school. What were you doing?
[cpg cn=true]


[OnName num="shouya"]
How do you know?　She hasn't come home yet.
[cpg cn=true]


She tells me that she can tell because we've known each other since childhood, but that doesn't explain it.
[cpg]

[free time=1000]

I was not surprised that she thought I had gone home first.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/2" time=800]

In the end, the three of us, Shizuka, Ryoko, and I, followed our usual pattern of going home.
[cpg]


Shizuka was more relaxed than usual. And Ryoko's smile was scarier than usual.
[cpg]


I wonder if Ryoko sees through everything. If so, how?
[cpg]


Thinking about this, I walk along the road to my house.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





Then we had dinner, and at night. I decided to call Mitsuki.
[cpg]

;//[lbox on]

[SE f="se000"]
;//【ＳＥ】『携帯電話の発信音』





[OnName num="shouya"]
He said, "Hello?　It's Shoya. ......."
[cpg cn=true]


[VOICE f="Mituki036"]
[OnName num="mituki"]
Ummm, yes. What's wrong ......?"
[cpg cn=true]


[OnName num="shouya"]
He asked me what I was talking about the other day. Another girl.
[cpg cn=true]


What do you mean the other day?　I explained in detail.
[cpg]


There is a girl who likes me morbidly, and that she was asking me about it.
[cpg]


And that if I don't do this, I don't know what I'm going to do to Mitsuki. ......
[cpg]


[VOICE f="Mituki037"]
[OnName num="mituki"]
I don't want to ...... be found out."
[cpg cn=true]


[OnName num="shouya"]
I'm not so sure. The actuality that you can't find it, but it's been found.
[cpg cn=true]


[VOICE f="sMituki002"]
[OnName num="mituki"]
But I can't stop loving you.
[cpg cn=true]



[VOICE f="sMituki003"]
[OnName num="mituki"]
If you hold back,...... you might want to say it in front of everyone."
[cpg cn=true]


...... what?　That sounds like a threat again.
[cpg]


If that were to happen in front of Shizuka, it would add fuel to the fire.
[cpg]


[VOICE f="sMituki004"]
[OnName num="mituki"]
'Wow, I can ...... do it in front of everyone.'
[cpg cn=true]


[OnName num="shouya"]
'All right, all right!　If you don't make sure they don't find us this time, it'll be really bad."
[cpg cn=true]



[SE f="se000"]
;//【ＳＥ】『携帯電話の通話終了音』


;//[lbox off]


With that, he hung up the phone.
[cpg]


......What should I do? I flirted with Mitsuki so that Shizuka wouldn't find me and Mitsuki wouldn't find ...... me.
[cpg]


Oh no, that one can find me. Huh?　I wonder.
[cpg]


I wonder how much Mitsuki knows about my relationship with Shizuka. It would be bad for a man not to tell her that.
[cpg]


I thought about calling her again, but I thought it would be better to talk about important things like this in person, so I went to sleep that day.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[SE f="se005"]
;//【ＳＥ】『鳥の鳴き声』





[OnName num="shouya"]
Is it morning already? ......
[cpg cn=true]


I feel like I'm not sleeping well these days. I dreamt that I was being approached by three people at the same time.
[cpg]


Isn't that a good dream?　Some people might say, "Isn't that a good dream?" ......
[cpg]


It's hard to think that it was all caused by my indecision.
[cpg]


I can't go out with at least two of them. It's weird to date more than two girls at the same time, isn't it?
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




Shizuka's mood was a little better on the way to school. Other than that, nothing special happened.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





What happened was that day at lunchtime.
[cpg]


Instead of eating lunch with Shizuka and Ryoko, I called Mitsuki.
[cpg]


This time, I went further to the edge of the school so that no one would find us. A dusty classroom where no one enters anymore.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki040"]
[OnName num="mituki"]
"Hey, what ...... are you suddenly talking about?"
[cpg cn=true]


[OnName num="shouya"]
"...... I've been keeping quiet about something. I called you up because I felt I had to tell you.
[cpg cn=true]


 Mitsuki was timidly restless, but still had a serious look on her face.
[cpg]


[OnName num="shouya"]
The girl who saw me with Shizuka Tojo .......
[cpg cn=true]


[OnName num="shouya"]
She's also being pressed by that girl, or perhaps she's thinking what Mitsuki is thinking too."
[cpg cn=true]


Will Mitsuki be disappointed?  Or would she hit me?
[cpg]


I thought so, but she reacted in a way I did not expect. She laughed.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mituki041"]
[OnName num="mituki"]
She laughed and said, "Ah, ah, ah, ah, ah, I don't mind. I don't care about that.
[cpg cn=true]


A crazy smile. Was that supposed to be funny?　I questioned my senses.
[cpg]


[OnName num="shouya"]
But, because ...... it's okay?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mituki042"]
[OnName num="mituki"]
"No problem. Me and Shoya are dating."
[cpg cn=true]


......It was. In her mind, she was already dating me.
[cpg]


Unlike Shizuka, Mituki is probably not a jealous person.
[cpg]


Rather, she doesn't even try to look at other girls. That's how sure she is of my love.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sMituki901"]
[OnName num="mituki"]
;//「それよりも……そんなに私のことを気にしてくれるなら、嬉しい」
That's more ...... than that."
[cpg cn=true]


Mitsuki approaches me with enraptured eyes.
[cpg]


[SE f=se000]
;//【ＳＥ】『倒れる』


;//========================================
;//●ＣＧ（主人公に密着するヒロイン。主人公を押し倒してるような感じ）ev_06
;//人物１：ヒロイン３
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_06_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]


 And just like that, I lost my balance.
[cpg]

[OnName num="shouya"]
The actuality that you can't just take a look at the actual video and also the actual video is going to be a lot more effective. It's dangerous.
[cpg cn=true]


Mitsuki's face remained enraptured. I don't know what I'm going to do with this.
[cpg]

[VOICE f="sMituki005"]
[OnName num="mituki"]
It smells so good. ......
[cpg cn=true]


I was getting close enough to kiss her as I said that.
[cpg]

What if Shizuka sees this? I try to shake her off, thinking that this time it would be worse.
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sMituki902"]
[OnName num="mituki"]
;//「どうして嫌がるの？」
Why ......?"
[cpg cn=true]


[OnName num="shouya"]
I'm sorry. ......
[cpg cn=true]


I was already tossed around by the past few days, so I left without explaining myself properly.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



[SE f="se014"]
;//【ＳＥ】『学園のチャイム』





Then I finished my afternoon classes and it was completely evening.
[cpg]


I received a slightly different approach from Shizuka than usual.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Shizuka069"]
[OnName num="shizuka"]
She said, "Hey, Shoya, how about coming over to my place for the next holiday?"
[cpg cn=true]


What I had once said was that it was still too early. The first time I saw her, I was so excited.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ryoko044"]
[OnName num="ryoko"]
He said, "...... what are you going to do?　Shoya."
[cpg cn=true]


Ryoko scares me. She seems to know something about her and my movements somehow.
[cpg]


But can I refuse Shizuka's invitation here?
[cpg]


If anything, Shizuka is the one who is likely to use force. I thought about it for a while.
[cpg]


[OnName num="shouya"]
"Well then, let's go and visit her. ...... Ryoko, you coming too?"
[cpg cn=true]


I tried to take this approach. But it backfired.
[cpg]


Both of them looked at me with a sour look on their faces. I wonder if it's wrong for me to say this.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Ryoko045"]
[OnName num="ryoko"]
"That's okay!　It's okay if you two are having fun together.
[cpg cn=true]

[free time=1000]
Ryoko angrily leaves the classroom. I did a bad thing.
[cpg]


I wonder if I might be a very bad person.
[cpg]


And is it also outrageously evil that I haven't noticed it until now? ......
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



[SE f="se002"]
;//【ＳＥ】『雑踏』





A few days pass, and it's noon on my day off.
[cpg]


It was quite early for the meeting time. But Shizuka was already there.
[cpg]


[OnName num="shouya"]
"Sorry to keep you waiting.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka070"]
[OnName num="shizuka"]
No, I'm not waiting at all. I'm not waiting at all. Shall we go?
[cpg cn=true]


She could have been waiting for me for about two hours.
[cpg]


But I kept that in my imagination. I was afraid to actually ask her.
[cpg]



[SE f="se010"]
;//【ＳＥ】『歩く』





We walked around town. Holding her hand, like a normal lover.
[cpg]


We're not lovers yet, but like lovers,...... sometimes our eyes meet, and Shizuka blushes and looks forward.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




Then we arrived at Shizuka's house. Her parents welcomed us.
[cpg]


[OnName num="shizuka_mother"]
'I can't believe Shizuka finally brought her boyfriend. I am deeply moved.
[cpg cn=true]


I thought "boyfriend" was an old-fashioned way of saying "boyfriend," but I thought it must be true.
[cpg]


It's not the same as a boyfriend, either.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************





Shizuka's room was very tidy. It was a very tidy room.
[cpg]


It was just as it should be. I could feel the madness in the whole empty room.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka071"]
[OnName num="shizuka"]
I was wondering what kind of things we should talk about when we are alone at ...... home.
[cpg cn=true]


[OnName num="shouya"]
I don't ...... know, but what kind of talk would be good?"
[cpg cn=true]


So, we talk about nothing else.
[cpg]


Shizuka often asked me one-sided questions.
[cpg]


Not only about my favorite books, movies, and other hobbies, but also about ......
[cpg]


She would ask me about the type of girl I liked. I could feel her desire to be liked by me.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Shizuka072"]
[OnName num="shizuka"]
I was like, "I'm sorry, I'm sorry, I'm sorry. I'm sorry, it's not nice to be asked what type of girl you like in a one-on-one situation with a girl, is it?
[cpg cn=true]


[OnName num="shouya"]
No, it's okay. I like gentle girls.
[cpg cn=true]


A safe answer of all safe answers. But it's also what I really want.
[cpg]


I want Shizuka to be a kind girl. Am I being cunning to include such intentions?
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka073"]
[OnName num="shizuka"]
I see.
[cpg cn=true]


[OnName num="shouya"]
I want to hear it from you too. What kind of boy is your type?
[cpg cn=true]


What a needless question.
[cpg]


Shizuka's face turned red and she glanced at me and looked down.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka074"]
[OnName num="shizuka"]
She looked at me and looked down. "Well,......, I'm not so good at boys who are very good looking or who stand out.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka075"]
[OnName num="shizuka"]
I like people who gently reach out their hands to me when I'm ...... crying."
[cpg cn=true]


It's all about me. I think he's referring to the Valentine's Day one.
[cpg]


He's turning red as he says it. He must be very embarrassed.
[cpg]


It's true that love is a little heavy. But she is cute.
[cpg]


I think she is a good girl. Even if his character is a little distorted about love, he is not a ......
[cpg]


He is not a so-called evil person at all. He's not the kind of person who annoys people like I am.
[cpg]


He's just too good for ...... me. I don't know why they liked me.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************





As time goes by, I get into a good mood.
[cpg]

She was getting more and more moist in her eyes.
[cpg]

;//========================================
;//●ＣＧエロ（互いにベットで横並びに座りながら、互いの性器を刺激しあう。主人公は後ろから手をまわして胸を揉む）ev_07
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sShizuka002"]
[OnName num="shizuka"]
She said, "...... I'm happy just doing this. Let me stay by your side more."
[cpg cn=true]


Just looking at her like this, she is just a girl.
[cpg]

I think she is also so beautiful that you might fall in love with her. ......
[cpg]

[OnName num="shouya"]
I'll stay by your side if you want me to. I'll stay by your side if you want me to."
[cpg cn=true]


I wonder if it's bad of me to say these things so carelessly.
[cpg]

Even though I thought so, I could not be cold to her at this moment.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka093"]
[OnName num="shizuka"]
I said, "Well, I'll see you later. You can come visit me anytime.
[cpg cn=true]


[OnName num="shouya"]
I'll see you later. See you at ......."
[cpg cn=true]


She waved her hand. She looks like just a pretty girl.
[cpg]


No, a very pretty girl. I couldn't see her usual madness.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




She has a relationship with Shizuka. But the relationship with Mitsuki is also unbreakable.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="female_student_A"]
'Hey, she's that girl, isn't she, Ichijo-kun? ......
[cpg cn=true]


[OnName num="female_student_B"]
I know. I'm not afraid to go out with those two.
[cpg cn=true]


[OnName num="female_student_A"]
Really. They're both mensch."
[cpg cn=true]


[OnName num="female_student_B"]
But I feel like I'd be courted by a girl like that.
[cpg cn=true]


It's not just the boys who are jealous of me, but even the girls are talking about me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
At lunch time, I usually eat with Shizuka, but I refused to have lunch with her and had lunch with Ryoko.
[cpg]


Ryoko didn't say anything. Her expression was almost expressionless, not that she had a gloomy look on her face.
[cpg]


[OnName num="shouya"]
She said, "...... Oh, you know. I'm sorry I haven't talked to you lately."
[cpg cn=true]


Ryoko doesn't say anything. She really doesn't say anything.
[cpg]


I think she's angry, but she doesn't look unhappy either.
[cpg]


[OnName num="shouya"]
I also care about Ryoko. She's an important childhood friend of mine. ......
[cpg cn=true]


No, I can't do that. The only way to convince Ryoko is to tell her that she is the best.
[cpg]


But I don't have the courage to do that. I can't imagine what the other two would think of me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ryoko046"]
[OnName num="ryoko"]
I'm not going to say anything about it. I can wait forever.
[cpg cn=true]


[OnName num="shouya"]
What, ......?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko047"]
[OnName num="ryoko"]
I've been waiting for this for a long time. This is no big deal.
[cpg cn=true]


She was almost confessing, and her eyes were brimming with tears.
[cpg]


The first thing to do is to make sure that you have a good idea of what you're doing. I can't tell her.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko048"]
[OnName num="ryoko"]
I can't tell you. I couldn't tell you for a long time.
[cpg cn=true]


[OnName num="shouya"]
Ryoko ......
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ryoko049"]
[OnName num="ryoko"]
I'm not saying that, it's just that I'm afraid to hear it from ...... Shoya.
[cpg cn=true]


It is not a confession. Rather, it is a refusal to do so.
[cpg]


 I couldn't stand it again. She also wanted to keep this distance.
[cpg]


If only Shizuka and Mitsuki weren't here, we'd probably be ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko050"]
[OnName num="ryoko"]
I think I'm going to cry ....... What should I do, I had decided not to cry."
[cpg cn=true]


I can't even say don't cry. I just said, "I'm just.
[cpg]


[OnName num="shouya"]
"I'm sorry ...... for being so indecisive. ......"
[cpg cn=true]


I had no choice but to say, "I'm sorry.
[cpg]


If I just said, "I'm sorry," it would be like saying I'm done with this relationship, so I added, "I was indecisive.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ryoko051"]
[OnName num="ryoko"]
I added, "I'm sorry. I didn't mean to do this, ugh. ......"
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************





There was nothing I could have done. Or rather, I did nothing.
[cpg]


The result of that was the worst possible outcome.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





I thought it was strange because Ryoko was not there during the morning commute to school, so I headed to her house.
[cpg]



[SE f="se003"]
;//【ＳＥ】『玄関のチャイム』





I pressed the chime, but there was no answer. I had no choice but to call her cell phone and everything became clear.
[cpg]


[OnName num="shouya"]
Ryoko is gone!　Oh no, why?"
[cpg cn=true]


Ryoko's mother answered the phone. She had collapsed, apparently.
[cpg]


She had taken too much of some medicine, so-called overdose.
[cpg]


I was told the name of the drug and its efficacy, but I was too panicked to care about it.
[cpg]


Was even Ryoko so broken that she had to take such medicine?
[cpg]


Even her, without my knowledge. Of course, there were some things that I thought were a little strange. ......
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




I took the train to the hospital. I'm skipping school.
[cpg]


I can't leave her alone. Shizuka sent me nearly a hundred e-mails, but I wasn't in the state of mind to respond to them.
[cpg]



[VOICE f="Ryoko052"]
[OnName num="ryoko"]
She said, "...... you're here."
[cpg cn=true]


[OnName num="shouya"]
Ryoko ......, why did you do that?"
[cpg cn=true]


Ryoko was not covered in tubes from the IV.
[cpg]


But when I saw him in his hospital gown and with a depressed look in his eyes, I knew he really was.
[cpg]


The hospital room. Ryoko said she wanted to talk to me alone and let her parents out of the room.
[cpg]



[VOICE f="Ryoko053"]
[OnName num="ryoko"]
'I'm scared, I ...... think Shoya will go far away.
[cpg cn=true]


[OnName num="shouya"]
'I won't go anywhere. I promise."
[cpg cn=true]


When I said this, she smiled at me just a little.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************





I left the room and the hospital.
[cpg]


She is on the road to recovery. As long as she doesn't repeat the same thing again, I have nothing to worry about.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





I went back to my room and thought. What should I do?
[cpg]


Shizuka. Ryoko. Mitsuki. They are all attractive, but there is something wrong with them.
[cpg]


I wonder if one day I will have to choose someone ......?
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sMituki006"]
[OnName num="mituki"]
Oh, uh, um,...... Shoya-san, that,...... are you free right now?"
[cpg cn=true]


Mitsuki always comes on to me forcefully.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]





[VOICE f="Shizuka094"]
[OnName num="shizuka"]
Shoya, do you have time later?"
[cpg cn=true]


[OnName num="shouya"]
"...... what?"
[cpg cn=true]



[VOICE f="sShizuka003"]
[OnName num="shizuka"]
I'm sure you know what I mean. I'm sure you know that.
[cpg cn=true]


Shizuka approaches me, threatening me.
[cpg]


I don't know what will happen to Mitsuki if I upset her.
[cpg]





[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko086"]
[OnName num="ryoko"]
You know what? Shoya_...... home, do you want to play at my place?"
[cpg cn=true]


And finally, even Ryoko started saying this to me.
[cpg]


She is not pushy or threatening, but I can say that she is holding me hostage.
[cpg]


But I can say that she is holding herself hostage. If I refuse, she might kill herself.
[cpg]


[OnName num="shouya"]
...... got it."
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





As I repeat these days, my heart aches more and more.
[cpg]


And I'm not just talking about the pain, but the self-centeredness of it.
[cpg]


What should I do? My personality has brought this on me.
[cpg]


I have to do something about it.
[cpg]



;//■選択肢
[switch]
[case "I have to choose one person."]
	[swap]
	[jump target="*select02_1"]
[case "I'm just scared."]
	[swap]
	[jump target="*select02_2"]
[endswitch]


One, I have to choose one person.
Two, I'm just scared.


;//==============================
;//１、誰か一人選ばなくちゃいけない

*select02_1|I have a feeling something is going to happen.

;//恋愛ポイント+1
[stflag LoLiflg = 1]
[system sysSel02=true]



I still have to choose one person.
[cpg]


It's not best to keep putting it off, not to go out with anyone.
[cpg]


It's not good for anyone. It's not good for them, and most importantly, it's not good for me to change.
[cpg]


[jump target="*select02_3"]
;//==============================
;//２、ただただ怖い

*select02_2|I have a feeling something is going to happen.

[system sysSel02=false]

I'm scared. What if Shizuka does something to Mitsuki?
[cpg]


What if Ryoko tries to commit suicide again? I'm just scared.
[cpg]


What am I going to do? ......
[cpg]



;//==============================

*select02_3|I have a feeling something will happen.



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002"]
;//【ＳＥ】『雑踏』





While I'm thinking about it, morning comes again. The days were turning into something painful.
[cpg]


I kept trying to have a relationship with all of them. As a result, everyone was going crazy.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

Today, I go to school with Shizuka and Ryoko.
[cpg]


I have to stop this kind of thing as soon as possible. I'm too scared to do it.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ryoko087"]
[OnName num="ryoko"]
Hey Tojo-san, have you ever cut your wrist? Have you ever cut your wrist?
[cpg cn=true]


Ryoko says on the way to school.
[cpg]


She seems to be talking to Shizuka, but I guess she is talking to me too.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Ryoko088"]
[OnName num="ryoko"]
It hurts so much, I can't cut it properly. If I wanted to do it until it became a scar, I would have to do it many times.
[cpg cn=true]


Shizuka replies without any concern, "Yes.
[cpg]


[OnName num="shouya"]
I say, "...... no, you can't slit your wrists."
[cpg cn=true]


I say, but I already know those words won't stop them.
[cpg]


I know those words are not enough to stop them.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Shizuka096"]
[OnName num="shizuka"]
You should have just let them die.
[cpg cn=true]


Shizuka mumbles in a whisper. In a voice that only I can hear.
[cpg]


Both of them are going crazy. They are not hiding their madness any more than before.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





During lunch break, Shizuka, Ryoko and I started having lunch together.
[cpg]


Ryoko is no longer watching us from afar.
[cpg]


The three of us were sitting around the same desk, Shizuka and Ryoko were quietly creating sparks.
[cpg]


I keep soothing them. I can't stop them, even though they know what I intend to do.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



[SE f="se014"]
;//【ＳＥ】『学園のチャイム』


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]


Then, in the evening, Shizuka forced me to go with her.
[cpg]


[OnName num="shouya"]
"Hey, where are you going?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka097"]
[OnName num="shizuka"]
It's a nice place. I found it recently.
[cpg cn=true]


Shizuka said, and we ended up at ......
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Behind the school. She says that a cat lives in this area.
[cpg]

Shizuka's expression is contrary to the awkward feeling she had earlier.
[cpg]

;//[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sShizuka004"]
[OnName num="shizuka"]
She says, "Look, look. Isn't he cute?
[cpg cn=true]


Indeed, a stray cat seems to be living in the area. I was distracted and went along with the conversation.
[cpg]

[OnName num="shouya"]
Yes, I think so, too. I think so, too.
[cpg cn=true]


;//[FACE method="change_1" pos="2/3"]
[VOICE f="sShizuka005"]
[OnName num="shizuka"]
......"
[cpg cn=true]


;//========================================
;//●ＣＧ（しゃがみこんで、主人公を見上げるヒロイン）ev_10
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園裏
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


She crouched down to pet the cat and now looked at me.
[cpg]

[VOICE f="sShizuka006"]
[OnName num="shizuka"]
I wish you'd call me pretty, too.
[cpg cn=true]


[OnName num="shouya"]
......"
[cpg cn=true]


Her eyes seemed pure as she said this.
[cpg]

I'm starting to lose track of everything. Really, I just looked like a damsel in love.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





It was after school and in the middle of leaving the school.
[cpg]


Then, as a matter of course, Ryoko was waiting for me at the school gate.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko089"]
[OnName num="ryoko"]
She said, "You are late. Let's go home."
[cpg cn=true]


She might be angry inside. But there is something more frightening than that.
[cpg]


How did she know I hadn't left?　This has happened before, hasn't it?
[cpg]


Does he know where I am?　If so, how did you ......
[cpg]


Shizuka doesn't seem to care about Shizuka. I don't know anymore.
[cpg]


I wonder if Shizuka would know if I asked her, but I'm too scared to ask her.
[cpg]

[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Shizuka114"]
[OnName num="shizuka"]
I'm afraid to ask her that too. Let's go home.
[cpg cn=true]


The two of them are smiling and checking each other out.
[cpg]


I've had enough of this. I walked on my way home, feeling like that.
[cpg]



[SE f="se010"]
;//【ＳＥ】『歩く』





[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Ryoko090"]
[OnName num="ryoko"]
Speaking of which, thanks for lending me the notebook you gave me when I was on vacation.
[cpg cn=true]


What?　What are you talking about?
[cpg]


I was skipping school when Ryoko was absent. ......
[cpg]


Shizuka?　No way, why.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Shizuka115"]
[OnName num="shizuka"]
'Fine, that's fine. If I have to take a day off because of a cold, please do."
[cpg cn=true]


I don't understand the relationship between these two.
[cpg]


Why would Shizuka be nice to Ryoko?
[cpg]


If it was the other way around, I could still understand. ...... No, maybe.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Ryoko091"]
[OnName num="ryoko"]
I don't care about the scary things she wrote.
[cpg cn=true]


[OnName num="shouya"]
What did it say?"
[cpg cn=true]


I couldn't help but ask. Did it say to break up or stay away?
[cpg]


Or did they say die or kill me?
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Ryoko092"]
[OnName num="ryoko"]
I'll write them all back next time. I'll write them all back in the next couple of days.
[cpg cn=true]


[OnName num="shouya"]
No, no, no!　I don't want to hear any more!
[cpg cn=true]


I shouted and stopped. They walked a little further and looked back at me.
[cpg]


What's wrong?　They looked as if they wanted to say, "What's wrong?
[cpg]


I lost my voice and slumped to the ground.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





Mengera. I think Mitsuki is an easy example.
[cpg]


She is what you would call a sick person, or a girl who seems to have something wrong with her. But on the contrary, I could understand her best.
[cpg]


I couldn't understand Ryoko. I didn't even know she was taking medicine until I heard about it.
[cpg]


I didn't know that she was taking such drugs, and she didn't look like she was taking them.
[cpg]


She is a menshera who looks like a so-called normal girl.
[cpg]


Shizuka is exactly in the middle of the two. No, her direction is different from Mitsuki's. ......
[cpg]


Mitsuki'slove is somewhat normal, even if a little crazy, but Shizuka's love is out of the ordinary and heavy.
[cpg]


Jealousy is too strong. I guess it would be more correct to say that she is possessive.
[cpg]


Even now, I continue to receive e-mails from her. She knows I don't even look at them, but she keeps sending them.
[cpg]


It's broken. I'm getting sick of having a cell phone, but I can't stop myself from having it.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002"]
;//【ＳＥ】『雑踏』




[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

The next day. Shizuka comes to my house again, even though she has to go all the way back and forth.
[cpg]


Ryoko also came to my house. I don't want to do it anymore.
[cpg]


I knew that saying "I don't want to do this anymore" was not going to help.
[cpg]


I can't go on like this. I have to make a decision somewhere.
[cpg]


I knew that, but I was still continuing the current relationship on the sly. ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Ryoko093"]
[OnName num="ryoko"]
I said, "I'll give you back the notebook. Yes.
[cpg cn=true]


The note probably contains Ryoko's resentment towards Shizuka.
[cpg]


However, Shizuka took the note once and went to a nearby convenience store and ......
[cpg]


and threw it in the trash.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Ryoko094"]
[OnName num="ryoko"]
What ......?"
[cpg cn=true]


Even Ryoko, the quintessential Ryoko, was aghast.
[cpg]


Does that mean she doesn't want to read it?　Because I already know what is written in it.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Shizuka116"]
[OnName num="shizuka"]
I don't want to use the notebook you touched anymore. So, I don't want it.
[cpg cn=true]


So this is it. He lent Ryoko the notebook just to say this.
[cpg]


It's more than bizarre, it's crazy. Jealousy has gone too far.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ryoko095"]
[OnName num="ryoko"]
"...... I see. I know, right? You seem to be a germophobe."
[cpg cn=true]


Shizuka says, "No, I'm not. I can't stop her anymore. What should I do?
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





It's getting harder and harder to concentrate on my classes at the school.
[cpg]


I'm thinking about them more than anything else.
[cpg]


I wonder what I would say if someone said to me, "That makes you happy as a man. ...... I might not be able to answer anything.
[cpg]


I might not be able to answer anything. I'm so tired that I don't even know if I'm unhappy right now.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





And a little before after school, between classes. Mitsuki caught me.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sMituki007"]
[OnName num="mituki"]
'You're looking ...... good today.'
[cpg cn=true]


Mitsuki has an eerie smile on her face. Maybe he's smiling cutely in this girl's mind.
[cpg]


I can still understand this kid. I can understand it well just because everything is crazy.
[cpg]


To be honest, it is easier than being with Shizuka and Ryoko. I do as I'm taken.
[cpg]



;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





And before it's after school, I leave Mitsuki and go home with Shizuka and Ryoko.
[cpg]


No matter what I do, Shizuka will try to go home with me.
[cpg]


And Ryoko somehow seems to know where I am and what I'm doing. ......
[cpg]


That's another unresolved scary thing, but that's the phenomenon, not the cause.
[cpg]


The status quo isn't going to get any better when they don't know where I am anymore, right?
[cpg]


Even now, Shizuka and Ryoko are killing each other over words.
[cpg]


As someone who has to listen to that all the time, it's just hell.
[cpg]


I guess this is what it's like to have flowers on both hands. ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





The next morning is the same. The shuraba repeated over and over again.
[cpg]


Ryoko is still self-injurious, and Shizuka's words are too sharp and thorny.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Shizuka117"]
[OnName num="shizuka"]
'Today, too, you're eating lunch with me, right?'
[cpg cn=true]


[OnName num="shouya"]
Oh, yeah. ...... let's eat together."
[cpg cn=true]


I reply without any concern. Ryoko heard that and replied: "Then I'll eat with you too.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Ryoko096"]
[OnName num="ryoko"]
Then I will eat with you.
[cpg cn=true]


The words are without any implication. But ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Shizuka118"]
[OnName num="shizuka"]
I'm sure it's fine. It's more fun to eat with more people, isn't it?
[cpg cn=true]


Just hearing this exchange makes me think, "Oh, the three of us are going to spend more time together again.
[cpg]


It's still fine when it's one-on-one. For example, Shizuka would say she loves me.
[cpg]


It's okay if it's a little heavy. But ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Ryoko097"]
[OnName num="ryoko"]
I think it's more fun when there are fewer people.
[cpg cn=true]


It always starts with a little thorn like this.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Shizuka119"]
[OnName num="shizuka"]
Then, shall we eat together, me and Mizuhara-san?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ryoko098"]
[OnName num="ryoko"]
I don't like ...... it. I don't want to eat with just the two of us.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Shizuka120"]
[OnName num="shizuka"]
Huh?"　Mizuhara-san knows more about medicine than you do, right?　Hey, Shoya."
[cpg cn=true]


Shizuka is also funny to use Ryoko's near-death experience as an irony.
[cpg]


And Ryoko is also strange to be so sarcastic with Shizuka.
[cpg]


I've been listening to this crazy conversation all day long.
[cpg]


[OnName num="shouya"]
"Let's not do that. ...... I'm tired.
[cpg cn=true]


My spirit was getting worn out.
[cpg]




;//移植のためシーンをカットしています
;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[SE f="se014"]
;//【ＳＥ】『学園のチャイム』


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





After all that happened, we are now in the classroom at lunchtime ......
[cpg]


Shizuka had finished her lunch and had left her seat to use the restroom.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mituki078"]
[OnName num="mituki"]
'Sh, sh, Shoya-san,...... hello.'
[cpg cn=true]


Mitsuki came to my class. I thought, "Hey, hey, hey," and I got impatient.
[cpg]


If Shizuka comes back here, the four of us will have to talk. I want to avoid that. We don't know what will happen.
[cpg]

[free time=1000]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/2" time=800]

[VOICE f="Ryoko099"]
[OnName num="ryoko"]
I said, "Why don't you answer her at ......?　Shoya.
[cpg cn=true]


[OnName num="shouya"]
Ah, ah. Hello."
[cpg cn=true]


Even Ryoko's casual words seem scary in the way she says them.
[cpg]


Ryoko knows Mitsuki well. There must be plenty of resentment.
[cpg]


No, I may have just as much resentment,......, but right now I'm worried about Mitsuki.
[cpg]


If either Ryoko or Mitsuki were to raise a hand, it would be Ryoko's. Mitsuki has already gone out with me.
[cpg]


Mitsuki already convinced he's dating me, and no matter what he says to me, he'll blow it out of the water.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Mituki079"]
[OnName num="mituki"]
"Go, eat rice ...... with me?　I made lunch for you."
[cpg cn=true]


[OnName num="shouya"]
I'm already full ...... and I've already finished eating."
[cpg cn=true]


I wonder why he started asking me to eat lunch with him at this point in the day.
[cpg]


If it had been a little earlier,...... no, no, if it had been earlier, the four of us would have talked after all.
[cpg]


Was Mitsuki being considerate in his own way?　It is still strange for him to suggest eating lunch for that matter.
[cpg]


Maybe you made two lunches as an excuse to talk to me?
[cpg]


[OnName num="shouya"]
That's ...... why don't you go back to your class?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="Mituki080"]
[OnName num="mituki"]
I'm ...... your girlfriend and I want to be with you for as long as I can."
[cpg cn=true]


That's not a good idea. The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it.
[cpg]


And gradually, her expression changed to one of anger. This is not good.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Ryoko100"]
[OnName num="ryoko"]
If only you weren't here,......."
[cpg cn=true]


The first thing to do is to make sure that you have a good time with your family.
[cpg]


It looks like he is going to put his hands on my neck. This is not good.
[cpg]


The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Mituki081"]
[OnName num="mituki"]
I was in a hurry and didn't know how to stop him.　I'll tell them about the GPS.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Ryoko101"]
[OnName num="ryoko"]
I said, "What ......, how do you know about it?"
[cpg cn=true]


I stopped thinking for a moment. I thought, "What are you talking about?
[cpg]


Right after that, it made sense to me.
[cpg]


They must have planted something in my belongings or on my phone itself.
[cpg]


That's how they knew where I was. Would I go that far?　At the same time, I caught a glimpse of Ryoko's madness.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mituki082"]
[OnName num="mituki"]
;//「だ、だ、だから……仲良くしたい。恋人の、幼馴染だから」
'Da, da, that's why I want to ...... get along with you.'
[cpg cn=true]


Rather than sparks flying, Ryoko is trying to mend the situation. It's already useless.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Then Mitsuki retreated. Before Shizuka returned, he left as if to escape.
[cpg]


She only exposed Ryoko's madness, closed the distance between me and her, and then quickly left.
[cpg]


It makes me think that she is really a very well-prepared girl.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************




[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
I think Ryoko was weak. She knew a secret that she didn't want me to know.
[cpg]


Before Shizuka came to my class, she forcefully pulled my arm.
[cpg]


I walk back to my house as fast as I can run, not as fast as I can walk.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ryoko102"]
[OnName num="ryoko"]
"I won't give you ...... Shoya, he's mine and mine alone."
[cpg cn=true]


He's mumbling, but I can hear him.
[cpg]


[OnName num="shouya"]
I'm not going anywhere. I'm not going anywhere.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko103"]
[OnName num="ryoko"]
It's not enough that I'm not going anywhere.
[cpg cn=true]


It's not good enough. While I'm not going anywhere, Shizuka or Mitsuki might take me.
[cpg]


That is what Ryoko is afraid of. I understand it very well.
[cpg]


That said, I can't be swayed by that every single time.
[cpg]


I have to have my own will. I was beginning to think so recently.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I was beginning to think so, and then I was brought to this place.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko104"]
[OnName num="ryoko"]
"......"
[cpg cn=true]


[OnName num="shouya"]
"......"
[cpg cn=true]


We both fall silent. For some reason, we both sit on the floor and sit on our haunches.
[cpg]


I had been to Ryoko's room before. We live close to each other, and we've known each other since childhood.
[cpg]


But being brought to her room now has a slightly different meaning.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sRyoko902"]
[OnName num="ryoko"]
;//「お、お願い……私のこと、好きって言って……可愛いって言って」
Please ...... tell her that you like me ......."
[cpg cn=true]


She turns red in the face and says so. Yes, that's what I'm talking about.
[cpg]


Thinking back, I hadn't said anything to Ryoko since the incident at the hospital.
[cpg]


[OnName num="shouya"]
The first thing to do is to make sure that you are not too anxious about the situation. I think it's going to turn out the way it's going to turn out.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko106"]
[OnName num="ryoko"]
I'm sure it'll turn out the way it's going to turn out. You can't just say it like it's someone else's problem.
[cpg cn=true]


I agree with you. I'm sure you'll be able to find a way.
[cpg]


A genuine three-way. I never dreamed I'd end up like this.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Ryoko107"]
[OnName num="ryoko"]
Please ...... I have to be Shoya. I love him so much I can't help it."
[cpg cn=true]


The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it. But I'm not just going to be swept away by the cuteness of it,.......
[cpg]


The first thing that I did was to tell her that I was going to make sure that Ryoko wouldn't explode in the future.
[cpg]

[OnName num="shouya"]
"...... is cute, Ryoko."
[cpg cn=true]


I'm the worst. I am the worst of the worst as a man.
[cpg]


Why did they like me so much?
[cpg]



;//========================================
;//●ＣＧ（立っているヒロイン。主人公を見下ろしている）ev_13
;//人物１：ヒロイン２
;//服装１：私服→制服にします
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_13_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sRyoko001"]
[OnName num="ryoko"]
I'm sorry, ....... It's like I'm making you say it."
[cpg cn=true]


She stood up and said that to me as she sat down.
[cpg]

She still has some sense of reason. It was the kind of comment that made me think so.
[cpg]

[OnName num="shouya"]
I'm not forcing myself to say it.
[cpg cn=true]


;**【ＣＧ】 ev_13_a ***********************
[CG id=7 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="sRyoko002"]
[OnName num="ryoko"]
She said, "No, I'm not forcing myself. I'm happy for you, no matter how you feel about it.
[cpg cn=true]


She looked down at me and seemed a little sad.
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





I returned home before nightfall after all that.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Ryoko125"]
[OnName num="ryoko"]
"Well, I'll see you at ......."
[cpg cn=true]



[OnName num="shouya"]
I'll see you later. See you."
[cpg cn=true]


I said, meaning that I didn't mind.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

When I returned home, Shizuka was waiting for me.
[cpg]


I was a little surprised. Had she been waiting for me all this time?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka138"]
[OnName num="shizuka"]
She said, "Welcome home. You came out from Ms. Mizuhara's house."
[cpg cn=true]


[OnName num="shouya"]
"......Yes. She forced me to take you to ......."
[cpg cn=true]


No, no.
[cpg]


[OnName num="shouya"]
No,......, I went to Ryoko's house of my own volition.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka139"]
[OnName num="shizuka"]
I wonder if he felt any guilt towards me. Do you want to know how I felt when I was waiting for you?
[cpg cn=true]


I don't want to know. I don't want to know, but I have no choice but to ask.
[cpg]


[OnName num="shouya"]
I don't want to know, but I'm going to have to ask. You can tell me anything you want if we can talk it out.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka140"]
[OnName num="shizuka"]
"Heh. I'm angry at you, Mr. Mizuhara.
[cpg cn=true]


Oh, I see. I guess there's nothing I can say to make it go away.
[cpg]


I guess that shurabu will come again. With that thought, I said my goodbyes with a sense of dread.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




I couldn't even say "I'm home. I was already exhausted.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I collapse into bed, still groggy. Nothing would change even if I did that.
[cpg]


It's my fault. Even if I realize that, nothing will change.
[cpg]


Nothing changes. On top of that, things keep going from bad to worse.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/2" time=800]

The next morning. Shizuka and Ryoko sparked off.
[cpg]


I can't get used to seeing them. I feel like they are both showing me how it's done.
[cpg]


I wonder if one of them will kill the other one someday.
[cpg]


If so, Shizuka is more likely to do it. ......
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





In between morning classes. I was in between classes in the morning when I left my seat to use the restroom.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
When I came back from the bathroom, I saw Ryoko playing with my phone.
[cpg]


My phone has a passcode on it. Does she know that I'm playing with it?
[cpg]


So I wonder if she's playing some kind of trick that sends my current location somewhere.
[cpg]


I dared to approach her unnoticed and talked to Ryoko from behind.
[cpg]


[OnName num="shouya"]
What are you doing at ......?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Ryoko126"]
[OnName num="ryoko"]
Whoa!　What's wrong?　I didn't see any sign of you.
[cpg cn=true]


She was more flustered than she should have been. I guess that's what he meant.
[cpg]


That's not good. What's worse is that I didn't notice that about Ryoko.
[cpg]


She's sick, too. It's not normal for her to want to restrain me like this.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ryoko127"]
[OnName num="ryoko"]
"Look, look. I have to get to my seat because class is about to start.
[cpg cn=true]


[OnName num="shouya"]
"......, right. ......."
[cpg cn=true]


I was too tired to say anything else, so I decided to just let it go.
[cpg]


I wonder how much she knows about me.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



[SE f="se014"]
;//【ＳＥ】『学園のチャイム』





And then, the end of class. Today, too, Ryoko took me out before Shizuka came in.
[cpg]


[OnName num="shouya"]
Where are you going?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sRyoko003"]
[OnName num="ryoko"]
Let's take the train to another town. For a change."
[cpg cn=true]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



[SE f="se000"]
;//【ＳＥ】『電車に揺られる』


And in the nearly full train, Ryoko whispers to me, "Hold my hand.
[cpg]


;//========================================
;//●ＣＧ（電車で密着する二人）ev_14
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：電車内
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sRyoko004"]
[OnName num="ryoko"]
Hold my hand.
[cpg cn=true]


[OnName num="shouya"]
Even if it's ......."
[cpg cn=true]


I tried to hold her hand as she asked, but it was difficult because of the ...... position.
[cpg]

;**【ＣＧ】 ev_14_a ***********************
[CG id=8 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="sRyoko005"]
[OnName num="ryoko"]
If you can't, hold me. I want you to show everyone."
[cpg cn=true]


I can understand her mindset when she says this much.
[cpg]

I'm sure she's saying that as long as Shizuka is around, she can't flirt in front of people.
[cpg]

I approached her, thinking that there was no way she was being watched right now.
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





We did not do anything special at the station where we got off the train, but just took a short walk and came back soon after.
[cpg]

Perhaps, for Ryoko, the train incident was the main issue.
[cpg]


I guess Shizuka is at home anyway. Shall I go home through the back door?
[cpg]


What a surprise, that would add fuel to the fire.
[cpg]


If anything, it's going to happen normally that I'll be waiting in front of the house all the way to .......
[cpg]


Ryoko and I are going back in the same direction. And we ran into Shizuka at the same time.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Shizuka141"]
[OnName num="shizuka"]
She said, "Welcome back to ....... You're back late.
[cpg cn=true]


[OnName num="shouya"]
Ryoko said she wanted to buy something,......, and it was urgent, so I was forced to go with her.
[cpg cn=true]


It's a bitter excuse. And then Shizuka pursued further.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Shizuka142"]
[OnName num="shizuka"]
The first thing to do is to get a good idea of what you are looking for. What is it?　Say it at the ready. Se-no."
[cpg cn=true]


We couldn't say anything. Shizuka has already noticed.
[cpg]


She's not going to talk to us about it.
[cpg]


[OnName num="shouya"]
She said, "...... is true. Trust me.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Shizuka143"]
[OnName num="shizuka"]
Why would she lie?　Do you hate me now?
[cpg cn=true]


[OnName num="shouya"]
I don't hate you. ......
[cpg cn=true]


It's a problem to say this here, though. Ryoko is right next to me.
[cpg]


[OnName num="shouya"]
I'm not going to choose someone else.
[cpg cn=true]


I wonder if this is counterproductive. I think so and try to say it out loud.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ryoko147"]
[OnName num="ryoko"]
I'm going to go to ...... now, okay?　I'll see you later, Shoya."
[cpg cn=true]

[free time=1000]
The reason why Ryoko looks a little grumpy is because she is not happy.
[cpg]


The reason she looks grumpy is probably because she said, "I don't hate you.
[cpg]


[OnName num="shouya"]
'Well, I'll be here too ...... See you later, Shizuka.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka144"]
[OnName num="shizuka"]
Shizuka said, "Wait a minute. I'm not done talking yet."
[cpg cn=true]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




From there, it took me thirty minutes to persuade Shizuka.
[cpg]


It was already hard. I'm not going to let anyone help me even if I want them to.
[cpg]


It's all my fault. I think I have to do something about it, but I can't do anything about it. ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************





Then, the next holiday. I thought Shizuka would come barging into my house, but she said something about catching a cold on SNS.
[cpg]


I just can't move, and I get emails with great frequency, but I can't answer every single one of them.
[cpg]


And Ryoko has no place to go to barge into my house.
[cpg]


I'm going to spend some time for myself today. So she decided to go out somewhere.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




[OnName num="shouya"]
I'm off."
[cpg cn=true]



[SE f="se011"]
;//【ＳＥ】『ドア開く』





[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





Then I saw someone a little unexpected. He was standing there in a gothic lolita fashion.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mituki083"]
[OnName num="mituki"]
Sho, Shoya-san ......, I'm going to go on a date with you, that .......
[cpg cn=true]


Come to think of it, Mitsuki had also been left alone for a while.
[cpg]


The next time you are in the market, it's Mitsuki's turn. I feel like sighing, but I don't sigh.
[cpg]



;//ＢＫ



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************




[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
This isn't the first time I've gone out on a date with Mitsuki. It was a little different from the dates I've had with her in the past.
[cpg]


Mitsuki was getting used to me, or maybe she was starting to show her own taste.
[cpg]


She would browse through books in the occult section of a used bookstore with a smirk on her face, or on the other hand, she would make a difficult face.
[cpg]


If I were a normal girl, I would think that if I did these things in front of boys, I would pull it off or something. ......
[cpg]


In Mitsuki's case, it was not that she was opening up to me so much.
[cpg]


I don't know if I should be happy about that. I don't know.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki084"]
[OnName num="mituki"]
I don't know. "Ta, ta, fun. ......?　Shoya-san.
[cpg cn=true]


[OnName num="shouya"]
I'm having fun."
[cpg cn=true]


I answered in a very unenthusiastic way.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mituki085"]
[OnName num="mituki"]
I was afraid I was going to get pulled off .......
[cpg cn=true]


I'm pulling back, though. I thought it was not a good idea to lie.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se002"]
;//【ＳＥ】『ゲームセンターの騒音』





The first thing to do is to make sure that you have a good time with your friends and family.
[cpg]


The other day we were playing a sound game, but today we were going to something else.
[cpg]


Shooting, I think it's called. Not the kind where you aim with a gun, but the kind where you use levers and buttons on a flat surface.
[cpg]


[OnName num="shouya"]
I said, "...... what is this thing doing?"
[cpg cn=true]



[VOICE f="Mituki086"]
[OnName num="mituki"]
"This, this is all even bullets, so ......."
[cpg cn=true]


He tried to explain something to me, but I had no idea what it was.
[cpg]


And then what looked like enemy bullets were scattered all over the screen and then disappeared.
[cpg]


I was getting tired of pulling it off, as I was just thinking again that this kid is a gamer.
[cpg]


And after that, it was still a sound game. A lot of notes ...... and this is what I thought before.
[cpg]



[VOICE f="Mituki087"]
[OnName num="mituki"]
"This song is so beautiful to look at that it's easy to get ...... peculiar."
[cpg cn=true]


[OnName num="shouya"]
What do you mean by "peculiar" ......?"
[cpg cn=true]


Mitsuki started talking like a machine gun after I asked him one word.
[cpg]



[VOICE f="Mituki088"]
[OnName num="mituki"]
"Mi, mi, if you look pretty, I'll remember you by mistake on my own."
[cpg cn=true]



[VOICE f="Mituki089"]
[OnName num="mituki"]
The so-called curse is called ...... uh, a curse."
[cpg cn=true]


That's enough. What's a quirk?　And you just said so.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





The last place I was taken, exhausted, was to her house.
[cpg]


...... There's no turning back here. I couldn't get in before.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki090"]
[OnName num="mituki"]
Let's go in. ...... what's wrong?"
[cpg cn=true]


[OnName num="shouya"]
Nothing."
[cpg cn=true]


;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

At her house, Mitsuki was more nervous.
[cpg]

But I can see that she seems happy. I can say that her reaction is different from Ryoko's. ......
[cpg]

In the end, while we were repeating the conversation without doing anything else, it was time to go back.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="shouya"]
"Well then, goodbye ......
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mituki107"]
[OnName num="mituki"]
Today was fun.
[cpg cn=true]


[OnName num="shouya"]
I see.
[cpg cn=true]


I had to choose one person. I'm sure of it now.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





The next morning. The morning sun was awfully dazzling. It was probably because I was tired.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Shizuka145"]
[OnName num="shizuka"]
The next morning, the sun was shining brightly. Shoya, shall we go to the school?
[cpg cn=true]



[VOICE f="Ryoko148"]
[OnName num="ryoko"]
Good morning. Good morning, another day is about to begin.
[cpg cn=true]


It almost rings in stereo. I wonder if they are competing with each other to see who will greet first.
[cpg]


By the way, Shizuka seems to have recovered from her cold. That is honestly a good thing. ......
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





So, a little before lunch break, in between the morning classes.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mituki108"]
[OnName num="mituki"]
Sho, Shoya-san,......, I had a good time yesterday.
[cpg cn=true]


Not surprisingly, Mitsuki said such a thing when he was with Shizuka.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Shizuka146"]
[OnName num="shizuka"]
"...... what did you do yesterday?"
[cpg cn=true]


Shizuka asks me that. This is not good.
[cpg]


While I was thinking of an excuse, Kouki answered.
[cpg]

[FADEOUTBGM]
[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="sMituki008"]
[OnName num="mituki"]
We were making out ...... at home, just the two of us."
[cpg cn=true]


I said something I definitely shouldn't have said.
[cpg]


Kouki is not sure anymore. She probably feels like a complete lover with me.
[cpg]


She and I are lovers. So there is no problem to say this.
[cpg]


That's probably the logic. While I was thinking about this, Shizuka pulled out a cutter knife from her pen case.
[cpg]



[BGM f="bg_ky"]

[SE f="se045"]
;//【ＳＥ】『カッターナイフの刃を出す　キリキリ』





Shizuka took out a box cutter knife from her pen case and tried to put it on Mitsuki's neck.
[cpg]


The fact that she stopped at "tried to apply it" was thanks to me.
[cpg]


I want both Shizuka and Mitsuki to be grateful. I mean....
[cpg]


In short, I was holding Shizuka's arm. I think I did a good job of moving on the spur of the moment.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Shizuka147"]
[OnName num="shizuka"]
I'm not going to let you get any closer to Shouya!
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Mituki110"]
[OnName num="mituki"]
Why ...... are we lovers?"
[cpg cn=true]


The first time I saw him, I thought he was going to be a good guy. I knew this would happen one day.
[cpg]


The students around you will look at you with eyes that see something bizarre.
[cpg]



;//■選択肢
[switch]
[case "Let's cut ties with these kids."]
	[swap]
	[jump target="*select03_1"]
[case "I'm lucky to be so loved."]
	[swap]
	[jump target="*select03_2"]
[endswitch]


One, I'll cut myself off from these kids.
2. I'm happy to be loved like this.



;//==============================
;//１、この子たちとは縁を切ろう
*select03_1|I have a feeling something will happen.


[system sysSel03=false]

Let's get rid of these children. Not right now, but little by little.
[cpg]


[OnName num="shouya"]
If you keep doing that, I'm cutting them off. ......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Shizuka148"]
[OnName num="shizuka"]
......!"
[cpg cn=true]


Shizuka put away the cutter knife after hearing those words.
[cpg]


[jump target="*select03_3"]
;//==============================
;//２、こんなに愛されてる自分は幸せだ
*select03_2|I have a feeling something is going to happen.

;//恋愛ポイント+1
[stflag LoLiflg = 1]

[system sysSel03=true]


......It's a man's dream in a way. If only she loved me this much.
[cpg]


[OnName num="shouya"]
'I know, and I know how much you love me from Shizuka, so calm down,......!
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Shizuka149"]
[OnName num="shizuka"]
"......I understand."
[cpg cn=true]


Shizuka put down the cutter knife. I was relieved.
[cpg]



;//==============================

*select03_3|I have a feeling something is going to happen.


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





If I continue like this every day, I really can't handle it.
[cpg]


With that in mind, I headed home with Shizuka, Ryoko, and the two of them in tow.
[cpg]


Please bear with me. It won't help if I tell them that.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Ryoko149"]
[OnName num="ryoko"]
I heard you almost stabbed ...... Shimano-san?"
[cpg cn=true]


If you had just stabbed her, there would have been two people out of the way. And ...... she blurted out, but I can hear her.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Shizuka150"]
[OnName num="shizuka"]
I can hear you. I might stab you if I have to.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ryoko150"]
[OnName num="ryoko"]
"Nothing, I do self-harm, too. ......
[cpg cn=true]


Oh, God. I've had enough. I've had enough.
[cpg]


I've had enough. I'm going to explode.
[cpg]


The only reason I can stand it is because I feel bad about me.
[cpg]


I'm such a bad person. That's why I'm like this.
[cpg]


I shouldn't have done this when I'm not much of a guy and can't satisfy all the girls.
[cpg]


I should have just stuck with someone else. Even if the other two girls stabbed me in the back.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




[OnName num="shouya"]
"Okay, bye-bye. ......
[cpg cn=true]



[VOICE f="Shizuka151"]
[OnName num="shizuka"]
Bye. See you later.
[cpg cn=true]



[VOICE f="Ryoko151"]
[OnName num="ryoko"]
"See you at ...... school."
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[SE f="se011"]
;//【ＳＥ】『ドア閉まる』





You have to choose one ...... of them, but who will you take as your girlfriend?
[cpg]


Who is the prettiest?　I don't know... I don't even know if it's wrong to choose based on such criteria anymore.
[cpg]


I don't know anymore. I think it's strange to go out with someone for their protection.
[cpg]


It is also strange to go out with someone for their sake.
[cpg]


I think people should get together when they truly love someone.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



With these thoughts in mind, I went to sleep today with my answer still vague.
[cpg]


You think that you can't stand ...... anything anymore, but you are desperate to maintain the status quo.
[cpg]


[jump storage="ep002.ks" target="*start"]
