
*start


;#################################################
*Ep004|Continue Shizuka's Lover
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

*root_true|Continue Shizuka's Lover

[SCENE id=4]

[OnName num="shouya"]
"...... right. Shizuka is right."
[cpg cn=true]


I decided to continue being Shizuka's lover.
[cpg]


I know her abnormality better than anyone else. I don't know what will happen if I make her angry.
[cpg]


If I offend her, it's still fine, but if I dump her, she will really kill me.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





The days go on. Not only Mitsuki, but even Ryoko stopped coming to the school.
[cpg]


I made both girls crazy.
[cpg]


Not only did I make them crazy, but I gave Ryoko a near fatal wound: ......
[cpg]


It's my fault. I sigh, thinking so.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka233"]
[OnName num="shizuka"]
What's wrong?　Sighing, are you worried about something?"
[cpg cn=true]


[OnName num="shouya"]
"Yeah, well, ...... a little.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka234"]
[OnName num="shizuka"]
Tell me. I want to know everything about you. I want to get rid of everything that makes you unhappy."
[cpg cn=true]


I like what you're saying, but the way you say it is a little scary.
[cpg]


You don't have to use such a scary word as "elimination. Thinking that, I told him what I was thinking.
[cpg]


[OnName num="shouya"]
About Ryoko. I thought, "It's my fault, isn't it?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka235"]
[OnName num="shizuka"]
...... are you still thinking about her?"
[cpg cn=true]


Low tone of voice. It was a tone that made it clear at once that he had stepped on a landmine.
[cpg]


[OnName num="shouya"]
I'm thinking about Shizuka. I always think about Shizuka.
[cpg cn=true]


It was a bitter excuse. I had let my guard down.
[cpg]


I knew that if I thought about it calmly, it would upset Shizuka's nerves.
[cpg]


But when your childhood friend tries to commit suicide, you can't stay calm, can you?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Shizuka236"]
[OnName num="shizuka"]
I don't want to be separated from you even for a second. I don't want you to think about any other woman, not even for a second.
[cpg cn=true]


Nothing happened in that moment.
[cpg]


To make it up to her, I would go to Shizuka's house today. I thought that was the end of the matter.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





Then, I finished my classes at the school.
[cpg]


If only I had realized at that moment that every time I saw Shizuka, she was grinning at me.
[cpg]


If only I had realized it and had been able to see the danger that was about to befall me. ......
[cpg]


I'm sure it wouldn't have happened that way.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




Shizuka was grinning as we walked through the city.
[cpg]


I wondered why she was in such a good mood.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************





[OnName num="shouya"]
No matter how many times I look at it, Shizuka's room is always so tidy. ......
[cpg cn=true]


As soon as I said that, I fell unconscious. I remember that someone grabbed me from behind.
[cpg]


That's the strange thing about it, Shizuka was right in front of me.
[cpg]


So it was not Shizuka who did this. Does that mean Shizuka's family ......?
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************





The next time I woke up, the scenery had changed.
[cpg]


[OnName num="shouya"]
"What ......?"
[cpg cn=true]


I couldn't move, but I couldn't even open the door. And there was Shizuka sitting on the bed, smiling.
[cpg]


And the clock had gone back about an hour. I thought it was ridiculous and looked at it again, but it was back.
[cpg]


It means I had slept for twenty-three hours. Unless I was on drugs, there was no way I could have slept like that.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka237"]
[OnName num="shizuka"]
My room needs a key to open from the inside. Isn't it nice?
[cpg cn=true]


[OnName num="shouya"]
"......Ah, you know.........Shizuka..."
[cpg cn=true]


Gradually, I began to understand the situation. I'm being held captive, perhaps?
[cpg]


[OnName num="shouya"]
I want to go home,.......
[cpg cn=true]


I didn't ask a stupidly honest question like, "Are you going to lock me up?
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Shizuka238"]
[OnName num="shizuka"]
No. You're a nice person, but you're more than that. You're a nice person, but I'll make you more like me.
[cpg cn=true]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************





A few more hours passed. I was hungry.
[cpg]


I mean, I hadn't eaten anything in over a day. I was beyond hungry and my insides started to ache.
[cpg]


[OnName num="shouya"]
I'd like to eat something ......, anything at all.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sShizuka013"]
[OnName num="shizuka"]
I don't know. I don't know.
[cpg cn=true]


I could feel the intention behind it, as if he was trying to get me in a good mood.
[cpg]

But I was too hungry to think properly.
[cpg]


;//移植のためシーンをカットしています

[FACE method="change_4" pos="2/3"]
[VOICE f="sShizuka014"]
[OnName num="shizuka"]
But I feel sorry for him if he is in too much pain.
[cpg cn=true]




Shizuka leaves the room. At that moment, the door was opened. ......
[cpg]


The door was opened at that moment, but I couldn't leave the room.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka257"]
[OnName num="shizuka"]
It's no use trying to get out. My house, you have to go through the living room to get to the front door. ......
[cpg cn=true]


He said that one of his parents was always watching the living room.
[cpg]


Of course, he also said that he had something to make me quiet.
[cpg]


Something to make me quiet. A knife or some kind of weapon?
[cpg]


I felt a chill as I sensed that the family must be crazy.
[cpg]



;//ＢＫ



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka258"]
[OnName num="shizuka"]
She said, "Yes, it's late dinner, but you'll eat it, won't you?"
[cpg cn=true]


With that, she brought me a plate of curry.
[cpg]


There was a spoon, but I couldn't hold it. I had an inkling of what she was going to do.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka259"]
[OnName num="shizuka"]
I'll feed it to you. Yes, ah-an."
[cpg cn=true]


She opened her mouth. I have to open my mouth. The hunger was already too much.
[cpg]


I hated myself for feeling that the curry tasted good.
[cpg]


I hate the fact that I don't like or appreciate Shizuka anymore.
[cpg]


Yes, I had completely lost my love for Shizuka.
[cpg]


I can't like someone who goes so far, no matter how much I want to.
[cpg]


But if I say that I no longer like her, I think that would be the end.
[cpg]


I don't know what will happen to me. I will be crippled, killed, or worse than either of them.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************



Then, the days of brainwashing by Shizuka started.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************




Shizuka also brought my lunch directly to my mouth.
[cpg]


Sometimes she would even feed it to me by hand, and I could not help but feel embarrassed.
[cpg]


I had no choice but to think she was crazy.
[cpg]


I had never seen a girl like this. I've never seen a girl who could do such a horrible thing to someone and then be ashamed of it.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



She took me to the bathroom when I asked.
[cpg]


Of course, I couldn't run away.
[cpg]

My sense of time is getting fuzzier and fuzzier. ......
[cpg]


;//移植のためシーンをカットしています


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka281"]
[OnName num="shizuka"]
The first thing that comes to mind is the fact that the first time you see a person, you know that you're going to be able to see them. Shoya."
[cpg cn=true]


Chance, I thought a little. If you can take away the key that she would have.
[cpg]


It should be possible to open it from the inside. We might be able to escape from here.
[cpg]


As I was thinking that, Shizuka nailed me.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka282"]
[OnName num="shizuka"]
She said, "You know I don't have the key right now. I'll have your father lock the door from the outside.
[cpg cn=true]


[OnName num="shouya"]
She said, "......, what are you talking about ......?　Are you insane?　What are you going to do about the bathroom?
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka283"]
[OnName num="shizuka"]
"I'll call your father and he'll open it for me. Okay, good night."
[cpg cn=true]


Even if I took the phone or ...... it, my voice would give it away.
[cpg]


There was nothing I could do. I was at a loss.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



The two of us in bed, cuddled up together. Shizuka was asking for it, so I had no choice but to comply.
[cpg]


If you live like this for too long, you'll never get back to normal.
[cpg]

......Thinking this, I fell asleep exhausted.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************





And morning comes. I was so tired that I went to bed.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka284"]
[OnName num="shizuka"]
Good morning, Shoya. Shall we have breakfast?"
[cpg cn=true]



[OnName num="shouya"]
"...... Shizuka, how is the school doing ......?"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka285"]
[OnName num="shizuka"]
I'm on a leave of absence. The actuality that you can get a lot of these types of products and services is a good thing.
[cpg cn=true]


Huh. It's kind of like all common sense doesn't apply anymore.
[cpg]


It's not even a question of crazy or not crazy.
[cpg]


I feel as if I am a different creature. That's how different he is from me.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************



Around noon. Shizuka's brainwashing began in earnest.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka313"]
[OnName num="shizuka"]
She said, "Tell me what you think is cute about me.
[cpg cn=true]


I still didn't know what she meant by that.
[cpg]


[OnName num="shouya"]
I still didn't know what it meant. "......Yes, your smile is cute. ......"
[cpg cn=true]


My voice was trembling. I didn't know what they would do to me if I used the wrong words.
[cpg]

And Shizuka asked, "What else?　She asked.
[cpg]


[OnName num="shouya"]
'She's single-minded and ...... usually ladylike, but she's very interested in love ...... and .......
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka314"]
[OnName num="shizuka"]
She says, "Yes. Keep it up and don't stop."
[cpg cn=true]


;//だんだん意図が見えてきた。言えなくなったところで電流を流される。
Gradually I began to see the intention. When I couldn't say it anymore, I was made to say it again from the beginning.
[cpg]


It was only a matter of time. There are only so many words you can use to compliment a girl, and if you say something that doesn't apply to her, that's not good either.
[cpg]


[OnName num="shouya"]
Stop it, ......."
[cpg cn=true]



Shizuka nodded her head. And then she came closer to me.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="sShizuka015"]
[OnName num="shizuka"]
I'm not joking.
[cpg cn=true]


I'm not kidding. I would really go crazy if they took away my meal in this situation.
[cpg]


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

;//========================================
;//●ＣＧ（主人公に迫るヒロイン。狂気の形相）ev_23
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：夜
;//========================================

[BGM f="bg_h2"]
;**【ＣＧ】 ev_23_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]


She's cute, she made me say it.
[cpg]



I was going crazy, but she looked down at me with a smile.
[cpg]

[VOICE f="sShizuka016"]
[OnName num="shizuka"]
Anything else?"
[cpg cn=true]


[OnName num="shouya"]
Uh, let's see... ......."
[cpg cn=true]

;**【ＣＧ】 ev_23_a ***********************
[CG id=11 index=1 time=1]
;***************************************
[WAIT time=1]


She looks at me happily as I'm at a loss for words. I could see that she was completely broken.
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


That day, by the time I went to bed, Shizuka was out of the room.
[cpg]


I guessed she was sleeping in another room. Why?
[cpg]


She also said she was preparing for tomorrow, what was she going to do?
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************





[OnName num="shouya"]
......"
[cpg cn=true]


When I woke up in the morning, she was not in this room.
[cpg]


I'm left alone.
[cpg]


I have ...... enough time for a while. I wanted to go to the bathroom on the way, so I called out loudly for someone and Shizuka's mother unlocked the door for me.
[cpg]


Shizuka's mother, who is also cooperating with the confinement,......
[cpg]


She had a quiet smile on her face, but I sensed an unfathomable freakishness behind it. I see, I thought, that must be Shizuka's mother.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




With all that going on, the morning was almost noon.
[cpg]


There was no way she would do anything more than I could imagine. Somewhere along the way, I had gotten my head out of my ass.
[cpg]


I was reminded that I had been naive.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************





[FG f="CHA02_p3_02_a.ui" method="change_5"  pos="1/2" time=800]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Ryoko156"]
[OnName num="ryoko"]
What is ......?　Why is Shoya here?
[cpg cn=true]


[OnName num="shouya"]
"Nah, ......."
[cpg cn=true]


The one who was brought there was Ryoko.
[cpg]

I really didn't understand what it all meant.
[cpg]


Why would they do something that would add to their sins?　What does Shizuka want?
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_2"  pos="2/2" time=800]
;//[VOICE f="sShizuka017"]
;//[OnName num="shizuka"]
;//「このまま、二人でキスしてちょうだい」
;//[cpg cn=true]

As I was thinking that, Shizuka asked me and Ryoko to kiss.
[cpg]

What she was saying was so crazy that I couldn't catch up with what she was saying.
[cpg]


I thought Shizuka was jealous.　Isn't it outrageous for me and Ryoko to kiss?
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sShizuka017"]
[OnName num="shizuka"]
I'm going to imprint on you guys so you can't even kiss."
[cpg cn=true]



[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sRyoko006"]
[OnName num="ryoko"]
"Well, wait ...... what do you mean me and Shoya are kissing ......?"
[cpg cn=true]



[OnName num="shouya"]
"Ryoko, don't say unnecessary things,...... you'd better follow Shizuka."
[cpg cn=true]


 Ryoko turned to face Shizuka without knowing what was going on.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Ryoko158"]
[OnName num="ryoko"]
The first thing you need to do is to get a good idea of what you're looking for.
[cpg cn=true]


[OnName num="shouya"]
The actuality is that you can't just say anything you don't need to.　I told you not to say anything else.
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_5"  pos="1/2" time=800]
The first thing to do is to make sure that you have a good idea of what you're doing.
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Shizuka332"]
[OnName num="shizuka"]
That's why you have to do it.
[cpg cn=true]


[OnName num="shouya"]
Ryoko, look at me.
[cpg cn=true]


Ryoko is having a hard time understanding me who is too understanding.
[cpg]


I'm sure that's true, because she doesn't know what I've been through.
[cpg]

[FACE method="change_1" pos="2/2"]
[VOICE f="sShizuka018"]
[OnName num="shizuka"]
It must be hard just to be trapped, isn't it?　At times like that, if I had a memory of kissing you, ......"
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="sShizuka019"]
[OnName num="shizuka"]
I shouldn't be able to kiss you again."
[cpg cn=true]



Shizuka looked much calmer. I wonder how she can look like that.
[cpg]


And when Ryoko was getting mature ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************

;//移植のためシーンをカットしています


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="sShizuka020"]
[OnName num="shizuka"]
'Come on, let's keep going. I'll make sure you can't get any closer by any means."
[cpg cn=true]


[OnName num="shouya"]
...... I wouldn't care what you do to me, so don't do anything to Ryoko."
[cpg cn=true]


I said, but rather Shizuka targeted Ryoko.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Ryoko175"]
[OnName num="ryoko"]
She said, "Hiii!　No, no, stay away from me."
[cpg cn=true]


Shizuka also said it was an experiment. I guess she thought I would be more reluctant.
[cpg]


But in fact, I was not. Her anger was directed at Ryoko, not me.
[cpg]


[OnName num="shouya"]
Ryoko is not to blame. ......!　Why did you do that?
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="Shizuka337"]
[OnName num="shizuka"]
Do you think so?　Then will you love only me?"
[cpg cn=true]


[OnName num="shouya"]
I told you before, I only look at Shizuka!
[cpg cn=true]


A bit of a bitter argument, isn't it? Because he was clearly concerned about Ryoko.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************





Then Ryoko was locked in another room, apparently.
[cpg]


At least, she is no longer in my sight.
[cpg]


But if I let her go, it would be obvious that she is holding me captive.
[cpg]


I'm still trapped somewhere. I shudder to think how many rooms can be locked from the outside like this.
[cpg]





;//ＢＫ

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


The brainwashing continues. It was hard for me to make her list all the cute things about her.
[cpg]


I gradually lose track of what I'm saying.
[cpg]


I fall into the illusion that I really like Shizuka.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



When we were in the room together, Shizuka and I said to her, "Well then, you should tell me what a cute girl I am.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka346"]
[OnName num="shizuka"]
Then, will you tell me what's cute about me?
[cpg cn=true]


[OnName num="shouya"]
She said, "Ummm, yes. You have a cute smile, you're single-minded, you're usually ladylike but you're also aggressive. ......
[cpg cn=true]


[OnName num="shouya"]
She has a nice style, nice skin, smart, and she smells good. ......
[cpg cn=true]


That's how I memorized it. It's not that she told me to memorize it.
[cpg]


I couldn't come up with something different every time, so I did this so that I could keep doing it for as long as possible.
[cpg]



;//ＢＫ


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


The same days repeated themselves. I think a month passed.
[cpg]


I wondered why no one came to help her. Could it be that Shizuka's family is very powerful?
[cpg]


I could only think that it was being covered up in some way.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************





[OnName num="shouya"]
She has a cute smile, a single-minded personality, is usually ladylike, and has an aggressive ......
[cpg cn=true]


[OnName num="shouya"]
'She has a nice style, nice skin, smart, and smells good ...... ha, ha.'
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka348"]
[OnName num="shizuka"]
What's wrong?　You're blushing.
[cpg cn=true]


[OnName num="shouya"]
"Geez, geez, ...... keg."
[cpg cn=true]


I've caught a cold, it seems. Or maybe something else entirely.
[cpg]


Still, Shizuka didn't take me to the hospital.
[cpg]


On the contrary, she wanted me.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

The symptoms were getting worse and worse. I got chills and aches all over my body.
[cpg]


[OnName num="shouya"]
'Oh, please ...... take me to the hospital, .......'
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka349"]
[OnName num="shizuka"]
When you really, truly love me from the bottom of your heart, I will take you there."
[cpg cn=true]


[OnName num="shouya"]
'Okay, I love you, I love you, I really consider you my lover, so help me already.'
[cpg cn=true]


I'm saying that, but Shizuka does something that makes it rather worse.
[cpg]

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


That's when I completely lost consciousness.
[cpg]

By the time I woke up next, things had changed rapidly.
[cpg]

That's when I woke up in the hospital, and I thought, "Oh, I've been released.
[cpg]

It is difficult to describe in one word what had happened up to that point and what happened from that point on.
[cpg]

If I had to use one word, it would be "Mitsuki saved me.
[cpg]

She was suspicious that she couldn't get in touch with me, so she found me.
[cpg]

;//[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMituki009"]
[OnName num="mituki"]
He did this to me, and you're just going to keep quiet?
[cpg cn=true]


[OnName num="shouya"]
...... because I was the one who was trying to make him think I was interested in him.
[cpg cn=true]


That's what I thought, it's true. But more than that,......
[cpg]

I was too afraid of retaliation to do anything.
[cpg]




[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





Shizuka has stopped interacting with me since then.
[cpg]


Ryoko became quiet and stopped self-harming. And Mitsuki was always quiet.
[cpg]


Of course, from a normal person's point of view, there are some differences, but compared to Shizuka, everything is a blur.
[cpg]


It all seemed to be a dream made possible by the madness that is Shizuka.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko177"]
[OnName num="ryoko"]
I was so happy to see him.　Have you lost weight?
[cpg cn=true]


[OnName num="shouya"]
I'm fine. It's much better than being locked up like that.
[cpg cn=true]


Ryoko and I met up with him. I wanted to discuss the incident between us.
[cpg]



;//ＢＫ



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』



;//俺は基本的になんともない。様々なトラウマが残っただろうが、静香は刑務所の中だ。
I was basically fine. I was probably left with various traumas, but Shizuka was no longer involved with me.
[cpg]


What about Ryoko?　She, too, must have had her heart broken.
[cpg]


[OnName num="shouya"]
I asked her, "...... Ryoko, are you all right?　You look pale."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko178"]
[OnName num="ryoko"]
'Yeah,...... you know, Shoya.'
[cpg cn=true]


He turns to me and looks serious. I know roughly what he is going to say.
[cpg]


I was going to reply to that as well, so we met up today.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko179"]
[OnName num="ryoko"]
"Won't you go out with me ......?　I don't know if I have a chance anymore."
[cpg cn=true]


I can no longer date Shizuka. There is no doubt about that.
[cpg]


The same is true for Ryoko.
[cpg]


[OnName num="shouya"]
I'm sorry. I want to go out with normal girls."
[cpg cn=true]


[OnName num="shouya"]
Even temporarily, Ryoko has been watching me and self-mutilating, right?"
[cpg cn=true]


Ryoko looks down. She bit her lip.
[cpg]


[OnName num="shouya"]
I can't go out with a girl like that. I'm sorry.
[cpg cn=true]


Everything was probably a reaction to what happened with Shizuka.
[cpg]


I understood that, and I wanted Ryoko to understand it too.
[cpg]



;//ＢＫ


I was also unable to fall in love with my benefactor, Mitsuki.
[cpg]

That's how deep the wound in my heart was.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

Time passed. A lot of time has passed.
[cpg]


I graduated from the school and said goodbye to Ryoko and Mitsuki.
[cpg]


I was still friends with them. I never went out with those girls.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





I went out with a bright girl I met at the school I went to.
[cpg]


She didn't have anything dark behind like Shizuka and Ryoko. She was just an ordinary girl.
[cpg]


She wasn't particularly pretty, but that was fine. That kind of ordinary happiness is what I was looking for.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





Then I got a job, got married, had a ...... daughter, and became a father.
[cpg]


It seemed like a long time, but it passed in a blink of an eye.
[cpg]


At first I couldn't really feel what it was like to work, but recently I understand it a little.
[cpg]


I was finally able to regain a sense of happiness. It was then that he said to me, "It's been a long time, haven't you been outside?
[cpg]


[OnName num="shouya_wife"]
I said to him, "It's been a long time since you went out ....... Are you that busy with work?"
[cpg cn=true]


[OnName num="shouya"]
I've been working a lot. But I think I'm over the hump.
[cpg cn=true]


[OnName num="shouya_daughter"]
I'm having fun. I'm having fun. I'm with my dad!
[cpg cn=true]


Today is family service. We had talked about going to the mall together.
[cpg]


[FADEOUTBGM]


Before getting into the car, I walked out the front door.
[cpg]


[OnName num="shouya"]
"......?"
[cpg cn=true]


Someone walked up to us. I hadn't seen this person for more than 10 years.
[cpg]


But there was a familiar face. This person must be ......
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka365"]
[OnName num="shizuka"]
I've been away for a long time. Shoya, of course you know who I am, don't you?"
[cpg cn=true]


[OnName num="shouya"]
"Oh, ah......"
[cpg cn=true]

[BGM f="bg_op"]

It was Shizuka. I understood that I had been looking for the right moment all along.
[cpg]


I had a flashback of all the traumas and fell into a heap on the spot.
[cpg]


[OnName num="shouya"]
I was so shocked, but I knew that I had to do something.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka366"]
[OnName num="shizuka"]
'I hear, I hear you got married. Who do you like better, your current wife or me?"
[cpg cn=true]


[OnName num="shouya"]
"Of course, Shizuka!　So please don't do something terrible to me.
[cpg cn=true]


I squirmed at Shizuka's feet, almost incontinent.
[cpg]


[OnName num="shouya_daughter"]
"Dad, ......?"
[cpg cn=true]


[OnName num="shouya_wife"]
Hey, hey!　What's wrong with you?
[cpg cn=true]


[OnName num="shouya"]
Shut up!
[cpg cn=true]


The trauma that was etched in my mind was deeper than I could have ever imagined.
[cpg]


The trauma that had been etched in my mind was deeper than I could ever have imagined.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka367"]
[OnName num="shizuka"]
I'm going to marry you. I'm going to marry you, and you'll be happy, won't you?　You'll leave your family, too, won't you?
[cpg cn=true]


[OnName num="shouya"]
Of course!　I would do anything for Shizuka.
[cpg cn=true]


[OnName num="shouya_wife"]
What are you talking about?　Please, come to your senses!
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka368"]
[OnName num="shizuka"]
"Well then, let me ask you something.　What's so cute about me?
[cpg cn=true]


He gulped and spat. Then I started talking at once.
[cpg]


[OnName num="shouya"]
She has a cute smile, a single-minded personality, is usually ladylike, and has an aggressive side.
[cpg cn=true]


[OnName num="shouya"]
She's stylish, fair-skinned, smart, and smells ...... good."
[cpg cn=true]


There was no going back. I kept talking like a broken gramophone.
[cpg]




;//ＢＫ



;//ＥＮＤ：ヒロイン１ルート１（トゥルーエンド）

[system cl_h1r1=true]

[SCENE id=13]

[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

