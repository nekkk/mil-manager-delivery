
*start

;//==============================
;//１、静香
;#################################################
*Ep003|Select Shizuka
;#################################################

[stflag LoLiflg = 0]
[if exp={ isSystemFlagsEnabled( "sysSel01") }]
[stflag LoLiflg = 1]
[endif]
[if exp={ isSystemFlagsEnabled( "sysSel02") }]
[stflag LoLiflg = 1]
[endif]
[if exp={ isSystemFlagsEnabled( "sysSel03") }]
[stflag LoLiflg = 1]
[endif]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="3/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

*select04_1|Choose Shizuka

[SCENE id=3]

[OnName num="shouya"]
I'm going out with Shizuka. I'm sorry Ryoko and Mitsuki, but let's not have this quadrilateral relationship anymore."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Shizuka156"]
[OnName num="shizuka"]
What? ......"
[cpg cn=true]


Shizuka's face blushes. She probably didn't fully believe that she was loved somewhere.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="1/3" time=800]
[VOICE f="Ryoko155"]
[OnName num="ryoko"]
"Oh, no!　You almost stabbed a man, what's so good about a man like that?
[cpg cn=true]


[OnName num="shouya"]
That's Ryoko's sashine, isn't it?"
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
Ryoko became silent. And Mitsuki looked as if he didn't know what was going on.
[cpg]


It's cruel even for Mitsuki. But I love Shizuka.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
I still remember my first crush. I still believe that she is not a bad girl.
[cpg]


Otherwise, I wouldn't have chosen her.
[cpg]


And I'm sure Shizuka is the one who can reciprocate my love the most.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="3/3" time=800]
[VOICE f="Mituki114"]
[OnName num="mituki"]
What do you mean ......?　Does it mean you're going to cheat on me?
[cpg cn=true]


[OnName num="shouya"]
No, I'm not. I'm not dating Mitsuki in the first place.
[cpg cn=true]


I refuse to go out with him once and for all. I think this is fine.
[cpg]


[OnName num="shouya"]
I'll say it one more time, I'm going out with Shizuka. I'm sorry for being so ambiguous with both of you."
[cpg cn=true]


Ryoko was aghast. And Mitsuki seemed as if he still didn't understand what was happening.
[cpg]


And Shizuka was blushing all the way to .......
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』





On the way home that day, Ryoko was too depressed to go home with me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka157"]
[OnName num="shizuka"]
She said, "It seems ...... to be a lie. Why me?
[cpg cn=true]


[OnName num="shouya"]
Were you unsure?"
[cpg cn=true]


Shizuka answered, "I wasn't. I guess I was.
[cpg]


I might have had the most abnormal behavior. No, in terms of abnormality, Mitsuki was more so. ......
[cpg]


But it was Shizuka who was dangerous. She was always trying to hurt people.
[cpg]


Maybe she was aware of it herself. But.
[cpg]


[OnName num="shouya"]
I'm not saying that I gave in to threats or anything like that. I just found Shizuka attractive.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Shizuka158"]
[OnName num="shizuka"]
I'm embarrassed, so don't say it.
[cpg cn=true]


Even my ears turn red. I thought it was cute.
[cpg]


I think that's what makes her turn to violence and such.
[cpg]


[OnName num="shouya"]
......What's wrong?"
[cpg cn=true]


Shizuka stopped. Then she said.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka159"]
[OnName num="shizuka"]
"Wow, would you like to come to my house ......?"
[cpg cn=true]


I had no reason to refuse. Even if there was, I don't know anymore.
[cpg]


I don't care how Ryoko interferes or what Mitsuki thinks.
[cpg]


I will accept it. I'll be hers for now.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se011"]
;//【ＳＥ】『ドア開く』






[VOICE f="Shizuka160"]
[OnName num="shizuka"]
"Hey, I'm back at .......
[cpg cn=true]


[OnName num="shouya"]
"......, sorry to disturb you."
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************





The two of them looked at each other.
[cpg]



[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sShizuka007"]
[OnName num="shizuka"]
;//「あのね、翔也……私、私の、キスもしたことないの……」
I've never even been kissed before,.......
[cpg cn=true]


The first thing to do is to make sure that you have a good time.
[cpg]


[OnName num="shouya"]
The first thing you need to do is to get a good idea of what you're looking for. I'm the same way, and there are a lot of things I don't understand.
[cpg cn=true]


I don't know what value such things have in the eyes of a girl.
[cpg]


But in Shizuka's mind, it seemed to be meaningful. It seems to stimulate her desire for exclusivity.
[cpg]



;//========================================
;//●ＣＧ（ベッドに倒れ込んでいるヒロイン。主人公とキスをする）ev_16
;//人物１：ヒロイン１
;//服装１：着衣
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sShizuka008"]
[OnName num="shizuka"]
Kiss me, ......."
[cpg cn=true]


When she said that to me, she really just looked like a pretty girl.
[cpg]

I thought I could love her now. ......
[cpg]


;**【ＣＧ】 ev_16_a ***********************
[CG id=9 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="sShizuka009"]
[OnName num="shizuka"]
I said, "Nn......."
[cpg cn=true]



;//移植のためシーンをカットしています

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka179"]
[OnName num="shizuka"]
I'll see you at the school. I'll see you at school.
[cpg cn=true]


[OnName num="shouya"]
I'll see you at the school. See you soon.
[cpg cn=true]


It was already late. I decided to go home.
[cpg]


I didn't need to explain to my parents where I had been.
[cpg]


Shizuka and I had already started dating. I don't feel guilty about anything anymore.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





The next day, Shizuka came to pick me up as usual. Shizuka came to pick me up as usual, but Ryoko was not there.
[cpg]


[OnName num="shouya"]
She said, "I don't see Ryoko at ......."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka180"]
[OnName num="shizuka"]
She was already gone.　She's going to be late for school.
[cpg cn=true]


Either she got there before me, or she's still at home.
[cpg]


Either way, it was a blatant reaction. She probably thought I had dumped her.
[cpg]


I guess she thought I dumped her, or maybe she actually did. It was my fault for taking an either-or attitude.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





Thus, a while after Shizuka and I started our life as lovers, we were together in lovey-dovey lovey-dovey.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
Shizuka is coming close to me with lovey-dovey lovey-dovey.
[cpg]


Ryoko is looking at me with cold eyes. At times, she didn't even want to look at me.
[cpg]


Mitsuki, on the other hand, seems to be too shocked to come to the school.
[cpg]


I felt bad for her too, but I continued to be Shizuka's lover.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka181"]
[OnName num="shizuka"]
Isn't she great?　I'm really good at cooking, aren't I?
[cpg cn=true]


[OnName num="shouya"]
Umm, yes. ......
[cpg cn=true]


As usual, the amount of food in the bento box is amazing. The amount is not only great, but it also takes a lot of time and effort.
[cpg]


It makes me wonder when in the world they are making it. They must have gotten up very early.
[cpg]


They won't let me go until they've eaten all of it. But this is cute.
[cpg]


As long as he doesn't bring out a knife or something, I don't have any problem.
[cpg]


What worries me more is Ryoko. She's been my childhood friend for a long time, and I'm sure she had feelings for me, but I'm sure she dumped me.
[cpg]


I was afraid to flirt with her in a class where she was also there.
[cpg]


But I had a feeling that Ryoko would follow me even if I went to Shizuka's class.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka182"]
[OnName num="shizuka"]
I'm happy ...... probably happier than anyone else in the world.
[cpg cn=true]


[OnName num="shouya"]
Sure, you look happy."
[cpg cn=true]


I'm tempted to give her a sweet line here, but I can't say it when I think Ryoko might be listening too.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Shizuka183"]
[OnName num="shizuka"]
I'm sure you will come to my house again today, right?　No, you're coming over.
[cpg cn=true]


[OnName num="shouya"]
No, I want you to come. Shall we go?
[cpg cn=true]


It was unnatural for him not to answer her right then and there. Ryoko might follow me, but I had no choice but to answer her.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』





Sure enough, Ryoko followed us.
[cpg]


I didn't even let her in the house.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka184"]
[OnName num="shizuka"]
She said, "Hey, why are you looking back? Why are you turning around?
[cpg cn=true]


[OnName num="shouya"]
No, no, I'm just curious about .......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka185"]
[OnName num="shizuka"]
I don't need you to look at anything else.　I just want you to look at me."
[cpg cn=true]


That's a bit extreme, isn't it? I don't think we would get along socially if we only looked at each other.
[cpg]


I tried to explain this to Shizuka, but she wouldn't listen to me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka186"]
[OnName num="shizuka"]
'Society is not what we need. All I need is Shoya.
[cpg cn=true]


[OnName num="shouya"]
Shizuka said, "It doesn't work that way, we live in a society. ......
[cpg cn=true]


Shizuka would not be convinced by anything I said. Well, we'll have to explain that to you in due course. ......
[cpg]




;//ＢＫ

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[SE f="se011"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************





And then, for the umpteenth time, we went to Shizuka's house. She said something like this.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sShizuka010"]
[OnName num="shizuka"]
'Let's have dinner together tonight.
[cpg cn=true]



[OnName num="shouya"]
'...... but I haven't explained it to my family.'
[cpg cn=true]


Shizuka says I can explain later.
[cpg]


Although I thought it was absurd, I couldn't say no.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




Then, Shizuka, Shizuka's parents, and the four of us ate together.
[cpg]


There was a great deal of awkwardness, ...... but I realized that I was wrong to feel awkward.
[cpg]


[OnName num="shizuka_mother"]
Shizuka is not my boyfriend. Why don't you stay over tonight?"
[cpg cn=true]


Shizuka's mother was in such a mood. I thought her father would be less so. ......
[cpg]



[VOICE f="Shizuka189"]
[OnName num="shizuka"]
Shizuka's mom was not so sure.　Dad, I want him to stay the night."
[cpg cn=true]


[OnName num="shizuka_father"]
'Well, if Shizuka says so, that would be fine too.
[cpg cn=true]


At first glance, he seems like a strict man. The first thing that comes to mind is the fact that the two of them are very close to each other.
[cpg]


It seemed as if both of them thought that what Shizuka said was absolute.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************





That's why I even took a bath. There was no escape now.
[cpg]


I thought that I would never sleep in the same room with Shizuka .......
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sShizuka011"]
[OnName num="shizuka"]
She said, "Hey, you wouldn't ...... let me sleep alone, would you?"
[cpg cn=true]


I couldn't say no.
[cpg]



;//ＢＫ



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************





The next day at noon. I was still not released.
[cpg]


Her parents also told me that I should stay here a little longer.
[cpg]


It was an unusual family. It's as if everything is moving according to Shizuka's will.
[cpg]


[OnName num="shouya"]
......Then, I think it's time for me to go home.
[cpg cn=true]


I've said this many times. But Shizuka pretends not to hear.
[cpg]

[OnName num="shouya"]
"Hey, Shizuka. Are you listening to me?　I want some me time too.
[cpg cn=true]


[OnName num="shouya"]
No matter how much I love you, staying with Shizuka all the time is ......
[cpg cn=true]


When I said that much, she came closer to me with no expression on her face.
[cpg]

;//========================================
;//●ＣＧ（主人公にのしかかるヒロイン。怒っている感じ）ev_17
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：昼
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]


And then she leans on me. I was surprised because I didn't think I said something that would offend her so much.
[cpg]

[VOICE f="sShizuka012"]
[OnName num="shizuka"]
Why?　If you love her, you can be with her all the time, can't you?"
[cpg cn=true]


Her voice is still calm. But I could see that he was on the verge of exploding, so I adjusted the conversation accordingly.
[cpg]

[OnName num="shouya"]
I said, "Well, yes, but I have some business to take care of. But I've got some business to attend to.
[cpg cn=true]


It was a bitter excuse (......), but I had no choice but to say it like this.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





There was a bit of an argument when we finally left the house, but Shizuka gave up in the end.
[cpg]


And, as expected, Ryoko wasn't nearby either.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka207"]
[OnName num="shizuka"]
She said, "I'll see you at ...... then. I'll see you at the school, right?
[cpg cn=true]


[OnName num="shouya"]
'Of course I will. I'll see you at school, right?
[cpg cn=true]


The only thing is that they might suspect me of being unfaithful.
[cpg]


I don't think it's any wonder they suspect that. I've done that kind of thing.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




And when I came home, my parents were more concerned than cool with me.
[cpg]


Worried like, "Is your girlfriend okay?
[cpg]


That's right, they didn't let me go for almost the whole day.
[cpg]


And I couldn't irresponsibly tell them that my girlfriend was fine.
[cpg]





[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************





Furthermore, now I wonder if I myself am okay or not.
[cpg]


Would I really be able to continue being Shizuka's lover?
[cpg]


I think I'm already crazy for thinking such a thing at such a early stage of our relationship.
[cpg]


But I can't help but think about it. Shizuka is not normal.
[cpg]


I wonder if I can be the kind of lover she is looking for.　I don't know if I can be.
[cpg]


I'm tired of thinking about it, so I've decided to just relax from this afternoon.
[cpg]


I'm exhausted in terms of energy. It's hard to even think about girls anymore.
[cpg]


I know I brought this on myself, so it's all inevitable. ......
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





Then, around evening. I received dozens of e-mails from Shizuka.
[cpg]


She really thinks about me all the way, doesn't she? Thinking so, I looked at the contents.
[cpg]


Most of them were about what we would do tomorrow. Tomorrow is Sunday, right?
[cpg]


I thought a normal date would be fine, so I suggested it.
[cpg]


I think it's only natural for him to use both Saturday and Sunday for her, since they just started dating.
[cpg]


She was on board. She immediately responded.
[cpg]


She sends me several joyful emails, but every time I think that one email is enough: .......
[cpg]


I guess it's like a diary in her mind.
[cpg]


A diary just to show me. It must be like she is keeping a diary just to show me.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




I went to bed that day with that thought in my mind.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



[SE f="se002"]
;//【ＳＥ】『雑踏』




[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
The next day. The next day, the two of us walked aimlessly through the city on Sunday.
[cpg]


We window-shopped, and did some normal shopping.
[cpg]


I didn't like game arcades as much as Mitsuki did.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka208"]
[OnName num="shizuka"]
"Hey, didn't you just make eye contact with another girl?
[cpg cn=true]


[OnName num="shouya"]
We didn't make eye contact.
[cpg cn=true]


However, Shizuka frequently said this kind of thing to me.
[cpg]


There are places where you're not even allowed to make eye contact, but of course you do.
[cpg]


[OnName num="shouya"]
I'm afraid that some other girl will take you away from me.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka209"]
[OnName num="shizuka"]
"It's not that I'm afraid, it's more that I want ...... to keep her to myself. Is that wrong?
[cpg cn=true]


I think it's cute when you put it that way.
[cpg]


The first thing you need to do is to make sure that you have a good idea of what you want to do. Okay, let's do it this way then.
[cpg]


[OnName num="shouya"]
Let's have a date at home again today. Then I'll never look at anyone.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka210"]
[OnName num="shizuka"]
"......Yeah. I guess so.
[cpg cn=true]


I am aware that Ryoko had been following me all this time. But I didn't have the heart to react.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************





Shizuka is a pretty girl. The first thing to do is to make sure that you have a good time with your family.
[cpg]


However, her love for me is unusually heavy. Today, too, I realized this.
[cpg]


[OnName num="shouya"]
"...... Are you not going to go home today?"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka211"]
[OnName num="shizuka"]
Yes. Tomorrow is Monday, but if you hurry, you can pick up your clothes and other things by morning.
[cpg cn=true]


I'm going to stay here today, and by the time it's time to go to school, I'll be back at my place, and then I'll head back to the school.
[cpg]


That is what Shizuka is suggesting. The idea is quite out of the ordinary.
[cpg]


[OnName num="shouya"]
"I'll get tired of ...... being with you.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka212"]
[OnName num="shizuka"]
"Are you tired of being with me ......?"
[cpg cn=true]


[OnName num="shouya"]
I didn't mean it like that. I'm sorry, I'm sorry.
[cpg cn=true]


I think it was a bad idea not to say here that I was tired of being with Shizuka.
[cpg]


The first thing to do is to make sure that you have a good time with your friends and family.
[cpg]

;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

That was how the day ended.
[cpg]


I was exhausted and really fell asleep at her house.
[cpg]


I was very late as I went to pick up my uniform in the morning and came back again.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





I was continuing my girlfriend relationship with Shizuka like that, one day.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka229"]
[OnName num="shizuka"]
She said, "Are you interested in ...... Mizuhara-san?"
[cpg cn=true]


[OnName num="shouya"]
Eh ......?"
[cpg cn=true]


Ryoko had been absent for two days in a row, and I was looking at her seat. That's really all there is to it.
[cpg]


I was getting jealous even though we didn't even make eye contact. I was a little horrified.
[cpg]


[OnName num="shouya"]
"Hey, it's ...... nothing like that."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka230"]
[OnName num="shizuka"]
Yes. But still, has Shoya lost some weight?"
[cpg cn=true]


The actuality is, since I started dating Shizuka, I've been losing weight.
[cpg]


Maybe I'm unknowingly stressing myself out.
[cpg]


But they say stress makes you gain weight. ......
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





And he always walks to my house on his way home.
[cpg]


I don't know how she can do such a leisurely thing, but for her it's a moment of bliss.
[cpg]


I try to look straight ahead or at Shizuka as much as possible as I walk.
[cpg]

[FADEOUTBGM]
On the way home, I received a text message from my mother at .......
[cpg]


[OnName num="shouya"]
What ......?"
[cpg cn=true]


The reason why Ryoko had been absent for so long was written there.
[cpg]

[BGM f="bg_ky"]

She had slit her wrists and attempted suicide. She was in a coma until yesterday.
[cpg]


They say he's regaining consciousness now, but he did a ...... terrible thing.
[cpg]


My hands start to shake. Shizuka, sensing my abnormality, peeks at the screen of my phone.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka231"]
[OnName num="shizuka"]
She says, "......What's wrong, Shoya? Why are you shaking?"
[cpg cn=true]


I was scared of Shizuka saying that. Don't you know why you are trembling?
[cpg]


[OnName num="shouya"]
She said, "Because Ryoko tried to kill herself."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka232"]
[OnName num="shizuka"]
'What do you care about lives other than ours?'
[cpg cn=true]


It was a word that came out so easily. It was the kind of thing that would not have come out if he did not really mean it.
[cpg]


It was crazy. Even though Shizuka hated Ryoko, she didn't need to care about her now.
[cpg]


She was his girlfriend and he was her friend. There was no need to worry about being taken, and it was crazy to think that they could die.
[cpg]


Does that mean that they really don't care what happens to anyone but themselves?
[cpg]


I stood there for a while. And after thinking and thinking: ......
[cpg]



;//==============================
;//恋愛ポイントが３かつ他のルートをすべて通っている場合

[if exp={getFlagValue("LoLiflg") == 3}]
[if exp={ isSystemFlagsEnabled( "cl_h1r2", "cl_h2r1", "cl_h2r2", "cl_h3r1", "cl_h3r2", "cl_h4r4") }]
;//TRUEルートに入る
[jump target="*root_true"]
[endif]
[endif]


[jump target="*root_1_2"]



;//TRUEルートに入る

*root_true|I choose Shizuka.
[jump storage="ep004.ks" target="*root_true"]


*root_1_2|I choose Shizuka.
[jump storage="ep005.ks" target="*root_1_2"]

