


;//==============================

*start

;//恋愛ポイントが１以下の場合

;#################################################
*Ep008|Let's break up with Ryoko
;#################################################

*root_2_2|Let's break up with Ryoko.


[SCENE id=8]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』





I made up my mind. On the way to the school with Ryoko, I start to say goodbye.
[cpg]


[OnName num="shouya"]
"Hey, Ryoko. I want to talk to you.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko327"]
[OnName num="ryoko"]
"...... what?"
[cpg cn=true]


Ryoko was shaking a little. After all that had happened.
[cpg]


She probably thought she was going to be asked to break up with me. And she was right.
[cpg]


[OnName num="shouya"]
I told him I didn't think we should be together. I'm the one who confessed to you.
[cpg cn=true]


[OnName num="shouya"]
I think Ryoko is more suitable for someone else.
[cpg cn=true]


Ryoko stopped shaking. Then she says, "I thought you would say that to me someday.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ryoko328"]
[OnName num="ryoko"]
I knew you would say so someday. That's why I did this."
[cpg cn=true]


Ryoko then holds her phone up in front of my eyes.
[cpg]


There was a picture of me flirting with Shizuka on .......
[cpg]

Depending on how you look at it, the images look like they are doing something unhealthy at the school.
[cpg]


[OnName num="shouya"]
"Ko, where did you get this ...... stuff?"
[cpg cn=true]


According to Ryoko, she pulled it out of her phone.
[cpg]


I wonder when they did that, I don't have any idea but ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko329"]
[OnName num="ryoko"]
If you insist on breaking up with me, I will post your picture and address on the Internet. ......
[cpg cn=true]


This is bad. What's worse is that from this point on, it's not a proper relationship.
[cpg]


I'm going to have to start dating under threat.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ryoko330"]
[OnName num="ryoko"]
I'm going to be threatened and have to go out with him. Tell me you like me. Even if it's a lie.
[cpg cn=true]


I swallowed hard and spat. And then I said.
[cpg]


[OnName num="shouya"]
I like you ......."
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




From that point on, I started to feel visibly ill.
[cpg]


I think it is because I am forcing myself to go out with Ryoko. I gradually lost my appetite.
[cpg]


Ryoko told me that it was a medicine for appetite and shared it with me.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





One evening. I was visiting her house.
[cpg]



[OnName num="shouya"]
She said, "Huh, huh, is that medicine ...... really an appetite medicine?"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko331"]
[OnName num="ryoko"]
'Whatever, right?　If I tell you to take it, you'll take it."
[cpg cn=true]


Saying that, he handed me a new medicine.
[cpg]


Maybe an aphrodisiac or something. If I take this, I won't be able to stay sane.
[cpg]


I wondered why Ryoko would ask me to do this.
[cpg]


...... I somehow know. I think she gets her mental stability from being asked to do this.
[cpg]


I don't know how she feels. That may be how girls are.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I stayed by Ryoko's side for a long time. She was never satisfied.
[cpg]


Then, she gave me an aphrodisiac to take every day.
[cpg]


I am not confident that I can act like I just pretended to take it without taking it.
[cpg]


So I ...... ritually took it every day.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





The effect of the aphrodisiac was tremendous. I was already unsteady on my feet and my heart pounded in my chest no matter who I looked at.
[cpg]


There is something wrong with my sight and hearing too. I couldn't distinguish between various things.
[cpg]


Then one evening, I met Ryoko.
[cpg]


I met Ryoko there. I was sure that this figure was Ryoko.
[cpg]



;//========================================
;//●ＣＧ（モブ女性がヒロイン２に見えている。後ろから声をかける）ev_34
;//人物１：モブ女性（ヒロイン２の外見・声）
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：電車内
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sRyoko011"]
[OnName num="ryoko"]
"......?"
[cpg cn=true]


My heart was pounding. I see, Ryoko came to see me, too.
[cpg]

She came to pick me up after being driven crazy by the aphrodisiac.
[cpg]

I can't let this happen. I want to be alone with her as soon as possible.
[cpg]

So I pulled her hand and forced her to get off the train.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



We left the station and headed for a secluded place.
[cpg]


Ryoko didn't like it, but she didn't try to shake my hand with all her might.
[cpg]



;//========================================
;//●ＣＧエロ（モブ女性がヒロイン２に見えている。バックの姿勢で処女喪失、無茶苦茶に痛がる）ev_35
;//人物１：モブ女性（ヒロイン２の外見・声）
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：駅男子トイレ
;//時間　：夕方
;//========================================

[BGM f="bg_h2"]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sRyoko012"]
[OnName num="unknown"]
'I don't want to ...... let you go, in a place like this, what are you going to do?
[cpg cn=true]


[OnName num="shouya"]
Don't tell me what to do now."
[cpg cn=true]


We're lovers. It would not look suspicious from the side.
[cpg]


[OnName num="shouya"]
What's going on, Ryoko?　I thought you were drugged because you wanted me to come on to you."
[cpg cn=true]


She acted as if she didn't understand what I was saying.
[cpg]

I was looking at Ryoko, and I noticed something.
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************
;//ここから「涼子」の名前欄を元に戻してください
;//場所は街中ではないので上下に黒帯を入れるなどしてください



The person who looked like Ryoko, who looked like Ryoko, started to look like a completely different person.
[cpg]


Drugs are scary. My head is not as trustworthy as I thought.
[cpg]


Just because I was on drugs or in a delirium doesn't mean I can be forgiven.
[cpg]


I suddenly regained my reason and got scared and ran away from the place.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


When I told this story to Ryoko, she laughed.
[cpg]


;//[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sRyoko013"]
[OnName num="ryoko"]
'Now you won't have to look at any other woman but me.
[cpg cn=true]


...... She is crazy, but she drove me crazy too.
[cpg]

I almost committed a crime.
[cpg]

But if I did, ...... she would be glad she had me all to herself.
[cpg]



;//ＥＮＤ：ヒロイン２ルート２

[system cl_h2r2=true]

[SCENE id=16]

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

