
*start


;//==============================
;//４、全員と縁を切る


;#################################################
*Ep012|Cutting ties with all of them
;#################################################


*select04_4|I'm cutting myself off from all of them.

[SCENE id=12]


[OnName num="shouya"]
I can't go out with any of them. All three of you are crazy."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="3/3" time=800]

[VOICE f="Shizuka430"]
[OnName num="shizuka"]
Oh, no. ......!
[cpg cn=true]


[OnName num="shouya"]
I've done terrible things to you. I'm really sorry."
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
Ryoko tells me not to apologize. But I apologize.
[cpg]


These three are too heavy for me. Even if I went out with one of them, it would be heavy.
[cpg]


And if I went out with one of them, the other two would hate me.
[cpg]


If that's the case, I thought it would be better to break up with everyone here.
[cpg]


Even if I can't fall in love at all in the future, even if I don't have another chance ......
[cpg]


This is not the kind of love I'm looking for.
[cpg]


[OnName num="shouya"]
That's why. I want you to leave me alone now. ......I'm sorry, I'm being selfish."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="3/3" time=800]
[VOICE f="Mituki310"]
[OnName num="mituki"]
"U, u, no lie,...... Shoya-san, tell me it's not true."
[cpg cn=true]


The first thing to do is to make sure that you have a good time.
[cpg]


And Ryoko is about to start crying. Three different people, but they have hurt everyone.
[cpg]


But this is the last time. This is the end.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』





Neither Shizuka nor Ryoko followed me on the way home.
[cpg]


It was as if something had fallen from my mind. I feel fine.
[cpg]


I know I shouldn't feel like this after messing with people's hearts of love. ......
[cpg]


But I was able to escape the love that was too heavy for me until now.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se011"]
;//【ＳＥ】『ドア閉まる』




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="shouya"]
I feel like "...... wind."
[cpg cn=true]


I got out of the bath and looked at my cell phone.
[cpg]


There were no more texts from Shizuka.
[cpg]


I was relieved because I had predicted that there might be more than before.
[cpg]


I'm going to be pretty much out of touch with girls from now on.
[cpg]


I've broken up with three of them at once. But I can't even say I was in a relationship.
[cpg]


This is the natural way of things. I haven't done anything wrong.
[cpg]


In fact, I have done nothing wrong up until now. Thinking this, I fell into a quiet sleep.
[cpg]


I think I'll sleep well today. ......
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002"]
;//【ＳＥ】『雑踏』





And the next morning. Neither Ryoko nor Shizuka are there.
[cpg]


I am just relieved. It's a terrible thing to be relieved that they are not here.
[cpg]


I can walk at my own pace.
[cpg]


What I took for granted just a little while ago has been restored.
[cpg]


I didn't think it would be such a liberating feeling.
[cpg]


On the contrary, I had been so constrained.
[cpg]


[OnName num="female_student_A"]
Hey, Ichijo-kun. ......
[cpg cn=true]


[OnName num="female_student_B"]
I'm not with you two today."
[cpg cn=true]


A completely different girl is talking to me. See, these things happen.
[cpg]


I've always had girls in tow, so I've never even had them talk to me like this before.
[cpg]


[OnName num="shouya"]
I've always had girls in tow, so I've never even heard them say this to me. It's a little bit complicated.
[cpg cn=true]


[OnName num="female_student_A"]
"Things, well, I'm sure you've been through a lot. ......
[cpg cn=true]


[OnName num="female_student_B"]
With those girls, it must have been hard, right?
[cpg cn=true]


[OnName num="shouya"]
I wouldn't go so far as to say it was hard,......, but I think it's easier now.
[cpg cn=true]


I naturally smile. I'm a terrible person.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************





At the school, Shizuka, Ryoko, and Mitsuki were acting as if they were in some kind of collusion.
[cpg]


It's lunchtime and not a single person is approaching me.
[cpg]


It's nice to feel at ease, but this worries me. ......
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




The days went on and on. One day, the situation suddenly changed.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』





[OnName num="shouya"]
"Oh, Ryoko ......
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ryoko380"]
[OnName num="ryoko"]
Shall we go home together? Shoya."
[cpg cn=true]


I was so happy to see her.
[cpg]


 The expression also has a face that looks like it's blown away.
[cpg]


[OnName num="shouya"]
Let's go home.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko381"]
[OnName num="ryoko"]
Then, I want to stop by somewhere, will you come with me?
[cpg cn=true]


[OnName num="shouya"]
What?　Umm, yes. ......"
[cpg cn=true]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




It was a mistake to answer so.
[cpg]


I was right about the blown-out look on his face, but I was going in the wrong direction.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************





When I woke up, I realized that I was in ...... um, yes. Shizuka's room, right?
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]

In front of me is a smiling Shizuka. What's going on?
[cpg]


I was with Ryoko ...... and she sniffed me some kind of drug on the way home.
[cpg]


That's when I blacked out. Was the place Ryoko wanted to go to Shizuka's house?
[cpg]


If so, why ......
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka431"]
[OnName num="shizuka"]
I thought to myself, "You seem to be awake. We were discussing whose house to lock you up at."
[cpg cn=true]


The words are coming out of my mouth. But the situation I'm in right now is anything but confinement.
[cpg]


[OnName num="shouya"]
"Ho, are the other two guys there too, ......?"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka432"]
[OnName num="shizuka"]
Of course. My parents are there, too, so I can't escape.
[cpg cn=true]


[OnName num="shouya"]
Parents too, you mean ......?
[cpg cn=true]


You mean the whole family is locked up?　What kind of family is Shizuka's family? ......
[cpg]


[OnName num="shouya"]
"You won't take this off and ...... me, will you?"
[cpg cn=true]


Shizuka nods. Then he comes closer.
[cpg]

;//移植のためシーンをカットしています
;//追加2022/09/14

;//========================================
;//●ＣＧ（主人公手を後ろに、足は曲げて座ったまま動かせない感じで拘束されている。そのままヒロインは主人公に近づく）ev_46
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：夜
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_46_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Shizuka433"]
[OnName num="shizuka"]
'How could you say that you were abandoning all of us? I think it was the bravest choice you could have made."
[cpg cn=true]


He came close to me as he said that. He was so close that I could almost breathe on him.
[cpg]


[OnName num="shouya"]
What are you going to do ......?　No, don't do this, just let me go home."
[cpg cn=true]


I'm talking like a girl in captivity.
[cpg]


I sound like a girl being held captive, and in fact, I am close to it.
[cpg]


I can't resist anything they do to me here. I can't even move.
[cpg]


;//移植のためシーンをカットしています



[OnName num="shouya"]
I'm sorry, Shizuka.
[cpg cn=true]


What am I apologizing for? I don't know what I'm apologizing for.
[cpg]


;**【ＣＧ】 ev_46_a ***********************
[CG id=19 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Shizuka446"]
[OnName num="shizuka"]
I'll make you apologize as many times as I have to. I'll make you apologize as many times as you want from now on."
[cpg cn=true]


Shizuka is saying that. I'm afraid that if she says so, I can't help but think that she's probably right.
[cpg]


Besides, she said that Ryoko and Mitsuki are also here.
[cpg]


I guess I have to satisfy them too.
[cpg]


Just imagining it makes me shudder. I was in a bad situation no matter how I thought about it.
[cpg]



[VOICE f="Shizuka447"]
[OnName num="shizuka"]
I'm done for now. I'll go get them.
[cpg cn=true]


[OnName num="shouya"]
Wait, wait, ......, take this off.
[cpg cn=true]


I said something once more that I knew would never be heard.
[cpg]



[VOICE f="Shizuka448"]
[OnName num="shizuka"]
"You idiot. I'm not going to take it off.　The actuality that you can't take it off is that Shoya is our slave from now on.
[cpg cn=true]


Slave. I felt that it was true somehow when I heard those words.
[cpg]


As a result of my shunning all of them, I couldn't escape from all of them.
[cpg]



[VOICE f="Shizuka449"]
[OnName num="shizuka"]
Please take responsibility for what you have done."
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



They came into the room, replacing Shizuka.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Ryoko382"]
[OnName num="ryoko"]
'Good morning. No, I guess it's good evening. ......
[cpg cn=true]


Ryoko said such a crazy thing.
[cpg]


Ryoko seemed to have no hesitation in this situation, but Mitsuki was timid.
[cpg]


It is usual for her to be frightened, but she is behaving more suspiciously than usual.
[cpg]


[OnName num="shouya"]
Mitsuki, do you really think you can do this?　Please help me."
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Mituki311"]
[OnName num="mituki"]
I can't do that. ...... I don't want to let go of Shoya-san.
[cpg cn=true]


No. I don't feel like I need another push.
[cpg]


 Even Mitsuki, who seems to be the best in terms of common sense, can't really get me out in this situation...
[cpg]


[OnName num="shouya"]
Oh, you know,......, I need to go to the bathroom.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ryoko383"]
[OnName num="ryoko"]
"...... really?　You're not thinking of running away, are you?"
[cpg cn=true]


[OnName num="shouya"]
"Really!　Please, let me out of here."
[cpg cn=true]


Ryoko thought for a moment, then nodded.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Ryoko384"]
[OnName num="ryoko"]
Go get Tojo-san. I don't know where the bathroom is either."
[cpg cn=true]


Mitsuki nodded as he was told. And he was going to call Shizuka.
[cpg]


Really, if there were this many people, they would never get out of there. ......
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




The three of us followed closely on the way to the restroom.
[cpg]


One man and three women. It's delicate to think if violence can solve the problem.
[cpg]


Per Shizuka, they might have some weapons. I'm too scared to run away: ......
[cpg]


No, help must come before things really get out of control.
[cpg]


One person is missing, someone will come looking for them.
[cpg]


I was extremely nervous and tired, apparently.
[cpg]

Sleep came eventually. And by the time I next woke up, ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************





The clock struck noon.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="3/3" time=800]

But all three of them were there. It was as if they were waiting for me to wake up.
[cpg]


[OnName num="shouya"]
"Hmm. ......."
[cpg cn=true]


It seems that the three of them were talking, and they all looked at me in response to my voice.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka450"]
[OnName num="shizuka"]
"Are you awake?　How are you feeling?"
[cpg cn=true]


I'm not in a good mood.
[cpg]


[OnName num="shouya"]
I say, "I'm hungry.
[cpg cn=true]


I just say what I'm thinking.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Ryoko386"]
[OnName num="ryoko"]
I said what I was thinking. What should I do?
[cpg cn=true]

[FO pos="2/3" time=1000]
Shizuka got up and left the room.
[cpg]


I waited for her to bring me something.
[cpg]


Meanwhile, Shizuka and Mitsuki were talking happily. It was an odd sight.
[cpg]


The three of us now had a common goal, and we were strangely in collusion with each other.
[cpg]

I waited for Shizuka to return with a chill down my spine.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka451"]
[OnName num="shizuka"]
I wait for Shizuka to return, feeling a chill down my spine. I think it will fill you up.
[cpg cn=true]


What Shizuka brought me was some kind of jelly drink ......
[cpg]


It was the kind of thing that dieters would drink.
[cpg]


I don't think this will help me regain my strength. But he made me open my mouth.
[cpg]


I drank it down. I feel so miserable.
[cpg]


I can't even eat alone. It's not even a decent meal.
[cpg]


I'm being kept by the girls. I have to get out of this place right now.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************





I can't actually do anything about it, even though I think so.
[cpg]


[OnName num="shouya"]
"Are the three of you sure you want to go to school ......?"
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="3/3" time=800]
I asked in a tired voice. Each of them looked at each other.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Mituki312"]
[OnName num="mituki"]
I've done all this,......, and there's no school or anything.
[cpg cn=true]


It's true.
[cpg]

It's a ridiculous story.
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************





More time passed from there.
[cpg]

For them, even this seems to mean that they have me.
[cpg]

My heart is rather rejecting them.
[cpg]



[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sShizuka022"]
[OnName num="shizuka"]
"You have something to say?"
[cpg cn=true]


[OnName num="shouya"]
"......"
[cpg cn=true]


You ask me that even though you won't listen to anything I have to say.
[cpg]


[OnName num="shouya"]
I'm going to get you out of here and ...... look at the same scenery all day long, I'm going to go crazy."
[cpg cn=true]


I'm going crazy looking at the same scenery all day long. What's so funny?
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka453"]
[OnName num="shizuka"]
'I'm fine though, okay?　As long as Shoya is there, I'm fine with staying in the same room all the time.
[cpg cn=true]


I'm going to ...... say something crazy like that. I've had enough of this.
[cpg]


;//ＢＫ

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************





The three of us taking turns keeping watch. Now that I was awake, Mitsuki was watching me.
[cpg]


...... This means that at least the people keeping an eye on me are spread out.
[cpg]


If I pretend to go to the bathroom and slip out by force,......
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mituki320"]
[OnName num="mituki"]
...... and Tojo-san's mother and father are also cooperating, so you shouldn't think about anything else."
[cpg cn=true]


Mitsuki tells me that ahead of time.
[cpg]


What is really going on in Shizuka's house? I can't believe they allow this kind of behavior.
[cpg]


It would be as much of a crime as confinement. Even when weighing it against that, is fulfilling his daughter's wishes the priority?
[cpg]


It's a thought I don't understand. But I'm actually locked up, so I can't help it. ......
[cpg]


[FG f="CHA03_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mituki321"]
[OnName num="mituki"]
I'm hungry, aren't you? I'll make you drink ......'s."
[cpg cn=true]


The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it.
[cpg]


He gave me a mouthful to drink. Mitsuki seemed to be enjoying this situation.
[cpg]


I feel that she is also attracted to Shizuka's madness. There is no escape for me.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************





My sense of time is getting stranger and stranger. How many days has it been since I came here?
[cpg]


No, I came here at night. ......?　In this short time, my memory is becoming hazy.
[cpg]


That's how debilitated I've become. I probably don't even need to keep an eye on him anymore.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko397"]
[OnName num="ryoko"]
You look like you're having a hard time. Are you hungry?　Or is it your heart?"
[cpg cn=true]


[OnName num="shouya"]
......
[cpg cn=true]


Ryoko is watching me now. She also comes close to me.
[cpg]


Unlike Mitsuki, he doesn't kiss me playfully or anything like that, though.
[cpg]


[OnName num="shouya"]
Hey, Ryoko ......, do you think you could sneak me away or something?"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko398"]
[OnName num="ryoko"]
"...... are you still saying that?　I've come this far and that's not going to happen.
[cpg cn=true]


[OnName num="shouya"]
The first thing to do is to make sure that you are not a victim.
[cpg cn=true]


He didn't even show any expression of hesitation.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


...... and then.
[cpg]


;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Ryoko399"]
[OnName num="ryoko"]
Shoya in his weakened state is cute too,...... so cute I want to eat him."
[cpg cn=true]


...... Ryoko was such a girl?
[cpg]


Is everyone calling everyone else's madness out on each other, or did they lose their halt when they locked her up?
[cpg]


I don't know. I don't know, but it has become impossible for me to escape by myself.
[cpg]


I had to rely on someone to help me go to the bathroom.
[cpg]


I can't move. I don't know, but I can't get out of here by myself anymore.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko400"]
[OnName num="ryoko"]
"It's as if I'm keeping Shoya. ...... I shouldn't say it like this.
[cpg cn=true]


I'm not going to. I'm not going to let you do that. What are you thinking?
[cpg]


I no longer have the strength to argue with them. I just get weaker and weaker.
[cpg]



[SE f="se011"]
;//【ＳＥ】『ドア開く』





Then, Mitsuki came to me.
[cpg]

[free time=1000]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Ryoko401"]
[OnName num="ryoko"]
What's wrong?　It's still too early to change.
[cpg cn=true]


Mitsuki fidgeted and nodded.
[cpg]


He said it was too early for a change. I guess there must be some rules between these girls.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mituki322"]
[OnName num="mituki"]
Go, rice, I want to feed you."
[cpg cn=true]


Mitsuki seemed to take pleasure in being kind to me in my weakness.
[cpg]


It's quite distorted, but what has happened can't be helped.
[cpg]


Besides, it is not hard to understand that kind of feeling. If there was a girl in the opposite position, I would be the first to want to be kind to her.
[cpg]


It's normal to feel that way. So in a sense, Mitsuki is the most normal.
[cpg]


Mitsuki wants to be kind to me when I am weak.
[cpg]


Ryoko says I am cute when I am weak.
[cpg]


And Shizuka who intentionally makes me weak.
[cpg]


...... are three splendidly different people, but why doesn't anyone help me?
[cpg]


I wonder if that's how sinful I am.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************





......And then.
[cpg]


The next time I woke up, it was noon again. I must have slept all day.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="3/3" time=800]
The three of them were happy to see me, as if they didn't think anything of it.
[cpg]


[OnName num="shouya"]
Please, please let me go home now. ...... because I was bad.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Ryoko408"]
[OnName num="ryoko"]
Because. What are you going to do?"
[cpg cn=true]


Mitsuki is silent. Whether he nods or shakes his head, the meaning is the same.
[cpg]


You won't let me go. I know, even as I say it.
[cpg]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************



[SE f="se000"]
;//【ＳＥ】『カラスの鳴き声』





Time passes. A crow crows outside.
[cpg]


How many days has this been?　I don't know anymore.
[cpg]


If this were a prison, I'd scratch the walls and count them, but I can't even do that.
[cpg]


I'd rather be in jail. They'll bring us food.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mituki335"]
[OnName num="mituki"]
So, then, dinner ......."
[cpg cn=true]


Mitsuki is trying to make me drink by mouth again.
[cpg]


 Again, even though I thought about it, I would really die if this disappeared.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************





Gradually, I become more and more dazed.
[cpg]


I can't remember the reason why I did this.
[cpg]


I'm sure I remembered a while ago, and I remember thinking something like, "It's no use remembering.
[cpg]


Was that right, ......?　How about ......?
[cpg]


I can't remember. My brain is clearly not working.
[cpg]

[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="Shizuka474"]
[OnName num="shizuka"]
"Oh, lovely ......, I want to kill her just like that."
[cpg cn=true]


Shizuka is saying some disturbing things, but it really could happen.
[cpg]


I wonder if Shizuka would really be happy if she did.
[cpg]


I wonder if the destination of Mengele's love is the death of his lover. ......
[cpg]


......I don't think so necessarily. I believe that Ryoko and Mitsuki, for example, should be different.
[cpg]


Believing that, I wait for help. I'm sure that even if Shizuka really tries to kill me, I'll be fine.
[cpg]


If she really wanted to kill me, she would have been stabbed long ago.
[cpg]


I don't know if she has a proclivity to make me die a debilitating death in captivity, but I don't know.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="Ryoko409"]
[OnName num="ryoko"]
I'm sure you'll be able to find out more at "....... People have this kind of complexion when they're weak."
[cpg cn=true]


I wonder what kind of complexion I have. But Ryoko also said with an enraptured look on her face.
[cpg]


Both Shizuka and Ryoko seemed to be enjoying the present time, when they can keep alive or kill at their own discretion.
[cpg]


Aside from Mitsuki, they are probably thinking about that ......
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************




[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/3" time=800]
[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="3/3" time=800]

Then comes morning. The three of them don't take turns watching over me anymore, chatting and laughing as they watch me weaken.
[cpg]


[OnName num="shouya"]
I'm going to die, so I need a decent meal.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="1/3" time=800]
[VOICE f="Ryoko410"]
[OnName num="ryoko"]
I want to watch Shoya weaken a little more. You have to be patient."
[cpg cn=true]


It's not a matter of patience or anything like that. ......
[cpg]


But if Ryoko wants me to do so, I can't go against her.
[cpg]


But how can the three of you be laughing and talking when someone is dying right in front of you?
[cpg]


The content of their conversation was also terrible.
[cpg]


They were talking about what they would do if I died, and how their love would be eternal.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Mituki336"]
[OnName num="mituki"]
Killing me would be ...... quintessential, I think it's too much."
[cpg cn=true]


Mitsuki is applying the brakes, but it doesn't have much effect on Shizuka.
[cpg]


And Ryoko is not trying to stop. That was the way it looked.
[cpg]


I wonder what these girls think about loving someone.
[cpg]


Is it love to abuse and torture?
[cpg]


There are people like that in the world. But I can't believe that all the girls who happen to have feelings for me are like that. ......
[cpg]


What are the odds? I don't know.
[cpg]


I can't think straight. ...... If that's the case, I need to figure out a way to get out of this.
[cpg]


I've been thinking about something completely unrelated.
[cpg]


It seems that the three of us have been affected by the abnormality of the three of them, and I have been affected by it too.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
;//ＢＫ

I'm completely their plaything. I'm not a slave or anything.
[cpg]


They don't treat me like a human being. When I was in school with the three of them, at least I was treated like a human being.
[cpg]


Should I have continued the relationship with them? No, I don't think so.
[cpg]


If I had done that, someone's stress would have exploded.
[cpg]


I don't think it would have been good for anyone to explode.
[cpg]


So I'm glad I did this. ...... Maybe this is the right thing to do.
[cpg]


I don't know if this is the result of the right thing to do. But I have a little patience left.
[cpg]






[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************





I think so, but help is not coming.
[cpg]


I wonder what's going on. Are Shizuka's parents very powerful behind the scenes?
[cpg]


If that's the case, I'll be like this for the rest of my life, or so I thought.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Shizuka485"]
[OnName num="shizuka"]
What's wrong, you look so scared. Let's still have fun.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="Ryoko416"]
[OnName num="ryoko"]
That's right. We're throwing away our youth, too.
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="3/3" time=800]
[VOICE f="Mituki345"]
[OnName num="mituki"]
That's why we want to ...... stay ...... together forever and ever."
[cpg cn=true]


They were all smiling in unison. I feel broken.
[cpg]


I can't see properly because my eyes are already blurry, but I can see their smiles clearly.
[cpg]





[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************





I had been repeating this day after day, and it seemed I had stopped waking up.
[cpg]


I heard the three of them panicking in the distance.
[cpg]


I went back to sleep, thinking that they would be in a hurry there.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



When I woke up next at ...... I was in the hospital.
[cpg]

They asked me what had happened, but I stubbornly said nothing.
[cpg]

I was afraid of retaliation from the girls, so I didn't say anything.
[cpg]

But now that the others knew, the three of us couldn't do anything reckless. ......
[cpg]





[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



[SE f="se002"]
;//【ＳＥ】『雑踏』





[OnName num="shouya_lover"]
"...... what's going on?　Thinking?"
[cpg cn=true]


[OnName num="shouya"]
"Oh, no,...... it's nothing."
[cpg cn=true]


Holidays.  I became what is called a transfer student.
[cpg]


There was a girl who reached out to me when I was distrustful of women.
[cpg]


There was not a trace of menshera-ness about her. In fact, she was the exact opposite.
[cpg]


She was like the sun. She would probably go out with people who have fallen ill without discrimination.
[cpg]


That's why she approached me. That's what I thought.
[cpg]


[OnName num="shouya_lover"]
Really?　Shoya-kun, you have a tendency to hoard, so I don't trust you.
[cpg cn=true]


[OnName num="shouya"]
I don't know if that's true.
[cpg cn=true]


I thought, "If she says that much, I might as well tell her.
[cpg]


With that in mind, I go on to explain to her.
[cpg]


[OnName num="shouya"]
You know what? I'm afraid of women. That happened to me in the past. ......
[cpg cn=true]


[OnName num="shouya"]
It's not so much that I have a phobia of women, but more like a distrust of women. I still have doubts about you.
[cpg cn=true]


[OnName num="shouya_lover"]
Suspicion, like what?
[cpg cn=true]


[OnName num="shouya"]
For example, ......, that you're going to lock me up.
[cpg cn=true]


I think I am talking out of my head. But she was listening to me seriously.
[cpg]


[OnName num="shouya_lover"]
It's tough," she said. But every wound can heal.
[cpg cn=true]


[OnName num="shouya"]
I wondered when ...... that would be. That is."
[cpg cn=true]


[OnName num="shouya_lover"]
'I don't know that, but I'll wait. Until Shoya believes in me.
[cpg cn=true]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





And in the evening. The date was almost over.
[cpg]


[OnName num="shouya"]
Then, let's go home.
[cpg cn=true]


[OnName num="shouya_lover"]
Yeah. Let's see, ......, I have a suggestion as a first step in healing the wound."
[cpg cn=true]


[OnName num="shouya"]
What?
[cpg cn=true]


[OnName num="shouya_lover"]
Kiss me.
[cpg cn=true]


...... Yeah. I haven't even kissed this girl.
[cpg]


I've done my best to hold her hand. That's how scared I was of girls.
[cpg]


But I think I can do it now. She closes her eyes, and I try to put my lips on hers. ......
[cpg]



;//下記のセリフのキャラ名は「声」と変えてください



[VOICE f="Shizuka486"]
[OnName num="voice"]
'Are you betraying me?'
[cpg cn=true]


[OnName num="shouya"]
Huh?"
[cpg cn=true]


I heard someone's voice. The first thing you need to do is to make sure that you have a good relationship with the person you are going to be talking to.
[cpg]


[OnName num="shouya"]
I knew I couldn't ...... sorry, I can't."
[cpg cn=true]


She slowly opened her eyes. She didn't look disappointed, but smiled a little.
[cpg]


[OnName num="shouya_lover"]
It's okay," she said. Let's heal slowly.
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




And then... I started to hear someone's voice every time I tried to kiss my girlfriend or something like that.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





...... and I stand in front of the psychiatrist's office.
[cpg]


As I was surrounded by these Mengele girlfriends, I became a Mengele too.
[cpg]


It's a joke, not funny. But it's not a joke, it's the truth.
[cpg]


I wonder if my current girlfriend would really do anything to me.
[cpg]


Will she change one day and take out a knife?
[cpg]


Or will someone somewhere get jealous of her and stab me?
[cpg]


Will she lock me up? I have always been afraid of such things.
[cpg]


I open the door of the hospital. I felt as if the girls were beckoning me, and I shivered.
[cpg]



;//ＥＮＤ：ハーレムルート

[system cl_h4r4=true]

[SCENE id=19]

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


