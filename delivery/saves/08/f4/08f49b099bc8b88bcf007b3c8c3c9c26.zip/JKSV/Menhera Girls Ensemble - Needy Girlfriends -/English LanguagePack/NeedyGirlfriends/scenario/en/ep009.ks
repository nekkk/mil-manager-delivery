
*start

;//==============================
;//３、光希


;#################################################
*Ep009|Select Mitsuki
;#################################################


[stflag LoLiflg = 0]
[if exp={ isSystemFlagsEnabled( "sysSel01") }]
[stflag LoLiflg = 1]
[endif]
[if exp={ isSystemFlagsEnabled( "sysSel02") }]
[stflag LoLiflg = 1]
[endif]
[if exp={ isSystemFlagsEnabled( "sysSel03") }]
[stflag LoLiflg = 1]
[endif]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="3/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


*select04_3|I choose Mitsuki.

[SCENE id=9]

I like Mitsuki. The answer is fixed in my mind.
[cpg]


But then, I wait and stay.
[cpg]


[OnName num="shouya"]
"I like ......."
[cpg cn=true]


That would also mean dumping the other two. It would be bad to reject either Shizuka or Ryoko.
[cpg]


Shizuka will try to hurt me or the other two.
[cpg]


And Ryoko would probably try to hurt herself.
[cpg]


To dump both of them at the same time seemed incredibly risky.
[cpg]


[OnName num="shouya"]
I like ...... them all, so I'll choose all three of them.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

He said so, and then blurted it out. I misrepresented my feelings of love for Mitsuki.
[cpg]



[VOICE f="Ryoko369"]
[OnName num="ryoko"]
If you keep talking like that, you're going to break this relationship somewhere down the road.
[cpg cn=true]


It's true. I've already given my answer.
[cpg]


I decided to gradually distance myself from everyone except Mitsuki. That's what I decided.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





On the way home. Shizuka and Ryoko, the two of them are sticking to me.
[cpg]


I said I would treat them equally in front of them. I can't refuse this situation.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Shizuka414"]
[OnName num="shizuka"]
I said, "Are you seriously going to go out with all of them?　I'd go crazy with jealousy if I did."
[cpg cn=true]


[OnName num="shouya"]
I said to her, "...... Then what do you want me to do? I can't choose just one person.
[cpg cn=true]


Am I deceiving myself? That I really like Mitsuki.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





I went back to my room and called Mitsuki. I have her contact information.
[cpg]

;//[lbox on]


[VOICE f="Mituki132"]
[OnName num="mituki"]
I called her at ....... "What's wrong, Shoya-san?
[cpg cn=true]


[OnName num="shouya"]
I'm sorry about earlier. I told her I was going out with everyone.
[cpg cn=true]


Mitsuki replied that he didn't care.
[cpg]


She must be convinced that she is the best.
[cpg]


[OnName num="shouya"]
I really like you the best," he said. Please believe me.
[cpg cn=true]



[VOICE f="Mituki133"]
[OnName num="mituki"]
I'm sure you believe me, too. I am sure that you are the best in the world.
[cpg cn=true]


I would normally have doubts at this point.
[cpg]


It is Mitsuki who doesn't say that. There is something wrong.
[cpg]


But I have decided to love Mitsuki, including that part. So, I have to take the first step.
[cpg]


[OnName num="shouya"]
How can I get rid of Shizuka and Ryoko?
[cpg cn=true]


These are also words to make you believe my words. But they were also words that came from the heart.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




I will discuss this with Mitsuki. After consulting with her, we decided to head to her house.
[cpg]


He said he had something he couldn't talk about unless he met her face to face.
[cpg]


I guessed that a phone call would be a bad idea. I decided to go along.
[cpg]

;//[lbox off]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





We talked about it until late that day, but in the end we didn't get an answer.
[cpg]

But the more we talked, the more I felt that Mitsuki was different. Even though he is clearly a Mengele, he is ......
[cpg]

He is somewhat alone and calm. Maybe it's because he's crazy that he can maintain his peace of mind in this crazy situation.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mituki134"]
[OnName num="mituki"]
"Oh, oh, here we go...... let's go."
[cpg cn=true]


[OnName num="shouya"]
"Oh, yeah. I'm not waiting for you."
[cpg cn=true]


Mitsuki came to the meeting place. The gothic lolita fashion is eye-catching.
[cpg]


I've never been up to Mitsuki's house before.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




I was shown through the front door and met someone who appeared to be Mitsuki's father.
[cpg]


[OnName num="shouya"]
I said, "Ojamashimasu ......."
[cpg cn=true]


but there was no answer. He didn't seem like a strict father.
[cpg]


He seemed to be indifferent to Mitsuki's situation.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（朝）******************************************************





He let me through to Mitsuki's room, which was, how should I say it, ......
[cpg]


The room is excessively girlie. It's so girly that it's almost too much.
[cpg]


No wonder she has a taste for gothic lolita. Her personality comes out in this kind of place.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Mituki135"]
[OnName num="mituki"]
I knew it was weird.
[cpg cn=true]


[OnName num="shouya"]
What's funny ......?"
[cpg cn=true]


And Mitsuki was arranging the tarot cards of sometime.
[cpg]


[OnName num="shouya"]
I'm not the one you're meant to be, or something?"
[cpg cn=true]


Seeing Mitsuki's pale face, I tried to talk to him somehow. However, Mitsuki shook his head.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki136"]
[OnName num="mituki"]
I don't know what's going on,......, I've never seen anything like this.
[cpg cn=true]


I don't know what kind of state is a state she's seen before, but ......
[cpg]


Something abnormal seems to be happening. Mitsuki seems to be disturbed by it.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************





Mitsuki explained the anomaly to me at length.
[cpg]


First, let's start with the basics of tarot cards. He talked about the meaning of each card and its positive and reverse positions.
[cpg]


I gave up listening to him because I couldn't keep up with him from the middle of the lecture, but it was completely noon.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Mituki137"]
[OnName num="mituki"]
"Oh, ......, it's already this late.
[cpg cn=true]


[OnName num="shouya"]
I guess so. I wonder if you are hungry.
[cpg cn=true]


;//========================================
;//●ＣＧ（背中を向けているヒロイン。主人公を誘惑する感じの表情）ev_36
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：昼
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMituki010"]
[OnName num="mituki"]
I've been sitting here all day and I'm tired.
[cpg cn=true]


I've been sitting here for a long time, and I'm tired.
[cpg]

I don't know, maybe you're asking me out, but ...... I feel a little uncomfortable, I guess.
[cpg]

[VOICE f="sMituki011"]
[OnName num="mituki"]
"...... don't you think anything of it when you see me like this?"
[cpg cn=true]


[OnName num="shouya"]
I think what you just said is cute."
[cpg cn=true]


We exchanged such words and smiled at each other.
[cpg]


;//移植のためシーンをカットしています



;//ＢＫ

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア開ける』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mituki157"]
[OnName num="mituki"]
I'll see you at ...... tomorrow.
[cpg cn=true]


[OnName num="shouya"]
I know, tomorrow is Sunday, so you want to come to ...... my house?"
[cpg cn=true]


He turned red in the face and muffled his mouth. He's cute.
[cpg]


[OnName num="shouya"]
"I heard you're coming to ....... Then come to my house.
[cpg cn=true]


It's near Ryoko's house, so if Ryoko finds you, she'll kill you. ......
[cpg]


But when I think about it, since I'm in the frame of mind to go out with all three of them, there's no problem, right?
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mituki158"]
[OnName num="mituki"]
"...... see you tomorrow."
[cpg cn=true]


Mitsuki says the same thing as before. I nodded and waved.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





I return home and look at my cell phone. There were dozens of texts from Shizuka.
[cpg]


I knew I couldn't ignore them, so I responded to them.
[cpg]


I couldn't reply to every message, so I kept it as short and to the point as possible.
[cpg]


In short, I replied, "I can't see you tomorrow because it's not convenient for me.
[cpg]


It's hard to be a lover when you have to be a lover with ...... Shizuka and Ryoko as well on the pretense.
[cpg]


But it's even harder to dump these two. I wish I could talk about that with Mitsuki tomorrow, too.
[cpg]


Oh, did I mention that something was wrong with the fortune-telling results?
[cpg]


I'll have to ask him about that too. Whether it's right or not, ......
[cpg]


I'm sure it will determine what kind of action she will take.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************





With this in mind, the next day. I waited for Mitsuki.
[cpg]


;//[lbox on]

Mitsuki called me, so I picked it up right away.
[cpg]


[OnName num="shouya"]
She said, "......, what's wrong?"
[cpg cn=true]


[VOICE f="Mituki159"]
[OnName num="mituki"]
Oh, um,......, I'm coming to Shoya's house.
[cpg cn=true]


[OnName num="shouya"]
I see. I'm going to pick you up then.
[cpg cn=true]

;//[lbox off]

Then I leave the house.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se011"]
;//【ＳＥ】『ドア開く』





[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





 Mitsuki was in her usual gothic lolita fashion.
[cpg]


[OnName num="shouya"]
The first thing you need to do is to make sure that you have the right tools and the right equipment to do the job. I'm sure it's hard for you to wear that ...... outfit again today.
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mituki160"]
[OnName num="mituki"]
I know it's a lot of work, but I would do it for ...... Shoya."
[cpg cn=true]


Is it for me? I thought it was a personal hobby.
[cpg]


[OnName num="shouya"]
No, wait, you were wearing it before you met me."
[cpg cn=true]


When I asked her this, she said she was wearing it for the person she was destined to meet someday.
[cpg]


She says it was already predestined that she would meet him soon.
[cpg]


That's ...... radio waves. I'm trusting my love to the cards.
[cpg]


But I hope that in time, no matter what the horoscope says, she'll come to love me.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se011"]
;//【ＳＥ】『ドア閉まる』




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="2/3" time=800]

And in my room. We were both blushing.
[cpg]


[OnName num="shouya"]
I couldn't stand the silence.
[cpg cn=true]


I couldn't stand the silence, so I asked her about it. Then he said ......
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sMituki012"]
[OnName num="mituki"]
......I have more important things to do than that.
[cpg cn=true]


The first thing to do is to make sure that you have a good understanding of what is going on in your life.
[cpg]

He's a lovely man. If he's got me expecting so much from him, I have to live up to it.
[cpg]


;//移植のためシーンをカットしています

After some time of flirting, when it was probably time for Mitsuki to go home,.......
[cpg]


[OnName num="shouya"]
......Doesn't Mitsuki have to go home?
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mituki178"]
[OnName num="mituki"]
I don't want to go home.
[cpg cn=true]


The way she said it, I guess she meant she had to go home.
[cpg]


[OnName num="shouya"]
I think you should go home. Your parents will be worried.
[cpg cn=true]


Mitsuki wanted to say something, but in the end she listened to me.
[cpg]


Because even for me, I can't ...... let her stay at home like this.
[cpg]


I don't know how I'm going to tell my parents.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se011"]
;//【ＳＥ】『ドア開く』





[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





[OnName num="shouya"]
I'll see you later."
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mituki179"]
[OnName num="mituki"]
Umm, yeah...... see you at the academy......."
[cpg cn=true]


The first time I saw her, she was a little nervous.
[cpg]


 That gesture was indescribably Mitsuki like.
[cpg]


I want to love you more. There are many obstacles to that, though.
[cpg]


I've got to get over all of that. I have to at least think I can do that now.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se011"]
;//【ＳＥ】『ドア閉まる』




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="shouya"]
"Well, and ......"
[cpg cn=true]


Mitsuki left. The scent of her scent is still there.
[cpg]


I wonder if I will be able to sleep today. I might be too excited to sleep.
[cpg]


But I have to wake up early, I have to walk with Shizuka and Ryoko next to me.
[cpg]


If I oversleep, they might be late too.
[cpg]


It is unlikely that those two would leave me behind, given their personalities.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





The next morning. I had overslept a little and they were still waiting for me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Ryoko370"]
[OnName num="ryoko"]
You're late. I'm going to be late.
[cpg cn=true]


[OnName num="shouya"]
You should have gone ahead of me. ......
[cpg cn=true]


I tried to tell them, but it was impossible, wasn't it?
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
I had my love rival next to me, and I was the only one who was going to the school first.
[cpg]


From both Shizuka's and Ryoko's point of view, it is absolutely impossible.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Shizuka415"]
[OnName num="shizuka"]
You can find a lot of different types of shoes and boots.
[cpg cn=true]


He says so and pulls my hand away. I knew these two were heavy. ......
[cpg]


On the contrary, I don't think Mitsuki's love is so heavy.
[cpg]


Maybe I'm paralyzed by Shizuka and Ryoko, but I think it's just right.
[cpg]


It is neither too serious nor too frivolous. He is very preoccupied, but that is also a charm point.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ryoko371"]
[OnName num="ryoko"]
What are you smiling about ......?"
[cpg cn=true]


[OnName num="shouya"]
I'm sorry. It's nothing.
[cpg cn=true]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

And lunchtime. It was lunch with Shizuka, Ryoko, and me as usual.
[cpg]


I remember that Mitsuki doesn't step in at times like this.
[cpg]


I wonder if she's being considerate in her own way.
[cpg]


Because if Mitsuki were to join us, it would be a far cry from a shuraba situation.
[cpg]


She is confident that she is truly loved, so I guess that's why she doesn't want to join in.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Ryoko372"]
[OnName num="ryoko"]
So, why are you smiling?　Something's wrong.
[cpg cn=true]


[OnName num="shouya"]
I'm sorry. ......
[cpg cn=true]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And after all the classes were over.
[cpg]

[SE f="se011"]
;//【ＳＥ】『ドア開ける』



[OnName num="shouya"]
I'm home. ......
[cpg cn=true]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





I collapse on the bed in my room.
[cpg]


I haven't had much contact with Shizuka and Ryoko. ...... I was feeling pretty preoccupied on the way home.
[cpg]


I have to take care of both of them. I don't want them to blow up somewhere.
[cpg]


It's already been discovered that neither of them know what they're capable of.
[cpg]


Shizuka is really going to take out a knife, and Ryoko is planning strange schemes and self-mutilation.
[cpg]


Both of them are bad, aren't they? Thinking so, I come to doze off: ......
[cpg]


No, no, I have to eat dinner. The first thing that comes to mind is the fact that the two of you are not the only ones who have been through this.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



The first thing that comes to mind is the fact that you have three lovers, even though they may not look like it. It's not an easy thing to do.
[cpg]


I pretend to love them all equally, but I love only Mitsuki.
[cpg]


I really can't complain even if I go to hell. ......
[cpg]


Still, while also going out with Shizuka and Ryoko, the next holiday.
[cpg]




[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





I invited Mitsuki to my room. The agenda was how to get rid of those two.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki197"]
[OnName num="mituki"]
"Ki, don't worry about it,.......
[cpg cn=true]


[OnName num="shouya"]
...... what do you mean?"
[cpg cn=true]


She was nodding her head in agreement today as she laid out the tarot cards.
[cpg]


I have no idea what she is talking about, so I ask her for more details.
[cpg]


[OnName num="shouya"]
I don't know what she is talking about, but I have no idea what she is talking about. I don't know what's going to happen.
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mituki198"]
[OnName num="mituki"]
I don't know what's going to happen to them," she said. Maybe a car accident or something on that level."
[cpg cn=true]


[OnName num="shouya"]
What are you talking about?　Can you tell such things from fortune telling?
[cpg cn=true]


Mitsuki assured me that he could tell. I thought that was not true, no matter how much I wanted to believe it.
[cpg]


For example, the story of the person who is destined to be is something that can be done with a lot of assumptions.
[cpg]


But a car accident is something that happens by chance. It is not about the human mind.
[cpg]


[OnName num="shouya"]
I thought to myself, "Really, really?　You're not joking, are you?
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki199"]
[OnName num="mituki"]
"Uh-huh. I think those two are going to die in the accident.
[cpg cn=true]


...... Does this mean that Mitsuki will take some steps?
[cpg]


 Either way, it's not very exciting.
[cpg]


Mitsuki has always been strange, but this is a bit too much.
[cpg]


How should we treat him? ......
[cpg]



;//==============================
;//恋愛ポイントが１以上の場合
[if exp={getFlagValue("LoLiflg") == 0}]
[jump target="*root_2_2"]
[endif]


*root_2_1|I choose Mitsuki.
[jump storage="ep010.ks" target="*root_3_1"]

*root_2_2|Choose Mitsuki
[jump storage="ep011.ks" target="*root_3_2"]




