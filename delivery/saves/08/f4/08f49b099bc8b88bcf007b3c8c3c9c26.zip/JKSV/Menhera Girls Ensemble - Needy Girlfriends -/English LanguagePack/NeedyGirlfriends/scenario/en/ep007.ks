
*start

;#################################################
*Ep007|Protect Ryoko no matter what
;#################################################

*root_2_1|Protect Ryoko no matter what

[SCENE id=7]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』





The next morning. I was on my way to the school with Ryoko.
[cpg]


[OnName num="shouya"]
"Hey, Ryoko.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko249"]
[OnName num="ryoko"]
"...... what?　Don't you like me anymore?
[cpg cn=true]


[OnName num="shouya"]
The opposite. I will protect Ryoko no matter what.
[cpg cn=true]


The answer I gave was that I love her.
[cpg]


I will protect her no matter what. I will protect her even if I fall. Even if we both fall, I will protect her.
[cpg]


I vowed to keep seeing her, even though I felt something wasn't right with this relationship.
[cpg]


[FADEOUTBGM]
;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




After the daytime school, I headed back to her house.
[cpg]





;//========================================
;//●ＣＧ（主人公の体に手を当てて、よりそうヒロイン）ev_30
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================


[BGM f="bg_h2"]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]

[window target=true]

She is there for me at all times.
[cpg]

How could I not be affected by being so close to her?
[cpg]



She wasn't the only one who was sick. Even I am getting sick.
[cpg]


[OnName num="shouya"]
......I haven't been able to sleep lately.
[cpg cn=true]


The cause is obvious. She is pulling on my spirit.
[cpg]


I know that this dependency on her is not good for our relationship, but I said it out loud.
[cpg]


[VOICE f="sRyoko008"]
[OnName num="ryoko"]
I have some medicine that will help you sleep, so I'll share it with you. Which do you prefer, a sleep aid or a sleeping pill?"
[cpg cn=true]


[OnName num="shouya"]
'......What's the difference?'
[cpg cn=true]


Ryoko didn't seem to know much about it either, but she said she uses them differently depending on her mood.
[cpg]


I wondered if that's how medicine is supposed to be, and I asked her to share her pills with me.
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************





No one stops me from staying over at her house at night anymore.
[cpg]


Ryoko's parents and my parents are the same. We are already an official couple.
[cpg]


From the outside, it might just be a happy thing. However, my physical condition was getting worse and worse.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002"]
;//【ＳＥ】『雑踏』



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

Weekday. Ryoko and I head to the school.
[cpg]


My house is close by, and I can go get a change of clothes right away. So there is no problem to stay over.
[cpg]


However, I was having trouble sleeping recently, so I was taking the medicine she gave me.
[cpg]


It seems that it is not good for me. I don't know if it's a side effect or if Ryoko mixed it with sleeping pills: ......
[cpg]


My heart is kind of pounding in my chest. Just looking at the girl is enough to make me flustered.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko269"]
[OnName num="ryoko"]
"...... don't look at any other girl but me."
[cpg cn=true]


[OnName num="shouya"]
I'm sorry,......, but I've been acting strange lately."
[cpg cn=true]


I explain the situation to Ryoko.
[cpg]


I've been taking medication and something has been wrong with me since I started taking it.
[cpg]

When I told her that, Ryoko was not surprised at all.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko270"]
[OnName num="ryoko"]
I see, so the aphrodisiac is working properly.
[cpg cn=true]


What is that, an aphrodisiac ......?　Is that what you're making me take?
[cpg]


[OnName num="shouya"]
What do you mean ......?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="sRyoko009"]
[OnName num="ryoko"]
"Don't worry, it's a legal drug."
[cpg cn=true]


It's a legit drug. I knew they were giving it to me mixed with sleeping pills.
[cpg]


That explains everything.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ryoko271"]
[OnName num="ryoko"]
Well, I don't think Shoya would be able to tell the difference.
[cpg cn=true]


...... Is this also Ryoko's order?
[cpg]


If I dump it out of hiding, she might start self-harming again.
[cpg]


I can't believe she would dump the aphrodisiac behind my back and then pretend that the aphrodisiac is working. I'm not dexterous enough to pull off such an act.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





I can't even listen to the lesson properly in class anymore.
[cpg]



No, I can't look at any other girl but Ryoko. ......
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
The first thing you need to do is to make sure that you have a good understanding of what you're doing and how to do it.
[cpg]


I thought she was not going to look at me, but she stopped for a moment and muttered to me, "Ryoko and I are going out.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki130"]
[OnName num="mituki"]
Are you happy ...... with Ryoko-san?"
[cpg cn=true]


[OnName num="shouya"]
......."
[cpg cn=true]


I also stopped involuntarily.
[cpg]


[OnName num="shouya"]
I'm ...... happy."
[cpg cn=true]


The actuality that the actuality that the actuality is that the actuality is not a lot of.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mituki131"]
[OnName num="mituki"]
So, yes,......."
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

And after class, I was alone with Ryoko in one of the empty classrooms.
[cpg]

;//========================================
;//●ＣＧ（ヒロインに抱きつく主人公）ev_31
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_31_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="shouya"]
'...... holding Ryoko makes me feel relieved.
[cpg cn=true]


Everything must be because of the drug. They even called it an aphrodisiac.
[cpg]

It's a drug that makes you feel like you can't stop doing these things. ......
[cpg]


;//移植のためシーンをカットしています


;**【ＣＧ】 ev_31_a ***********************
[CG id=13 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Ryoko289"]
[OnName num="ryoko"]
"...... Shoya's house, can I go?"
[cpg cn=true]


[OnName num="shouya"]
'Sure. I think my parents would probably be happy to see you."
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




The couple is officially approved by their parents. I don't feel any different anymore.
[cpg]


I wonder if my parents know that we are both drugged.
[cpg]


Probably not. With that thought in mind, we headed to my house.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I wondered why she was asking me to do this.
[cpg]


I thought about it before, but I guess it's because she has no other proof.
[cpg]


I think she is anxious. Then I think I should be supportive.
[cpg]


Even if it raises her libido a little. Even if it makes me feel a little wobbly.
[cpg]


I thought I would be the man she wanted me to be.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[SE f="se005"]
;//【ＳＥ】『鳥の鳴き声』


And in the morning, I couldn't wake up properly because of the medication.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





When I woke up, it was evening ...... and strangely I wasn't hungry.
[cpg]


Still, I felt like I needed to eat something.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko291"]
[OnName num="ryoko"]
What should I ...... do for dinner?"
[cpg cn=true]


[OnName num="shouya"]
"Ryoko, you hardly ate all day,...... are you okay with it?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ryoko292"]
[OnName num="ryoko"]
I have very little appetite. I've never had much of an appetite.
[cpg cn=true]


I didn't know that. I guess I just found out something pretty painful.
[cpg]


The first thing that comes to mind is that the family is all together for the meal.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]




We were eating together as a family, and in addition, my girlfriend was there.
[cpg]


My parents looked happy, nervous, and strange.
[cpg]


I've never seen my parents like this. If they're happy, whatever. ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

Then I go back to my room.
[cpg]


[OnName num="shouya"]
"What do you ...... want to do?　Ryoko want to go back home already?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sRyoko010"]
[OnName num="ryoko"]
No, I still want to stay.
[cpg cn=true]


I can't refuse her asking for that.
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





Time passes. Time flows surprisingly fast.
[cpg]


I don't know what kind of drugs she is taking.
[cpg]


Perhaps it's Ryoko, so she is being drugged to make her like herself.
[cpg]


The side effects were immediate. She is getting more and more dizzy walking.
[cpg]


It's bad enough that I'm not sleeping properly. The sleeping pills are becoming less and less effective.
[cpg]


Is it because I'm worried about Ryoko hurting herself, or is it still the drugs? ......
[cpg]


Whatever it was, I was breaking down more and more. I don't know what I'm doing anymore.
[cpg]


I wondered if this is how Ryoko usually saw the world.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ky"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





Then one evening. I was on my way home with Ryoko.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko310"]
[OnName num="ryoko"]
I said, "...... Shoya?"
[cpg cn=true]


I was in worse shape than usual that day. I don't remember exactly why.
[cpg]


[free time=1000]

I didn't notice the red light, or rather I didn't notice that it was a pedestrian crossing and didn't ......
[cpg]


I couldn't stop where I needed to stop.
[cpg]


It was like we were in love.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se050"]
;//【ＳＥ】『ブレーキ』



I was hit by a car. I was hit by a car and my consciousness flew away in an instant.
[cpg]


I thought to myself, "This can't be real.
[cpg]


But I had no choice but to accept what had actually happened. I had no choice but to accept it.
[cpg]


And I didn't wake up from that moment, I think.
[cpg]


Time is flying. I think I was taken to the ambulance, Ryoko had a stroke, and so on.
[cpg]


I also wondered if my parents would cry or if my classmates would come to worry.
[cpg]


I wondered if Mitsuki would come, ...... and so on.
[cpg]


The next time I was conscious was in a situation like this.
[cpg]


I wondered if this was a dream, and it might have actually been a dream.
[cpg]


I couldn't move. I think I was unconscious. ......
[cpg]


For some reason, I could hear clearly only at this moment. I felt someone touching me.
[cpg]

;//移植のためシーンをカットしています

[free time=2000]
[BG f="white.ui" time=2000]
[WAIT time=3000]
;//画面白く

[VOICE f="Ryoko325"]
[OnName num="ryoko"]
I thought, "......?　Shoya?　Did you just move......?"
[cpg cn=true]


[OnName num="shouya"]
"Ryo, this is ......."
[cpg cn=true]



[VOICE f="Ryoko326"]
[OnName num="ryoko"]
Shoya!　I'm here!
[cpg cn=true]


I'm here!" I open my eyes just a little. I can see Ryoko.
[cpg]


[OnName num="shouya"]
"Be happy, ......."
[cpg cn=true]


I can say that Ryoko has done me a terrible disservice. But that was the last thing she said to me.
[cpg]


Will I wake up from this? Or will I die after all?
[cpg]


No one knows. But I knew that my consciousness was slipping away again.
[cpg]


I wonder when I will wake up again. I fall asleep with such thoughts in my mind.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]


;//ＥＮＤ：ヒロイン２ルート１

[system cl_h2r1=true]

[SCENE id=15]
[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


