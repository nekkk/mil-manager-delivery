
*start

;//束縛彼女の三重奏　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//静香　裸　私服　制服
;//涼子　裸　私服　制服
;//光希　裸　私服　制服
;//以下音声なし
;//翔也　男子学生　翔也の母　男子学生Ａ　男子学生Ｂ　静香の母
;//女子学生Ａ　女子学生Ｂ　男の声　静香の父　翔也の妻　翔也の娘　教師　翔也の恋人


;#################################################
*Ep000|Disturbing Rumors
;#################################################

[SCENE id=0]

;//Love Life Flg
[stflag LoLiflg = 0]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************






The season is winter. Valentine's Day.
[cpg]


Everyone is sobbing. The atmosphere was somewhat buoyant. I was looking at it as if it was something else.
[cpg]


Nobody likes me, but I have a girl friend from childhood.
[cpg]


I get one every year from her, so it's not zero.
[cpg]


No strikeouts, no home runs. I always greet Valentine's Day with a more stable feeling than everyone else.
[cpg]


Shoya Ichijo. He is a characteristic-less boy by his own admission and by others.
[cpg]


Nothing special would happen this Valentine's Day. I thought so.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************





But that day, this year was a little different. I didn't see anything that I intended to see either.
[cpg]


I caught a glimpse of it from the hallway. I saw a beautiful girl handing a piece of chocolate to someone who was obviously her true love.
[cpg]


The boy shakes his head. The girl's is crying. ......
[cpg]


And the boys are about to leave the classroom. He approaches me in the hallway.
[cpg]


[OnName num="male_student"]
He says, "Hey, what the hell. Did you see that?"
[cpg cn=true]


[OnName num="shouya"]
"......."
[cpg cn=true]


[OnName num="male_student"]
He said, "You saw me in a bad way. ...... Don't start rumors or anything like that."
[cpg cn=true]


I don't mean to do that. I basically don't want to do anything that people don't like.
[cpg]



[SE f="se011"]
;//【ＳＥ】『ドア開く』





I was left alone and went to her crying.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

It's ...... Shizuka. I didn't recognize her from a distance. She is Shizuka Tojo, in a different class but in the same grade.
[cpg]



[VOICE f="Shizuka001"]
[OnName num="shizuka"]
"......Gusu, ugh, ahhh......."
[cpg cn=true]


She must have noticed my approach, but she kept crying.
[cpg]


[OnName num="shouya"]
"Calm down. Don't cry.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Shizuka002"]
[OnName num="shizuka"]
Who are you ......?　Leave me alone,.......
[cpg cn=true]


[OnName num="shouya"]
I'm Shoya. I'm Shoya Ichijo and I'm ...... well, uh..."
[cpg cn=true]


It's an old bad habit. I know I think I'm uncharacteristic, but these things could be a feature.
[cpg]


I can't leave people in trouble. It's not just people in need, it's the same with people who are crying like this.
[cpg]


It's hard for me when people are in pain. It's always been that way.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





As we talked a little, Shizuka calmed down.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka003"]
[OnName num="shizuka"]
She said, "I've been in love with you for a long time. Really, to the point that I would kill her if I couldn't go out with her."
[cpg cn=true]


That's a bit of a disturbing way of putting it. I can understand if it's "if I can't go out with you, I'll kill you.
[cpg]


[OnName num="shouya"]
I can understand if you're going to die if you can't go out with him. I know how you feel. ......
[cpg cn=true]


I don't like anyone. I don't understand how you can say you're going to kill them.
[cpg]


But I want to somehow comfort her, and the words come out on my own.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Shizuka004"]
[OnName num="shizuka"]
I know how you feel. ...... Do you have someone you love too?
[cpg cn=true]


[OnName num="shouya"]
"Well,......, I don't."
[cpg cn=true]


And then, they get into it deeply like this, and fail.
[cpg]


But Shizuka seemed relieved to hear that there was no one she liked.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka005"]
[OnName num="shizuka"]
So you don't have anyone you like. Then go to ......."
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（ヒロインからチョコレートを渡される。ヒロイン顔を赤らめている）ev_01
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]



It was a turn of events that I never thought would happen. Shizuka-san blushed.
[cpg]


I was so happy to see her.
[cpg]


[OnName num="shouya"]
"Shizuka-san,...... are you serious?"
[cpg cn=true]



[VOICE f="Shizuka006"]
[OnName num="shizuka"]
I'm not serious yet.
[cpg cn=true]


What does that mean?　What does that mean?
[cpg]


[OnName num="shouya"]
I understand that it's a waste of time to make them, but it's really a waste of time to give them to me.
[cpg cn=true]



[VOICE f="Shizuka007"]
[OnName num="shizuka"]
It's okay. Take it, please.
[cpg cn=true]


I don't know what to do. ...... If I accept it here, I don't think we are strangers to each other anymore.
[cpg]


Whether or not it will develop into love, you have to think about it.
[cpg]



;//■選択肢
[switch]
[case "Accept"]
	[swap]
	[jump target="*select01_1"]
[case "Refuse"]
	[swap]
	[jump target="*select01_2"]
[endswitch]

1. accept
2. refuse



;//==============================
;//１、受け取る
*select01_1|Disturbing rumor


;//恋愛ポイント+1
[stflag LoLiflg = 1]
[system sysSel01=true]



[OnName num="shouya"]
"I understand ....... Thank you."
[cpg cn=true]



[VOICE f="Shizuka008"]
[OnName num="shizuka"]
I don't need to thank you. I'd rather say it myself.
[cpg cn=true]


[OnName num="shouya"]
"No, you don't. I think this is the first time I've gotten chocolate from someone other than my childhood friends and family.
[cpg cn=true]


[jump target="*select01_3"]
;//==============================
;//２、断る
*select01_2|Disturbing rumors

[system sysSel01=false]


[OnName num="shouya"]
I don't know what to do. ......
[cpg cn=true]


I couldn't say no to him and gave him a vague answer.
[cpg]


[VOICE f="Shizuka009"]
[OnName num="shizuka"]
Then throw it in the trash. I want to give it to you."
[cpg cn=true]


I can't throw it away. I was forced to accept the chocolate with that thought in my mind.
[cpg]



;//==============================
*select01_3|Disturbing Rumors





[VOICE f="Shizuka010"]
[OnName num="shizuka"]
I was so thankful for ....... I would have exploded if you hadn't come.
[cpg cn=true]


[OnName num="shouya"]
What do you mean by explode?　That's a funny way to put it.
[cpg cn=true]


I laughed a little and Shizuka laughed too.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka011"]
[OnName num="shizuka"]
"Phew. It's a little hot for winter.
[cpg cn=true]


She blushed, looked away, and said something like that.
[cpg]


[OnName num="shouya"]
I think I might be getting a little nervous too.
[cpg cn=true]


I shouldn't say these thought-provoking things.
[cpg]


But it's true that I felt that way. I'm not lying.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka012"]
[OnName num="shizuka"]
I'm not going to lie to you.
[cpg cn=true]


[OnName num="shouya"]
I don't mind what you call me. I don't mind what you call me, Shizuka.
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
I'm not lying.
[cpg]


The first thing to do is to make sure that you have a good understanding of what you're doing.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka013"]
[OnName num="shizuka"]
You can call me Shizuka, too. Call me by my name."
[cpg cn=true]


[OnName num="shouya"]
I said, "...... right. Shizuka ......"
[cpg cn=true]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





I brought the chocolates home with me after something like .......
[cpg]


The first time I brought home two chocolates is really the first time I brought home two chocolates.
[cpg]


I get them every year from my childhood friend, so I didn't feel like I was getting them as far as she was concerned,.......
[cpg]


I'm home.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ





[OnName num="shouya"]
I'm home."
[cpg cn=true]


I didn't want my parents to get cold feet, so I didn't tell them I got chocolates.
[cpg]


My parents are very interested in my love life.
[cpg]


It's fine, it's fine, but it's ...... a little bit depressing.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="shouya"]
Wow. ......
[cpg cn=true]


However, I can't help but wonder if I'll ever see chocolates like this.
[cpg]


The one I got from my childhood friend is a normal, so-called handmade chocolate.
[cpg]


But the one from Shizuka, or Shizuka, was a cake. The first thing to do is to make sure that you have a good idea of what you're getting into.
[cpg]


I thought I couldn't eat it by myself, so I had no choice but to bring it to my parents as well. ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ





Then, as I expected, they were cold. I was told repeatedly that it was finally her.
[cpg]


Please leave me alone. I finished eating the chocolate cake, which I divided into three equal portions, while thinking that.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002"]
;//【ＳＥ】『雑踏』





Our school is close to each other in terms of distance. Or rather, it is so close that I could say I chose it for its distance.
[cpg]


I can walk there and it's not hard at all. It's just a nice walk.
[cpg]


On the way there, I met my childhood friend. On the way, I ran into Ryoko Mizuhara, my childhood friend.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ryoko001"]
[OnName num="ryoko"]
She said, "Hey, how was it yesterday?
[cpg cn=true]


By "yesterday," I assume she was talking about the chocolates.
[cpg]


[OnName num="shouya"]
They were delicious. I don't know how girls do such elaborate things.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko002"]
[OnName num="ryoko"]
"...... Everyone?　That's a tricky thing to say.
[cpg cn=true]


It's not good if Ryoko finds out about it. It might not be good if Ryoko finds out.
[cpg]


I was afraid that she would get cold feet again, so I decided to change the subject.
[cpg]


[OnName num="shouya"]
I'm depressed about White Day right now. I'm going to be giving something back for all the trouble I put into it.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Ryoko003"]
[OnName num="ryoko"]
I was so indecisive. I'm secretly looking forward to seeing Shoya's indecisive mind agonize over it.
[cpg cn=true]


What's that? That's some inflected fun.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





Ryoko and I are in the same class. So we talk a lot.
[cpg]


On the other hand, Shizuka and I are in different classes. Even so, I hear rumors about her from time to time.
[cpg]


Since she is a secretly popular girl, I am a little happy that we have grown closer.
[cpg]


But I wonder what the boy who dumped her is thinking. Such a beautiful girl. ......
[cpg]


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_d2"]
[WAIT time=100]
;//ＢＫ





I was thinking, "I ran into that boy in the hallway.
[cpg]


[OnName num="male_student"]
"...... it's you?"
[cpg cn=true]


[OnName num="shouya"]
Why did you dump her?"
[cpg cn=true]


[OnName num="male_student"]
He said, "Why not? If I ask you, you'll wish you hadn't."
[cpg cn=true]


[OnName num="shouya"]
I don't understand. What do you mean?"
[cpg cn=true]


The boy, who did not even know his name, looked around to make sure no one was nearby.
[cpg]


[OnName num="male_student"]
I heard it from a guy from ...... Tojo's school.
[cpg cn=true]


[OnName num="male_student"]
He said, "That guy ain't normal. He counts the number of times his eyes have met the person he loves.
[cpg cn=true]


[OnName num="shouya"]
"...... Isn't that pretty common?　If you're a girl.
[cpg cn=true]


[OnName num="male_student"]
"The guy you like...... I mean, me. I write the names of the girls I'm close to in my notebook.
[cpg cn=true]


[OnName num="male_student"]
Next to it, there's a positive character. I thought I was going to kill her.
[cpg cn=true]


[OnName num="shouya"]
"...... is a lie. I don't think she would do something like that.
[cpg cn=true]


Because she didn't look that dark. I don't think I'm one to be fooled by appearances.
[cpg]


[OnName num="male_student"]
I don't care if you believe me or not. It's just that, well, ......
[cpg cn=true]


[OnName num="male_student"]
If you're willing to take my place, by all means.
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se014"]
;//【ＳＥ】『学園のチャイム』





It was right after that class. For the sake of the class, I was in the same classroom as Shizuka.
[cpg]


I was in a position where I could see her notes, but she didn't seem to be taking any such notes.
[cpg]


I wonder if that boy is too paranoid. But it doesn't sound like a story that came out of thin air. ......
[cpg]


[OnName num="shouya"]
Huh."
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
While I was thinking that, Shizuka looked back at me. She blushed and turned back to face forward.
[cpg]

[free time=1000]

It was a gesture that I thought was cute. I still can't believe such a girl has a dark side.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


At the end of the class, I talked with Shizuka for a while.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka014"]
[OnName num="shizuka"]
She said, "......Why were you looking at me?"
[cpg cn=true]


I couldn't say it was because I had heard bad rumors. I tried to cover it up.
[cpg]


[OnName num="shouya"]
"Well, you know, ...... it's just, no, it's nothing."
[cpg cn=true]


Is this bad? I was afraid that he might think that I was interested in him.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka015"]
[OnName num="shizuka"]
"It's not fair, Shoya's in the back seat ...... while I want to see what's behind you."
[cpg cn=true]


The first thing to do is to make sure that you have a good time with your friends and family.
[cpg]


I was a little buoyant, thinking that spring had sprung in my life,.......
[cpg]



;//ＢＫ


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





I headed to my usual place. The usual place is nothing but the classroom of my class. ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko004"]
[OnName num="ryoko"]
It's late. Let's eat quickly.
[cpg cn=true]


[OnName num="shouya"]
"Oh, sorry,......, I was talking to someone for a minute."
[cpg cn=true]


Eating lunch with Ryoko. This had already become a routine.
[cpg]


I don't mean to make a show of it. It's been this way since I can't remember when it started and ......
[cpg]


I don't have romantic feelings for Ryoko. It's really just a habit.
[cpg]


No,...... it's a little different from just a habit. I enjoy it.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko005"]
[OnName num="ryoko"]
What's wrong?　You look so difficult."
[cpg cn=true]


[OnName num="shouya"]
"No, it's nothing."
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（二人でお弁当を食べる。机越しに向き合っている）ev_02
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]



We chat for a while. We talked for a while, just the two of us, talking about nothing at all.
[cpg]


Usually this is the time when all smiles come together. But ......
[cpg]



[VOICE f="Ryoko006"]
[OnName num="ryoko"]
What?　Really really?"
[cpg cn=true]


The moment we started talking about Shizuka, her face clouded over.
[cpg]


[OnName num="shouya"]
I'm not sure if it was chocolate or cake. Um, it was more of a cake than chocolate. ......"
[cpg cn=true]



[VOICE f="Ryoko007"]
[OnName num="ryoko"]
I think it would have been better if you didn't accept it,.......
[cpg cn=true]


The actuality is, it's not really a good idea to take it.
[cpg]


[OnName num="shouya"]
 "Somehow, everyone is strict with Shizuka."
[cpg cn=true]


When I said this, Ryoko made a disgusted face.
[cpg]



[VOICE f="Ryoko008"]
[OnName num="ryoko"]
I said, and Ryoko made a disgusted face.　Don't call me Shizuka like that. You gave me goosebumps.
[cpg cn=true]


[OnName num="shouya"]
I got goosebumps.　You seem like a normal girl.
[cpg cn=true]


Ryoko looks down her eyes a little while saying "I see. ......". I wonder what "I see" is.
[cpg]


 I decided to ask her about it, even though I wondered what was going on.
[cpg]


[OnName num="shouya"]
'Is she that much talked about?
[cpg cn=true]



[VOICE f="Ryoko009"]
[OnName num="ryoko"]
'On the contrary, haven't you heard anything about her?　She told me that she got into an altercation at her old school.
[cpg cn=true]


A bludgeoning ......?　Does that mean that Shizuka was attacked by someone?
[cpg]


[OnName num="shouya"]
The actuality is, it's a lie. That's too absurd.
[cpg cn=true]



[VOICE f="Ryoko010"]
[OnName num="ryoko"]
"It's too crazy, you know. That cake might have blood or something in it.
[cpg cn=true]


I was horrified. What do you mean blood? That's what gave me goosebumps.
[cpg]


[OnName num="shouya"]
"Don't tell me. ...... I couldn't finish it, and my parents ate it, too.
[cpg cn=true]



[VOICE f="Ryoko011"]
[OnName num="ryoko"]
I'm the kind of girl who gives away more food than she can eat on her own, so you get the general idea.
[cpg cn=true]


[OnName num="shouya"]
"Maybe I'm prejudiced. ...... No, I don't think Ryoko would lie either.
[cpg cn=true]


 When I said that, Ryoko's face became even more sullen.
[cpg]



[VOICE f="Ryoko012"]
[OnName num="ryoko"]
"...... Shoya, you should fix that part of you. You're not on the same page."
[cpg cn=true]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





I don't know which way to go. I know that very well.
[cpg]


The relationship with Ryoko is a good example of this. I am hesitant to close the distance between us or let go.
[cpg]


If nothing happens, I will maintain the status quo. If I have to choose between two options, I will choose between the two, and if I can't choose between the two, I will hold off.
[cpg]


I think that's my nature. I know I need to fix it.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





While I'm in such a state of self-loathing, it's right after school.
[cpg]


Shizuka had come to my class.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka016"]
[OnName num="shizuka"]
She said, "Is this a good time?　I have something to tell you. ......
[cpg cn=true]


I can tell you that I have something to tell you, too. I want to find out the truth of the rumors.
[cpg]


But I don't want to be too pushy about it. ......
[cpg]


[OnName num="shouya"]
Yeah. Okay, what?"
[cpg cn=true]


I thought I'd tell her now, since Ryoko had already left.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka017"]
[OnName num="shizuka"]
It's just a small favor. No, it's funny to call it a favor.
[cpg cn=true]


She's blushing a lot. I'm pretty sure she's into me.
[cpg]


And the favor was a very trivial one: to exchange social networking contacts.
[cpg]


[OnName num="shouya"]
I'll do that. I want to be friends with Shizuka.
[cpg cn=true]


It came out of my heart. Is it possible that I'm in love with her too?
[cpg]


I think there is something that attracts people. It's not just that she's beautiful.
[cpg]


I can see why she's so popular with the boys, not to be outdone by the bad rumors.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka018"]
[OnName num="shizuka"]
I'm sure you've heard of ......?　Oh, thanks."
[cpg cn=true]


He holds my hand. And then he immediately releases it in a hurry. Hmmm, that's grueling. ......
[cpg]


[OnName num="shouya"]
Shall we go home together today? Which direction is it ......?"
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
When I asked him, it was the exact opposite. I was in trouble.
[cpg]


[OnName num="shouya"]
I can't go home with you.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka019"]
[OnName num="shizuka"]
"Okay, I'll go to your house and come back."
[cpg cn=true]


[OnName num="shouya"]
"Ha-ha-ha, what's that?　You don't have to do that.
[cpg cn=true]


It's true that love is a bit heavy. No normal girl would say such a thing.
[cpg]


But I think there is a fine line between heavy love and strong love.
[cpg]


In her case, I think she is in the category of "strong love.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka020"]
[OnName num="shizuka"]
"I don't know what to do. ...... I want to go home with you, but..."
[cpg cn=true]


She still says it. Whether you take this as scary or cute depends on the person.
[cpg]


[OnName num="shouya"]
Then I'll go to your house and we'll go back?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Shizuka021"]
[OnName num="shizuka"]
'Eh, ...... that's weird. Why would you say that?"
[cpg cn=true]


She said the exact same thing. Well, okay.
[cpg]


[OnName num="shouya"]
Well, I really have to go home soon,......, so I'll see you later.
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
Yes," she said and followed me. We had the same exit to the school, so of course we did.
[cpg]



[SE f="se011"]
;//【ＳＥ】『ドア開く』





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





But she was still following me.
[cpg]


She followed me until we were almost at my house, talking to me as we walked.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka022"]
[OnName num="shizuka"]
She was talking to me, "Don't worry about White Day. I didn't make it for that kind of thing.
[cpg cn=true]


[OnName num="shouya"]
"Yeah, yeah ...... I know, I know, but..."
[cpg cn=true]


Why are you following me?　I wonder if he really wants to come up to my house.
[cpg]


I can understand if he is trying to come up to my house.
[cpg]


[OnName num="shouya"]
"Is Shizuka trying to come up to my house?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka023"]
[OnName num="shizuka"]
What are you talking about? That's a little too soon. ......
[cpg cn=true]


I don't know what her standards are. I don't think she is able to draw the line between abnormal and normal.
[cpg]


I can feel that she wants to go home with me, so I don't feel bad.
[cpg]


[OnName num="shouya"]
Well, this is my house, so I'll see you later.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka024"]
[OnName num="shizuka"]
"Yeah, see you then. See you later.
[cpg cn=true]

[free time=1000]
Shizuka then really tries to go home. She is indeed a little bit strange.
[cpg]


She followed me all the way here and never went up to my house. She's going back and forth from the school to my house, and then back to her own house again.
[cpg]



[SE f="se011"]
;//【ＳＥ】『ドア開く』




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



[OnName num="shouya"]
"I'm home!
[cpg cn=true]


[OnName num="shouya_mother"]
"Hey, who was that girl who came to the front door?　You know, that girl?
[cpg cn=true]


Mom was watching from the window, apparently. I'm home.
[cpg]


[OnName num="shouya_mother"]
If she came all the way here, why didn't you ask her to come up?
[cpg cn=true]


[OnName num="shouya"]
"No, I think so too, but she said it's too early."
[cpg cn=true]


I'm getting confused.
[cpg]


 Well, I'm sure there must be girls like that... I head to my room while thinking that.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





I received a SNS text message from Shizuka. Let's go home together again.
[cpg]


No, no, I wonder if she is planning to do this back and forth again. ......
[cpg]


I reply, wondering what that would be like. All I got was, "Yes."
[cpg]


I felt it would be strange to deny it here. On the other hand, I could not positively affirm it either.
[cpg]


It was an ambivalent response. This is a common pattern for me.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



After that, we had dinner, took a bath, and then went to .......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="shouya"]
Wow, ......."
[cpg cn=true]


About twenty e-mails are sent one way or another.
[cpg]


For example, "Shall I make lunch tomorrow?", "Should I stop?" Reply me." "I wonder if she's taking a bath."
[cpg cn=true]


I was a little scared because they were full of things like, "Please talk to yourself.
[cpg]


I was a little scared and replied, "I'm sorry I couldn't reply. I was a little scared and replied, "Sorry I couldn't reply, but lunch is fine.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************





That was enough for that day. She didn't send me any text messages during the night.
[cpg]


I assume that she had an errand to run and I didn't respond to it, so that's why she was like that.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』





[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko013"]
[OnName num="ryoko"]
She said, "Good morning, Shoya. What's wrong?　Lack of sleep?"
[cpg cn=true]


Lack of sleep. Does it look like I'm not getting enough sleep, or do I have dark circles under my eyes?
[cpg]


[OnName num="shouya"]
Why is that?
[cpg cn=true]


When I asked, Ryoko said worriedly, "You look a little paler than usual.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ryoko014"]
[OnName num="ryoko"]
You look a little paler than usual."
[cpg cn=true]


A little paler than usual?　Is it possible to know such a thing?
[cpg]


The complexion is a subtle change, so is it possible to notice a slight difference?
[cpg]


[OnName num="shouya"]
No, I'm fine.
[cpg cn=true]


Yesterday, there was the story of the 20 e-mails. I may have had a bit of a swoon over that.
[cpg]


It's just to the extent that he doesn't realize it.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko015"]
[OnName num="ryoko"]
You know what?　I'm always on Shoya's side.
[cpg cn=true]


[OnName num="shouya"]
That's reassuring. Thank you."
[cpg cn=true]


He scratched his head and said, "Ehehe.
[cpg]


Keep walking. Then you will see ......
[cpg]


[free time=1000]
Then something strange happened. Shizuka came from the other side.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Shizuka025"]
[OnName num="shizuka"]
She said, "Good morning, Shoya. Who is this girl?
[cpg cn=true]


[OnName num="shouya"]
"Eh ......?　Her name is Ryoko, and she's my childhood friend.
[cpg cn=true]


No, that's not it. This is not the time to answer questions.
[cpg]


Shizuka's house is in the opposite direction. Why is she coming from over there?
[cpg]


[OnName num="shouya"]
Why is Shizuka coming here?　You don't have anything to do.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Shizuka026"]
[OnName num="shizuka"]
I have something to do. I came to pick you up. Is something funny?
[cpg cn=true]


Something's wrong. It's quite strange, she's not a child, she's not coming to pick me up. ......
[cpg]


Well, I can kind of understand why you'd want to be with me, but...
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Ryoko016"]
[OnName num="ryoko"]
I'm not a kid, so I'm not going to pick you up. I'm not a kid, I know you want to be with me.
[cpg cn=true]


Ryoko grabs my arm and pulls me close.
[cpg]


 It's a story I heard from Ryoko about how the blade was wounded.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Shizuka027"]
[OnName num="shizuka"]
"......Yes. Let's go."
[cpg cn=true]


Shizuka grabs my arm on the opposite side. So that's a bit unusual too.
[cpg]


I understand grabbing one arm. It's an indication that you won't give it to him.
[cpg]


But grabbing the other arm is strange to look at.
[cpg]


That may be a man's dream, but it's just, it's weird. ......
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I ended up refusing both of them because I couldn't walk with them all the way to the academy.
[cpg]


I remember saying something like, "I can walk alone.
[cpg]


Ryoko was bummed and Shizuka was disappointed. I guess it can't be helped .......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





I take my morning class. On my way to and from class, I saw a girl I was a little curious about.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
I wonder who that is?　I see her every once in a while. ......
[cpg]


A girl who always carries around what looks like tarot cards, like fortune-telling or something.
[cpg]


I've always wondered about her because she's always telling fortunes even in class.
[cpg]


With that in mind, I went to another classroom. Seriously and soundly, I take the class.
[cpg]


While I'm in class, that means Shizuka is in class too, which means I don't have to worry about her sending me an e-mail.
[cpg]


No, getting e-mails isn't something I'm afraid of in the first place.
[cpg]

[free time=1000]
While I was thinking about such a thing alone, I was embarrassed because I was nominated to write down the answer.
[cpg]


I shouldn't be thinking about unnecessary things. I can tell even I'm a bit flustered.
[cpg]


You thought Valentine's Day had nothing to do with you until a while ago, but I can't help it. ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="shouya"]
Hey, do you know Ryoko?　The tarot card girl."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko017"]
[OnName num="ryoko"]
...... another girl?"
[cpg cn=true]


He sighs with a sigh. I'm not saying I'm interested in her.
[cpg]


[OnName num="shouya"]
No, I'm just curious.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko018"]
[OnName num="ryoko"]
　She's a celebrity at the school, just like Tojo-san.
[cpg cn=true]


Shizuka is famous too. I thought, Ryoko must know her name.
[cpg]


[OnName num="shouya"]
'Is she that famous?　No, I'm not even famous. ......"
[cpg cn=true]


Ryoko sighs again. I've been seeing this look on Ryoko's face a lot lately.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko019"]
[OnName num="ryoko"]
I'm going to be. If I did fortune-telling in class, she would get angry with me.
[cpg cn=true]


But I don't get angry, you know why?　Ryoko says.
[cpg]


Well, it's not hard to understand. She probably has some kind of mental illness.
[cpg]


So called Mengele. If so, the school would treat her like a tumor.
[cpg]


[OnName num="shouya"]
I see, she is that kind of girl after all.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko020"]
[OnName num="ryoko"]
I think it's the same with Tojo-san, but you shouldn't go out with girls like that.
[cpg cn=true]


In this case, "going out" probably means getting involved.
[cpg]


The actuality that you can find a lot more than one of these types of products and services is actually a great thing.
[cpg]


[OnName num="shouya"]
I'm sure you'll be able to find a way to get a hold of me.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko021"]
[OnName num="ryoko"]
I'm sure you're right,......, Shoya has that kind of thing.
[cpg cn=true]


[OnName num="shouya"]
No?" he said. These places."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ryoko022"]
[OnName num="ryoko"]
The actuality that you can't get a good deal on the internet is a good thing.
[cpg cn=true]


He mumbles to me, "That's just part of being Shoya. I can hear him perfectly, but I'll pretend I can't hear him.
[cpg]


[OnName num="shouya"]
 “Even if I say I’m interested, it doesn’t mean that I’ve come to like you.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Ryoko023"]
[OnName num="ryoko"]
Why are you saying that to me? Why are you saying that to me?"
[cpg cn=true]


Oh yeah, that's what you're talking about.
[cpg]


Saying you don't like Shimano-san is like saying you sense Ryoko's fondness for you.
[cpg]


[OnName num="shouya"]
No, it's nothing. Sorry, that's weird."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko024"]
[OnName num="ryoko"]
Yes, it's weird. ......
[cpg cn=true]


What a bit unnatural lunchtime. She shows up.
[cpg]


[OnName num="shouya"]
'Huh?　Shizuka, why did you come to this class?"
[cpg cn=true]

[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Shizuka028"]
[OnName num="shizuka"]
'...... you're with that girl again.'
[cpg cn=true]


She didn't glare at Ryoko. Just smiling and saying such a thing is a little scary.
[cpg]


Then silence. Ryoko is looking up at Shizuka. It's very awkward.
[cpg]


[OnName num="shouya"]
She says, "Yi, do you want to have dinner together?　Haha ......"
[cpg cn=true]


I don't think this is a very good line either. I think it might make things worse.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Ryoko025"]
[OnName num="ryoko"]
I don't want to eat with you. If you want to eat with Tojo-san, you two go ahead."
[cpg cn=true]


Ryoko is angry. This is what I call a "shuraba" situation, right?
[cpg]


But neither of them are my girlfriends. I haven't done anything yet.
[cpg]


I was not in a good mood to fight with them, but I was just annoyed.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Shizuka029"]
[OnName num="shizuka"]
Shoya.
[cpg cn=true]


He said and pulled out a nearby chair. Ryoko and I were sitting facing each other, so I put them next to each other.
[cpg]

[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
Ryoko moves to another seat with her half-eaten bento.
[cpg]


I don't like this. How did this happen. It's my fault, maybe ......
[cpg]


I guess indecision is what gets people in trouble.
[cpg]


Someday I'll really have to choose between Shizuka and Ryoko.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



And just like that, me and Shizuka ate our lunch. Ryoko's gaze was piercing me the whole time. ......
[cpg]


Finally, Ryoko stopped looking at me. She is obviously jealous.
[cpg]


And after school, after lunch break and afternoon classes.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Ryoko026"]
[OnName num="ryoko"]
She said, "Let's ...... go home together. Shoya."
[cpg cn=true]


Ryoko is not usually this aggressive. It's just a matter of having lunch together.
[cpg]


But she led me to go home before Shizuka came from another class.
[cpg]


[OnName num="shouya"]
She said, "Hey, don't pull. It hurts."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko027"]
[OnName num="ryoko"]
I really don't think you should go out with Tojo-san. I think I already told you that."
[cpg cn=true]


With that, he tried to get me out of the room before Shizuka arrived.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』




[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
And furthermore, he tried to take me home by a different route than usual.
[cpg]


I didn't know why, but I soon realized.
[cpg]


Shizuka is trying to keep me from being chased .......
[cpg]


[OnName num="shouya"]
How did you come up with this ...... thing?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko028"]
[OnName num="ryoko"]
What do you mean?　Going home the other way?
[cpg cn=true]


[OnName num="shouya"]
Yes. Because you are doing this so that Shizuka can't follow you.
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
Ryoko nodded. And then she walks me home without any particular conversation.
[cpg]


It seems that Ryoko is doing this to get me away from Shizuka, rather than going home together to enjoy conversation.
[cpg]


Ryoko is Ryoko, and she's a little scary ......, I think, and we walk on.
[cpg]



[SE f="se010"]
;//【ＳＥ】『歩く』





Walking that way still takes longer than usual.
[cpg]


The road she is accustomed to taking is close by and she is accustomed to taking it, but the different road she is accustomed to taking is inevitably a few minutes slower.
[cpg]


That's why she was ahead of me. ......
[cpg]

[free time=1000]

[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Shizuka030"]
[OnName num="shizuka"]
Welcome back, Shoya. Shoya."
[cpg cn=true]


[OnName num="shouya"]
"Eh,...... Shizuka,......?"
[cpg cn=true]


Ryoko holding my hand. The force with which she holds my hand grows stronger.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Ryoko029"]
[OnName num="ryoko"]
What are you ...... doing here?"
[cpg cn=true]


The first thing to do is to get a good look at the picture.
[cpg]


But the tone of his voice was trembling with anger. I am just scared.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Shizuka031"]
[OnName num="shizuka"]
See you later.
[cpg cn=true]


With that, Shizuka went back along the same path she had taken earlier.
[cpg]


It's crazy. Shizuka is crazy and Ryoko is a bit taken by her madness.
[cpg]


[OnName num="shouya"]
So I'll see you tomorrow at .......
[cpg cn=true]


[free time=1000]

I try to shake off Ryoko's hand. I was so excited to see her, but I didn't know what to do.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko030"]
[OnName num="ryoko"]
I'm sorry. Did I hurt you ......?
[cpg cn=true]


[OnName num="shouya"]
Just a little bit. But I'm fine.
[cpg cn=true]


I was so scared. I wonder if I should come to a conclusion soon.
[cpg]


But they're both pretty girls, I can't pick one. ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



[SE f="se011"]
;//【ＳＥ】『ドア閉まる』





And when I got home, I was bombarded with emails. I mean, they seemed to have been sent several times on the way, I hadn't noticed.
[cpg]


Today it was, "Why did you try to take a different road home?" Did you not want to see me?" Do you hate me now?" Or something like that.
[cpg]


I had no choice but to reply, "No, I don't.
[cpg]


[OnName num="shouya"]
I just said, "I'm in trouble with ......."
[cpg cn=true]


I know it's rude to say that I'm in trouble, but there's no other way to put it.
[cpg]


The first thing to do is to make sure that you have a good relationship with the person you are going to be talking to. I think it's a bad idea to keep it in this state.
[cpg]


But choosing one or the other would mean abandoning one or the other.
[cpg]


I think that would make the situation worse, and if I think about it even a little, I can't do it anymore.
[cpg]


If I choose Shizuka, Ryoko will be depressed.
[cpg]


If I choose Ryoko, Shizuka might do more than just text me.
[cpg]


Thinking about it, I feel like it would be better to choose Shizuka, but that would be like deciding who to go out with based on the disadvantages.
[cpg]


That is not a healthy love. No, to begin with, the idea of confessing to someone because I don't want to be in a shura is ......
[cpg]


As I think about all of this, I settle on one word: "indecisive.
[cpg]


I hate myself like that and I hate myself. But I can't change so easily.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





I had no choice but to go out to the city in the evening.
[cpg]


I thought I would go to a used bookstore to browse through some used books for a diversion, so I walked in that direction.
[cpg]


[OnName num="shouya"]
What's that?
[cpg cn=true]



;//ここで少し光希の立ち絵を表示してください　私服です


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]


It's the tarot card girl. Let's see... ...... Shimano-san, right?
[cpg]


I don't know what she's wearing. I wonder if that kind of dress is called Gothic Lolita.
[cpg]


She entered the game center. I somehow followed her figure.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ



[SE f="se002"]
;//【ＳＥ】『ゲームセンターの騒音』





I have never been in a game center before.
[cpg]


I've only been taken there by friends who are proud of their skills and say, "Wow, that's great. ......
[cpg]


I was stunned. I was stunned.
[cpg]



[VOICE f="Mituki001"]
[OnName num="mituki"]
"Fufu...... fufu."
[cpg cn=true]


Shimano-san's hand was moving too fast for me to see. The first thing that comes to mind is the fact that the first time you see a person in the same room, you know that you've seen him or her.
[cpg]


It seemed to transcend the level of skill. He was like a karuta (Japanese playing cards) master, moving through a large number of notes.
[cpg]


I couldn't bear to watch the scene, so I left.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************





[OnName num="shouya"]
I left the place because I couldn't bear to watch the spectacle.
[cpg cn=true]


She was somewhat mysterious, but I saw something human.
[cpg]


No, I wouldn't call that kind of thing human nature.
[cpg]


......I'll forget about it. Let's forget about it.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002"]
;//【ＳＥ】『雑踏』





The next day. I headed to the school as usual.
[cpg]


And by "as usual," I mean this.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Shizuka032"]
[OnName num="shizuka"]
The first thing to do is to make sure that you have a good time.　Do you like to play games?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Ryoko031"]
[OnName num="ryoko"]
I know all about that kind of thing. I'll teach you, Tojo-san.
[cpg cn=true]


The only thing is that there is no such thing as one on each arm today.
[cpg]


I can't stand to be there. The feeling of fighting is incredible.
[cpg]


Even in the conversation we had just had, I could tell that Shizuka was trying to get me. ......
[cpg]


I can also see that Ryoko is restraining Shizuka.
[cpg]


It's so hard. I wonder if there are any girls who can take a step back more like this.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ





And then it goes straight to class and I'm finally released.
[cpg]


The class is a time of repose, and I sometimes think it's the opposite of being a normal student.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





It was the end of the class. Around the entrance of the classroom, I heard a boy gossiping.
[cpg]


[OnName num="male_student_A"]
I asked him, "Is that for real ......?　It must be terrible to be told that.
[cpg cn=true]


[OnName num="male_student_B"]
I heard it's for real. They say that the seating order isn't good and that if they don't get their seats in the right order, bad things will happen. ......
[cpg cn=true]


[OnName num="male_student_B"]
I heard he even skipped class today, saying it would be bad luck to attend. You should stay away from them.
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（机にタロットカードを並べて占うヒロイン。真剣な表情）ev_03
;//人物１：ヒロイン３
;//服装１：制服
;//場所　：学園教室
;//時間　：昼
;//========================================




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="male_student_B"]
"Look, they're still lining up tarot ......, it's creepy."
[cpg cn=true]


Maybe it's Shimano-san.
[cpg]


[OnName num="male_student_A"]
"Hey Shimano,...... that's what you call a menshera.
[cpg cn=true]


[OnName num="male_student_B"]
He's a radio wave on top of being a mensch. It's so crazy it's hard to find a sane place."
[cpg cn=true]


[OnName num="shouya"]
"Don't do it. Don't talk behind his back.
[cpg cn=true]


[OnName num="male_student_A"]
What?　Who is it?
[cpg cn=true]


[OnName num="shouya"]
Just because he can't hear you doesn't mean you can't say anything.
[cpg cn=true]


[OnName num="male_student_B"]
"You have a crush on ...... Shimano?　That's very unusual.
[cpg cn=true]


[OnName num="shouya"]
I don't mean to be so specific, but... Even her fortune-telling might be right.
[cpg cn=true]


I was peeled off and said something like that. Then, she said.
[cpg]


[OnName num="male_student_A"]
"Then why don't you get your fortune read?　She'll be happy.
[cpg cn=true]


[OnName num="male_student_B"]
"Yes, yes. It would be much better for her than to stop talking behind her back.
[cpg cn=true]


I was pissed off at ...... and decided to do as I was told.
[cpg]


[OnName num="shouya"]
"Yeah, all right."
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Mituki002"]
[OnName num="mituki"]
"Oh, ah ...... ah, eh?"
[cpg cn=true]


I brought a chair in front of Shimano-san's desk and talked to her.
[cpg]


It may be too abrupt, but I was a little worked up about what had just happened.
[cpg]


[OnName num="shouya"]
I was a little nervous about what had just happened. I'm doing some fortune-telling right now, right?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki003"]
[OnName num="mituki"]
"Oh, ...... Ummm, yes. Yes, fortune-telling, fortune-telling, it's fortune-telling, so ......."
[cpg cn=true]


He looked at me, looked away, looked at me, looked away. That kind of attitude.
[cpg]


It's suspicious behavior. But since I told them that, I decided to have my fortune read.
[cpg]


[OnName num="shouya"]
I wanted to ask them to read my future. Do I need to know your name?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mituki004"]
[OnName num="mituki"]
Yes, I do. But it's our first meeting, so ......
[cpg cn=true]


[OnName num="shouya"]
Shoya Ichijo. Oh, should I write it in kanji?"
[cpg cn=true]


 While saying that it's okay, I bring the cards that were lined up on the desk to my hand.
[cpg]


I almost missed it many times. I guess I'm not used to boys. ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mituki005"]
[OnName num="mituki"]
"Kanji, I don't need it,......, it's okay, just wait a minute."
[cpg cn=true]


Saying that, he cuts the card. The shuffling was so awkward that it was hard to believe that it was the same person whose brilliant handiwork I had seen at the arcade one day.
[cpg]


And then he arranges the cards in some sort of order. The order of the cards seems to have a certain order, and it looks like a proper fortune-telling.
[cpg]


He flips through the cards, muttering something about the correct position and the reverse.
[cpg]


I can't tell which way the cards are facing, but I can tell which way the cards are facing.
[cpg]


I was looking at him, thinking, "If he were totally crazy, he wouldn't be able to do this. ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Mituki006"]
[OnName num="mituki"]
"Lies......, is this really true......?"
[cpg cn=true]


He is shaking a little and his face is turning blue.
[cpg]


I wonder what came out of it. I'd hate it if I had ten years to live or something.
[cpg]


[OnName num="shouya"]
What's wrong?　Did something ominous come up?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Mituki007"]
[OnName num="mituki"]
Wait, I'm going to change my fortune-telling.
[cpg cn=true]


He said, "Wait a minute, I'm going to change my fortune-telling method.
[cpg]


I don't know what the difference is because I don't remember the lineup earlier, but in the middle of flipping through the ...... cards.
[cpg]



[SE f="se012"]
;//【ＳＥ】『椅子から勢いよく立ち上がる　ガタン』





I was in the middle of flipping through the cards when Shimano-san suddenly got up from her chair. I was startled.
[cpg]


[OnName num="shouya"]
He said, "Are you okay with ......?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mituki008"]
[OnName num="mituki"]
"I'm fine ...... accepting, yeah, I know, I was."
[cpg cn=true]


[OnName num="shouya"]
So, how did it go?　Did you find out anything about me?
[cpg cn=true]


I can't hear the result of the fortune-telling. The face that was blue is now red.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mituki009"]
[OnName num="mituki"]
My blue face turned red. "Wow, my destiny is you, ......."
[cpg cn=true]


Then he returned to the first arrangement, looking at the pattern of the cards.
[cpg]


He explains to me about this circle of destiny and the lovers, but he talks too fast for me to understand.
[cpg]


[OnName num="shouya"]
I see. ......"
[cpg cn=true]


This does not seem to be her way of approaching me.
[cpg]


She was really surprised at the result of the reading.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Mituki010"]
[OnName num="mituki"]
The second time, I told her about Shoya's surroundings, and I was the closest to him.
[cpg cn=true]


He says, "I was the closest to you. I don't know what he means.
[cpg]


When I look back, the two boys are pulling away. Not laughing or making fun of them, but pulling away.
[cpg]



;//ＢＫ


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





It was lunch break after such an incident.
[cpg]


Shizuka and Ryoko are still sparking sparks.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuka033"]
[OnName num="shizuka"]
Shizuka is still gulping, "I'll make lunch tomorrow, so Shoya doesn't have to bring his lunch."
[cpg cn=true]


Shizuka is still coming on strong. Ryoko is watching from a distance in a completely different seat.
[cpg]


I'm glad Shimano-san isn't here. She thinks I'm the one for her, too, right?
[cpg]


If she were here, it would be one man and three women. That's not good.
[cpg]


It's too twisted. Is there such a thing as a quadrilateral relationship?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Shizuka034"]
[OnName num="shizuka"]
Are you listening to me?　Shoya, don't bring my lunch tomorrow.
[cpg cn=true]


[OnName num="shouya"]
Oh, yeah. Uh, yeah.
[cpg cn=true]


...... I wasn't listening for a second. No, there are some things I should make clear here.
[cpg]


[OnName num="shouya"]
Why does Shizuka keep coming on to me like this?
[cpg cn=true]


I don't know if I can put it this way. I could have asked him more softly.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Shizuka035"]
[OnName num="shizuka"]
"It's too early to say ...... that."
[cpg cn=true]


She fidgets and blushes. I'm sure he's thinking about me.
[cpg]


 Even so, I can't believe I'm so popular here.
[cpg]


I feel like I'm happy about it. Sorry Ryoko, but ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuka036"]
[OnName num="shizuka"]
Was I getting that close?　Was I bothering you?"
[cpg cn=true]


That's sometimes annoying, like the e-mail thing.
[cpg]


But there's no point in saying that. It's because of Shizuka's single-minded love for him.
[cpg]


[OnName num="shouya"]
I'm not annoyed. It's not annoying.
[cpg cn=true]


Ryoko is staring at me with her big eyes. But it can't be helped that Shizuka is cute.
[cpg]


She is not a bad girl at all. I sometimes feel that her affection is a bit heavy.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

And after school. We were going home.
[cpg]


Ryoko had already given up on the idea of going home by another route, so it was just me, Shizuka, and Ryoko.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Shizuka037"]
[OnName num="shizuka"]
Then let's go home.
[cpg cn=true]


[OnName num="shouya"]
Ummm, yeah...... you two, it's a bit close.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Ryoko032"]
[OnName num="ryoko"]
I'm not close. It's normal, isn't it?
[cpg cn=true]


I wonder if even ...... Ryoko is being inspired by Shizuka?
[cpg]


I think she's getting a little pushy.
[cpg]


Really, I'm glad Shimano-san isn't here.
[cpg]


I still don't get the idea of girls on both sides, but if there is one more person here, I really can't get over it.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





And after enjoying the man's dream of walking home with girls on both sides.
[cpg]

;//[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuka038"]
[OnName num="shizuka"]
See you later. See you at the school.
[cpg cn=true]


Ryoko looked at me with staring eyes. How should I answer her?
[cpg]

[OnName num="shouya"]
"Ummm, yeah. ...... See you later."
[cpg cn=true]


I thought that this kind of reply would be acceptable. I thought so, but Ryoko seemed to be in a bad mood.
[cpg]


[free time=1000]

I was so happy to see her.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ryoko033"]
[OnName num="ryoko"]
I said, "......I wonder why this happened. I know I'm annoying you too, Shoya."
[cpg cn=true]


[OnName num="shouya"]
'What's wrong all of a sudden?　It's not like that.
[cpg cn=true]


Even if it is annoying, I can't say it at this timing.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ryoko034"]
[OnName num="ryoko"]
'No, I'm sure it's annoying. ...... I'm not as beautiful as Tojo-san.'
[cpg cn=true]


Ryoko suddenly becomes weak. She looks somewhat depressed.
[cpg]


[OnName num="shouya"]
No, she's not. Ryoko is cute."
[cpg cn=true]


Ryoko's eyes light up with that comment. And then she turns to me.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Ryoko035"]
[OnName num="ryoko"]
She said, "I haven't heard such a word from Shoya in a long time.
[cpg cn=true]


And then she laughed softly and blushed.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ





 After that exchange, Ryoko and I parted ways and went back to our respective homes.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="shouya"]
I'm tired ......."
[cpg cn=true]


I can't help but think they're cute. Both of you.
[cpg]


More to the point, even Shimano-san is not without her cuteness. I don't have any contact with her at the moment, though.
[cpg]


But I'm afraid something might happen soon.
[cpg]


[jump storage="ep001.ks" target="*start"]

