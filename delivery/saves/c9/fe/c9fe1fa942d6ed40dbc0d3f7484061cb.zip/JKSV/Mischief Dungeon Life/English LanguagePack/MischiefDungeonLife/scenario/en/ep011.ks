*start

;###################################################################
*Ep011|The breadth of transformation is the breadth of mischief
;###################################################################


[SCENE id=11]


[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]
[BG f="black.ui"  time=1000]
[WAIT time=100]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





Demons can be disguised as demons. I can be transformed into a human being. But you can't turn into something that doesn't exist.
[cpg]


If we can overcome this, it will be a big step forward.
[cpg]


Not only will you be able to play the role of a nuisance, but you will also be able to expand your tactical skills.
[cpg]


[OnName num="renzi"]
I don't know about .......
[cpg cn=true]


To transform into something that is not there also means to re-create within oneself the structure of a living being.
[cpg]


Until now, I could not breathe fire when transformed into a dragon, nor could I control water when transformed into an undine.
[cpg]


[OnName num="renzi"]
But you can copy the mechanisms of muscles and so on. ......
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha135"]
[OnName num="asha"]
What's wrong? Talking to yourself?"
[cpg cn=true]


[OnName num="renzi"]
Asha. Is the cafeteria okay?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha136"]
[OnName num="asha"]
I'm off today. Renji seems to be free every day, doesn't he?"
[cpg cn=true]


I've been exempted from the watch and such in recognition of my work.
[cpg]


That doesn't mean I don't get taunted by other demons.
[cpg]


Capturing Kulara was such a big deal.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





I was going to expand on the mischief I had been doing.
[cpg]


But I still couldn't get more things to turn into monsters.
[cpg]


The rule that only things that know how to smell can turn into monsters remained unchanged.
[cpg]


Once I thought that was enough.
[cpg]


A safe life is guaranteed for a while. I'd done that much.
[cpg]


Then, could I continue to live the way I wanted to while playing tricks on someone else?
[cpg]


With this thought in mind, I walked down the aisle, probably at night.
[cpg]



[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト

Somehow I feel lonely being alone. It's not that I'm ...... at a time like this, but ......
[cpg]


I want to go to Asha's. I know she is always lonely.
[cpg]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





I approached Asha's place as the frog I was sometime ago.
[cpg]


I wouldn't confide my loneliness to an intelligent demon.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Arsha138"]
[OnName num="asha"]
'What ......?　How did you get here ......"
[cpg cn=true]


Now demons like me don't usually make it into the bedroom.
[cpg]


There are several doors on the way. So I'm just saying it's not possible. ......
[cpg]


Asha gulps and spits. I think she wants help from whoever or whatever it is.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha139"]
[OnName num="asha"]
'I think I've seen something like this ...... before, maybe.
[cpg cn=true]


I almost noticed, but Asha shook her head.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="sArsha012"]
[OnName num="asha"]
'Well, okay. You miss me too."
[cpg cn=true]

;//ブラックアウト

[SE f=se012]
;//【ＳＥ】『衣擦れ』

Asha pats my head. My loneliness was being soothed along with her.
[cpg]

;//移植前シーンカット


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************

As expected of a demon, I would not raise a thing in the form of a frog to my bed.
[cpg]


Without going so far as to sleep with her, I silently left the room. I say shut up, but I can't talk.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


I go back to the passage and take on the form of a person.
[cpg]


I have to do something about Asha.
[cpg]


She's prone to falling in love, right? I get the feeling that she doesn't want to be in love.
[cpg]


All I can do is what I just did. ......
[cpg]


I knew I couldn't leave her alone after seeing her sad face like that.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





I go back to my bedroom. A hazy feeling of being lost spreads over me.
[cpg]


Even though we are all demons, we all have our own circumstances.
[cpg]


I don't know if I should be happy that Dorothy seems to like me.
[cpg]


I'm not in a situation where I can call it a harem, and I'm not doing anything to her face.
[cpg]


I felt like I was not left out.
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[SE f=se008]
;//【ＳＥ】『喧噪』


The next day, I was hungry and headed down to the cafeteria.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Arsha162"]
[OnName num="asha"]
I said, "Good morning. Renji."
[cpg cn=true]


Asha is smiling as if yesterday never happened.
[cpg]



[FACE method="change_7" pos="2/5"]

[VOICE f="Janice118"]
[OnName num="janice"]
What's wrong? Don't you return my greeting?"
[cpg cn=true]


[OnName num="renzi"]
No, no. Good morning."
[cpg cn=true]


I didn't know how much Asha was aware of what was going on, so I couldn't say anything.
[cpg]


Would she comfort herself again this evening?
[cpg]


She certainly said she was lonely. I wanted to fill the void in her heart, even if I had to disguise myself in a way that she wouldn't recognize me.
[cpg]


[FACE method="feadin_up" pos="4/7"]

;//ブラックアウト





Asha has been a great help to me.
[cpg]


Or should I say, I am still indebted to her?
[cpg]


I had Kulara. It could be said that Asha cooks the meals and they are just doing their respective jobs.
[cpg]


Still, I don't think we can say we are strangers anymore.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/5" time=1]
[FO pos="4/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FACE method="out" pos="4/7"]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


;**【ＣＧ】ci_14_0 ***********************
;//カットイン
[CUTIN f="ci_14_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


That day, too, I head near her room. I didn't go there in the form of a frog, but in the form of a cat.
[cpg]

[CUTIN f="ci_14_0.ui" show={false} method="slideout"]
[WAIT time=1000]

Today, too, the door is slightly open. It seems as if she is waiting for something.
[cpg]


Perhaps she is waiting for me. I have a feeling that she is waiting for me.
[cpg]


Still, I wondered whether I should enter her room or not. After two days in a row, it was as if she was already saying it was me.
[cpg]


While I was hesitating, my eyes met Asha's through the door.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Arsha163"]
[OnName num="asha"]
I looked at her and said, "...... you came to comfort me, too."
[cpg cn=true]


I can't back down now. I want to soothe Asha's loneliness.
[cpg]



[SE f=se012]
;//【ＳＥ】『衣擦れ』
[FACE method="feadin_up" pos="4/7"]

[FG f="CHA04_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

[WAIT time=1000]

;//ブラックアウト


[FACE method="change_6" pos="2/3"]

[VOICE f="sArsha013"]
[OnName num="asha"]
I'm a beast of the ...... rabbit tribe, so I'm easy to fall in love with."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[VOICE f="sArsha014"]
[OnName num="asha"]
Even if I don't look like a person, I'm the same ...... as you."
[cpg cn=true]


She began to explain little by little. I know I'm talking to myself right now, but this is the first time I've heard it properly.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="sArsha015"]
[OnName num="asha"]
The truth is, ...... there's only one person I want to like."
[cpg cn=true]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





As it was, we stayed together until Asha fell asleep.
[cpg]


This time she let me stay with her until just before she fell asleep.
[cpg]


I hope Asha can meet someone good too. ...... Maybe that's me?
[cpg]


Come to think of it, he also said there was only one person he wanted to like.
[cpg]


But that is indeed not the case. ......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


I make my way back to my room via the passageway.
[cpg]


It was hard to move around dressed as a cat forever, so I was back in human form.
[cpg]


[OnName num="renzi"]
I went to ......"
[cpg cn=true]


But it's a troubling story. It would be hard for Asha to stay like that forever.
[cpg]


That said, I wasn't sure I wanted to be tied to any one person right now.
[cpg]


[SE f=se009]
;//【ＳＥ】『歩く』

[BG f="b_03_5.ui" time=1500]
[WAIT time=1500]
;//ブラックアウト


[SE f=se012]
;//【ＳＥ】『衣擦れ』


I went back to my room and lay down on my bed.
[cpg]


After all, I want to play pranks on girls for a while.
[cpg]


This was not limited to Asha.
[cpg]


There were many things that Kulara hadn't done yet.
[cpg]



[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』

After much thought, I knew I wanted to broaden my transformation.
[cpg]


I can't transform into something I've never seen before. Then I would have to see a variety of creatures.
[cpg]


And it was also important for me to know what they smelled like.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[SE f=se008]
;//【ＳＥ】『喧噪』


I don't know who I can talk to about this.
[cpg]


Dorothy knows I'm playing a trick on her without telling her, and Janice knows I'm playing a trick on her and refuses to do it.
[cpg]


So I guess I should ...... talk to Asha now. I feel like I'm about to find out a lot of things.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha183"]
[OnName num="asha"]
'The breadth of the transformation......?　That's a hard thing to say. I guess you just have to look at all kinds of creatures, don't you?"
[cpg cn=true]


[OnName num="renzi"]
I knew it.
[cpg cn=true]


Same thing I'm thinking. But I don't know much about demons.
[cpg]


[OnName num="renzi"]
"Is there any demon that could be useful if it could turn into this?"
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Arsha184"]
[OnName num="asha"]
I don't know. ......
[cpg cn=true]


Asha seemed to have an idea.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha185"]
[OnName num="asha"]
I'm sure he's around here somewhere. ......
[cpg cn=true]


Asha took me to a place that looked like some kind of treasure chest.
[cpg]


[OnName num="renzi"]
I asked her, "...... is this the demon?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Arsha186"]
[OnName num="asha"]
Yes," he said. It's called a mimic, and I think it's a relative of the shapeshifter."
[cpg cn=true]


...... I see. A mimic.
[cpg]


A mimic probably can't turn into a living thing, but a mimic could turn into an inorganic object.
[cpg]


It may be able to turn into something non-living via this.
[cpg]


Approaching the mimic. Anyway, we need to know what it smells like.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha187"]
[OnName num="asha"]
It's tough when you can't turn into something unless you know what it smells like."
[cpg cn=true]


[OnName num="renzi"]
Well, ...... that's true."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sArsha016"]
[OnName num="asha"]
Renji smelling the mimic, it's kind of a little suspicious.
[cpg cn=true]


Maybe so, but it's a process that can't be helped. ......
[cpg]


[OnName num="renzi"]
I don't want Asha telling me what to do."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Arsha189"]
[OnName num="asha"]
What?　What? Why?
[cpg cn=true]


Asha has such a reaction. Don't you realize that it was me who had just done that?
[cpg]

If so, I may have said something unnecessary: ......
[cpg]

[FACE method="change_1" pos="2/3"]


;//ブラックアウト

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_16_0 ***********************
;//カットイン
[CUTIN f="ci_16_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

That's how I was able to turn into a mimic.
[cpg]

[CUTIN f="ci_16_0.ui" show={false} method="slideout"]
[WAIT time=1000]

I can even transform myself into another inorganic object while in the mimic state.
[cpg]


Of course, mimics cannot transform into living things like I can.
[cpg]


On the other hand, I have never been able to transform into anything. Being able to transform into a mimic has broadened the scope of my transformation.
[cpg]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



Being able to transform into an inorganic object means that I can also transform into clothing.
[cpg]


The first prank I came up with was to become someone's clothes.
[cpg]


It might be a little too bizarre to be anyone's dream ......, but I at least wanted to try it.
[cpg]


Asha was different as a partner. It's a little too lukewarm to be Asha.
[cpg]


It's also different to do it to Janice. She is more the type of person who is fun to scare.
[cpg]


Then the person to do it to is ......
[cpg]



[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[FACE method="out" pos="4/7"]


[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="04"]


;//ブラックアウト


Dorothy. I snuck into her room first, just as she was getting out of the bath.
[cpg]


[SE f=se009]
;//【ＳＥ】『歩く』

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Dorothy121"]
[OnName num="dorothy"]
She said, "Phew. Good hot water again today."
[cpg cn=true]


;//移植前シーンカット


She quickly finishes changing her clothes while I'm still waiting for her to finish. I was actually going to be her clothes.
[cpg]


What the hell, why don't I just become the blanket she's wearing?
[cpg]


That's what I thought, and I turn into a blanket. I can be in close contact with her and not be discovered.
[cpg]


;//移植前シーンカット

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[STOPBGM]


And so it went. The next day Dorothy was at ......
[cpg]



[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy163"]
[OnName num="dorothy"]
Renji ...... good morning."
[cpg cn=true]


His expression was kind of dark.
[cpg]


[OnName num="renzi"]
He said, "Good morning. What's up?"
[cpg cn=true]




[FACE method="change_7" pos="2/3"]
[VOICE f="sDorothy002"]
[OnName num="dorothy"]
Yes. I had a weird dream. The futon felt heavy.
[cpg cn=true]


[OnName num="renzi"]
Oh. ......"
[cpg cn=true]


I was feeling somewhat guilty, pretending not to know.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/5" time=800]

[OnName num="rudolf"]
I hear there's more stuff you can transform into again.
[cpg cn=true]


[OnName num="renzi"]
Yeah. Since I turned into a mimic, I can turn into things."
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[VOICE f="Janice119"]
[OnName num="janice"]
'Is that right ......?　I guess you can turn into anything now."
[cpg cn=true]


[OnName num="renzi"]
No, that's not true. You can't turn into something that doesn't exist.
[cpg cn=true]


[OnName num="rudolf"]
Your potential is immeasurable. As is the fact that you captured Clara. ......"
[cpg cn=true]


[OnName num="rudolf"]
I believe it is possible not only to end this battle, but even to win this battle."
[cpg cn=true]


[OnName num="renzi"]
'...... is too much to buy into. But thank you."
[cpg cn=true]


[OnName num="rudolf"]
I'm not buying it." If only you were a little more serious."
[cpg cn=true]


It seemed that the Demon Lord could see what I was doing.
[cpg]


Should I be a little more self-conscious? But I have no intention of stopping.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokie1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



Since then, I have tried all sorts of pranks.
[cpg]


The pranks in which I disguised myself as an object were unexpected by the girls, and they never found out that it was me.
[cpg]


On the other hand, I began to feel as if I was not satisfied with just pranks.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha190"]
[OnName num="asha"]
What's wrong, look so difficult."
[cpg cn=true]


[OnName num="renzi"]
No. ...... just thinking about what we're going to do."
[cpg cn=true]


It has already come true, going around playing pranks on girls.
[cpg]


But I was also thinking like this is not the end.
[cpg]

[move from="2/3" to="4/5" ease="easeInOutSine" time=1000]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/5" time=1000]
[VOICE f="Janice120"]
[OnName num="janice"]
Wind ......"
[cpg cn=true]


[FACE method="change_2" pos="4/5"]
[VOICE f="Arsha191"]
[OnName num="asha"]
Oh, Janice. Good work."
[cpg cn=true]


[FACE method="change_1" pos="2/5"]
[VOICE f="Janice121"]
[OnName num="janice"]
'Not at all,' he said. That Kulara seems to be quite tight-lipped. Or maybe he has nothing to hide anymore.
[cpg cn=true]


[OnName num="renzi"]
In that case, I'll help you.
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Janice122"]
[OnName num="janice"]
...... Renji's eyes really light up at times like this."
[cpg cn=true]


[OnName num="renzi"]
Oh, yeah?"
[cpg cn=true]


You can't hide your human nature. Janice, for example, may be very good at that.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/5" time=1]
[FO pos="4/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


So Janice and I decided to go to Kulara's place together.
[cpg]



;//俺はもう人間の姿をしてない。これからやる尋問に使う、ある道具に変身していた。[cpg]
;//ブラックアウト



[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]

[VOICE f="Janice123"]
[OnName num="janice"]
"Kulara. You have a defiant look in your eyes today.
[cpg cn=true]



[VOICE f="Clara074"]
[OnName num="clara"]
It's ...... obvious."
[cpg cn=true]

With a high-handed expression, Janice told Klara.
[cpg]


I said I'd help, but I couldn't do anything. Because ......
[cpg]


In any case, Kulara would not talk. She didn't even say anything she didn't want to anymore.
[cpg]


It was as if Janice would snap first. Even I was thinking, "Thank God Janice is not a cruel person.
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]
[FO pos="1/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice131"]
[OnName num="janice"]
How's it going?　Clara must be pretty stubborn."
[cpg cn=true]


[OnName num="renzi"]
...... yeah."
[cpg cn=true]


Still, ...... Janice's interrogation was more tame than I expected.
[cpg]


I had previously thought that Janice would certainly interrogate Kulara without hesitation, but ......
[cpg]


Surprisingly, it was not so. I have pretty strong feelings of sympathy and such.
[cpg]


I unexpectedly came in contact with Janice's gentle side and thought she was kind of cute.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************

[SE f=se008]
;//【ＳＥ】『喧噪』



I went back to the dining room to get some food.
[cpg]


Dorothy was there. She saw us and waved.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy166"]
[OnName num="dorothy"]
Renji, you've been dressed as a person for a long time now.
[cpg cn=true]


[OnName num="renzi"]
That's because they used to be people."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]f
[VOICE f="Dorothy167"]
[OnName num="dorothy"]
You'd be surprised at everyone in the dungeon. They might be used to it by now, though."
[cpg cn=true]


Indeed, there have been times when I was mistaken for an intruder and almost attacked.
[cpg]


However, if push came to shove, all I had to do was untransform myself.
[cpg]


More than that, I was taking the ease of spending time there.
[cpg]


[FO pos="2/3" time=1000]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/5" time=1000]
[VOICE f="Janice132"]
[OnName num="janice"]
Princess, it's Kulara, but she's ...... stubborn."
[cpg cn=true]


The story you told me is now going to be told to Dorothy.
[cpg]


[FACE method="change_1" pos="2/5"]
[VOICE f="Janice133"]
[OnName num="janice"]
'I don't know if I can get anything out of her if I interrogate her any further.
[cpg cn=true]


[FACE method="change_2" pos="4/5"]
[VOICE f="Dorothy168"]
[OnName num="dorothy"]
Do you want me to do it?　I think I'm good at that kind of thing."
[cpg cn=true]


It's happened before. Dorothy would really be relentless.
[cpg]


[OnName num="renzi"]
No, no. I'll do it.
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Dorothy169"]
[OnName num="dorothy"]
I see. I don't care either way, but if you're going to do it, do it thoroughly.
[cpg cn=true]


Dorothy's fear oozes out fully in that one word.
[cpg]


If I let her interrogate Kulara, she might kill him.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





Another day is about to pass. I'm exempted from guard duty, so my day is getting awfully long.
[cpg]


That's why I'm playing a prank on someone...but ......
[cpg]


I have noticed something. A definite drawback of this method of pranks.
[cpg]


Even if I can get close to these women without them noticing, it does not lead to a relationship beyond that.
[cpg]


Rather, I was beginning to think that this was not the way to go, as I kept repeating the same thing before the real thing.
[cpg]



[window target=false]
[BG f="b_03_5.ui" time=1000]
[WAIT time=1500]
[window target=true]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





As long as she doesn't realize it's me, nothing more will happen.
[cpg]


But it is also against my principles to forcefully attack them.
[cpg]


When I think about whether that's what I want to do, I think it's not.
[cpg]


[SE f=se002]
;//【ＳＥ】『ベッドに倒れ込む』

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト




I was kind of at a dead end.
[cpg]


It's not enough to just do whatever I want. I had to make use of it for someone else.
[cpg]




[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





The next day. I saw Janice in the aisle.
[cpg]


She seemed to be thinking about something and didn't say hello when I passed her.
[cpg]


She's a lovely person, ...... she's a lovely person, too. I unexpectedly saw a cute side of her, or so I thought.
[cpg]


She was not cold hearted towards Kulara. I thought she was the kind of person who does everything with calculation.
[cpg]


I felt like doing something about it, so I took on a different form once again.
[cpg]

[window target=false]


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[BG f="white.ui" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

[STOPBGM]

;//ブラックアウト

[BG f="black.ui" time=1000]
[WAIT time=1500]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Janice134"]
[OnName num="janice"]
I said to myself, "...... puppy?　Why are you here, so deep in the dungeon?"
[cpg cn=true]

;**【ＣＧ】ci_17_0 ***********************
;//カットイン
[CUTIN f="ci_17_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

I appeared before Janice in the form of a puppy.
[cpg]

[CUTIN f="ci_17_0.ui" show={false} method="slideout"]
[WAIT time=1000]

As I approached her, her face turned a little softer from the thoughtful expression she had earlier.
[cpg]



[FACE method="change_1" pos="2/3"]
[VOICE f="Janice135"]
[OnName num="janice"]
She looked a little softer than her earlier thoughtful expression. Is she someone's pet?"
[cpg cn=true]


Janice pats my head. I pretend to be pleased.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Janice136"]
[OnName num="janice"]
'Okay, okay, ......, he's a cute guy.'
[cpg cn=true]


I still feel somewhat empty.
[cpg]


She thinks I'm cute, not the puppy.
[cpg]


It was a dilemma created by the fact that I could transform.
[cpg]


[SE f=se012]
;//【ＳＥ】『衣擦れ』


I wanted to do something for someone, to be liked, and I made it happen, but it wasn't me who was being liked.
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="sJanice006"]
[OnName num="janice"]
I'm not the one being liked. Where are you going?
[cpg cn=true]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





The emptiness is only growing. I run down the aisle.
[cpg]


When Janice is out of sight, I return to my human form.
[cpg]


[OnName num="renzi"]
......"
[cpg cn=true]


What do I want to do? It's time to make it clear.
[cpg]



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="ep012.ks" target="*start"]


