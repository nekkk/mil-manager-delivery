
*start


;//異世界変態生活　シナリオ
;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//クラーラ　　　　裸　下着　私服　軽装の鎧
;//ドロシー　　　　裸　下着　着衣
;//ジャニス　　　　裸　下着　私服　鎧
;//アーシャ　　　　裸　下着　着衣
;//サツキ　　　　　裸　下着　着衣

;//上記以外のキャラクターには音声がありません

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//クラーラ　　　　一人称「私（わたし）」　ドロシー呼び「ドロシー」　ジャニス呼び「ジャニス」
;//　　　　　　　　アーシャ呼び「アーシャ」　サツキ呼び「サツキ」　蓮司呼び「蓮司」
;//ドロシー　　　　一人称「あたし」　クラーラ呼び「クラーラ」　ジャニス呼び「ジャニス」
;//　　　　　　　　アーシャ呼び「アーシャ」　サツキ呼び「サツキ」　蓮司呼び「蓮司」
;//ジャニス　　　　一人称「私（わたし）」　クラーラ呼び「クラーラ」　ドロシー呼び「姫様」
;//　　　　　　　　アーシャ呼び「アーシャ」　サツキ呼び「サツキ」　蓮司呼び「蓮司」
;//アーシャ　　　　一人称「私（わたし）」　クラーラ呼び「クラーラ」　ドロシー呼び「ドロシー」
;//　　　　　　　　ジャニス呼び「ジャニス」　サツキ呼び「サツキ」　蓮司呼び「蓮司」
;//サツキ　　　　　一人称「私（わたし）」　クラーラ呼び「クラーラさん」　ドロシー呼び「ドロシーさん」
;//　　　　　　　　ジャニス呼び「ジャニスさん」　アーシャ呼び「アーシャさん」　蓮司呼び「蓮司」

;//蓮司　　　　　　一人称「俺」　クラーラ呼び「クラーラ」　ドロシー呼び「ドロシー」
;//　　　　　　　　ジャニス呼び「ジャニス」　アーシャ呼び「アーシャ」　サツキ呼び「サツキ」
;//　　　　　　　　ただし、物語序盤ではさん付けあるいはちゃん付けで呼ぶ

;//クラーラルートの一部では、蓮司は「ハリー」と偽名を使う
;//その間蓮司はクラーラを「クラーラさん」と呼び　クラーラは蓮司を「ハリーさん」と呼ぶ


;//////////////////////////////////////
;///////////////以下本編///////////////
;//////////////////////////////////////

;###################################################################
*Ep000|Transformation.
;###################################################################


[SCENE id=0]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]
[STOPBGM]


[stflag Cha1flg = 1]
[stflag Cha2flg = 1]
[stflag Cha3flg = 1]
[stflag Cha4flg = 1]
[stflag Cha5flg = 1]

[stflag Gameflg = 0]

[stflag Jumpflg = 1]


[BG f="black.ui"  time=1000]
[WAIT time=100]
[WAIT time=100]
;//ブラックアウト




I think someone somewhere compared a story in which the protagonist is reincarnated in another world to Kafka's "metamorphosis.
[cpg]


I kind of know the feeling too. I know what you mean: ......
[cpg]


I didn't expect to be reincarnated and then further transformed again.
[cpg]




[window target=false]

[WAIT time=1000]

[BGM f="04"]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="04"]
[window target=true]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





A student living in the modern world. A student who is too ordinary to have anything to say.
[cpg]


I don't have a girlfriend, but I have a few friends. No inconvenience, but not too much freedom either.
[cpg]


Generally, neither happy nor unhappy...that's the kind of life ......
[cpg]


What a view, that's not what I think while looking at such a view.
[cpg]


[OnName num="renzi"]
"......"
[cpg cn=true]


Renji Haramura. I don't remember exactly what happened and how it happened.
[cpg]


It appears to be somewhere underground, like a dungeon.
[cpg]


I was supposed to have been hit by a car while protecting a cat, but the cat I was supposed to have protected was not there either.
[cpg]


And most importantly, even if I tried to get up, I couldn't do it.
[cpg]


I don't know where is my leg and where is my hand. Still, I had the sensation of being able to move.
[cpg]


I see myself. I had some idea of what I looked like, but I didn't know what I looked like. ......
[cpg]

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

;//レターボックスin
[FACE method="feadin" pos="4/7"]

[BG f="b_04_5_up.ui" time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_01_1 ***********************
;//カットイン
[CUTIN f="ci_01_1.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

Arguably, it was a snake. It was no ordinary snake.
[cpg]


A student living in the modern age. I don't know if there is such a thing as being hit by a car and reincarnated.
[cpg]


It is quite possible that this is a dream I am having.
[cpg]



It could be that the real me is in a coma in a hospital.
[cpg]


But what was strange about it was my appearance.
[cpg]


Snakes, snakes ...... are not that much of an obsession for me.
[cpg]


[CUTIN f="ci_01_1.ui" show={false} method="feadout"]
;//[WAIT time=1000]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』
[WAIT time=1000]

[window target=true]

Everything felt awfully real to confirm that it wasn't a dream.
[cpg]


No legs. No hands. Yet I knew how to move my body to move forward.
[cpg]


And I don't feel any discomfort. The sense of touch is there, too.
[cpg]


[OnName num="renzi"]
......
[cpg cn=true]


Even if I wanted to talk to myself, I have no vocal cords and cannot speak.
[cpg]


I crawled along the passageway, not knowing what had happened to me, until I found a steep staircase in the middle of the passage.
[cpg]


I couldn't go any further. At least, not in my current state.
[cpg]

;//レターボックスout
[FACE method="feadout" pos="4/7"]


[SE f="se007"]
;//【ＳＥ】『ゴーレム足音』

[WAIT time=2000]

;**【ＣＧ】ci_02_0 ***********************
;//カットイン
[CUTIN f="ci_02_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


As I was thinking this, a large stone doll, about two meters in height, like a golem, passed by me.
[cpg]


It was like a "Oh, it's a demon.
[cpg]


I wasn't really surprised because I looked like this. And they were not surprised either.
[cpg]


The golem didn't care if it saw me.
[cpg]

[CUTIN f="ci_02_0.ui" show={false} method="slideout"]
[WAIT time=1000]



I wonder if a demon looking at a demon is like a person looking at a person. ......
[cpg]


We can't go on like this. As I stared at the golem moving away from me, I wondered if I could do something about it.
[cpg]

[SE f=se001]
;//【ＳＥ】『変身音　リバースシンバル』

[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_02_0 ***********************
;//カットイン
[CUTIN f="ci_02_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


I prayed. I thought, and ...... found that the structure of my body was changing.
[cpg]


The only thing that triggered it was that I wanted to go up the stairs.
[cpg]


That was all it took, and I was no longer in the form of a snake.
[cpg]


Transformation. It is possible to be reincarnated in another world and take on a different form, but ......
[cpg]


How is it possible to take on another form from there further?
[cpg]


No, what has happened has happened. I had gotten my legs now, so I continued on to the end of the stairs.
[cpg]


[SE f="se007"]
;//【ＳＥ】『ゴーレム足音』


[CUTIN f="ci_02_0.ui" show={false} method="slideout"]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



My body was heavy. I walked slowly, but I couldn't go fast.
[cpg]


Step by step, the number of demons increased. Goblins, orcs, and the other golems were the same ones that didn't pay attention when they saw me.
[cpg]


As I went deeper into the dungeon, I found a slightly open area.
[cpg]


[window target=false]

[STOPBGM]
[transition target={true} rule="tobira2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=1]
[WAIT time=100]
[transition target={false} rule="tobira2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[BGM f="02"]


[SE f="se008"]
;//【ＳＥ】『喧噪』

[window target=true]

There was a place that could be called a headquarters, or something like that.
[cpg]


A large desk and many chairs. And when I looked at the food on the table, it looked more like a cafeteria than a base.
[cpg]


There, demons of various races gathered, and the food was served by demons who also cooked.
[cpg]


It was a strange sight, but I guess demons can't afford not to eat anything.
[cpg]


[OnName num="renzi"]
"(Come to think of it, I'm hungry. ......)"
[cpg cn=true]


If I asked, I might get something, but it's a golem, so it can't speak.
[cpg]


But I was too hungry, so I decided to join them.
[cpg]


I was not sure if it was okay for me to join them now, but I couldn't help myself.
[cpg]


;//ここから暫くアーシャの名前をunknownと隠してください


[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha001"]
[OnName num="unknown"]
It's rare to see a golem in a diner. What can I get you?
[cpg cn=true]


A beastman, rabbit-like, is looking at us.
[cpg]


[OnName num="renzi"]
......."
[cpg cn=true]


I can't reply to anything. After all, I have no mouth.
[cpg]


If I don't have a mouth, does that mean I can't eat? You also said it was unusual for a golem to come to the cafeteria.
[cpg]


I nodded silently. I thought that would be enough to get the message across.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha002"]
[OnName num="unknown"]
I'll leave it to you. I mean, do golems eat rice?"
[cpg cn=true]


The beastman said this and then pointed to his seat.
[cpg]


I wondered if it was natural for him to cook for someone he didn't know if he would eat rice or not. ......
[cpg]

Now I can't even get a lucky break.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Arsha003"]
[OnName num="unknown"]
I can't even make a comment right now. I'll bring it right over."
[cpg cn=true]


[SE f="se007"]
;//【ＳＥ】『ゴーレム足音』


[FO pos="2/3" time=2000]

;//レターボックスin
[FACE method="feadin_up" pos="4/7"]

So he said, and I went to my seat.
[cpg]


I thought the chair was going to break, I'm probably heavier than I am now. ......
[cpg]


It was a sturdy chair, as if it was designed for that kind of thing.
[cpg]


;//ブラックアウト

But a dining room in a dungeon?
[cpg]


I wonder how they use fire. It has to let air through, doesn't it?
[cpg]


I mean, what are they doing with the ingredients?
[cpg]


Vegetables may be grown by magic or something, but would they raise livestock? ......
[cpg]


The questions were endless, but anyway, I had my hands full with my own hunger right now.
[cpg]

[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


[FG f="CHA04_p1_01_a.ui" method="change_2"  pos="2/3" time=1000]
[VOICE f="Arsha004"]
[OnName num="unknown"]
'Here you go. Somehow I figured you wouldn't eat meat, so I decided on a salad set."
[cpg cn=true]



[SE f=se011]
;//【ＳＥ】『食器の音』


I'm sure you're right, I can't imagine what it would be like for a golem to eat meat.
[cpg]


On the other hand, I can't say if it would eat vegetables.
[cpg]


I think the original golem probably doesn't eat rice, but I wanted to eat it.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha005"]
[OnName num="unknown"]
I was like, "...... what's wrong, you don't want to eat it?　You came here, which means you want something to eat."
[cpg cn=true]

Bread and salad are placed in a bowl and placed in front of you.
[cpg]

I agree. I want to eat. But I don't have a mouth.
[cpg]


I have the senses of sight, hearing, smell, and touch, even though I am a golem.
[cpg]


The only thing it doesn't have is the sense of taste. After all, it has no mouth.
[cpg]


Without a mouth, it is impossible to eat. How does the golem get nourishment?
[cpg]


Or does the original golem not need to eat? ......
[cpg]


Then, I guess I am not able to imitate the mechanism of a golem itself, even though I am now transformed into a golem.
[cpg]

[FO pos="2/3" time=1000]


I look next to me. The goblin is eating something, a meat dish, roughly.
[cpg]


I'm thinking to myself, "Even though he's a demon, he uses eating utensils," but that's not what I should be looking at right now.
[cpg]


It would be good if he transformed into a goblin. At least he has a mouth.
[cpg]


I think, and I try to remind myself the same as before, but ......
[cpg]


[OnName num="renzi"]
"......"
[cpg cn=true]


I can't transform. I don't know what is different.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha006"]
[OnName num="unknown"]
If you don't eat it, I'll turn it down, okay?"
[cpg cn=true]



The rabbit beastman approaches me. It was so close that I could smell it.
[cpg]


I've never had a girl come this close to me before. I guess she doesn't care that I'm a golem, I thought. ......
[cpg]


I knew what it smelled like. It smelled like a combination of vanilla and soap.
[cpg]


Somehow, it was a scent I wanted to remember.
[cpg]


Still, even though I am a golem, I have a sense of smell. I had always had sight and hearing, right?
[cpg]



It suddenly occurred to me that I should try to transform myself into the beastman.
[cpg]


I don't know why I thought so. But I somehow thought that I could transform better than the goblin next to me.
[cpg]

[STOPBGM]

[SE f=se001]
;//【ＳＥ】『変身音　リバースシンバルのような音』
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

;//レターボックスout
[FACE method="out" pos="4/7"]

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/5" time=1]
[FG f="CHA04_p4_01_a.ui" method="change_7"  pos="4/5" time=1]

[WAIT time=100]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


And then the structure of his body changed again. It was neither a snake nor a golem, but a beastman.
[cpg]

[BGM f="02"]
[SE f="se008"]
;//【ＳＥ】『喧噪』

[OnName num="goblins"]
Whoa!　Hey, what the hell are you?
[cpg cn=true]


The surroundings are buzzing. It was just a transformation, but it seemed unusual.
[cpg]



[FACE method="change_1" pos="2/5"]
[VOICE f="Arsha007"]
[OnName num="unknown"]
I was surprised. ...... You are a shapeshifter, aren't you?
[cpg cn=true]


[OnName num="goblins"]
I didn't know there were still survivors. Where did you come from?"
[cpg cn=true]


I can reply, or I can now. But more than that: ......
[cpg]

[FO pos="2/5" time=1000]
[FO pos="4/5" time=1000]

[SE f=se011]
;//【ＳＥ】『食器の音』

;//レターボックスin
[FACE method="feadin" pos="4/7"]

I decided to get my hands on the meal in front of me.
[cpg]


The demons are looking at me and talking about this and that, but I don't care.
[cpg]


[OnName num="goblins"]
They must have been really hungry ......, but I didn't know there were shapeshifters in this dungeon.
[cpg cn=true]


The voices that spoke in a raspy tone were generally what you would expect from me, and that's about it.
[cpg]


In fact, there were even demons who came up to me and tried to talk directly to me.
[cpg]


[OnName num="orc_A"]
I heard you're a shapeshifter.　You really look just like Asha."
[cpg cn=true]



;//ここからアーシャの名前を隠さないでください



[OnName num="orc_B"]
It's true, ...... if you can transform so closely, you'll have a lot of maneuvering to do."
[cpg cn=true]

[stopse g=3]
;//通常se

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト


;//レターボックスout
[FACE method="out" pos="4/7"]


According to the story, shapeshifters are a race that once made great contributions to the demon tribe.
[cpg]


I wasn't sure how I should take it, but I didn't feel bad about being pampered.
[cpg]


[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=100]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************




[window target=true]

On the other hand, it would be conspicuous if I kept dressing up like that girl.
[cpg]


I changed back into my golem form again and left the cafeteria.
[cpg]


As usual, I couldn't disguise myself as a goblin. I don't know why I was able to turn into that girl who was called Asha.
[cpg]


It's a strange thing, but there must be some condition.
[cpg]


[OnName num="renzi"]
I'm a little sleepy now that my stomach is full.
[cpg cn=true]


Sleepy. I am sleepy, but I don't know where to sleep.
[cpg]


Is it okay to sleep anywhere in the middle of a dungeon?
[cpg]


If this is a safe place, it's fine. But there is a possibility that it is not.
[cpg]


Demons seem to leave demons alone, but there is a possibility that they are hostile to humans.
[cpg]


There was some talk about shapeshifters being useful in some kind of operation.
[cpg]


If there is an operation, it means there is something hostile.
[cpg]


[OnName num="renzi"]
' (No, I don't want to think about anything else right now. ......)"
[cpg cn=true]


After much thought, I decided to go back to sleep.
[cpg]



[BG f="black.ui"  time=1000]
[WAIT time=100]
[STOPBGM]
;//ブラックアウト





I lay down in a suitable place in the hallway. Even if there were bugs, they wouldn't bite me, because I am a golem.
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[window target=true]

And after a good night's sleep. I didn't wake up on my own, I was woken up.
[cpg]


The one who woke me up was a lizardman, or should I say an upright reptilian looking creature.
[cpg]


[OnName num="lizardman"]
What are you doing? What are you doing, sleeping in a place like this?
[cpg cn=true]


[OnName num="renzi"]
"......"
[cpg cn=true]


[OnName num="lizardman"]
You never know when that brave woman might attack. Aren't you afraid?
[cpg cn=true]


I was left speechless and unable to say anything back.
[cpg]


[OnName num="lizardman"]
Anyway, I'd rather you go on guard duty than sleep here."
[cpg cn=true]



They say things like that. Reluctantly, I headed for the place I was led.
[cpg]

[SE f=se007]
;//【ＳＥ】『ゴーレム足音』


;//レターボックスin
[FACE method="feadin_up" pos="4/7"]


I guess they assigned me a job as a member of the dungeon community.
[cpg]


It wasn't much of a job, even though I was on guard duty. I was really just there to keep watch.
[cpg]


I was never alone there, so I was never bored.
[cpg]


[OnName num="goblins_A"]
The golem is kind of boring to hang out with because you can't talk to it."
[cpg cn=true]


[OnName num="goblins_B"]
'Well, don't be so sure. I heard a shapeshifter came to our house.
[cpg cn=true]


[OnName num="goblins_A"]
I'm thinking, "Shapeshifters ......?　If it's true, it's a big deal.
[cpg cn=true]


We spent some time in the dungeon, taking turns keeping watch.
[cpg]


Fortunately, no humans showed up while I was on watch. Perhaps they are hostile.
[cpg]


If they appeared, would I have to fight them?
[cpg]


I tried to look as strong as possible, so I kept disguising myself as a golem instead of my original serpent-like form.
[cpg]


Its movements were slow. It doesn't look like it could fight very well, but that's true even in its original form.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//レターボックスout
[FACE method="out" pos="4/7"]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************

[window target=true]


Still, I just can't stay in golem form when I eat.
[cpg]


My transformation repertoire was either a golem or the beastman ...... asha for example.
[cpg]


[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="4/5" time=800]

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/5" time=800]
[VOICE f="Arsha008"]
[OnName num="asha"]
'Whoa!　Surprise, surprise, I thought I was there."
[cpg cn=true]


Being at the dinner table in her form can lead to unwanted misunderstandings.
[cpg]


[OnName num="orc"]
'Two Asha's ......?　Did you learn some kind of magic?"
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Arsha009"]
[OnName num="asha"]
No, no, no, he's a shapeshifter and he's ...... more of a she than a he."
[cpg cn=true]

[FO pos="2/5" time=1000]
[FO pos="4/5" time=1000]


[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





And when I went to bed, I headed to a large room that was separate from the dining room.
[cpg]


It was quite large and was apparently meant to be a communal bedroom.
[cpg]


There were several rooms similar to this one, and the higher ranking demons had private rooms.
[cpg]



[window target=false]

[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************

[window target=true]


As I continued to keep watch, I would occasionally see a human being.
[cpg]

;**【ＣＧ】ci_02_0 ***********************
;//カットイン
[CUTIN f="ci_02_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

But if they were disguised as strong-looking golems, they would run away just as soon as they encountered them.
[cpg]


Whether or not they can actually fight, it would be useful to be able to change their appearance.
[cpg]

[CUTIN f="ci_02_0.ui" show={false} method="slideout"]
[WAIT time=1000]


[OnName num="goblins"]
'No, it helps. You just look so strong.'
[cpg cn=true]


People around me are beginning to learn that I am a shapeshifter.
[cpg]


They knew I wasn't strong enough to fight myself, and they were supportive.
[cpg]


But being a golem who can't speak forever is a problem. ......
[cpg]


That said, the only way to speak is to borrow Asha's form.
[cpg]


It is also troublesome to explain every time someone sees you doing it and misunderstands you.
[cpg]


[OnName num="goblins"]
You really don't talk much,......, or rather, you can't speak."
[cpg cn=true]


[OnName num="renzi"]
(Well, that's because it's a golem.)"
[cpg cn=true]


[OnName num="goblins"]
You should try to turn into me," he said. Then maybe you can talk.
[cpg cn=true]


I tried desperately to turn into him, but I couldn't do it.
[cpg]


What was the difference? I tried hard to disguise myself, but I couldn't. I couldn't remember anything at all.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="ep001.ks" target="*start"]


