*start

;###################################################################
*Ep014|What even transformation can't do.
;###################################################################
;//２、ドロシー

[SCENE id=14]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out" pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out" pos="3/5"]


[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="05"]


[window target=true]


......I like Dorothy.
[cpg]



I can't say that right now as long as the person in question is right in front of me. But I had a firm intention in my mind.
[cpg]


[FACE method="change_5"  pos="2/3"]
[VOICE f="Dorothy201"]
[OnName num="dorothy"]
I was like, "......What?　Why are you staring at me?"
[cpg cn=true]


[OnName num="renzi"]
No. Nothing."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





At that point, Dorothy and I didn't speak any more.
[cpg]


I wanted to get my thoughts straight. I wanted Dorothy to love me, and I knew it was true.
[cpg]


I wanted to understand why.
[cpg]


[OnName num="renzi"]
「……」
[cpg cn=true]


The first person to recognize my power, I guess.
[cpg]


I had a feeling that Dorothy liked me after my success in capturing Kulara.
[cpg]


It may be that she likes me because she likes me.
[cpg]


Even now, Dorothy was approaching me at every opportunity, and there was no doubt that she was at least fond of me.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





One day, as I was spending time thinking about this.
[cpg]


[OnName num="renzi"]
One day, I found myself thinking, "Neither Dorothy nor Janice are here today, are they?
[cpg cn=true]


[OnName num="rudolf"]
Oh. I have to ask you to sit out for a reason."
[cpg cn=true]


I was summoned by the Demon King. As I waited for him to speak, I wondered if I had done something wrong.
[cpg]


[OnName num="rudolf"]
What do you think about my daughter?"
[cpg cn=true]


[OnName num="renzi"]
...... In what way, sir?"
[cpg cn=true]


[OnName num="rudolf"]
No," he said. "No," he said, "that was a roundabout way of putting it.
[cpg cn=true]


[OnName num="rudolf"]
If you're serious about dating my daughter, be prepared.
[cpg cn=true]


...... got ahead of what I was thinking.
[cpg]


At the moment, the closest thing Dorothy and I have to the opposite sex is definitely me. So I guess the Demon King would say this.
[cpg]


[OnName num="renzi"]
Preparedness, if you will ......."
[cpg cn=true]


[OnName num="rudolf"]
It means you will be the next Demon King. Can you seriously support Dorothy?"
[cpg cn=true]


I fell silent. Well, of course I would.
[cpg]


I wasn't ready to go that far, but I was serious about loving Dorothy.
[cpg]


Of course, I was going to accept it if that was the only way, even though I knew I wasn't the right person to be the Demon King.
[cpg]


[OnName num="renzi"]
I'm ready. If you want me to be the Demon King, I will be.
[cpg cn=true]


[OnName num="rudolf"]
I see. That's one weight off my shoulders.
[cpg cn=true]


The Demon King laughed just a little. I thought I had never seen him laugh before.
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



I think this must mean that he is officially approved by his father.
[cpg]


Finally, I had no choice but to make this love come true. I have no intention of giving up.
[cpg]


If that's the case, I'll have to start by filling the outer moat. ......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FACE method="feadin_up" pos="4/7"]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





;//[FG f="CHA02_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sDorothy003"]
[OnName num="dorothy"]
"......?　Oh, did I have two of these clothes?"
[cpg cn=true]


I think it is common up to the idea of burying the outer moat first.
[cpg]


But to turn into something she is familiar with is not something that everyone can do.
[cpg]


That's why I was trying to find out what her hobbies were.
[cpg]


;//[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy203"]
[OnName num="dorothy"]
Well, no matter. ......
[cpg cn=true]

[SE f=se012]
;//【ＳＥ】『衣擦れ』

[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=1000]
After her bath, she gets dressed. I stick close to her and smell good.
[cpg]


I was hoping I could hear her talking to herself, or maybe even hear her talking to someone else.
[cpg]

[SE f=se019]
;//【ＳＥ】『ノック』
[WAIT time=1100]


[VOICE f="Janice169"]
[OnName num="janice"]
Princess. May I?"
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Dorothy204"]
[OnName num="dorothy"]
It's fine. What?"
[cpg cn=true]



[FO pos="2/3" time=1]

[SE f=se023]
;//【ＳＥ】『ドア閉まる・開く』




[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=1000]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=1000]

[VOICE f="Janice170"]
[OnName num="janice"]
'Lately, there have been fewer invasions from humans. So we are considering replacing our cultivators and guards."
[cpg cn=true]


Janice is consulting with Dorothy about whether or not to make a proposal to the Demon King.
[cpg]


[FACE method="change_2"  pos="2/2"]
[VOICE f="Dorothy205"]
[OnName num="dorothy"]
Dorothy says, "Yes, that's fine. Good luck with that."
[cpg cn=true]


Dorothy didn't seem too interested in that. It's just like her or something. ......
[cpg]


[FACE method="change_3"  pos="1/2"]
[VOICE f="Janice171"]
[OnName num="janice"]
......Yes, sir."
[cpg cn=true]


That was the only conversation I had with Janice. She didn't tell me anything in particular that I wanted to know.
[cpg]

[FO pos="1/2" time=800]
[FO pos="2/2" time=800]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





And then. Dorothy wasn't particularly soliloquial.
[cpg]


;//[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Dorothy206"]
[OnName num="dorothy"]
Good night. ......
[cpg cn=true]


And I'm already trying to fall asleep. At this rate, I'll never get anything out of him.
[cpg]


I thought that my transformation would be in vain, and I wondered if I could at least do something for her.
[cpg]


;//移植前シーンカット



[window target=false]

[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





The next morning, still in agony.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy226"]
[OnName num="dorothy"]
'Mmm ...... still, sleepy.'
[cpg cn=true]


Dorothy gets up quietly. I wake up at the same time.
[cpg]


It is not possible for the transformation to be undone while I am asleep. If that were the case, I wouldn't be able to transform into anything.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************




[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Dorothy227"]
[OnName num="dorothy"]
Good morning. Asha, what do you have for me today?"
[cpg cn=true]


[FACE method="change_2"  pos="1/2"]
[VOICE f="Arsha205"]
[OnName num="asha"]
I know, ...... there's some live fish in there, how about that?"
[cpg cn=true]


Live fish in the dungeon ......?　Do they get it from somewhere else?
[cpg]


Or are we talking about growing them in a pond somewhere?
[cpg]



[FACE method="change_1"  pos="2/2"]
[VOICE f="Dorothy228"]
[OnName num="dorothy"]
Fish, huh? I haven't eaten any recently.
[cpg cn=true]


Through her clothes, I can faintly see Asha.
[cpg]


Dorothy and Asha are good friends. She's probably good friends with Janice, too.
[cpg]


I don't, but I don't know if it's two people, Asha and Janice: ......
[cpg]


And once I figure that out, the strategy I can take won't change much.
[cpg]


[FO pos="1/2" time=1000]
[FO pos="2/2" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



Then Dorothy took a look around the cultivation room, etc., and headed for the demon king's place.
[cpg]



[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Dorothy229"]
[OnName num="dorothy"]
She said, "...... Dad. I had the strangest dream.
[cpg cn=true]


[OnName num="rudolf"]
What kind of dream?"
[cpg cn=true]


Eavesdropping on a father-son conversation. Despite the pain in my conscience, I cannot untransform here and now.
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy230"]
[OnName num="dorothy"]
I was with Renji. I was so surprised that he even appeared in my dream."
[cpg cn=true]


No, I'm not allowed to say that. That's what I was thinking.
[cpg]


[OnName num="rudolf"]
I see."
[cpg cn=true]


And when the demon king heard this, he responded simply.
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy231"]
[OnName num="dorothy"]
'What do you think, from your father's point of view?　Do you think we're a good match?"
[cpg cn=true]


[OnName num="rudolf"]
'...... don't ask me. I can't answer."
[cpg cn=true]


I guess it's complicated as a quirky father. There was a bit of silence.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





I couldn't help but get on the ball when I heard that .......
[cpg]


That night, the moment I undressed in the bathroom, I left the place in my clothes.
[cpg]


I was glad no one found me. It would have been a big deal if anyone had found me crawling around in my clothes in the changing room.
[cpg]



[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FACE method="out" pos="4/7"]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


I didn't want to be disguised as clothes. Even if I could have stayed near her, I wouldn't have been able to see her.
[cpg]


So I decided to disguise myself as a chair in her room.
[cpg]


She often reads. I can do something in the meantime.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy232"]
[OnName num="dorothy"]
I asked her, "Oh, ...... did I move the chair?"
[cpg cn=true]


Dorothy returns after her bath and nods her head as she says this.
[cpg]


I wondered if it was a bad idea, but Dorothy nodded and laughed a little.
[cpg]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Dorothy233"]
[OnName num="dorothy"]
It was just my imagination," she said. I'm sure it's just my imagination. Nothing strange happened last night either."
[cpg cn=true]


...... You've got it all figured out. On top of being obvious, Dorothy sat on top of me.
[cpg]



;//========================================
;//●ＣＧ（椅子になってヒロインを観察する主人公。ヒロインは編み物をしている）ev_37
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：無し
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公は椅子に化けています
;//=======================================

;//*Scene031
[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="10"]
;**【ＣＧ】 ev_37_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1500]





She seemed to be glancing at me, who had become a chair.
[cpg]


But I couldn't be sure if I was allowed to do anything or not.
[cpg]



[VOICE f="Dorothy234"]
[OnName num="dorothy"]
I thought to myself, "I don't know what I'm going to do. Maybe I'll do some knitting."
[cpg cn=true]


Dorothy says this as if she dares me to listen.
[cpg]


I, who can't utter a single word, can't be sure.
[cpg]


I did nothing, wondering what to do.
[cpg]

;**【ＣＧ】 ev_37_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Dorothy235"]
[OnName num="dorothy"]
'It's not easy to get new books these days. ......
[cpg cn=true]


Dorothy's soliloquy is growing. This is probably because she realizes I'm a chair.
[cpg]


Or maybe she also noticed when I was in clothes.
[cpg]


I was even more confused as to what was going on.
[cpg]


And I guess Dorothy was wondering the same thing. She is talking to herself and choosing what she wants me to hear.
[cpg]

;**【ＣＧ】 ev_37_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sDorothy004"]
[OnName num="dorothy"]
Haa...... it's hard to be a maiden in love."
[cpg cn=true]


[VOICE f="sDorothy005"]
[OnName num="dorothy"]
I wonder if Renji is going to do anything about it. I'm waiting for you.)"
[cpg cn=true]


;//ブラックアウト

[VOICE f="sDorothy006"]
[OnName num="dorothy"]
I think I'll leave the knitting for now, too."
[cpg cn=true]


Unnatural words for a soliloquy. After saying that, she stopped sitting down.
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Dorothy253"]
[OnName num="dorothy"]
She said, "...... good night."
[cpg cn=true]


That good night was not a soliloquy. It is directed at me.
[cpg]


He has forgiven me to some extent. He may even want me to stay by his side.
[cpg]


But I didn't think I could confess my feelings to him now and be in love with him.
[cpg]


I was also afraid that he would be attracted to me if I approached him too forcefully.
[cpg]




;//ブラックアウト


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


The next morning, I disguised myself once again in Dorothy's clothes and waited for her to put me on.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Dorothy254"]
[OnName num="dorothy"]
'Hmmm ...... rn, rn.'
[cpg cn=true]


Dorothy is always in a good mood. Is she happy that she is getting closer to me?
[cpg]


That might be a little too convenient as an interpretation, but ......
[cpg]


She looked happy, and I was happy to see her happy too.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



And then the cafeteria. When I finished my meal and was chatting with Asha who was off-duty.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Dorothy255"]
[OnName num="dorothy"]
She said, "Ha-ha-ha. That's tough."
[cpg cn=true]


[FACE method="change_6"  pos="1/2"]
[VOICE f="sArsha017"]
[OnName num="asha"]
It's not funny,...... Dorothy, you don't know what it's like to not be able to fall in love only with the person you love."
[cpg cn=true]


They were talking about such a topic. It's a topic that only two girls can talk about.
[cpg]


[FACE method="change_4"  pos="2/2"]
[VOICE f="sDorothy007"]
[OnName num="dorothy"]
I guess so," she said. I'm a single-minded person.
[cpg cn=true]


I wonder to whom he is referring to when he says "single-mindedly ......".
[cpg]


;//qwe

;//移植前シーンカット




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



Talking about such things... I realized I had lost sight of my original purpose.
[cpg]



I remembered that I was to find out Dorothy's preferences. I had forgotten the most important thing.
[cpg]

;//ブラックアウト

I slipped out of her room once more just as I was taking off my clothes.
[cpg]


[OnName num="renzi"]
"What shall we do ...... Oh, that's right."
[cpg cn=true]


I suddenly had an idea and tried to disguise myself as someone close to her.
[cpg]


Even in the middle of the night, Janice would come to Dorothy's room.
[cpg]


Just disguising myself as an object wouldn't get me any further. If I disguised myself as Janice, who was close to Dorothy, I could ask her questions.
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



;//ここからしばらく、ジャニスのセリフ名前欄を「ジャニス（蓮司）」と置き換えてください



Once I decided that, my action was quick.
[cpg]

[SE f=se019]
;//【ＳＥ】『ノック』

[WAIT time=1500]

;//[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Janice172"]
[OnName num="renzi_to_janice"]
Princess. May I come in now?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Dorothy274"]
[OnName num="dorothy"]
I'm fine. Come in."
[cpg cn=true]


[FO pos="2/3" time=1000]


I don't know how Janice is talking to Dorothy.
[cpg]


But I still wanted to ask her something.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Janice173"]
[OnName num="renzi_to_janice"]
"Have you ever been in love, ...... princess?"
[cpg cn=true]


I decided to go for the straight and narrow. If I went too far here, the risk of being found out would increase.
[cpg]


[FACE method="change_4"  pos="2/2"]
[VOICE f="Dorothy275"]
[OnName num="dorothy"]
What's the matter, suddenly? Janice, I'm in love with someone.
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Janice174"]
[OnName num="renzi_to_janice"]
No, that's not what ......
[cpg cn=true]


I denied it, but took a stance to make it seem like I might have. Then.
[cpg]


[FACE method="change_7"  pos="2/2"]
[VOICE f="Dorothy276"]
[OnName num="dorothy"]
Hmmm?"　Maybe you've fallen in love with your dad?"
[cpg cn=true]


Dorothy gets a hunch. Here, say something more.
[cpg]


[FACE method="change_2"  pos="2/2"]
[VOICE f="Dorothy277"]
[OnName num="dorothy"]
If so, you and I are rivals."
[cpg cn=true]


[FACE method="change_5"  pos="1/2"]
[VOICE f="Janice175"]
[OnName num="renzi_to_janice"]
What?"
[cpg cn=true]


[FACE method="change_1"  pos="2/2"]
[VOICE f="Dorothy278"]
[OnName num="dorothy"]
I told you the other day. I like your father."
[cpg cn=true]


...... I was amused by the quirkiness of the stone. I thought Dorothy was close to the Demon King.
[cpg]


[FACE method="change_7"  pos="1/2"]
[VOICE f="Janice176"]
[OnName num="renzi_to_janice"]
'Is that so?　Well, you know, Renji's ......"
[cpg cn=true]


I asked, wondering if I was slipping a little.
[cpg]


[FACE method="change_2"  pos="2/2"]
[VOICE f="Dorothy279"]
[OnName num="dorothy"]
I like Renji, but I like your father so much that it diminishes my love for him. If your mother were alive, I think I'd be jealous."
[cpg cn=true]


Come to think of it, I have never seen Dorothy's mother, the wife of the Demon Lord.
[cpg]


Had she passed away? I somehow had a feeling that she was.
[cpg]


As I was at a loss for words, Dorothy
[cpg]


[FACE method="change_1"  pos="2/2"]
[VOICE f="Dorothy280"]
[OnName num="dorothy"]
And?"　Who does Janice like?"
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Janice177"]
[OnName num="renzi_to_janice"]
I'm ......."
[cpg cn=true]


[FACE method="change_2"  pos="2/2"]
[VOICE f="sDorothy008"]
[OnName num="dorothy"]
You miss human skin, don't you?"
[cpg cn=true]


Again?　What are you talking about?　As I was thinking, Dorothy approached me disguised as Janice.
[cpg]

[FACE method="change_1"  pos="2/2"]
[WAIT time=1]
[move from="2/2" to="2/3" ease="easeInOutSine" time=1000]


[VOICE f="Dorothy282"]
[OnName num="dorothy"]
I thought, "Don't tell me you've fallen in love with me?"
[cpg cn=true]


Dorothy is bizarrely close to me and tries to take off her clothes.
[cpg]


Janice and Dorothy had that kind of relationship? If so, I must have been the wrong person to turn into her.
[cpg]


[FACE method="change_2"  pos="2/2"]
[VOICE f="Dorothy283"]
[OnName num="dorothy"]
I like Janice, too," Dorothy said. I love Janice too, in no particular order.
[cpg cn=true]

[FO pos="1/2" time=1000]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



I have no choice but to be prepared now. I can't say now that I am really Renji.
[cpg]


I was in the middle of thinking that.
[cpg]


;//移植前シーンカット

[SE f=se023]
;//【ＳＥ】『扉開く』

[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************




;//ここからジャニスのセリフ名前欄を元に戻してください
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="3/3" time=800]
[FG f="CHA03_p4_01_a.ui" method="change_4"  pos="1/3" time=800]




[VOICE f="Janice186"]
[OnName num="janice"]
I was in the middle of thinking that. Princess, I have a few words to tell you. ......"
[cpg cn=true]


The real Janice came into the room.
[cpg]


[FACE method="change_5"  pos="2/3"]
[VOICE f="Dorothy296"]
[OnName num="dorothy"]
What?　Two Janices?"
[cpg cn=true]

[SE f=se010]
;//【ＳＥ】『走る』

[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="3/3" time=1]
[FO pos="2/3" time=1]
[FO pos="1/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]

I quickly got up and ran away.
[cpg]


It was only a temporary fix, but I still couldn't stay where I was.
[cpg]



[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





Of course, I couldn't run away in Janice's form.
[cpg]

;**【ＣＧ】ci_06_0 ***********************
;//カットイン
[CUTIN f="ci_06_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

Once outside the room, I disguised myself as a slime. Now they wouldn't know it was me.
[cpg]


It was a close call. Just in time, or was it out?
[cpg]

[CUTIN f="ci_06_0.ui" show={false} method="slideout"]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





Over the next few days, I took on the appearance of various demons and blended in with my surroundings.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha214"]
[OnName num="asha"]
You don't look familiar to me. Are you new here?
[cpg cn=true]


I was disguised as a goblin at the time, but Asha saw right through me. She is the one who runs the cafeteria.
[cpg]


[OnName num="renzi"]
'It's me. It's Renji."
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Arsha215"]
[OnName num="asha"]
Oh, I see what you mean. Dorothy's been looking for you.
[cpg cn=true]


[OnName num="renzi"]
I'm sure you're right. ......
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Arsha216"]
[OnName num="asha"]
Dorothy, you were mad at me ...... but you didn't seem like you were really mad at me, so maybe we should meet."
[cpg cn=true]


You're absolutely right. It's not something you can put off forever.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





That's why I was going to apologize to Dorothy in person.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy297"]
[OnName num="dorothy"]
She said, "That's fine. It doesn't matter. I knew and was aware of it all along.
[cpg cn=true]


Dorothy is still a little angry. Asha was right.
[cpg]


[OnName num="renzi"]
I'm sorry."
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="sDorothy009"]
[OnName num="dorothy"]
Renji is such a coward. I know he wants to find out about me.
[cpg cn=true]


I can't deny that. I sat silently on my haunches.
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="sDorothy010"]
[OnName num="dorothy"]
I don't dislike Renji either. I might have known that somehow.

[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="sDorothy011"]
[OnName num="dorothy"]
I hope you're being fair. It's not manly."
[cpg cn=true]


Then Dorothy blushed and slumped down. I don't know how to take this.
[cpg]


I know she's doing me a favor. But I don't know if ...... it's a good idea to do anything about it right now.
[cpg]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Dorothy301"]
[OnName num="dorothy"]
Do you want me to ...... say any more?"
[cpg cn=true]


[OnName num="renzi"]
I'm going to go to ...... and say, "...... no. You don't have to say anything."
[cpg cn=true]


Suddenly an opportunity presented itself. I approach her, bewildered.
[cpg]


Come to think of it, she may have been waiting for this for a long time.
[cpg]


I take her hand, and we both know she's nervous.
[cpg]


;//移植前シーンカット

;//移植前シーンカット

[SE f=se012]
;//【ＳＥ】『衣擦れ』
[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

Lightly, we take each other's hands. And then I said the all-important words.
[cpg]


[OnName num="renzi"]
Dorothy. I love you. I love you."
[cpg cn=true]

[FACE method="change_4"  pos="2/3"]
[VOICE f="sDorothy012"]
[OnName num="dorothy"]
'Heh. I wish you had told me before you did all those naughty things.
[cpg cn=true]


Dorothy looked stunned, but she laughed.
[cpg]


I think this would have been the same thing anytime I had said it already.
[cpg]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Dorothy347"]
[OnName num="dorothy"]
'But I'm glad. Thank you. I like Renji, too.
[cpg cn=true]


Dorothy looked at me as she said this.
[cpg]



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



The next day, after such an affair.
[cpg]


I guess we must have tied the knot, but something still felt off.
[cpg]


It still stuck in my mind that it was the Demon King that she liked.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy348"]
[OnName num="dorothy"]
Renji, good morning."
[cpg cn=true]


[OnName num="renzi"]
Good morning."
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy349"]
[OnName num="dorothy"]
...... It's kind of awkward. After something like that."
[cpg cn=true]


Dorothy would tell me that, but I had another thing on my mind.
[cpg]


[OnName num="renzi"]
'Dorothy likes your father, the Demon King ......, doesn't she?
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy350"]
[OnName num="dorothy"]
What's wrong, all of a sudden?"
[cpg cn=true]


[OnName num="renzi"]
I'm telling you, I could make that wish come true, too."
[cpg cn=true]


[OnName num="renzi"]
I could even take on the appearance of the Demon Lord and stay by Dorothy's side.
[cpg cn=true]


Dorothy hesitated for a moment when she heard this.
[cpg]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Dorothy351"]
[OnName num="dorothy"]
...... Heh. Indeed it is."
[cpg cn=true]


He also seemed to think that the love he had always wanted to achieve would come true, even if only in a pseudo way.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





The distance between me and Dorothy was closing somewhat.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Janice187"]
[OnName num="janice"]
"Princess, are you having dinner with him again today?"
[cpg cn=true]


[FACE method="change_2"  pos="2/2"]
[VOICE f="Dorothy352"]
[OnName num="dorothy"]
Yes," he said. And I haven't forgotten about Janice, so don't worry."
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Janice188"]
[OnName num="janice"]
No, I'm not worried about that. ......
[cpg cn=true]


Janice is wincing, but seems to be directing some jealousy at me.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





Then night comes again. I was about to grant Dorothy's wish.
[cpg]


I invited her into my bedroom.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]






[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Dorothy353"]
[OnName num="dorothy"]
"Oh, my God," she said. Really, you look just like your father."
[cpg cn=true]


[OnName num="renzi"]
That's because ...... I'm a demon like that."
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="sDorothy013"]
[OnName num="dorothy"]
...... I wish I could hold you like that right now."
[cpg cn=true]


[OnName num="renzi"]
I'll do whatever Dorothy wants.
[cpg cn=true]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Dorothy355"]
[OnName num="dorothy"]
Don't say that in your father's voice. ...... I'll get out of control."
[cpg cn=true]


It seems that Dorothy really likes her own father, the Demon King.
[cpg]


She had a different expression on her face when she faced me.
[cpg]


I guess, by all means, I can't make it up to her father. I could imagine that.
[cpg]


;//移植前シーンカット


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

I stroked Dorothy's head while I was in my Demon King form.
[cpg]


But the more we touched each other, the more Dorothy's love for her own father became apparent.
[cpg]


[OnName num="renzi"]
Stay by my side. Dorothy."
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy377"]
[OnName num="dorothy"]
Don't say "...... me. Say me."
[cpg cn=true]


[OnName num="renzi"]
Come to think of it, I did."
[cpg cn=true]


The figure was so close to the ideal that Dorothy began to demand that he act, speak and behave like the real thing.
[cpg]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Dorothy378"]
[OnName num="dorothy"]
'Dorothy, I wish you'd say I love you ...... in that voice.
[cpg cn=true]


[OnName num="renzi"]
I said, "Oh. I love you."
[cpg cn=true]


;//ブラックアウト


I try to reciprocate, but I don't feel like I'm truly satisfying Dorothy.
[cpg]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Dorothy379"]
[OnName num="dorothy"]
Thank you, Dorothy. I've always wanted to do this, and I think I've achieved it.
[cpg cn=true]


Dorothy looked wistful as she said, "I'm sorry.
[cpg]


[OnName num="renzi"]
Really?　Just tell me what you're thinking."
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy380"]
[OnName num="dorothy"]
'Yes. ...... yeah. I'm Renji, so I'll tell you."
[cpg cn=true]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Dorothy381"]
[OnName num="dorothy"]
It's kind of empty or sad. I think I still love my father.
[cpg cn=true]


[OnName num="renzi"]
I see. ......
[cpg cn=true]


If I want Dorothy to truly love me, I may have to truly become her.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





For example, let's say I get married to Dorothy and become the next Demon King.
[cpg]


But that doesn't mean I can become her father himself.
[cpg]


It is obvious from the fact that I can't just imitate her appearance.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha217"]
[OnName num="asha"]
"......Renji."
[cpg cn=true]


I was troubled. Of course I wanted to make Dorothy's unfulfilled love come true.
[cpg]


Of course, it would be unethical for her to be united with her own father, and that is true even if he is a demon.
[cpg]


How can I change this situation? ......
[cpg]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Arsha218"]
[OnName num="asha"]
Renji!"
[cpg cn=true]


[OnName num="renzi"]
What?　Oh, oh, ...... Asha?"
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Arsha219"]
[OnName num="asha"]
Not "Asha, huh? Why are you so glum?
[cpg cn=true]


[OnName num="renzi"]
"...... actually."
[cpg cn=true]


I talked to Asha about it. I know it's not like I can talk to her about it.
[cpg]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Arsha220"]
[OnName num="asha"]
I see. Dorothy, I knew it.
[cpg cn=true]


[OnName num="renzi"]
I've already talked to Janice about it. She told me that there was nothing more I could do about it.
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Arsha221"]
[OnName num="asha"]
I think I'm with Janice on this one.
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="sArsha018"]
[OnName num="asha"]
Dorothy is the type of person who likes everyone. Like Janice, or even me. ......"
[cpg cn=true]


[OnName num="renzi"]
Me too. What?
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha223"]
[OnName num="asha"]
No," he said. Nothing. I'll leave it to your imagination."
[cpg cn=true]


I can kind of imagine. Dorothy is not a sexually active person, but she is lonely.
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Arsha224"]
[OnName num="asha"]
But when it comes to the most important person, I think it is the Demon Lord. For Dorothy, he is a very special person.
[cpg cn=true]


[FO pos="2/3" time=1000]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_04_5_up.ui" time=1000]

[FACE method="feadin_up" pos="4/7"]

[WAIT time=1500]


I would talk to anyone I could talk to.
[cpg]


[OnName num="renzi"]
What do you think about this story called ......?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Clara530"]
[OnName num="clara"]
I don't know anything about that.
[cpg cn=true]


Finally, he even told his captor, Klara.
[cpg]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Clara531"]
[OnName num="clara"]
He said, "You have other things to be on the lookout for than love, don't you?
[cpg cn=true]


[OnName num="renzi"]
What are you talking about?"
[cpg cn=true]


I had no idea what Kulara was talking about.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





After much thought, I began to wonder if I could only make Dorothy love me for what I could do.
[cpg]


In other words, a makeover. I was the only one who could play tricks on her like I had been doing.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy382"]
[OnName num="dorothy"]
I think I'll go to bed ...... but I'm slightly bleary-eyed."
[cpg cn=true]


And today, I was transformed into a houseplant in Dorothy's room.
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy383"]
[OnName num="dorothy"]
I said, "Yes, I need to water it. Let's see, the jug is at ......."
[cpg cn=true]


Saying this, he takes the jug in his hand and approaches me. I extended my ivy to her.
[cpg]


[FACE method="change_5"  pos="2/3"]
[VOICE f="Dorothy384"]
[OnName num="dorothy"]
She said, "Kyaaaah!　What?
[cpg cn=true]



;//========================================
;//●ＣＧ（観葉植物から蔦が伸びて、ヒロインの体に巻き付く。ヒロインは立ったまま動けない感じ）ev_02
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：無し
;//場所　：ダンジョン内部
;//時間　：夜
;//備考　：主人公は観葉植物に化けています
;//========================================

;//*Scene037
[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="10"]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1500]


[SE f=se014]
;//【ＳＥ】『弓を引き絞る』

[VOICE f="Dorothy385"]
[OnName num="dorothy"]
What is this?　This plant was a demon!
[cpg cn=true]



I wrapped myself around Dorothy's body so that she couldn't move at first.
[cpg]


It was interesting to watch her confused expression.
[cpg]


Too bad I can't say a word. ......
[cpg]


But there are some things you can do because you can't say anything.
[cpg]

;**【ＣＧ】 ev_02_a ***********************
[CG id=11 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Dorothy386"]
[OnName num="dorothy"]
I can't untie you, I'm tangled ......!　Stop it, let me go!"
[cpg cn=true]


She is trying to shake it off. I wrap myself around her tightly.
[cpg]


I wonder what it is that the more she resists, the more I feel like doing it.
[cpg]



[VOICE f="Dorothy387"]
[OnName num="dorothy"]
'How is this possible ......!　Nothing ever happened to me before."
[cpg cn=true]


I want to play a prank on Dorothy. It's an emotion I haven't felt in a long time.
[cpg]


She still doesn't understand that it's something I do. She seems to think that the plant I grew was simply a demon.
[cpg]

;**【ＣＧ】 ev_02_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Dorothy389"]
[OnName num="dorothy"]
I'm like, "Okay, I get it. It's Renji, right?　I can already tell by the stones, tell me it's so."
[cpg cn=true]


...... wrong. They know.
[cpg]


;//移植前シーンカット


[VOICE f="Dorothy404"]
[OnName num="dorothy"]
'Renji, come on, I'm ...... going to be really mad at you.'
[cpg cn=true]


And then Dorothy was telling me that she had calmed down a little bit.
[cpg]



[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



I was still playing silly pranks on her.
[cpg]


Dorothy was pissed at me, but I wouldn't stop playing tricks on her.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





As usual, Dorothy still likes her own father, the Demon King.
[cpg]


That has not been resolved. I was beginning to think that was okay.
[cpg]


I thought this happy time would last forever.
[cpg]

[FACE method="feadin_up" pos="4/7"]

[BG f="b_03_5_up.ui" time=1500]
[WAIT time=2000]
;//ブラックアウト

The day that shattered everything came suddenly.
[cpg]


I must have been a peace-loving person. I never dreamed this would happen.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





Adventurers invaded the dungeon to rescue Kulara.
[cpg]


Thinking that this was what Kulara had been talking about, I fought back.
[cpg]


[OnName num="warrior"]
Get out of the way if you don't want to die!
[cpg cn=true]



[SE f="se025"]
;//【ＳＥ】『剣戟』





My fellow demons, though wounded, were protecting them from advancing deeper into the dungeon.
[cpg]


Still, there were many on the human side. When we were in a party, there were four of us, but now there are at least ten of them.
[cpg]


It was a small dungeon, so it was not enough to push them with numbers, but each and every one of them was strong.
[cpg]


When we were having an unprecedentedly hard time against the humans who had formed a clique, it was the ...... demon king who appeared.
[cpg]


[OnName num="rudolf"]
What do you want? How can you do this to us?"
[cpg cn=true]


[OnName num="monk"]
Here's the line. Please return Kulara."
[cpg cn=true]


When the Demon King casts a spell, the battle situation changes quickly. The quintessence is that he is the leader of the demons.
[cpg]




[FACE method="feadin_up" pos="4/7"]
[WAIT time=1100]

;//ブラックアウト



It was time to see if I could push through with this.
[cpg]


[OnName num="rudolf"]
Damn ......!"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Clara532"]
[OnName num="clara"]
...... don't take it personally. It's what brave men do."
[cpg cn=true]


Kulara was in the throes and was running away.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



Kulara had escaped. The demon king was mortally wounded. Still, the human did not step in any further.
[cpg]


It seems that the objective was only to rescue Kulara.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/2" time=800]

[VOICE f="Janice189"]
[OnName num="janice"]
How did it go, Princess?
[cpg cn=true]


[FACE method="change_4"  pos="2/2"]
[VOICE f="Dorothy405"]
[OnName num="dorothy"]
'...... It's no ordinary wound,' he said. It looks like he was slashed by a sword with a spell in it."
[cpg cn=true]


Dorothy seemed tired of crying and her voice was muffled.
[cpg]


[FACE method="change_7"  pos="1/2"]
[VOICE f="Janice190"]
[OnName num="janice"]
I see. ......
[cpg cn=true]


Janice felt like she had no words to say.
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





There are doctors in the dungeon. Almost all of them were treating the demon king.
[cpg]


[OnName num="rudolf"]
I'm ...... sorry for worrying you."
[cpg cn=true]


He was in a lot of pain and I had never seen him so weak.
[cpg]


[OnName num="renzi"]
'...... demon king, is there anything I can do to help?'
[cpg cn=true]


[OnName num="rudolf"]
No." Nothing. I can tell for myself that I don't have much longer."
[cpg cn=true]



[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



The demon king's condition worsened day by day. Dorothy cried day after day after day.
[cpg]


Then one day. The Demon King summoned me to the King's Chamber.
[cpg]


[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





There was no doctor there. The Demon King, who was left alone with me, said...
[cpg]


[OnName num="rudolf"]
I want you to be me. I have no one else to ask."
[cpg cn=true]


[OnName num="renzi"]
......I somehow thought that's what you would say."
[cpg cn=true]


[OnName num="rudolf"]
Then we'll talk soon. The day when you would lead the demon tribe was bound to come sooner or later.
[cpg cn=true]


If you do, you will be loved by Dorothy.
[cpg]


[OnName num="rudolf"]
I have told my entourage, including Janice, to hide their deaths. I'm counting on you."
[cpg cn=true]


[OnName num="renzi"]
...... yes."
[cpg cn=true]


I nodded. I was ready and determined to fake Dorothy.
[cpg]

[FACE method="feadin" pos="4/7"]
[BG f="b_01_5_up.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





I was present at the moment of the Demon King's death. Dorothy was not there, and I was told she was on the road to recovery.
[cpg]


On the contrary, I was supposed to go on a journey to find a way to help the Demon King.
[cpg]


It all made sense. From that day on, I disguised myself as the Demon King and took on the role of Dorothy's father.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************


;**【ＣＧ】ci_18_0 ***********************
;//カットイン
[CUTIN f="ci_18_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

Dorothy was in a good mood, I thought.
[cpg]

[CUTIN f="ci_18_0.ui" show={false} method="feadout"]
[WAIT time=1000]


I didn't feel that she was happy from the bottom of my heart. She must have been really worried.
[cpg]



Or maybe she was worried about when the humans would invade next.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy406"]
[OnName num="dorothy"]
I said to her, "...... Dad. Don't do anything reckless again, don't leave me alone."
[cpg cn=true]


[OnName num="renzi"]
Oh," he said. I'm sorry. I won't leave you.
[cpg cn=true]


The first person, me, not me, came right out. In front of her, I had to pretend everything.
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





For a while, I act as the Demon King.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice191"]
[OnName num="janice"]
"My Lord, I think we have to increase the number of guards again. ...... how about it?
[cpg cn=true]


[OnName num="renzi"]
Oh," he said. Do that."
[cpg cn=true]


It was becoming a habit of mine to say, "Do that.
[cpg]


Janice is taking care of things and suggesting things on my behalf.
[cpg]


I guess it had not been like this before. Dorothy looked doubtful.
[cpg]


[FACE method="feadin" pos="4/7"]
[BG f="b_01_5_up.ui" time=1000]
[WAIT time=1500]

;//ブラックアウト





I wondered if Dorothy had always been such a spoiled child.
[cpg]


I was the Demon King, and I was her father, and she spoiled me many times.
[cpg]


I was her partner, but I didn't know how long I could keep the truth from her.
[cpg]


Still, I wanted to keep it hidden. She had lost her father, and I wanted to keep it that way as long as I could hide it.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy407"]
[OnName num="dorothy"]
She said, "Hey, Dad. Janice has been working hard lately.
[cpg cn=true]


[OnName num="renzi"]
I guess so." I guess they're taking some of the burden off of me."
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy408"]
[OnName num="dorothy"]
Renji, you haven't come back. After what he did to me, maybe he's not coming back after all.
[cpg cn=true]


[OnName num="renzi"]
What's wrong with him?"
[cpg cn=true]


I did my best to sound genuine, but tried not to be obvious.
[cpg]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Dorothy409"]
[OnName num="dorothy"]
Dad, pat me on the head. I miss you, Renji.
[cpg cn=true]


[OnName num="renzi"]
...... yeah."
[cpg cn=true]


I pat Dorothy's head. She seemed like a kitten as I stroked her.
[cpg]


Even in my peaceful days with Dorothy, it was hard to pretend.
[cpg]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Dorothy410"]
[OnName num="dorothy"]
She said, "Hey. I'm really aware of everything.
[cpg cn=true]


[OnName num="renzi"]
You're aware?　What are you talking about?
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy411"]
[OnName num="dorothy"]
All of it. You are Renji, aren't you?
[cpg cn=true]


...... I knew it. I knew it.
[cpg]


[OnName num="renzi"]
How long have you known?
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy412"]
[OnName num="dorothy"]
From the beginning. But if I told him, he'd probably stop pretending to be my father.
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy413"]
[OnName num="dorothy"]
I just couldn't accept that my father was going to die.
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Dorothy414"]
[OnName num="dorothy"]
You tried to ease my mind about that. I'm glad you did."
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


Dorothy had sad eyes. It was as if she had lost something important this time.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





Late at night. She invited me to her bedroom.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Dorothy416"]
[OnName num="dorothy"]
I've been waiting for you for a long, long time. I can't do anything while you're pretending to be my father.
[cpg cn=true]


[OnName num="renzi"]
I'm sorry about ......."
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="sDorothy014"]
[OnName num="dorothy"]
You can disguise yourself however you like. You can be whatever you want. You can hug me as Renji ......, not as your father."
[cpg cn=true]


So they say, and I change my appearance.
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

[FACE method="change_6"  pos="2/3"]
[VOICE f="Dorothy418"]
[OnName num="dorothy"]
I was so excited to be able to change into whatever I wanted to be. I don't want Renji to get bored with me either.
[cpg cn=true]


[OnName num="renzi"]
I'm not going to get bored. I'll never get tired of you.
[cpg cn=true]


Dorothy blushes as she says, "Yes. Then she said, "I'm sorry.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3"]
[VOICE f="Dorothy419"]
[OnName num="dorothy"]
I love you, Renji. I can't replace my father, but I still love him.
[cpg cn=true]

;//移植前シーンカット



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





No one except the Demon King's entourage and Dorothy are aware that the Demon King is dead.
[cpg]


How would Dorothy be feeling?　It doesn't change the fact that we lost someone important.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy440"]
[OnName num="dorothy"]
......"
[cpg cn=true]


Occasionally, he would huff and puff and look gloomy. I see it and feel a sense of helplessness.
[cpg]


[OnName num="renzi"]
Do you still want to get revenge on ...... Kulara?
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy441"]
[OnName num="dorothy"]
I don't know. Revenge won't bring your father back.
[cpg cn=true]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Dorothy442"]
[OnName num="dorothy"]
But it doesn't make up for the loneliness. So here's what I'm going to do.
[cpg cn=true]



;//========================================
;//●ＣＧ（ベッドに腰掛けてキスをする二人。ヒロインは頬を染めている）ev_44
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ダンジョン＿寝室
;//時間　：夜
;//備考　：主人公は魔王に化けています
;//========================================


[STOPBGM]

[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1500]




[VOICE f="Dorothy443"]
[OnName num="dorothy"]
"Suck."
[cpg cn=true]


She brought her lips to mine. I, disguised as the Demon King, responded.
[cpg]



[VOICE f="Dorothy444"]
[OnName num="dorothy"]
I finally realized how weak I am.
[cpg cn=true]


[OnName num="renzi"]
I don't think so. Dorothy is strong.
[cpg cn=true]

;**【ＣＧ】 ev_44_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Dorothy445"]
[OnName num="dorothy"]
Thank you. You kind of sound like a father to me."
[cpg cn=true]


Even when Dorothy smiles, she still says the same thing, as if she is carrying some emptiness in her heart.
[cpg]


[OnName num="renzi"]
I'll be whatever Dorothy wants me to be," I said.
[cpg cn=true]


There was nothing false in those words. I can do it.
[cpg]

;**【ＣＧ】 ev_44_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Dorothy446"]
[OnName num="dorothy"]
I can do it. Renji can really transform.
[cpg cn=true]


I nodded. Then I kissed him again.
[cpg]



[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





There was a hole in Dorothy's heart, but I could fill it.
[cpg]

[SCENE id=19]


;//ＥＮＤ　ヒロイン２ルート
[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="epend.ks" target="*start"]



;//==============================
