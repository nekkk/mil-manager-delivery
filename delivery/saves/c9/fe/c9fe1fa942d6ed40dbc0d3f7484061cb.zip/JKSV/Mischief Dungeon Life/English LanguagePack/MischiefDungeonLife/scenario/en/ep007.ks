*start

;###################################################################
*Ep007|An unusual constitution.
;###################################################################


[SCENE id=7]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]
[BG f="black.ui"  time=1000]
[WAIT time=100]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



Here's what happened a few hours after the one with Dorothy.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="3/3" time=800]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]

[VOICE f="Dorothy076"]
[OnName num="dorothy"]
There have been a lot of strange demons lately.
[cpg cn=true]


Dorothy speaks to Asha as she takes her order at the diner.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha097"]
[OnName num="asha"]
'Yeah?　In what way?"
[cpg cn=true]


I listen to Dorothy and Asha's conversation with a nonchalant look on my face.
[cpg]


[FACE method="change_1" pos="3/3"]
[VOICE f="Dorothy077"]
[OnName num="dorothy"]
I listen to Dorothy and Asha's conversation with a nonchalant look on my face. Nothing.
[cpg cn=true]


I kept my ears open and stayed out of the conversation.
[cpg]


[FACE method="change_1" pos="1/3"]
[VOICE f="Janice080"]
[OnName num="janice"]
I asked, "Is that Renji at ...... there?"
[cpg cn=true]


[OnName num="renzi"]
He said, "Yes. ...... How did you know it was me?
[cpg cn=true]


[FACE method="change_7" pos="1/3"]
[VOICE f="Janice081"]
[OnName num="janice"]
You'll see, I'm always alone. But still, you're being polite again."
[cpg cn=true]


[OnName num="renzi"]
Sorry. Sorry.
[cpg cn=true]



;//ブラックアウト



[SE f=se011]
;//【ＳＥ】『食器の音』



Janice, Dorothy, and I eat together. I was already dressed as a goblin, not as a bee.
[cpg]


Still, it is strange that Janice recognized me.
[cpg]


No, wait, does ...... mean that what I've done so far is also a surprise?
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="3/3" time=1]
[FO pos="2/3" time=1]
[FO pos="1/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



Finishing our meal, we take a breather.
[cpg]


Asha had finished her duty and was coming to our desk.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="3/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]

[VOICE f="Arsha098"]
[OnName num="asha"]
......"
[cpg cn=true]


He is silent, a little red in the face, and looking into the distance.
[cpg]


I don't mean far away, I mean ...... like he's looking hotly at someone somewhere.
[cpg]


[FACE method="change_7" pos="3/3"]
[VOICE f="Dorothy078"]
[OnName num="dorothy"]
What does that look mean?"
[cpg cn=true]


[FACE method="change_7" pos="1/3"]
[VOICE f="Janice082"]
[OnName num="janice"]
You can guess," he said. Princess."
[cpg cn=true]


[FACE method="change_5" pos="3/3"]
[VOICE f="Dorothy079"]
[OnName num="dorothy"]
Oh, I see."
[cpg cn=true]


Asha's face turns even redder as she says this. I nodded my head, unsure.
[cpg]


[FACE method="change_3" pos="3/3"]
[VOICE f="Dorothy080"]
[OnName num="dorothy"]
'You'll have to guess,' he said. Renji."
[cpg cn=true]


[OnName num="renzi"]
No, you don't have to say that."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="sArsha009"]
[OnName num="asha"]
I'm so tired of it. Don't make fun of us all."
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="3/3" time=1]
[FO pos="2/3" time=1]
[FO pos="1/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[BGM f="05"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





I ended up not knowing what I was talking about and asked again when Janice and I were alone.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Janice083"]
[OnName num="janice"]
I asked her again when Janice and I were alone. She's a beast of the rabbit tribe, isn't she?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sJanice004"]
[OnName num="janice"]
I'm prone to falling in love, whether I want to or not," he said. He must have been admiring the new demon."
[cpg cn=true]


[OnName num="renzi"]
Oh, ...... is that what you're talking about?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sJanice005"]
[OnName num="janice"]
I hear that loneliness is also felt more easily than other people. He seems to be concerned about it, so give him some space."
[cpg cn=true]


I'm sorry I didn't realize that.
[cpg]


I just ended up embarrassing you. I'll have to apologize later.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





For example, a demon that is similar to an insect or animal has no intelligence.
[cpg]


It is not a good idea to approach them in goblin form. Orcs, for example, talk, are bipedal, and seem to think like humans.
[cpg]


But I have also seen demons that are almost like animals, ...... I guess you could call them magical beasts.
[cpg]


If it is in the form of something like that, can't I fill Asha's loneliness?
[cpg]


;//ブラックアウト


[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

I have newly learned the smell of frogs demonic beasts. Smelling a hexenbiest was not something I wanted to do, but ......
[cpg]


Still, if I had to do it for Asha, I had no hesitation.
[cpg]

[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





So I followed Asha in the form of a frog magical beast.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Arsha100"]
[OnName num="asha"]
This girl ...... has been following me since a while ago. I wonder if she likes me."
[cpg cn=true]


As Asha crouched down, I pretended to be friendly.
[cpg]


It felt awkward, as if I was trying to trick her. No, I'm not fooling her.
[cpg]


She puts out her hand and I lick her fingers.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sArsha010"]
[OnName num="asha"]
I wonder if I should get a ...... pet. But that would be weird with a beast."
[cpg cn=true]


They say things like that. Asha seemed to be in a state of considerable loneliness.

Normally, she would not have thought such a thing.

;//移植前シーンカット

[FACE method="change_1" pos="2/3"]
[VOICE f="sArsha011"]
[OnName num="asha"]
I'm sorry. I'll get a pet when it gets really hard.
[cpg cn=true]


He pats my head. It's an indescribable feeling.
[cpg]


I feel like I'm cheating on him. ......
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





Like this, I went on and on with my mischief.
[cpg]


At first, no matter who I scared, they never knew it was me.
[cpg]


[OnName num="renzi"]
I would say, "Good morning. Maybe it's morning now."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Janice085"]
[OnName num="janice"]
Hmm?　Oh, ......."
[cpg cn=true]


I tried to greet Janice, but she seemed to be in something of a bad mood.
[cpg]


I didn't know why I was reacting the way I was.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Janice086"]
[OnName num="janice"]
Renji, whatever you do, don't overdo it."
[cpg cn=true]


I kind of understood when he told me.
[cpg]


[OnName num="renzi"]
'...... what are you talking about?'
[cpg cn=true]


You know what I mean, but I'm going to blurt it out.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Janice087"]
[OnName num="janice"]
You're the only shapeshifter I know. You don't think I won't find out?"
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



I was implicitly offended. I must have overdone it.
[cpg]


But instead of breaking down there, I wondered how I could transform myself in such a way that I wouldn't be recognized.
[cpg]


However, if I was the only one with the ability to transform, it would be difficult to do so without being discovered.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha126"]
[OnName num="asha"]
Oh, there he is. It's Renji, isn't it?
[cpg cn=true]


I was now dressed as a goblin. I needed to dress like this in order to make my voice heard.
[cpg]


Still, how could you tell it was me? I wonder if they can see through my behavior patterns and gestures pretty well?
[cpg]


[OnName num="renzi"]
Asha. What do you want?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha127"]
[OnName num="asha"]
The Demon Lord called for me. Shouldn't you go?"
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[OnName num="rudolf"]
Renji. You're not going on a reconnaissance mission?
[cpg cn=true]


[OnName num="renzi"]
Yeah, yeah. Well, ......."
[cpg cn=true]


At the Demon Lord's request, I shrug it off.
[cpg]


[OnName num="rudolf"]
As you know, the battle between us demons and humans is at a stalemate.
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Dorothy081"]
[OnName num="dorothy"]
But that could all change at once, depending on what Renji does."
[cpg cn=true]


[OnName num="renzi"]
...... Of course I'm willing to do it." But I have a repertoire of transformations ......"
[cpg cn=true]


[OnName num="rudolf"]
You can be anything you want to be now. I've heard all the details."
[cpg cn=true]


They know, don't they? Dorothy must have told you.
[cpg]


[OnName num="renzi"]
Really, I'll get there sometime."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="4/5" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


I just kept dodging and dodging.
[cpg]


The truth is, I don't want to go. I didn't want to put myself in danger.
[cpg]


But then again, I had reached the limit of my mischievousness in the dungeon.
[cpg]


I was thinking, "What should I do? ......
[cpg]


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[WAIT time=1000]
[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="2/3" time=1]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]




I transform into Janice and look at her body seriously once more.
[cpg]



;//ここからしばらく、ジャニスのセリフ名前欄を「ジャニス（蓮司）」と置き換えてください



[VOICE f="Janice088"]
[OnName num="renzi_to_janice"]
「……」
[cpg cn=true]


For example, you can pretend to be someone else and live there without being of any use to anyone else.
[cpg]


It's hard to get rid of me completely, after all, even if I eat free food in the cafeteria.
[cpg]


When I think about it, I don't even feel like doing anything myself.
[cpg]

;//移植前シーンカット


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



;//ここからジャニスのセリフの名前欄を元に戻してください


If I say I haven't done anything, I haven't done anything. Nothing useful for the demon tribe.
[cpg]



;//ブラックアウト


As long as I stayed the same, the people around me started rushing me.
[cpg]


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]



[jump storage="ep008.ks" target="*start"]

