*start


;###################################################################
*Ep017|I will change this body and the world for you.
;###################################################################
;//５、サツキ

[SCENE id=17]


[window target=false]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out" pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out" pos="3/5"]


[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="05"]

[window target=true]



[OnName num="renzi"]
"......, this is Satsuki."
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy527"]
[OnName num="dorothy"]
What?"　Who's Satsuki?"
[cpg cn=true]


[OnName num="renzi"]
No. It's nothing.
[cpg cn=true]


I was attracted to Satsuki. We didn't have much in common, but the little contact we did have was intense.
[cpg]


I found myself feeling this feeling, which was almost like love at first sight.
[cpg]


[FO pos="2/3" time=1000]

[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



Once I realized this, I couldn't stand still.
[cpg]


Fortunately, my success in capturing Kulara was greater than I had expected, and it didn't stop me from saying that I was leaving the dungeon.
[cpg]

[BG f="b_01_5.ui" time=1000]
[WAIT time=1500]

[OnName num="renzi"]
I'll be right back. Don't worry.
[cpg cn=true]


[OnName num="rudolf"]
I hope so, but there are many dangers outside the dungeon for the demons. Be careful.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy528"]
[OnName num="dorothy"]
I'm telling you the truth. If you ever get lonely, you can always come back."
[cpg cn=true]


Dorothy says this as if she is doing me a favor.
[cpg]


I'm sorry to ignore those feelings, but I've made up my mind.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（昼）******************************************************



Satsuki. I head for her place.
[cpg]


[SE f=se020]
;//【ＳＥ】『草原歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『鬼の集落』（昼）******************************************************





I felt that it was not a good idea to dress up as an ogre or a human when heading to the ogre village.
[cpg]


For now, I'll take the form of a goblin, so that people can tell at a glance that I'm a demon tribe.
[cpg]


[OnName num="demon"]
What is it ......?"　What's a demon doing all the way out here?"
[cpg cn=true]


[OnName num="renzi"]
I'm looking for someone. I won't do anything. Can you let me in the gate?"
[cpg cn=true]


[OnName num="demon"]
If I were ...... human, I would have turned him away. Just don't cause me any trouble."
[cpg cn=true]


Then, he looks for Satsuki. I somehow remembered the line of houses.
[cpg]

[SE f=se009]
;//【ＳＥ】『歩く』

[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





;//[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Satuki108"]
[OnName num="satsuki"]
'...... the shapeshifter from that time?　Really, you can look like anything you want."
[cpg cn=true]


[OnName num="renzi"]
I need to talk to you for a minute. Can you take me up to your house?"
[cpg cn=true]





[window target=false]

[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（夕方）******************************************************





Satsuki's house was, as usual, too big for one person.
[cpg]


I think she told me that her parents had died early in her life.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki109"]
[OnName num="satsuki"]
So?　What's the story?"
[cpg cn=true]


[OnName num="renzi"]
...... that is."
[cpg cn=true]


I choose my words. Satsuki has never forgiven me.
[cpg]


Or rather, I had the feeling that the entire demon tribe treated me like an outsider.
[cpg]


This was before we were in love. I wondered how I could get to know her better.
[cpg]


[OnName num="renzi"]
I wanted to know what the humans were up to. I know they are at odds with the demons.
[cpg cn=true]


I quickly told him something I wasn't really interested in.
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki110"]
[OnName num="satsuki"]
I don't know either. We are demons.
[cpg cn=true]


That's it. Better not to step in now: ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（夕方）******************************************************





I decided to fill the outer moat first. I decided to disguise myself as another demon to get information about Satsuki.
[cpg]


[OnName num="renzi"]
"......, hey, okay?"
[cpg cn=true]


[OnName num="demon_A"]
Oh, it's you. What's up?"
[cpg cn=true]


I was disguised as another demon tribe look-alike, so people around me thought I had been there before.
[cpg]


If my true identity is discovered, they will be suspicious of me this time, but I can't say that.
[cpg]


[OnName num="renzi"]
About Satsuki, ...... is it true that she's in love with a human?"
[cpg cn=true]


[OnName num="demon_B"]
What?"　If you're going for it, give it up. Was she a human ...... priestess?　I'm crazy about that guy."
[cpg cn=true]


[OnName num="renzi"]
Tell me more.
[cpg cn=true]


[OnName num="demon_A"]
Don't you know?　I thought you said you saved me when I wandered into a human village."
[cpg cn=true]


[OnName num="demon_B"]
As I recall, yes. What was his name, uh, ......?"
[cpg cn=true]



[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





As soon as I got the description of the priest, I left the village of the demon tribe.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（夜）******************************************************





The person she was in love with would not come to the demon tribe's village.
[cpg]


If that were the case, it would mean that I might be able to replace that person.
[cpg]

[SE f=se020]
;//【ＳＥ】『草原歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（朝）******************************************************





I went to the town of the humans and searched for the priest.
[cpg]


[OnName num="renzi"]
I found him at .......
[cpg cn=true]


Well, he is certainly a manly man. But he seems a year older than Satsuki.
[cpg]


And there was a woman who looked like ...... his wife and a child.
[cpg]


Satsuki's love has become an unfulfilled love. ...... No, I can still be with Satsuki.
[cpg]


In any case, I can't start without transforming into him.
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





The first time I went back to the village of the demon tribe after I was able to transform into a priest, I was in the middle of the village.
[cpg]


It was already late, so I got an inn and left in the morning ......
[cpg]





[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（昼）******************************************************





If I were a real priest instead of a shapeshifter, I would get a gate pass.
[cpg]


But I could go in quietly. That was my strength.
[cpg]


[OnName num="demon"]
You're here again. What do you want so many times?
[cpg cn=true]


I couldn't answer honestly and made up a suitable reason, saying that I was a messenger of the Demon King.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（夕方）******************************************************

;**【ＣＧ】ci_26_0 ***********************
;//カットイン
[CUTIN f="ci_26_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]



And that evening. I finally met Satsuki, disguised as a priestess.
[cpg]

[CUTIN f="ci_26_0.ui" show={false} method="slideout"]
[WAIT time=1000]

[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Satuki111"]
[OnName num="satsuki"]
You are ......
[cpg cn=true]


The look on Satsuki's face the moment we met was unforgettable.
[cpg]


A look of surprise. Perhaps this is the kind of expression one gets when reuniting with the person of one's destiny.
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki112"]
[OnName num="satsuki"]
"I've been wanting to ...... meet you for a long time. Why did you come here?
[cpg cn=true]


[OnName num="renzi"]
I had to come here on a business trip. I was wondering how you were doing."
[cpg cn=true]


Would they be convinced by the reason that it was a personal errand?　I thought ......
[cpg]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Satuki113"]
[OnName num="satsuki"]
I see. Really ...... much better looking than when we first met."
[cpg cn=true]


Satsuki had the look of a maiden in love. It didn't seem to bother her that what I was saying didn't add up.
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Satuki114"]
[OnName num="satsuki"]
'...... are you going to stay the night?　If we go back into town now, it will be night."
[cpg cn=true]


[OnName num="renzi"]
Oh," he said. I'm thinking of doing that."
[cpg cn=true]


[FACE method="change21"  pos="2/3"]
[VOICE f="Satuki115"]
[OnName num="satsuki"]
Yes," he said. I'll prepare the dishes.
[cpg cn=true]


Satsuki had a buoyancy I had never seen before. I felt a little sorry for her.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





After dinner, she came on to me.
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki116"]
[OnName num="satsuki"]
I've always wanted to repay you.
[cpg cn=true]


[OnName num="renzi"]
I see. ......
[cpg cn=true]




[FACE method="change_6"  pos="2/3"]
[VOICE f="satuki117"]
[VOICE f="sSatuki003"]
[OnName num="satsuki"]
;//「いえ……恩返し、なんて言葉じゃ説明つきませんね。貴方に、こういうことがしたかった」
No, ......, "repay" doesn't even begin to describe it.
[cpg cn=true]


[FACE method="change_6"  pos="2/3"]
[VOICE f="satuki118"]
[VOICE f="sSatuki004"]
[OnName num="satsuki"]
;//「淫乱だって思ってくれて結構です。事実、そうかもしれません」
Do you think I'm a little bit of a prude?"
[cpg cn=true]


Then Satsuki sticks close to me.
[cpg]


[OnName num="renzi"]
I don't think so. I don't think that.
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Satuki119"]
[OnName num="satsuki"]
I see that you are ...... kind. I love that about you."
[cpg cn=true]

;//移植前シーンカット

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト


Then Satsuki and I talked for a while.
[cpg]


At first I was trying to fool Satsuki, but she was starting to get a little ragged.
[cpg]

[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki144"]
[OnName num="satsuki"]
She said, "By the way, it's been a long time since I've seen you. How did you get here?
[cpg cn=true]


[OnName num="renzi"]
It's ......
[cpg cn=true]


I see. Is it strange that I can come here? If you were a normal person, you'd be at the gate.
[cpg]


It's no wonder they've already figured out that I'm the only one who can get in this far.
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki145"]
[OnName num="satsuki"]
The fact that you're at a loss for a reply means that you're ...... a ...... person after all."
[cpg cn=true]

Exhaling, Satsuki continued.
[cpg]

[FACE method="change_3"  pos="2/3"]
[VOICE f="Satuki146"]
[OnName num="satsuki"]
Renji, I see. If anyone could pull off a trick like this, it would be him.
[cpg cn=true]


I've found out who I am. My plans were soon to be foiled.
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki147"]
[OnName num="satsuki"]
What do you think you're doing?　Are you trying to get on my case?"
[cpg cn=true]


[OnName num="renzi"]
...... sorry."
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Satuki148"]
[OnName num="satsuki"]
I'm glad you feel that way. But it's the real him I want to love."
[cpg cn=true]


[OnName num="renzi"]
But ......, the real thing is...
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki149"]
[OnName num="satsuki"]
The real what?　Are you still hiding something?
[cpg cn=true]


[OnName num="renzi"]
The real one looked like he was already married. He had a child.
[cpg cn=true]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Satuki150"]
[OnName num="satsuki"]
...... yeah."
[cpg cn=true]


Satsuki looked more than a little upset.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ヒロイン５の家＿室内』（昼）******************************************************





I was asked to stay at her place for a while. I told her I'd do it, and she didn't refuse.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki151"]
[OnName num="satsuki"]
I thought about it ...... all night after that.
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki152"]
[OnName num="satsuki"]
'If the real him is happy with someone else. I don't think I'm going to ruin his happiness anymore."
[cpg cn=true]


[OnName num="renzi"]
「……そうか」
[cpg cn=true]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Satuki153"]
[OnName num="satsuki"]
So I just want to say that it's okay to be an ...... imposter." Will you stay by my side just a little while longer?"
[cpg cn=true]


If the real one is married, he says, the only one he can love is me, the imposter.
[cpg]


I had mixed feelings. Perhaps he would not love me if I were no longer in this form. ......
[cpg]


[OnName num="renzi"]
Oh." I get it."
[cpg cn=true]


I decided to spend some time being the person Satsuki wanted me to be for a while.
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





Another night is coming. I was the only one who could give her what she wanted.
[cpg]


Just stroking her hair, she looked satisfied.
[cpg]


But deep down inside, I just couldn't satisfy her.
[cpg]


The time with Satsuki passes. It was time to see where true love lies.
[cpg]


I was troubled, but Satsuki must have had mixed feelings too.
[cpg]


Even if she loved me in the guise of a priestess, she might not be able to say that she loved me in and of myself.
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





We continued to keep our distance from each other with similar problems.
[cpg]




[window target=false]

[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（朝）******************************************************





[OnName num="demon_A"]
It seems that the demon tribe and humans are getting a little tense again.
[cpg cn=true]


[OnName num="demon_B"]
Oh," he said. If things go on like this, it could turn into a war."
[cpg cn=true]


In the midst of all this, I heard from the wind that the battle between humans and demons was intensifying.
[cpg]


[OnName num="demon_A"]
Apparently, the demon tribe side has been cheating ......
[cpg cn=true]


[OnName num="demon_B"]
What could possibly be so unprofitable?　I thought you said the humans made this up."
[cpg cn=true]


I'm listening to all this talk from a distance.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Satuki178"]
[OnName num="satsuki"]
Shouldn't you be out there fighting?
[cpg cn=true]


Satsuki asked. I owe a debt of gratitude to the demon tribe as well.
[cpg]


[FACE method="change_4"  pos="2/3"]

[VOICE f="Satuki179"]
[OnName num="satsuki"]
I'm also a member of the ...... demon tribe, and we're all hoping for the same thing. I hope the battle will be over soon.
[cpg cn=true]


Is ending this battle also for the sake of the demon tribe that has been caught in the middle?
[cpg]


[OnName num="renzi"]
...... I suppose so."
[cpg cn=true]


Satsuki's words encouraged me to decide to join the fight.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（昼）******************************************************


[SE f=se020]
;//【ＳＥ】『草原歩く』


I am weak in a head-to-head fight. I decided to disguise myself in human form to distract them.
[cpg]


So, if there is anything I can do, for example, assassinate someone in the king's entourage or ......?
[cpg]


I don't have the courage to kill people. But I wonder if I have to.
[cpg]


Can't we reduce the human side's military strength more peacefully? ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（昼）******************************************************





With this in mind, I disguised myself as a soldier.
[cpg]


I aimed at the armory, the powder magazine, and other places where it would be difficult for ordinary demons to get in.
[cpg]


[OnName num="soldier"]
I thought to myself, "Oh, have I already taken my turn ......?　Well, take good care of him."
[cpg cn=true]


[OnName num="renzi"]
I'll take care of it. I'll protect this place."
[cpg cn=true]


With these words, they deflected the troops from the inside.
[cpg]





[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="07"]

;//【ＢＧ】『街』（夜）******************************************************


For a while, that was fine. People didn't know what was going on.
[cpg]

But it didn't work out that way forever.
[cpg]

Apparently, Kulara had escaped from the dungeon. She seemed to be telling them everything.
[cpg]

In other words, that there is a demon called ...... shapeshifter.
[cpg]

[OnName num="citizen_A"]
Is it true ...... that there are demons that can turn into humans?"
[cpg cn=true]


[OnName num="citizen_B"]
Yeah. I heard they are attacking the armory. They're going to kill people soon.
[cpg cn=true]


[OnName num="citizen_A"]
There's talk of putting a bounty on him, isn't there?
[cpg cn=true]


[OnName num="citizen_B"]
I heard so. Even if they don't, people are looking for them with all their eyes.
[cpg cn=true]


[OnName num="renzi"]
"......"
[cpg cn=true]


I couldn't stay in town. Everywhere I go, everyone is out to get me.
[cpg]


I tried to blend in with the city and took on human form,...... but.
[cpg]



[FACE method="slidein" pos="4/7"]

[BG f="b_07_4_up.ui" time=1500]
[WAIT time=2000]
;//ブラックアウト


[SE f=se010]
;//【ＳＥ】『走る』

[OnName num="wizard"]
There he is!　He ran that way.
[cpg cn=true]


[OnName num="soldier"]
'Block the road to the main street!　Everything else is a cul-de-sac!"
[cpg cn=true]



It was not enough to just be disguised as a human being.
[cpg]


There seemed to be an entity called the Wizard. No matter how I turned out, they had the power to find me.
[cpg]


[OnName num="renzi"]
Damn it. ......
[cpg cn=true]


I was found in the city and soldiers are everywhere.
[cpg]


I couldn't escape and they caught me.
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（昼）******************************************************


[SE f=se014]
;//【ＳＥ】『弓を引き絞る・縛る』

I was in human form at the time. I was bound and unable to move, but I thought I could escape by transforming into another form.
[cpg]


However, the magician had used a strange technique on me, and I was unable to transform myself.
[cpg]


[OnName num="soldier_A"]
He was unable to escape by transforming himself into another form. You can't escape now.
[cpg cn=true]


[OnName num="soldier_B"]
You're giving me a hard time," he said. Now you're finished."
[cpg cn=true]


I was being walked to the executioner's block. If I die like this, surely this time it will be the end.
[cpg]


What are the possibilities for a comeback from this?
[cpg]


The more I think about it, the more I have nothing. Would Dorothy or Janice come?
[cpg]


Even if they did, they wouldn't know it was me. I would look human.
[cpg]


They would look like ordinary guilty people. If that were the case, there would be no reason for them to help me.
[cpg]


So, if they would help me out: ......
[cpg]


[SE f=se016]
;//【ＳＥ】『倒れる』


[OnName num="soldier_A"]
What?　What the hell is this?
[cpg cn=true]


[OnName num="soldier_B"]
"Are you a demon tribe? ......!　Wait, hey!
[cpg cn=true]


[FG f="CHA05_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Satuki180"]
[OnName num="satsuki"]
This way. Renji."
[cpg cn=true]


Satsuki came to my rescue. How did she know it was me?
[cpg]


No, that's not the point now. I just decided to get out of there.
[cpg]




;//ブラックアウト



[SE f=se010]
;//【ＳＥ】『走る』


[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（夕方）******************************************************





[OnName num="renzi"]
"Ha, ha, ha."
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Satuki181"]
[OnName num="satsuki"]
'...... that was a close call. That's one hell of a coincidence."
[cpg cn=true]


Apparently, when he came to visit the priest, he happened to pass by.
[cpg]


I escaped with my life and made it to the outskirts of town. The sorcerer's art had been broken and I was able to transform again.
[cpg]


[OnName num="renzi"]
How did they know it was me when I was ...... dressed completely differently?
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Satuki182"]
[OnName num="satsuki"]
I don't really understand it either. But I know it's you."
[cpg cn=true]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Satuki183"]
[OnName num="satsuki"]
Maybe he thought you were ...... you in some way other than your appearance."
[cpg cn=true]


Are you trying to say that you love me for what I am not on the outside?
[cpg]


I don't say it out loud, but there was a hint of it.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（夜）******************************************************





Then we walked back to the village of the demon tribe.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="satuki184"]
[VOICE f="sSatuki005"]
[OnName num="satsuki"]
;//「最初はね。私の思い人に化けられるからって理由で、そういうこともしてたわ」
At first. "At first, I wanted to stay with you because you could turn into the person I wanted.
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki185"]
[OnName num="satsuki"]
But now it's different. He wanted to end the fight for us."
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Satuki186"]
[OnName num="satsuki"]
I was genuinely happy. I felt I had to help you."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





Then we returned to her house again.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki187"]
[OnName num="satsuki"]
She said, "...... I've given up on that love of my life. I found a new love."
[cpg cn=true]


How much does she really mean it? I wonder if she really fell in love with me from something like an accident like this.
[cpg]


[OnName num="renzi"]
Is she serious?"　I didn't do anything."
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Satuki188"]
[OnName num="satsuki"]
How can you say that? You were almost killed for the sake of the demon tribe.
[cpg cn=true]


As she said this, Satsuki pressed closer to me.
[cpg]



;//========================================
;//●ＣＧ（主人公に迫るヒロイン。覆い被さる感じ）ev_64
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン５の部屋
;//時間　：夜
;//備考　：主人公は兵士に化けています
;//=======================================

;//*Scene059
[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="10"]
;**【ＣＧ】 ev_64_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sSatuki006"]
[OnName num="satsuki"]
She said, "...... Renji. Stay with me.
[cpg cn=true]


[VOICE f="sSatuki007"]
[OnName num="satsuki"]
You don't have to go anywhere anymore."
[cpg cn=true]


Then he reaches out his hand to my cheek.
[cpg]


I couldn't say anything, but I was happy just to feel Satsuki's body heat.
[cpg]


I loved her before she loved me. ......
[cpg]

;**【ＣＧ】 ev_64_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=1500]

;//移植前シーンカット

[VOICE f="sSatuki008"]
[OnName num="satsuki"]
I want to kiss you. May I?"
[cpg cn=true]

[OnName num="renzi"]
...... yeah."
[cpg cn=true]


Our lips touch. I will never forget that feeling.
[cpg]


That day, Satsuki and I fell asleep together.
[cpg]


;//ブラックアウト



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（昼）******************************************************



And from then on, I was to stay in the demon village.
[cpg]


If I went back to the city, I would probably be killed this time.
[cpg]


I could have gone back to the dungeon, but I couldn't take Satsuki with me.
[cpg]


I decided to stay, despite being treated like an outsider.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（昼）******************************************************





I didn't feel very good about going outside. No matter how far I went, I would always be a foreigner to the community.
[cpg]


However, being by Satsuki's side was enough to make me feel as if all my stresses were gone.
[cpg]


I had a lot of things I wanted to talk about with Satsuki.
[cpg]


And it seemed to be the same for her, too.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki235"]
[OnName num="satsuki"]
When you came to visit me for the first time in a long time, I didn't even recognize you.
[cpg cn=true]


That being said. And yet, on the verge of being executed, he recognized me even though I looked different.
[cpg]


[OnName num="renzi"]
......I really don't know how they knew."
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki236"]
[OnName num="satsuki"]
I guess it just goes to show that looks don't matter."
[cpg cn=true]


Does this mean that they are proof that they are attracted to each other and not to appearances?
[cpg]


[OnName num="renzi"]
I hope we all realize that."
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Satuki237"]
[OnName num="satsuki"]
It's true," he said. The differences between demons and humans, or even demons, are trivial.
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（夕方）******************************************************




After that, I continued to live with Satsuki. We shared the household chores and tried to get along with the demons.
[cpg]


The days passed slowly. Being by Satsuki's side felt fulfilling.
[cpg]



As I communicated with the various demons, my ability to transform was transformed.
[cpg]


In other words, I became able to transform into demons that were nowhere to be found.
[cpg]

;**【ＣＧ】ci_25_0 ***********************
;//カットイン
[CUTIN f="ci_25_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

This was convenient for me and for those around me.
[cpg]


As long as I looked like a demon, I could blend in a little easier, and since I wasn't someone else, I couldn't be mistaken for anyone else.
[cpg]


[CUTIN f="ci_25_0.ui" show={false} method="feadout"]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Satuki259"]
[OnName num="satsuki"]
It's strange to be transformed into something that doesn't exist, isn't it?
[cpg cn=true]


[OnName num="renzi"]
Me too. But I finally feel like the real me."
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Satuki260"]
[OnName num="satsuki"]
'Maybe so,' he said. I don't care what I look like."
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Satuki261"]
[OnName num="satsuki"]
But if Renji is satisfied, that's the best.
[cpg cn=true]


;//ブラックアウト

She seemed to be in love with me. I was kind of apologetic about it.
[cpg]


As much as I like her too, this relationship will last forever.
[cpg]


We can seek each other as many times as we want. That's how lovers are, even if there is nothing missing in each other's life.
[cpg]

;//移植前シーンカット


We fell asleep together. Satsuki and I will always be together.
[cpg]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[FO pos="2/3" time=1]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[STOPBGM]
[window target=true]

;//========================================
;//●ＣＧ（キス。朝起きてすぐ、布団にまだ入っているような感じ）ev_68
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン５の部屋
;//時間　：朝
;//備考　：主人公は鬼に化けています
;//=======================================



[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_68_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1500]


[SE f=se024]
;//【ＳＥ】『鳥の鳴き声』


Morning. I wake up to her kiss.
[cpg]


[OnName num="renzi"]
...... Good morning.
[cpg cn=true]



[VOICE f="Satuki287"]
[OnName num="satsuki"]
Giggle. Good morning, Renji."
[cpg cn=true]


Satsuki parted her lips and laughed at my sleepwalking.
[cpg]



[VOICE f="Satuki288"]
[OnName num="satsuki"]
'I should probably get breakfast ready,' she said.
[cpg cn=true]


[OnName num="renzi"]
No, wait a minute. Let's just stay like this for a little while longer."
[cpg cn=true]

;**【ＣＧ】 ev_68_a ***********************
[CG id=19 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Satuki289"]
[OnName num="satsuki"]
I'm going to go to ...... and see what I can find out. You're a sweetheart."
[cpg cn=true]


I kiss Satsuki again.
[cpg]



[VOICE f="Satuki290"]
[OnName num="satsuki"]
I wonder what will happen now. The war between demons and humans is still going on.
[cpg cn=true]


[OnName num="renzi"]
I hear that's true. Some say it's starting to subside a bit. ......"
[cpg cn=true]

 

[VOICE f="Satuki291"]
[OnName num="satsuki"]
Someday, when there is real peace and there is no more separation between the demon and ogre races,...... let's get married."
[cpg cn=true]


Satsuki used quite a bit of courage to say those words.
[cpg]


[OnName num="renzi"]
'Oh,' she said, 'I'm sorry. Of course. I have to do what I can for that.
[cpg cn=true]

;**【ＣＧ】 ev_68_b ***********************
[CG id=19 index=2 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Satuki292"]
[OnName num="satsuki"]
Don't get caught again. I don't want to have to go through that scary experience again.
[cpg cn=true]


[OnName num="renzi"]
I'll make it work. I think I can do it now.
[cpg cn=true]


I had a meaningless, baseless confidence. Was this also the power of love?
[cpg]

[SCENE id=22]


;//ＥＮＤ　ヒロイン５ルート

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="epend.ks" target="*start"]


;//==============================



