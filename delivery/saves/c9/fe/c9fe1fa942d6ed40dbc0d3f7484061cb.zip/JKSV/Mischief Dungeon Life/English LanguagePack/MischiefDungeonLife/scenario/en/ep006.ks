*start

;###################################################################
*Ep006|The Law of Transformation
;###################################################################


[SCENE id=6]

[window target=false]


[BG f="black.ui"  time=1000]
[WAIT time=1000]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]

[stflag Jumpflg = 0]


[if exp={getFlagValue("Jumpflg") == 0 }]
[stflag Cha1flg = 1]
[stflag Cha2flg = 1]
[stflag Cha3flg = 0]
[stflag Cha4flg = 0]
[stflag Cha5flg = 0]

[stflag Gameflg = 0]

[stflag Jumpflg = 1]
[endif]



[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





I do whatever I want to do. I was aware of this, but that didn't stop me.
[cpg]


No one can stop me. I can't even realize that I did it.
[cpg]

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

I transformed myself to look just like Janice and checked my reflection in front of the mirror.
[cpg]



;//ここからしばらく、ジャニスのセリフ名前欄を「ジャニス（蓮司）」と置き換えてください



[FG f="CHA03_p4_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Janice051"]
[OnName num="renzi_to_janice"]
Surprisingly, you have big breasts. ...... Oh, there's a mole here."
[cpg cn=true]


You can see every detail of her body. Even though I didn't see everything.
[cpg]


I can imagine that there must be some kind of magical power at work.
[cpg]


There must just be some trigger to be able to transform. It's not like you have to know everything to be able to transform.
[cpg]

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1500]
[WAIT time=1000]
;//ブラックアウト





And I slept that day in Janice's form.
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





I went to the cafeteria in my sleepy state, still in that outfit.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="4/5" time=800]
[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Dorothy045"]
[OnName num="dorothy"]
What's that?　Janice, we just passed each other a few minutes ago."
[cpg cn=true]


Dorothy surprised me. Oh, so I'm dressed as Janice now.
[cpg]

[FACE method="change_7" pos="2/5"]
[VOICE f="Janice052"]
[OnName num="renzi_to_janice"]
No, I'm Renji."
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Dorothy046"]
[OnName num="dorothy"]
Oh, I see. ...... what a surprise."
[cpg cn=true]



;//ここからジャニスのセリフ名前欄を元に戻してください


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FO pos="2/5" time=1]
[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



It was indeed confusing, so I left my transformation unmasked ......, or rather, dressed differently.
[cpg]


My usual golem outfit. I can't talk in this outfit, but it's easier to walk around in if I'm going to spend time in my everyday life.
[cpg]


If I were a human-like slime, I could talk, but it would be hard to move.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy047"]
[OnName num="dorothy"]
But if I met Janice while dressed as Janice, she would probably be surprised."
[cpg cn=true]


Dorothy chuckles with a hand to her chin as if scheming.
[cpg]


But maybe so. She's not very good with ghosts, so she might mistake me for a doppelganger or something.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="07"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



Janice told me that she was on the night shift and is still sleeping.
[cpg]


I go toward her room. Of course, I'll dress up as Janice in advance to surprise her.
[cpg]


I recall her in detail. The way she looks, even the way she smells: ......
[cpg]


I already know Janice's scent. As I recall, it was like this.
[cpg]



;////////////////////////
;////////////////////////
;//二度目の変身システム//
;////////////////////////
;////////////////////////


;//選択肢用フラグ
[stflag IseSel02flg = 0]

I'm pretty sure the first smell is ......
[cpg]


[switch]
[case "Vanilla"]
	[swap]
	[jump target="*hen21"]
[case "Fruits"]
	[swap]
	[stflag IseSel02flg = 1]
	[jump target="*hen21"]
[case "Flower"]
	[swap]
	[jump target="*hen21"]
[endswitch]


*hen21|変身の法則


The second smell is ......
[cpg]



[switch]
[case "mint"]
	[swap]
	[stflag IseSel02flg = 1]
	[jump target="*hen22"]
[case "Perfume"]
	[swap]
	[jump target="*hen22"]
[case "soap"]
	[swap]
	[jump target="*hen22"]
[endswitch]

*hen22|変身の法則


[window target=true]

[WAIT time=100]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FACE method="out" pos="4/7"]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="04"]


[window target=true]

[if exp={getFlagValue("IseSel02flg") == 2 }]
[jump target="*select02_2"]
[endif]



[jump target="*select02_1"]

;//■選択肢Ａ
1. vanilla
2. fruit
3. flower

;//■選択肢Ｂ
4, mint
5. Perfume
6, soap





;//==============================
;//２、果物　４、ミント　を選んでいた場合
*select02_2|変身の法則

[window target=false]

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

[window target=true]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="2/3" time=800]


I succeeded in my transformation and involuntarily muttered, "Okay.
[cpg]



;//どこからどう見てもジャニスだ。その姿のまま、彼女の部屋まで向かう。

For all intents and purposes, I am Janice.
[cpg]

I guess you could say the transformation was a success.
[cpg]

In that form, I headed up to her room. I had a bit of a prank on my mind.
[cpg]


[SE f=se009]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//ブラックアウト

[window target=true]

[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/5" time=800]

[VOICE f="sJanice002"]
[OnName num="janice"]
"What ...... me, you two ......?"
[cpg cn=true]


When I headed to her room in this form, Janice was taken aback.
[cpg]

[FACE method="change_5" pos="4/5"]

[FO pos="2/5" time=1000]

[SE f=se016]
;//【ＳＥ】『倒れる』

Then, perhaps realizing the situation, she slumped down and passed out.
[cpg]


It seems that she really doesn't like ghosts.
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[BGM f="02"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/5" time=800]

[VOICE f="sJanice003"]
[OnName num="janice"]
She said, "I had a weird dream about ....... It was a dream in which there were two of me."
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="sArsha008"]
[OnName num="asha"]
What's that?　You mean like astral projection?"
[cpg cn=true]


[FACE method="change_4" pos="2/5"]
[VOICE f="Janice073"]
[OnName num="janice"]
No, ...... it didn't seem to be anything like that."
[cpg cn=true]


I knew everything and kept quiet.
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Arsha093"]
[OnName num="asha"]
What do you think, Renji?　I wonder if I'm possessed by some kind of ghost."
[cpg cn=true]


[OnName num="renzi"]
Come on. Come on."
[cpg cn=true]


What a thing to say, but the truth is, I know everything.
[cpg]


[OnName num="renzi"]
More importantly, my metamorphosis, I'm beginning to understand the law."
[cpg cn=true]


I said this to get off the subject.
[cpg]



;//ヒロイン３ルートの可能性が残る

[jump target="*select02_3"]

;//==============================
;//２、果物　４、ミント　のいずれかを外した場合
*select02_1|変身の法則


I couldn't remember clearly and it took me a long time to transform.
[cpg]


I could have transformed right away earlier. Am I missing some information to transform?
[cpg]


In any case, I was so drained of energy that by the time the transformation worked, I had no energy left to play a trick on Janice herself.
[cpg]


I had no choice but to go to sleep in Janice's form. ......
[cpg]




;//ブラックアウト

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[BGM f="02"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=800]

And the next day. I met Janice and Asha in the cafeteria.
[cpg]


I realized something about this time and decided to tell them both.
[cpg]


[OnName num="renzi"]
I said to them, "Can I have a word? I've figured out the law about my transformation.
[cpg cn=true]



;//ヒロイン３ルートの可能性がなくなる


[stflag Cha3flg = -1]


;//==============================

*select02_3|変身の法則



[FACE method="change_1" pos="4/5"]
[VOICE f="Arsha094"]
[OnName num="asha"]
I see. Come to think of it, there are some things you can't turn into.
[cpg cn=true]


[OnName num="renzi"]
Oh," he said. Asha has been able to turn me before, and now I know why.
[cpg cn=true]


And if my hypothesis is correct, it would explain why I was able to transform into an inorganic object.
[cpg]


[OnName num="renzi"]
If he could simply transform into something mechanical or something like that, then it would be strange for him to be able to transform into Asha."
[cpg cn=true]


[OnName num="renzi"]
I thought, "Maybe it's because I'm a beast, but I couldn't turn into any other beast ...... so I figured what's the difference?"
[cpg cn=true]


[OnName num="renzi"]
I don't think it's enough to draw a line in the sand simply because I know some things about Asha.
[cpg cn=true]


They nod and listen to me. Then I spoke my conclusion.
[cpg]


[OnName num="renzi"]
'Maybe it's the smell. Asha has a smell when we first meet, and inorganic-looking demons don't have a smell from the get-go."
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Arsha095"]
[OnName num="asha"]
'Nah, I see. ......?　How is that possible?"
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Janice074"]
[OnName num="janice"]
I also hear that each shapeshifter has a different set of circumstances under which they can transform. It's possible.
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Arsha096"]
[OnName num="asha"]
But there's no way to know for sure. I don't know if it's true or not.
[cpg cn=true]


[OnName num="renzi"]
No, you can be sure. All you have to do is smell the other demons."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/5" time=1]
[FO pos="4/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

So I sniffed various demons.
[cpg]


I stayed dressed as a slime so as not to creep them out.
[cpg]


If I did that dressed as Asha or Janice, they would think I was a pervert and I would get in trouble.
[cpg]


I had a sense of smell even in my slime state. More to the point, I had it when I was a golem.
[cpg]


I guess this was something I could do, working backwards from my abilities.
[cpg]


If I couldn't smell from my first form, I couldn't transform into anything.
[cpg]

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

[OnName num="goblins"]
You know, "......?　What's with this slime, it's getting awfully close."
[cpg cn=true]


[OnName num="orc"]
I think he's smelling you.
[cpg cn=true]


[OnName num="goblins"]
Don't be creepy. What's the use?"
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





Then I go back to my room and try to turn into a goblin.
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_09_0 ***********************
;//カットイン
[CUTIN f="ci_09_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


[OnName num="renzi"]
I could ......."
[cpg cn=true]


My hypothesis was correct. I can now turn into a goblin. ......
[cpg]


I can't do this. I have to learn to smell more demons.
[cpg]


The range of mischief I can do is about to expand, I thought to myself, smiling.
[cpg]

[CUTIN f="ci_09_0.ui" show={false} method="slideout"]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





So, I usually disguise myself as a slime or golem, and repeat the days of approaching demons and learning their smells. As a result ......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[BGM f="08"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


[SE f=se017]
;//【ＳＥ】『竜の唸り』

;**【ＣＧ】ci_10_0 ***********************
;//カットイン
[CUTIN f="ci_10_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]


I was even able to turn into a giant dragon.
[cpg]

[CUTIN f="ci_10_0.ui" show={false} method="feadout"]
[WAIT time=1000]

[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/5" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="4/5" time=800]

[OnName num="rudolf"]
That's impressive."
[cpg cn=true]



[VOICE f="Dorothy048"]
[OnName num="dorothy"]
"Yeah, isn't that great ...... bigger than your original height ......?"
[cpg cn=true]


[OnName num="rudolf"]
I can only say it's magic. I'm also curious as to how it weighs."
[cpg cn=true]


Indeed. If it's heavier than the original weight, it doesn't seem to add up, no matter how magical it is.
[cpg]


But is there such a thing as summoning magic? I wonder if there is any in this world.
[cpg]


[OnName num="renzi"]
Thank you."
[cpg cn=true]


Of course, there is a dragon that is the source of the transformation, so you can't transform into something that isn't there.
[cpg]


[FACE method="change_1" pos="2/5"]
[VOICE f="Janice075"]
[OnName num="janice"]
Now, if it could breathe fire, there would be nothing to say. ......
[cpg cn=true]


[OnName num="renzi"]
That's just not possible. It was the same with Undine."
[cpg cn=true]


[OnName num="rudolf"]
'That's great power, by the way. We, too, will make our strategy based on the premise that we can transform into anything."
[cpg cn=true]


[OnName num="rudolf"]
I have high expectations for you, and so does Dorothy. "We're counting on you, Dorothy and I. We're counting on you to use your power.
[cpg cn=true]


I didn't feel bad about the compliment, but I still had other things on my mind.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/5" time=800]

[VOICE f="Janice076"]
[OnName num="janice"]
'...... are you only addressing me and the Demon Lord with honorifics?'
[cpg cn=true]


[OnName num="renzi"]
'Yes,' he said. Dorothy told me to stop using honorifics, so..."
[cpg cn=true]


[FACE method="change_4" pos="2/5"]

[VOICE f="Janice077"]
[OnName num="janice"]
I see. ......"
[cpg cn=true]


Janice looked a little disappointed and didn't know why.
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Dorothy049"]
[OnName num="dorothy"]
'Are you frustrated because you feel like you've been singled out?'
[cpg cn=true]


[FACE method="change_5" pos="2/5"]
[VOICE f="Janice078"]
[OnName num="janice"]
No, no, no, no. No, it's not like that.
[cpg cn=true]


[FACE method="change_2" pos="4/5"]
[VOICE f="Dorothy050"]
[OnName num="dorothy"]
'Renji, you can talk to Janice as normal. She seems lonely.
[cpg cn=true]


[FACE method="change_6" pos="2/5"]
[VOICE f="Janice079"]
[OnName num="janice"]
So, that's not ...... true."
[cpg cn=true]


I watched the two of them talk over each other, a little relieved.
[cpg]


[OnName num="renzi"]
'Well, I guess I'll let you do that. Janice."
[cpg cn=true]


I called her out on it. Janice seemed to soften her expression a bit.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





Once I left Dorothy and Janice, I was alone in the bedroom.
[cpg]


I start to think of more mischief. For example, I can now transform myself into an insect demon.
[cpg]


I heard that insect demons are not intelligent, so even if they attack a girl, they won't know it's me.
[cpg]


But then again, if they are unintelligent, how would they know what kind of counterattack I would get?
[cpg]


[OnName num="renzi"]
But if it's the same demon, won't it hurt me? ......
[cpg cn=true]


These women are not purists. I think that is why they are in this dungeon.
[cpg]


So maybe it's okay for me to be a little reckless.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************

;**【ＣＧ】ci_11_0 ***********************
;//カットイン
[CUTIN f="ci_11_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

So, I was transformed into a giant bee.
[cpg]

[CUTIN f="ci_11_0.ui" show={false} method="slideout"]
[WAIT time=1000]

I see Dorothy in the distance. There are hardly any pedestrians in the corridors around here.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Dorothy051"]
[OnName num="dorothy"]
'In a place like this, an insect demon ......?　I wonder why."
[cpg cn=true]


On the contrary, I don't know how Dorothy could be in a place like this.
[cpg]


Anyway, I'm in a situation now where my true nature won't be revealed.
[cpg]



[SE f=se018]
;//【ＳＥ】『蜂の羽音』

[WAIT time=1000]


[FACE method="change_5" pos="2/3"]
[VOICE f="Dorothy052"]
[OnName num="dorothy"]
What the hell?　What?
[cpg cn=true]

I'll get close to you in the middle of the noise, and maybe touch you a little ......
[cpg]


I thought about it, but on second thought, I can't touch it with my hands, or rather my feet, as they are now.
[cpg]


;//移植前シーンカット

[FACE method="change_3" pos="2/3"]
[VOICE f="sDorothy001"]
[OnName num="dorothy"]
Shoo, shoo!　Go away!　Do you understand my words!
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





I leave Dorothy. If she chases me and catches me, I won't be able to talk my way out of it.
[cpg]


She was in a heap, so I quickly got away.
[cpg]



[SE f=se018]
;//【ＳＥ】『蜂の羽音』



I'm a bee now, but I was moving slow. I knew I couldn't copy that part of the bee.
[cpg]


But that doesn't mean I can't fly. It is strange.
[cpg]


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep007.ks" target="*start"]


