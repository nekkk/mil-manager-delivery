*start

;###################################################################
*Ep005|Even after the transformation, the brave are still afraid.
;###################################################################


[SCENE id=5]


[BG f="black.ui"  time=1000]
[WAIT time=100]


[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]


[window target=true]


And the next day.
[cpg]

[window target=false]





[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





I was always waking up at a certain time in this dungeon, which was always dimly lit.
[cpg]


I had been given one of those table clocks. Even without an alarm function, I could kind of wake up.
[cpg]


Still, I'd like to see the light of day at least once: ......
[cpg]


I know my body is a demon, so I guess I'm dealing with a world without light.
[cpg]


But I felt like my heart or soul as a human being is looking for light.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=800]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="4/5" time=800]

[VOICE f="Janice047"]
[OnName num="janice"]
Do you want to see the sun?"
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Arsha091"]
[OnName num="asha"]
But it's not safe near the ground. Humans will come out.
[cpg cn=true]


But I still want to see it. I explained this to him and asked him to show me the way to the ground.
[cpg]


[FACE method="change_7" pos="2/5"]
[VOICE f="Janice048"]
[OnName num="janice"]
I said, "If you insist,......, I'll show you.
[cpg cn=true]


[SE f=se009]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/5" time=1]
[FO pos="4/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





Janice took me halfway to the dungeon exit, or rather entrance ......?　I had come as close as I could.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Janice049"]
[OnName num="janice"]
Be careful," he said. If you see a human, you better run.
[cpg cn=true]


Taking Janice's advice, I headed toward the ground.
[cpg]

[SE f=se007]
;//【ＳＥ】『ゴーレム足音』

I took the form of a golem so that if I was spotted by a human, I would be able to escape from them.
[cpg]


Then, once on the ground, I went to ......
[cpg]



;//画面白く

[STOPBGM]


[window target=false]
[transition target={true} rule="tobira.webp" color={0xffffffff} time=2000]
[WAIT time=3100]
[FO pos="2/3" time=1]
[BG f="white.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0xffffffff} time=1]
[WAIT time=1]



[transition target={true} rule="tobira.webp" color={0xffffffff} time=1]
[WAIT time=1000]
[BG f="b_09_2.ui" time=1000]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0xffffffff} time=2000]
[WAIT time=3100]

[window target=true]
[BGM f="06"]
;//【ＢＧ】『平原』（昼）******************************************************



;//徐々に色調戻る





It was dazzling. Just dazzling.
[cpg]


I've heard it said that's what happens when you see the sun after a long time. ......
[cpg]


It was some kind of tearful light.
[cpg]


But I thought to myself, "I don't think the golem has an organ that can produce tears.
[cpg]


[SE f=se022]
;//【ＳＥ】『草むらが揺れる』
[WAIT time=1100]

There was a human being. I felt a jolt.
[cpg]


[OnName num="swordfighter"]
I wondered why a demon was in such a place. Is it scouting or something, going out on the ground?"
[cpg cn=true]


[OnName num="monk"]
What do we do now, Klara?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Clara001"]
[OnName num="clara"]
......"
[cpg cn=true]

[SE f=se014]
;//【ＳＥ】『弓を引き絞る』

Kulara, the female elf called, readied her bow.
[cpg]


I rush back to the basement. But are these women trying to challenge the dungeon?
[cpg]


If so, running away is only temporary. They will catch up with us.
[cpg]


[SE f=se007]
;//【ＳＥ】『ゴーレム足音』


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_06_0 ***********************
;//カットイン
[CUTIN f="ci_06_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

I quickly disguised myself as a slime and hid in a gap in the wall.
[cpg]

[CUTIN f="ci_06_0.ui" show={false} method="slideout"]
[WAIT time=1000]

[SE f=se010]
;//【ＳＥ】『走る』
[WAIT time=1000]

[OnName num="monk"]
He's not here. ...... where has he disappeared to?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Clara002"]
[OnName num="clara"]
Maybe it wasn't just a golem. It may have transformed and is lurking around here somewhere."
[cpg cn=true]



You're on the right track. If they see through me, I'm done.
[cpg]


But the stones, they didn't think the golem would turn into slime, so they just went straight through. ......
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="4/5" time=800]
[VOICE f="Janice050"]
[OnName num="janice"]
"You said Kulara was here!"
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Dorothy018"]
[OnName num="dorothy"]
You're not looking at it wrong, are you?　Renji doesn't know what Kulara looks like.
[cpg cn=true]


[OnName num="renzi"]
Yeah. But I think my buddy said it was Kulara."
[cpg cn=true]


I was a humanoid slime, talking to Janice and Dorothy.
[cpg]


[OnName num="rudolf"]
'I don't see any sign of you getting into the ...... depths.'
[cpg cn=true]


The demon king seemed to sense a presence as he said this.
[cpg]


It must mean that he is the one who controls the dungeon, and he may have some idea of where things are.
[cpg]


[FACE method="change_4" pos="2/5"]
[VOICE f="Dorothy019"]
[OnName num="dorothy"]
What shall we do, father?
[cpg cn=true]


[OnName num="rudolf"]
This time it might be a scouting mission, but it's possible that they will eventually invade deeper.
[cpg cn=true]


We were in the midst of a terrible scene. I guess I was saved in the nick of time.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/5" time=1]
[FO pos="4/5" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





Come to think of it, I could have died at any moment.
[cpg]


In this kind of worldview, when you're a demon and not a human, it's hard just to stay alive.
[cpg]


I shook my head, feeling strangely pessimistic.
[cpg]


[OnName num="renzi"]
I shook my head. "...... No, I should just enjoy the moment."
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[STOPBGM]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』


The time of day is night. Dorothy and Asha should be asleep by now.
[cpg]


Janice is only a warrior and her life pattern is hard to read, but ......
[cpg]


Dorothy is definitely going to be trying to sleep soon.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



With that in mind, I head over to Dorothy's place.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy020"]
[OnName num="dorothy"]
I ask, "Hmmm... ......?　Slime, what do you want?"
[cpg cn=true]


Dorothy thinks I'm a slime.
[cpg]


No wonder. I turn into slime a lot, but there are plenty of slimes who aren't me.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Dorothy021"]
[OnName num="dorothy"]
She's lonely and wants me to leave her alone.　Shall I play with you?"
[cpg cn=true]


She calls herself a big sister, but she is too innocent to say so.
[cpg]


How old is she?　Is it possible to say that they are generally younger than humans, since their lifespan would be different from humans?
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Dorothy022"]
[OnName num="dorothy"]
Kya!"
[cpg cn=true]

[SE f=se015]
;//【ＳＥ】『触手・スライム』

With this thought in mind, I took hold of her body.
[cpg]


She was on her ass, trying to shake me off.
[cpg]



;//========================================
;//●ＣＧ（床に座っているヒロインに近づく主人公）ev_09
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：無し
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公は人型のスライムに変身しています
;//========================================

;//*Scene004

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_09_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1500]



[VOICE f="Dorothy023"]
[OnName num="dorothy"]
I said, "No, don't ...... get away from me!"
[cpg cn=true]

[SE f=se015]
;//【ＳＥ】『触手・スライム』

Dorothy tries to push me away, but I can't do that because I'm slime.
[cpg]


I try to push, but it's like her arms are inside my body.
[cpg]


In this situation, the slime body comes in handy.
[cpg]

;**【ＣＧ】 ev_09_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Dorothy024"]
[OnName num="dorothy"]
What are you going to do, a slime doing this ......?
[cpg cn=true]


Surely a slime can fall in love with another species?
[cpg]


I think slimes will have children with other slimes.
[cpg]


Or do they multiply in a divisive way?　Either way.
[cpg]


I don't think they would fall in love with any other species. That's why Dorothy is surprised.
[cpg]


But then, that wouldn't explain the Asha one, would it?
[cpg]

[SE f=se015]
;//【ＳＥ】『触手・スライム』


In any case, I was amused by her reaction and was about to touch her.
[cpg]


;**【ＣＧ】 ev_09_b ***********************
[CG id=3 index=2 time=1000]
;***************************************
[WAIT time=1500]


[VOICE f="Dorothy025"]
[OnName num="dorothy"]
"Mmmm, it's cold. No, don't!"
[cpg cn=true]


She continues to hate it. It's a different reaction than Asha's or Janice's.
[cpg]


Rather than turning blue, her face is turning red.
[cpg]


[VOICE f="Dorothy026"]
[OnName num="dorothy"]
She says, "No, I said ......, haha, don't do anything."
[cpg cn=true]



;//移植前シーンカット

;//ブラックアウト

[SE f=se015]
;//【ＳＥ】『触手・スライム』


[VOICE f="Dorothy043"]
[OnName num="dorothy"]
Well, wait ......, I'm not going to let you get away with it."
[cpg cn=true]


Dorothy tried to stand up, but seemed unable to do so.
[cpg]


She seemed to be in a sort of a slump and couldn't follow me.
[cpg]


I took advantage of this and headed out of the room.
[cpg]

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[STOPBGM]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


I left Dorothy there, unable to move, and transformed into another form as soon as I left the room.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[SE f=se010]
;//【ＳＥ】『走る』

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Dorothy044"]
[OnName num="dorothy"]
Oh, ......, she's not here."
[cpg cn=true]


Now I'm dressed as a golem. It would have been obvious if I thought about it for a second, but Dorothy seemed confused.
[cpg]


I had to stop myself from laughing. I mean, it's a golem, so it's not funny to begin with. ......
[cpg]


Then I go back to my room. What am I going to do with this feeling I can't have?
[cpg]



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="ep006.ks" target="*start"]

